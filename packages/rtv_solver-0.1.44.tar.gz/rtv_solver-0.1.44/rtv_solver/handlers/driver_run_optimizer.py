"""
Driver Run Optimizer using Gurobi

This module provides functionality to reoptimize the ordering of stops
in a single driver_run using Gurobi optimization.
"""

import gurobipy as gp
from gurobipy import GRB
import numpy as np
import copy
import logging
from typing import Dict, List, Tuple, Optional

from .network_handler import NetworkHandler
from .payload_parser import PayloadParser
from ..structure.node import Node


class DriverRunOptimizer:
    """
    Optimizes the ordering of stops in a single driver_run using Gurobi.
    
    This class handles:
    - Time window constraints
    - Capacity constraints  
    - Pickup-delivery precedence constraints
    - Travel time minimization
    """
    
    def __init__(self, dwell_pickup: int = 180, dwell_dropoff: int = 60):
        """
        Initialize the optimizer.
        
        Args:
            dwell_pickup: Time spent at pickup locations (seconds)
            dwell_dropoff: Time spent at dropoff locations (seconds)
        """
        self.dwell_pickup = dwell_pickup
        self.dwell_dropoff = dwell_dropoff
        
        # NetworkHandler is already initialized by SwapHandler, no need to reinitialize
    
    def reoptimize_driver_run(self, driver_run: Dict, depot: Dict, objective: str = "travel_time") -> Tuple[Dict, float, bool]:
        """
        Reoptimize the ordering of stops in a driver_run using Gurobi.
        
        Args:
            driver_run: The driver run to optimize with structure:
                {
                    "state": {
                        "run_id": int,
                        "start_time": int,
                        "end_time": int,
                        "am_capacity": int,
                        "wc_capacity": int,
                        "locations_already_serviced": int,
                        "location_dt_seconds": int,
                        "loc": {"lat": float, "lon": float, "node_id": int},
                        "total_locations": int
                    },
                    "manifest": [Stop, ...]
                }
            depot: Depot information with structure:
                {
                    "pt": {"lat": float, "lon": float, "node_id": int}
                }
            objective: Optimization objective ("travel_time" or "total_time")
            
        Returns:
            Tuple of (optimized_driver_run, cost_improvement, is_feasible)
        """
        try:
            # Extract and validate input
            state = driver_run["state"]
            manifest = driver_run["manifest"]
            
            # Get completed and remaining stops
            completed_stops = manifest[:state["locations_already_serviced"]]
            remaining_stops = manifest[state["locations_already_serviced"]:]

            current_load = 0
            for stop in completed_stops:
                if stop["action"] == "pickup":
                    current_load += stop["am"]
                else:
                    current_load -= stop["am"]
            
            if len(remaining_stops) <= 1:
                # No optimization needed for 0 or 1 remaining stops
                return driver_run, 0.0, True
            
            # All locations already have node_ids from SwapHandler initialization

            
            # Calculate current cost
            current_cost = self._calculate_manifest_cost(state, remaining_stops)
            
            # Optimize the remaining stops
            optimized_stops, is_feasible = self._optimize_stop_sequence(
                state, remaining_stops, depot, objective, current_load
            )
            
            if not is_feasible:
                logging.warning("Optimization infeasible, returning original driver_run")
                return driver_run, 0.0, False
            
            # Calculate new cost
            new_cost = self._calculate_manifest_cost(state, optimized_stops)
            cost_improvement = current_cost - new_cost
            
            # Create optimized driver_run
            optimized_driver_run = copy.deepcopy(driver_run)
            optimized_driver_run["manifest"] = completed_stops + optimized_stops
            
            # Update order numbers
            self._update_stop_orders(optimized_driver_run, state["locations_already_serviced"])
            
            
            return optimized_driver_run, cost_improvement, True
            
        except Exception as e:
            logging.error(f"Error optimizing driver run: {e}")
            return driver_run, 0.0, False
    
    def _optimize_stop_sequence(self, state: Dict, stops: List[Dict], depot: Dict, objective: str, current_load: int) -> Tuple[List[Dict], bool]:
        """
        Optimize the sequence of stops using Gurobi.
        
        Args:
            state: Driver state information
            stops: List of stops to optimize
            depot: Depot information
            objective: Optimization objective
            
        Returns:
            Tuple of (optimized_stops, is_feasible)
        """
        n_stops = len(stops)
        if n_stops == 0:
            return [], True
        
        # Create pickup-delivery pairs mapping
        pickup_delivery_pairs = self._create_pickup_delivery_pairs(stops)
        
        # Get travel time matrix
        travel_times = self._get_travel_time_matrix(state, stops, depot)
        
        try:
            with gp.Env(empty=True) as env:
                env.setParam('OutputFlag', 0)
                env.start()
                
                model = gp.Model('DriverRunOptimization', env=env)
                
                # Decision variables: x[i][j] = 1 if stop j is visited immediately after stop i
                x = {}
                for i in range(n_stops + 1):  # +1 for depot
                    for j in range(n_stops + 1):
                        if i != j:
                            x[i, j] = model.addVar(vtype=GRB.BINARY, name=f'x_{i}_{j}')
                
                # Time variables: t[i] = arrival time at stop i
                t = {}
                for i in range(n_stops):
                    t[i] = model.addVar(lb=0, name=f't_{i}')
                
                # Load variables: l[i] = load after visiting stop i
                l = {}
                for i in range(n_stops):
                    l[i] = model.addVar(lb=0, ub=state["am_capacity"], name=f'l_{i}')
                
                # Objective: minimize travel time
                if objective == "travel_time":
                    model.setObjective(
                        gp.quicksum(travel_times[i][j] * x[i, j] 
                                  for i in range(n_stops + 1) 
                                  for j in range(n_stops + 1) if i != j),
                        GRB.MINIMIZE
                    )
                else:  # total_time
                    model.setObjective(
                        gp.quicksum(t[i] for i in range(n_stops)),
                        GRB.MINIMIZE
                    )
                
                # Constraints
                
                # 1. Each stop must be visited exactly once (from depot or another stop)
                for j in range(n_stops):
                    model.addConstr(
                        gp.quicksum(x[i, j] for i in range(n_stops + 1) if i != j) == 1,
                        name=f'visit_{j}'
                    )
                
                # 2. Each stop must be left exactly once (to depot or another stop)
                for i in range(n_stops):
                    model.addConstr(
                        gp.quicksum(x[i, j] for j in range(n_stops + 1) if i != j) == 1,
                        name=f'leave_{i}'
                    )
                
                # 3. Depot constraints (start and end)
                model.addConstr(
                    gp.quicksum(x[n_stops, j] for j in range(n_stops)) == 1,
                    name='start_from_depot'
                )
                model.addConstr(
                    gp.quicksum(x[i, n_stops] for i in range(n_stops)) == 1,
                    name='return_to_depot'
                )
                
                # 4. Pickup-delivery precedence constraints
                for pickup_idx, delivery_idx in pickup_delivery_pairs.items():
                    if pickup_idx is not None and delivery_idx is not None:
                        # Delivery must come after pickup
                        model.addConstr(t[delivery_idx] >= t[pickup_idx], 
                                      name=f'precedence_{pickup_idx}_{delivery_idx}')
                
                # 5. Time window constraints
                for i in range(n_stops):
                    stop = stops[i]
                    model.addConstr(t[i] >= stop["time_window_start"], 
                                  name=f'tw_start_{i}')
                    model.addConstr(t[i] <= stop["time_window_end"], 
                                  name=f'tw_end_{i}')
                
                # 6. Travel time and service time constraints
                for i in range(n_stops + 1):
                    for j in range(n_stops):
                        if i != j:
                            if i == n_stops:  # From depot
                                service_time = 0
                                prev_time = state["location_dt_seconds"]
                            else:  # From another stop
                                service_time = (self.dwell_pickup if stops[i]["action"] == "pickup" 
                                              else self.dwell_dropoff)
                                prev_time = t[i] + service_time
                            
                            model.addConstr(
                                t[j] >= prev_time + travel_times[i][j] - 
                                (1 - x[i, j]) * 1000000,  # Big M constraint
                                name=f'travel_{i}_{j}'
                            )
                
                # 7. Capacity constraints (linear with Big M)
                M = state["am_capacity"]  # Big M value. M is the capacity of the vehicle.
                
                for i in range(n_stops):
                    # Load at stop i = load from previous stop + load change at stop i
                    load_change = stops[i]["am"] if stops[i]["action"] == "pickup" else -stops[i]["am"]
                    
                    # If coming from depot (index n_stops), load is just the load change
                    model.addConstr(
                        l[i] >= current_load + load_change - M * (1 - x[n_stops, i]),
                        name=f'load_from_depot_{i}'
                    )
                    
                    # If coming from another stop j, load is previous load + load change
                    for j in range(n_stops):
                        if j != i:
                            model.addConstr(
                                l[i] >= l[j] + load_change - M * (1 - x[j, i]),
                                name=f'load_from_stop_{j}_{i}'
                            )
                
                # 8. End time constraint - ensure vehicle can return to depot by end_time
                for i in range(n_stops):
                    service_time = (self.dwell_pickup if stops[i]["action"] == "pickup" 
                                  else self.dwell_dropoff)
                    model.addConstr(
                        t[i] + service_time + travel_times[i][n_stops] <= state["end_time"],
                        name=f'end_time_{i}'
                    )
                
                # Set initial solution (current stop sequence)
                self._set_initial_solution(model, x, stops, n_stops, t, l, current_load, state, travel_times)
                
                # Write model to file for debugging
                # try:
                #     model.write('driver_run_optimization.lp')
                #     logging.debug("Model written to driver_run_optimization.lp")
                # except Exception as e:
                #     logging.warning(f"Failed to write model to file: {e}")
                
                # Solve the model
                model.setParam('TimeLimit', 30)  # 30 second time limit
                model.optimize()

                time_taken = model.Runtime
                logging.debug(f"Time taken for reoptimization of driver run: {time_taken} seconds")
                if model.Status == GRB.OPTIMAL or model.Status == GRB.SUBOPTIMAL:
                    # Extract solution
                    optimized_stops = self._extract_solution(model, stops, x, n_stops)
                    return optimized_stops, True
                else:
                    logging.warning(f"Gurobi optimization failed with status: {model.Status}")
                    return stops, False
                    
        except Exception as e:
            logging.error(f"Gurobi optimization error: {e}")
            return stops, False
    
    def _create_pickup_delivery_pairs(self, stops: List[Dict]) -> Dict[int, int]:
        """Create mapping of pickup to delivery stop indices."""
        pairs = {}
        booking_to_pickup = {}
        booking_to_delivery = {}
        
        for i, stop in enumerate(stops):
            booking_id = stop["booking_id"]
            if stop["action"] == "pickup":
                booking_to_pickup[booking_id] = i
            else:
                booking_to_delivery[booking_id] = i
        
        # Create pairs
        for booking_id in booking_to_pickup:
            if booking_id in booking_to_delivery:
                pickup_idx = booking_to_pickup[booking_id]
                delivery_idx = booking_to_delivery[booking_id]
                pairs[pickup_idx] = delivery_idx
        
        return pairs
    
    def _get_travel_time_matrix(self, state: Dict, stops: List[Dict], depot: Dict) -> List[List[float]]:
        """Get travel time matrix between all stops and depot using NetworkHandler.travel_time."""
        n_stops = len(stops)
        matrix = [[0.0 for _ in range(n_stops + 1)] for _ in range(n_stops + 1)]
        
        # Current location node
        current_node = Node(state["loc"]["lat"], state["loc"]["lon"], id=state["loc"]["node_id"])
        # Depot node
        depot_node = Node(depot["pt"]["lat"], depot["pt"]["lon"], id=depot["pt"]["node_id"])
        
        # Travel times from current location to stops
        for j, stop in enumerate(stops):
            stop_node = Node(stop["loc"]["lat"], stop["loc"]["lon"], id=stop["loc"]["node_id"])
            matrix[n_stops][j] = NetworkHandler.travel_time(current_node, stop_node)
        
        # Travel times between stops
        for i, stop_i in enumerate(stops):
            node_i = Node(stop_i["loc"]["lat"], stop_i["loc"]["lon"], id=stop_i["loc"]["node_id"])
            
            # To other stops
            for j, stop_j in enumerate(stops):
                if i != j:
                    node_j = Node(stop_j["loc"]["lat"], stop_j["loc"]["lon"], id=stop_j["loc"]["node_id"])
                    matrix[i][j] = NetworkHandler.travel_time(node_i, node_j)
            
            # Back to depot
            matrix[i][n_stops] = NetworkHandler.travel_time(node_i, depot_node)
        
        return matrix
    
    def _extract_solution(self, model, stops: List[Dict], x: Dict, n_stops: int) -> List[Dict]:
        """Extract the optimized stop sequence from the Gurobi solution."""
        # Find the sequence by following the x variables
        sequence = []
        current = n_stops  # Start from depot
        
        while len(sequence) < n_stops:
            for j in range(n_stops):
                if current != j and x[current, j].X > 0.5:  # If x[current, j] = 1
                    sequence.append(j)
                    current = j
                    break
        
        # Reorder stops according to the sequence
        optimized_stops = [stops[i] for i in sequence]
        
        # Update scheduled times
        self._update_scheduled_times(optimized_stops, model, n_stops)
        
        return optimized_stops
    
    def _update_scheduled_times(self, stops: List[Dict], model, n_stops: int):
        """Update scheduled times based on the optimization solution."""
        for i, stop in enumerate(stops):
            if i < n_stops:
                # Get time variable value from model
                time_var = model.getVarByName(f't_{i}')
                if time_var is not None:
                    stop["scheduled_time"] = int(time_var.X)
    
    def _calculate_manifest_cost(self, state: Dict, stops: List[Dict]) -> float:
        """Calculate the total travel time cost of a manifest using NetworkHandler.travel_time."""
        if not stops:
            return 0.0
        
        cost = 0.0
        current_node = Node(state["loc"]["lat"], state["loc"]["lon"], id=state["loc"]["node_id"])
        
        for stop in stops:
            next_node = Node(stop["loc"]["lat"], stop["loc"]["lon"], id=stop["loc"]["node_id"])
            cost += NetworkHandler.travel_time(current_node, next_node)
            current_node = next_node
        
        return cost
    
    def _update_stop_orders(self, driver_run: Dict, start_order: int):
        """Update the order numbers in the manifest."""
        manifest = driver_run["manifest"]
        for i, stop in enumerate(manifest[start_order:], start=start_order + 1):
            stop["order"] = i
    
    def _set_initial_solution(self, model, x, stops: List[Dict], n_stops: int, t, l, current_load: int, state: Dict, travel_times: List[List[float]]):
        """Set the current stop sequence as an initial solution for Gurobi."""
        try:
            # Set initial values for the decision variables
            # The current sequence is: depot -> stop[0] -> stop[1] -> ... -> stop[n-1] -> depot
            
            # Start from depot (index n_stops)
            x[n_stops, 0].start = 1.0  # Go from depot to first stop
            
            # Connect stops in current order
            for i in range(n_stops - 1):
                x[i, i + 1].start = 1.0  # Go from stop i to stop i+1
            
            # Return to depot from last stop
            x[n_stops - 1, n_stops].start = 1.0  # Go from last stop to depot
            
            # Set all other x variables to 0
            for i in range(n_stops + 1):
                for j in range(n_stops + 1):
                    if i != j and (i, j) not in [(n_stops, 0), (n_stops - 1, n_stops)]:
                        if i < n_stops and j != i + 1:
                            x[i, j].start = 0.0
            
            # Set initial time values using scheduled times
            current_load_value = current_load
            
            for i in range(n_stops):
                # Use the scheduled time for each stop
                t[i].start = stops[i]["scheduled_time"]
                
                # Set initial load values
                load_change = stops[i]["am"] if stops[i]["action"] == "pickup" else -stops[i]["am"]
                current_load_value += load_change
                l[i].start = current_load_value
            
            
        except Exception as e:
            logging.warning(f"Failed to set initial solution: {e}")
            # Continue without initial solution if there's an error


