import copy
import logging
from typing import Dict, List, Tuple, Optional

from .network_handler import NetworkHandler
from ..structure.driver_run_state import DriverRunCurrentState


class GreedySequenceOptimizer:
    """
    Greedy sequence optimizer that inserts a new request's pickup and dropoff
    into an existing sequence without altering the order of existing stops.
    
    The algorithm tries all valid insertion positions for pickup and dropoff
    (pickup must come before dropoff) and returns the feasible combination
    with minimum additional travel cost.
    """
    
    def __init__(self, dwell_pickup: int = 180, dwell_dropoff: int = 60, return_cost: bool = False):
        self.dwell_pickup = dwell_pickup
        self.dwell_dropoff = dwell_dropoff
        self.return_cost = return_cost

    def insert_request_to_sequence(self, driver_run: DriverRunCurrentState, depot_node_id: float, request: Dict = None) -> Tuple[float, List[Dict]]:
        """
        Insert a new request into the existing sequence without changing the order of existing stops.
        
        Args:
            driver_run: Current state of the driver run
            depot_node_id: Node ID of the depot (for return cost calculation)
            request: The new request to insert (pickup and dropoff)
            
        Returns:
            Tuple of (total_travel_time, new_sequence) or (-1, None) if infeasible
        """
        am_capacity = driver_run.am_capacity
        current_am_load = driver_run.current_am_load
        current_time = driver_run.start_time
        end_time = driver_run.end_time
        remaining_stops = copy.deepcopy(driver_run.sequence)
        vehicle_id = driver_run.id
        start_node_id = driver_run.start_node
        completed = driver_run.completed

        # If no request to insert, just validate and return the existing sequence
        if request is None:
            return self._evaluate_sequence(
                remaining_stops, start_node_id, depot_node_id, 
                current_time, end_time, am_capacity, current_am_load, 
                vehicle_id, completed
            )

        # Create pickup and dropoff stops for the new request
        pickup_stop = {
            'run_id': vehicle_id, 
            'booking_id': request['booking_id'], 
            'order': -1, 
            'action': "pickup", 
            "loc": request["pickup_pt"], 
            'scheduled_time': -1, 
            'am': request["am"], 
            'wc': request["wc"], 
            'time_window_start': request['pickup_time_window_start'],
            'time_window_end': request['pickup_time_window_end']
        }
        dropoff_stop = {
            'run_id': vehicle_id, 
            'booking_id': request['booking_id'], 
            'order': -1, 
            'action': "dropoff",
            "loc": request["dropoff_pt"], 
            'scheduled_time': -1, 
            'am': request["am"], 
            'wc': request["wc"], 
            'time_window_start': request['dropoff_time_window_start'],
            'time_window_end': request['dropoff_time_window_end']
        }

        if "pickup_`service_time" in request:
            pickup_stop["service_time"] = request["pickup_service_time"]
            dropoff_stop["service_time"] = request["dropoff_service_time"]
            

        n = len(remaining_stops)
        best_cost = float('inf')
        best_sequence = None
        
        earliest_pickup_time = pickup_stop["time_window_start"]
        latest_pickup_time = pickup_stop["time_window_end"]
        earliest_dropoff_time = dropoff_stop["time_window_start"]
        latest_dropoff_time = dropoff_stop["time_window_end"]
        pick_earliest_index = 0
        pick_latest_index = 0
        for i, stop in enumerate(remaining_stops):
            if stop["time_window_end"] >= earliest_pickup_time:
                break
            else:
                pick_earliest_index = i + 1
        
        for i, stop in enumerate(remaining_stops):
            if stop["time_window_start"] > latest_pickup_time:
                break
            else:
                pick_latest_index = i + 1
        if pick_latest_index == len(remaining_stops):
            pick_latest_index += 1

        drop_earliest_index = 0
        drop_latest_index = 0
        for i, stop in enumerate(remaining_stops):
            if stop["time_window_end"] >= earliest_dropoff_time:
                break
            else:
                drop_earliest_index = i + 1
        for i, stop in enumerate(remaining_stops):
            if stop["time_window_start"] > latest_dropoff_time:
                break
            else:
                drop_latest_index = i + 1
        if drop_latest_index == len(remaining_stops):
            drop_latest_index += 1

        # Try all possible insertion positions
        # pickup_pos: position to insert pickup (0 to n)
        # dropoff_pos: position to insert dropoff (pickup_pos+1 to n+1)
        for pickup_pos in range(pick_earliest_index, pick_latest_index+1):
            for dropoff_pos in range(max(pickup_pos+1, drop_earliest_index), min(len(remaining_stops), drop_latest_index) + 2):
                # Create candidate sequence
                candidate = copy.deepcopy(remaining_stops)
                candidate.insert(pickup_pos, copy.deepcopy(pickup_stop))
                candidate.insert(dropoff_pos, copy.deepcopy(dropoff_stop))
                
                # Evaluate this candidate
                cost, new_seq = self._evaluate_sequence(
                    candidate, start_node_id, depot_node_id,
                    current_time, end_time, am_capacity, current_am_load,
                    vehicle_id, completed
                )
                
                if cost >= 0 and cost < best_cost:
                    best_cost = cost
                    best_sequence = new_seq

        if best_sequence is not None:
            return best_cost, best_sequence
        else:
            return -1, None

    def _evaluate_sequence(
        self, 
        stops: List[Dict], 
        start_node_id: int,
        depot_node_id: int,
        start_time: float, 
        end_time: float,
        am_capacity: int, 
        initial_load: int,
        vehicle_id: str,
        completed: int
    ) -> Tuple[float, List[Dict]]:
        """
        Evaluate a sequence for feasibility and calculate its cost.
        
        Checks:
        1. Time window constraints
        2. Capacity constraints
        3. Precedence constraints (pickup before dropoff for same booking)
        
        Returns:
            Tuple of (total_travel_time, sequence_with_scheduled_times) or (-1, None) if infeasible
        """
        if len(stops) == 0:
            return 0, []

        current_time = start_time
        current_load = initial_load
        current_node = start_node_id
        total_travel_time = 0
        new_sequence = []
        current_order = completed

        for stop in stops:
            action = stop["action"]
            booking_id = stop["booking_id"]
            next_node = stop["loc"]["node_id"]
            
            # Calculate travel time to this stop
            travel_time = NetworkHandler.travel_time_from_node_indices(current_node, next_node)
            total_travel_time += travel_time
            current_time += travel_time
            
            # Wait if we arrive before time window opens
            if current_time < stop["time_window_start"]:
                current_time = stop["time_window_start"]
            
            # Check time window constraint (arrival must be before window closes)
            if current_time > stop["time_window_end"]:
                return -1, None  # Infeasible: missed time window
            
            # Update load
            if action == "pickup":
                current_load += stop["am"]
            else:  # dropoff
                current_load -= stop["am"]
            
            # Check capacity constraint
            if current_load > am_capacity:
                return -1, None  # Infeasible: capacity violation
            
            # Build the new stop with scheduled time
            current_order += 1
            new_stop = {
                'run_id': vehicle_id,
                'booking_id': booking_id,
                'order': current_order,
                'action': action,
                'loc': stop['loc'],
                'scheduled_time': current_time,
                'am': stop['am'],
                'wc': stop.get('wc', 0),
                'time_window_start': stop['time_window_start'],
                'time_window_end': stop['time_window_end']
            }
            new_sequence.append(new_stop)
            
            # Add service time
            service_time = self.dwell_pickup if action == "pickup" else self.dwell_dropoff
            if "service_time" in stop:
                service_time = stop["service_time"]
            current_time += service_time
            
            current_node = next_node

        # Check if we can finish before end_time
        if current_time > end_time:
            return -1, None  # Infeasible: exceeds shift end time

        # Add return-to-depot cost if requested
        if self.return_cost and len(new_sequence) > 0:
            last_node = new_sequence[-1]["loc"]["node_id"]
            return_travel_time = NetworkHandler.travel_time_from_node_indices(last_node, depot_node_id)
            total_travel_time += return_travel_time

        return total_travel_time, new_sequence
