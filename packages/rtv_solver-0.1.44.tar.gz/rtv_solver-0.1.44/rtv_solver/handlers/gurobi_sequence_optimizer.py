import gurobipy as gp
from gurobipy import GRB
import numpy as np
import copy
import logging
from typing import Dict, List, Tuple, Optional

from .network_handler import NetworkHandler
from ..structure.driver_run_state import DriverRunCurrentState
from ..structure.node import Node


class GurobiSequenceOptimizer:
    def __init__(self, dwell_pickup: int = 180, dwell_dropoff: int = 60, time_limit: int = 1, return_cost: bool = False, solution_limit: int = 1):
        self.dwell_pickup = dwell_pickup
        self.dwell_dropoff = dwell_dropoff
        self.time_limit = time_limit
        self.return_cost = return_cost
        self.solution_limit = solution_limit

    def insert_request_to_sequence(self, driver_run: DriverRunCurrentState, depot_node_id: float, request: Dict = None) -> Tuple[Dict, float, bool]:
        if len(driver_run.sequence) == 0 and request == None:
            return 0, []
        am_capacity = driver_run.am_capacity
        current_am_load = driver_run.current_am_load
        current_wc_load = driver_run.current_wc_load
        current_time = driver_run.start_time
        end_time = driver_run.end_time
        remaining_stops = driver_run.sequence
        vehicle_id = driver_run.id

        if request != None:
            pickup_stop = {'run_id': vehicle_id, 'booking_id': request['booking_id'], 'order': -1, 'action': "pickup", 
            "loc": request["pickup_pt"], 'scheduled_time': int((end_time+current_time)/2), 
            'am': request["am"], 'wc': request["wc"], 'time_window_start': request['pickup_time_window_start'],
            'time_window_end': request['pickup_time_window_end']}
            dropoff_stop = {'run_id': vehicle_id, 'booking_id': request['booking_id'], 'order': -1, 'action': "dropoff",
                "loc": request["dropoff_pt"], 'scheduled_time': int((end_time+current_time)/2), 
                'am': request["am"], 'wc': request["wc"], 'time_window_start': request['dropoff_time_window_start'],
                'time_window_end': request['dropoff_time_window_end']}
            if "pickup_service_time" in request:
                pickup_stop["service_time"] = request["pickup_service_time"]
            if "dropoff_service_time" in request:
                dropoff_stop["service_time"] = request["dropoff_service_time"]
            remaining_stops.append(pickup_stop)
            remaining_stops.append(dropoff_stop)

        nb_customers = len(remaining_stops)
        start_node_id = driver_run.start_node

        # Build arrays
        demands_data = [0] * nb_customers
        service_time_data = [0] * nb_customers
        earliest_start_data = [0] * nb_customers
        latest_end_data = [0] * nb_customers
        pick_up_index = [0] * nb_customers
        delivery_index = [0] * nb_customers

        booking_to_pick = {}
        booking_to_drop = {}
        for i, stop in enumerate(remaining_stops):
            if stop["action"] == "pickup":
                booking_to_pick[stop["booking_id"]] = i
            else:
                booking_to_drop[stop["booking_id"]] = i

        for i, stop in enumerate(remaining_stops):
            action = stop["action"]
            amt = stop["am"]
            service_time = self.dwell_pickup if action == "pickup" else self.dwell_dropoff
            if "service_time" in stop:
                service_time = stop["service_time"]
            service_time_data[i] = service_time
            earliest_start_data[i] = stop["time_window_start"]
            latest_end_data[i] = stop["time_window_end"]
            if action == "pickup":
                demands_data[i] = amt
                pick_up_index[i] = -1
                delivery_index[i] = booking_to_drop.get(stop["booking_id"], -1)
            else:
                demands_data[i] = -amt
                pick_up_index[i] = booking_to_pick.get(stop["booking_id"], -1)
                delivery_index[i] = -1

        # Distance matrices including depot/current location as 0 index
        travel_times = [[0] * (nb_customers + 1) for _ in range(nb_customers + 1)]
        # from depot/current location (index 0) to customers 1..n
        
        for j, stop in enumerate(remaining_stops):
            travel_times[0][j + 1] = NetworkHandler.travel_time_from_node_indices(start_node_id, stop["loc"]["node_id"])
            travel_times[j + 1][0] = NetworkHandler.travel_time_from_node_indices(stop["loc"]["node_id"], depot_node_id)
        # inter-customers
        for i, stop_i in enumerate(remaining_stops):
            for j, stop_j in enumerate(remaining_stops):
                if i == j:
                    continue
                travel_times[i + 1][j + 1] = NetworkHandler.travel_time_from_node_indices(stop_i["loc"]["node_id"], stop_j["loc"]["node_id"])

        try:
            with gp.Env(empty=True) as env:
                env.setParam('OutputFlag', 0)
                env.start()
                
                model = gp.Model('GurobiSequenceOptimization', env=env)
                
                # Decision variables: x[i][j] = 1 if stop j is visited immediately after stop i
                x = {}
                for i in range(nb_customers + 1):  # +1 for depot, depot is 0
                    for j in range(nb_customers + 1):
                        if i != j:
                            x[i, j] = model.addVar(vtype=GRB.BINARY, name=f'x_{i}_{j}')
                
                # Time variables: t[i] = arrival time at stop i
                t = {}
                for i in range(nb_customers):
                    t[i] = model.addVar(lb=current_time+travel_times[0][i+1], ub=end_time-travel_times[i+1][0]-service_time_data[i], name=f't_{i}')
                
                # Load variables: l[i] = load after visiting stop i
                l = {}
                for i in range(nb_customers):
                    l[i] = model.addVar(lb=0, ub=am_capacity, name=f'l_{i}')
                
                # Objective: minimize travel time
                # if objective == "travel_time":
                if self.return_cost:
                    model.setObjective(
                        gp.quicksum(travel_times[i][j] * x[i, j] 
                                    for i in range(nb_customers + 1) 
                                    for j in range(nb_customers + 1) if i != j),
                        GRB.MINIMIZE
                    )
                else:
                    model.setObjective(
                        gp.quicksum(travel_times[i][j] * x[i, j] 
                                    for i in range(nb_customers + 1) 
                                    for j in range(1, nb_customers + 1) if i != j),
                        GRB.MINIMIZE
                    )
                # else:  # total_time
                #     model.setObjective(
                #         gp.quicksum(t[i] for i in range(nb_customers)),
                #         GRB.MINIMIZE
                    # )
                
                # Constraints
                
                # 1. Each stop must be visited exactly once (from depot or another stop)
                for j in range(nb_customers+1):
                    model.addConstr(
                        gp.quicksum(x[i, j] for i in range(nb_customers + 1) if i != j) == 1,
                        name=f'visit_{j}'
                    )
                
                # 2. Each stop must be left exactly once (to depot or another stop)
                for i in range(nb_customers+1):
                    model.addConstr(
                        gp.quicksum(x[i, j] for j in range(nb_customers + 1) if i != j) == 1,
                        name=f'leave_{i}'
                    )
                
                # 4. Pickup-delivery precedence constraints
                for booking_id in booking_to_pick:
                    # Delivery must come after pickup
                    pickup_idx = booking_to_pick[booking_id]
                    delivery_idx = booking_to_drop.get(booking_id, -1)
                    model.addConstr(t[delivery_idx] >= t[pickup_idx], 
                                    name=f'precedence_{pickup_idx}_{delivery_idx}')
                
                # 5. Time window constraints
                for i in range(nb_customers):
                    model.addConstr(t[i] >= earliest_start_data[i], 
                                  name=f'tw_start_{i}')
                    model.addConstr(t[i] <= latest_end_data[i], 
                                  name=f'tw_end_{i}')
                
                # 6. Travel time and service time constraints
                for i in range(nb_customers):
                    for j in range(nb_customers):
                        if i != j:
                            model.addConstr(
                                t[j] >= t[i] + travel_times[i+1][j+1] + service_time_data[i] - 
                                (1 - x[i+1, j+1]) * 1000000,  # Big M constraint
                                name=f'travel_{i}_{j}'
                            )
                
                # 7. Capacity constraints (linear with Big M)
                M = 100000  # Big M value. M is the capacity of the vehicle.
                
                for i in range(nb_customers):
                    # Load at stop i = load from previous stop + load change at stop i
                    demand = demands_data[i]
                    
                    # If coming from depot (index nb_customers), load is just the load change
                    model.addConstr(
                        l[i] >= current_am_load + demand - M * (1 - x[0, i+1]),
                        name=f'load_from_depot_{i}'
                    )
                    
                    # If coming from another stop j, load is previous load + load change
                    for j in range(nb_customers):
                        if j != i:
                            model.addConstr(
                                l[i] >= l[j] + demand - M * (1 - x[j+1, i+1]),
                                name=f'load_from_stop_{j}_{i}'
                            )
                
                # Set initial solution (current stop sequence)
                x[0, 1].start = 1.0  # Go from depot to first stop
            
                # Connect stops in current order
                for i in range(nb_customers):
                    x[i, i + 1].start = 1.0  # Go from stop i to stop i+1
                
                # Return to depot from last stop
                x[nb_customers, 0].start = 1.0  # Go from last stop to depot
                
                # Set all other x variables to 0
                for i in range(nb_customers + 1):
                    for j in range(nb_customers + 1):
                        if i == 0 and j == 1:
                            continue
                        if i == nb_customers and j == 0:
                            continue
                        if i + 1 == j:
                            continue
                        if i == j:
                            continue
                        x[i, j].start = 0.0
                
                # Set initial time values using scheduled times
                current_load_value = current_am_load
                
                for i in range(nb_customers):
                    # Use the scheduled time for each stop
                    t[i].start = remaining_stops[i]["scheduled_time"]
                    
                    # Set initial load values
                    demand = demands_data[i]
                    current_load_value += demand
                    l[i].start = current_load_value
                
                # Write model to file for debugging
                # try:
                #     model.write('driver_run_optimization.lp')
                #     logging.debug("Model written to driver_run_optimization.lp")
                # except Exception as e:
                #     logging.warning(f"Failed to write model to file: {e}")
                
                # Solve the model
                model.setParam('TimeLimit', self.time_limit)  # reset time limit
                model.setParam('MIPGap', 0.05)  # 5% gap
                if self.solution_limit > 0:
                    model.setParam("solutionLimit", self.solution_limit)
                model.optimize()

                time_taken = model.Runtime
                logging.debug(f"Time taken for reoptimization of driver run: {time_taken} seconds")

                if model.SolCount > 0 or model.Status == GRB.OPTIMAL or model.Status == GRB.SUBOPTIMAL:
                    # Extract solution
                    sequence = []
                    current = 0  # Start from depot

                    while len(sequence) < nb_customers:
                        for j in range(nb_customers):
                            if current != j+1 and x[current, j+1].X > 0.5:  # If x[current, j] = 1
                                sequence.append(j)
                                current = j+1
                                break
                    
                    # Update scheduled times
                    # extract route
                    new_sequence = []
                    current_node = start_node_id
                    total_travel_time = 0
                    current_order = driver_run.completed
                    for idx in sequence:
                        stop = remaining_stops[idx]
                        next_node = stop["loc"]["node_id"]
                        travel_time = NetworkHandler.travel_time_from_node_indices(current_node, next_node)
                        total_travel_time += travel_time
                        current_time += travel_time
                        if current_time < stop["time_window_start"]:
                            current_time = stop["time_window_start"]
                        action = stop["action"]
                        demand = stop["am"] if action == "pickup" else -stop["am"]
                        current_order += 1
                        new_stop = {
                            'run_id': vehicle_id,
                            'booking_id': stop['booking_id'],
                            'order': current_order,
                            'action': action,
                            'loc': stop['loc'],
                            'scheduled_time': current_time,
                            'am': demand if action == 'pickup' else -demand,
                            'wc': stop.get('wc', 0),
                            'time_window_start': stop['time_window_start'],
                            'time_window_end': stop['time_window_end']
                        }
                        current_node = next_node
                        service_time = self.dwell_pickup if action == 'pickup' else self.dwell_dropoff
                        if "service_time" in stop:
                            service_time = stop["service_time"]
                        current_time += service_time
                        new_sequence.append(new_stop)

                        
                    return total_travel_time, new_sequence
                else:
                    logging.debug(f"Gurobi optimization failed with status: {model.Status}")
                    return -1, None
                    
        except Exception as e:
            logging.error(f"Gurobi optimization error: {e}")
            return -1, None
    
