"""
Large Neighbourhood Search Handler

This module implements a Large Neighbourhood Search (LNS) solver that extends
the swap-based solver architecture with destroy-repair operations and RTV-like
graph construction for request insertion.

LNS Design:
1. Remove K number of unserved requests (First K requests) from each driver run
2. This creates two sets of requests: fixed (remaining in driver runs) and unfixed (removed)
3. Build RTV-like framework for reinsertion:
   - Request-Request shareable graph
   - Request-Vehicle shareable graph  
   - Request-Trip-Vehicle graph
4. Use ILP to optimally assign unfixed requests back to vehicles
"""

from rtv_solver.handlers.network_handler import NetworkHandler
from rtv_solver.handlers.payload_parser import PayloadParser
from rtv_solver.handlers.swap_handler import SwapHandler
from rtv_solver.handlers.gurobi_sequence_optimizer import GurobiSequenceOptimizer
from rtv_solver.handlers.greedy_sequence_optimizer import GreedySequenceOptimizer
from rtv_solver.handlers.partial_reorder_sequence_optimizer import PartialReorderSequenceOptimizer
from rtv_solver.structure.node import Node
from rtv_solver.structure.driver_run_state import DriverRunCurrentState
import numpy as np
import logging
import multiprocessing as mp
import gurobipy as gp
from gurobipy import GRB
import time
import copy
import itertools
import random
import os

class VehicleTrip:
    def __init__(self, requests, run_id, cost, sequence):
        self.requests = requests
        self.run_id = run_id
        self.cost = cost
        self.sequence = sequence  # Store the actual sequence, not empty list

class LNSHandler:
    """Large Neighbourhood Search Handler for PDPTW optimization."""
    
    def __init__(self, server_url, driver_runs, depot, DWELL_PICKUP, DWELL_ALIGHT, 
                 MAX_NUM_THREAD, new_requests, enable_TSP_reoptimization=True, 
                 return_cost=False, output_folder=None, enable_tail_swap=False, RV_K=0, tt_matrix=None):
        """
        Initialize the LNS Handler.
        
        Args:
            server_url: Network service URL
            driver_runs: List of current driver runs
            depot: Depot information
            DWELL_PICKUP: Pickup dwell time in seconds
            DWELL_ALIGHT: Dropoff dwell time in seconds
            MAX_NUM_THREAD: Maximum number of threads for parallel processing
            new_requests: New requests to insert
            enable_TSP_reoptimization: Whether to enable TSP reoptimization
            return_cost: Whether to include return-to-depot cost
            output_folder: Output folder for logs
            enable_tail_swap: Whether to enable tail swap
            RV_K: Parameter for RTV graph construction (maximum vehicles per requests)
        """
        self.output_folder = output_folder
        self.MAX_NUM_THREAD = MAX_NUM_THREAD
        self.enable_tail_swap = enable_tail_swap
        self.RV_K = RV_K
        if tt_matrix is not None:
            NetworkHandler.init(False, tt_matrix=tt_matrix, euclidean=False)
        else:
            NetworkHandler.init(True, server_url, euclidean=False)
        
        # Parse payload and initialize data structures
        payload_object = PayloadParser.get_payload_object({
            "driver_runs": driver_runs, 
            "depot": depot, 
            "requests": new_requests
        })
        
        # Active requests are the requests that were not picked up yet
        self.active_requests = set(payload_object.active_requests)
        # Active requests + boarded requests are the requests that were picked up and are not dropped off yet
        requests = payload_object.requests
        self.new_requests = new_requests

        # Initialize node IDs for depot and requests
        if tt_matrix is None:
            depot_node_id = NetworkHandler.get_next_node_id(depot["pt"]["lat"],depot["pt"]["lon"])
            for request in requests:
                node_id = NetworkHandler.get_next_node_id(
                    request["pickup_pt"]["lat"], request["pickup_pt"]["lon"]
                )
                request["pickup_pt"]["node_id"] = node_id
                node_id = NetworkHandler.get_next_node_id(
                    request["dropoff_pt"]["lat"], request["dropoff_pt"]["lon"]
                )
                request["dropoff_pt"]["node_id"] = node_id
        else:
            depot_node_id = depot["pt"]["node_id"]
        
        depot_node = Node(depot["pt"]["lat"],depot["pt"]["lon"], id=depot_node_id)
        
        # Build request dictionary
        self.request_dic = {}
        for request in requests:
            self.request_dic[request["booking_id"]] = request

        # Initialize driver runs with node IDs
        self.driver_runs = copy.deepcopy(driver_runs)
        if tt_matrix is None:
            for driver_run in self.driver_runs:
                state = driver_run[PayloadParser.DRIVER_STATE]
                run_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
                current_node_id = NetworkHandler.get_next_node_id(
                    state[PayloadParser.DRIVER_STATE_LOC]["lat"], 
                    state[PayloadParser.DRIVER_STATE_LOC]["lon"]
                )
                state[PayloadParser.DRIVER_STATE_LOC]["node_id"] = current_node_id
                current_order = state[PayloadParser.DRIVER_STATE_LOC_SERV]
                manifest = driver_run[PayloadParser.DRIVER_MANIFEST]
                
                for stop in manifest[current_order:]:
                    booking_id = stop["booking_id"]
                    request = self.request_dic[booking_id]
                    # Update node ID for pickup and dropoff stops
                    if stop["action"] == "pickup":
                        stop["loc"]["node_id"] = request["pickup_pt"]["node_id"]
                    else:
                        stop["loc"]["node_id"] = request["dropoff_pt"]["node_id"]
        
            # Initialize travel time matrix
            NetworkHandler.initialize_travel_time_matrix()

        # Store configuration
        self.DWELL_PICKUP = DWELL_PICKUP
        self.DWELL_ALIGHT = DWELL_ALIGHT
        self.depot = depot_node
        self.depot_node_id = depot_node_id
        self.enable_TSP_reoptimization = enable_TSP_reoptimization
        self.return_cost = return_cost
        
        # LNS-specific data structures
        self.trips = []
        self.vehicle_trips = []
        self.rr_graph = {}  # Request-Request shareability graph
        self.rtv_graph = {} # Request-Trip-Vehicle graph
        self.merged_start_with = {}
        self.merged_end_with = {}
        if output_folder != None:
            if not os.path.exists(output_folder):
                os.makedirs(output_folder)
            logging.basicConfig(filename=output_folder+"lns_solver.log", level=logging.DEBUG)
        
    def run_lns(self, K=3, max_iterations=1, max_time=300):
        """
        Run Large Neighbourhood Search optimization.
        
        Args:
            K: Number of requests to remove from each driver run
            max_iterations: Maximum number of LNS iterations
            max_time: Maximum time limit in seconds
            
        Returns:
            Tuple of (optimized_driver_runs, cost_improvement, num_iterations)
        """
        logging.debug(f"Starting LNS with K={K}, max_iterations={max_iterations}")
        
        start_time = time.time()
        best_solution = copy.deepcopy(self.driver_runs)
        best_cost = self._calculate_total_cost(best_solution)
        current_solution = copy.deepcopy(best_solution)
        current_cost = best_cost
        unserved_request_ids = set([req["booking_id"] for req in self.new_requests])
        
        iteration = 0
        while iteration < max_iterations and (time.time() - start_time) < max_time:
            logging.debug(f"LNS iteration {iteration + 1}")
            
            # Step 1: Destroy - Remove K requests from each driver run
            fixed_solution, removed_requests = self._destroy_solution(current_solution, K)

            removed_request_set = set([request["booking_id"] for request in removed_requests])
            for req in self.new_requests:
                if req["booking_id"] not in removed_request_set:
                    removed_requests.append(req)
            
            if len(removed_requests) == 0:
                logging.debug("No requests to remove, stopping LNS")
                break
                
            # Step 2: Repair - Reinsert removed requests using RTV framework
            repaired_solution, repair_cost = self._repair_solution(fixed_solution, removed_requests)
            # repaired_solution = None
            
            if repaired_solution is not None:
                # Accept solution if it improves or meets acceptance criteria
                if repair_cost < current_cost:
                    current_solution = repaired_solution
                    current_cost = repair_cost
                    logging.debug(f"Accepted solution with cost {repair_cost} (improvement: {current_cost - repair_cost})")
                    
                    if repair_cost < best_cost:
                        best_solution = copy.deepcopy(repaired_solution)
                        best_cost = repair_cost
                        logging.debug(f"New best solution found with cost {best_cost}")
            
            iteration += 1
        
        total_time = time.time() - start_time
        improvement = self._calculate_total_cost(self.driver_runs) - best_cost

        for driver_run in best_solution:
            for stop in driver_run[PayloadParser.DRIVER_MANIFEST]:
                if stop["booking_id"] in unserved_request_ids:
                    unserved_request_ids.remove(stop["booking_id"])
        
        logging.debug(f"LNS completed: {iteration} iterations, {total_time:.2f}s, improvement: {improvement}")
        
        return best_solution, unserved_request_ids
    
    def _destroy_solution(self, solution, K):
        """
        Destroy operation: Remove first K requests from each driver run.
        
        Args:
            solution: Current driver runs solution
            K: Number of requests to remove from each driver run
            
        Returns:
            Tuple of (fixed_solution, removed_requests)
        """
        fixed_solution = copy.deepcopy(solution)
        removed_requests = []
        self.merged_start_with = {}
        self.merged_end_with = {}
        self.prev_assignment = {}
        self.removed_from_vehicles = {}
        
        for i, driver_run in enumerate(fixed_solution):
            state = driver_run[PayloadParser.DRIVER_STATE]
            run_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
            current_order = state[PayloadParser.DRIVER_STATE_LOC_SERV]
            manifest = driver_run[PayloadParser.DRIVER_MANIFEST]
            
            self.merged_start_with[run_id] = [run_id]
            self.merged_end_with[run_id] = [run_id]
            # Find pickup stops to remove (first K)
            stops_to_remove = []
            pickup_count = 0
            self.removed_from_vehicles[run_id] = set()
            
            for stop in manifest[current_order:]:
                if stop["action"] == "pickup" and pickup_count < K:
                    stops_to_remove.append(stop["booking_id"])
                    pickup_count += 1
                    request = self.request_dic[stop["booking_id"]]
                    removed_requests.append(request)
                    self.prev_assignment[stop["booking_id"]] = run_id
                    self.removed_from_vehicles[run_id].add(stop["booking_id"])
            
            logging.debug(f"Driver run {run_id}: removing {self.removed_from_vehicles[run_id]} requests")
            
            new_manifest = []
            # Remove pickup and dropoff stops from manifest
            order = 1
            for stop in manifest:
                if stop["booking_id"] not in stops_to_remove:
                    stop["order"] = order
                    order += 1
                    new_manifest.append(stop)
                
            driver_run[PayloadParser.DRIVER_MANIFEST] = new_manifest
            
            # Update state
            state[PayloadParser.DRIVER_STATE_T_LOCS] = len(new_manifest)

        if self.enable_tail_swap:
            number_of_driver_runs = len(fixed_solution)
            for i in range(number_of_driver_runs):
                driver_run1 = fixed_solution[i]
                driver_run1, requests_in_tail1, removed_stops1 = self._strip_tail(driver_run1)
                driver_run1_state = driver_run1[PayloadParser.DRIVER_STATE]
                driver_run1_completed_no = driver_run1_state[PayloadParser.DRIVER_STATE_LOC_SERV]
                driver_run1_manifest = driver_run1[PayloadParser.DRIVER_MANIFEST]
                completed_sequence = driver_run1_manifest[:driver_run1_completed_no]
                run_id1 = driver_run1_state[PayloadParser.DRIVER_STATE_RUN_ID]
                for j in range(number_of_driver_runs):
                    if i == j:
                        continue
                    driver_run2 = fixed_solution[j]
                    driver_run2, requests_in_tail2, removed_stops2 = self._strip_tail(driver_run2)
                    driver_run2_state = driver_run2[PayloadParser.DRIVER_STATE]
                    run_id2 = driver_run2_state[PayloadParser.DRIVER_STATE_RUN_ID]
                    new_driver_run = {
                        PayloadParser.DRIVER_STATE: copy.deepcopy(driver_run1_state),
                        PayloadParser.DRIVER_MANIFEST: driver_run1_manifest + removed_stops2
                    }
                    new_merged_id = f"merged_{run_id1}_{run_id2}"
                    new_driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_RUN_ID] = new_merged_id
                    current_dr_state = self._get_current_driver_run_state(new_driver_run)
                    optimizer = GurobiSequenceOptimizer(self.DWELL_PICKUP, self.DWELL_ALIGHT, time_limit=2, return_cost=True)
                    cost, new_sequence = optimizer.insert_request_to_sequence(current_dr_state, self.depot_node_id, None)
                    if cost >= 0:
                        self.merged_start_with[run_id1].append(new_merged_id)
                        self.merged_end_with[run_id2].append(new_merged_id)
                        new_driver_run[PayloadParser.DRIVER_MANIFEST] = completed_sequence + new_sequence
                        new_driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_T_LOCS] = len(new_driver_run[PayloadParser.DRIVER_MANIFEST])
                        fixed_solution.append(new_driver_run)

        
        logging.debug(f"Destroyed solution: removed {len(removed_requests)} requests")
        return fixed_solution, removed_requests

    def _strip_tail(self, driver_run):
        """Strip the tail of a driver run."""
        driver_run = copy.deepcopy(driver_run)
        state = driver_run[PayloadParser.DRIVER_STATE]
        current_order = state[PayloadParser.DRIVER_STATE_LOC_SERV]
        manifest = driver_run[PayloadParser.DRIVER_MANIFEST]
        tail_stops = manifest[current_order:]
        requests_in_tail = set()
        for stop in tail_stops:
            if stop["action"] == "pickup":
                requests_in_tail.add(stop["booking_id"])
        updated_manifest = manifest[:current_order]
        removed_stops = []
        for stop in tail_stops:
            if stop["booking_id"] not in requests_in_tail:
                stop["order"] = current_order + 1
                updated_manifest.append(stop)
                current_order += 1
            else:
                removed_stops.append(stop)
        driver_run[PayloadParser.DRIVER_MANIFEST] = updated_manifest
        state[PayloadParser.DRIVER_STATE_T_LOCS] = len(updated_manifest)
        return driver_run, requests_in_tail, removed_stops
    
    def _repair_solution(self, fixed_solution, removed_requests):
        """
        Repair operation: Reinsert removed requests using RTV framework.
        
        Args:
            fixed_solution: Solution with requests removed
            removed_requests: List of requests to reinsert
            
        Returns:
            Tuple of (repaired_solution, total_cost) or (None, float('inf')) if infeasible
        """
        
        logging.debug(f"Repairing solution: reinserting {len(removed_requests)} requests")
        
        # Step 1: Generate trips for removed requests
        # self._generate_trips_for_requests(removed_requests)
        
        # Step 2: Build Request-Request shareable graph
        self._build_rr_graph(removed_requests)
        
        # Step 3: Build Request-Vehicle graph (generate trip costs)
        self._build_rv_graph(fixed_solution, removed_requests)

        # Step 4: Build Request-Trip-Vehicle graph
        self._build_rtv_graph(fixed_solution, removed_requests)

        
        # Step 5: Solve assignment problem using ILP
        selected_trips = self._solve_assignment_ilp(fixed_solution, removed_requests)
        
        if selected_trips is not None:
            repaired_solution = []
            for driver_run in fixed_solution:
                state = driver_run[PayloadParser.DRIVER_STATE]
                run_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
                stop_sequence = driver_run[PayloadParser.DRIVER_MANIFEST]
                for trip in selected_trips:
                    if trip.run_id == run_id:
                        completed_sequence = stop_sequence[:state[PayloadParser.DRIVER_STATE_LOC_SERV]]
                        stop_sequence = completed_sequence + trip.sequence
                        driver_run[PayloadParser.DRIVER_MANIFEST] = stop_sequence
                        state[PayloadParser.DRIVER_STATE_T_LOCS] = len(stop_sequence)
                        if type(run_id) == str and "merged" in run_id:
                            run_id = int(run_id.split("_")[1])
                            state[PayloadParser.DRIVER_STATE_RUN_ID] = run_id
                            for stop in driver_run[PayloadParser.DRIVER_MANIFEST]:
                                stop["run_id"] = run_id
                        repaired_solution.append(driver_run)
                        break

            # reoptimize selected trips with GurobiSequenceOptimizer
            reoptimized_solution = {}
            for driver_run in repaired_solution:
                state = driver_run[PayloadParser.DRIVER_STATE]
                run_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
                reoptimized_solution[run_id] = driver_run
                # manifest = driver_run[PayloadParser.DRIVER_MANIFEST]
                # completed_sequence = manifest[:state[PayloadParser.DRIVER_STATE_LOC_SERV]]
                # current_dr_state = self._get_current_driver_run_state(driver_run)
                # optimizer = GurobiSequenceOptimizer(self.DWELL_PICKUP, self.DWELL_ALIGHT, time_limit=2, return_cost=True, solution_limit=-1)
                # cost, new_sequence = optimizer.insert_request_to_sequence(current_dr_state, self.depot_node_id, None)
                # if cost >= 0:
                #     driver_run[PayloadParser.DRIVER_MANIFEST] = completed_sequence + new_sequence
                #     reoptimized_solution[run_id] = driver_run
            for dr in self.driver_runs:
                driver_run = copy.deepcopy(dr)
                run_id = driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_RUN_ID]
                if run_id not in reoptimized_solution:
                    if driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_LOC_SERV] == 0:
                        driver_run[PayloadParser.DRIVER_MANIFEST] = []
                    reoptimized_solution[run_id] = driver_run
            reoptimized_solution = list(reoptimized_solution.values())
            total_cost = self._calculate_total_cost(reoptimized_solution)
            return reoptimized_solution, total_cost
        else:
            return None, float('inf')
    
    # def _generate_trips_for_requests(self, removed_requests):
    #     """Generate individual trips for each removed request."""
    #     self.trips = []
    #     self.request_to_trip_map = {}
        
    #     for i, request in enumerate(removed_requests):
    #         trip = Trip(
    #             request_id=request["booking_id"],
    #             number=i,
    #             am_capacity=request["am"],
    #             wc_capacity=request["wc"],
    #             pick_up_time=request["pickup_time_window_start"],
    #             latest_pick_up_time=request["pickup_time_window_end"],
    #             earliest_arrival_time=request["dropoff_time_window_start"],
    #             latest_arrival_time=request["dropoff_time_window_end"],
    #             origin=Node(request["pickup_pt"]["lat"], request["pickup_pt"]["lon"], 
    #                        id=request["pickup_pt"]["node_id"]),
    #             destination=Node(request["dropoff_pt"]["lat"], request["dropoff_pt"]["lon"],
    #                            id=request["dropoff_pt"]["node_id"]),
    #             dwell_pickup=self.DWELL_PICKUP,
    #             dwell_alight=self.DWELL_ALIGHT,
    #             iteration=0
    #         )
    #         self.trips.append(trip)
    #         self.request_to_trip_map[request["booking_id"]] = trip.number
        
    #     logging.debug(f"Generated {len(self.trips)} individual trips")
    
    def _build_rr_graph(self, removed_requests):
        """Build Request-Request shareable graph."""
        self.rr_graph = {}
        
        # Initialize graph
        for request in removed_requests:
            self.rr_graph[request["booking_id"]] = set()
        
        # Check pairwise shareability
        for i, request1 in enumerate(removed_requests):
            for j, request2 in enumerate(removed_requests[i+1:], i+1):
                if self._can_share_requests(request1, request2):
                    self.rr_graph[request1["booking_id"]].add(request2["booking_id"])
                    self.rr_graph[request2["booking_id"]].add(request1["booking_id"])
        
        logging.debug(f"Built RR graph with {len(self.rr_graph)} nodes")
    
    def _can_share_requests(self, request1, request2):
        """
        Check if two requests can be shared based on time windows.
        
        Args:
            request1, request2: Trip objects to check for shareability
            
        Returns:
            Boolean indicating if requests can be shared
        """
        # Check time window compatibility
        # check if the requests can be served in the same vehicle
        feasible = False
        pickup_stops = []
        dropoff_stops = []
        for request in [request1, request2]:
            pickup_stops.append({
                "booking_id": request["booking_id"],
                "order": -1,
                "action": "pickup",
                "loc": request["pickup_pt"],
                "scheduled_time": request["pickup_time_window_start"],
                "am": request["am"],
                "wc": request["wc"],
                "time_window_start": request["pickup_time_window_start"],
                "time_window_end": request["pickup_time_window_end"]
            })
            dropoff_stops.append({
                "booking_id": request["booking_id"],
                "order": -1,
                "action": "dropoff",
                "loc": request["dropoff_pt"],
                "scheduled_time": request["dropoff_time_window_start"],
                "am": request["am"],
                "wc": request["wc"],
                "time_window_start": request["dropoff_time_window_start"],
                "time_window_end": request["dropoff_time_window_end"]
            })
        possible_orders = [[pickup_stops[0], dropoff_stops[0], pickup_stops[1], dropoff_stops[1]],
                            [pickup_stops[1], dropoff_stops[1], pickup_stops[0], dropoff_stops[0]],
                            [pickup_stops[0], pickup_stops[1], dropoff_stops[1], dropoff_stops[0]],
                            [pickup_stops[0], pickup_stops[1], dropoff_stops[0], dropoff_stops[1]],
                            [pickup_stops[1], pickup_stops[0], dropoff_stops[1], dropoff_stops[0]],
                            [pickup_stops[1], pickup_stops[0], dropoff_stops[0], dropoff_stops[1]]]
        for order in possible_orders:
            if self._can_serve_stops(order):
                feasible = True
                break
        return feasible
    
    def _can_serve_stops(self, stops):
        """Check if the stops can be served in the same vehicle."""
        current_time = stops[0]["time_window_start"]
        previous_node = stops[0]["loc"]["node_id"]
        for stop in stops:
            current_node = stop["loc"]["node_id"]
            current_time += NetworkHandler.travel_time_from_node_indices(previous_node, current_node)
            if current_time < stop["time_window_start"]:
                current_time = stop["time_window_start"]
            if current_time > stop["time_window_end"]:
                return False
            if stop["action"] == "pickup":
                current_time += self.DWELL_PICKUP
            else:
                current_time += self.DWELL_ALIGHT
            previous_node = current_node
        return True

    def _get_current_driver_run_state(self, driver_run):
        """Get the current driver run state."""
        state = driver_run[PayloadParser.DRIVER_STATE]
        vehicle_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
        manifest = driver_run[PayloadParser.DRIVER_MANIFEST]
        completed_no = state[PayloadParser.DRIVER_STATE_LOC_SERV]
        current_am_load = 0
        current_wc_load = 0
        for stop in manifest[:completed_no]:
            if stop["action"] == "pickup":
                current_am_load += stop["am"]
            else:
                current_am_load -= stop["am"]
        remaining_stops = manifest[completed_no:]
        current_location = state[PayloadParser.DRIVER_STATE_LOC]["node_id"]
        current_time = state[PayloadParser.DRIVER_STATE_DT_SEC]
        current_dr_state = DriverRunCurrentState(vehicle_id, current_location, current_time, state["am_capacity"], state["wc_capacity"], current_am_load, current_wc_load, state["end_time"], remaining_stops, self.depot_node_id, completed_no)
        return current_dr_state


    def _build_rv_graph(self, fixed_solution, removed_requests):
        """Build Request-Vehicle graph by generating trip costs."""
        self.vehicle_trips = []
        
        # Initialize rtv_graph for vehicles (needed for _process_trip_vehicle callback)
        self.rtv_graph = {}
        # for driver_run in fixed_solution:
        #     state = driver_run[PayloadParser.DRIVER_STATE]
        #     vehicle_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
        #     self.rtv_graph[vehicle_id] = [{}]
        
        # Generate costs for each trip-vehicle combination
        pool = mp.Pool(self.MAX_NUM_THREAD)

        fixed_solution_cost = {}
        
        for driver_run in fixed_solution:
            state = driver_run[PayloadParser.DRIVER_STATE]
            vehicle_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
            current_dr_state = self._get_current_driver_run_state(driver_run)
            dr_state_dict = current_dr_state.to_dict()  # Serialize once per vehicle

            fixed_solution_cost[vehicle_id] = self._calculate_remaining_cost(current_dr_state)
            self.rtv_graph[vehicle_id] = [{}]
            self._process_trip_vehicle((current_dr_state.sequence, fixed_solution_cost[vehicle_id], frozenset({}), vehicle_id))
            self.rtv_graph[vehicle_id].append({})
            
            for request in removed_requests:
                request_id = request["booking_id"]
                request_set = frozenset([request_id])  # Must use frozenset for dict key
                # Calculate insertion cost - pass dict instead of object to avoid pickling overhead
                args = (request_set, dr_state_dict, request, self.depot_node_id, self.DWELL_PICKUP, self.DWELL_ALIGHT, self.return_cost, False, False)
                pool.apply_async(LNSHandler.insert_new_request_to_driver_run, args=args,
                               callback=self._process_trip_vehicle)
        
        pool.close()
        pool.join()
        
        logging.debug(f"Generated {len(self.vehicle_trips)} trips")
        self.removed_trips = set()

        # Prune trips if RV_K is set
        if self.RV_K > 0:
            new_request_ids = set([req["booking_id"] for req in self.new_requests])
            self.rv_graph = {}
            for request in removed_requests:
                request_id = request["booking_id"]
                self.rv_graph[request_id] = []
            for run_id in self.rtv_graph:
                for trip_requests in self.rtv_graph[run_id][1]:
                    trip_index = self.rtv_graph[run_id][1][trip_requests]
                    trip = self.vehicle_trips[trip_index]
                    for request_id in trip.requests:
                        self.rv_graph[request_id].append((trip.cost-fixed_solution_cost[run_id], run_id))
            # Keep only lowest cost RV_K trips per request
            for request_id in self.rv_graph:
                trip_list = self.rv_graph[request_id]
                trip_list.sort(key=lambda x: x[0])
                if request_id in new_request_ids:
                    # No pruning for new requests
                    pruned_trip_list = trip_list
                else:
                    pruned_trip_list = []#trip_list[:self.RV_K]
                    starting_list, ending_list = [], []
                    for k, v in trip_list:
                        if v == self.prev_assignment[request_id]:
                            pruned_trip_list.append((k, v))
                        elif v in self.merged_start_with[self.prev_assignment[request_id]]:
                            starting_list.append((k, v))
                        elif v in self.merged_end_with[self.prev_assignment[request_id]]:
                            ending_list.append((k, v))
                        elif type(v) != str:
                            pruned_trip_list.append((k, v))
                    starting_list.sort(key=lambda x: x[0])
                    ending_list.sort(key=lambda x: x[0])
                    pruned_trip_list.sort(key=lambda x: x[0])
                    pruned_trip_list = pruned_trip_list[:self.RV_K] + starting_list[:self.RV_K//2] + ending_list[:self.RV_K//2]
                self.rv_graph[request_id] = set([x[1] for x in pruned_trip_list])
            # Update rtv_graph
            updated_trip_size = 0
            for run_id in self.rtv_graph:
                updated_trip_map = {}
                for trip_requests in self.rtv_graph[run_id][1]:
                    remove_trip = False
                    for request_id in trip_requests:
                        if run_id not in self.rv_graph[request_id]:
                            remove_trip = True
                            break
                    if not remove_trip:
                        updated_trip_map[trip_requests] = self.rtv_graph[run_id][1][trip_requests]
                    else:
                        self.removed_trips.add(self.rtv_graph[run_id][1][trip_requests])
                logging.debug(f"Vehicle {run_id}: pruned from {len(self.rtv_graph[run_id][1])} to {len(updated_trip_map)} trips")
                logging.debug(f"Vehicle {run_id}: updated RV edges {self.rtv_graph[run_id][1].keys()} trips")
                self.rtv_graph[run_id][1] = updated_trip_map
                updated_trip_size += len(updated_trip_map)

            logging.debug(f"Pruned trips based on RV_K={self.RV_K}, updated trip size: {updated_trip_size}")
            logging.debug(f"Removed trips based on RV_K={self.RV_K}: {len(self.removed_trips)}")
    
    def _build_rtv_graph(self, fixed_solution, removed_requests):
        """Build Request-Trip-Vehicle graph."""
        # rtv_graph is already initialized in _build_rv_graph, just update indices
        # for index, vehicle_trip in enumerate(self.vehicle_trips):
        #     self.rtv_graph[vehicle_trip.run_id][0][vehicle_trip.requests] = index

        start_time = time.time()
        # Build RTV graph for k shared trips
        k = 2
        max_cardinality = 5#len(removed_requests)
        while k <= max_cardinality:
            start_time_k = time.time()
            number_of_trips = len(self.vehicle_trips)
            
            # Collect all tasks first, then batch submit
            all_tasks = []
            time_taken_for_subset_check = 0
            
            for driver_run in fixed_solution:
                considered_trips = set()
                state = driver_run[PayloadParser.DRIVER_STATE]
                vehicle_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
                previous_trips = list(self.rtv_graph[vehicle_id][-1].keys())
                self.rtv_graph[vehicle_id].append({})
                # Adding the removed set as a trip if its size matches k
                if vehicle_id in self.removed_from_vehicles:
                    removed_set = frozenset(self.removed_from_vehicles[vehicle_id])
                    if len(removed_set) == k:
                        considered_trips.add(removed_set)
                        for dr in self.driver_runs:
                            if dr[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_RUN_ID] == vehicle_id:
                                self.rtv_graph[vehicle_id][len(removed_set)][removed_set] = len(self.vehicle_trips)
                                current_dr_state = self._get_current_driver_run_state(dr)
                                cost = self._calculate_remaining_cost(current_dr_state)
                                vehicle_trip = VehicleTrip(removed_set, vehicle_id, cost, current_dr_state.sequence)
                                self.vehicle_trips.append(vehicle_trip)
                                break
                if len(previous_trips) == 0:
                    continue
                number_of_previous_trips = len(previous_trips)
                for first in range(number_of_previous_trips):
                    request_set1 = previous_trips[first]
                    # If the previous round contained only one trip and that trip is the removed set, try adding all individual requests to that trip
                    if number_of_previous_trips == 1 and vehicle_id in self.removed_from_vehicles:
                        removed_set = frozenset(self.removed_from_vehicles[vehicle_id])
                        if removed_set == request_set1:
                            previous_trips = list(self.rtv_graph[vehicle_id][1].keys())
                            first = -1
                    for second in range(first + 1, len(previous_trips)):
                        subset_check_start_time = time.time()
                        request_set2 = previous_trips[second]
                        new_request_set = frozenset(request_set1.union(request_set2))  # frozenset for dict key
                        if len(new_request_set) != k:
                            continue
                        new_request_id = None
                        for request_id in request_set2:
                            if request_id not in request_set1:
                                new_request_id = request_id
                                break

                        # skip if the new set contain more that 3 requests not in removed set
                        if vehicle_id in self.removed_from_vehicles:
                            if len(new_request_set-self.removed_from_vehicles[vehicle_id]) > 3:
                                continue
                        # check if the new request set is already considered
                        if new_request_set in considered_trips:
                            continue
                        considered_trips.add(new_request_set)

                        # check for R-R shareability
                        shareable = True
                        for request_id in new_request_set:
                            if request_id != new_request_id and request_id not in self.rr_graph[new_request_id]:
                                shareable = False
                                break
                        
                        if not shareable:
                            continue
                    
                        all_subsets_exists = True
                        for request_id in new_request_set:
                            subset = frozenset(new_request_set.difference({request_id}))  # frozenset for dict key
                            if subset not in self.rtv_graph[vehicle_id][-2]:
                                all_subsets_exists = False
                                break
                        if not all_subsets_exists:
                            continue
                        time_taken_for_subset_check += time.time() - subset_check_start_time
                        trip1_index = self.rtv_graph[vehicle_id][-2][request_set1]
                        trip1 = self.vehicle_trips[trip1_index]
                        # create a new vehicle trip by merging the two previous trips
                        current_dr_state = self._get_current_driver_run_state(driver_run)
                        current_dr_state.sequence = trip1.sequence
                        dr_state_dict = current_dr_state.to_dict()  # Serialize to avoid pickling overhead
                        use_gurobi = False
                        if vehicle_id in self.removed_from_vehicles:
                            use_gurobi = new_request_set.issubset(self.removed_from_vehicles[vehicle_id])
                        if k >=4 or k > len(self.removed_from_vehicles.get(vehicle_id, set())):
                            use_gurobi = True
                        args = (new_request_set, dr_state_dict, self.request_dic[new_request_id], self.depot_node_id, self.DWELL_PICKUP, self.DWELL_ALIGHT, self.return_cost, False, use_gurobi)
                        all_tasks.append(args)
                        # logging.debug(f"Vid: {vehicle_id}, Inserting {new_request_id} and request set {request_set1}")
                logging.debug(f"Number of considered trips for {vehicle_id}: {len(considered_trips)}")
            
            # Batch process all tasks using imap_unordered (streaming results)
            number_of_sequence_insertions = len(all_tasks)
            if number_of_sequence_insertions > 0:
                time_batch_start = time.time()
                with mp.Pool(self.MAX_NUM_THREAD) as pool:
                    # Use imap_unordered for better performance with many tasks
                    # chunksize helps reduce IPC overhead
                    chunksize = max(1, number_of_sequence_insertions // (self.MAX_NUM_THREAD * 4))
                    for result in pool.starmap(LNSHandler.insert_new_request_to_driver_run, all_tasks, chunksize=chunksize):
                        self._process_trip_vehicle(result)
                logging.debug(f"Time for batch processing: {time.time() - time_batch_start} seconds")
            
            logging.debug(f"Number of sequence insertions for k={k}: {number_of_sequence_insertions}")
            logging.debug(f"Time taken for subset check: {time_taken_for_subset_check} seconds")
            logging.debug(f"Built RTV graph for {k} shared trips in {time.time()-start_time_k} seconds")
            logging.debug(f"Number of size {k} trips: {len(self.vehicle_trips)-number_of_trips}")
            k += 1
            # break if no new trips are created
            if number_of_trips == len(self.vehicle_trips):
                break
        
        # for driver_run in self.driver_runs:
        #     state = driver_run[PayloadParser.DRIVER_STATE]
        #     vehicle_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
        #     removed_set = frozenset(self.removed_from_vehicles[vehicle_id])
        #     if len(removed_set) > 0:
        #         if removed_set not in self.rtv_graph[vehicle_id][len(removed_set)]:
        #             self.rtv_graph[vehicle_id][len(removed_set)][removed_set] = len(self.vehicle_trips)
        #             current_dr_state = self._get_current_driver_run_state(driver_run)
        #             cost = self._calculate_remaining_cost(current_dr_state)
        #             vehicle_trip = VehicleTrip(removed_set, vehicle_id, cost, current_dr_state.sequence)
        #             self.vehicle_trips.append(vehicle_trip)
        logging.debug(f"Time to build RTV graph: {time.time()-start_time}")
        logging.debug(f"Generated {len(self.vehicle_trips)} trips in total")
    
    @staticmethod
    def insert_new_request_to_driver_run(request_set, driver_run_dict, request, depot, dwell_pickup, dwell_alight, return_cost, greedy_only, gurobi):
        """Insert a new request to a trip.
        
        Static method to avoid pickling entire LNSHandler instance in multiprocessing.
        
        Args:
            request_set: frozenset of request IDs
            driver_run_dict: dict from DriverRunCurrentState.to_dict()
            request: request dict to insert
            depot: depot node id
            dwell_pickup: pickup dwell time
            dwell_alight: dropoff dwell time
            return_cost: whether to include return-to-depot cost
        """
        # Reconstruct DriverRunCurrentState from dict
        driver_run = DriverRunCurrentState.from_dict(driver_run_dict)

        # First try greedy optimizer
        optimizer = GreedySequenceOptimizer(dwell_pickup, dwell_alight, return_cost=return_cost)
        cost, new_sequence = optimizer.insert_request_to_sequence(driver_run, depot, request)
        if cost >= 0:
            return new_sequence, cost, request_set, driver_run.id

        # Then try partial reorder sequence optimizer
        if not greedy_only:
            optimizer = PartialReorderSequenceOptimizer(dwell_pickup, dwell_alight, return_cost=return_cost)
            cost, new_sequence = optimizer.insert_request_to_sequence(driver_run, depot, request)
        if cost >= 0:
            return new_sequence, cost, request_set, driver_run.id

        # # Then try ILP optimizer
        if gurobi:
            optimizer = PartialReorderSequenceOptimizer(dwell_pickup, dwell_alight, return_cost=return_cost, k_flexible=6)
            cost, new_sequence = optimizer.insert_request_to_sequence(driver_run, depot, request)
        #     optimizer = GurobiSequenceOptimizer(dwell_pickup, dwell_alight, time_limit=1, return_cost=return_cost)
        #     cost, new_sequence = optimizer.insert_request_to_sequence(driver_run, depot, request)
        return new_sequence, cost, request_set, driver_run.id
    
    def _process_trip_vehicle(self, result):
        """Process the result of trip vehicle calculation."""
        new_sequence, cost, request_set, vehicle_id = result
        if cost >= 0:
            vehicle_trip = VehicleTrip(request_set, vehicle_id, cost, new_sequence)
            self.vehicle_trips.append(vehicle_trip)
            self.rtv_graph[vehicle_id][-1][request_set] = len(self.vehicle_trips) - 1
    
    def _solve_assignment_ilp(self, fixed_solution, removed_requests):
        """Solve the assignment problem using Integer Linear Programming."""
        try:
            with gp.Env(empty=True) as env:
                env.start()
                model = gp.Model('LNS_Assignment', env=env)
                
                # Decision variables: x_trip_vehicle = 1 if trip assigned to vehicle
                x = {}
                for trip_index, vehicle_trip in enumerate(self.vehicle_trips):
                    if trip_index in self.removed_trips:
                        continue
                    x[trip_index] = model.addVar(
                        vtype=GRB.BINARY, 
                        obj=vehicle_trip.cost,
                        name=f'x_{trip_index}'
                    )
                
                # variable to penalize the assignment of new request
                new_request_ids = set([req["booking_id"] for req in self.new_requests])
                z = {}
                for req_id in new_request_ids:
                    z[req_id] = model.addVar(vtype=GRB.BINARY, obj=10000000, name="z_"+req_id)

                # variables to track whether a vehicle is used or not
                y = {}
                for vehicle_id in self.merged_start_with:
                    for driver_run in fixed_solution:
                        if driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_RUN_ID] == vehicle_id:
                            completed_no = driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_LOC_SERV]
                            if completed_no == 0:
                                y[vehicle_id] = model.addVar(vtype=GRB.BINARY, obj=1000000, name=f'y_{vehicle_id}')
                            break
                
                non_empty_vehicle_tails = []
                for vehicle_id in self.merged_end_with:
                    for driver_run in fixed_solution:
                        if driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_RUN_ID] == vehicle_id:
                            completed_no = driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_LOC_SERV]
                            for stop in driver_run[PayloadParser.DRIVER_MANIFEST][completed_no:]:
                                if stop["action"] == "pickup":
                                    non_empty_vehicle_tails.append(vehicle_id)
                                    break
                            break
                # Constraint: Each request must be assigned exactly once
                for request in removed_requests:
                    request_id = request["booking_id"]
                    set_of_trips_for_request = []
                    for trip_index, vehicle_trip in enumerate(self.vehicle_trips):
                        if request_id in vehicle_trip.requests and trip_index not in self.removed_trips:
                            set_of_trips_for_request.append(trip_index)
                    if request_id in new_request_ids:
                        model.addConstr(
                            gp.quicksum(x[trip_index] for trip_index in set_of_trips_for_request) + z[request_id] == 1,
                            name=f'request_{request_id}'
                        )
                    else:
                        model.addConstr(
                            gp.quicksum(x[trip_index] for trip_index in set_of_trips_for_request) == 1,
                            name=f'request_{request_id}'
                        )
                
                # Constraint: Each vehicle can be assigned at most one trip/shared trip
                for vehicle_id in self.merged_start_with:
                    set_of_trips_with_vehicle = []
                    for vk in self.merged_start_with[vehicle_id]:
                        for k in range(len(self.rtv_graph[vk])):
                            set_of_trips_with_vehicle.extend(self.rtv_graph[vk][k].values())
                    if vehicle_id in y:
                        model.addConstr(
                            gp.quicksum(x[trip_index] for trip_index in set_of_trips_with_vehicle) == y[vehicle_id],
                            name=f'vehicle_{vehicle_id}'
                        )
                    else:
                        model.addConstr(
                            gp.quicksum(x[trip_index] for trip_index in set_of_trips_with_vehicle) == 1,
                            name=f'vehicle_{vehicle_id}'
                        )

                # constraint: each tail must be assigned to exactly one vehicle
                for vehicle_id in self.merged_end_with:
                    set_of_trips_with_vehicle = []
                    for vk in self.merged_end_with[vehicle_id]:
                        for k in range(len(self.rtv_graph[vk])):
                            set_of_trips_with_vehicle.extend(self.rtv_graph[vk][k].values())
                    if vehicle_id in y and vehicle_id not in non_empty_vehicle_tails:
                        model.addConstr(
                            gp.quicksum(x[trip_index] for trip_index in set_of_trips_with_vehicle) == y[vehicle_id],
                            name=f'tail_{vehicle_id}'
                        )
                    else:
                        model.addConstr(
                            gp.quicksum(x[trip_index] for trip_index in set_of_trips_with_vehicle) == 1,
                            name=f'tail_{vehicle_id}'
                        )
                logging.debug(f"Number of constraints: {model.NumConstrs}")
                # Solve
                model.setParam('TimeLimit', 30)
                model.optimize()

                # save model to file
                # model.write('ilp_assignment.lp')
                
                if model.SolCount > 0:
                    logging.debug(f"Optimal solution found with objective value: {model.ObjVal}")
                    # Extract selected trips
                    selected_trips = []
                    for trip_index, var in x.items():
                        if var.X > 0.5:
                            selected_trips.append(self.vehicle_trips[trip_index])
                    return selected_trips
                else:
                    logging.warning(f"ILP solver failed with status {model.Status}")
                    return None
                    
        except Exception as e:
            logging.error(f"Error in ILP assignment: {e}")
            return None
    
    def _build_repaired_solution(self, fixed_solution, model, x_vars):
        """Build the repaired solution from ILP results."""
        repaired_solution = copy.deepcopy(fixed_solution)
        
        # Extract assignments
        assignments = {}
        for (trip_no, vehicle_id), var in x_vars.items():
            if var.X > 0.5:  # Variable is selected
                if vehicle_id not in assignments:
                    assignments[vehicle_id] = []
                assignments[vehicle_id].append(trip_no)
        
        # Apply assignments to driver runs
        for driver_run in repaired_solution:
            state = driver_run[PayloadParser.DRIVER_STATE]
            vehicle_id = state[PayloadParser.DRIVER_STATE_RUN_ID]
            
            if vehicle_id in assignments:
                # Add assigned trips to this driver run
                for trip_no in assignments[vehicle_id]:
                    trip = self.trips[trip_no]
                    if isinstance(trip, Trip):
                        self._add_trip_to_driver_run(driver_run, trip)
                    else:  # SharedTrip
                        for sub_trip_no in trip.trips:
                            sub_trip = self.trips[sub_trip_no]
                            self._add_trip_to_driver_run(driver_run, sub_trip)
        
        return repaired_solution
    
    def _add_trip_to_driver_run(self, driver_run, trip):
        """Add a trip to a driver run manifest."""
        # Create pickup and dropoff stops
        pickup_stop = {
            'run_id': driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_RUN_ID],
            'booking_id': trip.request_id,
            'order': -1,  # Will be updated
            'action': "pickup",
            "loc": {"lat": trip.origin.lat, "lon": trip.origin.lon, "node_id": trip.origin.id},
            'scheduled_time': trip.pick_up_time,
            'am': trip.am_capacity,
            'wc': trip.wc_capacity,
            'time_window_start': trip.pick_up_time,
            'time_window_end': trip.latest_pick_up_time
        }
        
        dropoff_stop = {
            'run_id': driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_RUN_ID],
            'booking_id': trip.request_id,
            'order': -1,  # Will be updated
            'action': "dropoff",
            "loc": {"lat": trip.destination.lat, "lon": trip.destination.lon, "node_id": trip.destination.id},
            'scheduled_time': trip.earliest_arrival_time,
            'am': trip.am_capacity,
            'wc': trip.wc_capacity,
            'time_window_start': trip.earliest_arrival_time,
            'time_window_end': trip.latest_arrival_time
        }
        
        # Add stops to manifest (simplified - should use proper insertion logic)
        manifest = driver_run[PayloadParser.DRIVER_MANIFEST]
        manifest.extend([pickup_stop, dropoff_stop])
        
        # Update order numbers
        for i, stop in enumerate(manifest):
            stop["order"] = i + 1
        
        # Update state
        driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_T_LOCS] = len(manifest)

    def _calculate_remaining_cost(self, driver_run_state):
        """Calculate remaining cost of a driver run state."""
        total_cost = 0
        current_node = driver_run_state.start_node
        for stop in driver_run_state.sequence:
            cost = NetworkHandler.travel_time_from_node_indices(current_node, stop["loc"]["node_id"])
            total_cost += cost
            current_node = stop["loc"]["node_id"]
        if self.return_cost:
            total_cost += NetworkHandler.travel_time_from_node_indices(current_node, self.depot_node_id)
        return total_cost

    def _calculate_total_cost(self, solution):
        """Calculate total cost of a solution."""
        total_cost = 0
        included_new_requests = set()
        new_request_ids = set([req["booking_id"] for req in self.new_requests])
        for driver_run in solution:
            cost = SwapHandler.get_manifest_cost(driver_run, depot_node=self.depot, return_cost=self.return_cost)
            total_cost += cost
            for stop in driver_run[PayloadParser.DRIVER_MANIFEST]:
                if stop["booking_id"] in new_request_ids:
                    included_new_requests.add(stop["booking_id"])
        total_cost += (len(new_request_ids)-len(included_new_requests))*1000000 # Penalty for not including new request
        return total_cost
