import copy
from typing import Dict, List, Tuple, Set

from .greedy_sequence_optimizer import GreedySequenceOptimizer
from .network_handler import NetworkHandler
from ..structure.driver_run_state import DriverRunCurrentState
import itertools


class PartialReorderSequenceOptimizer(GreedySequenceOptimizer):
    """
    Partial reorder sequence optimizer that allows the first K stops to be reordered
    when inserting a new request, while keeping the remaining stops in their original order.
    
    Uses best-first search with a priority queue to generate permutations in 
    heuristic order (best candidates first) without generating all permutations upfront.
    
    The algorithm:
    1. Take first K stops + new pickup/dropoff as "flexible" stops
    2. Keep remaining stops as "fixed" (maintain relative order)
    3. Use priority queue to explore permutations in order of heuristic score
    4. Return the first feasible sequence
    """
    
    def __init__(self, dwell_pickup: int = 180, dwell_dropoff: int = 60, 
                 return_cost: bool = False, k_flexible: int = 4,
                 time_weight: float = 1.0, distance_weight: float = 1.0):
        super().__init__(dwell_pickup, dwell_dropoff, return_cost)
        self.k_flexible = k_flexible  # Number of stops that can be reordered
        self.time_weight = time_weight  # Weight for time window deviation
        self.distance_weight = distance_weight  # Weight for travel distance

    def insert_request_to_sequence(self, driver_run: DriverRunCurrentState, depot_node_id: float, request: Dict = None) -> Tuple[float, List[Dict]]:
        """
        Insert a new request into the sequence, allowing first K stops to be reordered.
        """
        am_capacity = driver_run.am_capacity
        current_am_load = driver_run.current_am_load
        current_time = driver_run.start_time
        end_time = driver_run.end_time
        remaining_stops = copy.deepcopy(driver_run.sequence)
        vehicle_id = driver_run.id
        start_node_id = driver_run.start_node
        completed = driver_run.completed

        # If no request to insert, just validate and return the existing sequence
        if request is None:
            return self._evaluate_sequence(
                remaining_stops, start_node_id, depot_node_id, 
                current_time, end_time, am_capacity, current_am_load, 
                vehicle_id, completed
            )

        # Create pickup and dropoff stops for the new request
        pickup_stop = {
            'run_id': vehicle_id, 
            'booking_id': request['booking_id'], 
            'order': -1, 
            'action': "pickup", 
            "loc": request["pickup_pt"], 
            'scheduled_time': -1, 
            'am': request["am"], 
            'wc': request["wc"], 
            'time_window_start': request['pickup_time_window_start'],
            'time_window_end': request['pickup_time_window_end']
        }
        dropoff_stop = {
            'run_id': vehicle_id, 
            'booking_id': request['booking_id'], 
            'order': -1, 
            'action': "dropoff",
            "loc": request["dropoff_pt"], 
            'scheduled_time': -1, 
            'am': request["am"], 
            'wc': request["wc"], 
            'time_window_start': request['dropoff_time_window_start'],
            'time_window_end': request['dropoff_time_window_end']
        }

        if "pickup_`service_time" in request:
            pickup_stop["service_time"] = request["pickup_service_time"]
            dropoff_stop["service_time"] = request["dropoff_service_time"]

        n = len(remaining_stops)
        k = min(self.k_flexible, n)

        
        # Split into flexible and fixed parts
        fix_before_flexible = 0#min(2, len(remaining_stops))
        fixed_before = copy.deepcopy(remaining_stops[:fix_before_flexible])
        flexible_stops = remaining_stops[fix_before_flexible:k+fix_before_flexible]
        fixed_after = copy.deepcopy(remaining_stops[k+fix_before_flexible:])
        
        # Add new pickup and dropoff to flexible stops
        flexible_stops.append(pickup_stop)
        flexible_stops.append(dropoff_stop)
        
        num_flexible = len(flexible_stops)  # Bug fix: was using k+1, should be k+2
        
        # Build unlocks: which dropoff is unlocked by which pickup
        # unlocks[i] = set of indices that become valid after visiting stop i
        unlocks = {}
        # Build feasible_after: which stops can come after stop i based on time windows
        feasible_after = {}
        # Track which stops are pickups (don't need to be unlocked)
        is_pickup = {}
        # Track which dropoffs need their pickup to be in fixed_before (already visited)
        dropoff_needs_unlock = {}
        
        for i in range(num_flexible):
            feasible_after[i] = set()
            unlocks[i] = set()
            stop_node_id = flexible_stops[i]["loc"]["node_id"]
            booking_id = flexible_stops[i]["booking_id"]
            stop_type = flexible_stops[i]["action"]
            is_pickup[i] = (stop_type == "pickup")
            
            if stop_type == "dropoff":
                # Check if the pickup for this dropoff is in flexible_stops
                pickup_in_flexible = any(
                    s["booking_id"] == booking_id and s["action"] == "pickup" 
                    for s in flexible_stops
                )
                dropoff_needs_unlock[i] = pickup_in_flexible
            
            for j in range(num_flexible):
                if j != i:
                    next_node_id = flexible_stops[j]["loc"]["node_id"]
                    next_booking_id = flexible_stops[j]["booking_id"]
                    next_stop_type = flexible_stops[j]["action"]
                    
                    # A dropoff cannot come immediately before its own pickup
                    if stop_type == "dropoff" and next_stop_type == "pickup" and next_booking_id == booking_id:
                        continue
                    
                    # If this is a pickup, it unlocks the corresponding dropoff
                    if stop_type == "pickup" and next_stop_type == "dropoff" and next_booking_id == booking_id:
                        unlocks[i].add(j)
                    
                    # Check time window feasibility
                    earliest_arrival_time = flexible_stops[i]["time_window_start"] + NetworkHandler.travel_time_from_node_indices(stop_node_id, next_node_id)
                    if earliest_arrival_time <= flexible_stops[j]["time_window_end"]:
                        feasible_after[i].add(j)
        
        # Determine valid first stops:
        # - Pickups can always be first
        # - Dropoffs can be first only if their pickup is in fixed_before
        valid_first_stops = set()
        for i in range(num_flexible):
            if is_pickup[i]:
                valid_first_stops.add(i)
            elif not dropoff_needs_unlock.get(i, True):
                valid_first_stops.add(i)
        
        # Get order of stops based on number of feasible predecessors (fewer = more constrained = try first)
        order = sorted(range(num_flexible), key=lambda x: len(feasible_after.get(x, set())))
        
        # Generate permutations of stops based on order
        for perm in itertools.permutations(order):
            # Quick check if permutation is valid
            
            # Check if first stop is valid
            if perm[0] not in valid_first_stops:
                continue
            
            valid = True
            unlocked = set()  # Set of dropoff indices that have been unlocked by visiting their pickup
            
            # First stop unlocks its corresponding dropoff (if it's a pickup)
            unlocked.update(unlocks[perm[0]])
            
            # Track last stop for feasibility check
            last_stop = perm[0]
            
            for i in perm[1:]:
                # Check if we can go from last_stop to i (time window feasibility)
                if i not in feasible_after[last_stop]:
                    valid = False
                    break
                
                # Check precedence: if i is a dropoff that needs unlock, it must be unlocked
                if not is_pickup[i] and dropoff_needs_unlock.get(i, True) and i not in unlocked:
                    valid = False
                    break
                
                # Visit this stop: unlock any dropoffs it enables
                unlocked.update(unlocks[i])
                last_stop = i
            
            if not valid:
                continue
            
            # Build candidate sequence
            candidate = copy.deepcopy(fixed_before) + [flexible_stops[i] for i in perm] + copy.deepcopy(fixed_after)
            # Evaluate candidate sequence
            cost, new_seq = self._evaluate_sequence(candidate, start_node_id, depot_node_id, current_time, end_time, am_capacity, current_am_load, vehicle_id, completed)
            if cost >= 0:
                return cost, new_seq

        return -1, None
