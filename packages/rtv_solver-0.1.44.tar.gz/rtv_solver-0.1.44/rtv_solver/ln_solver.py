# import matplotlib.pyplot as plt
import gurobipy as gp
from gurobipy import GRB
import numpy as np
import time
import os
import argparse
import copy
import sys
import math
import random
import pickle
import logging
from .handlers.network_handler import NetworkHandler
from .handlers.payload_parser import PayloadParser
from .handlers.lns_handler import LNSHandler
from .structure.node import Node


class LNSolver:
    """
    Large Neighbourhood Search Solver for PDPTW.
    """
    
    @staticmethod
    def solve_pdptw_lns(server_url, payload, time_limit, output_dir, iteration, 
                       K=3, max_lns_iterations=10, dwell_pickup=180, dwell_dropoff=60, return_cost=True):
        """
        Solve PDPTW using Large Neighbourhood Search approach.
        
        Args:
            server_url: Network service URL
            payload: Problem payload with driver_runs, depot, and requests
            time_limit: Time limit for optimization
            output_dir: Output directory for logs and results
            iteration: Current iteration number
            K: Number of requests to remove in each LNS iteration
            max_lns_iterations: Maximum LNS iterations
            dwell_pickup: Pickup dwell time
            dwell_dropoff: Dropoff dwell time
            return_cost: Whether to include return-to-depot cost
            
        Returns:
            Optimized driver runs or None if infeasible
        """
        try:
            logging.info(f"Starting LNS solver for iteration {iteration}")
            
            # Initialize LNS Handler
            lns_handler = LNSHandler(
                server_url=server_url,
                driver_runs=payload["driver_runs"],
                depot=payload["depot"],
                DWELL_PICKUP=dwell_pickup,
                DWELL_ALIGHT=dwell_dropoff,
                MAX_NUM_THREAD=min(16, os.cpu_count() or 4),
                new_request=None,
                enable_TSP_reoptimization=True,
                return_cost=return_cost
            )
            
            # Run LNS optimization
            start_time = time.time()
            optimized_runs, improvement, lns_iterations = lns_handler.run_lns(
                K=K,
                max_iterations=max_lns_iterations,
                max_time=min(time_limit, 300)  # Limit LNS time
            )
            
            lns_time = time.time() - start_time
            logging.info(f"LNS completed: {lns_iterations} iterations, {lns_time:.2f}s, improvement: {improvement}")
            
            return optimized_runs
            
        except Exception as e:
            logging.error(f"LNS solver failed: {e}")
            return None
    
    @staticmethod
    def solve_pdptw(server_url, payload, time_limit, output_dir, iteration, min_truck=False, dwell_pickup=180, dwell_dropoff=60, return_cost=True):

        NetworkHandler.init(True, server_url)

        depot = payload["depot"]
        depot_node_id = NetworkHandler.get_next_node_id(depot["pt"]["lat"],depot["pt"]["lon"])
        depot_node = Node(depot["pt"]["lat"],depot["pt"]["lon"], id=depot_node_id)

        
        requests = copy.deepcopy(payload["requests"])
        unserved = []
        for request in requests:
            unserved.append(request["booking_id"])
        driver_runs = copy.deepcopy(payload["driver_runs"])
        nb_nodes = len(requests)*2
        truck_capacity = driver_runs[0]["state"]["am_capacity"]
        completed_pickups = set()
        completed_dropoffs = set()
        truck_load_data = []
        truck_current_time_data = []
        truck_current_location_data = []
        fixed_dropoff_requests = {}
        unused_trucks = []
        used_trucks = []

        active_requests = set()
        request_pickup_map = {}
        request_dropoff_map = {}

        fixed_requests = []
        for i in range(len(driver_runs)):
            if driver_runs[i]["state"]["locations_already_serviced"] == 0:
                unused_trucks.append(i)
            else:
                used_trucks.append(i)
        for driver_run in driver_runs:
            state = driver_run["state"]
            manifest = driver_run["manifest"]

            # Updating node_id for current location
            state_loc = state["loc"]
            node_id = NetworkHandler.get_next_node_id(state_loc["lat"],state_loc["lon"])
            state_loc["node_id"] = node_id
            state["loc"] = state_loc

            completed = driver_run["state"]["locations_already_serviced"]

            # Updating node_id for remaining stops
            for stop in manifest[completed:]:
                node_id = NetworkHandler.get_next_node_id(stop["loc"]["lat"],stop["loc"]["lon"])
                stop["loc"]["node_id"] = node_id
                active_requests.add(stop["booking_id"])
                if stop["action"] == "pickup":
                    request_pickup_map[stop["booking_id"]] = stop
                else:
                    request_dropoff_map[stop["booking_id"]] = stop
                    if stop["booking_id"] not in request_pickup_map:
                        for stop_t in manifest[:completed]:
                            if stop_t["booking_id"] == stop["booking_id"]:
                                request_pickup_map[stop["booking_id"]] = stop_t
                                break

            load = 0
            nb_nodes += len(manifest)
            for stop in manifest[:completed]:
                nb_nodes -= 1
                if stop["action"] == "pickup":
                    load += stop["am"]
                    fixed_dropoff_requests[stop["booking_id"]] = stop["run_id"]
                    fixed_requests.append(stop["booking_id"])
                    completed_pickups.add(stop["booking_id"])
                else:
                    load -= stop["am"]
                    del fixed_dropoff_requests[stop["booking_id"]]
                    completed_dropoffs.add(stop["booking_id"])
            truck_load_data.append(load)
            truck_current_time_data.append(driver_run["state"]["location_dt_seconds"])
            truck_current_location_data.append(driver_run["state"]["loc"]["node_id"])
        nb_trucks = len(driver_runs)
        max_horizon = driver_runs[0]["state"]["end_time"]
        nb_nodes += nb_trucks  # Adding starting locations of vehicles
        nb_nodes += 1 # Adding depot at end

        # print(truck_load_data)

        node_map = {}
        reverse_node_map = {}
        reverse_request_map = {}
        node_start = 0

        demands_data = [0] * nb_nodes
        service_time_data = [0] * nb_nodes
        earliest_start_data = [driver_runs[0]["state"]["start_time"]] * nb_nodes
        latest_end_data = [max_horizon] * nb_nodes
        pick_up_index = [0] * nb_nodes
        delivery_index = [0] * nb_nodes
        run_id_fix_data = [0] * nb_nodes

        # Setting depot
        node_map[depot_node_id] = node_start
        reverse_node_map[node_start] = depot_node_id
        node_start += 1
        pick_up_index[0] = -3
        delivery_index[0] = -3
        run_id_fix_data[0] = -3

        # Setting trucks starting locations
        demands_data[1:nb_trucks+1] = truck_load_data
        earliest_start_data[1:nb_trucks+1] = truck_current_time_data
        pick_up_index[1:nb_trucks+1] = [-3]*nb_trucks
        delivery_index[1:nb_trucks+1] = [-3]*nb_trucks
        run_id_fix_data[1:nb_trucks+1] = [-3]*nb_trucks
        for node_id in truck_current_location_data:
            node_map[node_id] = node_start
            reverse_node_map[node_start] = node_id
            node_start += 1

        request_index = 0

        for request in requests:
            origin = request["pickup_pt"]
            dest = request["dropoff_pt"]
            origin_id = NetworkHandler.get_next_node_id(origin["lat"],origin["lon"])
            origin["node_id"] = origin_id
            dest_id = NetworkHandler.get_next_node_id(dest["lat"],dest["lon"])
            dest["node_id"] = dest_id

        for booking_id in active_requests:
            request = {}
            pickup_stop = request_pickup_map[booking_id]
            request["pickup_pt"] = pickup_stop["loc"]
            request["pickup_time_window_start"] = pickup_stop["time_window_start"]
            request["pickup_time_window_end"] = pickup_stop["time_window_end"]
            dropoff_stop = request_dropoff_map[booking_id]
            request["dropoff_pt"] = dropoff_stop["loc"]
            request["am"] = dropoff_stop["am"]
            request["dwell_pickup"] = dwell_pickup
            request["dwell_alight"] = dwell_dropoff
            request["dropoff_time_window_start"] = dropoff_stop["time_window_start"]
            request["dropoff_time_window_end"] = dropoff_stop["time_window_end"]
            request["booking_id"] = booking_id
            requests.append(request)

        for request in requests:
            booking_id = request["booking_id"]
            origin_id = request["pickup_pt"]["node_id"]
            dest_id = request["dropoff_pt"]["node_id"]

            if booking_id not in completed_dropoffs:
                origin = node_start
                if booking_id not in completed_pickups:
                    node_map[origin_id] = origin
                    reverse_node_map[origin] = origin_id
                    reverse_request_map[origin] = request_index
                    node_start += 1
                    demands_data[origin] = request["am"]
                    service_time_data[origin] = dwell_pickup
                    earliest_start_data[origin] = request["pickup_time_window_start"]
                    latest_end_data[origin] = request["pickup_time_window_end"]
                    pick_up_index[origin] = -1
                    delivery_index[origin] = node_start
                    run_id_fix_data[origin] = -1
                dest = node_start
                node_map[dest_id] = dest
                reverse_node_map[dest] = dest_id
                reverse_request_map[dest] = request_index
                node_start += 1
                demands_data[dest] = -request["am"]
                service_time_data[dest] = dwell_dropoff
                earliest_start_data[dest] = request["dropoff_time_window_start"]
                latest_end_data[dest] = request["dropoff_time_window_end"]
                if booking_id not in completed_pickups:
                    pick_up_index[dest] = origin
                    run_id_fix_data[dest] = -1
                else:
                    pick_up_index[dest] = -2
                    run_id_fix_data[dest] = fixed_dropoff_requests[request["booking_id"]]
                delivery_index[dest] = -1
            request_index += 1

        time_matrix, no_of_nodes, _ = NetworkHandler.initialize_travel_time_matrix()
        no_of_nodes = int(no_of_nodes.value)
        time_matrix = np.frombuffer(time_matrix, dtype=np.float64)
        time_matrix = time_matrix.reshape((no_of_nodes, no_of_nodes))
        
        print("No of customers: ",nb_nodes)
        travel_times = [[0] * (nb_nodes+1) for i in range(nb_nodes+1)]
        depot_id = payload["depot"]["node_id"]
        for i in range(nb_nodes):
            for j in range(nb_nodes):
                travel_time = time_matrix[reverse_node_map[i]][reverse_node_map[j]]
                if i >= 1 and i <= nb_trucks and i != j and (j >= 1 and j <= nb_trucks):
                    travel_time = np.inf
                if i == 0 and j >=1 and j <= nb_trucks:
                    travel_time = 0
                if i > nb_trucks and j >= 1 and j <= nb_trucks:
                    travel_time = np.inf
                travel_times[i][j] = travel_time

        print("Distance matrix shape: ", len(travel_times),len(travel_times[0]))
        print("No of demand data: ",len(demands_data))
        print(travel_times)
        routes = {}

        # if output_dir:
        #     with open(output_dir+"fixed_requests.txt".format(iteration), 'a') as f:
        #         f.write("Iteration	{0} :  {1}\n".format(iteration," ".join(str(x) for x in fixed_requests)))

        try:
            with gp.Env(empty=True) as env:
                # env.setParam('OutputFlag', 0)
                env.start()
                
                model = gp.Model('PDPTWOptimization', env=env)
                
                # Decision variables: x[i][j] = 1 if stop j is visited immediately after stop i
                x = {}
                for i in range(1,nb_nodes):  # +1 for depot, depot is 0
                    x[i, 0] = model.addVar(vtype=GRB.BINARY, name=f'x_{i}_{0}')
                    for j in range(nb_trucks+1,nb_nodes):
                        if i != j and travel_times[i][j] < np.inf:
                            x[i, j] = model.addVar(vtype=GRB.BINARY, name=f'x_{i}_{j}')
                
                # Time variables: t[i] = arrival time at stop i
                t = {}
                for i in range(nb_nodes):
                    t[i] = model.addVar(lb=earliest_start_data[i], ub=latest_end_data[i], name=f't_{i}')
                
                # Load variables: l[i] = load after visiting stop i
                l = {}
                for i in range(1,nb_nodes):
                    lb = 0
                    if i >= 1 and i<= nb_trucks:
                        lb = demands_data[i]
                    l[i] = model.addVar(lb=lb, ub=state["am_capacity"], name=f'l_{i}')
                
                # Objective: minimize travel time
                # if objective == "travel_time":
                if return_cost:
                    model.setObjective(
                        gp.quicksum(travel_times[i][j] * x[i, j] 
                                    for i in range(1,nb_nodes) 
                                    for j in range(nb_trucks+1,nb_nodes) if (i != j and travel_times[i][j] < np.inf))+
                        gp.quicksum(travel_times[i][0] * x[i, 0] 
                                    for i in range(1,nb_nodes)),
                        GRB.MINIMIZE
                    )
                else:
                    model.setObjective(
                        gp.quicksum(travel_times[i][j] * x[i, j] 
                                    for i in range(1,nb_nodes) 
                                    for j in range(nb_trucks+1,nb_nodes) if (i != j and travel_times[i][j] < np.inf)),
                        GRB.MINIMIZE
                    )
                # else:  # total_time
                #     model.setObjective(
                #         gp.quicksum(t[i] for i in range(nb_nodes)),
                #         GRB.MINIMIZE
                    # )
                
                # Constraints
                
                # 1. Each stop must be visited exactly once (from depot or another stop)
                for j in range(1+nb_trucks,nb_nodes):
                    model.addConstr(
                        gp.quicksum(x[i, j] for i in range(1,nb_nodes) if (i != j and travel_times[i][j] < np.inf)) == 1,
                        name=f'visit_{j}'
                    )
                
                model.addConstr(
                        gp.quicksum(x[i, 0] for i in range(1,nb_nodes)) == nb_trucks,
                        name=f'visit_{0}'
                    )
                
                # 2. Each stop must be left exactly once (to depot or another stop)
                for j in range(1,nb_nodes):
                    model.addConstr(
                        gp.quicksum(x[j, i] for i in range(nb_nodes) if (i != j and travel_times[j][i] < np.inf)) == 1,
                        name=f'visit_{j}'
                    )
                
                # 4. Pickup-delivery precedence constraints
                booking_to_pick = {}
                booking_to_drop = {}
                
                # Build booking to node mappings
                for i in range(nb_nodes):
                    if pick_up_index[i] == -1:  # This is a pickup node
                        booking_id = reverse_request_map.get(i)
                        if booking_id is not None:
                            request = requests[booking_id]
                            booking_to_pick[request["booking_id"]] = i
                    elif delivery_index[i] == -1:  # This is a delivery node
                        booking_id = reverse_request_map.get(i)
                        if booking_id is not None:
                            request = requests[booking_id]
                            booking_to_drop[request["booking_id"]] = i
                
                for booking_id in booking_to_pick:
                    # Delivery must come after pickup
                    pickup_idx = booking_to_pick[booking_id]
                    delivery_idx = booking_to_drop.get(booking_id, -1)
                    if delivery_idx != -1:
                        model.addConstr(t[delivery_idx] >= t[pickup_idx], 
                                        name=f'precedence_{pickup_idx}_{delivery_idx}')
                
                # # 5. Time window constraints
                # for i in range(nb_nodes):
                #     model.addConstr(t[i] >= earliest_start_data[i], 
                #                   name=f'tw_start_{i}')
                #     model.addConstr(t[i] <= latest_end_data[i], 
                #                   name=f'tw_end_{i}')
                M = 1000000  # Big M value for time constraints
                # 6. Travel time and service time constraints
                for i in range(1,nb_nodes):
                    for j in range(nb_nodes):
                        if i != j and travel_times[i][j] < np.inf:
                            model.addConstr(
                                t[j] >= t[i] + travel_times[i][j] + service_time_data[i] - 
                                (1 - x[i, j]) * M,  # Big M constraint
                                name=f'travel_{i}_{j}'
                            )
                
                # 7. Capacity constraints (linear with Big M)
                M = state["am_capacity"]  # Big M value. M is the capacity of the vehicle.
                
                for i in range(1,nb_nodes):
                    # Load at stop i = load from previous stop + load change at stop i
                    demand = demands_data[i]
                    
                    # If coming from depot (index nb_nodes), load is just the load change
                    # model.addConstr(
                    #     l[i] >= current_load + demand - M * (1 - x[0, i+1]),
                    #     name=f'load_from_depot_{i}'
                    # )
                    
                    # If coming from another stop j, load is previous load + load change
                    for j in range(nb_nodes):
                        if j != i and travel_times[i][j] < np.inf:
                            model.addConstr(
                                l[i] >= l[j] + demand - M * (1 - x[j, i]),
                                name=f'load_from_stop_{j}_{i}'
                            )
                
                # Set initial solution (current stop sequence)
                intitial_edge_list = {}
                for i in range(nb_trucks):
                    driver_run = driver_runs[i]
                    state = driver_run["state"]
                    manifest = driver_run["manifest"]
                    completed = driver_run["state"]["locations_already_serviced"]

                    t[i+1].start = truck_current_time_data[i]
                    l[i+1].start = truck_load_data[i]
                    # Updating node_id for remaining stops
                    current_j = i + 1
                    current_load = truck_load_data[i]
                    for stop in manifest[completed:]:
                        node_id = stop["loc"]["node_id"]
                        j = node_map[node_id]
                        t[j].start = stop["scheduled_time"]
                        current_load += stop["am"]
                        l[j].start = current_load
                        x[current_j, j].start = 1.0
                        intitial_edge_list.append((current_j, j))
                        current_j = j
                    intitial_edge_list.append((current_j, 0))
                    x[current_j, 0].start = 1.0  # Return to depot
                
                # Set all other x variables to 0
                for i in range(1,nb_nodes):
                    for j in range(nb_trucks+1,nb_nodes):
                        if i != j and travel_times[i][j] < np.inf:
                            if (i, j) not in intitial_edge_list:
                                x[i, j].start = 0.0
                
                # Set initial time values using scheduled times
                current_load_value = current_load

                # Write model to file for debugging
                try:
                    model.write(output_dir+'PDPTW_optimization.lp')
                    logging.debug("Model written to PDPTW.lp")
                except Exception as e:
                    logging.warning(f"Failed to write model to file: {e}")
                
                # Solve the model
                model.setParam('TimeLimit', time_limit)  # reset time limit
                model.setParam('MIPGap', 0.05)  # 5% gap
                model.optimize()

                time_taken = model.Runtime
                logging.debug(f"Time taken for reoptimization of driver run: {time_taken} seconds")
                if model.Status == GRB.OPTIMAL or model.Status == GRB.SUBOPTIMAL or model.Status == GRB.TIME_LIMIT:
                    print("Optimal solution found with objective value: ", model.ObjVal)
                    # Extract solution
                    routes = []
                    for i in range(nb_trucks):
                        route = []
                        current = i+1  # Start from depot

                        while True:
                            if x[current, 0].X > 0.5:
                                break
                            for j in range(nb_trucks+1,nb_nodes):
                                if current != j and x[current, j].X > 0.5:  # If x[current, j] = 1
                                    route.append(j)
                                    current = j
                                    break
                        routes.append(route)
                    
                    new_driver_runs = []
                    for driver_run in driver_runs:
                        state = copy.deepcopy(driver_run["state"])
                        new_driver_run = {"state": state, "manifest": driver_run["manifest"][:state["locations_already_serviced"]]}
                        new_driver_runs.append(new_driver_run)
                    for route_no, route in enumerate(routes):
                        driver_run = new_driver_runs[route_no]
                        driver_run["state"]["total_locations"] = len(route) + driver_run["state"]["locations_already_serviced"]
                        current_time = driver_run["state"]["location_dt_seconds"]
                        current_loc = driver_run["state"]["loc"]["node_id"]
                        current_order = driver_run["state"]["locations_already_serviced"] + 1
                        for i in route:
                            # print("Current order: ", current_order)
                            # print("Current location: ", current_loc)
                            # print("Current time: ", current_time)
                            current_time += time_matrix[current_loc][reverse_node_map[i]]
                            if current_time < earliest_start_data[i]:
                                current_time = earliest_start_data[i]
                            action = "pickup" if pick_up_index[i] == -1 else "dropoff"
                            request = requests[reverse_request_map[i]]
                            booking_id = request["booking_id"]
                            demand = demands_data[i] if pick_up_index[i] == -1 else - demands_data[i]
                            loc = request["pickup_pt"] if action == "pickup" else request["dropoff_pt"]
                            stop = {'run_id': driver_run["state"]["run_id"], 'booking_id': booking_id, 'order': current_order, 'action': action, 
                                    "loc": loc, 'scheduled_time': current_time, 
                                    'am': demand, 'wc': 0, 'time_window_start': earliest_start_data[i], 
                                    'time_window_end':latest_end_data[i], 'dwell': service_time_data[i]}
                            current_loc = reverse_node_map[i]    
                            current_order += 1
                            current_time += service_time_data[i]
                            driver_run["manifest"].append(stop)
                    return new_driver_runs
                else:
                    print("No feasible solution found.")
                    return None
        except Exception as e:
            raise RuntimeError(f"An error occurred during optimization: {e}")
