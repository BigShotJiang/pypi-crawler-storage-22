from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
import copy
import numpy as np
from .handlers.network_handler import NetworkHandler
from .handlers.payload_parser import PayloadParser
from .structure.node import Node


class ORToolsSolverSoft:

    def solve_pdptw(server_url, payload, time_limit, output_dir, iteration,
                    min_truck=False, dwell_pickup=180, dwell_dropoff=60, set_initial_solution=False, tt_matrix=None,
                    early_penalty=10000, late_penalty=10000, log_search=False):

        time_matrix, no_of_nodes = None, None
        if tt_matrix == None:
            NetworkHandler.init(True, server_url)
        else:
            time_matrix, no_of_nodes, _, _ = NetworkHandler.init(False, server_url, tt_matrix)

        depot = payload["depot"]
        if tt_matrix == None:
            depot_node_id = NetworkHandler.get_next_node_id(depot["pt"]["lat"],depot["pt"]["lon"])
        else:
            depot_node_id = depot["pt"]["node_id"]
        depot_node = Node(depot["pt"]["lat"],depot["pt"]["lon"], id=depot_node_id)
        
        requests = copy.deepcopy(payload["requests"])
        unserved = []
        for request in requests:
            unserved.append(request["booking_id"])
        driver_runs = copy.deepcopy(payload["driver_runs"])
        nb_customers = len(requests)*2
        truck_capacity = driver_runs[0]["state"]["am_capacity"]
        completed_pickups = set()
        completed_dropoffs = set()
        truck_load_data = []
        fixed_dropoff_requests = {}
        unused_trucks = []
        used_trucks = []

        active_requests = set()
        request_pickup_map = {}
        request_dropoff_map = {}

        fixed_requests = []
        for i in range(len(driver_runs)):
            if driver_runs[i]["state"]["locations_already_serviced"] == 0:
                unused_trucks.append(i)
            else:
                used_trucks.append(i)
        for driver_run in driver_runs:
            state = driver_run["state"]
            manifest = driver_run["manifest"]

            # Updating node_id for current location
            state_loc = state["loc"]
            if tt_matrix is None:
                node_id = NetworkHandler.get_next_node_id(state_loc["lat"],state_loc["lon"])
                state_loc["node_id"] = node_id
            state["loc"] = state_loc

            completed = driver_run["state"]["locations_already_serviced"]

            # Updating node_id for remaining stops
            for stop in manifest[completed:]:
                if tt_matrix is None:
                    node_id = NetworkHandler.get_next_node_id(stop["loc"]["lat"],stop["loc"]["lon"])
                    stop["loc"]["node_id"] = node_id
                active_requests.add(stop["booking_id"])
                if stop["action"] == "pickup":
                    request_pickup_map[stop["booking_id"]] = stop
                else:
                    request_dropoff_map[stop["booking_id"]] = stop
                    if stop["booking_id"] not in request_pickup_map:
                        for stop_t in manifest[:completed]:
                            if stop_t["booking_id"] == stop["booking_id"]:
                                request_pickup_map[stop["booking_id"]] = stop_t
                                break

            load = 0
            nb_customers += len(manifest)
            for stop in manifest[:completed]:
                nb_customers -= 1
                if stop["action"] == "pickup":
                    load += stop["am"]
                    fixed_dropoff_requests[stop["booking_id"]] = stop["run_id"]
                    fixed_requests.append(stop["booking_id"])
                    completed_pickups.add(stop["booking_id"])
                else:
                    load -= stop["am"]
                    del fixed_dropoff_requests[stop["booking_id"]]
                    completed_dropoffs.add(stop["booking_id"])
            truck_load_data.append(load)
        nb_trucks = len(driver_runs)
        max_horizon = driver_runs[0]["state"]["end_time"]

        node_map = {}
        reverse_node_map = {}
        reverse_request_map = {}

        node_start = 0  # 0 is depot
        node_map[depot_node_id] = 0
        reverse_node_map[0] = depot_node_id
        reverse_request_map[0] = -1
        node_start += 1

        num_nodes = nb_customers + 1 + nb_trucks  # including depot and start of trucks

        demands_data = [0] * num_nodes
        service_time_data = [0] * num_nodes
        earliest_start_data = [0] * num_nodes
        latest_end_data = [0] * num_nodes
        pick_up_index = [0] * num_nodes
        delivery_index = [0] * num_nodes
        run_id_fix_data = [0] * num_nodes

        earliest_start_data[0] = 0
        latest_end_data[0] = max_horizon
        service_time_data[0] = 0
        demands_data[0] = 0
        pick_up_index[0] = -1
        delivery_index[0] = -1
        run_id_fix_data[0] = -1

        for driver_run in driver_runs:
            start_loc_id = driver_run["state"]["loc"]["node_id"]
            node_map[start_loc_id] = node_start
            reverse_node_map[node_start] = start_loc_id
            reverse_request_map[node_start] = -1
            current_load = 0
            for stop in driver_run["manifest"][:driver_run["state"]["locations_already_serviced"]]:
                if stop["action"] == "pickup":
                    current_load += stop["am"]
                else:
                    current_load -= stop["am"]
            demands_data[node_start] = current_load
            service_time_data[node_start] = int(driver_run["state"]["location_dt_seconds"])
            earliest_start_data[node_start] = 0
            latest_end_data[node_start] = driver_run["state"]["end_time"]
            pick_up_index[node_start] = -1
            delivery_index[node_start] = -1
            run_id_fix_data[node_start] = -1
            node_start += 1

        
        request_index = 0

        if tt_matrix is None:
            for request in requests:
                origin = request["pickup_pt"]
                dest = request["dropoff_pt"]
                origin_id = NetworkHandler.get_next_node_id(origin["lat"],origin["lon"])
                origin["node_id"] = origin_id
                dest_id = NetworkHandler.get_next_node_id(dest["lat"],dest["lon"])
                dest["node_id"] = dest_id

        for booking_id in active_requests:
            request = {}
            pickup_stop = request_pickup_map[booking_id]
            request["pickup_pt"] = pickup_stop["loc"]
            request["pickup_time_window_start"] = pickup_stop["time_window_start"]
            request["pickup_time_window_end"] = pickup_stop["time_window_end"]
            dropoff_stop = request_dropoff_map[booking_id]
            request["dropoff_pt"] = dropoff_stop["loc"]
            request["am"] = dropoff_stop["am"]
            request["dwell_pickup"] = dwell_pickup
            request["dwell_alight"] = dwell_dropoff
            request["dropoff_time_window_start"] = dropoff_stop["time_window_start"]
            request["dropoff_time_window_end"] = dropoff_stop["time_window_end"]
            request["booking_id"] = booking_id
            requests.append(request)

        for request in requests:
            booking_id = request["booking_id"]
            origin_id = request["pickup_pt"]["node_id"]
            dest_id = request["dropoff_pt"]["node_id"]

            if booking_id not in completed_dropoffs:
                origin = node_start
                if booking_id not in completed_pickups:
                    node_map[origin_id] = origin
                    reverse_node_map[origin] = origin_id
                    reverse_request_map[origin] = request_index
                    node_start += 1
                    demands_data[origin] = request["am"]
                    service_time_data[origin] = dwell_pickup
                    earliest_start_data[origin] = request["pickup_time_window_start"]
                    latest_end_data[origin] = request["pickup_time_window_end"]
                    pick_up_index[origin] = -1
                    delivery_index[origin] = node_start
                    run_id_fix_data[origin] = -1
                dest = node_start
                node_map[dest_id] = dest
                reverse_node_map[dest] = dest_id
                reverse_request_map[dest] = request_index
                node_start += 1
                demands_data[dest] = -request["am"]
                service_time_data[dest] = dwell_dropoff
                earliest_start_data[dest] = request["dropoff_time_window_start"]
                latest_end_data[dest] = request["dropoff_time_window_end"]
                if booking_id not in completed_pickups:
                    pick_up_index[dest] = origin
                    run_id_fix_data[dest] = -1
                else:
                    pick_up_index[dest] = -2
                    run_id_fix_data[dest] = fixed_dropoff_requests[request["booking_id"]]
                delivery_index[dest] = -1
            request_index += 1

        if tt_matrix is None:
            time_matrix, no_of_nodes, _, _ = NetworkHandler.initialize_travel_time_matrix()
        no_of_nodes = int(no_of_nodes.value)
        time_matrix = np.frombuffer(time_matrix, dtype=np.float64)
        time_matrix = time_matrix.reshape((no_of_nodes, no_of_nodes))
        
        print("No of nodes: ",num_nodes)
        dist_matrix = [[0] * (num_nodes) for i in range(num_nodes)]
        for i in range(num_nodes):
            for j in range(num_nodes):
                dist_matrix[i][j] = int(time_matrix[reverse_node_map[i]][reverse_node_map[j]])

        # make it impossible to go from any other node to start of trucks except from depot
        # set the distance from depot to start of trucks as driver_run["state"]["location_dt_seconds"]
        # make it impossible to go depott to any other node except start of trucks
        # dist_matrix[0] = [999999] * num_nodes
        # dist_matrix[0][0] = 0
        for driver_run in driver_runs:
            start_loc_id = driver_run["state"]["loc"]["node_id"]
            start_index = node_map[start_loc_id]
            # current_time = int(driver_run["state"]["location_dt_seconds"])
            for i in range(num_nodes):
                if i != start_index:
                    dist_matrix[start_index][i] = dist_matrix[start_index][i]

        # for i in range(num_nodes):
        #     print(dist_matrix[i])
        # === STEP 2: Create Routing Model ===
        manager = pywrapcp.RoutingIndexManager(num_nodes, nb_trucks, [i+1 for i in range(nb_trucks)],[0]*nb_trucks)  # depot=0
        routing = pywrapcp.RoutingModel(manager)

        # Distance callback
        def distance_callback(from_index, to_index):
            from_node = manager.IndexToNode(from_index)
            to_node = manager.IndexToNode(to_index)
            return dist_matrix[from_node][to_node]

        transit_callback_index = routing.RegisterTransitCallback(distance_callback)
        routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

        # === STEP 3: Add capacity constraint ===
        def demand_callback(from_index):
            node = manager.IndexToNode(from_index)
            return demands_data[node]

        demand_callback_index = routing.RegisterUnaryTransitCallback(demand_callback)
        routing.AddDimensionWithVehicleCapacity(
            demand_callback_index,
            0,  # no slack
            [truck_capacity] * nb_trucks,
            True,  # start cumul to zero
            'Capacity')

        # === STEP 4: Add time windows ===
        def time_callback(from_index, to_index):
            from_node = manager.IndexToNode(from_index)
            to_node = manager.IndexToNode(to_index)
            return dist_matrix[from_node][to_node] + service_time_data[from_node]

        time_callback_index = routing.RegisterTransitCallback(time_callback)
        # Use 2*max_horizon as capacity to allow penalized late depot returns (soft bound at latest_end_data[0])
        routing.AddDimension(
            time_callback_index,
            int(max_horizon),  # waiting slack
            int(2 * max_horizon),  # capacity: allow exploration beyond depot deadline
            True,  # start cumul to zero
            'Time')

        time_dimension = routing.GetDimensionOrDie('Time')
        
        # Use soft time windows instead of hard constraints to allow infeasible exploration
        # Penalty weights for time window violations (configurable via parameters)
        # Higher penalties guide search more strongly toward feasible solutions
        # Lower penalties allow more exploration of infeasible space
        
        for node in range(nb_trucks+1,num_nodes):
            index = manager.NodeToIndex(node)
            start = int(earliest_start_data[node])
            end = int(latest_end_data[node])
            
            # Add soft lower bound (penalize early arrivals before time window opens)
            time_dimension.SetCumulVarSoftLowerBound(index, start, early_penalty)
            
            # Add soft upper bound (penalize late arrivals after time window closes)
            time_dimension.SetCumulVarSoftUpperBound(index, end, late_penalty)

        # Penalize late arrival at depot (latest_end_data[0] = max_horizon)
        depot_latest = int(latest_end_data[0])
        for vehicle_id in range(nb_trucks):
            end_index = routing.End(vehicle_id)
            time_dimension.SetCumulVarSoftUpperBound(end_index, depot_latest, late_penalty)

        # for i in range(nb_trucks):
        #     routing.AddVariableMinimizedByFinalizer(
        #         time_dimension.CumulVar(routing.Start(i))
        #     )
        #     routing.AddVariableMinimizedByFinalizer(time_dimension.CumulVar(routing.End(i)))

        # === STEP 5: Add pickup-delivery constraints ===
        for i in range(nb_trucks+1,num_nodes):
            pick_up_index_i = pick_up_index[i]
            if pick_up_index_i >= 0:
                pickup = pick_up_index_i
                delivery = i
                pickup_index = manager.NodeToIndex(pickup)
                delivery_index = manager.NodeToIndex(delivery)
                routing.AddPickupAndDelivery(pickup_index, delivery_index)
                routing.solver().Add(
                    routing.VehicleVar(pickup_index) == routing.VehicleVar(delivery_index))
                routing.solver().Add(
                    time_dimension.CumulVar(pickup_index) <= time_dimension.CumulVar(delivery_index))
        for i in range(nb_trucks+1,num_nodes):
            if run_id_fix_data[i] >= 0:
                delivery = i
                delivery_index = manager.NodeToIndex(delivery)
                routing.solver().Add(routing.VehicleVar(delivery_index) == run_id_fix_data[i])

        routes = []
        total_cost = 0
        for driver_run in driver_runs:
            start_node_id = driver_run["state"]["loc"]["node_id"]
            new_route = []
            current_time = 0
            for stop in driver_run["manifest"][driver_run["state"]["locations_already_serviced"]:]:
                node_id = stop["loc"]["node_id"]
                new_route.append(manager.NodeToIndex((node_map[node_id])))
                travel_time = dist_matrix[node_map[start_node_id]][node_map[node_id]]
                total_cost += travel_time
                current_time += travel_time
                start_node_id = node_id

            routes.append(new_route)
        print("Total cost of initial routes: ", total_cost)

        if set_initial_solution:
            initial_solution = routing.ReadAssignmentFromRoutes(routes, True)
        # === STEP 6: Search parameters ===
        search_params = pywrapcp.DefaultRoutingSearchParameters()
        search_params.log_search = log_search
        search_params.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.AUTOMATIC
        search_params.local_search_metaheuristic = routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
        search_params.time_limit.seconds = time_limit
        # search_params.solution_limit = 1

        # === STEP 7: Solve ===
        if set_initial_solution:
           solution = routing.SolveFromAssignmentWithParameters(initial_solution,search_params)
        else:
            solution = routing.SolveWithParameters(search_params)
        print("Solver status: ", routing.status())
        if not solution:
            return payload["driver_runs"], unserved
        # print("Objective: {}".format(solution.ObjectiveValue()))

        # === STEP 8: Extract routes back into driver_runs ===
        new_driver_runs = copy.deepcopy(driver_runs)

        """Prints solution on console."""
        print(f"Objective: {solution.ObjectiveValue()}")
        time_dimension = routing.GetDimensionOrDie("Time")
        total_time = 0
        for vehicle_id in range(nb_trucks):
            new_driver_run = new_driver_runs[vehicle_id]
            completed = new_driver_run["state"]["locations_already_serviced"]
            new_driver_run["manifest"] = new_driver_run["manifest"][:completed]
            current_time = new_driver_run["state"]["location_dt_seconds"]
            current_loc_id = new_driver_run["state"]["loc"]["node_id"]
            current_order = new_driver_run["state"]["locations_already_serviced"] + 1
            if not routing.IsVehicleUsed(solution, vehicle_id):
                continue
            index = routing.Start(vehicle_id)
            plan_output = f"Route for vehicle {vehicle_id}:\n"
            while not routing.IsEnd(index):
                i = manager.IndexToNode(index)
                node_id = reverse_node_map[i]
                time_var = time_dimension.CumulVar(index)
                node_desc = "-1"
                request_index = reverse_request_map[i]
                if request_index >= 0:
                    request = requests[request_index]
                    node_desc = f"{request['booking_id']}({ 'P' if demands_data[i]>0 else 'D'})"
                plan_output += (
                    f"{node_desc}"
                    f" Time({solution.Min(time_var)},{solution.Max(time_var)})"
                    " -> "
                )
                index = solution.Value(routing.NextVar(index))
                if current_loc_id == node_id or current_loc_id == depot_node_id:
                    continue
                current_time += time_matrix[current_loc_id][node_id]
                if current_time < earliest_start_data[i]:
                    current_time = earliest_start_data[i]
                action = "pickup" if pick_up_index[i] == -1 else "dropoff"
                request = requests[request_index]
                booking_id = request["booking_id"]
                demand = abs(demands_data[i])
                loc = request["pickup_pt"] if action == "pickup" else request["dropoff_pt"]
                stop = {'run_id': new_driver_run["state"]["run_id"], 'booking_id': booking_id, 'order': current_order, 'action': action, 
                        "loc": loc, 'scheduled_time': current_time, 
                        'am': demand, 'wc': 0, 'time_window_start': earliest_start_data[i], 
                        'time_window_end':latest_end_data[i]}
                current_loc_id = node_id
                current_order += 1
                current_time += service_time_data[i]
                new_driver_run["manifest"].append(stop)

            new_driver_run["state"]["total_locations"] = len(new_driver_run["manifest"])

            time_var = time_dimension.CumulVar(index)
            plan_output += (
                f"{manager.IndexToNode(index)}"
                f" Time({solution.Min(time_var)},{solution.Max(time_var)})\n"
            )
            plan_output += f"Time of the route: {solution.Min(time_var)}min\n"
            print(plan_output)
            total_time += solution.Min(time_var)
        print(f"Total time of all routes: {total_time}min")

        return new_driver_runs, []
