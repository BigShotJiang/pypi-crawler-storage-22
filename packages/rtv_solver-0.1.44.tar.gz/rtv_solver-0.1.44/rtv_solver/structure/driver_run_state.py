class DriverRunCurrentState:
    def __init__(self, id, start_node, start_time, am_capacity, wc_capacity, current_am_load, current_wc_load, end_time, sequence, depot, completed):
        self.id = id
        self.start_time = start_time
        self.start_node = start_node
        self.end_time = end_time
        self.depot = depot
        self.am_capacity = am_capacity
        self.current_am_load = current_am_load
        self.wc_capacity = wc_capacity
        self.current_wc_load = current_wc_load
        self.sequence = sequence
        self.completed = completed

    def __str__(self):
        return "{{Driver Run ID: {0}, start time: {1}, start node: {2}, end time: {3}, depot: {4}}}".format(self.id, self.start_time, self.start_node, self.end_time, self.depot)

    def to_dict(self):
        """Serialize to dictionary for efficient pickling in multiprocessing."""
        return {
            'id': self.id,
            'start_node': self.start_node,
            'start_time': self.start_time,
            'am_capacity': self.am_capacity,
            'wc_capacity': self.wc_capacity,
            'current_am_load': self.current_am_load,
            'current_wc_load': self.current_wc_load,
            'end_time': self.end_time,
            'sequence': self.sequence,
            'depot': self.depot,
            'completed': self.completed
        }

    @classmethod
    def from_dict(cls, d):
        """Deserialize from dictionary."""
        return cls(
            id=d['id'],
            start_node=d['start_node'],
            start_time=d['start_time'],
            am_capacity=d['am_capacity'],
            wc_capacity=d['wc_capacity'],
            current_am_load=d['current_am_load'],
            current_wc_load=d['current_wc_load'],
            end_time=d['end_time'],
            sequence=d['sequence'],
            depot=d['depot'],
            completed=d['completed']
        )
