from typing import List, Optional, Callable
import asyncio
from .client import HTTPClient
from .handlers import Handler
from .middleware import Middleware
from .models import Update
from . import filters

class Bot(HTTPClient):
    def __init__(self, token: str, sequential_handlers: bool = False):
        super().__init__(token)
        self.handlers: List[Handler] = []
        self.middlewares: List[Middleware] = []
        self.sequential_handlers = sequential_handlers
        self._running = False
        self._update_offset = None

    # ---------- Handler Registration ----------
    def on_update(self, *filters):
        def decorator(func):
            self.handlers.append(Handler(func, filters))
            return func
        return decorator

    def add_handler(self, callback: Callable, *filters):
        self.handlers.append(Handler(callback, filters))

    # ---------- Middleware ----------
    def middleware(self):
        def decorator(func):
            self.middlewares.append(Middleware(func))
            return func
        return decorator

    # ---------- Processing ----------
    async def process_update(self, update: Update):
        # تزریق client به update برای دسترسی به متدهای reply و ...
        update.client = self

        # اجرای middlewareها
        async def call_next(index=0):
            if index < len(self.middlewares):
                await self.middlewares[index](self, update, lambda: call_next(index+1))
            else:
                # اجرای هندلرها
                for handler in self.handlers:
                    if await handler.check(update):
                        await handler.callback(self, update)
                        if self.sequential_handlers:
                            break

        await call_next()

    # ---------- Polling ----------
    async def polling(self, interval: float = 1, limit: int = 100):
        self._running = True
        while self._running:
            try:
                data = await self.request("getUpdates", {"limit": limit, "offset_id": self._update_offset})
                updates = data.get("updates", [])
                for upd in updates:
                    update = Update.from_dict(upd)
                    # آپدیت offset (در صورت وجود next_offset_id در پاسخ)
                    self._update_offset = data.get("next_offset_id")
                    asyncio.create_task(self.process_update(update))
            except Exception as e:
                print(f"Polling error: {e}")
            await asyncio.sleep(interval)

    def stop(self):
        self._running = False

    # ---------- API Methods (نمونه) ----------
    async def send_message(self, chat_id: str, text: str, **kwargs):
        data = {"chat_id": chat_id, "text": text, **kwargs}
        result = await self.request("sendMessage", data)
        return result.get("message_id")

    async def delete_message(self, chat_id: str, message_id: str):
        await self.request("deleteMessage", {"chat_id": chat_id, "message_id": message_id})