import aiohttp
import asyncio
from typing import Optional, Dict, Any, List

class HTTPClient:
    def __init__(self, token: str, base_url: str = "https://botapi.rubika.ir/v3/{token}/{method}"):
        self.token = token
        self.base_url = base_url
        self.session: Optional[aiohttp.ClientSession] = None

    async def start(self):
        self.session = aiohttp.ClientSession()

    async def stop(self):
        if self.session:
            await self.session.close()

    async def request(self, method: str, data: Dict[str, Any] = None) -> Dict[str, Any]:
        url = self.base_url.format(token=self.token, method=method)
        async with self.session.post(url, json=data) as resp:
            result = await resp.json()
            if result.get("status") != "OK":
                raise Exception(f"API error: {result}")
            return result.get("data")