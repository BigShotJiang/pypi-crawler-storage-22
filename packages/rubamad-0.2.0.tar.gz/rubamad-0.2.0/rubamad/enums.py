from enum import Enum

class ChatTypeEnum(Enum):
    USER = "User"
    BOT = "Bot"
    GROUP = "Group"
    CHANNEL = "Channel"

class UpdateTypeEnum(Enum):
    NEW_MESSAGE = "NewMessage"
    EDITED_MESSAGE = "EditedMessage"
    DELETED_MESSAGE = "DeletedMessage"
    STARTED_BOT = "StartedBot"
    STOPPED_BOT = "StoppedBot"

# سایر Enumها مانند ButtonTypeEnum، ChatKeypadTypeEnum و ...