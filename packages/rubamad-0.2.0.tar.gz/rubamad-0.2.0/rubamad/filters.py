from abc import ABC, abstractmethod
from typing import Union, Pattern
import re

class Filter(ABC):
    @abstractmethod
    async def check(self, update: "Update") -> bool:
        pass

class TextFilter(Filter):
    def __init__(self, pattern: Union[str, Pattern] = None, regex: bool = False):
        self.pattern = pattern
        self.regex = regex

    async def check(self, update: "Update") -> bool:
        if not update.new_message or not update.new_message.text:
            return False
        text = update.new_message.text
        if self.pattern is None:
            return True
        if self.regex:
            return re.match(self.pattern, text) is not None
        return text == self.pattern

class CommandFilter(Filter):
    def __init__(self, commands: Union[str, List[str]]):
        self.commands = [commands] if isinstance(commands, str) else commands

    async def check(self, update: "Update") -> bool:
        if not update.new_message or not update.new_message.text:
            return False
        text = update.new_message.text
        return any(text.startswith(f"/{cmd}") for cmd in self.commands)

class PrivateFilter(Filter):
    async def check(self, update: "Update") -> bool:
        # نیاز به دسترسی به نوع چت از طریق API یا مدل
        # در اینجا فرض می‌کنیم chat_type در دسترس نیست، پس باید از client دریافت شود
        # یا اینکه در Update.chat_type ذخیره شود.
        return True  # placeholder

# توابع کمکی برای ساخت فیلتر
def text(pattern=None, regex=False):
    return TextFilter(pattern, regex)

def command(commands):
    return CommandFilter(commands)

def private():
    return PrivateFilter()