from typing import Callable, List, Optional, Any
from .filters import Filter

class Handler:
    def __init__(self, callback: Callable, filters: Optional[List[Filter]] = None):
        self.callback = callback
        self.filters = filters or []

    async def check(self, update) -> bool:
        for f in self.filters:
            if not await f.check(update):
                return False
        return True