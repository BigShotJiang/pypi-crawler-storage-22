from typing import Callable, Awaitable

class Middleware:
    def __init__(self, func: Callable):
        self.func = func

    async def __call__(self, bot, update, call_next):
        return await self.func(bot, update, call_next)