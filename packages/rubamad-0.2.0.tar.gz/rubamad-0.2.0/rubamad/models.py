from dataclasses import dataclass
from typing import Optional, List, Any, Dict
from .enums import *

@dataclass
class File:
    file_id: str
    file_name: Optional[str] = None
    size: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        return cls(
            file_id=data.get("file_id"),
            file_name=data.get("file_name"),
            size=data.get("size")
        )

@dataclass
class Message:
    message_id: str
    text: Optional[str] = None
    time: Optional[int] = None
    is_edited: Optional[bool] = None
    sender_id: Optional[str] = None
    file: Optional[File] = None
    # ...

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        return cls(
            message_id=data["message_id"],
            text=data.get("text"),
            time=data.get("time"),
            is_edited=data.get("is_edited"),
            sender_id=data.get("sender_id"),
            file=File.from_dict(data["file"]) if data.get("file") else None,
        )

@dataclass
class Update:
    type: UpdateTypeEnum
    chat_id: str
    new_message: Optional[Message] = None
    updated_message: Optional[Message] = None
    removed_message_id: Optional[str] = None
    client: Optional["Bot"] = None  # برای دسترسی به متدهای پاسخ

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        return cls(
            type=UpdateTypeEnum(data["type"]),
            chat_id=data["chat_id"],
            new_message=Message.from_dict(data["new_message"]) if data.get("new_message") else None,
            updated_message=Message.from_dict(data["updated_message"]) if data.get("updated_message") else None,
            removed_message_id=data.get("removed_message_id")
        )

    async def reply(self, text: str, **kwargs):
        if not self.client:
            raise ValueError("client not set")
        return await self.client.send_message(self.chat_id, text, reply_to_message_id=self.new_message.message_id, **kwargs)

    async def delete(self):
        if not self.client:
            raise ValueError("client not set")
        return await self.client.delete_message(self.chat_id, self.new_message.message_id)