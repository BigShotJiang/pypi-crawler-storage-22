# RunCalc

A library for runners, to run calculations and conversions

## Installation
```bash
pip install runcalc
```

## Usage
```python
from runcalc import kmh_to_mph, vo2max

# Convert speed
speed_mph = kmh_to_mph(10)

# Calculate VO2max
vo2 = vo2max('cooper', distance_m=2800)
```

## Features

- Speed and pace conversions
- Distance calculations
- VO2max estimation
- Heart rate zone calculations
- Race time predictions
- And more!

## License

MIT
```

**`LICENSE`:**
Use MIT licence (simple and popular):
```
MIT License

Copyright (c) 2026 [Your Name]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicence, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.