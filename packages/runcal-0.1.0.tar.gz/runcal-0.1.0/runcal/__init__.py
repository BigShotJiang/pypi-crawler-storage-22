"""A library of running calculations and conversions."""

__version__ = "0.1.0"

from .core import (
    # Import all your functions here
    kmh_to_mph,
    mph_to_kmh,
    kmh_to_minpk,
    minpk_to_kmh,
    mph_to_minpmi,
    minpmi_to_mph,
    minpk_to_minpmi,
    minpmi_to_minpk,
    kmh_to_minpmi,
    minpmi_to_kmh,
    mph_to_minpk,
    minpk_to_mph,
    convert_distance,
    time_to_distance,
    speed_to_time,
    distance_from_speed,
    distance_from_pace,
    pace_from_distance,
    time_at_arrival,
    ascent_from_gradient,
    elevation_gain_from_pace,
    stride_from_distance,
    stride_from_pace,
    distance_from_stride,
    race_splits,
    predict_race_time,
    vo2max,
    heart_rate_zones,
    calories_keytel,
    time_to_decimal,
    decimal_to_time,
)