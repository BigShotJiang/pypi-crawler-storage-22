import datetime as dt
import numpy as np

# ============ Speed/Pace Conversions ============

def kmh_to_mph(speed_kmh, formatted=False):
    """
    Convert kilometres per hour to miles per hour.

    Args:
        speed_kmh (float): Speed in kilometres per hour
        formatted (bool): Not applicable for this conversion

    Returns:
        float: Speed in miles per hour
    """
    if speed_kmh < 0:
        raise ValueError("Speed cannot be negative")
    return speed_kmh * 0.62137


def mph_to_kmh(speed_mph, formatted=False):
    """
    Convert miles per hour to kilometres per hour.

    Args:
        speed_mph (float): Speed in miles per hour
        formatted (bool): Not applicable for this conversion

    Returns:
        float: Speed in kilometres per hour
    """
    if speed_mph < 0:
        raise ValueError("Speed cannot be negative")
    return speed_mph / 0.62137


def kmh_to_minpk(speed_kmh, formatted=False):
    """
    Convert km/h to pace in min/km.

    Args:
        speed_kmh (float): Speed in kilometres per hour
        formatted (bool): If True, return MM:SS string. If False, return decimal minutes.

    Returns:
        float or str: Pace in min/km (decimal) or MM:SS format
    """
    if speed_kmh <= 0:
        raise ValueError("Speed must be positive")

    pace = 60 / speed_kmh

    if formatted:
        minutes = int(pace)
        seconds = int((pace - minutes) * 60)
        return f"{minutes}:{seconds:02d}"

    return pace


def minpk_to_kmh(pace_minpk, formatted=False):
    """
    Convert pace in min/km to km/h.

    Args:
        pace_minpk (float): Pace in minutes per kilometre
        formatted (bool): Not applicable for this conversion

    Returns:
        float: Speed in kilometres per hour
    """
    if pace_minpk <= 0:
        raise ValueError("Pace must be positive")
    return 60 / pace_minpk


def mph_to_minpmi(speed_mph, formatted=False):
    """
    Convert mph to pace in min/mile.

    Args:
        speed_mph (float): Speed in miles per hour
        formatted (bool): If True, return MM:SS string. If False, return decimal minutes.

    Returns:
        float or str: Pace in min/mile (decimal) or MM:SS format
    """
    if speed_mph <= 0:
        raise ValueError("Speed must be positive")

    pace = 60 / speed_mph

    if formatted:
        minutes = int(pace)
        seconds = int((pace - minutes) * 60)
        return f"{minutes}:{seconds:02d}"

    return pace


def minpmi_to_mph(pace_minpmi, formatted=False):
    """
    Convert pace in min/mile to mph.

    Args:
        pace_minpmi (float): Pace in minutes per mile
        formatted (bool): Not applicable for this conversion

    Returns:
        float: Speed in miles per hour
    """
    if pace_minpmi <= 0:
        raise ValueError("Pace must be positive")
    return 60 / pace_minpmi


def minpk_to_minpmi(pace_minpk, formatted=False):
    """
    Convert pace from min/km to min/mile.

    Args:
        pace_minpk (float): Pace in minutes per kilometre
        formatted (bool): If True, return MM:SS string. If False, return decimal minutes.

    Returns:
        float or str: Pace in min/mile (decimal) or MM:SS format
    """
    if pace_minpk <= 0:
        raise ValueError("Pace must be positive")

    pace = pace_minpk * 1.60934

    if formatted:
        minutes = int(pace)
        seconds = int((pace - minutes) * 60)
        return f"{minutes}:{seconds:02d}"

    return pace


def minpmi_to_minpk(pace_minpmi, formatted=False):
    """
    Convert pace from min/mile to min/km.

    Args:
        pace_minpmi (float): Pace in minutes per mile
        formatted (bool): If True, return MM:SS string. If False, return decimal minutes.

    Returns:
        float or str: Pace in min/km (decimal) or MM:SS format
    """
    if pace_minpmi <= 0:
        raise ValueError("Pace must be positive")

    pace = pace_minpmi / 1.60934

    if formatted:
        minutes = int(pace)
        seconds = int((pace - minutes) * 60)
        return f"{minutes}:{seconds:02d}"

    return pace


def kmh_to_minpmi(speed_kmh, formatted=False):
    """
    Convert km/h to pace in min/mile.

    Args:
        speed_kmh (float): Speed in kilometres per hour
        formatted (bool): If True, return MM:SS string. If False, return decimal minutes.

    Returns:
        float or str: Pace in min/mile (decimal) or MM:SS format
    """
    if speed_kmh <= 0:
        raise ValueError("Speed must be positive")

    pace = 96.560699 / speed_kmh

    if formatted:
        minutes = int(pace)
        seconds = int((pace - minutes) * 60)
        return f"{minutes}:{seconds:02d}"

    return pace


def minpmi_to_kmh(pace_minpmi, formatted=False):
    """
    Convert pace in min/mile to km/h.

    Args:
        pace_minpmi (float): Pace in minutes per mile
        formatted (bool): Not applicable for this conversion

    Returns:
        float: Speed in kilometres per hour
    """
    if pace_minpmi <= 0:
        raise ValueError("Pace must be positive")
    return 96.560699 / pace_minpmi


def mph_to_minpk(speed_mph, formatted=False):
    """
    Convert mph to pace in min/km.

    Args:
        speed_mph (float): Speed in miles per hour
        formatted (bool): If True, return MM:SS string. If False, return decimal minutes.

    Returns:
        float or str: Pace in min/km (decimal) or MM:SS format
    """
    if speed_mph <= 0:
        raise ValueError("Speed must be positive")

    pace = 37.282364 / speed_mph

    if formatted:
        minutes = int(pace)
        seconds = int((pace - minutes) * 60)
        return f"{minutes}:{seconds:02d}"

    return pace


def minpk_to_mph(pace_minpk, formatted=False):
    """
    Convert pace in min/km to mph.

    Args:
        pace_minpk (float): Pace in minutes per kilometre
        formatted (bool): Not applicable for this conversion

    Returns:
        float: Speed in miles per hour
    """
    if pace_minpk <= 0:
        raise ValueError("Pace must be positive")
    return 37.282364 / pace_minpk


# ============ Distance Conversions ============

def convert_distance(value, unitfrom, unitto):
    """
    Convert between distance units.

    Args:
        value (float): Distance value to convert
        unitfrom (str): Unit to convert from ('m', 'km', 'mi', 'ft', 'yd', 'cm')
        unitto (str): Unit to convert to ('m', 'km', 'mi', 'ft', 'yd', 'cm')

    Returns:
        float: Converted distance value rounded to 3 decimal places

    Example:
        >>> convert_distance(5, 'km', 'm')
        5000.0
        >>> convert_distance(1, 'mi', 'km')
        1.609
    """
    if value < 0:
        raise ValueError("Distance cannot be negative")

    to_metres = {
        'm': 1,
        'km': 1000,
        'mi': 1609.344,
        'ft': 0.3048,
        'yd': 0.9144,
        'cm': 0.01
    }

    if unitfrom not in to_metres or unitto not in to_metres:
        raise ValueError(f"Unsupported unit. Use: {list(to_metres.keys())}")

    metres = value * to_metres[unitfrom]
    result = metres / to_metres[unitto]

    return round(result, 3)


# ============ Distance Calculations ============

def time_to_distance(pace_min, distance):
    """
    Calculate time required to cover a distance at a given pace.

    Args:
        pace_min (float): Pace in minutes per unit distance (e.g., min/km)
        distance (float): Distance in same units as pace

    Returns:
        float: Time in minutes

    Example:
        >>> time_to_distance(5.0, 10)  # 5 min/km pace for 10 km
        50.0
    """
    if pace_min <= 0:
        raise ValueError("Pace must be positive")
    if distance < 0:
        raise ValueError("Distance cannot be negative")
    return pace_min * distance


def speed_to_time(speed, distance):
    """
    Calculate time required to cover a distance at a given speed.

    Args:
        speed (float): Speed in units per hour (e.g., km/h)
        distance (float): Distance in same units as speed

    Returns:
        float: Time in hours

    Example:
        >>> speed_to_time(12, 6)  # 12 km/h for 6 km
        0.5
    """
    if speed <= 0:
        raise ValueError("Speed must be positive")
    if distance < 0:
        raise ValueError("Distance cannot be negative")
    return distance / speed


def distance_from_speed(speed, time_hours):
    """
    Calculate distance covered at a given speed over time.

    Args:
        speed (float): Speed in units per hour (e.g., km/h)
        time_hours (float): Time in hours

    Returns:
        float: Distance in same units as speed

    Example:
        >>> distance_from_speed(12, 0.5)  # 12 km/h for 30 minutes
        6.0
    """
    if speed <= 0:
        raise ValueError("Speed must be positive")
    if time_hours < 0:
        raise ValueError("Time cannot be negative")
    return speed * time_hours


def distance_from_pace(pace_min, time_min):
    """
    Calculate distance covered at a given pace over time.

    Args:
        pace_min (float): Pace in minutes per unit distance
        time_min (float): Time in minutes

    Returns:
        float: Distance in same units as pace

    Example:
        >>> distance_from_pace(5.0, 50)  # 5 min/km pace for 50 minutes
        10.0
    """
    if pace_min <= 0:
        raise ValueError("Pace must be positive")
    if time_min < 0:
        raise ValueError("Time cannot be negative")
    return time_min / pace_min


def pace_from_distance(distance, time_min):
    """
    Calculate pace from distance and time.

    Args:
        distance (float): Distance covered
        time_min (float): Time in minutes

    Returns:
        float: Pace in minutes per unit distance

    Example:
        >>> pace_from_distance(10, 50)  # 10 km in 50 minutes
        5.0
    """
    if distance <= 0:
        raise ValueError("Distance must be positive")
    if time_min <= 0:
        raise ValueError("Time must be positive")
    return time_min / distance


def time_at_arrival(distance, pace_min):
    """
    Calculate estimated arrival time based on current time, distance, and pace.

    Args:
        distance (float): Distance remaining
        pace_min (float): Pace in minutes per unit distance

    Returns:
        datetime: Estimated arrival time

    Example:
        >>> time_at_arrival(5, 5.0)  # 5 km at 5 min/km pace
        # Returns current time + 25 minutes
    """
    if distance < 0:
        raise ValueError("Distance cannot be negative")
    if pace_min <= 0:
        raise ValueError("Pace must be positive")

    delta = distance * pace_min / 60
    return dt.datetime.now() + dt.timedelta(hours=delta)


# ============ Elevation and Gradient ============

def ascent_from_gradient(gradient, distance):
    """
    Calculate elevation gain from gradient and distance.

    Args:
        gradient (float): Gradient as decimal (e.g., 0.05 for 5% grade)
        distance (float): Distance travelled

    Returns:
        float: Elevation gain in same units as distance

    Example:
        >>> ascent_from_gradient(0.05, 1000)  # 5% grade over 1000m
        50.0
    """
    if distance < 0:
        raise ValueError("Distance cannot be negative")
    return gradient * distance


def elevation_gain_from_pace(gradient, time_min, pace_min):
    """
    Calculate elevation gain from gradient, time, and pace.

    Args:
        gradient (float): Gradient as decimal
        time_min (float): Time in minutes
        pace_min (float): Pace in minutes per unit distance

    Returns:
        float: Elevation gain

    Example:
        >>> elevation_gain_from_pace(0.05, 50, 5)  # 5% grade, 50 min, 5 min/km pace
        50.0
    """
    if time_min < 0:
        raise ValueError("Time cannot be negative")
    if pace_min <= 0:
        raise ValueError("Pace must be positive")
    return time_min / pace_min * gradient


# ============ Stride and Steps ============

def stride_from_distance(distance, steps):
    """
    Calculate stride length from distance and step count.

    Args:
        distance (float): Distance covered
        steps (int): Number of steps taken

    Returns:
        float: Stride length in same units as distance, rounded to 3 decimals

    Example:
        >>> stride_from_distance(1000, 1250)  # 1000m in 1250 steps
        1.6
    """
    if distance < 0:
        raise ValueError("Distance cannot be negative")
    if steps <= 0:
        raise ValueError("Steps must be positive")
    return round(distance / (steps / 2), 3)


def stride_from_pace(pace_min, steps, time_min):
    """
    Calculate stride length from pace, step count, and time.

    Args:
        pace_min (float): Pace in minutes per unit distance
        steps (int): Number of steps taken
        time_min (float): Time in minutes

    Returns:
        float: Stride length, rounded to 3 decimals

    Example:
        >>> stride_from_pace(5.0, 1250, 50)  # 5 min/km, 1250 steps, 50 minutes
        1.6
    """
    if pace_min <= 0:
        raise ValueError("Pace must be positive")
    if steps <= 0:
        raise ValueError("Steps must be positive")
    if time_min < 0:
        raise ValueError("Time cannot be negative")
    return round(time_min / pace_min / (steps / 2), 3)


def distance_from_stride(stride_length, steps):
    """
    Calculate distance from stride length and step count.

    Args:
        stride_length (float): Length of one stride
        steps (int): Number of steps taken

    Returns:
        float: Distance in same units as stride length

    Example:
        >>> distance_from_stride(1.6, 1250)  # 1.6m stride, 1250 steps
        1000.0
    """
    if stride_length <= 0:
        raise ValueError("Stride length must be positive")
    if steps <= 0:
        raise ValueError("Steps must be positive")
    return stride_length * (steps / 2)


# ============ Race Planning ============

def race_splits(target_time_hours, distance, split_distance=1):
    """
    Calculate split times for even-paced race.

    Args:
        target_time_hours (float): Target finish time in hours
        distance (float): Total race distance
        split_distance (float): Distance interval for splits (default: 1)

    Returns:
        dict: Split times with keys like 'km 1', 'km 2', etc.
              Values are cumulative time in minutes

    Example:
        >>> race_splits(1.5, 10)  # 1.5 hours for 10 km
        {'km 1': 9.0, 'km 2': 18.0, ..., 'km 10': 90.0}
    """
    if target_time_hours <= 0:
        raise ValueError("Target time must be positive")
    if distance <= 0:
        raise ValueError("Distance must be positive")
    if split_distance <= 0:
        raise ValueError("Split distance must be positive")

    target_time_min = target_time_hours * 60
    splits_list = list(np.arange(split_distance, distance + split_distance, split_distance))

    split_times = {
        f'km {i}': round(target_time_min / distance * i, 3)
        for i in splits_list
    }

    return split_times


def predict_race_time(distance_km, time_hours, target_distance_km, fatigue_factor=1.06):
    """
    Predict race time using Riegel's formula.

    Args:
        distance_km (float): Known race distance in km
        time_hours (float): Time for known race in hours
        target_distance_km (float): Target race distance in km
        fatigue_factor (float): Fatigue exponent (default: 1.06)

    Returns:
        tuple: (predicted_time_hours, pace_min_per_km, speed_kmh)
            - predicted_time_hours: Predicted finish time in hours
            - pace_min_per_km: Average pace in min/km
            - speed_kmh: Average speed in km/h

    Example:
        >>> predict_race_time(5, 0.5, 10)  # 5km in 30 min, predict 10km
        (1.074, 6.444, 9.312)
    """
    if distance_km <= 0 or target_distance_km <= 0:
        raise ValueError("Distances must be positive")
    if time_hours <= 0:
        raise ValueError("Time must be positive")
    if fatigue_factor <= 0:
        raise ValueError("Fatigue factor must be positive")

    predicted_time_hours = time_hours * (target_distance_km / distance_km) ** fatigue_factor
    pace_min_per_km = (predicted_time_hours * 60) / target_distance_km
    speed_kmh = target_distance_km / predicted_time_hours

    return (
        round(predicted_time_hours, 3),
        round(pace_min_per_km, 3),
        round(speed_kmh, 3)
    )


# ============ Performance Metrics ============

def vo2max(method, *, distance_m=None, time_min=None, heart_rate=None, age=None, weight_kg=None, sex=None, speed_kmh=None):
    """
    Calculate VO2max using different methods.

    Args:
        method (str): Calculation method - 'cooper', 'rockport', or 'speed'
        distance_m (float): Distance in metres (cooper method)
        time_min (float): Time in minutes (rockport method)
        heart_rate (int): Heart rate (rockport method)
        age (int): Age in years (rockport method)
        weight_kg (float): Weight in kg (rockport method)
        sex (int): Sex (1 for male, 0 for female) (rockport method)
        speed_kmh (float): Speed in km/h (speed method)

    Returns:
        float: VO2max value rounded to 3 decimals

    Example:
        >>> vo2max('cooper', distance_m=2800)
        51.3
    """
    if method == 'cooper':
        if distance_m is None:
            raise ValueError("Cooper method requires distance_m")
        if distance_m <= 0:
            raise ValueError("Distance must be positive")
        return round(((distance_m - 504.9) / 44.73), 3)

    elif method == 'rockport':
        required = [weight_kg, age, sex, time_min, heart_rate]
        if any(x is None for x in required):
            raise ValueError("Rockport method requires weight_kg, age, sex, time_min, heart_rate")
        if weight_kg <= 0:
            raise ValueError("Weight must be positive")
        if age <= 0:
            raise ValueError("Age must be positive")
        if time_min <= 0:
            raise ValueError("Time must be positive")
        if heart_rate <= 0:
            raise ValueError("Heart rate must be positive")
        return round((132.853
            - (0.0769 * weight_kg)
            - (0.3877 * age)
            + (6.315 * sex)
            - (3.2649 * time_min)
            - (0.1565 * heart_rate)
            ), 3)

    elif method == 'speed':
        if speed_kmh is None:
            raise ValueError("Speed method requires speed_kmh")
        if speed_kmh <= 0:
            raise ValueError("Speed must be positive")
        speed_m_min = speed_kmh * 1000 / 60
        return round((0.182258 * speed_m_min + 0.000104 * speed_m_min**2 + 3.5), 3)

    else:
        raise ValueError("Method must be 'cooper', 'rockport', or 'speed'")


def heart_rate_zones(method='hrmax', hr_max=None, hr_rest=None):
    """
    Calculate heart rate training zones.

    Args:
        method (str): Calculation method - 'hrmax' or 'karvonen'
        hr_max (int): Maximum heart rate in bpm
        hr_rest (int): Resting heart rate in bpm (required for karvonen method)

    Returns:
        dict: Heart rate zones with keys Z1-Z5, values as (lower, upper) tuples

    Example:
        >>> heart_rate_zones('hrmax', hr_max=190)
        {'Z1': (95.0, 114.0), 'Z2': (114.0, 133.0), ...}
    """
    if hr_max is None:
        raise ValueError("hr_max is required")
    if hr_max <= 0:
        raise ValueError("Maximum heart rate must be positive")

    if method == 'hrmax':
        return {
            "Z1": (0.50 * hr_max, 0.60 * hr_max),
            "Z2": (0.60 * hr_max, 0.70 * hr_max),
            "Z3": (0.70 * hr_max, 0.80 * hr_max),
            "Z4": (0.80 * hr_max, 0.90 * hr_max),
            "Z5": (0.90 * hr_max, hr_max),
        }

    elif method == 'karvonen':
        if hr_rest is None:
            raise ValueError("Karvonen method requires hr_rest")
        if hr_rest <= 0:
            raise ValueError("Resting heart rate must be positive")
        if hr_rest >= hr_max:
            raise ValueError("Resting heart rate must be less than maximum heart rate")

        hrr = hr_max - hr_rest

        return {
            "Z1": (hr_rest + 0.50 * hrr, hr_rest + 0.60 * hrr),
            "Z2": (hr_rest + 0.60 * hrr, hr_rest + 0.70 * hrr),
            "Z3": (hr_rest + 0.70 * hrr, hr_rest + 0.80 * hrr),
            "Z4": (hr_rest + 0.80 * hrr, hr_rest + 0.90 * hrr),
            "Z5": (hr_rest + 0.90 * hrr, hr_max),
        }

    else:
        raise ValueError("Method must be 'hrmax' or 'karvonen'")


def calories_keytel(
    hr_avg,
    duration_min,
    weight_kg,
    age,
    sex,
    vo2max=None,
    vo2max_ref=45,
    zone=None
):
    """
    Estimate calories burned using Keytel equations.

    Args:
        hr_avg (float): Average heart rate in bpm
        duration_min (float): Duration in minutes
        weight_kg (float): Body weight in kg
        age (int): Age in years
        sex (str): 'male' or 'female'
        vo2max (float): Optional VO2max (ml/kg/min) for efficiency adjustment
        vo2max_ref (float): Reference VO2max for neutral efficiency (default: 45)
        zone (str): Optional training zone ('Z1', 'Z2', 'Z3', 'Z4', 'Z5') for intensity adjustment

    Returns:
        float: Total calories burned

    Example:
        >>> calories_keytel(150, 45, 70, 30, 'male')
        450.5
    """
    if hr_avg <= 0:
        raise ValueError("Heart rate must be positive")
    if duration_min <= 0:
        raise ValueError("Duration must be positive")
    if weight_kg <= 0:
        raise ValueError("Weight must be positive")
    if age <= 0:
        raise ValueError("Age must be positive")

    # Zone multipliers for intensity adjustment
    ZONE_MULTIPLIERS = {
        "Z1": 0.95,
        "Z2": 1.00,
        "Z3": 1.03,
        "Z4": 1.06,
        "Z5": 1.10,
    }

    if sex == "male":
        kcal_min = (
            -55.0969
            + (0.6309 * hr_avg)
            + (0.1988 * weight_kg)
            + (0.2017 * age)
        ) / 4.184
    elif sex == "female":
        kcal_min = (
            -20.4022
            + (0.4472 * hr_avg)
            - (0.1263 * weight_kg)
            + (0.074 * age)
        ) / 4.184
    else:
        raise ValueError("sex must be 'male' or 'female'")

    # VO2max efficiency adjustment
    if vo2max is not None:
        if vo2max <= 0:
            raise ValueError("VO2max must be positive")
        if vo2max_ref <= 0:
            raise ValueError("VO2max reference must be positive")
        efficiency_factor = vo2max_ref / vo2max
        kcal_min *= efficiency_factor

    # Zone intensity adjustment
    if zone is not None:
        if zone not in ZONE_MULTIPLIERS:
            raise ValueError(f"zone must be one of: {list(ZONE_MULTIPLIERS.keys())}")
        kcal_min *= ZONE_MULTIPLIERS[zone]

    return kcal_min * duration_min


# ============ Time Conversions ============

def time_to_decimal(hours=0, minutes=0, seconds=0, unit='hours'):
    """
    Convert HH:MM:SS time to decimal format.

    Args:
        hours (int): Hours component (default: 0)
        minutes (int): Minutes component (default: 0)
        seconds (int): Seconds component (default: 0)
        unit (str): Output unit - 'hours', 'minutes', or 'seconds' (default: 'hours')

    Returns:
        float: Time in decimal format in specified unit

    Example:
        >>> time_to_decimal(1, 30, 0, 'hours')
        1.5
        >>> time_to_decimal(0, 90, 0, 'minutes')
        90.0
    """
    if hours < 0 or minutes < 0 or seconds < 0:
        raise ValueError("Time components cannot be negative")

    total_seconds = hours * 3600 + minutes * 60 + seconds

    conversions = {
        'hours': total_seconds / 3600,
        'minutes': total_seconds / 60,
        'seconds': total_seconds
    }

    if unit not in conversions:
        raise ValueError(f"Unit must be one of: {list(conversions.keys())}")

    return conversions[unit]


def decimal_to_time(decimal_value, unit='hours'):
    """
    Convert decimal time to HH:MM:SS format.

    Args:
        decimal_value (float): Decimal time value
        unit (str): Input unit - 'hours', 'minutes', or 'seconds' (default: 'hours')

    Returns:
        str: Time in HH:MM:SS format

    Example:
        >>> decimal_to_time(1.5, 'hours')
        '01:30:00'
        >>> decimal_to_time(90, 'minutes')
        '01:30:00'
    """
    if decimal_value < 0:
        raise ValueError("Time cannot be negative")

    # Convert everything to total seconds first
    to_seconds = {
        'hours': 3600,
        'minutes': 60,
        'seconds': 1
    }

    if unit not in to_seconds:
        raise ValueError(f"Unit must be one of: {list(to_seconds.keys())}")

    total_seconds = decimal_value * to_seconds[unit]

    hours = int(total_seconds // 3600)
    minutes = int((total_seconds % 3600) // 60)
    seconds = int(total_seconds % 60)

    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"