"""Verified Local MCP Proxy - Secure proxy for verified local MCP servers."""

__version__ = "0.1.0"
