"""Shared fixtures and utilities for sync Devbox tests.

This module contains fixtures and helpers specific to sync devbox testing
that are shared across multiple test modules in this directory.
"""
# Currently minimal - add shared helpers if patterns emerge
