#!/usr/bin/env bash
#
# runsim.sh -- Unified CLI for reservoir simulators and PET examples
#
# Usage:
#   ./runsim.sh flow [flow-args...]              # Run native OPM Flow (passthrough)
#   ./runsim.sh flow-docker [flow-args...]        # Run OPM Flow via Docker (passthrough)
#   ./runsim.sh jutuldarcy [args...]              # Run JutulDarcy simulation
#   ./runsim.sh dumux [args...]                   # Run DuMux simulation
#   ./runsim.sh dumux-docker [args...]            # Run DuMux via Docker
#   ./runsim.sh pet [options] <example>           # Run PET example (DA/optimization)
#   ./runsim.sh setup                             # Bootstrap environment
#   ./runsim.sh help                              # Show this help
#
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${SCRIPT_DIR}/simulators/common.sh"

SIMULATORS_DIR="${SCRIPT_DIR}/simulators"

# ── Help ─────────────────────────────────────────────────────────────
usage() {
    cat <<EOF
Usage: $(basename "$0") <command> [args...]

Commands:
  flow [flow-args...]           Run native OPM Flow (passthrough to binary)
  flow-docker [flow-args...]    Run OPM Flow via Docker (passthrough)
  jutuldarcy [args...]          Run JutulDarcy simulation
  dumux [args...]               Run DuMux simulation
  dumux-docker [args...]        Run DuMux via Docker
  pet [options] <example>       Run PET example (data assimilation / optimization)
  setup                         Bootstrap environment (venv, PET, Docker)
  help                          Show this help

Examples:
  $(basename "$0") flow --version
  $(basename "$0") flow --output-dir=./out SPE1CASE1.DATA
  $(basename "$0") flow-docker --output-dir=./out SPE1CASE1.DATA
  $(basename "$0") pet --list
  $(basename "$0") pet 3dBox/tiny
  $(basename "$0") pet 3dBox/tiny --simulator flow-docker
  $(basename "$0") setup
EOF
}

# ── Flow (native) ───────────────────────────────────────────────────
cmd_flow() {
    local flow_bin=""

    # 1. Check opm-build location
    local build_bin="${PROJECT_ROOT}/opm-build/opm-install/bin/flow"
    if [ -x "$build_bin" ]; then
        flow_bin="$build_bin"
    fi

    # 2. Check venv wrapper (only if it's not the docker wrapper)
    if [ -z "$flow_bin" ]; then
        local venv_bin="${VENV_DIR}/bin/flow"
        if [ -x "$venv_bin" ] && ! grep -q "docker" "$venv_bin" 2>/dev/null; then
            flow_bin="$venv_bin"
        fi
    fi

    # 3. Check system PATH
    if [ -z "$flow_bin" ]; then
        flow_bin=$(command -v flow 2>/dev/null || true)
    fi

    if [ -z "$flow_bin" ]; then
        err "Native flow binary not found."
        err "Install with: ./simulators/opm/install.sh"
        exit 1
    fi

    exec "$flow_bin" "$@"
}

# ── Flow (Docker) ───────────────────────────────────────────────────
cmd_flow_docker() {
    local wrapper="${VENV_DIR}/bin/flow-docker"

    if [ ! -x "$wrapper" ]; then
        err "flow-docker wrapper not found."
        err "Run: ./runsim.sh setup  or  ./simulators/opm/install-docker.sh"
        exit 1
    fi

    exec "$wrapper" "$@"
}

# ── JutulDarcy ──────────────────────────────────────────────────────
cmd_jutuldarcy() {
    exec bash "${SIMULATORS_DIR}/jutuldarcy/run.sh" "$@"
}

# ── DuMux (native) ─────────────────────────────────────────────────
cmd_dumux() {
    exec bash "${SIMULATORS_DIR}/dumux/run.sh" "$@"
}

# ── DuMux (Docker) ─────────────────────────────────────────────────
cmd_dumux_docker() {
    err "dumux-docker is not yet implemented."
    err "See simulators/dumux/Dockerfile for manual Docker usage."
    exit 1
}

# ── PET ─────────────────────────────────────────────────────────────
cmd_pet() {
    exec bash "${SIMULATORS_DIR}/pet/run.sh" "$@"
}

# ── Setup ───────────────────────────────────────────────────────────
cmd_setup() {
    exec bash "${SIMULATORS_DIR}/setup_env.sh" "$@"
}

# ── Dispatch ────────────────────────────────────────────────────────
CMD="${1:-help}"
case "$CMD" in
    flow)         shift; cmd_flow "$@" ;;
    flow-docker)  shift; cmd_flow_docker "$@" ;;
    jutuldarcy)   shift; cmd_jutuldarcy "$@" ;;
    dumux)        shift; cmd_dumux "$@" ;;
    dumux-docker) shift; cmd_dumux_docker "$@" ;;
    pet)          shift; cmd_pet "$@" ;;
    setup)        shift; cmd_setup "$@" ;;
    help|--help|-h) usage ;;
    *)
        err "Unknown command: $CMD"
        echo ""
        usage
        exit 1
        ;;
esac
