"""runsim -- Unified interface for running reservoir simulators."""

from runsim.base import Simulator
from runsim.dumux import DuMux
from runsim.opm import OPMFlow

__version__ = "0.1.0"
__all__ = ["Simulator", "OPMFlow", "DuMux"]
