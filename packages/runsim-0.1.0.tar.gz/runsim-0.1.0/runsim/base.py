"""Abstract base class for reservoir simulators."""

from __future__ import annotations

import shutil
import subprocess
from abc import ABC, abstractmethod
from pathlib import Path


class Simulator(ABC):
    """Base class for all simulator wrappers.

    Subclasses must implement `_find_executable` and `run`.
    """

    def __init__(self, name: str, executable: str | None = None):
        self.name = name
        if executable is not None:
            self.executable = Path(executable)
        else:
            self.executable = self._find_executable()

    @abstractmethod
    def _find_executable(self) -> Path:
        """Locate the simulator binary on this system."""
        ...

    @abstractmethod
    def run(
        self,
        deck_file: str | Path,
        output_dir: str | Path,
        **kwargs,
    ) -> subprocess.CompletedProcess:
        """Run a simulation and return the completed process."""
        ...

    def version(self) -> str:
        """Return the simulator version string."""
        if not self.is_available():
            return "not installed"
        try:
            result = subprocess.run(
                [str(self.executable), "--version"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            output = result.stdout.strip() or result.stderr.strip()
            return output.split("\n")[0] if output else "unknown"
        except (subprocess.TimeoutExpired, OSError):
            return "unknown"

    def is_available(self) -> bool:
        """Check if the simulator binary exists and is executable."""
        return self.executable is not None and self.executable.is_file()

    def __repr__(self) -> str:
        return f"{type(self).__name__}(executable={self.executable!r})"


def find_in_paths(*candidates: str | Path) -> Path | None:
    """Return the first existing executable from a list of candidate paths."""
    for p in candidates:
        path = Path(p)
        if path.is_file():
            return path
    # Fall back to PATH lookup
    return None


def find_on_path(name: str) -> Path | None:
    """Find an executable on the system PATH."""
    found = shutil.which(name)
    return Path(found) if found else None
