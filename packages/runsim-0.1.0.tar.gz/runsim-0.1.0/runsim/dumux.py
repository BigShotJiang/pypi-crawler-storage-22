"""DuMux porous media simulator wrapper (stub)."""

from __future__ import annotations

import subprocess
from pathlib import Path

from runsim.base import Simulator


class DuMux(Simulator):
    """Run DuMux simulations.

    This is a stub -- DuMux executables are problem-specific (each example
    compiles to its own binary). Full integration will be added when
    standard DuMux workflows are established.

    Usage:
        sim = DuMux(executable="/path/to/dumux_example")
        result = sim.run(input_file="params.input", output_dir="./output")
    """

    def __init__(self, executable: str | None = None):
        super().__init__(name="dumux", executable=executable)

    def _find_executable(self) -> Path:
        """Search for a DuMux binary in common locations."""
        pkg_dir = Path(__file__).resolve().parent  # runsim/ (package)
        project_root = pkg_dir.parent.parent  # opm/
        install_dir = project_root / "dumux-build" / "dumux-install"

        # DuMux doesn't have a single binary -- check install dir exists
        if install_dir.is_dir():
            # Return the install bin directory as a marker
            bin_dir = install_dir / "bin"
            if bin_dir.is_dir():
                # Return first executable found, if any
                for f in sorted(bin_dir.iterdir()):
                    if f.is_file() and f.stat().st_mode & 0o111:
                        return f
        return Path("dumux")  # placeholder

    def run(
        self,
        deck_file: str | Path = "",
        output_dir: str | Path = ".",
        **kwargs,
    ) -> subprocess.CompletedProcess:
        """Run a DuMux simulation.

        Args:
            deck_file: Path to input file (DuMux uses .input parameter files).
            output_dir: Directory for simulation output.
            **kwargs: Additional parameters.

        Returns:
            subprocess.CompletedProcess with stdout/stderr.
        """
        output_dir = Path(output_dir).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

        cmd = [str(self.executable)]

        if deck_file:
            cmd.append(str(Path(deck_file).resolve()))

        for key, value in kwargs.items():
            cmd.append(f"-{key}")
            cmd.append(str(value))

        return subprocess.run(cmd, capture_output=True, text=True, cwd=output_dir)
