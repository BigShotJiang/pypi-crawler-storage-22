"""OPM Flow reservoir simulator wrapper."""

from __future__ import annotations

import subprocess
from pathlib import Path

from runsim.base import Simulator, find_in_paths, find_on_path


class OPMFlow(Simulator):
    """Run OPM Flow simulations (native or Docker).

    Usage:
        sim = OPMFlow()                         # auto-detect executable
        sim = OPMFlow(mode="docker")            # use Docker wrapper
        sim = OPMFlow(executable="/path/to/flow")  # explicit path

        result = sim.run("SPE1CASE1.DATA", output_dir="./output")
    """

    def __init__(
        self,
        mode: str = "native",
        executable: str | None = None,
    ):
        self.mode = mode  # "native" or "docker"
        super().__init__(name="opm-flow", executable=executable)

    def _find_executable(self) -> Path:
        """Search for the flow binary in common locations."""
        # Determine project paths relative to this file
        pkg_dir = Path(__file__).resolve().parent  # runsim/ (package)
        project_dir = pkg_dir.parent  # runsim/ (project root)
        project_root = project_dir.parent  # opm/
        venv_dir = project_dir / ".venv"

        if self.mode == "docker":
            candidates = [
                venv_dir / "bin" / "flow-docker",
            ]
        else:
            candidates = [
                venv_dir / "bin" / "flow",
                project_root / "opm-build" / "opm-install" / "bin" / "flow",
            ]

        found = find_in_paths(*candidates)
        if found is not None:
            return found

        # Try system PATH
        binary_name = "flow-docker" if self.mode == "docker" else "flow"
        on_path = find_on_path(binary_name)
        if on_path is not None:
            return on_path

        # Return the most likely path even if it doesn't exist yet
        return candidates[0] if candidates else Path("flow")

    def run(
        self,
        deck_file: str | Path,
        output_dir: str | Path,
        **kwargs,
    ) -> subprocess.CompletedProcess:
        """Run an OPM Flow simulation.

        Args:
            deck_file: Path to the .DATA deck file.
            output_dir: Directory for simulation output.
            **kwargs: Additional flags passed as --key=value.

        Returns:
            subprocess.CompletedProcess with stdout/stderr.
        """
        deck_file = Path(deck_file).resolve()
        output_dir = Path(output_dir).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

        cmd = [
            str(self.executable),
            f"--output-dir={output_dir}",
        ]

        # Add extra keyword arguments as --key=value flags
        for key, value in kwargs.items():
            flag = key.replace("_", "-")
            cmd.append(f"--{flag}={value}")

        cmd.append(str(deck_file))

        return subprocess.run(cmd, capture_output=True, text=True)
