#!/usr/bin/env bash
#
# common.sh -- Shared helpers and path resolution for all simulator scripts
#
# Source this file at the top of every script:
#   From simulators/:   source "$(cd "$(dirname "$0")" && pwd)/common.sh"
#   From simulators/X/: source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"
#
# Provides:
#   SIMULATORS_DIR  -- absolute path to simulators/
#   PROJECT_DIR     -- absolute path to runsim/
#   PROJECT_ROOT    -- absolute path to opm/ (parent of runsim)
#   VENV_DIR        -- absolute path to runsim/.venv/
#   PYTHON          -- path to venv Python
#   PIP             -- path to venv pip
#   info(), ok(), warn(), err() -- colored output helpers

SIMULATORS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SIMULATORS_DIR")"
PROJECT_ROOT="$(dirname "$PROJECT_DIR")"
VENV_DIR="${PROJECT_DIR}/.venv"
PYTHON="${VENV_DIR}/bin/python"
PIP="${VENV_DIR}/bin/pip"

info()  { printf "\033[1;34m[INFO]\033[0m  %s\n" "$*"; }
ok()    { printf "\033[1;32m[OK]\033[0m    %s\n" "$*"; }
warn()  { printf "\033[1;33m[WARN]\033[0m  %s\n" "$*"; }
err()   { printf "\033[1;31m[ERROR]\033[0m %s\n" "$*" >&2; }
