# DuMux

DuMux (DUNE for Multi-{Phase, Component, Scale, Physics, ...}) -- open-source simulator for flow and transport processes in porous media, built on the DUNE framework.

## Links

- [DuMux (main)](https://dumux.org/)
- [Documentation](https://dumux.org/docs/doxygen/master/index.html)
- [Installation guide](https://dumux.org/docs/doxygen/master/installation.html)
- [Examples](https://git.iws.uni-stuttgart.de/dumux-repositories/dumux/-/blob/master/examples/README.md)
- [Gallery](https://dumux.org/gallery/)
- [Docker template (main repo)](https://git.iws.uni-stuttgart.de/dumux-repositories/dumux/-/tree/master/docker)
- [Docker CI images](https://git.iws.uni-stuttgart.de/dumux-repositories/dumux-docker-ci)
- [Docker Hub](https://hub.docker.com/u/dumux) (stale -- last updated Nov 2020)

## Installation

Builds Dune 2.10 (shared with OPM if available) + DuMux from source.

```bash
./install.sh                     # Full build (skips if already installed)
./install.sh --deps-only         # Homebrew + Dune only
./install.sh --rebuild           # Force full rebuild
./install.sh --test              # Build + run test example
```

Requires: Xcode CLI tools, Homebrew, cmake, boost, suite-sparse, pkg-config.

If OPM has already been built (`opm-build/dune-install/`), DuMux will reuse the existing Dune installation and only build `dune-localfunctions` (the extra module DuMux needs).

## Running simulations

```bash
./run.sh                         # Run test example to verify installation
```

## Docker

Our Dockerfile is adapted from the official DuMux Docker setup (see [docker template](https://git.iws.uni-stuttgart.de/dumux-repositories/dumux/-/tree/master/docker) and [CI images](https://git.iws.uni-stuttgart.de/dumux-repositories/dumux-docker-ci)). It builds Dune + DuMux from source using `dunecontrol`.

```bash
docker build -t dumux .
docker build --build-arg DUMUX_BRANCH=releases/3.10 -t dumux:3.10 .
docker run -it --rm -v $(pwd):/dumux/shared dumux
```
