#!/usr/bin/env bash
#
# install.sh -- Build DuMux from source on macOS
#
# Builds Dune 2.10 (shared with OPM if available) + dune-localfunctions + DuMux.
# DuMux is a DUNE-based simulator for flow and transport in porous media.
#
# Usage:
#   ./simulators/dumux/install.sh                    # Full build (skips if already installed)
#   ./simulators/dumux/install.sh --deps-only        # Install Homebrew deps + Dune only
#   ./simulators/dumux/install.sh --test             # Build + run test example
#   ./simulators/dumux/install.sh --rebuild          # Force full rebuild from scratch
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

BUILD_DIR="${PROJECT_ROOT}/dumux-build"
OPM_BUILD_DIR="${PROJECT_ROOT}/opm-build"
NPROC=$(sysctl -n hw.ncpu 2>/dev/null || echo 4)

DEPS_ONLY=false
RUN_TEST=false
REBUILD=false

# ── Parse arguments ──────────────────────────────────────────────────
while [ $# -gt 0 ]; do
    case "$1" in
        --deps-only) DEPS_ONLY=true; shift ;;
        --test)      RUN_TEST=true; shift ;;
        --rebuild)   REBUILD=true; shift ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --deps-only      Install Homebrew deps + Dune only (no DuMux)"
            echo "  --test           Build + run test example"
            echo "  --rebuild        Force full rebuild (removes existing build artifacts)"
            exit 0
            ;;
        *) shift ;;
    esac
done

# ── Pre-flight ─────────────────────────────────────────────────────────
info "━━━ DuMux Build (macOS) ━━━"

# Check if already installed (skip unless --rebuild)
DUMUX_INSTALL="${BUILD_DIR}/dumux-install"
if [ "$REBUILD" = false ] && [ "$DEPS_ONLY" = false ] && [ -d "$DUMUX_INSTALL" ]; then
    ok "DuMux already installed at $DUMUX_INSTALL"
    info "Use --rebuild to force a full rebuild."

    if [ "$RUN_TEST" = true ]; then
        echo ""
        info "━━━ Running test example ━━━"
        # Run a simple test if available
        TEST_BIN=$(find "$DUMUX_INSTALL/bin" -name "test_*" -type f 2>/dev/null | head -1)
        if [ -n "$TEST_BIN" ] && [ -x "$TEST_BIN" ]; then
            info "Running: $(basename "$TEST_BIN")"
            "$TEST_BIN" && ok "Test passed." || err "Test failed."
        else
            info "No test binaries found. DuMux is installed but no test examples were built."
        fi
    fi
    exit 0
fi

# If --rebuild, clean existing build artifacts
if [ "$REBUILD" = true ] && [ -d "$BUILD_DIR" ]; then
    warn "Removing existing DuMux build artifacts for rebuild..."
    rm -rf "${BUILD_DIR}/dumux/build"
    rm -rf "$DUMUX_INSTALL"
    ok "Build artifacts cleaned."
fi

# Check Xcode CLI tools
if ! xcode-select -p &>/dev/null; then
    err "Xcode command line tools not installed."
    info "Run: xcode-select --install"
    exit 1
fi
ok "Xcode CLI tools found."

# Check Homebrew
if ! command -v brew &>/dev/null; then
    err "Homebrew not installed."
    info "Install from: https://brew.sh"
    exit 1
fi
ok "Homebrew found."

# ── Step 1: Homebrew dependencies ────────────────────────────────────
info "━━━ Step 1: Homebrew packages ━━━"

BREW_DEPS=(cmake pkg-config doxygen boost suite-sparse)
MISSING=()
for pkg in "${BREW_DEPS[@]}"; do
    if ! brew list "$pkg" &>/dev/null; then
        MISSING+=("$pkg")
    fi
done

if [ ${#MISSING[@]} -gt 0 ]; then
    info "Installing: ${MISSING[*]}"
    brew install "${MISSING[@]}"
    ok "Packages installed."
else
    ok "All Homebrew packages already installed."
fi

# ── Step 2: Build Dune 2.10 ─────────────────────────────────────────
info "━━━ Step 2: Dune 2.10 ━━━"

# Check if OPM already built Dune -- reuse if available
OPM_DUNE_PREFIX="${OPM_BUILD_DIR}/dune-install"
if [ -d "$OPM_DUNE_PREFIX" ] && \
   [ -f "${OPM_DUNE_PREFIX}/lib/cmake/dune-common/dune-common-config.cmake" -o \
     -f "${OPM_DUNE_PREFIX}/lib64/cmake/dune-common/dune-common-config.cmake" ]; then
    DUNE_PREFIX="$OPM_DUNE_PREFIX"
    ok "Reusing OPM's Dune installation at $DUNE_PREFIX"
else
    DUNE_PREFIX="${BUILD_DIR}/dune-install"
    info "Building Dune from scratch (OPM's Dune not found)."
fi

mkdir -p "$BUILD_DIR" "$DUNE_PREFIX"

# DuMux needs the 4 core Dune modules + dune-localfunctions
DUNE_MODULES=(dune-common dune-geometry dune-grid dune-istl dune-localfunctions)
DUNE_BRANCH="releases/2.10"

for mod in "${DUNE_MODULES[@]}"; do
    SRC="${BUILD_DIR}/${mod}"

    if [ -f "${DUNE_PREFIX}/lib/cmake/${mod}/${mod}-config.cmake" ] || \
       [ -f "${DUNE_PREFIX}/lib64/cmake/${mod}/${mod}-config.cmake" ]; then
        ok "$mod already installed."
        continue
    fi

    if [ ! -d "$SRC" ]; then
        info "Cloning $mod ($DUNE_BRANCH)..."
        git clone --branch "$DUNE_BRANCH" --depth 1 \
            "https://gitlab.dune-project.org/core/${mod}.git" "$SRC"
    fi

    info "Building $mod (using $NPROC cores)..."
    mkdir -p "$SRC/build"
    if ! cmake -S "$SRC" -B "$SRC/build" \
        -DCMAKE_PREFIX_PATH="$DUNE_PREFIX" \
        -DCMAKE_INSTALL_PREFIX="$DUNE_PREFIX" \
        -DCMAKE_BUILD_TYPE=Release; then
        err "cmake configure failed for $mod"; exit 1
    fi
    if ! cmake --build "$SRC/build" -j "$NPROC"; then
        err "cmake build failed for $mod"; exit 1
    fi
    if ! cmake --install "$SRC/build"; then
        err "cmake install failed for $mod"; exit 1
    fi
    ok "$mod installed."
done

if [ "$DEPS_ONLY" = true ]; then
    ok "Dependencies installed. Exiting (--deps-only)."
    exit 0
fi

# ── Step 3: Build DuMux ─────────────────────────────────────────────
info "━━━ Step 3: DuMux ━━━"

DUMUX_SRC="${BUILD_DIR}/dumux"
DUMUX_BRANCH="releases/3.10"

if [ ! -d "$DUMUX_SRC" ]; then
    info "Cloning DuMux ($DUMUX_BRANCH)..."
    git clone --branch "$DUMUX_BRANCH" --depth 1 \
        "https://git.iws.uni-stuttgart.de/dumux-repositories/dumux.git" "$DUMUX_SRC"
fi

info "Building DuMux (using $NPROC cores)..."
mkdir -p "$DUMUX_SRC/build"
if ! cmake -S "$DUMUX_SRC" -B "$DUMUX_SRC/build" \
    -DCMAKE_PREFIX_PATH="$DUNE_PREFIX" \
    -DCMAKE_INSTALL_PREFIX="$DUMUX_INSTALL" \
    -DCMAKE_BUILD_TYPE=Release; then
    err "cmake configure failed for DuMux"; exit 1
fi
if ! cmake --build "$DUMUX_SRC/build" -j "$NPROC"; then
    err "cmake build failed for DuMux"; exit 1
fi
if ! cmake --install "$DUMUX_SRC/build"; then
    err "cmake install failed for DuMux"; exit 1
fi
ok "DuMux installed."

# ── Optional test ────────────────────────────────────────────────────
if [ "$RUN_TEST" = true ]; then
    echo ""
    info "━━━ Running test example ━━━"
    TEST_BIN=$(find "$DUMUX_INSTALL/bin" -name "test_*" -type f 2>/dev/null | head -1)
    if [ -n "$TEST_BIN" ] && [ -x "$TEST_BIN" ]; then
        info "Running: $(basename "$TEST_BIN")"
        "$TEST_BIN" && ok "Test passed." || err "Test failed."
    else
        info "No test binaries found. Try building examples separately."
        info "See: https://git.iws.uni-stuttgart.de/dumux-repositories/dumux/-/blob/master/examples/README.md"
    fi
fi

echo ""
ok "DuMux build complete."
info "Install directory: $DUMUX_INSTALL"
info "Dune prefix: $DUNE_PREFIX"
info "Build directory: $BUILD_DIR"
