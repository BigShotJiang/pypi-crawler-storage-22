#!/usr/bin/env bash
#
# run.sh -- Run DuMux simulations
#
# Usage:
#   ./simulators/dumux/run.sh              # Verify installation
#   ./simulators/dumux/run.sh /path/to/exe # Run a specific DuMux executable
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

BUILD_DIR="${PROJECT_ROOT}/dumux-build"
DUMUX_INSTALL="${BUILD_DIR}/dumux-install"

# ── Pre-flight ────────────────────────────────────────────────────────
info "━━━ DuMux Runner ━━━"

if [ ! -d "$DUMUX_INSTALL" ]; then
    err "DuMux not installed. Run ./simulators/dumux/install.sh first."
    exit 1
fi
ok "DuMux installation found at $DUMUX_INSTALL"

if [ $# -ge 1 ]; then
    # Run a specific executable
    EXEC="$1"
    shift
    if [ ! -x "$EXEC" ]; then
        err "Executable not found or not executable: $EXEC"
        exit 1
    fi
    info "Running: $EXEC $*"
    exec "$EXEC" "$@"
else
    # Verify installation by listing available executables
    info "Available DuMux executables:"
    FOUND=0
    if [ -d "$DUMUX_INSTALL/bin" ]; then
        for exe in "$DUMUX_INSTALL/bin"/*; do
            if [ -x "$exe" ] && [ -f "$exe" ]; then
                echo "  $(basename "$exe")"
                FOUND=$((FOUND + 1))
            fi
        done
    fi

    if [ "$FOUND" -eq 0 ]; then
        warn "No executables found in $DUMUX_INSTALL/bin/"
        info "DuMux examples must be built separately."
        info "See: https://git.iws.uni-stuttgart.de/dumux-repositories/dumux/-/blob/master/examples/README.md"
    else
        ok "Found $FOUND executable(s)."
        info "Run a specific one with: $0 $DUMUX_INSTALL/bin/<executable>"
    fi
fi
