# JutulDarcy

JutulDarcy.jl -- fully differentiable reservoir simulator written in Julia. Supports automatic differentiation for gradient-based optimization and history matching workflows.

## Links

- [JutulDarcy.jl (GitHub)](https://github.com/sintefmath/JutulDarcy.jl)
- [PyJutulDarcy (PyPI)](https://pypi.org/project/jutuldarcy/)
- [Documentation](https://sintefmath.github.io/JutulDarcy.jl/stable/)
- [Paper (DOI)](https://doi.org/10.1007/s10596-025-10366-6)

## Installation

Two modes available:

```bash
./install.sh                     # Python mode (recommended, pip install jutuldarcy)
./install.sh --julia             # Julia mode (JutulDarcy.jl + juliacall)
./install.sh --both              # Both modes
./install.sh --test              # Install + verify
./install.sh --rebuild           # Force reinstall
```

**Python mode** uses `jutuldarcy` pip package (PyJutulDarcy) -- simplest setup.
**Julia mode** installs Julia + JutulDarcy.jl + juliacall bridge -- full native performance.

## Running simulations

```bash
./run.sh --test                                              # Quick SPE1 test
./run.sh /path/to/DECK.DATA                                  # Run custom deck
./run.sh --platform Julia /path/to/DECK.DATA                 # Use Julia backend
```

## Usage in SimulatorWrap

```python
# Python mode (default)
from subsurface.multphaseflow.jutuldarcy import jutuldarcy
sim = jutuldarcy(input_dict=..., platform='Python')

# Julia mode
sim = jutuldarcy(input_dict=..., platform='Julia')
```
