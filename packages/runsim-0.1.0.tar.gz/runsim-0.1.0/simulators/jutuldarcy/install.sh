#!/usr/bin/env bash
#
# install.sh -- Install JutulDarcy reservoir simulator
#
# JutulDarcy.jl is a fully differentiable reservoir simulator written in Julia.
# SimulatorWrap supports two modes:
#   - Python mode: uses the 'jutuldarcy' pip package (PyJutulDarcy)
#   - Julia mode:  uses juliacall + native Julia packages
#
# Usage:
#   ./simulators/jutuldarcy/install.sh              # Install Python mode (recommended)
#   ./simulators/jutuldarcy/install.sh --julia      # Install Julia mode (native)
#   ./simulators/jutuldarcy/install.sh --both       # Install both modes
#   ./simulators/jutuldarcy/install.sh --test       # Install + run import test
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

MODE="python"   # default: Python mode
RUN_TEST=false
REBUILD=false

# ── Parse arguments ──────────────────────────────────────────────────
for arg in "$@"; do
    case "$arg" in
        --julia)   MODE="julia" ;;
        --both)    MODE="both" ;;
        --test)    RUN_TEST=true ;;
        --rebuild) REBUILD=true ;;
        --help|-h)
            echo "Usage: $0 [--julia|--both] [--test] [--rebuild]"
            echo ""
            echo "Modes:"
            echo "  (default)   Python mode -- pip install jutuldarcy (PyJutulDarcy)"
            echo "  --julia     Julia mode  -- install Julia + JutulDarcy.jl + juliacall"
            echo "  --both      Install both Python and Julia modes"
            echo ""
            echo "Options:"
            echo "  --test      Run a quick import test after installation"
            echo "  --rebuild   Force reinstall even if already present"
            exit 0
            ;;
    esac
done

# ── Pre-flight ─────────────────────────────────────────────────────────
info "━━━ JutulDarcy Installation ━━━"

if [ ! -d "$VENV_DIR" ] || [ ! -f "$PYTHON" ]; then
    err "Virtual environment not found at $VENV_DIR"
    err "Run simulators/setup_env.sh first to create it."
    exit 1
fi
ok "Virtual environment found."

# ── Python mode: pip install jutuldarcy ──────────────────────────────
install_python_mode() {
    info "━━━ Python mode (PyJutulDarcy) ━━━"

    if [ "$REBUILD" = false ] && "$PYTHON" -c "import jutuldarcy" 2>/dev/null; then
        ok "jutuldarcy already installed."
        VERSION=$("$PYTHON" -c "import jutuldarcy; print(getattr(jutuldarcy, '__version__', 'unknown'))" 2>/dev/null)
        ok "Version: $VERSION"
        info "Use --rebuild to force reinstall."
        return 0
    fi

    if [ "$REBUILD" = true ]; then
        info "Reinstalling jutuldarcy via pip (--rebuild)..."
        "$PIP" install --force-reinstall jutuldarcy -q 2>&1 | tail -3
    else
        info "Installing jutuldarcy via pip..."
        "$PIP" install jutuldarcy -q 2>&1 | tail -3
    fi
    if "$PYTHON" -c "import jutuldarcy" 2>/dev/null; then
        ok "jutuldarcy installed successfully."
    else
        err "jutuldarcy installation failed."
        info "Try manually: $PIP install jutuldarcy"
        info "Or check: https://github.com/sintefmath/PyJutulDarcy"
        return 1
    fi
}

# ── Julia mode: install Julia + JutulDarcy.jl + juliacall ────────────
install_julia_mode() {
    info "━━━ Julia mode (native JutulDarcy.jl) ━━━"

    # Quick check if already fully installed
    if [ "$REBUILD" = false ] && command -v julia &>/dev/null && \
       "$PYTHON" -c "import juliacall" 2>/dev/null && \
       julia -e 'using Pkg; haskey(Pkg.project().dependencies, "JutulDarcy") || exit(1)' 2>/dev/null; then
        JULIA_VER=$(julia --version 2>&1)
        ok "Julia mode already installed ($JULIA_VER + JutulDarcy.jl + juliacall)."
        info "Use --rebuild to force reinstall."
        return 0
    fi

    # Check/install Julia
    if command -v julia &>/dev/null; then
        JULIA_VER=$(julia --version 2>&1)
        ok "Julia found: $JULIA_VER"
    else
        info "Julia not found. Checking for juliaup..."

        if command -v juliaup &>/dev/null; then
            ok "juliaup found."
        elif command -v brew &>/dev/null; then
            info "Installing juliaup via Homebrew..."
            brew install juliaup
        else
            info "Installing juliaup..."
            curl -fsSL https://install.julialang.org | sh -s -- -y
            export PATH="$HOME/.juliaup/bin:$PATH"
        fi

        if command -v juliaup &>/dev/null; then
            info "Installing latest Julia via juliaup..."
            juliaup install release
            juliaup default release
        fi

        if ! command -v julia &>/dev/null; then
            err "Julia installation failed."
            info "Install manually from: https://julialang.org/downloads/"
            return 1
        fi
        ok "Julia installed: $(julia --version 2>&1)"
    fi

    # Install JutulDarcy.jl + Jutul.jl
    info "Installing JutulDarcy.jl and Jutul.jl (this may take several minutes on first run)..."
    julia -e '
        using Pkg
        installed = keys(Pkg.project().dependencies)
        need = String[]
        "JutulDarcy" in installed || push!(need, "JutulDarcy")
        "Jutul"      in installed || push!(need, "Jutul")
        if !isempty(need)
            Pkg.add(need)
            println("Installed: ", join(need, ", "))
        else
            println("JutulDarcy and Jutul already installed.")
        end
        # Precompile
        using JutulDarcy, Jutul
        println("Precompilation complete.")
    '
    if [ $? -eq 0 ]; then
        ok "JutulDarcy.jl installed and precompiled."
    else
        err "JutulDarcy.jl installation failed."
        return 1
    fi

    # Install juliacall Python package
    info "Installing juliacall Python bridge..."
    if "$PYTHON" -c "import juliacall" 2>/dev/null; then
        ok "juliacall already installed."
    else
        "$PIP" install juliacall -q 2>&1 | tail -3
        if "$PYTHON" -c "import juliacall" 2>/dev/null; then
            ok "juliacall installed."
        else
            err "juliacall installation failed."
            info "Try manually: $PIP install juliacall"
            return 1
        fi
    fi
}

# ── Run installations ────────────────────────────────────────────────
case "$MODE" in
    python) install_python_mode ;;
    julia)  install_julia_mode ;;
    both)
        install_python_mode
        echo ""
        install_julia_mode
        ;;
esac

# ── Optional test ────────────────────────────────────────────────────
if [ "$RUN_TEST" = true ]; then
    echo ""
    info "━━━ Verification ━━━"

    if [ "$MODE" = "python" ] || [ "$MODE" = "both" ]; then
        info "Testing Python mode..."
        if "$PYTHON" -c "
from jutuldarcy import simulate_data_file
print('jutuldarcy imported OK')
print('simulate_data_file function available')
" 2>/dev/null; then
            ok "Python mode: working"
        else
            err "Python mode: import failed"
        fi
    fi

    if [ "$MODE" = "julia" ] || [ "$MODE" = "both" ]; then
        info "Testing Julia mode..."
        if "$PYTHON" -c "
from juliacall import Main as jl
jl.seval('using JutulDarcy, Jutul')
print('JutulDarcy.jl loaded via juliacall OK')
" 2>/dev/null; then
            ok "Julia mode: working"
        else
            err "Julia mode: import failed"
        fi
    fi
fi

# ── Summary ──────────────────────────────────────────────────────────
echo ""
ok "JutulDarcy installation complete."
info "Mode: $MODE"

case "$MODE" in
    python)
        info "Usage in SimulatorWrap: platform='Python' (default)"
        ;;
    julia)
        info "Usage in SimulatorWrap: platform='Julia'"
        ;;
    both)
        info "Usage in SimulatorWrap: platform='Python' or platform='Julia'"
        ;;
esac

info "Reference: https://doi.org/10.1007/s10596-025-10366-6"
