#!/usr/bin/env bash
#
# run.sh -- Run reservoir simulations via JutulDarcy
#
# JutulDarcy.jl is a fully differentiable reservoir simulator written in Julia.
# This script supports both Python (PyJutulDarcy) and native Julia backends.
#
# Usage:
#   ./simulators/jutuldarcy/run.sh --test                              # Quick SPE1 test
#   ./simulators/jutuldarcy/run.sh /path/to/DECK.DATA                  # Run custom deck
#   ./simulators/jutuldarcy/run.sh --platform Julia /path/to/DECK.DATA # Use Julia backend
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

DATA_DIR="${PROJECT_ROOT}/opm-repos/opm-data-master"
OUTPUT_BASE="${PROJECT_ROOT}/output-jutul"
PLATFORM="Python"  # Default: Python mode

# ── Parse arguments ───────────────────────────────────────────────────
DECK_FILE=""
RUN_TEST=false

while [ $# -gt 0 ]; do
    case "$1" in
        --platform|-p)
            PLATFORM="$2"
            shift 2
            ;;
        --test|-t)
            RUN_TEST=true
            shift
            ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS] [DECK_FILE]"
            echo ""
            echo "Options:"
            echo "  --platform, -p MODE  JutulDarcy backend: Python (default) or Julia"
            echo "  --test, -t           Quick SPE1 validation test"
            echo "  --help, -h           Show this help"
            echo ""
            echo "Examples:"
            echo "  $0 --test                                              # Quick SPE1 test"
            echo "  $0 ../opm-repos/opm-data-master/spe1/SPE1CASE1.DATA   # Run SPE1"
            echo "  $0 --platform Julia /path/to/DECK.DATA                 # Julia backend"
            exit 0
            ;;
        -*)
            err "Unknown option: $1"
            exit 1
            ;;
        *)
            DECK_FILE="$1"
            shift
            ;;
    esac
done

# ── Pre-flight ────────────────────────────────────────────────────────
info "━━━ JutulDarcy Runner ━━━"
info "Platform: $PLATFORM"

if [ ! -d "$VENV_DIR" ] || [ ! -f "$PYTHON" ]; then
    err "Virtual environment not found at $VENV_DIR"
    err "Run simulators/setup_env.sh first."
    exit 1
fi

# Verify JutulDarcy is available
case "$PLATFORM" in
    Python)
        if ! "$PYTHON" -c "import jutuldarcy" 2>/dev/null; then
            err "jutuldarcy Python package not installed."
            err "Run: ./simulators/jutuldarcy/install.sh"
            exit 1
        fi
        ok "jutuldarcy (Python) available."
        ;;
    Julia)
        if ! "$PYTHON" -c "import juliacall" 2>/dev/null; then
            err "juliacall not installed."
            err "Run: ./simulators/jutuldarcy/install.sh --julia"
            exit 1
        fi
        ok "juliacall available."
        ;;
    *)
        err "Unknown platform: $PLATFORM (use Python or Julia)"
        exit 1
        ;;
esac

# ── Determine deck file ──────────────────────────────────────────────
if [ "$RUN_TEST" = true ]; then
    DECK_FILE="${DATA_DIR}/spe1/SPE1CASE1.DATA"
fi

if [ -z "$DECK_FILE" ]; then
    err "No deck file specified. Use --test for SPE1 or provide a .DATA file."
    exit 1
fi

if [ ! -f "$DECK_FILE" ]; then
    err "Deck file not found: $DECK_FILE"
    if [ "$RUN_TEST" = true ]; then
        err "Test data not found. Run ./simulators/opm/install.sh to download opm-data."
    fi
    exit 1
fi

# Convert to absolute path
DECK_FILE="$(cd "$(dirname "$DECK_FILE")" && pwd)/$(basename "$DECK_FILE")"
CASE_NAME="$(basename "$DECK_FILE" .DATA)"
OUT_DIR="${OUTPUT_BASE}/${CASE_NAME}"
mkdir -p "$OUT_DIR"

info "Running: $CASE_NAME"
info "  Deck:     $DECK_FILE"
info "  Output:   $OUT_DIR"
info "  Platform: $PLATFORM"
echo ""

# ── Run simulation ───────────────────────────────────────────────────
START=$SECONDS

case "$PLATFORM" in
    Python)
        "$PYTHON" -c "
import os
from jutuldarcy import simulate_data_file

deck = '$DECK_FILE'
out  = '$OUT_DIR'

print(f'Running JutulDarcy (Python) on {os.path.basename(deck)}...')
result = simulate_data_file(deck)
print('Simulation complete.')
print(f'Result keys: {list(result.keys()) if hasattr(result, \"keys\") else type(result)}')
"
        EXIT_CODE=$?
        ;;
    Julia)
        "$PYTHON" -c "
import os
from juliacall import Main as jl

jl.seval('using JutulDarcy, Jutul')
deck = '$DECK_FILE'
out  = '$OUT_DIR'

print(f'Running JutulDarcy (Julia) on {os.path.basename(deck)}...')
jl.seval(f'''
    case = setup_case_from_data_file(\"{deck}\")
    result = simulate_reservoir(case)
    println(\"Simulation complete.\")
    println(\"Keys: \", keys(result))
''')
"
        EXIT_CODE=$?
        ;;
esac

ELAPSED=$(( SECONDS - START ))

echo ""
if [ $EXIT_CODE -eq 0 ]; then
    ok "$CASE_NAME completed in ${ELAPSED}s"
else
    err "$CASE_NAME FAILED (exit code $EXIT_CODE) after ${ELAPSED}s"
fi

exit $EXIT_CODE
