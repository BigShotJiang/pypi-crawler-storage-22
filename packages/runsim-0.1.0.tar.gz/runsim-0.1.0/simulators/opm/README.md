# OPM Flow

Open Porous Media Flow -- industry-standard open-source reservoir simulator for modeling multiphase flow in porous media. Supports black-oil, compositional, and polymer flooding models.

## Links

- [OPM Project (main)](https://opm-project.org/)
- [Build from source](https://opm-project.org/?page_id=231)
- [Docker installation](https://opm-project.org/?page_id=853)
- [Docker image source](https://github.com/OPM/opm-utilities/tree/master/docker_opm_user) (builds `openporousmedia/opmreleases`)
- [opm-simulators (GitHub)](https://github.com/OPM/opm-simulators)
- [opm-data test cases (GitHub)](https://github.com/OPM/opm-data)

## Installation

### Docker (recommended for quick start)

```bash
./install-docker.sh              # Pull image + create flow-docker wrapper
./install-docker.sh --test       # + run SPE1 validation
./install-docker.sh --test-all   # + run all test cases (SPE1, SPE3, SPE9, Norne)
```

### Native macOS build (recommended for performance)

Builds Dune 2.10 + OPM from source with full ARM-native performance on Apple Silicon.

```bash
./install.sh                     # Full build (skips if already installed)
./install.sh --deps-only         # Homebrew + Dune only
./install.sh --test              # Build + SPE1 test
./install.sh --rebuild           # Force full rebuild
./install.sh --dir /path/to/dir  # Custom opm-repos directory
```

Requires: Xcode CLI tools, Homebrew, cmake, boost, suite-sparse, cjson, fmt.

## Running simulations

```bash
# Native
./run.sh                                                  # All bundled test cases
./run.sh /path/to/DECK.DATA                               # Custom deck

# Docker
./run-docker.sh                                           # All bundled test cases
./run-docker.sh /path/to/DECK.DATA                        # Custom deck
```

## OPM CLI syntax (2025.10+)

```bash
flow --output-dir=./output DECK.DATA
flow --parsing-strictness=low DECK.DATA
flow --enable-adaptive-time-stepping=true DECK.DATA
```
