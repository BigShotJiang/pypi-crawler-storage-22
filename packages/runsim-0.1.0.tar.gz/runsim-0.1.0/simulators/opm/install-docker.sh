#!/usr/bin/env bash
#
# install-docker.sh -- Install OPM Flow via Docker
#
# Pulls the OPM releases image, creates a flow wrapper script in the venv,
# and optionally runs a quick validation with SPE1.
#
# Usage:
#   ./simulators/opm/install-docker.sh                    # Install only
#   ./simulators/opm/install-docker.sh --test             # Install + run SPE1 test
#   ./simulators/opm/install-docker.sh --test-all         # Install + run all test cases
#   ./simulators/opm/install-docker.sh --dir /path/to/dir # Use custom opm-repos directory
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

OPM_IMAGE="openporousmedia/opmreleases:latest"
OPM_REPOS_DIR="${PROJECT_ROOT}/opm-repos"  # default: parent directory

RUN_TEST=""

# ── Parse arguments ──────────────────────────────────────────────────
while [ $# -gt 0 ]; do
    case "$1" in
        --test)     RUN_TEST="spe1"; shift ;;
        --test-all) RUN_TEST="all"; shift ;;
        --dir|-d)   OPM_REPOS_DIR="$2"; shift 2 ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --test           Install + run SPE1 validation test"
            echo "  --test-all       Install + run all test cases"
            echo "  --dir, -d PATH   Set opm-repos directory (default: ${OPM_REPOS_DIR})"
            exit 0
            ;;
        *) shift ;;
    esac
done

DATA_DIR="${OPM_REPOS_DIR}/opm-data-master"
DATA_ZIP="${OPM_REPOS_DIR}/opm-data-master.zip"

# ── Pre-flight ─────────────────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
    err "Docker is not installed."
    err "Install Docker Desktop from: https://www.docker.com/products/docker-desktop/"
    exit 1
fi

if ! docker info &>/dev/null; then
    err "Docker daemon is not running. Start Docker Desktop and try again."
    exit 1
fi

# ── Pull image ─────────────────────────────────────────────────────────
info "━━━ OPM Docker Installation ━━━"

if ! docker image inspect "$OPM_IMAGE" &>/dev/null; then
    info "Pulling ${OPM_IMAGE}..."
    docker pull "$OPM_IMAGE"
    ok "Image pulled."
else
    ok "Image already available."
fi

# Show version
VERSION=$(docker run --rm "$OPM_IMAGE" flow --version 2>/dev/null || echo "unknown")
ok "OPM Flow version: $VERSION"

# ── Create flow wrappers ──────────────────────────────────────────────
if [ -d "$VENV_DIR" ]; then
    # Create persistent Docker wrapper
    cat > "$VENV_DIR/bin/flow-docker" << 'FLOW_WRAPPER'
#!/usr/bin/env bash
# Docker wrapper for OPM Flow
OPM_IMAGE="openporousmedia/opmreleases:latest"
CWD="$(pwd)"
MOUNT_ROOT="$CWD"
for _ in 1 2 3 4; do
    PARENT="$(dirname "$MOUNT_ROOT")"
    [ "$PARENT" = "$MOUNT_ROOT" ] && break
    MOUNT_ROOT="$PARENT"
done
ARGS=()
for arg in "$@"; do
    if [[ "$arg" == --output-dir=* ]]; then
        DIR="${arg#--output-dir=}"
        [[ "$DIR" != /* ]] && DIR="$CWD/$DIR"
        ARGS+=("--output-dir=/work${DIR#$MOUNT_ROOT}")
    elif [[ "$arg" == *.DATA ]]; then
        FILE="$arg"
        [[ "$FILE" != /* ]] && FILE="$CWD/$FILE"
        ARGS+=("/work${FILE#$MOUNT_ROOT}")
    else
        ARGS+=("$arg")
    fi
done
REL_CWD="${CWD#$MOUNT_ROOT}"
[ -z "$REL_CWD" ] && REL_CWD="/"
exec docker run --rm -v "$MOUNT_ROOT:/work" -w "/work${REL_CWD}" "$OPM_IMAGE" flow "${ARGS[@]}"
FLOW_WRAPPER
    chmod +x "$VENV_DIR/bin/flow-docker"
    ok "flow-docker wrapper created"
else
    warn "No .venv found. Run simulators/setup_env.sh first."
fi

# ── Download/extract test data ────────────────────────────────────────
if [ ! -d "$DATA_DIR" ]; then
    mkdir -p "${OPM_REPOS_DIR}"
    if [ -f "$DATA_ZIP" ]; then
        info "Extracting test data..."
        unzip -q "$DATA_ZIP" -d "${OPM_REPOS_DIR}"
        ok "Test data extracted."
    else
        info "Downloading opm-data from GitHub..."
        if git clone --depth 1 "https://github.com/OPM/opm-data.git" "$DATA_DIR"; then
            ok "opm-data downloaded."
        else
            warn "Could not download opm-data. Test runs will not work."
        fi
    fi
else
    ok "Test data already present."
fi

# ── Optional test run ─────────────────────────────────────────────────
run_test() {
    local deck="$1"
    local name
    name="$(basename "$deck" .DATA)"
    local outdir="${PROJECT_ROOT}/output/${name}"
    mkdir -p "$outdir"
    info "  Running $name..."
    if docker run --rm \
        -v "$PROJECT_ROOT:/shared_host" \
        "$OPM_IMAGE" \
        flow --output-dir="/shared_host/output/${name}" \
        "/shared_host/${deck#$PROJECT_ROOT/}" >/dev/null 2>&1; then
        ok "  $name passed"
        return 0
    else
        err "  $name FAILED"
        return 1
    fi
}

case "$RUN_TEST" in
    spe1)
        echo ""
        info "━━━ Validation: SPE1 ━━━"
        if [ -f "$DATA_DIR/spe1/SPE1CASE1.DATA" ]; then
            run_test "$DATA_DIR/spe1/SPE1CASE1.DATA"
        else
            err "Test data not found. Place opm-data-master/ in $OPM_REPOS_DIR/"
        fi
        ;;
    all)
        echo ""
        info "━━━ Validation: All test cases ━━━"
        FAILED=()
        for deck in \
            "$DATA_DIR/spe1/SPE1CASE1.DATA" \
            "$DATA_DIR/spe3/SPE3CASE1.DATA" \
            "$DATA_DIR/spe9/SPE9.DATA" \
            "$DATA_DIR/norne/NORNE_ATW2013.DATA"; do
            if [ -f "$deck" ]; then
                run_test "$deck" || FAILED+=("$(basename "$deck" .DATA)")
            fi
        done
        echo ""
        if [ ${#FAILED[@]} -eq 0 ]; then
            ok "All tests passed."
        else
            err "Failed: ${FAILED[*]}"
        fi
        ;;
esac

echo ""
ok "OPM Docker installation complete."
