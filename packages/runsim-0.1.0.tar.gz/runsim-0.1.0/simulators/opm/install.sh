#!/usr/bin/env bash
#
# install.sh -- Build OPM Flow from source on macOS
#
# Builds Dune + OPM modules (opm-common, opm-grid, opm-simulators, opm-upscaling)
# with full ARM-native performance on Apple Silicon.
#
# Usage:
#   ./simulators/opm/install.sh                    # Full build (skips if already installed)
#   ./simulators/opm/install.sh --deps-only        # Install Homebrew deps + Dune only
#   ./simulators/opm/install.sh --test             # Build + run SPE1 test
#   ./simulators/opm/install.sh --rebuild          # Force full rebuild from scratch
#   ./simulators/opm/install.sh --dir /path/to/dir # Use custom opm-repos directory
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

BUILD_DIR="${PROJECT_ROOT}/opm-build"
DUNE_PREFIX="${BUILD_DIR}/dune-install"
OPM_PREFIX="${BUILD_DIR}/opm-install"
NPROC=$(sysctl -n hw.ncpu 2>/dev/null || echo 4)

OPM_REPOS_DIR="${PROJECT_ROOT}/opm-repos"  # default: parent directory
DEPS_ONLY=false
RUN_TEST=false
REBUILD=false

# ── Parse arguments ──────────────────────────────────────────────────
while [ $# -gt 0 ]; do
    case "$1" in
        --deps-only) DEPS_ONLY=true; shift ;;
        --test)      RUN_TEST=true; shift ;;
        --rebuild)   REBUILD=true; shift ;;
        --dir|-d)    OPM_REPOS_DIR="$2"; shift 2 ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --deps-only      Install Homebrew deps + Dune only (no OPM)"
            echo "  --test           Build + run SPE1 validation test"
            echo "  --rebuild        Force full rebuild (removes existing build artifacts)"
            echo "  --dir, -d PATH   Set opm-repos directory (default: ${OPM_REPOS_DIR})"
            exit 0
            ;;
        *) shift ;;
    esac
done

# ── Pre-flight ─────────────────────────────────────────────────────────
info "━━━ OPM Native Build (macOS) ━━━"

# Check if already installed (skip unless --rebuild)
FLOW_BIN="${OPM_PREFIX}/bin/flow"
if [ "$REBUILD" = false ] && [ "$DEPS_ONLY" = false ] && [ -x "$FLOW_BIN" ]; then
    VERSION=$("$FLOW_BIN" --version 2>&1 | head -1 || echo "unknown")
    ok "OPM Flow already installed: $VERSION"
    ok "Binary: $FLOW_BIN"
    info "Use --rebuild to force a full rebuild."

    # Create/update wrapper even if build is skipped
    if [ -d "$VENV_DIR" ]; then
        cat > "$VENV_DIR/bin/flow" << WRAPPER
#!/usr/bin/env bash
exec "$FLOW_BIN" "\$@"
WRAPPER
        chmod +x "$VENV_DIR/bin/flow"
        ok "flow wrapper created (native OPM)"
    fi

    # Still run test if requested
    if [ "$RUN_TEST" = true ]; then
        echo ""
        info "━━━ Validation: SPE1 ━━━"
        DATA_DIR="${OPM_REPOS_DIR}/opm-data-master"
        SPE1="$DATA_DIR/spe1/SPE1CASE1.DATA"
        if [ -f "$SPE1" ]; then
            OUTDIR="${PROJECT_ROOT}/output/SPE1CASE1"
            mkdir -p "$OUTDIR"
            info "Running SPE1CASE1..."
            if "$FLOW_BIN" --output-dir="$OUTDIR" "$SPE1" >/dev/null 2>&1; then
                ok "SPE1 passed."
            else
                err "SPE1 failed."
                exit 1
            fi
        else
            err "Test data not found at $SPE1"
            err "Place opm-data-master/ in $OPM_REPOS_DIR/ or run: ./simulators/opm/install.sh --test"
        fi
    fi
    exit 0
fi

# If --rebuild, clean existing build artifacts
if [ "$REBUILD" = true ] && [ -d "$BUILD_DIR" ]; then
    warn "Removing existing build artifacts for rebuild..."
    for mod in opm-common opm-grid opm-simulators opm-upscaling; do
        rm -rf "${BUILD_DIR}/${mod}/build"
    done
    rm -rf "$OPM_PREFIX"
    ok "Build artifacts cleaned."
fi

# Check Xcode CLI tools
if ! xcode-select -p &>/dev/null; then
    err "Xcode command line tools not installed."
    info "Run: xcode-select --install"
    exit 1
fi
ok "Xcode CLI tools found."

# Check Homebrew
if ! command -v brew &>/dev/null; then
    err "Homebrew not installed."
    info "Install from: https://brew.sh"
    exit 1
fi
ok "Homebrew found."

# ── Step 1: Homebrew dependencies ────────────────────────────────────
info "━━━ Step 1: Homebrew packages ━━━"

BREW_DEPS=(cmake pkg-config doxygen boost suite-sparse cjson fmt)
MISSING=()
for pkg in "${BREW_DEPS[@]}"; do
    if ! brew list "$pkg" &>/dev/null; then
        MISSING+=("$pkg")
    fi
done

if [ ${#MISSING[@]} -gt 0 ]; then
    info "Installing: ${MISSING[*]}"
    brew install "${MISSING[@]}"
    ok "Packages installed."
else
    ok "All Homebrew packages already installed."
fi

# Optional: MPI
if brew list open-mpi &>/dev/null; then
    ok "open-mpi available (parallel runs enabled)."
else
    warn "open-mpi not installed. Parallel simulation disabled."
    info "Optional: brew install open-mpi"
fi

# ── Step 2: Build Dune 2.10 ─────────────────────────────────────────
info "━━━ Step 2: Dune 2.10 ━━━"

mkdir -p "$BUILD_DIR" "$DUNE_PREFIX"

DUNE_MODULES=(dune-common dune-geometry dune-grid dune-istl)
DUNE_BRANCH="releases/2.10"
DUNE_BUILT=true

for mod in "${DUNE_MODULES[@]}"; do
    SRC="${BUILD_DIR}/${mod}"

    if [ -f "${DUNE_PREFIX}/lib/cmake/${mod}/${mod}-config.cmake" ] || \
       [ -f "${DUNE_PREFIX}/lib64/cmake/${mod}/${mod}-config.cmake" ]; then
        ok "$mod already installed."
        continue
    fi

    DUNE_BUILT=false
    if [ ! -d "$SRC" ]; then
        info "Cloning $mod ($DUNE_BRANCH)..."
        git clone --branch "$DUNE_BRANCH" --depth 1 \
            "https://gitlab.dune-project.org/core/${mod}.git" "$SRC"
    fi

    info "Building $mod (using $NPROC cores)..."
    mkdir -p "$SRC/build"
    if ! cmake -S "$SRC" -B "$SRC/build" \
        -DCMAKE_INSTALL_PREFIX="$DUNE_PREFIX" \
        -DCMAKE_BUILD_TYPE=Release; then
        err "cmake configure failed for $mod"; exit 1
    fi
    if ! cmake --build "$SRC/build" -j "$NPROC"; then
        err "cmake build failed for $mod"; exit 1
    fi
    if ! cmake --install "$SRC/build"; then
        err "cmake install failed for $mod"; exit 1
    fi
    ok "$mod installed."
done

if [ "$DUNE_BUILT" = true ]; then
    ok "All Dune modules already built."
fi

if [ "$DEPS_ONLY" = true ]; then
    ok "Dependencies installed. Exiting (--deps-only)."
    exit 0
fi

# ── Step 3: Build OPM modules ───────────────────────────────────────
info "━━━ Step 3: OPM modules ━━━"

OPM_MODULES=(opm-common opm-grid opm-simulators opm-upscaling)
OPM_CMAKE_PREFIX="${DUNE_PREFIX};${OPM_PREFIX}"

for mod in "${OPM_MODULES[@]}"; do
    SRC="${BUILD_DIR}/${mod}"

    # Check if already built
    if [ "$mod" = "opm-simulators" ] && [ -x "${OPM_PREFIX}/bin/flow" ]; then
        ok "$mod already built (flow binary exists)."
        continue
    elif [ "$mod" != "opm-simulators" ] && \
         { [ -f "${OPM_PREFIX}/lib/cmake/${mod}/${mod}-config.cmake" ] || \
           [ -f "${OPM_PREFIX}/lib64/cmake/${mod}/${mod}-config.cmake" ]; }; then
        ok "$mod already installed."
        continue
    fi

    if [ ! -d "$SRC" ]; then
        info "Cloning $mod..."
        git clone --depth 1 "https://github.com/OPM/${mod}.git" "$SRC"
    fi

    info "Building $mod (using $NPROC cores)..."
    mkdir -p "$SRC/build"
    if ! cmake -S "$SRC" -B "$SRC/build" \
        -DCMAKE_PREFIX_PATH="$OPM_CMAKE_PREFIX" \
        -DCMAKE_INSTALL_PREFIX="$OPM_PREFIX" \
        -DCMAKE_BUILD_TYPE=Release; then
        err "cmake configure failed for $mod"; exit 1
    fi
    if ! cmake --build "$SRC/build" -j "$NPROC"; then
        err "cmake build failed for $mod"; exit 1
    fi
    if ! cmake --install "$SRC/build"; then
        err "cmake install failed for $mod"; exit 1
    fi
    ok "$mod installed."

    # Accumulate install prefix for downstream modules
    OPM_CMAKE_PREFIX="${DUNE_PREFIX};${OPM_PREFIX}"
done

# ── Step 4: Create symlink or wrapper in venv ────────────────────────
FLOW_BIN="${OPM_PREFIX}/bin/flow"

if [ -x "$FLOW_BIN" ]; then
    ok "OPM Flow binary: $FLOW_BIN"
    VERSION=$("$FLOW_BIN" --version 2>&1 | head -1 || echo "unknown")
    ok "Version: $VERSION"

    if [ -d "$VENV_DIR" ]; then
        # Create flow wrapper (native OPM)
        cat > "$VENV_DIR/bin/flow" << WRAPPER
#!/usr/bin/env bash
exec "$FLOW_BIN" "\$@"
WRAPPER
        chmod +x "$VENV_DIR/bin/flow"
        ok "flow wrapper created (native OPM)"
    else
        warn "No .venv found. Create it with simulators/setup_env.sh, then run this script again."
        info "Or add $OPM_PREFIX/bin to your PATH."
    fi
else
    err "flow binary not found at $FLOW_BIN. Build may have failed."
    exit 1
fi

# ── Download opm-data if missing ──────────────────────────────────────
DATA_DIR="${OPM_REPOS_DIR}/opm-data-master"
if [ ! -d "$DATA_DIR" ]; then
    DATA_ZIP="${OPM_REPOS_DIR}/opm-data-master.zip"
    mkdir -p "${OPM_REPOS_DIR}"
    if [ -f "$DATA_ZIP" ]; then
        info "Extracting opm-data from zip..."
        unzip -q "$DATA_ZIP" -d "${OPM_REPOS_DIR}"
        ok "Test data extracted."
    else
        info "Downloading opm-data from GitHub..."
        if git clone --depth 1 "https://github.com/OPM/opm-data.git" "$DATA_DIR"; then
            ok "opm-data downloaded."
        else
            warn "Could not download opm-data. Test data will not be available."
        fi
    fi
else
    ok "opm-data already present."
fi

# ── Optional test ────────────────────────────────────────────────────
if [ "$RUN_TEST" = true ]; then
    echo ""
    info "━━━ Validation: SPE1 ━━━"
    SPE1="$DATA_DIR/spe1/SPE1CASE1.DATA"
    if [ -f "$SPE1" ]; then
        OUTDIR="${PROJECT_ROOT}/output/SPE1CASE1"
        mkdir -p "$OUTDIR"
        info "Running SPE1CASE1..."
        if "$FLOW_BIN" --output-dir="$OUTDIR" "$SPE1" >/dev/null 2>&1; then
            ok "SPE1 passed."
        else
            err "SPE1 failed."
            exit 1
        fi
    else
        err "Test data not found at $SPE1"
        err "Run: ./simulators/opm/install.sh to download opm-data"
    fi
fi

echo ""
ok "OPM native build complete."
info "Binary: $FLOW_BIN"
info "Build directory: $BUILD_DIR"
