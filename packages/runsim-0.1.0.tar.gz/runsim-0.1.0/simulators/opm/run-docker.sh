#!/usr/bin/env bash
#
# run-docker.sh -- Run OPM Flow simulations via Docker
#
# Usage:
#   ./simulators/opm/run-docker.sh                     # Run all bundled test cases
#   ./simulators/opm/run-docker.sh /path/to/DECK.DATA  # Run a custom deck file
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

# ── Configuration ──────────────────────────────────────────────────────
OPM_IMAGE="openporousmedia/opmreleases:latest"
DATA_ZIP="${PROJECT_ROOT}/opm-repos/opm-data-master.zip"
DATA_DIR="${PROJECT_ROOT}/opm-repos/opm-data-master"
OUTPUT_BASE="${PROJECT_ROOT}/output"

run_flow() {
    local deck_file="$1"
    local case_name
    case_name="$(basename "${deck_file}" .DATA)"
    local output_dir="${OUTPUT_BASE}/${case_name}"

    mkdir -p "${output_dir}"
    info "Running: ${case_name}"
    info "  Deck:   ${deck_file}"
    info "  Output: ${output_dir}"

    local start=$SECONDS
    if docker run --rm \
        -v "${PROJECT_ROOT}:/shared_host" \
        "${OPM_IMAGE}" \
        flow \
        --output-dir="/shared_host/output/${case_name}" \
        "/shared_host/${deck_file#${PROJECT_ROOT}/}"; then
        local elapsed=$(( SECONDS - start ))
        ok "${case_name} completed in ${elapsed}s"
        echo ""
        return 0
    else
        local elapsed=$(( SECONDS - start ))
        err "${case_name} FAILED after ${elapsed}s"
        echo ""
        FAILED_CASES+=("${case_name}")
        return 1
    fi
}

# ── Pre-flight checks ─────────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
    err "Docker is not installed. Install Docker Desktop from https://www.docker.com/products/docker-desktop/"
    exit 1
fi

if ! docker info &>/dev/null; then
    err "Docker daemon is not running. Start Docker Desktop and try again."
    exit 1
fi

# ── Pull image if not present ──────────────────────────────────────────
if ! docker image inspect "${OPM_IMAGE}" &>/dev/null; then
    info "Pulling OPM Docker image: ${OPM_IMAGE}"
    docker pull "${OPM_IMAGE}"
    ok "Image pulled."
else
    ok "OPM Docker image already available."
fi

# Show version
OPM_VERSION=$(docker run --rm "${OPM_IMAGE}" flow --version 2>/dev/null || true)
info "OPM Flow version: ${OPM_VERSION}"

# ── Extract test data if needed ────────────────────────────────────────
if [ ! -d "${DATA_DIR}" ]; then
    if [ -f "${DATA_ZIP}" ]; then
        info "Extracting ${DATA_ZIP}..."
        unzip -q "${DATA_ZIP}" -d "${PROJECT_ROOT}/opm-repos"
        ok "Test data extracted."
    else
        err "No test data found. Place opm-data-master/ in ${PROJECT_ROOT}/opm-repos/"
        exit 1
    fi
else
    ok "Test data directory already exists."
fi

# ── Run simulations ───────────────────────────────────────────────────
mkdir -p "${OUTPUT_BASE}"
FAILED_CASES=()

if [ $# -ge 1 ]; then
    # Custom deck file provided as argument
    CUSTOM_DECK="$1"
    if [ ! -f "${CUSTOM_DECK}" ]; then
        err "Deck file not found: ${CUSTOM_DECK}"
        exit 1
    fi
    # Convert to absolute path if relative
    CUSTOM_DECK="$(cd "$(dirname "${CUSTOM_DECK}")" && pwd)/$(basename "${CUSTOM_DECK}")"
    run_flow "${CUSTOM_DECK}"
else
    # Run bundled test cases
    info "Running all bundled test cases..."
    echo ""

    CASES=(
        "${DATA_DIR}/spe1/SPE1CASE1.DATA"
        "${DATA_DIR}/spe3/SPE3CASE1.DATA"
        "${DATA_DIR}/spe9/SPE9.DATA"
        "${DATA_DIR}/norne/NORNE_ATW2013.DATA"
    )

    total=${#CASES[@]}
    current=0

    for deck in "${CASES[@]}"; do
        current=$((current + 1))
        info "━━━ Case ${current}/${total} ━━━"
        if [ -f "${deck}" ]; then
            run_flow "${deck}" || true
        else
            err "Deck not found, skipping: ${deck}"
            FAILED_CASES+=("$(basename "${deck}" .DATA)")
            echo ""
        fi
    done
fi

# ── Summary ────────────────────────────────────────────────────────────
echo ""
info "━━━ Summary ━━━"
info "Output files are in: ${OUTPUT_BASE}/"
ls -1d "${OUTPUT_BASE}"/*/ 2>/dev/null | while read -r d; do
    count=$(ls -1 "$d" | wc -l | tr -d ' ')
    size=$(du -sh "$d" | cut -f1)
    printf "  %-30s %s files, %s\n" "$(basename "$d")/" "${count}" "${size}"
done

if [ ${#FAILED_CASES[@]} -eq 0 ]; then
    ok "All simulations finished successfully."
else
    err "Failed cases: ${FAILED_CASES[*]}"
    exit 1
fi
