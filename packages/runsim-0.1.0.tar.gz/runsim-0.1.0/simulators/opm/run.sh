#!/usr/bin/env bash
#
# run.sh -- Run OPM Flow simulations using the native build
#
# Usage:
#   ./simulators/opm/run.sh                     # Run all bundled test cases
#   ./simulators/opm/run.sh /path/to/DECK.DATA  # Run a custom deck file
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

# ── Configuration ──────────────────────────────────────────────────────
BUILD_DIR="${PROJECT_ROOT}/opm-build"
OPM_PREFIX="${BUILD_DIR}/opm-install"
FLOW_BIN="${OPM_PREFIX}/bin/flow"
DATA_ZIP="${PROJECT_ROOT}/opm-repos/opm-data-master.zip"
DATA_DIR="${PROJECT_ROOT}/opm-repos/opm-data-master"
OUTPUT_BASE="${PROJECT_ROOT}/output-native"

run_flow() {
    local deck_file="$1"
    local case_name
    case_name="$(basename "${deck_file}" .DATA)"
    local output_dir="${OUTPUT_BASE}/${case_name}"

    mkdir -p "${output_dir}"
    info "Running: ${case_name}"
    info "  Deck:   ${deck_file}"
    info "  Output: ${output_dir}"

    local start=$SECONDS
    if "$FLOW_BIN" --output-dir="${output_dir}" "${deck_file}"; then
        local elapsed=$(( SECONDS - start ))
        ok "${case_name} completed in ${elapsed}s"
        echo ""
        return 0
    else
        local elapsed=$(( SECONDS - start ))
        err "${case_name} FAILED after ${elapsed}s"
        echo ""
        FAILED_CASES+=("${case_name}")
        return 1
    fi
}

# ── Pre-flight checks ─────────────────────────────────────────────────
if [ ! -x "$FLOW_BIN" ]; then
    # Also check venv wrapper
    VENV_FLOW="${VENV_DIR}/bin/flow"
    if [ -x "$VENV_FLOW" ] && ! grep -q "docker" "$VENV_FLOW" 2>/dev/null; then
        FLOW_BIN="$VENV_FLOW"
    else
        err "Native flow binary not found at $FLOW_BIN"
        err "Run: ./simulators/opm/install.sh"
        exit 1
    fi
fi

OPM_VERSION=$("$FLOW_BIN" --version 2>&1 | head -1 || echo "unknown")
info "OPM Flow (native): ${OPM_VERSION}"
info "Binary: ${FLOW_BIN}"

# ── Extract test data if needed ────────────────────────────────────────
if [ ! -d "${DATA_DIR}" ]; then
    if [ -f "${DATA_ZIP}" ]; then
        info "Extracting ${DATA_ZIP}..."
        unzip -q "${DATA_ZIP}" -d "${PROJECT_ROOT}/opm-repos"
        ok "Test data extracted."
    else
        err "No test data found. Place opm-data-master/ in ${PROJECT_ROOT}/opm-repos/"
        exit 1
    fi
else
    ok "Test data directory already exists."
fi

# ── Run simulations ───────────────────────────────────────────────────
mkdir -p "${OUTPUT_BASE}"
FAILED_CASES=()

if [ $# -ge 1 ]; then
    # Custom deck file provided as argument
    CUSTOM_DECK="$1"
    if [ ! -f "${CUSTOM_DECK}" ]; then
        err "Deck file not found: ${CUSTOM_DECK}"
        exit 1
    fi
    # Convert to absolute path if relative
    CUSTOM_DECK="$(cd "$(dirname "${CUSTOM_DECK}")" && pwd)/$(basename "${CUSTOM_DECK}")"
    run_flow "${CUSTOM_DECK}"
else
    # Run bundled test cases
    info "Running all bundled test cases..."
    echo ""

    CASES=(
        "${DATA_DIR}/spe1/SPE1CASE1.DATA"
        "${DATA_DIR}/spe3/SPE3CASE1.DATA"
        "${DATA_DIR}/spe9/SPE9.DATA"
        "${DATA_DIR}/norne/NORNE_ATW2013.DATA"
    )

    total=${#CASES[@]}
    current=0

    for deck in "${CASES[@]}"; do
        current=$((current + 1))
        info "━━━ Case ${current}/${total} ━━━"
        if [ -f "${deck}" ]; then
            run_flow "${deck}" || true
        else
            err "Deck not found, skipping: ${deck}"
            FAILED_CASES+=("$(basename "${deck}" .DATA)")
            echo ""
        fi
    done
fi

# ── Summary ────────────────────────────────────────────────────────────
echo ""
info "━━━ Summary ━━━"
info "Output files are in: ${OUTPUT_BASE}/"
ls -1d "${OUTPUT_BASE}"/*/ 2>/dev/null | while read -r d; do
    count=$(ls -1 "$d" | wc -l | tr -d ' ')
    size=$(du -sh "$d" | cut -f1)
    printf "  %-30s %s files, %s\n" "$(basename "$d")/" "${count}" "${size}"
done

if [ ${#FAILED_CASES[@]} -eq 0 ]; then
    ok "All simulations finished successfully."
else
    err "Failed cases: ${FAILED_CASES[*]}"
    exit 1
fi
