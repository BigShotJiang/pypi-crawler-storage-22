# PET -- Python Ensemble Toolbox

Data assimilation and optimization framework for reservoir modeling. Implements ES-MDA (Ensemble Smoother with Multiple Data Assimilation) and gradient-based optimization algorithms.

## Links

- [PET (GitHub)](https://github.com/Python-Ensemble-Toolbox/PET)
- [SimulatorWrap (GitHub)](https://github.com/Python-Ensemble-Toolbox/SimulatorWrap)
- [Examples (GitHub)](https://github.com/Python-Ensemble-Toolbox/Examples)

## Installation

```bash
./install.sh                     # Download repos + pip install PET/SimulatorWrap
./install.sh --status            # Show which repos/packages are present
./install.sh --dir /path/to/dir  # Custom repos directory
```

This clones three repositories into `pet-repos/`:
- **PET-main/** -- Python Ensemble Toolbox (DA + optimization algorithms)
- **SimulatorWrap-main/** -- Python wrappers around OPM Flow, Eclipse, JutulDarcy
- **Examples-main/** -- Example cases (3dBox, LinearModel, 3Spot, etc.)

PET and SimulatorWrap are installed as editable pip packages.

## Running examples

Use the top-level `run_example.sh`:

```bash
../../run_example.sh --list              # List all available examples
../../run_example.sh Quadratic           # Analytic optimization (no simulator)
../../run_example.sh 3dBox/tiny          # History matching with OPM Flow
```
