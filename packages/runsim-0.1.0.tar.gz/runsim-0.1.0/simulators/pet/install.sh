#!/usr/bin/env bash
#
# install.sh -- Download and install PET packages
#
# Clones PET, SimulatorWrap, and Examples repos into pet-repos/ and
# installs SimulatorWrap + PET as editable pip packages into the venv.
#
# Usage:
#   ./simulators/pet/install.sh                    # Download repos + pip install
#   ./simulators/pet/install.sh --status           # Show status of repos and packages
#   ./simulators/pet/install.sh --dir /path/to/dir # Use custom repos directory
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

PET_REPOS_DIR="${PROJECT_ROOT}/pet-repos"  # default: parent directory

# ── Repository definitions ───────────────────────────────────────────
# Format: "url|target_dir|description"
REPOS=(
    "https://github.com/Python-Ensemble-Toolbox/PET.git|PET-main|Python Ensemble Toolbox"
    "https://github.com/Python-Ensemble-Toolbox/SimulatorWrap.git|SimulatorWrap-main|Simulator wrappers"
    "https://github.com/Python-Ensemble-Toolbox/Examples.git|Examples-main|PET example cases"
)

# ── Functions ────────────────────────────────────────────────────────
show_status() {
    info "━━━ PET Repository Status ━━━"
    echo ""
    for entry in "${REPOS[@]}"; do
        IFS='|' read -r url dir desc <<< "$entry"
        target="${PET_REPOS_DIR}/${dir}"
        if [ -d "$target" ]; then
            ok "$dir/ -- $desc"
        else
            warn "$dir/ -- $desc (MISSING)"
        fi
    done
    echo ""

    # Check pip packages
    info "━━━ PET Package Status ━━━"
    echo ""
    if [ -d "$VENV_DIR" ]; then
        if "$PYTHON" -c "import subsurface" 2>/dev/null; then
            ok "SimulatorWrap (subsurface) installed"
        else
            warn "SimulatorWrap (subsurface) NOT installed"
        fi
        if "$PYTHON" -c "import pipt" 2>/dev/null; then
            ok "PET (pipt) installed"
        else
            warn "PET (pipt) NOT installed"
        fi
    else
        warn "Virtual environment not found at ${VENV_DIR}"
    fi
}

download_repos() {
    info "━━━ Downloading PET Repositories ━━━"
    echo ""

    mkdir -p "$PET_REPOS_DIR"

    DOWNLOADED=0
    SKIPPED=0
    FAILED=0

    for entry in "${REPOS[@]}"; do
        IFS='|' read -r url dir desc <<< "$entry"
        target="${PET_REPOS_DIR}/${dir}"

        if [ -d "$target" ]; then
            ok "$dir/ already exists -- $desc"
            SKIPPED=$((SKIPPED + 1))
            continue
        fi

        info "Cloning $dir ($desc)..."
        if git clone --depth 1 "$url" "$target" 2>&1 | tail -2; then
            ok "$dir downloaded."
            DOWNLOADED=$((DOWNLOADED + 1))
        else
            err "Failed to clone $dir from $url"
            FAILED=$((FAILED + 1))
        fi
        echo ""
    done

    echo ""
    info "━━━ Download Summary ━━━"
    [ $DOWNLOADED -gt 0 ] && ok "Downloaded: $DOWNLOADED"
    [ $SKIPPED -gt 0 ]    && ok "Already present: $SKIPPED"
    [ $FAILED -gt 0 ]     && err "Failed: $FAILED"

    if [ $FAILED -gt 0 ]; then
        exit 1
    fi
}

install_packages() {
    info "━━━ Installing PET Packages ━━━"
    echo ""

    if [ ! -d "$VENV_DIR" ]; then
        err "Virtual environment not found at ${VENV_DIR}"
        err "Run ./simulators/setup_env.sh first to create the venv."
        exit 1
    fi

    if ! "$PYTHON" -c "import subsurface" 2>/dev/null; then
        info "Installing SimulatorWrap..."
        "$PIP" install -e "${PET_REPOS_DIR}/SimulatorWrap-main/" -q 2>&1 | tail -1
        ok "SimulatorWrap installed."
    else
        ok "SimulatorWrap already installed."
    fi

    if ! "$PYTHON" -c "import pipt" 2>/dev/null; then
        info "Installing PET..."
        # --no-deps: PET pins libecalc==8.23.1 which is incompatible with Python 3.13.
        # Core deps (numpy, scipy, etc.) are already satisfied via SimulatorWrap.
        "$PIP" install -e "${PET_REPOS_DIR}/PET-main/" --no-deps -q 2>&1 | tail -1
        ok "PET installed."
    else
        ok "PET already installed."
    fi
}

# ── Parse arguments ──────────────────────────────────────────────────
ACTION="install"

while [ $# -gt 0 ]; do
    case "$1" in
        --status)
            ACTION="status"
            shift
            ;;
        --dir|-d)
            PET_REPOS_DIR="$2"
            shift 2
            ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Downloads PET repositories and installs SimulatorWrap + PET"
            echo "as editable pip packages."
            echo ""
            echo "Repositories:"
            for entry in "${REPOS[@]}"; do
                IFS='|' read -r url dir desc <<< "$entry"
                printf "  %-25s %s\n" "$dir/" "$desc"
            done
            echo ""
            echo "Options:"
            echo "  --status         Show which repos/packages are present"
            echo "  --dir, -d PATH   Set repos directory (default: ${PET_REPOS_DIR})"
            exit 0
            ;;
        -*)
            err "Unknown option: $1"
            exit 1
            ;;
        *)
            shift
            ;;
    esac
done

# ── Main ─────────────────────────────────────────────────────────────
info "PET repos directory: ${PET_REPOS_DIR}"

case "$ACTION" in
    status)
        show_status
        ;;
    install)
        download_repos
        install_packages
        ;;
esac
