#!/usr/bin/env bash
#
# run.sh -- Run PET examples (data assimilation & optimization)
#
# Usage (via runsim.sh):
#   ./runsim.sh pet --list                         # List available examples
#   ./runsim.sh pet LinearModel                    # Run an example
#   ./runsim.sh pet 3dBox/tiny                     # Run a sub-case
#   ./runsim.sh pet 3SpotRobust --variant bhp      # Run a specific variant
#   ./runsim.sh pet --clean 3dBox/tiny             # Clean outputs then run
#   ./runsim.sh pet --simulator flow 3dBox/tiny    # Use native OPM Flow (default)
#   ./runsim.sh pet --simulator flow-docker 3dBox/tiny  # Use Docker
#
# Direct usage:
#   ./simulators/pet/run.sh --list
#   ./simulators/pet/run.sh 3dBox/tiny
#
set -uo pipefail

source "$(cd "$(dirname "$0")/.." && pwd)/common.sh"

EXAMPLES_DIR="${PROJECT_ROOT}/pet-repos/Examples-main"

# ── Example registry ──────────────────────────────────────────────────
# Format: "name|type|simulator|run_script|needs_datagen|subcases"
EXAMPLES=(
    "LinearModel|DA|none|run_script.py|no|"
    "3dBox/tiny|DA|flow|run_script.py|yes|"
    "3dBox/small|DA|flow|run_script.py|yes|"
    "3dBox/medium|DA|flow|run_script.py|yes|"
    "3dBox/large|DA|flow|run_script.py|yes|"
    "3dBox/flowrock|DA|flow|run_script.py|yes|"
    "Spe11b|DA|flow|run_script.py|yes|"
    "3Spot|Opt|flow|run_opt.py|no|"
    "3SpotRobust|Opt|flow|run_opt_bhp.py|no|bhp,rate"
    "3SpotEcalc|Opt|flow|run_opt.py|no|"
    "5SpotInverted|Opt|flow|run_opt.py|no|"
    "5SpotLineSearch|Opt|flow|run.py|no|"
    "Rosenbrock|Opt|none|run_opt.py|no|"
    "Quadratic|Opt|none|run_opt.py|no|"
)

get_field() { echo "$1" | cut -d'|' -f"$2"; }

list_examples() {
    echo ""
    printf "  %-22s %-6s %-10s %s\n" "EXAMPLE" "TYPE" "SIMULATOR" "NOTES"
    printf "  %-22s %-6s %-10s %s\n" "───────" "────" "─────────" "─────"
    for entry in "${EXAMPLES[@]}"; do
        name=$(get_field "$entry" 1)
        typ=$(get_field "$entry" 2)
        sim=$(get_field "$entry" 3)
        datagen=$(get_field "$entry" 5)
        variants=$(get_field "$entry" 6)
        notes=""
        [ "$datagen" = "yes" ] && notes="needs data generation"
        [ -n "$variants" ] && notes="${notes:+$notes, }variants: $variants"
        printf "  %-22s %-6s %-10s %s\n" "$name" "$typ" "$sim" "$notes"
    done
    echo ""
    echo "  Type: DA = Data Assimilation, Opt = Optimization"
    echo "  Simulator: flow = OPM Flow, none = analytic/built-in"
    echo ""
}

find_example() {
    local query="$1"
    for entry in "${EXAMPLES[@]}"; do
        name=$(get_field "$entry" 1)
        if [ "$name" = "$query" ]; then
            echo "$entry"
            return 0
        fi
    done
    return 1
}

# ── Parse arguments ───────────────────────────────────────────────────
CLEAN=false
VARIANT=""
SIMULATOR=""
EXAMPLE_NAME=""

while [ $# -gt 0 ]; do
    case "$1" in
        --list|-l)
            list_examples
            exit 0
            ;;
        --clean|-c)
            CLEAN=true
            shift
            ;;
        --variant|-v)
            VARIANT="$2"
            shift 2
            ;;
        --simulator|-s)
            SIMULATOR="$2"
            shift 2
            ;;
        --help|-h)
            echo "Usage: runsim.sh pet [OPTIONS] EXAMPLE_NAME"
            echo ""
            echo "Options:"
            echo "  --list, -l             List available examples"
            echo "  --clean, -c            Clean previous outputs before running"
            echo "  --variant, -v NAME     Select variant (e.g., bhp or rate for 3SpotRobust)"
            echo "  --simulator, -s MODE   Choose simulator: flow (native, default), flow-docker"
            echo "  --help, -h             Show this help"
            exit 0
            ;;
        -*)
            err "Unknown option: $1"
            exit 1
            ;;
        *)
            EXAMPLE_NAME="$1"
            shift
            ;;
    esac
done

if [ -z "$EXAMPLE_NAME" ]; then
    err "No example specified. Use --list to see available examples."
    exit 1
fi

# ── Look up example ───────────────────────────────────────────────────
ENTRY=$(find_example "$EXAMPLE_NAME") || {
    err "Unknown example: $EXAMPLE_NAME"
    echo ""
    info "Available examples:"
    list_examples
    exit 1
}

EX_NAME=$(get_field "$ENTRY" 1)
EX_TYPE=$(get_field "$ENTRY" 2)
EX_SIM=$(get_field "$ENTRY" 3)
EX_SCRIPT=$(get_field "$ENTRY" 4)
EX_DATAGEN=$(get_field "$ENTRY" 5)
EX_VARIANTS=$(get_field "$ENTRY" 6)

# Handle variant selection
if [ -n "$VARIANT" ] && [ -n "$EX_VARIANTS" ]; then
    EX_SCRIPT="run_opt_${VARIANT}.py"
elif [ -n "$VARIANT" ] && [ -z "$EX_VARIANTS" ]; then
    warn "Example $EX_NAME has no variants. Ignoring --variant $VARIANT."
fi

# Determine the example directory
EX_DIR="${EXAMPLES_DIR}/${EX_NAME}"

if [ ! -d "$EX_DIR" ]; then
    err "Example directory not found: $EX_DIR"
    exit 1
fi

if [ ! -f "$EX_DIR/$EX_SCRIPT" ]; then
    err "Run script not found: $EX_DIR/$EX_SCRIPT"
    exit 1
fi

# ── Ensure environment is set up ──────────────────────────────────────
if [ ! -d "$VENV_DIR" ] || [ ! -f "$PYTHON" ]; then
    info "Environment not set up. Running setup_env.sh..."
    bash "${SIMULATORS_DIR}/setup_env.sh"
    echo ""
fi

# Verify key packages
if ! "$PYTHON" -c "import pipt" 2>/dev/null; then
    err "PET not installed. Run: ./runsim.sh setup"
    exit 1
fi

# Check Docker for flow-based examples when using docker mode
if [ "$EX_SIM" = "flow" ] && [ "$SIMULATOR" = "flow-docker" ]; then
    if ! command -v docker &>/dev/null || ! docker info &>/dev/null 2>&1; then
        err "Docker is required for flow-docker mode but is not running."
        exit 1
    fi
fi

# ── Clean previous outputs ────────────────────────────────────────────
if [ "$CLEAN" = true ]; then
    info "Cleaning previous outputs in $EX_DIR..."
    rm -rf "$EX_DIR/SaveOutputs" "$EX_DIR/Crashdump" 2>/dev/null
    rm -rf "$EX_DIR"/en_* 2>/dev/null
    ok "Cleaned."
fi

# ── Generate data if needed ───────────────────────────────────────────
if [ "$EX_DATAGEN" = "yes" ]; then
    # 3dBox cases share a common data/ directory
    if [[ "$EX_NAME" == 3dBox/* ]]; then
        DATA_SCRIPT="${EXAMPLES_DIR}/3dBox/data/setup.py"
        DATA_DIR="${EXAMPLES_DIR}/3dBox/data"
        MARKER="$DATA_DIR/data.pkl"
    elif [ -f "$EX_DIR/setup.py" ]; then
        DATA_SCRIPT="$EX_DIR/setup.py"
        DATA_DIR="$EX_DIR"
        MARKER="$EX_DIR/TRUE_RUN"
    else
        DATA_SCRIPT=""
        MARKER=""
    fi

    if [ -n "$DATA_SCRIPT" ] && [ -n "$MARKER" ] && [ ! -e "$MARKER" ]; then
        info "Generating synthetic data..."
        (cd "$DATA_DIR" && PATH="${VENV_DIR}/bin:$PATH" "$PYTHON" "$(basename "$DATA_SCRIPT")")
        ok "Data generated."
    elif [ -e "$MARKER" ]; then
        ok "Data already generated."
    fi
fi

# ── Select simulator if requested ─────────────────────────────────────
if [ -n "$SIMULATOR" ]; then
    FLOW_WRAPPER="$VENV_DIR/bin/${SIMULATOR}"

    if [ ! -f "$FLOW_WRAPPER" ]; then
        err "Simulator '$SIMULATOR' not installed. Available wrappers:"
        ls -1 "$VENV_DIR/bin"/flow* 2>/dev/null || echo "  (none)"
        echo ""
        info "Install with:"
        echo "  ./simulators/opm/install-docker.sh   # for flow-docker"
        echo "  ./simulators/opm/install.sh          # for flow (native)"
        exit 1
    fi

    # If flow-docker is requested, temporarily symlink flow -> flow-docker
    if [ "$SIMULATOR" = "flow-docker" ]; then
        info "Using Docker simulator"
        ln -sf flow-docker "$VENV_DIR/bin/flow"
    else
        info "Using native simulator"
    fi
fi

# ── Run the example ───────────────────────────────────────────────────
echo ""
info "━━━ Running: $EX_NAME ($EX_TYPE) ━━━"
info "  Script:    $EX_SCRIPT"
info "  Directory: $EX_DIR"
info "  Simulator: $EX_SIM${SIMULATOR:+ ($SIMULATOR mode)}"
echo ""

export PATH="${VENV_DIR}/bin:$PATH"
cd "$EX_DIR"

START=$SECONDS
"$PYTHON" "$EX_SCRIPT"
EXIT_CODE=$?
ELAPSED=$(( SECONDS - START ))

echo ""
if [ $EXIT_CODE -eq 0 ]; then
    ok "$EX_NAME completed in ${ELAPSED}s"
    if [ -d "$EX_DIR/SaveOutputs" ]; then
        info "Results saved to: $EX_DIR/SaveOutputs/"
        ls -1 "$EX_DIR/SaveOutputs/"
    fi
else
    err "$EX_NAME failed (exit code $EXIT_CODE) after ${ELAPSED}s"
fi

exit $EXIT_CODE
