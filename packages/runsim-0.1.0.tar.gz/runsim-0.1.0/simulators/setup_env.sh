#!/usr/bin/env bash
#
# setup_env.sh -- Bootstrap the Python environment and OPM Docker wrapper
#
# This script is idempotent: safe to run multiple times.
#
set -uo pipefail

source "$(cd "$(dirname "$0")" && pwd)/common.sh"

OPM_IMAGE="openporousmedia/opmreleases:latest"

# ── Python venv ────────────────────────────────────────────────────────
info "━━━ Python environment ━━━"

if [ ! -d "$VENV_DIR" ]; then
    info "Creating virtual environment at ${VENV_DIR}..."
    python3 -m venv "$VENV_DIR"
    "$PIP" install --upgrade pip -q 2>&1 | tail -1
    ok "Virtual environment created."
else
    ok "Virtual environment exists."
fi

# ── Install PET packages ─────────────────────────────────────────────
bash "${SIMULATORS_DIR}/pet/install.sh"

# ── Install runsim package ───────────────────────────────────────────
info "━━━ runsim package ━━━"
if ! "$PYTHON" -c "import runsim" 2>/dev/null; then
    info "Installing runsim package..."
    "$PIP" install -e "${PROJECT_DIR}" -q 2>&1 | tail -1
    ok "runsim installed."
else
    ok "runsim already installed."
fi

# ── Docker + OPM image ────────────────────────────────────────────────
info "━━━ OPM Docker image ━━━"

if ! command -v docker &>/dev/null; then
    err "Docker is not installed. Install Docker Desktop from https://docker.com/products/docker-desktop/"
    err "Some examples (analytic functions) will still work without it."
elif ! docker info &>/dev/null; then
    err "Docker daemon is not running. Start Docker Desktop."
    err "Some examples (analytic functions) will still work without it."
else
    if ! docker image inspect "$OPM_IMAGE" &>/dev/null; then
        info "Pulling ${OPM_IMAGE}..."
        docker pull "$OPM_IMAGE"
        ok "Image pulled."
    else
        ok "OPM Docker image already available."
    fi
fi

# ── flow-docker wrapper ───────────────────────────────────────────────
info "━━━ flow-docker wrapper ━━━"

cat > "$VENV_DIR/bin/flow-docker" << 'FLOW_WRAPPER'
#!/usr/bin/env bash
# Docker wrapper for OPM Flow -- mounts a broad directory tree to resolve
# relative INCLUDE paths in DATA files.
OPM_IMAGE="openporousmedia/opmreleases:latest"
CWD="$(pwd)"
MOUNT_ROOT="$CWD"
for _ in 1 2 3 4; do
    PARENT="$(dirname "$MOUNT_ROOT")"
    [ "$PARENT" = "$MOUNT_ROOT" ] && break
    MOUNT_ROOT="$PARENT"
done
ARGS=()
for arg in "$@"; do
    if [[ "$arg" == --output-dir=* ]]; then
        DIR="${arg#--output-dir=}"
        [[ "$DIR" != /* ]] && DIR="$CWD/$DIR"
        ARGS+=("--output-dir=/work${DIR#$MOUNT_ROOT}")
    elif [[ "$arg" == *.DATA ]]; then
        FILE="$arg"
        [[ "$FILE" != /* ]] && FILE="$CWD/$FILE"
        ARGS+=("/work${FILE#$MOUNT_ROOT}")
    else
        ARGS+=("$arg")
    fi
done
REL_CWD="${CWD#$MOUNT_ROOT}"
[ -z "$REL_CWD" ] && REL_CWD="/"
exec docker run --rm -v "$MOUNT_ROOT:/work" -w "/work${REL_CWD}" "$OPM_IMAGE" flow "${ARGS[@]}"
FLOW_WRAPPER
chmod +x "$VENV_DIR/bin/flow-docker"
ok "flow-docker wrapper created"
info "Note: To use native OPM Flow, run ./simulators/opm/install.sh"

# ── Done ──────────────────────────────────────────────────────────────
echo ""
ok "Environment ready. Activate with:"
echo "  source ${VENV_DIR}/bin/activate"
echo ""
ok "Or run examples directly with:"
echo "  ./runsim.sh pet --list"
