"""Tests for runsim base module."""

from pathlib import Path
from unittest.mock import patch

import pytest

from runsim import DuMux, OPMFlow, Simulator


class TestSimulatorBase:
    def test_abstract_class_cannot_instantiate(self):
        with pytest.raises(TypeError):
            Simulator(name="test")

    def test_explicit_executable(self):
        sim = OPMFlow(executable="/usr/bin/false")
        assert sim.executable == Path("/usr/bin/false")

    def test_repr(self):
        sim = OPMFlow(executable="/usr/bin/false")
        assert "OPMFlow" in repr(sim)
        assert "/usr/bin/false" in repr(sim)


class TestOPMFlow:
    def test_default_mode_is_native(self):
        sim = OPMFlow(executable="/usr/bin/false")
        assert sim.mode == "native"

    def test_docker_mode(self):
        sim = OPMFlow(mode="docker", executable="/usr/bin/false")
        assert sim.mode == "docker"

    def test_is_available_false_for_missing_binary(self):
        sim = OPMFlow(executable="/nonexistent/flow")
        assert sim.is_available() is False

    def test_version_not_installed(self):
        sim = OPMFlow(executable="/nonexistent/flow")
        assert sim.version() == "not installed"

    def test_run_builds_correct_command(self, tmp_path):
        deck = tmp_path / "TEST.DATA"
        deck.touch()
        output = tmp_path / "output"

        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            sim = OPMFlow(executable="/usr/bin/echo")
            sim.run(deck, output_dir=output, parsing_strictness="low")

        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "/usr/bin/echo"
        assert f"--output-dir={output.resolve()}" in cmd
        assert "--parsing-strictness=low" in cmd
        assert str(deck.resolve()) == cmd[-1]


class TestDuMux:
    def test_stub_not_available(self):
        sim = DuMux(executable="/nonexistent/dumux")
        assert sim.is_available() is False

    def test_run_builds_correct_command(self, tmp_path):
        input_file = tmp_path / "params.input"
        input_file.touch()
        output = tmp_path / "output"

        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            sim = DuMux(executable="/usr/bin/echo")
            sim.run(deck_file=input_file, output_dir=output)

        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "/usr/bin/echo"
        assert str(input_file.resolve()) in cmd


class TestHelpers:
    def test_find_in_paths_returns_existing(self, tmp_path):
        from runsim.base import find_in_paths

        f = tmp_path / "bin"
        f.touch()
        assert find_in_paths(f) == f

    def test_find_in_paths_returns_none_for_missing(self):
        from runsim.base import find_in_paths

        assert find_in_paths("/nonexistent/a", "/nonexistent/b") is None

    def test_find_on_path_finds_python(self):
        from runsim.base import find_on_path

        result = find_on_path("python3")
        assert result is not None
        assert result.name == "python3"

    def test_find_on_path_returns_none_for_missing(self):
        from runsim.base import find_on_path

        assert find_on_path("nonexistent_binary_xyz") is None
