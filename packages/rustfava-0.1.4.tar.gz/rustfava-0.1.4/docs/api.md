# API Reference

!!! note
    There's no stability guarantee as this is just for internal purposes currently.

## Core Modules

::: rustfava.core
    options:
      show_submodules: true

## Application

::: rustfava.application

## CLI

::: rustfava.cli
