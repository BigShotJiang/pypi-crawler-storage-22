<script lang="ts">
  import AddEntry from "./AddEntry.svelte";
  import Context from "./Context.svelte";
  import DocumentUpload from "./DocumentUpload.svelte";
  import Export from "./Export.svelte";
</script>

<AddEntry />
<Context />
<DocumentUpload />
<Export />
