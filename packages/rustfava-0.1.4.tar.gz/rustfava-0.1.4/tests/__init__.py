"""Rustfava tests."""
