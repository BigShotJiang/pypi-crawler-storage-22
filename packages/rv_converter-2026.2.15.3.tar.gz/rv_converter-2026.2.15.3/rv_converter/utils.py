import csv
import json
import os
from math import ceil
from typing import Dict, List, Optional

import pandas as pd
from openpyxl import load_workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font
from openpyxl.utils.cell import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from .constants import EXCEL_MAX_COLUMNS, EXCEL_MAX_ROWS
from .i18n import get_i18n

i18n = get_i18n()

try:
    import ijson

    HAS_IJSON = True
except ImportError:
    HAS_IJSON = False


def add_bold_count(ws: Worksheet, num_columns: int, num_rows: int) -> None:
    """Добавляет жирную строку с формулами SUBTOTAL для подсчёта заполненных ячеек.

    Использует SUBTOTAL(103, ...) — аналог COUNTA, который игнорирует
    скрытые (отфильтрованные) строки.

    Args:
        ws: Лист Excel для записи.
        num_columns: Количество столбцов.
        num_rows: Количество строк данных.
    """
    bold = Font(bold=True)

    data_start_row = 3  # Row 1 = counts, Row 2 = headers, Row 3+ = data
    data_end_row = data_start_row + num_rows - 1
    formulas = []
    for col_idx in range(1, num_columns + 1):
        col_letter = get_column_letter(col_idx)
        cell = WriteOnlyCell(
            ws,
            value=f"=SUBTOTAL(103,{col_letter}{data_start_row}:{col_letter}{data_end_row})",
        )
        cell.font = bold
        formulas.append(cell)

    ws.append(formulas)


def append_bold_header(header: list[str], ws: Worksheet) -> None:
    """Добавляет жирный заголовок к листу Excel.

    Args:
        header: Список заголовков для добавления.
        ws: Лист Excel для записи заголовков.
    """

    bold = Font(bold=True)
    cells = []
    for value in header:
        cell = WriteOnlyCell(ws, value=value)
        cell.font = bold
        cells.append(cell)
    ws.append(cells)


def add_filters(ws: Worksheet, num_columns: int, row: int) -> None:
    """Добавляет автофильтры к указанной строке листа Excel.

    Args:
        ws: Лист Excel для добавления фильтров.
        num_columns: Количество столбцов для фильтрации.
        row: Номер строки с заголовками.
    """
    ws.auto_filter.ref = f"A{row}:{get_column_letter(num_columns)}{row}"


SUPPORTED_INPUT_EXTENSIONS = (".json", ".jsonl", ".csv", ".xlsx")


def validate_input_file(input_file_path: str) -> bool:
    """Проверяет существование файла и его расширение.

    Args:
        input_file_path: Путь к файлу для проверки.

    Returns:
        True если файл существует и имеет корректное расширение, иначе False.
    """
    if not os.path.isfile(input_file_path):
        print(i18n.get("file_not_exist", input_file_path))
        return False

    ext = os.path.splitext(input_file_path)[1].lower()
    if ext not in SUPPORTED_INPUT_EXTENSIONS:
        print(i18n.get("file_not_supported", input_file_path))
        return False

    return True


def read_json_file(input_file_path: str) -> Optional[List[Dict]]:
    """Читает и парсит JSON-файл. Использует ijson при наличии для потоковой обработки.

    Args:
        input_file_path: Путь к JSON-файлу.

    Returns:
        Список объектов из файла или None при ошибке.
    """
    try:
        with open(input_file_path, "r", encoding="utf-8") as file:
            if HAS_IJSON:
                data = ijson.items(file, "item")
                return list(data)
            else:
                return json.load(file)
    except json.JSONDecodeError:
        print(i18n.get("file_invalid_json", input_file_path))
        return None
    except Exception as e:
        print(i18n.get("file_read_error", str(e)))
        return None


def read_jsonl_file(input_file_path: str) -> Optional[List[Dict]]:
    try:
        data = []
        with open(input_file_path, "r", encoding="utf-8") as file:
            for line in file:
                if not line.strip():
                    continue

                data.append(json.loads(line))
        return data
    except json.JSONDecodeError as e:
        print(i18n.get("file_invalid_jsonl", input_file_path, str(e)))
        return None
    except Exception as e:
        print(i18n.get("file_read_error", str(e)))
        return None


def read_csv_file(input_file_path: str) -> Optional[List[Dict]]:
    """Читает CSV-файл и возвращает список словарей.

    Args:
        input_file_path: Путь к CSV-файлу.

    Returns:
        Список словарей или None при ошибке.
    """
    try:
        with open(input_file_path, "r", encoding="utf-8") as file:
            reader = csv.DictReader(file)
            return list(reader)
    except Exception as e:
        print(i18n.get("file_read_error", str(e)))
        return None


def read_xlsx_file(input_file_path: str) -> Optional[List[Dict]]:
    """Читает XLSX-файл и возвращает список словарей.

    Читает первый лист. Пропускает ведущие строки, где все значения None
    (например, строки с формулами). Первая непустая строка используется как заголовки.

    Args:
        input_file_path: Путь к XLSX-файлу.

    Returns:
        Список словарей или None при ошибке.
    """
    try:
        wb = load_workbook(input_file_path, read_only=True, data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        wb.close()

        if not rows:
            return []

        # Skip leading rows where all values are None (e.g. SUBTOTAL formula rows)
        header_idx = 0
        for idx, row in enumerate(rows):
            if any(v is not None for v in row):
                header_idx = idx
                break

        headers = [
            str(h) if h is not None else f"col_{i}"
            for i, h in enumerate(rows[header_idx])
        ]
        data = []
        for row in rows[header_idx + 1 :]:
            entry = {}
            for key, val in zip(headers, row):
                entry[key] = val if val is not None else ""
            data.append(entry)
        return data
    except Exception as e:
        print(i18n.get("file_read_error", str(e)))
        return None


def load_data(filename: str) -> Optional[List[Dict]]:
    if not validate_input_file(filename):
        return None

    ext = os.path.splitext(filename)[1].lower()
    if ext == ".jsonl":
        return read_jsonl_file(filename)
    elif ext == ".csv":
        return read_csv_file(filename)
    elif ext == ".xlsx":
        return read_xlsx_file(filename)
    else:
        return read_json_file(filename)


def split_dataframe(df: pd.DataFrame) -> List[pd.DataFrame]:
    """Разбивает DataFrame на части по максимальному числу строк Excel.

    Args:
        df: DataFrame для разбиения.

    Returns:
        Список DataFrame-частей.
    """
    return [df[i : i + EXCEL_MAX_ROWS] for i in range(0, len(df), EXCEL_MAX_ROWS)]


def split_dataframe_by_columns(df: pd.DataFrame) -> List[pd.DataFrame]:
    """Разбивает DataFrame на части по максимальному числу столбцов Excel.

    Args:
        df: DataFrame для разбиения.

    Returns:
        Список DataFrame-частей.
    """
    num_chunks = ceil(df.shape[1] / EXCEL_MAX_COLUMNS)
    return [
        df.iloc[:, i * EXCEL_MAX_COLUMNS : (i + 1) * EXCEL_MAX_COLUMNS]
        for i in range(num_chunks)
    ]


def split_data(data: List[Dict]) -> List[List[Dict]]:
    """Разбивает список словарей на части по максимальному числу строк Excel.

    Args:
        data: Список словарей для разбиения.

    Returns:
        Список списков словарей.
    """
    return [data[i : i + EXCEL_MAX_ROWS] for i in range(0, len(data), EXCEL_MAX_ROWS)]
