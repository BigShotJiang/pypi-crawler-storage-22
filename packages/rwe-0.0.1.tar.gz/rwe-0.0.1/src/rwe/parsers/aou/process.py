import pandas as pd
import os
from tqdm import tqdm
import json
import numpy as np
from scipy import stats
import multiprocessing as mp
from scipy.stats import ks_2samp


def clean_measurements_helper(g):
    m = g["measurement"].iat[0]
    # 1) drop units (manual)
    drops = UNIT_DROPS.get(m, set())
    if drops:
        g = g[~g["unit"].isin(drops)].copy()
    if g.empty:
        return g
    # 2) convert units (manual)
    conv = UNIT_CONVERSIONS.get(m, {})
    for u, fn in conv.items():
        mask = g["unit"].eq(u)
        if mask.any():
            g.loc[mask, "median_value"] = fn(g.loc[mask, "median_value"].astype(float))
    # 3) plausible range filter
    lo, hi = PLAUSIBLE[m]
    g = g[g["median_value"].between(lo, hi)].copy()

    # 4) remove units present in < MIN_UNIT_N samples
    unit_counts = g["unit"].value_counts()
    keep_units = unit_counts[unit_counts >= 5].index
    g = g[g["unit"].isin(keep_units)].copy()
    if g.empty or g["unit"].nunique() == 1:
        return g
    
    # 5) dissimilar distributions via KS test vs most common unit
    ref_unit = g["unit"].value_counts().idxmax()
    ref = g.loc[g["unit"].eq(ref_unit), "median_value"].astype(float).dropna()

    keep = {ref_unit}
    for u, sub in g.groupby("unit"):
        if u == ref_unit:
            continue
        x = sub["median_value"].astype(float).dropna()
        res = ks_2samp(ref, x, alternative="two-sided", mode="auto")  # res.statistic, res.pvalue
        if (res.pvalue>=0.001) or (res.statistic<=0.25):
            keep.add(u)
    return g[g["unit"].isin(keep)].copy()

def clean_measurements():
    from rwe.parsers.aou.config import BUCKET, CDR, GOOGLE_PROJECT
    numerical_measurements_df = pd.read_parquet(f"{BUCKET}/data/rwe_info/raw/numerical_measurements.parquet")
    selected_nm_df = numerical_measurements_df.loc[
    numerical_measurements_df.measurement.isin(PLAUSIBLE.keys())
    ]
    cleaned_nm_df = selected_nm_df.groupby("measurement").apply(clean_measurements_helper).reset_index(drop=True)
    cleaned_nm_df.to_parquet(f"{BUCKET}/data/rwe_info/processed/selected_numerical_measurements.parquet")
    return

def clean_surveys():
    from rwe.parsers.aou.config import BUCKET, CDR, GOOGLE_PROJECT
    survey_df = pd.read_parquet(f"{BUCKET}/data/rwe_info/raw/survey_health.parquet")

    questions = [
    'Overall Health: General Health',
    'Overall Health: General Mental Health',
    'Overall Health: General Physical Health',
    'Overall Health: General Quality',
    ]

    selected_survey_df = survey_df.loc[survey_df.question.isin(questions)].copy()
    selected_survey_df.to_parquet(f"{BUCKET}/data/rwe_info/processed/selected_surveys.parquet")
    return

