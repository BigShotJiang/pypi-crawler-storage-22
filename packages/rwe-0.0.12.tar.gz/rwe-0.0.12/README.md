# Real world evidence of siRNA targets
The current pipeline generates a real world genetic evidence document of an siRNA target by providing phenotypic details of individuals carrying predicted loss of function mutations in that target from multiple biobanks. The report can be used for the following three broader utilities:
- Discover new target-indication pairs
- Safety evaluation of potential target
- Repurposing opportunity of existing target

# Description of the report
The report currently has the following sections:
- Variant information and demographics
- Clinical records
- Labs and measurements
- Survey information
- Homozygous loss of function carriers
- Indication specific report

Future updates might have the following additional sections:
- OpenTargets
- Plasma protein effect: https://azphewas.com/geneView/6319c068-fd59-46d8-85ee-82d82482eb14/APOC3/glr/continuous
- Knowledge portal networks: https://hugeamp.org/research.html?pageid=kpn_portals
- Genomics England information: https://www.genomicsengland.co.uk/
- Genes and Health information: https://www.genesandhealth.org/

## Variant information and demographics
### Variant information
Provides number of pLoF carriers across four variant categories in the All of Us cohort: 
- stop gained
- frameshift
- splice acceptor
- splice donor

### Demographics
Includes age, sex, ancestry and ethnicity information of pLoF carriers in comparison with non-carriers.

## Clinical records
Provides phenomewide association study results of pLoF carriers in All of Us and UK Biobank cohorts. The All of Us association results are generated in-house. The UK Biobank results are collected from genebass and astrazeneca open-source portal. 

## Labs and measurements
Provides lab results of pLoF carriers in All of Us cohort in comparison to the non-carriers. The following labs and measurements are currently being collected:
| Name of measurement | Concept ID (All of Us) | Category | Lower than baseline (clinical meaning) | Higher than baseline (clinical meaning) |
|:---|---:|:---|:---|:---|
| Body mass index (BMI) [Ratio] | 3038553 | Vitals / anthropometrics | Often indicates underweight or low body fat; may reflect malnutrition, chronic illness, or frailty. | Often indicates overweight/obesity; associated with insulin resistance and higher cardiometabolic risk. |
| Body height | 3036277 | Vitals / anthropometrics | If decreased vs prior: possible measurement error or age-related height loss (vertebral compression/kyphosis). Persistently low stature may reflect childhood growth disorders. | Tall stature can be constitutional; if extreme may suggest connective-tissue disorders (e.g., Marfan) or growth hormone excess (gigantism). |
| Body weight | 3025315 | Vitals / anthropometrics | Weight loss or low weight can reflect malnutrition, cachexia, dehydration, or endocrine/GI disease. | Weight gain/high weight may reflect obesity or fluid retention (edema, heart/renal failure). |
| Systolic blood pressure | 3004249 | Vitals / anthropometrics | Hypotension: possible dehydration, blood loss, sepsis, cardiogenic shock, or antihypertensive effects; may cause dizziness/syncope. | Hypertension: increased risk of stroke, MI, HF, CKD; may reflect primary or secondary hypertension. |
| Diastolic blood pressure | 3012888 | Vitals / anthropometrics | Low DBP may reflect hypotension or widened pulse pressure (e.g., arterial stiffness, aortic regurgitation); can reduce coronary perfusion in some patients. | High DBP suggests hypertension and increased cardiovascular risk, especially in younger adults. |
| Heart rate | 3027018 | Vitals / anthropometrics | Bradycardia: can be physiologic (athletes, sleep) or due to drugs (beta-blockers), conduction disease, or hypothyroidism. | Tachycardia: may reflect fever, pain, anxiety, hypovolemia, anemia, hyperthyroidism, or arrhythmia. |
| Hemoglobin [Mass/volume] in Blood | 3000963 | Hematology | Anemia: blood loss, iron/B12/folate deficiency, chronic disease, hemolysis, marrow suppression. | Polycythemia/hemoconcentration: dehydration, chronic hypoxia/smoking, or myeloproliferative disease. |
| Hematocrit [Volume Fraction] of Blood by Automated count | 3023314 | Hematology | Low hematocrit supports anemia or hemodilution. | High hematocrit suggests hemoconcentration or polycythemia; increases viscosity/thrombosis risk. |
| Erythrocytes [#/volume] in Blood by Automated count | 3020416 | Hematology | Low RBC count supports anemia (production loss, bleeding, hemolysis). | High RBC count suggests polycythemia or chronic hypoxia; may also reflect dehydration. |
| Erythrocyte distribution width [Entitic volume] | 3002888 | Hematology | Low RDW-SD is usually not clinically meaningful (uniform RBC size). | High RDW-SD indicates anisocytosis; seen with iron deficiency, B12/folate deficiency, mixed anemias, or recent transfusion. |
| MCV [Entitic volume] by Automated count | 3023599 | Hematology | Microcytosis: commonly iron deficiency or thalassemia; can occur in chronic inflammation/lead exposure. | Macrocytosis: B12/folate deficiency, alcohol use, liver disease, hypothyroidism, certain drugs, or reticulocytosis. |
| Platelets [#/volume] in Blood by Automated count | 3024929 | Hematology | Thrombocytopenia: bleeding risk; causes include marrow suppression, immune destruction (ITP), infection, liver disease, or consumption (DIC). | Thrombocytosis: reactive (inflammation, iron deficiency, postsplenectomy) or myeloproliferative; may raise thrombosis risk. |
| Monocytes [#/volume] in Blood by Automated count | 3033575 | Hematology | Low monocytes are often not clinically significant; can be seen with marrow suppression or steroid effect. | Monocytosis: chronic infection/inflammation, recovery phase of neutropenia, autoimmune disease, or myeloid neoplasm. |
| Eosinophils [#/volume] in Blood by Automated count | 3028615 | Hematology | Low eosinophils are usually not clinically significant; may be seen with stress or corticosteroids. | Eosinophilia: allergy/asthma, parasitic infection, drug reaction, adrenal insufficiency, or eosinophilic disorders. |
| Basophils [#/volume] in Blood by Automated count | 3013429 | Hematology | Low basophils are usually not clinically significant. | Basophilia: can occur in allergy/inflammation; classically associated with myeloproliferative neoplasms (e.g., CML). |
| Basophils [#/volume] in Blood | 3006315 | Hematology | Low basophils are usually not clinically significant. | Basophilia: allergy/inflammation or myeloproliferative neoplasm. |
| Basophils/100 leukocytes in Blood by Automated count | 3013869 | Hematology | Low percent basophils is usually not clinically significant. | High percent basophils (relative basophilia) may reflect allergy/inflammation or myeloproliferative disease. |
| Basophils/100 leukocytes in Blood by Manual count | 3009797 | Hematology | Low percent basophils is usually not clinically significant. | High percent basophils (relative basophilia) may reflect allergy/inflammation or myeloproliferative disease. |
| Basophils/100 leukocytes in Blood | 3013580 | Hematology | Low percent basophils is usually not clinically significant. | High percent basophils (relative basophilia) may reflect allergy/inflammation or myeloproliferative disease. |
| Immature granulocytes [#/volume] in Blood by Automated count | 3013209 | Hematology | Low/absent immature granulocytes is expected in healthy individuals. | Elevated immature granulocytes (left shift): acute infection/inflammation, physiologic stress, or marrow stimulation. |
| Immature granulocytes [#/volume] in Blood | 3033400 | Hematology | Low/absent immature granulocytes is expected in healthy individuals. | Elevated immature granulocytes (left shift): acute infection/inflammation, physiologic stress, or marrow stimulation. |
| Immature granulocytes/100 leukocytes in Blood by Automated count | 42869452 | Hematology | Low/near-zero percentage is typical in health. | High percentage suggests left shift from infection/inflammation, stress response, or marrow stimulation. |
| Immature granulocytes/100 leukocytes in Blood | 3025784 | Hematology | Low/near-zero percentage is typical in health. | High percentage suggests left shift from infection/inflammation, stress response, or marrow stimulation. |
| Nucleated erythrocytes [#/volume] in Blood by Automated count | 3023049 | Hematology | Absent/very low NRBCs is normal in adults. | Presence/elevation suggests marrow stress (severe hypoxia, hemolysis, hemorrhage), severe infection, or marrow infiltration; also normal in neonates. |
| Nucleated erythrocytes/100 leukocytes [Ratio] in Blood by Automated count | 40761514 | Hematology | Absent/very low ratio is normal in adults. | Elevated ratio indicates circulating NRBCs from marrow stress or severe illness (hypoxia, hemolysis, hemorrhage, sepsis). |
| Nucleated erythrocytes/100 leukocytes [Ratio] in Blood | 3007993 | Hematology | Absent/very low ratio is normal in adults. | Elevated ratio indicates circulating NRBCs from marrow stress or severe illness. |
| Leukocytes [#/volume] in Blood by Automated count | 3010813 | Hematology | Leukopenia: viral infection, marrow suppression, autoimmune disease, or chemotherapy; increases infection risk if severe. | Leukocytosis: infection/inflammation, stress/steroids, smoking, or hematologic malignancy. |
| Neutrophils [#/volume] in Blood by Automated count | 3000909 | Hematology | Neutropenia: increased risk for bacterial/fungal infection; causes include chemo, drugs, viral infection, autoimmune disease, marrow failure. | Neutrophilia: bacterial infection, inflammation, stress response, corticosteroids, or myeloproliferative disease. |
| Lymphocytes [#/volume] in Blood by Automated count | 3018974 | Hematology | Lymphopenia: immunosuppression (steroids), severe illness, HIV, autoimmune disease, or malnutrition. | Lymphocytosis: often viral infection; can indicate chronic lymphocytic leukemia or other lymphoproliferative disorders. |
| MCH [Entitic mass] by Automated count | 3000809 | Hematology | Low MCH suggests hypochromic microcytic anemia (often iron deficiency or thalassemia). | High MCH often accompanies macrocytosis (B12/folate deficiency, liver disease, alcohol). |
| MCHC [Mass/volume] by Automated count | 3008526 | Hematology | Low MCHC indicates hypochromia, commonly iron deficiency. | High MCHC may be seen with hereditary spherocytosis or some hemolytic states; can also be analytic artifact (e.g., cold agglutinins). |
| Erythrocyte distribution width [Ratio] by Automated count | 3008499 | Hematology | Low RDW% is usually not clinically meaningful. | High RDW% indicates anisocytosis; associated with iron/B12/folate deficiency, mixed anemia, or recent transfusion. |
| Platelet mean volume [Entitic volume] in Blood by Automated count | 3028132 | Hematology | Low MPV can suggest reduced platelet production (marrow suppression) in context of thrombocytopenia. | High MPV suggests larger/younger platelets (increased turnover, e.g., ITP) or inherited macrothrombocytopenias. |
| Creatinine [Mass/volume] in Serum or Plasma | 3016723 | Renal / electrolytes | Low creatinine often reflects low muscle mass, frailty, or pregnancy; less commonly severe liver disease. | High creatinine suggests reduced kidney function or acute kidney injury; can also rise with dehydration, high muscle mass, or rhabdomyolysis. |
| Urea nitrogen [Mass/volume] in Serum or Plasma | 3028287 | Renal / electrolytes | Low BUN can reflect low protein intake, malnutrition, liver dysfunction, or overhydration. | High BUN suggests reduced kidney function, dehydration, high protein catabolism, or GI bleeding. |
| Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD) | 46236952 | Renal / electrolytes | Lower eGFR indicates reduced kidney function/CKD (or AKI if acute). | Higher eGFR can reflect hyperfiltration (early diabetes), pregnancy, or low creatinine from low muscle mass. |
| Sodium [Moles/volume] in Serum or Plasma | 3019550 | Renal / electrolytes | Hyponatremia: excess free water (SIADH), heart/liver failure, diuretics, adrenal insufficiency; can cause confusion/seizures if severe. | Hypernatremia: water deficit/dehydration or diabetes insipidus; can cause neurologic symptoms. |
| Potassium [Moles/volume] in Serum or Plasma | 3023103 | Renal / electrolytes | Hypokalemia: GI loss, diuretics, alkalosis; can cause weakness and arrhythmias. | Hyperkalemia: renal failure, acidosis, tissue breakdown, RAAS-inhibiting drugs; can cause life-threatening arrhythmias. |
| Bicarbonate [Moles/volume] in Serum or Plasma | 3014576 | Renal / electrolytes | Low bicarbonate suggests metabolic acidosis (e.g., DKA, lactic acidosis, renal failure, diarrhea). | High bicarbonate suggests metabolic alkalosis (vomiting, diuretics) or compensation for chronic respiratory acidosis. |
| Chloride [Moles/volume] in Serum or Plasma | 3010156 | Renal / electrolytes | Hypochloremia: often with vomiting/NG suction or metabolic alkalosis; can also reflect dilutional states. | Hyperchloremia: metabolic acidosis (non–anion gap), dehydration, renal tubular acidosis, or large-volume normal saline. |
| Calcium [Mass/volume] in Serum or Plasma | 3006906 | Renal / electrolytes | Hypocalcemia: vitamin D deficiency, hypoparathyroidism, CKD; can cause paresthesias/tetany/seizures. | Hypercalcemia: primary hyperparathyroidism, malignancy, granulomatous disease, vitamin D excess; can cause stones, constipation, confusion. |
| Magnesium [Mass/volume] in Serum or Plasma | 3024328 | Renal / electrolytes | Hypomagnesemia: GI loss, diuretics, alcoholism; can cause arrhythmias and refractory hypokalemia/hypocalcemia. | Hypermagnesemia: usually renal failure or excess supplementation; can cause hypotension, bradycardia, respiratory depression. |
| Phosphate [Mass/volume] in Serum or Plasma | 3018920 | Renal / electrolytes | Hypophosphatemia: refeeding syndrome, hyperparathyroidism, insulin therapy; can cause muscle weakness/respiratory failure if severe. | Hyperphosphatemia: CKD, tumor lysis/rhabdomyolysis, hypoparathyroidism; contributes to vascular calcification. |
| Anion gap 3 in Serum or Plasma | 3003708 | Renal / electrolytes | Low anion gap most often reflects hypoalbuminemia; can also be lab artifact or paraproteinemia (e.g., multiple myeloma). | High anion gap indicates anion-gap metabolic acidosis (lactate, ketoacids, toxins, renal failure). |
| Albumin [Mass/volume] in Serum or Plasma | 3002752 | Liver / protein balance | Hypoalbuminemia: chronic liver disease, nephrotic syndrome, protein-losing enteropathy, malnutrition, or inflammation. | High albumin is uncommon and usually reflects dehydration/hemoconcentration. |
| Protein [Mass/volume] in Serum or Plasma | 3018302 | Liver / protein balance | Low total protein: malnutrition, liver disease, nephrotic syndrome, protein-losing enteropathy. | High total protein: dehydration or increased immunoglobulins (chronic inflammation or monoclonal gammopathy). |
| Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma | 3005755 | Liver / protein balance | Low ALT is usually not clinically significant. | High ALT suggests hepatocellular injury (viral hepatitis, NAFLD, ischemia, toxins/drugs). |
| Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma | 3013721 | Liver / protein balance | Low AST is usually not clinically significant. | High AST suggests hepatocellular injury and can also reflect muscle injury or hemolysis; interpret with ALT/CK. |
| Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma | 3012902 | Liver / protein balance | Low ALP is uncommon; can be seen with malnutrition, hypothyroidism, zinc deficiency, or hypophosphatasia. | High ALP suggests cholestasis/biliary obstruction or bone turnover (e.g., Paget, healing fracture); also rises in pregnancy. |
| Bilirubin.total [Mass/volume] in Serum or Plasma | 3024128 | Liver / protein balance | Low bilirubin is typically not clinically significant. | High bilirubin: jaundice; can be due to hemolysis, impaired conjugation (e.g., Gilbert), hepatocellular disease, or cholestasis/obstruction. |
| Glucose [Mass/volume] in Serum or Plasma | 3004501 | Metabolic | Hypoglycemia: excess insulin/sulfonylureas, adrenal insufficiency, severe liver disease, sepsis; can cause neuroglycopenic symptoms. | Hyperglycemia: diabetes, stress response, steroids; severe elevations risk DKA/HHS. |
| Hemoglobin A1c/Hemoglobin.total in Blood | 3004410 | Metabolic | Lower A1c usually reflects lower average glucose; if unexpectedly low, consider shortened RBC lifespan (hemolysis), recent blood loss, or transfusion. | Higher A1c indicates higher average glucose over ~2–3 months; supports diabetes/poor glycemic control. |
| Cholesterol [Mass/volume] in Serum or Plasma | 3007070 | Metabolic | Low total cholesterol can reflect malnutrition, hyperthyroidism, chronic illness, or liver disease. | High total cholesterol increases atherosclerotic cardiovascular risk depending on LDL/HDL fractions. |
| Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation | 3048961 | Metabolic | Low LDL is generally associated with lower ASCVD risk; very low levels can be seen with malabsorption, hyperthyroidism, or genetic hypolipidemias. | High LDL is strongly associated with increased ASCVD risk (familial hypercholesterolemia, diet, metabolic disease). |
| Cholesterol in HDL [Mass/volume] in Serum or Plasma | 3007215 | Metabolic | Low HDL is associated with higher cardiometabolic/ASCVD risk and often accompanies metabolic syndrome. | Higher HDL is often associated with lower ASCVD risk, though extremely high levels can be genetic and not always protective. |
| Triglyceride [Mass/volume] in Serum or Plasma | 3022192 | Metabolic | Low triglycerides are usually benign; can reflect low fat intake or malnutrition. | High triglycerides: insulin resistance, alcohol use, hypothyroidism, genetic causes; very high levels increase pancreatitis risk. |
| Thyroxine (T4) free [Mass/volume] in Serum or Plasma | 3018617 | Metabolic | Low free T4 suggests hypothyroidism (primary or central) depending on TSH context. | High free T4 suggests hyperthyroidism or excess thyroid hormone; interpret with TSH and clinical context. |
| 25-Hydroxyvitamin D3+25-Hydroxyvitamin D2 [Mass/volume] in Serum or Plasma | 40765040 | Metabolic | Low 25(OH)D suggests vitamin D deficiency/insufficiency (risk for osteomalacia, fractures). | High 25(OH)D suggests excessive supplementation; can cause hypercalcemia and toxicity. |
| Protein [Mass/volume] in Urine by Test strip | 3033235 | Urine / kidney damage | Negative/low protein is generally normal. | Higher protein on dipstick suggests proteinuria (glomerular disease, diabetic nephropathy) or transient causes (UTI, fever, exercise). |
| Leukocytes [#/area] in Urine sediment by Microscopy high power field | 3013483 | Urine / kidney damage | Low/none is normal. | High urine WBCs (pyuria) suggests UTI, interstitial nephritis, or urinary tract inflammation. |
| Erythrocytes [#/area] in Urine sediment by Microscopy high power field | 3013984 | Urine / kidney damage | Low/none is normal. | High urine RBCs (hematuria) suggests stones, infection, glomerulonephritis, trauma, or urologic malignancy. |
| Epithelial cells.squamous [#/area] in Urine sediment by Microscopy high power field | 3035405 | Urine / kidney damage | Low squamous cells suggests a cleaner (less contaminated) specimen. | High squamous cells often indicates sample contamination (poor clean-catch technique). |
| Albumin/Creatinine [Mass Ratio] in Urine | 3034485 | Urine / kidney damage | Low ACR is normal (minimal albumin excretion). | High ACR indicates albuminuria—kidney damage often from diabetes or hypertension; higher levels predict CKD/CV risk. |
| C reactive protein [Mass/volume] in Serum or Plasma | 3000968 | Inflammation | Low CRP is expected and suggests absence of significant systemic inflammation. | High CRP indicates acute-phase inflammation (infection, autoimmune flare, tissue injury); persistent elevation can reflect chronic inflammation. |
| Erythrocyte sedimentation rate by Westergren method | 3007529 | Inflammation | Low ESR is usually not clinically significant; can be seen with polycythemia or some RBC abnormalities. | High ESR is nonspecific for inflammation/infection, autoimmune disease, malignancy, or anemia. |
| Natriuretic peptide B [Mass/volume] in Serum or Plasma | 3034939 | Cardiac biomarkers | Low BNP is generally reassuring against significant heart failure in the right clinical context. | High BNP suggests myocardial wall stress/heart failure; can also rise with renal dysfunction, older age, and pulmonary hypertension. |
| Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma | 3034840 | Cardiac biomarkers | Low NT-proBNP is generally reassuring against significant heart failure in the right clinical context. | High NT-proBNP suggests heart failure/wall stress; also increases with age and reduced kidney function. |
| Troponin I.cardiac [Mass/volume] in Serum or Plasma | 3021337 | Cardiac biomarkers | Undetectable/low troponin is expected (no evidence of myocardial injury at that time). | Elevated troponin indicates myocardial injury (MI, myocarditis, demand ischemia); can be chronically elevated in CKD. |
| Creatine kinase [Enzymatic activity/volume] in Serum or Plasma | 3000959 | Cardiac biomarkers | Low CK is usually not clinically significant; can reflect low muscle mass. | High CK indicates muscle injury (exercise, myositis, rhabdomyolysis) and can rise with MI; interpret with symptoms and troponin. |

## Survey information
Includes self-reported survey information about general, mental, physical and overall health of pLoF carriers in comparison with non-carriers in the All of Us cohort.

## Homozygous loss of function carriers
Provides demographics and survey information of the biallelic lof variant carriers in All of Us.

## Indication specific report
Provides association results for user specified indications from All of Us and UK Biobank cohorts. 

# Resources used to generate the report

## Controlled Datasets

### All of Us
The All of Us cohort currently consists of 420k participants with whole genome sequencing and phenotypic data. 

## Open Source Databases
Here we describe the open source databases used for gathering evidence about the targets:

### GeneBass
GeneBass reports phenomewide associations for LoF carriers among 380k participants from the UK Biobank cohort.

### AstraZeneca PheWAS portal
AstraZeneca reports phenomewide associations for LoF carriers among 500k participants from the UK Biobank cohort.

# Updates and Installation
## v0.0.8
Now includes labs and measurements from UKB through AZN and GeneBass portals.

## v0.0.6
Provides biallelic loss of function carrier information as a new section: Homozygous loss of function carriers to the report.

## v0.0.5
First working version. Generates a report in docx format that includes variant information, demographics, clinical records, and survey information. All individual level data is obtained from All of Us where as summary statistics are obtained from All of Us and UK Biobank cohorts.

## Internal Use for installation
```bash
python -m pip install -U pip build
python -m build
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install dist/rwe-0.0.1-py3-none-any.whl
python -c "import rwe; print('import ok')"

pip install twine
twine upload dist/*


conda install -c conda-forge python=3.12
pip install -r requirements.txt
playwright install
python -m playwright install-deps

# New version
rm -rf dist build *.egg-info src/*.egg-info
python -m build
pip install dist/rwe-0.0.11-py3-none-any.whl
python -c "from rwe.generate_report import generate_rwe_report; print('import ok')"
twine upload dist/*
```

# Resources
1. ICD to Phecode mappings: https://www.vumc.org/wei-lab/sites/default/files/public_files/ICD_to_Phecode_mapping.csv
