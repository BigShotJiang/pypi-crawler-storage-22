import os
import pandas as pd

import matplotlib
matplotlib.use("Agg")  # important for batch/report generation (no display)

import rwe.utils.report as utr
from rwe.utils.keywords import disease_to_keywords


# ---------- Main user-facing function ----------

def generate_rwe_report(
    gene: str,
    chrm: str,
    out_docx_path: str = "",
    logo_path: str = "",
    report_date: str = "",
    indications: str = ""
):
    """
    Creates a DOCX report with:
      - Title page
      - Contents (TOC field)
      - Five section headers
      - Variant information + Demographics figures inserted into section 1

    Parameters
    ----------
    gene : str
    chrm : str
    out_docx_path : str
    logo_path : optional str (path to Arrowhead logo PNG/JPG)
    report_date : optional str (e.g. "January 26th, 2026")
    indications : optional str (e.g. "obesity,diabetes")
    """
    if not out_docx_path:
        out_docx_path = f"./rwe_reports/{gene}_RWE_report.docx"
    proj_dir = os.path.dirname(out_docx_path)
    os.makedirs(proj_dir, exist_ok=True)

    # --- Title and Contents --- #
    doc = utr.generate_title_and_contents(gene, logo_path=logo_path, report_date=report_date)

    # --- Variant information and demographics --- #
    doc = utr.generate_variant_information_and_demographics(doc, chrm, gene, "hetz")

    # --- Clinical records --- #
    doc = utr.generate_clinical_records(doc, chrm, gene, "hetz", proj_dir)
    
    # --- Labs and measurements --- #
    doc = utr.generate_labs_and_measurements(doc, chrm, gene, "hetz", proj_dir)

    # --- Survey information --- #
    doc = utr.generate_survey_information(doc, chrm, gene, "hetz", proj_dir)

    # --- Homozygous loss of function carriers --- #
    doc = utr.generate_homozygous_lof_carriers(doc, chrm, gene, proj_dir)

    # --- Plasma proteomics --- #
    doc = utr.generate_plasma_proteomics_report(doc, chrm, gene, proj_dir)

    # --- Indication-specific report --- #
    if indications:
        indications = [i.strip() for i in indications.split(",")]
        keywords = sum([disease_to_keywords[i] for i in indications if i in disease_to_keywords], [])
        if keywords:
            doc = utr.generate_indication_specific_report(doc, chrm, gene, proj_dir, indications, keywords)
        else:
            print(f"Warning: no keywords found for indications {indications}; skipping indication-specific report")

    # --- End of report --- #
    doc = utr.generate_end_of_report(doc)

    # Save
    doc.save(out_docx_path)
    return out_docx_path

if __name__ == "__main__":
    import pandas as pd
