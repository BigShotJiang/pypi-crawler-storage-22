########################################################################################################
# Simple RWKV-7 Training Script - Pure PyTorch (No CUDA Kernel Required)
# For small data validation and quick experiments
########################################################################################################

import torch
import torch.nn as nn
from torch.nn import functional as F
import numpy as np
from torch.utils.data import Dataset, DataLoader

# Set default dtype
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.allow_tf32 = True
torch.backends.cuda.matmul.allow_tf32 = True


def RWKV7_OP(r, w, k, v, a, b, head_size=64):
    """
    Pure PyTorch implementation of RWKV-7 attention (no CUDA kernel needed).
    Slower but works on any PyTorch setup.
    """
    B, T, C = r.size()
    H = C // head_size
    N = head_size
    
    # Convert to float for computation
    r = r.view(B, T, H, N).float()
    k = k.view(B, T, H, N).float()
    v = v.view(B, T, H, N).float()
    a = a.view(B, T, H, N).float()
    b = b.view(B, T, H, N).float()
    w = torch.exp(-torch.exp(w.view(B, T, H, N).float()))
    
    out = torch.zeros((B, T, H, N), device=r.device, dtype=torch.float)
    state = torch.zeros((B, H, N, N), device=r.device, dtype=torch.float)

    for t in range(T):
        kk = k[:, t, :].view(B, H, 1, N)
        rr = r[:, t, :].view(B, H, N, 1)
        vv = v[:, t, :].view(B, H, N, 1)
        aa = a[:, t, :].view(B, H, N, 1)
        bb = b[:, t, :].view(B, H, 1, N)
        state = state * w[:, t, :, None, :] + state @ aa @ bb + vv @ kk
        out[:, t, :] = (state @ rr).view(B, H, N)

    return out.view(B, T, C).to(dtype=r.dtype)


class RWKV_Tmix_x070(nn.Module):
    def __init__(self, n_embd, n_layer, layer_id, head_size=64, 
                 d_decay_lora=64, d_aaa_lora=64, d_mv_lora=32, d_gate_lora=128):
        super().__init__()
        self.n_embd = n_embd
        self.n_layer = n_layer
        self.layer_id = layer_id
        self.head_size = head_size
        self.n_head = n_embd // head_size
        
        H = self.n_head
        N = head_size
        C = n_embd
        
        self.x_r = nn.Parameter(torch.empty(1, 1, C))
        self.x_w = nn.Parameter(torch.empty(1, 1, C))
        self.x_k = nn.Parameter(torch.empty(1, 1, C))
        self.x_v = nn.Parameter(torch.empty(1, 1, C))
        self.x_a = nn.Parameter(torch.empty(1, 1, C))
        self.x_g = nn.Parameter(torch.empty(1, 1, C))

        self.w0 = nn.Parameter(torch.empty(1, 1, C))
        self.w1 = nn.Parameter(torch.empty(C, d_decay_lora))
        self.w2 = nn.Parameter(torch.empty(d_decay_lora, C))

        self.a0 = nn.Parameter(torch.empty(1, 1, C))
        self.a1 = nn.Parameter(torch.empty(C, d_aaa_lora))
        self.a2 = nn.Parameter(torch.empty(d_aaa_lora, C))

        self.v0 = nn.Parameter(torch.empty(1, 1, C))
        self.v1 = nn.Parameter(torch.empty(C, d_mv_lora))
        self.v2 = nn.Parameter(torch.empty(d_mv_lora, C))

        self.g1 = nn.Parameter(torch.empty(C, d_gate_lora))
        self.g2 = nn.Parameter(torch.empty(d_gate_lora, C))

        self.k_k = nn.Parameter(torch.empty(1, 1, C))
        self.k_a = nn.Parameter(torch.empty(1, 1, C))
        self.r_k = nn.Parameter(torch.empty(H, N))

        self.time_shift = nn.ZeroPad2d((0, 0, 1, -1))
        self.receptance = nn.Linear(C, C, bias=False)
        self.key = nn.Linear(C, C, bias=False)
        self.value = nn.Linear(C, C, bias=False)
        self.output = nn.Linear(C, C, bias=False)
        self.ln_x = nn.GroupNorm(H, C, eps=64e-5)

    def forward(self, x, v_first):
        B, T, C = x.size()
        H = self.n_head
        xx = self.time_shift(x) - x

        xr = x + xx * self.x_r
        xw = x + xx * self.x_w
        xk = x + xx * self.x_k
        xv = x + xx * self.x_v
        xa = x + xx * self.x_a
        xg = x + xx * self.x_g

        r = self.receptance(xr)
        w = -F.softplus(-(self.w0 + torch.tanh(xw @ self.w1) @ self.w2)) - 0.5
        k = self.key(xk)
        v = self.value(xv)
        
        if self.layer_id == 0:
            v_first = v
        else:
            v = v + (v_first - v) * torch.sigmoid(self.v0 + (xv @ self.v1) @ self.v2)
            
        a = torch.sigmoid(self.a0 + (xa @ self.a1) @ self.a2)
        g = torch.sigmoid(xg @ self.g1) @ self.g2

        kk = k * self.k_k
        kk = F.normalize(kk.view(B, T, H, -1), dim=-1, p=2.0).view(B, T, C)
        k = k * (1 + (a - 1) * self.k_a)

        x = RWKV7_OP(r, w, k, v, -kk, kk * a, self.head_size)
        x = self.ln_x(x.view(B * T, C)).view(B, T, C)
        
        x = x + ((r.view(B, T, H, -1) * k.view(B, T, H, -1) * self.r_k).sum(dim=-1, keepdim=True) * v.view(B, T, H, -1)).view(B, T, C)
        x = self.output(x * g)
        return x, v_first


class RWKV_CMix_x070(nn.Module):
    def __init__(self, n_embd, dim_ffn=None):
        super().__init__()
        if dim_ffn is None:
            dim_ffn = n_embd * 4
        self.time_shift = nn.ZeroPad2d((0, 0, 1, -1))
        self.x_k = nn.Parameter(torch.empty(1, 1, n_embd))
        self.key = nn.Linear(n_embd, dim_ffn, bias=False)
        self.value = nn.Linear(dim_ffn, n_embd, bias=False)

    def forward(self, x):
        xx = self.time_shift(x) - x
        k = x + xx * self.x_k
        k = torch.relu(self.key(k)) ** 2
        return self.value(k)


class Block(nn.Module):
    def __init__(self, n_embd, n_layer, layer_id, head_size=64):
        super().__init__()
        self.layer_id = layer_id
        self.ln0 = nn.LayerNorm(n_embd) if layer_id == 0 else None
        self.ln1 = nn.LayerNorm(n_embd)
        self.ln2 = nn.LayerNorm(n_embd)
        self.att = RWKV_Tmix_x070(n_embd, n_layer, layer_id, head_size)
        self.ffn = RWKV_CMix_x070(n_embd)

    def forward(self, x, v_first):
        if self.layer_id == 0:
            x = self.ln0(x)
        xx, v_first = self.att(self.ln1(x), v_first)
        x = x + xx
        x = x + self.ffn(self.ln2(x))
        return x, v_first


class RWKV7(nn.Module):
    def __init__(self, vocab_size, n_layer=6, n_embd=512, head_size=64, ctx_len=1024):
        super().__init__()
        self.vocab_size = vocab_size
        self.n_layer = n_layer
        self.n_embd = n_embd
        self.ctx_len = ctx_len
        
        self.emb = nn.Embedding(vocab_size, n_embd)
        self.blocks = nn.ModuleList([Block(n_embd, n_layer, i, head_size) for i in range(n_layer)])
        self.ln_out = nn.LayerNorm(n_embd)
        self.head = nn.Linear(n_embd, vocab_size, bias=False)

    def forward(self, idx):
        B, T = idx.size()
        x = self.emb(idx)
        v_first = None
        
        for block in self.blocks:
            x, v_first = block(x, v_first)
            
        x = self.ln_out(x)
        return self.head(x)

    def generate_init_weight(self):
        """Initialize model weights"""
        print(f"Initializing model weights...")
        for name, m in self.named_parameters():
            if 'emb' in name:
                nn.init.uniform_(m, -0.0001, 0.0001)
            elif 'head' in name:
                nn.init.uniform_(m, -0.01, 0.01)
            elif 'ln' in name or 'norm' in name:
                if 'weight' in name:
                    nn.init.ones_(m)
                elif 'bias' in name:
                    nn.init.zeros_(m)
            else:
                nn.init.orthogonal_(m, gain=1.0)
        print("Weight initialization complete.")


class SimpleSequenceDataset(Dataset):
    """Simple dataset for sequence data"""
    def __init__(self, data, ctx_len):
        """
        Args:
            data: numpy array of shape (num_sequences, sequence_length) or (total_tokens,)
            ctx_len: context length for training
        """
        if data.ndim == 2:
            # (num_sequences, sequence_length) -> flatten
            data = data.reshape(-1)
        self.data = torch.from_numpy(data).long()
        self.ctx_len = ctx_len
        self.data_size = len(self.data)
        
    def __len__(self):
        return max(1, self.data_size - self.ctx_len)
    
    def __getitem__(self, idx):
        # Random sampling
        start = torch.randint(0, self.data_size - self.ctx_len - 1, (1,)).item()
        chunk = self.data[start:start + self.ctx_len + 1]
        x = chunk[:-1]
        y = chunk[1:]
        return x, y


def train_rwkv7_simple(
    data,
    work_dir,
    vocab_size=361,
    n_layer=6,
    n_embd=512,
    ctx_len=1024,
    head_size=64,
    num_epochs=100,
    batch_size=8,
    lr_init=6e-4,
    lr_final=6e-5,
    warmup_steps=10,
    device='cuda' if torch.cuda.is_available() else 'cpu'
):
    """
    Simple training function for RWKV-7 on small data.
    
    Args:
        data: numpy array of shape (num_sequences, sequence_length)
        work_dir: output directory
        vocab_size: vocabulary size
        n_layer: number of layers
        n_embd: embedding dimension
        ctx_len: context length
        head_size: head size for attention
        num_epochs: number of epochs
        batch_size: batch size
        lr_init: initial learning rate
        lr_final: final learning rate
        warmup_steps: warmup steps
        device: 'cuda' or 'cpu'
    """
    import os
    os.makedirs(work_dir, exist_ok=True)
    
    print("="*60)
    print("RWKV-7 Simple Trainer (Pure PyTorch)")
    print("="*60)
    print(f"Device: {device}")
    print(f"Data shape: {data.shape}")
    print(f"Vocab size: {vocab_size}")
    print(f"Layers: {n_layer}, Embedding: {n_embd}, Context: {ctx_len}")
    print(f"Epochs: {num_epochs}, Batch size: {batch_size}")
    print("="*60)
    
    # Create model
    model = RWKV7(vocab_size, n_layer, n_embd, head_size, ctx_len).to(device)
    model.generate_init_weight()
    
    # Count parameters
    num_params = sum(p.numel() for p in model.parameters())
    print(f"Total parameters: {num_params:,}")
    
    # Create dataset
    dataset = SimpleSequenceDataset(data, ctx_len)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    
    # Optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=lr_init, betas=(0.9, 0.99), eps=1e-18)
    
    # Learning rate scheduler
    def get_lr(step, total_steps):
        if step < warmup_steps:
            return lr_init * step / warmup_steps
        progress = (step - warmup_steps) / (total_steps - warmup_steps)
        return lr_init + (lr_final - lr_init) * progress
    
    # Training loop
    model.train()
    step = 0
    total_steps = num_epochs * len(dataloader)
    
    for epoch in range(num_epochs):
        epoch_loss = 0.0
        num_batches = 0
        
        for batch_idx, (x, y) in enumerate(dataloader):
            x, y = x.to(device), y.to(device)
            
            # Forward
            logits = model(x)
            loss = F.cross_entropy(logits.view(-1, vocab_size), y.view(-1))
            
            # Backward
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            # Update LR
            step += 1
            lr = get_lr(step, total_steps)
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr
            
            epoch_loss += loss.item()
            num_batches += 1
            
            if batch_idx % 10 == 0:
                print(f"Epoch {epoch+1}/{num_epochs}, Batch {batch_idx}/{len(dataloader)}, Loss: {loss.item():.4f}, LR: {lr:.6f}")
        
        avg_loss = epoch_loss / num_batches
        print(f"Epoch {epoch+1} completed. Average loss: {avg_loss:.4f}")
        
        # Save checkpoint
        if (epoch + 1) % 10 == 0 or epoch == num_epochs - 1:
            checkpoint_path = os.path.join(work_dir, f'rwkv-epoch-{epoch+1}.pth')
            torch.save({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': avg_loss,
            }, checkpoint_path)
            print(f"Checkpoint saved: {checkpoint_path}")
    
    # Save final model
    final_path = os.path.join(work_dir, 'rwkv-final.pth')
    torch.save(model.state_dict(), final_path)
    print(f"\nTraining complete! Final model saved: {final_path}")
    
    return model


if __name__ == "__main__":
    # Test with random data
    print("Testing RWKV-7 Simple Trainer...")
    
    # Generate random test data (5 sequences, 512 tokens each)
    test_data = np.random.randint(0, 361, size=(5, 512))
    
    model = train_rwkv7_simple(
        data=test_data,
        work_dir='./test_simple',
        vocab_size=361,
        n_layer=2,
        n_embd=64,
        ctx_len=512,
        head_size=64,
        num_epochs=2,
        batch_size=1,
        lr_init=1e-4,
        lr_final=1e-5,
        device='cpu'  # Use CPU for testing
    )
    
    print("Test completed successfully!")
