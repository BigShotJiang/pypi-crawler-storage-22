########################################################################################################
# Simple Random Sampling Dataset for Small Data
# Bypasses RWKV's magic_prime sampling logic entirely
########################################################################################################

import numpy as np
import torch
from torch.utils.data import Dataset
from pytorch_lightning.utilities import rank_zero_info
from data_utils.binidx import MMapIndexedDataset


class SimpleRandomDataset(Dataset):
    """
    Simple dataset for small data that uses pure random sampling.
    
    This bypasses RWKV's magic_prime sampling logic which requires
    large datasets (magic_prime / dataset_slot > 0.9).
    
    Usage:
        dataset = SimpleRandomDataset(
            data_file='/path/to/data',
            ctx_len=512,
            vocab_size=361
        )
    """
    
    def __init__(self, data_file, ctx_len, vocab_size):
        self.ctx_len = ctx_len
        self.vocab_size = vocab_size
        
        # Load data from binidx file
        self.data = MMapIndexedDataset(data_file)
        self.data_size = len(self.data._bin_buffer) // self.data._index._dtype_size
        
        rank_zero_info(f"[SimpleRandomDataset] Data has {self.data_size} tokens.")
        rank_zero_info(f"[SimpleRandomDataset] Context length: {ctx_len}")
        rank_zero_info(f"[SimpleRandomDataset] Effective sequences: {self.data_size // ctx_len}")
        
        # Calculate number of valid starting positions
        # We need ctx_len + 1 tokens for each sample (input + target)
        self.num_samples = max(1, self.data_size - ctx_len)
        
    def __len__(self):
        # Return a fixed large number for "infinite" epochs
        # The actual sampling is random, so we can keep sampling
        return 100000
    
    def __getitem__(self, idx):
        """
        Get a random sample from the data.
        
        Args:
            idx: Ignored (random sampling)
            
        Returns:
            x: Input tokens [ctx_len]
            y: Target tokens [ctx_len]
        """
        # Pick a random starting position
        start_pos = np.random.randint(0, self.num_samples)
        
        # Get ctx_len + 1 tokens
        dix = self.data.get(idx=0, offset=start_pos, length=self.ctx_len + 1).astype(int)
        
        # Split into input (x) and target (y)
        x = torch.tensor(dix[:-1], dtype=torch.long)
        y = torch.tensor(dix[1:], dtype=torch.long)
        
        return x, y
