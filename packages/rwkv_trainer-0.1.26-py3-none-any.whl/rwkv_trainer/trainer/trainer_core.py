"""
RWKV Training Core - Direct function interface for packaged use

This module provides a direct Python API for RWKV training,
eliminating the need for subprocess calls to train.py.
"""

import os
import sys
from pathlib import Path
from typing import Optional, Dict, Any
import logging

# Set default environment variables before importing RWKV modules
# These are required by model.py at import time
os.environ.setdefault("RWKV_MY_TESTING", "x070")
os.environ.setdefault("RWKV_JIT_ON", "1")
os.environ.setdefault("RWKV_HEAD_SIZE_A", "64")
os.environ.setdefault("RWKV_CTXLEN", "1024")
os.environ.setdefault("RWKV_FLOAT_MODE", "bf16")  # bf16, fp16, or fp32

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import RWKV components (works both in dev and installed package)
try:
    from ..model.model import RWKV
    from ..trainer.trainer_module import train_callback, generate_init_weight
    from ..data_utils.binidx import MMapIndexedDataset
    from ..data_utils.utils import MaybeIsPrime
except ImportError:
    # When installed as package
    from rwkv_trainer.model.model import RWKV
    from rwkv_trainer.trainer.trainer_module import train_callback, generate_init_weight
    from rwkv_trainer.data_utils.binidx import MMapIndexedDataset
    from rwkv_trainer.data_utils.utils import MaybeIsPrime

import pytorch_lightning as pl
from pytorch_lightning import Trainer
from pytorch_lightning.utilities import rank_zero_info, rank_zero_only


def run_training(
    # Data parameters
    data_file: str,
    data_type: str = "binidx",
    vocab_size: int = 0,
    
    # Model parameters
    n_layer: int = 6,
    n_embd: int = 512,
    dim_att: int = 0,
    dim_ffn: int = 0,
    ctx_len: int = 1024,
    
    # Training parameters
    epoch_steps: int = 1000,
    epoch_count: int = 500,
    epoch_begin: int = 0,
    epoch_save: int = 5,
    micro_bsz: int = 12,
    
    # Optimizer parameters
    lr_init: float = 6e-4,
    lr_final: float = 1e-5,
    warmup_steps: int = -1,
    beta1: float = 0.9,
    beta2: float = 0.99,
    adam_eps: float = 1e-8,
    grad_cp: int = 0,
    dropout: float = 0,
    weight_decay: float = 0.0,
    grad_clip: float = 1.0,
    
    # Advanced parameters
    head_size_a: int = 64,
    head_size_divisor: int = 8,
    layerwise_lr: int = 1,
    ds_bucket_mb: int = 200,
    
    # Stage parameters
    my_pile_stage: int = 0,
    my_pile_version: int = 1,
    magic_prime: int = 0,
    my_exit_tokens: int = 0,
    
    # Model type and testing
    my_testing: str = 'x052',
    my_exit: int = 99999999,
    
    # Checkpoint and paths
    load_model: str = "",
    proj_dir: str = "out",
    random_seed: int = -1,
    
    # Device parameters
    accelerator: str = "gpu",
    strategy: str = "auto",
    devices: int = 1,
    num_nodes: int = 1,
    precision: str = "fp16",
    
    # Wandb
    wandb: str = "",
    
    # Additional flags
    pre_ffn: int = 0,
    head_qk: int = 0,
    tiny_att_dim: int = 0,
    tiny_att_layer: int = -999,
    my_pile_shift: int = -1,
    my_pile_edecay: int = 0,
    my_sample_len: int = 0,
    my_ffn_shift: int = 1,
    my_att_shift: int = 1,
    my_pos_emb: int = 0,
    load_partial: int = 0,
    my_qa_mask: int = 0,
    my_random_steps: int = 0,
    weight_decay_final: float = -1,
    accumulate_grad_batches: int = 1,
    
    # Training type
    train_type: str = "",
) -> None:
    """
    Run RWKV training directly without subprocess.
    
    This is the core training function that replaces the command-line interface.
    All parameters are the same as the original train.py arguments.
    """
    
    # Create args namespace to mimic argparse output
    import types
    args = types.SimpleNamespace(**locals())
    
    # Convert Path to string for data_file (required by MMapIndexedDataset)
    args.data_file = str(args.data_file)
    
    # Handle dimension defaults
    if args.dim_att == 0:
        args.dim_att = args.n_embd
    if args.dim_ffn == 0:
        args.dim_ffn = int((args.n_embd * 3.5) // 32 * 32)
    
    # Setup directories
    proj_dir = Path(args.proj_dir)
    proj_dir.mkdir(parents=True, exist_ok=True)
    
    # Log info
    rank_zero_info("########## RWKV Trainer (Direct API) ##########")
    rank_zero_info(f"Project directory: {args.proj_dir}")
    rank_zero_info(f"Model: {args.n_layer} layers, {args.n_embd} dim, {args.ctx_len} ctx")
    rank_zero_info(f"Training: {args.epoch_count} epochs, batch {args.micro_bsz}")
    
    # Create model
    model = RWKV(args)
    
    # Setup data
    if args.data_type == "binidx":
        train_data = MMapIndexedDataset(args.data_file)
        args.my_exit_tokens = len(train_data) * args.ctx_len
    else:
        raise ValueError(f"Unsupported data type: {args.data_type}")
    
    # Setup callbacks
    callbacks = [train_callback(args)]
    
    # Setup trainer
    trainer_kwargs = {
        "max_epochs": args.epoch_count,
        "devices": args.devices,
        "num_nodes": args.num_nodes,
        "gradient_clip_val": args.grad_clip,
        "callbacks": callbacks,
        "enable_progress_bar": True,
        "logger": False,
    }
    
    # Handle precision and accelerator based on PyTorch Lightning version
    if pl.__version__[0] == '2':
        trainer_kwargs["accelerator"] = args.accelerator
        trainer_kwargs["strategy"] = args.strategy
        trainer_kwargs["precision"] = args.precision
        trainer_kwargs["accumulate_grad_batches"] = args.accumulate_grad_batches
    else:
        # PL 1.x
        trainer_kwargs["gpus"] = args.devices if args.accelerator == "gpu" else 0
        trainer_kwargs["precision"] = 16 if args.precision == "fp16" else 32
    
    # DeepSpeed strategy
    if "deepspeed" in args.strategy:
        from pytorch_lightning.strategies import DeepSpeedStrategy
        trainer_kwargs["strategy"] = DeepSpeedStrategy(
            stage=int(args.strategy.split("_")[-1]),
            offload_optimizer=False,
        )
    
    trainer = Trainer(**trainer_kwargs)
    
    # Train
    trainer.fit(model)
    
    rank_zero_info("########## Training Complete ##########")


def generate_init_model(
    n_layer: int,
    n_embd: int,
    vocab_size: int,
    output_path: str,
    model_type: str = "x052",
    head_size_a: int = 64,
    random_seed: int = -1,
) -> str:
    """
    Generate initial model weights (Stage 1).
    
    Args:
        n_layer: Number of layers
        n_embd: Embedding dimension
        vocab_size: Vocabulary size
        output_path: Path to save the initialized model
        model_type: Model type (x052, x060, x070)
        head_size_a: Head size for attention
        random_seed: Random seed for initialization
    
    Returns:
        Path to the generated model file
    """
    import torch
    import types
    
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Generating initial model: {n_layer}L, {n_embd}D, vocab={vocab_size}")
    
    # Create args namespace with all required fields for RWKV model
    args = types.SimpleNamespace(
        n_layer=n_layer,
        n_embd=n_embd,
        vocab_size=vocab_size,
        model_type=model_type,
        head_size_a=head_size_a,
        head_size_divisor=8,
        random_seed=random_seed,
        dim_att=n_embd,
        dim_ffn=int((n_embd * 3.5) // 32 * 32),
        my_testing=model_type,
        ctx_len=1024,  # Will be overridden
        # Stage 1 specific args
        my_pile_stage=1,
        load_model="",
        # Other required args with defaults
        pre_ffn=0,
        head_qk=0,
        tiny_att_dim=0,
        tiny_att_layer=-999,
        my_pile_version=1,
        my_pile_shift=-1,
        my_pile_edecay=0,
        layerwise_lr=1,
        ds_bucket_mb=200,
        my_sample_len=0,
        my_ffn_shift=1,
        my_att_shift=1,
        my_pos_emb=0,
        load_partial=0,
        magic_prime=0,
        my_qa_mask=0,
        my_random_steps=0,
        my_exit=99999999,
        my_exit_tokens=0,
        # Training args (not used in init but required by model)
        lr_init=6e-4,
        lr_final=1e-5,
        warmup_steps=10,
        beta1=0.9,
        beta2=0.99,
        adam_eps=1e-18,
        weight_decay=0.001,
        grad_cp=0,
        dropout=0,
        weight_decay_final=-1,
        train_type="",
        # Device args
        accelerator="gpu",
        strategy="auto",
        devices=1,
        num_nodes=1,
        precision="bf16",
        accumulate_grad_batches=1,
    )
    
    # Create RWKV model instance
    model = RWKV(args)
    
    # Generate init weights using the model's method
    import torch
    mm = model.generate_init_weight()
    
    # Save the weights
    torch.save(mm, str(output_path))
    
    logger.info(f"Initial model saved to: {output_path}")
    return str(output_path)
