"""Version information."""

__version__ = "1.19.2"
