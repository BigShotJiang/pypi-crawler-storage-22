# Atlas Python SDK Design

> Design document for the Atlas Control Plane Python SDK

## Overview

The Atlas Python SDK enables AI agents to self-report their existence, configuration, and health to the Atlas Control Plane. The SDK is designed to be:

- **Fail-safe**: Control plane unavailability never blocks agent operation
- **Minimal**: Lightweight footprint, few dependencies
- **Typed**: Full type hints for IDE autocompletion and static analysis
- **Flexible**: Sync and async clients for different runtime environments

## Core Concepts

### Heartbeat Model

The SDK implements a "phone home" model:

```
┌─────────────────┐                    ┌─────────────────────┐
│                 │  register()        │                     │
│     Agent       │ ─────────────────► │   Control Plane     │
│                 │                    │                     │
│  (active        │  heartbeat()       │  (passive           │
│   reporter)     │ ─────────────────► │   monitor)          │
│                 │                    │                     │
│                 │  deregister()      │                     │
│                 │ ─────────────────► │                     │
└─────────────────┘                    └─────────────────────┘
```

- **Agent** sends periodic heartbeats to the control plane
- **Control Plane** passively tracks `last_seen_at` timestamps
- **If agent can't reach control plane**: Log warning, continue working
- **If control plane sees missed heartbeats**: Mark agent as stale/inactive

### Agent Lifecycle

```
┌──────────┐     ┌────────────┐     ┌─────────────────┐     ┌──────────────┐
│  Start   │ ──► │  Register  │ ──► │  Heartbeat Loop │ ──► │  Deregister  │
└──────────┘     └────────────┘     │   (background)  │     └──────────────┘
                                    └─────────────────┘
```

1. **Start**: Agent initializes, creates `ControlPlaneClient`
2. **Register**: Agent calls `register()`, control plane creates record
3. **Heartbeat Loop**: Background thread/task sends periodic heartbeats
4. **Deregister**: Agent calls `deregister()` on shutdown (or via context manager)

---

## Public API

### Client Initialization

```python
from atlas_sdk import ControlPlaneClient, AsyncControlPlaneClient

# Synchronous client
client = ControlPlaneClient(
    base_url="https://atlas.company.com/api/v1",  # or ATLAS_API_URL env var
    api_key="atlas_prod_ak_...",                   # or ATLAS_API_KEY env var
)

# Asynchronous client
async_client = AsyncControlPlaneClient(
    base_url="https://atlas.company.com/api/v1",
    api_key="atlas_prod_ak_...",
)
```

#### Configuration Options

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `base_url` | `str` | `ATLAS_API_URL` env var | Control plane API base URL |
| `api_key` | `str` | `ATLAS_API_KEY` env var | API key for authentication |
| `timeout` | `float` | `30.0` | Request timeout in seconds |
| `fail_silently` | `bool` | `True` | Log errors instead of raising exceptions |
| `auto_detect_context` | `bool` | `True` | Auto-detect deployment context |

### Registration

```python
from atlas_sdk import ControlPlaneClient, AgentConfiguration

client = ControlPlaneClient()

# Register with minimal config
response = client.register(
    name="my-agent",
    owner="team@company.com",
    configuration=AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read", "file_write"],
    ),
)

print(f"Registered as {response.agent_id}")
print(f"Risk level: {response.grasp_assessment.overall_risk}")
```

#### Register Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `name` | `str` | Yes | Human-readable agent name |
| `owner` | `str` | Yes | Owner email address |
| `configuration` | `AgentConfiguration` | Yes | Agent configuration |
| `definition_id` | `str` | No | Agent definition template ID |
| `deployment_context` | `DeploymentContext` | No | Auto-detected if not provided |
| `heartbeat_interval_seconds` | `int` | No | Default: 300 (5 minutes) |

#### Agent ID Generation

The SDK automatically generates a unique `agent_id` (UUID v4) for each session. This means:

- Each agent run is tracked as a distinct instance
- Restarts create new agent records
- Historical data is preserved per-session
- The agent `name` can remain the same across sessions (e.g., "john.doe's Claude Code")

**Rationale**: Auto-generation simplifies the API and ensures uniqueness. The `name` field provides human-readable continuity while `agent_id` provides unique instance tracking.

### Heartbeat Management

Heartbeats are managed automatically in the background after registration.

```python
# Heartbeats start automatically after register()
response = client.register(...)

# Agent does its work - heartbeats happen in background
do_agent_work()

# Heartbeats stop on deregister() or client close
client.deregister()
```

#### Heartbeat Behavior

| Scenario | Behavior |
|----------|----------|
| Normal operation | Send heartbeat every `heartbeat_interval_seconds` |
| Control plane unreachable | Log warning, retry next interval |
| Repeated failures | Log warning, continue retrying (never block agent) |
| Agent shutting down | Stop heartbeat loop, send deregister |

#### Heartbeat Content

Heartbeats include optional status and metrics:

```python
# Automatic heartbeats use defaults
# status="healthy", metrics={}

# For manual control, you can provide custom values
client.heartbeat(
    status="healthy",        # healthy | degraded | unhealthy
    metrics={                # Optional metrics dict
        "requests": 42,
        "errors": 0,
    },
)
```

#### Manual Heartbeat (Optional)

For agents that want explicit control:

```python
# Disable automatic heartbeats
client = ControlPlaneClient(auto_heartbeat=False)
client.register(...)

# Send heartbeats manually
while running:
    do_work()
    client.heartbeat(
        status="healthy",
        metrics={"requests": 42, "errors": 0},
    )
    time.sleep(300)
```

### Configuration Updates

Update agent configuration after registration (creates a new configuration version):

```python
# Update tools list
client.update_configuration(
    configuration=AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read", "file_write", "bash", "web_fetch"],  # Added web_fetch
    ),
)

# Update with new deployment context
client.update_configuration(
    configuration=AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read", "file_write"],
    ),
    deployment_context=DeploymentContext(
        filesystem_scope="/Users/john/NewProject",  # Changed scope
    ),
)
```

### Deregistration

```python
# Explicit deregistration
client.deregister(reason="Shutdown requested by user")

# Or use context manager for automatic cleanup
with ControlPlaneClient() as client:
    client.register(name="my-agent", owner="team@company.com", ...)
    do_agent_work()
# deregister() called automatically on exit
```

#### Crash Handling

The SDK registers `atexit` and signal handlers to attempt graceful deregistration:

- `atexit.register()` for normal Python exit
- `signal.signal(SIGTERM, ...)` for container/process termination

If the agent crashes without calling deregister:

- Control plane will mark it as stale after missing heartbeats
- Stale threshold = `heartbeat_interval_seconds * 3` (configurable on control plane)

---

## Data Models

### AgentConfiguration

```python
from atlas_sdk import AgentConfiguration

config = AgentConfiguration(
    model_provider="anthropic",           # Required: LLM provider
    model_name="claude-sonnet-4-20250514", # Required: Model identifier
    tools=["file_read", "file_write"],    # Required: List of enabled tools
    parameters={                           # Optional: Additional parameters
        "max_tokens": 4096,
        "temperature": 0.7,
    },
)
```

### DeploymentContext

```python
from atlas_sdk import DeploymentContext

context = DeploymentContext(
    hostname="workstation.local",         # Auto-detected
    environment="local",                   # local | staging | production
    has_internet_access=True,             # Auto-detected
    has_filesystem_access=True,           # Auto-detected
    filesystem_scope="/Users/john/Code",  # Root path for fs access
    resource_limits=ResourceLimits(       # Optional
        max_memory_mb=4096,
        max_cpu_cores=2,
    ),
)
```

#### Auto-Detection

When `auto_detect_context=True` (default), the SDK detects:

| Field | Detection Method |
|-------|------------------|
| `hostname` | `socket.gethostname()` |
| `environment` | `ATLAS_ENVIRONMENT` env var, or infer from hostname |
| `has_internet_access` | Attempt connection to known endpoint |
| `has_filesystem_access` | Check if running in sandbox/container |

### Response Models

```python
# Registration response
class RegisterResponse:
    agent_id: UUID
    lifecycle_state: LifecycleState  # active, inactive, suspended, terminated
    definition_id: str | None
    grasp_assessment: GraspAssessment | None
    next_heartbeat_due: datetime

# Heartbeat response
class HeartbeatResponse:
    acknowledged: bool
    next_heartbeat_due: datetime
    directives: list[Directive]  # Future: control plane instructions (always empty for MVP)

# Configuration update response
class UpdateConfigurationResponse:
    agent_id: UUID
    configuration_version: int      # Incremented version number
    grasp_assessment: GraspAssessment | None  # Re-computed after config change

# Deregister response
class DeregisterResponse:
    agent_id: UUID
    lifecycle_state: LifecycleState  # Will be "terminated"
    terminated_at: datetime

# GRASP assessment
class GraspAssessment:
    overall_risk: RiskLevel  # low, medium, high, critical
    governance_score: int | None  # 1-5
    reach_score: int | None
    agency_score: int | None
    safeguards_score: int | None
    potential_damage_score: int | None
    computed_at: datetime
```

---

## Error Handling

### Exception Hierarchy

```python
from atlas_sdk.exceptions import (
    AtlasError,              # Base exception
    ConnectionError,         # Network/connectivity issues
    AuthenticationError,     # Invalid API key
    AuthorizationError,      # Insufficient permissions
    ValidationError,         # Invalid request data
    RateLimitError,          # Rate limit exceeded
    AgentNotFoundError,      # Agent ID not found
    DuplicateAgentError,     # Agent ID conflict
)
```

### Fail-Silent Mode (Default)

When `fail_silently=True` (default):

```python
client = ControlPlaneClient(fail_silently=True)

# These log warnings but don't raise exceptions
client.register(...)  # Logs warning if control plane unreachable
client.heartbeat()    # Logs warning if heartbeat fails
client.deregister()   # Logs warning if deregister fails
```

### Strict Mode

When `fail_silently=False`:

```python
client = ControlPlaneClient(fail_silently=False)

try:
    client.register(...)
except ConnectionError:
    print("Control plane unreachable")
except AuthenticationError:
    print("Invalid API key")
```

### Retry Behavior

The SDK implements automatic retry with exponential backoff for transient errors:

| Error Type | Retry? | Strategy |
|------------|--------|----------|
| `ConnectionError` | Yes | 3 attempts, exponential backoff |
| `RateLimitError` | Yes | Use `Retry-After` header |
| `AuthenticationError` | No | Fail immediately |
| `ValidationError` | No | Fail immediately |
| `5xx Server Error` | Yes | 3 attempts, exponential backoff |

---

## Usage Patterns

### Basic Usage

```python
from atlas_sdk import ControlPlaneClient, AgentConfiguration

# Initialize and register
client = ControlPlaneClient()
client.register(
    name="code-assistant",
    owner="developer@company.com",
    configuration=AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read", "file_write", "bash"],
    ),
)

# Do agent work (heartbeats happen automatically)
run_agent_loop()

# Cleanup
client.deregister()
```

### Context Manager Pattern

```python
from atlas_sdk import ControlPlaneClient, AgentConfiguration

with ControlPlaneClient() as client:
    client.register(
        name="code-assistant",
        owner="developer@company.com",
        configuration=AgentConfiguration(
            model_provider="anthropic",
            model_name="claude-sonnet-4-20250514",
            tools=["file_read", "file_write"],
        ),
    )

    # Do work - heartbeats in background
    run_agent_loop()

# Automatic deregister on exit
```

### Async Usage

```python
from atlas_sdk import AsyncControlPlaneClient, AgentConfiguration

async def main():
    async with AsyncControlPlaneClient() as client:
        await client.register(
            name="async-agent",
            owner="developer@company.com",
            configuration=AgentConfiguration(
                model_provider="anthropic",
                model_name="claude-sonnet-4-20250514",
                tools=["file_read"],
            ),
        )

        # Do async work - heartbeats as background task
        await run_async_agent_loop()
```

### Framework Integration (Claude Code Example)

```python
# In Claude Code's initialization
from atlas_sdk import ControlPlaneClient, AgentConfiguration, DeploymentContext

def init_atlas_reporting():
    """Initialize Atlas control plane reporting."""
    client = ControlPlaneClient(
        fail_silently=True,  # Never block Claude Code operation
    )

    client.register(
        name=f"{get_username()}'s Claude Code",
        owner=get_user_email(),
        definition_id="claude-code",
        configuration=AgentConfiguration(
            model_provider="anthropic",
            model_name=get_current_model(),
            tools=get_enabled_tools(),
            parameters={"max_turns": get_max_turns()},
        ),
        deployment_context=DeploymentContext(
            hostname=socket.gethostname(),
            environment="local",
            has_internet_access=True,
            has_filesystem_access=True,
            filesystem_scope=get_working_directory(),
        ),
    )

    return client
```

---

## Configuration Reference

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `ATLAS_API_URL` | Control plane base URL | None (required) |
| `ATLAS_API_KEY` | API key for authentication | None (required) |
| `ATLAS_ENVIRONMENT` | Deployment environment hint | Auto-detect |
| `ATLAS_HEARTBEAT_INTERVAL` | Heartbeat interval in seconds | 300 |
| `ATLAS_FAIL_SILENTLY` | Fail-silent mode | `true` |
| `ATLAS_TIMEOUT` | Request timeout in seconds | 30 |
| `ATLAS_DISABLED` | Disable all Atlas reporting | `false` |

### Disabling the SDK

For testing or environments where Atlas shouldn't run:

```bash
export ATLAS_DISABLED=true
```

When disabled, all SDK methods become no-ops that return mock responses.

---

## Threading Model

### Synchronous Client

- Main thread: `register()`, `deregister()`, manual `heartbeat()`
- Background daemon thread: Automatic heartbeat loop
- Thread-safe: All public methods are thread-safe

```
┌─────────────────────────────────────────────────────┐
│                    Main Thread                       │
│  register() ─► do_work() ─► do_work() ─► deregister()│
└─────────────────────────────────────────────────────┘
        │                                      │
        ▼                                      ▼
┌─────────────────────────────────────────────────────┐
│               Background Thread (daemon)             │
│  heartbeat() ─► sleep ─► heartbeat() ─► sleep ─► stop│
└─────────────────────────────────────────────────────┘
```

### Asynchronous Client

- Uses `asyncio.Task` for background heartbeats
- Cancels heartbeat task on `deregister()` or context exit

```
┌─────────────────────────────────────────────────────┐
│                    Event Loop                        │
│  register() ─► do_work() ─► do_work() ─► deregister()│
│       │                                      │       │
│       ▼                                      ▼       │
│  [heartbeat task] ─► sleep ─► heartbeat ─► cancel    │
└─────────────────────────────────────────────────────┘
```

---

## Design Decisions

> Resolved decisions for MVP implementation

1. **Agent IDs**: New UUID generated per session. The `name` field provides human-readable continuity across sessions.

2. **Heartbeat Content**: Include `status` (healthy/degraded/unhealthy) and optional `metrics` dict.

3. **Directives**: Exposed in `HeartbeatResponse.directives` but always empty for MVP. Future policy engine will populate these.

4. **Configuration Updates**: Supported via `client.update_configuration()` in MVP.

---

## Appendix: API Endpoints

| Method | Endpoint | SDK Method | Scope Required |
|--------|----------|------------|----------------|
| POST | `/agents/register` | `client.register()` | `agent:register` |
| POST | `/agents/{id}/heartbeat` | `client.heartbeat()` | `agent:heartbeat` |
| PATCH | `/agents/{id}/configuration` | `client.update_configuration()` | `agent:register` |
| POST | `/agents/{id}/deregister` | `client.deregister()` | `agent:register` |
