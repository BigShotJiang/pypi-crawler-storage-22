# Plan: Atlas SDK for Python (MVP)

## Goal

Create a lightweight, typed Python client library for the Atlas Control Plane API to enable agents to self-report their existence, configuration, and health.

## Design

See [sdk-design.md](../design/sdk-design.md) for detailed design decisions.

## Scope

- Core `ControlPlaneClient` and `AsyncControlPlaneClient`.
- Agent registration, configuration updates, and deregistration.
- Automatic heartbeat management (background thread/task).
- Basic deployment context auto-detection.
- Typed Pydantic models for all API entities.
- Fail-safe mode (default): never block agent operation.
- Comprehensive testing strategy (Unit, Integration, E2E).

## Task List

### 1. Project Initialization

- [x] Initialize Python project structure in `atlas-sdks/python`.
- [x] Configure `pyproject.toml` with dependencies:
  - Runtime: `httpx`, `pydantic`.
  - Dev/Test: `pytest`, `pytest-asyncio`, `pytest-mock`, `respx`.
- [x] Set up `pytest.ini` with markers for `unit`, `integration`, and `e2e`.

### 2. Core Implementation

- [x] Define Pydantic models:
  - [x] `AgentConfiguration`, `DeploymentContext`, `ResourceLimits`
  - [x] `RegisterResponse`, `HeartbeatResponse`, `UpdateConfigurationResponse`, `DeregisterResponse`
  - [x] `GraspAssessment`, `Directive`
  - [x] Enums: `LifecycleState`, `RiskLevel`, `HeartbeatStatus`, `DirectiveType`
- [x] Define exception hierarchy:
  - [x] `AtlasError` (base), `AtlasConnectionError`, `AuthenticationError`, `AuthorizationError`
  - [x] `AtlasValidationError`, `RateLimitError`, `AgentNotFoundError`, `DuplicateAgentError`
- [x] Implement `ControlPlaneClient` (synchronous) with `httpx`:
  - [x] `register()` - register agent, auto-generate UUID, start heartbeat loop
  - [x] `heartbeat()` - send heartbeat with status/metrics
  - [x] `update_configuration()` - update config after registration
  - [x] `deregister()` - mark agent terminated, stop heartbeat loop
  - [x] Context manager support (`__enter__`/`__exit__`)
- [x] Implement `AsyncControlPlaneClient` (asynchronous) with `httpx`:
  - [x] Same methods as sync client
  - [x] Async context manager support (`__aenter__`/`__aexit__`)
- [x] Implement background heartbeat manager:
  - [x] Sync: daemon thread with threading.Event for shutdown
  - [x] Async: asyncio.Task with cancellation
- [x] Implement retry logic with exponential backoff for transient errors.

### 3. Context Detection

- [x] Implement `detect_context()` to auto-detect:
  - [x] `hostname` via `socket.gethostname()`
  - [x] `environment` via `ATLAS_ENVIRONMENT` env var or hostname inference
  - [x] `has_internet_access` via connectivity check
  - [x] `has_filesystem_access` via sandbox/container detection

### 4. Testing Implementation

- [x] **Infrastructure**
  - [x] Create directory structure: `tests/unit`, `tests/integration`, `tests/e2e`.
  - [x] Configure `conftest.py` with shared fixtures.
- [x] **Unit Tests** (Mocked Logic)
  - [x] Test client payload construction and response parsing.
  - [x] Test error handling and retry logic (mocking `httpx`).
  - [x] Test context detection (mocking `os.environ`/fs).
  - [x] Test heartbeat manager start/stop lifecycles.
- [x] **Integration Tests** (Mocked Network)
  - [x] Implement `respx` mocks for Control Plane endpoints (`/register`, `/heartbeat`).
  - [x] Verify Async/Sync client parity.
  - [x] Test full lifecycle flows (Register -> Heartbeat -> Deregister).
- [x] **E2E Tests** (Live System)
  - [x] Create test harness reading `ATLAS_API_URL` from env.
  - [x] Implement live registration test against local Control Plane (Docker).

### 5. Documentation

- [x] Write `README.md` with:
  - [x] Installation instructions.
  - [x] Quickstart examples (Sync & Async).
  - [x] Configuration reference.

### 6. Build & Publish

- [x] Configure `pyproject.toml` with build system (hatchling).
- [x] Add GitHub Actions CI workflow for PR verification.
- [x] Add GitHub Actions release workflow:
  - [x] Semantic versioning via `semantic-release`.
  - [x] Build wheel and sdist.
  - [x] Publish to PyPI via trusted publishing (OIDC).

## Acceptance Criteria

1. **Registration**: An agent can register with the Control Plane and receive an auto-generated `agent_id`.
2. **Heartbeats**: Once registered, heartbeats are sent automatically in the background without blocking the main agent logic. Heartbeats include `status` and optional `metrics`.
3. **Configuration Updates**: An agent can update its configuration after registration via `update_configuration()`.
4. **Typing**: The SDK provides full IDE autocompletion and type safety for all configuration and context fields.
5. **Reliability**:
    - **Fail-Safe**: If the Control Plane is unreachable, the SDK logs a warning but does not crash (when `fail_silently=True`, the default).
    - **Retry**: Transient errors (network, rate limits, 5xx) are retried with exponential backoff.
    - **Coverage**: Unit tests cover >90% of code paths.
    - **Contracts**: Integration tests verify strict API compliance using `respx`.
6. **Deregistration**: The agent is correctly marked as terminated when `deregister()` is called or when used via a context manager.
7. **Graceful Shutdown**: `atexit` and signal handlers attempt deregistration on unexpected exit.
