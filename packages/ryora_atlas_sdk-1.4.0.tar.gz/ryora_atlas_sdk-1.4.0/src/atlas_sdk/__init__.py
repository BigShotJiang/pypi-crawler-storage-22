"""Atlas SDK for Python.

A lightweight, typed Python client library for the Atlas Control Plane API.

Example:
    >>> from atlas_sdk import ControlPlaneClient, AgentConfiguration
    >>> client = ControlPlaneClient()
    >>> client.register(
    ...     name="my-agent",
    ...     owner="team@company.com",
    ...     configuration=AgentConfiguration(
    ...         model_provider="anthropic",
    ...         model_name="claude-sonnet-4-20250514",
    ...         tools=["file_read", "file_write"],
    ...     ),
    ... )
"""

from atlas_sdk.async_client import AsyncControlPlaneClient
from atlas_sdk.client import ControlPlaneClient
from atlas_sdk.context import detect_context
from atlas_sdk.exceptions import (
    AgentNotFoundError,
    AtlasConnectionError,
    AtlasError,
    AtlasValidationError,
    AuthenticationError,
    AuthorizationError,
    DuplicateAgentError,
    RateLimitError,
)
from atlas_sdk.models import (
    AgentConfiguration,
    DeploymentContext,
    DeregisterResponse,
    Directive,
    DirectiveType,
    GraspAssessment,
    HeartbeatResponse,
    HeartbeatStatus,
    LifecycleState,
    RegisterResponse,
    ResourceLimits,
    RiskLevel,
    UpdateConfigurationResponse,
)

__version__ = "0.1.0"

__all__ = [
    "AgentConfiguration",
    "AgentNotFoundError",
    "AsyncControlPlaneClient",
    "AtlasConnectionError",
    "AtlasError",
    "AtlasValidationError",
    "AuthenticationError",
    "AuthorizationError",
    "ControlPlaneClient",
    "DeploymentContext",
    "DeregisterResponse",
    "Directive",
    "DirectiveType",
    "DuplicateAgentError",
    "GraspAssessment",
    "HeartbeatResponse",
    "HeartbeatStatus",
    "LifecycleState",
    "RateLimitError",
    "RegisterResponse",
    "ResourceLimits",
    "RiskLevel",
    "UpdateConfigurationResponse",
    "__version__",
    "detect_context",
]
