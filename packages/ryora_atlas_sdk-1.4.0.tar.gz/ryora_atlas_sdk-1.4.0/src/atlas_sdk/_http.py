"""Shared HTTP utilities for sync and async clients."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from atlas_sdk.exceptions import (
    AgentNotFoundError,
    AtlasConnectionError,
    AtlasError,
    AtlasValidationError,
    AuthenticationError,
    AuthorizationError,
    DuplicateAgentError,
    RateLimitError,
)

if TYPE_CHECKING:
    from uuid import UUID

    import httpx

logger = logging.getLogger(__name__)

# Default configuration values
DEFAULT_TIMEOUT = 30.0
DEFAULT_HEARTBEAT_INTERVAL = 300  # 5 minutes
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_BASE_DELAY = 1.0


def handle_response_error(response: httpx.Response, agent_id: UUID | None = None) -> None:
    """Convert HTTP errors to SDK exceptions.

    Args:
        response: The HTTP response to check.
        agent_id: The current agent ID for error messages.

    Raises:
        AuthenticationError: For 401 responses.
        AuthorizationError: For 403 responses.
        AgentNotFoundError: For 404 responses.
        DuplicateAgentError: For 409 responses.
        AtlasValidationError: For 422 responses.
        RateLimitError: For 429 responses.
        AtlasError: For other 4xx/5xx responses.
    """
    status = response.status_code

    if status == 401:
        raise AuthenticationError()
    if status == 403:
        raise AuthorizationError()
    if status == 404:
        raise AgentNotFoundError(str(agent_id or "unknown"))
    if status == 409:
        raise DuplicateAgentError(str(agent_id or "unknown"))
    if status == 422:
        try:
            details = response.json()
        except Exception:
            details = {}
        raise AtlasValidationError("Validation error", details=details)
    if status == 429:
        retry_after = response.headers.get("Retry-After")
        raise RateLimitError(
            retry_after=float(retry_after) if retry_after else None,
        )
    if status >= 500:
        raise AtlasError(f"Server error: {status}", status_code=status)
    if status >= 400:
        raise AtlasError(f"Request error: {status}", status_code=status)


def should_retry(error: Exception) -> bool:
    """Determine if an error should be retried.

    Args:
        error: The exception that occurred.

    Returns:
        True if the error is transient and should be retried.
    """
    if isinstance(error, AtlasConnectionError | RateLimitError):
        return True
    return (
        isinstance(error, AtlasError) and error.status_code is not None and error.status_code >= 500
    )


def handle_error(error: Exception, operation: str, *, fail_silently: bool) -> None:
    """Handle errors based on fail_silently setting.

    Args:
        error: The exception that occurred.
        operation: Description of the operation that failed.
        fail_silently: If True, log warning; if False, raise the error.

    Raises:
        Exception: Re-raises the error if fail_silently is False.
    """
    if fail_silently:
        logger.warning("Atlas %s failed: %s", operation, error)
    else:
        raise error


def build_auth_headers(api_key: str | None) -> dict[str, str]:
    """Build HTTP headers including authentication.

    Args:
        api_key: Optional API key for Bearer authentication.

    Returns:
        Dictionary of HTTP headers.
    """
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def build_registration_payload(
    agent_id: UUID,
    name: str,
    owner: str,
    configuration: Any,
    heartbeat_interval: int,
    definition_id: str | None = None,
    deployment_context: Any | None = None,
) -> dict[str, Any]:
    """Build the registration request payload.

    Args:
        agent_id: The agent's UUID.
        name: Human-readable agent name.
        owner: Owner email address.
        configuration: Agent configuration model.
        heartbeat_interval: Heartbeat interval in seconds.
        definition_id: Optional definition template ID.
        deployment_context: Optional deployment context model.

    Returns:
        Dictionary payload for the registration request.
    """
    payload: dict[str, Any] = {
        "agent_id": str(agent_id),
        "name": name,
        "owner": owner,
        "configuration": configuration.model_dump(),
        "heartbeat_interval_seconds": heartbeat_interval,
    }

    if definition_id:
        payload["definition_id"] = definition_id

    if deployment_context:
        payload["deployment_context"] = deployment_context.model_dump(exclude_none=True)

    return payload
