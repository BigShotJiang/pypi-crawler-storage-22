"""Synchronous Control Plane client."""

from __future__ import annotations

import atexit
import contextlib
import logging
import os
import signal
import threading
import time
from typing import TYPE_CHECKING, Any, Self
from uuid import UUID, uuid4

import httpx

from atlas_sdk._http import (
    DEFAULT_HEARTBEAT_INTERVAL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_BASE_DELAY,
    DEFAULT_TIMEOUT,
    build_auth_headers,
    handle_error,
    handle_response_error,
    should_retry,
)
from atlas_sdk.context import detect_context
from atlas_sdk.exceptions import (
    AtlasConnectionError,
    AtlasError,
    RateLimitError,
)
from atlas_sdk.models import (
    AgentConfiguration,
    DeploymentContext,
    DeregisterResponse,
    HeartbeatResponse,
    HeartbeatStatus,
    RegisterResponse,
    UpdateConfigurationResponse,
)

if TYPE_CHECKING:
    from types import FrameType

# Type alias for signal handlers
_SignalHandler = signal.Handlers

logger = logging.getLogger(__name__)


class ControlPlaneClient:
    """Synchronous client for Atlas Control Plane.

    Example:
        >>> client = ControlPlaneClient()
        >>> client.register(
        ...     name="my-agent",
        ...     owner="team@company.com",
        ...     configuration=AgentConfiguration(
        ...         model_provider="anthropic",
        ...         model_name="claude-sonnet-4-20250514",
        ...         tools=["file_read", "file_write"],
        ...     ),
        ... )
        >>> # Heartbeats happen automatically in background
        >>> client.deregister()

    Or use as a context manager:
        >>> with ControlPlaneClient() as client:
        ...     client.register(...)
        ...     # Do work
        ... # Automatic deregister on exit
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        fail_silently: bool = True,
        auto_detect_context: bool = True,
        auto_heartbeat: bool = True,
        heartbeat_interval_seconds: int = DEFAULT_HEARTBEAT_INTERVAL,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        """Initialize the Control Plane client.

        Args:
            base_url: Control plane API base URL. Falls back to ATLAS_API_URL env var.
            api_key: API key for authentication. Falls back to ATLAS_API_KEY env var.
            timeout: Request timeout in seconds.
            fail_silently: If True, log errors instead of raising exceptions.
            auto_detect_context: If True, auto-detect deployment context.
            auto_heartbeat: If True, start background heartbeat after registration.
            heartbeat_interval_seconds: Interval between heartbeats.
            max_retries: Maximum retry attempts for transient errors.
        """
        self._base_url = (base_url or os.environ.get("ATLAS_API_URL", "")).rstrip("/")
        self._api_key = api_key or os.environ.get("ATLAS_API_KEY")
        self._timeout = timeout
        self._fail_silently = fail_silently
        self._auto_detect_context = auto_detect_context
        self._auto_heartbeat = auto_heartbeat
        self._heartbeat_interval = heartbeat_interval_seconds
        self._max_retries = max_retries

        self._disabled = os.environ.get("ATLAS_DISABLED", "").lower() in ("true", "1", "yes")

        self._agent_id: UUID | None = None
        self._registered = False
        self._http_client: httpx.Client | None = None

        # Heartbeat management
        self._heartbeat_thread: threading.Thread | None = None
        self._heartbeat_stop_event = threading.Event()
        self._heartbeat_lock = threading.Lock()

        # Signal handlers for graceful shutdown
        self._original_sigterm: _SignalHandler | None = None
        self._original_sigint: _SignalHandler | None = None

    @property
    def agent_id(self) -> UUID | None:
        """The registered agent ID, or None if not registered."""
        return self._agent_id

    @property
    def is_registered(self) -> bool:
        """Whether the client is currently registered."""
        return self._registered

    def _get_http_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._http_client is None:
            self._http_client = httpx.Client(
                base_url=self._base_url,
                headers=build_auth_headers(self._api_key),
                timeout=self._timeout,
            )
        return self._http_client

    def _execute_with_retry(
        self,
        method: str,
        path: str,
        *,
        json_data: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Execute an HTTP request with retry logic."""
        client = self._get_http_client()
        last_error: Exception | None = None

        for attempt in range(self._max_retries):
            try:
                response = client.request(method, path, json=json_data)
                if response.status_code < 400:
                    return response
                handle_response_error(response, self._agent_id)
            except httpx.RequestError as e:
                last_error = AtlasConnectionError(f"Connection error: {e}")
            except RateLimitError as e:
                last_error = e
                if e.retry_after:
                    time.sleep(e.retry_after)
                    continue
            except AtlasError as e:
                if not should_retry(e):
                    raise
                last_error = e

            if attempt < self._max_retries - 1:
                delay = DEFAULT_RETRY_BASE_DELAY * (2**attempt)
                logger.warning(
                    "Request failed (attempt %d/%d), retrying in %.1fs: %s",
                    attempt + 1,
                    self._max_retries,
                    delay,
                    last_error,
                )
                time.sleep(delay)

        if last_error:
            raise last_error
        raise AtlasError("Request failed after retries")

    def register(
        self,
        name: str,
        owner: str,
        configuration: AgentConfiguration,
        *,
        definition_id: str | None = None,
        deployment_context: DeploymentContext | None = None,
        heartbeat_interval_seconds: int | None = None,
    ) -> RegisterResponse | None:
        """Register the agent with the control plane.

        Args:
            name: Human-readable agent name.
            owner: Owner email address.
            configuration: Agent configuration.
            definition_id: Optional agent definition template ID.
            deployment_context: Deployment context. Auto-detected if not provided.
            heartbeat_interval_seconds: Override default heartbeat interval.

        Returns:
            Registration response, or None if failed and fail_silently is True.
        """
        if self._disabled:
            logger.debug("Atlas SDK disabled, skipping registration")
            return None

        if self._registered:
            logger.warning("Agent already registered, skipping")
            return None

        # Generate new agent ID
        self._agent_id = uuid4()

        # Use provided heartbeat interval or fall back to client default
        if heartbeat_interval_seconds:
            self._heartbeat_interval = heartbeat_interval_seconds

        # Build request payload
        payload: dict[str, Any] = {
            "agent_id": str(self._agent_id),
            "name": name,
            "owner": owner,
            "configuration": configuration.model_dump(),
            "heartbeat_interval_seconds": self._heartbeat_interval,
        }

        if definition_id:
            payload["definition_id"] = definition_id

        if deployment_context:
            payload["deployment_context"] = deployment_context.model_dump(exclude_none=True)
        elif self._auto_detect_context:
            detected = detect_context()
            payload["deployment_context"] = detected.model_dump(exclude_none=True)

        try:
            response = self._execute_with_retry("POST", "/agents/register", json_data=payload)
            result = RegisterResponse.model_validate(response.json())
            self._registered = True

            # Set up graceful shutdown handlers
            self._setup_shutdown_handlers()

            # Start background heartbeat if enabled
            if self._auto_heartbeat:
                self._start_heartbeat_loop()

            logger.info("Agent registered: %s", self._agent_id)
            return result

        except Exception as e:
            self._agent_id = None
            handle_error(e, "registration", fail_silently=self._fail_silently)
            return None

    def heartbeat(
        self,
        status: HeartbeatStatus = HeartbeatStatus.HEALTHY,
        metrics: dict[str, Any] | None = None,
    ) -> HeartbeatResponse | None:
        """Send a heartbeat to the control plane.

        Args:
            status: Agent health status.
            metrics: Optional metrics dictionary.

        Returns:
            Heartbeat response, or None if failed and fail_silently is True.
        """
        if self._disabled:
            return None

        if not self._registered or not self._agent_id:
            logger.warning("Cannot send heartbeat: agent not registered")
            return None

        payload: dict[str, Any] = {
            "status": status.value,
        }
        if metrics:
            payload["metrics"] = metrics

        try:
            response = self._execute_with_retry(
                "POST",
                f"/agents/{self._agent_id}/heartbeat",
                json_data=payload,
            )
            return HeartbeatResponse.model_validate(response.json())

        except Exception as e:
            handle_error(e, "heartbeat", fail_silently=self._fail_silently)
            return None

    def update_configuration(
        self,
        configuration: AgentConfiguration,
        *,
        deployment_context: DeploymentContext | None = None,
    ) -> UpdateConfigurationResponse | None:
        """Update agent configuration.

        Args:
            configuration: New agent configuration.
            deployment_context: Optional new deployment context.

        Returns:
            Update response, or None if failed and fail_silently is True.
        """
        if self._disabled:
            return None

        if not self._registered or not self._agent_id:
            logger.warning("Cannot update configuration: agent not registered")
            return None

        payload: dict[str, Any] = {
            "configuration": configuration.model_dump(),
        }

        if deployment_context:
            payload["deployment_context"] = deployment_context.model_dump(exclude_none=True)

        try:
            response = self._execute_with_retry(
                "PATCH",
                f"/agents/{self._agent_id}/configuration",
                json_data=payload,
            )
            return UpdateConfigurationResponse.model_validate(response.json())

        except Exception as e:
            handle_error(e, "configuration update", fail_silently=self._fail_silently)
            return None

    def deregister(self, reason: str | None = None) -> DeregisterResponse | None:
        """Deregister the agent from the control plane.

        Args:
            reason: Optional reason for deregistration.

        Returns:
            Deregister response, or None if failed and fail_silently is True.
        """
        if self._disabled:
            return None

        if not self._registered or not self._agent_id:
            logger.debug("Cannot deregister: agent not registered")
            return None

        # Stop heartbeat loop first
        self._stop_heartbeat_loop()

        payload: dict[str, Any] = {}
        if reason:
            payload["reason"] = reason

        try:
            response = self._execute_with_retry(
                "POST",
                f"/agents/{self._agent_id}/deregister",
                json_data=payload,
            )
            result = DeregisterResponse.model_validate(response.json())
            self._registered = False
            self._cleanup_shutdown_handlers()
            logger.info("Agent deregistered: %s", self._agent_id)
            return result

        except Exception as e:
            # Mark as not registered even on error to prevent retry loops
            self._registered = False
            self._cleanup_shutdown_handlers()
            handle_error(e, "deregistration", fail_silently=self._fail_silently)
            return None

    def _start_heartbeat_loop(self) -> None:
        """Start the background heartbeat thread."""
        with self._heartbeat_lock:
            if self._heartbeat_thread is not None:
                return

            self._heartbeat_stop_event.clear()
            self._heartbeat_thread = threading.Thread(
                target=self._heartbeat_loop,
                daemon=True,
                name="atlas-heartbeat",
            )
            self._heartbeat_thread.start()
            logger.debug("Heartbeat loop started")

    def _stop_heartbeat_loop(self) -> None:
        """Stop the background heartbeat thread."""
        with self._heartbeat_lock:
            if self._heartbeat_thread is None:
                return

            self._heartbeat_stop_event.set()
            self._heartbeat_thread.join(timeout=5.0)
            self._heartbeat_thread = None
            logger.debug("Heartbeat loop stopped")

    def _heartbeat_loop(self) -> None:
        """Background heartbeat loop."""
        while not self._heartbeat_stop_event.wait(timeout=self._heartbeat_interval):
            if not self._registered:
                break
            try:
                self.heartbeat()
            except Exception as e:
                logger.warning("Background heartbeat failed: %s", e)

    def _setup_shutdown_handlers(self) -> None:
        """Set up atexit and signal handlers for graceful shutdown."""
        atexit.register(self._atexit_handler)

        try:
            self._original_sigterm = signal.signal(signal.SIGTERM, self._signal_handler)  # type: ignore[assignment]
            self._original_sigint = signal.signal(signal.SIGINT, self._signal_handler)  # type: ignore[assignment]
        except ValueError:
            # Can't set signal handlers from non-main thread
            logger.debug("Could not set signal handlers (not main thread)")

    def _cleanup_shutdown_handlers(self) -> None:
        """Remove shutdown handlers."""
        with contextlib.suppress(Exception):
            atexit.unregister(self._atexit_handler)

        try:
            if self._original_sigterm is not None:
                signal.signal(signal.SIGTERM, self._original_sigterm)
            if self._original_sigint is not None:
                signal.signal(signal.SIGINT, self._original_sigint)
        except ValueError:
            pass

    def _atexit_handler(self) -> None:
        """Handle process exit."""
        if self._registered:
            logger.debug("atexit: deregistering agent")
            self.deregister(reason="Process exit")

    def _signal_handler(self, signum: int, frame: FrameType | None) -> None:
        """Handle termination signals."""
        if self._registered:
            logger.debug("Signal %d: deregistering agent", signum)
            self.deregister(reason=f"Signal {signum}")

        # Call original handler
        original = self._original_sigterm if signum == signal.SIGTERM else self._original_sigint
        if original and callable(original):
            original(signum, frame)

    def close(self) -> None:
        """Close the client and release resources."""
        if self._registered:
            self.deregister()

        self._stop_heartbeat_loop()

        if self._http_client:
            self._http_client.close()
            self._http_client = None

    def __enter__(self) -> Self:
        """Enter context manager."""
        return self

    def __exit__(self, exc_type: type | None, exc_val: Exception | None, exc_tb: object) -> None:
        """Exit context manager."""
        self.close()
