"""Deployment context auto-detection."""

from __future__ import annotations

import logging
import os
import socket
from pathlib import Path

from atlas_sdk.models import DeploymentContext

logger = logging.getLogger(__name__)

# Environment variable for explicit environment setting
ATLAS_ENVIRONMENT_VAR = "ATLAS_ENVIRONMENT"

# Environment variable to skip context detection (useful for testing)
ATLAS_SKIP_CONTEXT_DETECTION_VAR = "ATLAS_SKIP_CONTEXT_DETECTION"

# Known internet connectivity check endpoints
CONNECTIVITY_CHECK_HOST = "1.1.1.1"  # Cloudflare DNS
CONNECTIVITY_CHECK_PORT = 53
CONNECTIVITY_CHECK_TIMEOUT = 2.0

# Container/sandbox detection paths
CONTAINER_INDICATORS = (
    "/.dockerenv",
    "/run/.containerenv",
)
CGROUP_PATHS = (
    "/proc/1/cgroup",
    "/proc/self/cgroup",
)
CONTAINER_CGROUP_MARKERS = ("docker", "kubepods", "lxc", "containerd")


def detect_context() -> DeploymentContext:
    """Auto-detect deployment context.

    Detects:
    - hostname: via socket.gethostname()
    - environment: via ATLAS_ENVIRONMENT env var or hostname inference
    - has_internet_access: via connectivity check to Cloudflare DNS
    - has_filesystem_access: True unless in detected sandbox/container

    Set ATLAS_SKIP_CONTEXT_DETECTION=true to skip detection and return empty context.
    This is useful in testing environments where network checks may cause flakiness.

    Returns:
        DeploymentContext with detected values, or empty context if detection is skipped.
    """
    # Allow skipping context detection for testing environments
    if os.environ.get(ATLAS_SKIP_CONTEXT_DETECTION_VAR, "").lower() in ("true", "1", "yes"):
        logger.debug("Context detection skipped via %s", ATLAS_SKIP_CONTEXT_DETECTION_VAR)
        return DeploymentContext()

    return DeploymentContext(
        hostname=_detect_hostname(),
        environment=_detect_environment(),
        has_internet_access=_detect_internet_access(),
        has_filesystem_access=_detect_filesystem_access(),
    )


def _detect_hostname() -> str | None:
    """Detect the current hostname."""
    try:
        return socket.gethostname()
    except Exception as e:
        logger.debug("Failed to detect hostname: %s", e)
        return None


def _detect_environment() -> str | None:
    """Detect the deployment environment.

    Priority:
    1. ATLAS_ENVIRONMENT env var (explicit override)
    2. Infer from hostname patterns

    Common environment values: local, development, staging, production
    """
    # Check explicit environment variable first
    env_value = os.environ.get(ATLAS_ENVIRONMENT_VAR)
    if env_value:
        return env_value.lower()

    # Infer from hostname
    try:
        hostname = socket.gethostname().lower()
        return _infer_environment_from_hostname(hostname)
    except Exception as e:
        logger.debug("Failed to infer environment from hostname: %s", e)
        return None


def _infer_environment_from_hostname(hostname: str) -> str | None:
    """Infer environment from hostname patterns.

    Common patterns:
    - prod*, production* -> production
    - stag*, staging* -> staging
    - dev*, develop* -> development
    - local*, localhost -> local
    - test* -> test
    """
    hostname = hostname.lower()

    if hostname.startswith(("prod", "prd")):
        return "production"
    if hostname.startswith(("stag", "stg")):
        return "staging"
    if hostname.startswith(("dev", "develop")):
        return "development"
    if hostname.startswith(("local", "localhost")) or hostname in ("localhost",):
        return "local"
    if hostname.startswith("test"):
        return "test"

    # Check for environment indicators in the hostname
    if "prod" in hostname or "production" in hostname:
        return "production"
    if "stag" in hostname or "staging" in hostname:
        return "staging"
    if "dev" in hostname or "develop" in hostname:
        return "development"

    return None


def _detect_internet_access() -> bool | None:
    """Detect if the host has internet access.

    Uses a lightweight connectivity check to Cloudflare DNS (1.1.1.1:53).
    This is fast and reliable without making HTTP requests.

    Returns:
        True if internet access is available, False if not, None if detection failed.
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(CONNECTIVITY_CHECK_TIMEOUT)
        try:
            sock.connect((CONNECTIVITY_CHECK_HOST, CONNECTIVITY_CHECK_PORT))
            return True
        except (OSError, TimeoutError):
            return False
        finally:
            sock.close()
    except Exception as e:
        logger.debug("Failed to detect internet access: %s", e)
        return None


def _detect_filesystem_access() -> bool | None:
    """Detect if the agent has filesystem access.

    Checks for container/sandbox indicators that might restrict filesystem access.
    Returns True if running outside a detected container/sandbox.

    Detection methods:
    1. Check for container indicator files (/.dockerenv, etc.)
    2. Check cgroup information for container markers
    3. Check environment variables for container runtimes

    Returns:
        True if full filesystem access is expected, False if containerized/sandboxed,
        None if detection failed.
    """
    try:
        is_containerized = _is_containerized()
        # If containerized, filesystem access may be restricted
        # Return True (has access) if NOT containerized
        return not is_containerized if is_containerized is not None else None
    except Exception as e:
        logger.debug("Failed to detect filesystem access: %s", e)
        return None


def _is_containerized() -> bool | None:
    """Check if running inside a container or sandbox.

    Returns:
        True if containerized, False if not, None if unknown.
    """
    # Check for container indicator files
    for indicator in CONTAINER_INDICATORS:
        if Path(indicator).exists():
            logger.debug("Container detected via %s", indicator)
            return True

    # Check cgroup information
    for cgroup_path in CGROUP_PATHS:
        cgroup_file = Path(cgroup_path)
        if cgroup_file.exists():
            try:
                content = cgroup_file.read_text().lower()
                for marker in CONTAINER_CGROUP_MARKERS:
                    if marker in content:
                        logger.debug("Container detected via cgroup marker: %s", marker)
                        return True
            except (OSError, PermissionError):
                pass

    # Check container-related environment variables
    container_env_vars = (
        "KUBERNETES_SERVICE_HOST",
        "DOCKER_CONTAINER",
        "container",
    )
    for env_var in container_env_vars:
        if os.environ.get(env_var):
            logger.debug("Container detected via env var: %s", env_var)
            return True

    return False
