"""Exception hierarchy for Atlas SDK."""

from __future__ import annotations

from typing import Any


class AtlasError(Exception):
    """Base exception for all Atlas SDK errors."""

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class AtlasConnectionError(AtlasError):
    """Network or connectivity error when communicating with control plane."""


class AuthenticationError(AtlasError):
    """Invalid or missing API key."""

    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message, status_code=401)


class AuthorizationError(AtlasError):
    """Insufficient permissions for the requested operation."""

    def __init__(self, message: str = "Insufficient permissions") -> None:
        super().__init__(message, status_code=403)


class AtlasValidationError(AtlasError):
    """Invalid request data."""

    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(message, status_code=422)
        self.details: dict[str, Any] = details or {}


class RateLimitError(AtlasError):
    """Rate limit exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        *,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class AgentNotFoundError(AtlasError):
    """Agent ID not found in control plane."""

    def __init__(self, agent_id: str) -> None:
        super().__init__(f"Agent not found: {agent_id}", status_code=404)
        self.agent_id = agent_id


class DuplicateAgentError(AtlasError):
    """Agent ID already exists in control plane."""

    def __init__(self, agent_id: str) -> None:
        super().__init__(f"Agent already exists: {agent_id}", status_code=409)
        self.agent_id = agent_id
