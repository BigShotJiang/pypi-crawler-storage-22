"""Pydantic models for Atlas SDK."""

from __future__ import annotations

from datetime import datetime  # noqa: TC003 - Pydantic needs this at runtime
from enum import Enum
from typing import Any
from uuid import UUID  # noqa: TC003 - Pydantic needs this at runtime

from pydantic import BaseModel, Field


class LifecycleState(str, Enum):
    """Agent lifecycle states."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    TERMINATED = "terminated"


class RiskLevel(str, Enum):
    """GRASP risk assessment levels."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class HeartbeatStatus(str, Enum):
    """Agent health status for heartbeats."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class DirectiveType(str, Enum):
    """Types of directives from control plane."""

    SHUTDOWN = "shutdown"
    RECONFIGURE = "reconfigure"
    RATE_LIMIT = "rate_limit"
    SUSPEND = "suspend"


# Request Models


class ResourceLimits(BaseModel):
    """Resource limits for agent deployment."""

    max_memory_mb: int | None = None
    max_cpu_cores: int | None = None
    max_disk_mb: int | None = None
    max_network_bandwidth_mbps: int | None = None


class DeploymentContext(BaseModel):
    """Deployment context for an agent."""

    hostname: str | None = None
    environment: str | None = None  # local, staging, production
    has_internet_access: bool | None = None
    has_filesystem_access: bool | None = None
    filesystem_scope: str | None = None
    resource_limits: ResourceLimits | None = None


class AgentConfiguration(BaseModel):
    """Configuration for an agent."""

    model_provider: str
    model_name: str
    tools: list[str] = Field(default_factory=list)
    parameters: dict[str, Any] = Field(default_factory=dict)


# Response Models


class Directive(BaseModel):
    """Directive from control plane to agent."""

    directive_type: DirectiveType
    payload: dict[str, Any] = Field(default_factory=dict)
    issued_at: datetime


class GraspAssessment(BaseModel):
    """GRASP risk assessment for an agent."""

    overall_risk: RiskLevel
    governance_score: int | None = None
    reach_score: int | None = None
    agency_score: int | None = None
    safeguards_score: int | None = None
    potential_damage_score: int | None = None
    computed_at: datetime


class RegisterResponse(BaseModel):
    """Response from agent registration."""

    agent_id: UUID
    lifecycle_state: LifecycleState
    definition_id: str | None = None
    grasp_assessment: GraspAssessment | None = None
    next_heartbeat_due: datetime


class HeartbeatResponse(BaseModel):
    """Response from heartbeat."""

    acknowledged: bool
    next_heartbeat_due: datetime
    directives: list[Directive] = Field(default_factory=list)


class UpdateConfigurationResponse(BaseModel):
    """Response from configuration update."""

    agent_id: UUID
    configuration_version: int
    grasp_assessment: GraspAssessment | None = None


class DeregisterResponse(BaseModel):
    """Response from agent deregistration."""

    agent_id: UUID
    lifecycle_state: LifecycleState
    terminated_at: datetime
