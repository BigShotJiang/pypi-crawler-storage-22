"""Shared pytest configuration and fixtures for all tests."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import pytest

from atlas_sdk import (
    AgentConfiguration,
    DeploymentContext,
)


@pytest.fixture
def mock_config() -> AgentConfiguration:
    """Create a test agent configuration."""
    return AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read", "file_write"],
    )


@pytest.fixture
def mock_deployment_context() -> DeploymentContext:
    """Create a test deployment context."""
    return DeploymentContext(
        hostname="test-host",
        environment="test",
        has_internet_access=True,
        has_filesystem_access=True,
    )


@pytest.fixture
def mock_agent_id() -> str:
    """Return a consistent test agent ID."""
    return "12345678-1234-5678-1234-567812345678"


@pytest.fixture
def mock_register_response_data(mock_agent_id: str) -> dict[str, Any]:
    """Create mock registration response data."""
    return {
        "agent_id": mock_agent_id,
        "lifecycle_state": "active",
        "next_heartbeat_due": datetime.now(UTC).isoformat(),
    }


@pytest.fixture
def mock_heartbeat_response_data() -> dict[str, Any]:
    """Create mock heartbeat response data."""
    return {
        "acknowledged": True,
        "next_heartbeat_due": datetime.now(UTC).isoformat(),
        "directives": [],
    }


@pytest.fixture
def mock_deregister_response_data(mock_agent_id: str) -> dict[str, Any]:
    """Create mock deregistration response data."""
    return {
        "agent_id": mock_agent_id,
        "lifecycle_state": "terminated",
        "terminated_at": datetime.now(UTC).isoformat(),
    }


@pytest.fixture
def mock_update_config_response_data(mock_agent_id: str) -> dict[str, Any]:
    """Create mock configuration update response data."""
    return {
        "agent_id": mock_agent_id,
        "configuration_version": 2,
        "grasp_assessment": None,
    }
