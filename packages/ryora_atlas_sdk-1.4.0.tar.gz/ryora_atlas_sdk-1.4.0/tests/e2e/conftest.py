"""Pytest configuration for end-to-end tests."""

from __future__ import annotations

import os

import pytest


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Automatically add 'e2e' marker to all tests in this directory."""
    for item in items:
        if "/e2e/" in str(item.fspath):
            item.add_marker(pytest.mark.e2e)


def pytest_configure(config: pytest.Config) -> None:
    """Configure e2e test settings."""
    config.addinivalue_line(
        "markers",
        "e2e: End-to-end tests that require a live Control Plane",
    )


@pytest.fixture(scope="session")
def e2e_api_url() -> str:
    """Get the API URL for e2e tests from environment."""
    url = os.environ.get("ATLAS_API_URL")
    if not url:
        pytest.skip("ATLAS_API_URL not set - skipping e2e tests")
    return url


@pytest.fixture(scope="session")
def e2e_api_key() -> str | None:
    """Get the optional API key for e2e tests from environment."""
    return os.environ.get("ATLAS_API_KEY")


@pytest.fixture
def skip_if_no_api() -> None:
    """Skip test if API URL is not configured."""
    if not os.environ.get("ATLAS_API_URL"):
        pytest.skip("ATLAS_API_URL not set - skipping e2e test")
