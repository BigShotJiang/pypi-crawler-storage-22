"""End-to-end tests for live agent registration against Control Plane.

These tests require a running Control Plane instance. Set ATLAS_API_URL
environment variable to the Control Plane URL before running.

Example:
    ATLAS_API_URL=http://localhost:8080 pytest tests/e2e -v
"""

from __future__ import annotations

import asyncio

import pytest

from atlas_sdk import (
    AgentConfiguration,
    AsyncControlPlaneClient,
    ControlPlaneClient,
    DeploymentContext,
    HeartbeatStatus,
    LifecycleState,
)

pytestmark = pytest.mark.e2e


@pytest.fixture
def e2e_config() -> AgentConfiguration:
    """Create configuration for e2e tests."""
    return AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read"],
    )


@pytest.fixture
def e2e_context() -> DeploymentContext:
    """Create deployment context for e2e tests."""
    return DeploymentContext(
        hostname="e2e-test-host",
        environment="test",
        has_internet_access=True,
        has_filesystem_access=True,
    )


class TestLiveSyncRegistration:
    """E2E tests for synchronous client against live API."""

    def test_register_and_deregister(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test full registration and deregistration cycle."""
        client = ControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=False,
            auto_detect_context=False,
            fail_silently=False,
        )

        try:
            # Register
            result = client.register(
                name="e2e-test-agent-sync",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            assert result is not None
            assert result.lifecycle_state == LifecycleState.ACTIVE
            assert result.agent_id is not None
            assert client.is_registered is True

            # Deregister
            deregister_result = client.deregister(reason="E2E test complete")

            assert deregister_result is not None
            assert deregister_result.lifecycle_state == LifecycleState.TERMINATED
            assert client.is_registered is False

        finally:
            if client.is_registered:
                client.deregister()
            client.close()

    def test_register_heartbeat_deregister(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test registration with manual heartbeat."""
        client = ControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=False,
            auto_detect_context=False,
            fail_silently=False,
        )

        try:
            # Register
            client.register(
                name="e2e-test-agent-heartbeat",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            # Send heartbeat
            heartbeat_result = client.heartbeat(
                status=HeartbeatStatus.HEALTHY,
                metrics={"test_metric": 42},
            )

            assert heartbeat_result is not None
            assert heartbeat_result.acknowledged is True

        finally:
            if client.is_registered:
                client.deregister()
            client.close()

    def test_context_manager_lifecycle(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test context manager handles lifecycle correctly."""
        with ControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=False,
            auto_detect_context=False,
            fail_silently=False,
        ) as client:
            result = client.register(
                name="e2e-test-agent-ctx-mgr",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            assert result is not None
            assert client.is_registered is True

        # After context manager exit, should be deregistered
        assert client.is_registered is False


class TestLiveAsyncRegistration:
    """E2E tests for asynchronous client against live API."""

    async def test_async_register_and_deregister(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test async registration and deregistration cycle."""
        client = AsyncControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=False,
            auto_detect_context=False,
            fail_silently=False,
        )

        try:
            # Register
            result = await client.register(
                name="e2e-test-agent-async",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            assert result is not None
            assert result.lifecycle_state == LifecycleState.ACTIVE
            assert result.agent_id is not None
            assert client.is_registered is True

            # Deregister
            deregister_result = await client.deregister(reason="E2E test complete")

            assert deregister_result is not None
            assert deregister_result.lifecycle_state == LifecycleState.TERMINATED
            assert client.is_registered is False

        finally:
            if client.is_registered:
                await client.deregister()
            await client.close()

    async def test_async_heartbeat(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test async heartbeat functionality."""
        client = AsyncControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=False,
            auto_detect_context=False,
            fail_silently=False,
        )

        try:
            await client.register(
                name="e2e-test-agent-async-heartbeat",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            # Send heartbeat
            heartbeat_result = await client.heartbeat(
                status=HeartbeatStatus.HEALTHY,
                metrics={"async_test_metric": 100},
            )

            assert heartbeat_result is not None
            assert heartbeat_result.acknowledged is True

        finally:
            if client.is_registered:
                await client.deregister()
            await client.close()

    async def test_async_context_manager_lifecycle(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test async context manager handles lifecycle correctly."""
        async with AsyncControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=False,
            auto_detect_context=False,
            fail_silently=False,
        ) as client:
            result = await client.register(
                name="e2e-test-agent-async-ctx-mgr",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            assert result is not None
            assert client.is_registered is True

        # After context manager exit, should be deregistered
        assert client.is_registered is False


class TestLiveAutoHeartbeat:
    """E2E tests for automatic heartbeat functionality."""

    def test_auto_heartbeat_starts_after_registration(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test that auto heartbeat starts after registration."""
        # Use a very short interval for testing
        client = ControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=True,
            heartbeat_interval_seconds=2,  # Short interval for testing
            auto_detect_context=False,
            fail_silently=False,
        )

        try:
            client.register(
                name="e2e-test-agent-auto-heartbeat",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            # Verify heartbeat thread is running
            assert client._heartbeat_thread is not None
            assert client._heartbeat_thread.is_alive()

            # Wait a bit and verify still registered
            import time

            time.sleep(0.5)
            assert client.is_registered is True

        finally:
            if client.is_registered:
                client.deregister()
            client.close()

    async def test_async_auto_heartbeat_starts_after_registration(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        e2e_context: DeploymentContext,
    ) -> None:
        """Test that async auto heartbeat starts after registration."""
        client = AsyncControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=True,
            heartbeat_interval_seconds=2,  # Short interval for testing
            auto_detect_context=False,
            fail_silently=False,
        )

        try:
            await client.register(
                name="e2e-test-agent-async-auto-heartbeat",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                deployment_context=e2e_context,
            )

            # Verify heartbeat task is running
            assert client._heartbeat_task is not None
            assert not client._heartbeat_task.done()

            # Wait a bit and verify still registered
            await asyncio.sleep(0.5)
            assert client.is_registered is True

        finally:
            if client.is_registered:
                await client.deregister()
            await client.close()


class TestLiveContextDetection:
    """E2E tests for context auto-detection."""

    def test_auto_detect_context_integration(
        self,
        e2e_api_url: str,
        e2e_api_key: str | None,
        e2e_config: AgentConfiguration,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Test that auto-detected context is sent to API."""
        # Set environment for consistent detection
        monkeypatch.setenv("ATLAS_ENVIRONMENT", "e2e-test")

        client = ControlPlaneClient(
            base_url=e2e_api_url,
            api_key=e2e_api_key,
            auto_heartbeat=False,
            auto_detect_context=True,  # Enable auto-detection
            fail_silently=False,
        )

        try:
            result = client.register(
                name="e2e-test-agent-context-detect",
                owner="e2e-test@example.com",
                configuration=e2e_config,
                # No deployment_context provided - should be auto-detected
            )

            assert result is not None
            assert result.lifecycle_state == LifecycleState.ACTIVE

        finally:
            if client.is_registered:
                client.deregister()
            client.close()
