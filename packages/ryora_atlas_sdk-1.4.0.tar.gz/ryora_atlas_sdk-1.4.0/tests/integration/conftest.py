"""Pytest configuration for integration tests."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import httpx
import pytest
import respx

if TYPE_CHECKING:
    from collections.abc import Iterator


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Automatically add 'integration' marker to all tests in this directory."""
    for item in items:
        if "/integration/" in str(item.fspath):
            item.add_marker(pytest.mark.integration)


@pytest.fixture
def base_url() -> str:
    """Return the mock base URL for integration tests."""
    return "https://api.atlas.test"


@pytest.fixture
def respx_mock(base_url: str) -> Iterator[respx.MockRouter]:
    """Create a respx mock router for the test."""
    with respx.mock(base_url=base_url, assert_all_called=False) as router:
        yield router


@pytest.fixture
def mock_register_endpoint(
    respx_mock: respx.MockRouter,
    mock_agent_id: str,
) -> respx.Route:
    """Set up mock for /agents/register endpoint."""
    return respx_mock.post("/agents/register").mock(
        return_value=httpx.Response(
            200,
            json={
                "agent_id": mock_agent_id,
                "lifecycle_state": "active",
                "next_heartbeat_due": datetime.now(UTC).isoformat(),
            },
        )
    )


@pytest.fixture
def mock_heartbeat_endpoint(
    respx_mock: respx.MockRouter,
    mock_agent_id: str,
) -> respx.Route:
    """Set up mock for /agents/{id}/heartbeat endpoint."""
    return respx_mock.post(f"/agents/{mock_agent_id}/heartbeat").mock(
        return_value=httpx.Response(
            200,
            json={
                "acknowledged": True,
                "next_heartbeat_due": datetime.now(UTC).isoformat(),
                "directives": [],
            },
        )
    )


@pytest.fixture
def mock_deregister_endpoint(
    respx_mock: respx.MockRouter,
    mock_agent_id: str,
) -> respx.Route:
    """Set up mock for /agents/{id}/deregister endpoint."""
    return respx_mock.post(f"/agents/{mock_agent_id}/deregister").mock(
        return_value=httpx.Response(
            200,
            json={
                "agent_id": mock_agent_id,
                "lifecycle_state": "terminated",
                "terminated_at": datetime.now(UTC).isoformat(),
            },
        )
    )


@pytest.fixture
def mock_update_config_endpoint(
    respx_mock: respx.MockRouter,
    mock_agent_id: str,
) -> respx.Route:
    """Set up mock for /agents/{id}/configuration endpoint."""
    return respx_mock.patch(f"/agents/{mock_agent_id}/configuration").mock(
        return_value=httpx.Response(
            200,
            json={
                "agent_id": mock_agent_id,
                "configuration_version": 2,
                "grasp_assessment": None,
            },
        )
    )


def create_error_response(status_code: int, detail: str = "") -> dict[str, Any]:
    """Create a mock error response."""
    return {"detail": detail or f"Error {status_code}"}
