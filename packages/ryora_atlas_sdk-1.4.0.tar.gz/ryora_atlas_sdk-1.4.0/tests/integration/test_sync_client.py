"""Integration tests for synchronous ControlPlaneClient using respx mocks."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import patch
from uuid import UUID

import httpx
import pytest
import respx

from atlas_sdk import (
    AgentConfiguration,
    ControlPlaneClient,
    DeploymentContext,
    HeartbeatStatus,
    LifecycleState,
)


class TestSyncClientRegistration:
    """Integration tests for sync client registration."""

    def test_register_sends_correct_payload(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_deployment_context: DeploymentContext,
        mock_agent_id: str,
    ) -> None:
        """Registration sends correct payload structure to API."""
        register_route = respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )
        )

        with patch.object(ControlPlaneClient, "_setup_shutdown_handlers"):
            client = ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=False,
            )

            # Force the agent_id to match our mock
            with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                result = client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                    deployment_context=mock_deployment_context,
                )

        assert register_route.called
        assert result is not None
        assert result.lifecycle_state == LifecycleState.ACTIVE

        # Verify request payload
        request = register_route.calls.last.request
        payload = request.read()
        import json

        data = json.loads(payload)
        assert data["name"] == "test-agent"
        assert data["owner"] == "test@example.com"
        assert "configuration" in data
        assert data["configuration"]["model_provider"] == "anthropic"
        assert "deployment_context" in data

    def test_register_with_auto_detect_context(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_agent_id: str,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration auto-detects deployment context when enabled."""
        monkeypatch.setenv("ATLAS_ENVIRONMENT", "test")

        register_route = respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )
        )

        with patch.object(ControlPlaneClient, "_setup_shutdown_handlers"):
            client = ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=True,
            )

            with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )

        assert register_route.called
        request = register_route.calls.last.request
        import json

        data = json.loads(request.read())
        assert "deployment_context" in data
        assert data["deployment_context"]["environment"] == "test"


class TestSyncClientHeartbeat:
    """Integration tests for sync client heartbeat."""

    def test_heartbeat_after_registration(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_agent_id: str,
    ) -> None:
        """Heartbeat works after successful registration."""
        respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )
        )

        heartbeat_route = respx_mock.post(f"/agents/{mock_agent_id}/heartbeat").mock(
            return_value=httpx.Response(
                200,
                json={
                    "acknowledged": True,
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                    "directives": [],
                },
            )
        )

        with patch.object(ControlPlaneClient, "_setup_shutdown_handlers"):
            client = ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=False,
            )

            with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )

            result = client.heartbeat(status=HeartbeatStatus.HEALTHY)

        assert heartbeat_route.called
        assert result is not None
        assert result.acknowledged is True

    def test_heartbeat_with_metrics(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_agent_id: str,
    ) -> None:
        """Heartbeat includes metrics in payload."""
        respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )
        )

        heartbeat_route = respx_mock.post(f"/agents/{mock_agent_id}/heartbeat").mock(
            return_value=httpx.Response(
                200,
                json={
                    "acknowledged": True,
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                    "directives": [],
                },
            )
        )

        with patch.object(ControlPlaneClient, "_setup_shutdown_handlers"):
            client = ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=False,
            )

            with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )

            client.heartbeat(
                status=HeartbeatStatus.DEGRADED,
                metrics={"cpu": 85, "memory_mb": 512},
            )

        import json

        request = heartbeat_route.calls.last.request
        data = json.loads(request.read())
        assert data["status"] == "degraded"
        assert data["metrics"] == {"cpu": 85, "memory_mb": 512}


class TestSyncClientDeregistration:
    """Integration tests for sync client deregistration."""

    def test_deregister_after_registration(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_agent_id: str,
    ) -> None:
        """Deregistration works after successful registration."""
        respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )
        )

        deregister_route = respx_mock.post(f"/agents/{mock_agent_id}/deregister").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "terminated",
                    "terminated_at": datetime.now(UTC).isoformat(),
                },
            )
        )

        with (
            patch.object(ControlPlaneClient, "_setup_shutdown_handlers"),
            patch.object(ControlPlaneClient, "_cleanup_shutdown_handlers"),
        ):
            client = ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=False,
            )

            with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )

            result = client.deregister(reason="Test complete")

        assert deregister_route.called
        assert result is not None
        assert result.lifecycle_state == LifecycleState.TERMINATED
        assert client.is_registered is False


class TestSyncClientFullLifecycle:
    """Integration tests for full client lifecycle."""

    def test_full_lifecycle_register_heartbeat_deregister(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_agent_id: str,
    ) -> None:
        """Full lifecycle: register -> heartbeat -> deregister."""
        respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )
        )

        respx_mock.post(f"/agents/{mock_agent_id}/heartbeat").mock(
            return_value=httpx.Response(
                200,
                json={
                    "acknowledged": True,
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                    "directives": [],
                },
            )
        )

        respx_mock.post(f"/agents/{mock_agent_id}/deregister").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "terminated",
                    "terminated_at": datetime.now(UTC).isoformat(),
                },
            )
        )

        with (
            patch.object(ControlPlaneClient, "_setup_shutdown_handlers"),
            patch.object(ControlPlaneClient, "_cleanup_shutdown_handlers"),
        ):
            client = ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=False,
            )

            # Register
            with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                register_result = client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )

            assert register_result is not None
            assert client.is_registered is True

            # Heartbeat
            heartbeat_result = client.heartbeat()
            assert heartbeat_result is not None
            assert heartbeat_result.acknowledged is True

            # Deregister
            deregister_result = client.deregister()
            assert deregister_result is not None
            assert client.is_registered is False

    def test_context_manager_lifecycle(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_agent_id: str,
    ) -> None:
        """Context manager properly handles registration and deregistration."""
        respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )
        )

        deregister_route = respx_mock.post(f"/agents/{mock_agent_id}/deregister").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "terminated",
                    "terminated_at": datetime.now(UTC).isoformat(),
                },
            )
        )

        with (
            patch.object(ControlPlaneClient, "_setup_shutdown_handlers"),
            patch.object(ControlPlaneClient, "_cleanup_shutdown_handlers"),
        ):
            with ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=False,
            ) as client:
                with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                    client.register(
                        name="test-agent",
                        owner="test@example.com",
                        configuration=mock_config,
                    )
                assert client.is_registered is True

            # After context manager exit
            assert deregister_route.called


class TestSyncClientErrorHandling:
    """Integration tests for error handling."""

    def test_registration_server_error_retries(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
        mock_agent_id: str,
    ) -> None:
        """Server errors are retried during registration."""
        call_count = 0

        def handler(_request: respx.MockRequest) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                return httpx.Response(503, json={"error": "Service unavailable"})
            return httpx.Response(
                200,
                json={
                    "agent_id": mock_agent_id,
                    "lifecycle_state": "active",
                    "next_heartbeat_due": datetime.now(UTC).isoformat(),
                },
            )

        respx_mock.post("/agents/register").mock(side_effect=handler)

        with patch.object(ControlPlaneClient, "_setup_shutdown_handlers"):
            client = ControlPlaneClient(
                base_url=base_url,
                auto_heartbeat=False,
                auto_detect_context=False,
                max_retries=5,
            )

            with patch("atlas_sdk.client.uuid4", return_value=UUID(mock_agent_id)):
                result = client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )

        assert call_count == 3
        assert result is not None
        assert result.lifecycle_state == LifecycleState.ACTIVE

    def test_registration_fail_silently_on_error(
        self,
        base_url: str,
        respx_mock: respx.MockRouter,
        mock_config: AgentConfiguration,
    ) -> None:
        """Failed registration returns None when fail_silently=True."""
        respx_mock.post("/agents/register").mock(
            return_value=httpx.Response(500, json={"error": "Internal server error"})
        )

        client = ControlPlaneClient(
            base_url=base_url,
            auto_heartbeat=False,
            auto_detect_context=False,
            fail_silently=True,
            max_retries=1,
        )

        result = client.register(
            name="test-agent",
            owner="test@example.com",
            configuration=mock_config,
        )

        assert result is None
        assert client.is_registered is False
