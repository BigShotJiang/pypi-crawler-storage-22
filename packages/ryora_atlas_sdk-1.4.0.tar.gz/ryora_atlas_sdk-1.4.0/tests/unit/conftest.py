"""Pytest configuration for unit tests."""

import pytest


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Automatically add 'unit' marker to all tests in this directory."""
    for item in items:
        if "/unit/" in str(item.fspath):
            item.add_marker(pytest.mark.unit)
