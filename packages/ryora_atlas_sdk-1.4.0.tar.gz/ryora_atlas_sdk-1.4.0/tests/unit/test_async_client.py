"""Unit tests for asynchronous AsyncControlPlaneClient."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from atlas_sdk import (
    AgentConfiguration,
    AsyncControlPlaneClient,
    AtlasConnectionError,
    DeploymentContext,
    HeartbeatStatus,
    LifecycleState,
)


@pytest.fixture
def mock_config() -> AgentConfiguration:
    """Create a test agent configuration."""
    return AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read"],
    )


@pytest.fixture
def mock_register_response() -> dict:
    """Create a mock registration response."""
    return {
        "agent_id": "12345678-1234-5678-1234-567812345678",
        "lifecycle_state": "active",
        "next_heartbeat_due": datetime.now(UTC).isoformat(),
    }


@pytest.fixture
def mock_heartbeat_response() -> dict:
    """Create a mock heartbeat response."""
    return {
        "acknowledged": True,
        "next_heartbeat_due": datetime.now(UTC).isoformat(),
        "directives": [],
    }


@pytest.fixture
def mock_deregister_response() -> dict:
    """Create a mock deregister response."""
    return {
        "agent_id": "12345678-1234-5678-1234-567812345678",
        "lifecycle_state": "terminated",
        "terminated_at": datetime.now(UTC).isoformat(),
    }


class TestAsyncControlPlaneClientInit:
    """Tests for async client initialization."""

    def test_default_initialization(self) -> None:
        """Client initializes with default values."""
        client = AsyncControlPlaneClient()
        assert client.agent_id is None
        assert client.is_registered is False

    def test_custom_base_url(self) -> None:
        """Client accepts custom base URL."""
        client = AsyncControlPlaneClient(base_url="https://custom.api.com")
        assert client._base_url == "https://custom.api.com"

    def test_env_var_base_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Client reads base URL from ATLAS_API_URL env var."""
        monkeypatch.setenv("ATLAS_API_URL", "https://env.api.com")
        client = AsyncControlPlaneClient()
        assert client._base_url == "https://env.api.com"

    def test_disabled_via_env_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Client can be disabled via ATLAS_DISABLED env var."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")
        client = AsyncControlPlaneClient()
        assert client._disabled is True


class TestAsyncControlPlaneClientRegister:
    """Tests for async agent registration."""

    async def test_register_success(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Successful registration returns RegisterResponse."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = mock_register_response

        with patch.object(
            client, "_execute_with_retry", new_callable=AsyncMock, return_value=mock_response
        ):
            result = await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

            assert result is not None
            assert result.lifecycle_state == LifecycleState.ACTIVE
            assert client.is_registered is True
            assert client.agent_id is not None

    async def test_register_disabled_returns_none(
        self,
        mock_config: AgentConfiguration,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration returns None when SDK is disabled."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")
        client = AsyncControlPlaneClient()

        result = await client.register(
            name="test-agent",
            owner="test@example.com",
            configuration=mock_config,
        )

        assert result is None
        assert client.is_registered is False

    async def test_register_already_registered_returns_none(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration returns None if already registered."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = mock_register_response

        with patch.object(
            client, "_execute_with_retry", new_callable=AsyncMock, return_value=mock_response
        ):
            await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            # Second registration
            result = await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

            assert result is None

    async def test_register_with_deployment_context(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration includes provided deployment context."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
            auto_detect_context=False,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = mock_register_response

        context = DeploymentContext(
            hostname="test-host",
            environment="production",
        )

        with patch.object(
            client, "_execute_with_retry", new_callable=AsyncMock, return_value=mock_response
        ) as mock_exec:
            await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
                deployment_context=context,
            )

            # Verify context was included in payload
            call_args = mock_exec.call_args
            payload = call_args.kwargs["json_data"]
            assert "deployment_context" in payload
            assert payload["deployment_context"]["hostname"] == "test-host"

    async def test_register_fail_silently_logs_error(
        self,
        mock_config: AgentConfiguration,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration with fail_silently=True logs error and returns None."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            fail_silently=True,
            auto_heartbeat=False,
        )

        with patch.object(
            client,
            "_execute_with_retry",
            new_callable=AsyncMock,
            side_effect=AtlasConnectionError("Network error"),
        ):
            result = await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

        assert result is None
        assert client.is_registered is False

    async def test_register_fail_silently_false_raises(
        self,
        mock_config: AgentConfiguration,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration with fail_silently=False raises exception."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            fail_silently=False,
            auto_heartbeat=False,
        )

        with (
            patch.object(
                client,
                "_execute_with_retry",
                new_callable=AsyncMock,
                side_effect=AtlasConnectionError("Network error"),
            ),
            pytest.raises(AtlasConnectionError),
        ):
            await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )


class TestAsyncControlPlaneClientHeartbeat:
    """Tests for async heartbeat sending."""

    async def test_heartbeat_success(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_heartbeat_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Successful heartbeat returns HeartbeatResponse."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        heartbeat_mock = MagicMock(spec=httpx.Response)
        heartbeat_mock.status_code = 200
        heartbeat_mock.json.return_value = mock_heartbeat_response

        with patch.object(
            client,
            "_execute_with_retry",
            new_callable=AsyncMock,
            side_effect=[register_mock, heartbeat_mock],
        ):
            await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            result = await client.heartbeat()

            assert result is not None
            assert result.acknowledged is True

    async def test_heartbeat_not_registered_returns_none(self) -> None:
        """Heartbeat returns None if not registered."""
        client = AsyncControlPlaneClient(base_url="https://api.test.com")
        result = await client.heartbeat()
        assert result is None

    async def test_heartbeat_with_status_and_metrics(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_heartbeat_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Heartbeat includes status and metrics in payload."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        heartbeat_mock = MagicMock(spec=httpx.Response)
        heartbeat_mock.status_code = 200
        heartbeat_mock.json.return_value = mock_heartbeat_response

        with patch.object(
            client,
            "_execute_with_retry",
            new_callable=AsyncMock,
            side_effect=[register_mock, heartbeat_mock],
        ) as mock_exec:
            await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            await client.heartbeat(
                status=HeartbeatStatus.DEGRADED,
                metrics={"cpu": 80},
            )

            heartbeat_call = mock_exec.call_args_list[1]
            payload = heartbeat_call.kwargs["json_data"]
            assert payload["status"] == "degraded"
            assert payload["metrics"] == {"cpu": 80}


class TestAsyncControlPlaneClientDeregister:
    """Tests for async agent deregistration."""

    async def test_deregister_success(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_deregister_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Successful deregistration returns DeregisterResponse."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        deregister_mock = MagicMock(spec=httpx.Response)
        deregister_mock.status_code = 200
        deregister_mock.json.return_value = mock_deregister_response

        with patch.object(
            client,
            "_execute_with_retry",
            new_callable=AsyncMock,
            side_effect=[register_mock, deregister_mock],
        ):
            await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            result = await client.deregister()

            assert result is not None
            assert result.lifecycle_state == LifecycleState.TERMINATED
            assert client.is_registered is False

    async def test_deregister_not_registered_returns_none(self) -> None:
        """Deregister returns None if not registered."""
        client = AsyncControlPlaneClient(base_url="https://api.test.com")
        result = await client.deregister()
        assert result is None


class TestAsyncControlPlaneClientContextManager:
    """Tests for async context manager support."""

    async def test_async_context_manager(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_deregister_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Async context manager works correctly."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        deregister_mock = MagicMock(spec=httpx.Response)
        deregister_mock.status_code = 200
        deregister_mock.json.return_value = mock_deregister_response

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        with patch.object(
            client,
            "_execute_with_retry",
            new_callable=AsyncMock,
            side_effect=[register_mock, deregister_mock],
        ):
            async with client:
                await client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )
                assert client.is_registered is True
            # After context manager exit, should be deregistered
            assert client.is_registered is False


class TestAsyncControlPlaneClientRetryLogic:
    """Tests for HTTP retry logic."""

    async def test_connection_error_triggers_retry(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Connection errors are retried."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            max_retries=2,
        )

        mock_client = AsyncMock()
        mock_client.request.side_effect = httpx.RequestError("Connection failed")

        with (
            patch.object(
                client, "_get_http_client", new_callable=AsyncMock, return_value=mock_client
            ),
            patch("atlas_sdk.async_client.asyncio.sleep", new_callable=AsyncMock),
            pytest.raises(AtlasConnectionError),
        ):
            await client._execute_with_retry("GET", "/test")

        # Should have tried max_retries times
        assert mock_client.request.call_count == 2

    async def test_rate_limit_with_retry_after_sleeps(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Rate limit error with retry_after header causes sleep."""
        from atlas_sdk.exceptions import RateLimitError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            max_retries=2,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 429
        mock_response.headers = {"Retry-After": "5"}

        mock_client = AsyncMock()
        mock_client.request.return_value = mock_response

        with (
            patch.object(
                client, "_get_http_client", new_callable=AsyncMock, return_value=mock_client
            ),
            patch("atlas_sdk.async_client.asyncio.sleep", new_callable=AsyncMock) as mock_sleep,
            pytest.raises(RateLimitError),
        ):
            await client._execute_with_retry("GET", "/test")

        # Should have slept for retry_after value
        mock_sleep.assert_any_call(5.0)

    async def test_non_retryable_error_raises_immediately(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Non-retryable errors (4xx) raise immediately without retry."""
        from atlas_sdk.exceptions import AuthenticationError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            max_retries=3,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 401

        mock_client = AsyncMock()
        mock_client.request.return_value = mock_response

        with (
            patch.object(
                client, "_get_http_client", new_callable=AsyncMock, return_value=mock_client
            ),
            pytest.raises(AuthenticationError),
        ):
            await client._execute_with_retry("GET", "/test")

        # Should have only tried once (no retry for 401)
        assert mock_client.request.call_count == 1


class TestAsyncControlPlaneClientDisabled:
    """Tests for disabled SDK behavior."""

    async def test_update_configuration_when_disabled(
        self, mock_config: AgentConfiguration, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """update_configuration returns None when SDK is disabled."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")

        client = AsyncControlPlaneClient(base_url="https://api.test.com")
        result = await client.update_configuration(mock_config)
        assert result is None

    async def test_deregister_when_disabled(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """deregister returns None when SDK is disabled."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")

        client = AsyncControlPlaneClient(base_url="https://api.test.com")
        result = await client.deregister()
        assert result is None


class TestAsyncControlPlaneClientHeartbeatLoop:
    """Tests for background heartbeat loop."""

    async def test_heartbeat_loop_starts_and_stops(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Heartbeat loop can be started and stopped."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,  # We'll start it manually
            heartbeat_interval_seconds=1,
        )

        # Mock registration
        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        with patch.object(
            client, "_execute_with_retry", new_callable=AsyncMock, return_value=register_mock
        ):
            await client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

        # Manually start heartbeat
        await client._start_heartbeat_loop()
        assert client._heartbeat_task is not None

        # Stop heartbeat
        await client._stop_heartbeat_loop()
        assert client._heartbeat_task is None

    async def test_heartbeat_loop_already_running_noop(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Starting heartbeat when already running does nothing."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )
        client._registered = True

        # Create a mock task
        mock_task = MagicMock()
        client._heartbeat_task = mock_task

        # Try to start again
        await client._start_heartbeat_loop()

        # Should still be the same task (not replaced)
        assert client._heartbeat_task is mock_task


class TestAsyncControlPlaneClientErrorPaths:
    """Tests for error handling paths."""

    async def test_heartbeat_error_with_fail_silently(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Heartbeat errors are logged when fail_silently=True."""
        from atlas_sdk.exceptions import AtlasError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
            fail_silently=True,
        )

        # Set up as registered
        client._registered = True
        client._agent_id = MagicMock()

        with patch.object(
            client,
            "_execute_with_retry",
            new_callable=AsyncMock,
            side_effect=AtlasError("Server error"),
        ):
            result = await client.heartbeat()
            assert result is None  # Should return None, not raise

    async def test_deregister_error_cleans_up(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Deregister errors still mark client as not registered."""
        from atlas_sdk.exceptions import AtlasError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = AsyncControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
            fail_silently=True,
        )

        # Set up as registered
        client._registered = True
        client._agent_id = MagicMock()

        with (
            patch.object(
                client,
                "_execute_with_retry",
                new_callable=AsyncMock,
                side_effect=AtlasError("Error"),
            ),
            patch.object(client, "_stop_heartbeat_loop", new_callable=AsyncMock),
        ):
            result = await client.deregister()
            assert result is None
            assert client._registered is False  # Should be marked as not registered
