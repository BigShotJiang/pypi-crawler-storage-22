"""Unit tests for synchronous ControlPlaneClient."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import MagicMock, patch

import httpx
import pytest

from atlas_sdk import (
    AgentConfiguration,
    AtlasConnectionError,
    ControlPlaneClient,
    DeploymentContext,
    HeartbeatStatus,
    LifecycleState,
)


@pytest.fixture
def mock_config() -> AgentConfiguration:
    """Create a test agent configuration."""
    return AgentConfiguration(
        model_provider="anthropic",
        model_name="claude-sonnet-4-20250514",
        tools=["file_read"],
    )


@pytest.fixture
def mock_register_response() -> dict:
    """Create a mock registration response."""
    return {
        "agent_id": "12345678-1234-5678-1234-567812345678",
        "lifecycle_state": "active",
        "next_heartbeat_due": datetime.now(UTC).isoformat(),
    }


@pytest.fixture
def mock_heartbeat_response() -> dict:
    """Create a mock heartbeat response."""
    return {
        "acknowledged": True,
        "next_heartbeat_due": datetime.now(UTC).isoformat(),
        "directives": [],
    }


@pytest.fixture
def mock_deregister_response() -> dict:
    """Create a mock deregister response."""
    return {
        "agent_id": "12345678-1234-5678-1234-567812345678",
        "lifecycle_state": "terminated",
        "terminated_at": datetime.now(UTC).isoformat(),
    }


class TestControlPlaneClientInit:
    """Tests for client initialization."""

    def test_default_initialization(self) -> None:
        """Client initializes with default values."""
        client = ControlPlaneClient()
        assert client.agent_id is None
        assert client.is_registered is False

    def test_custom_base_url(self) -> None:
        """Client accepts custom base URL."""
        client = ControlPlaneClient(base_url="https://custom.api.com")
        assert client._base_url == "https://custom.api.com"

    def test_base_url_strips_trailing_slash(self) -> None:
        """Trailing slash is stripped from base URL."""
        client = ControlPlaneClient(base_url="https://api.example.com/")
        assert client._base_url == "https://api.example.com"

    def test_env_var_base_url(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Client reads base URL from ATLAS_API_URL env var."""
        monkeypatch.setenv("ATLAS_API_URL", "https://env.api.com")
        client = ControlPlaneClient()
        assert client._base_url == "https://env.api.com"

    def test_env_var_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Client reads API key from ATLAS_API_KEY env var."""
        monkeypatch.setenv("ATLAS_API_KEY", "test-key")
        client = ControlPlaneClient()
        assert client._api_key == "test-key"

    def test_disabled_via_env_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Client can be disabled via ATLAS_DISABLED env var."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")
        client = ControlPlaneClient()
        assert client._disabled is True

    @pytest.mark.parametrize("value", ["true", "1", "yes", "TRUE"])
    def test_disabled_various_truthy_values(
        self, monkeypatch: pytest.MonkeyPatch, value: str
    ) -> None:
        """Various truthy values for ATLAS_DISABLED work."""
        monkeypatch.setenv("ATLAS_DISABLED", value)
        client = ControlPlaneClient()
        assert client._disabled is True

    def test_custom_timeout(self) -> None:
        """Client accepts custom timeout."""
        client = ControlPlaneClient(timeout=60.0)
        assert client._timeout == 60.0

    def test_custom_heartbeat_interval(self) -> None:
        """Client accepts custom heartbeat interval."""
        client = ControlPlaneClient(heartbeat_interval_seconds=120)
        assert client._heartbeat_interval == 120


class TestControlPlaneClientRegister:
    """Tests for agent registration."""

    def test_register_success(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Successful registration returns RegisterResponse."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = mock_register_response

        with (
            patch.object(client, "_execute_with_retry", return_value=mock_response),
            patch.object(client, "_setup_shutdown_handlers"),
        ):
            result = client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

        assert result is not None
        assert result.lifecycle_state == LifecycleState.ACTIVE
        assert client.is_registered is True
        assert client.agent_id is not None

    def test_register_disabled_returns_none(
        self,
        mock_config: AgentConfiguration,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration returns None when SDK is disabled."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")
        client = ControlPlaneClient()

        result = client.register(
            name="test-agent",
            owner="test@example.com",
            configuration=mock_config,
        )

        assert result is None
        assert client.is_registered is False

    def test_register_already_registered_returns_none(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration returns None if already registered."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = mock_register_response

        with (
            patch.object(client, "_execute_with_retry", return_value=mock_response),
            patch.object(client, "_setup_shutdown_handlers"),
        ):
            client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            # Second registration
            result = client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

        assert result is None

    def test_register_with_deployment_context(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration includes provided deployment context."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
            auto_detect_context=False,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = mock_register_response

        context = DeploymentContext(
            hostname="test-host",
            environment="production",
        )

        with patch.object(client, "_execute_with_retry", return_value=mock_response) as mock_exec:
            client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
                deployment_context=context,
            )

            # Verify context was included in payload
            call_args = mock_exec.call_args
            payload = call_args.kwargs["json_data"]
            assert "deployment_context" in payload
            assert payload["deployment_context"]["hostname"] == "test-host"

    def test_register_fail_silently_logs_error(
        self,
        mock_config: AgentConfiguration,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration with fail_silently=True logs error and returns None."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            fail_silently=True,
            auto_heartbeat=False,
        )

        with patch.object(
            client, "_execute_with_retry", side_effect=AtlasConnectionError("Network error")
        ):
            result = client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

        assert result is None
        assert client.is_registered is False

    def test_register_fail_silently_false_raises(
        self,
        mock_config: AgentConfiguration,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Registration with fail_silently=False raises exception."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            fail_silently=False,
            auto_heartbeat=False,
        )

        with (
            patch.object(
                client, "_execute_with_retry", side_effect=AtlasConnectionError("Network error")
            ),
            pytest.raises(AtlasConnectionError),
        ):
            client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )


class TestControlPlaneClientHeartbeat:
    """Tests for heartbeat sending."""

    def test_heartbeat_success(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_heartbeat_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Successful heartbeat returns HeartbeatResponse."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        # First register
        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        heartbeat_mock = MagicMock(spec=httpx.Response)
        heartbeat_mock.status_code = 200
        heartbeat_mock.json.return_value = mock_heartbeat_response

        with (
            patch.object(
                client, "_execute_with_retry", side_effect=[register_mock, heartbeat_mock]
            ),
            patch.object(client, "_setup_shutdown_handlers"),
        ):
            client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            result = client.heartbeat()

        assert result is not None
        assert result.acknowledged is True

    def test_heartbeat_not_registered_returns_none(self) -> None:
        """Heartbeat returns None if not registered."""
        client = ControlPlaneClient(base_url="https://api.test.com")
        result = client.heartbeat()
        assert result is None

    def test_heartbeat_disabled_returns_none(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Heartbeat returns None when SDK is disabled."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")
        client = ControlPlaneClient()
        result = client.heartbeat()
        assert result is None

    def test_heartbeat_with_status_and_metrics(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_heartbeat_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Heartbeat includes status and metrics in payload."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        heartbeat_mock = MagicMock(spec=httpx.Response)
        heartbeat_mock.status_code = 200
        heartbeat_mock.json.return_value = mock_heartbeat_response

        with (
            patch.object(
                client, "_execute_with_retry", side_effect=[register_mock, heartbeat_mock]
            ) as mock_exec,
            patch.object(client, "_setup_shutdown_handlers"),
        ):
            client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            client.heartbeat(
                status=HeartbeatStatus.DEGRADED,
                metrics={"cpu": 80, "memory": 1024},
            )

            # Get the second call (heartbeat)
            heartbeat_call = mock_exec.call_args_list[1]
            payload = heartbeat_call.kwargs["json_data"]
            assert payload["status"] == "degraded"
            assert payload["metrics"] == {"cpu": 80, "memory": 1024}


class TestControlPlaneClientDeregister:
    """Tests for agent deregistration."""

    def test_deregister_success(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_deregister_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Successful deregistration returns DeregisterResponse."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        deregister_mock = MagicMock(spec=httpx.Response)
        deregister_mock.status_code = 200
        deregister_mock.json.return_value = mock_deregister_response

        with (
            patch.object(
                client, "_execute_with_retry", side_effect=[register_mock, deregister_mock]
            ),
            patch.object(client, "_setup_shutdown_handlers"),
            patch.object(client, "_cleanup_shutdown_handlers"),
        ):
            client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )
            result = client.deregister()

        assert result is not None
        assert result.lifecycle_state == LifecycleState.TERMINATED
        assert client.is_registered is False

    def test_deregister_not_registered_returns_none(self) -> None:
        """Deregister returns None if not registered."""
        client = ControlPlaneClient(base_url="https://api.test.com")
        result = client.deregister()
        assert result is None


class TestControlPlaneClientContextManager:
    """Tests for context manager support."""

    def test_context_manager_closes_on_exit(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        mock_deregister_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Context manager deregisters on exit."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        deregister_mock = MagicMock(spec=httpx.Response)
        deregister_mock.status_code = 200
        deregister_mock.json.return_value = mock_deregister_response

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        with (
            patch.object(
                client, "_execute_with_retry", side_effect=[register_mock, deregister_mock]
            ),
            patch.object(client, "_setup_shutdown_handlers"),
            patch.object(client, "_cleanup_shutdown_handlers"),
        ):
            with client:
                client.register(
                    name="test-agent",
                    owner="test@example.com",
                    configuration=mock_config,
                )
                assert client.is_registered is True
            # After context manager exit, should be deregistered
            assert client.is_registered is False


class TestControlPlaneClientRetryLogic:
    """Tests for HTTP retry logic."""

    def test_connection_error_triggers_retry(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Connection errors are retried."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            max_retries=2,
        )

        mock_client = MagicMock()
        mock_client.request.side_effect = httpx.RequestError("Connection failed")

        with (
            patch.object(client, "_get_http_client", return_value=mock_client),
            patch("atlas_sdk.client.time.sleep"),
            pytest.raises(AtlasConnectionError),
        ):
            client._execute_with_retry("GET", "/test")

        # Should have tried max_retries times
        assert mock_client.request.call_count == 2

    def test_rate_limit_with_retry_after_sleeps(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Rate limit error with retry_after header causes sleep."""
        from atlas_sdk.exceptions import RateLimitError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            max_retries=2,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 429
        mock_response.headers = {"Retry-After": "5"}

        mock_client = MagicMock()
        mock_client.request.return_value = mock_response

        with (
            patch.object(client, "_get_http_client", return_value=mock_client),
            patch("atlas_sdk.client.time.sleep") as mock_sleep,
            pytest.raises(RateLimitError),
        ):
            client._execute_with_retry("GET", "/test")

        # Should have slept for retry_after value
        mock_sleep.assert_any_call(5.0)

    def test_non_retryable_error_raises_immediately(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Non-retryable errors (4xx) raise immediately without retry."""
        from atlas_sdk.exceptions import AuthenticationError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            max_retries=3,
        )

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 401

        mock_client = MagicMock()
        mock_client.request.return_value = mock_response

        with (
            patch.object(client, "_get_http_client", return_value=mock_client),
            pytest.raises(AuthenticationError),
        ):
            client._execute_with_retry("GET", "/test")

        # Should have only tried once (no retry for 401)
        assert mock_client.request.call_count == 1


class TestControlPlaneClientDisabled:
    """Tests for disabled SDK behavior."""

    def test_update_configuration_when_disabled(
        self, mock_config: AgentConfiguration, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """update_configuration returns None when SDK is disabled."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")

        client = ControlPlaneClient(base_url="https://api.test.com")
        result = client.update_configuration(mock_config)
        assert result is None

    def test_deregister_when_disabled(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """deregister returns None when SDK is disabled."""
        monkeypatch.setenv("ATLAS_DISABLED", "true")

        client = ControlPlaneClient(base_url="https://api.test.com")
        result = client.deregister()
        assert result is None


class TestControlPlaneClientHeartbeatLoop:
    """Tests for background heartbeat loop."""

    def test_heartbeat_loop_starts_and_stops(
        self,
        mock_config: AgentConfiguration,
        mock_register_response: dict,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Heartbeat loop can be started and stopped."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,  # We'll start it manually
            heartbeat_interval_seconds=1,
        )

        # Mock registration
        register_mock = MagicMock(spec=httpx.Response)
        register_mock.status_code = 200
        register_mock.json.return_value = mock_register_response

        with (
            patch.object(client, "_execute_with_retry", return_value=register_mock),
            patch.object(client, "_setup_shutdown_handlers"),
        ):
            client.register(
                name="test-agent",
                owner="test@example.com",
                configuration=mock_config,
            )

        # Manually start heartbeat
        client._start_heartbeat_loop()
        assert client._heartbeat_thread is not None
        assert client._heartbeat_thread.is_alive()

        # Stop heartbeat
        client._stop_heartbeat_loop()
        assert client._heartbeat_thread is None

    def test_heartbeat_loop_already_running_noop(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Starting heartbeat when already running does nothing."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )
        client._registered = True

        # Create a mock thread
        mock_thread = MagicMock()
        client._heartbeat_thread = mock_thread

        # Try to start again
        client._start_heartbeat_loop()

        # Should still be the same thread (not replaced)
        assert client._heartbeat_thread is mock_thread


class TestControlPlaneClientErrorPaths:
    """Tests for error handling paths."""

    def test_heartbeat_error_with_fail_silently(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Heartbeat errors are logged when fail_silently=True."""
        from atlas_sdk.exceptions import AtlasError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
            fail_silently=True,
        )

        # Set up as registered
        client._registered = True
        client._agent_id = MagicMock()

        with patch.object(client, "_execute_with_retry", side_effect=AtlasError("Server error")):
            result = client.heartbeat()
            assert result is None  # Should return None, not raise

    def test_deregister_error_cleans_up(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Deregister errors still mark client as not registered."""
        from atlas_sdk.exceptions import AtlasError

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
            fail_silently=True,
        )

        # Set up as registered
        client._registered = True
        client._agent_id = MagicMock()

        with (
            patch.object(client, "_execute_with_retry", side_effect=AtlasError("Error")),
            patch.object(client, "_stop_heartbeat_loop"),
            patch.object(client, "_cleanup_shutdown_handlers"),
        ):
            result = client.deregister()
            assert result is None
            assert client._registered is False  # Should be marked as not registered


class TestControlPlaneClientSignalHandlers:
    """Tests for signal and atexit handlers."""

    def test_atexit_handler_deregisters(
        self, mock_deregister_response: dict, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Atexit handler calls deregister when registered."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )
        client._registered = True
        client._agent_id = MagicMock()

        deregister_mock = MagicMock(spec=httpx.Response)
        deregister_mock.status_code = 200
        deregister_mock.json.return_value = mock_deregister_response

        with (
            patch.object(client, "_execute_with_retry", return_value=deregister_mock),
            patch.object(client, "_stop_heartbeat_loop"),
            patch.object(client, "_cleanup_shutdown_handlers"),
        ):
            client._atexit_handler()
            assert client._registered is False

    def test_signal_handler_deregisters(
        self, mock_deregister_response: dict, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Signal handler calls deregister when registered."""
        import signal

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )
        client._registered = True
        client._agent_id = MagicMock()
        client._original_sigterm = None
        client._original_sigint = None

        deregister_mock = MagicMock(spec=httpx.Response)
        deregister_mock.status_code = 200
        deregister_mock.json.return_value = mock_deregister_response

        with (
            patch.object(client, "_execute_with_retry", return_value=deregister_mock),
            patch.object(client, "_stop_heartbeat_loop"),
            patch.object(client, "_cleanup_shutdown_handlers"),
        ):
            client._signal_handler(signal.SIGTERM, None)
            assert client._registered is False

    def test_signal_handler_calls_original(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Signal handler calls original handler after deregister."""
        import signal

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )
        client._registered = False  # Not registered, skip deregister

        original_handler = MagicMock()
        client._original_sigterm = original_handler

        client._signal_handler(signal.SIGTERM, None)

        original_handler.assert_called_once_with(signal.SIGTERM, None)

    def test_cleanup_shutdown_handlers_restores_signals(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Cleanup restores original signal handlers."""
        import signal

        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")

        client = ControlPlaneClient(
            base_url="https://api.test.com",
            auto_heartbeat=False,
        )

        original_sigterm = MagicMock()
        original_sigint = MagicMock()
        client._original_sigterm = original_sigterm
        client._original_sigint = original_sigint

        with patch("atlas_sdk.client.signal.signal") as mock_signal:
            client._cleanup_shutdown_handlers()

            # Should restore both handlers
            mock_signal.assert_any_call(signal.SIGTERM, original_sigterm)
            mock_signal.assert_any_call(signal.SIGINT, original_sigint)
