"""Unit tests for context detection."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from atlas_sdk.context import (
    _detect_environment,
    _detect_filesystem_access,
    _detect_hostname,
    _detect_internet_access,
    _infer_environment_from_hostname,
    _is_containerized,
    detect_context,
)


class TestDetectContext:
    """Tests for the main detect_context function."""

    def test_returns_deployment_context(self) -> None:
        """detect_context returns a DeploymentContext instance."""
        ctx = detect_context()
        assert ctx is not None
        # Should have at least hostname populated on most systems
        assert hasattr(ctx, "hostname")
        assert hasattr(ctx, "environment")
        assert hasattr(ctx, "has_internet_access")
        assert hasattr(ctx, "has_filesystem_access")

    def test_skip_detection_via_env_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """ATLAS_SKIP_CONTEXT_DETECTION=true returns empty context."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "true")
        ctx = detect_context()
        assert ctx.hostname is None
        assert ctx.environment is None
        assert ctx.has_internet_access is None
        assert ctx.has_filesystem_access is None

    @pytest.mark.parametrize("value", ["true", "1", "yes", "TRUE", "Yes"])
    def test_skip_detection_various_truthy_values(
        self, monkeypatch: pytest.MonkeyPatch, value: str
    ) -> None:
        """Various truthy values for ATLAS_SKIP_CONTEXT_DETECTION work."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", value)
        ctx = detect_context()
        assert ctx.hostname is None

    def test_skip_detection_false_does_not_skip(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """ATLAS_SKIP_CONTEXT_DETECTION=false does not skip detection."""
        monkeypatch.setenv("ATLAS_SKIP_CONTEXT_DETECTION", "false")
        ctx = detect_context()
        # Should have hostname populated
        assert ctx.hostname is not None


class TestDetectHostname:
    """Tests for hostname detection."""

    def test_returns_string(self) -> None:
        """_detect_hostname returns a string on most systems."""
        hostname = _detect_hostname()
        assert hostname is not None
        assert isinstance(hostname, str)
        assert len(hostname) > 0

    def test_handles_exception(self) -> None:
        """_detect_hostname returns None on exception."""
        with patch("atlas_sdk.context.socket.gethostname", side_effect=OSError("mocked")):
            hostname = _detect_hostname()
            assert hostname is None


class TestDetectEnvironment:
    """Tests for environment detection."""

    def test_explicit_env_var_takes_precedence(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """ATLAS_ENVIRONMENT env var overrides hostname inference."""
        monkeypatch.setenv("ATLAS_ENVIRONMENT", "PRODUCTION")
        env = _detect_environment()
        assert env == "production"  # lowercased

    def test_infers_from_hostname(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Environment is inferred from hostname when env var not set."""
        monkeypatch.delenv("ATLAS_ENVIRONMENT", raising=False)
        with patch("atlas_sdk.context.socket.gethostname", return_value="prod-server-01"):
            env = _detect_environment()
            assert env == "production"

    def test_handles_exception(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """_detect_environment returns None on exception."""
        monkeypatch.delenv("ATLAS_ENVIRONMENT", raising=False)
        with patch("atlas_sdk.context.socket.gethostname", side_effect=OSError("mocked")):
            env = _detect_environment()
            assert env is None


class TestInferEnvironmentFromHostname:
    """Tests for hostname-based environment inference."""

    @pytest.mark.parametrize(
        ("hostname", "expected"),
        [
            ("prod-server-01", "production"),
            ("production-api", "production"),
            ("prd-web-001", "production"),
            ("staging-api", "staging"),
            ("stag-server", "staging"),
            ("stg-web-001", "staging"),
            ("dev-machine", "development"),
            ("develop-api", "development"),
            ("localhost", "local"),
            ("local-dev", "local"),
            ("test-runner", "test"),
            ("my-app-prod", "production"),
            ("api-staging-01", "staging"),
            ("api-dev-01", "development"),
            ("my-develop-app", "development"),
            ("random-server", None),
            ("unknown", None),
        ],
    )
    def test_hostname_patterns(self, hostname: str, expected: str | None) -> None:
        """Various hostname patterns are correctly identified."""
        result = _infer_environment_from_hostname(hostname)
        assert result == expected


class TestDetectInternetAccess:
    """Tests for internet access detection."""

    def test_returns_bool_or_none(self) -> None:
        """_detect_internet_access returns bool or None."""
        result = _detect_internet_access()
        assert result is None or isinstance(result, bool)

    def test_successful_connection_returns_true(self) -> None:
        """Successful socket connection returns True."""
        mock_socket = MagicMock()
        with patch("atlas_sdk.context.socket.socket", return_value=mock_socket):
            result = _detect_internet_access()
            assert result is True
            mock_socket.connect.assert_called_once()
            mock_socket.close.assert_called_once()

    def test_connection_failure_returns_false(self) -> None:
        """Failed socket connection returns False."""
        mock_socket = MagicMock()
        mock_socket.connect.side_effect = OSError("Connection refused")
        with patch("atlas_sdk.context.socket.socket", return_value=mock_socket):
            result = _detect_internet_access()
            assert result is False
            mock_socket.close.assert_called_once()

    def test_timeout_returns_false(self) -> None:
        """Timeout returns False."""
        mock_socket = MagicMock()
        mock_socket.connect.side_effect = TimeoutError("timed out")
        with patch("atlas_sdk.context.socket.socket", return_value=mock_socket):
            result = _detect_internet_access()
            assert result is False

    def test_socket_creation_failure_returns_none(self) -> None:
        """Socket creation failure returns None."""
        with patch("atlas_sdk.context.socket.socket", side_effect=OSError("mocked")):
            result = _detect_internet_access()
            assert result is None


class TestDetectFilesystemAccess:
    """Tests for filesystem access detection."""

    def test_not_containerized_returns_true(self) -> None:
        """Non-containerized environment returns True."""
        with patch("atlas_sdk.context._is_containerized", return_value=False):
            result = _detect_filesystem_access()
            assert result is True

    def test_containerized_returns_false(self) -> None:
        """Containerized environment returns False."""
        with patch("atlas_sdk.context._is_containerized", return_value=True):
            result = _detect_filesystem_access()
            assert result is False

    def test_unknown_returns_none(self) -> None:
        """Unknown container status returns None."""
        with patch("atlas_sdk.context._is_containerized", return_value=None):
            result = _detect_filesystem_access()
            assert result is None

    def test_exception_returns_none(self) -> None:
        """Exception during detection returns None."""
        with patch("atlas_sdk.context._is_containerized", side_effect=Exception("mocked")):
            result = _detect_filesystem_access()
            assert result is None


class TestIsContainerized:
    """Tests for container detection."""

    def test_dockerenv_file_detected(self, tmp_path: pytest.TempPathFactory) -> None:
        """/.dockerenv file indicates container."""
        with patch("atlas_sdk.context.CONTAINER_INDICATORS", (str(tmp_path / ".dockerenv"),)):
            # Create the indicator file
            (tmp_path / ".dockerenv").touch()
            with patch("atlas_sdk.context.Path") as mock_path:
                mock_path.return_value.exists.return_value = True
                result = _is_containerized()
                assert result is True

    def test_no_indicators_returns_false(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """No container indicators returns False."""
        # Clear container env vars
        monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
        monkeypatch.delenv("DOCKER_CONTAINER", raising=False)
        monkeypatch.delenv("container", raising=False)

        with (
            patch("atlas_sdk.context.Path") as mock_path,
        ):
            mock_path.return_value.exists.return_value = False
            result = _is_containerized()
            assert result is False

    def test_kubernetes_env_var_detected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """KUBERNETES_SERVICE_HOST indicates container."""
        monkeypatch.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        with patch("atlas_sdk.context.Path") as mock_path:
            mock_path.return_value.exists.return_value = False
            result = _is_containerized()
            assert result is True

    def test_docker_container_env_var_detected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """DOCKER_CONTAINER env var indicates container."""
        monkeypatch.setenv("DOCKER_CONTAINER", "true")
        monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
        with patch("atlas_sdk.context.Path") as mock_path:
            mock_path.return_value.exists.return_value = False
            result = _is_containerized()
            assert result is True

    def test_cgroup_marker_detected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Cgroup file with docker marker indicates container."""

        monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
        monkeypatch.delenv("DOCKER_CONTAINER", raising=False)
        monkeypatch.delenv("container", raising=False)

        def mock_path_factory(path: str) -> MagicMock:
            mock = MagicMock()
            if path == "/proc/1/cgroup":
                mock.exists.return_value = True
                mock.read_text.return_value = "12:memory:/docker/abc123"
            else:
                mock.exists.return_value = False
            return mock

        with (
            patch("atlas_sdk.context.Path", side_effect=mock_path_factory),
            patch("atlas_sdk.context.CONTAINER_INDICATORS", ()),
            patch("atlas_sdk.context.CGROUP_PATHS", ("/proc/1/cgroup",)),
        ):
            result = _is_containerized()
            assert result is True

    def test_cgroup_permission_error_handled(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Permission error reading cgroup file is handled."""
        monkeypatch.delenv("KUBERNETES_SERVICE_HOST", raising=False)
        monkeypatch.delenv("DOCKER_CONTAINER", raising=False)
        monkeypatch.delenv("container", raising=False)

        def mock_path_factory(path: str) -> MagicMock:
            mock = MagicMock()
            if path == "/proc/1/cgroup":
                mock.exists.return_value = True
                mock.read_text.side_effect = PermissionError("denied")
            else:
                mock.exists.return_value = False
            return mock

        with (
            patch("atlas_sdk.context.Path", side_effect=mock_path_factory),
            patch("atlas_sdk.context.CONTAINER_INDICATORS", ()),
            patch("atlas_sdk.context.CGROUP_PATHS", ("/proc/1/cgroup",)),
        ):
            result = _is_containerized()
            # Should return False (no container found, permission error was swallowed)
            assert result is False
