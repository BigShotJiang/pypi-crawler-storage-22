"""Tests for shared HTTP utilities."""

from __future__ import annotations

from unittest.mock import MagicMock
from uuid import uuid4

import httpx
import pytest

from atlas_sdk._http import (
    DEFAULT_HEARTBEAT_INTERVAL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_BASE_DELAY,
    DEFAULT_TIMEOUT,
    build_auth_headers,
    build_registration_payload,
    handle_error,
    handle_response_error,
    should_retry,
)
from atlas_sdk.exceptions import (
    AgentNotFoundError,
    AtlasConnectionError,
    AtlasError,
    AtlasValidationError,
    AuthenticationError,
    AuthorizationError,
    DuplicateAgentError,
    RateLimitError,
)
from atlas_sdk.models import AgentConfiguration


class TestConstants:
    """Tests for default configuration constants."""

    def test_default_timeout(self) -> None:
        """Default timeout is 30 seconds."""
        assert DEFAULT_TIMEOUT == 30.0

    def test_default_heartbeat_interval(self) -> None:
        """Default heartbeat interval is 5 minutes."""
        assert DEFAULT_HEARTBEAT_INTERVAL == 300

    def test_default_max_retries(self) -> None:
        """Default max retries is 3."""
        assert DEFAULT_MAX_RETRIES == 3

    def test_default_retry_base_delay(self) -> None:
        """Default retry base delay is 1 second."""
        assert DEFAULT_RETRY_BASE_DELAY == 1.0


class TestHandleResponseError:
    """Tests for HTTP response error handling."""

    def test_401_raises_authentication_error(self) -> None:
        """401 response raises AuthenticationError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 401

        with pytest.raises(AuthenticationError):
            handle_response_error(mock_response)

    def test_403_raises_authorization_error(self) -> None:
        """403 response raises AuthorizationError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 403

        with pytest.raises(AuthorizationError):
            handle_response_error(mock_response)

    def test_404_raises_agent_not_found_error(self) -> None:
        """404 response raises AgentNotFoundError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 404
        agent_id = uuid4()

        with pytest.raises(AgentNotFoundError) as exc_info:
            handle_response_error(mock_response, agent_id)

        assert str(agent_id) in str(exc_info.value)

    def test_404_with_no_agent_id(self) -> None:
        """404 response with no agent_id uses 'unknown'."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 404

        with pytest.raises(AgentNotFoundError) as exc_info:
            handle_response_error(mock_response)

        assert "unknown" in str(exc_info.value)

    def test_409_raises_duplicate_agent_error(self) -> None:
        """409 response raises DuplicateAgentError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 409
        agent_id = uuid4()

        with pytest.raises(DuplicateAgentError) as exc_info:
            handle_response_error(mock_response, agent_id)

        assert str(agent_id) in str(exc_info.value)

    def test_422_raises_validation_error_with_details(self) -> None:
        """422 response raises AtlasValidationError with details."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 422
        mock_response.json.return_value = {"field": "name", "error": "required"}

        with pytest.raises(AtlasValidationError) as exc_info:
            handle_response_error(mock_response)

        assert exc_info.value.details == {"field": "name", "error": "required"}

    def test_422_raises_validation_error_with_invalid_json(self) -> None:
        """422 response with invalid JSON uses empty details."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 422
        mock_response.json.side_effect = ValueError("Invalid JSON")

        with pytest.raises(AtlasValidationError) as exc_info:
            handle_response_error(mock_response)

        assert exc_info.value.details == {}

    def test_429_raises_rate_limit_error_with_retry_after(self) -> None:
        """429 response raises RateLimitError with retry_after."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 429
        mock_response.headers = {"Retry-After": "30"}

        with pytest.raises(RateLimitError) as exc_info:
            handle_response_error(mock_response)

        assert exc_info.value.retry_after == 30.0

    def test_429_raises_rate_limit_error_without_retry_after(self) -> None:
        """429 response without Retry-After header."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 429
        mock_response.headers = {}

        with pytest.raises(RateLimitError) as exc_info:
            handle_response_error(mock_response)

        assert exc_info.value.retry_after is None

    def test_5xx_raises_atlas_error(self) -> None:
        """5xx response raises AtlasError with status code."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 503

        with pytest.raises(AtlasError) as exc_info:
            handle_response_error(mock_response)

        assert exc_info.value.status_code == 503
        assert "Server error" in str(exc_info.value)

    def test_500_raises_atlas_error(self) -> None:
        """500 response raises AtlasError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 500

        with pytest.raises(AtlasError) as exc_info:
            handle_response_error(mock_response)

        assert exc_info.value.status_code == 500

    def test_4xx_raises_atlas_error(self) -> None:
        """Other 4xx responses raise AtlasError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 418  # I'm a teapot

        with pytest.raises(AtlasError) as exc_info:
            handle_response_error(mock_response)

        assert exc_info.value.status_code == 418
        assert "Request error" in str(exc_info.value)

    def test_success_codes_do_nothing(self) -> None:
        """Success codes (2xx, 3xx) don't raise."""
        for status in [200, 201, 204, 301, 302]:
            mock_response = MagicMock(spec=httpx.Response)
            mock_response.status_code = status
            # Should not raise
            handle_response_error(mock_response)


class TestShouldRetry:
    """Tests for retry logic."""

    def test_connection_error_should_retry(self) -> None:
        """Connection errors should be retried."""
        error = AtlasConnectionError("Network error")
        assert should_retry(error) is True

    def test_rate_limit_error_should_retry(self) -> None:
        """Rate limit errors should be retried."""
        error = RateLimitError()
        assert should_retry(error) is True

    def test_rate_limit_error_with_retry_after_should_retry(self) -> None:
        """Rate limit errors with retry_after should be retried."""
        error = RateLimitError(retry_after=30.0)
        assert should_retry(error) is True

    def test_5xx_error_should_retry(self) -> None:
        """5xx errors should be retried."""
        error = AtlasError("Server error", status_code=503)
        assert should_retry(error) is True

    def test_500_error_should_retry(self) -> None:
        """500 errors should be retried."""
        error = AtlasError("Internal server error", status_code=500)
        assert should_retry(error) is True

    def test_4xx_error_should_not_retry(self) -> None:
        """4xx errors should not be retried."""
        error = AtlasError("Bad request", status_code=400)
        assert should_retry(error) is False

    def test_authentication_error_should_not_retry(self) -> None:
        """Authentication errors should not be retried."""
        error = AuthenticationError()
        assert should_retry(error) is False

    def test_authorization_error_should_not_retry(self) -> None:
        """Authorization errors should not be retried."""
        error = AuthorizationError()
        assert should_retry(error) is False

    def test_validation_error_should_not_retry(self) -> None:
        """Validation errors should not be retried."""
        error = AtlasValidationError("Invalid", details={})
        assert should_retry(error) is False

    def test_atlas_error_without_status_code_should_not_retry(self) -> None:
        """AtlasError without status_code should not be retried."""
        error = AtlasError("Unknown error")
        assert should_retry(error) is False

    def test_generic_exception_should_not_retry(self) -> None:
        """Generic exceptions should not be retried."""
        error = ValueError("Some error")
        assert should_retry(error) is False


class TestHandleError:
    """Tests for error handling based on fail_silently."""

    def test_fail_silently_true_logs_warning(self, caplog: pytest.LogCaptureFixture) -> None:
        """When fail_silently=True, errors are logged."""
        import logging

        caplog.set_level(logging.WARNING)
        error = AtlasError("Test error")

        handle_error(error, "test operation", fail_silently=True)

        assert "Atlas test operation failed" in caplog.text
        assert "Test error" in caplog.text

    def test_fail_silently_false_raises(self) -> None:
        """When fail_silently=False, errors are raised."""
        error = AtlasError("Test error")

        with pytest.raises(AtlasError) as exc_info:
            handle_error(error, "test operation", fail_silently=False)

        assert exc_info.value is error

    def test_fail_silently_false_preserves_exception_type(self) -> None:
        """When fail_silently=False, original exception type is preserved."""
        error = AuthenticationError()

        with pytest.raises(AuthenticationError):
            handle_error(error, "auth", fail_silently=False)


class TestBuildAuthHeaders:
    """Tests for building authentication headers."""

    def test_with_api_key(self) -> None:
        """Headers include Bearer token when api_key provided."""
        headers = build_auth_headers("test-api-key")

        assert headers["Content-Type"] == "application/json"
        assert headers["Authorization"] == "Bearer test-api-key"

    def test_without_api_key(self) -> None:
        """Headers don't include Authorization when api_key is None."""
        headers = build_auth_headers(None)

        assert headers["Content-Type"] == "application/json"
        assert "Authorization" not in headers

    def test_with_empty_api_key(self) -> None:
        """Empty string api_key is treated as falsy."""
        headers = build_auth_headers("")

        assert "Authorization" not in headers


class TestBuildRegistrationPayload:
    """Tests for building registration payloads."""

    def test_minimal_payload(self) -> None:
        """Build payload with required fields only."""
        agent_id = uuid4()
        config = AgentConfiguration(
            model_provider="anthropic",
            model_name="claude-sonnet-4-20250514",
        )

        payload = build_registration_payload(
            agent_id=agent_id,
            name="test-agent",
            owner="test@example.com",
            configuration=config,
            heartbeat_interval=300,
        )

        assert payload["agent_id"] == str(agent_id)
        assert payload["name"] == "test-agent"
        assert payload["owner"] == "test@example.com"
        assert payload["heartbeat_interval_seconds"] == 300
        assert payload["configuration"]["model_provider"] == "anthropic"
        assert "definition_id" not in payload
        assert "deployment_context" not in payload

    def test_with_definition_id(self) -> None:
        """Build payload with definition_id."""
        agent_id = uuid4()
        config = AgentConfiguration(
            model_provider="anthropic",
            model_name="claude-sonnet-4-20250514",
        )

        payload = build_registration_payload(
            agent_id=agent_id,
            name="test-agent",
            owner="test@example.com",
            configuration=config,
            heartbeat_interval=300,
            definition_id="def-123",
        )

        assert payload["definition_id"] == "def-123"

    def test_with_deployment_context(self) -> None:
        """Build payload with deployment_context."""
        from atlas_sdk.models import DeploymentContext

        agent_id = uuid4()
        config = AgentConfiguration(
            model_provider="anthropic",
            model_name="claude-sonnet-4-20250514",
        )
        context = DeploymentContext(hostname="test-host", environment="production")

        payload = build_registration_payload(
            agent_id=agent_id,
            name="test-agent",
            owner="test@example.com",
            configuration=config,
            heartbeat_interval=300,
            deployment_context=context,
        )

        assert payload["deployment_context"]["hostname"] == "test-host"
        assert payload["deployment_context"]["environment"] == "production"
