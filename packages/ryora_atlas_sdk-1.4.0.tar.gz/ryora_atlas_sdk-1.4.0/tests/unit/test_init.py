"""Unit tests for atlas_sdk package initialization."""

import pytest

import atlas_sdk


@pytest.mark.unit
def test_version_exists() -> None:
    """Verify that the package has a version attribute."""
    assert hasattr(atlas_sdk, "__version__")
    assert isinstance(atlas_sdk.__version__, str)


@pytest.mark.unit
def test_version_format() -> None:
    """Verify that the version follows semver format."""
    version = atlas_sdk.__version__
    parts = version.split(".")
    assert len(parts) >= 2, "Version should have at least major.minor"
    assert all(part.isdigit() for part in parts[:2]), "Major and minor should be numeric"
