"""Unit tests for Pydantic models."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID

import pytest
from pydantic import ValidationError

from atlas_sdk import (
    AgentConfiguration,
    DeploymentContext,
    DeregisterResponse,
    Directive,
    DirectiveType,
    GraspAssessment,
    HeartbeatResponse,
    HeartbeatStatus,
    LifecycleState,
    RegisterResponse,
    ResourceLimits,
    RiskLevel,
    UpdateConfigurationResponse,
)


class TestEnums:
    """Tests for enumeration types."""

    def test_lifecycle_state_values(self) -> None:
        """LifecycleState has expected values."""
        assert LifecycleState.ACTIVE.value == "active"
        assert LifecycleState.INACTIVE.value == "inactive"
        assert LifecycleState.SUSPENDED.value == "suspended"
        assert LifecycleState.TERMINATED.value == "terminated"

    def test_risk_level_values(self) -> None:
        """RiskLevel has expected values."""
        assert RiskLevel.LOW.value == "low"
        assert RiskLevel.MEDIUM.value == "medium"
        assert RiskLevel.HIGH.value == "high"
        assert RiskLevel.CRITICAL.value == "critical"

    def test_heartbeat_status_values(self) -> None:
        """HeartbeatStatus has expected values."""
        assert HeartbeatStatus.HEALTHY.value == "healthy"
        assert HeartbeatStatus.DEGRADED.value == "degraded"
        assert HeartbeatStatus.UNHEALTHY.value == "unhealthy"

    def test_directive_type_values(self) -> None:
        """DirectiveType has expected values."""
        assert DirectiveType.SHUTDOWN.value == "shutdown"
        assert DirectiveType.RECONFIGURE.value == "reconfigure"
        assert DirectiveType.RATE_LIMIT.value == "rate_limit"
        assert DirectiveType.SUSPEND.value == "suspend"


class TestResourceLimits:
    """Tests for ResourceLimits model."""

    def test_all_fields_optional(self) -> None:
        """All fields in ResourceLimits are optional."""
        limits = ResourceLimits()
        assert limits.max_memory_mb is None
        assert limits.max_cpu_cores is None
        assert limits.max_disk_mb is None
        assert limits.max_network_bandwidth_mbps is None

    def test_with_values(self) -> None:
        """ResourceLimits accepts values."""
        limits = ResourceLimits(
            max_memory_mb=1024,
            max_cpu_cores=4,
            max_disk_mb=10240,
            max_network_bandwidth_mbps=100,
        )
        assert limits.max_memory_mb == 1024
        assert limits.max_cpu_cores == 4


class TestDeploymentContext:
    """Tests for DeploymentContext model."""

    def test_all_fields_optional(self) -> None:
        """All fields in DeploymentContext are optional."""
        ctx = DeploymentContext()
        assert ctx.hostname is None
        assert ctx.environment is None
        assert ctx.has_internet_access is None
        assert ctx.has_filesystem_access is None
        assert ctx.filesystem_scope is None
        assert ctx.resource_limits is None

    def test_with_values(self) -> None:
        """DeploymentContext accepts values."""
        ctx = DeploymentContext(
            hostname="prod-server-01",
            environment="production",
            has_internet_access=True,
            has_filesystem_access=False,
        )
        assert ctx.hostname == "prod-server-01"
        assert ctx.environment == "production"
        assert ctx.has_internet_access is True
        assert ctx.has_filesystem_access is False

    def test_with_resource_limits(self) -> None:
        """DeploymentContext can include resource limits."""
        ctx = DeploymentContext(resource_limits=ResourceLimits(max_memory_mb=2048))
        assert ctx.resource_limits is not None
        assert ctx.resource_limits.max_memory_mb == 2048


class TestAgentConfiguration:
    """Tests for AgentConfiguration model."""

    def test_required_fields(self) -> None:
        """AgentConfiguration requires model_provider and model_name."""
        config = AgentConfiguration(
            model_provider="anthropic",
            model_name="claude-sonnet-4-20250514",
        )
        assert config.model_provider == "anthropic"
        assert config.model_name == "claude-sonnet-4-20250514"

    def test_missing_required_field_raises(self) -> None:
        """Missing required fields raises ValidationError."""
        with pytest.raises(ValidationError):
            AgentConfiguration(model_provider="anthropic")  # type: ignore[call-arg]

    def test_tools_default_empty(self) -> None:
        """tools defaults to empty list."""
        config = AgentConfiguration(
            model_provider="anthropic",
            model_name="claude-sonnet-4-20250514",
        )
        assert config.tools == []

    def test_parameters_default_empty(self) -> None:
        """parameters defaults to empty dict."""
        config = AgentConfiguration(
            model_provider="anthropic",
            model_name="claude-sonnet-4-20250514",
        )
        assert config.parameters == {}

    def test_with_tools_and_parameters(self) -> None:
        """AgentConfiguration accepts tools and parameters."""
        config = AgentConfiguration(
            model_provider="openai",
            model_name="gpt-4o",
            tools=["file_read", "file_write", "shell"],
            parameters={"temperature": 0.7, "max_tokens": 4096},
        )
        assert config.tools == ["file_read", "file_write", "shell"]
        assert config.parameters["temperature"] == 0.7


class TestDirective:
    """Tests for Directive model."""

    def test_required_fields(self) -> None:
        """Directive requires directive_type and issued_at."""
        now = datetime.now(UTC)
        directive = Directive(
            directive_type=DirectiveType.SHUTDOWN,
            issued_at=now,
        )
        assert directive.directive_type == DirectiveType.SHUTDOWN
        assert directive.issued_at == now

    def test_payload_default_empty(self) -> None:
        """payload defaults to empty dict."""
        directive = Directive(
            directive_type=DirectiveType.RECONFIGURE,
            issued_at=datetime.now(UTC),
        )
        assert directive.payload == {}

    def test_with_payload(self) -> None:
        """Directive accepts payload."""
        directive = Directive(
            directive_type=DirectiveType.RATE_LIMIT,
            payload={"requests_per_minute": 10},
            issued_at=datetime.now(UTC),
        )
        assert directive.payload["requests_per_minute"] == 10


class TestGraspAssessment:
    """Tests for GraspAssessment model."""

    def test_required_fields(self) -> None:
        """GraspAssessment requires overall_risk and computed_at."""
        now = datetime.now(UTC)
        assessment = GraspAssessment(
            overall_risk=RiskLevel.MEDIUM,
            computed_at=now,
        )
        assert assessment.overall_risk == RiskLevel.MEDIUM
        assert assessment.computed_at == now

    def test_optional_scores(self) -> None:
        """Score fields are optional."""
        assessment = GraspAssessment(
            overall_risk=RiskLevel.LOW,
            computed_at=datetime.now(UTC),
        )
        assert assessment.governance_score is None
        assert assessment.reach_score is None
        assert assessment.agency_score is None
        assert assessment.safeguards_score is None
        assert assessment.potential_damage_score is None

    def test_with_all_scores(self) -> None:
        """GraspAssessment accepts all scores."""
        assessment = GraspAssessment(
            overall_risk=RiskLevel.HIGH,
            governance_score=80,
            reach_score=60,
            agency_score=90,
            safeguards_score=70,
            potential_damage_score=85,
            computed_at=datetime.now(UTC),
        )
        assert assessment.governance_score == 80
        assert assessment.reach_score == 60


class TestRegisterResponse:
    """Tests for RegisterResponse model."""

    def test_required_fields(self) -> None:
        """RegisterResponse requires agent_id, lifecycle_state, next_heartbeat_due."""
        response = RegisterResponse(
            agent_id=UUID("12345678-1234-5678-1234-567812345678"),
            lifecycle_state=LifecycleState.ACTIVE,
            next_heartbeat_due=datetime.now(UTC),
        )
        assert response.agent_id == UUID("12345678-1234-5678-1234-567812345678")
        assert response.lifecycle_state == LifecycleState.ACTIVE

    def test_optional_fields(self) -> None:
        """Optional fields default to None."""
        response = RegisterResponse(
            agent_id=UUID("12345678-1234-5678-1234-567812345678"),
            lifecycle_state=LifecycleState.ACTIVE,
            next_heartbeat_due=datetime.now(UTC),
        )
        assert response.definition_id is None
        assert response.grasp_assessment is None

    def test_from_dict(self) -> None:
        """RegisterResponse can be created from dict (API response)."""
        data = {
            "agent_id": "12345678-1234-5678-1234-567812345678",
            "lifecycle_state": "active",
            "next_heartbeat_due": "2024-01-01T00:00:00Z",
        }
        response = RegisterResponse.model_validate(data)
        assert response.lifecycle_state == LifecycleState.ACTIVE


class TestHeartbeatResponse:
    """Tests for HeartbeatResponse model."""

    def test_required_fields(self) -> None:
        """HeartbeatResponse requires acknowledged and next_heartbeat_due."""
        response = HeartbeatResponse(
            acknowledged=True,
            next_heartbeat_due=datetime.now(UTC),
        )
        assert response.acknowledged is True

    def test_directives_default_empty(self) -> None:
        """directives defaults to empty list."""
        response = HeartbeatResponse(
            acknowledged=True,
            next_heartbeat_due=datetime.now(UTC),
        )
        assert response.directives == []

    def test_with_directives(self) -> None:
        """HeartbeatResponse can include directives."""
        now = datetime.now(UTC)
        response = HeartbeatResponse(
            acknowledged=True,
            next_heartbeat_due=now,
            directives=[Directive(directive_type=DirectiveType.SHUTDOWN, issued_at=now)],
        )
        assert len(response.directives) == 1
        assert response.directives[0].directive_type == DirectiveType.SHUTDOWN


class TestUpdateConfigurationResponse:
    """Tests for UpdateConfigurationResponse model."""

    def test_required_fields(self) -> None:
        """UpdateConfigurationResponse requires agent_id and configuration_version."""
        response = UpdateConfigurationResponse(
            agent_id=UUID("12345678-1234-5678-1234-567812345678"),
            configuration_version=2,
        )
        assert response.configuration_version == 2

    def test_optional_grasp_assessment(self) -> None:
        """grasp_assessment is optional."""
        response = UpdateConfigurationResponse(
            agent_id=UUID("12345678-1234-5678-1234-567812345678"),
            configuration_version=1,
        )
        assert response.grasp_assessment is None


class TestDeregisterResponse:
    """Tests for DeregisterResponse model."""

    def test_required_fields(self) -> None:
        """DeregisterResponse requires all fields."""
        response = DeregisterResponse(
            agent_id=UUID("12345678-1234-5678-1234-567812345678"),
            lifecycle_state=LifecycleState.TERMINATED,
            terminated_at=datetime.now(UTC),
        )
        assert response.lifecycle_state == LifecycleState.TERMINATED

    def test_from_dict(self) -> None:
        """DeregisterResponse can be created from dict (API response)."""
        data = {
            "agent_id": "12345678-1234-5678-1234-567812345678",
            "lifecycle_state": "terminated",
            "terminated_at": "2024-01-01T00:00:00Z",
        }
        response = DeregisterResponse.model_validate(data)
        assert response.lifecycle_state == LifecycleState.TERMINATED
