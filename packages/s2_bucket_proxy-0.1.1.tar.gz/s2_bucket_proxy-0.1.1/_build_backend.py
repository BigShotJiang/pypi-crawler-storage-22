"""
Custom build backend wrapper.

Wraps setuptools.build_meta to compile the C engine
before any build/wheel/editable step.
Works for ALL install types: pip install, pip install -e, python -m build.
"""
import os
import sys
import subprocess
import shutil

# Import all standard hooks from setuptools
from setuptools.build_meta import *  # noqa: F401,F403
from setuptools.build_meta import (
    build_wheel as _build_wheel,
    build_editable as _build_editable,
    build_sdist as _build_sdist,
    get_requires_for_build_wheel as _get_requires_for_build_wheel,
    get_requires_for_build_editable as _get_requires_for_build_editable,
)

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_C_ENGINE_DIR = os.path.join(_THIS_DIR, "c_engine")
_BIN_DIR = os.path.join(_THIS_DIR, "s2_bucket_proxy", "bin")
_BINARY_NAME = "bucket_proxy_engine"
_compiled = False


def _get_distro_hint():
    try:
        with open("/etc/os-release") as f:
            c = f.read().lower()
        if any(d in c for d in ("ubuntu", "debian", "mint")):
            return "sudo apt install -y build-essential libcurl4-openssl-dev libssl-dev libmicrohttpd-dev pkg-config"
        elif any(d in c for d in ("fedora", "rhel", "centos", "rocky")):
            return "sudo dnf install -y gcc make libcurl-devel openssl-devel libmicrohttpd-devel pkgconf-pkg-config"
        elif any(d in c for d in ("arch", "manjaro")):
            return "sudo pacman -S base-devel curl openssl libmicrohttpd pkgconf"
        elif any(d in c for d in ("alpine",)):
            return "apk add build-base curl-dev openssl-dev libmicrohttpd-dev pkgconf"
    except FileNotFoundError:
        pass
    # Termux
    if os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
        return "pkg install clang make libcurl openssl libmicrohttpd pkg-config"
    import platform
    if platform.system() == "Darwin":
        return "brew install curl openssl libmicrohttpd pkg-config"
    return "Install: gcc, make, libcurl-dev, libssl-dev, libmicrohttpd-dev, pkg-config (or equivalents)"


def _compile_engine():
    global _compiled
    if _compiled:
        return
    _compiled = True

    dst = os.path.join(_BIN_DIR, _BINARY_NAME)
    if os.path.exists(dst) and os.access(dst, os.X_OK):
        print(f"  ✓ C engine already compiled: {dst}")
        return

    print("\n" + "=" * 60)
    print("  s2-bucket-proxy: Compiling C engine...")
    print("=" * 60)

    # Quick dependency check
    if not shutil.which("gcc") and not shutil.which("cc"):
        hint = _get_distro_hint()
        sys.exit(
            f"\n  ✗ C compiler not found.\n"
            f"  Install build dependencies first:\n    {hint}\n"
            f"  Then retry: pip install s2-bucket-proxy\n"
        )

    os.makedirs(_BIN_DIR, exist_ok=True)

    result = subprocess.run(
        ["make", "-j4"],
        cwd=_C_ENGINE_DIR,
        capture_output=True,
        text=True,
        timeout=300,
    )

    if result.returncode != 0:
        hint = _get_distro_hint()
        sys.exit(
            f"\n  ✗ C engine compilation failed.\n\n"
            f"  stderr:\n{result.stderr[-800:]}\n\n"
            f"  Install build dependencies:\n    {hint}\n"
            f"  Then retry: pip install s2-bucket-proxy\n"
        )

    src = os.path.join(_C_ENGINE_DIR, _BINARY_NAME)
    if not os.path.exists(src):
        sys.exit(f"\n  ✗ Compiled binary not found at {src}\n")

    shutil.copy2(src, dst)
    os.chmod(dst, 0o755)
    size_kb = os.path.getsize(dst) / 1024
    print(f"  ✓ Compiled: {dst} ({size_kb:.0f} KB)")
    print("=" * 60 + "\n")


# Override build hooks to compile C engine first

def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    _compile_engine()
    return _build_wheel(wheel_directory, config_settings, metadata_directory)


def build_editable(wheel_directory, config_settings=None, metadata_directory=None):
    _compile_engine()
    return _build_editable(wheel_directory, config_settings, metadata_directory)


def build_sdist(sdist_directory, config_settings=None):
    # Don't compile for sdist — source distribution only
    return _build_sdist(sdist_directory, config_settings)


def get_requires_for_build_wheel(config_settings=None):
    return _get_requires_for_build_wheel(config_settings)


def get_requires_for_build_editable(config_settings=None):
    return _get_requires_for_build_editable(config_settings)
