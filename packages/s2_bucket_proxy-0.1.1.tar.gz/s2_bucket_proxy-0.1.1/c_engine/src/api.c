/*
 * api.c — HTTP client for the main storage server.
 *
 * Functions:
 *   - Validate bucket token  → POST /api/buckets/proxy/validate
 *   - Get file download info → GET  /api/buckets/proxy/info/{file_id}
 *   - List bucket files      → GET  /api/buckets/{bucket_id}/files
 *   - Download chunk data    → GET  (arbitrary URLs with fallback)
 */

#include "engine.h"
#include "cJSON.h"
#include <curl/curl.h>

/* ─── CURL response buffer ──────────────────────────────── */

typedef struct {
    unsigned char *data;
    size_t         size;
    size_t         capacity;
} response_buf_t;

static size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp)
{
    response_buf_t *buf = (response_buf_t *)userp;
    size_t total = size * nmemb;

    /* Grow buffer if needed */
    if (buf->size + total >= buf->capacity) {
        size_t new_cap = (buf->capacity == 0) ? 4096 : buf->capacity;
        while (new_cap < buf->size + total + 1)
            new_cap *= 2;
        unsigned char *tmp = realloc(buf->data, new_cap);
        if (!tmp) return 0;
        buf->data = tmp;
        buf->capacity = new_cap;
    }

    memcpy(buf->data + buf->size, contents, total);
    buf->size += total;
    buf->data[buf->size] = '\0';
    return total;
}

static void response_buf_init(response_buf_t *buf)
{
    buf->data = NULL;
    buf->size = 0;
    buf->capacity = 0;
}

static void response_buf_free(response_buf_t *buf)
{
    free(buf->data);
    buf->data = NULL;
    buf->size = 0;
    buf->capacity = 0;
}

/* ─── Helpers ───────────────────────────────────────────── */

static CURL *make_curl(const char *url, response_buf_t *buf, long timeout)
{
    CURL *curl = curl_easy_init();
    if (!curl) return NULL;

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, buf);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeout);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "s2-bucket-proxy/" PROXY_VERSION);

    return curl;
}

static void set_auth_header(CURL *curl, struct curl_slist **headers, const char *token)
{
    char auth_header[MAX_TOKEN_LEN + 20];
    snprintf(auth_header, sizeof(auth_header), "Authorization: Bearer %s", token);
    *headers = curl_slist_append(*headers, auth_header);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, *headers);
}

/* Safe JSON string extraction */
static const char *json_str(cJSON *obj, const char *key)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(obj, key);
    if (cJSON_IsString(item) && item->valuestring)
        return item->valuestring;
    return "";
}

static int json_int(cJSON *obj, const char *key)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(obj, key);
    if (cJSON_IsNumber(item))
        return item->valueint;
    return 0;
}

static long json_long(cJSON *obj, const char *key)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(obj, key);
    if (cJSON_IsNumber(item))
        return (long)item->valuedouble;
    return 0;
}


/* ─── Validate Token ────────────────────────────────────── */

int api_validate_token(const char *server_url, const char *token, bucket_t *out)
{
    char url[MAX_URL_LEN];
    response_buf_t resp;
    CURL *curl;
    struct curl_slist *headers = NULL;
    CURLcode res;
    long http_code;
    int ret = -1;

    snprintf(url, sizeof(url), "%s/api/buckets/proxy/validate", server_url);

    response_buf_init(&resp);
    curl = make_curl(url, &resp, HTTP_TIMEOUT_SECS);
    if (!curl) return -1;

    /* POST with auth */
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 0L);
    set_auth_header(curl, &headers, token);

    res = curl_easy_perform(curl);
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    if (res != CURLE_OK) {
        LOG_ERR("api: validate_token failed: %s", curl_easy_strerror(res));
        goto done;
    }

    if (http_code != 200) {
        LOG_ERR("api: validate_token HTTP %ld", http_code);
        goto done;
    }

    /* Parse JSON response */
    cJSON *root = cJSON_Parse((char *)resp.data);
    if (!root) {
        LOG_ERR("api: validate_token JSON parse error");
        goto done;
    }

    cJSON *success = cJSON_GetObjectItemCaseSensitive(root, "success");
    if (!cJSON_IsTrue(success)) {
        LOG_ERR("api: validate_token: success=false");
        cJSON_Delete(root);
        goto done;
    }

    cJSON *bucket = cJSON_GetObjectItemCaseSensitive(root, "bucket");
    if (!bucket) {
        cJSON_Delete(root);
        goto done;
    }

    memset(out, 0, sizeof(*out));
    snprintf(out->name, sizeof(out->name), "%s", json_str(bucket, "name"));
    snprintf(out->display_name, sizeof(out->display_name), "%s", json_str(bucket, "display_name"));
    snprintf(out->bucket_id, sizeof(out->bucket_id), "%s", json_str(bucket, "id"));
    snprintf(out->token, sizeof(out->token), "%s", token);
    snprintf(out->storage_type, sizeof(out->storage_type), "%s", json_str(bucket, "storage_type"));
    out->total_files = json_int(bucket, "total_files");
    out->used_bytes = json_long(bucket, "used_bytes");

    /* Add timestamp */
    time_t now = time(NULL);
    struct tm *tm = gmtime(&now);
    strftime(out->added_at, sizeof(out->added_at), "%Y-%m-%dT%H:%M:%SZ", tm);

    cJSON_Delete(root);
    ret = 0;

done:
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    response_buf_free(&resp);
    return ret;
}


/* ─── Get File Info ─────────────────────────────────────── */

int api_get_file_info(const char *server_url, const char *bucket_token,
                      const char *file_id, const char *file_token,
                      file_info_t *out)
{
    char url[MAX_URL_LEN];
    response_buf_t resp;
    CURL *curl;
    struct curl_slist *headers = NULL;
    CURLcode res;
    long http_code;
    int ret = -1;

    if (file_token && file_token[0]) {
        snprintf(url, sizeof(url), "%s/api/buckets/proxy/info/%s?file_token=%s",
                 server_url, file_id, file_token);
    } else {
        snprintf(url, sizeof(url), "%s/api/buckets/proxy/info/%s",
                 server_url, file_id);
    }

    response_buf_init(&resp);
    curl = make_curl(url, &resp, HTTP_TIMEOUT_SECS);
    if (!curl) return -1;

    set_auth_header(curl, &headers, bucket_token);

    res = curl_easy_perform(curl);
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    if (res != CURLE_OK) {
        LOG_ERR("api: get_file_info failed: %s", curl_easy_strerror(res));
        goto done;
    }

    if (http_code != 200) {
        LOG_ERR("api: get_file_info HTTP %ld for %s", http_code, file_id);
        ret = -(int)http_code;  /* negative HTTP code for caller to check */
        goto done;
    }

    /* Parse JSON */
    cJSON *root = cJSON_Parse((char *)resp.data);
    if (!root) {
        LOG_ERR("api: get_file_info JSON parse error");
        goto done;
    }

    memset(out, 0, sizeof(*out));
    snprintf(out->file_id, sizeof(out->file_id), "%s",
             json_str(root, "id")[0] ? json_str(root, "id") : json_str(root, "file_id"));
    snprintf(out->name, sizeof(out->name), "%s",
             json_str(root, "name")[0] ? json_str(root, "name") : json_str(root, "file_name"));
    snprintf(out->mime_type, sizeof(out->mime_type), "%s", json_str(root, "mime_type"));
    out->size = (size_t)json_long(root, "size");
    out->chunk_size = (size_t)json_long(root, "chunk_size");

    /* Access type */
    const char *access = json_str(root, "access_type");
    if (access[0]) {
        snprintf(out->access_type, sizeof(out->access_type), "%s", access);
        out->is_public = (strcmp(access, "public") == 0);
    } else {
        cJSON *pub = cJSON_GetObjectItemCaseSensitive(root, "is_public");
        out->is_public = cJSON_IsTrue(pub);
        snprintf(out->access_type, sizeof(out->access_type), "%s",
                 out->is_public ? "public" : "private");
    }

    /* Parse chunks array */
    cJSON *chunks = cJSON_GetObjectItemCaseSensitive(root, "chunks");
    if (cJSON_IsArray(chunks)) {
        int n = 0;
        cJSON *ch;
        cJSON_ArrayForEach(ch, chunks) {
            if (n >= MAX_CHUNKS) break;

            chunk_info_t *ci = &out->chunks[n];
            ci->sequence = json_int(ch, "sequence");
            snprintf(ci->aes_key_b64, sizeof(ci->aes_key_b64), "%s", json_str(ch, "aes_key"));
            snprintf(ci->aes_iv_b64, sizeof(ci->aes_iv_b64), "%s", json_str(ch, "aes_iv"));
            ci->encrypted_size = (size_t)json_long(ch, "encrypted_size");

            /* Parse download URLs (multi-replica) */
            ci->num_urls = 0;
            cJSON *urls = cJSON_GetObjectItemCaseSensitive(ch, "download_urls");
            if (cJSON_IsArray(urls)) {
                cJSON *u;
                cJSON_ArrayForEach(u, urls) {
                    if (ci->num_urls >= MAX_REPLICAS) break;
                    if (cJSON_IsString(u) && u->valuestring) {
                        snprintf(ci->download_urls[ci->num_urls],
                                 MAX_URL_LEN, "%s", u->valuestring);
                        ci->num_urls++;
                    }
                }
            }

            /* Fallback: single download_url */
            if (ci->num_urls == 0) {
                const char *single = json_str(ch, "download_url");
                if (single[0]) {
                    snprintf(ci->download_urls[0], MAX_URL_LEN, "%s", single);
                    ci->num_urls = 1;
                }
            }

            n++;
        }
        out->num_chunks = n;
    }

    cJSON_Delete(root);
    ret = 0;

done:
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    response_buf_free(&resp);
    return ret;
}


/* ─── List Files ────────────────────────────────────────── */

char *api_list_files(const char *server_url, const char *bucket_id,
                     const char *bucket_token, int limit, int offset)
{
    char url[MAX_URL_LEN];
    response_buf_t resp;
    CURL *curl;
    struct curl_slist *headers = NULL;
    CURLcode res;
    long http_code;

    snprintf(url, sizeof(url), "%s/api/buckets/%s/files?limit=%d&offset=%d",
             server_url, bucket_id, limit, offset);

    response_buf_init(&resp);
    curl = make_curl(url, &resp, HTTP_TIMEOUT_SECS);
    if (!curl) return NULL;

    set_auth_header(curl, &headers, bucket_token);

    res = curl_easy_perform(curl);
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK || http_code != 200) {
        response_buf_free(&resp);
        return NULL;
    }

    /* Return ownership of the JSON string to caller */
    char *json = (char *)resp.data;
    resp.data = NULL;
    return json;
}


/* ─── Download Chunk ────────────────────────────────────── */

unsigned char *api_download_chunk(const chunk_info_t *chunk, size_t *out_len)
{
    *out_len = 0;

    for (int i = 0; i < chunk->num_urls; i++) {
        response_buf_t resp;
        response_buf_init(&resp);

        CURL *curl = make_curl(chunk->download_urls[i], &resp, DOWNLOAD_TIMEOUT_SECS);
        if (!curl) {
            response_buf_free(&resp);
            continue;
        }

        CURLcode res = curl_easy_perform(curl);
        long http_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
        curl_easy_cleanup(curl);

        if (res == CURLE_OK && http_code == 200 && resp.size > 0) {
            *out_len = resp.size;
            unsigned char *data = resp.data;
            resp.data = NULL; /* transfer ownership */
            response_buf_free(&resp);
            return data;
        }

        if (i < chunk->num_urls - 1) {
            LOG_WARN("Replica %d failed for chunk %d (HTTP %ld), trying next",
                     i + 1, chunk->sequence, http_code);
        } else {
            LOG_ERR("All replicas failed for chunk %d", chunk->sequence);
        }

        response_buf_free(&resp);
    }

    return NULL;
}
