/*
 * crypto.c — AES-256-CBC decryption.
 *
 * Compatible with EdgeCrypto.encrypt() from the Python server.
 * Takes base64-encoded key/IV, decrypts, removes PKCS7 padding.
 */

#include "engine.h"
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <openssl/err.h>

/* ─── Base64 decode ─────────────────────────────────────── */

static int b64_decode(const char *input, unsigned char **out, size_t *out_len)
{
    BIO *b64, *bmem;
    size_t in_len = strlen(input);

    /* Allocate output buffer (decoded is always shorter) */
    unsigned char *buf = malloc(in_len);
    if (!buf) return -1;

    b64 = BIO_new(BIO_f_base64());
    BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    bmem = BIO_new_mem_buf(input, (int)in_len);
    bmem = BIO_push(b64, bmem);

    int decoded_len = BIO_read(bmem, buf, (int)in_len);
    BIO_free_all(bmem);

    if (decoded_len < 0) {
        free(buf);
        return -1;
    }

    *out = buf;
    *out_len = (size_t)decoded_len;
    return 0;
}


/* ─── AES-256-CBC decryption ────────────────────────────── */

int crypto_decrypt(const unsigned char *encrypted, size_t enc_len,
                   const char *key_b64, const char *iv_b64,
                   unsigned char **out, size_t *out_len)
{
    unsigned char *key = NULL, *iv = NULL;
    size_t key_len = 0, iv_len = 0;
    EVP_CIPHER_CTX *ctx = NULL;
    unsigned char *plaintext = NULL;
    int len, total_len;
    int ret = -1;

    /* Decode key and IV */
    if (b64_decode(key_b64, &key, &key_len) != 0) {
        LOG_ERR("crypto: failed to decode AES key");
        goto cleanup;
    }
    if (key_len != AES_KEY_SIZE) {
        LOG_ERR("crypto: key size %zu != %d", key_len, AES_KEY_SIZE);
        goto cleanup;
    }

    if (b64_decode(iv_b64, &iv, &iv_len) != 0) {
        LOG_ERR("crypto: failed to decode AES IV");
        goto cleanup;
    }
    if (iv_len != AES_IV_SIZE) {
        LOG_ERR("crypto: IV size %zu != %d", iv_len, AES_IV_SIZE);
        goto cleanup;
    }

    /* Allocate output buffer */
    plaintext = malloc(enc_len + AES_BLOCK_SIZE);
    if (!plaintext) goto cleanup;

    /* Create and init context */
    ctx = EVP_CIPHER_CTX_new();
    if (!ctx) goto cleanup;

    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv) != 1)
        goto cleanup;

    /* PKCS7 padding is handled by OpenSSL by default */

    if (EVP_DecryptUpdate(ctx, plaintext, &len, encrypted, (int)enc_len) != 1)
        goto cleanup;
    total_len = len;

    if (EVP_DecryptFinal_ex(ctx, plaintext + total_len, &len) != 1) {
        unsigned long err = ERR_get_error();
        char err_buf[256];
        ERR_error_string_n(err, err_buf, sizeof(err_buf));
        LOG_ERR("crypto: decrypt final failed: %s", err_buf);
        goto cleanup;
    }
    total_len += len;

    *out = plaintext;
    *out_len = (size_t)total_len;
    plaintext = NULL; /* prevent free */
    ret = 0;

cleanup:
    if (ctx) EVP_CIPHER_CTX_free(ctx);
    if (key) { memset(key, 0, key_len); free(key); }
    if (iv)  { memset(iv, 0, iv_len); free(iv); }
    if (plaintext) free(plaintext);
    return ret;
}
