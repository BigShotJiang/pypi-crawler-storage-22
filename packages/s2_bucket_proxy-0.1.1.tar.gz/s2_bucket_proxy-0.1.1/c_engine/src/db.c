/*
 * db.c — SQLite3 configuration and stats store.
 *
 * Replaces the JSON config file from v1.
 * Stores: buckets, config key-value pairs, request stats.
 */

#include "engine.h"
#include "sqlite3.h"
#include "cJSON.h"

static sqlite3 *g_db = NULL;
static pthread_mutex_t g_db_mutex = PTHREAD_MUTEX_INITIALIZER;

/* ─── Schema ────────────────────────────────────────────── */

static const char *SCHEMA_SQL =
    "CREATE TABLE IF NOT EXISTS config ("
    "  key   TEXT PRIMARY KEY,"
    "  value TEXT NOT NULL"
    ");"
    "CREATE TABLE IF NOT EXISTS buckets ("
    "  name          TEXT PRIMARY KEY,"
    "  display_name  TEXT,"
    "  bucket_id     TEXT NOT NULL,"
    "  token         TEXT NOT NULL,"
    "  storage_type  TEXT,"
    "  total_files   INTEGER DEFAULT 0,"
    "  used_bytes    INTEGER DEFAULT 0,"
    "  added_at      TEXT"
    ");"
    "CREATE TABLE IF NOT EXISTS stats ("
    "  bucket_name   TEXT PRIMARY KEY,"
    "  requests      INTEGER DEFAULT 0,"
    "  bytes_served  INTEGER DEFAULT 0"
    ");";


/* ─── Init / Close ──────────────────────────────────────── */

int db_init(const char *db_path)
{
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_open(db_path, &g_db);
    if (rc != SQLITE_OK) {
        LOG_ERR("Failed to open database '%s': %s", db_path, sqlite3_errmsg(g_db));
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    /* Enable WAL mode for concurrent reads */
    sqlite3_exec(g_db, "PRAGMA journal_mode=WAL;", NULL, NULL, NULL);
    sqlite3_exec(g_db, "PRAGMA busy_timeout=5000;", NULL, NULL, NULL);

    /* Create tables */
    char *err_msg = NULL;
    rc = sqlite3_exec(g_db, SCHEMA_SQL, NULL, NULL, &err_msg);
    if (rc != SQLITE_OK) {
        LOG_ERR("Schema creation failed: %s", err_msg);
        sqlite3_free(err_msg);
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    pthread_mutex_unlock(&g_db_mutex);
    return 0;
}

void db_close(void)
{
    pthread_mutex_lock(&g_db_mutex);
    if (g_db) {
        sqlite3_close(g_db);
        g_db = NULL;
    }
    pthread_mutex_unlock(&g_db_mutex);
}


/* ─── Config key-value ──────────────────────────────────── */

int db_get_config(const char *key, char *value, size_t value_len)
{
    sqlite3_stmt *stmt;
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "SELECT value FROM config WHERE key = ?", -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    sqlite3_bind_text(stmt, 1, key, -1, SQLITE_STATIC);

    rc = sqlite3_step(stmt);
    if (rc == SQLITE_ROW) {
        const char *val = (const char *)sqlite3_column_text(stmt, 0);
        snprintf(value, value_len, "%s", val ? val : "");
        sqlite3_finalize(stmt);
        pthread_mutex_unlock(&g_db_mutex);
        return 0;
    }

    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);
    return -1; /* not found */
}

int db_set_config(const char *key, const char *value)
{
    sqlite3_stmt *stmt;
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)",
        -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    sqlite3_bind_text(stmt, 1, key, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, value, -1, SQLITE_STATIC);

    rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);

    return (rc == SQLITE_DONE) ? 0 : -1;
}


/* ─── Buckets ───────────────────────────────────────────── */

int db_add_bucket(const bucket_t *b)
{
    sqlite3_stmt *stmt;
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "INSERT OR REPLACE INTO buckets "
        "(name, display_name, bucket_id, token, storage_type, total_files, used_bytes, added_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        LOG_ERR("db_add_bucket prepare: %s", sqlite3_errmsg(g_db));
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    sqlite3_bind_text(stmt, 1, b->name, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, b->display_name, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, b->bucket_id, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, b->token, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, b->storage_type, -1, SQLITE_STATIC);
    sqlite3_bind_int(stmt,  6, b->total_files);
    sqlite3_bind_int64(stmt, 7, b->used_bytes);
    sqlite3_bind_text(stmt, 8, b->added_at, -1, SQLITE_STATIC);

    rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);

    return (rc == SQLITE_DONE) ? 0 : -1;
}

int db_remove_bucket(const char *name)
{
    sqlite3_stmt *stmt;
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "DELETE FROM buckets WHERE name = ?", -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    sqlite3_bind_text(stmt, 1, name, -1, SQLITE_STATIC);
    rc = sqlite3_step(stmt);
    int changes = sqlite3_changes(g_db);
    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);

    return (rc == SQLITE_DONE && changes > 0) ? 0 : -1;
}

static void row_to_bucket(sqlite3_stmt *stmt, bucket_t *b)
{
    const char *s;

    memset(b, 0, sizeof(*b));

    s = (const char *)sqlite3_column_text(stmt, 0);
    if (s) snprintf(b->name, sizeof(b->name), "%s", s);

    s = (const char *)sqlite3_column_text(stmt, 1);
    if (s) snprintf(b->display_name, sizeof(b->display_name), "%s", s);

    s = (const char *)sqlite3_column_text(stmt, 2);
    if (s) snprintf(b->bucket_id, sizeof(b->bucket_id), "%s", s);

    s = (const char *)sqlite3_column_text(stmt, 3);
    if (s) snprintf(b->token, sizeof(b->token), "%s", s);

    s = (const char *)sqlite3_column_text(stmt, 4);
    if (s) snprintf(b->storage_type, sizeof(b->storage_type), "%s", s);

    b->total_files = sqlite3_column_int(stmt, 5);
    b->used_bytes  = sqlite3_column_int64(stmt, 6);

    s = (const char *)sqlite3_column_text(stmt, 7);
    if (s) snprintf(b->added_at, sizeof(b->added_at), "%s", s);
}

int db_get_bucket(const char *name, bucket_t *b)
{
    sqlite3_stmt *stmt;
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "SELECT name, display_name, bucket_id, token, storage_type, "
        "total_files, used_bytes, added_at FROM buckets WHERE name = ?",
        -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    sqlite3_bind_text(stmt, 1, name, -1, SQLITE_STATIC);

    rc = sqlite3_step(stmt);
    if (rc == SQLITE_ROW) {
        row_to_bucket(stmt, b);
        sqlite3_finalize(stmt);
        pthread_mutex_unlock(&g_db_mutex);
        return 0;
    }

    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);
    return -1;
}

int db_get_bucket_by_id(const char *bucket_id, bucket_t *b)
{
    sqlite3_stmt *stmt;
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "SELECT name, display_name, bucket_id, token, storage_type, "
        "total_files, used_bytes, added_at FROM buckets WHERE bucket_id = ?",
        -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    sqlite3_bind_text(stmt, 1, bucket_id, -1, SQLITE_STATIC);

    rc = sqlite3_step(stmt);
    if (rc == SQLITE_ROW) {
        row_to_bucket(stmt, b);
        sqlite3_finalize(stmt);
        pthread_mutex_unlock(&g_db_mutex);
        return 0;
    }

    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);
    return -1;
}

int db_list_buckets(bucket_t *buckets, int max_buckets, int *count)
{
    sqlite3_stmt *stmt;
    int rc;

    *count = 0;
    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "SELECT name, display_name, bucket_id, token, storage_type, "
        "total_files, used_bytes, added_at FROM buckets ORDER BY name",
        -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        pthread_mutex_unlock(&g_db_mutex);
        return -1;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW && *count < max_buckets) {
        row_to_bucket(stmt, &buckets[*count]);
        (*count)++;
    }

    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);
    return 0;
}

int db_get_bucket_token(const char *name, char *token, size_t token_len)
{
    bucket_t b;
    if (db_get_bucket(name, &b) != 0)
        return -1;
    snprintf(token, token_len, "%s", b.token);
    return 0;
}


/* ─── Stats ─────────────────────────────────────────────── */

void db_increment_stats(const char *bucket_name, long bytes_served)
{
    sqlite3_stmt *stmt;
    int rc;

    pthread_mutex_lock(&g_db_mutex);

    rc = sqlite3_prepare_v2(g_db,
        "INSERT INTO stats (bucket_name, requests, bytes_served) VALUES (?, 1, ?) "
        "ON CONFLICT(bucket_name) DO UPDATE SET "
        "requests = requests + 1, bytes_served = bytes_served + ?",
        -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        pthread_mutex_unlock(&g_db_mutex);
        return;
    }

    sqlite3_bind_text(stmt, 1, bucket_name, -1, SQLITE_STATIC);
    sqlite3_bind_int64(stmt, 2, bytes_served);
    sqlite3_bind_int64(stmt, 3, bytes_served);

    sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    pthread_mutex_unlock(&g_db_mutex);
}
