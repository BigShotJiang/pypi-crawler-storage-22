/*
 * Bucket Proxy Engine — Shared Header
 *
 * Core structures and constants for the C-based proxy server.
 * Handles: HTTP serving, chunk fetching, AES decryption, SQLite3 config.
 */

#ifndef PROXY_ENGINE_H
#define PROXY_ENGINE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <pthread.h>

/* ─── Constants ─────────────────────────────────────────── */

#define PROXY_VERSION           "0.1.0"
#define DEFAULT_PORT            8001
#define DEFAULT_DB_PATH         ".s2_proxy.db"
#define MAX_BUCKETS             64
#define MAX_URL_LEN             2048
#define MAX_TOKEN_LEN           512
#define MAX_NAME_LEN            256
#define MAX_MIME_LEN            128
#define MAX_CHUNKS              4096
#define MAX_REPLICAS            8
#define CHUNK_STREAM_SIZE       (64 * 1024)    /* 64KB streaming pieces */
#define HTTP_TIMEOUT_SECS       30
#define DOWNLOAD_TIMEOUT_SECS   300
#define MAX_CONCURRENT_FETCHES  4

/* AES-256-CBC */
#define AES_KEY_SIZE            32
#define AES_IV_SIZE             16
#define AES_BLOCK_SIZE          16

/* ─── Structures ────────────────────────────────────────── */

/* A registered bucket */
typedef struct {
    char name[MAX_NAME_LEN];
    char display_name[MAX_NAME_LEN];
    char bucket_id[64];
    char token[MAX_TOKEN_LEN];
    char storage_type[32];
    int  total_files;
    long used_bytes;
    char added_at[32];
} bucket_t;

/* A single chunk's download info (from /proxy/info) */
typedef struct {
    int    sequence;
    char   download_urls[MAX_REPLICAS][MAX_URL_LEN];
    int    num_urls;
    char   aes_key_b64[64];        /* base64 encoded AES key */
    char   aes_iv_b64[32];         /* base64 encoded AES IV */
    size_t encrypted_size;
} chunk_info_t;

/* File info returned from /proxy/info */
typedef struct {
    char          file_id[64];
    char          name[MAX_NAME_LEN];
    char          mime_type[MAX_MIME_LEN];
    size_t        size;            /* original file size */
    size_t        chunk_size;      /* chunk size used during upload */
    int           num_chunks;
    bool          is_public;
    char          access_type[16]; /* "public" or "private" */
    chunk_info_t  chunks[MAX_CHUNKS];
} file_info_t;

/* Server configuration (from SQLite3) */
typedef struct {
    char  main_server_url[MAX_URL_LEN];
    int   port;
    char  db_path[512];
    char  log_file[512];
    char  pid_file[512];
    bool  daemon_mode;
    bool  docker_mode;
} server_config_t;

/* Runtime statistics (atomic-friendly) */
typedef struct {
    time_t start_time;
    long   total_requests;
    long   total_bytes_served;
    long   stream_requests;
    long   download_requests;
} server_stats_t;


/* ─── Database (db.c) ───────────────────────────────────── */

int   db_init(const char *db_path);
void  db_close(void);

/* Config */
int   db_get_config(const char *key, char *value, size_t value_len);
int   db_set_config(const char *key, const char *value);

/* Buckets */
int   db_add_bucket(const bucket_t *b);
int   db_remove_bucket(const char *name);
int   db_get_bucket(const char *name, bucket_t *b);
int   db_get_bucket_by_id(const char *bucket_id, bucket_t *b);
int   db_list_buckets(bucket_t *buckets, int max_buckets, int *count);
int   db_get_bucket_token(const char *name, char *token, size_t token_len);

/* Stats */
void  db_increment_stats(const char *bucket_name, long bytes_served);


/* ─── Crypto (crypto.c) ─────────────────────────────────── */

/*
 * Decrypt AES-256-CBC data.
 * key_b64/iv_b64: base64 encoded key/IV strings
 * Returns: malloc'd decrypted buffer (caller must free)
 *          *out_len set to decrypted length
 *          NULL on error
 */
int   crypto_decrypt(const unsigned char *encrypted, size_t enc_len,
                     const char *key_b64, const char *iv_b64,
                     unsigned char **out, size_t *out_len);


/* ─── API Client (api.c) ────────────────────────────────── */

/*
 * Validate a bucket token with the main server.
 * On success, fills bucket_t and returns 0.
 */
int   api_validate_token(const char *server_url, const char *token, bucket_t *out);

/*
 * Get file download info (chunk URLs + decryption keys).
 * On success, fills file_info_t and returns 0.
 */
int   api_get_file_info(const char *server_url, const char *bucket_token,
                        const char *file_id, const char *file_token,
                        file_info_t *out);

/*
 * List files in a bucket.
 * Returns JSON string (caller must free), or NULL on error.
 */
char *api_list_files(const char *server_url, const char *bucket_id,
                     const char *bucket_token, int limit, int offset);

/*
 * Download a chunk from a URL.
 * Tries multiple URLs (replicas) with fallback.
 * Returns: malloc'd buffer with data, *out_len set, or NULL.
 */
unsigned char *api_download_chunk(const chunk_info_t *chunk, size_t *out_len);


/* ─── HTTP Server (server.c) ─────────────────────────────── */

int   server_start(server_config_t *config, server_stats_t *stats);
void  server_stop(void);


/* ─── Logging helpers ────────────────────────────────────── */

#define LOG_INFO(fmt, ...)   fprintf(stdout, "\033[92m[INFO]\033[0m  " fmt "\n", ##__VA_ARGS__)
#define LOG_WARN(fmt, ...)   fprintf(stdout, "\033[93m[WARN]\033[0m  " fmt "\n", ##__VA_ARGS__)
#define LOG_ERR(fmt, ...)    fprintf(stderr, "\033[91m[ERR]\033[0m   " fmt "\n", ##__VA_ARGS__)
#define LOG_REQ(fmt, ...)    fprintf(stdout, "\033[96m[REQ]\033[0m   " fmt "\n", ##__VA_ARGS__)
#define LOG_DIM(fmt, ...)    fprintf(stdout, "\033[2m" fmt "\033[0m\n", ##__VA_ARGS__)

#endif /* PROXY_ENGINE_H */
