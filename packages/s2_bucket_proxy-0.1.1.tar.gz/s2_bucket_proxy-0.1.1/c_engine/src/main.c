/*
 * main.c — Entry point for the bucket proxy engine.
 *
 * Subcommands:
 *   serve            Start the HTTP proxy server
 *   add-bucket       Validate and register a bucket token
 *   remove-bucket    Remove a registered bucket
 *   list-buckets     List all registered buckets
 *   status           Show server status
 *
 * Options:
 *   --port N         Port to listen on (default: 8001)
 *   --server URL     Main storage server URL
 *   --db PATH        SQLite database path
 *   --token TOKEN    Bucket token (for add-bucket / auto-add in docker)
 *   --name NAME      Bucket name (for remove-bucket)
 *   --daemon         Run as background daemon
 *   --docker         Docker/container mode: read config from env vars,
 *                    no interactive CLI, stdout logging
 *   --pid-file PATH  PID file for daemon mode
 *   --log-file PATH  Log file path
 */

#include "engine.h"
#include <getopt.h>
#include <signal.h>
#include <unistd.h>
#include <sys/stat.h>
#include <curl/curl.h>

static volatile sig_atomic_t g_shutdown = 0;

static void signal_handler(int sig)
{
    (void)sig;
    g_shutdown = 1;
    server_stop();
}

static void print_usage(const char *prog)
{
    printf(
        "Usage: %s <command> [options]\n"
        "\n"
        "Commands:\n"
        "  serve            Start the proxy server\n"
        "  add-bucket       Register a bucket (requires --token)\n"
        "  remove-bucket    Remove a bucket (requires --name)\n"
        "  list-buckets     List all registered buckets\n"
        "  status           Show server info\n"
        "\n"
        "Options:\n"
        "  --port N         Server port (default: %d)\n"
        "  --server URL     Main server URL\n"
        "  --db PATH        Database path (default: ~/%s)\n"
        "  --token TOKEN    Bucket token (for add-bucket)\n"
        "  --name NAME      Bucket name (for remove-bucket)\n"
        "  --daemon         Run in background\n"
        "  --docker         Docker/container mode (env var config)\n"
        "  --pid-file PATH  PID file path\n"
        "  --log-file PATH  Log file path\n"
        "  --help           Show this help\n"
        "\n"
        "Docker Mode Environment Variables:\n"
        "  S2_MAIN_SERVER   Main storage server URL\n"
        "  S2_PORT          Proxy server port\n"
        "  S2_TOKEN         Bucket token (auto-registers on start)\n"
        "  S2_DB_PATH       Database path (default: /data/proxy.db)\n"
        "\n",
        prog, DEFAULT_PORT, DEFAULT_DB_PATH
    );
}

/* ─── Config helpers ────────────────────────────────────── */

static void resolve_db_path(char *db_path, size_t len, const char *user_path, bool docker)
{
    if (user_path && user_path[0]) {
        snprintf(db_path, len, "%s", user_path);
    } else if (docker) {
        snprintf(db_path, len, "/data/proxy.db");
    } else {
        const char *home = getenv("HOME");
        if (home) {
            snprintf(db_path, len, "%s/%s", home, DEFAULT_DB_PATH);
        } else {
            snprintf(db_path, len, "%s", DEFAULT_DB_PATH);
        }
    }
}

static void load_config_from_db(server_config_t *config)
{
    char val[MAX_URL_LEN];

    if (config->main_server_url[0] == '\0') {
        if (db_get_config("main_server_url", val, sizeof(val)) == 0)
            snprintf(config->main_server_url, sizeof(config->main_server_url), "%s", val);
        else
            snprintf(config->main_server_url, sizeof(config->main_server_url), "http://localhost:8000");
    }

    if (config->port == 0) {
        if (db_get_config("port", val, sizeof(val)) == 0)
            config->port = atoi(val);
        else
            config->port = DEFAULT_PORT;
    }
}

static void load_config_from_env(server_config_t *config)
{
    const char *val;

    val = getenv("S2_MAIN_SERVER");
    if (val && val[0])
        snprintf(config->main_server_url, sizeof(config->main_server_url), "%s", val);

    val = getenv("S2_PORT");
    if (val && val[0])
        config->port = atoi(val);

    val = getenv("S2_DB_PATH");
    if (val && val[0])
        snprintf(config->db_path, sizeof(config->db_path), "%s", val);
}

static void save_config_to_db(server_config_t *config)
{
    char val[32];
    db_set_config("main_server_url", config->main_server_url);
    snprintf(val, sizeof(val), "%d", config->port);
    db_set_config("port", val);
}


/* ─── Docker auto-register ──────────────────────────────── */

static void docker_auto_register(server_config_t *config)
{
    const char *token = getenv("S2_TOKEN");
    if (!token || !token[0]) return;

    /* Try to validate and add */
    LOG_INFO("Docker: auto-registering bucket token...");

    bucket_t bucket;
    if (api_validate_token(config->main_server_url, token, &bucket) != 0) {
        LOG_WARN("Docker: token validation failed — will retry on next start");
        return;
    }

    if (db_add_bucket(&bucket) != 0) {
        LOG_WARN("Docker: failed to save bucket");
        return;
    }

    LOG_INFO("Docker: ✓ registered bucket \"%s\" (%s)", bucket.display_name, bucket.name);
}


/* ─── Subcommand: serve ─────────────────────────────────── */

static int cmd_serve(server_config_t *config)
{
    server_stats_t stats = {0};

    /* Set up signal handlers */
    signal(SIGINT,  signal_handler);
    signal(SIGTERM, signal_handler);
    signal(SIGPIPE, SIG_IGN); /* Ignore broken pipe — crucial for streaming */

    /* Daemonize if requested (not in docker mode) */
    if (config->daemon_mode && !config->docker_mode) {
        pid_t pid = fork();
        if (pid < 0) {
            LOG_ERR("Failed to fork");
            return 1;
        }
        if (pid > 0) {
            /* Parent: write PID file and exit */
            if (config->pid_file[0]) {
                FILE *f = fopen(config->pid_file, "w");
                if (f) {
                    fprintf(f, "%d\n", pid);
                    fclose(f);
                }
            }
            printf("%d\n", pid);
            _exit(0);
        }

        setsid();

        if (config->log_file[0]) {
            FILE *lf = fopen(config->log_file, "a");
            if (lf) {
                dup2(fileno(lf), STDOUT_FILENO);
                dup2(fileno(lf), STDERR_FILENO);
                fclose(lf);
            }
        }
    }

    save_config_to_db(config);

    /* Docker: auto-register token from env */
    if (config->docker_mode) {
        docker_auto_register(config);
    }

    /* Print banner */
    bucket_t buckets[MAX_BUCKETS];
    int count = 0;
    db_list_buckets(buckets, MAX_BUCKETS, &count);

    printf("\n");
    LOG_INFO("═══════════════════════════════════════════");
    LOG_INFO("  Bucket Proxy Engine v%s", PROXY_VERSION);
    if (config->docker_mode)
        LOG_INFO("  Mode:    Docker (container)");
    LOG_INFO("═══════════════════════════════════════════");
    LOG_INFO("  Server:  %s", config->main_server_url);
    LOG_INFO("  Port:    %d", config->port);
    LOG_INFO("  DB:      %s", config->db_path);
    LOG_INFO("  Buckets: %d registered", count);
    for (int i = 0; i < count; i++) {
        LOG_INFO("    → %s (%s) [%d files]",
                 buckets[i].name, buckets[i].display_name, buckets[i].total_files);
    }
    LOG_INFO("═══════════════════════════════════════════");
    printf("\n");

    /* Start HTTP server */
    if (server_start(config, &stats) != 0)
        return 1;

    /* Wait for shutdown signal */
    while (!g_shutdown) {
        sleep(1);
    }

    LOG_INFO("Shutting down...");
    server_stop();
    return 0;
}


/* ─── Subcommand: add-bucket ────────────────────────────── */

static int cmd_add_bucket(server_config_t *config, const char *token)
{
    if (!token || !token[0]) {
        LOG_ERR("Token required (--token bkt_xxxx)");
        return 1;
    }

    if (strncmp(token, "bkt_", 4) != 0) {
        LOG_ERR("Invalid token format (must start with 'bkt_')");
        return 1;
    }

    LOG_INFO("Validating token with %s ...", config->main_server_url);

    bucket_t bucket;
    if (api_validate_token(config->main_server_url, token, &bucket) != 0) {
        LOG_ERR("Token validation failed");
        return 1;
    }

    if (db_add_bucket(&bucket) != 0) {
        LOG_ERR("Failed to save bucket to database");
        return 1;
    }

    printf("\n");
    LOG_INFO("✓ Added bucket \"%s\"", bucket.display_name);
    LOG_INFO("  Name:    %s", bucket.name);
    LOG_INFO("  ID:      %s", bucket.bucket_id);
    LOG_INFO("  Type:    %s", bucket.storage_type);
    LOG_INFO("  Files:   %d", bucket.total_files);
    printf("\n");
    return 0;
}


/* ─── Subcommand: remove-bucket ─────────────────────────── */

static int cmd_remove_bucket(const char *name)
{
    if (!name || !name[0]) {
        LOG_ERR("Bucket name required (--name xxx)");
        return 1;
    }

    if (db_remove_bucket(name) != 0) {
        LOG_ERR("Bucket '%s' not found", name);
        return 1;
    }

    LOG_INFO("✓ Removed bucket '%s'", name);
    return 0;
}


/* ─── Subcommand: list-buckets ──────────────────────────── */

static int cmd_list_buckets(void)
{
    bucket_t buckets[MAX_BUCKETS];
    int count = 0;
    db_list_buckets(buckets, MAX_BUCKETS, &count);

    if (count == 0) {
        printf("No buckets registered. Use 'add-bucket --token bkt_xxx' to add one.\n");
        return 0;
    }

    printf("\n  Registered Buckets (%d)\n", count);
    printf("  ─────────────────────────────────────────\n");

    for (int i = 0; i < count; i++) {
        char size_buf[32];
        double used = (double)buckets[i].used_bytes;
        const char *unit = "B";
        if (used >= 1073741824) { used /= 1073741824; unit = "GB"; }
        else if (used >= 1048576) { used /= 1048576; unit = "MB"; }
        else if (used >= 1024) { used /= 1024; unit = "KB"; }
        snprintf(size_buf, sizeof(size_buf), "%.1f %s", used, unit);

        printf("  %d. %s (%s)\n", i + 1, buckets[i].name, buckets[i].display_name);
        printf("     Type: %s | Files: %d | Size: %s\n",
               buckets[i].storage_type, buckets[i].total_files, size_buf);
        printf("     Added: %s\n", buckets[i].added_at);
    }
    printf("\n");
    return 0;
}


/* ─── Subcommand: status ────────────────────────────────── */

static int cmd_status(server_config_t *config)
{
    printf("\n  Bucket Proxy Engine v%s\n", PROXY_VERSION);
    printf("  ─────────────────────────────────────────\n");
    printf("  Main Server: %s\n", config->main_server_url);
    printf("  Port:        %d\n", config->port);
    printf("  Database:    %s\n", config->db_path);

    bucket_t buckets[MAX_BUCKETS];
    int count = 0;
    db_list_buckets(buckets, MAX_BUCKETS, &count);
    printf("  Buckets:     %d\n", count);

    if (config->pid_file[0]) {
        FILE *f = fopen(config->pid_file, "r");
        if (f) {
            int pid;
            if (fscanf(f, "%d", &pid) == 1) {
                if (kill(pid, 0) == 0) {
                    printf("  Status:      \033[92mRunning\033[0m (PID %d)\n", pid);
                } else {
                    printf("  Status:      \033[91mStopped\033[0m\n");
                }
            }
            fclose(f);
        }
    }
    printf("\n");
    return 0;
}


/* ─── Main ──────────────────────────────────────────────── */

int main(int argc, char *argv[])
{
    server_config_t config = {0};
    char *token_arg = NULL;
    char *name_arg  = NULL;
    char *db_arg    = NULL;

    static struct option long_opts[] = {
        {"port",     required_argument, 0, 'p'},
        {"server",   required_argument, 0, 's'},
        {"db",       required_argument, 0, 'd'},
        {"token",    required_argument, 0, 't'},
        {"name",     required_argument, 0, 'n'},
        {"daemon",   no_argument,       0, 'D'},
        {"docker",   no_argument,       0, 'K'},
        {"pid-file", required_argument, 0, 'P'},
        {"log-file", required_argument, 0, 'L'},
        {"help",     no_argument,       0, 'h'},
        {0, 0, 0, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "p:s:d:t:n:DKP:L:h", long_opts, NULL)) != -1) {
        switch (opt) {
        case 'p': config.port = atoi(optarg); break;
        case 's': snprintf(config.main_server_url, sizeof(config.main_server_url), "%s", optarg); break;
        case 'd': db_arg = optarg; break;
        case 't': token_arg = optarg; break;
        case 'n': name_arg = optarg; break;
        case 'D': config.daemon_mode = true; break;
        case 'K': config.docker_mode = true; break;
        case 'P': snprintf(config.pid_file, sizeof(config.pid_file), "%s", optarg); break;
        case 'L': snprintf(config.log_file, sizeof(config.log_file), "%s", optarg); break;
        case 'h': print_usage(argv[0]); return 0;
        default:  print_usage(argv[0]); return 1;
        }
    }

    /* Get subcommand */
    const char *cmd = (optind < argc) ? argv[optind] : "serve";

    /* Docker mode: load env vars */
    if (config.docker_mode) {
        load_config_from_env(&config);

        /* In docker, token from env overrides --token arg */
        const char *env_token = getenv("S2_TOKEN");
        if (env_token && env_token[0] && !token_arg)
            token_arg = (char *)env_token;
    }

    /* Initialize curl globally */
    curl_global_init(CURL_GLOBAL_ALL);

    /* Resolve and open database */
    resolve_db_path(config.db_path, sizeof(config.db_path), db_arg, config.docker_mode);

    /* Ensure /data dir exists in docker */
    if (config.docker_mode) {
        mkdir("/data", 0755);
    }

    if (db_init(config.db_path) != 0) {
        LOG_ERR("Failed to initialize database at %s", config.db_path);
        curl_global_cleanup();
        return 1;
    }

    /* Load config: env (docker) > CLI args > DB stored values > defaults */
    load_config_from_db(&config);
    if (config.docker_mode)
        load_config_from_env(&config); /* env wins over DB */

    int ret;

    if (strcmp(cmd, "serve") == 0) {
        /* Auto-add token if provided via CLI */
        if (token_arg && !config.docker_mode) {
            bucket_t bucket;
            if (api_validate_token(config.main_server_url, token_arg, &bucket) == 0) {
                db_add_bucket(&bucket);
                LOG_INFO("Auto-registered bucket: %s", bucket.name);
            }
        }
        ret = cmd_serve(&config);
    } else if (strcmp(cmd, "add-bucket") == 0) {
        ret = cmd_add_bucket(&config, token_arg);
    } else if (strcmp(cmd, "remove-bucket") == 0) {
        ret = cmd_remove_bucket(name_arg);
    } else if (strcmp(cmd, "list-buckets") == 0 || strcmp(cmd, "list") == 0) {
        ret = cmd_list_buckets();
    } else if (strcmp(cmd, "status") == 0) {
        ret = cmd_status(&config);
    } else {
        LOG_ERR("Unknown command: %s", cmd);
        print_usage(argv[0]);
        ret = 1;
    }

    db_close();
    curl_global_cleanup();
    return ret;
}
