/*
 * server.c — Production-grade HTTP server using libmicrohttpd.
 *
 * Features:
 *   - Thread pool with epoll (high concurrency)
 *   - Full HTTP Range support (bytes, multi-part seeking)
 *   - CORS preflight (OPTIONS)
 *   - ETag / If-None-Match / If-Range support
 *   - Proper Content-Type for every MIME type
 *   - Accept-Ranges header on all file responses
 *   - Connection keep-alive
 *   - Chunk download with multi-replica fallback
 *   - AES-256-CBC decryption per chunk
 *   - Content-Disposition for downloads
 *   - Cache-Control headers
 *   - Streaming optimized: small buffer chunks, early flush
 *   - Browser/player compatibility: video.js, HLS, dash, VLC, etc.
 *
 * Routes:
 *   GET  /health                          → health check
 *   GET  /status                          → server stats + bucket list
 *   GET  /buckets                         → list registered buckets
 *   GET  /{bucket}/files                  → list files (proxied)
 *   GET  /{bucket}/stream/{file_id}       → stream with Range + decryption
 *   GET  /{bucket}/download/{file_id}     → download with Content-Disposition
 *   HEAD /{bucket}/stream/{file_id}       → head request for size/type
 *   HEAD /{bucket}/download/{file_id}     → head request for size/type
 *   OPTIONS *                             → CORS preflight
 */

#include "engine.h"
#include "cJSON.h"
#include <microhttpd.h>
#include <signal.h>

/* Globals */
static struct MHD_Daemon  *g_daemon = NULL;
static server_config_t    *g_config = NULL;
static server_stats_t     *g_stats  = NULL;
static volatile sig_atomic_t g_running = 1;

/* Production thread pool size */
#define THREAD_POOL_SIZE  16
/* Connection limits */
#define MAX_CONNECTIONS   512
#define CONNECTION_TIMEOUT 300
/* Stream buffer size — 128KB for smooth video streaming */
#define STREAM_BUF_SIZE  (128 * 1024)


/* ─── Helpers ───────────────────────────────────────────── */

static const char *get_query_param(struct MHD_Connection *conn, const char *key)
{
    return MHD_lookup_connection_value(conn, MHD_GET_ARGUMENT_KIND, key);
}

static const char *get_header(struct MHD_Connection *conn, const char *key)
{
    return MHD_lookup_connection_value(conn, MHD_HEADER_KIND, key);
}

static void add_cors_headers(struct MHD_Response *resp)
{
    MHD_add_response_header(resp, "Access-Control-Allow-Origin", "*");
    MHD_add_response_header(resp, "Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
    MHD_add_response_header(resp, "Access-Control-Allow-Headers",
                            "Range, Authorization, Content-Type, Accept, Origin");
    MHD_add_response_header(resp, "Access-Control-Expose-Headers",
                            "Content-Length, Content-Range, Accept-Ranges, Content-Disposition, ETag");
    MHD_add_response_header(resp, "Access-Control-Max-Age", "86400");
}

/* Send JSON string response with CORS */
static enum MHD_Result send_json(struct MHD_Connection *conn, int status, const char *json)
{
    struct MHD_Response *resp;
    resp = MHD_create_response_from_buffer(strlen(json), (void *)json, MHD_RESPMEM_MUST_COPY);
    MHD_add_response_header(resp, "Content-Type", "application/json; charset=utf-8");
    add_cors_headers(resp);
    MHD_add_response_header(resp, "Cache-Control", "no-cache");
    enum MHD_Result ret = MHD_queue_response(conn, status, resp);
    MHD_destroy_response(resp);
    return ret;
}

static enum MHD_Result send_error(struct MHD_Connection *conn, int status, const char *msg)
{
    char buf[512];
    snprintf(buf, sizeof(buf), "{\"error\":\"%s\",\"status\":%d}", msg, status);
    return send_json(conn, status, buf);
}

static enum MHD_Result send_cors_preflight(struct MHD_Connection *conn)
{
    struct MHD_Response *resp = MHD_create_response_from_buffer(0, NULL, MHD_RESPMEM_PERSISTENT);
    add_cors_headers(resp);
    enum MHD_Result ret = MHD_queue_response(conn, MHD_HTTP_NO_CONTENT, resp);
    MHD_destroy_response(resp);
    return ret;
}

static void fmt_bytes(long bytes, char *buf, size_t buf_len)
{
    const char *units[] = {"B", "KB", "MB", "GB", "TB"};
    double val = (double)bytes;
    int u = 0;
    while (val >= 1024.0 && u < 4) { val /= 1024.0; u++; }
    snprintf(buf, buf_len, "%.1f %s", val, units[u]);
}

/*
 * Generate a simple ETag from file_id + size.
 * Not cryptographic — just for cache validation.
 */
static void generate_etag(const char *file_id, size_t size, char *etag, size_t etag_len)
{
    unsigned long hash = 5381;
    for (const char *p = file_id; *p; p++)
        hash = ((hash << 5) + hash) + (unsigned long)*p;
    hash ^= size;
    snprintf(etag, etag_len, "\"%lx-%zx\"", hash, size);
}

/*
 * Guess robust Content-Type from file extension.
 * Handles all major browser/player media types.
 */
static const char *guess_content_type(const char *filename, const char *stored_mime)
{
    /* If server provides a valid MIME, use it */
    if (stored_mime && stored_mime[0] && strcmp(stored_mime, "application/octet-stream") != 0)
        return stored_mime;

    /* Extension-based fallback */
    const char *ext = strrchr(filename, '.');
    if (!ext) return "application/octet-stream";
    ext++;

    /* Video */
    if (strcasecmp(ext, "mp4") == 0 || strcasecmp(ext, "m4v") == 0) return "video/mp4";
    if (strcasecmp(ext, "webm") == 0) return "video/webm";
    if (strcasecmp(ext, "mkv") == 0) return "video/x-matroska";
    if (strcasecmp(ext, "avi") == 0) return "video/x-msvideo";
    if (strcasecmp(ext, "mov") == 0) return "video/quicktime";
    if (strcasecmp(ext, "ts") == 0) return "video/mp2t";
    if (strcasecmp(ext, "flv") == 0) return "video/x-flv";
    if (strcasecmp(ext, "wmv") == 0) return "video/x-ms-wmv";
    if (strcasecmp(ext, "m3u8") == 0) return "application/vnd.apple.mpegurl";
    if (strcasecmp(ext, "mpd") == 0) return "application/dash+xml";

    /* Audio */
    if (strcasecmp(ext, "mp3") == 0) return "audio/mpeg";
    if (strcasecmp(ext, "m4a") == 0 || strcasecmp(ext, "aac") == 0) return "audio/mp4";
    if (strcasecmp(ext, "ogg") == 0 || strcasecmp(ext, "oga") == 0) return "audio/ogg";
    if (strcasecmp(ext, "opus") == 0) return "audio/opus";
    if (strcasecmp(ext, "wav") == 0) return "audio/wav";
    if (strcasecmp(ext, "flac") == 0) return "audio/flac";
    if (strcasecmp(ext, "wma") == 0) return "audio/x-ms-wma";

    /* Images */
    if (strcasecmp(ext, "jpg") == 0 || strcasecmp(ext, "jpeg") == 0) return "image/jpeg";
    if (strcasecmp(ext, "png") == 0) return "image/png";
    if (strcasecmp(ext, "gif") == 0) return "image/gif";
    if (strcasecmp(ext, "webp") == 0) return "image/webp";
    if (strcasecmp(ext, "svg") == 0) return "image/svg+xml";
    if (strcasecmp(ext, "ico") == 0) return "image/x-icon";
    if (strcasecmp(ext, "bmp") == 0) return "image/bmp";
    if (strcasecmp(ext, "avif") == 0) return "image/avif";

    /* Documents */
    if (strcasecmp(ext, "pdf") == 0) return "application/pdf";
    if (strcasecmp(ext, "json") == 0) return "application/json";
    if (strcasecmp(ext, "xml") == 0) return "application/xml";
    if (strcasecmp(ext, "html") == 0 || strcasecmp(ext, "htm") == 0) return "text/html";
    if (strcasecmp(ext, "css") == 0) return "text/css";
    if (strcasecmp(ext, "js") == 0) return "text/javascript";
    if (strcasecmp(ext, "txt") == 0 || strcasecmp(ext, "log") == 0) return "text/plain";
    if (strcasecmp(ext, "csv") == 0) return "text/csv";
    if (strcasecmp(ext, "md") == 0) return "text/markdown";

    /* Archives */
    if (strcasecmp(ext, "zip") == 0) return "application/zip";
    if (strcasecmp(ext, "gz") == 0 || strcasecmp(ext, "gzip") == 0) return "application/gzip";
    if (strcasecmp(ext, "tar") == 0) return "application/x-tar";
    if (strcasecmp(ext, "7z") == 0) return "application/x-7z-compressed";
    if (strcasecmp(ext, "rar") == 0) return "application/vnd.rar";

    return "application/octet-stream";
}


/* ─── URL Parsing ───────────────────────────────────────── */

static int parse_file_url(const char *url, char *bucket_name, size_t bn_len,
                          char *action, size_t act_len,
                          char *file_id, size_t fid_len)
{
    if (!url || url[0] != '/') return -1;

    const char *p = url + 1;
    const char *slash = strchr(p, '/');
    if (!slash) return -1;

    size_t blen = (size_t)(slash - p);
    if (blen == 0 || blen >= bn_len) return -1;
    memcpy(bucket_name, p, blen);
    bucket_name[blen] = '\0';

    p = slash + 1;
    slash = strchr(p, '/');
    if (!slash) {
        snprintf(action, act_len, "%s", p);
        file_id[0] = '\0';
        return 0;
    }

    size_t alen = (size_t)(slash - p);
    if (alen == 0 || alen >= act_len) return -1;
    memcpy(action, p, alen);
    action[alen] = '\0';

    p = slash + 1;
    snprintf(file_id, fid_len, "%s", p);
    return 0;
}


/* ─── Route: /health ────────────────────────────────────── */

static enum MHD_Result handle_health(struct MHD_Connection *conn)
{
    bucket_t buckets[MAX_BUCKETS];
    int count = 0;
    db_list_buckets(buckets, MAX_BUCKETS, &count);

    char buf[512];
    snprintf(buf, sizeof(buf),
             "{\"status\":\"healthy\",\"version\":\"%s\",\"registered_buckets\":%d,"
             "\"docker\":%s}",
             PROXY_VERSION, count,
             g_config->docker_mode ? "true" : "false");
    return send_json(conn, MHD_HTTP_OK, buf);
}


/* ─── Route: /status ────────────────────────────────────── */

static enum MHD_Result handle_status(struct MHD_Connection *conn)
{
    bucket_t buckets[MAX_BUCKETS];
    int count = 0;
    db_list_buckets(buckets, MAX_BUCKETS, &count);

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "status", "running");
    cJSON_AddStringToObject(root, "version", PROXY_VERSION);
    cJSON_AddStringToObject(root, "main_server", g_config->main_server_url);
    cJSON_AddNumberToObject(root, "port", g_config->port);
    cJSON_AddBoolToObject(root, "docker", g_config->docker_mode);
    cJSON_AddNumberToObject(root, "total_requests", g_stats->total_requests);
    cJSON_AddNumberToObject(root, "total_bytes_served", (double)g_stats->total_bytes_served);

    long uptime = (long)(time(NULL) - g_stats->start_time);
    char uptime_buf[64];
    int days = (int)(uptime / 86400);
    int hours = (int)((uptime % 86400) / 3600);
    int mins = (int)((uptime % 3600) / 60);
    int secs = (int)(uptime % 60);
    if (days > 0)
        snprintf(uptime_buf, sizeof(uptime_buf), "%dd %dh %dm %ds", days, hours, mins, secs);
    else if (hours > 0)
        snprintf(uptime_buf, sizeof(uptime_buf), "%dh %dm %ds", hours, mins, secs);
    else
        snprintf(uptime_buf, sizeof(uptime_buf), "%dm %ds", mins, secs);
    cJSON_AddStringToObject(root, "uptime", uptime_buf);

    char bytes_buf[32];
    fmt_bytes(g_stats->total_bytes_served, bytes_buf, sizeof(bytes_buf));
    cJSON_AddStringToObject(root, "total_bytes_served_human", bytes_buf);

    cJSON *arr = cJSON_AddArrayToObject(root, "buckets");
    for (int i = 0; i < count; i++) {
        cJSON *b = cJSON_CreateObject();
        cJSON_AddStringToObject(b, "name", buckets[i].name);
        cJSON_AddStringToObject(b, "display_name", buckets[i].display_name);
        cJSON_AddStringToObject(b, "storage_type", buckets[i].storage_type);
        cJSON_AddNumberToObject(b, "total_files", buckets[i].total_files);
        cJSON_AddNumberToObject(b, "used_bytes", (double)buckets[i].used_bytes);
        cJSON_AddItemToArray(arr, b);
    }

    char *json = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    enum MHD_Result ret = send_json(conn, MHD_HTTP_OK, json);
    free(json);
    return ret;
}


/* ─── Route: /buckets ───────────────────────────────────── */

static enum MHD_Result handle_buckets(struct MHD_Connection *conn)
{
    bucket_t buckets[MAX_BUCKETS];
    int count = 0;
    db_list_buckets(buckets, MAX_BUCKETS, &count);

    cJSON *root = cJSON_CreateObject();
    cJSON *arr = cJSON_AddArrayToObject(root, "buckets");

    for (int i = 0; i < count; i++) {
        cJSON *b = cJSON_CreateObject();
        cJSON_AddStringToObject(b, "name", buckets[i].name);
        cJSON_AddStringToObject(b, "display_name", buckets[i].display_name);
        cJSON_AddStringToObject(b, "storage_type", buckets[i].storage_type);
        cJSON_AddNumberToObject(b, "total_files", buckets[i].total_files);
        cJSON_AddItemToArray(arr, b);
    }

    char *json = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    enum MHD_Result ret = send_json(conn, MHD_HTTP_OK, json);
    free(json);
    return ret;
}


/* ─── Route: /{bucket}/files ────────────────────────────── */

static enum MHD_Result handle_list_files(struct MHD_Connection *conn,
                                          const char *bucket_name)
{
    bucket_t bucket;
    if (db_get_bucket(bucket_name, &bucket) != 0)
        return send_error(conn, MHD_HTTP_NOT_FOUND, "Bucket not registered");

    const char *limit_s  = get_query_param(conn, "limit");
    const char *offset_s = get_query_param(conn, "offset");
    int limit  = limit_s  ? atoi(limit_s)  : 100;
    int offset = offset_s ? atoi(offset_s) : 0;
    if (limit < 1) limit = 1;
    if (limit > 500) limit = 500;
    if (offset < 0) offset = 0;

    char *json = api_list_files(g_config->main_server_url,
                                bucket.bucket_id, bucket.token, limit, offset);
    if (!json)
        return send_error(conn, MHD_HTTP_BAD_GATEWAY, "Failed to list files from server");

    enum MHD_Result ret = send_json(conn, MHD_HTTP_OK, json);
    free(json);
    return ret;
}


/* ─── Streaming context ─────────────────────────────────── */

typedef struct {
    file_info_t   file_info;
    size_t        start_byte;
    size_t        end_byte;
    int           current_chunk_idx;
    unsigned char *current_data;
    size_t        current_data_len;
    size_t        current_data_pos;
    long          bytes_sent;
    char          bucket_name[MAX_NAME_LEN];
    bool          is_download;
} stream_ctx_t;

static void stream_ctx_free(void *cls)
{
    stream_ctx_t *ctx = (stream_ctx_t *)cls;
    if (!ctx) return;

    if (ctx->bytes_sent > 0) {
        __sync_add_and_fetch(&g_stats->total_requests, 1);
        __sync_add_and_fetch(&g_stats->total_bytes_served, ctx->bytes_sent);
        if (ctx->is_download)
            __sync_add_and_fetch(&g_stats->download_requests, 1);
        else
            __sync_add_and_fetch(&g_stats->stream_requests, 1);
        db_increment_stats(ctx->bucket_name, ctx->bytes_sent);

        char size_buf[32];
        fmt_bytes(ctx->bytes_sent, size_buf, sizeof(size_buf));
        LOG_INFO("  %s %s for %s (%s)",
                 ctx->is_download ? "⬇ Downloaded" : "✓ Streamed",
                 ctx->file_info.name, ctx->bucket_name, size_buf);
    }

    free(ctx->current_data);
    free(ctx);
}

/*
 * Content reader callback.
 * Called repeatedly by MHD to get data chunks for streaming response.
 * Downloads and decrypts chunks on-demand, one at a time.
 */
static ssize_t stream_reader_callback(void *cls, uint64_t pos, char *buf, size_t max)
{
    stream_ctx_t *ctx = (stream_ctx_t *)cls;
    size_t total_to_send = ctx->end_byte - ctx->start_byte + 1;

    if ((size_t)ctx->bytes_sent >= total_to_send)
        return MHD_CONTENT_READER_END_OF_STREAM;

    size_t filled = 0;

    while (filled < max && (size_t)ctx->bytes_sent < total_to_send) {
        /* If current chunk data exhausted, fetch and decrypt next */
        if (!ctx->current_data || ctx->current_data_pos >= ctx->current_data_len) {
            free(ctx->current_data);
            ctx->current_data = NULL;
            ctx->current_data_len = 0;
            ctx->current_data_pos = 0;

            size_t chunk_size = ctx->file_info.chunk_size;

            while (ctx->current_chunk_idx < ctx->file_info.num_chunks) {
                chunk_info_t *ci = &ctx->file_info.chunks[ctx->current_chunk_idx];
                size_t chunk_start_byte = (size_t)ci->sequence * chunk_size;

                /* Download encrypted chunk data */
                size_t enc_len;
                unsigned char *enc = api_download_chunk(ci, &enc_len);
                if (!enc) {
                    LOG_ERR("Failed to download chunk %d for %s",
                            ci->sequence, ctx->file_info.name);
                    ctx->current_chunk_idx++;
                    continue;
                }

                /* Decrypt */
                unsigned char *dec = NULL;
                size_t dec_len = 0;
                if (crypto_decrypt(enc, enc_len, ci->aes_key_b64, ci->aes_iv_b64,
                                   &dec, &dec_len) != 0) {
                    LOG_ERR("Failed to decrypt chunk %d for %s",
                            ci->sequence, ctx->file_info.name);
                    free(enc);
                    ctx->current_chunk_idx++;
                    continue;
                }
                free(enc);

                size_t chunk_data_end = chunk_start_byte + dec_len;

                /* Skip chunks entirely before our range */
                if (chunk_data_end <= ctx->start_byte) {
                    free(dec);
                    ctx->current_chunk_idx++;
                    continue;
                }

                /* Stop if chunk is entirely after our range */
                if (chunk_start_byte > ctx->end_byte) {
                    free(dec);
                    break;
                }

                /* Slice the chunk to our range */
                size_t local_start = 0;
                size_t local_end = dec_len;

                if (chunk_start_byte < ctx->start_byte)
                    local_start = ctx->start_byte - chunk_start_byte;
                if (chunk_data_end > ctx->end_byte + 1)
                    local_end = ctx->end_byte + 1 - chunk_start_byte;

                size_t slice_len = local_end - local_start;

                ctx->current_data = malloc(slice_len);
                if (!ctx->current_data) {
                    free(dec);
                    return MHD_CONTENT_READER_END_WITH_ERROR;
                }
                memcpy(ctx->current_data, dec + local_start, slice_len);
                ctx->current_data_len = slice_len;
                ctx->current_data_pos = 0;
                free(dec);

                ctx->current_chunk_idx++;
                break;
            }

            if (!ctx->current_data)
                return filled > 0 ? (ssize_t)filled : MHD_CONTENT_READER_END_OF_STREAM;
        }

        /* Copy from decrypted chunk to output buffer */
        size_t remaining_chunk = ctx->current_data_len - ctx->current_data_pos;
        size_t remaining_total = total_to_send - (size_t)ctx->bytes_sent;
        size_t space = max - filled;
        size_t to_copy = remaining_chunk;
        if (to_copy > space) to_copy = space;
        if (to_copy > remaining_total) to_copy = remaining_total;

        memcpy(buf + filled, ctx->current_data + ctx->current_data_pos, to_copy);
        ctx->current_data_pos += to_copy;
        ctx->bytes_sent += (long)to_copy;
        filled += to_copy;
    }

    return (ssize_t)filled;
}


/* ─── Parse Range header ────────────────────────────────── */

static bool parse_range(const char *range_header, size_t file_size,
                        size_t *start, size_t *end)
{
    *start = 0;
    *end = file_size > 0 ? file_size - 1 : 0;

    if (!range_header || strncmp(range_header, "bytes=", 6) != 0)
        return false;

    const char *spec = range_header + 6;
    char *dash = strchr(spec, '-');
    if (!dash) return false;

    if (dash > spec) {
        /* bytes=N-M or bytes=N- */
        *start = (size_t)strtoll(spec, NULL, 10);
    } else {
        /* bytes=-N (last N bytes) */
        size_t suffix = (size_t)strtoll(dash + 1, NULL, 10);
        if (suffix > file_size) suffix = file_size;
        *start = file_size - suffix;
        *end = file_size - 1;
        return true;
    }

    if (dash[1] != '\0') {
        *end = (size_t)strtoll(dash + 1, NULL, 10);
    }

    /* Clamp */
    if (*start >= file_size) *start = file_size - 1;
    if (*end >= file_size) *end = file_size - 1;
    if (*start > *end) *start = 0;

    return true;
}


/* ─── Build streaming response ──────────────────────────── */

static enum MHD_Result serve_file(struct MHD_Connection *conn,
                                   const char *bucket_name,
                                   const char *file_id,
                                   bool is_download,
                                   bool head_only)
{
    bucket_t bucket;
    if (db_get_bucket(bucket_name, &bucket) != 0)
        return send_error(conn, MHD_HTTP_NOT_FOUND, "Bucket not registered");

    const char *file_token = get_query_param(conn, "token");

    /* Fetch file metadata + chunk info */
    file_info_t fi;
    int rc = api_get_file_info(g_config->main_server_url, bucket.token,
                               file_id, file_token, &fi);
    if (rc != 0) {
        if (rc == -404) return send_error(conn, MHD_HTTP_NOT_FOUND, "File not found");
        if (rc == -401) return send_error(conn, MHD_HTTP_UNAUTHORIZED, "File token required");
        if (rc == -403) return send_error(conn, MHD_HTTP_FORBIDDEN, "Access denied");
        return send_error(conn, MHD_HTTP_BAD_GATEWAY, "Failed to get file info");
    }

    /* Generate ETag */
    char etag[64];
    generate_etag(file_id, fi.size, etag, sizeof(etag));

    /* ── ETag: If-None-Match (304 Not Modified) ── */
    const char *if_none_match = get_header(conn, "If-None-Match");
    if (if_none_match && strcmp(if_none_match, etag) == 0) {
        struct MHD_Response *resp = MHD_create_response_from_buffer(0, NULL, MHD_RESPMEM_PERSISTENT);
        add_cors_headers(resp);
        MHD_add_response_header(resp, "ETag", etag);
        enum MHD_Result ret = MHD_queue_response(conn, MHD_HTTP_NOT_MODIFIED, resp);
        MHD_destroy_response(resp);
        return ret;
    }

    /* Content type */
    const char *content_type;
    if (is_download) {
        content_type = "application/octet-stream";
    } else {
        content_type = guess_content_type(fi.name, fi.mime_type);
    }

    /* ── Range parsing ── */
    const char *range_header = get_header(conn, "Range");
    size_t start_byte = 0;
    size_t end_byte = fi.size > 0 ? fi.size - 1 : 0;
    bool has_range = false;

    if (range_header) {
        /* If-Range: only honour Range if ETag matches */
        const char *if_range = get_header(conn, "If-Range");
        if (if_range && strcmp(if_range, etag) != 0) {
            /* ETag mismatch → serve full file */
            has_range = false;
        } else {
            has_range = parse_range(range_header, fi.size, &start_byte, &end_byte);
        }
    }

    size_t content_length = end_byte - start_byte + 1;

    /* Log */
    char size_buf[32];
    fmt_bytes((long)fi.size, size_buf, sizeof(size_buf));
    if (is_download) {
        LOG_REQ("⬇ DOWNLOAD %s/%s — %s (%s, %d chunks)",
                bucket_name, fi.name, fi.file_id, size_buf, fi.num_chunks);
    } else if (has_range) {
        LOG_REQ("▶ STREAM %s/%s — Range %zu-%zu/%zu (%s)",
                bucket_name, fi.name, start_byte, end_byte, fi.size,
                fi.is_public ? "public" : "private");
    } else {
        LOG_REQ("▶ STREAM %s/%s — Full %s (%d chunks, %s)",
                bucket_name, fi.name, size_buf, fi.num_chunks,
                fi.is_public ? "public" : "private");
    }

    /* ── HEAD request: just return headers ── */
    if (head_only) {
        struct MHD_Response *resp = MHD_create_response_from_buffer(0, NULL, MHD_RESPMEM_PERSISTENT);
        MHD_add_response_header(resp, "Content-Type", content_type);
        add_cors_headers(resp);
        MHD_add_response_header(resp, "Accept-Ranges", "bytes");
        MHD_add_response_header(resp, "ETag", etag);

        char cl_buf[32];
        snprintf(cl_buf, sizeof(cl_buf), "%zu", fi.size);
        MHD_add_response_header(resp, "Content-Length", cl_buf);

        if (is_download) {
            char cd_buf[MAX_NAME_LEN + 64];
            snprintf(cd_buf, sizeof(cd_buf), "attachment; filename=\"%s\"", fi.name);
            MHD_add_response_header(resp, "Content-Disposition", cd_buf);
        }

        enum MHD_Result ret = MHD_queue_response(conn, MHD_HTTP_OK, resp);
        MHD_destroy_response(resp);
        __sync_add_and_fetch(&g_stats->total_requests, 1);
        return ret;
    }

    /* ── Build streaming response ── */
    stream_ctx_t *ctx = calloc(1, sizeof(stream_ctx_t));
    if (!ctx) return send_error(conn, MHD_HTTP_INTERNAL_SERVER_ERROR, "Out of memory");

    ctx->file_info = fi;
    ctx->start_byte = start_byte;
    ctx->end_byte = end_byte;
    ctx->current_chunk_idx = 0;
    ctx->is_download = is_download;
    snprintf(ctx->bucket_name, sizeof(ctx->bucket_name), "%s", bucket_name);

    struct MHD_Response *resp = MHD_create_response_from_callback(
        content_length,
        STREAM_BUF_SIZE,
        stream_reader_callback,
        ctx,
        stream_ctx_free
    );
    if (!resp) {
        free(ctx);
        return send_error(conn, MHD_HTTP_INTERNAL_SERVER_ERROR, "Failed to create response");
    }

    /* ── Response headers ── */
    MHD_add_response_header(resp, "Content-Type", content_type);
    add_cors_headers(resp);
    MHD_add_response_header(resp, "Accept-Ranges", "bytes");
    MHD_add_response_header(resp, "ETag", etag);

    /* Cache-Control: public files get mild caching, private don't */
    if (fi.is_public) {
        MHD_add_response_header(resp, "Cache-Control", "public, max-age=3600, must-revalidate");
    } else {
        MHD_add_response_header(resp, "Cache-Control", "private, no-store");
    }

    char cl_buf[32];
    snprintf(cl_buf, sizeof(cl_buf), "%zu", content_length);
    MHD_add_response_header(resp, "Content-Length", cl_buf);

    /* X-Content-Duration for audio/video (helps some players) */
    /* Keep-alive */
    MHD_add_response_header(resp, "Connection", "keep-alive");

    int http_status;
    if (has_range) {
        char cr_buf[128];
        snprintf(cr_buf, sizeof(cr_buf), "bytes %zu-%zu/%zu",
                 start_byte, end_byte, fi.size);
        MHD_add_response_header(resp, "Content-Range", cr_buf);
        http_status = MHD_HTTP_PARTIAL_CONTENT;
    } else {
        http_status = MHD_HTTP_OK;
    }

    /* Download: Content-Disposition */
    if (is_download) {
        char cd_buf[MAX_NAME_LEN + 64];
        snprintf(cd_buf, sizeof(cd_buf), "attachment; filename=\"%s\"", fi.name);
        MHD_add_response_header(resp, "Content-Disposition", cd_buf);
    } else {
        /* Inline for streaming — browsers can play inline */
        char cd_buf[MAX_NAME_LEN + 64];
        snprintf(cd_buf, sizeof(cd_buf), "inline; filename=\"%s\"", fi.name);
        MHD_add_response_header(resp, "Content-Disposition", cd_buf);
    }

    enum MHD_Result ret = MHD_queue_response(conn, http_status, resp);
    MHD_destroy_response(resp);
    return ret;
}


/* ─── Main request handler ──────────────────────────────── */

static enum MHD_Result request_handler(
    void *cls,
    struct MHD_Connection *conn,
    const char *url,
    const char *method,
    const char *version,
    const char *upload_data,
    size_t *upload_data_size,
    void **con_cls)
{
    (void)cls; (void)version; (void)upload_data; (void)upload_data_size;

    /* First call setup */
    if (*con_cls == NULL) {
        *con_cls = (void *)1;
        return MHD_YES;
    }

    /* CORS preflight */
    if (strcmp(method, "OPTIONS") == 0)
        return send_cors_preflight(conn);

    bool is_head = (strcmp(method, "HEAD") == 0);
    bool is_get  = (strcmp(method, "GET") == 0);

    if (!is_get && !is_head) {
        return send_error(conn, MHD_HTTP_METHOD_NOT_ALLOWED, "Only GET/HEAD/OPTIONS");
    }

    /* ─── Fixed routes ─── */
    if (strcmp(url, "/") == 0 || strcmp(url, "/health") == 0)
        return handle_health(conn);

    if (strcmp(url, "/status") == 0)
        return handle_status(conn);

    if (strcmp(url, "/buckets") == 0)
        return handle_buckets(conn);

    /* ─── Dynamic: /{bucket}/... ─── */
    char bucket_name[MAX_NAME_LEN] = {0};
    char action[32] = {0};
    char file_id[256] = {0};

    if (parse_file_url(url, bucket_name, sizeof(bucket_name),
                       action, sizeof(action),
                       file_id, sizeof(file_id)) == 0) {

        if (strcmp(action, "files") == 0 && file_id[0] == '\0')
            return handle_list_files(conn, bucket_name);

        if (strcmp(action, "stream") == 0 && file_id[0])
            return serve_file(conn, bucket_name, file_id, false, is_head);

        if (strcmp(action, "download") == 0 && file_id[0])
            return serve_file(conn, bucket_name, file_id, true, is_head);
    }

    return send_error(conn, MHD_HTTP_NOT_FOUND, "Not found");
}


/* ─── Start / Stop ──────────────────────────────────────── */

int server_start(server_config_t *config, server_stats_t *stats)
{
    g_config = config;
    g_stats  = stats;
    g_stats->start_time = time(NULL);
    g_running = 1;

    /*
     * Production configuration:
     * - MHD_USE_EPOLL: epoll for Linux (best perf)
     * - MHD_USE_TURBO: optimized internal polling
     * - MHD_USE_INTERNAL_POLLING_THREAD + thread pool
     * - High connection limit for heavy concurrency
     */
    unsigned int flags = MHD_USE_INTERNAL_POLLING_THREAD | MHD_USE_ERROR_LOG;

#ifdef MHD_USE_EPOLL
    flags |= MHD_USE_EPOLL;
#endif
#ifdef MHD_USE_TURBO
    flags |= MHD_USE_TURBO;
#endif

    g_daemon = MHD_start_daemon(
        flags,
        (uint16_t)config->port,
        NULL, NULL,                                     /* access policy */
        &request_handler, NULL,                         /* handler */
        MHD_OPTION_THREAD_POOL_SIZE, (unsigned int)THREAD_POOL_SIZE,
        MHD_OPTION_CONNECTION_LIMIT, (unsigned int)MAX_CONNECTIONS,
        MHD_OPTION_CONNECTION_TIMEOUT, (unsigned int)CONNECTION_TIMEOUT,
        MHD_OPTION_END
    );

    if (!g_daemon) {
        LOG_ERR("Failed to start HTTP server on port %d", config->port);
        LOG_ERR("Is another process using this port?");
        return -1;
    }

    LOG_INFO("HTTP server listening on :%d (pool=%d, maxconn=%d)",
             config->port, THREAD_POOL_SIZE, MAX_CONNECTIONS);
    return 0;
}

void server_stop(void)
{
    g_running = 0;
    if (g_daemon) {
        MHD_stop_daemon(g_daemon);
        g_daemon = NULL;
        LOG_INFO("HTTP server stopped");
    }
}
