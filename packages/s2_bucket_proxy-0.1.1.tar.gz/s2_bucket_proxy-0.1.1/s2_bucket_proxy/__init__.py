"""S2 Bucket Proxy — C Engine-based file proxy server."""

__version__ = "0.1.1"
__author__ = "Sandesh"

from .manager import ProxyManager
