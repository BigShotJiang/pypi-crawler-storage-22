"""
Interactive CLI for the S2 Bucket Proxy.

Provides a terminal interface for managing the proxy server,
registering/removing buckets, and controlling the C engine.

Usage:
  s2-proxy                 Interactive mode
  s2-proxy start           Start server (foreground)
  s2-proxy start -d        Start server (daemon)
  s2-proxy stop            Stop daemon server
  s2-proxy add <token>     Add a bucket
  s2-proxy remove <name>   Remove a bucket
  s2-proxy list            List buckets
  s2-proxy status          Show status
  s2-proxy --docker        Docker container mode
"""

import sys
import os
import argparse

from .manager import ProxyManager


BANNER = """
\033[96m╔═══════════════════════════════════════════════╗
║        S2 Bucket Proxy — v{version:<19s}║
╚═══════════════════════════════════════════════╝\033[0m
"""

HELP_TEXT = """
\033[1mAvailable Commands:\033[0m

  \033[92mstart\033[0m              Start the proxy server (foreground)
  \033[92mstart -d\033[0m           Start as background daemon
  \033[92mstop\033[0m               Stop the daemon
  \033[92madd <token>\033[0m        Register a bucket by its token
  \033[92mremove <name>\033[0m      Remove a registered bucket
  \033[92mlist\033[0m               List registered buckets
  \033[92mstatus\033[0m             Show server status
  \033[92mconfig\033[0m             Show/edit configuration
  \033[92mhelp\033[0m               Show this help
  \033[92mquit\033[0m               Exit
"""


def _input(prompt):
    """Read input with a colored prompt."""
    try:
        return input(f"\033[93m{prompt}\033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return "quit"


def interactive_mode(manager):
    """Run the interactive CLI."""
    from . import __version__
    print(BANNER.format(version=__version__))
    print(f"  \033[2mMain Server:  {manager.server_url}\033[0m")
    print(f"  \033[2mProxy Port:   {manager.port}\033[0m")
    print(f"  \033[2mDatabase:     {manager.db_path}\033[0m")
    print()

    # Show registered buckets on start
    manager.list_buckets()

    while True:
        cmd = _input("proxy> ")
        if not cmd:
            continue

        parts = cmd.split()
        action = parts[0].lower()

        if action in ("quit", "exit", "q"):
            print("\033[2mGoodbye!\033[0m")
            break

        elif action == "help":
            print(HELP_TEXT)

        elif action == "start":
            daemon = "-d" in parts or "--daemon" in parts
            token = None
            for i, p in enumerate(parts):
                if p in ("-t", "--token") and i + 1 < len(parts):
                    token = parts[i + 1]
            manager.start(daemon=daemon, token=token)

        elif action == "stop":
            manager.stop()

        elif action == "add":
            if len(parts) < 2:
                token = _input("Bucket token (bkt_...): ")
            else:
                token = parts[1]
            if token and token != "quit":
                manager.add_bucket(token)

        elif action == "remove":
            if len(parts) < 2:
                name = _input("Bucket name: ")
            else:
                name = parts[1]
            if name and name != "quit":
                manager.remove_bucket(name)

        elif action == "list":
            manager.list_buckets()

        elif action == "status":
            manager.status()
            if manager.health_check():
                print(f"  \033[92m●\033[0m HTTP server responding on :{manager.port}")
            else:
                print(f"  \033[91m●\033[0m HTTP server not responding on :{manager.port}")

        elif action == "config":
            print(f"\n  Main Server:  {manager.server_url}")
            print(f"  Proxy Port:   {manager.port}")
            print(f"  Database:     {manager.db_path}")
            print(f"  Docker Mode:  {manager.docker}")
            new_server = _input(f"  Main Server [{manager.server_url}]: ")
            if new_server and new_server != "quit":
                manager.server_url = new_server
            new_port = _input(f"  Port [{manager.port}]: ")
            if new_port and new_port != "quit" and new_port.isdigit():
                manager.port = int(new_port)
            print("  \033[92m✓ Config updated\033[0m")

        else:
            print(f"  \033[91mUnknown command: {action}\033[0m — type 'help' for commands")


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="s2-proxy",
        description="S2 Bucket Proxy — C Engine-based file proxy server"
    )
    parser.add_argument("command", nargs="?", default=None,
                        help="Command: start, stop, add, remove, list, status")
    parser.add_argument("arg", nargs="?", default=None,
                        help="Argument for the command (token or bucket name)")
    parser.add_argument("--server", "-s", default="http://localhost:8000",
                        help="Main storage server URL")
    parser.add_argument("--port", "-p", type=int, default=8001,
                        help="Proxy server port")
    parser.add_argument("--db", default=None,
                        help="Database path")
    parser.add_argument("--daemon", "-d", action="store_true",
                        help="Start as daemon")
    parser.add_argument("--docker", action="store_true",
                        help="Docker/container mode (env vars)")
    parser.add_argument("--token", "-t", default=None,
                        help="Bucket token")

    args = parser.parse_args()

    # Docker mode: read from env
    if args.docker:
        args.server = os.environ.get("S2_MAIN_SERVER", args.server)
        args.port = int(os.environ.get("S2_PORT", str(args.port)))
        args.db = os.environ.get("S2_DB_PATH", args.db)
        args.token = os.environ.get("S2_TOKEN", args.token)

    manager = ProxyManager(
        server_url=args.server,
        port=args.port,
        db_path=args.db,
        docker=args.docker
    )

    # Non-interactive commands
    if args.command:
        cmd = args.command.lower()

        if cmd == "start":
            manager.start(daemon=args.daemon, token=args.token)

        elif cmd == "stop":
            manager.stop()

        elif cmd == "add":
            token = args.arg or args.token
            if not token:
                print("\033[91mError: token required. Usage: s2-proxy add <token>\033[0m")
                sys.exit(1)
            manager.add_bucket(token)

        elif cmd == "remove":
            name = args.arg
            if not name:
                print("\033[91mError: bucket name required. Usage: s2-proxy remove <name>\033[0m")
                sys.exit(1)
            manager.remove_bucket(name)

        elif cmd == "list":
            manager.list_buckets()

        elif cmd == "status":
            manager.status()
            if manager.health_check():
                print(f"  \033[92m●\033[0m Server responding on :{manager.port}")
            else:
                print(f"  \033[91m●\033[0m Server not responding on :{manager.port}")

        else:
            print(f"\033[91mUnknown command: {cmd}\033[0m")
            parser.print_help()
            sys.exit(1)
    else:
        # Interactive mode
        interactive_mode(manager)


if __name__ == "__main__":
    main()
