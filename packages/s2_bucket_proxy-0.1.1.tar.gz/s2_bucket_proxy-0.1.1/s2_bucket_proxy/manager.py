"""
Proxy engine process manager.

Finds the compiled C engine binary and provides start/stop/status operations.
"""

import os
import sys
import signal
import subprocess
import time

from pathlib import Path


def _find_engine():
    """Find the bucket_proxy_engine binary.

    Search order:
    1. Package bin/ directory (installed via pip)
    2. Development c_engine/ directory (pip install -e .)
    3. System PATH
    """
    pkg_dir = Path(__file__).parent

    # 1. Installed package bin/ directory
    pkg_bin = pkg_dir / "bin" / "bucket_proxy_engine"
    if pkg_bin.is_file() and os.access(pkg_bin, os.X_OK):
        return str(pkg_bin)

    # 2. Development directory (editable install)
    dev_bin = pkg_dir.parent / "c_engine" / "bucket_proxy_engine"
    if dev_bin.is_file() and os.access(dev_bin, os.X_OK):
        return str(dev_bin)

    # 3. System PATH
    for d in os.environ.get("PATH", "").split(":"):
        p = Path(d) / "bucket_proxy_engine"
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)

    return None


class ProxyManager:
    """Manage the bucket proxy engine process."""

    def __init__(self,
                 server_url="http://localhost:8000",
                 port=8001,
                 db_path=None,
                 docker=False):
        self.server_url = server_url
        self.port = port
        self.docker = docker
        self.db_path = db_path or os.path.expanduser("~/.s2_proxy.db")
        self.engine_path = _find_engine()
        self._process = None

    def _build_args(self, cmd, extra=None):
        args = [self.engine_path]
        args += ["--server", self.server_url]
        args += ["--port", str(self.port)]
        args += ["--db", self.db_path]
        if self.docker:
            args += ["--docker"]
        args.append(cmd)
        if extra:
            args += extra
        return args

    def start(self, daemon=False, token=None):
        """Start the proxy server."""
        if not self.engine_path:
            print("\033[91mError: C engine binary not found.\033[0m")
            print("\033[91mTry reinstalling: pip install --force-reinstall s2-bucket-proxy\033[0m")
            return False

        args = [self.engine_path]
        args += ["--server", self.server_url]
        args += ["--port", str(self.port)]
        args += ["--db", self.db_path]
        if self.docker:
            args += ["--docker"]
        if daemon:
            args += ["--daemon"]
            pid_file = os.path.expanduser("~/.s2_proxy.pid")
            log_file = os.path.expanduser("~/.s2_proxy.log")
            args += ["--pid-file", pid_file]
            args += ["--log-file", log_file]
        if token:
            args += ["--token", token]
        args.append("serve")

        if daemon:
            result = subprocess.run(args, capture_output=True, text=True)
            if result.returncode == 0:
                pid = result.stdout.strip()
                print(f"\033[92m✓ Proxy started in background (PID {pid})\033[0m")
                return True
            else:
                print(f"\033[91m✗ Failed to start: {result.stderr}\033[0m")
                return False
        else:
            # Foreground mode
            try:
                self._process = subprocess.Popen(args)
                self._process.wait()
            except KeyboardInterrupt:
                self.stop()
            return True

    def stop(self):
        """Stop the proxy server."""
        if self._process:
            self._process.terminate()
            self._process.wait(timeout=5)
            self._process = None
            return True

        # Try PID file
        pid_file = os.path.expanduser("~/.s2_proxy.pid")
        if os.path.exists(pid_file):
            try:
                with open(pid_file) as f:
                    pid = int(f.read().strip())
                os.kill(pid, signal.SIGTERM)
                for _ in range(10):
                    try:
                        os.kill(pid, 0)
                        time.sleep(0.5)
                    except ProcessLookupError:
                        break
                os.unlink(pid_file)
                print(f"\033[92m✓ Proxy stopped (PID {pid})\033[0m")
                return True
            except Exception as e:
                print(f"\033[91m✗ Failed to stop: {e}\033[0m")
        return False

    def add_bucket(self, token):
        """Register a bucket with the proxy."""
        if not self.engine_path:
            print("\033[91mError: C engine binary not found.\033[0m")
            return False
        args = self._build_args("add-bucket", ["--token", token])
        return subprocess.run(args).returncode == 0

    def remove_bucket(self, name):
        """Remove a registered bucket."""
        if not self.engine_path:
            print("\033[91mError: C engine binary not found.\033[0m")
            return False
        args = self._build_args("remove-bucket", ["--name", name])
        return subprocess.run(args).returncode == 0

    def list_buckets(self):
        """List registered buckets."""
        if not self.engine_path:
            print("\033[91mError: C engine binary not found.\033[0m")
            return False
        args = self._build_args("list-buckets")
        return subprocess.run(args).returncode == 0

    def status(self):
        """Show proxy status."""
        if not self.engine_path:
            print("\033[91mError: C engine binary not found.\033[0m")
            return False
        args = self._build_args("status")
        return subprocess.run(args).returncode == 0

    def health_check(self):
        """Check if the proxy server is responding."""
        import urllib.request
        try:
            url = f"http://localhost:{self.port}/health"
            req = urllib.request.urlopen(url, timeout=3)
            return req.status == 200
        except Exception:
            return False
