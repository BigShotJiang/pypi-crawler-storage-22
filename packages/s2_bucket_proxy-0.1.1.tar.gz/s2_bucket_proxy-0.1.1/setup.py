"""
Setup script for s2-bucket-proxy.

Dependency checking and distro-specific hints.
Compilation is handled by _build_backend.py, NOT here.
"""

from setuptools import setup

setup()
