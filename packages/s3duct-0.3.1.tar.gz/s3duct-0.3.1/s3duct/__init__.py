"""s3duct - Chunked, resumable, encrypted pipe to object storage."""

__version__ = "0.3.1"
