"""S3Hero - A powerful CLI tool to manage S3 buckets."""

__version__ = "1.0.0"
__author__ = "S3Hero Team"
