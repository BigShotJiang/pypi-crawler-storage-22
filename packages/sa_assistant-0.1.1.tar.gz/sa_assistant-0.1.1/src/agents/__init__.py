# SA 에이전트 모듈
# Orchestrator + Guru Sub-agents + Specialist Sub-agents 아키텍처

from .orchestrator import (
    create_orchestrator,
    consult_guru,
    list_gurus,
    get_available_gurus,
)

from .specialists import (
    consult_specialist,
    list_specialists,
    get_available_specialists,
    parallel_research,
    run_specialists_parallel,
)

__all__ = [
    # Orchestrator
    "create_orchestrator",
    # Guru
    "consult_guru",
    "list_gurus",
    "get_available_gurus",
    # Specialist
    "consult_specialist",
    "list_specialists",
    "get_available_specialists",
    "parallel_research",
    "run_specialists_parallel",
]
