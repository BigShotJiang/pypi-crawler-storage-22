# SA Orchestrator - AWS Solutions Architect Professional Agent
# Guru Sub-agents를 활용한 전문가 자문 시스템
# ThreadPoolExecutor를 사용하여 Sub-agent를 별도 스레드에서 실행 (OpenTelemetry 컨텍스트 격리)

from concurrent.futures import ThreadPoolExecutor
from typing import List, Any
from strands import Agent, tool

# 로컬 모듈 임포트
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from model.load import load_opus, load_sonnet
from prompts.system_prompts import (
    ORCHESTRATOR_PROMPT,
    GURU_PROMPTS,
    get_orchestrator_prompt,
)


# =============================================================================
# Guru Sub-agent 도구 (ThreadPoolExecutor로 별도 스레드에서 실행)
# =============================================================================

def get_available_gurus() -> List[str]:
    """사용 가능한 Guru 목록을 반환합니다."""
    return list(GURU_PROMPTS.keys())


def _run_guru_in_thread(guru_name: str, question: str) -> str:
    """
    별도 스레드에서 Guru Agent 실행 (OpenTelemetry 컨텍스트 격리)
    
    ThreadPoolExecutor에서 호출되어 독립적인 스레드에서 실행됩니다.
    OpenTelemetry 컨텍스트를 명시적으로 분리하여
    "Failed to detach context" 오류를 방지합니다.
    
    Args:
        guru_name: Guru 이름 (소문자)
        question: 자문을 구할 질문
    
    Returns:
        str: Guru의 응답 텍스트
    """
    # OpenTelemetry 컨텍스트 명시적 분리
    try:
        from opentelemetry import context as otel_context
        # 새로운 빈 컨텍스트에서 실행
        token = otel_context.attach(otel_context.Context())
    except ImportError:
        token = None
    
    try:
        guru_agent = Agent(
            model=load_sonnet(enable_thinking=False),
            system_prompt=GURU_PROMPTS[guru_name],
        )
        result = guru_agent(question)
        return str(result)
    finally:
        # 컨텍스트 복원
        if token is not None:
            try:
                otel_context.detach(token)
            except Exception:
                pass  # detach 실패 무시


@tool
def consult_guru(guru_name: str, question: str) -> str:
    """
    전문가 Guru에게 자문을 구합니다.
    
    복잡한 아키텍처 결정, 비즈니스 전략, 학습 방법 등에 대해
    저명한 전문가들의 사고방식을 기반으로 조언을 받습니다.
    
    Args:
        guru_name: Guru 이름
            - "bezos": Jeff Bezos - 고객 중심 사고, 장기적 비전, Day 1 문화
            - "vogels": Werner Vogels - 분산 시스템, 확장성, 운영 우수성
            - "naval": Naval Ravikant - 레버리지, 비대칭적 결과, 시스템적 사고
            - "feynman": Richard Feynman - 복잡한 개념 단순화, 학습 최적화
        question: 자문을 구할 질문
    
    Returns:
        str: Guru의 조언
    
    Example:
        consult_guru("bezos", "이 아키텍처가 고객에게 어떤 가치를 제공하나요?")
        consult_guru("vogels", "이 시스템의 확장성을 어떻게 개선할 수 있을까요?")
    """
    guru_name_lower = guru_name.lower()
    
    if guru_name_lower not in GURU_PROMPTS:
        available = ", ".join(get_available_gurus())
        return f"알 수 없는 Guru입니다: {guru_name}. 사용 가능한 Guru: {available}"
    
    try:
        # ThreadPoolExecutor로 별도 스레드에서 Guru Agent 실행
        # OpenTelemetry 컨텍스트가 스레드별로 격리되어 충돌 방지
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(_run_guru_in_thread, guru_name_lower, question)
            response_text = future.result()
        
        return f"[{guru_name.upper()} GURU 조언]\n\n{response_text}"
    except Exception as e:
        return f"Guru 자문 중 오류 발생: {str(e)}"


@tool
def list_gurus() -> str:
    """
    사용 가능한 Guru 목록과 전문 분야를 반환합니다.
    
    Returns:
        str: Guru 목록 및 설명
    """
    guru_descriptions = {
        "bezos": "Jeff Bezos - 고객 중심 사고, 장기적 비전, Day 1 문화, 역방향 사고",
        "vogels": "Werner Vogels - 분산 시스템, 확장성, 운영 우수성, 장애 대응",
        "naval": "Naval Ravikant - 레버리지, 비대칭적 결과, 시스템적 사고, 복리 효과",
        "feynman": "Richard Feynman - 복잡한 개념 단순화, 학습 최적화, First Principles"
    }
    
    result = "## 사용 가능한 Guru 전문가\n\n"
    for name, desc in guru_descriptions.items():
        result += f"- **{name}**: {desc}\n"
    
    result += "\n`consult_guru(guru_name, question)` 도구로 자문을 구할 수 있습니다."
    return result


# =============================================================================
# Orchestrator 생성
# =============================================================================

def create_orchestrator(
    tools: List[Any] = None,
    system_prompt: str = None,
    enable_thinking: bool = True
) -> Agent:
    """
    SA Orchestrator 에이전트를 생성합니다.
    
    Args:
        tools: 추가할 도구 목록 (MCP 도구 등)
        system_prompt: 커스텀 시스템 프롬프트 (None이면 기본 프롬프트 사용)
        enable_thinking: Extended Thinking 활성화 여부
    
    Returns:
        Agent: SA Orchestrator 에이전트
    """
    # 시스템 프롬프트 구성
    if system_prompt is None:
        system_prompt = get_orchestrator_prompt()
    
    # 기본 도구 목록
    default_tools = [
        consult_guru,
        list_gurus,
    ]
    
    # 추가 도구 병합
    all_tools = default_tools + (tools or [])
    
    # Conversation Manager 설정
    conversation_manager = SlidingWindowConversationManager(
        window_size=20  # 최근 20개 메시지 유지
    )
    
    # Orchestrator 에이전트 생성
    orchestrator = Agent(
        model=load_opus(enable_thinking=enable_thinking),
        system_prompt=system_prompt,
        tools=all_tools,
        conversation_manager=conversation_manager
    )
    
    return orchestrator


# =============================================================================
# CLI 실행 지원
# =============================================================================

# ANSI 색상 코드
class Colors:
    """터미널 색상 코드"""
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    WHITE = '\033[97m'
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    ORANGE = '\033[38;5;208m'  # AWS Orange


def print_banner():
    """SA Assistant 배너를 출력합니다."""
    banner = f"""
{Colors.ORANGE}╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   {Colors.WHITE}AWS SA Assistant{Colors.ORANGE}                                          ║
║   {Colors.DIM}Solutions Architect Professional Agent{Colors.ORANGE}                    ║
║                                                              ║
║   {Colors.CYAN}Powered by Claude Opus 4.5 with Extended Thinking{Colors.ORANGE}         ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝{Colors.RESET}
"""
    print(banner)


def tool_callback_handler(**kwargs):
    """도구 호출 콜백 핸들러"""
    if "current_tool_use" in kwargs:
        tool_use = kwargs["current_tool_use"]
        if isinstance(tool_use, dict):
            tool_name = tool_use.get("name", "")
            if tool_name:
                if tool_name == "consult_guru":
                    guru = tool_use.get("input", {}).get("guru_name", "")
                    print(f"\n{Colors.MAGENTA}🧙 Consulting {guru.upper()} Guru...{Colors.RESET}", flush=True)
                elif tool_name == "list_gurus":
                    print(f"\n{Colors.BLUE}📋 Listing available Gurus...{Colors.RESET}", flush=True)
                else:
                    print(f"\n{Colors.CYAN}🔧 [{tool_name}]{Colors.RESET}", flush=True)
    
    if "data" in kwargs:
        print(kwargs["data"], end="", flush=True)


def run_cli(tools: List[Any] = None):
    """CLI 모드로 실행합니다."""
    print_banner()
    
    print(f"{Colors.WHITE}안녕하세요! AWS Solutions Architect Assistant입니다.{Colors.RESET}")
    print(f"{Colors.DIM}아키텍처 설계, 비용 분석, 보안 검토 등을 도와드립니다.{Colors.RESET}")
    print(f"\n{Colors.YELLOW}💡 Guru 전문가 자문: 'list_gurus'로 사용 가능한 전문가를 확인하세요.{Colors.RESET}")
    print(f"{Colors.DIM}종료하려면 'exit' 또는 'quit'을 입력하세요.{Colors.RESET}\n")
    
    # Orchestrator 생성 (Progressive Disclosure: 스킬은 main.py에서 처리)
    orchestrator = create_orchestrator(
        tools=tools,
        enable_thinking=True
    )
    
    # 콜백 핸들러 설정
    orchestrator.callback_handler = tool_callback_handler
    
    while True:
        try:
            user_input = input(f"\n{Colors.GREEN}You: {Colors.RESET}").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ["exit", "quit", "종료"]:
                print(f"\n{Colors.ORANGE}감사합니다. 좋은 하루 되세요! 👋{Colors.RESET}")
                break
            
            print(f"\n{Colors.ORANGE}{Colors.BOLD}SA Assistant:{Colors.RESET} ", end="", flush=True)
            
            try:
                response = orchestrator(user_input)
                print()  # 줄바꿈
            except Exception as e:
                print(f"\n{Colors.RED}오류 발생: {e}{Colors.RESET}")
                continue
                
        except KeyboardInterrupt:
            print(f"\n\n{Colors.YELLOW}중단되었습니다.{Colors.RESET}")
            break
        except Exception as e:
            print(f"\n{Colors.RED}오류: {e}{Colors.RESET}")


if __name__ == "__main__":
    run_cli()
