"""Specialist Sub-agents - 전문 영역별 서브 에이전트

Explorer, Researcher, Reviewer 등 전문 분야별 서브에이전트를 제공합니다.
ThreadPoolExecutor를 사용하여 OpenTelemetry 컨텍스트 격리를 보장합니다.
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Any, Optional
from strands import Agent, tool

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from model.load import load_sonnet, load_haiku
from prompts.system_prompts import SPECIALIST_PROMPTS, get_specialist_prompt


def get_available_specialists() -> List[str]:
    return list(SPECIALIST_PROMPTS.keys())


def _isolate_otel_context():
    """OpenTelemetry 컨텍스트를 격리합니다."""
    try:
        from opentelemetry import context as otel_context

        return otel_context.attach(otel_context.Context())
    except ImportError:
        return None


def _restore_otel_context(token):
    """OpenTelemetry 컨텍스트를 복원합니다."""
    if token is not None:
        try:
            from opentelemetry import context as otel_context

            otel_context.detach(token)
        except Exception:
            pass


def _run_specialist_in_thread(
    specialist_name: str, task: str, context: str = ""
) -> str:
    """
    별도 스레드에서 Specialist Agent 실행
    """
    token = _isolate_otel_context()

    try:
        prompt = get_specialist_prompt(specialist_name)
        if not prompt:
            return f"알 수 없는 Specialist: {specialist_name}"

        # Specialist는 Haiku 사용 (빠른 응답)
        specialist_agent = Agent(
            model=load_haiku(enable_thinking=False),
            system_prompt=prompt,
        )

        full_task = task
        if context:
            full_task = f"## Context\n{context}\n\n## Task\n{task}"

        result = specialist_agent(full_task)
        return str(result)
    finally:
        _restore_otel_context(token)


@tool
def consult_specialist(specialist_name: str, task: str, context: str = "") -> str:
    """
    전문 Specialist 에이전트에게 작업을 위임합니다.

    Specialist는 특정 도메인에 특화된 분석/조사 작업을 수행합니다.

    Args:
        specialist_name: Specialist 이름
            - "explorer": 기존 아키텍처 분석, 다이어그램 해석
            - "researcher": AWS 서비스/가격/Best Practice 조사
            - "reviewer": Well-Architected Framework 기반 검토
        task: 수행할 작업 설명
        context: 추가 컨텍스트 (선택)

    Returns:
        str: Specialist의 분석 결과

    Example:
        consult_specialist("explorer", "이 아키텍처 다이어그램을 분석해주세요")
        consult_specialist("researcher", "DynamoDB vs Aurora 비교")
        consult_specialist("reviewer", "이 설계의 보안 취약점을 검토해주세요")
    """
    specialist_name_lower = specialist_name.lower()

    if specialist_name_lower not in SPECIALIST_PROMPTS:
        available = ", ".join(get_available_specialists())
        return f"알 수 없는 Specialist: {specialist_name}. 사용 가능: {available}"

    try:
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(
                _run_specialist_in_thread, specialist_name_lower, task, context
            )
            response_text = future.result(timeout=120)

        return f"[{specialist_name.upper()} SPECIALIST 결과]\n\n{response_text}"
    except Exception as e:
        return f"Specialist 실행 중 오류 발생: {str(e)}"


@tool
def list_specialists() -> str:
    """
    사용 가능한 Specialist 목록과 전문 분야를 반환합니다.

    Returns:
        str: Specialist 목록 및 설명
    """
    specialist_descriptions = {
        "explorer": "🔍 Architecture Explorer - 기존 아키텍처 분석, 다이어그램 해석, 코드 탐색",
        "researcher": "📚 AWS Researcher - 서비스 정보, 가격, Best Practice 조사",
        "reviewer": "✅ Architecture Reviewer - Well-Architected 검토, 보안 분석, 개선 권장",
    }

    result = "## 사용 가능한 Specialist 에이전트\n\n"
    for name, desc in specialist_descriptions.items():
        result += f"- **{name}**: {desc}\n"

    result += "\n`consult_specialist(specialist_name, task)` 도구로 작업을 위임할 수 있습니다."
    return result


def run_specialists_parallel(
    tasks: List[Dict[str, str]], max_workers: int = 3
) -> List[Dict[str, Any]]:
    """
    여러 Specialist를 병렬로 실행합니다.

    Args:
        tasks: 작업 목록 [{"specialist": "name", "task": "...", "context": "..."}]
        max_workers: 최대 동시 실행 수

    Returns:
        결과 목록 [{"specialist": "name", "result": "...", "success": bool}]
    """
    results = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_task = {}
        for task_info in tasks:
            future = executor.submit(
                _run_specialist_in_thread,
                task_info["specialist"],
                task_info["task"],
                task_info.get("context", ""),
            )
            future_to_task[future] = task_info

        for future in as_completed(future_to_task):
            task_info = future_to_task[future]
            try:
                result = future.result(timeout=120)
                results.append(
                    {
                        "specialist": task_info["specialist"],
                        "result": result,
                        "success": True,
                    }
                )
            except Exception as e:
                results.append(
                    {
                        "specialist": task_info["specialist"],
                        "result": str(e),
                        "success": False,
                    }
                )

    return results


@tool
def parallel_research(tasks_json: str) -> str:
    """
    여러 Specialist에게 병렬로 작업을 위임합니다.

    복잡한 분석을 위해 여러 전문가를 동시에 활용할 때 사용합니다.

    Args:
        tasks_json: JSON 형식의 작업 목록
            예: '[{"specialist": "researcher", "task": "DynamoDB 가격 조사"},
                  {"specialist": "reviewer", "task": "보안 검토"}]'

    Returns:
        str: 모든 Specialist의 결과를 종합한 보고서

    Example:
        parallel_research('[
            {"specialist": "explorer", "task": "현재 아키텍처 분석"},
            {"specialist": "researcher", "task": "대안 서비스 조사"},
            {"specialist": "reviewer", "task": "개선안 검토"}
        ]')
    """
    import json

    try:
        tasks = json.loads(tasks_json)
    except json.JSONDecodeError as e:
        return f"JSON 파싱 오류: {e}"

    if not isinstance(tasks, list):
        return "tasks_json은 배열 형식이어야 합니다."

    results = run_specialists_parallel(tasks)

    # 결과 종합
    output = "## 병렬 분석 결과\n\n"

    for r in results:
        specialist = r["specialist"].upper()
        if r["success"]:
            output += f"### {specialist} 결과\n{r['result']}\n\n"
        else:
            output += f"### {specialist} (실패)\n오류: {r['result']}\n\n"

    return output
