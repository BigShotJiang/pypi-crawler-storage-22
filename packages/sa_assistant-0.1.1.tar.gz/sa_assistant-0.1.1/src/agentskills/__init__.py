"""Agent Skills - SA Agent용 스킬 시스템

Progressive Disclosure 패턴을 따르는 스킬 로딩 시스템:
- Phase 1: 메타데이터만 로드 (discovery)
- Phase 2: 필요 시 전체 instructions 로드 (skill tool)
- Phase 3: 리소스 파일 로드 (file_read)
"""

from .models import SkillProperties
from .parser import find_skill_md, load_metadata, load_instructions, load_resource
from .discovery import discover_skills
from .prompt import generate_skills_prompt
from .tool import create_skill_tool
from .errors import (
    SkillError,
    ParseError,
    ValidationError,
    SkillNotFoundError,
    SkillActivationError,
)

__version__ = "1.0.0"

__all__ = [
    "SkillProperties",
    "find_skill_md",
    "load_metadata",
    "load_instructions",
    "load_resource",
    "discover_skills",
    "generate_skills_prompt",
    "create_skill_tool",
    "SkillError",
    "ParseError",
    "ValidationError",
    "SkillNotFoundError",
    "SkillActivationError",
]
