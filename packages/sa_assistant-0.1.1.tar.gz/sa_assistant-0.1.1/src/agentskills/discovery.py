"""스킬 디스커버리 - Progressive Disclosure Phase 1

스킬 디렉토리를 스캔하여 경량 메타데이터만 로드합니다.
"""

import logging
from pathlib import Path
from typing import List

from .parser import find_skill_md, load_metadata
from .errors import ParseError, ValidationError
from .models import SkillProperties

logger = logging.getLogger(__name__)


def is_safe_path(path: Path, base_dir: Path) -> bool:
    """경로가 base_dir 내부에 안전하게 포함되어 있는지 확인
    
    심볼릭 링크나 경로 조작을 통한 디렉토리 탐색 공격 방지
    """
    try:
        resolved_path = path.resolve()
        resolved_base = base_dir.resolve()
        resolved_path.relative_to(resolved_base)
        return True
    except (ValueError, OSError, RuntimeError):
        return False


def discover_skills(skills_dir: str | Path) -> List[SkillProperties]:
    """디렉토리에서 모든 스킬 발견
    
    스킬 디렉토리를 스캔하고 각 스킬의 SKILL.md frontmatter에서
    메타데이터를 로드합니다. (Progressive Disclosure Phase 1)
    
    디렉토리 구조:
        skills/
        ├── pptx/
        │   ├── SKILL.md          # 필수
        │   └── references/       # 선택
        │       └── html2pptx.md
        ├── docx/
        │   └── SKILL.md
        └── mcp/
            └── SKILL.md
    
    Args:
        skills_dir: 스킬 하위 디렉토리들이 있는 경로
        
    Returns:
        SkillProperties 리스트 (이름순 정렬)
    """
    skills_dir = Path(skills_dir).expanduser().resolve()

    if not skills_dir.exists():
        logger.info(f"스킬 디렉토리가 존재하지 않습니다: {skills_dir}")
        return []

    if not skills_dir.is_dir():
        logger.warning(f"스킬 경로가 디렉토리가 아닙니다: {skills_dir}")
        return []

    skills: List[SkillProperties] = []

    # 각 하위 디렉토리 스캔
    for skill_dir in skills_dir.iterdir():
        if not skill_dir.is_dir():
            continue

        # 보안: 경로 검증
        if not is_safe_path(skill_dir, skills_dir):
            logger.warning(f"안전하지 않은 경로 건너뜀: {skill_dir}")
            continue

        # SKILL.md 찾기
        skill_md_path = find_skill_md(skill_dir)
        if skill_md_path is None:
            logger.debug(f"SKILL.md를 찾을 수 없음: {skill_dir}")
            continue

        # 보안: SKILL.md 경로 검증
        if not is_safe_path(skill_md_path, skills_dir):
            logger.warning(f"안전하지 않은 SKILL.md 건너뜀: {skill_md_path}")
            continue

        # 메타데이터 파싱
        try:
            skill_props = load_metadata(skill_dir)
            skills.append(skill_props)
            logger.debug(f"스킬 발견: {skill_props.name}")

        except (ParseError, ValidationError) as e:
            logger.warning(f"유효하지 않은 스킬 건너뜀 ({skill_dir}): {e}")
            continue
        except Exception as e:
            logger.error(f"예상치 못한 오류 ({skill_dir}): {e}")
            continue

    # 이름순 정렬
    skills.sort(key=lambda s: s.name)

    logger.info(f"{skills_dir}에서 {len(skills)}개 스킬 발견")
    return skills


__all__ = ["discover_skills"]
