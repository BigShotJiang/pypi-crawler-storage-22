"""스킬 관련 예외 정의"""


class SkillError(Exception):
    """스킬 관련 기본 예외"""
    pass


class ParseError(SkillError):
    """SKILL.md 파싱 실패 시 발생"""
    pass


class ValidationError(SkillError):
    """스킬 속성 검증 실패 시 발생"""

    def __init__(self, message: str, errors: list[str] | None = None):
        super().__init__(message)
        self.errors = errors if errors is not None else [message]


class SkillNotFoundError(SkillError):
    """요청한 스킬을 찾을 수 없을 때 발생"""
    pass


class SkillActivationError(SkillError):
    """스킬 활성화 실패 시 발생"""
    pass


__all__ = [
    "SkillError",
    "ParseError",
    "ValidationError",
    "SkillNotFoundError",
    "SkillActivationError",
]
