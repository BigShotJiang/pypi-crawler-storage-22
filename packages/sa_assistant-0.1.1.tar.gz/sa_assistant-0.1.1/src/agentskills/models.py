"""스킬 데이터 모델"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SkillProperties:
    """SKILL.md frontmatter에서 파싱된 스킬 메타데이터
    
    Progressive Disclosure Phase 1: 경량 메타데이터만 포함 (~100 tokens)
    
    Attributes:
        name: 스킬 이름 (kebab-case)
        description: 스킬 설명 및 사용 시점
        path: SKILL.md 파일의 절대 경로
        skill_dir: 스킬 디렉토리의 절대 경로
        license: 라이선스 정보 (선택)
        allowed_tools: 스킬이 사용하는 도구 패턴 (선택)
        metadata: 커스텀 메타데이터 (선택)
    """

    name: str
    description: str
    path: str
    skill_dir: str
    license: Optional[str] = None
    allowed_tools: Optional[str] = None
    metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """딕셔너리로 변환 (None 값 제외)"""
        result = {
            "name": self.name,
            "description": self.description,
            "path": self.path,
            "skill_dir": self.skill_dir,
        }
        if self.license is not None:
            result["license"] = self.license
        if self.allowed_tools is not None:
            result["allowed_tools"] = self.allowed_tools
        if self.metadata:
            result["metadata"] = self.metadata
        return result


__all__ = ["SkillProperties"]
