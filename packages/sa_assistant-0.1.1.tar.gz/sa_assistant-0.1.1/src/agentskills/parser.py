"""SKILL.md 파일 파싱

YAML frontmatter와 Markdown body를 분리하여 파싱합니다.
"""

import re
from pathlib import Path
from typing import Optional

import yaml

from .errors import ParseError, ValidationError
from .models import SkillProperties


def find_skill_md(skill_dir: Path) -> Optional[Path]:
    """스킬 디렉토리에서 SKILL.md 파일 찾기
    
    SKILL.md (대문자) 우선, skill.md (소문자)도 허용
    """
    for name in ("SKILL.md", "skill.md"):
        path = skill_dir / name
        if path.exists():
            return path
    return None


def _parse_skill_md(content: str) -> tuple[dict, str]:
    """SKILL.md 내용을 frontmatter와 body로 분리
    
    Args:
        content: SKILL.md 파일 내용
        
    Returns:
        (frontmatter dict, body string) 튜플
        
    Raises:
        ParseError: frontmatter가 유효하지 않을 때
    """
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n?(.*)$', content, re.DOTALL)
    if not match:
        raise ParseError("SKILL.md는 YAML frontmatter (---)로 시작해야 합니다")

    frontmatter_str = match.group(1)
    body = match.group(2).strip()

    try:
        frontmatter = yaml.safe_load(frontmatter_str)
    except yaml.YAMLError as e:
        raise ParseError(f"frontmatter YAML 파싱 오류: {e}")

    if not isinstance(frontmatter, dict):
        raise ParseError("SKILL.md frontmatter는 YAML 매핑이어야 합니다")

    # metadata 필드가 있으면 문자열로 변환
    if "metadata" in frontmatter and isinstance(frontmatter["metadata"], dict):
        frontmatter["metadata"] = {
            str(k): str(v) for k, v in frontmatter["metadata"].items()
        }

    return frontmatter, body


def load_metadata(skill_dir: str | Path) -> SkillProperties:
    """SKILL.md frontmatter에서 메타데이터 로드 (Phase 1)
    
    경량 메타데이터만 로드하여 컨텍스트 절약
    
    Args:
        skill_dir: 스킬 디렉토리 경로
        
    Returns:
        SkillProperties (instructions 미포함)
        
    Raises:
        ParseError: SKILL.md가 없거나 YAML이 유효하지 않을 때
        ValidationError: 필수 필드가 없을 때
    """
    skill_dir = Path(skill_dir).resolve()
    skill_md = find_skill_md(skill_dir)

    if skill_md is None:
        raise ParseError(f"SKILL.md를 찾을 수 없습니다: {skill_dir}")

    content = skill_md.read_text(encoding="utf-8")
    frontmatter, _ = _parse_skill_md(content)

    # 필수 필드 검증
    if "name" not in frontmatter:
        raise ValidationError("frontmatter에 'name' 필드가 필요합니다")
    if "description" not in frontmatter:
        raise ValidationError("frontmatter에 'description' 필드가 필요합니다")

    name = frontmatter["name"]
    description = frontmatter["description"]

    if not isinstance(name, str) or not name.strip():
        raise ValidationError("'name'은 비어있지 않은 문자열이어야 합니다")
    if not isinstance(description, str) or not description.strip():
        raise ValidationError("'description'은 비어있지 않은 문자열이어야 합니다")

    return SkillProperties(
        name=name.strip(),
        description=description.strip(),
        path=str(skill_md.absolute()),
        skill_dir=str(skill_dir.absolute()),
        license=frontmatter.get("license"),
        allowed_tools=frontmatter.get("allowed-tools"),
        metadata=frontmatter.get("metadata", {}),
    )


def load_instructions(skill_path: str | Path) -> str:
    """SKILL.md body에서 instructions 로드 (Phase 2)
    
    스킬이 활성화될 때 전체 Markdown body를 로드
    
    Args:
        skill_path: SKILL.md 파일 경로
        
    Returns:
        Markdown body (instructions)
        
    Raises:
        ParseError: 파일을 읽거나 파싱할 수 없을 때
    """
    skill_path = Path(skill_path)

    try:
        content = skill_path.read_text(encoding="utf-8")
        _, instructions = _parse_skill_md(content)
        return instructions
    except Exception as e:
        raise ParseError(f"instructions 로드 실패 ({skill_path}): {e}")


def load_resource(skill_dir: str | Path, resource_path: str) -> str:
    """스킬 디렉토리에서 리소스 파일 로드 (Phase 3)
    
    scripts/, references/, assets/ 등의 파일을 필요 시 로드
    
    Args:
        skill_dir: 스킬 디렉토리 경로
        resource_path: 상대 경로 (예: "references/html2pptx.md")
        
    Returns:
        리소스 파일 내용
        
    Raises:
        ParseError: 리소스를 읽을 수 없거나 디렉토리 외부일 때
    """
    skill_dir = Path(skill_dir).resolve()
    resource_file = (skill_dir / resource_path).resolve()

    # 보안: 스킬 디렉토리 내부인지 확인
    try:
        resource_file.relative_to(skill_dir)
    except ValueError:
        raise ParseError(f"리소스 경로가 스킬 디렉토리 외부입니다: {resource_path}")

    if not resource_file.exists():
        raise ParseError(f"리소스를 찾을 수 없습니다: {resource_path}")

    if not resource_file.is_file():
        raise ParseError(f"리소스가 파일이 아닙니다: {resource_path}")

    # 파일 크기 제한 (10MB)
    MAX_FILE_SIZE = 10 * 1024 * 1024
    if resource_file.stat().st_size > MAX_FILE_SIZE:
        raise ParseError(f"리소스가 너무 큽니다 (최대 10MB): {resource_path}")

    try:
        return resource_file.read_text(encoding="utf-8")
    except Exception as e:
        raise ParseError(f"리소스 읽기 실패 ({resource_path}): {e}")


__all__ = [
    "find_skill_md",
    "load_metadata",
    "load_instructions",
    "load_resource",
]
