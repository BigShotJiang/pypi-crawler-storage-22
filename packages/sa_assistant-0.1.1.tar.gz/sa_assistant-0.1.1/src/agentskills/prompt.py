"""스킬 프롬프트 생성

시스템 프롬프트에 포함할 스킬 메타데이터 XML 생성
"""

from typing import List
from .models import SkillProperties


SKILLS_SYSTEM_PROMPT = """
## Skills System

You have access to a skills library that provides specialized capabilities.

<skills_instructions>
**스킬 사용 방법:**

스킬은 **Progressive Disclosure** 패턴을 따릅니다:
- 시스템 프롬프트에는 스킬 메타데이터(이름, 설명)만 포함됩니다
- 전체 instructions는 스킬이 필요할 때 로드됩니다

1. **스킬 적용 여부 확인**: 사용자 요청이 아래 스킬 설명과 일치하는지 확인
2. **스킬 instructions 로드**: `skill(skill_name="스킬이름")` 도구 호출
3. **instructions 따르기**: 로드된 워크플로우, 예제, 베스트 프랙티스 준수
4. **리소스 파일 접근**: 필요 시 `file_read`로 추가 파일 로드

**스킬 사용 시점:**
- 사용자 요청이 스킬 도메인과 일치할 때 (예: "PPT 만들어줘" → pptx 스킬)
- 전문 지식이나 구조화된 워크플로우가 필요할 때
- 복잡한 작업에 검증된 패턴이 있을 때
</skills_instructions>

<available_skills>
{skills_list}
</available_skills>
"""


def generate_skills_prompt(skills: List[SkillProperties]) -> str:
    """스킬 메타데이터로 시스템 프롬프트 섹션 생성
    
    Progressive Disclosure Phase 1: 메타데이터만 포함하여 컨텍스트 절약
    
    Args:
        skills: 발견된 스킬 속성 리스트
        
    Returns:
        XML 형식의 프롬프트 텍스트
    """
    if not skills:
        return ""

    # XML 스킬 리스트 생성 (메타데이터만)
    skill_elements = []
    for skill in sorted(skills, key=lambda s: s.name):
        skill_xml = (
            "  <skill>\n"
            f"    <name>{skill.name}</name>\n"
            f"    <description>{skill.description}</description>\n"
            f"    <location>{skill.path}</location>\n"
            "  </skill>"
        )
        skill_elements.append(skill_xml)

    skills_list = "\n".join(skill_elements)

    return SKILLS_SYSTEM_PROMPT.format(skills_list=skills_list)


__all__ = ["generate_skills_prompt"]
