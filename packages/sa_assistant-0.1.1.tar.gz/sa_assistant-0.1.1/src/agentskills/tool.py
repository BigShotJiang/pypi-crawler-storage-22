"""스킬 도구 - Progressive Disclosure Phase 2

스킬이 필요할 때 전체 instructions를 로드하는 Strands 도구
"""

import logging
from pathlib import Path
from typing import List, Dict

from strands import tool

from .models import SkillProperties
from .errors import SkillNotFoundError, SkillActivationError
from .parser import load_instructions

logger = logging.getLogger(__name__)


def _scan_skill_resources(skill_dir: Path) -> List[str]:
    """스킬 디렉토리에서 사용 가능한 리소스 스캔
    
    references/, scripts/, assets/ 하위 디렉토리의 파일 목록 반환
    """
    resources = []
    for subdir in ["references", "scripts", "assets"]:
        resource_dir = skill_dir / subdir
        if resource_dir.exists() and resource_dir.is_dir():
            for file_path in sorted(resource_dir.rglob("*")):
                if file_path.is_file():
                    resources.append(str(file_path.absolute()))
    return resources


def _build_skill_header(skill: SkillProperties) -> str:
    """스킬 헤더 문자열 생성 (메타데이터 + 리소스 목록)"""
    header = (
        f"# Skill: {skill.name}\n\n"
        f"**Description:** {skill.description}\n\n"
        f"**Skill Directory:** `{skill.skill_dir}/`\n\n"
    )

    # allowed-tools가 있으면 표시
    if skill.allowed_tools:
        header += f"\n**IMPORTANT:** Only use these tools: `{skill.allowed_tools}`\n"

    # 리소스 파일 목록
    skill_dir = Path(skill.skill_dir)
    resources = _scan_skill_resources(skill_dir)

    if resources:
        header += "\n**Available Resources (use file_read to access):**\n"
        for resource in resources:
            header += f"- `{resource}`\n"
        header += "\n"

    header += "---\n\n"

    return header


def create_skill_tool(skills: List[SkillProperties], skills_dir: str | Path):
    """스킬 활성화 도구 생성 (Inline Mode)
    
    Progressive Disclosure를 구현하는 팩토리 함수:
    - Phase 1: 시스템 프롬프트에 메타데이터 (이미 로드됨)
    - Phase 2: 스킬 호출 시 전체 instructions 로드
    - Phase 3: LLM이 file_read로 리소스 접근
    
    Args:
        skills: 발견된 스킬 속성 리스트
        skills_dir: 스킬 기본 디렉토리
        
    Returns:
        @tool 데코레이터가 적용된 Strands 도구 함수
        
    Example:
        >>> from agentskills import discover_skills, create_skill_tool
        >>> from strands import Agent
        >>> from strands_tools import file_read
        >>>
        >>> skills = discover_skills("./skills")
        >>> skill_tool = create_skill_tool(skills, "./skills")
        >>>
        >>> agent = Agent(tools=[skill_tool, file_read])
    """
    skills_dir = Path(skills_dir).expanduser().resolve()

    # 빠른 조회를 위한 맵 생성
    skill_map: Dict[str, SkillProperties] = {skill.name: skill for skill in skills}

    @tool
    def skill(skill_name: str) -> str:
        """전문 스킬 instructions를 로드합니다.
        
        사용자 요청이 특정 스킬 도메인과 일치할 때 호출하세요.
        로드된 instructions에는 워크플로우, 예제, 베스트 프랙티스가 포함됩니다.
        
        Args:
            skill_name: 스킬 이름 (시스템 프롬프트의 available_skills 참조)
                - "pptx": PowerPoint 프레젠테이션 생성
                - "docx": Word 문서 생성
                - "mcp": MCP 도구 사용 가이드
                
        Returns:
            스킬 헤더 + 전체 instructions + 리소스 정보
            
        Example:
            skill(skill_name="pptx")  # PPTX 생성 스킬 로드
        """
        # 스킬 존재 여부 확인
        if skill_name not in skill_map:
            available = ", ".join(skill_map.keys())
            raise SkillNotFoundError(
                f"스킬 '{skill_name}'을 찾을 수 없습니다. "
                f"사용 가능한 스킬: {available}"
            )

        skill_props = skill_map[skill_name]

        try:
            # Phase 2: instructions 로드
            instructions = load_instructions(skill_props.path)
            logger.info(f"스킬 로드됨: {skill_name}")

            # 헤더 + instructions 조합
            header = _build_skill_header(skill_props)
            return header + instructions

        except Exception as e:
            logger.error(f"스킬 '{skill_name}' 로드 오류: {e}", exc_info=True)
            raise SkillActivationError(
                f"스킬 '{skill_name}' 로드 실패: {e}"
            ) from e

    return skill


__all__ = ["create_skill_tool"]
