"""SA Assistant CLI Module - Rich-based modern CLI interface."""

from .console import (
    SAConsole,
    get_console,
    print_error,
    print_warning,
    print_info,
    print_success,
)
from .components import (
    AgentPanel,
    ToolStatus,
    ResponseRenderer,
    print_banner,
    print_help,
)
from .callback import (
    RichCallbackHandler,
    MinimalCallbackHandler,
    VerboseCallbackHandler,
)
from .mdstream import (
    MarkdownStream,
    SimpleMarkdownStream,
    SAMarkdown,
    render_markdown,
    render_code,
)

__all__ = [
    "SAConsole",
    "get_console",
    "print_error",
    "print_warning",
    "print_info",
    "print_success",
    "AgentPanel",
    "ToolStatus",
    "ResponseRenderer",
    "RichCallbackHandler",
    "MinimalCallbackHandler",
    "VerboseCallbackHandler",
    "print_banner",
    "print_help",
    "MarkdownStream",
    "SimpleMarkdownStream",
    "SAMarkdown",
    "render_markdown",
    "render_code",
]
