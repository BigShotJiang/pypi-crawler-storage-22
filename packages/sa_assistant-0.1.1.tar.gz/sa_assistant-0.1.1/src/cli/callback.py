"""SA Assistant Rich Callback Handler - Strands Agent callback to Rich UI."""

from typing import Any, Set, Optional
from .console import get_console
from .components import ToolStatus
from .mdstream import MarkdownStream


class RichCallbackHandler:
    """Rich-based Strands Agent callback handler with markdown streaming.

    Usage:
        handler = RichCallbackHandler()
        agent = Agent(callback_handler=handler)
    """

    def __init__(
        self,
        show_tool_calls: bool = True,
        show_thinking: bool = False,
        use_markdown_stream: bool = True,
    ):
        self.console = get_console()
        self.show_tool_calls = show_tool_calls
        self.show_thinking = show_thinking
        self.use_markdown_stream = use_markdown_stream

        self._tool_status = ToolStatus()
        self._printed_tool_ids: Set[str] = set()
        self._in_response = False
        self._text_buffer = ""
        self._md_stream: Optional[MarkdownStream] = None

    def reset(self) -> None:
        """Reset state for new conversation."""
        self._printed_tool_ids.clear()
        self._in_response = False
        self._text_buffer = ""
        if self._md_stream:
            self._md_stream.finish()
            self._md_stream = None

    def __call__(self, **kwargs) -> None:
        """Strands Agent callback entry point."""
        if "data" in kwargs:
            self._handle_data(kwargs["data"])

        if "current_tool_use" in kwargs and self.show_tool_calls:
            self._handle_tool_use(kwargs["current_tool_use"])

        if "thinking" in kwargs and self.show_thinking:
            self._handle_thinking(kwargs["thinking"])

        if "tool_result" in kwargs:
            self._handle_tool_result(kwargs["tool_result"])

        if "stop" in kwargs:
            self._handle_stop()

    def _handle_data(self, data: str) -> None:
        """Handle streaming text."""
        if not self._in_response:
            self._in_response = True
            if self.use_markdown_stream:
                self._md_stream = MarkdownStream(console=self.console)

        self._text_buffer += data

        if self.use_markdown_stream and self._md_stream:
            self._md_stream.update(self._text_buffer)
        else:
            print(data, end="", flush=True)

    def _handle_tool_use(self, tool_use: Any) -> None:
        """Handle tool invocation."""
        if not isinstance(tool_use, dict):
            return

        tool_id = tool_use.get("toolUseId", "")
        tool_name = tool_use.get("name", "")

        if tool_id and tool_id in self._printed_tool_ids:
            return

        if not tool_name:
            return

        if tool_id:
            self._printed_tool_ids.add(tool_id)

        self._finalize_response()

        args = tool_use.get("input", {})
        self._tool_status.tool_start(tool_id, tool_name, args)

    def _handle_thinking(self, thinking: str) -> None:
        """Handle thinking text."""
        display = f"{thinking[:100]}..." if len(thinking) > 100 else thinking
        self.console.print(f"[text.thinking]💭 {display}[/]")

    def _handle_tool_result(self, result: Any) -> None:
        """Handle tool result."""
        if isinstance(result, dict) and result.get("status") == "error":
            error_msg = result.get("error", "Unknown error")
            self.console.print(f"[tool.error]  ↳ Error: {error_msg}[/]")

    def _handle_stop(self) -> None:
        """Handle stop event - finalize markdown rendering."""
        self._finalize_response()

    def _finalize_response(self) -> None:
        """Finalize current response."""
        if self._in_response:
            if self.use_markdown_stream and self._md_stream:
                self._md_stream.update(self._text_buffer, final=True)
                self._md_stream = None
            else:
                print()
            self._in_response = False
            self._text_buffer = ""


class MinimalCallbackHandler:
    """Minimal callback handler - text streaming only."""

    def __call__(self, **kwargs) -> None:
        if "data" in kwargs:
            print(kwargs["data"], end="", flush=True)


class VerboseCallbackHandler(RichCallbackHandler):
    """Verbose callback handler - shows all events."""

    def __init__(self):
        super().__init__(show_tool_calls=True, show_thinking=True)

    def __call__(self, **kwargs) -> None:
        super().__call__(**kwargs)

        if "message" in kwargs:
            self.console.print("[text.dim]📨 Message event[/]")

        if "stop" in kwargs:
            reason = kwargs.get("stop_reason", "unknown")
            self.console.print(f"[text.dim]🛑 Stop reason: {reason}[/]")
