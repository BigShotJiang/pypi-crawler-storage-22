"""SA Assistant CLI Components - UI 컴포넌트

Rich 기반 UI 컴포넌트들을 제공합니다.
"""

from typing import Optional, Dict, Any
from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.live import Live
from rich.spinner import Spinner
from rich.progress import Progress, SpinnerColumn, TextColumn

from .console import get_console, SA_THEME


# =============================================================================
# 배너 및 헬프
# =============================================================================

BANNER = """
[aws.orange]╔══════════════════════════════════════════════════════════════════════╗[/]
[aws.orange]║[/]                                                                      [aws.orange]║[/]
[aws.orange]║[/]   [bold white]AWS SA Assistant[/]                                                  [aws.orange]║[/]
[aws.orange]║[/]   [dim]Solutions Architect Professional Agent[/]                            [aws.orange]║[/]
[aws.orange]║[/]                                                                      [aws.orange]║[/]
[aws.orange]║[/]   [cyan]Powered by Claude with Extended Thinking[/]                          [aws.orange]║[/]
[aws.orange]║[/]   [cyan]+ Guru Sub-agents (Bezos, Vogels, Naval, Feynman)[/]                  [aws.orange]║[/]
[aws.orange]║[/]   [cyan]+ Specialist Agents (Explorer, Researcher, Reviewer)[/]               [aws.orange]║[/]
[aws.orange]║[/]                                                                      [aws.orange]║[/]
[aws.orange]╚══════════════════════════════════════════════════════════════════════╝[/]
"""


def print_banner() -> None:
    """SA Assistant 배너를 출력합니다."""
    console = get_console()
    console.print(BANNER)


def print_help() -> None:
    """도움말을 출력합니다."""
    console = get_console()

    help_table = Table(show_header=False, box=None, padding=(0, 2))
    help_table.add_column("Command", style="cyan")
    help_table.add_column("Description", style="dim")

    help_table.add_row("Enter", "메시지 전송")
    help_table.add_row("Esc+Enter / Alt+Enter", "줄바꿈")
    help_table.add_row("↑ / ↓", "히스토리 탐색")
    help_table.add_row("Ctrl+C", "입력 취소")
    help_table.add_row("exit / quit", "종료")

    console.print()
    console.print(
        Panel(
            help_table,
            title="[bold]키보드 단축키[/]",
            border_style="dim",
            padding=(0, 1),
        )
    )


def print_specialists_info(specialists: list[str]) -> None:
    """사용 가능한 Specialist 정보를 출력합니다."""
    console = get_console()

    specialist_descriptions = {
        "explorer": ("🔍", "아키텍처 분석, 다이어그램 해석, 코드 탐색"),
        "researcher": ("📚", "AWS 문서 검색, Best Practice, 가격 정보"),
        "reviewer": ("✅", "Well-Architected 검토, 보안 분석, 개선 권장"),
    }

    guru_descriptions = {
        "bezos": ("👔", "고객 중심 사고, 장기 비전"),
        "vogels": ("🔧", "분산 시스템, 확장성"),
        "naval": ("💡", "레버리지, ROI 분석"),
        "feynman": ("🎓", "개념 단순화, 설명"),
    }

    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("Agent", style="cyan")
    table.add_column("Type", style="dim")
    table.add_column("전문 분야")

    for name, (emoji, desc) in specialist_descriptions.items():
        table.add_row(f"{emoji} {name}", "Specialist", desc)

    for name, (emoji, desc) in guru_descriptions.items():
        table.add_row(f"{emoji} {name}", "Guru", desc)

    console.print()
    console.print(
        Panel(
            table,
            title="[bold]사용 가능한 에이전트[/]",
            border_style="cyan",
            padding=(0, 1),
        )
    )


# =============================================================================
# 에이전트 패널
# =============================================================================


class AgentPanel:
    """에이전트 실행 상태를 표시하는 패널"""

    AGENT_COLORS = {
        "orchestrator": "aws.orange",
        "guru": "agent.guru",
        "specialist": "agent.specialist",
        "bezos": "agent.guru",
        "vogels": "agent.guru",
        "naval": "agent.guru",
        "feynman": "agent.guru",
        "explorer": "agent.explorer",
        "researcher": "agent.researcher",
        "reviewer": "agent.reviewer",
    }

    AGENT_EMOJIS = {
        "orchestrator": "🎯",
        "bezos": "👔",
        "vogels": "🔧",
        "naval": "💡",
        "feynman": "🎓",
        "explorer": "🔍",
        "researcher": "📚",
        "reviewer": "✅",
    }

    def __init__(self, agent_name: str, agent_type: str = "specialist"):
        self.agent_name = agent_name
        self.agent_type = agent_type
        self.console = get_console()

    def print_start(self, task: str = None) -> None:
        """에이전트 시작을 표시합니다."""
        emoji = self.AGENT_EMOJIS.get(self.agent_name.lower(), "🤖")
        color = self.AGENT_COLORS.get(self.agent_name.lower(), "cyan")

        text = f"{emoji} [{color}]{self.agent_name.upper()}[/] 에이전트 호출 중..."
        if task:
            text += f" ({task[:50]}...)" if len(task) > 50 else f" ({task})"

        self.console.print(text)

    def print_result(self, success: bool = True, message: str = None) -> None:
        """에이전트 결과를 표시합니다."""
        emoji = self.AGENT_EMOJIS.get(self.agent_name.lower(), "🤖")
        color = self.AGENT_COLORS.get(self.agent_name.lower(), "cyan")

        if success:
            status = "[success]완료[/]"
        else:
            status = "[error]실패[/]"

        text = f"{emoji} [{color}]{self.agent_name.upper()}[/] {status}"
        if message:
            text += f": {message}"

        self.console.print(text)


# =============================================================================
# 도구 상태
# =============================================================================


class ToolStatus:
    """도구 실행 상태를 관리합니다."""

    TOOL_EMOJIS = {
        "consult_guru": "🧙",
        "consult_specialist": "🔬",
        "file_read": "📄",
        "file_write": "💾",
        "shell": "🖥️",
        "image_reader": "🖼️",
        "code_interpreter": "⚡",
        "skill": "📚",
        "list_gurus": "📋",
        "list_specialists": "📋",
    }

    def __init__(self):
        self.console = get_console()
        self._active_tools: Dict[str, str] = {}  # tool_id -> tool_name

    def tool_start(
        self, tool_id: str, tool_name: str, args: Dict[str, Any] = None
    ) -> None:
        """도구 시작을 표시합니다."""
        if tool_id in self._active_tools:
            return  # 이미 표시됨

        self._active_tools[tool_id] = tool_name
        emoji = self.TOOL_EMOJIS.get(tool_name, "🔧")

        # 특별한 도구들에 대한 상세 정보
        detail = ""
        if args:
            if tool_name == "consult_guru":
                guru_name = args.get("guru_name", "")
                detail = f" → {guru_name.upper()}"
            elif tool_name == "consult_specialist":
                specialist_name = args.get("specialist_name", "")
                detail = f" → {specialist_name.upper()}"
            elif tool_name == "skill":
                skill_name = args.get("skill_name", "")
                detail = f" → {skill_name}"
            elif tool_name in ("file_read", "file_write"):
                path = args.get("path", args.get("file_path", ""))
                if path:
                    # 경로가 길면 축약
                    if len(path) > 40:
                        path = "..." + path[-37:]
                    detail = f" → {path}"

        self.console.print(f"[tool.running]{emoji} {tool_name}{detail}[/]")

    def tool_end(self, tool_id: str, success: bool = True, error: str = None) -> None:
        """도구 종료를 표시합니다. (선택적)"""
        if tool_id in self._active_tools:
            del self._active_tools[tool_id]

        # 에러가 있을 때만 표시
        if not success and error:
            self.console.print(f"[tool.error]✗ 오류: {error}[/]")


# =============================================================================
# 응답 렌더러
# =============================================================================


class ResponseRenderer:
    """에이전트 응답을 렌더링합니다."""

    def __init__(self):
        self.console = get_console()
        self._buffer = ""

    def stream_text(self, text: str) -> None:
        """스트리밍 텍스트를 출력합니다."""
        print(text, end="", flush=True)
        self._buffer += text

    def render_markdown(self, text: str) -> None:
        """마크다운을 렌더링합니다."""
        md = Markdown(text)
        self.console.print(md)

    def render_code(self, code: str, language: str = "python") -> None:
        """코드를 구문 강조하여 렌더링합니다."""
        syntax = Syntax(code, language, theme="monokai", line_numbers=True)
        self.console.print(syntax)

    def render_thinking(self, text: str) -> None:
        """Thinking 텍스트를 렌더링합니다."""
        self.console.print(
            Panel(
                Text(text, style="text.thinking"),
                title="[dim]💭 Thinking[/]",
                border_style="dim",
            )
        )

    def clear_buffer(self) -> str:
        """버퍼를 비우고 내용을 반환합니다."""
        content = self._buffer
        self._buffer = ""
        return content


# =============================================================================
# 프로그레스 및 스피너
# =============================================================================


def create_spinner(text: str = "처리 중...") -> Progress:
    """스피너 Progress 인스턴스를 생성합니다."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=get_console(),
        transient=True,
    )


class ThinkingSpinner:
    """Thinking 상태를 표시하는 스피너"""

    def __init__(self):
        self.console = get_console()
        self._live: Optional[Live] = None

    def start(self) -> None:
        """스피너를 시작합니다."""
        spinner = Spinner("dots", text="[text.thinking]생각 중...[/]")
        self._live = Live(spinner, console=self.console, transient=True)
        self._live.start()

    def update(self, text: str) -> None:
        """스피너 텍스트를 업데이트합니다."""
        if self._live:
            spinner = Spinner("dots", text=f"[text.thinking]{text}[/]")
            self._live.update(spinner)

    def stop(self) -> None:
        """스피너를 중지합니다."""
        if self._live:
            self._live.stop()
            self._live = None


# =============================================================================
# 유틸리티
# =============================================================================


def format_duration(seconds: float) -> str:
    """시간을 포맷팅합니다."""
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    else:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.0f}s"


def truncate_text(text: str, max_length: int = 100) -> str:
    """텍스트를 축약합니다."""
    if len(text) <= max_length:
        return text
    return text[: max_length - 3] + "..."
