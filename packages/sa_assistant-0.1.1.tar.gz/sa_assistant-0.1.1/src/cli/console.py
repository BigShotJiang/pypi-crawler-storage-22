"""SA Assistant Console - Rich 기반 콘솔 래퍼

Rich 라이브러리를 사용하여 터미널 UI를 개선합니다.
"""

from typing import Optional
from rich.console import Console
from rich.theme import Theme
from rich.style import Style

# SA Assistant 커스텀 테마 - AWS 오렌지 기반
SA_THEME = Theme(
    {
        # AWS 컬러 스킴
        "aws.orange": "bold #FF9900",
        "aws.dark": "#232F3E",
        "aws.blue": "#1A73E8",
        # 에이전트 타입별 색상
        "agent.orchestrator": "bold #FF9900",
        "agent.guru": "bold magenta",
        "agent.specialist": "bold cyan",
        "agent.explorer": "bold green",
        "agent.researcher": "bold blue",
        "agent.reviewer": "bold yellow",
        # 도구 상태 색상
        "tool.running": "cyan",
        "tool.success": "green",
        "tool.error": "red",
        "tool.pending": "dim",
        # 텍스트 스타일
        "text.user": "bold green",
        "text.assistant": "bold #FF9900",
        "text.thinking": "dim italic",
        "text.error": "bold red",
        "text.warning": "yellow",
        "text.info": "cyan",
        "text.dim": "dim",
        # 특수 용도
        "highlight": "bold #FF9900",
        "success": "bold green",
        "error": "bold red",
        "warning": "yellow",
    }
)


class SAConsole:
    """SA Assistant 전용 Rich Console 래퍼

    싱글톤 패턴으로 전역 콘솔 인스턴스를 관리합니다.
    """

    _instance: Optional[Console] = None

    @classmethod
    def get_console(cls) -> Console:
        """전역 Console 인스턴스를 반환합니다."""
        if cls._instance is None:
            cls._instance = Console(
                theme=SA_THEME,
                highlight=True,
                markup=True,
                emoji=True,
            )
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Console 인스턴스를 리셋합니다. (테스트용)"""
        cls._instance = None


# 편의 함수들
def get_console() -> Console:
    """전역 Console 인스턴스를 반환합니다."""
    return SAConsole.get_console()


def print_styled(text: str, style: str = None, **kwargs) -> None:
    """스타일이 적용된 텍스트를 출력합니다."""
    console = get_console()
    console.print(text, style=style, **kwargs)


def print_error(text: str) -> None:
    """에러 메시지를 출력합니다."""
    console = get_console()
    console.print(f"[text.error]✗ {text}[/]")


def print_warning(text: str) -> None:
    """경고 메시지를 출력합니다."""
    console = get_console()
    console.print(f"[text.warning]⚠ {text}[/]")


def print_info(text: str) -> None:
    """정보 메시지를 출력합니다."""
    console = get_console()
    console.print(f"[text.info]ℹ {text}[/]")


def print_success(text: str) -> None:
    """성공 메시지를 출력합니다."""
    console = get_console()
    console.print(f"[success]✓ {text}[/]")
