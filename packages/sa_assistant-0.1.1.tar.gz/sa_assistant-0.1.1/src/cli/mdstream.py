"""SA Assistant Markdown Stream - Streaming markdown renderer with Rich Live display."""

import io
import time
from typing import Optional

from rich import box
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown, CodeBlock, Heading
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text

from .console import get_console


class SACodeBlock(CodeBlock):
    """Code block with minimal padding and monokai theme."""

    def __rich_console__(self, console, options):
        code = str(self.text).rstrip()
        syntax = Syntax(
            code,
            self.lexer_name,
            theme="monokai",
            word_wrap=True,
            padding=(1, 2),
            background_color="#1a1a1a",
        )
        yield syntax


class SAHeading(Heading):
    """Left-aligned heading with AWS color scheme."""

    def __rich_console__(self, console, options):
        text = self.text
        text.justify = "left"

        if self.tag == "h1":
            yield Panel(
                text,
                box=box.HEAVY,
                style="bold #FF9900",
                border_style="#FF9900",
            )
        elif self.tag == "h2":
            yield Text("")
            text.stylize("bold cyan")
            yield text
        else:
            text.stylize("bold")
            yield text


class SAMarkdown(Markdown):
    """Custom markdown renderer with SA Assistant styling."""

    elements = {
        **Markdown.elements,
        "fence": SACodeBlock,
        "code_block": SACodeBlock,
        "heading_open": SAHeading,
    }


class MarkdownStream:
    """Streaming markdown renderer using Rich Live display.

    Renders LLM responses in real-time with proper markdown formatting.
    Uses sliding window approach: stable lines go to console,
    unstable lines stay in Live area for smooth updates.

    Usage:
        stream = MarkdownStream()
        for chunk in llm_response:
            stream.update(accumulated_text)
        stream.update(final_text, final=True)
    """

    MIN_FPS = 20
    MAX_DELAY = 2.0

    def __init__(
        self,
        console: Optional[Console] = None,
        live_window: int = 6,
        min_delay: float = 1.0 / 20,
    ):
        self.console = console or get_console()
        self.live_window = live_window
        self.min_delay = min_delay

        self.live: Optional[Live] = None
        self.when: float = 0
        self.printed: list = []
        self._live_started: bool = False
        self._text_buffer: str = ""

    def _render_markdown_to_lines(self, text: str) -> list:
        string_io = io.StringIO()
        temp_console = Console(
            file=string_io, force_terminal=True, width=self.console.width
        )

        markdown = SAMarkdown(text)
        temp_console.print(markdown)
        output = string_io.getvalue()

        return output.splitlines(keepends=True)

    def update(self, text: str, final: bool = False) -> None:
        """Update displayed markdown content."""
        self._text_buffer = text

        if not self._live_started:
            self.live = Live(
                Text(""),
                console=self.console,
                refresh_per_second=1.0 / self.min_delay,
                transient=True,
            )
            self.live.start()
            self._live_started = True

        now = time.time()
        if not final and now - self.when < self.min_delay:
            return
        self.when = now

        start = time.time()
        lines = self._render_markdown_to_lines(text)
        render_time = time.time() - start

        self.min_delay = min(max(render_time * 10, 1.0 / self.MIN_FPS), self.MAX_DELAY)

        num_lines = len(lines)

        if not final:
            num_lines -= self.live_window

        if final or num_lines > 0:
            num_printed = len(self.printed)
            show_count = num_lines - num_printed

            if show_count > 0 and self.live is not None:
                show = lines[num_printed:num_lines]
                show_text = "".join(show)
                show_rich = Text.from_ansi(show_text)
                self.live.console.print(show_rich, end="")

                self.printed = lines[:num_lines]

        if final:
            if self.live:
                self.live.update(Text(""))
                self.live.stop()
                self.live = None
            return

        rest = lines[num_lines:]
        rest_text = "".join(rest)
        rest_rich = Text.from_ansi(rest_text)
        if self.live:
            self.live.update(rest_rich)

    def finish(self) -> None:
        """Finalize stream and output remaining content."""
        if self._text_buffer:
            self.update(self._text_buffer, final=True)
        elif self.live:
            self.live.stop()
            self.live = None

    def __del__(self):
        if self.live:
            try:
                self.live.stop()
            except Exception:
                pass


class SimpleMarkdownStream:
    """Simple markdown stream - renders final result only.

    Outputs plain text during streaming, renders full markdown on completion.
    """

    def __init__(self, console: Optional[Console] = None):
        self.console = console or get_console()
        self._buffer = ""
        self._last_printed_len = 0

    def update(self, text: str, final: bool = False) -> None:
        """Update text content."""
        if final:
            print()
            self.console.print(SAMarkdown(text))
        else:
            new_text = text[self._last_printed_len :]
            if new_text:
                print(new_text, end="", flush=True)
                self._last_printed_len = len(text)

        self._buffer = text

    def finish(self) -> None:
        """Finalize stream."""
        if self._buffer:
            self.update(self._buffer, final=True)


def render_markdown(text: str, console: Optional[Console] = None) -> None:
    """Render markdown text to console."""
    console = console or get_console()
    console.print(SAMarkdown(text))


def render_code(
    code: str,
    language: str = "python",
    console: Optional[Console] = None,
    line_numbers: bool = True,
) -> None:
    """Render code with syntax highlighting."""
    console = console or get_console()
    syntax = Syntax(
        code,
        language,
        theme="monokai",
        line_numbers=line_numbers,
        word_wrap=True,
        background_color="#1a1a1a",
    )
    console.print(syntax)
