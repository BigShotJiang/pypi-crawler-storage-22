# 프롬프트 모듈
# 시스템 프롬프트 및 스킬 파일 로더

from pathlib import Path
from typing import Optional


def get_prompts_dir() -> Path:
    """프롬프트 디렉토리 경로를 반환합니다."""
    return Path(__file__).parent


def get_skills_dir() -> Path:
    """스킬 디렉토리 경로를 반환합니다."""
    return get_prompts_dir() / "skills"


def load_skill(skill_name: str) -> Optional[str]:
    """
    스킬 파일을 로드합니다.
    
    Args:
        skill_name: 스킬 파일명 (확장자 제외)
    
    Returns:
        str: 스킬 파일 내용 또는 None
    """
    skill_path = get_skills_dir() / f"{skill_name}.md"
    if skill_path.exists():
        return skill_path.read_text(encoding="utf-8")
    return None


def load_all_skills() -> dict:
    """
    모든 스킬 파일을 로드합니다.
    
    Returns:
        dict: {스킬명: 내용} 딕셔너리
    """
    skills = {}
    skills_dir = get_skills_dir()
    if skills_dir.exists():
        for skill_file in skills_dir.glob("*.md"):
            skill_name = skill_file.stem
            skills[skill_name] = skill_file.read_text(encoding="utf-8")
    return skills


# 시스템 프롬프트 임포트
from .system_prompts import (
    ORCHESTRATOR_PROMPT,
    GURU_PROMPTS,
    get_orchestrator_prompt,
)

__all__ = [
    "get_prompts_dir",
    "get_skills_dir", 
    "load_skill",
    "load_all_skills",
    "ORCHESTRATOR_PROMPT",
    "GURU_PROMPTS",
    "get_orchestrator_prompt",
]
