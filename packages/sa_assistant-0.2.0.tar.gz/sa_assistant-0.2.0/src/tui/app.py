"""SA Assistant TUI Application - Main Textual App class."""

from datetime import datetime
from pathlib import Path
from typing import Optional

from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import ScrollableContainer, Vertical
from textual.widgets import Footer, Header, Input, Static, RichLog, Collapsible
from textual.worker import Worker
from rich.text import Text
from rich.markdown import Markdown

from strands import Agent
from strands.agent.conversation_manager import SlidingWindowConversationManager
from strands_tools import file_read, file_write, shell, image_reader

from model.load import load_sonnet
from prompts.system_prompts import ORCHESTRATOR_PROMPT
from agents.orchestrator import consult_guru, list_gurus
from agents.specialists import consult_specialist, list_specialists, parallel_research
from agentskills import discover_skills, generate_skills_prompt, create_skill_tool


CSS_PATH = Path(__file__).parent / "styles.tcss"
SKILLS_DIR = Path(__file__).parent.parent / "skills"


class SessionHeader(Static):
    """Top header showing session info, tokens, cost."""

    def __init__(self, session_id: str = None):
        super().__init__()
        self.session_start = datetime.now()
        self.session_id = session_id or self.session_start.strftime("%Y-%m-%dT%H:%M:%S")
        self.token_count = 0
        self.cost = 0.0

    def compose(self) -> ComposeResult:
        yield Static(id="session-info")

    def on_mount(self) -> None:
        self._update_display()

    def _update_display(self) -> None:
        info = self.query_one("#session-info", Static)
        info.update(
            f"# Session - {self.session_id}    "
            f"[dim]{self.token_count:,} tokens · ${self.cost:.2f}[/dim]"
        )

    def update_stats(self, tokens: int = 0, cost: float = 0.0) -> None:
        self.token_count += tokens
        self.cost += cost
        self._update_display()


class AgentIndicator(Static):
    """Bottom indicator showing current agent and model."""

    def __init__(self, agent_name: str = "SA Assistant", model_name: str = "Claude Sonnet"):
        super().__init__()
        self.agent_name = agent_name
        self.model_name = model_name

    def on_mount(self) -> None:
        self._update_display()

    def _update_display(self) -> None:
        self.update(f"[cyan]■[/cyan] {self.agent_name} · [dim]{self.model_name}[/dim]")

    def set_agent(self, name: str, model: str = None) -> None:
        self.agent_name = name
        if model:
            self.model_name = model
        self._update_display()


class MessageSection(Collapsible):
    """Collapsible section for a single message/action."""

    def __init__(self, title: str, content: str = "", collapsed: bool = False):
        super().__init__(title=title, collapsed=collapsed)
        self._content = content
        self._log: Optional[RichLog] = None

    def compose(self) -> ComposeResult:
        self._log = RichLog(highlight=True, markup=True, wrap=True)
        yield self._log

    def on_mount(self) -> None:
        if self._content and self._log:
            self._log.write(self._content)

    def append(self, text: str) -> None:
        if self._log:
            self._log.write(text)

    def update_content(self, text: str) -> None:
        if self._log:
            self._log.clear()
            self._log.write(text)


class ChatContainer(ScrollableContainer):
    """Main scrollable container for chat messages."""

    def __init__(self):
        super().__init__()
        self._sections: list[MessageSection] = []

    def add_user_message(self, text: str) -> MessageSection:
        section = MessageSection(title=f"[green]You[/green]", content=text, collapsed=False)
        self._sections.append(section)
        self.mount(section)
        section.scroll_visible()
        return section

    def add_assistant_message(self, title: str = "SA Assistant") -> MessageSection:
        section = MessageSection(title=f"[#FF9900]{title}[/#FF9900]", collapsed=False)
        self._sections.append(section)
        self.mount(section)
        section.scroll_visible()
        return section

    def add_tool_section(self, tool_name: str, collapsed: bool = True) -> MessageSection:
        emoji_map = {
            "consult_guru": "🧙",
            "consult_specialist": "🔬",
            "file_read": "📄",
            "file_write": "💾",
            "shell": "🖥️",
            "skill": "📚",
        }
        emoji = emoji_map.get(tool_name, "🔧")
        section = MessageSection(title=f"[cyan]{emoji} {tool_name}[/cyan]", collapsed=collapsed)
        self._sections.append(section)
        self.mount(section)
        return section


class SAAssistantApp(App):
    """SA Assistant Textual TUI Application."""

    CSS_PATH = "styles.tcss"

    TITLE = "SA Assistant"
    SUB_TITLE = "AWS Solutions Architect Agent"

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
        Binding("ctrl+c", "quit", "Quit", show=True),
        Binding("ctrl+l", "clear", "Clear", show=True),
        Binding("ctrl+t", "toggle_dark", "Theme", show=True),
    ]

    def __init__(self):
        super().__init__()
        self._agent: Optional[Agent] = None
        self._current_section: Optional[MessageSection] = None
        self._response_buffer = ""
        self._init_agent()

    def _init_agent(self) -> None:
        discovered_skills = discover_skills(SKILLS_DIR)
        skills_prompt = generate_skills_prompt(discovered_skills)
        full_prompt = ORCHESTRATOR_PROMPT + skills_prompt
        skill_tool = create_skill_tool(discovered_skills, SKILLS_DIR) if discovered_skills else None

        tools = [
            consult_guru,
            list_gurus,
            consult_specialist,
            list_specialists,
            parallel_research,
            file_read,
            file_write,
            image_reader,
            shell,
        ]
        if skill_tool:
            tools.append(skill_tool)

        conversation_manager = SlidingWindowConversationManager(window_size=20)

        self._agent = Agent(
            model=load_sonnet(enable_thinking=False),
            conversation_manager=conversation_manager,
            system_prompt=full_prompt,
            tools=tools,
            callback_handler=self._streaming_callback,
        )

    def _streaming_callback(self, **kwargs) -> None:
        if "data" in kwargs:
            self._response_buffer += kwargs["data"]
            if self._current_section:
                self.call_from_thread(self._current_section.update_content, self._response_buffer)

        if "current_tool_use" in kwargs:
            tool_use = kwargs["current_tool_use"]
            if isinstance(tool_use, dict):
                tool_name = tool_use.get("name", "tool")
                self.call_from_thread(self._add_tool_section, tool_name)

    def _add_tool_section(self, tool_name: str) -> None:
        chat = self.query_one(ChatContainer)
        chat.add_tool_section(tool_name, collapsed=True)

    def compose(self) -> ComposeResult:
        yield Header()
        yield SessionHeader()
        yield ChatContainer()
        yield AgentIndicator()
        yield Input(placeholder="Type your message... (Enter to send)")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one(Input).focus()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        user_input = event.value.strip()
        if not user_input:
            return

        event.input.value = ""

        if user_input.lower() in ("exit", "quit", "종료"):
            self.exit()
            return

        chat = self.query_one(ChatContainer)
        chat.add_user_message(user_input)

        self._current_section = chat.add_assistant_message()
        self._response_buffer = ""

        self.run_agent(user_input)

    @work(thread=True)
    def run_agent(self, prompt: str) -> None:
        try:
            self._agent(prompt)
        except Exception as e:
            if self._current_section:
                self.call_from_thread(
                    self._current_section.update_content, f"[red]Error: {e}[/red]"
                )

    def action_cancel(self) -> None:
        self.workers.cancel_all()

    def action_clear(self) -> None:
        chat = self.query_one(ChatContainer)
        chat.remove_children()

    def action_toggle_dark(self) -> None:
        self.dark = not self.dark


def run_app() -> None:
    app = SAAssistantApp()
    app.run()


if __name__ == "__main__":
    run_app()
