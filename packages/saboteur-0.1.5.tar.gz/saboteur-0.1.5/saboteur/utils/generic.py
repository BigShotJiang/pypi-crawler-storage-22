from typing import TypeVar

T = TypeVar('T')