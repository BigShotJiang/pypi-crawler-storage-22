import logging

logger = logging.getLogger("saboteur")
logger.setLevel(logging.DEBUG)