AVAILABLE_PRIMITIVE_TYPES = (
    int, float, str, bool, list, dict, set, tuple
)