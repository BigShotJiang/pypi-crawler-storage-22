"""Collection of attacks for assessing the privacy of trained ML models."""
