"""Collection of defensive wrappers for preserving the privacy of ML models."""
