import random
import typer

app = typer.Typer()

EXCUSES = [
    "Network issue da...",
    "Laptop hang bro...",
    "Sudden sleep attack...",
    "Mentally tired da...",
    "Unexpected hunger...",
    "Will start tomorrow surely...",
]

MOTIVATION = [
    "You can do it bro... but relax first.",
    "Consistency is important da... from tomorrow.",
    "Work smart, not today.",
]

MOODS = [
    "Sleepy",
    "Hungry",
    "Unmotivated",
    "Confident without reason",
]

PLANS = [
    "Think about working",
    "Watch YouTube",
    "Open laptop and stare",
    "Panic at night",
]

DECISIONS = [
    "YES (but later)",
    "NO (obviously)",
    "Maybe tomorrow",
]

@app.command()
def excuse():
    print(random.choice(EXCUSES))

@app.command()
def motivation():
    print(random.choice(MOTIVATION))

@app.command()
def mood():
    print(f"Current Mood: {random.choice(MOODS)}")

@app.command()
def plan():
    print("Today's Plan:")
    for item in random.sample(PLANS, k=3):
        print(f"- {item}")

@app.command()
def decide(question: str):
    print(f"Question: {question}")
    print(f"Decision: {random.choice(DECISIONS)}")

@app.command()
def productivity():
    level = random.randint(0, 10)
    print(f"Productivity Level: {level}/10")

if __name__ == "__main__":
    app()
