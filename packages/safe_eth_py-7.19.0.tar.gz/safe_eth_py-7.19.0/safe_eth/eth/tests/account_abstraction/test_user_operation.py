from unittest import TestCase

from safe_eth.util.util import to_0x_hex_str

from ...account_abstraction import UserOperation
from ...account_abstraction.user_operation import UserOperationV07
from ..mocks.mock_bundler import (
    safe_4337_chain_id_mock,
    safe_4337_user_operation_hash_mock,
    user_operation_mock,
    user_operation_v07_hash_1,
    user_operation_v07_hash_2,
    user_operation_v07_hash_v150,
    user_operation_v07_mock_1,
    user_operation_v07_mock_2,
    user_operation_v07_mock_v150,
)


class TestUserOperation(TestCase):
    def test_calculate_user_operation_hash_V06(self):
        user_operation_hash = safe_4337_user_operation_hash_mock
        user_operation = UserOperation.from_bundler_response(
            to_0x_hex_str(user_operation_hash), user_operation_mock["result"]
        )
        self.assertIsInstance(user_operation, UserOperation)
        self.assertEqual(
            user_operation.calculate_user_operation_hash(safe_4337_chain_id_mock),
            user_operation_hash,
        )

    def test_calculate_user_operation_hash_V07(self):
        for (
            user_operation_v07_hash,
            user_operation_v07_mock,
            user_operation_v07_chain_id,
        ) in [
            (
                user_operation_v07_hash_1,
                user_operation_v07_mock_1,
                safe_4337_chain_id_mock,
            ),
            (
                user_operation_v07_hash_2,
                user_operation_v07_mock_2,
                safe_4337_chain_id_mock,
            ),
            (
                user_operation_v07_hash_v150,
                user_operation_v07_mock_v150,
                safe_4337_chain_id_mock,
            ),
        ]:
            user_operation_hash = user_operation_v07_hash
            user_operation = UserOperation.from_bundler_response(
                to_0x_hex_str(user_operation_hash), user_operation_v07_mock["result"]
            )
            self.assertIsInstance(user_operation, UserOperationV07)
            self.assertEqual(
                user_operation.calculate_user_operation_hash(
                    user_operation_v07_chain_id
                ),
                user_operation_hash,
            )
