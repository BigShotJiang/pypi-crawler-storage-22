"""Tests for SafeNest SDK."""
