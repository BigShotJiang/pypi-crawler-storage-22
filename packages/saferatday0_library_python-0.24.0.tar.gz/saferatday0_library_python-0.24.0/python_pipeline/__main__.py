# SPDX-FileCopyrightText: UL Research Institutes
# SPDX-License-Identifier: Apache-2.0

import argparse

import yaml

from ._version import __version__

parser = argparse.ArgumentParser()
parser.add_argument("name", help="Name")
parser.add_argument(
    "-V", "--version", action="version", version="%(prog)s " + __version__
)


def main():
    args = parser.parse_args()
    print("Hello", args.name)
    print(yaml.dump({"more": "info"}))


if __name__ == "__main__":
    main()
