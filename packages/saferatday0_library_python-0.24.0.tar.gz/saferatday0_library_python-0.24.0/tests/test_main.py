# SPDX-FileCopyrightText: UL Research Institutes
# SPDX-License-Identifier: Apache-2.0

import subprocess


def test_nothing():
    pass


def test_main():
    subprocess.run(["python", "-m", "python_pipeline", "John Doe"])
