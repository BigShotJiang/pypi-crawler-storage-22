"""SafetyGate SDK — Runtime safety layer for quantum error correction."""
__version__ = "0.0.1"
