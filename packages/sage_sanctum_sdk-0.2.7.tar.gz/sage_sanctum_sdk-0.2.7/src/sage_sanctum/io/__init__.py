"""Agent input/output types."""
