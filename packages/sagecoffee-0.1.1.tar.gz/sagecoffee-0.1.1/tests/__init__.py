"""Tests for sagecoffee."""
