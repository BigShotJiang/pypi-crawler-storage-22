import * as fc from 'fast-check';
import {
  createNewCellSourceForCell,
  getMagicLineFromInterpreterAndConnection,
  isCellStartWithSupportedMagics,
} from '../../utils/DropdownUtils';
import { Constants } from '../../constants';

jest.mock('@jupyterlab/notebook');
jest.mock('@jupyterlab/cells');

// Test generators for magic commands and interpreters
const interpreterArbitrary = fc.constantFrom(
  Constants.INTERPRETER_PYSPARK_VALUE,
  Constants.INTERPRETER_SCALA_SPARK_VALUE,
  Constants.INTERPRETER_SQL_VALUE,
  Constants.INTERPRETER_LOCAL_PYTHON_VALUE
);

const connectionArbitrary = fc.oneof(
  fc.constantFrom(
    Constants.DEFAULT_IAM_CONNECTION_NAME,
    Constants.DEFAULT_IAM_CONNECTION_NAME_EXPRESS,
    Constants.DEFAULT_IAM_CONNECTION_DISPLAYNAME,
    Constants.DEFAULT_REDSHIFT_CONNECTION_NAME,
    Constants.DEFAULT_ATHENA_CONNECTION_NAME,
    Constants.DEFAULT_GLUE_COMPATIBILITY_CONNECTION_NAME
  ),
  fc.string({ minLength: 1, maxLength: 50 }).map(s => `test-${s}`)
);

const magicCommandArbitrary = fc.constantFrom(
  Constants.CONNECT_PYSPARK_MAGIC_ALIAS,
  Constants.CONNECT_SCALA_SPARK_CELL_MAGIC_ALIAS,
  Constants.CONNECT_SQL_CELL_MAGIC_ALIAS,
  Constants.CONNECT_LOCAL_MAGIC_ALIAS,
  Constants.CONNECT_CELL_MAGIC,
  Constants.CONNECT_SPARK_MAGIC_ALIAS
);

const sourceContentArbitrary = fc.oneof(
  fc.constant(''),
  fc.string({ minLength: 1, maxLength: 200 }),
  fc.array(fc.string({ maxLength: 50 }), { minLength: 1, maxLength: 10 }).map(lines => lines.join('\n'))
);

describe('Property-based tests for DropdownUtils', () => {
  describe('Property 1: Cell Creation Consistency', () => {
    /**
     * **Validates: Requirements 2.1, 5.2, 6.1**
     * For any valid interpreter and connection combination, creating cell source should be consistent
     */
    it('should consistently create valid cell source for any interpreter/connection combination', () => {
      fc.assert(
        fc.property(
          interpreterArbitrary,
          connectionArbitrary,
          sourceContentArbitrary,
          (interpreter, connection, source) => {
            const result = createNewCellSourceForCell(interpreter, connection, source);
            
            // Property: Result should always be a string
            expect(typeof result).toBe('string');
            
            // Property: For non-IAM local connections, result should contain magic command
            if (!(connection === Constants.DEFAULT_IAM_CONNECTION_NAME && interpreter === Constants.INTERPRETER_LOCAL_PYTHON_VALUE) &&
                !(connection === Constants.DEFAULT_IAM_CONNECTION_NAME_EXPRESS && interpreter === Constants.INTERPRETER_LOCAL_PYTHON_VALUE) &&
                !(connection === Constants.DEFAULT_IAM_CONNECTION_DISPLAYNAME && interpreter === Constants.INTERPRETER_LOCAL_PYTHON_VALUE)) {
              
              const expectedMagic = getMagicLineFromInterpreterAndConnection(interpreter, connection).trim();
              const resultLines = result.split('\n');
              
              if (resultLines.length > 0 && resultLines[0] !== '') {
                expect(resultLines[0]).toBe(expectedMagic);
              }
            }
            
            // Property: Original content should be preserved (excluding magic line modifications)
            if (source.trim() !== '') {
              const sourceLines = source.split('\n');
              const resultLines = result.split('\n');
              
              // If source doesn't start with magic, original content should be in result
              if (!isCellStartWithSupportedMagics(sourceLines[0])) {
                const contentStartIndex = resultLines[0].startsWith('%%') ? 1 : 0;
                const preservedContent = resultLines.slice(contentStartIndex).join('\n');
                expect(preservedContent).toContain(source.trim());
              }
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Property 2: Magic Command Execution', () => {
    /**
     * **Validates: Requirements 1.1, 1.2, 2.2, 3.1**
     * For any interpreter and connection, magic line generation should be consistent
     */
    it('should generate consistent magic lines for interpreter/connection pairs', () => {
      fc.assert(
        fc.property(
          interpreterArbitrary,
          connectionArbitrary,
          (interpreter, connection) => {
            const result = getMagicLineFromInterpreterAndConnection(interpreter, connection);
            
            // Property: Result should always be a string ending with newline
            expect(typeof result).toBe('string');
            expect(result).toMatch(/\n$/);
            
            // Property: Result should start with appropriate magic command
            const expectedPrefix = interpreter === Constants.INTERPRETER_PYSPARK_VALUE ? '%%pyspark' :
                                 interpreter === Constants.INTERPRETER_SCALA_SPARK_VALUE ? '%%scalaspark' :
                                 interpreter === Constants.INTERPRETER_SQL_VALUE ? '%%sql' :
                                 '%%local';
            
            expect(result).toMatch(new RegExp(`^${expectedPrefix.replace('%', '\\%')} `));
            
            // Property: Result should contain the connection name
            expect(result).toContain(connection);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Property 3: User Input Preservation', () => {
    /**
     * **Validates: Requirements 2.3, 6.2, 6.3**
     * User input should be preserved when creating cell source
     */
    it('should preserve user input content when creating cell source', () => {
      fc.assert(
        fc.property(
          interpreterArbitrary,
          connectionArbitrary,
          fc.string({ minLength: 1, maxLength: 100 }).filter(s => s.trim() !== ''),
          (interpreter, connection, userContent) => {
            // Skip if content starts with magic (would be replaced)
            if (isCellStartWithSupportedMagics(userContent)) {
              return true;
            }
            
            const result = createNewCellSourceForCell(interpreter, connection, userContent);
            
            // Property: User content should be preserved in the result
            expect(result).toContain(userContent.trim());
            
            // Property: No content should be lost
            const resultLines = result.split('\n');
            const userLines = userContent.split('\n');
            
            // Find where user content starts in result
            let userContentFound = false;
            for (let i = 0; i < resultLines.length; i++) {
              if (resultLines[i] === userLines[0]) {
                userContentFound = true;
                // Verify all user lines are preserved
                for (let j = 0; j < userLines.length; j++) {
                  if (i + j < resultLines.length) {
                    expect(resultLines[i + j]).toBe(userLines[j]);
                  }
                }
                break;
              }
            }
            
            expect(userContentFound).toBe(true);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Property 4: Interpreter Consistency', () => {
    /**
     * **Validates: Requirements 2.4, 3.3, 3.4**
     * Same interpreter should always generate same magic command type
     */
    it('should generate consistent magic commands for same interpreter', () => {
      fc.assert(
        fc.property(
          interpreterArbitrary,
          fc.array(connectionArbitrary, { minLength: 2, maxLength: 5 }),
          (interpreter, connections) => {
            const magicLines = connections.map(conn => 
              getMagicLineFromInterpreterAndConnection(interpreter, conn)
            );
            
            // Property: All magic lines for same interpreter should start with same magic command
            const expectedPrefix = interpreter === Constants.INTERPRETER_PYSPARK_VALUE ? '%%pyspark' :
                                 interpreter === Constants.INTERPRETER_SCALA_SPARK_VALUE ? '%%scalaspark' :
                                 interpreter === Constants.INTERPRETER_SQL_VALUE ? '%%sql' :
                                 '%%local';
            
            magicLines.forEach(line => {
              expect(line).toMatch(new RegExp(`^${expectedPrefix.replace('%', '\\%')} `));
            });
            
            // Property: Only connection names should differ
            const magicCommands = magicLines.map(line => line.split(' ')[0]);
            const uniqueCommands = new Set(magicCommands);
            expect(uniqueCommands.size).toBe(1);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Property 5: Magic Command Compatibility', () => {
    /**
     * **Validates: Requirements 1.3, 3.4**
     * Magic command detection should be consistent and reliable
     */
    it('should consistently detect supported magic commands', () => {
      fc.assert(
        fc.property(
          magicCommandArbitrary,
          connectionArbitrary,
          (magicCommand, connection) => {
            const magicLine = `${magicCommand} ${connection}`;
            
            // Property: All generated magic lines should be detected as supported
            expect(isCellStartWithSupportedMagics(magicLine)).toBe(true);
            
            // Property: Magic detection should be prefix-based
            const withExtraContent = `${magicLine}\nsome code here`;
            expect(isCellStartWithSupportedMagics(withExtraContent)).toBe(true);
            
            // Property: Non-magic content should not be detected
            const nonMagic = `# ${magicLine}`;
            expect(isCellStartWithSupportedMagics(nonMagic)).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Property 6: Combined Execution', () => {
    /**
     * **Validates: Requirements 3.2**
     * Creating cell source then detecting magic should be consistent
     */
    it('should maintain consistency between cell creation and magic detection', () => {
      fc.assert(
        fc.property(
          interpreterArbitrary,
          connectionArbitrary,
          sourceContentArbitrary,
          (interpreter, connection, source) => {
            const result = createNewCellSourceForCell(interpreter, connection, source);
            
            // Property: If result contains magic command, it should be detected
            const resultLines = result.split('\n');
            if (resultLines.length > 0 && resultLines[0].startsWith('%%')) {
              expect(isCellStartWithSupportedMagics(result)).toBe(true);
            }
            
            // Property: Round-trip consistency - creating then parsing should be stable
            if (result.trim() !== '') {
              const secondResult = createNewCellSourceForCell(interpreter, connection, result);
              
              // The magic line should be the same (connection might be normalized)
              const firstLines = result.split('\n');
              const secondLines = secondResult.split('\n');
              
              if (firstLines[0].startsWith('%%') && secondLines[0].startsWith('%%')) {
                // Both should have same magic command type
                const firstMagic = firstLines[0].split(' ')[0];
                const secondMagic = secondLines[0].split(' ')[0];
                expect(firstMagic).toBe(secondMagic);
              }
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  describe('Property 7: Edge Case Stability', () => {
    /**
     * **Validates: Requirements 4.1, 4.2, 4.3**
     * System should handle edge cases gracefully
     */
    it('should handle edge cases gracefully', () => {
      fc.assert(
        fc.property(
          interpreterArbitrary,
          connectionArbitrary,
          fc.oneof(
            fc.constant(''),
            fc.constant('   '),
            fc.constant('\n\n\n'),
            fc.constant('\t\t'),
            fc.string({ minLength: 0, maxLength: 5 }).map(s => s + '\n'.repeat(10))
          ),
          (interpreter, connection, edgeCase) => {
            // Property: Should not throw errors on edge cases
            expect(() => {
              const result = createNewCellSourceForCell(interpreter, connection, edgeCase);
              expect(typeof result).toBe('string');
            }).not.toThrow();
            
            // Property: Should not throw on magic detection
            expect(() => {
              const isSupported = isCellStartWithSupportedMagics(edgeCase);
              expect(typeof isSupported).toBe('boolean');
            }).not.toThrow();
            
            // Property: Should not throw on magic line generation
            expect(() => {
              const magicLine = getMagicLineFromInterpreterAndConnection(interpreter, connection);
              expect(typeof magicLine).toBe('string');
            }).not.toThrow();
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});