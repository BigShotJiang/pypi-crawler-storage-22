import {
  getCellConnectionName,
  getInterpreterList,
  getSqlOnlyConnections,
  getSqlOnlyInterpreterList,
  createNewCellSourceForCell,
  getMagicLineFromInterpreterAndConnection,
  isCellStartWithSupportedMagics,
} from '../../utils/DropdownUtils';
import { Constants } from '../../constants';

jest.mock('@jupyterlab/notebook');

jest.mock('@jupyterlab/cells');

describe('test getInterpreterList', () => {
  it('test getInterpreterList with empty connection list', function () {
    expect(getInterpreterList([])).toEqual([
      { label: 'Connection Type', value: '' },
      { label: '-', value: '-', disabled: true },
    ]);
  });

  it('test getInterpreterList with all types connection list', function () {
    expect(
      getInterpreterList([
        { name: 'emr-s.test', type: 'SPARK_EMR_SERVERLESS', enableTrustedIdentityPropagation: false },
        { name: 'emr.test', type: 'SPARK_EMR_EC2', enableTrustedIdentityPropagation: false },
        { name: 'project.lakehouse', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
        { name: 'project.redshift', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
        { name: 'project.athena', type: 'ATHENA', enableTrustedIdentityPropagation: false },
        { name: 'project.iam', type: 'IAM', enableTrustedIdentityPropagation: false },
        { name: 'project.spark', type: 'SPARK_GLUE', enableTrustedIdentityPropagation: false },
      ])
    ).toEqual([
      { label: 'Connection Type', value: '' },
      { label: '-', value: '-', disabled: true },
      { label: 'PySpark', value: 'pyspark' },
      { label: 'ScalaSpark', value: 'scalaspark' },
      { label: 'SQL', value: 'sql' },
      { label: 'Local Python', value: 'local' },
    ]);
  });
});

describe('test getSqlOnlyInterpreterList', () => {
  it('test getSqlOnlyInterpreterList with empty connection list', function () {
    expect(getSqlOnlyInterpreterList([])).toEqual([
      { label: 'Connection Type', value: '' },
      { label: '-', value: '-', disabled: true },
    ]);
  });

  it('test getSqlOnlyInterpreterList with all types connection list', function () {
    expect(
      getSqlOnlyInterpreterList([
        { name: 'emr-s.test', type: 'SPARK_EMR_SERVERLESS', enableTrustedIdentityPropagation: false },
        { name: 'emr.test', type: 'SPARK_EMR_EC2', enableTrustedIdentityPropagation: false },
        { name: 'project.lakehouse', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
        { name: 'project.redshift', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
        { name: 'project.athena', type: 'ATHENA', enableTrustedIdentityPropagation: false },
        { name: 'project.iam', type: 'IAM', enableTrustedIdentityPropagation: false },
        { name: 'project.spark', type: 'SPARK_GLUE', enableTrustedIdentityPropagation: false },
      ])
    ).toEqual([
      { label: 'Connection Type', value: '' },
      { label: '-', value: '-', disabled: true },
      { label: 'SQL', value: 'sql' },
    ]);
  });
});

describe('test getSqlOnlyConnections', () => {
  it('test getSqlOnlyInterpreterList with empty connection list', function () {
    expect(getSqlOnlyConnections([])).toEqual([]);
  });

  it('test getSqlOnlyInterpreterList with all types connection list', function () {
    expect(
      getSqlOnlyConnections([
        { name: 'emr-s.test', type: 'SPARK_EMR_SERVERLESS', enableTrustedIdentityPropagation: false },
        { name: 'emr.test', type: 'SPARK_EMR_EC2', enableTrustedIdentityPropagation: false },
        { name: 'project.lakehouse', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
        { name: 'project.redshift', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
        { name: 'project.athena', type: 'ATHENA', enableTrustedIdentityPropagation: false },
        { name: 'project.iam', type: 'IAM', enableTrustedIdentityPropagation: false },
        { name: 'project.spark', type: 'SPARK_GLUE', enableTrustedIdentityPropagation: false },
      ])
    ).toEqual([
      { name: 'project.lakehouse', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
      { name: 'project.redshift', type: 'REDSHIFT', enableTrustedIdentityPropagation: false },
      { name: 'project.athena', type: 'ATHENA', enableTrustedIdentityPropagation: false },
    ]);
  });
});

describe('test getCellConnectionName', () => {
  it('test getCellConnectionName with undefined code cell', function () {
    expect(getCellConnectionName(undefined)).toEqual('project.python');
  });
});

describe('test createNewCellSourceForCell', () => {
  it('should create cell source with empty line for PySpark magic', function () {
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_PYSPARK_VALUE,
      'test-connection',
      ''
    );
    
    expect(result).toBe('%%pyspark test-connection\n\n');
  });

  it('should create cell source with empty line for SQL magic', function () {
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_SQL_VALUE,
      'test-connection',
      ''
    );
    
    expect(result).toBe('%%sql test-connection\n\n');
  });

  it('should create cell source with empty line for Scala Spark magic', function () {
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_SCALA_SPARK_VALUE,
      'test-connection',
      ''
    );
    
    expect(result).toBe('%%scalaspark test-connection\n\n');
  });

  it('should skip magic line for local Python with default IAM connection', function () {
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_LOCAL_PYTHON_VALUE,
      Constants.DEFAULT_IAM_CONNECTION_NAME,
      'print("hello")'
    );
    
    expect(result).toBe('print("hello")');
  });

  it('should preserve existing content when adding magic line', function () {
    const existingContent = 'df = spark.sql("SELECT * FROM table")';
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_PYSPARK_VALUE,
      'test-connection',
      existingContent
    );
    
    expect(result).toBe('%%pyspark test-connection\ndf = spark.sql("SELECT * FROM table")');
  });

  it('should replace existing magic line with new one', function () {
    const existingContent = '%%pyspark old-connection\ndf = spark.sql("SELECT * FROM table")';
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_SQL_VALUE,
      'new-connection',
      existingContent
    );
    
    expect(result).toBe('%%sql new-connection\ndf = spark.sql("SELECT * FROM table")');
  });

  it('should handle empty content with magic commands', function () {
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_PYSPARK_VALUE,
      'test-connection',
      ''
    );
    
    expect(result).toBe('%%pyspark test-connection\n\n');
  });

  it('should handle multiline content', function () {
    const existingContent = 'line1\nline2\nline3';
    const result = createNewCellSourceForCell(
      Constants.INTERPRETER_PYSPARK_VALUE,
      'test-connection',
      existingContent
    );
    
    expect(result).toBe('%%pyspark test-connection\nline1\nline2\nline3');
  });
});

describe('test getMagicLineFromInterpreterAndConnection', () => {
  it('should generate correct PySpark magic line', function () {
    const result = getMagicLineFromInterpreterAndConnection(
      Constants.INTERPRETER_PYSPARK_VALUE,
      'test-connection'
    );
    
    expect(result).toBe('%%pyspark test-connection\n');
  });

  it('should generate correct SQL magic line', function () {
    const result = getMagicLineFromInterpreterAndConnection(
      Constants.INTERPRETER_SQL_VALUE,
      'test-connection'
    );
    
    expect(result).toBe('%%sql test-connection\n');
  });

  it('should generate correct Scala Spark magic line', function () {
    const result = getMagicLineFromInterpreterAndConnection(
      Constants.INTERPRETER_SCALA_SPARK_VALUE,
      'test-connection'
    );
    
    expect(result).toBe('%%scalaspark test-connection\n');
  });

  it('should generate correct Local Python magic line', function () {
    const result = getMagicLineFromInterpreterAndConnection(
      Constants.INTERPRETER_LOCAL_PYTHON_VALUE,
      'test-connection'
    );
    
    expect(result).toBe('%%local test-connection\n');
  });
});

describe('test isCellStartWithSupportedMagics', () => {
  it('should detect PySpark magic', function () {
    expect(isCellStartWithSupportedMagics('%%pyspark connection')).toBe(true);
  });

  it('should detect SQL magic', function () {
    expect(isCellStartWithSupportedMagics('%%sql connection')).toBe(true);
  });

  it('should detect Scala Spark magic', function () {
    expect(isCellStartWithSupportedMagics('%%scalaspark connection')).toBe(true);
  });

  it('should detect Local magic', function () {
    expect(isCellStartWithSupportedMagics('%%local connection')).toBe(true);
  });

  it('should not detect non-magic content', function () {
    expect(isCellStartWithSupportedMagics('print("hello")')).toBe(false);
  });

  it('should not detect commented magic', function () {
    expect(isCellStartWithSupportedMagics('# %%pyspark connection')).toBe(false);
  });
});
