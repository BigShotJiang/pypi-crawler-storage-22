class StartSessionException(RuntimeError):
    pass


class StopSessionException(RuntimeError):
    pass


class NoSessionException(RuntimeError):
    pass


class LanguageNotSupportedException(RuntimeError):
    pass


class NotAllowedSecondaryMagicException(RuntimeError):
    pass


class ConnectionNotFoundException(RuntimeError):
    """
    Exception raised when SageMaker connection name is not found in
    existing connections
    """
    pass


class ConnectionNotSupportedException(RuntimeError):
    """
    Exception raised when SageMaker connection type provided by
    customer is not supported.
    """
    pass


class SessionExpiredError(RuntimeError):
    '''
    Exception raised when SageMaker connection session is expired
    '''
    pass

class AuthenticationError(RuntimeError):
    '''
    Exception raised when authentication fails when connecting to remote compute
    '''
    pass

class ConnectionDetailError(RuntimeError):
    '''
    Exception raised when SageMaker connection detail is invalid
    '''
    pass

class ExecutionException(RuntimeError):
    '''
    Exception raised when execution failed
    '''
    pass

class RetrySignalException(Exception):
    """Generic signal exception for retry operations."""
    pass



def is_retryable_error(exception: Exception) -> bool:
    """Check if exception is retryable.
    
    Uses botocore's built-in retry logic which provides:
    - Rich analysis for AWS SDK exceptions (error codes, HTTP status, service patterns)
    - Basic analysis for network exceptions (ConnectionError, TimeoutError, etc.)
    """
    from botocore.retries.standard import StandardRetryConditions, RetryContext
    
    # Use botocore's comprehensive retry logic
    checker = StandardRetryConditions()
    
    # Build retry context: include parsed_response for AWS SDK exceptions
    parsed_response = exception.response if hasattr(exception, 'response') and isinstance(exception.response, dict) else None
    
    try:
        context = RetryContext(attempt_number=1, parsed_response=parsed_response, caught_exception=exception)
        return checker.is_retryable(context)
    except (AttributeError, TypeError):
        # Botocore checker requires AWS operation context which generic exceptions don't have
        # Return False for non-AWS exceptions
        return False