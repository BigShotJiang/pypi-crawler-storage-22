"""Retry utilities with exponential backoff and timeout handling.

This module uses a hybrid approach combining:
- Tenacity: Industry-standard Python retry framework for decorators/backoff
- Botocore: AWS SDK's battle-tested error detection logic

This provides AWS expertise for error classification with Python flexibility for retry behavior.
"""

import logging

from tenacity import (
    retry,
    stop_after_delay,
    wait_exponential_jitter,
    before_sleep_log,
    retry_if_exception_type,
    retry_if_exception,
    retry_any,
    RetryError
)

from .unified_retry_config import unified_retry_config

logger = logging.getLogger(__name__)

from .exceptions import is_retryable_error, RetrySignalException


def create_retry_decorator(operation_type: str):
    """Create retry decorator with exponential backoff and timeout conversion.
    
    This decorator retries the ENTIRE decorated method on any failure that matches
    the retry conditions. Each retry starts the method execution from the beginning.
    
    IMPORTANT: When retrying whole methods, be aware of:
    - Resource leaks: Clean up connections/sessions before each retry
    - External calls: Multiple API calls per retry can trigger rate limiting
    - State changes: Ensure methods are idempotent or reset state at method start
    
    Args:
        operation_type: Operation identifier (e.g., 'emr_serverless.get_application')
    
    Returns:
        Retry decorator that converts RetryError to RetryTimeoutException
        
    Retry Conditions:
        - RetrySignalException: Explicitly signals that a retry should occur
        - Transient errors: Network issues, temporary service unavailability, etc.
        
    Behavior:
        - Uses exponential backoff with jitter to avoid thundering herd
        - Retries until max_timeout is reached (not max attempts)
        - On timeout, raises RetryTimeoutException with configuration details
    """
    retry_config = unified_retry_config.get_config(operation_type)
    
    retry_conditions = [
        retry_if_exception_type(RetrySignalException),
        retry_if_exception(is_retryable_error)
    ]
    
    def wrapper(func):  # Decorator factory that creates the actual decorator
        retry_decorator = retry(
            stop=stop_after_delay(retry_config['max_timeout']),
            wait=wait_exponential_jitter(
                initial=retry_config['initial_delay'],
                max=retry_config['max_delay'],
                exp_base=retry_config['backoff_factor']
            ),
            retry=retry_any(*retry_conditions),
            before_sleep=before_sleep_log(logger, log_level=logging.DEBUG),
            reraise=False  # Raises RetryError when max attempts/timeout reached
        )
        
        def inner(*args, **kwargs):
            return retry_decorator(func)(*args, **kwargs)
        
        return inner
    
    return wrapper