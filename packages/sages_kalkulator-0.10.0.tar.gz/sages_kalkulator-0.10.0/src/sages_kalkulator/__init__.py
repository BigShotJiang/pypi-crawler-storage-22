__version__ = "0.10.0"

from .calculator import add, subtract, multiply, divide

__all__ = ["add", "subtract", "multiply", "divide"]
