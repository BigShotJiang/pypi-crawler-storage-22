#from .calculator import add, subtract, multiply, divide
from .calculator import add, subtract, multiply, divide, load_model, predict

__version__ = '0.5.0'