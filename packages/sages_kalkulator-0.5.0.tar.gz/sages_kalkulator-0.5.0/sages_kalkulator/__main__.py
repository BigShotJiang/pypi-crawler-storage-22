import argparse

from .calculator import predict

def main():
    parser = argparse.ArgumentParser(description="Kalkulator")
    parser.add_argument("--sepal-length", type=float, help="Długość działki")
    parser.add_argument("--sepal-width", type=float, help="Szerokość działki")
    parser.add_argument("--petal-length", type=float, help="Długość płatka")
    parser.add_argument("--petal-width", type=float, help="Szerokość płatka")
    args = parser.parse_args()

    prediction = predict([args.sepal_length, args.sepal_width, args.petal_length, args.petal_width])
    print(f"Przewidziana klasa: {prediction}")

if __name__ == "__main__":
    main()

# Użycie
# python -m sages_kalkulator --sepal-length 5.1 --sepal-width 3.5 --petal-length 1.4 --petal-width 0.2
# iris-classifier --sepal-length 5.1 --sepal-width 3.5 --petal-length 1.4 --petal-width 0.2