def add(a, b):
    """Dodaje dwie liczby."""
    return a + b

def subtract(a, b):
    """Odejmuje b od a."""
    return a - b

def multiply(a, b):
    """Mnoży dwie liczby."""
    return a * b

def divide(a, b):
    """Dzieli a przez b."""
    if b == 0:
        raise ValueError("Nie można dzielić przez zero!")
    return a / b

# dodany w drugiej wersji

import joblib
import importlib.resources as pkg_resources
from . import models

def load_model():
    """Ładuje wytrenowany model."""
    with pkg_resources.path(models, 'iris_model.joblib') as model_path:
        model = joblib.load(str(model_path))
    return model

def predict(features):
    """Dokonuje predykcji używając modelu."""
    model = load_model()
    return model.predict([features])[0]


# example usage
# Przykład użycia modelu:
#
# # Import modułu
# from sages_kalkulator import predict
#
# # Przygotowanie cech dla modelu (np. dla modelu klasyfikacji irysów)
# features = [5.1, 3.5, 1.4, 0.2]
#
# # Wykonanie predykcji
# prediction = predict(features)
# print(f"Przewidziana klasa: {prediction}")
#
# # Można również załadować model bezpośrednio
# from sages_kalkulator import load_model
# model = load_model()
# prediction = model.predict([[5.1, 3.5, 1.4, 0.2]])[0]
# print(f"Przewidziana klasa: {prediction}")
