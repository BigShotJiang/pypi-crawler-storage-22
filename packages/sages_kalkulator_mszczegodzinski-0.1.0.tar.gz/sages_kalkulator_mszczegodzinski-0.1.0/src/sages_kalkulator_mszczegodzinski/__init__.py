__version__ = "0.1.0"

from .calculator import add, subtract, multiply, divide

__all__ = ["add", "subtract", "multiply", "divide"]