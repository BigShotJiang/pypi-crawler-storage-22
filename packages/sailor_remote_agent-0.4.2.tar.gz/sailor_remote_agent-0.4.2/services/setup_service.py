"""Service module for handling exam setup scripts on application startup."""

import json
import logging
import os
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


class SetupService:
    """Service class for managing exam setup operations."""
    
    SETUP_MARKER_FILE = "/tmp/marker"
    
    def __init__(self, exam_asset_path: str, ssh_service):
        """
        Initialize SetupService.
        
        Args:
            exam_asset_path: Path to the directory containing exam.json
            ssh_service: Instance of SSHService for executing scripts
        """
        self.exam_asset_path = exam_asset_path
        self.ssh_service = ssh_service
        self.exam_json_path = os.path.join(exam_asset_path, "exam.json")
    
    def is_setup_completed(self) -> bool:
        """
        Check if setup has already been completed.
        
        Returns:
            True if setup marker file exists, False otherwise
        """
        return os.path.exists(self.SETUP_MARKER_FILE)
    
    def mark_setup_completed(self) -> None:
        """Create marker file to indicate setup is complete."""
        try:
            with open(self.SETUP_MARKER_FILE, 'w') as f:
                f.write("Setup completed successfully\n")
            logger.info(f"Setup marker file created: {self.SETUP_MARKER_FILE}")
        except Exception as e:
            logger.error(f"Failed to create setup marker file: {e}")
    
    def load_exam_data(self) -> Optional[Dict]:
        """
        Load exam data from exam.json file.
        
        Returns:
            Parsed exam data dictionary or None if file doesn't exist/invalid
        """
        if not os.path.exists(self.exam_json_path):
            logger.warning(f"Exam file not found: {self.exam_json_path}")
            return None
        
        try:
            with open(self.exam_json_path, 'r') as f:
                data = json.load(f)
            logger.info("Exam data loaded successfully")
            return data
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse exam.json: {e}")
            return None
        except Exception as e:
            logger.error(f"Error reading exam.json: {e}")
            return None
    
    def extract_setup_scripts(self, exam_data: Dict) -> List[Dict]:
        """
        Extract setup scripts from exam data.
        
        Args:
            exam_data: Parsed exam data from exam.json
            
        Returns:
            List of dictionaries containing machine_hostname and scripts
        """
        setup_tasks = []
        
        if not exam_data.get('success'):
            logger.warning("Exam data indicates failure")
            return setup_tasks
        
        lab = exam_data.get('data', {}).get('lab', {})
        questions = lab.get('questions', [])
        
        for question in questions:
            question_id = question.get('_id', 'unknown')
            question_order = question.get('question_order', 0)
            question_type = question.get('question_type')
            
            # Only process performance type questions
            if question_type != 'performance':
                continue
            
            performance_data = question.get('performance_data', {})
            machine_hostname = performance_data.get('machine_hostname')
            setup_scripts = performance_data.get('setup_scripts', {})
            steps = setup_scripts.get('steps', [])
            
            if not machine_hostname:
                logger.warning(f"Question {question_id} has no machine_hostname")
                continue
            
            if not steps:
                logger.info(f"Question {question_id} has no setup scripts")
                continue
            
            # Sort steps by order
            sorted_steps = sorted(steps, key=lambda x: x.get('order', 0))
            
            setup_tasks.append({
                'question_id': question_id,
                'question_order': question_order,
                'machine_hostname': machine_hostname,
                'steps': sorted_steps
            })
        
        return setup_tasks
    
    def execute_setup_scripts(self, setup_tasks: List[Dict]) -> Dict:
        """
        Execute setup scripts on remote machines.
        
        Args:
            setup_tasks: List of setup tasks with scripts to execute
            
        Returns:
            Dictionary with execution summary
        """
        results = {
            'total_tasks': len(setup_tasks),
            'successful': 0,
            'failed': 0,
            'details': []
        }
        
        for task in setup_tasks:
            question_id = task['question_id']
            question_order = task['question_order']
            machine_hostname = task['machine_hostname']
            steps = task['steps']
            
            logger.info(
                f"Executing setup for Question {question_order} "
                f"(ID: {question_id}) on {machine_hostname}"
            )
            
            task_result = {
                'question_id': question_id,
                'question_order': question_order,
                'machine_hostname': machine_hostname,
                'steps_executed': 0,
                'steps_failed': 0,
                'step_details': []
            }
            
            for step in steps:
                step_order = step.get('order', 0)
                step_description = step.get('description', 'No description')
                script_content = step.get('script_content', '')
                
                if not script_content:
                    logger.warning(
                        f"Question {question_order}, Step {step_order}: "
                        f"Empty script content"
                    )
                    continue
                
                logger.info(
                    f"  Executing Step {step_order}: {step_description}"
                )
                
                # Execute script via SSH
                exec_result = self.ssh_service.execute_script(
                    hostname=machine_hostname,
                    script_content=script_content,
                    max_retries=3
                )
                
                step_detail = {
                    'order': step_order,
                    'description': step_description,
                    'success': exec_result['success'],
                    'exit_code': exec_result['exit_code'],
                    'attempts': exec_result['attempts']
                }
                
                task_result['step_details'].append(step_detail)
                task_result['steps_executed'] += 1
                
                if exec_result['success']:
                    logger.info(
                        f"  Step {step_order} completed successfully "
                        f"(exit code: {exec_result['exit_code']})"
                    )
                else:
                    logger.error(
                        f"  Step {step_order} failed "
                        f"(exit code: {exec_result['exit_code']}): "
                        f"{exec_result['error']}"
                    )
                    task_result['steps_failed'] += 1
            
            results['details'].append(task_result)
            
            if task_result['steps_failed'] == 0:
                results['successful'] += 1
                logger.info(
                    f"Question {question_order} setup completed successfully"
                )
            else:
                results['failed'] += 1
                logger.warning(
                    f"Question {question_order} setup completed with "
                    f"{task_result['steps_failed']} failed steps"
                )
        
        return results
    
    def run_setup(self) -> bool:
        """
        Main method to run setup process.
        
        Returns:
            True if setup was successful, False otherwise
        """
        # Check if setup already completed
        if self.is_setup_completed():
            logger.info("Setup already completed (marker file exists), skipping")
            return True
        
        logger.info("Starting exam setup process...")
        
        # Load exam data
        exam_data = self.load_exam_data()
        if not exam_data:
            logger.error("Failed to load exam data, skipping setup")
            return False
        
        # Extract setup scripts
        setup_tasks = self.extract_setup_scripts(exam_data)
        if not setup_tasks:
            logger.info("No setup scripts to execute")
            self.mark_setup_completed()
            return True
        
        logger.info(f"Found {len(setup_tasks)} questions with setup scripts")
        
        # Execute setup scripts
        results = self.execute_setup_scripts(setup_tasks)
        
        # Log summary
        logger.info("=" * 60)
        logger.info("Setup Summary:")
        logger.info(f"  Total tasks: {results['total_tasks']}")
        logger.info(f"  Successful: {results['successful']}")
        logger.info(f"  Failed: {results['failed']}")
        logger.info("=" * 60)
        
        # Mark setup as completed even if some scripts failed
        # (to prevent repeated attempts on restart)
        self.mark_setup_completed()
        
        return results['failed'] == 0
