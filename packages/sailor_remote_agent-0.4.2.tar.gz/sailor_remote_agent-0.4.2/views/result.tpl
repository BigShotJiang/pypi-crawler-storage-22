<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assessment Results</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
            background-color: #fff;
            color: #2d2f31;
            line-height: 1.6;
        }
        
        /* Navbar */
        .navbar {
            background: #fff;
            border-bottom: 1px solid #d1d7dc;
            padding: 16px 24px;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .navbar-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: #1c1d1f;
        }
        
        .navbar-links {
            display: flex;
            gap: 24px;
            align-items: center;
        }
        
        .navbar-link {
            color: #1c1d1f;
            text-decoration: none;
            font-size: 0.875rem;
            font-weight: 600;
            padding: 8px 0;
            transition: color 0.2s;
        }
        
        .navbar-link:hover {
            color: #5624d0;
        }
        
        .navbar-link.active {
            color: #5624d0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 24px;
        }
        
        /* Header Section */
        .header {
            background: #fff;
            padding: 0 0 32px 0;
            margin-bottom: 40px;
            border-bottom: 1px solid #d1d7dc;
        }
        
        .header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 20px;
            color: #1c1d1f;
        }
        
        /* Stats Cards (matching answer page style) */
        .stats-cards {
            display: flex;
            gap: 32px;
            flex-wrap: wrap;
            margin-bottom: 40px;
        }
        
        .stat-card {
            display: flex;
            flex-direction: column;
            padding: 16px;
            border: 1px solid #d1d7dc;
            border-radius: 4px;
            background: #fff;
            min-width: 120px;
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: #6a6f73;
            margin-bottom: 8px;
        }
        
        .stat-value {
            font-size: 1rem;
            font-weight: 600;
            color: #1c1d1f;
        }
        
        .questions-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1c1d1f;
            margin-bottom: 24px;
        }
        
        /* Question Card */
        .question-card {
            background: #fff;
            padding: 32px;
            margin-bottom: 24px;
            border: 1px solid #d1d7dc;
        }
        
        .question-header {
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid #d1d7dc;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .question-info {
            display: flex;
            align-items: center;
            flex: 1;
        }
        
        .question-number {
            background: #1c1d1f;
            color: white;
            width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            font-size: 0.875rem;
            font-weight: 700;
            margin-right: 12px;
            flex-shrink: 0;
        }
        
        .question-title {
            flex: 1;
            font-size: 1.25rem;
            font-weight: 700;
            color: #1c1d1f;
            line-height: 1.4;
        }
        
        .question-score {
            background: #f7f9fa;
            padding: 8px 16px;
            border: 1px solid #d1d7dc;
            font-weight: 700;
            white-space: nowrap;
            margin-left: 16px;
            color: #1c1d1f;
        }
        
        /* Performance Data */
        .performance-data {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }
        
        .performance-item {
            padding: 8px 12px;
            background: #f7f9fa;
            border: 1px solid #d1d7dc;
            font-size: 0.875rem;
        }
        
        .performance-label {
            font-weight: 600;
            margin-right: 4px;
            color: #6a6f73;
        }
        
        .performance-value {
            font-family: 'Monaco', 'Courier New', monospace;
            color: #1c1d1f;
        }
        
        /* Steps */
        .steps-section {
            margin-top: 24px;
        }
        
        .steps-title {
            font-size: 1rem;
            font-weight: 700;
            color: #1c1d1f;
            margin-bottom: 12px;
        }
        
        .step-item {
            background: #f7f9fa;
            padding: 16px;
            margin-bottom: 12px;
            border: 1px solid #d1d7dc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .step-description {
            font-weight: 600;
            color: #1c1d1f;
            flex: 1;
        }
        
        .step-status {
            font-weight: 600;
            padding: 6px 16px;
            border: 1px solid #d1d7dc;
            background: #f7f9fa;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #1c1d1f;
        }
        
        /* Error State */
        .error-message {
            background: #fcebea;
            color: #c0392b;
            padding: 24px;
            border-left: 4px solid #c0392b;
            margin: 24px 0;
        }
        
        /* Footer */
        .footer {
            margin-top: 60px;
            padding-top: 24px;
            border-top: 1px solid #d1d7dc;
            text-align: center;
            color: #6a6f73;
            font-size: 0.875rem;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 24px 16px;
            }
            
            .navbar-content {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }
            
            .navbar-links {
                gap: 16px;
            }
            
            .header h1 {
                font-size: 1.5rem;
            }
            
            .question-card {
                padding: 20px;
            }
            
            .question-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .question-score {
                margin-left: 0;
                margin-top: 12px;
            }
            
            .stats-cards {
                gap: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="navbar-content">
            <div class="navbar-title">Sailor.sh</div>
            <div class="navbar-links">
                <a href="/questions" class="navbar-link">Questions</a>
                <a href="/answer" class="navbar-link">Answers</a>
                <a href="/result" class="navbar-link active">Results</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        % if error:
        <div class="error-message">
            <strong>Notice:</strong> {{error}}
        </div>
        % else:
        
        <!-- Header Section -->
        <div class="header">
            <h1>{{exam_summary.get('name', 'Assessment')}} - Results</h1>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-label">Your Score</div>
                <div class="stat-value">{{total_points_awarded}}/{{total_possible_points}}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Percentage</div>
                <div class="stat-value">{{percentage}}%</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Questions</div>
                <div class="stat-value">{{len(results)}}</div>
            </div>
        </div>
        
        <!-- Questions Title -->
        <h2 class="questions-title">Questions ({{len(results)}})</h2>
        
        <!-- Results Section -->
        % for result in results:
        <div class="question-card">
            <div class="question-header">
                <div class="question-info">
                    <div class="question-number">{{result['question_order']}}</div>
                    <h2 class="question-title">{{result['question_title']}}</h2>
                </div>
                <div class="question-score">
                    {{result['total_points_awarded']}}/{{result['total_possible_points']}} points
                </div>
            </div>
            
            <!-- Performance Data -->
            % if result.get('performance_data'):
            <div class="performance-data">
                <div class="performance-item">
                    <span class="performance-label">Hostname:</span>
                    <span class="performance-value">{{result['performance_data'].get('machine_hostname', 'N/A')}}</span>
                </div>
                <div class="performance-item">
                    <span class="performance-label">Namespace:</span>
                    <span class="performance-value">{{result['performance_data'].get('namespace', 'N/A')}}</span>
                </div>
            </div>
            % end
            
            <!-- Verification Steps -->
            % if result.get('steps'):
            <div class="steps-section">
                <div class="steps-title">Verification Steps</div>
                % for step in result['steps']:
                <div class="step-item {{('success' if step['success'] else 'failed')}}">
                    <div class="step-description">{{step['description']}}</div>
                    <div class="step-status">
                        {{('Correct' if step['success'] else 'Incorrect')}}
                    </div>
                </div>
                % end
            </div>
            % end
        </div>
        % end
        
        % end
        
        <!-- Footer -->
        <div class="footer">
            All rights reserved sailor.sh
        </div>
    </div>
</body>
</html>
