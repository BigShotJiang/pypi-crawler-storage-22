# sales-model

This folder (`model/`) is a standalone Python package you can build and publish to PyPI.

It includes:
- `sales_model/`: the core sales brain + supporting utilities
- `app/`: a FastAPI-based voice/API gateway

## Local install (editable)

From the repo root:

```bash
cd model
python -m pip install -U pip
python -m pip install -e .
```

Quick sanity check:

```bash
python -c "from sales_model import SalesBrain; print(SalesBrain)"
```

## Build

```bash
cd model
python -m pip install -U build
python -m build
```

Artifacts land in `model/dist/`:
- `*.whl`
- `*.tar.gz`

## Upload to PyPI

For CI/CD via GitHub Actions (Trusted Publishing), see `PYPI_PUBLISHING.md`.

Create an account/token on PyPI first, then:

```bash
cd model
python -m pip install -U twine
python -m twine upload dist/*
```

## Using the package

Install:

```bash
pip install sales-model
```

Run the CLI:

```bash
sales-brain
```

Run the API (example):

```bash
uvicorn app.main:app --reload
# or
uvicorn app.main_v2:app --reload
```
