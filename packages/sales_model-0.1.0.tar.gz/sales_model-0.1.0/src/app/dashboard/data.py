"""
Dashboard data access layer - provides data operations for dashboard functionality.

This module serves as the main entry point for dashboard data operations.
It imports all operations from the PostgreSQL implementation.
"""
from __future__ import annotations

# Import all functions and classes from PostgreSQL implementation
from app.dashboard.postgres_data import (
    # Exceptions
    DataAccessError,
    UserNotFoundError,
    OrganizationNotFoundError,
    ApiKeyNotFoundError,
    
    # User Operations
    create_user,
    get_user_by_email,
    get_user_by_id,
    update_user_login,
    update_user_profile,
    change_password,
    
    # Organization Operations
    create_organization,
    get_organization_by_id,
    get_user_organization,
    update_organization,
    
    # API Key Operations
    create_api_key,
    get_organization_api_keys,
    revoke_api_key,
    
    # Dashboard Statistics
    get_dashboard_stats,
    
    # Activity Log
    add_activity,
    get_organization_activities,
    
    # Usage Analytics
    get_usage_stats,
    
    # Billing and Plans
    get_available_plans,
    
    # Team Management
    get_team_members,
    invite_team_member_to_org,
    update_member_role,
    remove_team_member_from_org,
    
    # Subscription Management
    get_subscription_details,
    upgrade_organization_plan,
    
    # Analytics
    get_analytics_data,
    get_detailed_usage_analytics,
    
    # Settings
    get_user_settings,
    update_user_settings,
    
    # Password Utilities
    hash_password,
    verify_password,
    
    # Demo Data
    init_demo_data,
)

# Re-export everything for backward compatibility
__all__ = [
    # Exceptions
    "DataAccessError",
    "UserNotFoundError", 
    "OrganizationNotFoundError",
    "ApiKeyNotFoundError",
    
    # User Operations
    "create_user",
    "get_user_by_email",
    "get_user_by_id",
    "update_user_login",
    "update_user_profile",
    "change_password",
    
    # Organization Operations
    "create_organization",
    "get_organization_by_id",
    "get_user_organization",
    "update_organization",
    
    # API Key Operations
    "create_api_key",
    "get_organization_api_keys",
    "revoke_api_key",
    
    # Dashboard Statistics
    "get_dashboard_stats",
    
    # Activity Log
    "add_activity",
    "get_organization_activities",
    
    # Usage Analytics
    "get_usage_stats",
    
    # Billing and Plans
    "get_available_plans",
    
    # Team Management
    "get_team_members",
    "invite_team_member_to_org",
    "update_member_role",
    "remove_team_member_from_org",
    
    # Subscription Management
    "get_subscription_details",
    "upgrade_organization_plan",
    
    # Analytics
    "get_analytics_data",
    "get_detailed_usage_analytics",
    
    # Settings
    "get_user_settings",
    "update_user_settings",
    
    # Password Utilities
    "hash_password",
    "verify_password",
    
    # Demo Data
    "init_demo_data",
]