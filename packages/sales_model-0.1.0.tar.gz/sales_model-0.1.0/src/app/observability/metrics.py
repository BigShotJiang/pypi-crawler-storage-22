from __future__ import annotations


def record_latency(_: str, __: float) -> None:
    return


def increment(_: str, __: int = 1) -> None:
    return
