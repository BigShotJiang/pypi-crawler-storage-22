from __future__ import annotations


def start_span(_: str):
    return None
