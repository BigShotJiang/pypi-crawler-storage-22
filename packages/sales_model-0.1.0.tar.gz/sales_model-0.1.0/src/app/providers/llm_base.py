from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass
class LLMResult:
    text: str
    metadata: Dict[str, str]


class LLMProvider:
    async def generate(self, prompt: str) -> LLMResult:
        raise NotImplementedError
