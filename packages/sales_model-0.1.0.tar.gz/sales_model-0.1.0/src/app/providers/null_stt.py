from __future__ import annotations

import asyncio
from typing import AsyncIterator

from app.providers.stt_base import STTProvider, STTStream, TranscriptEvent


class NullSTTStream(STTStream):
    def __init__(self) -> None:
        self._closed = asyncio.Event()

    async def send_audio(self, _: bytes) -> None:
        return

    async def end(self) -> None:
        self._closed.set()

    async def results(self) -> AsyncIterator[TranscriptEvent]:
        await self._closed.wait()
        if False:
            yield TranscriptEvent(text="", is_final=True)


class NullSTTProvider(STTProvider):
    async def start_stream(self, sample_rate: int) -> STTStream:
        _ = sample_rate
        return NullSTTStream()
