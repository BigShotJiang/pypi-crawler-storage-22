from __future__ import annotations

from typing import AsyncIterator, Optional

from app.providers.tts_base import TTSProvider


class NullTTSProvider(TTSProvider):
    async def synthesize_stream(self, text: str, voice: Optional[str] = None) -> AsyncIterator[bytes]:
        _ = text
        _ = voice
        if False:
            yield b""
