from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator, Optional


@dataclass
class TranscriptEvent:
    text: str
    is_final: bool
    confidence: Optional[float] = None


class STTStream:
    async def send_audio(self, _: bytes) -> None:
        raise NotImplementedError

    async def end(self) -> None:
        raise NotImplementedError

    async def results(self) -> AsyncIterator[TranscriptEvent]:
        raise NotImplementedError


class STTProvider:
    async def start_stream(self, sample_rate: int) -> STTStream:
        raise NotImplementedError
