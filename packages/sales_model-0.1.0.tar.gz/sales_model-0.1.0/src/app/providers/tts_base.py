from __future__ import annotations

from typing import AsyncIterator, Optional


class TTSProvider:
    async def synthesize_stream(self, text: str, voice: Optional[str] = None) -> AsyncIterator[bytes]:
        raise NotImplementedError
