from __future__ import annotations

from typing import Any, Dict

from sales_model.sales_brain import SalesBrain
from sales_model.schemas import BrainOutput


def merge_memory(memory: Dict[str, Any], output: BrainOutput) -> Dict[str, Any]:
    ex = output.extracted.to_dict()
    for k, v in ex.items():
        if v in (None, "", []):
            continue
        if k not in memory or memory.get(k) in (None, "", []):
            memory[k] = v
    if output.meta:
        memory["_meta"] = output.meta
    return memory


class SalesBrainEngine:
    def __init__(self) -> None:
        self._brain = SalesBrain()

    def run_turn(self, state: str, user_message: str, memory: Dict[str, Any]) -> BrainOutput:
        return self._brain.run_turn(state, user_message, memory=memory)
