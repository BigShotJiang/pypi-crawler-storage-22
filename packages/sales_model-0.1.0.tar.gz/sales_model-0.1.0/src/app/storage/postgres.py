from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class VoiceSessionRecord:
    sid: str
    user_id: str
    org_id: Optional[str]
    plan: str


def save_session(_: VoiceSessionRecord) -> None:
    # Placeholder: persist session metadata in Postgres.
    return
