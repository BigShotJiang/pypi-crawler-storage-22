from __future__ import annotations


def pcm16_bytes_to_seconds(num_bytes: int, sample_rate: int, channels: int = 1) -> float:
    if sample_rate <= 0 or channels <= 0:
        return 0.0
    bytes_per_sample = 2
    return num_bytes / float(sample_rate * channels * bytes_per_sample)
