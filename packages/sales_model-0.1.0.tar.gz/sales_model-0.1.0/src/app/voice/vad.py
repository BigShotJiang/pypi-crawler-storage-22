from __future__ import annotations


def is_speech(_: bytes, __: int) -> bool:
    # Placeholder for webrtcvad or client-side VAD.
    return False
