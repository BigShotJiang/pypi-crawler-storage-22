"""Sales model (brain) + supporting utilities.

This package is intended to be built and published from the `model/` folder.
"""

from .sales_brain import SalesBrain

__all__ = ["SalesBrain"]
