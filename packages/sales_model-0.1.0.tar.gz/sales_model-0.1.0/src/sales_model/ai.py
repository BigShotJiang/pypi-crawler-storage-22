from __future__ import annotations

import os

from openai import AzureOpenAI


def main() -> None:
    try:
        from dotenv import load_dotenv
    except Exception:
        load_dotenv = None

    if load_dotenv:
        load_dotenv()

    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    api_key = os.getenv("AZURE_OPENAI_KEY")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")

    if not endpoint or not deployment or not api_key:
        raise RuntimeError(
            "Missing required env vars: AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_KEY"
        )

    client = AzureOpenAI(
        api_version=api_version,
        azure_endpoint=endpoint,
        api_key=api_key,
    )

    content = input("Enter your product/service query: ")

    response = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": (
                    "You are an expert sales agent helping businesses close deals like a real sales representative. "
                    "Assist and close clients using skills like those of Joe Girard (The Volume King)."
                ),
            },
            {"role": "user", "content": content},
        ],
        max_completion_tokens=16384,
        model=deployment,
    )

    print(response.choices[0].message.content)


if __name__ == "__main__":
    main()