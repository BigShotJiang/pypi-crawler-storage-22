# config.py
import os

try:
    from dotenv import load_dotenv
except Exception:
    load_dotenv = None

if load_dotenv:
    # Rely on default dotenv discovery (typically the working directory's .env).
    load_dotenv()

AZURE_OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
AZURE_OPENAI_KEY = os.getenv('AZURE_OPENAI_KEY')
AZURE_OPENAI_API_VERSION = os.getenv('AZURE_OPENAI_API_VERSION', '2024-12-01-preview')
AZURE_OPENAI_DEPLOYMENT = os.getenv('AZURE_OPENAI_DEPLOYMENT')
AZURE_OPENAI_TEMPERATURE = float(os.getenv('AZURE_OPENAI_TEMPERATURE', '1.0'))
AZURE_OPENAI_MAX_TOKENS = int(os.getenv('AZURE_OPENAI_MAX_TOKENS', '800'))

# Optional business integrations
CRM_WEBHOOK_URL = os.getenv('CRM_WEBHOOK_URL')
CRM_WEBHOOK_TIMEOUT = float(os.getenv('CRM_WEBHOOK_TIMEOUT', '5'))

# Budget sanity thresholds (USD)
HIGH_BUDGET_THRESHOLD = int(os.getenv('SALES_HIGH_BUDGET_THRESHOLD', '2500'))
DEV_LAPTOP_HIGH_BUDGET_THRESHOLD = int(os.getenv('SALES_DEV_LAPTOP_HIGH_BUDGET_THRESHOLD', '3000'))

def validate_config():
    missing = []
    if not AZURE_OPENAI_ENDPOINT:
        missing.append('AZURE_OPENAI_ENDPOINT')
    if not AZURE_OPENAI_KEY:
        missing.append('AZURE_OPENAI_KEY')
    if not AZURE_OPENAI_DEPLOYMENT:
        missing.append('AZURE_OPENAI_DEPLOYMENT')
    if missing:
        raise RuntimeError(f"Missing env vars: {', '.join(missing)}")
