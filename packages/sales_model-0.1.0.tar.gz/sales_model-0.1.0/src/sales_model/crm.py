from typing import Any, Dict

import httpx

from .config import CRM_WEBHOOK_TIMEOUT, CRM_WEBHOOK_URL


def send_crm_webhook(payload: Dict[str, Any]) -> bool:
    if not CRM_WEBHOOK_URL:
        return False
    try:
        response = httpx.post(
            CRM_WEBHOOK_URL,
            json=payload,
            timeout=CRM_WEBHOOK_TIMEOUT,
        )
        response.raise_for_status()
    except (httpx.HTTPError, ValueError):
        return False
    return True
