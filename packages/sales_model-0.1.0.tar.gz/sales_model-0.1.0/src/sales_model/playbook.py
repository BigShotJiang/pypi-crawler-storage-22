from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Literal, Optional

Vertical = Literal[
    "saas",
    "services",
    "retail",
    "art_luxury",
    "marketplace",
    "real_estate",
    "healthcare",
    "education",
    "other",
]
Channel = Literal["whatsapp", "web", "email", "voice"]
Tone = Literal["formal", "neutral", "casual", "luxury_minimal"]
Methodology = Literal["consultative", "challenger", "sandler"]


@dataclass
class TenantPlaybook:
    tenant_id: str
    vertical: Vertical
    channel_defaults: Dict[str, Channel]
    tone: Tone

    allowed_claims: List[str]
    forbidden_claims: List[str]
    pricing_policy: str
    close_policy: str

    version: int
    methodology: Methodology = "consultative"

    keywords: Optional[List[str]] = None
