from typing import Dict

from .prompt_compiler import CompileKey


class PromptCache:
    def __init__(self):
        self._cache: Dict[CompileKey, str] = {}

    def get(self, key: CompileKey) -> str | None:
        return self._cache.get(key)

    def set(self, key: CompileKey, prompt: str) -> None:
        self._cache[key] = prompt
