from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from .prompt_registry import (
    BASE_PROMPT,
    VERTICAL_MODULES,
    CHANNEL_MODULES,
    TONE_MODULES,
    METHODOLOGY_MODULES,
)


@dataclass(frozen=True)
class CompileKey:
    tenant_id: str
    vertical: str
    channel: str
    tone: str 
    methodology: str
    version: int


def compile_system_prompt(playbook, channel: str) -> str:
    vertical = playbook.vertical if playbook.vertical in VERTICAL_MODULES else "other"
    channel_key = channel if channel in CHANNEL_MODULES else "web"
    tone = playbook.tone if playbook.tone in TONE_MODULES else "neutral"
    methodology = playbook.methodology if playbook.methodology in METHODOLOGY_MODULES else "consultative"

    policy = f"""
Policies (must follow):
- Allowed claims: {", ".join(playbook.allowed_claims[:8])}
- Forbidden claims: {", ".join(playbook.forbidden_claims[:8])}
- Pricing policy: {playbook.pricing_policy}
- Close policy: {playbook.close_policy}
"""

    parts = [
        BASE_PROMPT.strip(),
        VERTICAL_MODULES[vertical].strip(),
        METHODOLOGY_MODULES[methodology].strip(),
        CHANNEL_MODULES[channel_key].strip(),
        TONE_MODULES[tone].strip(),
        policy.strip(),
    ]
    return "\n\n".join(parts)
