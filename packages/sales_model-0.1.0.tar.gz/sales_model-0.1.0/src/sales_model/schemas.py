# schemas.py
# structured output contract
# schemas.py
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Literal, Optional, Dict, Any, List

SalesState = Literal["GREETING", "DISCOVERY", "QUALIFICATION", "VALUE", "OBJECTIONS", "NEXT_STEP", "HANDOFF"]

@dataclass
class Extracted:
    buyer_role: Optional[str] = None
    company: Optional[str] = None
    email: Optional[str] = None
    industry: Optional[str] = None
    use_case: Optional[str] = None
    product: Optional[str] = None
    delivery_location: Optional[str] = None
    piece_id: Optional[str] = None
    authenticity_facts: Optional[str] = None
    offer_category: Optional[Literal["art", "software", "service", "retail"]] = None
    ml_intensity: Optional[Literal["none", "light", "medium", "heavy"]] = None
    os_preference: Optional[Literal["macos", "windows", "linux", "no_preference"]] = None
    budget_range: Optional[str] = None
    financial_sentiment: Optional[Literal["broke", "tight", "neutral", "comfortable"]] = None
    timeline: Optional[str] = None
    key_pain: Optional[str] = None
    objections: List[str] = None
    committed: Optional[bool] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if d["objections"] is None:
            d["objections"] = []
        return d

@dataclass
class BrainOutput:
    reply: str
    next_state: SalesState
    extracted: Extracted
    missing_fields: List[str]
    lead_score: int
    safety_flags: List[str]
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reply": self.reply,
            "next_state": self.next_state,
            "extracted": self.extracted.to_dict(),
            "missing_fields": self.missing_fields,
            "lead_score": self.lead_score,
            "safety_flags": self.safety_flags,
            "meta": self.meta,
        }

