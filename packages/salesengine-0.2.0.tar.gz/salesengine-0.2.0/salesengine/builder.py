"""Converts a filled questionnaire JSON into a ProjectConfig."""

import json
from typing import Dict
from salesengine.config import ProjectConfig


class ConfigBuilder:
    """
    Reads a filled-in questionnaire and produces a ProjectConfig.

    Usage::

        builder = ConfigBuilder('my_intake_filled.json')
        config = builder.build()
    """

    def __init__(self, questionnaire_path: str = None, questionnaire_dict: Dict = None):
        if questionnaire_path:
            with open(questionnaire_path, 'r') as f:
                self.q = json.load(f)
        elif questionnaire_dict:
            self.q = questionnaire_dict
        else:
            raise ValueError("Provide questionnaire_path or questionnaire_dict")

    def build(self) -> ProjectConfig:
        ctx = self.q.get('section_1_business_context', {})
        cfg = ProjectConfig(
            project_name=self._answer(ctx, 'project_name') or 'Unnamed Project',
            industry=self._answer(ctx, 'industry') or 'General',
        )

        # Field mapping
        mapping = self.q.get('section_2_field_mapping', {})
        for group_key, group_data in mapping.items():
            if group_key.startswith('_') or not isinstance(group_data, dict):
                continue
            # Skip hierarchy sections — handled separately below
            if group_key in ('org_hierarchy', 'geo_hierarchy'):
                continue
            for logical_name, field_info in group_data.items():
                if logical_name.startswith('_') or not isinstance(field_info, dict):
                    continue
                if 'your_answer' in field_info:
                    answer = field_info['your_answer']
                    cfg.fields[logical_name] = answer if answer and answer != 'null' else None

        # ── Organizational Hierarchy ──
        org_section = mapping.get('org_hierarchy', {})
        org_levels_info = org_section.get('levels', {})
        org_levels = org_levels_info.get('answer', []) if isinstance(org_levels_info, dict) else []
        if org_levels and isinstance(org_levels, list):
            cfg.org_hierarchy = []
            for level in org_levels:
                if isinstance(level, dict) and level.get('id'):
                    cfg.org_hierarchy.append({
                        'label': level.get('label', 'Level'),
                        'id': level['id'],
                        'name': level.get('name'),
                    })

        # ── Geographic Hierarchy ──
        geo_section = mapping.get('geo_hierarchy', {})
        geo_levels_info = geo_section.get('levels', {})
        geo_levels = geo_levels_info.get('answer', []) if isinstance(geo_levels_info, dict) else []
        if geo_levels and isinstance(geo_levels, list):
            cfg.geo_hierarchy = []
            for level in geo_levels:
                if isinstance(level, dict) and level.get('column'):
                    cfg.geo_hierarchy.append({
                        'label': level.get('label', 'Level'),
                        'column': level['column'],
                    })

        # ── Business rules → disabled functions ──
        rules = self.q.get('section_3_business_rules', {})

        churn_rules = rules.get('customer_churn', {})
        if not self._answer(churn_rules, 'enable_churn_analysis'):
            cfg.disabled_functions.add('classify_customer_movement')
            cfg.disabled_functions.add('determine_active_customers')

        # Churn activity window
        activity_window = self._answer(churn_rules, 'churn_activity_window')
        if activity_window and isinstance(activity_window, (int, float)) and activity_window > 0:
            cfg.churn_activity_window = int(activity_window)
        activity_field = self._answer(churn_rules, 'churn_activity_field')
        if activity_field:
            cfg.churn_activity_field = activity_field

        if not self._answer(rules.get('customer_acquisition', {}), 'enable_lead_scoring'):
            cfg.disabled_functions.add('identify_non_buyers')

        if not self._answer(rules.get('pricing_health', {}), 'enable_price_index'):
            cfg.disabled_functions.update({
                'calculate_price_index', 'classify_index', 'detect_index_conflicts'})

        if not self._answer(rules.get('margin_health', {}), 'enable_margin_analysis'):
            cfg.disabled_functions.add('assign_band')

        if not self._answer(rules.get('customer_value', {}), 'enable_priority_scoring'):
            cfg.disabled_functions.add('calculate_priority_score')

        # Report preferences
        prefs = self.q.get('section_5_report_preferences', {})
        analyses = prefs.get('analyses_to_run', {})
        for key, funcs in {'statistical_tests': ['run_statistical_summary', 'cramers_v', 'gini_coefficient']}.items():
            info = analyses.get(key, {})
            if isinstance(info, dict) and not info.get('answer', True):
                cfg.disabled_functions.update(funcs)

        # Thresholds
        thresh = self.q.get('section_4_thresholds', {})
        idx_t = thresh.get('index_thresholds', {})
        cfg.index_thresholds = {
            'extreme_high': self._answer(idx_t, 'extreme_high') or 1.50,
            'high': self._answer(idx_t, 'high') or 1.10,
            'low': self._answer(idx_t, 'low') or 0.90,
        }

        conf_t = thresh.get('confidence_thresholds', {})
        for dim in ['volume', 'coverage']:
            dim_t = conf_t.get(dim, {})
            for level in ['HIGH', 'MEDIUM', 'LOW']:
                if level in dim_t and isinstance(dim_t[level], dict):
                    val = dim_t[level].get('answer')
                    if val is not None:
                        cfg.confidence_thresholds.setdefault(dim, {})[level] = val

        margin_bands_raw = self._answer(rules.get('margin_health', {}), 'margin_bands')
        if margin_bands_raw and isinstance(margin_bands_raw, list):
            cfg.margin_bands = [(b[0], b[1]) for b in margin_bands_raw]

        return cfg

    @staticmethod
    def _answer(section: Dict, key: str, default=None):
        item = section.get(key, {})
        return item.get('answer', default) if isinstance(item, dict) else default
