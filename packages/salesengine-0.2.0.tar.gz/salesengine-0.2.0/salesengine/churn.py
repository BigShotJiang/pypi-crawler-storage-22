"""Customer churn and acquisition analysis."""

import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional
from salesengine.config import (
    ProjectConfig, get_global_config, _register, requires_fields
)


@_register('Customer & Churn', 'revman', required_fields=['customer_id'])
def classify_customer_movement(
    current_customers: set,
    prior_customers: set,
    parent_current: set = None,
    parent_prior: set = None,
    all_active_current: set = None,
    config: ProjectConfig = None
) -> Dict[str, Any]:
    """
    4-level customer movement classification.

    Distinguishes true churn from migration, segment shifts, and growth.
    Prevents the most common analytics mistake: over-counting churn.
    """
    cfg = config or get_global_config()
    empty = {'left_entirely': 0, 'left_segment': 0, 'migrated_out': 0,
             'migrated_in': 0, 'new_acquisition': 0, 'retained': 0,
             'retention_pct': 0}

    if not cfg.is_enabled('classify_customer_movement'):
        return empty

    left = prior_customers - current_customers
    joined = current_customers - prior_customers
    retained = current_customers & prior_customers

    left_entirely = left_segment = migrated_out = 0
    migrated_in = new_acquisition = 0

    for cust in left:
        if parent_current and cust in parent_current:
            migrated_out += 1
        elif all_active_current and cust in all_active_current:
            left_segment += 1
        else:
            left_entirely += 1

    for cust in joined:
        if parent_prior and cust in parent_prior:
            migrated_in += 1
        else:
            new_acquisition += 1

    retention_pct = (len(retained) / len(prior_customers) * 100
                     if len(prior_customers) > 0 else 0)

    return {
        'left_entirely': left_entirely,
        'left_segment': left_segment,
        'migrated_out': migrated_out,
        'migrated_in': migrated_in,
        'new_acquisition': new_acquisition,
        'retained': len(retained),
        'retention_pct': round(retention_pct, 1),
    }


@_register('Customer & Churn', 'salesengine v0.2.0',
           required_fields=['customer_id', 'volume_cy'])
def determine_active_customers(
    df: pd.DataFrame,
    config: ProjectConfig = None,
    verbose: bool = True,
) -> Dict[str, Any]:
    """
    Determine which customers are "active" using either:

    A) **Recency window** — purchased within last N periods from max date.
       Prevents counting a customer who bought once in week 1 and nothing
       since as "active" when you're looking at the data in week 26.

    B) **Simple volume** — any CY volume > 0 (fallback if no window set).

    Configure via::

        config.churn_activity_window = 6
        config.churn_activity_field = 'fiscal_week'

    Returns dict with 'current_active', 'prior_active' sets and metadata.
    """
    cfg = config or get_global_config()
    cid_col = cfg.col('customer_id')
    vol_cy = cfg.col('volume_cy')
    vol_py = cfg.col('volume_py')
    window = cfg.churn_activity_window
    time_field = cfg.churn_activity_field

    result = {
        'current_active': set(),
        'prior_active': set(),
        'activity_method': 'any_volume',
        'window_info': {},
    }

    # --- Method A: Recency window ---
    if window and window > 0:
        time_col = cfg.col(time_field)
        if time_col and time_col in df.columns and cid_col in df.columns:
            time_vals = pd.to_numeric(df[time_col], errors='coerce')

            if time_vals.notna().any():
                max_period = time_vals.max()
                cutoff = max_period - window

                if vol_cy and vol_cy in df.columns:
                    recent_mask = (time_vals > cutoff) & (df[vol_cy] > 0)
                    result['current_active'] = set(
                        df.loc[recent_mask, cid_col].unique()
                    )

                if vol_py and vol_py in df.columns:
                    result['prior_active'] = set(
                        df[df[vol_py] > 0][cid_col].unique()
                    )
                elif vol_cy and vol_cy in df.columns:
                    all_cy_buyers = set(df[df[vol_cy] > 0][cid_col].unique())
                    result['prior_active'] = all_cy_buyers

                result['activity_method'] = 'recency_window'
                result['window_info'] = {
                    'time_field': time_col,
                    'max_period': int(max_period),
                    'cutoff_period': int(cutoff),
                    'window_size': window,
                    'periods_in_data': int(time_vals.nunique()),
                }

                if verbose:
                    info = result['window_info']
                    print(f"   🔍 Churn: recency window = last {window} periods")
                    print(f"      Max period: {info['max_period']}, "
                          f"Cutoff: > {info['cutoff_period']}")
                    print(f"      Active (recent): {len(result['current_active'])}")
                    print(f"      Prior buyers: {len(result['prior_active'])}")

                return result

        if verbose:
            print(f"   ⚠️  Recency window requested but '{time_field}' "
                  f"not available, falling back to any_volume")

    # --- Method B: Simple volume > 0 ---
    if cid_col in df.columns:
        if vol_cy and vol_cy in df.columns:
            result['current_active'] = set(
                df[df[vol_cy] > 0][cid_col].unique()
            )
        if vol_py and vol_py in df.columns:
            result['prior_active'] = set(
                df[df[vol_py] > 0][cid_col].unique()
            )

    if verbose:
        print(f"   🔍 Churn: any volume > 0")
        print(f"      Current active: {len(result['current_active'])}")
        print(f"      Prior active: {len(result['prior_active'])}")

    return result


@_register('Customer & Churn', 'pmi_evaluation + revman',
           required_fields=['customer_id', 'affinity_field'])
@requires_fields('customer_id', 'affinity_field', returns_on_skip=pd.DataFrame())
def identify_non_buyers(
    customer_universe: pd.DataFrame,
    active_buyers: set,
    high_affinity_values: List[str],
    config: ProjectConfig = None
) -> pd.DataFrame:
    """
    Find high-affinity customers who should be buying but aren't.
    """
    cfg = config or get_global_config()
    cid_col = cfg.col('customer_id')
    aff_col = cfg.col('affinity_field')

    universe = customer_universe.copy()
    universe['_is_buyer'] = universe[cid_col].isin(active_buyers)
    universe['_high_affinity'] = universe[aff_col].isin(high_affinity_values)
    non_buyers = universe[(~universe['_is_buyer']) & (universe['_high_affinity'])].copy()
    return non_buyers.drop(columns=['_is_buyer', '_high_affinity'])
