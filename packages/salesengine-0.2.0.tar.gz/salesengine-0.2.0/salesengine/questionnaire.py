"""Generates a structured JSON questionnaire from scan results."""

import json
from typing import Dict, List
from datetime import datetime


class QuestionnaireGenerator:
    """
    Builds a JSON questionnaire with smart defaults from auto-detection.

    Sections:
      1. Business Context
      2. Field Mapping (with auto-detected defaults)
      3. Business Rules (churn, leads, growth, pricing, margin)
      4. Thresholds
      5. Report Preferences
    """

    def __init__(self, scan_profile: Dict):
        self.profile = scan_profile
        self.questionnaire = {}

    def generate(self) -> Dict:
        self.questionnaire = {
            '_meta': {
                'version': '1.0',
                'generated': datetime.now().isoformat(),
                'source_file': self.profile['file_info']['filename'],
                'total_columns': self.profile['file_info']['total_columns'],
                'rows_sampled': self.profile['file_info']['rows_sampled'],
                'instructions': (
                    "Fill in each section. Fields with 'auto_detected' have been "
                    "pre-filled — confirm or change them. Set to null to skip."
                ),
            },
            'section_1_business_context': self._build_business_context(),
            'section_2_field_mapping': self._build_field_mapping(),
            'section_3_business_rules': self._build_business_rules(),
            'section_4_thresholds': self._build_thresholds(),
            'section_5_report_preferences': self._build_report_preferences(),
        }
        return self.questionnaire

    def save(self, filepath: str):
        with open(filepath, 'w') as f:
            json.dump(self.questionnaire, f, indent=2, default=str)
        print(f"✅ Questionnaire saved to: {filepath}")

    def _build_business_context(self) -> Dict:
        return {
            '_instructions': "Tell us about your business.",
            'project_name': {'question': 'What is this project called?', 'answer': None,
                             'example': 'Q1 2025 Revenue Review'},
            'industry': {'question': 'What industry?', 'answer': None,
                         'options': ['Food Distribution', 'Retail', 'SaaS / Software',
                                     'Healthcare', 'Manufacturing', 'Financial Services',
                                     'Logistics', 'Hospitality', 'Other']},
            'unit_of_measure': {'question': 'Primary volume unit?', 'answer': None,
                                'example': 'lbs, cases, units, seats, licenses'},
            'currency': {'question': 'Currency?', 'answer': 'USD',
                         'options': ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'Other']},
            'time_grain': {'question': 'Time period per row?', 'answer': None,
                           'options': ['Weekly', 'Monthly', 'Quarterly', 'Annual', 'Transaction-level']},
            'comparison_type': {'question': 'Comparison type?', 'answer': None,
                                'options': ['Current Year vs Prior Year', 'Plan vs Actual',
                                            'This Quarter vs Last Quarter', 'None / Single Period']},
        }

    def _build_field_mapping(self) -> Dict:
        auto = self.profile.get('auto_mapping', {})
        all_cols = [c['column_name'] for c in self.profile['columns']]

        mapping = {
            '_instructions': "Confirm or correct auto-detected columns. Set to null to skip.",
            '_available_columns': all_cols,
        }

        field_groups = {
            'identifiers': {
                '_label': '🏷️  IDENTIFIERS — Customer & Product',
                'customer_id': 'Unique customer/account identifier (the end-user who buys)',
                'customer_name': 'Customer display name',
                'item_number': 'Product SKU / item number',
                'item_description': 'Product description',
            },
            'volume': {
                '_label': '📦  VOLUME',
                'volume_cy': 'Volume current period',
                'volume_py': 'Volume prior period',
                'delta_volume': 'Volume change',
            },
            'price_and_sales': {
                '_label': '💰  PRICE & SALES',
                'price_per_unit_cy': 'Price per unit current',
                'price_per_unit_py': 'Price per unit prior',
                'sales_ext_cy': 'Extended sales $ current',
                'sales_ext_py': 'Extended sales $ prior',
            },
            'margin': {
                '_label': '📊  MARGIN',
                'margin_per_unit_cy': 'Margin per unit current',
                'margin_per_unit_py': 'Margin per unit prior',
                'margin_ext_cy': 'Extended margin $ current',
                'margin_ext_py': 'Extended margin $ prior',
                'margin_pct_cy': 'Margin % current',
                'margin_pct_py': 'Margin % prior',
            },
            'time': {
                '_label': '📅  TIME',
                'fiscal_week': 'Fiscal week / period',
                'fiscal_year': 'Fiscal year',
                'invoice_date': 'Transaction date',
            },
            'segmentation': {
                '_label': '🏷️  SEGMENTATION',
                'segment': 'Customer segment / tier',
                'affinity_field': 'Affinity (cuisine, industry, SIC...)',
                'product_group': 'Product category code',
                'product_group_name': 'Product category name',
            },
            'pricing_structure': {
                '_label': '🏪  PRICING',
                'price_zone': 'Price zone / tier',
                'price_source': 'Price source type',
            },
            'benchmarking': {
                '_label': '📈  BENCHMARKING',
                'benchmark_price': 'Market / competitor price',
                'benchmark_volume': 'Market volume',
                'benchmark_coverage': 'Markets in benchmark',
                'benchmark_customers': 'Customers in benchmark',
            },
            'geography': {
                '_label': '🌍  GEOGRAPHY',
                'geography': 'Region / DMA / territory',
            },
        }

        for group_key, group_fields in field_groups.items():
            group_out = {'_label': group_fields.pop('_label')}
            for logical_name, description in group_fields.items():
                auto_info = auto.get(logical_name, {})
                auto_col = auto_info.get('column', None)
                confidence = auto_info.get('confidence', None)
                group_out[logical_name] = {
                    'description': description,
                    'auto_detected': auto_col,
                    'auto_confidence': confidence,
                    'your_answer': auto_col,
                    'set_null_to_skip': True,
                }
            mapping[group_key] = group_out

        unmapped = self.profile.get('unmapped_columns', [])
        if unmapped:
            mapping['_unmapped_columns'] = {
                '_label': '❓ UNMATCHED COLUMNS',
                '_instructions': "These weren't auto-matched. Update mappings above if needed.",
                'columns': unmapped,
            }

        # ── Organizational Hierarchy ──
        mapping['org_hierarchy'] = {
            '_label': '🏢 ORGANIZATIONAL HIERARCHY',
            '_instructions': (
                "Define who OWNS the customer relationship, from the level directly "
                "above the customer up to the top. Examples: Branch→Region→Market, "
                "or Franchise→Territory→Division. Leave empty [] if flat structure.\n\n"
                "Each level needs: label (what you call it), id (the code/number column), "
                "and optionally name (the display name column)."
            ),
            'levels': {
                'question': (
                    'What levels exist ABOVE the customer? List from lowest (closest '
                    'to customer) to highest. Use your column names.'
                ),
                'answer': [],
                'example': [
                    {"label": "Site", "id": "Company Number *", "name": "Company Name *"},
                    {"label": "Region", "id": "Company Region ID", "name": "Company Region Name"},
                    {"label": "Market", "id": "Company Market Level", "name": None}
                ],
            },
        }

        # ── Geographic Hierarchy ──
        mapping['geo_hierarchy'] = {
            '_label': '🌍 GEOGRAPHIC HIERARCHY',
            '_instructions': (
                "Define WHERE the business happens, from most granular to broadest. "
                "This controls geographic breakdowns in reports — you'll get a separate "
                "analysis at each level. Can overlap with org hierarchy.\n\n"
                "If you only have one geography column, just put it in the flat "
                "'geography' field above and leave this empty."
            ),
            'levels': {
                'question': (
                    'What geographic levels do you want reports at? '
                    'List from most granular to broadest.'
                ),
                'answer': [],
                'example': [
                    {"label": "Branch", "column": "Company Name *"},
                    {"label": "Region", "column": "Company Region Name"},
                    {"label": "Market", "column": "Company Market Level"}
                ],
            },
        }

        return mapping

    def _build_business_rules(self) -> Dict:
        return {
            '_instructions': "Define your business terms. These become the single source of truth.",
            'customer_churn': {
                '_label': '🚪 CHURN',
                'enable_churn_analysis': {'question': 'Analyze customer churn?', 'answer': True},
                'churn_definition': {
                    'question': 'How do you define "lost"?', 'answer': None,
                    'options': ['No purchases in current period', 'Volume dropped below threshold',
                                'Account marked inactive', 'Custom'],
                },
                'churn_activity_window': {
                    'question': (
                        'How many recent periods define "active"? '
                        'E.g., 6 = purchased in last 6 fiscal weeks from max date. '
                        'Set to 0 or null to use simple "any volume > 0" method.'
                    ),
                    'answer': None,
                    'example': 6,
                },
                'churn_activity_field': {
                    'question': (
                        'Which time field to measure recency against? '
                        'Use a logical field name from your field mapping.'
                    ),
                    'answer': 'fiscal_week',
                    'options': ['fiscal_week', 'fiscal_year', 'invoice_date'],
                },
                'churn_volume_threshold_pct': {'question': 'Volume drop % = at risk?', 'answer': 50},
                'distinguish_migration_from_churn': {
                    'question': (
                        'Separate customers who left YOUR branch/site but still buy '
                        'from another branch? (requires org hierarchy above)'
                    ),
                    'answer': True,
                },
                'churn_lookback_periods': {'question': 'Periods of inactivity = churned?', 'answer': 1},
            },
            'customer_acquisition': {
                '_label': '🎯 ACQUISITION',
                'enable_lead_scoring': {'question': 'Identify non-buying prospects?', 'answer': True},
                'high_affinity_values': {
                    'question': 'High-affinity values from your affinity column?',
                    'answer': [], 'example': ['Seafood Restaurant', 'Sushi']},
                'good_lead_criteria': {
                    'question': 'Additional lead criteria?', 'answer': None,
                    'options': ['High affinity + high volume', 'High conversion segment',
                                'Geographic proximity', 'Custom']},
            },
            'growth_classification': {
                '_label': '📈 GROWTH',
                'growth_threshold_pct': {'question': 'YoY increase % = growing?', 'answer': 5},
                'decline_threshold_pct': {'question': 'YoY decrease % = declining?', 'answer': -5},
                'significant_change_pct': {'question': '% change to flag?', 'answer': 15},
            },
            'pricing_health': {
                '_label': '💲 PRICING',
                'enable_price_index': {'question': 'Have benchmark pricing data?', 'answer': False},
                'competitive_range_low': {'question': 'Below = underpriced', 'answer': 0.90},
                'competitive_range_high': {'question': 'Above = overpriced', 'answer': 1.10},
                'extreme_threshold': {'question': 'Above = extreme', 'answer': 1.50},
            },
            'margin_health': {
                '_label': '📊 MARGIN',
                'enable_margin_analysis': {'question': 'Have margin data?', 'answer': False},
                'target_margin_pct': {'question': 'Target margin %?', 'answer': 25},
                'margin_floor_pct': {'question': 'Below this = unhealthy?', 'answer': 10},
                'margin_bands': {
                    'question': 'Custom margin bands? (null = defaults)',
                    'answer': None,
                    'example': [[5, 'Critical'], [15, 'Below Target'], [25, 'At Target'], [100, 'Above Target']]},
            },
            'customer_value': {
                '_label': '⭐ CUSTOMER VALUE',
                'enable_priority_scoring': {'question': 'Rank customers by priority?', 'answer': True},
                'priority_factors': {
                    'question': 'Priority factors ranked 1-4?',
                    'answer': {'volume_share': 1, 'margin_contribution': 2,
                               'growth_trajectory': 3, 'retention_risk': 4}},
            },
        }

    def _build_thresholds(self) -> Dict:
        return {
            '_instructions': "Numeric thresholds. Defaults work for most industries.",
            'index_thresholds': {
                '_label': 'Price Index Signals',
                'extreme_high': {'question': 'Above = EXTREME', 'answer': 1.50},
                'high': {'question': 'Above = HIGH', 'answer': 1.10},
                'low': {'question': 'Below = LOW', 'answer': 0.90},
            },
            'confidence_thresholds': {
                '_label': 'Data Confidence',
                'volume': {
                    'HIGH': {'question': 'Volume >= HIGH', 'answer': 50},
                    'MEDIUM': {'question': 'Volume >= MEDIUM', 'answer': 25},
                    'LOW': {'question': 'Volume >= LOW', 'answer': 10},
                },
                'coverage': {
                    'HIGH': {'question': 'Coverage >= HIGH', 'answer': 10},
                    'MEDIUM': {'question': 'Coverage >= MEDIUM', 'answer': 5},
                    'LOW': {'question': 'Coverage >= LOW', 'answer': 2},
                },
            },
            'statistical_significance': {
                '_label': 'Statistical Tests',
                'p_value_threshold': {'question': 'P-value significance', 'answer': 0.05},
                'cramers_v_strong': {'question': 'Cramers V strong', 'answer': 0.15},
            },
        }

    def _build_report_preferences(self) -> Dict:
        return {
            '_instructions': "Choose analyses. Missing-field analyses auto-skip.",
            'output_format': {'question': 'Output format?', 'answer': 'excel',
                              'options': ['excel', 'csv_bundle', 'both']},
            'analyses_to_run': {
                '_label': 'Toggle analyses',
                'executive_summary': {'question': 'Executive summary?', 'answer': True, 'requires': []},
                'volume_trends': {'question': 'Volume trends?', 'answer': True, 'requires': ['volume_cy', 'volume_py']},
                'revenue_analysis': {'question': 'Revenue analysis?', 'answer': True, 'requires': ['sales_ext_cy']},
                'margin_analysis': {'question': 'Margin analysis?', 'answer': True, 'requires': ['margin_ext_cy', 'margin_pct_cy']},
                'price_index': {'question': 'Price benchmarking?', 'answer': True, 'requires': ['price_per_unit_cy', 'benchmark_price']},
                'customer_churn': {'question': 'Customer churn?', 'answer': True, 'requires': ['customer_id', 'volume_cy', 'volume_py']},
                'customer_acquisition': {'question': 'Prospect ID?', 'answer': True, 'requires': ['customer_id', 'affinity_field']},
                'segment_comparison': {'question': 'Segment comparison?', 'answer': True, 'requires': ['segment']},
                'product_mix': {'question': 'Product mix?', 'answer': True, 'requires': ['product_group']},
                'geographic_analysis': {'question': 'Geographic breakdown?', 'answer': True, 'requires': ['geography']},
                'statistical_tests': {'question': 'Statistical tests?', 'answer': True, 'requires': ['segment']},
                'priority_ranking': {'question': 'Customer ranking?', 'answer': True, 'requires': ['customer_id', 'volume_cy']},
            },
        }
