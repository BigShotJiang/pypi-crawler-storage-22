"""Weighted aggregation functions."""

import pandas as pd
import numpy as np
from typing import Dict, List
from salesengine.config import (
    ProjectConfig, get_global_config, _register, requires_fields
)


@_register('Weighted Aggregation', 'pmi_evaluation + category_aggregator')
def weighted_average(values: pd.Series, weights: pd.Series) -> float:
    """Volume-weighted average, safe for zero/NaN weights."""
    w = weights.replace(0, np.nan)
    total = w.sum()
    if pd.isna(total) or total == 0:
        return np.nan
    return (values * w).sum() / total


@_register('Weighted Aggregation', 'category_aggregator',
           required_fields=['volume_cy'])
@requires_fields('volume_cy', returns_on_skip=pd.DataFrame())
def aggregate_to_grain(
    df: pd.DataFrame,
    group_cols: List[str],
    sum_cols: List[str] = None,
    wavg_cols: Dict[str, str] = None,
    count_col: str = None,
    config: ProjectConfig = None
) -> pd.DataFrame:
    """
    Aggregate transactional data to a higher grain with weighted averages.

    Example::

        >>> agg = aggregate_to_grain(
        ...     df, group_cols=['Customer_ID', 'Week'],
        ...     sum_cols=['Pounds', 'Sales'],
        ...     wavg_cols={'Price_Per_LB': 'Pounds'},
        ...     config=cfg
        ... )
    """
    cfg = config or get_global_config()
    group_cols = [c for c in group_cols if c in df.columns]
    sum_cols = sum_cols or []
    wavg_cols = wavg_cols or {}

    agg_dict = {}
    for col in sum_cols:
        if col in df.columns:
            agg_dict[col] = 'sum'
    if count_col and count_col in df.columns:
        agg_dict[count_col] = 'nunique'

    result = df.groupby(group_cols, dropna=False).agg(agg_dict).reset_index()

    if count_col and count_col in result.columns:
        result = result.rename(columns={count_col: f'N_{count_col}s'})

    for metric_col, weight_col in wavg_cols.items():
        if metric_col in df.columns and weight_col in df.columns:
            wavg_result = df.groupby(group_cols, dropna=False).apply(
                lambda g: weighted_average(g[metric_col], g[weight_col].abs()),
                include_groups=False
            ).reset_index(name=metric_col)
            result = result.merge(wavg_result, on=group_cols, how='left',
                                  suffixes=('_drop', ''))
            drop_cols = [c for c in result.columns if c.endswith('_drop')]
            result = result.drop(columns=drop_cols, errors='ignore')

    return result
