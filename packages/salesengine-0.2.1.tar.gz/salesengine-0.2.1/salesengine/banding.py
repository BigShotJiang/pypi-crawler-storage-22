"""Banding, tiering, and priority scoring."""

import pandas as pd
from typing import List, Tuple, Optional
from salesengine.config import ProjectConfig, get_global_config, _register


@_register('Banding / Tiering', 'category_aggregator_v2')
def assign_band(
    value: float,
    band_definitions: List[Tuple[float, str]] = None,
    na_label: str = 'UNKNOWN',
    config: ProjectConfig = None
) -> str:
    """
    Assign a numeric value to a named band.

    Uses ``config.margin_bands`` if no ``band_definitions`` provided.

    Example::

        >>> assign_band(17.5)
        'Band_04_15to20'
    """
    cfg = config or get_global_config()
    if band_definitions is None:
        band_definitions = cfg.margin_bands
    if pd.isna(value):
        return na_label
    for threshold, label in band_definitions:
        if value < threshold:
            return label
    return band_definitions[-1][1] if band_definitions else na_label


@_register('Banding / Tiering', 'revman')
def calculate_priority_score(
    volume_pct: float,
    loss_pct: float,
    active_pct: float,
    loss_ratio: float,
    multiplier: float = 10000,
    config: ProjectConfig = None
) -> float:
    """Priority = Volume% × Loss% × Active% × LossRatio × Multiplier."""
    cfg = config or get_global_config()
    if not cfg.is_enabled('calculate_priority_score'):
        return 0.0
    return volume_pct * loss_pct * active_pct * loss_ratio * multiplier
