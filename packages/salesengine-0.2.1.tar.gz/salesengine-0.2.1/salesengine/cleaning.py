"""Data cleaning functions for messy business/financial data."""

import pandas as pd
import numpy as np
from typing import List
from salesengine.config import ProjectConfig, get_global_config, _register


@_register('Data Cleaning', 'pmi_evaluation + revman')
def clean_numeric(series: pd.Series) -> pd.Series:
    """
    Production-grade numeric cleaning.

    Handles: ``$``, commas, ``%``, parenthetical negatives ``(123)``,
    blanks, dashes, N/A variants, whitespace.

    Example::

        >>> df['Revenue'] = clean_numeric(df['Revenue'])
    """
    s = series.astype(str).str.strip()
    s = s.replace(['', '-', '--', 'N/A', 'n/a', 'NA', 'null', 'None', 'none', '.', ' '], '0')
    is_negative = s.str.match(r'^\(.*\)$', na=False)
    s = s.str.replace(r'[\(\)]', '', regex=True)
    s = (s.str.replace('$', '', regex=False)
          .str.replace('%', '', regex=False)
          .str.replace(',', '', regex=False)
          .str.strip())
    result = pd.to_numeric(s, errors='coerce').fillna(0)
    result = result.where(~is_negative, -result)
    return result


@_register('Data Cleaning', 'category_aggregator')
def clean_currency(series: pd.Series) -> pd.Series:
    """Lightweight currency cleaner (no parenthetical negatives)."""
    return (series.astype(str)
            .str.replace('$', '', regex=False)
            .str.replace(',', '', regex=False)
            .str.replace('%', '', regex=False)
            .apply(pd.to_numeric, errors='coerce'))


@_register('Data Cleaning', 'revman')
def clean_dataframe(
    df: pd.DataFrame,
    numeric_columns: List[str] = None,
    strip_headers: bool = True,
    config: ProjectConfig = None
) -> pd.DataFrame:
    """
    Batch-clean a DataFrame. Auto-detects numeric columns from config
    if ``numeric_columns`` is not provided.
    """
    cfg = config or get_global_config()
    if strip_headers:
        df.columns = df.columns.str.strip()

    if numeric_columns is None:
        numeric_fields = [
            'volume_cy', 'volume_py', 'delta_volume',
            'price_per_unit_cy', 'price_per_unit_py',
            'sales_ext_cy', 'sales_ext_py',
            'margin_per_unit_cy', 'margin_per_unit_py',
            'margin_ext_cy', 'margin_ext_py',
            'margin_pct_cy', 'margin_pct_py', 'fiscal_week',
        ]
        numeric_columns = [cfg.col(f) for f in numeric_fields if cfg.col(f)]

    cleaned = 0
    for col in numeric_columns:
        if col in df.columns:
            df[col] = clean_numeric(df[col])
            cleaned += 1

    print(f"   ✅ Cleaned {cleaned} numeric columns")
    return df
