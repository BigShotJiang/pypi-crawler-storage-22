"""Command-line interface for salesengine."""

import sys
import os


def main():
    """
    CLI entry point.

    Usage:
        salesengine scan my_data.csv
        salesengine run my_data.csv intake.json
        salesengine run my_data.csv intake.json --output report.xlsx
    """
    args = sys.argv[1:]

    if not args or args[0] in ('-h', '--help', 'help'):
        print("""
salesengine — Universal Sales Intelligence Engine

Commands:
  salesengine scan <data_file>                     Scan data + generate questionnaire
  salesengine run  <data_file> <questionnaire>     Run analysis + generate report

Options:
  --output PATH    Output file path (default: auto-generated)

Examples:
  salesengine scan sales_data.csv
  salesengine run sales_data.csv intake.json
  salesengine run sales_data.csv intake.json --output Q1_Report.xlsx
""")
        return

    command = args[0]

    if command == 'scan':
        if len(args) < 2:
            print("Error: provide a data file path")
            sys.exit(1)
        import salesengine
        salesengine.scan(args[1])

    elif command == 'run':
        if len(args) < 3:
            print("Error: provide data file and questionnaire paths")
            sys.exit(1)
        output = None
        if '--output' in args:
            idx = args.index('--output')
            if idx + 1 < len(args):
                output = args[idx + 1]
        import salesengine
        salesengine.run(args[1], args[2], output_path=output)

    else:
        print(f"Unknown command: {command}. Use 'scan' or 'run'.")
        sys.exit(1)


if __name__ == '__main__':
    main()
