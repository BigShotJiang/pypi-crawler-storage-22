"""
Computed fields: auto-derive columns that can be calculated from existing data.

Runs after cleaning, before analysis. If the user has margin $ and sales $
but no margin %, we compute it. If they have sales and volume but no price
per unit, we compute it. Etc.

Each computed field only fires if:
  1. The target field is NOT already mapped (user doesn't have it)
  2. The source fields ARE mapped and present in the DataFrame
"""

import pandas as pd
import numpy as np
from typing import List, Tuple
from salesengine.config import ProjectConfig, get_global_config, _register


# Registry of computable fields: (target, [sources], compute_function)
# Each entry: (logical_name, [required_logicals], formula_description)

COMPUTED_FIELDS = []


def _computed(target: str, sources: List[str], description: str):
    """Decorator to register a computed field."""
    def decorator(func):
        COMPUTED_FIELDS.append({
            'target': target,
            'sources': sources,
            'description': description,
            'compute': func,
        })
        return func
    return decorator


# ── Margin % from Margin $ and Sales $ ──

@_computed('margin_pct_cy', ['margin_ext_cy', 'sales_ext_cy'],
           'Margin % CY = Margin Ext $ CY / Net Sales Ext $ CY × 100')
def _margin_pct_cy(df: pd.DataFrame, cfg: ProjectConfig) -> pd.Series:
    margin = df[cfg.col('margin_ext_cy')]
    sales = df[cfg.col('sales_ext_cy')]
    return np.where(sales != 0, (margin / sales * 100).round(2), 0)


@_computed('margin_pct_py', ['margin_ext_py', 'sales_ext_py'],
           'Margin % PY = Margin Ext $ PY / Net Sales Ext $ PY × 100')
def _margin_pct_py(df: pd.DataFrame, cfg: ProjectConfig) -> pd.Series:
    margin = df[cfg.col('margin_ext_py')]
    sales = df[cfg.col('sales_ext_py')]
    return np.where(sales != 0, (margin / sales * 100).round(2), 0)


# ── Price per unit from Sales $ and Volume ──

@_computed('price_per_unit_cy', ['sales_ext_cy', 'volume_cy'],
           'Price Per Unit CY = Net Sales Ext $ CY / Volume CY')
def _price_per_unit_cy(df: pd.DataFrame, cfg: ProjectConfig) -> pd.Series:
    sales = df[cfg.col('sales_ext_cy')]
    volume = df[cfg.col('volume_cy')]
    return np.where(volume != 0, (sales / volume).round(4), 0)


@_computed('price_per_unit_py', ['sales_ext_py', 'volume_py'],
           'Price Per Unit PY = Net Sales Ext $ PY / Volume PY')
def _price_per_unit_py(df: pd.DataFrame, cfg: ProjectConfig) -> pd.Series:
    sales = df[cfg.col('sales_ext_py')]
    volume = df[cfg.col('volume_py')]
    return np.where(volume != 0, (sales / volume).round(4), 0)


# ── Delta volume from CY - PY ──

@_computed('delta_volume', ['volume_cy', 'volume_py'],
           'Delta Volume = Volume CY - Volume PY')
def _delta_volume(df: pd.DataFrame, cfg: ProjectConfig) -> pd.Series:
    return df[cfg.col('volume_cy')] - df[cfg.col('volume_py')]


# ── Master function ──

@_register('Computed Fields', 'salesengine v0.2.0')
def compute_derived_fields(
    df: pd.DataFrame,
    config: ProjectConfig = None,
    verbose: bool = True
) -> pd.DataFrame:
    """
    Auto-compute fields that can be derived from existing data.

    Only computes a field if:
      - The target is NOT already mapped in config
      - All source fields ARE mapped and present in the DataFrame

    Automatically updates ``config.fields`` so downstream functions
    can use the newly computed columns.

    Returns
    -------
    DataFrame with new computed columns added.
    """
    cfg = config or get_global_config()
    computed_count = 0

    for entry in COMPUTED_FIELDS:
        target = entry['target']
        sources = entry['sources']

        # Skip if user already has this field
        if cfg.has_field(target):
            target_col = cfg.col(target)
            if target_col in df.columns:
                continue

        # Check all sources are available
        all_sources_available = True
        for src in sources:
            src_col = cfg.col(src)
            if not src_col or src_col not in df.columns:
                all_sources_available = False
                break

        if not all_sources_available:
            continue

        # Compute it
        try:
            new_col_name = f'_computed_{target}'
            df[new_col_name] = entry['compute'](df, cfg)

            # Register in config so downstream functions find it
            cfg.fields[target] = new_col_name
            computed_count += 1

            if verbose:
                print(f"   🔧 Computed: {target} → {entry['description']}")

        except Exception as e:
            if verbose:
                print(f"   ⚠️  Could not compute {target}: {e}")

    if verbose and computed_count > 0:
        print(f"   ✅ {computed_count} field(s) auto-computed")
    elif verbose:
        print(f"   ℹ️  No additional fields to compute")

    return df
