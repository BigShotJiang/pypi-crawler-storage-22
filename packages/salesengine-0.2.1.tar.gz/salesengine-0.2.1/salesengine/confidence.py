"""Data confidence and quality scoring."""

import pandas as pd
from typing import Dict
from salesengine.config import ProjectConfig, get_global_config, _register


@_register('Confidence & Data Quality', 'revman')
def score_confidence(
    dimensions: Dict[str, str],
    penalty: int = 0,
    config: ProjectConfig = None
) -> str:
    """
    Final confidence = LOWEST dimension score minus penalty levels.

    Example::

        >>> score_confidence({'volume': 'HIGH', 'coverage': 'MEDIUM'})
        'MEDIUM'
    """
    level_order = ['UNRELIABLE', 'LOW', 'MEDIUM', 'HIGH']
    level_to_idx = {lev: i for i, lev in enumerate(level_order)}
    min_idx = min(level_to_idx.get(v, 0) for v in dimensions.values())
    final_idx = max(0, min_idx - penalty)
    return level_order[final_idx]


@_register('Confidence & Data Quality', 'pmi_evaluation + revman')
def classify_confidence_band(
    value: float,
    thresholds: Dict[str, float] = None,
    config: ProjectConfig = None
) -> str:
    """Classify a value into HIGH / MEDIUM / LOW / UNRELIABLE."""
    if thresholds is None:
        cfg = config or get_global_config()
        thresholds = cfg.confidence_thresholds.get(
            'coverage', {'HIGH': 10, 'MEDIUM': 5, 'LOW': 2})
    for level in ['HIGH', 'MEDIUM', 'LOW']:
        if level in thresholds and value >= thresholds[level]:
            return level
    return 'UNRELIABLE'
