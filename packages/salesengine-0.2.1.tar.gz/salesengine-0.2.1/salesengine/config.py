"""
Configuration system: ProjectConfig, @requires_fields, function registry.
"""

import pandas as pd
import numpy as np
import functools
import warnings
from typing import Dict, List, Tuple, Optional, Any, Set, Callable
from dataclasses import dataclass, field


@dataclass
class ProjectConfig:
    """
    Maps logical field names to your dataset's actual column names.

    Usage::

        cfg = ProjectConfig(
            project_name="Q1 Revenue Review",
            industry="Food Distribution"
        )
        cfg.fields['customer_id'] = 'Account_Number'
        cfg.fields['volume_cy'] = 'Pounds_CY'

    Set a field to ``None`` to indicate it's not in your dataset —
    any function that requires it will gracefully skip.
    """

    project_name: str = "Unnamed Project"
    industry: str = "General"

    fields: Dict[str, Optional[str]] = field(default_factory=lambda: {
        # Customer (the lowest transactional entity)
        'customer_id': None, 'customer_name': None,
        # Volume
        'volume_cy': None, 'volume_py': None, 'delta_volume': None,
        # Price
        'price_per_unit_cy': None, 'price_per_unit_py': None,
        'sales_ext_cy': None, 'sales_ext_py': None,
        # Margin
        'margin_per_unit_cy': None, 'margin_per_unit_py': None,
        'margin_ext_cy': None, 'margin_ext_py': None,
        'margin_pct_cy': None, 'margin_pct_py': None,
        # Time
        'fiscal_week': None, 'fiscal_year': None, 'invoice_date': None,
        # Segmentation
        'segment': None, 'affinity_field': None,
        'product_group': None, 'product_group_name': None,
        'item_number': None, 'item_description': None,
        # Pricing Structure
        'price_zone': None, 'price_source': None,
        # Benchmarking
        'benchmark_price': None, 'benchmark_volume': None,
        'benchmark_coverage': None, 'benchmark_customers': None,
        # Geography (flat — for simple datasets with one geo column)
        'geography': None,
    })

    # ── Organizational Hierarchy ──
    # Defines who OWNS the customer relationship, from bottom to top.
    # Each level is a dict with 'id' and optional 'name' column.
    # Example for food distribution:
    #   [
    #     {"label": "Site",    "id": "Company Number *", "name": "Company Name *"},
    #     {"label": "Region",  "id": "Company Region ID", "name": "Company Region Name"},
    #     {"label": "Market",  "id": "Company Market Level", "name": null},
    #   ]
    # Customers are always the bottom. Corporate is always the top (implicit).
    # Set to empty list if you have a flat structure (no branches/sites).
    org_hierarchy: List[Dict[str, Optional[str]]] = field(default_factory=list)

    # ── Geographic Hierarchy ──
    # Defines WHERE the business happens, from most granular to broadest.
    # Can overlap with org hierarchy (branch = geography) or be independent.
    # Example:
    #   [
    #     {"label": "Branch",  "column": "Company Name *"},
    #     {"label": "Region",  "column": "Company Region Name"},
    #     {"label": "Market",  "column": "Company Market Level"},
    #   ]
    # Set to empty list to fall back to the flat 'geography' field.
    geo_hierarchy: List[Dict[str, str]] = field(default_factory=list)

    disabled_functions: Set[str] = field(default_factory=set)

    index_thresholds: Dict[str, float] = field(default_factory=lambda: {
        'extreme_high': 1.50, 'high': 1.10, 'low': 0.90,
    })

    confidence_thresholds: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        'volume': {'HIGH': 50, 'MEDIUM': 25, 'LOW': 10},
        'coverage': {'HIGH': 10, 'MEDIUM': 5, 'LOW': 2},
        'customers': {'HIGH': 50, 'MEDIUM': 25, 'LOW': 10},
    })

    margin_bands: List[Tuple[float, str]] = field(default_factory=lambda: [
        (5, 'Band_01_Under5'), (10, 'Band_02_5to10'),
        (15, 'Band_03_10to15'), (20, 'Band_04_15to20'),
        (25, 'Band_05_20to25'), (30, 'Band_06_25to30'),
        (35, 'Band_07_30to35'), (40, 'Band_08_35to40'),
        (float('inf'), 'Band_09_Over40'),
    ])

    # Churn: recency-based activity window
    # "active" = purchased within last N weeks/periods from max date in data
    # Set to 0 or None to use the old method (any CY volume > 0)
    churn_activity_window: Optional[int] = None
    churn_activity_field: str = 'fiscal_week'  # which time field to measure recency against

    # ── Fiscal Calendar ──
    # Tells the engine how to interpret time fields.
    #
    # calendar_type: 'calendar' or 'fiscal'
    # fiscal_start_month: 1-12, which calendar month starts fiscal year
    #   (e.g., 7 = July for Sysco, 10 = October for US Gov)
    # fiscal_pattern: '445', '454', '544', '13_period', 'monthly', 'weekly_52'
    #   445 = 4wk + 4wk + 5wk quarters (most common in retail/food)
    # period_format: how the period ID column is encoded
    #   'YYYYWW'  → 202533 = FY2025 Week 33
    #   'YYYYPP'  → 202507 = FY2025 Period 07
    #   'WW'      → 33 = just the week number, no year
    #   'PP'      → 7  = just the period number
    #   'date'    → actual date column (MM/DD/YYYY or YYYY-MM-DD)
    #   'auto'    → engine will try to figure it out
    # weeks_in_year: 52 or 53 (53 for leap years in 445 calendars)
    calendar_type: str = 'fiscal'
    fiscal_start_month: int = 1          # January default
    fiscal_pattern: str = 'weekly_52'    # simple 52-week
    period_format: str = 'auto'          # auto-detect
    weeks_in_year: int = 52

    def col(self, logical_name: str) -> Optional[str]:
        """Get the actual column name for a logical field."""
        return self.fields.get(logical_name)

    def has_field(self, logical_name: str) -> bool:
        return self.fields.get(logical_name) is not None

    def has_org_hierarchy(self) -> bool:
        """True if organizational hierarchy levels are defined."""
        return len(self.org_hierarchy) > 0

    def has_geo_hierarchy(self) -> bool:
        """True if geographic hierarchy levels are defined."""
        return len(self.geo_hierarchy) > 0

    def org_level(self, index: int) -> Optional[Dict]:
        """Get org hierarchy level by index (0 = closest to customer)."""
        if index < len(self.org_hierarchy):
            return self.org_hierarchy[index]
        return None

    def org_level_id(self, index: int) -> Optional[str]:
        """Get the ID column for an org hierarchy level."""
        level = self.org_level(index)
        return level.get('id') if level else None

    def org_level_name(self, index: int) -> Optional[str]:
        """Get the name column for an org hierarchy level."""
        level = self.org_level(index)
        return level.get('name') if level else None

    def geo_columns(self) -> List[str]:
        """Get all geographic hierarchy columns, most granular first."""
        if self.geo_hierarchy:
            return [level['column'] for level in self.geo_hierarchy
                    if level.get('column')]
        # Fall back to flat geography field
        geo = self.col('geography')
        return [geo] if geo else []

    def has_all_fields(self, *logical_names: str) -> bool:
        return all(self.has_field(n) for n in logical_names)

    def has_any_fields(self, *logical_names: str) -> bool:
        return any(self.has_field(n) for n in logical_names)

    def is_enabled(self, func_name: str) -> bool:
        return func_name not in self.disabled_functions

    def available_fields(self) -> Dict[str, str]:
        return {k: v for k, v in self.fields.items() if v is not None}

    def missing_fields(self) -> List[str]:
        return [k for k, v in self.fields.items() if v is None]

    def status(self) -> str:
        mapped = len(self.available_fields())
        total = len(self.fields)
        disabled = len(self.disabled_functions)
        lines = [
            f"╔══ PROJECT: {self.project_name} ({self.industry}) ══╗",
            f"  Fields mapped:      {mapped}/{total}",
            f"  Functions disabled:  {disabled}",
        ]
        if self.disabled_functions:
            lines.append(f"  Disabled: {', '.join(sorted(self.disabled_functions))}")
        unmapped = self.missing_fields()
        if unmapped:
            shown = unmapped[:8]
            lines.append(f"  Unmapped: {', '.join(shown)}")
            if len(unmapped) > 8:
                lines.append(f"    ... and {len(unmapped) - 8} more")
        lines.append("╚" + "═" * (len(lines[0]) - 2) + "╝")
        return '\n'.join(lines)


# ── Global config singleton ──

_global_config = ProjectConfig(project_name="Default", industry="General")


def set_global_config(config: ProjectConfig):
    """Set the global config used when no config is passed to functions."""
    global _global_config
    _global_config = config


def get_global_config() -> ProjectConfig:
    """Get the current global config."""
    return _global_config


# ── @requires_fields decorator ──

def requires_fields(*logical_names: str, returns_on_skip=None):
    """
    Decorator: auto-checks field availability, skips gracefully if missing.

    Example::

        @requires_fields('customer_id', 'volume_cy', returns_on_skip=pd.DataFrame())
        def my_analysis(df, config=None):
            cid = config.col('customer_id')
            ...
    """
    def decorator(func: Callable):
        func._required_fields = list(logical_names)
        func._returns_on_skip = returns_on_skip

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            config = kwargs.get('config') or _global_config

            if not config.is_enabled(func.__name__):
                warnings.warn(f"⏭️  {func.__name__}() SKIPPED — disabled in config",
                              stacklevel=2)
                return returns_on_skip

            missing = [n for n in logical_names if not config.has_field(n)]
            if missing:
                warnings.warn(
                    f"⏭️  {func.__name__}() SKIPPED — missing fields: "
                    f"{', '.join(missing)}", stacklevel=2)
                return returns_on_skip

            if args and isinstance(args[0], pd.DataFrame):
                df = args[0]
                bad = [f"{n}→'{config.col(n)}'" for n in logical_names
                       if config.col(n) and config.col(n) not in df.columns]
                if bad:
                    warnings.warn(
                        f"⏭️  {func.__name__}() SKIPPED — columns not in DataFrame: "
                        f"{', '.join(bad)}", stacklevel=2)
                    return returns_on_skip

            return func(*args, **kwargs)
        return wrapper
    return decorator


# ── Function Registry ──

FUNCTION_REGISTRY = {}


def _register(category: str, origin: str, required_fields: List[str] = None):
    """Register a function in the library catalog."""
    def decorator(func):
        FUNCTION_REGISTRY[func.__name__] = {
            'category': category,
            'origin': origin,
            'required_fields': required_fields or getattr(func, '_required_fields', []),
            'cross_industry': True,
        }
        return func
    return decorator


def list_functions(config: ProjectConfig = None) -> pd.DataFrame:
    """Show all library functions with availability status."""
    cfg = config or _global_config
    rows = []
    for name, info in FUNCTION_REGISTRY.items():
        req = info.get('required_fields', [])
        if not cfg.is_enabled(name):
            status = '🚫 DISABLED'
        elif not req:
            status = '✅ AVAILABLE'
        elif all(cfg.has_field(f) for f in req):
            status = '✅ AVAILABLE'
        else:
            missing = [f for f in req if not cfg.has_field(f)]
            status = f'⏭️ SKIP (need: {", ".join(missing)})'
        rows.append({'Function': name, 'Category': info['category'],
                     'Required_Fields': ', '.join(req) or '—', 'Status': status})
    return pd.DataFrame(rows).sort_values(['Category', 'Function']).reset_index(drop=True)
