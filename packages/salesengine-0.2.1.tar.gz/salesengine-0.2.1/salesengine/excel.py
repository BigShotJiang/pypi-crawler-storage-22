"""Excel report formatting utilities."""

import pandas as pd
import numpy as np
from typing import List
from salesengine.config import ProjectConfig, get_global_config, _register


@_register('Excel Formatting', 'pmi_evaluation + revman')
def get_excel_styles():
    """Return standard openpyxl styles for professional reports."""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    return {
        'header_font': Font(name='Arial', bold=True, size=11, color='FFFFFF'),
        'header_fill': PatternFill('solid', fgColor='2F5496'),
        'title_font': Font(name='Arial', bold=True, size=14),
        'subtitle_font': Font(name='Arial', bold=True, size=11),
        'body_font': Font(name='Arial', size=10),
        'red_fill': PatternFill('solid', fgColor='FFC7CE'),
        'green_fill': PatternFill('solid', fgColor='C6EFCE'),
        'yellow_fill': PatternFill('solid', fgColor='FFEB9C'),
        'gray_fill': PatternFill('solid', fgColor='D9D9D9'),
        'thin_border': Border(
            left=Side(style='thin'), right=Side(style='thin'),
            top=Side(style='thin'), bottom=Side(style='thin')),
    }


@_register('Excel Formatting', 'pmi_evaluation + revman')
def style_header_row(ws, ncols: int, styles: dict = None):
    """Apply dark-blue header styling to row 1 of a worksheet."""
    from openpyxl.styles import Alignment
    if styles is None:
        styles = get_excel_styles()
    for c in range(1, ncols + 1):
        cell = ws.cell(row=1, column=c)
        cell.font = styles['header_font']
        cell.fill = styles['header_fill']
        cell.alignment = Alignment(horizontal='center', wrap_text=True)
        cell.border = styles['thin_border']


@_register('Excel Formatting', 'pmi_evaluation + revman')
def auto_width(ws, max_width: int = 40):
    """Auto-size column widths based on content."""
    from openpyxl.utils import get_column_letter
    for col_cells in ws.columns:
        mx = 0
        col_letter = get_column_letter(col_cells[0].column)
        for cell in col_cells:
            try:
                mx = max(mx, len(str(cell.value or '')))
            except Exception:
                pass
        ws.column_dimensions[col_letter].width = min(mx + 3, max_width)


@_register('Excel Formatting', 'pmi_evaluation + revman')
def df_to_sheet(
    wb, df: pd.DataFrame, sheet_name: str,
    num_fmt_cols: List[str] = None,
    pct_fmt_cols: List[str] = None,
    index_col: str = None,
    config: ProjectConfig = None
):
    """Write DataFrame to Excel sheet with formatting + conditional colors."""
    cfg = config or get_global_config()
    styles = get_excel_styles()
    ws = wb.create_sheet(title=sheet_name[:31])

    for c, col_name in enumerate(df.columns, 1):
        ws.cell(row=1, column=c, value=col_name)
    style_header_row(ws, len(df.columns), styles)

    for r, (_, row) in enumerate(df.iterrows(), 2):
        for c, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=c)
            cell.value = '' if isinstance(val, float) and np.isnan(val) else val
            cell.font = styles['body_font']
            cell.border = styles['thin_border']

    if num_fmt_cols:
        for col_name in num_fmt_cols:
            if col_name in df.columns:
                ci = df.columns.get_loc(col_name) + 1
                for r in range(2, len(df) + 2):
                    ws.cell(row=r, column=ci).number_format = '#,##0'

    if pct_fmt_cols:
        for col_name in pct_fmt_cols:
            if col_name in df.columns:
                ci = df.columns.get_loc(col_name) + 1
                for r in range(2, len(df) + 2):
                    ws.cell(row=r, column=ci).number_format = '0.0%'

    if index_col and index_col in df.columns:
        t = cfg.index_thresholds
        ci = df.columns.get_loc(index_col) + 1
        for r in range(2, len(df) + 2):
            v = ws.cell(row=r, column=ci).value
            try:
                v = float(v)
                ws.cell(row=r, column=ci).number_format = '0.00'
                if v > t.get('high', 1.10):
                    ws.cell(row=r, column=ci).fill = styles['red_fill']
                elif v < t.get('low', 0.90):
                    ws.cell(row=r, column=ci).fill = styles['green_fill']
                else:
                    ws.cell(row=r, column=ci).fill = styles['yellow_fill']
            except (ValueError, TypeError):
                pass

    auto_width(ws)
    ws.freeze_panes = 'A2'
    return ws
