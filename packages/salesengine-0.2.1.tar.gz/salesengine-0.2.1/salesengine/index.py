"""Price index and benchmark comparison functions."""

import pandas as pd
from typing import Optional
from salesengine.config import ProjectConfig, get_global_config, _register


@_register('Index / Benchmark', 'pmi_evaluation + revman')
def calculate_price_index(
    company_price: float,
    benchmark_price: float,
    min_benchmark_volume: float = 0,
    actual_benchmark_volume: float = 0,
    min_benchmark_price: float = 0,
    config: ProjectConfig = None
) -> Optional[float]:
    """
    PMI = Company_Price / Benchmark_Price.

    >1.0 = overpriced, <1.0 = underpriced, 1.0 = at market.
    """
    cfg = config or get_global_config()
    if not cfg.is_enabled('calculate_price_index'):
        return None
    if (benchmark_price > min_benchmark_price and
            actual_benchmark_volume >= min_benchmark_volume):
        return company_price / benchmark_price
    return None


@_register('Index / Benchmark', 'pmi_evaluation + revman')
def classify_index(
    index_value: Optional[float],
    config: ProjectConfig = None
) -> str:
    """Classify an index value into a signal bucket using config thresholds."""
    cfg = config or get_global_config()
    if not cfg.is_enabled('classify_index'):
        return 'DISABLED'
    t = cfg.index_thresholds
    if index_value is None or pd.isna(index_value):
        return 'NO DATA'
    if 'extreme_high' in t and index_value >= t['extreme_high']:
        return '🔴 EXTREME'
    if index_value > t.get('high', 1.10):
        return '🔴 HIGH'
    if index_value < t.get('low', 0.90):
        return '🟢 LOW'
    return '✅ COMPETITIVE'


@_register('Index / Benchmark', 'pmi_evaluation')
def detect_index_conflicts(
    detail_index: Optional[float],
    aggregate_index: Optional[float],
    config: ProjectConfig = None
) -> str:
    """
    Catches when detail-level and aggregate-level indices disagree.

    The core insight: aggregation masks item-level truth. If the
    category looks competitive but individual items are 40% overpriced,
    this function flags CONFLICT.
    """
    cfg = config or get_global_config()
    if not cfg.is_enabled('detect_index_conflicts'):
        return 'DISABLED'
    if pd.isna(detail_index) or pd.isna(aggregate_index):
        return 'NO DATA'
    detail_signal = classify_index(detail_index, config=cfg)
    agg_signal = classify_index(aggregate_index, config=cfg)
    return 'CONFLICT' if detail_signal != agg_signal else 'CONSISTENT'
