"""Quick file profiling utilities."""

import pandas as pd
import os
from salesengine.config import _register


@_register('File Inspection', 'list.py')
def inspect_csv(filepath: str, sample_rows: int = 1000, save: bool = False) -> pd.DataFrame:
    """Quick profile of any CSV — column names, types, nulls, samples."""
    df = pd.read_csv(filepath, dtype=str, nrows=sample_rows)
    info = pd.DataFrame({
        'Column Name': df.columns,
        'Data Type': [
            df[col].dropna().apply(type).mode()[0].__name__
            if not df[col].dropna().empty else 'unknown'
            for col in df.columns
        ],
        'Non-Null Count': df.notnull().sum().values,
        'Sample Value': [
            df[col].dropna().iloc[0] if df[col].dropna().any() else ""
            for col in df.columns
        ]
    })
    if save:
        base = os.path.splitext(os.path.basename(filepath))[0]
        out_path = os.path.join(os.path.dirname(filepath), f"{base}_column_info.csv")
        info.to_csv(out_path, index=False)
        print(f"✅ Saved column info to: {out_path}")
    return info
