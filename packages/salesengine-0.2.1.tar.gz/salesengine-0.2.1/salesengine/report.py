"""Report engine: runs analyses and produces formatted Excel workbooks."""

import pandas as pd
import numpy as np
from typing import Dict, List
from datetime import datetime

from salesengine.config import ProjectConfig, set_global_config, list_functions
from salesengine.cleaning import clean_dataframe
from salesengine.computed import compute_derived_fields
from salesengine.churn import classify_customer_movement, determine_active_customers
from salesengine.banding import assign_band
from salesengine.excel import df_to_sheet, get_excel_styles, auto_width


class ReportEngine:
    """
    Runs all applicable analyses and produces a formatted Excel report.

    Usage::

        engine = ReportEngine(df, config, questionnaire)
        engine.run()
        engine.save('report.xlsx')
    """

    def __init__(self, df: pd.DataFrame, config: ProjectConfig, questionnaire: Dict = None):
        self.df = df.copy()
        self.cfg = config
        self.q = questionnaire or {}
        self.results = {}
        self.summary_lines = []

    def run(self):
        """Run all applicable analyses."""
        set_global_config(self.cfg)

        print("\n🧹 STEP 1: Cleaning data...")
        self.df = clean_dataframe(self.df, config=self.cfg)

        print("\n🔧 STEP 2: Computing derived fields...")
        self.df = compute_derived_fields(self.df, config=self.cfg)

        print("\n📋 STEP 3: Checking available analyses...")
        func_status = list_functions(self.cfg)
        print(func_status.to_string(index=False))

        print("\n📊 STEP 4: Running analyses...")
        self._run_executive_summary()
        self._run_volume_analysis()
        self._run_revenue_analysis()
        self._run_margin_analysis()
        self._run_segment_analysis()
        self._run_product_analysis()
        self._run_geographic_analysis()
        self._run_customer_movement()
        self._run_priority_scoring()

        print(f"\n✅ Completed {len(self.results)} analysis sections")

    def _run_executive_summary(self):
        summary = {'metric': [], 'current_period': [], 'prior_period': [], 'change': [], 'change_pct': []}

        def add_metric(name, cy_field, py_field=None):
            cy_col = self.cfg.col(cy_field)
            py_col = self.cfg.col(py_field) if py_field else None
            if cy_col and cy_col in self.df.columns:
                cy_val = self.df[cy_col].sum()
                py_val = self.df[py_col].sum() if py_col and py_col in self.df.columns else None
                change = cy_val - py_val if py_val is not None else None
                change_pct = (change / py_val * 100) if py_val and py_val != 0 else None
                summary['metric'].append(name)
                summary['current_period'].append(round(cy_val, 2))
                summary['prior_period'].append(round(py_val, 2) if py_val else None)
                summary['change'].append(round(change, 2) if change is not None else None)
                summary['change_pct'].append(round(change_pct, 1) if change_pct is not None else None)

        add_metric('Total Volume', 'volume_cy', 'volume_py')
        add_metric('Total Revenue', 'sales_ext_cy', 'sales_ext_py')
        add_metric('Total Margin $', 'margin_ext_cy', 'margin_ext_py')

        cid_col = self.cfg.col('customer_id')
        vol_cy = self.cfg.col('volume_cy')
        vol_py = self.cfg.col('volume_py')
        if cid_col and cid_col in self.df.columns and vol_cy and vol_cy in self.df.columns:
            active_cy = self.df[self.df[vol_cy] > 0][cid_col].nunique()
            summary['metric'].append('Active Customers')
            summary['current_period'].append(active_cy)
            if vol_py and vol_py in self.df.columns:
                active_py = self.df[self.df[vol_py] > 0][cid_col].nunique()
                summary['prior_period'].append(active_py)
                summary['change'].append(active_cy - active_py)
                summary['change_pct'].append(round((active_cy - active_py) / active_py * 100, 1) if active_py else None)
            else:
                summary['prior_period'].append(None)
                summary['change'].append(None)
                summary['change_pct'].append(None)

        if summary['metric']:
            self.results['Executive Summary'] = pd.DataFrame(summary)
            self.summary_lines.append(f"📊 Executive Summary: {len(summary['metric'])} metrics")

    def _run_volume_analysis(self):
        vol_cy = self.cfg.col('volume_cy')
        vol_py = self.cfg.col('volume_py')
        if not vol_cy or vol_cy not in self.df.columns:
            return

        for dim_name, dim_field in [('segment', 'segment'), ('product_group', 'product_group'), ('geography', 'geography')]:
            dim_col = self.cfg.col(dim_field)
            if not dim_col or dim_col not in self.df.columns:
                continue
            agg = {vol_cy: 'sum'}
            if vol_py and vol_py in self.df.columns:
                agg[vol_py] = 'sum'
            grouped = self.df.groupby(dim_col, dropna=False).agg(agg).reset_index().sort_values(vol_cy, ascending=False)
            if vol_py and vol_py in grouped.columns:
                grouped['Volume_Change'] = grouped[vol_cy] - grouped[vol_py]
                grouped['Volume_Change_%'] = np.where(grouped[vol_py] != 0, (grouped['Volume_Change'] / grouped[vol_py] * 100).round(1), None)
            sheet_name = f'Volume by {dim_name.title()}'
            self.results[sheet_name] = grouped
            self.summary_lines.append(f"📦 {sheet_name}: {len(grouped)} groups")

    def _run_revenue_analysis(self):
        sales_cy = self.cfg.col('sales_ext_cy')
        seg_col = self.cfg.col('segment')
        if not sales_cy or sales_cy not in self.df.columns or not seg_col or seg_col not in self.df.columns:
            return
        grouped = self.df.groupby(seg_col, dropna=False).agg({sales_cy: 'sum'}).reset_index().sort_values(sales_cy, ascending=False)
        grouped['Revenue_Share_%'] = (grouped[sales_cy] / grouped[sales_cy].sum() * 100).round(1)
        self.results['Revenue by Segment'] = grouped
        self.summary_lines.append(f"💰 Revenue by Segment: {len(grouped)} segments")

    def _run_margin_analysis(self):
        margin_pct = self.cfg.col('margin_pct_cy')
        margin_ext = self.cfg.col('margin_ext_cy')
        cid_col = self.cfg.col('customer_id')
        if not margin_pct or margin_pct not in self.df.columns:
            return
        self.df['_Margin_Band'] = self.df[margin_pct].apply(lambda x: assign_band(x, config=self.cfg))
        if cid_col and cid_col in self.df.columns:
            band_summary = self.df.groupby('_Margin_Band', dropna=False).agg(Customers=(cid_col, 'nunique')).reset_index()
        else:
            band_summary = self.df.groupby('_Margin_Band', dropna=False).size().reset_index(name='Count')
        if margin_ext and margin_ext in self.df.columns:
            margin_by_band = self.df.groupby('_Margin_Band', dropna=False).agg({margin_ext: 'sum'}).reset_index()
            band_summary = band_summary.merge(margin_by_band, on='_Margin_Band', how='left')
        self.results['Margin Distribution'] = band_summary
        self.summary_lines.append(f"📊 Margin Distribution: {len(band_summary)} bands")
        self.df.drop(columns=['_Margin_Band'], inplace=True, errors='ignore')

    def _run_segment_analysis(self):
        seg_col = self.cfg.col('segment')
        if not seg_col or seg_col not in self.df.columns:
            return
        agg_cols = {}
        for logical, agg_type in [('volume_cy', 'sum'), ('volume_py', 'sum'), ('sales_ext_cy', 'sum'), ('margin_ext_cy', 'sum')]:
            actual = self.cfg.col(logical)
            if actual and actual in self.df.columns:
                agg_cols[actual] = agg_type
        cid_col = self.cfg.col('customer_id')
        if cid_col and cid_col in self.df.columns:
            agg_cols[cid_col] = 'nunique'
        if agg_cols:
            grouped = self.df.groupby(seg_col, dropna=False).agg(agg_cols).reset_index()
            if cid_col and cid_col in grouped.columns:
                grouped = grouped.rename(columns={cid_col: 'N_Customers'})
            self.results['Segment Comparison'] = grouped
            self.summary_lines.append(f"🏷️ Segment Comparison: {len(grouped)} segments")

    def _run_product_analysis(self):
        pg_col = self.cfg.col('product_group')
        pg_name = self.cfg.col('product_group_name')
        vol_cy = self.cfg.col('volume_cy')
        if not pg_col or pg_col not in self.df.columns or not vol_cy:
            return
        group_by = [pg_col] + ([pg_name] if pg_name and pg_name in self.df.columns else [])
        agg = {vol_cy: 'sum'}
        sales_cy = self.cfg.col('sales_ext_cy')
        if sales_cy and sales_cy in self.df.columns:
            agg[sales_cy] = 'sum'
        grouped = self.df.groupby(group_by, dropna=False).agg(agg).reset_index().sort_values(vol_cy, ascending=False)
        grouped['Volume_Share_%'] = (grouped[vol_cy] / grouped[vol_cy].sum() * 100).round(1)
        self.results['Product Mix'] = grouped
        self.summary_lines.append(f"📦 Product Mix: {len(grouped)} groups")

    def _run_geographic_analysis(self):
        """Run geographic analysis at every hierarchy level, or flat if no hierarchy."""
        vol_cy = self.cfg.col('volume_cy')
        if not vol_cy or vol_cy not in self.df.columns:
            return

        # Determine which geo columns to analyze
        if self.cfg.has_geo_hierarchy():
            geo_levels = self.cfg.geo_hierarchy
        else:
            # Fall back to flat geography field
            geo_col = self.cfg.col('geography')
            if geo_col and geo_col in self.df.columns:
                geo_levels = [{'label': 'Geography', 'column': geo_col}]
            else:
                return

        for level in geo_levels:
            col = level.get('column')
            label = level.get('label', col)
            if not col or col not in self.df.columns:
                continue

            agg = {vol_cy: 'sum'}
            sales_cy = self.cfg.col('sales_ext_cy')
            if sales_cy and sales_cy in self.df.columns:
                agg[sales_cy] = 'sum'
            margin_cy = self.cfg.col('margin_ext_cy')
            if margin_cy and margin_cy in self.df.columns:
                agg[margin_cy] = 'sum'
            vol_py = self.cfg.col('volume_py')
            if vol_py and vol_py in self.df.columns:
                agg[vol_py] = 'sum'
            cid_col = self.cfg.col('customer_id')
            if cid_col and cid_col in self.df.columns:
                agg[cid_col] = 'nunique'

            grouped = (self.df.groupby(col, dropna=False)
                       .agg(agg).reset_index()
                       .sort_values(vol_cy, ascending=False))

            if cid_col and cid_col in grouped.columns:
                grouped = grouped.rename(columns={cid_col: 'N_Customers'})
            if vol_py and vol_py in grouped.columns:
                grouped['Volume_Change'] = grouped[vol_cy] - grouped[vol_py]
                grouped['Volume_Change_%'] = np.where(
                    grouped[vol_py] != 0,
                    (grouped['Volume_Change'] / grouped[vol_py] * 100).round(1),
                    None
                )
            if sales_cy and sales_cy in grouped.columns:
                total_sales = grouped[sales_cy].sum()
                if total_sales > 0:
                    grouped['Revenue_Share_%'] = (grouped[sales_cy] / total_sales * 100).round(1)

            sheet_name = f'Geo - {label}'
            self.results[sheet_name] = grouped
            self.summary_lines.append(f"🌍 {sheet_name}: {len(grouped)} groups")

    def _run_customer_movement(self):
        cid_col = self.cfg.col('customer_id')
        vol_cy = self.cfg.col('volume_cy')
        vol_py = self.cfg.col('volume_py')
        if not all([cid_col, vol_cy]):
            return
        if cid_col not in self.df.columns or vol_cy not in self.df.columns:
            return

        # Use recency-aware method if configured, else simple volume > 0
        activity = determine_active_customers(self.df, config=self.cfg)
        current = activity['current_active']
        prior = activity['prior_active']

        if not prior:
            return

        # If org hierarchy exists, use it for migration detection
        parent_current = None
        parent_prior = None
        all_active_current = current  # all active at corporate level

        if self.cfg.has_org_hierarchy():
            site_id_col = self.cfg.org_level_id(0)  # first level above customer
            if site_id_col and site_id_col in self.df.columns:
                # For each site, build its customer sets
                # "parent_current" = customers buying from ANY site in CY
                # This lets us distinguish: left my site vs left entirely
                parent_current = current  # all CY buyers across all sites
                parent_prior = prior

                # Also run per-site churn
                site_name_col = self.cfg.org_level_name(0)
                site_col = site_name_col if (site_name_col and site_name_col in self.df.columns) else site_id_col

                site_churn_rows = []
                for site_val in sorted(self.df[site_col].dropna().unique()):
                    site_df = self.df[self.df[site_col] == site_val]
                    site_current = set(site_df[site_df[vol_cy] > 0][cid_col].unique()) if vol_cy in site_df.columns else set()
                    site_prior = set(site_df[site_df[vol_py] > 0][cid_col].unique()) if vol_py and vol_py in site_df.columns else set()

                    if not site_prior:
                        continue

                    site_movement = classify_customer_movement(
                        site_current, site_prior,
                        parent_current=all_active_current,
                        all_active_current=all_active_current,
                        config=self.cfg,
                    )
                    site_churn_rows.append({
                        site_col: site_val,
                        'Prior_Customers': len(site_prior),
                        'Current_Customers': len(site_current),
                        'Retained': site_movement['retained'],
                        'Left_Entirely': site_movement['left_entirely'],
                        'Left_Site_Still_Active': site_movement['left_segment'],
                        'Migrated_Out': site_movement['migrated_out'],
                        'New_Acquisition': site_movement['new_acquisition'],
                        'Retention_%': site_movement['retention_pct'],
                    })

                if site_churn_rows:
                    site_churn_df = pd.DataFrame(site_churn_rows).sort_values(
                        'Left_Entirely', ascending=False)
                    level_label = self.cfg.org_hierarchy[0].get('label', 'Site')
                    self.results[f'Churn by {level_label}'] = site_churn_df
                    self.summary_lines.append(
                        f"🚪 Churn by {level_label}: {len(site_churn_df)} sites analyzed")

        # Corporate-level movement (all customers)
        movement = classify_customer_movement(
            current, prior,
            parent_current=parent_current,
            all_active_current=all_active_current,
            config=self.cfg,
        )
        if movement and movement.get('retained', 0) > 0:
            rows = [{'Metric': k.replace('_', ' ').title(), 'Value': v}
                    for k, v in movement.items()]

            rows.append({'Metric': '---', 'Value': '---'})
            rows.append({'Metric': 'Activity Method',
                         'Value': activity['activity_method']})
            if activity['window_info']:
                info = activity['window_info']
                rows.append({'Metric': 'Window Size',
                             'Value': f"Last {info.get('window_size', 'N/A')} periods"})
                rows.append({'Metric': 'Max Period in Data',
                             'Value': info.get('max_period', 'N/A')})
                rows.append({'Metric': 'Cutoff Period',
                             'Value': f"> {info.get('cutoff_period', 'N/A')}"})

            movement_df = pd.DataFrame(rows)
            self.results['Customer Movement'] = movement_df
            self.summary_lines.append(
                f"🚪 Customer Movement: {movement.get('retention_pct', 0)}% retention "
                f"({activity['activity_method']})"
            )

    def _run_priority_scoring(self):
        cid_col = self.cfg.col('customer_id')
        vol_cy = self.cfg.col('volume_cy')
        if not cid_col or not vol_cy or cid_col not in self.df.columns:
            return
        cust_agg = {vol_cy: 'sum'}
        for f in ['sales_ext_cy', 'margin_ext_cy']:
            actual = self.cfg.col(f)
            if actual and actual in self.df.columns:
                cust_agg[actual] = 'sum'
        cust = self.df.groupby(cid_col, dropna=False).agg(cust_agg).reset_index().sort_values(vol_cy, ascending=False)
        total_vol = cust[vol_cy].sum()
        cust['Volume_Share_%'] = (cust[vol_cy] / total_vol * 100).round(2) if total_vol > 0 else 0
        cust['Cumulative_Share_%'] = cust['Volume_Share_%'].cumsum().round(2)
        cname_col = self.cfg.col('customer_name')
        if cname_col and cname_col in self.df.columns:
            names = self.df.groupby(cid_col)[cname_col].first().reset_index()
            cust = cust.merge(names, on=cid_col, how='left')
            cols = [cid_col, cname_col] + [c for c in cust.columns if c not in [cid_col, cname_col]]
            cust = cust[cols]
        self.results['Customer Ranking'] = cust.head(200)
        self.summary_lines.append(f"⭐ Customer Ranking: Top {min(200, len(cust))} of {len(cust)}")

    def save(self, filepath: str):
        """Save all results to a formatted Excel workbook."""
        from openpyxl import Workbook

        wb = Workbook()
        ws = wb.active
        ws.title = 'Report Summary'
        styles = get_excel_styles()

        ws.cell(row=1, column=1, value=self.cfg.project_name).font = styles['title_font']
        ws.cell(row=2, column=1, value=f"Industry: {self.cfg.industry}").font = styles['subtitle_font']
        ws.cell(row=3, column=1, value=f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}").font = styles['body_font']
        ws.cell(row=4, column=1, value=f"Source: {self.q.get('_meta', {}).get('source_file', 'Unknown')}").font = styles['body_font']

        row = 6
        ws.cell(row=row, column=1, value='ANALYSIS RESULTS').font = styles['subtitle_font']
        for line in self.summary_lines:
            row += 1
            ws.cell(row=row, column=1, value=line).font = styles['body_font']
        auto_width(ws, max_width=80)

        for sheet_name, df in self.results.items():
            try:
                df_to_sheet(wb, df, sheet_name[:31], config=self.cfg)
            except Exception as e:
                print(f"   ⚠️ Could not write '{sheet_name}': {e}")

        wb.save(filepath)
        print(f"\n✅ Report saved to: {filepath}")
        print(f"   📄 {len(self.results) + 1} tabs")
