"""Dataset scanner: profiles columns and auto-detects semantic roles."""

import pandas as pd
import numpy as np
import os
import re
from typing import Dict, List
from datetime import datetime


class DatasetScanner:
    """
    Scans any CSV/Excel file and auto-detects column roles.

    Usage::

        scanner = DatasetScanner('my_data.csv')
        profile = scanner.scan()

    Returns a profile dict with file_info, columns, auto_mapping,
    and unmapped_columns.
    """

    PATTERNS = {
        'customer_id': [
            r'cust.*(?:id|num|code|key|#)', r'account.*(?:id|num|code|key|#)',
            r'client.*(?:id|num|code|key|#)', r'buyer.*(?:id|num)',
            r'patron.*(?:id|num)', r'member.*(?:id|num)', r'subscriber.*(?:id|num)',
        ],
        'customer_name': [
            r'cust.*name', r'account.*name', r'client.*name',
            r'buyer.*name', r'company.*name', r'^name$',
        ],
        'company_name': [
            r'(?:opco|operating|parent).*(?:name|company)',
            r'division.*name', r'branch.*name', r'location.*name',
        ],
        'company_number': [
            r'(?:opco|operating|parent).*(?:num|id|code)',
            r'division.*(?:num|id|code)', r'branch.*(?:num|id|code)',
        ],
        'item_number': [
            r'item.*(?:id|num|code|key|#|sku)', r'product.*(?:id|num|code|key|#|sku)',
            r'sku', r'upc', r'material.*(?:id|num)',
        ],
        'item_description': [
            r'item.*(?:desc|name)', r'product.*(?:desc|name)',
            r'material.*(?:desc|name)', r'sku.*(?:desc|name)',
        ],
        'volume_cy': [
            r'(?:vol|qty|quantity|units|lbs|pounds|cases|eaches).*(?:cy|current|ytd|this)',
            r'(?:cy|current|ytd).*(?:vol|qty|quantity|units|lbs|pounds|cases|eaches)',
        ],
        'volume_py': [
            r'(?:vol|qty|quantity|units|lbs|pounds|cases|eaches).*(?:py|prior|last|prev)',
            r'(?:py|prior|last|prev).*(?:vol|qty|quantity|units|lbs|pounds|cases|eaches)',
        ],
        'delta_volume': [
            r'(?:delta|change|diff|var).*(?:vol|qty|units|lbs|pounds)',
            r'(?:vol|qty|units|lbs|pounds).*(?:delta|change|diff|var)',
        ],
        'price_per_unit_cy': [
            r'(?:price|rate|cost).*(?:per|/).*(?:cy|current)',
            r'(?:net.*sales|revenue).*per.*(?:lb|unit|case|each).*(?:cy|current)',
            r'(?:cy|current).*(?:price|rate).*per', r'avg.*(?:price|sell).*(?:cy|current)',
        ],
        'price_per_unit_py': [
            r'(?:price|rate|cost).*(?:per|/).*(?:py|prior|last)',
            r'(?:net.*sales|revenue).*per.*(?:lb|unit|case|each).*(?:py|prior)',
        ],
        'sales_ext_cy': [
            r'(?:net.*)?(?:sales|revenue).*(?:ext|\$).*(?:cy|current|ytd)',
            r'(?:cy|current|ytd).*(?:net.*)?(?:sales|revenue)',
            r'total.*(?:sales|revenue).*(?:cy|current)',
        ],
        'sales_ext_py': [
            r'(?:net.*)?(?:sales|revenue).*(?:ext|\$).*(?:py|prior|last)',
            r'(?:py|prior|last).*(?:net.*)?(?:sales|revenue)',
        ],
        'margin_per_unit_cy': [
            r'(?:margin|profit|gp).*(?:per|/).*(?:cy|current)',
            r'(?:cy|current).*(?:margin|profit|gp).*per',
        ],
        'margin_per_unit_py': [r'(?:margin|profit|gp).*(?:per|/).*(?:py|prior|last)'],
        'margin_ext_cy': [
            r'(?:margin|profit|gp).*(?:ext|\$).*(?:cy|current)',
            r'(?:cy|current).*(?:margin|profit|gp).*(?:ext|\$)',
        ],
        'margin_ext_py': [r'(?:margin|profit|gp).*(?:ext|\$).*(?:py|prior|last)'],
        'margin_pct_cy': [
            r'(?:margin|profit|gp).*%.*(?:cy|current)',
            r'(?:cy|current).*(?:margin|profit|gp).*%',
        ],
        'margin_pct_py': [r'(?:margin|profit|gp).*%.*(?:py|prior|last)'],
        'fiscal_week': [r'(?:fiscal|fw).*(?:week|wk|period)', r'week.*(?:num|#|id)'],
        'fiscal_year': [r'(?:fiscal|fy).*year', r'year'],
        'invoice_date': [
            r'(?:invoice|order|transaction|purchase|sale).*date',
            r'date.*(?:invoice|order|transaction)',
            r'^date$', r'last.*(?:purchase|order|transaction).*date',
        ],
        'segment': [
            r'(?:cust|account|client).*(?:type|segment|class|tier|category)',
            r'segment', r'channel', r'trade.*class',
        ],
        'affinity_field': [
            r'cuisine.*type', r'industry.*(?:type|code|vertical)',
            r'sic.*code', r'naics', r'vertical',
        ],
        'product_group': [
            r'(?:attr|product|item).*(?:group|category|class|family).*(?:id|code|num)',
            r'category.*(?:id|code)',
        ],
        'product_group_name': [
            r'(?:attr|product|item).*(?:group|category|class|family).*(?:name|desc)',
            r'category.*(?:name|desc)',
        ],
        'price_zone': [r'price.*zone', r'pricing.*(?:zone|tier|level|band)'],
        'price_source': [
            r'price.*(?:source|type|method)', r'pricing.*(?:source|type)',
            r'cpa', r'contract.*type',
        ],
        'benchmark_price': [
            r'(?:benchmark|market|competitor|industry|npd).*(?:price|rate|avg)',
            r'(?:mkt|ind).*price',
        ],
        'benchmark_volume': [r'(?:benchmark|market|competitor|industry|npd).*(?:vol|qty|units)'],
        'benchmark_coverage': [
            r'(?:benchmark|market).*(?:coverage|markets|dmas|regions)',
            r'n.*(?:markets|dmas|regions)',
        ],
        'benchmark_customers': [
            r'(?:benchmark|market).*(?:customers|accounts|operators)',
            r'n.*(?:customers|operators)',
        ],
        'geography': [
            r'(?:dma|region|territory|market|area|zone|district)',
            r'(?:geo|geography|location|metro)', r'state', r'city', r'zip',
        ],
    }

    def __init__(self, filepath: str, sample_rows: int = 5000):
        self.filepath = filepath
        self.sample_rows = sample_rows
        self.df = None
        self.profile = {}

    def scan(self) -> Dict:
        self._load()
        self._profile_columns()
        self._auto_detect_roles()
        return self.profile

    def _load(self):
        ext = os.path.splitext(self.filepath)[1].lower()
        if ext in ('.xlsx', '.xls'):
            self.df = pd.read_excel(self.filepath, nrows=self.sample_rows, dtype=str)
        elif ext == '.tsv':
            self.df = pd.read_csv(self.filepath, sep='\t', nrows=self.sample_rows, dtype=str)
        else:
            self.df = pd.read_csv(self.filepath, nrows=self.sample_rows, dtype=str)

        self.df.columns = self.df.columns.str.strip()
        file_size = os.path.getsize(self.filepath)
        self.profile['file_info'] = {
            'filename': os.path.basename(self.filepath),
            'rows_sampled': len(self.df),
            'total_columns': len(self.df.columns),
            'file_size_mb': round(file_size / 1024 / 1024, 2),
            'scan_timestamp': datetime.now().isoformat(),
        }

    def _profile_columns(self):
        columns = []
        for col in self.df.columns:
            series = self.df[col]
            non_null = series.dropna()
            n_unique = non_null.nunique()
            n_total = len(series)
            n_null = series.isna().sum()
            inferred_type = self._infer_type(non_null)
            samples = non_null.head(5).tolist() if len(non_null) > 0 else []
            columns.append({
                'column_name': col, 'inferred_type': inferred_type,
                'n_unique': int(n_unique), 'n_null': int(n_null),
                'null_pct': round(n_null / n_total * 100, 1) if n_total > 0 else 0,
                'cardinality': 'HIGH' if n_unique > 100 else ('MEDIUM' if n_unique > 10 else 'LOW'),
                'sample_values': [str(s) for s in samples[:5]],
            })
        self.profile['columns'] = columns

    def _infer_type(self, series: pd.Series) -> str:
        if len(series) == 0:
            return 'empty'
        sample = series.head(200).astype(str)

        date_patterns = [r'\d{1,2}/\d{1,2}/\d{2,4}', r'\d{4}-\d{2}-\d{2}', r'\d{1,2}-\w{3}-\d{2,4}']
        if sum(sample.str.match('|'.join(date_patterns), na=False)) > len(sample) * 0.7:
            return 'date'
        if sum(sample.str.match(r'^[\$\-\(]', na=False)) > len(sample) * 0.5:
            return 'currency'
        if sum(sample.str.contains('%', na=False)) > len(sample) * 0.5:
            return 'percentage'

        cleaned = sample.str.replace(r'[\$,\%\(\)]', '', regex=True).str.strip()
        if pd.to_numeric(cleaned, errors='coerce').notna().sum() > len(sample) * 0.7:
            return 'numeric'

        unique_lower = set(sample.str.lower().str.strip().unique())
        if unique_lower.issubset({'yes', 'no', 'y', 'n', 'true', 'false', '1', '0', 'active', 'inactive', '', 'nan', 'none'}):
            return 'boolean'

        return 'text'

    def _auto_detect_roles(self):
        auto_mapping = {}
        matched_columns = set()

        for logical_name, patterns in self.PATTERNS.items():
            best_col, best_score = None, 0
            for col_info in self.profile['columns']:
                col = col_info['column_name']
                if col in matched_columns:
                    continue
                col_lower = col.lower().replace(' ', '').replace('_', '')
                for pattern in patterns:
                    pattern_clean = pattern.replace(' ', '').replace('_', '')
                    if re.search(pattern_clean, col_lower, re.IGNORECASE):
                        score = len(pattern)
                        if logical_name.startswith(('volume', 'price', 'margin', 'sales', 'delta', 'benchmark')):
                            if col_info['inferred_type'] in ('numeric', 'currency', 'percentage'):
                                score += 10
                        elif logical_name.endswith('_date'):
                            if col_info['inferred_type'] == 'date':
                                score += 10
                        elif logical_name.endswith(('_id', '_number')):
                            if col_info['cardinality'] in ('HIGH', 'MEDIUM'):
                                score += 5
                        if score > best_score:
                            best_score = score
                            best_col = col

            if best_col:
                auto_mapping[logical_name] = {
                    'column': best_col,
                    'confidence': 'HIGH' if best_score > 15 else ('MEDIUM' if best_score > 8 else 'LOW'),
                }
                matched_columns.add(best_col)

        self.profile['auto_mapping'] = auto_mapping
        self.profile['unmapped_columns'] = [
            c['column_name'] for c in self.profile['columns']
            if c['column_name'] not in matched_columns
        ]
