"""Statistical analysis functions."""

import pandas as pd
import numpy as np
from typing import Dict
from salesengine.config import ProjectConfig, get_global_config, _register


@_register('Statistical Analysis', 'revman')
def cramers_v(contingency_table: pd.DataFrame) -> float:
    """Cramér's V for categorical association strength (0–1)."""
    from scipy.stats import chi2_contingency
    chi2 = chi2_contingency(contingency_table)[0]
    n = contingency_table.sum().sum()
    phi2 = chi2 / n
    r, k = contingency_table.shape
    denom = min(k - 1, r - 1)
    return np.sqrt(phi2 / denom) if denom > 0 else 0


@_register('Statistical Analysis', 'revman')
def gini_coefficient(x) -> float:
    """Gini coefficient for concentration/inequality (0–1)."""
    x = np.sort(np.array(x, dtype=float))
    n = len(x)
    if n == 0 or x.sum() == 0:
        return 0
    cumx = np.cumsum(x)
    return (2.0 * np.sum((np.arange(1, n + 1) * x))) / (n * cumx[-1]) - (n + 1.0) / n


@_register('Statistical Analysis', 'revman', required_fields=[])
def run_statistical_summary(
    df: pd.DataFrame,
    group_col: str,
    outcome_col: str,
    label: str = "ANALYSIS",
    config: ProjectConfig = None
) -> Dict:
    """
    Chi-squared + Cramér's V + entropy + Gini in one call.

    Parameters
    ----------
    df : DataFrame
    group_col : str — column to group by
    outcome_col : str — column to measure
    label : str — descriptive label for this test
    """
    from scipy.stats import chi2_contingency, entropy as sp_entropy

    cfg = config or get_global_config()
    if not cfg.is_enabled('run_statistical_summary'):
        return {'verdict': 'DISABLED'}

    summary = {
        'label': label, 'total_rows': len(df),
        'unique_groups': df[group_col].nunique(),
        'chi2': None, 'p_value': None, 'cramers_v': None,
        'avg_entropy': None, 'gini': None, 'verdict': 'UNKNOWN'
    }

    try:
        ct = pd.crosstab(df[group_col], df[outcome_col])
        if ct.shape[0] > 1 and ct.shape[1] >= 2:
            chi2, p, dof, _ = chi2_contingency(ct)
            v = cramers_v(ct)
            summary.update({'chi2': round(chi2, 2), 'p_value': round(p, 6),
                            'cramers_v': round(v, 4)})
    except Exception:
        pass

    try:
        dist = pd.crosstab(df[group_col], df[outcome_col], normalize='index')
        row_ent = dist.apply(lambda r: sp_entropy(r, base=2), axis=1)
        summary['avg_entropy'] = round(row_ent.mean(), 4)
    except Exception:
        pass

    try:
        grp_sums = df.groupby(group_col)[outcome_col].sum().abs().values
        summary['gini'] = round(gini_coefficient(grp_sums), 4)
    except Exception:
        pass

    if summary['p_value'] is not None and summary['cramers_v'] is not None:
        if summary['p_value'] < 0.05 and summary['cramers_v'] >= 0.15:
            summary['verdict'] = '✅ STRONG SIGNAL'
        elif summary['p_value'] < 0.05:
            summary['verdict'] = '⚠️ SIGNIFICANT BUT WEAK'
        else:
            summary['verdict'] = '⛔ NOT SIGNIFICANT'

    return summary
