"""Basic tests for salesengine package."""

import pytest
import pandas as pd
import numpy as np
import os
import json
import tempfile


def test_import():
    import salesengine
    assert salesengine.__version__ == "0.1.0"


def test_clean_numeric():
    from salesengine import clean_numeric
    s = pd.Series(['$1,234.56', '(500)', 'N/A', '78%', '--'])
    result = clean_numeric(s)
    assert result.iloc[0] == 1234.56
    assert result.iloc[1] == -500
    assert result.iloc[2] == 0
    assert result.iloc[3] == 78
    assert result.iloc[4] == 0


def test_weighted_average():
    from salesengine import weighted_average
    vals = pd.Series([10, 20, 30])
    weights = pd.Series([100, 200, 300])
    result = weighted_average(vals, weights)
    expected = (10*100 + 20*200 + 30*300) / 600
    assert abs(result - expected) < 0.001


def test_classify_customer_movement():
    from salesengine import classify_customer_movement, ProjectConfig, set_global_config
    cfg = ProjectConfig()
    cfg.fields['customer_id'] = 'id'
    set_global_config(cfg)

    result = classify_customer_movement(
        current_customers={'A', 'B', 'C'},
        prior_customers={'B', 'C', 'D'},
        config=cfg,
    )
    assert result['retained'] == 2
    assert result['left_entirely'] == 1
    assert result['new_acquisition'] == 1


def test_assign_band():
    from salesengine import assign_band
    assert assign_band(3) == 'Band_01_Under5'
    assert assign_band(17) == 'Band_04_15to20'
    assert assign_band(50) == 'Band_09_Over40'


def test_classify_index():
    from salesengine import classify_index
    assert classify_index(1.0) == '✅ COMPETITIVE'
    assert 'HIGH' in classify_index(1.15)
    assert 'LOW' in classify_index(0.85)
    assert classify_index(None) == 'NO DATA'


def test_project_config():
    from salesengine import ProjectConfig
    cfg = ProjectConfig(project_name="Test", industry="Retail")
    cfg.fields['customer_id'] = 'Account_Number'
    assert cfg.has_field('customer_id')
    assert not cfg.has_field('volume_cy')
    assert cfg.col('customer_id') == 'Account_Number'
    assert cfg.col('volume_cy') is None


def test_list_functions():
    from salesengine import list_functions, ProjectConfig
    cfg = ProjectConfig()
    df = list_functions(cfg)
    assert len(df) > 0
    assert 'Function' in df.columns
    assert 'Status' in df.columns


def test_scanner():
    from salesengine import DatasetScanner
    # Create a small test CSV
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        f.write("Customer ID,Customer Name,Units Sold CY,Revenue CY,Region\n")
        f.write("C001,Acme Corp,100,5000,Northeast\n")
        f.write("C002,Beta Inc,200,8000,West\n")
        path = f.name

    try:
        scanner = DatasetScanner(path)
        profile = scanner.scan()
        assert profile['file_info']['total_columns'] == 5
        assert 'customer_id' in profile['auto_mapping']
    finally:
        os.unlink(path)


def test_full_pipeline():
    from salesengine import scan, run
    import tempfile, os

    # Create test data
    np.random.seed(42)
    n = 50
    df = pd.DataFrame({
        'Account Number': [f'C{i:03d}' for i in np.random.choice(range(20), n)],
        'Customer Name': [f'Cust {i}' for i in np.random.choice(range(20), n)],
        'Units Sold CY': np.random.randint(10, 500, n),
        'Units Sold PY': np.random.randint(10, 500, n),
        'Net Revenue CY': np.random.uniform(100, 5000, n).round(2),
        'Customer Segment': np.random.choice(['A', 'B', 'C'], n),
        'Region': np.random.choice(['East', 'West'], n),
    })

    with tempfile.TemporaryDirectory() as tmpdir:
        data_path = os.path.join(tmpdir, 'test.csv')
        df.to_csv(data_path, index=False)

        # Step 1: Scan
        profile = scan(data_path, save_to=os.path.join(tmpdir, 'intake.json'))
        assert os.path.exists(os.path.join(tmpdir, 'intake.json'))

        # Step 2: Fill in and run
        with open(os.path.join(tmpdir, 'intake.json')) as f:
            q = json.load(f)
        q['section_1_business_context']['project_name']['answer'] = 'Test'
        q['section_1_business_context']['industry']['answer'] = 'Retail'
        with open(os.path.join(tmpdir, 'intake.json'), 'w') as f:
            json.dump(q, f)

        result = run(data_path, os.path.join(tmpdir, 'intake.json'),
                     output_path=os.path.join(tmpdir, 'report.xlsx'))
        assert os.path.exists(os.path.join(tmpdir, 'report.xlsx'))
        assert len(result['analyses_run']) > 0
