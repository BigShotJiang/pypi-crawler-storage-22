"""
PDF report output using ReportLab.

Generates professional formatted PDF reports from SalesEngine analysis results.
Extracted from KTG report_template.py design system, made universal.

Install: pip install salesengine[pdf]
Requires: reportlab
"""

import os
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from salesengine.config import ProjectConfig, get_global_config, _register

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import inch
    from reportlab.lib.colors import HexColor, white, black
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, KeepTogether
    )
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False


# ═══════════════════════════════════════════════════════════════
# DESIGN SYSTEM — Colors, styles, reusable components
# ═══════════════════════════════════════════════════════════════

# Brand colors (professional teal theme)
TEAL = HexColor("#0B7B7F") if REPORTLAB_AVAILABLE else None
TEAL_DARK = HexColor("#065A5D") if REPORTLAB_AVAILABLE else None
TEAL_LIGHT = HexColor("#E6F3F3") if REPORTLAB_AVAILABLE else None
GRAY_TEXT = HexColor("#333333") if REPORTLAB_AVAILABLE else None
GRAY_LIGHT = HexColor("#666666") if REPORTLAB_AVAILABLE else None
GRAY_BG = HexColor("#F5F5F5") if REPORTLAB_AVAILABLE else None
GRAY_BORDER = HexColor("#DDDDDD") if REPORTLAB_AVAILABLE else None
ACCENT_ORANGE = HexColor("#E8720C") if REPORTLAB_AVAILABLE else None
RED = HexColor("#C00000") if REPORTLAB_AVAILABLE else None
GREEN = HexColor("#00B050") if REPORTLAB_AVAILABLE else None


def _init_styles():
    """Initialize paragraph styles. Call only when reportlab is available."""
    return {
        'title': ParagraphStyle('Title',
            fontName='Helvetica-Bold', fontSize=26, leading=32,
            textColor=TEAL, spaceAfter=6),
        'section': ParagraphStyle('SectionTitle',
            fontName='Helvetica-Bold', fontSize=18, leading=24,
            textColor=TEAL, spaceBefore=6, spaceAfter=4),
        'subsection': ParagraphStyle('SubsectionTitle',
            fontName='Helvetica-Bold', fontSize=13, leading=18,
            textColor=TEAL, spaceBefore=8, spaceAfter=4),
        'body': ParagraphStyle('Body',
            fontName='Helvetica', fontSize=9.5, leading=14,
            textColor=GRAY_TEXT, spaceAfter=6),
        'body_bold': ParagraphStyle('BodyBold',
            fontName='Helvetica-Bold', fontSize=9.5, leading=14,
            textColor=GRAY_TEXT, spaceAfter=6),
        'caption': ParagraphStyle('Caption',
            fontName='Helvetica-Oblique', fontSize=8, leading=11,
            textColor=GRAY_LIGHT, spaceAfter=4),
        'subtitle': ParagraphStyle('Subtitle',
            fontName='Helvetica', fontSize=14, leading=18,
            textColor=GRAY_LIGHT, spaceAfter=12),
    }


# ═══════════════════════════════════════════════════════════════
# FORMATTING HELPERS
# ═══════════════════════════════════════════════════════════════

@_register('PDF Output', 'report_template')
def fmt_num(val, prefix="", suffix=""):
    """Smart number formatting: 1234567→1M, 12345→12K, 1234→1,234."""
    try:
        v = float(val)
    except (ValueError, TypeError):
        return str(val)
    if abs(v) >= 1_000_000:
        return f"{prefix}{v/1_000_000:.1f}M{suffix}"
    elif abs(v) >= 10_000:
        return f"{prefix}{v/1_000:.0f}K{suffix}"
    else:
        return f"{prefix}{v:,.0f}{suffix}"


@_register('PDF Output', 'report_template')
def fmt_pct(val):
    """Format percentage with +/- sign: 0.15→+15.0%, -0.03→-3.0%."""
    try:
        v = float(val)
        if abs(v) < 1:  # Assume decimal form (0.15 = 15%)
            return f"{v:+.1%}"
        else:  # Already in percent form (15 = 15%)
            return f"{v:+.1f}%"
    except (ValueError, TypeError):
        return str(val)


def fmt_currency(val, prefix="$"):
    """Format as currency: 1234567→$1.2M, 12345→$12K."""
    return fmt_num(val, prefix=prefix)


# ═══════════════════════════════════════════════════════════════
# REUSABLE PDF COMPONENTS
# ═══════════════════════════════════════════════════════════════

def make_stat_card(value_text, label_text):
    """
    Big number + label card for executive summaries.
    Use inside a Table for side-by-side layout (up to 4 across).
    """
    if not REPORTLAB_AVAILABLE:
        raise ImportError("reportlab required: pip install salesengine[pdf]")

    val_style = ParagraphStyle('StatVal',
        fontName='Helvetica-Bold', fontSize=28, leading=34,
        textColor=TEAL, alignment=TA_CENTER)
    lbl_style = ParagraphStyle('StatLbl',
        fontName='Helvetica', fontSize=9, leading=12,
        textColor=GRAY_LIGHT, alignment=TA_CENTER)

    card = Table(
        [[Paragraph(value_text, val_style)],
         [Paragraph(label_text, lbl_style)]],
        colWidths=[1.6 * inch],
        rowHeights=[0.45 * inch, 0.35 * inch]
    )
    card.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BOX', (0, 0), (-1, -1), 0.75, TEAL),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    return card


def make_table(headers, rows, col_widths=None, keep=False):
    """
    Styled data table with teal header row and alternating gray rows.
    Auto-bolds TOTAL rows. First column left-aligned, rest centered.
    """
    if not REPORTLAB_AVAILABLE:
        raise ImportError("reportlab required: pip install salesengine[pdf]")

    hdr_style = ParagraphStyle('TblHdr',
        fontName='Helvetica-Bold', fontSize=8.5, leading=11,
        textColor=white, alignment=TA_CENTER)
    cell_style = ParagraphStyle('TblCell',
        fontName='Helvetica', fontSize=8.5, leading=11,
        textColor=GRAY_TEXT, alignment=TA_CENTER)
    cell_left = ParagraphStyle('TblCellL',
        fontName='Helvetica', fontSize=8.5, leading=11,
        textColor=GRAY_TEXT, alignment=TA_LEFT)

    hdr_row = [Paragraph(h.replace('\n', '<br/>'), hdr_style) for h in headers]

    data_rows = []
    for row in rows:
        styled_row = []
        for i, cell in enumerate(row):
            s = cell_left if i == 0 else cell_style
            if row[0] in ('TOTAL', 'Total', 'GRAND TOTAL'):
                s = ParagraphStyle('TblBold',
                    fontName='Helvetica-Bold', fontSize=8.5, leading=11,
                    textColor=GRAY_TEXT, alignment=TA_LEFT if i == 0 else TA_CENTER)
            styled_row.append(Paragraph(str(cell), s))
        data_rows.append(styled_row)

    all_rows = [hdr_row] + data_rows
    tbl = Table(all_rows, colWidths=col_widths, repeatRows=1)

    style_cmds = [
        ('BACKGROUND', (0, 0), (-1, 0), TEAL),
        ('TEXTCOLOR', (0, 0), (-1, 0), white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 8.5),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
        ('TOPPADDING', (0, 0), (-1, 0), 6),
        ('GRID', (0, 0), (-1, -1), 0.5, GRAY_BORDER),
        ('LINEBELOW', (0, 0), (-1, 0), 1.5, TEAL_DARK),
        ('TOPPADDING', (0, 1), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('ALIGN', (0, 1), (0, -1), 'LEFT'),
        ('ALIGN', (1, 1), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]

    for i in range(1, len(all_rows)):
        if i % 2 == 0:
            style_cmds.append(('BACKGROUND', (0, i), (-1, i), GRAY_BG))

    if rows and rows[-1][0] in ('TOTAL', 'Total', 'GRAND TOTAL'):
        last = len(all_rows) - 1
        style_cmds.append(('LINEABOVE', (0, last), (-1, last), 1, TEAL))
        style_cmds.append(('FONTNAME', (0, last), (-1, last), 'Helvetica-Bold'))

    tbl.setStyle(TableStyle(style_cmds))
    return KeepTogether([tbl]) if keep else tbl


def _make_header_footer(title_text, footer_text):
    """Create a header/footer function for the doc builder."""
    def _draw(canvas, doc):
        canvas.saveState()
        w, h = letter
        # Header bar
        canvas.setFillColor(TEAL)
        canvas.rect(0, h - 0.4 * inch, w, 0.4 * inch, fill=1, stroke=0)
        canvas.setFillColor(white)
        canvas.setFont("Helvetica", 8)
        canvas.drawString(0.5 * inch, h - 0.27 * inch, title_text)
        canvas.drawRightString(w - 0.5 * inch, h - 0.27 * inch, f"Page {doc.page}")
        # Footer
        canvas.setStrokeColor(GRAY_BORDER)
        canvas.setLineWidth(0.5)
        canvas.line(0.5 * inch, 0.45 * inch, w - 0.5 * inch, 0.45 * inch)
        canvas.setFillColor(GRAY_LIGHT)
        canvas.setFont("Helvetica", 7)
        canvas.drawString(0.5 * inch, 0.3 * inch, footer_text)
        canvas.restoreState()
    return _draw


# ═══════════════════════════════════════════════════════════════
# DATAFRAME → PDF TABLE CONVERSION
# ═══════════════════════════════════════════════════════════════

def df_to_pdf_table(df, max_rows=30, col_formats=None):
    """
    Convert a DataFrame to make_table format (headers + rows of strings).

    col_formats: dict mapping column names to format functions.
        e.g. {'Pounds CY': lambda v: fmt_num(v), 'Revenue': lambda v: fmt_currency(v)}
    """
    headers = list(df.columns)
    col_formats = col_formats or {}

    rows = []
    for _, row in df.head(max_rows).iterrows():
        str_row = []
        for col in headers:
            val = row[col]
            if col in col_formats:
                str_row.append(col_formats[col](val))
            elif isinstance(val, float):
                if abs(val) >= 1000:
                    str_row.append(fmt_num(val))
                else:
                    str_row.append(f"{val:.1f}")
            else:
                str_row.append(str(val) if not pd.isna(val) else "—")
        rows.append(str_row)

    return headers, rows


# ═══════════════════════════════════════════════════════════════
# MAIN PDF REPORT BUILDER
# ═══════════════════════════════════════════════════════════════

@_register('PDF Output', 'salesengine v0.3.0')
def build_pdf_report(
    results: Dict[str, pd.DataFrame],
    summary_lines: List[str],
    output_path: str,
    config: ProjectConfig = None,
    title: str = None,
    subtitle: str = None,
) -> str:
    """
    Build a complete PDF report from SalesEngine analysis results.

    Parameters
    ----------
    results : dict — {sheet_name: DataFrame} from ReportEngine
    summary_lines : list — executive summary bullet points
    output_path : str — where to save the PDF
    config : ProjectConfig
    title : str — report title (defaults to config.project_name)
    subtitle : str — subtitle (defaults to config.industry)

    Returns the output path.
    """
    if not REPORTLAB_AVAILABLE:
        raise ImportError("reportlab required: pip install salesengine[pdf]")

    cfg = config or get_global_config()
    styles = _init_styles()
    report_title = title or cfg.project_name
    report_subtitle = subtitle or cfg.industry

    header_text = f"{report_title}  |  {report_subtitle}"
    footer_text = f"Generated by SalesEngine  |  {report_title}"
    header_footer = _make_header_footer(header_text, footer_text)

    story = []

    # ── Cover page ──
    story.append(Spacer(1, 2 * inch))
    story.append(Paragraph(report_title, styles['title']))
    story.append(Paragraph(report_subtitle, styles['subtitle']))
    story.append(Spacer(1, 0.3 * inch))

    # Summary stats
    if summary_lines:
        story.append(Paragraph("Report includes:", styles['body']))
        for line in summary_lines:
            clean = line.encode('ascii', 'replace').decode('ascii')
            story.append(Paragraph(f"&#8226;&nbsp;&nbsp;{clean}", styles['body']))
    story.append(PageBreak())

    # ── Table of contents ──
    story.append(Paragraph("Table of Contents", styles['section']))
    story.append(Spacer(1, 0.2 * inch))
    toc_style = ParagraphStyle('TOC',
        fontName='Helvetica-Bold', fontSize=11, leading=22,
        textColor=TEAL, leftIndent=20)
    for i, sheet_name in enumerate(results.keys(), 1):
        story.append(Paragraph(f"{i}.&nbsp;&nbsp;{sheet_name}", toc_style))
    story.append(PageBreak())

    # ── Each analysis as a section ──
    for i, (sheet_name, df) in enumerate(results.items(), 1):
        story.append(Paragraph(f"{i}. {sheet_name}", styles['section']))
        story.append(Spacer(1, 0.1 * inch))

        if df is None or len(df) == 0:
            story.append(Paragraph("<i>No data for this analysis.</i>", styles['caption']))
            story.append(PageBreak())
            continue

        # Executive summary gets stat cards
        if sheet_name == 'Executive Summary':
            _add_executive_summary_section(story, df, styles, cfg)
        else:
            # Standard table
            headers, rows = df_to_pdf_table(df, max_rows=40)
            n_cols = len(headers)
            avail_width = 7.0 * inch
            col_w = [avail_width / n_cols] * n_cols
            table = make_table(headers, rows, col_widths=col_w)
            story.append(table)
            story.append(Spacer(1, 0.1 * inch))
            story.append(Paragraph(
                f"<i>Showing {min(40, len(df))} of {len(df)} rows.</i>",
                styles['caption']))

        story.append(PageBreak())

    # ── Build ──
    doc = SimpleDocTemplate(
        output_path, pagesize=letter,
        leftMargin=0.6 * inch, rightMargin=0.6 * inch,
        topMargin=0.7 * inch, bottomMargin=0.6 * inch)

    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    print(f"📄 PDF saved: {output_path}")
    return output_path


def _add_executive_summary_section(story, df, styles, cfg):
    """Build stat cards + key metrics for the executive summary page."""
    # Try to extract key stats from the summary df
    cards_data = []
    for _, row in df.iterrows():
        metric = str(row.get('Metric', row.iloc[0] if len(row) > 0 else ''))
        value = row.get('Value', row.iloc[1] if len(row) > 1 else '')
        if metric and value and str(value) not in ('', 'nan', '—'):
            cards_data.append((str(value), metric))

    # Show up to 4 as stat cards
    if cards_data:
        card_row = []
        for val, label in cards_data[:4]:
            card_row.append(make_stat_card(val, label.replace(' ', '\n')))

        n_cards = len(card_row)
        cards_table = Table([card_row], colWidths=[1.75 * inch] * n_cards)
        cards_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        story.append(cards_table)
        story.append(Spacer(1, 0.15 * inch))

    # Remaining metrics as bullet points
    if len(cards_data) > 4:
        for val, label in cards_data[4:]:
            story.append(Paragraph(
                f"&#8226;&nbsp;&nbsp;<b>{label}:</b> {val}",
                styles['body']))
