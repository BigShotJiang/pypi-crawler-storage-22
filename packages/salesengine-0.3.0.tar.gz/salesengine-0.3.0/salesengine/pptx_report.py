"""
PowerPoint report output using python-pptx.

Generates executive-ready slide decks from SalesEngine analysis results.
Extracted from KTG categoryv2.py slide system, made universal.

Install: pip install salesengine[pptx]
Requires: python-pptx
"""

import os
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from salesengine.config import ProjectConfig, get_global_config, _register

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False


# ═══════════════════════════════════════════════════════════════
# DESIGN SYSTEM
# ═══════════════════════════════════════════════════════════════

# Brand colors
COLOR_PRIMARY = RGBColor(11, 123, 127) if PPTX_AVAILABLE else None     # Teal
COLOR_DARK = RGBColor(6, 90, 93) if PPTX_AVAILABLE else None           # Dark teal
COLOR_ACCENT = RGBColor(232, 114, 12) if PPTX_AVAILABLE else None      # Orange
COLOR_TEXT = RGBColor(51, 51, 51) if PPTX_AVAILABLE else None           # Dark gray
COLOR_LIGHT = RGBColor(102, 102, 102) if PPTX_AVAILABLE else None      # Light gray
COLOR_RED = RGBColor(192, 0, 0) if PPTX_AVAILABLE else None
COLOR_GREEN = RGBColor(0, 176, 80) if PPTX_AVAILABLE else None
COLOR_WHITE = RGBColor(255, 255, 255) if PPTX_AVAILABLE else None
COLOR_BG = RGBColor(245, 245, 245) if PPTX_AVAILABLE else None


# ═══════════════════════════════════════════════════════════════
# SLIDE HELPERS
# ═══════════════════════════════════════════════════════════════

def _add_text_box(slide, left, top, width, height, text,
                  font_size=12, bold=False, color=None, align=PP_ALIGN.LEFT):
    """Add a text box to a slide."""
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top),
                                     Inches(width), Inches(height))
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color or COLOR_TEXT
    p.alignment = align
    return tf


def _add_table_to_slide(slide, df, left, top, width, height, max_rows=15):
    """
    Add a DataFrame as a formatted table on a slide.
    Teal header, alternating row shading, auto-sized.
    """
    display_df = df.head(max_rows)
    rows = len(display_df) + 1  # +1 for header
    cols = len(display_df.columns)

    table_shape = slide.shapes.add_table(
        rows, cols,
        Inches(left), Inches(top), Inches(width), Inches(height))
    table = table_shape.table

    # Header row
    for j, col_name in enumerate(display_df.columns):
        cell = table.cell(0, j)
        cell.text = str(col_name)
        _style_cell(cell, font_size=9, bold=True,
                    font_color=COLOR_WHITE, fill_color=COLOR_PRIMARY)

    # Data rows
    for i, (_, row) in enumerate(display_df.iterrows()):
        fill = COLOR_BG if i % 2 == 1 else None
        for j, col_name in enumerate(display_df.columns):
            cell = table.cell(i + 1, j)
            val = row[col_name]
            if isinstance(val, float) and abs(val) >= 1000:
                from salesengine.pdf_report import fmt_num
                cell.text = fmt_num(val)
            elif isinstance(val, float):
                cell.text = f"{val:.1f}"
            elif pd.isna(val):
                cell.text = "—"
            else:
                cell.text = str(val)
            _style_cell(cell, font_size=8, fill_color=fill)

    return table


def _style_cell(cell, font_size=9, bold=False, font_color=None,
                fill_color=None, align=PP_ALIGN.CENTER):
    """Style a table cell."""
    for paragraph in cell.text_frame.paragraphs:
        paragraph.font.size = Pt(font_size)
        paragraph.font.bold = bold
        paragraph.font.color.rgb = font_color or COLOR_TEXT
        paragraph.alignment = align
    if fill_color:
        cell.fill.solid()
        cell.fill.fore_color.rgb = fill_color


# ═══════════════════════════════════════════════════════════════
# SLIDE TYPES
# ═══════════════════════════════════════════════════════════════

def _create_cover_slide(prs, title, subtitle, date_text=None):
    """Create branded cover slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank

    # Accent bar
    shape = slide.shapes.add_shape(
        1, Inches(0), Inches(1.8), Inches(10), Inches(0.08))
    shape.fill.solid()
    shape.fill.fore_color.rgb = COLOR_PRIMARY
    shape.line.fill.background()

    # Title
    _add_text_box(slide, 1, 2.2, 8, 1.2, title,
                  font_size=32, bold=True, color=COLOR_PRIMARY)

    # Subtitle
    _add_text_box(slide, 1, 3.4, 8, 0.6, subtitle,
                  font_size=18, color=COLOR_LIGHT)

    # Date
    if date_text:
        _add_text_box(slide, 1, 6.5, 8, 0.4, date_text,
                      font_size=10, color=COLOR_LIGHT)

    # Footer
    _add_text_box(slide, 1, 6.9, 8, 0.3, "Generated by SalesEngine",
                  font_size=8, color=COLOR_LIGHT)


def _create_executive_slide(prs, summary_lines, results, cfg):
    """Executive summary slide with key metrics."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    _add_text_box(slide, 0.5, 0.3, 8, 0.6,
                  "Executive Summary",
                  font_size=28, bold=True, color=COLOR_PRIMARY)

    # Key metrics as text (stat cards don't work well in pptx without images)
    exec_df = results.get('Executive Summary')
    y_pos = 1.2

    if exec_df is not None and len(exec_df) > 0:
        for _, row in exec_df.head(8).iterrows():
            metric = str(row.iloc[0]) if len(row) > 0 else ''
            value = str(row.iloc[1]) if len(row) > 1 else ''
            if metric and value and metric != '---':
                tf = _add_text_box(slide, 0.8, y_pos, 8, 0.35,
                                   f"{metric}: ", font_size=14)
                # Add value as bold run
                run = tf.paragraphs[0].add_run()
                run.text = value
                run.font.size = Pt(14)
                run.font.bold = True
                run.font.color.rgb = COLOR_PRIMARY
                y_pos += 0.38

    # Summary lines
    if summary_lines:
        y_pos += 0.2
        _add_text_box(slide, 0.5, y_pos, 8, 0.3,
                      "Analyses Run:", font_size=12, bold=True)
        y_pos += 0.35
        for line in summary_lines[:8]:
            clean = line.encode('ascii', 'replace').decode('ascii')
            _add_text_box(slide, 0.8, y_pos, 8, 0.25,
                          clean, font_size=10, color=COLOR_LIGHT)
            y_pos += 0.25


def _create_data_slide(prs, sheet_name, df):
    """Create a slide with a data table."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    _add_text_box(slide, 0.5, 0.3, 8, 0.5,
                  sheet_name,
                  font_size=24, bold=True, color=COLOR_PRIMARY)

    if df is None or len(df) == 0:
        _add_text_box(slide, 1, 2, 8, 1,
                      "No data available for this analysis.",
                      font_size=14, color=COLOR_LIGHT)
        return

    # Determine table dimensions
    max_cols = min(len(df.columns), 8)
    display_df = df.iloc[:, :max_cols]
    max_rows = min(len(display_df), 15)
    display_df = display_df.head(max_rows)

    table_width = min(9.0, max_cols * 1.2)
    table_height = min(5.5, (max_rows + 1) * 0.35)

    _add_table_to_slide(slide, display_df,
                        left=0.5, top=1.0,
                        width=table_width, height=table_height,
                        max_rows=max_rows)

    # Row count note
    if len(df) > max_rows:
        _add_text_box(slide, 0.5, 6.8, 8, 0.3,
                      f"Showing {max_rows} of {len(df)} rows. See Excel report for full data.",
                      font_size=8, color=COLOR_LIGHT)


# ═══════════════════════════════════════════════════════════════
# MAIN PPTX BUILDER
# ═══════════════════════════════════════════════════════════════

@_register('PPTX Output', 'salesengine v0.3.0')
def build_pptx_report(
    results: Dict[str, pd.DataFrame],
    summary_lines: List[str],
    output_path: str,
    config: ProjectConfig = None,
    title: str = None,
    subtitle: str = None,
) -> str:
    """
    Build a complete PowerPoint deck from SalesEngine analysis results.

    Parameters
    ----------
    results : dict — {sheet_name: DataFrame} from ReportEngine
    summary_lines : list — executive summary bullet points
    output_path : str — where to save the PPTX
    config : ProjectConfig
    title : str — deck title (defaults to config.project_name)
    subtitle : str — subtitle (defaults to config.industry)

    Returns the output path.
    """
    if not PPTX_AVAILABLE:
        raise ImportError("python-pptx required: pip install salesengine[pptx]")

    cfg = config or get_global_config()
    report_title = title or cfg.project_name
    report_subtitle = subtitle or cfg.industry

    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)

    # Slide 1: Cover
    from datetime import datetime
    date_text = datetime.now().strftime("%B %d, %Y")
    _create_cover_slide(prs, report_title, report_subtitle, date_text)

    # Slide 2: Executive summary
    _create_executive_slide(prs, summary_lines, results, cfg)

    # Remaining slides: one per analysis
    for sheet_name, df in results.items():
        if sheet_name == 'Executive Summary':
            continue
        _create_data_slide(prs, sheet_name, df)

    prs.save(output_path)
    print(f"📊 PPTX saved: {output_path}")
    return output_path
