"""
SalesEngine — Universal Sales Intelligence Engine
==================================================

Drop in any sales/transaction dataset, answer a short questionnaire,
and get standardized, executive-ready reports. Works across industries.

Quick Start
-----------
    >>> import salesengine as se
    >>> se.scan("my_data.csv")                    # auto-detect columns
    >>> se.run("my_data.csv", "intake.json")      # generate report

Or use individual components:

    >>> from salesengine import ProjectConfig, DatasetScanner
    >>> from salesengine.cleaning import clean_numeric
    >>> from salesengine.churn import classify_customer_movement
"""

__version__ = "0.3.1"
__author__ = "KTG"
__license__ = "MIT"

# --- Config System (always available) ---
from salesengine.config import (
    ProjectConfig,
    set_global_config,
    get_global_config,
    requires_fields,
    FUNCTION_REGISTRY,
    list_functions,
)

# --- Intake Engine ---
from salesengine.scanner import DatasetScanner
from salesengine.questionnaire import QuestionnaireGenerator
from salesengine.builder import ConfigBuilder
from salesengine.report import ReportEngine

# --- Convenience functions ---
from salesengine.cleaning import clean_numeric, clean_currency, clean_dataframe
from salesengine.stats import cramers_v, gini_coefficient, run_statistical_summary
from salesengine.aggregation import weighted_average, aggregate_to_grain
from salesengine.churn import classify_customer_movement, identify_non_buyers, determine_active_customers
from salesengine.computed import compute_derived_fields
from salesengine.fiscal import (
    detect_period_format, compute_recency,
    get_fiscal_quarter, get_fiscal_month_from_week,
)
from salesengine.index import calculate_price_index, classify_index, detect_index_conflicts
from salesengine.confidence import score_confidence, classify_confidence_band
from salesengine.banding import assign_band, calculate_priority_score
from salesengine.excel import get_excel_styles, style_header_row, auto_width, df_to_sheet
from salesengine.inspect import inspect_csv

# --- Optional output formats ---
try:
    from salesengine.pdf_report import build_pdf_report, fmt_num, fmt_pct, fmt_currency
except ImportError:
    pass  # reportlab not installed

try:
    from salesengine.pptx_report import build_pptx_report
except ImportError:
    pass  # python-pptx not installed


# --- Top-level shortcuts ---

def scan(filepath: str, sample_rows: int = 5000, save_to: str = None):
    """
    Scan a dataset and generate an intake questionnaire.

    Parameters
    ----------
    filepath : str
        Path to CSV or Excel file.
    sample_rows : int
        Number of rows to sample for profiling.
    save_to : str, optional
        Where to save the questionnaire JSON. Defaults to same directory.

    Returns
    -------
    dict : Scan profile with auto-detected field mappings.
    """
    import os

    scanner = DatasetScanner(filepath, sample_rows=sample_rows)
    profile = scanner.scan()

    qgen = QuestionnaireGenerator(profile)
    questionnaire = qgen.generate()

    if save_to is None:
        base = os.path.splitext(filepath)[0]
        save_to = f"{base}_intake.json"

    qgen.save(save_to)

    n_mapped = len(profile.get('auto_mapping', {}))
    n_unmapped = len(profile.get('unmapped_columns', []))
    print(f"\n✅ Scanned {profile['file_info']['total_columns']} columns")
    print(f"   🤖 Auto-detected: {n_mapped} fields")
    print(f"   ❓ Unmatched: {n_unmapped} columns")
    print(f"   📝 Questionnaire: {save_to}")
    print(f"\n   Next: fill in the JSON, then run:")
    print(f"   >>> salesengine.run('{filepath}', '{save_to}')")

    return profile


def run(data_path: str, questionnaire_path: str, output_path: str = None,
        formats: list = None):
    """
    Run the full analysis pipeline from a filled questionnaire.

    Parameters
    ----------
    data_path : str
        Path to CSV or Excel file.
    questionnaire_path : str
        Path to the filled-in questionnaire JSON.
    output_path : str, optional
        Where to save the report. Auto-generated if not provided.
    formats : list, optional
        Output formats: ['excel'], ['pdf'], ['pptx'], ['all'], or any combo.
        Default: ['excel']. PDF requires reportlab, PPTX requires python-pptx.

    Returns
    -------
    dict : Results with config, report path, and analysis summaries.
    """
    import os
    import json
    import pandas as pd

    if formats is None:
        formats = ['excel']

    # Load questionnaire
    with open(questionnaire_path, 'r') as f:
        questionnaire = json.load(f)

    # Build config
    builder = ConfigBuilder(questionnaire_dict=questionnaire)
    config = builder.build()
    print(config.status())

    # Load data
    ext = os.path.splitext(data_path)[1].lower()
    if ext in ('.xlsx', '.xls'):
        df = pd.read_excel(data_path)
    else:
        df = pd.read_csv(data_path)

    # Run engine
    engine = ReportEngine(df, config, questionnaire)
    engine.run()

    # Save
    if output_path is None:
        safe_name = config.project_name.replace(' ', '_').replace('/', '_')
        output_path = os.path.join(os.path.dirname(data_path),
                                    f"{safe_name}_Report.xlsx")
    engine.save(output_path, formats=formats)

    return {
        'config': config,
        'report_path': output_path,
        'analyses_run': list(engine.results.keys()),
        'summary': engine.summary_lines,
    }
