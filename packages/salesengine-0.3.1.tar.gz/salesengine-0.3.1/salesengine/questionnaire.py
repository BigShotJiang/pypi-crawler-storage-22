"""Generates a structured JSON questionnaire from scan results."""

import json
from typing import Dict, List
from datetime import datetime


class QuestionnaireGenerator:
    """
    Builds a JSON questionnaire with smart defaults from auto-detection.

    Sections:
      1. Business Context
      2. Field Mapping (with auto-detected defaults)
      3. Business Rules (churn, leads, growth, pricing, margin)
      4. Thresholds
      5. Report Preferences
    """

    def __init__(self, scan_profile: Dict):
        self.profile = scan_profile
        self.questionnaire = {}

    def generate(self) -> Dict:
        self.questionnaire = {
            '_meta': {
                'version': '1.0',
                'generated': datetime.now().isoformat(),
                'source_file': self.profile['file_info']['filename'],
                'total_columns': self.profile['file_info']['total_columns'],
                'rows_sampled': self.profile['file_info']['rows_sampled'],
                'instructions': (
                    "Fill in each section. Fields with 'auto_detected' have been "
                    "pre-filled — confirm or change them. Set to null to skip."
                ),
            },
            'section_1_business_context': self._build_business_context(),
            'section_2_field_mapping': self._build_field_mapping(),
            'section_3_business_rules': self._build_business_rules(),
            'section_4_thresholds': self._build_thresholds(),
            'section_5_report_preferences': self._build_report_preferences(),
        }
        return self.questionnaire

    def save(self, filepath: str):
        with open(filepath, 'w') as f:
            json.dump(self.questionnaire, f, indent=2, default=str)
        print(f"✅ Questionnaire saved to: {filepath}")

    def _build_business_context(self) -> Dict:
        return {
            '_instructions': "Tell us about your business.",
            'project_name': {'question': 'What is this project called?', 'answer': None,
                             'example': 'Q1 2025 Revenue Review'},
            'industry': {'question': 'What industry?', 'answer': None,
                         'options': ['Food Distribution', 'Retail', 'SaaS / Software',
                                     'Healthcare', 'Manufacturing', 'Financial Services',
                                     'Logistics', 'Hospitality', 'Other']},
            'unit_of_measure': {'question': 'Primary volume unit?', 'answer': None,
                                'example': 'lbs, cases, units, seats, licenses'},
            'currency': {'question': 'Currency?', 'answer': 'USD',
                         'options': ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'Other']},
            'time_grain': {'question': 'Time period per row?', 'answer': None,
                           'options': ['Weekly', 'Monthly', 'Quarterly', 'Annual', 'Transaction-level']},
            'comparison_type': {'question': 'What are you comparing?', 'answer': None,
                                'options': ['Recent dataset vs older dataset (e.g., FY2025 vs FY2024)',
                                            'Plan vs Actual',
                                            'This Quarter vs Last Quarter',
                                            'None / Single dataset only']},
            'fiscal_calendar': {
                '_label': '📅 FISCAL CALENDAR',
                '_instructions': (
                    'How does your company track time? This affects how the engine '
                    'interprets period IDs and handles year boundaries.'
                ),
                'calendar_type': {
                    'question': 'Fiscal year or calendar year?',
                    'answer': 'fiscal',
                    'options': ['calendar', 'fiscal'],
                },
                'fiscal_start_month': {
                    'question': (
                        'What calendar month does your fiscal year START? '
                        '(1=Jan, 7=Jul, 10=Oct, etc.) '
                        'Set to 1 if calendar year.'
                    ),
                    'answer': 1,
                    'example': '7 for July (food distribution), 10 for October (US Gov), 2 for February (retail)',
                },
                'fiscal_pattern': {
                    'question': (
                        'What weekly pattern does your fiscal calendar use?'
                    ),
                    'answer': 'weekly_52',
                    'options': [
                        '445 — 4wk + 4wk + 5wk quarters (common in retail/food)',
                        '454 — 4wk + 5wk + 4wk quarters',
                        '544 — 5wk + 4wk + 4wk quarters',
                        '13_period — 13 four-week periods per year',
                        'monthly — standard 12 calendar months',
                        'weekly_52 — simple 52-week year',
                    ],
                },
                'period_format': {
                    'question': (
                        'How is the period/week column formatted? '
                        'Set to "auto" to let the engine detect it.'
                    ),
                    'answer': 'auto',
                    'options': [
                        'auto — let the engine detect',
                        'YYYYWW — e.g., 202533 = FY2025 Week 33',
                        'YYYYPP — e.g., 202507 = FY2025 Period 07',
                        'WW — just the week number (1-52)',
                        'PP — just the period number (1-13)',
                        'date — actual dates (MM/DD/YYYY or YYYY-MM-DD)',
                    ],
                },
                'weeks_in_year': {
                    'question': 'How many weeks/periods per year?',
                    'answer': 52,
                    'options': [52, 53, 13, 12],
                },
            },
        }

    def _build_field_mapping(self) -> Dict:
        auto = self.profile.get('auto_mapping', {})
        all_cols = [c['column_name'] for c in self.profile['columns']]

        mapping = {
            '_instructions': "Confirm or correct auto-detected columns. Set to null to skip.",
            '_available_columns': all_cols,
        }

        field_groups = {
            'identifiers': {
                '_label': '🏷️  IDENTIFIERS — Customer & Product',
                'customer_id': 'Unique customer/account identifier (the end-user who buys)',
                'customer_name': 'Customer display name',
                'item_number': 'Product SKU / item number',
                'item_description': 'Product description',
            },
            'volume': {
                '_label': '📦  VOLUME',
                'volume_cy': 'Volume — your MORE RECENT dataset (the one you want to analyze)',
                'volume_py': 'Volume — your COMPARISON dataset (what you are measuring against)',
                'delta_volume': 'Volume change (auto-computed if not provided)',
            },
            'price_and_sales': {
                '_label': '💰  PRICE & SALES',
                'price_per_unit_cy': 'Price per unit — recent (auto-computed from sales / volume)',
                'price_per_unit_py': 'Price per unit — comparison',
                'sales_ext_cy': 'Extended sales $ — recent dataset',
                'sales_ext_py': 'Extended sales $ — comparison dataset',
            },
            'margin': {
                '_label': '📊  MARGIN',
                'margin_per_unit_cy': 'Margin per unit — recent',
                'margin_per_unit_py': 'Margin per unit — comparison',
                'margin_ext_cy': 'Extended margin $ — recent',
                'margin_ext_py': 'Extended margin $ — comparison',
                'margin_pct_cy': 'Margin % — recent (auto-computed from margin $ / sales $)',
                'margin_pct_py': 'Margin % — comparison',
            },
            'time': {
                '_label': '📅  TIME',
                'fiscal_week': 'Fiscal week / period',
                'fiscal_year': 'Fiscal year',
                'invoice_date': 'Transaction date',
            },
            'segmentation': {
                '_label': '🏷️  SEGMENTATION',
                'segment': 'Customer segment / tier',
                'affinity_field': 'Affinity (cuisine, industry, SIC...)',
                'product_group': 'Product category code',
                'product_group_name': 'Product category name',
            },
            'pricing_structure': {
                '_label': '🏪  PRICING',
                'price_zone': 'Price zone / tier',
                'price_source': 'Price source type',
            },
            'benchmarking': {
                '_label': '📈  BENCHMARKING',
                'benchmark_price': 'Market / competitor price',
                'benchmark_volume': 'Market volume',
                'benchmark_coverage': 'Markets in benchmark',
                'benchmark_customers': 'Customers in benchmark',
            },
            'geography': {
                '_label': '🌍  GEOGRAPHY',
                'geography': 'Region / DMA / territory',
            },
        }

        for group_key, group_fields in field_groups.items():
            group_out = {'_label': group_fields.pop('_label')}
            for logical_name, description in group_fields.items():
                auto_info = auto.get(logical_name, {})
                auto_col = auto_info.get('column', None)
                confidence = auto_info.get('confidence', None)
                group_out[logical_name] = {
                    'description': description,
                    'auto_detected': auto_col,
                    'auto_confidence': confidence,
                    'your_answer': auto_col,
                    'set_null_to_skip': True,
                }
            mapping[group_key] = group_out

        unmapped = self.profile.get('unmapped_columns', [])
        if unmapped:
            mapping['_unmapped_columns'] = {
                '_label': '❓ UNMATCHED COLUMNS',
                '_instructions': "These weren't auto-matched. Update mappings above if needed.",
                'columns': unmapped,
            }

        # ── Organizational Hierarchy ──
        mapping['org_hierarchy'] = {
            '_label': '🏢 ORGANIZATIONAL HIERARCHY',
            '_instructions': (
                "Define who OWNS the customer relationship, from the level directly "
                "above the customer up to the top. Examples: Branch→Region→Market, "
                "or Franchise→Territory→Division. Leave empty [] if flat structure.\n\n"
                "Each level needs: label (what you call it), id (the code/number column), "
                "and optionally name (the display name column)."
            ),
            'levels': {
                'question': (
                    'What levels exist ABOVE the customer? List from lowest (closest '
                    'to customer) to highest. Use your column names.'
                ),
                'answer': [],
                'example': [
                    {"label": "Site", "id": "Company Number *", "name": "Company Name *"},
                    {"label": "Region", "id": "Company Region ID", "name": "Company Region Name"},
                    {"label": "Market", "id": "Company Market Level", "name": None}
                ],
            },
        }

        # ── Geographic Hierarchy ──
        mapping['geo_hierarchy'] = {
            '_label': '🌍 GEOGRAPHIC HIERARCHY',
            '_instructions': (
                "Define WHERE the business happens, from most granular to broadest. "
                "This controls geographic breakdowns in reports — you'll get a separate "
                "analysis at each level. Can overlap with org hierarchy.\n\n"
                "If you only have one geography column, just put it in the flat "
                "'geography' field above and leave this empty."
            ),
            'levels': {
                'question': (
                    'What geographic levels do you want reports at? '
                    'List from most granular to broadest.'
                ),
                'answer': [],
                'example': [
                    {"label": "Branch", "column": "Company Name *"},
                    {"label": "Region", "column": "Company Region Name"},
                    {"label": "Market", "column": "Company Market Level"}
                ],
            },
        }

        return mapping

    def _build_business_rules(self) -> Dict:
        return {
            '_instructions': "Define your business terms. These become the single source of truth.",
            'customer_churn': {
                '_label': '🚪 CHURN',
                'enable_churn_analysis': {'question': 'Analyze customer churn?', 'answer': True},
                'churn_definition': {
                    'question': 'How do you define a "lost" customer?',
                    'answer': None,
                    'options': [
                        'No purchases within recency window (recommended — uses activity window below)',
                        'Volume dropped below threshold vs comparison dataset',
                        'Account marked inactive in source data',
                        'Custom',
                    ],
                },
                'churn_activity_window': {
                    'question': (
                        'How many weeks/periods define "recently active"?\n'
                        'The engine looks at the LAST date in your dataset and counts '
                        'backward. A customer who purchased within this window is "active." '
                        'Anyone outside it is considered lost.\n\n'
                        'Example: If your data ends at week 202552 and you set this to 6, '
                        'then "active" = purchased in weeks 202547-202552.\n\n'
                        'Set to null to skip recency and just use "any volume > 0 in CY data."'
                    ),
                    'answer': None,
                    'example': 6,
                },
                'churn_activity_field': {
                    'question': (
                        'Which time field to measure recency against?\n'
                        'This should be the field that identifies WHEN each transaction '
                        'happened (fiscal week, period, or date).'
                    ),
                    'answer': 'fiscal_week',
                    'options': ['fiscal_week', 'fiscal_year', 'invoice_date'],
                },
                'churn_volume_threshold_pct': {
                    'question': (
                        'What volume drop % flags a customer as "at risk"?\n'
                        'E.g., 50 = if they dropped 50%+ vs comparison dataset, flag them.'
                    ),
                    'answer': 50,
                },
                'distinguish_migration_from_churn': {
                    'question': (
                        'Separate branch migration from true churn?\n'
                        'If YES: a customer who stopped buying from YOUR site but still '
                        'buys from another site is counted as "migrated," not "lost."\n'
                        'If NO: all departures count as churn.\n'
                        '(Requires org hierarchy to be defined above.)'
                    ),
                    'answer': True,
                },
                'churn_lookback_periods': {
                    'question': (
                        'How many consecutive periods of zero purchases = churned?\n'
                        'Set to 1 for strict (one missed period = churned).\n'
                        'Set higher for cyclical buyers (e.g., 13 for quarterly buyers).'
                    ),
                    'answer': 1,
                },
            },
            'customer_acquisition': {
                '_label': '🎯 ACQUISITION / PROSPECTING',
                '_description': (
                    'Finds customers who SHOULD be buying but AREN\'T.\n\n'
                    '⚠️  REQUIRES A SECOND FILE: a customer universe/master list '
                    'that includes non-buyers. Your sales data only has existing '
                    'buyers. Multi-file intake is planned for a future version.\n\n'
                    'If you don\'t have a universe file, set enable_lead_scoring to false.'
                ),
                'enable_lead_scoring': {
                    'question': (
                        'Do you have a customer universe file loaded?\n'
                        'Set to false if you only have sales data (most common).'
                    ),
                    'answer': False,
                },
                'high_affinity_values': {
                    'question': (
                        'What values in your affinity column indicate a likely buyer?\n'
                        'The engine finds universe customers with these values who '
                        'don\'t appear in your sales data = prospects.'
                    ),
                    'answer': [],
                    'example': ['Seafood Restaurant', 'Sushi'],
                },
                'good_lead_criteria': {
                    'question': 'Additional criteria for qualifying leads?',
                    'answer': None,
                    'options': ['High affinity + high volume', 'High conversion segment',
                                'Geographic proximity', 'Custom'],
                },
            },
            'growth_classification': {
                '_label': '📈 GROWTH',
                '_description': (
                    'These thresholds define what counts as "growing," "declining," '
                    'or "significant change" when comparing your recent dataset to '
                    'your comparison dataset.'
                ),
                'growth_threshold_pct': {
                    'question': (
                        'What % volume increase = "growing"?\n'
                        'Default 5 means volume needs to be up 5%+ vs comparison '
                        'dataset to be classified as growing.\n'
                        'Below this but above the decline threshold = "flat."'
                    ),
                    'answer': 5,
                },
                'decline_threshold_pct': {
                    'question': (
                        'What % volume decrease = "declining"?\n'
                        'Default -5 means down 5%+ vs comparison = declining.\n'
                        'Between -5% and +5% = flat/stable.'
                    ),
                    'answer': -5,
                },
                'significant_change_pct': {
                    'question': (
                        'What % change is big enough to FLAG in the report?\n'
                        'Default 15 means any customer/segment that moved 15%+ '
                        'in either direction gets highlighted for attention.\n'
                        'Think of this as: "what change would make me pick up the phone?"'
                    ),
                    'answer': 15,
                },
            },
            'pricing_health': {
                '_label': '💲 PRICING',
                '_description': (
                    'Controls the price benchmarking analysis. Only relevant if you '
                    'have benchmark/competitor pricing data.\n\n'
                    'If you don\'t have benchmark data, set enable_price_index to false '
                    'and skip this section.'
                ),
                'enable_price_index': {
                    'question': (
                        'Do you have benchmark or competitor pricing data loaded?\n'
                        'If NO, set to false — the pricing analysis will be skipped.\n'
                        'If YES, the engine compares your prices to the benchmark '
                        'at both the item level and category level, and flags conflicts '
                        'where the two disagree.'
                    ),
                    'answer': False,
                },
                'competitive_range_low': {
                    'question': (
                        'Below what price index = underpriced?\n'
                        'Default 0.90 means if your price is more than 10% below '
                        'the benchmark, you may be leaving margin on the table.'
                    ),
                    'answer': 0.90,
                },
                'competitive_range_high': {
                    'question': (
                        'Above what price index = overpriced?\n'
                        'Default 1.10 means if your price is more than 10% above '
                        'the benchmark, you may be losing customers on price.'
                    ),
                    'answer': 1.10,
                },
                'extreme_threshold': {
                    'question': (
                        'Above what price index = extreme?\n'
                        'Default 1.50 means 50%+ above market. These get red-flagged '
                        'in the report as urgent.'
                    ),
                    'answer': 1.50,
                },
            },
            'margin_health': {
                '_label': '📊 MARGIN',
                '_description': (
                    'Controls margin analysis. If your data has margin columns '
                    '(dollar or percentage), enable this. If your data only has margin '
                    'dollars and net sales, the engine auto-computes margin %.'
                ),
                'enable_margin_analysis': {
                    'question': (
                        'Do you have margin data (either margin $ or margin %)?\n'
                        'If YES, the engine groups customers/products into margin bands '
                        'and flags unhealthy margins.\n'
                        'If your data has margin $ and sales $ but no margin %, '
                        'the engine computes it automatically — still set this to true.'
                    ),
                    'answer': False,
                },
                'target_margin_pct': {
                    'question': (
                        'What is your target margin %?\n'
                        'Default 25 means your business aims for 25% margin. '
                        'Customers/products below this are flagged as below target.'
                    ),
                    'answer': 25,
                },
                'margin_floor_pct': {
                    'question': (
                        'Below what margin % = unhealthy/critical?\n'
                        'Default 10 means anything below 10% margin is a problem. '
                        'These get red-flagged in the report.'
                    ),
                    'answer': 10,
                },
                'margin_bands': {
                    'question': (
                        'Custom margin bands for grouping?\n'
                        'Set to null to use defaults (5% increments from 0-40+).\n'
                        'Or define your own bands as [threshold, label] pairs.\n'
                        'Each band captures everything from the previous threshold '
                        'up to this number.'
                    ),
                    'answer': None,
                    'example': [
                        [5, 'Critical — below 5%'],
                        [15, 'Below Target — 5% to 15%'],
                        [25, 'At Target — 15% to 25%'],
                        [100, 'Above Target — 25%+'],
                    ],
                },
            },
            'customer_value': {
                '_label': '⭐ CUSTOMER VALUE',
                '_description': (
                    'Controls how customers are ranked for priority.\n\n'
                    'NOTE: In a future version this will become a weighted composite '
                    'score (0-100) applied at every level of your org hierarchy. '
                    'For now, it produces a simple ranking by the factors you choose.'
                ),
                'enable_priority_scoring': {
                    'question': (
                        'Rank customers by priority?\n'
                        'If YES, the report includes a ranked customer list showing '
                        'volume share, cumulative share, and key metrics.'
                    ),
                    'answer': True,
                },
                'priority_factors': {
                    'question': (
                        'Which factors matter most for customer priority?\n'
                        'Rank from 1 (most important) to 4 (least).\n\n'
                        '  volume_share: What % of your total volume does this customer represent?\n'
                        '  margin_contribution: What % of total margin $ comes from this customer?\n'
                        '  growth_trajectory: Is this customer growing or shrinking vs prior year?\n'
                        '  retention_risk: Is this customer at risk of leaving (volume declining)?\n\n'
                        'Set any factor to null to exclude it.'
                    ),
                    'answer': {
                        'volume_share': 1,
                        'margin_contribution': 2,
                        'growth_trajectory': 3,
                        'retention_risk': 4,
                    },
                },
            },
        }

    def _build_thresholds(self) -> Dict:
        return {
            '_instructions': (
                "Numeric thresholds that control how the engine classifies and flags data.\n"
                "Defaults work for most industries. Only change these if you know your "
                "business needs different cutoffs.\n\n"
                "If you're not sure what something means, leave the default — it won't "
                "break anything."
            ),
            'index_thresholds': {
                '_label': '📏 PRICE INDEX THRESHOLDS',
                '_description': (
                    "A Price Index compares YOUR price to a BENCHMARK price.\n"
                    "  Index = Your Price / Benchmark Price\n"
                    "  1.00 = you're priced exactly at market\n"
                    "  1.10 = you're 10% ABOVE market (more expensive)\n"
                    "  0.90 = you're 10% BELOW market (cheaper)\n\n"
                    "These thresholds define when the engine flags a price as "
                    "problematic. Only relevant if you have benchmark/competitor "
                    "pricing data loaded."
                ),
                'extreme_high': {
                    'question': (
                        'Above what index = EXTREME overpricing?\n'
                        'Default 1.50 means 50% above market. Anything above this '
                        'gets a red flag in the report.'
                    ),
                    'answer': 1.50,
                },
                'high': {
                    'question': (
                        'Above what index = overpriced?\n'
                        'Default 1.10 means 10% above market. This is the threshold '
                        'where pricing starts to be a concern.'
                    ),
                    'answer': 1.10,
                },
                'low': {
                    'question': (
                        'Below what index = underpriced?\n'
                        'Default 0.90 means 10% below market. You might be leaving '
                        'margin on the table.'
                    ),
                    'answer': 0.90,
                },
            },
            'confidence_thresholds': {
                '_label': '🛡️ DATA CONFIDENCE THRESHOLDS',
                '_description': (
                    "Not all data points are equally trustworthy. If you're comparing "
                    "your price to a benchmark that only has 3 data points from 1 market, "
                    "that's a weak comparison. Confidence scoring grades the RELIABILITY "
                    "of each metric so you know when to trust the numbers vs. when to "
                    "take them with a grain of salt.\n\n"
                    "Each dimension gets a grade: HIGH, MEDIUM, LOW, or UNRELIABLE.\n"
                    "Below LOW = UNRELIABLE (not shown in recommendations)."
                ),
                'volume': {
                    '_description': (
                        "VOLUME CONFIDENCE: How much non-your-company volume exists "
                        "in the benchmark data, as a % of your volume.\n"
                        "Example: If your benchmark data has 50% as much volume as "
                        "you do, that's a decent sample. If it's only 5%, the "
                        "benchmark might not be representative.\n\n"
                        "Numbers below are percentages."
                    ),
                    'HIGH': {
                        'question': 'Benchmark volume >= what % of your volume = HIGH confidence?',
                        'answer': 50,
                    },
                    'MEDIUM': {
                        'question': 'Benchmark volume >= what % = MEDIUM confidence?',
                        'answer': 25,
                    },
                    'LOW': {
                        'question': 'Benchmark volume >= what % = LOW confidence? (below this = UNRELIABLE)',
                        'answer': 10,
                    },
                },
                'coverage': {
                    '_description': (
                        "COVERAGE CONFIDENCE: How many distinct markets/regions/DMAs "
                        "are represented in the benchmark data.\n"
                        "A benchmark from 10 markets is more reliable than one from "
                        "2 markets. Single-market benchmarks can be misleading.\n\n"
                        "Numbers below are counts of markets/regions."
                    ),
                    'HIGH': {
                        'question': 'Benchmark from >= how many markets = HIGH confidence?',
                        'answer': 10,
                    },
                    'MEDIUM': {
                        'question': 'Benchmark from >= how many markets = MEDIUM confidence?',
                        'answer': 5,
                    },
                    'LOW': {
                        'question': 'Benchmark from >= how many markets = LOW confidence? (below = UNRELIABLE)',
                        'answer': 2,
                    },
                },
            },
            'statistical_significance': {
                '_label': '📐 STATISTICAL TESTS',
                '_description': (
                    "These control when the engine considers a pattern in your data "
                    "to be REAL vs. just random noise.\n\n"
                    "If you're not familiar with statistics, leave the defaults — "
                    "they're standard thresholds used across most industries."
                ),
                'p_value_threshold': {
                    'question': (
                        'P-value threshold for statistical significance.\n'
                        'Default 0.05 means: "I\'m 95% confident this pattern is real, '
                        'not random chance." Lower = stricter. 0.01 = 99% confident.\n\n'
                        'Used in chi-squared tests that check whether customer behavior '
                        'actually differs across segments, or if it just looks that way.'
                    ),
                    'answer': 0.05,
                },
                'cramers_v_strong': {
                    'question': (
                        'Cramér\'s V threshold for "strong association."\n\n'
                        'Cramér\'s V measures HOW MUCH two categories are related, '
                        'on a scale from 0 to 1.\n'
                        '  0.00 = no relationship at all\n'
                        '  0.10 = weak (probably noise)\n'
                        '  0.15 = moderate (worth investigating)\n'
                        '  0.25+ = strong (real pattern)\n\n'
                        'Example: "Is there a relationship between customer SEGMENT '
                        'and whether they CHURNED?" A Cramér\'s V of 0.22 means yes — '
                        'segment matters. A V of 0.03 means no — churn is random '
                        'across segments.\n\n'
                        'Default 0.15 = flag anything moderate or stronger.'
                    ),
                    'answer': 0.15,
                },
            },
        }

    def _build_report_preferences(self) -> Dict:
        return {
            '_instructions': "Choose analyses. Missing-field analyses auto-skip.",
            'output_format': {'question': 'Output format?', 'answer': 'excel',
                              'options': ['excel', 'csv_bundle', 'both']},
            'analyses_to_run': {
                '_label': 'Toggle analyses',
                'executive_summary': {'question': 'Executive summary?', 'answer': True, 'requires': []},
                'volume_trends': {'question': 'Volume trends?', 'answer': True, 'requires': ['volume_cy', 'volume_py']},
                'revenue_analysis': {'question': 'Revenue analysis?', 'answer': True, 'requires': ['sales_ext_cy']},
                'margin_analysis': {'question': 'Margin analysis?', 'answer': True, 'requires': ['margin_ext_cy', 'margin_pct_cy']},
                'price_index': {'question': 'Price benchmarking?', 'answer': True, 'requires': ['price_per_unit_cy', 'benchmark_price']},
                'customer_churn': {'question': 'Customer churn?', 'answer': True, 'requires': ['customer_id', 'volume_cy', 'volume_py']},
                'customer_acquisition': {'question': 'Prospect ID?', 'answer': True, 'requires': ['customer_id', 'affinity_field']},
                'segment_comparison': {'question': 'Segment comparison?', 'answer': True, 'requires': ['segment']},
                'product_mix': {'question': 'Product mix?', 'answer': True, 'requires': ['product_group']},
                'geographic_analysis': {'question': 'Geographic breakdown?', 'answer': True, 'requires': ['geography']},
                'statistical_tests': {'question': 'Statistical tests?', 'answer': True, 'requires': ['segment']},
                'priority_ranking': {'question': 'Customer ranking?', 'answer': True, 'requires': ['customer_id', 'volume_cy']},
            },
        }
