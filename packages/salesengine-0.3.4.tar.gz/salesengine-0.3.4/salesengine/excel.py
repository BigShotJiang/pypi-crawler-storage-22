"""Excel report formatting utilities with smart auto-formatting."""

import pandas as pd
import numpy as np
from typing import List
from salesengine.config import ProjectConfig, get_global_config, _register


# ═══════════════════════════════════════════════════════════════
# NUMBER FORMAT DETECTION
# ═══════════════════════════════════════════════════════════════

_DOLLAR_PATTERNS = [
    'sales', 'revenue', 'margin', 'cost', 'price', 'spend',
    'dollar', 'amount', 'ext $', 'net $', '$ cy', '$ py',
]

_PCT_PATTERNS = [
    'share_%', 'change_%', 'retention_%', '_pct', 'margin %',
    'change_pct', 'penetration', '_%',
]

_COUNT_PATTERNS = [
    'n_customer', 'customers', 'count', 'distinct', 'num_',
]


def _detect_format(col_name: str, values: pd.Series = None) -> str:
    """Detect the appropriate Excel number format for a column."""
    lower = col_name.lower()

    for p in _PCT_PATTERNS:
        if p in lower:
            return '%'

    for p in _DOLLAR_PATTERNS:
        if p in lower:
            return '$'

    for p in _COUNT_PATTERNS:
        if p in lower:
            return '#'

    # Volume columns (pounds, units, etc.)
    if any(w in lower for w in ['pounds', 'volume', 'lbs', 'units', 'cases', 'qty']):
        return '#'

    # Fallback: large numbers get commas
    if values is not None:
        try:
            numeric = pd.to_numeric(values, errors='coerce').dropna()
            if len(numeric) > 0 and numeric.abs().max() > 999:
                return '#'
        except Exception:
            pass

    return ''


def _needs_decimals(values: pd.Series) -> bool:
    """Check if a numeric column has meaningful decimals."""
    try:
        numeric = pd.to_numeric(values, errors='coerce').dropna()
        if len(numeric) == 0:
            return False
        diffs = (numeric - numeric.round(0)).abs()
        return (diffs > 0.01).any()
    except Exception:
        return False


# ═══════════════════════════════════════════════════════════════
# COLUMN HEADER CLEANING
# ═══════════════════════════════════════════════════════════════

def _clean_header(col_name: str) -> str:
    """
    Make internal column names presentable.
    'Volume_Change_%' → 'Volume Change %'
    '_Margin_Band' → 'Margin Band'
    'N_Customers' → 'Customers'
    """
    name = col_name.strip('_')
    name = name.replace('_', ' ')
    if name.startswith('N '):
        name = name[2:]
    return name


# ═══════════════════════════════════════════════════════════════
# STYLES
# ═══════════════════════════════════════════════════════════════

@_register('Excel Formatting', 'pmi_evaluation + revman')
def get_excel_styles():
    """Return standard openpyxl styles for professional reports."""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    return {
        'header_font': Font(name='Arial', bold=True, size=11, color='FFFFFF'),
        'header_fill': PatternFill('solid', fgColor='2F5496'),
        'title_font': Font(name='Arial', bold=True, size=14),
        'subtitle_font': Font(name='Arial', bold=True, size=11),
        'body_font': Font(name='Arial', size=10),
        'red_font': Font(name='Arial', size=10, color='C00000'),
        'green_font': Font(name='Arial', size=10, color='00B050'),
        'red_fill': PatternFill('solid', fgColor='FFC7CE'),
        'green_fill': PatternFill('solid', fgColor='C6EFCE'),
        'yellow_fill': PatternFill('solid', fgColor='FFEB9C'),
        'gray_fill': PatternFill('solid', fgColor='D9D9D9'),
        'light_gray_fill': PatternFill('solid', fgColor='F2F2F2'),
        'thin_border': Border(
            left=Side(style='thin'), right=Side(style='thin'),
            top=Side(style='thin'), bottom=Side(style='thin')),
    }


@_register('Excel Formatting', 'pmi_evaluation + revman')
def style_header_row(ws, ncols: int, styles: dict = None):
    """Apply dark-blue header styling to row 1 of a worksheet."""
    from openpyxl.styles import Alignment
    if styles is None:
        styles = get_excel_styles()
    for c in range(1, ncols + 1):
        cell = ws.cell(row=1, column=c)
        cell.font = styles['header_font']
        cell.fill = styles['header_fill']
        cell.alignment = Alignment(horizontal='center', wrap_text=True)
        cell.border = styles['thin_border']


@_register('Excel Formatting', 'pmi_evaluation + revman')
def auto_width(ws, max_width: int = 40):
    """Auto-size column widths based on content."""
    from openpyxl.utils import get_column_letter
    for col_cells in ws.columns:
        mx = 0
        col_letter = get_column_letter(col_cells[0].column)
        for cell in col_cells:
            try:
                val = str(cell.value or '')
                mx = max(mx, len(val))
            except Exception:
                pass
        ws.column_dimensions[col_letter].width = min(mx + 3, max_width)


# ═══════════════════════════════════════════════════════════════
# MAIN SHEET WRITER
# ═══════════════════════════════════════════════════════════════

@_register('Excel Formatting', 'pmi_evaluation + revman')
def df_to_sheet(
    wb, df: pd.DataFrame, sheet_name: str,
    num_fmt_cols: List[str] = None,
    pct_fmt_cols: List[str] = None,
    dollar_fmt_cols: List[str] = None,
    index_col: str = None,
    config: ProjectConfig = None
):
    """
    Write DataFrame to Excel with professional auto-formatting.

    Auto-detects and applies:
    - $#,##0 for revenue/sales/margin columns
    - #,##0 for volume/count columns
    - 0.0 for percentage columns
    - Alternating row shading
    - Red/green coloring for change columns
    - Clean column headers
    - Frozen header row
    """
    from openpyxl.styles import Alignment

    cfg = config or get_global_config()
    styles = get_excel_styles()
    ws = wb.create_sheet(title=sheet_name[:31])

    # ── Write headers (cleaned) ──
    col_formats = {}
    for c, col_name in enumerate(df.columns, 1):
        clean_name = _clean_header(col_name)
        ws.cell(row=1, column=c, value=clean_name)

        fmt = _detect_format(col_name, df[col_name] if len(df) > 0 else None)

        if num_fmt_cols and col_name in num_fmt_cols:
            fmt = '#'
        if pct_fmt_cols and col_name in pct_fmt_cols:
            fmt = '%'
        if dollar_fmt_cols and col_name in dollar_fmt_cols:
            fmt = '$'

        col_formats[c] = fmt

    style_header_row(ws, len(df.columns), styles)

    # ── Precompute which columns need decimals ──
    decimal_cols = set()
    for c, col_name in enumerate(df.columns, 1):
        if col_formats.get(c) in ('$', '#') and len(df) > 0:
            if _needs_decimals(df[col_name]):
                decimal_cols.add(c)

    # ── Write data rows ──
    for r, (_, row) in enumerate(df.iterrows(), 2):
        is_shaded = (r % 2 == 0)

        for c, (col_name, val) in enumerate(zip(df.columns, row), 1):
            cell = ws.cell(row=r, column=c)

            if isinstance(val, float) and np.isnan(val):
                cell.value = ''
            else:
                cell.value = val

            cell.font = styles['body_font']
            cell.border = styles['thin_border']

            if is_shaded:
                cell.fill = styles['light_gray_fill']

            # Apply number format
            fmt = col_formats.get(c, '')
            is_num = isinstance(val, (int, float)) and not (isinstance(val, float) and np.isnan(val))

            if fmt == '$' and is_num:
                cell.number_format = '$#,##0.00' if c in decimal_cols else '$#,##0'
            elif fmt == '#' and is_num:
                cell.number_format = '#,##0.00' if c in decimal_cols else '#,##0'
            elif fmt == '%' and is_num:
                cell.number_format = '0.0'

            # Red/green for change columns
            lower_col = col_name.lower()
            if any(kw in lower_col for kw in ['change', 'growth', 'delta', 'yoy']):
                try:
                    v = float(val)
                    if v > 0:
                        cell.font = styles['green_font']
                    elif v < 0:
                        cell.font = styles['red_font']
                except (ValueError, TypeError):
                    pass

    # ── Index column conditional formatting ──
    if index_col and index_col in df.columns:
        t = cfg.index_thresholds
        ci = df.columns.get_loc(index_col) + 1
        for r in range(2, len(df) + 2):
            v = ws.cell(row=r, column=ci).value
            try:
                v = float(v)
                ws.cell(row=r, column=ci).number_format = '0.00'
                if v > t.get('high', 1.10):
                    ws.cell(row=r, column=ci).fill = styles['red_fill']
                elif v < t.get('low', 0.90):
                    ws.cell(row=r, column=ci).fill = styles['green_fill']
                else:
                    ws.cell(row=r, column=ci).fill = styles['yellow_fill']
            except (ValueError, TypeError):
                pass

    auto_width(ws)
    ws.freeze_panes = 'A2'
    return ws
