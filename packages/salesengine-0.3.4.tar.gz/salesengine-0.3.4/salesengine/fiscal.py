"""
Fiscal calendar: parses period IDs, handles year rollovers, computes recency.

Handles formats like:
  202533  → FY2025 Week 33 (YYYYWW)
  202507  → FY2025 Period 07 (YYYYPP)
  33      → Week 33 (WW, no year)
  2025-33 → FY2025 Week 33
  01/15/2025 → actual date

The key problem this solves: if your max period is 202503 and you want
the last 6 weeks, simple subtraction gives 202497 — which doesn't exist.
The correct answer crosses the year boundary: 202549..202552, 202501..202503.
"""

import pandas as pd
import numpy as np
import re
from typing import Optional, Tuple, List
from salesengine.config import ProjectConfig, get_global_config, _register


@_register('Fiscal Calendar', 'salesengine v0.2.0')
def detect_period_format(series: pd.Series) -> str:
    """
    Auto-detect the format of a period/time column.

    Returns one of: 'YYYYWW', 'YYYYPP', 'WW', 'PP', 'date', 'unknown'
    """
    sample = series.dropna().head(200).astype(str).str.strip()
    if len(sample) == 0:
        return 'unknown'

    # Check for date patterns first
    date_patterns = [
        r'\d{1,2}/\d{1,2}/\d{2,4}',
        r'\d{4}-\d{2}-\d{2}',
        r'\d{1,2}-\w{3}-\d{2,4}',
    ]
    date_matches = sum(sample.str.match('|'.join(date_patterns), na=False))
    if date_matches > len(sample) * 0.7:
        return 'date'

    # Try numeric
    nums = pd.to_numeric(sample, errors='coerce')
    if nums.isna().sum() > len(sample) * 0.3:
        return 'unknown'

    nums_clean = nums.dropna()
    min_val = nums_clean.min()
    max_val = nums_clean.max()
    n_unique = nums_clean.nunique()

    # YYYYWW: 6 digits, year prefix, week 01-53
    if min_val >= 100000 and max_val <= 999999:
        weeks = nums_clean % 100
        if weeks.min() >= 1 and weeks.max() <= 53:
            return 'YYYYWW'
        # Could be YYYYPP (periods 1-13)
        if weeks.min() >= 1 and weeks.max() <= 13:
            return 'YYYYPP'

    # Plain week number (1-53)
    if min_val >= 1 and max_val <= 53 and n_unique <= 53:
        if max_val > 13:
            return 'WW'
        # Ambiguous: could be week or period. If n_unique <= 13, guess period
        if n_unique <= 13:
            return 'PP'
        return 'WW'

    # Plain period (1-13)
    if min_val >= 1 and max_val <= 13 and n_unique <= 13:
        return 'PP'

    return 'unknown'


def parse_period(value, fmt: str) -> Tuple[Optional[int], Optional[int]]:
    """
    Parse a single period value into (year, period_number).

    Returns (None, None) if unparseable.
    """
    if pd.isna(value):
        return None, None

    try:
        val = int(float(value))
    except (ValueError, TypeError):
        return None, None

    if fmt == 'YYYYWW':
        year = val // 100
        week = val % 100
        return year, week
    elif fmt == 'YYYYPP':
        year = val // 100
        period = val % 100
        return year, period
    elif fmt in ('WW', 'PP'):
        return None, val
    else:
        return None, None


def period_to_sequence(value, fmt: str, weeks_in_year: int = 52) -> Optional[int]:
    """
    Convert a period value to a monotonically increasing sequence number.

    This is the key function — it turns 202552 → (2025 * 52 + 52) = 105352
    and 202503 → (2025 * 52 + 3) = 105303, so subtraction works across
    year boundaries.
    """
    year, period = parse_period(value, fmt)

    if period is None:
        return None

    if year is not None:
        return year * weeks_in_year + period
    else:
        # No year component — just use the raw period number
        return period


def sequence_to_period(seq: int, fmt: str, weeks_in_year: int = 52) -> int:
    """Convert a sequence number back to a period value."""
    if fmt == 'YYYYWW':
        year = seq // weeks_in_year
        week = seq % weeks_in_year
        if week == 0:
            year -= 1
            week = weeks_in_year
        return year * 100 + week
    elif fmt == 'YYYYPP':
        year = seq // weeks_in_year
        period = seq % weeks_in_year
        if period == 0:
            year -= 1
            period = weeks_in_year
        return year * 100 + period
    else:
        return seq


@_register('Fiscal Calendar', 'salesengine v0.2.0')
def compute_recency(
    df: pd.DataFrame,
    time_col: str,
    window: int,
    config: ProjectConfig = None,
    verbose: bool = True,
) -> pd.Series:
    """
    Compute a boolean mask: True for rows within the last N periods.

    Handles year rollovers correctly by converting to sequence numbers.

    Parameters
    ----------
    df : DataFrame
    time_col : str — the actual column name with period values
    window : int — how many periods back from max
    config : ProjectConfig — for calendar settings

    Returns
    -------
    pd.Series of bool — True = within recency window
    """
    cfg = config or get_global_config()

    # Detect or use configured format
    fmt = cfg.period_format
    if fmt == 'auto':
        fmt = detect_period_format(df[time_col])
        if verbose:
            print(f"      Period format auto-detected: {fmt}")

    weeks = cfg.weeks_in_year

    if fmt == 'date':
        # Parse as actual dates
        dates = pd.to_datetime(df[time_col], errors='coerce')
        if dates.notna().any():
            max_date = dates.max()
            # Window in weeks for dates
            cutoff_date = max_date - pd.Timedelta(weeks=window)
            mask = dates > cutoff_date
            if verbose:
                print(f"      Date range: {dates.min()} to {max_date}")
                print(f"      Cutoff: after {cutoff_date}")
            return mask
        return pd.Series(False, index=df.index)

    if fmt == 'unknown':
        # Fall back to simple numeric subtraction
        nums = pd.to_numeric(df[time_col], errors='coerce')
        if nums.notna().any():
            max_val = nums.max()
            cutoff = max_val - window
            if verbose:
                print(f"      Format unknown, using simple numeric: max={max_val}, cutoff>{cutoff}")
            return nums > cutoff
        return pd.Series(False, index=df.index)

    # Convert to sequence numbers for proper year-boundary math
    sequences = df[time_col].apply(lambda v: period_to_sequence(v, fmt, weeks))

    if sequences.notna().any():
        max_seq = sequences.max()
        cutoff_seq = max_seq - window

        # Convert back to human-readable for logging
        max_period = sequence_to_period(int(max_seq), fmt, weeks)
        cutoff_period = sequence_to_period(int(cutoff_seq), fmt, weeks)

        if verbose:
            print(f"      Max period: {max_period} (seq {int(max_seq)})")
            print(f"      Cutoff: > {cutoff_period} (seq {int(cutoff_seq)})")
            print(f"      Window: last {window} periods, {weeks} per year")

        return sequences > cutoff_seq

    return pd.Series(False, index=df.index)


def get_fiscal_quarter(period_num: int, pattern: str = '445') -> int:
    """
    Given a fiscal week/period number, return the fiscal quarter (1-4).

    Patterns:
      445: Q1=wk1-13, Q2=wk14-26, Q3=wk27-39, Q4=wk40-52
      454: Q1=wk1-13, Q2=wk14-27, Q3=wk28-40, Q4=wk41-52
      544: Q1=wk1-14, Q2=wk15-27, Q3=wk28-40, Q4=wk41-52
      13_period: Q1=P1-P3, Q2=P4-P6, Q3=P7-P9, Q4=P10-P13 (or P10-P12)
    """
    if pattern == '445':
        breaks = [13, 26, 39, 52]
    elif pattern == '454':
        breaks = [13, 27, 40, 52]
    elif pattern == '544':
        breaks = [14, 27, 40, 52]
    elif pattern == '13_period':
        breaks = [3, 6, 9, 13]
    elif pattern == 'monthly':
        breaks = [3, 6, 9, 12]
    else:
        breaks = [13, 26, 39, 52]

    for q, brk in enumerate(breaks, 1):
        if period_num <= brk:
            return q
    return 4


def get_fiscal_month_from_week(week_num: int, pattern: str = '445') -> int:
    """
    Map a fiscal week to its fiscal month (1-12) based on the pattern.

    445 pattern (most common in retail/distribution):
      Month 1: wk 1-4,  Month 2: wk 5-8,  Month 3: wk 9-13
      Month 4: wk 14-17, Month 5: wk 18-21, Month 6: wk 22-26
      ...etc.
    """
    if pattern == '445':
        month_breaks = [4, 8, 13, 17, 21, 26, 30, 34, 39, 43, 47, 52]
    elif pattern == '454':
        month_breaks = [4, 8, 13, 18, 22, 27, 31, 35, 40, 44, 48, 52]
    elif pattern == '544':
        month_breaks = [5, 9, 14, 18, 22, 27, 31, 35, 40, 44, 48, 52]
    else:
        # Default 445
        month_breaks = [4, 8, 13, 17, 21, 26, 30, 34, 39, 43, 47, 52]

    for m, brk in enumerate(month_breaks, 1):
        if week_num <= brk:
            return m
    return 12
