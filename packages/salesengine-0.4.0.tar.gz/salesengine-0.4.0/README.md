# SalesEngine

**Universal Sales Intelligence Engine** — Drop in any sales/transaction dataset, answer a short questionnaire, and get standardized, executive-ready reports. Works across industries.

## What's New in v0.4.0

**Professional Report Output** — Complete formatting overhaul:
- PDF reports with stat cards, styled tables, teal design system, page headers/footers
- PPTX decks with branded cover slides, KPI cards, color-coded change percentages
- Timestamped output files — never collides with open reports
- ReportTheme system — customize colors and branding for any company

**Bug Fixes:**
- Fixed "?" characters on PDF cover page (emoji Unicode rendering)
- Fixed raw numbers on executive summary (2758944.72 → 2.8M)
- Fixed table headers showing raw column names (Volume_Change_% → Change %)
- Fixed missing alternating row colors on PPTX tables

## Install

```bash
pip install salesengine              # Excel only
pip install salesengine[pdf]         # + PDF reports
pip install salesengine[pptx]        # + PowerPoint decks
pip install salesengine[all]         # Everything
```

## Quick Start

```python
import salesengine as se

# Scan your data
se.scan("sales_data.csv")

# Fill out the generated questionnaire, then run
se.run("sales_data.csv", "intake.json", formats=["all"])
```

## Three Output Formats

| Format | Audience | What They Get |
|--------|----------|---------------|
| Excel  | Analyst  | Pivot-ready workbook with all data |
| PDF    | Leadership | Polished report with stat cards and tables |
| PPTX   | Presenter | Slide deck with KPI cards and data slides |

## 22 Analytics Functions

Data Cleaning, Customer Churn Analysis, Price Benchmarking, Margin Health,
Volume & Revenue Analytics, Customer Ranking, Geographic Analysis,
Segment Comparison, Product Mix Analysis.

## Cross-Industry

The same engine serves food distribution, SaaS, healthcare, retail,
manufacturing, financial services, and logistics. Configure once via
the questionnaire — the analytics adapt automatically.
