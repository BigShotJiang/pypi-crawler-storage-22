"""
SalesEngine — Universal Sales Intelligence Engine
==================================================

Drop in any sales/transaction dataset, answer a short questionnaire,
and get standardized, executive-ready reports. Works across industries.

Quick Start:
    import salesengine as se
    se.scan("data.csv")
    se.run("data.csv", "intake.json")
"""

__version__ = "0.4.0"

from salesengine.config import ProjectConfig, get_global_config, set_global_config
from salesengine.scanner import scan_dataset
from salesengine.builder import build_config_from_json
from salesengine.report import ReportEngine
from salesengine.inspect import inspect_csv
from salesengine.formatting import ReportTheme
from salesengine.formatting.utils import timestamped_path

# Optional imports
try:
    from salesengine.pdf_report import build_pdf_report
except ImportError:
    pass
try:
    from salesengine.pptx_report import build_pptx_report
except ImportError:
    pass


def scan(csv_path, output_json=None):
    """Scan a CSV and generate a questionnaire JSON."""
    from salesengine.scanner import scan_dataset
    from salesengine.questionnaire import generate_questionnaire
    import json, os

    columns, dtypes, samples = scan_dataset(csv_path)
    q = generate_questionnaire(columns, dtypes, samples)

    out = output_json or csv_path.replace(".csv", "_intake.json")
    with open(out, "w") as f:
        json.dump(q, f, indent=2, default=str)
    print(f"Questionnaire saved: {out}")
    return out


def run(csv_path, intake_json, output_dir=None, formats=None):
    """Run the full SalesEngine pipeline."""
    import json, os

    formats = formats or ["excel"]
    with open(intake_json) as f:
        answers = json.load(f)

    cfg = build_config_from_json(answers)
    set_global_config(cfg)

    engine = ReportEngine(cfg)
    results, summary = engine.analyze(csv_path)

    out_dir = output_dir or os.path.dirname(csv_path) or "."
    base = os.path.splitext(os.path.basename(csv_path))[0]
    outputs = {}

    if "excel" in formats or "all" in formats:
        xlsx_path = timestamped_path(os.path.join(out_dir, f"{base}_Report.xlsx"))
        engine.write_excel(results, summary, xlsx_path)
        outputs["excel"] = xlsx_path

    if "pdf" in formats or "all" in formats:
        pdf_path = timestamped_path(os.path.join(out_dir, f"{base}_Report.pdf"))
        build_pdf_report(results, summary, pdf_path, config=cfg)
        outputs["pdf"] = pdf_path

    if "pptx" in formats or "all" in formats:
        pptx_path = timestamped_path(os.path.join(out_dir, f"{base}_Report.pptx"))
        build_pptx_report(results, summary, pptx_path, config=cfg)
        outputs["pptx"] = pptx_path

    return outputs
