"""Aggregation utilities."""
import pandas as pd
import numpy as np

def weighted_average(df, value_col, weight_col):
    """Weighted average: sum(value*weight) / sum(weight)."""
    v = pd.to_numeric(df[value_col], errors='coerce')
    w = pd.to_numeric(df[weight_col], errors='coerce')
    mask = v.notna() & w.notna() & (w != 0)
    if mask.sum() == 0:
        return np.nan
    return (v[mask] * w[mask]).sum() / w[mask].sum()

def aggregate_to_grain(df, group_cols, agg_dict):
    """Group-and-aggregate with automatic column naming."""
    return df.groupby(group_cols, as_index=False).agg(agg_dict)
