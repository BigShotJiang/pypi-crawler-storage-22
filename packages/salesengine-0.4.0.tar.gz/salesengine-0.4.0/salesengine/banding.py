"""Banding and priority scoring."""
import pandas as pd
import numpy as np

def assign_band(value, bands=None):
    """Assign a value to a named band."""
    bands = bands or [
        (0.00, 0.05, "Under 5%"), (0.05, 0.10, "5% to 10%"),
        (0.10, 0.15, "10% to 15%"), (0.15, 0.20, "15% to 20%"),
        (0.20, 0.25, "20% to 25%"), (0.25, 0.30, "25% to 30%"),
        (0.30, 0.35, "30% to 35%"), (0.35, 0.40, "35% to 40%"),
        (0.40, float('inf'), "Over 40%"),
    ]
    if pd.isna(value):
        return "Unknown"
    for low, high, label in bands:
        if low <= value < high:
            return label
    return "Unknown"

def priority_score(df, factors, weights=None):
    """Weighted composite score across multiple factors."""
    weights = weights or {f: 1.0 for f in factors}
    scores = pd.DataFrame(index=df.index)
    for f in factors:
        if f in df.columns:
            col = pd.to_numeric(df[f], errors='coerce')
            rank = col.rank(pct=True, na_option='bottom')
            scores[f] = rank * weights.get(f, 1.0)
    return scores.sum(axis=1) / sum(weights.values())
