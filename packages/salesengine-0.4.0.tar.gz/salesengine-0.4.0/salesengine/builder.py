"""Build a ProjectConfig from questionnaire JSON answers."""
from salesengine.config import ProjectConfig

def build_config_from_json(answers):
    """Convert questionnaire answers into a ProjectConfig."""
    fm = answers.get("field_mappings", {})
    kwargs = {
        "project_name": answers.get("project_name", {}).get("answer", "Analysis"),
        "industry": answers.get("industry", {}).get("answer", "General"),
    }
    for key, val in fm.items():
        answer = val.get("answer", "") if isinstance(val, dict) else val
        if answer:
            kwargs[key] = answer

    h = answers.get("hierarchy", {})
    kwargs["hierarchy"] = h.get("answer", []) if isinstance(h, dict) else h

    fc = answers.get("fiscal_calendar", {})
    if isinstance(fc, dict):
        kwargs["fiscal_start_month"] = fc.get("start_month", {}).get("answer", 1)
        kwargs["fiscal_pattern"] = fc.get("pattern", {}).get("answer", "calendar")
        kwargs["period_format"] = fc.get("period_format", {}).get("answer", "YYYYMM")

    ch = answers.get("churn", {})
    if isinstance(ch, dict):
        kwargs["activity_method"] = ch.get("activity_method", {}).get("answer", "recency_window")
        kwargs["active_window"] = ch.get("active_window", {}).get("answer", 6)

    return ProjectConfig(**kwargs)
