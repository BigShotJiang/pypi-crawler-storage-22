"""Customer churn / movement classification."""
import pandas as pd
import numpy as np

def classify_customer_movement(df, customer_col, volume_cy_col, volume_py_col,
                                segment_col=None, active_window=6):
    """
    Classify each customer into movement categories:
    Retained, Left_Entirely, Left_Segment, New_Acquisition, Migrated_In, Migrated_Out
    """
    result = df[[customer_col]].copy()
    cy = pd.to_numeric(df[volume_cy_col], errors='coerce').fillna(0)
    py = pd.to_numeric(df[volume_py_col], errors='coerce').fillna(0)

    conditions = [
        (cy > 0) & (py > 0),
        (cy == 0) & (py > 0),
        (cy > 0) & (py == 0),
    ]
    labels = ['Retained', 'Left_Entirely', 'New_Acquisition']
    result['Movement'] = np.select(conditions, labels, default='Unknown')
    return result

def identify_non_buyers(df, customer_col, volume_cy_col, volume_py_col):
    """Find customers who bought previously but not currently."""
    cy = pd.to_numeric(df[volume_cy_col], errors='coerce').fillna(0)
    py = pd.to_numeric(df[volume_py_col], errors='coerce').fillna(0)
    return df[(cy == 0) & (py > 0)]
