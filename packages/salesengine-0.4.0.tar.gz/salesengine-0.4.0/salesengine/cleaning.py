"""Data cleaning utilities."""
import pandas as pd
import numpy as np
import re

def clean_numeric(series):
    """Strip $, commas, parens-as-negative from a series and convert to float."""
    if series.dtype in ('float64', 'int64'):
        return series
    s = series.astype(str)
    s = s.str.replace(r'[\$,]', '', regex=True)
    s = s.str.replace(r'^\((.*)\)$', r'-\1', regex=True)
    return pd.to_numeric(s, errors='coerce')

def clean_currency(series):
    """Alias for clean_numeric."""
    return clean_numeric(series)

def clean_dataframe(df, numeric_cols=None):
    """Clean an entire DataFrame: strip whitespace, convert numerics."""
    df = df.copy()
    for col in df.select_dtypes(include='object').columns:
        df[col] = df[col].str.strip()
    if numeric_cols:
        for col in numeric_cols:
            if col in df.columns:
                df[col] = clean_numeric(df[col])
    return df
