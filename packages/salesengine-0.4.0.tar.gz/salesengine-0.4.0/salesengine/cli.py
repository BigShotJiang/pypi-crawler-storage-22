"""Command-line interface: salesengine scan / salesengine run"""
import argparse
import sys

def main():
    parser = argparse.ArgumentParser(prog="salesengine", description="Universal Sales Intelligence Engine")
    sub = parser.add_subparsers(dest="command")

    scan_p = sub.add_parser("scan", help="Scan a CSV and generate intake questionnaire")
    scan_p.add_argument("csv", help="Path to CSV file")
    scan_p.add_argument("-o", "--output", help="Output JSON path")

    run_p = sub.add_parser("run", help="Run the full analysis pipeline")
    run_p.add_argument("csv", help="Path to CSV file")
    run_p.add_argument("intake", help="Path to intake JSON")
    run_p.add_argument("-d", "--output-dir", help="Output directory")
    run_p.add_argument("-f", "--formats", nargs="+", default=["excel"], help="Output formats")

    inspect_p = sub.add_parser("inspect", help="Quick CSV inspection")
    inspect_p.add_argument("csv", help="Path to CSV file")

    args = parser.parse_args()

    if args.command == "scan":
        import salesengine
        salesengine.scan(args.csv, args.output)
    elif args.command == "run":
        import salesengine
        salesengine.run(args.csv, args.intake, args.output_dir, args.formats)
    elif args.command == "inspect":
        from salesengine.inspect import inspect_csv
        inspect_csv(args.csv)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
