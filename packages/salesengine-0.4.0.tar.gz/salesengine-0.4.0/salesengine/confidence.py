"""Confidence scoring for analytical results."""
import numpy as np

def score_confidence(sample_size, min_reliable=30, min_directional=10):
    """Score confidence based on sample size."""
    if sample_size >= min_reliable:
        return 1.0
    if sample_size >= min_directional:
        return sample_size / min_reliable
    return 0.0

def classify_confidence_band(score):
    """Classify confidence score into human-readable band."""
    if score >= 0.8:
        return "Reliable"
    if score >= 0.5:
        return "Directional"
    if score >= 0.2:
        return "Weak"
    return "Insufficient"
