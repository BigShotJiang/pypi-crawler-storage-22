"""
Configuration system — ProjectConfig + field mapping + @requires_fields decorator.
"""
import functools
import pandas as pd

_GLOBAL_CONFIG = None

def get_global_config():
    return _GLOBAL_CONFIG

def set_global_config(cfg):
    global _GLOBAL_CONFIG
    _GLOBAL_CONFIG = cfg


class ProjectConfig:
    """Maps logical field names to actual dataset columns."""

    def __init__(self, **kwargs):
        self.project_name = kwargs.get("project_name", "Analysis")
        self.industry = kwargs.get("industry", "General")

        # Core field mappings
        self.customer_id = kwargs.get("customer_id")
        self.customer_name = kwargs.get("customer_name")
        self.volume_cy = kwargs.get("volume_cy")
        self.volume_py = kwargs.get("volume_py")
        self.revenue_cy = kwargs.get("revenue_cy")
        self.revenue_py = kwargs.get("revenue_py")
        self.margin_cy = kwargs.get("margin_cy")
        self.margin_py = kwargs.get("margin_py")
        self.period_field = kwargs.get("period_field")
        self.segment_field = kwargs.get("segment_field")
        self.product_field = kwargs.get("product_field")
        self.geo_fields = kwargs.get("geo_fields", [])

        # Hierarchy
        self.hierarchy = kwargs.get("hierarchy", [])

        # Fiscal calendar
        self.fiscal_start_month = kwargs.get("fiscal_start_month", 1)
        self.fiscal_pattern = kwargs.get("fiscal_pattern", "calendar")
        self.period_format = kwargs.get("period_format", "YYYYMM")

        # Churn
        self.activity_method = kwargs.get("activity_method", "recency_window")
        self.active_window = kwargs.get("active_window", 6)

        # Theme
        self.theme = kwargs.get("theme", None)

        # Store all kwargs for extension
        self._raw = kwargs

    def has_fields(self, *fields):
        """Check if all named fields are mapped."""
        for f in fields:
            val = getattr(self, f, None)
            if val is None:
                return False
        return True

    def get_field(self, logical_name, default=None):
        return getattr(self, logical_name, default)


def requires_fields(*fields):
    """Decorator: skip function gracefully if required fields are missing."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            cfg = kwargs.get("config") or get_global_config()
            if cfg is None:
                print(f"  [skip] {func.__name__}: no config")
                return None
            for f in fields:
                if not cfg.has_fields(f):
                    print(f"  [skip] {func.__name__}: missing '{f}'")
                    return None
            return func(*args, **kwargs)
        return wrapper
    return decorator


# Registry for tracking what ran
_REGISTRY = []

def _register(label, version):
    def decorator(func):
        _REGISTRY.append({"function": func.__name__, "label": label, "version": version})
        return func
    return decorator
