"""Excel output utilities using openpyxl."""
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import pandas as pd

HEADER_FONT = Font(name='Calibri', bold=True, size=11, color='FFFFFF')
HEADER_FILL = PatternFill(start_color='0B7B7F', end_color='0B7B7F', fill_type='solid')
BODY_FONT = Font(name='Calibri', size=10)
THIN_BORDER = Border(
    left=Side(style='thin', color='DDDDDD'),
    right=Side(style='thin', color='DDDDDD'),
    top=Side(style='thin', color='DDDDDD'),
    bottom=Side(style='thin', color='DDDDDD'),
)

def style_header(ws, n_cols):
    """Apply styled header to first row."""
    for c in range(1, n_cols + 1):
        cell = ws.cell(row=1, column=c)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = THIN_BORDER

def auto_width(ws, max_width=40, min_width=10):
    """Auto-fit column widths."""
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        lengths = [len(str(cell.value or '')) for cell in col]
        width = min(max(max(lengths) + 2, min_width), max_width)
        ws.column_dimensions[letter].width = width

def df_to_sheet(ws, df, num_fmt_cols=None, pct_fmt_cols=None):
    """Write a DataFrame to a worksheet with formatting."""
    import numpy as np
    for c, col_name in enumerate(df.columns, 1):
        ws.cell(row=1, column=c, value=col_name)
    style_header(ws, len(df.columns))
    for r, (_, row) in enumerate(df.iterrows(), 2):
        for c, val in enumerate(row, 1):
            cell = ws.cell(row=r, column=c)
            cell.value = '' if isinstance(val, float) and np.isnan(val) else val
            cell.font = BODY_FONT
            cell.border = THIN_BORDER
    if num_fmt_cols:
        for cn in num_fmt_cols:
            if cn in df.columns:
                ci = df.columns.get_loc(cn) + 1
                for r in range(2, len(df) + 2):
                    ws.cell(row=r, column=ci).number_format = '#,##0'
    if pct_fmt_cols:
        for cn in pct_fmt_cols:
            if cn in df.columns:
                ci = df.columns.get_loc(cn) + 1
                for r in range(2, len(df) + 2):
                    ws.cell(row=r, column=ci).number_format = '0.0%'
    auto_width(ws)
    ws.freeze_panes = 'A2'
