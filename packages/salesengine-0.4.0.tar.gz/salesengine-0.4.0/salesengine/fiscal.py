"""Fiscal calendar utilities."""
from datetime import datetime, timedelta

def fiscal_week_to_date(fiscal_year, fiscal_week, start_month=7, pattern="4-4-5"):
    """Convert a fiscal year/week to an approximate calendar date."""
    fy_start = datetime(fiscal_year if start_month <= 6 else fiscal_year - 1, start_month, 1)
    # Find first Monday on or after fy_start
    while fy_start.weekday() != 0:
        fy_start += timedelta(days=1)
    return fy_start + timedelta(weeks=fiscal_week - 1)

def get_fiscal_period(date, start_month=7, pattern="4-4-5"):
    """Get fiscal year and week for a given date."""
    year = date.year
    fy_start = datetime(year if date.month >= start_month else year - 1, start_month, 1)
    while fy_start.weekday() != 0:
        fy_start += timedelta(days=1)
    delta = (date - fy_start).days
    week = delta // 7 + 1
    fy = year + 1 if date.month >= start_month else year
    return fy, max(1, min(week, 52))
