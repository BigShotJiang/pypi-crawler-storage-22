"""
salesengine.formatting — Design system for PDF and PPTX reports.

New in v0.4.0. Extracted from categoryv2.py and report_template.py.
"""
from salesengine.formatting.theme import ReportTheme
from salesengine.formatting.formatters import fmt_num, fmt_pct, safe_line, format_stat_value, clean_header
from salesengine.formatting.utils import timestamped_path
