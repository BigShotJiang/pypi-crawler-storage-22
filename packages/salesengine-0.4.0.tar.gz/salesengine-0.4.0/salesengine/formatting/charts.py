"""
Trend chart generation using matplotlib.
Extracted from categoryv2.py create_weekly_chart_image().

Dual-axis chart: delta bars + CY line + forecast + YoY%.
Works for any time-series business metric.
"""

def create_trend_chart(df, title, output_path,
                       period_col="Period", cy_col="CY", py_col="PY",
                       delta_col="Delta", yoy_col="YoY_Pct", type_col="Type",
                       colors=None, figsize=(12, 6), dpi=150):
    """
    Generate a dual-axis trend chart image.

    Green/red bars for delta, blue line for CY, orange dashed for forecast,
    purple line for YoY% on right axis.
    """
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        raise ImportError("matplotlib required: pip install salesengine[charts]")

    colors = colors or {
        'growth': '#00B050', 'decline': '#C00000', 'actual': '#0B7B7F',
        'forecast': '#E8720C', 'yoy': '#7030A0',
    }

    fig, ax1 = plt.subplots(figsize=figsize)
    x = np.arange(len(df))
    periods = df[period_col].astype(str).values

    # Delta bars
    if delta_col in df.columns:
        deltas = df[delta_col].fillna(0).values
        bar_colors = [colors['growth'] if d >= 0 else colors['decline'] for d in deltas]
        ax1.bar(x, deltas, color=bar_colors, alpha=0.4, width=0.6)

    # CY line
    if cy_col in df.columns:
        cy_vals = df[cy_col].values
        if type_col in df.columns:
            actual_mask = df[type_col].str.lower().isin(['actual', 'a'])
            forecast_mask = ~actual_mask
            ax1.plot(x[actual_mask], cy_vals[actual_mask], color=colors['actual'],
                     linewidth=2, marker='o', markersize=4, label='CY Actual')
            if forecast_mask.any():
                ax1.plot(x[forecast_mask], cy_vals[forecast_mask], color=colors['forecast'],
                         linewidth=2, linestyle='--', marker='s', markersize=4, label='Forecast')
        else:
            ax1.plot(x, cy_vals, color=colors['actual'], linewidth=2, marker='o',
                     markersize=4, label='CY')

    ax1.set_xlabel(period_col)
    ax1.set_ylabel('Volume')
    ax1.set_xticks(x)
    ax1.set_xticklabels(periods, rotation=45, ha='right', fontsize=8)

    # YoY% on right axis
    if yoy_col in df.columns:
        ax2 = ax1.twinx()
        yoy = df[yoy_col].values * 100 if df[yoy_col].abs().max() < 10 else df[yoy_col].values
        ax2.plot(x, yoy, color=colors['yoy'], linewidth=1.5, linestyle='-.',
                 marker='^', markersize=3, label='YoY %')
        ax2.set_ylabel('YoY %')
        ax2.axhline(y=0, color='gray', linewidth=0.5, linestyle=':')
        ax2.legend(loc='upper right', fontsize=8)

    ax1.legend(loc='upper left', fontsize=8)
    ax1.set_title(title, fontsize=14, fontweight='bold', color='#0B7B7F')
    ax1.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=dpi, bbox_inches='tight')
    plt.close()
    return output_path
