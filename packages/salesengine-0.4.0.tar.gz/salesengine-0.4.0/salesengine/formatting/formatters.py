"""
Number formatting, emoji stripping, header cleaning.

Extracted from report_template.py and categoryv2.py.
Every function here is industry-agnostic and tested.
"""
import re

# ═══════════════════════════════════════════════════════════
# NUMBER FORMATTING
# ═══════════════════════════════════════════════════════════

def fmt_num(val, prefix="", suffix=""):
    """
    Human-readable number formatter.

    2758944.72  -> '2.8M'
    23677       -> '24K'
    1234        -> '1,234'

    Works for any industry: revenue ($), volume (lbs), users, patients, tickets.
    """
    try:
        v = float(val)
    except (ValueError, TypeError):
        return str(val)
    if abs(v) >= 1_000_000:
        return f"{prefix}{v/1_000_000:.1f}M{suffix}"
    elif abs(v) >= 10_000:
        return f"{prefix}{v/1_000:.0f}K{suffix}"
    else:
        return f"{prefix}{v:,.0f}{suffix}"


def fmt_pct(val):
    """
    Percentage with +/- direction indicator.

    0.15   -> '+15.0%'
    -0.03  -> '-3.0%'
    """
    try:
        v = float(val)
        return f"{v:+.1%}" if abs(v) < 10 else f"{v:.0%}"
    except (ValueError, TypeError):
        return str(val)


def format_stat_value(metric_name, raw_value):
    """
    Auto-detect metric type and apply appropriate formatting.

    'Total Revenue', 2758944.72  -> '$2.8M'
    'Retention %', 0.515         -> '51.5%'
    'Distinct Customers', 21735  -> '21,735'
    """
    try:
        v = float(raw_value)
    except (ValueError, TypeError):
        return str(raw_value)

    m = metric_name.lower()
    if any(w in m for w in ['revenue', 'sales', 'margin', 'dollar', 'price', 'cost', '$']):
        return fmt_num(v, prefix="$")
    if any(w in m for w in ['percent', 'pct', 'rate', 'retention', '%', 'share', 'change %']):
        if abs(v) < 1:
            return f"{v:.1%}"
        return f"{v:.1f}%"
    return fmt_num(v)


# ═══════════════════════════════════════════════════════════
# EMOJI / UNICODE STRIPPING
# ═══════════════════════════════════════════════════════════

_EMOJI_RE = re.compile(
    "[\U0001F300-\U0001F9FF\U00002702-\U000027B0"
    "\U0000FE00-\U0000FE0F\U0000200D\U000020E3"
    "\U0000200B-\U0000200F]+", flags=re.UNICODE)

_EMOJI_MAP = {
    '\u2705': '[OK]', '\u26A0\uFE0F': '[NOTE]', '\u26A0': '[NOTE]',
    '\u274C': '[X]', '\U0001F4CA': '', '\U0001F4C8': '', '\U0001F4C9': '',
    '\U0001F50D': '', '\U0001F4A1': '', '\U0001F3AF': '', '\U0001F465': '',
    '\U0001F4CB': '', '\U0001F4DD': '', '\U0001F4E7': '',
}

def safe_line(text):
    """
    Strip emoji from text for PDF rendering (Helvetica has no emoji glyphs).

    This fixes the "?" characters in SalesEngine 0.3.5 reports.
    The old code used line.encode('ascii','replace').decode('ascii') which
    turned every emoji into ?.
    """
    if not text:
        return text
    for emoji, label in _EMOJI_MAP.items():
        text = text.replace(emoji, label)
    text = _EMOJI_RE.sub('', text)
    return re.sub(r'\s+', ' ', text).strip()


# ═══════════════════════════════════════════════════════════
# HEADER CLEANING
# ═══════════════════════════════════════════════════════════

_HEADER_MAP = {
    'Company Region Name': 'Region',
    'Company Name': 'Site',
    'Company Customer Number': 'Customer #',
    'Customer Name': 'Customer',
    'Net Sales Ext $ CY': 'Sales CY',
    'Net Sales Ext$ CY': 'Sales CY',
    'Computer Margin Ext $ CY': 'Margin CY',
    'Computer Margin Ext$ CY': 'Margin CY',
    'Attribute Group Name': 'Product Group',
    'Item Group ID': 'Group ID',
    'Volume_Change': 'Change',
    'Volume_Change_%': 'Change %',
    'Volume_Share_%': 'Vol Share %',
    'Cumulative_Share_%': 'Cum Share %',
    'Pounds CY': 'Lbs CY',
    'Pounds PY': 'Lbs PY',
    'Prior_Customers': 'Prior',
    'Current_Customers': 'Current',
    'Left_Entirely': 'Left',
    'Left_Site_Still_Active': 'Left (Active)',
    'Migrated_Out': 'Migrated Out',
    'New_Acquisition': 'New',
    'Retention_%': 'Retention %',
    'volume_cy': 'Volume CY',
    'volume_py': 'Volume PY',
    'revenue_cy': 'Revenue CY',
    'revenue_py': 'Revenue PY',
    'customers': 'Customers',
    'Avg Margin %': 'Avg Margin %',
    'Margin Band': 'Margin Band',
}

def clean_header(col_name):
    """
    Transform raw column names into readable table headers.

    'Volume_Change_%'           -> 'Change %'
    'Computer Margin Ext $ CY'  -> 'Margin CY'
    'anything_with_underscores' -> 'Anything With Underscores'
    """
    if col_name in _HEADER_MAP:
        return _HEADER_MAP[col_name]
    return col_name.replace('_', ' ')
