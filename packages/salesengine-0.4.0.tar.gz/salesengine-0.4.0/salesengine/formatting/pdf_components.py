"""
Reusable PDF components from report_template.py.
Can be used standalone outside of SalesEngine's report engine.

Usage:
    from salesengine.formatting.pdf_components import make_stat_card, make_table
    from salesengine.formatting.formatters import fmt_num

    card = make_stat_card(fmt_num(2800000), "Total\\nVolume")
"""

def make_stat_card(value_text, label_text, primary_color=None, label_color=None,
                   card_width=1.6, val_size=28, lbl_size=9):
    """Bordered KPI stat card for ReportLab PDFs."""
    from reportlab.lib.units import inch
    from reportlab.lib.colors import HexColor
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    from reportlab.platypus import Table, TableStyle, Paragraph

    pc = primary_color or HexColor("#0B7B7F")
    lc = label_color or HexColor("#666666")
    vs = ParagraphStyle('SV', fontName='Helvetica-Bold', fontSize=val_size,
        leading=val_size+6, textColor=pc, alignment=TA_CENTER)
    ls = ParagraphStyle('SL', fontName='Helvetica', fontSize=lbl_size,
        leading=lbl_size+3, textColor=lc, alignment=TA_CENTER)
    card = Table(
        [[Paragraph(str(value_text), vs)],
         [Paragraph(str(label_text), ls)]],
        colWidths=[card_width*inch], rowHeights=[0.45*inch, 0.35*inch])
    card.setStyle(TableStyle([
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('BOX',(0,0),(-1,-1),0.75,pc),
        ('TOPPADDING',(0,0),(-1,-1),4),
        ('BOTTOMPADDING',(0,0),(-1,-1),4),
    ]))
    return card


def make_table(headers, rows, col_widths=None, keep=False,
               header_bg=None, alt_row_bg=None, grid_color=None):
    """Styled data table with teal header and alternating rows."""
    from reportlab.lib.units import inch
    from reportlab.lib.colors import HexColor, white
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT, TA_CENTER
    from reportlab.platypus import Table, TableStyle, Paragraph, KeepTogether

    hbg = header_bg or HexColor("#0B7B7F")
    abg = alt_row_bg or HexColor("#F5F5F5")
    gc = grid_color or HexColor("#DDDDDD")
    hd = HexColor("#065A5D")

    hs = ParagraphStyle('TH', fontName='Helvetica-Bold', fontSize=8.5,
        leading=11, textColor=white, alignment=TA_CENTER)
    cs = ParagraphStyle('TC', fontName='Helvetica', fontSize=8.5,
        leading=11, textColor=HexColor("#333333"), alignment=TA_CENTER)
    cl = ParagraphStyle('TL', fontName='Helvetica', fontSize=8.5,
        leading=11, textColor=HexColor("#333333"), alignment=TA_LEFT)

    hdr = [Paragraph(h.replace('\n','<br/>'), hs) for h in headers]
    data = []
    for row in rows:
        data.append([Paragraph(str(c), cl if i==0 else cs) for i, c in enumerate(row)])

    all_r = [hdr] + data
    tbl = Table(all_r, colWidths=col_widths, repeatRows=1)
    cmds = [
        ('BACKGROUND',(0,0),(-1,0),hbg), ('TEXTCOLOR',(0,0),(-1,0),white),
        ('GRID',(0,0),(-1,-1),0.5,gc), ('LINEBELOW',(0,0),(-1,0),1.5,hd),
        ('TOPPADDING',(0,0),(-1,-1),5), ('BOTTOMPADDING',(0,0),(-1,-1),5),
        ('LEFTPADDING',(0,0),(-1,-1),6), ('RIGHTPADDING',(0,0),(-1,-1),6),
        ('ALIGN',(0,0),(-1,0),'CENTER'), ('ALIGN',(0,1),(0,-1),'LEFT'),
        ('ALIGN',(1,1),(-1,-1),'CENTER'), ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
    ]
    for i in range(1, len(all_r)):
        if i % 2 == 0:
            cmds.append(('BACKGROUND',(0,i),(-1,i),abg))
    if rows and str(rows[-1][0]).upper() in ('TOTAL','GRAND TOTAL'):
        last = len(all_r)-1
        cmds.append(('LINEABOVE',(0,last),(-1,last),1,hbg))
        cmds.append(('FONTNAME',(0,last),(-1,last),'Helvetica-Bold'))
    tbl.setStyle(TableStyle(cmds))
    return KeepTogether([tbl]) if keep else tbl


def make_header_footer_fn(header_text, footer_text, bar_color=None):
    """Factory: returns a (canvas, doc) callable for ReportLab page chrome."""
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import inch
    from reportlab.lib.colors import HexColor, white

    bc = bar_color or HexColor("#0B7B7F")
    gc = HexColor("#DDDDDD")
    gl = HexColor("#666666")

    def _draw(canvas, doc):
        canvas.saveState()
        w, h = letter
        canvas.setFillColor(bc)
        canvas.rect(0, h-0.4*inch, w, 0.4*inch, fill=1, stroke=0)
        canvas.setFillColor(white)
        canvas.setFont("Helvetica", 8)
        canvas.drawString(0.5*inch, h-0.27*inch, header_text)
        canvas.drawRightString(w-0.5*inch, h-0.27*inch, f"Page {doc.page}")
        canvas.setStrokeColor(gc)
        canvas.setLineWidth(0.5)
        canvas.line(0.5*inch, 0.45*inch, w-0.5*inch, 0.45*inch)
        canvas.setFillColor(gl)
        canvas.setFont("Helvetica", 7)
        canvas.drawString(0.5*inch, 0.3*inch, footer_text)
        canvas.restoreState()
    return _draw
