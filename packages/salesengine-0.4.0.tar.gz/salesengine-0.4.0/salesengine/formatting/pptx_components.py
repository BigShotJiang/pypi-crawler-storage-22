"""
Reusable PPTX components from categoryv2.py.
Can be used standalone outside of SalesEngine's report engine.

Usage:
    from salesengine.formatting.pptx_components import create_table_on_slide
"""
import os

def create_table_on_slide(slide, data_df, left, top, width, height,
                          number_cols=None, percent_cols=None,
                          header_color=None, alt_row_color=None,
                          font_size=9, header_font_size=10):
    """Render a DataFrame as a styled table on a PPTX slide."""
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor

    hc = header_color or RGBColor(0x0B, 0x7B, 0x7F)
    arc = alt_row_color or RGBColor(0xF5, 0xF5, 0xF5)
    number_cols = number_cols or set()
    percent_cols = percent_cols or set()

    rows = len(data_df) + 1
    cols = len(data_df.columns)
    ts = slide.shapes.add_table(rows, cols, left, top, width, height)
    tbl = ts.table

    for ci, cn in enumerate(data_df.columns):
        c = tbl.cell(0, ci)
        c.text = cn.replace('_', ' ')
        c.text_frame.paragraphs[0].font.size = Pt(header_font_size)
        c.text_frame.paragraphs[0].font.bold = True
        c.text_frame.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)
        c.fill.solid(); c.fill.fore_color.rgb = hc
        c.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

    for ri, (_, row) in enumerate(data_df.iterrows(), 1):
        for ci, cn in enumerate(data_df.columns):
            c = tbl.cell(ri, ci)
            val = row[cn]
            if cn in number_cols:
                try: c.text = f"{float(val):,.0f}"
                except: c.text = str(val)
            elif cn in percent_cols:
                try: c.text = f"{float(val):.1%}"
                except: c.text = str(val)
            else:
                c.text = '' if str(val) == 'nan' else str(val)
            c.text_frame.paragraphs[0].font.size = Pt(font_size)
            c.text_frame.paragraphs[0].alignment = PP_ALIGN.LEFT if ci == 0 else PP_ALIGN.CENTER
            if ri % 2 == 0:
                c.fill.solid(); c.fill.fore_color.rgb = arc


def add_logo_to_slide(slide, logo_path, position="top_right",
                      height_inches=0.6, margin_inches=0.3):
    """Add a logo image to a slide. Gracefully skips if file not found."""
    from pptx.util import Inches
    if not logo_path or not os.path.exists(logo_path):
        return
    sw = slide.part.package.presentation.slide_width
    left = sw - Inches(height_inches * 2) - Inches(margin_inches)
    top = Inches(margin_inches)
    slide.shapes.add_picture(logo_path, left, top, height=Inches(height_inches))
