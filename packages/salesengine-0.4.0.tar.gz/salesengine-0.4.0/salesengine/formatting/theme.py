"""
ReportTheme — Centralized design system for PDF and PPTX reports.

One theme object drives both output formats. Replaces all hardcoded
color constants scattered across categoryv2.py and report_template.py.

Usage:
    theme = ReportTheme()                                          # teal defaults
    theme = ReportTheme(primary="#0081C6", secondary="#757B82")     # Sysco blue
    theme = ReportTheme(primary="#6C63FF")                         # SaaS purple
    theme = ReportTheme(primary="#1B5E20", accent="#4CAF50")       # agriculture
"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class ReportTheme:
    # Core colors (hex strings)
    primary: str = "#0B7B7F"
    primary_dark: str = "#065A5D"
    primary_light: str = "#E6F3F3"
    secondary: str = "#666666"
    accent: str = "#E8720C"

    # Semantic
    positive: str = "#00B050"
    negative: str = "#C00000"
    neutral: str = "#595959"

    # Table
    header_bg: str = "#0B7B7F"
    header_text: str = "#FFFFFF"
    alt_row_bg: str = "#F5F5F5"
    grid_color: str = "#DDDDDD"

    # Text
    text_dark: str = "#333333"
    text_light: str = "#666666"

    # Typography
    font_heading: str = "Calibri"
    font_body: str = "Calibri"

    # Branding
    logo_path: Optional[str] = None
    company_name: str = ""
    confidentiality_text: str = "Confidential"

    def pptx_rgb(self, hex_str):
        """Convert hex to python-pptx RGBColor."""
        from pptx.dml.color import RGBColor
        h = hex_str.lstrip("#")
        return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))

    def pdf_hex(self, hex_str):
        """Convert hex to reportlab HexColor."""
        from reportlab.lib.colors import HexColor
        return HexColor(hex_str)

    @property
    def pptx_primary(self):
        return self.pptx_rgb(self.primary)

    @property
    def pptx_primary_dark(self):
        return self.pptx_rgb(self.primary_dark)

    @property
    def pptx_accent(self):
        return self.pptx_rgb(self.accent)

    @property
    def pptx_positive(self):
        return self.pptx_rgb(self.positive)

    @property
    def pptx_negative(self):
        return self.pptx_rgb(self.negative)

    @property
    def pdf_primary(self):
        return self.pdf_hex(self.primary)

    @property
    def pdf_primary_dark(self):
        return self.pdf_hex(self.primary_dark)
