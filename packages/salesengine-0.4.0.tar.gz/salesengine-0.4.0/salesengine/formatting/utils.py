"""Utility functions for report output."""
from datetime import datetime
from pathlib import Path


def timestamped_path(base_path, fmt="%Y%m%d_%H%M%S"):
    """
    Insert timestamp into filename. Prevents file collision when
    previous reports are still open.

    'Output/Report.pdf' -> 'Output/Report_20260214_143022.pdf'
    """
    p = Path(base_path)
    stamp = datetime.now().strftime(fmt)
    return str(p.parent / f"{p.stem}_{stamp}{p.suffix}")
