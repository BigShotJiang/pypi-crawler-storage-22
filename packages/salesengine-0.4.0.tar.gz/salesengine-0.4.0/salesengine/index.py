"""Price index and benchmarking."""
import pandas as pd
import numpy as np
from salesengine.stats import safe_div

def price_index(entity_price, benchmark_price):
    """PMI = entity_price / benchmark_price. 1.0 = at market, >1.0 = above."""
    return safe_div(entity_price, benchmark_price)

def classify_index(pmi, overpriced=1.05, underpriced=0.95):
    """Classify PMI into bands."""
    if pd.isna(pmi):
        return "No Data"
    if pmi > overpriced:
        return "Above Market"
    if pmi < underpriced:
        return "Below Market"
    return "At Market"

def detect_conflicts(df, item_col, price_col, group_col=None, threshold=0.15):
    """Find items with >threshold price variance across groups."""
    if group_col:
        stats = df.groupby([item_col, group_col])[price_col].mean().unstack()
    else:
        stats = df.groupby(item_col)[price_col].agg(['mean', 'std'])
    return stats
