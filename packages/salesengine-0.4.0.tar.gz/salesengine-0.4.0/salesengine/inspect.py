"""Quick dataset inspection."""
import pandas as pd

def inspect_csv(path, nrows=10):
    """Print a quick overview of a CSV file."""
    df = pd.read_csv(path, nrows=nrows, low_memory=False)
    print(f"Columns: {len(df.columns)}")
    print(f"Sample rows: {len(df)}")
    for col in df.columns:
        dtype = df[col].dtype
        nulls = df[col].isna().sum()
        sample = df[col].dropna().iloc[0] if not df[col].dropna().empty else "N/A"
        print(f"  {col:40s} {str(dtype):10s} nulls={nulls}  sample={sample}")
