"""Generate intake questionnaire from detected columns."""

def generate_questionnaire(columns, dtypes, samples, matches=None):
    """Build a JSON questionnaire from scan results."""
    matches = matches or {}
    q = {
        "project_name": {"question": "What is this project/report called?", "answer": ""},
        "industry": {"question": "What industry? (e.g. distribution, SaaS, retail, healthcare)", "answer": ""},
        "field_mappings": {},
        "hierarchy": {"question": "List geographic/org levels top to bottom", "answer": []},
        "fiscal_calendar": {
            "start_month": {"question": "What month does your fiscal year start? (1-12)", "answer": 1},
            "pattern": {"question": "Calendar pattern: calendar, 4-4-5, 4-5-4, 5-4-4", "answer": "calendar"},
            "period_format": {"question": "Period format in data: YYYYMM, YYYYWW, etc", "answer": "YYYYMM"},
        },
        "churn": {
            "activity_method": {"question": "How to detect active customers: recency_window or period_flag", "answer": "recency_window"},
            "active_window": {"question": "How many periods define 'active'?", "answer": 6},
        },
        "output_format": {"question": "Output formats: excel, pdf, pptx, all", "answer": ["excel"]},
    }
    logical_fields = [
        "customer_id", "customer_name", "volume_cy", "volume_py",
        "revenue_cy", "revenue_py", "margin_cy", "margin_py",
        "period_field", "segment_field", "product_field",
    ]
    for lf in logical_fields:
        detected = matches.get(lf, "")
        q["field_mappings"][lf] = {
            "question": f"Which column maps to '{lf}'?",
            "answer": detected,
            "available_columns": columns,
        }
    return q
