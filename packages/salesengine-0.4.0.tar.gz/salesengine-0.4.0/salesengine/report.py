"""
ReportEngine — runs all analyses and produces output.
"""
import pandas as pd
import numpy as np
from salesengine.config import ProjectConfig, get_global_config, requires_fields
from salesengine.cleaning import clean_numeric
from salesengine.stats import safe_div
from salesengine.formatting.formatters import fmt_num, fmt_pct


class ReportEngine:
    """Run all analyses against a dataset using ProjectConfig field mappings."""

    def __init__(self, config=None):
        self.cfg = config or get_global_config()

    def analyze(self, csv_path):
        """Run full analysis pipeline. Returns (results_dict, summary_lines)."""
        df = pd.read_csv(csv_path, low_memory=False)
        df.columns = df.columns.str.strip()

        # Clean numeric columns
        for attr in ['volume_cy','volume_py','revenue_cy','revenue_py','margin_cy','margin_py']:
            col = getattr(self.cfg, attr, None)
            if col and col in df.columns:
                df[col] = clean_numeric(df[col])

        results = {}
        summary = []

        # 1. Executive Summary
        exec_df, exec_lines = self._executive_summary(df)
        if exec_df is not None:
            results['Executive Summary'] = exec_df
            summary.extend(exec_lines)

        # 2. Volume Trends by segment
        seg = self._segment_analysis(df)
        if seg is not None:
            results['Segment Analysis'] = seg

        # 3. Customer Movement / Churn
        churn = self._customer_movement(df)
        if churn is not None:
            results['Customer Movement'] = churn

        # 4. Top Customers
        top = self._top_customers(df)
        if top is not None:
            results['Top Customers'] = top

        # 5. Geographic breakdown for each hierarchy level
        for level in (self.cfg.hierarchy or []):
            if level in df.columns:
                geo = self._geo_breakdown(df, level)
                if geo is not None:
                    results[f'By {level}'] = geo

        # 6. Product mix
        prod = self._product_mix(df)
        if prod is not None:
            results['Product Mix'] = prod

        # 7. Margin distribution
        margin = self._margin_analysis(df)
        if margin is not None:
            results['Margin Analysis'] = margin

        return results, summary

    def _executive_summary(self, df):
        """Build KPI summary table."""
        cfg = self.cfg
        rows = []

        if cfg.volume_cy and cfg.volume_cy in df.columns:
            total_vol = df[cfg.volume_cy].sum()
            rows.append({'Metric': 'Total Volume', 'Value': total_vol})
        if cfg.volume_py and cfg.volume_py in df.columns:
            total_vol_py = df[cfg.volume_py].sum()
            if cfg.volume_cy and cfg.volume_cy in df.columns:
                delta = df[cfg.volume_cy].sum() - total_vol_py
                pct_chg = safe_div(delta, total_vol_py)
                rows.append({'Metric': 'Volume Change', 'Value': delta})
                rows.append({'Metric': 'Volume Change %', 'Value': pct_chg})
        if cfg.revenue_cy and cfg.revenue_cy in df.columns:
            total_rev = df[cfg.revenue_cy].sum()
            rows.append({'Metric': 'Total Revenue', 'Value': total_rev})
        if cfg.revenue_py and cfg.revenue_py in df.columns and cfg.revenue_cy:
            rev_delta = df[cfg.revenue_cy].sum() - df[cfg.revenue_py].sum()
            rows.append({'Metric': 'Revenue Change', 'Value': rev_delta})
        if cfg.margin_cy and cfg.margin_cy in df.columns:
            total_margin = df[cfg.margin_cy].sum()
            rows.append({'Metric': 'Total Margin', 'Value': total_margin})
        if cfg.customer_id and cfg.customer_id in df.columns:
            n_cust = df[cfg.customer_id].nunique()
            rows.append({'Metric': 'Distinct Customers', 'Value': n_cust})

        if not rows:
            return None, []

        exec_df = pd.DataFrame(rows)
        lines = []
        for _, r in exec_df.iterrows():
            m, v = r['Metric'], r['Value']
            if 'Revenue' in m or 'Margin' in m:
                lines.append(f"{m}: {fmt_num(v, prefix='$')}")
            elif '%' in m:
                lines.append(f"{m}: {fmt_pct(v)}")
            else:
                lines.append(f"{m}: {fmt_num(v)}")
        return exec_df, lines

    def _segment_analysis(self, df):
        cfg = self.cfg
        seg_col = cfg.segment_field
        vol_cy = cfg.volume_cy
        vol_py = cfg.volume_py
        if not seg_col or seg_col not in df.columns or not vol_cy or vol_cy not in df.columns:
            return None
        agg = {'volume_cy': (vol_cy, 'sum')}
        if vol_py and vol_py in df.columns:
            agg['volume_py'] = (vol_py, 'sum')
        if cfg.revenue_cy and cfg.revenue_cy in df.columns:
            agg['revenue_cy'] = (cfg.revenue_cy, 'sum')
        if cfg.customer_id and cfg.customer_id in df.columns:
            agg['customers'] = (cfg.customer_id, 'nunique')
        result = df.groupby(seg_col).agg(**agg).reset_index()
        if 'volume_py' in result.columns:
            result['Volume_Change'] = result['volume_cy'] - result['volume_py']
            result['Volume_Change_%'] = result.apply(
                lambda r: safe_div(r['Volume_Change'], r['volume_py']), axis=1)
        result = result.sort_values('volume_cy', ascending=False)
        total = result['volume_cy'].sum()
        result['Volume_Share_%'] = result['volume_cy'] / total if total else 0
        result['Cumulative_Share_%'] = result['Volume_Share_%'].cumsum()
        return result

    def _customer_movement(self, df):
        cfg = self.cfg
        cust_col = cfg.customer_id
        vol_cy = cfg.volume_cy
        vol_py = cfg.volume_py
        if not all([cust_col, vol_cy, vol_py]):
            return None
        if not all(c in df.columns for c in [cust_col, vol_cy, vol_py]):
            return None
        from salesengine.churn import classify_customer_movement
        movement = classify_customer_movement(df, cust_col, vol_cy, vol_py)
        summary = movement.groupby('Movement').size().reset_index(name='Count')
        total = summary['Count'].sum()
        summary['Pct'] = summary['Count'] / total if total else 0
        return summary

    def _top_customers(self, df, n=20):
        cfg = self.cfg
        if not cfg.customer_id or cfg.customer_id not in df.columns:
            return None
        if not cfg.volume_cy or cfg.volume_cy not in df.columns:
            return None
        cols = [cfg.customer_id]
        if cfg.customer_name and cfg.customer_name in df.columns:
            cols.append(cfg.customer_name)
        agg = {cfg.volume_cy: 'sum'}
        if cfg.revenue_cy and cfg.revenue_cy in df.columns:
            agg[cfg.revenue_cy] = 'sum'
        if cfg.volume_py and cfg.volume_py in df.columns:
            agg[cfg.volume_py] = 'sum'
        top = df.groupby(cols).agg(agg).reset_index()
        top = top.sort_values(cfg.volume_cy, ascending=False).head(n)
        return top

    def _geo_breakdown(self, df, level_col):
        cfg = self.cfg
        vol_cy = cfg.volume_cy
        if not vol_cy or vol_cy not in df.columns:
            return None
        agg = {vol_cy: 'sum'}
        if cfg.volume_py and cfg.volume_py in df.columns:
            agg[cfg.volume_py] = 'sum'
        if cfg.revenue_cy and cfg.revenue_cy in df.columns:
            agg[cfg.revenue_cy] = 'sum'
        if cfg.customer_id and cfg.customer_id in df.columns:
            agg[cfg.customer_id] = 'nunique'
        result = df.groupby(level_col).agg(agg).reset_index()
        result = result.sort_values(vol_cy, ascending=False)
        return result

    def _product_mix(self, df):
        cfg = self.cfg
        prod_col = cfg.product_field
        vol_cy = cfg.volume_cy
        if not prod_col or prod_col not in df.columns:
            return None
        if not vol_cy or vol_cy not in df.columns:
            return None
        agg = {vol_cy: 'sum'}
        if cfg.revenue_cy and cfg.revenue_cy in df.columns:
            agg[cfg.revenue_cy] = 'sum'
        if cfg.customer_id and cfg.customer_id in df.columns:
            agg[cfg.customer_id] = 'nunique'
        result = df.groupby(prod_col).agg(agg).reset_index()
        result = result.sort_values(vol_cy, ascending=False)
        total = result[vol_cy].sum()
        result['Volume_Share_%'] = result[vol_cy] / total if total else 0
        return result.head(30)

    def _margin_analysis(self, df):
        cfg = self.cfg
        if not cfg.margin_cy or cfg.margin_cy not in df.columns:
            return None
        if not cfg.revenue_cy or cfg.revenue_cy not in df.columns:
            return None
        from salesengine.banding import assign_band
        df = df.copy()
        df['_margin_pct'] = df.apply(
            lambda r: safe_div(r[cfg.margin_cy], r[cfg.revenue_cy]), axis=1)
        df['_margin_band'] = df['_margin_pct'].apply(assign_band)
        summary = df.groupby('_margin_band').agg(
            count=('_margin_pct', 'count'),
            avg_margin=('_margin_pct', 'mean'),
        ).reset_index()
        summary.columns = ['Margin Band', 'Count', 'Avg Margin %']
        return summary.sort_values('Count', ascending=False)

    def write_excel(self, results, summary_lines, output_path):
        """Write results to a multi-tab Excel workbook."""
        from openpyxl import Workbook
        from salesengine.excel import df_to_sheet
        from salesengine.formatting.utils import timestamped_path

        wb = Workbook()
        ws = wb.active
        ws.title = "Executive Summary"

        first = True
        for sheet_name, df in results.items():
            if df is None or len(df) == 0:
                continue
            if first:
                ws.title = sheet_name
                first = False
            else:
                ws = wb.create_sheet(title=sheet_name[:31])
            df_to_sheet(ws, df)

        wb.save(output_path)
        print(f"Excel saved: {output_path}")
        return output_path
