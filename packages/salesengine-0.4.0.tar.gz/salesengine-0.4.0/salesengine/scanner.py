"""Auto-detect column roles via regex pattern matching."""
import re
import pandas as pd

_PATTERNS = {
    "customer_id": r"(?i)(cust|acct|account|client).*(id|num|no|code|key)|customer.?number",
    "customer_name": r"(?i)(cust|acct|account|client).*(name|desc)",
    "volume_cy": r"(?i)(pound|lb|unit|qty|quantity|volume).*(cy|current|this)",
    "volume_py": r"(?i)(pound|lb|unit|qty|quantity|volume).*(py|prior|prev|last)",
    "revenue_cy": r"(?i)(sale|revenue|net.?sale|gross).*(cy|current|this|\$.*cy)",
    "revenue_py": r"(?i)(sale|revenue|net.?sale|gross).*(py|prior|prev|last|\$.*py)",
    "margin_cy": r"(?i)(margin|profit|gp).*(cy|current|this|\$.*cy)",
    "margin_py": r"(?i)(margin|profit|gp).*(py|prior|prev|last|\$.*py)",
    "period_field": r"(?i)(fiscal.?week|period|week|month|quarter|date|fy.?week)",
    "segment_field": r"(?i)(segment|acct.?type|account.?type|customer.?type|channel|tier)",
    "product_field": r"(?i)(product|item|sku|category|attr.?group|brand|item.?group)",
    "geo_region": r"(?i)(region|territory|area|district|zone|market)",
    "geo_site": r"(?i)(site|branch|location|warehouse|company.?name|opco)",
}

def scan_dataset(csv_path, nrows=5000):
    """Scan a CSV and detect column roles."""
    df = pd.read_csv(csv_path, nrows=nrows, low_memory=False)
    columns = list(df.columns)
    dtypes = {c: str(df[c].dtype) for c in columns}
    samples = {c: df[c].dropna().head(3).tolist() for c in columns}

    matches = {}
    for col in columns:
        for role, pattern in _PATTERNS.items():
            if re.search(pattern, col):
                if role not in matches:
                    matches[role] = col
    return columns, dtypes, samples, matches
