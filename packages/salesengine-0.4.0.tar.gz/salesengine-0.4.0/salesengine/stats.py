"""Statistical utilities."""
import numpy as np
import pandas as pd

def safe_div(n, d):
    """Division with zero/NaN protection."""
    try:
        return float(n) / float(d) if float(d) != 0 else np.nan
    except Exception:
        return np.nan

def pct(n, d):
    """Percentage: n/d with zero protection."""
    if d == 0 or pd.isna(d):
        return np.nan
    return n / d

def cramers_v(series1, series2):
    """Cramér's V statistic for two categorical series."""
    try:
        from scipy.stats import chi2_contingency
        ct = pd.crosstab(series1, series2)
        chi2, _, _, _ = chi2_contingency(ct)
        n = ct.sum().sum()
        r, k = ct.shape
        return np.sqrt(chi2 / (n * (min(r, k) - 1))) if min(r, k) > 1 else 0
    except ImportError:
        return np.nan

def gini(array):
    """Gini coefficient for inequality measurement."""
    arr = np.array(array, dtype=float)
    arr = arr[~np.isnan(arr)]
    if len(arr) == 0:
        return np.nan
    arr = np.sort(arr)
    n = len(arr)
    idx = np.arange(1, n + 1)
    return (2 * np.sum(idx * arr) - (n + 1) * np.sum(arr)) / (n * np.sum(arr))

def statistical_summary(series):
    """Quick stats dict for a numeric series."""
    s = pd.to_numeric(series, errors='coerce').dropna()
    return {
        "count": len(s), "mean": s.mean(), "median": s.median(),
        "std": s.std(), "min": s.min(), "max": s.max(),
        "q25": s.quantile(0.25), "q75": s.quantile(0.75),
    }
