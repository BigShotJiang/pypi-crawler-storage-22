"""Tests for SalesEngine v0.4.0"""
import pytest

# ── Formatting Tests ──

def test_fmt_num():
    from salesengine.formatting.formatters import fmt_num
    assert fmt_num(2758944.72) == "2.8M"
    assert fmt_num(23677) == "24K"
    assert fmt_num(1234) == "1,234"
    assert fmt_num(2758944.72, prefix="$") == "$2.8M"
    assert fmt_num(0) == "0"
    assert fmt_num("bad") == "bad"

def test_fmt_pct():
    from salesengine.formatting.formatters import fmt_pct
    assert fmt_pct(0.15) == "+15.0%"
    assert fmt_pct(-0.03) == "-3.0%"
    assert fmt_pct(0) == "+0.0%"

def test_safe_line():
    from salesengine.formatting.formatters import safe_line
    assert "?" not in safe_line("✅ Volume: 100K")
    assert "?" not in safe_line("⚠️ Missing data")
    assert safe_line("plain text") == "plain text"
    assert safe_line("") == ""
    assert safe_line(None) is None

def test_format_stat_value():
    from salesengine.formatting.formatters import format_stat_value
    assert format_stat_value("Total Revenue", 2758944.72) == "$2.8M"
    assert format_stat_value("Retention %", 0.515) == "51.5%"
    assert format_stat_value("Distinct Customers", 21735) == "22K"

def test_clean_header():
    from salesengine.formatting.formatters import clean_header
    assert clean_header("Volume_Change_%") == "Change %"
    assert clean_header("Company Region Name") == "Region"
    assert clean_header("some_random_col") == "some random col"

def test_timestamped_path():
    from salesengine.formatting.utils import timestamped_path
    path = timestamped_path("/tmp/Report.pdf")
    assert "/tmp/Report_" in path
    assert path.endswith(".pdf")
    assert len(path) > len("/tmp/Report.pdf")

# ── Theme Tests ──

def test_report_theme_defaults():
    from salesengine.formatting.theme import ReportTheme
    t = ReportTheme()
    assert t.primary == "#0B7B7F"
    assert t.accent == "#E8720C"

def test_report_theme_custom():
    from salesengine.formatting.theme import ReportTheme
    t = ReportTheme(primary="#0081C6", company_name="Acme")
    assert t.primary == "#0081C6"
    assert t.company_name == "Acme"

# ── Config Tests ──

def test_project_config():
    from salesengine.config import ProjectConfig
    cfg = ProjectConfig(project_name="Test", customer_id="cust_id", volume_cy="vol_cy")
    assert cfg.has_fields("customer_id", "volume_cy")
    assert not cfg.has_fields("margin_cy")

def test_requires_fields_skip():
    from salesengine.config import requires_fields, set_global_config, ProjectConfig
    set_global_config(ProjectConfig(project_name="Test"))

    @requires_fields("margin_cy")
    def needs_margin(config=None):
        return "ran"

    assert needs_margin() is None  # Should skip, not crash

# ── Stats Tests ──

def test_safe_div():
    from salesengine.stats import safe_div
    import numpy as np
    assert safe_div(10, 2) == 5.0
    assert np.isnan(safe_div(10, 0))
    assert np.isnan(safe_div("bad", "data"))

def test_gini():
    from salesengine.stats import gini
    import numpy as np
    assert gini([1, 1, 1, 1]) == 0.0
    assert gini([0, 0, 0, 100]) > 0.5

# ── Cleaning Tests ──

def test_clean_numeric():
    import pandas as pd
    from salesengine.cleaning import clean_numeric
    s = pd.Series(["$1,234.56", "(500)", "abc", "100"])
    result = clean_numeric(s)
    assert result.iloc[0] == 1234.56
    assert result.iloc[1] == -500.0
    assert pd.isna(result.iloc[2])
    assert result.iloc[3] == 100.0

# ── Scanner Tests ──

def test_scan_patterns():
    import re
    from salesengine.scanner import _PATTERNS
    assert re.search(_PATTERNS["customer_id"], "Customer Number")
    assert re.search(_PATTERNS["volume_cy"], "Pounds CY")
    assert re.search(_PATTERNS["revenue_cy"], "Net Sales Ext $ CY")

# ── Churn Tests ──

def test_customer_movement():
    import pandas as pd
    from salesengine.churn import classify_customer_movement
    df = pd.DataFrame({
        'cust': ['A', 'B', 'C'],
        'vol_cy': [100, 0, 50],
        'vol_py': [80, 60, 0],
    })
    result = classify_customer_movement(df, 'cust', 'vol_cy', 'vol_py')
    assert result.loc[0, 'Movement'] == 'Retained'
    assert result.loc[1, 'Movement'] == 'Left_Entirely'
    assert result.loc[2, 'Movement'] == 'New_Acquisition'

# ── Integration Test ──

def test_version():
    import salesengine
    assert salesengine.__version__ == "0.4.0"

def test_imports():
    from salesengine import ProjectConfig, ReportTheme, timestamped_path
    from salesengine.formatting.formatters import fmt_num, fmt_pct, safe_line
    from salesengine.formatting.formatters import format_stat_value, clean_header
    from salesengine.stats import safe_div, pct, gini
    from salesengine.churn import classify_customer_movement
    from salesengine.index import price_index, classify_index
    from salesengine.confidence import score_confidence, classify_confidence_band
    from salesengine.banding import assign_band, priority_score
    from salesengine.cleaning import clean_numeric
