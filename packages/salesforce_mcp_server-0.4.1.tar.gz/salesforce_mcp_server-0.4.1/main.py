"""Salesforce MCP Server entry point."""

from salesforce_mcp_server.server import main

if __name__ == "__main__":
    main()
