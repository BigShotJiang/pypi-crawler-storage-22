"""Entry point for running salesforce_mcp_server as a module."""

from salesforce_mcp_server.server import main

if __name__ == "__main__":
    main()
