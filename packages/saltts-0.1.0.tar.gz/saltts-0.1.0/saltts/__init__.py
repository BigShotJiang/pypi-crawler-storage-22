"""SalTTS - Real-time, controllable, adaptive neural TTS system for AI VTubers."""

__version__ = "0.1.0"
__author__ = "SalTTS Team"

# Lazy imports to avoid dependency errors on import
def _get_engine():
    """Lazy import of SalTTSEngine."""
    from saltts.inference.engine import SalTTSEngine
    return SalTTSEngine

# Only export version and author by default
__all__ = ["__version__", "__author__"]

# Try to import main engine, but don't fail if dependencies missing
try:
    from saltts.inference.engine import SalTTSEngine
    __all__.append("SalTTSEngine")
except ImportError:
    # Dependencies not installed, skip
    pass
