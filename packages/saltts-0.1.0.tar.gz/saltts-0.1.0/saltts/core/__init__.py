"""Core components for SalTTS."""

from saltts.core.data_structures import ProsodyParams, AudioOutput

__all__ = ["ProsodyParams", "AudioOutput"]
