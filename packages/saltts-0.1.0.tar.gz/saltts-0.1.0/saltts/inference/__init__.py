"""Inference engine for SalTTS."""
