"""NMDB integration layer for SalTTS."""
