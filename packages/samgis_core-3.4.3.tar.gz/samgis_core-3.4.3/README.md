# SamGIS CORE

Core functionality for [SamGIS](https://github.com/trincadev/samgis-be) project:
- instance segmentation and recognition with a [segment anything](https://segment-anything.com/) model
- various utilities (logging, serialize, type hints, etcetera)
