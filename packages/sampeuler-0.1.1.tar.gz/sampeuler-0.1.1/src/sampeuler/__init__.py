"""
SampEuler: Euler Characteristic Transform and related topological data analysis tools.

This package provides efficient implementations of:
- Euler Characteristic Transform (ECT)
- Smooth Euler Characteristic Transform (SECT)
- SampEuler (randomly sampled ECT directions)
- SampEuler Vectorization (2D histogram representation)
- Distance metrics for comparing shapes
"""

from .core import (
    # Helper functions
    euler_critical_values,
    euler_curve,
    cumulative_euler_curve,
    # ECT 2D
    ect_2d,
    # SECT 2D
    sect_2d,
    # SampEuler 2D
    SampEuler_2d,
    # ECT general dimension
    ect,
    # SECT general dimension
    sect,
    # SampEuler general dimension
    SampEuler,
    # Metrics
    ect_metric,
    sampeuler_wasserstein_distance,
    # Vectorization class
    SampEulerVectorization,
    EctImg,  # Alias for backwards compatibility
)

__version__ = "0.1.0"

__all__ = [
    # Helper functions
    "euler_critical_values",
    "euler_curve",
    "cumulative_euler_curve",
    # ECT
    "ect_2d",
    "ect",
    # SECT
    "sect_2d",
    "sect",
    # SampEuler
    "SampEuler_2d",
    "SampEuler",
    # Metrics
    "ect_metric",
    "sampeuler_wasserstein_distance",
    # Vectorization
    "SampEulerVectorization",
    "EctImg",
]
