"""
Core functions for SampEuler package.

This module contains all the main computational functions for ECT, SECT, and SampEuler.
"""

import numpy as np
import numba as nb
from scipy.spatial.distance import cdist
from scipy.optimize import linear_sum_assignment
import matplotlib.pyplot as plt


@nb.njit()
def euler_critical_values(simp_comp, data, direction):
    """
    Compute the Euler critical values for an embedded simplicial complex filtered in a given direction.

    Parameters:
        simp_comp : numba.typed.List of numba.typed.List
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, dim)
            The coordinates of the vertices in Euclidean space.
        direction : np.array of shape (dim,)
            The unit vector direction for the filtration.

    Returns:
        np.array of shape (n_simplices, 2)
            Array where column 0 is the simplex size and column 1 is the filtration value.
    """
    filtration = np.empty((len(simp_comp), 2), dtype=float)
    for i, simplex in enumerate(simp_comp):
        fv = max([np.sum(np.multiply(data[v], direction)) for v in simplex])
        filtration[i] = (float(len(simplex)), fv)
    return filtration



@nb.njit()
def euler_curve(simp_comp, data, direction, interval=(-1., 1.), points: int = 100):
    """
    Compute the Euler curve as evenly spaced evaluations on a given interval.

    Parameters:
        simp_comp : numba.typed.List of numba.typed.List
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, dim)
            The coordinates of the vertices in Euclidean space.
        direction : np.array of shape (dim,)
            The unit vector direction for the filtration.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the Euler curve.
        points : int, default 100
            The number of evenly spaced points at which to evaluate the Euler curve.

    Returns:
        np.array of shape (points,)
            The Euler curve evaluated at evenly spaced points on the interval.
    """
    filtration = euler_critical_values(simp_comp, data, direction)
    order = np.argsort(filtration[:, 1])
    filtration = filtration[order]
    value, c = 0., 0
    step_size = (interval[1] - interval[0]) / (points - 1)

    chi = np.empty(points, dtype=float)

    for i, x in enumerate(np.linspace(interval[0], interval[1], points)):
        if x < filtration[c, 1] <= min(x + step_size, interval[1]):
            while filtration[c, 1] <= x + step_size and c < len(filtration):
                
                value -= float((-1) ** int(filtration[c, -2]))
                c += 1

        chi[i] = value

    return chi


@nb.njit()
def cumulative_euler_curve(simp_comp, data, direction, interval=(-1., 1.), points: int = 100):
    """
    Compute the cumulative (smooth) Euler curve as the integral of the Euler curve.

    Parameters:
        simp_comp : numba.typed.List of numba.typed.List
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, dim)
            The coordinates of the vertices in Euclidean space.
        direction : np.array of shape (dim,)
            The unit vector direction for the filtration.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the curve.
        points : int, default 100
            The number of evenly spaced points at which to evaluate.

    Returns:
        np.array of shape (points,)
            The cumulative Euler curve (integral of EC) evaluated at evenly spaced points.
    """
    chi = euler_curve(simp_comp, data, direction, interval, points)
    step_size = (interval[1] - interval[0]) / (points - 1)
    return np.cumsum(chi) * step_size


# ==================== ECT 2D ====================
@nb.njit(parallel=True)
def _ect_2d(simp_comp, data, k=20, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """JIT-compiled parallel inner function for ect_2d. Computes ECT over k evenly spaced directions."""
    ect = np.empty((k, points), dtype=np.float64)
    thetas = np.linspace(0, 2 * np.pi, k + 1)

    for i in nb.prange(k):
        theta = thetas[i]
        direction = np.array((np.sin(theta), np.cos(theta)))
        ect[i] = euler_curve(simp_comp, data, direction, interval, points * factor)[::factor]

    return ect


def ect_2d(simp_comp, data, k=20, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """
    Compute the Euler Characteristic Transform (ECT) in 2D using k evenly spaced directions.
    
    Parameters:
        simp_comp : list of lists
            The embedded simplicial complex, where each simplex is represented as a list of vertex indices.
        data : np.array of shape (n_vertices, 2)
            The coordinates of the vertices in 2D space.
        k : int, default 20
            The number of directions to sample for the ECT.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the Euler curve. This should be chosen long enough to include all vertices in the filtration.
        points : int, default 100
            The number of evenly spaced points at which to evaluate the Euler curve.
        factor : int, default 3
            The downsampling factor for the Euler curve evaluations.
    
    Returns:
        np.array of shape (k, points)
            The ECT represented as a 2D array, where each row corresponds to the Euler curve evaluated in a specific direction.
    """
    numba_comp_sc = nb.typed.List()
    for s in simp_comp:
        numba_comp_sc.append(nb.typed.List(s))
    
    return _ect_2d(numba_comp_sc, data, k, interval, points, factor)


# ==================== SECT 2D ====================
@nb.njit(parallel=True)
def _sect_2d(simp_comp, data, k=20, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """JIT-compiled parallel inner function for sect_2d. Computes SECT over k evenly spaced directions."""
    sect = np.empty((k, points), dtype=np.float64)
    thetas = np.linspace(0, 2 * np.pi, k + 1)

    for i in nb.prange(k):
        theta = thetas[i]
        direction = np.array((np.sin(theta), np.cos(theta)))
        sect[i] = cumulative_euler_curve(simp_comp, data, direction, interval, points * factor)[::factor]

    return sect


def sect_2d(simp_comp, data, k=20, interval=(-1., 1.), points: int = 100, factor: int = 3, mode='full'):
    """
    Compute the Smooth Euler Characteristic Transform (SECT) in 2D using k evenly spaced directions.

    Parameters:
        simp_comp : list of lists
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, 2)
            The coordinates of the vertices in 2D space.
        k : int, default 20
            The number of directions to sample for the SECT.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the cumulative Euler curve.
        points : int, default 100
            The number of evenly spaced points at which to evaluate.
        factor : int, default 3
            The downsampling factor for the evaluations.
        mode : str, default 'full'
            'full' returns the full (k, points) array.
            'mean' returns the mean across directions as a 1D array of shape (points,).

    Returns:
        np.array
            If mode='full': shape (k, points), each row is a cumulative Euler curve.
            If mode='mean': shape (points,), the mean cumulative Euler curve.
    """
    numba_comp_sc = nb.typed.List()
    for s in simp_comp:
        numba_comp_sc.append(nb.typed.List(s))

    result = _sect_2d(numba_comp_sc, data, k, interval, points, factor)

    if mode == 'mean':
        return np.mean(result, axis=0)
    return result


# ==================== SampEuler 2D ====================
@nb.njit(parallel=True)
def _sampeuler_2d(simp_comp, data, thetas, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """JIT-compiled parallel inner function for SampEuler_2d. Thetas passed in since np.random not compatible with njit."""
    k = len(thetas)
    ect = np.empty((k, points), dtype=np.float64)

    for i in nb.prange(k):
        theta = thetas[i]
        direction = np.array((np.sin(theta), np.cos(theta)))
        ec_values = euler_curve(simp_comp, data, direction, interval, points * factor)
        ect[i] = ec_values[::factor]

    return ect


def SampEuler_2d(simp_comp, data, k=20, interval=(-1., 1.), points=100, factor=3):
    """
    Compute the SampEuler transform using k randomly sampled directions in 2D.

    Parameters:
        simp_comp : list of lists
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, 2)
            The coordinates of the vertices in 2D space.
        k : int, default 20
            The number of random directions to sample.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the Euler curve.
        points : int, default 100
            The number of evenly spaced points at which to evaluate the Euler curve.
        factor : int, default 3
            The downsampling factor for the Euler curve evaluations.

    Returns:
        np.array of shape (k, points)
            The SampEuler transform, where each row is an Euler curve for a random direction.
    """
    numba_comp_sc = nb.typed.List()
    for s in simp_comp:
        numba_comp_sc.append(nb.typed.List(s))

    # Generate k random angles in [0, 2π) - must be outside JIT function
    thetas = 2 * np.pi * np.random.rand(k)

    return _sampeuler_2d(numba_comp_sc, data, thetas, interval, points, factor)


# ==================== ECT ====================
@nb.njit(parallel=True)
def _ect(simp_comp, data, thetas, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """JIT-compiled parallel inner function for ect. Computes ECT over provided direction vectors."""
    k = len(thetas)
    ect = np.empty((k, points), dtype=np.float64)
    for i in nb.prange(k):
        theta = thetas[i]
        direction = np.array((np.sin(theta), np.cos(theta)))
        ect[i] = euler_curve(simp_comp, data, direction, interval, points * factor)[::factor]

    return ect


def ect(simp_comp, data, thetas, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """
    Compute the ECT using provided direction vectors.

    Parameters:
        simp_comp : list of lists
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, dim)
            The coordinates of the vertices in Euclidean space.
        thetas : np.array of shape (k, dim)
            The unit direction vectors to use for the ECT.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the Euler curve.
        points : int, default 100
            The number of evenly spaced points at which to evaluate the Euler curve.
        factor : int, default 3
            The downsampling factor for the Euler curve evaluations.

    Returns:
        np.array of shape (k, points)
            The ECT, where each row is an Euler curve for a given direction.
    """
    numba_comp_sc = nb.typed.List()
    if data.shape[1] != thetas.shape[1]:
        raise ValueError("Dimension mismatch between data and thetas.")
    for s in simp_comp:
        numba_comp_sc.append(nb.typed.List(s))
    
    return _ect(numba_comp_sc, data, thetas, interval, points, factor)


# ==================== SECT ====================
@nb.njit(parallel=True)
def _sect(simp_comp, data, directions, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """JIT-compiled parallel inner function for sect. Directions are unit vectors passed in."""
    k = len(directions)
    sect = np.empty((k, points), dtype=np.float64)

    for i in nb.prange(k):
        direction = directions[i]  # Already a unit vector
        sect[i] = cumulative_euler_curve(simp_comp, data, direction, interval, points * factor)[::factor]

    return sect


def sect(simp_comp, data, directions, interval=(-1., 1.), points: int = 100, factor: int = 3, mode='full'):
    """
    Compute the SECT using provided direction vectors (arbitrary dimension).

    Parameters:
        simp_comp : list of lists
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, dim)
            The coordinates of the vertices in Euclidean space.
        directions : np.array of shape (k, dim)
            The unit direction vectors to use for the SECT.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the cumulative Euler curve.
        points : int, default 100
            The number of evenly spaced points at which to evaluate.
        factor : int, default 3
            The downsampling factor for the evaluations.
        mode : str, default 'full'
            'full' returns the full (k, points) array.
            'mean' returns the mean across directions as a 1D array of shape (points,).

    Returns:
        np.array
            If mode='full': shape (k, points), each row is a SECT curve.
            If mode='mean': shape (points,), the DETECT curve.
    """
    numba_comp_sc = nb.typed.List()
    if data.shape[1] != directions.shape[1]:
        raise ValueError("Dimension mismatch between data and directions.")
    for s in simp_comp:
        numba_comp_sc.append(nb.typed.List(s))

    result = _sect(numba_comp_sc, data, directions, interval, points, factor)

    if mode == 'mean':
        return np.mean(result, axis=0)
    return result


# ==================== SampEuler ====================
@nb.njit(parallel=True)
def _sampeuler(simp_comp, data, directions, interval=(-1., 1.), points: int = 100, factor: int = 3):
    """JIT-compiled parallel inner function for SampEuler. Directions are unit vectors passed in."""
    k = len(directions)
    ect = np.empty((k, points), dtype=np.float64)

    for i in nb.prange(k):
        direction = directions[i]  # Already a unit vector
        ec_values = euler_curve(simp_comp, data, direction, interval, points * factor)
        ect[i] = ec_values[::factor]

    return ect


def SampEuler(simp_comp, data, dim, k, interval=(-1., 1.), points=100, factor=3):
    """
    Compute the SampEuler transform using k randomly sampled directions in arbitrary dimension.

    Parameters:
        simp_comp : list of lists
            The embedded simplicial complex, where each simplex is a list of vertex indices.
        data : np.array of shape (n_vertices, dim)
            The coordinates of the vertices in Euclidean space.
        dim : int
            The dimension of the embedding space.
        k : int
            The number of random directions to sample.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the Euler curve.
        points : int, default 100
            The number of evenly spaced points at which to evaluate the Euler curve.
        factor : int, default 3
            The downsampling factor for the Euler curve evaluations.

    Returns:
        np.array of shape (k, points)
            The SampEuler transform, where each row is an Euler curve for a random direction.
    """
    numba_comp_sc = nb.typed.List()
    for s in simp_comp:
        numba_comp_sc.append(nb.typed.List(s))
    directions = np.random.randn(k, dim)  # generate k random vectors in R^dim
    directions /= np.linalg.norm(directions, axis=1)[:, np.newaxis]  # normalize to unit vectors
    return _sampeuler(numba_comp_sc, data, directions, interval, points, factor)


# ==================== ECT Metric ====================
@nb.njit(parallel=True)
def _ect_metric(simp_comp1, data1, simp_comp2, data2, thetas, interval=(-1., 1.), points: int = 100):
    """JIT-compiled parallel inner function for ect_metric. Computes supremum of L1 differences over directions."""
    k = len(thetas) - 1
    step_size = (interval[1] - interval[0]) / (points - 1)
    
    # Compute all integrals in parallel, then reduce
    integrals = np.empty(k, dtype=np.float64)
    
    for i in nb.prange(k):
        theta = thetas[i]
        direction = np.array((np.sin(theta), np.cos(theta)))
        ect1 = euler_curve(simp_comp1, data1, direction, interval, points)
        ect2 = euler_curve(simp_comp2, data2, direction, interval, points)
        integrals[i] = np.sum(np.abs(ect1 - ect2)) * step_size
    
    return np.max(integrals)


def ect_metric(simp_comp1, data1, simp_comp2, data2, k=20, interval=(-1., 1.), points: int = 100):
    """
    Compute the ECT metric between two shapes as the supremum of L1 differences over directions.

    Parameters:
        simp_comp1 : list of lists
            The first embedded simplicial complex.
        data1 : np.array of shape (n_vertices1, 2)
            The coordinates of vertices for the first shape.
        simp_comp2 : list of lists
            The second embedded simplicial complex.
        data2 : np.array of shape (n_vertices2, 2)
            The coordinates of vertices for the second shape.
        k : int, default 20
            The number of evenly spaced directions to use.
        interval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the Euler curves.
        points : int, default 100
            The number of evenly spaced points at which to evaluate the Euler curves.

    Returns:
        float
            The ECT metric (supremum of integrated L1 differences).
    """
    numba_comp_sc1 = nb.typed.List()
    for s in simp_comp1:
        numba_comp_sc1.append(nb.typed.List(s))
        
    numba_comp_sc2 = nb.typed.List()
    for s in simp_comp2:
        numba_comp_sc2.append(nb.typed.List(s))
    
    thetas = np.linspace(0, 2 * np.pi, k + 1)
    
    return _ect_metric(numba_comp_sc1, data1, numba_comp_sc2, data2, thetas, interval, points)

# ==================== SampEuler Metric ====================
def sampeuler_wasserstein_distance(empirical1, empirical2, p=2, delta_x=1.0):
    """
    Compute the Wasserstein distance between two SampEuler empirical measures,
    each represented as a k x N array (each row is a function sampled at N points),
    incorporating the delta_x factor for uniformly sampled points.

    Parameters:
        empirical1 : np.array of shape (k, N)
            The first set of Euler curves (from SampEuler).
        empirical2 : np.array of shape (k, N)
            The second set of Euler curves (from SampEuler).
        p : float, default 2
            The order of the norm (p=2 for L2, p=1 for L1).
        delta_x : float, default 1.0
            The spacing between sample points, e.g.,
            (x_max - x_min) / (N - 1).

    Returns:
        float
            The computed Wasserstein distance.
    """
    # Compute the cost matrix using the Minkowski metric.
    # cdist returns (sum_i |f_i - g_i|^p)^(1/p), so we multiply by (delta_x)^(1/p)
    cost_matrix = cdist(empirical1, empirical2, metric='minkowski', p=p) * (delta_x ** (1.0 / p))

    # Solve the assignment problem to obtain the best matching.
    row_ind, col_ind = linear_sum_assignment(cost_matrix)

    # Compute the average p-th power cost for the matched pairs.
    avg_cost_p = np.mean(cost_matrix[row_ind, col_ind] ** p)

    # Return the p-th root of the average cost.
    return avg_cost_p ** (1.0 / p)





    
class SampEulerVectorization:
    """
    A class to compute and visualize a SampEuler vectorization as a 2D image.

    Parameters:
        simp_comp : list of lists, optional
            The embedded simplicial complex, where each simplex is a list of vertex indices.
            Required if precomputed is not provided.
        data : np.array of shape (n_vertices, dim), optional
            The coordinates of the vertices in Euclidean space.
            Required if precomputed is not provided.
        k : int, default 20
            The number of random directions to sample. Ignored if precomputed is provided.
        xinterval : tuple of float, default (-1., 1.)
            The interval on which to evaluate the Euler curve (x-axis of image).
        xpoints : int, default 100
            The number of bins along the x-axis of the output image.
        yinterval : tuple of float, default (-1., 1.)
            The range of Euler characteristic values (y-axis of image).
        ypoints : int, default 100
            The number of bins along the y-axis.
        resolution : int, default 1
            Resolution multiplier for SampEuler. SampEuler will have xpoints * resolution
            evaluation points. When resolution > 1, a direction is counted in a bin only if
            ALL of its values within the corresponding x-interval fall within the y-bin.
        factor : int, default 3
            The downsampling factor for internal Euler curve evaluations.
        precomputed : np.array of shape (k, xpoints * resolution), optional
            Precomputed SampEuler or ECT data. If provided, simp_comp and data are ignored.

    Attributes:
        sampeuler : np.array of shape (k, xpoints * resolution)
            The underlying SampEuler data (computed lazily or from precomputed).
        image : np.array of shape (ypoints, xpoints)
            The vectorized image as a 2D histogram (computed lazily).
    """

    def __init__(self, simp_comp=None, data=None, k=20, xinterval=(-1., 1.), xpoints=100,
                 yinterval=(-1., 1.), ypoints=100, resolution=1, factor=3, precomputed=None):
        self._simp_comp = simp_comp
        self._data = data
        self._k = k
        self._dim = data.shape[1] if data is not None else None
        self.xinterval = xinterval
        self.yinterval = yinterval
        self.xpoints = xpoints
        self.ypoints = ypoints
        self.resolution = resolution
        self._factor = factor

        # Lazily computed attributes
        self._image = None

        # Handle precomputed data
        if precomputed is not None:
            self._sampeuler = precomputed
            self._k = precomputed.shape[0]
        else:
            self._sampeuler = None
            if simp_comp is None or data is None:
                raise ValueError("Either provide (simp_comp, data) or precomputed data.")

    @property
    def sampeuler(self):
        """The SampEuler transform of shape (k, xpoints * resolution). Computed lazily."""
        if self._sampeuler is None:
            self._sampeuler = SampEuler(
                self._simp_comp, self._data, self._dim, self._k,
                self.xinterval, self.xpoints * self.resolution, self._factor
            )
        return self._sampeuler

    @property
    def image(self):
        """The vectorized image of shape (ypoints, xpoints). Computed lazily."""
        if self._image is None:
            self._image = self._compute_image()
        return self._image

    def _compute_image(self):
        """
        Compute the image as a 2D histogram from SampEuler data.

        Returns:
            np.array of shape (ypoints, xpoints)
                The vectorized image.
        """
        sampeuler = self.sampeuler
        image = np.zeros((self.ypoints, self.xpoints), dtype=float)
        yvalues = np.linspace(self.yinterval[0], self.yinterval[1], self.ypoints + 1, endpoint=True)

        for i in range(self.xpoints):
            # Get all columns that fall into this x-interval
            start_col = i * self.resolution
            end_col = (i + 1) * self.resolution
            columns = sampeuler[:, start_col:end_col]  # shape (k, resolution)

            for j in range(self.ypoints):
                y_low = yvalues[j]
                y_high = yvalues[j + 1]

                if j < self.ypoints - 1:
                    # Check if values are within [y_low, y_high)
                    in_range = (columns >= y_low) & (columns < y_high)
                else:
                    # Last bin: inclusive on both ends [y_low, y_high]
                    in_range = (columns >= y_low) & (columns <= y_high)

                # Count rows where ALL columns are in range
                all_in_range = np.all(in_range, axis=1)
                image[j, i] = np.sum(all_in_range) / self._k

        return image

    def compute(self):
        """
        Force computation and return the image.

        Returns:
            np.array of shape (ypoints, xpoints)
                The vectorized image.
        """
        return self.image

    def plot(self, title='SampEuler Image', xlabel='Filtration Value', ylabel='Euler Characteristic'):
        """
        Display the image using matplotlib.

        Parameters:
            title : str, default 'SampEuler Image'
                The plot title.
            xlabel : str, default 'Filtration Value'
                The x-axis label.
            ylabel : str, default 'Euler Characteristic'
                The y-axis label.
        """
        plt.figure(figsize=(10, 8))
        plt.imshow(
            self.image, aspect='auto',
            extent=[self.xinterval[0], self.xinterval[1], self.yinterval[0], self.yinterval[1]],
            origin='lower', interpolation='none'
        )
        plt.colorbar(label='Density')
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.title(title)
        plt.show()


# Alias for backwards compatibility
EctImg = SampEulerVectorization
