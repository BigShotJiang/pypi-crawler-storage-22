"""
Basic tests for sampeuler package.
"""

import numpy as np
import pytest


def test_import():
    """Test that the package can be imported."""
    import sampeuler as se
    assert hasattr(se, '__version__')
    assert se.__version__ == "0.1.0"


def test_ect_2d():
    """Test ect_2d function on a simple triangle."""
    import sampeuler as se

    # Define a simple triangle
    simp_comp = [
        [0], [1], [2],           # vertices
        [0, 1], [1, 2], [0, 2],  # edges
        [0, 1, 2]                # face
    ]
    data = np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [0.5, 1.0]
    ])

    result = se.ect_2d(simp_comp, data, k=10, interval=(-2., 2.), points=50)

    assert result.shape == (10, 50)
    assert not np.isnan(result).any()


def test_sampeuler_2d():
    """Test SampEuler_2d function on a simple triangle."""
    import sampeuler as se

    simp_comp = [
        [0], [1], [2],
        [0, 1], [1, 2], [0, 2],
        [0, 1, 2]
    ]
    data = np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [0.5, 1.0]
    ])

    result = se.SampEuler_2d(simp_comp, data, k=100, interval=(-2., 2.), points=50)

    assert result.shape == (100, 50)
    assert not np.isnan(result).any()


def test_sect_2d():
    """Test sect_2d function on a simple triangle."""
    import sampeuler as se

    simp_comp = [
        [0], [1], [2],
        [0, 1], [1, 2], [0, 2],
        [0, 1, 2]
    ]
    data = np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [0.5, 1.0]
    ])

    # Test full mode
    result_full = se.sect_2d(simp_comp, data, k=10, interval=(-2., 2.), points=50, mode='full')
    assert result_full.shape == (10, 50)

    # Test mean mode
    result_mean = se.sect_2d(simp_comp, data, k=10, interval=(-2., 2.), points=50, mode='mean')
    assert result_mean.shape == (50,)


def test_sampeuler_vectorization():
    """Test SampEulerVectorization class."""
    import sampeuler as se

    simp_comp = [
        [0], [1], [2],
        [0, 1], [1, 2], [0, 2],
        [0, 1, 2]
    ]
    data = np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [0.5, 1.0]
    ])

    vec = se.SampEulerVectorization(
        simp_comp, data,
        k=50,
        xinterval=(-2., 2.), xpoints=20,
        yinterval=(-2., 2.), ypoints=10,
        resolution=1
    )

    # Test lazy computation
    image = vec.image
    assert image.shape == (10, 20)
    assert not np.isnan(image).any()


def test_sampeuler_vectorization_precomputed():
    """Test SampEulerVectorization with precomputed data."""
    import sampeuler as se

    # Create some fake precomputed data
    precomputed = np.random.randn(100, 50)

    vec = se.SampEulerVectorization(
        precomputed=precomputed,
        xinterval=(-2., 2.), xpoints=50,
        yinterval=(-5., 5.), ypoints=10,
        resolution=1
    )

    # Test that precomputed data is used
    assert vec.sampeuler is precomputed
    assert vec._k == 100

    # Test image computation
    image = vec.image
    assert image.shape == (10, 50)


def test_wasserstein_distance():
    """Test sampeuler_wasserstein_distance function."""
    import sampeuler as se

    # Create two random empirical measures
    emp1 = np.random.randn(50, 100)
    emp2 = np.random.randn(50, 100)

    distance = se.sampeuler_wasserstein_distance(emp1, emp2, p=2, delta_x=0.01)

    assert isinstance(distance, float)
    assert distance >= 0


def test_ect_metric():
    """Test ect_metric function."""
    import sampeuler as se

    # Two identical triangles
    simp_comp = [
        [0], [1], [2],
        [0, 1], [1, 2], [0, 2],
        [0, 1, 2]
    ]
    data1 = np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [0.5, 1.0]
    ])
    data2 = np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [0.5, 1.0]
    ])

    # Same shape should have distance close to 0
    metric = se.ect_metric(simp_comp, data1, simp_comp, data2, k=10, interval=(-2., 2.), points=50)
    assert metric >= 0
    assert metric < 0.1  # Should be very small for identical shapes
