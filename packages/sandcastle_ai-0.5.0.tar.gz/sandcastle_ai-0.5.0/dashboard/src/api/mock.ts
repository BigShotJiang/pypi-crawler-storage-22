import type { ApiResponse } from "./client";

// NOTE: GET /events is a Server-Sent Events (SSE) endpoint - cannot be mocked
// via mockFetch. The endpoint streams real-time events with the following format:
//
//   event: run.started | run.completed | run.failed |
//          step.started | step.completed | step.failed | dlq.new
//   data: {"type": "<event_type>", "data": {...}, "timestamp": "ISO8601"}
//
// Event data payloads:
//   run.started    -> { run_id, workflow }
//   run.completed  -> { run_id, status, workflow, duration_seconds, total_cost_usd }
//   run.failed     -> { run_id, workflow, error }
//   step.started   -> { run_id, step_name, workflow }
//   step.completed -> { run_id, step_name, status, cost_usd, duration_seconds }
//   step.failed    -> { run_id, step_name, error }
//   dlq.new        -> { run_id, step_name, error }
//
// Connect from the frontend with: new EventSource("/events")

interface MockStep {
  step_id: string;
  parallel_index: number | null;
  status: string;
  output: unknown;
  cost_usd: number;
  duration_seconds: number;
  attempt: number;
  error: string | null;
}

const now = new Date();
const h = (hoursAgo: number) => new Date(now.getTime() - hoursAgo * 3600000).toISOString();
const d = (daysAgo: number) => new Date(now.getTime() - daysAgo * 86400000).toISOString().slice(0, 10);

const MOCK_RUNS = [
  { run_id: "a1b2c3d4-1111-4000-8000-000000000001", workflow_name: "lead-enrichment", status: "completed", total_cost_usd: 1.84, started_at: h(0.5), completed_at: h(0.45) },
  { run_id: "a1b2c3d4-2222-4000-8000-000000000002", workflow_name: "competitor-monitor", status: "running", total_cost_usd: 0.67, started_at: h(0.1), completed_at: null },
  { run_id: "a1b2c3d4-3333-4000-8000-000000000003", workflow_name: "seo-audit", status: "completed", total_cost_usd: 1.23, started_at: h(2), completed_at: h(1.9) },
  { run_id: "a1b2c3d4-4444-4000-8000-000000000004", workflow_name: "lead-enrichment", status: "failed", total_cost_usd: 0.41, started_at: h(5), completed_at: h(4.95) },
  { run_id: "a1b2c3d4-5555-4000-8000-000000000005", workflow_name: "lead-enrichment", status: "completed", total_cost_usd: 1.72, started_at: h(8), completed_at: h(7.9) },
  { run_id: "a1b2c3d4-6666-4000-8000-000000000006", workflow_name: "competitor-monitor", status: "completed", total_cost_usd: 1.35, started_at: h(12), completed_at: h(11.8) },
  { run_id: "a1b2c3d4-7777-4000-8000-000000000007", workflow_name: "seo-audit", status: "completed", total_cost_usd: 0.98, started_at: h(18), completed_at: h(17.9) },
  { run_id: "a1b2c3d4-8888-4000-8000-000000000008", workflow_name: "lead-enrichment", status: "completed", total_cost_usd: 2.16, started_at: h(24), completed_at: h(23.8) },
  { run_id: "a1b2c3d4-9999-4000-8000-000000000009", workflow_name: "competitor-monitor", status: "failed", total_cost_usd: 0.29, started_at: h(30), completed_at: h(29.9) },
  { run_id: "a1b2c3d4-aaaa-4000-8000-00000000000a", workflow_name: "seo-audit", status: "completed", total_cost_usd: 0.87, started_at: h(36), completed_at: h(35.8) },
  { run_id: "a1b2c3d4-bbbb-4000-8000-00000000000b", workflow_name: "lead-enrichment", status: "completed", total_cost_usd: 1.54, started_at: h(48), completed_at: h(47.5) },
  { run_id: "a1b2c3d4-cccc-4000-8000-00000000000c", workflow_name: "lead-enrichment", status: "completed", total_cost_usd: 1.97, started_at: h(60), completed_at: h(59.8) },
];

const MOCK_STEPS: MockStep[] = [
  { step_id: "scrape", parallel_index: null, status: "completed", output: { url: "https://example.com", title: "Example Corp", employees: 150 }, cost_usd: 0.52, duration_seconds: 12.3, attempt: 1, error: null },
  { step_id: "enrich", parallel_index: null, status: "completed", output: { company: "Example Corp", revenue: "$50M", industry: "SaaS", decision_makers: ["John CEO", "Jane CTO"] }, cost_usd: 0.89, duration_seconds: 18.7, attempt: 1, error: null },
  { step_id: "score", parallel_index: null, status: "completed", output: { lead_score: 87, tier: "A", recommendation: "High priority - schedule demo this week" }, cost_usd: 0.43, duration_seconds: 8.2, attempt: 1, error: null },
];

const MOCK_STEPS_RUNNING: MockStep[] = [
  { step_id: "fetch-competitors", parallel_index: null, status: "completed", output: { competitors: ["CompA", "CompB", "CompC"] }, cost_usd: 0.02, duration_seconds: 6.1, attempt: 1, error: null },
  { step_id: "analyze", parallel_index: 0, status: "completed", output: { name: "CompA", changes: "New pricing page" }, cost_usd: 0.01, duration_seconds: 9.3, attempt: 1, error: null },
  { step_id: "analyze", parallel_index: 1, status: "running", output: null, cost_usd: 0.0, duration_seconds: 0, attempt: 1, error: null },
  { step_id: "analyze", parallel_index: 2, status: "pending", output: null, cost_usd: 0.0, duration_seconds: 0, attempt: 1, error: null },
];

const MOCK_STEPS_FAILED: MockStep[] = [
  { step_id: "scrape", parallel_index: null, status: "completed", output: { url: "https://broken.test" }, cost_usd: 0.02, duration_seconds: 4.1, attempt: 1, error: null },
  { step_id: "enrich", parallel_index: null, status: "failed", output: null, cost_usd: 0.01, duration_seconds: 2.3, attempt: 3, error: "Timeout after 300s - external API unreachable" },
];

function getRunDetail(runId: string) {
  const run = MOCK_RUNS.find((r) => r.run_id === runId);
  if (!run) return null;

  let steps = MOCK_STEPS;
  if (run.status === "running") steps = MOCK_STEPS_RUNNING;
  if (run.status === "failed") steps = MOCK_STEPS_FAILED;

  // Add budget for the first run to demo the BudgetBar
  const maxCost = runId === "a1b2c3d4-1111-4000-8000-000000000001" ? 2.50 : null;
  // Demo parent_run_id for the third run (replay)
  const parentRunId = runId === "a1b2c3d4-3333-4000-8000-000000000003"
    ? "a1b2c3d4-1111-4000-8000-000000000001"
    : null;
  const replayFromStep = parentRunId ? "analyze-technical" : null;

  return {
    ...run,
    input_data: { target_url: "https://example.com", max_depth: 3 },
    outputs: run.status === "completed" ? { final: "Lead enrichment complete" } : null,
    error: run.status === "failed" ? "Step 'enrich' failed after 3 attempts" : null,
    steps,
    max_cost_usd: maxCost,
    parent_run_id: parentRunId,
    replay_from_step: replayFromStep,
    fork_changes: null,
  };
}

const MOCK_STATS = {
  total_runs_today: 8,
  success_rate: 0.875,
  total_cost_today: 7.82,
  avg_duration_seconds: 42.3,
  runs_by_day: Array.from({ length: 30 }, (_, i) => {
    const completed = Math.floor(Math.random() * 12) + 2;
    const failed = Math.floor(Math.random() * 3);
    return { date: d(29 - i), completed, failed, total: completed + failed };
  }),
  cost_by_workflow: [
    { workflow: "lead-enrichment", cost: 14.58 },
    { workflow: "competitor-monitor", cost: 8.34 },
    { workflow: "seo-audit", cost: 4.72 },
  ],
};

const MOCK_WORKFLOWS = [
  {
    name: "Lead Enrichment",
    description: "Scrape target websites, enrich with company data, and score leads for sales outreach priority.",
    steps_count: 3,
    file_name: "lead-enrichment.yaml",
    steps: [
      { id: "scrape", model: "sonnet", depends_on: [] },
      { id: "enrich", model: "sonnet", depends_on: ["scrape"] },
      { id: "score", model: "haiku", depends_on: ["enrich"] },
    ],
  },
  {
    name: "Competitor Monitor",
    description: "Track competitor websites for changes, analyze differences, and generate a summary report.",
    steps_count: 4,
    file_name: "competitor-monitor.yaml",
    steps: [
      { id: "fetch-competitors", model: "sonnet", depends_on: [] },
      { id: "analyze", model: "sonnet", depends_on: ["fetch-competitors"] },
      { id: "summarize", model: "sonnet", depends_on: ["analyze"] },
      { id: "format-report", model: "haiku", depends_on: ["summarize"] },
    ],
  },
  {
    name: "SEO Audit",
    description: "Crawl a website, analyze on-page SEO factors, and produce actionable recommendations.",
    steps_count: 3,
    file_name: "seo-audit.yaml",
    steps: [
      { id: "crawl", model: "sonnet", depends_on: [] },
      { id: "analyze-technical", model: "sonnet", depends_on: ["crawl"] },
      { id: "recommendations", model: "haiku", depends_on: ["analyze-technical"] },
    ],
  },
];

const MOCK_SCHEDULES = [
  { id: "sch-001", workflow_name: "competitor-monitor", cron_expression: "0 */6 * * *", enabled: true, last_run_id: "a1b2c3d4-6666-4000-8000-000000000006", created_at: h(168) },
  { id: "sch-002", workflow_name: "lead-enrichment", cron_expression: "0 8 * * 1-5", enabled: true, last_run_id: "a1b2c3d4-1111-4000-8000-000000000001", created_at: h(240) },
  { id: "sch-003", workflow_name: "seo-audit", cron_expression: "0 0 * * 0", enabled: false, last_run_id: null, created_at: h(48) },
];

const MOCK_API_KEYS = [
  { id: "key-001", key_prefix: "sc_live_abc1", tenant_id: "acme-corp", name: "Production API", created_at: h(720), last_used_at: h(0.3) },
  { id: "key-002", key_prefix: "sc_live_def2", tenant_id: "acme-corp", name: "Staging API", created_at: h(480), last_used_at: h(12) },
  { id: "key-003", key_prefix: "sc_test_ghi3", tenant_id: "beta-inc", name: "Development", created_at: h(168), last_used_at: null },
];

const MOCK_DLQ = [
  { id: "dlq-001", run_id: "a1b2c3d4-4444-4000-8000-000000000004", step_id: "enrich", error: "Timeout after 300s - external API unreachable", attempts: 3, created_at: h(5), resolved_at: null, resolved_by: null },
  { id: "dlq-002", run_id: "a1b2c3d4-9999-4000-8000-000000000009", step_id: "analyze", error: "Rate limit exceeded (429) - retry after 60s", attempts: 3, created_at: h(30), resolved_at: null, resolved_by: null },
];

const MOCK_APPROVALS = [
  {
    id: "apr-001",
    run_id: "a1b2c3d4-1111-4000-8000-000000000001",
    step_id: "review-report",
    status: "pending",
    message: "Review the Q4 competitor analysis report before sending to client",
    request_data: {
      report_title: "Q4 Competitor Analysis - Acme Corp",
      sections: ["Market Overview", "Pricing Changes", "Feature Comparison", "Recommendations"],
      generated_at: "2026-02-16T10:30:00Z",
      confidence_score: 0.92,
    },
    reviewer_comment: null,
    timeout_at: new Date(now.getTime() + 24 * 3600000).toISOString(),
    on_timeout: "abort",
    allow_edit: true,
    created_at: h(0.5),
    resolved_at: null,
  },
  {
    id: "apr-002",
    run_id: "a1b2c3d4-2222-4000-8000-000000000002",
    step_id: "approve-outreach",
    status: "pending",
    message: "Approve email outreach to 15 high-priority leads",
    request_data: {
      lead_count: 15,
      avg_score: 87,
      estimated_cost: "$0.45",
      template: "enterprise-intro-v2",
    },
    reviewer_comment: null,
    timeout_at: new Date(now.getTime() + 12 * 3600000).toISOString(),
    on_timeout: "skip",
    allow_edit: false,
    created_at: h(1.2),
    resolved_at: null,
  },
  {
    id: "apr-003",
    run_id: "a1b2c3d4-5555-4000-8000-000000000005",
    step_id: "validate-data",
    status: "approved",
    message: "Validate enriched company data before storage",
    request_data: {
      companies_enriched: 42,
      data_quality_score: 0.95,
      missing_fields: ["revenue"],
    },
    reviewer_comment: "Looks good, minor missing fields are acceptable",
    timeout_at: null,
    on_timeout: "abort",
    allow_edit: true,
    created_at: h(6),
    resolved_at: h(5.5),
  },
  {
    id: "apr-004",
    run_id: "a1b2c3d4-8888-4000-8000-000000000008",
    step_id: "publish-report",
    status: "rejected",
    message: "Publish SEO audit report to client portal",
    request_data: {
      report_pages: 12,
      critical_issues: 3,
      client: "TechStart Inc",
    },
    reviewer_comment: "Report contains outdated data, needs re-run with fresh crawl",
    timeout_at: null,
    on_timeout: "abort",
    allow_edit: false,
    created_at: h(26),
    resolved_at: h(25),
  },
  {
    id: "apr-005",
    run_id: "a1b2c3d4-6666-4000-8000-000000000006",
    step_id: "deploy-changes",
    status: "skipped",
    message: "Deploy pricing page changes to staging",
    request_data: null,
    reviewer_comment: null,
    timeout_at: null,
    on_timeout: "skip",
    allow_edit: false,
    created_at: h(48),
    resolved_at: h(47),
  },
];

const MOCK_AUTOPILOT_EXPERIMENTS = [
  {
    id: "exp-001",
    workflow_name: "lead-enrichment",
    step_id: "enrich",
    status: "active",
    optimize_for: "quality",
    config: { min_samples: 20, auto_deploy: true, sample_rate: 1.0 },
    deployed_variant_id: null,
    created_at: h(72),
    completed_at: null,
    samples: [
      { id: "s-001", variant_id: "baseline", quality_score: 7.2, cost_usd: 0.05, duration_seconds: 18.7 },
      { id: "s-002", variant_id: "baseline", quality_score: 6.8, cost_usd: 0.04, duration_seconds: 16.2 },
      { id: "s-003", variant_id: "baseline", quality_score: 7.5, cost_usd: 0.05, duration_seconds: 19.1 },
      { id: "s-004", variant_id: "baseline", quality_score: 7.1, cost_usd: 0.05, duration_seconds: 17.8 },
      { id: "s-005", variant_id: "baseline", quality_score: 6.9, cost_usd: 0.04, duration_seconds: 15.9 },
      { id: "s-006", variant_id: "opus-deep", quality_score: 9.1, cost_usd: 0.12, duration_seconds: 32.4 },
      { id: "s-007", variant_id: "opus-deep", quality_score: 8.8, cost_usd: 0.11, duration_seconds: 28.6 },
      { id: "s-008", variant_id: "opus-deep", quality_score: 9.3, cost_usd: 0.13, duration_seconds: 35.1 },
      { id: "s-009", variant_id: "opus-deep", quality_score: 8.9, cost_usd: 0.11, duration_seconds: 30.2 },
      { id: "s-010", variant_id: "haiku-fast", quality_score: 5.4, cost_usd: 0.01, duration_seconds: 4.2 },
      { id: "s-011", variant_id: "haiku-fast", quality_score: 5.8, cost_usd: 0.01, duration_seconds: 3.9 },
      { id: "s-012", variant_id: "haiku-fast", quality_score: 5.1, cost_usd: 0.01, duration_seconds: 4.5 },
      { id: "s-013", variant_id: "haiku-fast", quality_score: 5.6, cost_usd: 0.01, duration_seconds: 4.1 },
    ],
  },
  {
    id: "exp-002",
    workflow_name: "competitor-monitor",
    step_id: "analyze",
    status: "completed",
    optimize_for: "pareto",
    config: { min_samples: 15, auto_deploy: true, quality_threshold: 7.0 },
    deployed_variant_id: "balanced",
    created_at: h(168),
    completed_at: h(48),
    samples: [
      { id: "s-020", variant_id: "baseline", quality_score: 7.0, cost_usd: 0.05, duration_seconds: 20.1 },
      { id: "s-021", variant_id: "baseline", quality_score: 7.2, cost_usd: 0.05, duration_seconds: 19.3 },
      { id: "s-022", variant_id: "baseline", quality_score: 6.8, cost_usd: 0.04, duration_seconds: 18.7 },
      { id: "s-023", variant_id: "baseline", quality_score: 7.1, cost_usd: 0.05, duration_seconds: 21.0 },
      { id: "s-024", variant_id: "baseline", quality_score: 7.3, cost_usd: 0.05, duration_seconds: 19.8 },
      { id: "s-025", variant_id: "balanced", quality_score: 8.1, cost_usd: 0.03, duration_seconds: 12.4 },
      { id: "s-026", variant_id: "balanced", quality_score: 8.4, cost_usd: 0.03, duration_seconds: 11.8 },
      { id: "s-027", variant_id: "balanced", quality_score: 7.9, cost_usd: 0.03, duration_seconds: 13.1 },
      { id: "s-028", variant_id: "balanced", quality_score: 8.2, cost_usd: 0.03, duration_seconds: 12.0 },
      { id: "s-029", variant_id: "balanced", quality_score: 8.0, cost_usd: 0.03, duration_seconds: 12.7 },
      { id: "s-030", variant_id: "thorough", quality_score: 9.0, cost_usd: 0.09, duration_seconds: 28.3 },
      { id: "s-031", variant_id: "thorough", quality_score: 8.7, cost_usd: 0.08, duration_seconds: 26.1 },
      { id: "s-032", variant_id: "thorough", quality_score: 9.2, cost_usd: 0.10, duration_seconds: 30.5 },
      { id: "s-033", variant_id: "thorough", quality_score: 8.9, cost_usd: 0.09, duration_seconds: 27.8 },
      { id: "s-034", variant_id: "thorough", quality_score: 9.1, cost_usd: 0.09, duration_seconds: 29.0 },
    ],
  },
  {
    id: "exp-003",
    workflow_name: "seo-audit",
    step_id: "recommendations",
    status: "active",
    optimize_for: "cost",
    config: { min_samples: 10, auto_deploy: false, sample_rate: 0.5 },
    deployed_variant_id: null,
    created_at: h(24),
    completed_at: null,
    samples: [
      { id: "s-040", variant_id: "sonnet", quality_score: 7.8, cost_usd: 0.04, duration_seconds: 14.2 },
      { id: "s-041", variant_id: "sonnet", quality_score: 8.0, cost_usd: 0.04, duration_seconds: 15.1 },
      { id: "s-042", variant_id: "haiku", quality_score: 6.5, cost_usd: 0.008, duration_seconds: 3.8 },
      { id: "s-043", variant_id: "haiku", quality_score: 6.2, cost_usd: 0.007, duration_seconds: 3.5 },
    ],
  },
];

const MOCK_AUTOPILOT_STATS = {
  total_experiments: 3,
  active_experiments: 2,
  completed_experiments: 1,
  total_samples: 32,
  avg_quality_improvement: 0.18,
  total_cost_savings_usd: 1.24,
};

const MOCK_VIOLATIONS = [
  {
    id: "vio-001",
    run_id: "a1b2c3d4-1111-4000-8000-000000000001",
    step_id: "enrich",
    policy_id: "pii-redact",
    severity: "critical",
    action_taken: "redacted",
    trigger_details: "PII detected in output: email address john.doe@example.com and SSN 123-45-6789 found in enrichment response. Content was automatically redacted before passing to next step.",
    output_modified: true,
    created_at: h(1),
  },
  {
    id: "vio-002",
    run_id: "a1b2c3d4-2222-4000-8000-000000000002",
    step_id: "analyze",
    policy_id: "cost-guard",
    severity: "high",
    action_taken: "blocked",
    trigger_details: "Step cost $0.18 exceeds per-step budget limit of $0.10. Execution blocked to prevent budget overrun.",
    output_modified: false,
    created_at: h(3),
  },
  {
    id: "vio-003",
    run_id: "a1b2c3d4-3333-4000-8000-000000000003",
    step_id: "score",
    policy_id: "secret-block",
    severity: "critical",
    action_taken: "blocked",
    trigger_details: "Potential API key detected in prompt: sk-proj-abc...xyz. Step execution blocked. Remove secrets from workflow input before retrying.",
    output_modified: false,
    created_at: h(6),
  },
  {
    id: "vio-004",
    run_id: "a1b2c3d4-5555-4000-8000-000000000005",
    step_id: "enrich",
    policy_id: "pii-redact",
    severity: "medium",
    action_taken: "redacted",
    trigger_details: "Phone number +1-555-0123 detected in output field 'contact_info'. Number was replaced with [REDACTED].",
    output_modified: true,
    created_at: h(12),
  },
  {
    id: "vio-005",
    run_id: "a1b2c3d4-6666-4000-8000-000000000006",
    step_id: "summarize",
    policy_id: "length-limit",
    severity: "low",
    action_taken: "flagged",
    trigger_details: "Output length 4,200 tokens exceeds soft limit of 4,000 tokens. Flagged for review but execution continued.",
    output_modified: false,
    created_at: h(24),
  },
  {
    id: "vio-006",
    run_id: "a1b2c3d4-8888-4000-8000-000000000008",
    step_id: "analyze",
    policy_id: "cost-guard",
    severity: "high",
    action_taken: "blocked",
    trigger_details: "Cumulative run cost $0.42 exceeds max_cost_usd budget of $0.30. Remaining steps skipped.",
    output_modified: false,
    created_at: h(36),
  },
];

const MOCK_VIOLATION_STATS = {
  total_violations_30d: 23,
  violations_by_severity: { critical: 2, high: 8, medium: 10, low: 3 },
  violations_by_policy: { "pii-redact": 12, "cost-guard": 6, "secret-block": 3, "length-limit": 2 },
  violations_by_day: Array.from({ length: 30 }, (_, i) => ({
    date: d(29 - i),
    count: Math.floor(Math.random() * 4),
  })),
};

const MOCK_OPTIMIZER_DECISIONS = [
  {
    id: "opt-001",
    run_id: "a1b2c3d4-1111-4000-8000-000000000001",
    step_id: "enrich",
    selected_model: "sonnet",
    confidence: 0.92,
    reason: "High complexity step with structured output requirements. Sonnet provides best quality-cost ratio for data enrichment tasks.",
    budget_pressure: 0.3,
    alternatives: [
      { id: "sonnet-v1", model: "sonnet", avg_quality: 0.92, avg_cost: 0.08 },
      { id: "haiku-v1", model: "haiku", avg_quality: 0.61, avg_cost: 0.02 },
      { id: "opus-v1", model: "opus", avg_quality: 0.88, avg_cost: 0.15 },
    ],
    slo: { quality_min: 0.7, cost_max_usd: 0.10, latency_max_seconds: 30, optimize_for: "balanced" },
    created_at: h(0.5),
  },
  {
    id: "opt-002",
    run_id: "a1b2c3d4-2222-4000-8000-000000000002",
    step_id: "fetch-competitors",
    selected_model: "haiku",
    confidence: 0.88,
    reason: "Simple data retrieval step. Haiku sufficient for structured extraction with minimal reasoning.",
    budget_pressure: 0.1,
    alternatives: [
      { id: "haiku-v1", model: "haiku", avg_quality: 0.88, avg_cost: 0.02 },
      { id: "sonnet-v1", model: "sonnet", avg_quality: 0.72, avg_cost: 0.08 },
    ],
    slo: { quality_min: 0.5, cost_max_usd: 0.05, latency_max_seconds: 15, optimize_for: "cost" },
    created_at: h(2),
  },
  {
    id: "opt-003",
    run_id: "a1b2c3d4-3333-4000-8000-000000000003",
    step_id: "recommendations",
    selected_model: "opus",
    confidence: 0.45,
    reason: "Complex reasoning required for actionable SEO recommendations. Low confidence due to limited historical data for this step type.",
    budget_pressure: 0.92,
    alternatives: [
      { id: "opus-v1", model: "opus", avg_quality: 0.45, avg_cost: 0.15 },
      { id: "sonnet-v1", model: "sonnet", avg_quality: 0.42, avg_cost: 0.08 },
      { id: "haiku-v1", model: "haiku", avg_quality: 0.18, avg_cost: 0.02 },
    ],
    slo: { quality_min: 0.8, cost_max_usd: 0.20, latency_max_seconds: 60, optimize_for: "quality" },
    created_at: h(5),
  },
  {
    id: "opt-004",
    run_id: "a1b2c3d4-5555-4000-8000-000000000005",
    step_id: "score",
    selected_model: "haiku",
    confidence: 0.78,
    reason: "Lead scoring uses a fixed rubric. Haiku handles structured scoring well within quality SLO.",
    budget_pressure: null,
    alternatives: [
      { id: "haiku-v1", model: "haiku", avg_quality: 0.78, avg_cost: 0.02 },
      { id: "sonnet-v1", model: "sonnet", avg_quality: 0.65, avg_cost: 0.08 },
    ],
    slo: { quality_min: 0.6, cost_max_usd: 0.03, latency_max_seconds: 10, optimize_for: "cost" },
    created_at: h(8),
  },
  {
    id: "opt-005",
    run_id: "a1b2c3d4-6666-4000-8000-000000000006",
    step_id: "analyze",
    selected_model: "sonnet",
    confidence: 0.85,
    reason: "Competitor analysis requires nuanced comparison. Sonnet selected as best balance under current budget pressure.",
    budget_pressure: 0.75,
    alternatives: [
      { id: "sonnet-v1", model: "sonnet", avg_quality: 0.85, avg_cost: 0.08 },
      { id: "opus-v1", model: "opus", avg_quality: 0.82, avg_cost: 0.15 },
      { id: "haiku-v1", model: "haiku", avg_quality: 0.39, avg_cost: 0.02 },
    ],
    slo: { quality_min: 0.7, cost_max_usd: 0.08, latency_max_seconds: 45, optimize_for: "balanced" },
    created_at: h(12),
  },
];

const MOCK_OPTIMIZER_STATS = {
  total_decisions_30d: 156,
  model_distribution: { haiku: 0.45, sonnet: 0.40, opus: 0.15 },
  avg_confidence: 0.72,
  estimated_savings_30d_usd: 3.45,
};

const MOCK_TEMPLATES = [
  {
    name: "summarize",
    description: "Summarize text input with configurable detail level",
    tags: ["NLP", "Text"],
    step_count: 2,
  },
  {
    name: "translate",
    description: "Detect language and translate to target language",
    tags: ["NLP", "Translation"],
    step_count: 2,
  },
  {
    name: "research_agent",
    description: "Multi-source research with parallel analysis and fact extraction",
    tags: ["Research", "Multi-agent"],
    step_count: 4,
  },
  {
    name: "chain_of_thought",
    description: "Step-by-step reasoning through complex problems",
    tags: ["Reasoning", "Chain"],
    step_count: 3,
  },
  {
    name: "review_and_approve",
    description: "Content generation with human approval gate before publishing",
    tags: ["Human-in-loop", "Content"],
    step_count: 3,
  },
  {
    name: "blog_to_social",
    description: "Transform a blog post into platform-specific social media content",
    tags: ["Marketing", "Content", "Social"],
    step_count: 5,
  },
  {
    name: "seo_content",
    description: "Research keywords and create SEO-optimized article with meta tags",
    tags: ["Marketing", "SEO", "Content"],
    step_count: 4,
  },
  {
    name: "email_campaign",
    description: "Generate email campaign with subject line variants and A/B copy",
    tags: ["Marketing", "Email", "Campaign"],
    step_count: 5,
  },
  {
    name: "competitor_analysis",
    description: "Analyze competitor positioning, strengths, weaknesses, and opportunities",
    tags: ["Marketing", "Strategy", "Research"],
    step_count: 4,
  },
  {
    name: "ad_copy_generator",
    description: "Generate ad copy variants for Google Ads and Meta Ads campaigns",
    tags: ["Marketing", "Advertising", "Copywriting"],
    step_count: 4,
  },
  {
    name: "lead_enrichment",
    description: "Research and enrich lead data with company info, scoring, and outreach angles",
    tags: ["Sales", "Research", "Lead-Gen"],
    step_count: 5,
  },
  {
    name: "proposal_generator",
    description: "Generate a customized business proposal from meeting notes and product info",
    tags: ["Sales", "Document", "Proposal"],
    step_count: 4,
  },
  {
    name: "meeting_recap",
    description: "Transform meeting transcript into summary, action items, and follow-up email",
    tags: ["Sales", "Productivity", "Communication"],
    step_count: 3,
  },
  {
    name: "ticket_classifier",
    description: "Classify support ticket, assign priority, and draft response",
    tags: ["Support", "Classification", "Automation"],
    step_count: 4,
  },
  {
    name: "review_sentiment",
    description: "Analyze customer reviews to extract sentiment trends and actionable insights",
    tags: ["Support", "Analytics", "Sentiment"],
    step_count: 4,
  },
  {
    name: "job_description",
    description: "Generate inclusive job description with requirements, benefits, and interview plan",
    tags: ["HR", "Recruiting", "Content"],
    step_count: 4,
  },
  {
    name: "resume_screener",
    description: "Screen resume against job description with match scoring and interview recommendations",
    tags: ["HR", "Recruiting", "Screening"],
    step_count: 4,
  },
  {
    name: "contract_review",
    description: "Review contract for key terms, risks, and generate plain-language summary",
    tags: ["Legal", "Compliance", "Document"],
    step_count: 4,
  },
  {
    name: "release_notes",
    description: "Generate user-facing release notes and internal changelog from commit history",
    tags: ["Product", "Engineering", "Documentation"],
    step_count: 4,
  },
  {
    name: "data_extractor",
    description: "Extract structured data from documents with validation and error handling",
    tags: ["Product", "Data", "Automation"],
    step_count: 4,
  },
];

const TEMPLATE_YAMLS: Record<string, string> = {
  summarize: `name: "summarize"
description: "Summarize text input with configurable detail level"
sandstorm_url: "\${SANDSTORM_URL}"
default_model: sonnet
default_max_turns: 10
default_timeout: 300

steps:
  - id: "extract"
    prompt: |
      Extract the key points from the following text.
      Focus on the main arguments and supporting evidence.
      Input: {input.text}
    model: haiku

  - id: "summarize"
    prompt: |
      Write a concise summary based on these key points.
      Detail level: {input.detail_level}
      Key points: {steps.extract.output}
    model: sonnet
    depends_on:
      - "extract"
`,
  translate: `name: "translate"
description: "Detect language and translate to target language"
sandstorm_url: "\${SANDSTORM_URL}"
default_model: sonnet
default_max_turns: 10
default_timeout: 300

steps:
  - id: "detect_language"
    prompt: |
      Detect the language of the following text and return the language code.
      Text: {input.text}
    model: haiku

  - id: "translate"
    prompt: |
      Translate the following text to {input.target_language}.
      Source language: {steps.detect_language.output}
      Text: {input.text}
    model: sonnet
    depends_on:
      - "detect_language"
`,
  research_agent: `name: "research_agent"
description: "Multi-source research with parallel analysis and fact extraction"
sandstorm_url: "\${SANDSTORM_URL}"
default_model: sonnet
default_max_turns: 10
default_timeout: 300

steps:
  - id: "plan"
    prompt: |
      Create a research plan for the topic: {input.topic}
      Identify 3-5 angles to investigate and list them as JSON array.
    model: sonnet

  - id: "research"
    prompt: |
      Research the following angle in depth.
      Topic: {input.topic}
      Angle: {item}
      Return key findings with sources.
    model: sonnet
    depends_on:
      - "plan"
    parallel_over: "steps.plan.output"

  - id: "extract_facts"
    prompt: |
      Extract verified facts from all research findings.
      Findings: {steps.research.output}
      Return a structured list of facts with confidence scores.
    model: sonnet
    depends_on:
      - "research"

  - id: "synthesize"
    prompt: |
      Synthesize the research into a comprehensive report.
      Facts: {steps.extract_facts.output}
      Include an executive summary, detailed findings, and recommendations.
    model: opus
    depends_on:
      - "extract_facts"
`,
  chain_of_thought: `name: "chain_of_thought"
description: "Step-by-step reasoning through complex problems"
sandstorm_url: "\${SANDSTORM_URL}"
default_model: sonnet
default_max_turns: 10
default_timeout: 300

steps:
  - id: "decompose"
    prompt: |
      Break down this problem into logical sub-problems.
      Problem: {input.problem}
      Return a numbered list of sub-problems to solve in order.
    model: sonnet

  - id: "reason"
    prompt: |
      Solve each sub-problem step by step.
      Sub-problems: {steps.decompose.output}
      Show your reasoning for each step.
    model: opus

  - id: "conclude"
    prompt: |
      Based on the step-by-step reasoning, provide the final answer.
      Reasoning: {steps.reason.output}
      Original problem: {input.problem}
      Verify the answer is consistent with all reasoning steps.
    model: sonnet
    depends_on:
      - "reason"
`,
  review_and_approve: `name: "review_and_approve"
description: "Content generation with human approval gate before publishing"
sandstorm_url: "\${SANDSTORM_URL}"
default_model: sonnet
default_max_turns: 10
default_timeout: 300

steps:
  - id: "generate"
    prompt: |
      Generate content based on the following brief.
      Brief: {input.brief}
      Tone: {input.tone}
      Target audience: {input.audience}
    model: sonnet

  - id: "review"
    type: approval
    approval_config:
      message: "Review the generated content before publishing"
      timeout_hours: 24
      on_timeout: abort
      allow_edit: true
    depends_on:
      - "generate"

  - id: "publish"
    prompt: |
      Format the approved content for publishing.
      Content: {steps.generate.output}
      Format: {input.output_format}
    model: haiku
    depends_on:
      - "review"
`,
};

function getTemplateDetail(name: string) {
  const template = MOCK_TEMPLATES.find((t) => t.name === name);
  if (!template) return null;
  return {
    ...template,
    file_name: `${name}.yaml`,
    content: TEMPLATE_YAMLS[name] || `name: "${name}"\nsteps: []`,
  };
}

const MOCK_SETTINGS = {
  sandstorm_url: "http://localhost:8080",
  anthropic_api_key: "****Qf8x",
  e2b_api_key: "****mN2k",
  auth_required: true,
  dashboard_origin: "http://localhost:5173",
  default_max_cost_usd: 5.0,
  webhook_secret: "****tR9w",
  log_level: "info",
  max_workflow_depth: 10,
  storage_backend: "local",
  storage_bucket: "",
  storage_endpoint: "",
  data_dir: "./data",
  workflows_dir: "./workflows",
  is_local_mode: true,
  database_url: "sqlite+aiosqlite:///./data/sandcastle.db",
  redis_url: "",
};

// Route matcher
type MockRoute = {
  match: RegExp;
  method?: string;
  handler: (params: Record<string, string>, body?: unknown) => unknown;
};

const routes: MockRoute[] = [
  {
    match: /^\/health$/,
    handler: () => ({ status: "ok", sandstorm: true, redis: null, database: true }),
  },
  {
    match: /^\/runtime$/,
    handler: () => ({ mode: "local", database: "sqlite", queue: "in-process", storage: "local", data_dir: "./data" }),
  },
  {
    match: /^\/stats$/,
    handler: () => MOCK_STATS,
  },
  {
    match: /^\/workflows$/,
    method: "GET",
    handler: () => MOCK_WORKFLOWS,
  },
  {
    match: /^\/runs$/,
    handler: (_params) => {
      const status = _params.status;
      let filtered = MOCK_RUNS;
      if (status && status !== "all") {
        filtered = filtered.filter((r) => r.status === status);
      }
      const offset = Number(_params.offset || 0);
      const limit = Number(_params.limit || 20);
      return {
        _data: filtered.slice(offset, offset + limit),
        _meta: { total: filtered.length, limit, offset },
      };
    },
  },
  {
    match: /^\/runs\/([^/]+)$/,
    handler: (params) => getRunDetail(params._1),
  },
  {
    match: /^\/schedules$/,
    method: "GET",
    handler: () => ({
      _data: MOCK_SCHEDULES,
      _meta: { total: MOCK_SCHEDULES.length, limit: 50, offset: 0 },
    }),
  },
  {
    match: /^\/dead-letter$/,
    handler: () => ({
      _data: MOCK_DLQ,
      _meta: { total: MOCK_DLQ.length, limit: 50, offset: 0 },
    }),
  },
  {
    match: /^\/approvals$/,
    handler: (params) => {
      let filtered = MOCK_APPROVALS;
      if (params.status && params.status !== "all") {
        filtered = filtered.filter((a) => a.status === params.status);
      }
      return filtered;
    },
  },
  {
    match: /^\/autopilot\/experiments$/,
    handler: () => MOCK_AUTOPILOT_EXPERIMENTS,
  },
  {
    match: /^\/autopilot\/stats$/,
    handler: () => MOCK_AUTOPILOT_STATS,
  },
  {
    match: /^\/violations$/,
    handler: (params) => {
      let filtered = MOCK_VIOLATIONS;
      if (params.severity && params.severity !== "all") {
        filtered = filtered.filter((v) => v.severity === params.severity);
      }
      return filtered;
    },
  },
  {
    match: /^\/violations\/stats$/,
    handler: () => MOCK_VIOLATION_STATS,
  },
  {
    match: /^\/optimizer\/decisions$/,
    handler: () => MOCK_OPTIMIZER_DECISIONS,
  },
  {
    match: /^\/optimizer\/stats$/,
    handler: () => MOCK_OPTIMIZER_STATS,
  },
  {
    match: /^\/templates$/,
    method: "GET",
    handler: () => MOCK_TEMPLATES,
  },
  {
    match: /^\/templates\/([^/]+)$/,
    method: "GET",
    handler: (params) => getTemplateDetail(params._1),
  },
  {
    match: /^\/settings$/,
    method: "GET",
    handler: () => ({ ...MOCK_SETTINGS }),
  },
  {
    match: /^\/settings$/,
    method: "PATCH",
    handler: (_params, body) => {
      const updates = body as Record<string, unknown> | undefined;
      if (updates) {
        Object.assign(MOCK_SETTINGS, updates);
      }
      return { ...MOCK_SETTINGS };
    },
  },
  {
    match: /^\/api-keys$/,
    method: "GET",
    handler: () => MOCK_API_KEYS,
  },
  {
    match: /^\/api-keys$/,
    method: "POST",
    handler: (_params, body) => {
      const b = body as { name?: string; tenant_id?: string } | undefined;
      return {
        id: `key-${Date.now()}`,
        key: `sc_live_${Math.random().toString(36).slice(2, 14)}${Math.random().toString(36).slice(2, 14)}`,
        key_prefix: `sc_live_${Math.random().toString(36).slice(2, 6)}`,
        tenant_id: b?.tenant_id || "default",
        name: b?.name || "Untitled",
        created_at: new Date().toISOString(),
        last_used_at: null,
      };
    },
  },
];

export function mockFetch(
  path: string,
  params?: Record<string, string>,
  method?: string,
  body?: unknown
): ApiResponse {
  const mergedParams = params || {};
  const reqMethod = (method || "GET").toUpperCase();

  for (const route of routes) {
    const m = path.match(route.match);
    if (!m) continue;
    // Check method if specified on route
    if (route.method && route.method.toUpperCase() !== reqMethod) continue;

    const extractedParams: Record<string, string> = { ...mergedParams };
    m.slice(1).forEach((val, i) => {
      extractedParams[`_${i + 1}`] = val;
    });

    const result = route.handler(extractedParams, body);

    // Handle routes that return _data/_meta separately
    if (result && typeof result === "object" && "_data" in (result as Record<string, unknown>)) {
      const r = result as { _data: unknown; _meta: unknown };
      return { data: r._data, error: null, meta: r._meta as ApiResponse["meta"] };
    }

    return { data: result, error: null };
  }

  return { data: null, error: { code: "NOT_FOUND", message: `Mock: ${path} not found` } };
}
