import{x as r}from"./index-kwdSk9ma.js";var a=r();export{a as r};
