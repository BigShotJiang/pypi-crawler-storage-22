"""Application configuration loaded from environment variables."""

from pydantic import computed_field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Sandcastle configuration."""

    # Sandstorm connection
    sandstorm_url: str = "http://localhost:3001"
    anthropic_api_key: str = ""
    e2b_api_key: str = ""

    # Database (empty = local SQLite mode)
    database_url: str = ""

    # Redis (empty = in-process queue)
    redis_url: str = ""

    # Storage
    storage_backend: str = "local"  # "s3" or "local"
    storage_bucket: str = "sandcastle-data"
    storage_endpoint: str = "http://localhost:9000"
    aws_access_key_id: str = "minioadmin"
    aws_secret_access_key: str = "minioadmin"

    # Local mode data directory
    data_dir: str = "./data"

    # Webhooks
    webhook_secret: str = "your-webhook-signing-secret"

    # Auth
    auth_required: bool = False  # Set to True to enforce API key auth
    dashboard_origin: str = "http://localhost:5173"

    # Budget
    default_max_cost_usd: float = 0.0  # 0 = no limit

    # Workflows directory
    workflows_dir: str = "./workflows"

    # Hierarchical workflows
    max_workflow_depth: int = 5

    # Logging
    log_level: str = "info"

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

    @computed_field
    @property
    def is_local_mode(self) -> bool:
        """True when running in local mode (SQLite + filesystem + in-process queue)."""
        return not self.database_url or self.database_url.startswith("sqlite")


settings = Settings()
