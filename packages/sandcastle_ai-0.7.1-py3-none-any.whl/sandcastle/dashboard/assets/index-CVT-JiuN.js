import{x as r}from"./index-BDLnSg9O.js";var a=r();export{a as r};
