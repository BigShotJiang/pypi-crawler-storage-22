# Publishing SandStrike to PyPI

SandStrike is a **Python** package. Users install it with **pip** (from PyPI), not npm:

```bash
pip install sandstrike
```

**npm** is for JavaScript/Node packages. This guide covers publishing to **PyPI** (Python Package Index).

---

## Prerequisites

1. **PyPI account** (free): https://pypi.org/account/register/
2. **Test PyPI account** (optional, for dry runs): https://test.pypi.org/account/register/
3. **Python 3.8+** with `pip` and `build`, `twine` installed

---

## One-time setup

### 1. Install build tools

```bash
pip install build twine
```

### 2. Create API tokens (recommended over password)

- **PyPI (production):** https://pypi.org/manage/account/token/
- **Test PyPI (testing only):** https://test.pypi.org/manage/account/token/

**Important:** PyPI and Test PyPI use **different accounts and different tokens**. A token from pypi.org will not work on test.pypi.org and vice versa.

When creating the token on PyPI:
- Use scope **“Entire account”** for your first upload (or create a **new project** first, then use “Project: sandstrike”).
- If the project “sandstrike” doesn’t exist yet, a project-scoped token for “sandstrike” may still work when you upload the first time (PyPI creates the project). If you get 403, try an “Entire account” token.
- Copy the token immediately; it starts with `pypi-` and is shown only once.

---

## Build and publish

### 1. Bump version (if needed)

Edit `pyproject.toml` and update:

```toml
version = "1.0.1"   # or your next version
```

### 2. Clean and build

From the **repository root** (where `pyproject.toml` is):

```bash
# Remove old build artifacts
rmdir /s /q dist 2>nul
# or on macOS/Linux: rm -rf dist

# Build source distribution and wheel
python -m build
```

This creates `dist/sandstrike-<version>.tar.gz` and `dist/sandstrike-<version>-py3-none-any.whl`.

### 3. Check the package (optional)

```bash
twine check dist/*
```

### 4. Upload to Test PyPI (recommended first time)

Use a token from **test.pypi.org** (not pypi.org):

```bash
twine upload --repository testpypi dist/*
```

Twine may prompt only once for a “password”. For token auth you must give **both**:

- **Username:** type exactly `__token__` (two underscores each side)
- **Password:** your **full** API token (e.g. `pypi-AgEIcHlwaS...`), no spaces

To avoid prompts, set both and then run the command:

**Windows (PowerShell):**

```powershell
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = "your-test-pypi-token-here"
twine upload --repository testpypi dist/*
```

**macOS / Linux:**

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=your-test-pypi-token-here
twine upload --repository testpypi dist/*
```

Then try installing from Test PyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ sandstrike
```

### 5. Upload to real PyPI

When you’re ready for production, use a token from **pypi.org** (not Test PyPI):

```bash
twine upload dist/*
```

- **Username:** exactly `__token__`
- **Password:** your **full** PyPI API token (starts with `pypi-`)

---

## After publishing

- Package page: `https://pypi.org/project/sandstrike/`
- Users install with: `pip install sandstrike`
- CLI: `sandstrike --help` (after install)

---

## Optional: GitHub Actions (automated publish)

To publish automatically on release (e.g. when you push a tag), you can add a workflow that builds and runs `twine upload` using a PyPI token stored as a GitHub secret. See the next section or add a `.github/workflows/publish.yml` that:

1. Triggers on release (or tag push).
2. Checks out repo, sets up Python, runs `python -m build`, then `twine upload` with `TWINE_USERNAME=__token__` and `TWINE_PASSWORD` from secrets.

If you want, I can add a ready-to-use `publish.yml` for this repo.
