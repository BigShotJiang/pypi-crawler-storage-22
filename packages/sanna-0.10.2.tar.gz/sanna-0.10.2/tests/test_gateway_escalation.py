"""Tests for gateway must_escalate UX (Block E).

Tests cover: escalation lifecycle (create, approve, deny), receipt chain,
expiry, meta-tool registration, concurrent escalations, and edge cases.
"""

import asyncio
import json
import sys
import textwrap

import pytest

pytest.importorskip("mcp", reason="mcp extra not installed")

from sanna.gateway.server import (
    SannaGateway,
    EscalationStore,
    PendingEscalation,
    _META_TOOL_APPROVE,
    _META_TOOL_DENY,
)


# =============================================================================
# MOCK SERVER SCRIPT
# =============================================================================

MOCK_SERVER_SCRIPT = textwrap.dedent("""\
    import json
    from mcp.server.fastmcp import FastMCP

    mcp = FastMCP("mock_downstream")

    @mcp.tool()
    def get_status() -> str:
        \"\"\"Get the current server status.\"\"\"
        return json.dumps({"status": "ok", "version": "1.0"})

    @mcp.tool()
    def search(query: str, limit: int = 10) -> str:
        \"\"\"Search for items matching a query.\"\"\"
        return json.dumps({"query": query, "limit": limit, "results": ["a", "b"]})

    @mcp.tool()
    def update_item(item_id: str, name: str) -> str:
        \"\"\"Update an item.\"\"\"
        return json.dumps({"updated": True, "item_id": item_id, "name": name})

    @mcp.tool()
    def delete_item(item_id: str) -> str:
        \"\"\"Delete an item by ID.\"\"\"
        return json.dumps({"deleted": True, "item_id": item_id})

    mcp.run(transport="stdio")
""")


# =============================================================================
# HELPERS
# =============================================================================

def _get_approval_token(gw, escalation_id: str) -> str:
    """Compute the valid approval token for a pending escalation.

    Uses the gateway's internal HMAC computation — mirrors what the
    gateway prints to stderr during escalation creation.
    """
    entry = gw.escalation_store.get(escalation_id)
    assert entry is not None, f"Escalation {escalation_id} not in store"
    return gw._compute_approval_token(entry)


def _create_signed_constitution(
    tmp_path,
    authority_boundaries=None,
):
    """Create a signed constitution and keypair for testing.

    Returns (constitution_path, private_key_path, public_key_path).
    """
    from sanna.crypto import generate_keypair
    from sanna.constitution import (
        Constitution,
        AgentIdentity,
        Provenance,
        Boundary,
        sign_constitution,
        save_constitution,
    )

    keys_dir = tmp_path / "keys"
    private_key_path, public_key_path = generate_keypair(str(keys_dir))

    identity = AgentIdentity(
        agent_name="test-agent",
        domain="testing",
    )
    provenance = Provenance(
        authored_by="test@example.com",
        approved_by=["approver@example.com"],
        approval_date="2024-01-01",
        approval_method="manual-sign-off",
    )
    boundaries = [
        Boundary(
            id="B001",
            description="Test boundary",
            category="scope",
            severity="high",
        ),
    ]

    constitution = Constitution(
        schema_version="0.1.0",
        identity=identity,
        provenance=provenance,
        boundaries=boundaries,
        authority_boundaries=authority_boundaries,
    )

    signed = sign_constitution(
        constitution, private_key_path=str(private_key_path),
    )

    const_path = tmp_path / "constitution.yaml"
    save_constitution(signed, const_path)

    return str(const_path), str(private_key_path), str(public_key_path)


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture()
def mock_server_path(tmp_path):
    """Write the mock server script to a temp file."""
    path = tmp_path / "mock_server.py"
    path.write_text(MOCK_SERVER_SCRIPT)
    return str(path)


@pytest.fixture()
def signed_constitution(tmp_path):
    """Create a signed constitution with must_escalate for update_item."""
    from sanna.constitution import (
        AuthorityBoundaries,
        EscalationRule,
    )

    ab = AuthorityBoundaries(
        cannot_execute=["delete_item"],
        must_escalate=[
            EscalationRule(condition="update"),
        ],
        can_execute=["get_status", "search"],
    )
    return _create_signed_constitution(tmp_path, authority_boundaries=ab)


# =============================================================================
# 1. ESCALATION REQUIRED — CREATING PENDING ESCALATION
# =============================================================================

class TestEscalationRequired:
    def test_escalation_returns_structured_json(
        self, mock_server_path, signed_constitution,
    ):
        """must_escalate tool call returns ESCALATION_REQUIRED with
        escalation_id (not a deny)."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                # Not an error — it's an escalation prompt
                assert result.isError is not True
                data = json.loads(result.content[0].text)
                assert data["status"] == "ESCALATION_REQUIRED"
                assert data["escalation_id"].startswith("esc_")
                assert data["tool"] == "mock_update_item"
                assert data["parameters"] == {"item_id": "1", "name": "new"}
                assert "reason" in data
                assert "instruction" in data
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_escalation_creates_pending_entry(
        self, mock_server_path, signed_constitution,
    ):
        """Escalation adds entry to the escalation store."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                data = json.loads(result.content[0].text)
                esc_id = data["escalation_id"]
                entry = gw.escalation_store.get(esc_id)
                assert entry is not None
                assert entry.original_name == "update_item"
                assert entry.arguments == {"item_id": "1", "name": "new"}
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 2. APPROVE ESCALATION
# =============================================================================

class TestApproveEscalation:
    def test_approve_forwards_to_downstream(
        self, mock_server_path, signed_constitution,
    ):
        """Approve valid escalation → original request forwarded to
        downstream, result returned."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                # Trigger escalation
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "42", "name": "approved-name"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                # Approve it
                approve_result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                assert approve_result.isError is not True
                data = json.loads(approve_result.content[0].text)
                assert data["updated"] is True
                assert data["item_id"] == "42"
                assert data["name"] == "approved-name"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_approve_receipt_has_chain(
        self, mock_server_path, signed_constitution,
    ):
        """Approve valid escalation → receipt includes full approval chain."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                # Trigger escalation
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                esc_receipt = gw.last_receipt
                esc_receipt_id = esc_receipt["receipt_id"]
                token = _get_approval_token(gw, esc_id)

                # Approve
                await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                approval_receipt = gw.last_receipt

                # Chain fields in extensions
                gw_ext = approval_receipt["extensions"]["gateway"]
                assert gw_ext["escalation_id"] == esc_id
                assert gw_ext["escalation_receipt_id"] == esc_receipt_id
                assert gw_ext["escalation_resolution"] == "approved"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_approve_removes_from_store(
        self, mock_server_path, signed_constitution,
    ):
        """After approval, the escalation is removed from the store."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                assert len(gw.escalation_store) == 1
                token = _get_approval_token(gw, esc_id)

                await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                assert len(gw.escalation_store) == 0
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 3. DENY ESCALATION
# =============================================================================

class TestDenyEscalation:
    def test_deny_generates_halt_receipt(
        self, mock_server_path, signed_constitution,
    ):
        """Deny valid escalation → denial receipt generated with halt_event,
        no downstream call."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                # Trigger escalation
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]

                # Deny
                deny_result = await gw._forward_call(
                    _META_TOOL_DENY,
                    {"escalation_id": esc_id},
                )
                assert deny_result.isError is not True
                deny_data = json.loads(deny_result.content[0].text)
                assert deny_data["status"] == "denied"

                # Receipt has halt_event
                receipt = gw.last_receipt
                assert receipt["halt_event"] is not None
                assert receipt["halt_event"]["halted"] is True
                assert esc_id in receipt["halt_event"]["reason"]
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_deny_receipt_has_chain(
        self, mock_server_path, signed_constitution,
    ):
        """Denial receipt references the original escalation receipt ID."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                esc_receipt_id = gw.last_receipt["receipt_id"]

                await gw._forward_call(
                    _META_TOOL_DENY,
                    {"escalation_id": esc_id},
                )
                deny_receipt = gw.last_receipt
                gw_ext = deny_receipt["extensions"]["gateway"]
                assert gw_ext["escalation_id"] == esc_id
                assert gw_ext["escalation_receipt_id"] == esc_receipt_id
                assert gw_ext["escalation_resolution"] == "denied"
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 4. EXPIRED AND NOT FOUND
# =============================================================================

class TestExpiredAndNotFound:
    def test_approve_nonexistent_returns_not_found(
        self, mock_server_path, signed_constitution,
    ):
        """Approve nonexistent escalation_id → ESCALATION_NOT_FOUND error."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": "esc_does_not_exist"},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "ESCALATION_NOT_FOUND"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_deny_nonexistent_returns_not_found(
        self, mock_server_path, signed_constitution,
    ):
        """Deny nonexistent escalation_id → ESCALATION_NOT_FOUND error."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                result = await gw._forward_call(
                    _META_TOOL_DENY,
                    {"escalation_id": "esc_does_not_exist"},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "ESCALATION_NOT_FOUND"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_approve_expired_returns_expired(
        self, mock_server_path, signed_constitution,
    ):
        """Approve expired escalation → ESCALATION_EXPIRED error."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
                escalation_timeout=1,  # 1 second
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]

                # Wait for expiry
                await asyncio.sleep(1.2)

                result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "ESCALATION_EXPIRED"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_deny_expired_returns_expired(
        self, mock_server_path, signed_constitution,
    ):
        """Deny expired escalation → ESCALATION_EXPIRED error."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
                escalation_timeout=1,  # 1 second
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]

                await asyncio.sleep(1.2)

                result = await gw._forward_call(
                    _META_TOOL_DENY,
                    {"escalation_id": esc_id},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "ESCALATION_EXPIRED"
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 5. RECEIPT VERIFICATION
# =============================================================================

class TestReceiptVerification:
    def test_escalation_receipt_verifies_offline(
        self, mock_server_path, signed_constitution,
    ):
        """Escalation receipt fingerprint passes offline verification."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            from sanna.verify import verify_fingerprint

            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                r = gw.last_receipt
                matches, computed, expected = verify_fingerprint(r)
                assert matches, (
                    f"Escalation receipt fingerprint mismatch: "
                    f"computed={computed}, expected={expected}"
                )
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_approval_receipt_verifies_offline(
        self, mock_server_path, signed_constitution,
    ):
        """Approval receipt fingerprint passes offline verification."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            from sanna.verify import verify_fingerprint

            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                r = gw.last_receipt
                matches, computed, expected = verify_fingerprint(r)
                assert matches, (
                    f"Approval receipt fingerprint mismatch: "
                    f"computed={computed}, expected={expected}"
                )
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_denial_receipt_verifies_offline(
        self, mock_server_path, signed_constitution,
    ):
        """Denial receipt fingerprint passes offline verification."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            from sanna.verify import verify_fingerprint

            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]

                await gw._forward_call(
                    _META_TOOL_DENY,
                    {"escalation_id": esc_id},
                )
                r = gw.last_receipt
                matches, computed, expected = verify_fingerprint(r)
                assert matches, (
                    f"Denial receipt fingerprint mismatch: "
                    f"computed={computed}, expected={expected}"
                )
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_approval_receipt_references_escalation_receipt_id(
        self, mock_server_path, signed_constitution,
    ):
        """Approval receipt references the original escalation receipt ID."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                esc_receipt_id = gw.last_receipt["receipt_id"]
                token = _get_approval_token(gw, esc_id)

                await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                approval_receipt = gw.last_receipt
                chain_ref = approval_receipt["extensions"]["gateway"][
                    "escalation_receipt_id"
                ]
                assert chain_ref == esc_receipt_id
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 6. META-TOOL REGISTRATION
# =============================================================================

class TestMetaToolRegistration:
    def test_meta_tools_visible_in_tool_list(
        self, mock_server_path, signed_constitution,
    ):
        """Meta-tools (approve/deny) are registered and visible in
        gateway's tool list."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                tools = gw._build_tool_list()
                names = {t.name for t in tools}
                assert _META_TOOL_APPROVE in names
                assert _META_TOOL_DENY in names
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_meta_tools_not_prefixed(
        self, mock_server_path, signed_constitution,
    ):
        """Meta-tools do NOT get prefixed with a server name."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                tools = gw._build_tool_list()
                for t in tools:
                    if t.name in (_META_TOOL_APPROVE, _META_TOOL_DENY):
                        assert not t.name.startswith("mock_")
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_meta_tools_have_schemas(
        self, mock_server_path, signed_constitution,
    ):
        """Meta-tools have proper input schemas with escalation_id."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                tools = gw._build_tool_list()
                meta_tools = {t.name: t for t in tools
                              if t.name in (_META_TOOL_APPROVE, _META_TOOL_DENY)}
                for name, tool in meta_tools.items():
                    schema = tool.inputSchema
                    assert "escalation_id" in schema["properties"]
                    assert "escalation_id" in schema["required"]
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 7. CONCURRENT ESCALATIONS
# =============================================================================

class TestConcurrentEscalations:
    def test_two_escalations_approve_one_deny_other(
        self, mock_server_path, signed_constitution,
    ):
        """Two different escalation IDs: approve one, deny the other."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                # Trigger two escalations
                r1 = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "first"},
                )
                esc_id_1 = json.loads(r1.content[0].text)["escalation_id"]

                r2 = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "2", "name": "second"},
                )
                esc_id_2 = json.loads(r2.content[0].text)["escalation_id"]

                assert esc_id_1 != esc_id_2
                assert len(gw.escalation_store) == 2
                token_1 = _get_approval_token(gw, esc_id_1)

                # Approve first
                approve_result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id_1, "approval_token": token_1},
                )
                data = json.loads(approve_result.content[0].text)
                assert data["updated"] is True
                assert data["item_id"] == "1"

                # Deny second
                deny_result = await gw._forward_call(
                    _META_TOOL_DENY,
                    {"escalation_id": esc_id_2},
                )
                deny_data = json.loads(deny_result.content[0].text)
                assert deny_data["status"] == "denied"

                assert len(gw.escalation_store) == 0
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 8. DOUBLE RESOLUTION
# =============================================================================

class TestDoubleResolution:
    def test_double_approve_returns_not_found(
        self, mock_server_path, signed_constitution,
    ):
        """Double-approve same escalation_id → second call returns NOT_FOUND."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_id = json.loads(
                    esc_result.content[0].text,
                )["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                # First approve succeeds
                r1 = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                assert r1.isError is not True

                # Second approve → NOT_FOUND (entry removed)
                r2 = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                assert r2.isError is True
                data = json.loads(r2.content[0].text)
                assert data["error"] == "ESCALATION_NOT_FOUND"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_approve_then_deny_returns_not_found(
        self, mock_server_path, signed_constitution,
    ):
        """Approve then deny same escalation → deny returns NOT_FOUND."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_id = json.loads(
                    esc_result.content[0].text,
                )["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )

                deny_result = await gw._forward_call(
                    _META_TOOL_DENY,
                    {"escalation_id": esc_id},
                )
                assert deny_result.isError is True
                data = json.loads(deny_result.content[0].text)
                assert data["error"] == "ESCALATION_NOT_FOUND"
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# 9. EDGE CASES
# =============================================================================

class TestEscalationEdgeCases:
    def test_approve_missing_escalation_id(
        self, mock_server_path, signed_constitution,
    ):
        """Approve with missing escalation_id → MISSING_PARAMETER error."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                result = await gw._forward_call(
                    _META_TOOL_APPROVE, {},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "MISSING_PARAMETER"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_deny_missing_escalation_id(
        self, mock_server_path, signed_constitution,
    ):
        """Deny with missing escalation_id → MISSING_PARAMETER error."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                result = await gw._forward_call(
                    _META_TOOL_DENY, {},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "MISSING_PARAMETER"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_escalation_store_cleared_on_shutdown(
        self, mock_server_path, signed_constitution,
    ):
        """Escalation store is cleared on gateway shutdown."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                assert len(gw.escalation_store) == 1
            finally:
                await gw.shutdown()
            assert len(gw.escalation_store) == 0

        asyncio.run(_test())


# =============================================================================
# 10. APPROVAL TOKEN VERIFICATION
# =============================================================================

class TestApprovalToken:
    """Tests for HMAC-bound approval tokens (human-binding)."""

    def test_valid_token_succeeds_with_token_verified(
        self, mock_server_path, signed_constitution,
    ):
        """Valid token succeeds, receipt shows approval_method: token_verified."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                approve_result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                assert approve_result.isError is not True

                receipt = gw.last_receipt
                gw_ext = receipt["extensions"]["gateway"]
                assert gw_ext["approval_method"] == "token_verified"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_missing_token_rejected(
        self, mock_server_path, signed_constitution,
    ):
        """Approval without token is rejected with MISSING_APPROVAL_TOKEN."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]

                result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "MISSING_APPROVAL_TOKEN"
                assert data["escalation_id"] == esc_id
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_wrong_token_rejected(
        self, mock_server_path, signed_constitution,
    ):
        """Approval with wrong token is rejected with INVALID_APPROVAL_TOKEN."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]

                result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {
                        "escalation_id": esc_id,
                        "approval_token": "wrong_token_value",
                    },
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "INVALID_APPROVAL_TOKEN"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_token_from_other_escalation_rejected(
        self, mock_server_path, signed_constitution,
    ):
        """Token from escalation A cannot approve escalation B."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                # Create two escalations
                r1 = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "first"},
                )
                esc_id_1 = json.loads(r1.content[0].text)["escalation_id"]
                token_1 = _get_approval_token(gw, esc_id_1)

                r2 = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "2", "name": "second"},
                )
                esc_id_2 = json.loads(r2.content[0].text)["escalation_id"]

                # Try to use token_1 to approve escalation 2
                result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {
                        "escalation_id": esc_id_2,
                        "approval_token": token_1,
                    },
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "INVALID_APPROVAL_TOKEN"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_token_expires_with_escalation(
        self, mock_server_path, signed_constitution,
    ):
        """Token is useless after escalation times out."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
                escalation_timeout=1,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                await asyncio.sleep(1.2)

                result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                assert result.isError is True
                data = json.loads(result.content[0].text)
                assert data["error"] == "ESCALATION_EXPIRED"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_no_token_mode_succeeds_without_token(
        self, mock_server_path, signed_constitution,
    ):
        """--no-approval-token mode: approval succeeds without token,
        receipt shows approval_method: unverified."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
                require_approval_token=False,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]

                approve_result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id},
                )
                assert approve_result.isError is not True
                data = json.loads(approve_result.content[0].text)
                assert data["updated"] is True

                receipt = gw.last_receipt
                gw_ext = receipt["extensions"]["gateway"]
                assert gw_ext["approval_method"] == "unverified"
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_stderr_contains_token_on_escalation(
        self, mock_server_path, signed_constitution, capsys,
    ):
        """Token is printed to stderr on escalation creation."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
            finally:
                await gw.shutdown()

        asyncio.run(_test())
        captured = capsys.readouterr()
        assert "[SANNA] Approval token for escalation" in captured.err
        assert "esc_" in captured.err

    def test_token_not_in_mcp_response(
        self, mock_server_path, signed_constitution,
    ):
        """Token is NOT present in the MCP response to the model."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                # The raw MCP response text must NOT contain the token
                response_text = esc_result.content[0].text
                assert token not in response_text
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_receipt_includes_token_hash_not_raw(
        self, mock_server_path, signed_constitution,
    ):
        """Receipt includes token_hash (SHA-256 of token), not raw token."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "1", "name": "new"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                esc_id = esc_data["escalation_id"]
                token = _get_approval_token(gw, esc_id)

                await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                receipt = gw.last_receipt
                gw_ext = receipt["extensions"]["gateway"]

                # token_hash is present and is a SHA-256 hex
                assert "token_hash" in gw_ext
                assert len(gw_ext["token_hash"]) == 64
                # Raw token is NOT in the receipt
                receipt_str = json.dumps(receipt)
                assert token not in receipt_str
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_end_to_end_escalation_approve_with_token(
        self, mock_server_path, signed_constitution,
    ):
        """Full flow: escalate -> token printed -> approve with token ->
        forwarded -> receipt with full chain."""
        const_path, key_path, _ = signed_constitution
        async def _test():
            from sanna.verify import verify_fingerprint

            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=[mock_server_path],
                constitution_path=const_path,
                signing_key_path=key_path,
            )
            await gw.start()
            try:
                # Step 1: Trigger escalation
                esc_result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "99", "name": "e2e-test"},
                )
                esc_data = json.loads(esc_result.content[0].text)
                assert esc_data["status"] == "ESCALATION_REQUIRED"
                esc_id = esc_data["escalation_id"]
                esc_receipt = gw.last_receipt
                esc_receipt_id = esc_receipt["receipt_id"]

                # Escalation receipt fingerprint is valid
                matches, _, _ = verify_fingerprint(esc_receipt)
                assert matches

                # Step 2: Get the token
                token = _get_approval_token(gw, esc_id)

                # Step 3: Approve with token
                approve_result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id, "approval_token": token},
                )
                assert approve_result.isError is not True
                data = json.loads(approve_result.content[0].text)
                assert data["updated"] is True
                assert data["item_id"] == "99"
                assert data["name"] == "e2e-test"

                # Step 4: Verify approval receipt
                approval_receipt = gw.last_receipt
                gw_ext = approval_receipt["extensions"]["gateway"]
                assert gw_ext["escalation_id"] == esc_id
                assert gw_ext["escalation_receipt_id"] == esc_receipt_id
                assert gw_ext["escalation_resolution"] == "approved"
                assert gw_ext["approval_method"] == "token_verified"
                assert "token_hash" in gw_ext
                assert len(gw_ext["token_hash"]) == 64

                # Approval receipt fingerprint is valid
                matches, _, _ = verify_fingerprint(approval_receipt)
                assert matches
            finally:
                await gw.shutdown()

        asyncio.run(_test())


# =============================================================================
# ESCALATION STORE HARDENING TESTS
# =============================================================================


class TestEscalationStoreHardening:
    """Tests for escalation store hardening (v0.10.1)."""

    # -- Full UUID IDs -------------------------------------------------------

    def test_escalation_id_is_full_uuid(self):
        """Escalation IDs use full uuid4.hex (32 chars), not truncated."""
        store = EscalationStore(timeout=300)
        entry = store.create(
            prefixed_name="srv_tool",
            original_name="tool",
            arguments={},
            server_name="srv",
            reason="test",
        )
        # esc_ prefix + 32 hex chars = 36 total
        assert entry.escalation_id.startswith("esc_")
        hex_part = entry.escalation_id[4:]
        assert len(hex_part) == 32
        int(hex_part, 16)  # valid hex

    def test_no_id_collisions_across_1000(self):
        """1000 IDs are all unique (full UUID prevents collisions)."""
        store = EscalationStore(timeout=300, max_pending=2000)
        ids = set()
        for _ in range(1000):
            entry = store.create(
                prefixed_name="srv_tool",
                original_name="tool",
                arguments={},
                server_name="srv",
                reason="test",
            )
            ids.add(entry.escalation_id)
        assert len(ids) == 1000

    # -- TTL purge on create() -----------------------------------------------

    def test_purge_expired_cleans_old_entries(self):
        """purge_expired() removes expired entries."""
        store = EscalationStore(timeout=1)
        entry = store.create(
            prefixed_name="srv_tool",
            original_name="tool",
            arguments={},
            server_name="srv",
            reason="test",
        )
        # Backdate to make it expired
        from datetime import datetime, timezone, timedelta
        old_time = datetime.now(timezone.utc) - timedelta(seconds=10)
        entry.created_at = old_time.isoformat()

        assert len(store) == 1
        purged = store.purge_expired()
        assert purged == 1
        assert len(store) == 0

    def test_create_purges_expired_first(self):
        """create() purges expired entries before adding new one."""
        store = EscalationStore(timeout=1, max_pending=2)
        e1 = store.create(
            prefixed_name="srv_tool",
            original_name="tool",
            arguments={},
            server_name="srv",
            reason="first",
        )
        e2 = store.create(
            prefixed_name="srv_tool",
            original_name="tool",
            arguments={},
            server_name="srv",
            reason="second",
        )
        assert len(store) == 2

        # Backdate both to make them expired
        from datetime import datetime, timezone, timedelta
        old_time = datetime.now(timezone.utc) - timedelta(seconds=10)
        e1.created_at = old_time.isoformat()
        e2.created_at = old_time.isoformat()

        # Creating a new one should succeed (expired ones get purged first)
        e3 = store.create(
            prefixed_name="srv_tool",
            original_name="tool",
            arguments={},
            server_name="srv",
            reason="third",
        )
        assert len(store) == 1
        assert store.get(e3.escalation_id) is not None

    # -- Max pending limit ---------------------------------------------------

    def test_max_pending_default_is_100(self):
        """Default max_pending is 100."""
        store = EscalationStore(timeout=300)
        assert store.max_pending == 100

    def test_max_pending_configurable(self):
        """max_pending can be set via constructor."""
        store = EscalationStore(timeout=300, max_pending=5)
        assert store.max_pending == 5

    def test_create_raises_at_capacity(self):
        """create() raises RuntimeError when store is at capacity."""
        store = EscalationStore(timeout=300, max_pending=2)
        store.create(
            prefixed_name="srv_t1",
            original_name="t1",
            arguments={},
            server_name="srv",
            reason="first",
        )
        store.create(
            prefixed_name="srv_t2",
            original_name="t2",
            arguments={},
            server_name="srv",
            reason="second",
        )
        with pytest.raises(RuntimeError, match="at capacity"):
            store.create(
                prefixed_name="srv_t3",
                original_name="t3",
                arguments={},
                server_name="srv",
                reason="third",
            )

    def test_capacity_freed_after_remove(self):
        """After removing an entry, capacity is available again."""
        store = EscalationStore(timeout=300, max_pending=1)
        e1 = store.create(
            prefixed_name="srv_t1",
            original_name="t1",
            arguments={},
            server_name="srv",
            reason="first",
        )
        store.remove(e1.escalation_id)
        # Now should succeed
        e2 = store.create(
            prefixed_name="srv_t2",
            original_name="t2",
            arguments={},
            server_name="srv",
            reason="second",
        )
        assert store.get(e2.escalation_id) is not None

    # -- Status field --------------------------------------------------------

    def test_default_status_is_pending(self):
        """New escalations have status 'pending'."""
        store = EscalationStore(timeout=300)
        entry = store.create(
            prefixed_name="srv_tool",
            original_name="tool",
            arguments={},
            server_name="srv",
            reason="test",
        )
        assert entry.status == "pending"

    def test_mark_status(self):
        """mark_status() updates the status in-place."""
        store = EscalationStore(timeout=300)
        entry = store.create(
            prefixed_name="srv_tool",
            original_name="tool",
            arguments={},
            server_name="srv",
            reason="test",
        )
        store.mark_status(entry.escalation_id, "approved")
        assert entry.status == "approved"
        # Still in store
        assert store.get(entry.escalation_id) is not None

    def test_mark_status_nonexistent_returns_none(self):
        """mark_status() returns None for unknown IDs."""
        store = EscalationStore(timeout=300)
        result = store.mark_status("esc_nonexistent", "approved")
        assert result is None

    # -- Escalation store full error in gateway ------------------------------

    def test_store_full_returns_error(self, signed_constitution, tmp_path):
        """When store is full, escalation returns ESCALATION_STORE_FULL."""
        mcp = pytest.importorskip("mcp")
        const_path, key_path, _ = signed_constitution

        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=["-c", MOCK_SERVER_SCRIPT],
                constitution_path=const_path,
                signing_key_path=key_path,
                policy_overrides={"update_item": "must_escalate"},
                escalation_timeout=300,
                max_pending_escalations=1,
                require_approval_token=False,
            )
            try:
                await gw.start()
                # First escalation should succeed
                result1 = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "p1", "name": "first"},
                )
                data1 = json.loads(result1.content[0].text)
                assert data1["status"] == "ESCALATION_REQUIRED"

                # Second escalation should fail (store full)
                result2 = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "p2", "name": "second"},
                )
                data2 = json.loads(result2.content[0].text)
                assert data2["error"] == "ESCALATION_STORE_FULL"
                assert result2.isError is True
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    # -- Approve-then-execute ordering (the critical fix) --------------------

    def test_approve_marks_approved_before_execution(
        self, signed_constitution, tmp_path,
    ):
        """Approved escalation is marked 'approved' before downstream call."""
        mcp = pytest.importorskip("mcp")
        const_path, key_path, _ = signed_constitution

        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=["-c", MOCK_SERVER_SCRIPT],
                constitution_path=const_path,
                signing_key_path=key_path,
                policy_overrides={"update_item": "must_escalate"},
                escalation_timeout=300,
                require_approval_token=False,
            )
            try:
                await gw.start()
                result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "p1", "name": "test"},
                )
                data = json.loads(result.content[0].text)
                esc_id = data["escalation_id"]

                # After successful approval, entry should be removed
                approve_result = await gw._forward_call(
                    _META_TOOL_APPROVE,
                    {"escalation_id": esc_id},
                )
                assert approve_result.isError is not True

                # Entry should be gone (execution succeeded)
                assert gw._escalation_store.get(esc_id) is None
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    def test_approve_downstream_failure_keeps_entry_as_failed(
        self, signed_constitution, tmp_path,
    ):
        """If downstream call raises, entry stays in store as 'failed'."""
        mcp = pytest.importorskip("mcp")
        from unittest.mock import AsyncMock
        const_path, key_path, _ = signed_constitution

        async def _test():
            gw = SannaGateway(
                server_name="mock",
                command=sys.executable,
                args=["-c", MOCK_SERVER_SCRIPT],
                constitution_path=const_path,
                signing_key_path=key_path,
                policy_overrides={"update_item": "must_escalate"},
                escalation_timeout=300,
                require_approval_token=False,
            )
            try:
                await gw.start()
                result = await gw._forward_call(
                    "mock_update_item",
                    {"item_id": "p1", "name": "test"},
                )
                data = json.loads(result.content[0].text)
                esc_id = data["escalation_id"]

                # Monkey-patch downstream to fail
                ds_state = gw._downstream_states["mock"]
                original_call = ds_state.connection.call_tool
                ds_state.connection.call_tool = AsyncMock(
                    side_effect=Exception("downstream crashed"),
                )

                with pytest.raises(Exception, match="downstream crashed"):
                    await gw._forward_call(
                        _META_TOOL_APPROVE,
                        {"escalation_id": esc_id},
                    )

                # Entry should still be in store with 'failed' status
                entry = gw._escalation_store.get(esc_id)
                assert entry is not None
                assert entry.status == "failed"

                # Restore original call_tool
                ds_state.connection.call_tool = original_call
            finally:
                await gw.shutdown()

        asyncio.run(_test())

    # -- Config integration --------------------------------------------------

    def test_max_pending_escalations_from_config(self, tmp_path):
        """max_pending_escalations is wired from gateway config."""
        from sanna.gateway.config import load_gateway_config

        # Create minimal signed constitution and key for config loading
        from sanna.constitution import (
            Constitution, AgentIdentity, Provenance, Boundary,
            sign_constitution, save_constitution,
        )
        from sanna.crypto import generate_keypair

        keys_dir = tmp_path / "keys"
        keys_dir.mkdir()
        key_path, _ = generate_keypair(str(keys_dir), label="test")

        const = Constitution(
            schema_version="1.0.0",
            identity=AgentIdentity(
                agent_name="test",
                domain="test",
                description="test",
            ),
            provenance=Provenance(
                authored_by="test@test.com",
                approved_by=["test@test.com"],
                approval_date="2026-02-15",
                approval_method="test",
            ),
            boundaries=[Boundary(
                id="B001",
                description="test boundary",
                category="scope",
                severity="high",
            )],
        )
        const_path = tmp_path / "constitution.yaml"
        sign_constitution(const, str(key_path))
        save_constitution(const, str(const_path))

        config_yaml = f"""
gateway:
  constitution: {const_path}
  signing_key: {key_path}
  max_pending_escalations: 42

downstream:
  - name: test
    command: echo
    args: ["hello"]
"""
        config_file = tmp_path / "gateway.yaml"
        config_file.write_text(config_yaml)

        config = load_gateway_config(str(config_file))
        assert config.max_pending_escalations == 42
