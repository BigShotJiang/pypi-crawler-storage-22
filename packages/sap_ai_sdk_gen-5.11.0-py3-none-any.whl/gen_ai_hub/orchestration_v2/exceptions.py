"""
Exceptions for the orchestration service module.
"""

from gen_ai_hub.orchestration_v2.models.response import ModuleResults

import httpx


class OrchestrationError(Exception):
    """
    This exception is raised when an error occurs during the execution of the
    orchestration service, typically due to incorrect usage, invalid configurations,
    or issues with run parameters defined by the user.

    Args:
        request_id: Unique identifier for the request that encountered the error.
        http_headers: HTTP headers associated with the request, useful in case of e.g. rate limiting.
        message: Detailed error message describing the issue.
        code: Error code associated with the specific type of failure.
        location: Specific component or step in the orchestration process where the error occurred.
        intermediate_results: State information and partial results from various modules
                                at the time of the error, useful for debugging.
    """

    def __init__(
            self,
            request_id: str,
            http_headers: httpx.Headers,
            message: str,
            code: int,
            location: str,
            intermediate_results: ModuleResults,
            retries: int = 0
    ):
        self.request_id = request_id
        self.http_headers = http_headers
        self.message = message
        self.code = code
        self.location = location
        self.intermediate_results = intermediate_results
        self.retries = retries
        super().__init__(message)
