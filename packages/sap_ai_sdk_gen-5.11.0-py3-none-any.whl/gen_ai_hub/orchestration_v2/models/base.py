"""
A base model class that extends Pydantic's BaseModel and ABC.
"""

from abc import ABC

from pydantic import BaseModel


class ABCBaseModel(BaseModel, ABC):
    """
    Abstract base model that extends Pydantic's BaseModel and ABC.
    It customizes the model_dump method to set default parameters.
    """

    def model_dump(self, **kwargs):
        kwargs.setdefault("by_alias", True)
        kwargs.setdefault("exclude_none", True)
        return super().model_dump(**kwargs)
