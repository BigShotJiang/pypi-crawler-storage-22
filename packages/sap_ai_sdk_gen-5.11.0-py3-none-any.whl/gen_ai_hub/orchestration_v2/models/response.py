"""
Response models for orchestration v2
"""

from typing import List, Optional, Any

from gen_ai_hub.orchestration_v2.models.base import ABCBaseModel as BaseModel
from gen_ai_hub.orchestration_v2.models.message import ChatMessage, FunctionCall


class TokenUsage(BaseModel):
    """
    Usage of tokens in the response
    """
    completion_tokens: int
    prompt_tokens: int
    total_tokens: int


class GenericModuleResult(BaseModel):
    """
    Generic module result
    Args:
        message: Some message created from the module. Example: Input to LLM is masked successfully.
        data: Additional data object from the module
    """
    message: str
    data: Optional[Any] = None


class TopLogprob(BaseModel):
    """
    Represents one of the most likely tokens and its log probability
    at a given token position.

    Attributes:
        token: The token.
        logprob: The log probability of this token.
        bytes: UTF-8 bytes of the token, if applicable.
    """
    token: str
    logprob: float
    bytes: Optional[List[int]] = None


class ChatCompletionTokenLogprob(BaseModel):
    """
    Represents a token in the message content along with its
    log probability and alternative top log probabilities.

    Attributes:
        token: The token.
        logprob: The log probability of this token.
        bytes: UTF-8 bytes of the token, if applicable.
        top_logprobs: List of most likely tokens and their log probabilities
            at this token position.
    """
    token: str
    logprob: float
    bytes: Optional[List[int]] = None
    top_logprobs: Optional[List[TopLogprob]] = None


class ChoiceLogprobs(BaseModel):
    """
    Log probabilities for the choice.
    """
    content: Optional[List[ChatCompletionTokenLogprob]] = None
    refusal: Optional[List[ChatCompletionTokenLogprob]] = None


class LLMChoice(BaseModel):
    """
    Args:
        index: Index of the choice
        message: Message from the LLM
        logprobs: Log probabilities for the choice
        finish_reason: Reason the model stopped generating tokens.
                       - 'stop' if the model hit a natural stop point or a provided stop sequence,
                       - 'length' if the maximum token number was reached,
                       - 'content_filter' if content was omitted due to a filter enforced by the LLM model provider
                                          or the content filtering module
    """

    index: int
    message: ChatMessage
    logprobs: Optional[ChoiceLogprobs] = None
    finish_reason: str


class StreamFunctionObject(FunctionCall):
    name: Optional[str] = None


class StreamToolCall(BaseModel):
    index: int
    id: Optional[str] = None
    function: StreamFunctionObject


class StreamDelta(BaseModel):
    role: Optional[str] = None
    content: Optional[str] = None
    tool_calls: Optional[List[StreamToolCall]] = None


class StreamLLMChoice(BaseModel):
    index: int
    delta: StreamDelta
    logprobs: Optional[ChoiceLogprobs] = None
    finish_reason: Optional[str] = None


class LLMModuleResult(BaseModel):
    """
    Output from LLM. Follows the OpenAI spec.

    Attributes:
        id: Unique identifier for the response.
        object: Type of object returned (e.g., "chat.completion").
        created: Unix timestamp of when the result was created.
        model: The model name (e.g., "gpt-4o-mini").
        system_fingerprint: Optional system fingerprint associated with the result.
        choices: List of LLMChoice objects representing the output choices.
        usage: TokenUsage object representing the token usage statistics.
    """
    id: str
    object: str
    created: int
    model: str
    system_fingerprint: Optional[str] = None
    choices: List[LLMChoice]
    usage: TokenUsage


class StreamLLMModuleResult(LLMModuleResult):
    choices: List[StreamLLMChoice]
    usage: Optional[TokenUsage] = None


class ModuleResults(BaseModel):
    """Represents the results of each module used in a processing pipeline.

    Attributes:
        grounding: Optional result from the grounding module.
        templating: Optional list of chat messages resulting from the templating
            module.
        input_translation: Optional result from the input translation module.
        input_masking: Optional result from the input masking module.
        input_filtering: Optional result from the input filtering module.
        output_filtering: Optional result from the output filtering module.
        output_translation: Optional result from the output translation module.
        llm: Optional result from an LLM-specific module.
        output_unmasking: Optional list of choices from the output unmasking
            module.
    """
    grounding: Optional[GenericModuleResult] = None
    templating: Optional[List[ChatMessage]] = None
    input_translation: Optional[GenericModuleResult] = None
    input_masking: Optional[GenericModuleResult] = None
    input_filtering: Optional[GenericModuleResult] = None
    output_filtering: Optional[GenericModuleResult] = None
    output_translation: Optional[GenericModuleResult] = None
    llm: Optional[LLMModuleResult] = None
    output_unmasking: Optional[List[LLMChoice]] = None


class StreamModuleResults(ModuleResults):
    llm: Optional[StreamLLMModuleResult] = None
    output_unmasking: Optional[List[StreamLLMChoice]] = None


class SAPAPIError(BaseModel):
    """
    Represents an error returned from an SAP API.

    Attributes:
        request_id (str): The unique identifier of the request associated
                          with the error.
        code (int): The http error code.
        message (str): A detailed message describing the error.
        location (str): The location where the error occurred
        intermediate_results (Optional[ModuleResults]): Optional attribute
                                                        to store any
                                                        processing results
                                                        if available or
                                                        applicable.
    """
    request_id: str
    code: int
    message: str
    location: str
    intermediate_results: Optional[ModuleResults] = None


class CompletionPostResponse(BaseModel):
    """
    Represents the response for a completion post request.

    Attributes:
        request_id (str): Unique identifier for the completion request.
        intermediate_results (ModuleResults): Results from various modules executed during the processing.
        final_result (LLMModuleResult): Output from LLM. Follows the OpenAI spec.
    """
    request_id: str
    intermediate_results: ModuleResults
    final_result: LLMModuleResult
    intermediate_failures: Optional[List[SAPAPIError]] = None


class StreamCompletionPostResponse(BaseModel):
    request_id: str
    intermediate_results: StreamModuleResults
    final_result: StreamLLMModuleResult
    intermediate_failures: Optional[List[SAPAPIError]] = None

class ErrorResponse(BaseModel):
    error: SAPAPIError


class OrchestrationResponseWithRetries(CompletionPostResponse):
    """
    Extended CompletionPostResponse that includes retry count information.

    This is returned when using retry-enabled methods like run_with_retries().

    Attributes:
        retries: Number of retry attempts that were made to successfully complete this request.
    """
    retries: int = 0