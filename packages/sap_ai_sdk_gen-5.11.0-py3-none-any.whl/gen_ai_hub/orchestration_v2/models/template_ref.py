"""
Module for template reference models.
"""

from gen_ai_hub.orchestration_v2.models.base import ABCBaseModel as BaseModel


class TemplateRefByID(BaseModel):
    """
    Represents a prompt template reference for generating prompts or conversations.
    Args:
        id(str): ID of the template in prompt registry
    """
    id: str


class TemplateRefByScenarioNameVersion(BaseModel):
    """
        Represents a prompt template reference for generating prompts or conversations.
        Args:
            scenario(str): Scenario name
            name(str): Name of template
            version(str): Version of template
        """
    scenario: str
    name: str
    version: str


class TemplateRef(BaseModel):
    template_ref: TemplateRefByID | TemplateRefByScenarioNameVersion
