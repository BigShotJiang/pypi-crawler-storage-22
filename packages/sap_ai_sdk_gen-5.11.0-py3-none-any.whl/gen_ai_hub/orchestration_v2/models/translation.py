"""
Translation module configuration models.
"""

from enum import Enum
from typing import Optional

from pydantic import Field

from gen_ai_hub.orchestration_v2.models.base import ABCBaseModel as BaseModel


class TranslationType(str, Enum):
    """Enumerates supported translation types."""
    SAP_DOCUMENT_TRANSLATION = "sap_document_translation"


class TranslationConfig(BaseModel):
    """
    Configuration for sap_document_translation translation provider.
    Args:
        source_language: Language of the text to be translated. Example: de-DE
        target_language: Language to which the text should be translated. Example: en-US
    """

    source_language: Optional[str] = None
    target_language: str


class SAPDocumentTranslation(BaseModel):
    """
    Configuration for translation module.

    Args:
        type: The type of translation module (e.g., 'sap_document_translation').
        config: Configuration object for the translation module.
    """
    type_: TranslationType = Field(default=TranslationType.SAP_DOCUMENT_TRANSLATION, alias="type")
    config: TranslationConfig


class TranslationModuleConfig(BaseModel):
    """
    Configuration for translation module
    Args:
        input: Configuration for input translation
        output: Configuration for output translation
    """
    input: Optional[SAPDocumentTranslation] = None
    output: Optional[SAPDocumentTranslation] = None
