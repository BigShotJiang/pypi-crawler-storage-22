# This is a Transformer algorithm of the BERT type (Bidirectional Encoder Representations from Transformers) developed by Sapiens Technology®️
# with the purpose of training, saving, fine-tuning, loading, and inferring bidirectional language models.
# The code includes a wide range of pre-established functions that make it easier to develop conversational Artificial Intelligence models of any scale.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .sapiens_bert import *
# This is a Transformer algorithm of the BERT type (Bidirectional Encoder Representations from Transformers) developed by Sapiens Technology®️
# with the purpose of training, saving, fine-tuning, loading, and inferring bidirectional language models.
# The code includes a wide range of pre-established functions that make it easier to develop conversational Artificial Intelligence models of any scale.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
