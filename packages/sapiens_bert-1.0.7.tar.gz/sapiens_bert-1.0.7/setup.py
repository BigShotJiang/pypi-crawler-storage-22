# This is a Transformer algorithm of the BERT type (Bidirectional Encoder Representations from Transformers) developed by Sapiens Technology®️
# with the purpose of training, saving, fine-tuning, loading, and inferring bidirectional language models.
# The code includes a wide range of pre-established functions that make it easier to develop conversational Artificial Intelligence models of any scale.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapiens_bert'
version = '1.0.7'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=[
        'torch',
        'numpy',
        'tiktoken',
        'tqdm',
        'certifi',
        "torch-xla; platform_system=='Linux' and platform_machine=='x86_64'"
    ],
    url='https://github.com/sapiens-technology/sapiens_bert',
    license='Proprietary Software'
)
# This is a Transformer algorithm of the BERT type (Bidirectional Encoder Representations from Transformers) developed by Sapiens Technology®️
# with the purpose of training, saving, fine-tuning, loading, and inferring bidirectional language models.
# The code includes a wide range of pre-established functions that make it easier to develop conversational Artificial Intelligence models of any scale.
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
