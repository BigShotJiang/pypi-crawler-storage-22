"""
The “Entity” is an algorithm architected, programmed, and developed by Sapiens Technology®️ with the purpose of managing multiple Artificial Intelligence models simultaneously,
operating as a master model capable of requesting the most appropriate model for each type of situation.
Its technology is based on the intelligent selection of models according to the user’s prompt;
this selection is carried out through the combination of distinct methods such as perplexity, symbolism, connectivity, and semantic comparison.
A primary model may be loaded as an assistant for input categorization or for building more elaborate responses inspired by the selection or combination of the outputs from secondary models (submodels).
The developer can set the most appropriate method depending on their project needs, or configure the call so that the function itself automatically chooses the best method.

Editing, customization, or distribution of this or any other Sapiens Technology®️ code is not permitted without the company’s prior consent,
and any public posting or commentary related to the technical concepts of our code is strictly prohibited. Violators may be subject to legal action initiated by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .sapiens_entity import *
"""
The “Entity” is an algorithm architected, programmed, and developed by Sapiens Technology®️ with the purpose of managing multiple Artificial Intelligence models simultaneously,
operating as a master model capable of requesting the most appropriate model for each type of situation.
Its technology is based on the intelligent selection of models according to the user’s prompt;
this selection is carried out through the combination of distinct methods such as perplexity, symbolism, connectivity, and semantic comparison.
A primary model may be loaded as an assistant for input categorization or for building more elaborate responses inspired by the selection or combination of the outputs from secondary models (submodels).
The developer can set the most appropriate method depending on their project needs, or configure the call so that the function itself automatically chooses the best method.

Editing, customization, or distribution of this or any other Sapiens Technology®️ code is not permitted without the company’s prior consent,
and any public posting or commentary related to the technical concepts of our code is strictly prohibited. Violators may be subject to legal action initiated by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
