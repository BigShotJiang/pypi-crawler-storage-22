_FILE_INFO = {
    "//": "ディレクトリパス: examples/benchmark_rust.py",
    "//": "タイトル: Rust vs Python ベンチマーク",
    "//": "目的: インストールされたsara-engineの計算速度を計測する。"
}

import time
from sara_engine import DynamicLiquidLayer

def run_benchmark():
    print("=== SARA Engine: Rust vs Python Benchmark ===")
    
    # パッケージからレイヤーを初期化
    # Rust実装が利用可能な場合は自動的に使用される
    layer = DynamicLiquidLayer(input_size=1024, hidden_size=2000, decay=0.5, density=0.05)
    
    mode = "Rust" if layer.use_rust else "Python"
    print(f"Running in {mode} mode.")
    
    steps = 1000
    start_time = time.time()
    
    print(f"Executing {steps} steps...")
    input_spikes = list(range(10)) 
    prev_spikes = []
    
    for i in range(steps):
        if i % 10 == 0:
            input_spikes = [(x + 1) % 1024 for x in input_spikes]
            
        # 順伝播
        spikes = layer.forward_with_feedback(input_spikes, prev_spikes)
        prev_spikes = spikes
        
    duration = time.time() - start_time
    fps = steps / duration
    
    print(f"\nResult ({mode}):")
    print(f"  Total Time: {duration:.4f} sec")
    print(f"  Speed: {fps:.2f} steps/sec")
    
    if mode == "Rust":
        print("\nOptimization Status: Native Acceleration Active.")
    else:
        print("\nOptimization Status: Using Python Fallback.")

if __name__ == "__main__":
    run_benchmark()