import json
import os
import time
import socket
import logging
from pathlib import Path
from typing import Optional, Iterable, Callable, TypedDict
from filelock import FileLock
from sari.core.fallback_governance import note_fallback_enter, note_fallback_exit

# Backward compatibility for legacy tests/tools that patch module-level path.
REGISTRY_FILE = Path.home() / ".local" / os.path.join("share", "sari") / "server.json"
_FALLBACK_REGISTRY = Path(
    os.environ.get(
        "SARI_REGISTRY_FALLBACK",
        "/tmp/sari/server.json"))
_logger = logging.getLogger("sari.server_registry")
_FALLBACK_WARNED = False


class DaemonEntry(TypedDict, total=False):
    host: str
    port: int
    pid: int
    start_ts: float
    last_seen_ts: float
    draining: bool
    version: str
    http_port: int
    http_host: str
    http_pid: int


class WorkspaceEntry(TypedDict, total=False):
    boot_id: str
    last_active_ts: float
    http_port: int
    http_host: str
    http_pid: int


class RegistryData(TypedDict):
    version: str
    daemons: dict[str, DaemonEntry]
    workspaces: dict[str, WorkspaceEntry]
    deployment: "DeploymentEntry"


class DaemonWithBootId(DaemonEntry, total=False):
    boot_id: str


class WorkspaceHttpEndpoint(TypedDict):
    host: str
    port: int
    boot_id: Optional[str]


class DeploymentEntry(TypedDict, total=False):
    generation: int
    active_boot_id: str
    candidate_boot_id: str
    old_boot_id: str
    state: str
    switch_ts: float
    health_fail_streak: int
    rollback_reason: str


def _ensure_writable_dir(path: Path) -> bool:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        return os.access(str(path.parent), os.W_OK)
    except Exception:
        _logger.debug("Failed to ensure writable directory for registry path: %s", path, exc_info=True)
        return False


def get_registry_path() -> Path:
    """Dynamically determine registry path from environment or default."""
    global _FALLBACK_WARNED
    env_path = os.environ.get("SARI_REGISTRY_FILE")
    if env_path:
        return Path(env_path).resolve()
    # Default path may be blocked in sandboxed/test environments.
    if _ensure_writable_dir(REGISTRY_FILE):
        note_fallback_exit(
            "registry_path_fallback",
            exit_condition="default_registry_path_writable",
        )
        return REGISTRY_FILE
    # Fallback to a temp location when home directory is not writable.
    _ensure_writable_dir(_FALLBACK_REGISTRY)
    if not _FALLBACK_WARNED:
        _logger.warning(
            "Default registry path not writable; using fallback path: %s",
            _FALLBACK_REGISTRY,
        )
        _FALLBACK_WARNED = True
    note_fallback_enter(
        "registry_path_fallback",
        trigger="default_registry_path_not_writable",
    )
    return _FALLBACK_REGISTRY.resolve()


class ServerRegistry:
    """
    Manages the 'server.json' registry for Sari Daemons using robust file locking.
    Registry v2 (SSOT):
      - daemons: boot_id -> {host, port, pid, start_ts, last_seen_ts, draining, version}
      - workspaces: workspace_root -> {boot_id, last_active_ts, http_port, http_host}
    """

    VERSION = "2.0"

    def __init__(self):
        # Delay lock initialization so tests can patch get_registry_path first.
        self._lock = None

    def _ensure_lock(self) -> FileLock:
        reg_file = get_registry_path()
        reg_file.parent.mkdir(parents=True, exist_ok=True)
        if self._lock is None:
            # Use FileLock for cross-platform reliability and built-in timeouts
            self._lock = FileLock(
                str(reg_file.with_suffix(".json.lock")), timeout=10)
        if not reg_file.exists():
            # Initialize registry file under lock without re-entering
            # _ensure_lock.
            with self._lock:
                if not reg_file.exists():
                    self._atomic_write(self._empty())
        return self._lock

    def _empty(self) -> RegistryData:
        return {"version": self.VERSION, "daemons": {}, "workspaces": {}, "deployment": self._empty_deployment()}

    @staticmethod
    def _empty_deployment() -> DeploymentEntry:
        return {
            "generation": 0,
            "active_boot_id": "",
            "candidate_boot_id": "",
            "old_boot_id": "",
            "state": "idle",
            "switch_ts": 0.0,
            "health_fail_streak": 0,
            "rollback_reason": "",
        }

    def _normalize_workspace_root(self, workspace_root: str) -> str:
        from sari.core.workspace import WorkspaceManager
        return WorkspaceManager.normalize_path(workspace_root)

    def _coerce_daemon_entry(self, value: object) -> Optional[DaemonEntry]:
        if not isinstance(value, dict):
            return None
        out: DaemonEntry = {}
        if value.get("host") is not None:
            out["host"] = str(value["host"])
        if value.get("version") is not None:
            out["version"] = str(value["version"])
        if value.get("http_host") is not None:
            out["http_host"] = str(value["http_host"])
        if value.get("draining") is not None:
            out["draining"] = bool(value["draining"])
        for field in ("port", "pid", "http_port", "http_pid"):
            raw = value.get(field)
            if raw is None:
                continue
            try:
                out[field] = int(raw)  # type: ignore[literal-required]
            except (TypeError, ValueError):
                continue
        for field in ("start_ts", "last_seen_ts"):
            raw = value.get(field)
            if raw is None:
                continue
            try:
                out[field] = float(raw)  # type: ignore[literal-required]
            except (TypeError, ValueError):
                continue
        return out

    def _coerce_workspace_entry(self, value: object) -> Optional[WorkspaceEntry]:
        if not isinstance(value, dict):
            return None
        out: WorkspaceEntry = {}
        if value.get("boot_id") is not None:
            out["boot_id"] = str(value["boot_id"])
        if value.get("http_host") is not None:
            out["http_host"] = str(value["http_host"])
        for field in ("http_port", "http_pid"):
            raw = value.get(field)
            if raw is None:
                continue
            try:
                out[field] = int(raw)  # type: ignore[literal-required]
            except (TypeError, ValueError):
                continue
        if value.get("last_active_ts") is not None:
            try:
                out["last_active_ts"] = float(value["last_active_ts"])
            except (TypeError, ValueError):
                pass
        return out

    def _coerce_deployment_entry(self, value: object) -> DeploymentEntry:
        out = self._empty_deployment()
        if not isinstance(value, dict):
            return out
        raw_state = str(value.get("state") or "").strip().lower()
        out["state"] = raw_state if raw_state in {"idle", "starting", "ready", "switched", "rolling_back"} else "idle"
        out["active_boot_id"] = str(value.get("active_boot_id") or "")
        out["candidate_boot_id"] = str(value.get("candidate_boot_id") or "")
        out["old_boot_id"] = str(value.get("old_boot_id") or "")
        out["rollback_reason"] = str(value.get("rollback_reason") or "")
        for field in ("generation", "health_fail_streak"):
            raw = value.get(field)
            try:
                out[field] = max(0, int(raw or 0))  # type: ignore[literal-required]
            except (TypeError, ValueError):
                out[field] = 0  # type: ignore[literal-required]
        try:
            out["switch_ts"] = max(0.0, float(value.get("switch_ts") or 0.0))
        except (TypeError, ValueError):
            out["switch_ts"] = 0.0
        return out

    def _safe_load(self, content: str) -> RegistryData:
        try:
            data = json.loads(content)
        except Exception:
            preview = str(content or "").replace("\n", "\\n")[:160]
            _logger.warning(
                "Failed to parse registry JSON; resetting to empty schema. preview=%r",
                preview,
                exc_info=True,
            )
            data = {}
        return self._ensure_v2(data)

    def _load_unlocked(self) -> RegistryData:
        reg_file = get_registry_path()
        try:
            with open(reg_file, "r", encoding="utf-8") as f:
                return self._safe_load(f.read())
        except FileNotFoundError:
            return self._empty()

    def _atomic_write(self, data: RegistryData) -> None:
        reg_file = get_registry_path()
        reg_file.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = reg_file.parent / \
            f"{reg_file.name}.tmp.{os.getpid()}.{int(time.time() * 1000)}"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, reg_file)
        except Exception:
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except Exception:
                pass
            raise

    def _ensure_v2(self, data: object) -> RegistryData:
        if not isinstance(data, dict):
            return self._empty()
        version = data.get("version")
        if version == self.VERSION and "daemons" in data and "workspaces" in data:
            normalized = self._empty()
            daemons = data.get("daemons")
            if isinstance(daemons, dict):
                for boot_id, info in daemons.items():
                    if not isinstance(boot_id, str):
                        continue
                    coerced = self._coerce_daemon_entry(info)
                    if coerced is not None:
                        normalized["daemons"][boot_id] = coerced
            workspaces = data.get("workspaces")
            if isinstance(workspaces, dict):
                for ws, info in workspaces.items():
                    if not isinstance(ws, str):
                        continue
                    coerced = self._coerce_workspace_entry(info)
                    if coerced is not None:
                        normalized["workspaces"][ws] = coerced
            normalized["deployment"] = self._coerce_deployment_entry(data.get("deployment"))
            return normalized

        # Migrate legacy schema (v1) if needed
        if "instances" in data and isinstance(data["instances"], dict):
            now = time.time()
            migrated = self._empty()
            for ws, info in data["instances"].items():
                if not isinstance(info, dict):
                    continue
                ws_norm = ws  # Simplification for migration
                pid = info.get("pid")
                port = info.get("port")
                if pid is None or port is None:
                    continue

                boot_id = f"legacy-{pid}-{port}"
                migrated["daemons"][boot_id] = {
                    "host": "127.0.0.1",
                    "port": int(port),
                    "pid": int(pid),
                    "start_ts": float(info.get("start_ts") or now),
                    "last_seen_ts": now,
                    "draining": False,
                    "version": info.get("version") or "legacy",
                }
                migrated["workspaces"][ws_norm] = {
                    "boot_id": boot_id, "last_active_ts": now}
            # Best-effort initialize active boot from most recent migrated daemon.
            if migrated["daemons"]:
                latest = max(
                    migrated["daemons"].items(),
                    key=lambda kv: float(kv[1].get("last_seen_ts") or 0.0),
                )
                migrated["deployment"]["active_boot_id"] = str(latest[0])
            return migrated

        return self._empty()

    def _load(self) -> RegistryData:
        lock = self._ensure_lock()
        with lock:
            return self._load_unlocked()

    def _save(self, data: RegistryData):
        lock = self._ensure_lock()
        with lock:
            self._atomic_write(data)

    def _update(self, updater: Callable[[RegistryData], None]) -> None:
        lock = self._ensure_lock()
        with lock:
            data = self._load_unlocked()
            updater(data)
            self._atomic_write(data)

    def _is_process_alive(self, pid: Optional[int]) -> bool:
        if not pid:
            return False
        try:
            os.kill(pid, 0)
            return True
        except (OSError, PermissionError):
            return False

    def _prune_dead_locked(self, data: RegistryData) -> None:
        daemons: dict[str, DaemonEntry] = {}
        for bid, raw_info in (data.get("daemons", {}) or {}).items():
            coerced = self._coerce_daemon_entry(raw_info)
            if coerced is None:
                continue
            daemons[bid] = coerced

        workspaces: dict[str, WorkspaceEntry] = {}
        for ws, raw_info in (data.get("workspaces", {}) or {}).items():
            coerced = self._coerce_workspace_entry(raw_info)
            if coerced is None:
                continue
            workspaces[ws] = coerced

        dead = [bid for bid, info in daemons.items() if not self._is_process_alive(info.get("pid"))]
        for bid in dead:
            daemons.pop(bid, None)
        if dead:
            workspaces = {
                ws: info for ws,
                info in workspaces.items() if info.get("boot_id") not in dead}
        valid_boot_ids = set(daemons.keys())
        workspaces = {
            ws: info
            for ws, info in workspaces.items()
            if info.get("boot_id") in valid_boot_ids
        }
        data["daemons"] = daemons
        data["workspaces"] = workspaces
        deployment = self._coerce_deployment_entry(data.get("deployment"))
        if deployment.get("active_boot_id") and deployment.get("active_boot_id") not in valid_boot_ids:
            deployment["active_boot_id"] = ""
            deployment["state"] = "idle"
        if deployment.get("candidate_boot_id") and deployment.get("candidate_boot_id") not in valid_boot_ids:
            deployment["candidate_boot_id"] = ""
            deployment["state"] = "idle"
        if deployment.get("old_boot_id") and deployment.get("old_boot_id") not in valid_boot_ids:
            deployment["old_boot_id"] = ""
        data["deployment"] = deployment

    def register_daemon(
        self,
        boot_id: str,
        host: str,
        port: int,
        pid: int,
        version: str = "",
        http_port: Optional[int] = None,
        http_host: Optional[str] = None,
        http_pid: Optional[int] = None,
    ) -> None:
        def _upd(data):
            self._prune_dead_locked(data)
            daemons = data.setdefault("daemons", {})
            prev = daemons.get(boot_id, {})
            daemons[boot_id] = {
                "host": host, "port": port, "pid": pid,
                "start_ts": prev.get("start_ts") or time.time(),
                "last_seen_ts": time.time(),
                "draining": bool(prev.get("draining", False)),
                "version": version or prev.get("version", ""),
            }
            if http_port is not None:
                daemons[boot_id]["http_port"] = int(http_port)
            elif prev.get("http_port") is not None:
                daemons[boot_id]["http_port"] = int(prev.get("http_port"))
            if http_host:
                daemons[boot_id]["http_host"] = str(http_host)
            elif prev.get("http_host"):
                daemons[boot_id]["http_host"] = str(prev.get("http_host"))
            if http_pid is not None:
                daemons[boot_id]["http_pid"] = int(http_pid)
            elif prev.get("http_pid") is not None:
                daemons[boot_id]["http_pid"] = int(prev.get("http_pid"))
        self._update(_upd)

    def get_daemon(self, boot_id: str) -> Optional[DaemonEntry]:
        data = self._load()
        daemon = (data.get("daemons") or {}).get(boot_id)
        if not daemon:
            return None
        if not self._is_process_alive(daemon.get("pid")):
            self.unregister_daemon(boot_id)
            return None
        return daemon

    def get_workspace(self, workspace_root: str) -> Optional[WorkspaceEntry]:
        ws = self._normalize_workspace_root(workspace_root)
        data = self._load()
        return (data.get("workspaces") or {}).get(ws)

    def list_workspaces_for_boot(self, boot_id: str) -> Iterable[str]:
        data = self._load()
        workspaces = data.get("workspaces", {})
        return [ws for ws, info in workspaces.items(
        ) if info.get("boot_id") == boot_id]

    def resolve_workspace_daemon(
            self, workspace_root: str) -> Optional[DaemonWithBootId]:
        ws = self._normalize_workspace_root(workspace_root)
        data = self._load()
        workspaces = data.get("workspaces", {})
        info = workspaces.get(ws)
        if not info:
            return None
        boot_id = info.get("boot_id")
        daemon = (data.get("daemons") or {}).get(boot_id)
        if not daemon:
            self.unregister_workspace(ws)
            return None
        if not self._is_process_alive(daemon.get("pid")):
            self.unregister_daemon(boot_id)
            return None
        merged = dict(daemon)
        merged["boot_id"] = boot_id
        return merged

    def unregister_daemon(self, boot_id: str) -> None:
        def _upd(data):
            daemons = data.get("daemons", {})
            daemons.pop(boot_id, None)
            workspaces = data.get("workspaces", {})
            data["workspaces"] = {
                ws: info for ws,
                info in workspaces.items() if info.get("boot_id") != boot_id}
            deployment = self._coerce_deployment_entry(data.get("deployment"))
            if deployment.get("active_boot_id") == boot_id:
                deployment["active_boot_id"] = ""
                deployment["state"] = "idle"
            if deployment.get("candidate_boot_id") == boot_id:
                deployment["candidate_boot_id"] = ""
            if deployment.get("old_boot_id") == boot_id:
                deployment["old_boot_id"] = ""
            data["deployment"] = deployment
        self._update(_upd)

    def set_daemon_draining(self, boot_id: str, draining: bool = True) -> None:
        def _upd(data):
            daemons = data.get("daemons", {})
            if boot_id in daemons:
                daemons[boot_id]["draining"] = bool(draining)
                daemons[boot_id]["last_seen_ts"] = time.time()
        self._update(_upd)

    def resolve_daemon_by_endpoint(
            self, host: str, port: int) -> Optional[DaemonWithBootId]:
        data = self._load()
        daemons = data.get("daemons", {})
        for bid, info in daemons.items():
            if str(
                    info.get("host")) == str(host) and int(
                    info.get("port")) == int(port):
                if self._is_process_alive(info.get("pid")):
                    res = dict(info)
                    res["boot_id"] = bid
                    return res
        return None

    def resolve_latest_daemon(self,
                              workspace_root: Optional[str] = None,
                              allow_draining: bool = True) -> Optional[DaemonWithBootId]:
        data = self._load()
        daemons = data.get("daemons", {}) or {}
        workspaces = data.get("workspaces", {}) or {}
        deployment = self._coerce_deployment_entry(data.get("deployment"))

        active_boot = str(deployment.get("active_boot_id") or "")
        if active_boot:
            active_daemon = daemons.get(active_boot)
            if active_daemon and self._is_process_alive(active_daemon.get("pid")):
                if allow_draining or not active_daemon.get("draining"):
                    res = dict(active_daemon)
                    res["boot_id"] = active_boot
                    return res

        if workspace_root:
            ws = self._normalize_workspace_root(workspace_root)
            info = workspaces.get(ws)
            if info:
                boot_id = info.get("boot_id")
                daemon = daemons.get(boot_id)
                if daemon and (
                        allow_draining or not daemon.get("draining")) and self._is_process_alive(
                        daemon.get("pid")):
                    res = dict(daemon)
                    res["boot_id"] = boot_id
                    return res

        best = None
        best_ts = -1.0
        for bid, info in daemons.items():
            if not allow_draining and info.get("draining"):
                continue
            if not self._is_process_alive(info.get("pid")):
                continue
            ts = float(info.get("last_seen_ts") or 0.0)
            if ts > best_ts:
                best_ts = ts
                best = (bid, info)

        if best:
            res = dict(best[1])
            res["boot_id"] = best[0]
            return res
        return None

    def find_free_port(
            self,
            host: str = "127.0.0.1",
            start_port: int = 47790,
            max_tries: int = 200) -> int:
        port = int(start_port)
        for _ in range(max_tries):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind((host, port))
                    return port
                except OSError:
                    port += 1
        # Fallback: ask OS for an ephemeral port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((host, 0))
            return s.getsockname()[1]

    def _is_nested_pair(self, a: str, b: str) -> bool:
        if not a or not b or a == b:
            return False
        return a.startswith(b + os.sep) or b.startswith(a + os.sep)

    def _dedupe_nested_workspaces_locked(
            self, data: RegistryData, preferred_ws: Optional[str] = None) -> None:
        workspaces = dict(data.get("workspaces", {}))
        if not workspaces:
            return

        if preferred_ws and preferred_ws in workspaces:
            remove = [
                ws for ws in workspaces.keys() if ws != preferred_ws and self._is_nested_pair(
                    ws, preferred_ws)]
            for ws in remove:
                workspaces.pop(ws, None)
            data["workspaces"] = workspaces
            return

        # Global dedupe fallback
        ordered = sorted(
            workspaces.items(),
            key=lambda kv: float(
                kv[1].get(
                    "last_active_ts",
                    0.0)),
            reverse=True)
        kept = {}
        for ws, info in ordered:
            if any(self._is_nested_pair(ws, k) for k in kept.keys()):
                continue
            kept[ws] = info
        data["workspaces"] = kept

    def set_workspace_http(
            self,
            workspace_root: str,
            http_port: int,
            http_host: Optional[str] = None,
            http_pid: Optional[int] = None) -> None:
        def _upd(data):
            workspaces = data.setdefault("workspaces", {})
            ws = self._normalize_workspace_root(workspace_root)
            payload = dict(workspaces.get(ws, {}))
            payload["http_port"] = int(http_port)
            if http_host:
                payload["http_host"] = str(http_host)
            if http_pid:
                payload["http_pid"] = int(http_pid)
            payload["last_active_ts"] = time.time()
            workspaces[ws] = payload
            self._dedupe_nested_workspaces_locked(data, preferred_ws=ws)
        self._update(_upd)

    def set_workspace(
        self,
        workspace_root: str,
        boot_id: str,
        http_port: Optional[int] = None,
        http_host: Optional[str] = None,
    ) -> None:
        def _upd(data):
            workspaces = data.setdefault("workspaces", {})
            ws = self._normalize_workspace_root(workspace_root)
            payload = dict(workspaces.get(ws, {}))
            payload["boot_id"] = boot_id
            if http_port is not None:
                payload["http_port"] = int(http_port)
            if http_host:
                payload["http_host"] = str(http_host)
            payload["last_active_ts"] = time.time()
            workspaces[ws] = payload
            self._dedupe_nested_workspaces_locked(data, preferred_ws=ws)
            deployment = self._coerce_deployment_entry(data.get("deployment"))
            if not str(deployment.get("active_boot_id") or ""):
                deployment["active_boot_id"] = str(boot_id or "")
            data["deployment"] = deployment
        self._update(_upd)

    def set_daemon_http(
            self,
            boot_id: str,
            http_port: int,
            http_host: Optional[str] = None,
            http_pid: Optional[int] = None) -> None:
        def _upd(data):
            daemons = data.setdefault("daemons", {})
            info = dict(daemons.get(boot_id, {}))
            if not info:
                return
            info["http_port"] = int(http_port)
            if http_host:
                info["http_host"] = str(http_host)
            if http_pid is not None:
                info["http_pid"] = int(http_pid)
            else:
                info.pop("http_pid", None)
            info["last_seen_ts"] = time.time()
            daemons[boot_id] = info
        self._update(_upd)

    def resolve_workspace_http(
            self, workspace_root: str) -> Optional[WorkspaceHttpEndpoint]:
        ws = self._normalize_workspace_root(workspace_root)
        data = self._load()
        workspaces = data.get("workspaces", {}) or {}
        daemons = data.get("daemons", {}) or {}
        ws_info = workspaces.get(ws) or {}
        boot_id = ws_info.get("boot_id")
        daemon = daemons.get(boot_id) if boot_id else None
        if daemon and self._is_process_alive(daemon.get("pid")):
            host = daemon.get("http_host") or daemon.get("host")
            port = daemon.get("http_port")
            if host and port:
                return {
                    "host": str(host),
                    "port": int(port),
                    "boot_id": boot_id}
        # Backward-compat fallback to workspace-level fields.
        if ws_info.get("http_host") and ws_info.get("http_port"):
            return {
                "host": str(ws_info.get("http_host")),
                "port": int(ws_info.get("http_port")),
                "boot_id": boot_id,
            }
        return None

    def unregister_workspace(self, workspace_root: str) -> None:
        def _upd(data):
            ws = self._normalize_workspace_root(workspace_root)
            data.get("workspaces", {}).pop(ws, None)
        self._update(_upd)

    def touch_daemon(self, boot_id: str) -> None:
        """Update last_seen_ts for a daemon to indicate it is still alive."""
        def _upd(data):
            daemons = data.get("daemons", {})
            if boot_id in daemons:
                daemons[boot_id]["last_seen_ts"] = time.time()
        self._update(_upd)

    def prune_dead(self) -> None:
        """Public method to prune dead daemons and associated workspaces."""
        self._update(self._prune_dead_locked)

    def get_registry_snapshot(self, *, include_dead: bool = False) -> RegistryData:
        """Return a normalized registry snapshot via public API."""
        data = self._load()
        daemons: dict[str, DaemonEntry] = {}
        for boot_id, info in (data.get("daemons") or {}).items():
            coerced = self._coerce_daemon_entry(info)
            if coerced is None:
                continue
            if (not include_dead) and (not self._is_process_alive(coerced.get("pid"))):
                continue
            daemons[str(boot_id)] = dict(coerced)

        valid_boot_ids = set(daemons.keys())
        workspaces: dict[str, WorkspaceEntry] = {}
        for ws, info in (data.get("workspaces") or {}).items():
            coerced = self._coerce_workspace_entry(info)
            if coerced is None:
                continue
            boot_id = str(coerced.get("boot_id") or "")
            if (not include_dead) and boot_id and boot_id not in valid_boot_ids:
                continue
            workspaces[str(ws)] = dict(coerced)
        deployment = self._coerce_deployment_entry(data.get("deployment"))
        if deployment.get("active_boot_id") and deployment.get("active_boot_id") not in valid_boot_ids:
            deployment["active_boot_id"] = ""
        if deployment.get("candidate_boot_id") and deployment.get("candidate_boot_id") not in valid_boot_ids:
            deployment["candidate_boot_id"] = ""
        if deployment.get("old_boot_id") and deployment.get("old_boot_id") not in valid_boot_ids:
            deployment["old_boot_id"] = ""

        return {"version": self.VERSION, "daemons": daemons, "workspaces": workspaces, "deployment": deployment}

    def get_deployment_state(self) -> DeploymentEntry:
        data = self._load()
        return self._coerce_deployment_entry(data.get("deployment"))

    def begin_deploy(self, candidate_boot_id: str, *, expected_active_boot_id: Optional[str] = None) -> DeploymentEntry:
        out: DeploymentEntry = self._empty_deployment()

        def _upd(data):
            nonlocal out
            self._prune_dead_locked(data)
            daemons = data.get("daemons", {}) or {}
            dep = self._coerce_deployment_entry(data.get("deployment"))
            current_active = str(dep.get("active_boot_id") or "")
            if expected_active_boot_id is not None and current_active != str(expected_active_boot_id):
                out = dep
                return
            dep["generation"] = int(dep.get("generation") or 0) + 1
            dep["candidate_boot_id"] = str(candidate_boot_id or "")
            if dep["candidate_boot_id"] and dep["candidate_boot_id"] not in daemons:
                dep["candidate_boot_id"] = ""
            dep["old_boot_id"] = current_active
            dep["state"] = "starting"
            dep["health_fail_streak"] = 0
            dep["rollback_reason"] = ""
            dep["switch_ts"] = 0.0
            data["deployment"] = dep
            out = dep

        self._update(_upd)
        return out

    def mark_candidate_healthy(self, generation: int, candidate_boot_id: str) -> DeploymentEntry:
        out: DeploymentEntry = self._empty_deployment()

        def _upd(data):
            nonlocal out
            dep = self._coerce_deployment_entry(data.get("deployment"))
            if int(dep.get("generation") or 0) != int(generation):
                out = dep
                return
            if str(dep.get("candidate_boot_id") or "") != str(candidate_boot_id or ""):
                out = dep
                return
            dep["state"] = "ready"
            data["deployment"] = dep
            out = dep

        self._update(_upd)
        return out

    def switch_active(self, generation: int, candidate_boot_id: str) -> DeploymentEntry:
        out: DeploymentEntry = self._empty_deployment()

        def _upd(data):
            nonlocal out
            self._prune_dead_locked(data)
            daemons = data.get("daemons", {}) or {}
            dep = self._coerce_deployment_entry(data.get("deployment"))
            if int(dep.get("generation") or 0) != int(generation):
                out = dep
                return
            candidate = str(candidate_boot_id or "")
            if candidate != str(dep.get("candidate_boot_id") or ""):
                out = dep
                return
            if candidate not in daemons:
                out = dep
                return
            active_before = str(dep.get("active_boot_id") or "")
            dep["old_boot_id"] = active_before
            dep["active_boot_id"] = candidate
            dep["state"] = "switched"
            dep["switch_ts"] = time.time()
            dep["health_fail_streak"] = 0
            dep["rollback_reason"] = ""
            for ws, info in (data.get("workspaces", {}) or {}).items():
                if not isinstance(info, dict):
                    continue
                ws_boot = str(info.get("boot_id") or "")
                if ws_boot in {"", active_before}:
                    info["boot_id"] = candidate
                    info["last_active_ts"] = time.time()
                    data["workspaces"][ws] = info
            data["deployment"] = dep
            out = dep

        self._update(_upd)
        return out

    def record_health_failure(
        self,
        generation: int,
        candidate_boot_id: str,
        *,
        reason: str = "",
    ) -> DeploymentEntry:
        out: DeploymentEntry = self._empty_deployment()

        def _upd(data):
            nonlocal out
            dep = self._coerce_deployment_entry(data.get("deployment"))
            if int(dep.get("generation") or 0) != int(generation):
                out = dep
                return
            if str(dep.get("active_boot_id") or "") != str(candidate_boot_id or ""):
                out = dep
                return
            dep["health_fail_streak"] = int(dep.get("health_fail_streak") or 0) + 1
            if reason:
                dep["rollback_reason"] = str(reason)
            data["deployment"] = dep
            out = dep

        self._update(_upd)
        return out

    def rollback_active(self, generation: int, restore_boot_id: str, *, reason: str = "") -> DeploymentEntry:
        out: DeploymentEntry = self._empty_deployment()

        def _upd(data):
            nonlocal out
            self._prune_dead_locked(data)
            daemons = data.get("daemons", {}) or {}
            dep = self._coerce_deployment_entry(data.get("deployment"))
            if int(dep.get("generation") or 0) != int(generation):
                out = dep
                return
            restore = str(restore_boot_id or "")
            if restore and restore in daemons:
                dep["active_boot_id"] = restore
            dep["candidate_boot_id"] = ""
            dep["state"] = "idle"
            dep["health_fail_streak"] = 0
            dep["rollback_reason"] = str(reason or dep.get("rollback_reason") or "")
            for ws, info in (data.get("workspaces", {}) or {}).items():
                if not isinstance(info, dict):
                    continue
                if restore:
                    info["boot_id"] = restore
                    info["last_active_ts"] = time.time()
                    data["workspaces"][ws] = info
            data["deployment"] = dep
            out = dep

        self._update(_upd)
        return out

    def list_daemons(self, *, include_dead: bool = False) -> list[DaemonWithBootId]:
        """List daemon entries, optionally including dead processes."""
        data = self.get_registry_snapshot(include_dead=include_dead)
        out: list[DaemonWithBootId] = []
        for boot_id, info in (data.get("daemons") or {}).items():
            row = dict(info)
            row["boot_id"] = str(boot_id)
            out.append(row)
        out.sort(key=lambda x: float(x.get("last_seen_ts") or 0.0), reverse=True)
        return out

    def get_active_daemons(self) -> list[DaemonWithBootId]:
        """Return live non-draining daemon rows sorted by recency."""
        rows = self.list_daemons(include_dead=False)
        return [r for r in rows if not bool(r.get("draining"))]

    def reset_registry(self) -> None:
        """Reset registry to an empty v2 payload."""
        self._save(self._empty())

    def get_live_daemon_pids(self) -> set[int]:
        """Return alive daemon PIDs currently tracked in registry."""
        data = self.get_registry_snapshot(include_dead=False)
        out: set[int] = set()
        for info in (data.get("daemons") or {}).values():
            if not isinstance(info, dict):
                continue
            try:
                pid = int(info.get("pid") or 0)
            except (TypeError, ValueError):
                continue
            if pid <= 0:
                continue
            if self._is_process_alive(pid):
                out.add(pid)
        return out
