from unittest.mock import MagicMock
from sari.mcp.tools.read_file import execute_read_file
from sari.mcp.tools.get_snippet import execute_get_snippet
from sari.mcp.tools.grep_and_read import execute_grep_and_read
from sari.mcp.tools.index_file import execute_index_file
from sari.mcp.tools.rescan import execute_rescan
from sari.mcp.tools.scan_once import execute_scan_once
from sari.mcp.tools.read_symbol import execute_read_symbol
from sari.mcp.tools.get_callers import execute_get_callers
from sari.mcp.tools.get_implementations import execute_get_implementations
from sari.mcp.tools.get_implementations import execute_get_implementations
from sari.mcp.tools.repo_candidates import execute_repo_candidates
from sari.mcp.tools.save_snippet import execute_save_snippet
from sari.mcp.tools.dry_run_diff import execute_dry_run_diff
from sari.mcp.tools.guide import execute_sari_guide
from sari.mcp.tools.registry import build_default_registry, ToolContext
from sari.mcp.tools._util import resolve_repo_scope
from sari.mcp.policies import PolicyEngine


def test_execute_read_file(tmp_path):
    roots = [str(tmp_path)]
    f = tmp_path / "test.txt"
    f.write_text("hello world")
    db = MagicMock()
    db.read_file.return_value = "hello world"
    from sari.core.workspace import WorkspaceManager
    root_id = WorkspaceManager.root_id(str(tmp_path))
    db_path = f"{root_id}/test.txt"
    args = {"path": db_path}
    resp = execute_read_file(args, db, roots)
    # The content is URL encoded
    import urllib.parse
    assert urllib.parse.quote("hello world") in resp["content"][0]["text"]


def test_execute_read_file_rejects_non_object_args():
    db = MagicMock()
    resp = execute_read_file(["bad-args"], db, ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=read_file ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_execute_read_file_empty_page_sets_returned_zero(tmp_path):
    roots = [str(tmp_path)]
    db = MagicMock()
    db.read_file.return_value = "line1\nline2"
    from sari.core.workspace import WorkspaceManager
    root_id = WorkspaceManager.root_id(str(tmp_path))
    db_path = f"{root_id}/test.txt"

    resp = execute_read_file({"path": db_path, "offset": 99, "limit": 10}, db, roots)
    text = resp["content"][0]["text"]

    assert "PACK1 tool=read_file ok=true" in text
    assert "returned=0" in text


def test_execute_read_file_out_of_scope_error_hides_physical_parent_path(tmp_path):
    outside_file = tmp_path / "secret.txt"
    outside_file.write_text("secret")
    db = MagicMock()

    # roots does not include tmp_path, so this file is out-of-scope.
    resp = execute_read_file({"path": str(outside_file)}, db, ["/tmp/other-root"])
    text = resp["content"][0]["text"]
    import urllib.parse

    assert "PACK1 tool=read_file ok=false code=ERR_ROOT_OUT_OF_SCOPE" in text
    assert urllib.parse.quote(str(outside_file.parent), safe="") not in text


def test_execute_get_snippet(tmp_path):
    roots = [str(tmp_path)]
    f = tmp_path / "code.py"
    f.write_text("line 1\nline 2")
    from sari.core.workspace import WorkspaceManager
    root_id = WorkspaceManager.root_id(str(tmp_path))
    db_path = f"{root_id}/code.py"
    db = MagicMock()
    # Mock for build_get_snippet
    db.list_snippets_by_tag.return_value = [
        {
            "tag": "test",
            "path": db_path,
            "start_line": 1,
            "end_line": 2,
            "content": "line 1\nline 2",
            "id": 1}]
    args = {"tag": "test"}
    resp = execute_get_snippet(args, db, roots)
    assert "PACK1" in resp["content"][0]["text"]


def test_execute_get_snippet_rejects_non_object_args():
    db = MagicMock()
    resp = execute_get_snippet(["bad-args"], db, ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_snippet ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_execute_grep_and_read(tmp_path):
    roots = [str(tmp_path)]
    db = MagicMock()
    logger = MagicMock()
    db.search_files.return_value = [{"path": "root-xxx/file1.txt"}]
    args = {"query": "pattern", "repo": "all"}
    try:
        resp = execute_grep_and_read(args, db, logger, roots)
        assert "PACK1" in resp["content"][0]["text"]
    except Exception:
        pass


def test_execute_grep_and_read_rejects_non_object_args():
    db = MagicMock()
    resp = execute_grep_and_read(["bad-args"], db, ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=grep_and_read ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_execute_grep_and_read_normalizes_scalar_and_boolean_filters(monkeypatch):
    captured = {}

    class _DB:
        def search(self, opts):
            captured["opts"] = opts
            return [], {"total": 0, "total_mode": "exact"}

        def has_legacy_paths(self):
            return False

    monkeypatch.setattr("sari.mcp.tools.grep_and_read.require_db_schema", lambda *_a, **_k: None)

    resp = execute_grep_and_read(
        {
            "query": "hello",
            "file_types": "py",
            "exclude_patterns": "*.min.js",
            "recency_boost": "false",
            "use_regex": "false",
            "case_sensitive": "0",
        },
        _DB(),
        ["/tmp/ws"],
    )
    assert resp.get("isError") is not True
    opts = captured["opts"]
    assert opts.file_types == ["py"]
    assert opts.exclude_patterns == ["*.min.js"]
    assert opts.recency_boost is False
    assert opts.use_regex is False
    assert opts.case_sensitive is False


def test_execute_index_file():
    indexer = MagicMock()
    roots = ["/tmp/ws"]
    args = {"path": "root-123/file.py"}
    resp = execute_index_file(args, indexer, roots)
    assert "PACK1" in resp["content"][0]["text"]


def test_execute_index_file_rejects_non_object_args():
    resp = execute_index_file(["bad-args"], MagicMock(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=index_file ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_execute_rescan():
    indexer = MagicMock()
    args = {}
    resp = execute_rescan(args, indexer)
    assert "PACK1" in resp["content"][0]["text"]


def test_execute_rescan_rejects_non_object_args():
    resp = execute_rescan(["bad-args"], MagicMock())
    text = resp["content"][0]["text"]
    assert "PACK1 tool=rescan ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_execute_scan_once_rejects_non_object_args():
    resp = execute_scan_once(["bad-args"], MagicMock(), MagicMock())
    text = resp["content"][0]["text"]
    assert "PACK1 tool=scan_once ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_execute_rescan_fallback_to_scan_once():
    class _IndexerWithoutRequestRescan:
        indexing_enabled = True
        indexer_mode = "leader"

        def __init__(self):
            self.called = 0

        def scan_once(self):
            self.called += 1

    idx = _IndexerWithoutRequestRescan()
    resp = execute_rescan({}, idx)
    assert "PACK1" in resp["content"][0]["text"]
    assert idx.called == 1


def test_execute_repo_candidates():
    db = MagicMock()
    logger = MagicMock()
    roots = ["/tmp/ws"]
    db.get_repo_stats.return_value = {"repo1": 10}
    args = {"query": "repo1"}
    resp = execute_repo_candidates(args, db, logger, roots)
    assert "repo1" in resp["content"][0]["text"]


def test_execute_dry_run_diff_requires_content(tmp_path):
    roots = [str(tmp_path)]
    target = tmp_path / "foo.py"
    target.write_text("x = 1\n", encoding="utf-8")
    db = MagicMock()
    resp = execute_dry_run_diff({"path": str(target)}, db, roots)
    text = resp["content"][0]["text"]
    assert "ok=false" in text
    assert "code=INVALID_ARGS" in text


def test_execute_dry_run_diff_rejects_non_object_args():
    db = MagicMock()
    resp = execute_dry_run_diff(["bad-args"], db, ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=dry_run_diff ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_execute_dry_run_diff_internal_error_has_reason_code(monkeypatch):
    monkeypatch.setenv("SARI_FORMAT", "json")
    from sari.mcp.tools import dry_run_diff as mod

    def _boom(*_args, **_kwargs):
        raise RuntimeError("unexpected explode")

    monkeypatch.setattr(mod, "build_dry_run_diff", _boom)
    resp = execute_dry_run_diff({"path": "a.py", "content": "x=1"}, MagicMock(), ["/tmp/ws"])
    assert resp["isError"] is True
    assert resp["error"]["code"] == "INTERNAL"
    assert resp["error"]["data"]["reason_code"] == "DRY_RUN_DIFF_FAILED"


def test_execute_sari_guide_rejects_non_object_args():
    resp = execute_sari_guide(["bad-args"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=sari_guide ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_registry_scan_once_handler_passes_logger():
    reg = build_default_registry()
    indexer = MagicMock()
    indexer.indexing_enabled = True
    indexer.status.scanned_files = 0
    indexer.status.indexed_files = 0
    indexer.get_queue_depths.return_value = {
        "fair_queue": 0, "priority_queue": 0, "db_writer": 0}
    indexer.storage.writer.flush.return_value = None

    ctx = ToolContext(
        db=MagicMock(),
        engine=None,
        indexer=indexer,
        roots=["/tmp/ws"],
        cfg=None,
        logger=MagicMock(),
        workspace_root="/tmp/ws",
        server_version="test",
    )

    resp = reg.execute("scan_once", ctx, {})
    assert "PACK1 tool=scan_once ok=true" in resp["content"][0]["text"]


def test_registry_does_not_mark_failed_search_as_search_context():
    reg = build_default_registry()
    policy = PolicyEngine(mode="enforce")
    ctx = ToolContext(
        db=MagicMock(),
        engine=None,
        indexer=MagicMock(),
        roots=["/tmp/ws"],
        cfg=MagicMock(),
        logger=MagicMock(),
        workspace_root="/tmp/ws",
        server_version="test",
        policy_engine=policy,
    )
    resp = reg.execute("search", ctx, {"query": ""})
    assert (resp.get("isError") or "ok=false" in str(resp))
    assert policy.has_search_context() is False


def test_policy_engine_marks_grep_and_read_as_search_context():
    policy = PolicyEngine(mode="enforce")
    policy.mark_action("grep_and_read")
    assert policy.has_search_context() is True


def test_registry_hides_internal_tools_by_default(monkeypatch):
    monkeypatch.delenv("SARI_EXPOSE_INTERNAL_TOOLS", raising=False)
    reg = build_default_registry()
    names = {t["name"] for t in reg.list_tools()}
    assert "scan_once" not in names
    assert "rescan" not in names
    assert "read_file" not in names
    assert "read_symbol" not in names
    assert "get_snippet" not in names
    assert "dry_run_diff" not in names
    assert "call_graph_health" not in names


def test_registry_hides_deprecated_legacy_tools_even_when_internal_exposed(monkeypatch):
    monkeypatch.setenv("SARI_EXPOSE_INTERNAL_TOOLS", "1")
    reg = build_default_registry()
    tools = {t["name"]: t for t in reg.list_tools()}
    assert "read_file" not in tools
    assert "read_symbol" not in tools
    assert "dry_run_diff" not in tools
    assert "save_snippet" not in tools
    assert "get_snippet" not in tools
    assert "archive_context" not in tools
    assert "get_context" not in tools
    assert "call_graph_health" not in tools


def test_registry_legacy_read_file_routes_to_unified_read(monkeypatch):
    reg = build_default_registry()
    captured = {}

    def _fake_read(args, _db, _roots, _logger):
        captured["args"] = dict(args)
        return {"content": [{"text": "PACK1 tool=read ok=true"}]}

    monkeypatch.setattr("sari.mcp.tools.registry.read_tool.execute_read", _fake_read)
    ctx = ToolContext(
        db=MagicMock(),
        engine=None,
        indexer=MagicMock(),
        roots=["/tmp/ws"],
        cfg=MagicMock(),
        logger=MagicMock(),
        workspace_root="/tmp/ws",
        server_version="test",
    )
    reg.execute("read_file", ctx, {"path": "a.py", "offset": 1, "limit": 2})
    assert captured["args"]["mode"] == "file"
    assert captured["args"]["target"] == "a.py"
    assert captured["args"]["offset"] == 1
    assert captured["args"]["limit"] == 2


def test_registry_legacy_read_symbol_routes_to_unified_read(monkeypatch):
    reg = build_default_registry()
    captured = {}

    def _fake_read(args, _db, _roots, _logger):
        captured["args"] = dict(args)
        return {"content": [{"text": "PACK1 tool=read ok=true"}]}

    monkeypatch.setattr("sari.mcp.tools.registry.read_tool.execute_read", _fake_read)
    ctx = ToolContext(
        db=MagicMock(),
        engine=None,
        indexer=MagicMock(),
        roots=["/tmp/ws"],
        cfg=MagicMock(),
        logger=MagicMock(),
        workspace_root="/tmp/ws",
        server_version="test",
    )
    reg.execute("read_symbol", ctx, {"name": "Foo", "path": "a.py"})
    assert captured["args"]["mode"] == "symbol"
    assert captured["args"]["target"] == "Foo"
    assert captured["args"]["path"] == "a.py"


def test_registry_legacy_dry_run_diff_routes_to_unified_read(monkeypatch):
    reg = build_default_registry()
    captured = {}

    def _fake_read(args, _db, _roots, _logger):
        captured["args"] = dict(args)
        return {"content": [{"text": "PACK1 tool=read ok=true"}]}

    monkeypatch.setattr("sari.mcp.tools.registry.read_tool.execute_read", _fake_read)
    ctx = ToolContext(
        db=MagicMock(),
        engine=None,
        indexer=MagicMock(),
        roots=["/tmp/ws"],
        cfg=MagicMock(),
        logger=MagicMock(),
        workspace_root="/tmp/ws",
        server_version="test",
    )
    reg.execute("dry_run_diff", ctx, {"path": "a.py", "content": "x", "against": "HEAD"})
    assert captured["args"]["mode"] == "diff_preview"
    assert captured["args"]["target"] == "a.py"
    assert captured["args"]["content"] == "x"
    assert captured["args"]["against"] == "HEAD"


def test_registry_symbol_tool_schemas_match_runtime_flexibility(monkeypatch):
    reg = build_default_registry()
    tools = {t.name: t for t in reg.list_tools_raw()}

    # read_symbol supports symbol_id/sid without forcing path+name.
    read_symbol_schema = tools["read_symbol"].input_schema
    assert "symbol_id" in read_symbol_schema["properties"]
    assert "sid" in read_symbol_schema["properties"]
    assert "required" not in read_symbol_schema or not read_symbol_schema["required"]

    # caller/implementation tools accept name OR symbol_id-style calls.
    callers_schema = tools["get_callers"].input_schema
    impl_schema = tools["get_implementations"].input_schema
    assert "symbol_id" in callers_schema["properties"]
    assert "sid" in callers_schema["properties"]
    assert "symbol_id" in impl_schema["properties"]
    assert "sid" in impl_schema["properties"]

    # call_graph should allow symbol alias and sid alias.
    cg_schema = tools["call_graph"].input_schema
    assert "symbol" in cg_schema["properties"]
    assert "name" in cg_schema["properties"]
    assert "symbol_id" in cg_schema["properties"]
    assert "sid" in cg_schema["properties"]


def test_registry_includes_unified_read_schema_with_required_constraints():
    reg = build_default_registry()
    tools = {t["name"]: t for t in reg.list_tools()}

    read_schema = tools["read"]["inputSchema"]
    assert read_schema["type"] == "object"
    props = read_schema["properties"]

    assert props["mode"]["type"] == "string"
    assert props["mode"]["enum"] == ["file", "symbol", "snippet", "diff_preview", "ast_edit"]

    for key in (
        "target",
        "path",
        "name",
        "symbol_id",
        "sid",
        "tag",
        "query",
        "content",
        "offset",
        "limit",
        "against",
        "expected_version_hash",
        "old_text",
        "new_text",
        "ast_edit_preview",
        "symbol",
        "symbol_qualname",
        "symbol_kind",
    ):
        assert key in props
        assert "description" in props[key]
    assert props["symbol_kind"]["type"] == "string"
    assert props["symbol_kind"]["enum"] == [
        "function",
        "method",
        "class",
        "interface",
        "struct",
        "trait",
        "enum",
        "module",
    ]

    assert read_schema["required"] == ["mode"]


def test_registry_read_tool_delegates_to_read_file():
    reg = build_default_registry()
    ctx = ToolContext(
        db=MagicMock(),
        engine=None,
        indexer=MagicMock(),
        roots=["/tmp/ws"],
        cfg=MagicMock(),
        logger=MagicMock(),
        workspace_root="/tmp/ws",
        server_version="test",
    )
    ctx.db.read_file.return_value = "hello from unified read"
    from sari.core.workspace import WorkspaceManager
    rid = WorkspaceManager.root_id("/tmp/ws")
    resp = reg.execute(
        "read",
        ctx,
        {"mode": "file", "target": f"{rid}/a.py", "offset": 0, "limit": 1},
    )
    text = resp["content"][0]["text"]
    assert "PACK1 tool=read_file ok=true" in text
    assert "hello%20from%20unified%20read" in text


def test_registry_read_tool_delegates_to_get_snippet(monkeypatch):
    monkeypatch.setenv("SARI_READ_GATE_MODE", "warn")
    reg = build_default_registry()
    ctx = ToolContext(
        db=MagicMock(),
        engine=None,
        indexer=MagicMock(),
        roots=["/tmp/ws"],
        cfg=MagicMock(),
        logger=MagicMock(),
        workspace_root="/tmp/ws",
        server_version="test",
    )
    from sari.core.workspace import WorkspaceManager
    rid = WorkspaceManager.root_id("/tmp/ws")
    ctx.db.list_snippets_by_tag.return_value = [{
        "tag": "demo",
        "path": f"{rid}/a.py",
        "start_line": 1,
        "end_line": 2,
        "content": "x = 1\\ny = 2",
        "id": 1,
    }]
    resp = reg.execute("read", ctx, {"mode": "snippet", "target": "demo"})
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_snippet ok=true" in text


def test_read_symbol_supports_symbol_id_without_path(tmp_path):
    from sari.core.db import LocalSearchDB
    from sari.core.workspace import WorkspaceManager

    root = tmp_path / "ws"
    root.mkdir()
    (root / "main.py").write_text("def hello():\n    return 1\n", encoding="utf-8")
    db = LocalSearchDB(str(root / "sari.db"))
    rid = WorkspaceManager.root_id(str(root))
    db.upsert_root(rid, str(root), str(root.resolve()), label="ws")
    cur = db._write.cursor()
    db.upsert_files_tx(cur,
                       [(f"{rid}/main.py",
                         "main.py",
                         rid,
                         "repo",
                         1,
                         20,
                         "def hello():\n    return 1\n",
                         "h",
                         "hello",
                         1,
                         0,
                         "ok",
                         "",
                         "ok",
                         "",
                         0,
                         0,
                         0,
                         20,
                         "{}")])
    db.upsert_symbols_tx(cur,
                         [("sid-hello",
                           f"{rid}/main.py",
                           rid,
                           "hello",
                           "function",
                           1,
                           2,
                           "def hello():",
                           "",
                           "{}",
                           "",
                           "hello")])
    db._write.commit()

    resp = execute_read_symbol(
        {"symbol_id": "sid-hello"}, db, MagicMock(), [str(root)])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=read_symbol ok=true" in text
    assert "sid=sid-hello" in text


def test_read_symbol_summary_string_false_keeps_full_content(tmp_path, monkeypatch):
    monkeypatch.setenv("SARI_FORMAT", "json")
    from sari.core.db import LocalSearchDB
    from sari.core.workspace import WorkspaceManager

    root = tmp_path / "ws"
    root.mkdir()
    (root / "main.py").write_text("def hello():\n    return 1\n", encoding="utf-8")
    db = LocalSearchDB(str(root / "sari.db"))
    rid = WorkspaceManager.root_id(str(root))
    db.upsert_root(rid, str(root), str(root.resolve()), label="ws")
    cur = db._write.cursor()
    db.upsert_files_tx(cur, [(f"{rid}/main.py", "main.py", rid, "repo", 1, 20, "def hello():\n    return 1\n", "h", "hello", 1, 0, "ok", "", "ok", "", 0, 0, 0, 20, "{}")])
    db.upsert_symbols_tx(cur, [("sid-hello", f"{rid}/main.py", rid, "hello", "function", 1, 2, "def hello():", "", "{}", "", "hello")])
    db._write.commit()

    resp = execute_read_symbol(
        {"symbol_id": "sid-hello", "summary": "false"},
        db,
        MagicMock(),
        [str(root)],
    )
    assert resp.get("isError") is not True
    assert resp["summary_mode"] is False
    assert "return 1" in resp["content"][0]["text"]


def test_execute_read_symbol_rejects_non_object_args():
    db = MagicMock()
    resp = execute_read_symbol(["bad-args"], db, MagicMock(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=read_symbol ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_read_symbol_tolerates_malformed_line_numbers(monkeypatch):
    monkeypatch.setenv("SARI_FORMAT", "pack")
    db = MagicMock()
    monkeypatch.setattr(
        "sari.mcp.tools.read_symbol._symbol_candidates",
        lambda *_a, **_k: [
            {
                "symbol_id": "sid-x",
                "path": "rid-x/a.py",
                "name": "f",
                "kind": "function",
                "line": "bad-line",
                "end_line": "bad-end",
                "qualname": "f",
            }
        ],
    )
    db.read_file.return_value = "def f():\n    return 1\n"
    out = execute_read_symbol({"symbol_id": "sid-x"}, db, MagicMock(), ["/tmp/ws"])
    text = out["content"][0]["text"]
    assert "PACK1 tool=read_symbol ok=true" in text


def test_execute_save_snippet_rejects_non_object_args():
    db = MagicMock()
    resp = execute_save_snippet(["bad-args"], db, ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=save_snippet ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_get_callers_falls_back_to_call_graph(monkeypatch):
    class _Conn:
        def execute(self, *_args, **_kwargs):
            class _Rows:
                def fetchall(self_non):
                    return []
            return _Rows()

    class _DB:
        _read = _Conn()

    monkeypatch.setattr(
        "sari.mcp.tools.get_callers.build_call_graph",
        lambda _args,
        _db,
        _roots: {
            "upstream": {
                "children": [
                    {
                        "path": "root-x/a.py",
                        "name": "callerA",
                        "symbol_id": "sid-a",
                        "line": 10,
                        "rel_type": "calls_heuristic"}]}},
    )
    resp = execute_get_callers({"name": "target"}, _DB(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_callers ok=true" in text
    assert "caller_symbol=callerA" in text
    assert "\nSARI_NEXT: read(" in text
    assert text.count("\nSARI_NEXT: ") == 1


def test_get_callers_rejects_non_object_args():
    resp = execute_get_callers(["bad-args"], MagicMock(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_callers ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_get_callers_uses_search_fallback_when_call_graph_is_empty(monkeypatch):
    class _Conn:
        def execute(self, *_args, **_kwargs):
            class _Rows:
                def fetchall(self_non):
                    return []
            return _Rows()

    class _SymbolDTO:
        def __init__(self):
            self.path = "rid-x/a.py"
            self.name = "target_caller"
            self.symbol_id = "sid-caller"
            self.line = 7

    class _Symbols:
        def search_symbols(self, _query, limit=20, **_kwargs):
            return [_SymbolDTO()]

    class _DB:
        _read = _Conn()
        symbols = _Symbols()

    monkeypatch.setattr(
        "sari.mcp.tools.get_callers.build_call_graph",
        lambda _args, _db, _roots: {"upstream": {"children": []}},
    )
    resp = execute_get_callers({"name": "target", "limit": 10}, _DB(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_callers ok=true" in text
    assert "caller_symbol=target_caller" in text
    assert "rel_type=search_fallback" in text


def test_get_callers_search_fallback_tolerates_non_integer_line(monkeypatch):
    class _Conn:
        def execute(self, *_args, **_kwargs):
            class _Rows:
                def fetchall(self_non):
                    return []
            return _Rows()

    class _SymbolDTO:
        def __init__(self):
            self.path = "rid-x/a.py"
            self.name = "target_caller"
            self.symbol_id = "sid-caller"
            self.line = "bad-line"

    class _Symbols:
        def search_symbols(self, _query, limit=20, **_kwargs):
            return [_SymbolDTO()]

    class _DB:
        _read = _Conn()
        symbols = _Symbols()

    monkeypatch.setattr(
        "sari.mcp.tools.get_callers.build_call_graph",
        lambda _args, _db, _roots: {"upstream": {"children": []}},
    )
    resp = execute_get_callers({"name": "target", "limit": 10}, _DB(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_callers ok=true" in text
    assert "rel_type=search_fallback" in text


def test_get_implementations_uses_search_fallback_when_service_returns_empty(monkeypatch):
    class _Svc:
        def __init__(self, _db):
            pass

        def get_implementations(self, **_kwargs):
            return []

    class _SymbolDTO:
        def __init__(self):
            self.path = "rid-x/impl.py"
            self.name = "TargetImpl"
            self.symbol_id = "sid-impl"
            self.line = 11

    class _Symbols:
        def search_symbols(self, _query, limit=20, **_kwargs):
            return [_SymbolDTO()]

    class _DB:
        symbols = _Symbols()

    monkeypatch.setattr("sari.mcp.tools.get_implementations.SymbolService", _Svc)
    resp = execute_get_implementations({"name": "Target", "limit": 10}, _DB(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_implementations ok=true" in text
    assert "implementer_symbol=TargetImpl" in text
    assert "rel_type=search_fallback" in text


def test_get_implementations_search_fallback_tolerates_non_integer_line(monkeypatch):
    class _Svc:
        def __init__(self, _db):
            pass

        def get_implementations(self, **_kwargs):
            return []

    class _SymbolDTO:
        def __init__(self):
            self.path = "rid-x/impl.py"
            self.name = "TargetImpl"
            self.symbol_id = "sid-impl"
            self.line = "bad-line"

    class _Symbols:
        def search_symbols(self, _query, limit=20, **_kwargs):
            return [_SymbolDTO()]

    class _DB:
        symbols = _Symbols()

    monkeypatch.setattr("sari.mcp.tools.get_implementations.SymbolService", _Svc)
    resp = execute_get_implementations({"name": "Target", "limit": 10}, _DB(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_implementations ok=true" in text
    assert "rel_type=search_fallback" in text


def test_get_callers_repo_filter_applied():
    from sari.core.workspace import WorkspaceManager
    repo_root = "/tmp/target-repo"
    rid = WorkspaceManager.root_id_for_workspace(repo_root)

    class _Conn:
        def execute(self, _sql, params=None):
            class _Rows:
                def __init__(self, rows): self._rows = rows
                def fetchall(self): return self._rows
            # Correctly handle root_id filtering in mock
            if params and any(isinstance(p, str) and p.startswith(rid)
                              for p in params):
                # Return tuples matching the tool's unpacking logic
                return _Rows([(f"{rid}/A.java", "a", "sid-a", 1, "calls")])
            return _Rows([])

    class _DB:
        _read = _Conn()
    resp = execute_get_callers(
        {"name": "foo", "repo": "target-repo"}, _DB(), [repo_root])
    text = resp["content"][0]["text"]
    assert f"caller_path={rid}/A.java" in text


def test_get_callers_sari_next_skips_noisy_candidate_path():
    class _Conn:
        def execute(self, *_args, **_kwargs):
            class _Rows:
                def fetchall(self_non):
                    return [
                        ("/repo/.venv/lib/a.py", "a", "sid-a", 1, "calls"),
                        ("/repo/src/b.py", "b", "sid-b", 2, "calls"),
                    ]

            return _Rows()

    class _DB:
        _read = _Conn()

    resp = execute_get_callers({"name": "foo"}, _DB(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "\nSARI_NEXT: read(" in text
    assert "/repo/src/b.py" in text
    assert "/repo/.venv/lib/a.py" not in text.split("SARI_NEXT: ", 1)[1]


def test_get_implementations_falls_back_to_file_content():
    class _Conn:
        def execute(self, sql, _params=None):
            class _Rows:
                def __init__(self, rows): self._rows = rows
                def fetchall(self): return self._rows
                def fetchone(
                    self): return self._rows[0] if self._rows else None
            if "FROM symbol_relations" in sql:
                return _Rows([])
            if "SELECT path, content FROM files" in sql:
                return _Rows(
                    [("root-x/a/Repo.java", "public interface Repo extends JpaRepository<User,Long> {}")])
            if "SELECT symbol_id, name, line FROM symbols" in sql:
                return _Rows([("sid-repo", "Repo", 1)])
            return _Rows([])

    class _DB:
        _read = _Conn()

    resp = execute_get_implementations(
        {"name": "JpaRepository"}, _DB(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_implementations ok=true" in text
    assert "implementer_symbol=Repo" in text
    assert "\nSARI_NEXT: read(" in text
    assert text.count("\nSARI_NEXT: ") == 1


def test_get_implementations_rejects_non_object_args():
    resp = execute_get_implementations(["bad-args"], MagicMock(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_implementations ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_get_implementations_invalid_limit_is_handled():
    resp = execute_get_implementations({"name": "Iface", "limit": "bad"}, MagicMock(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "PACK1 tool=get_implementations ok=false code=INVALID_ARGS" in text
    assert resp.get("isError") is True


def test_get_implementations_repo_filter_applied():
    from sari.core.workspace import WorkspaceManager
    repo_root = "/tmp/target-repo"
    rid = WorkspaceManager.root_id_for_workspace(repo_root)

    class _Conn:
        def execute(self, sql, params=None):
            class _Rows:
                def __init__(self, rows): self._rows = rows
                def fetchall(self): return self._rows
                def fetchone(
                    self): return self._rows[0] if self._rows else None
            if "FROM symbol_relations" in sql:
                return _Rows([])
            if "SELECT path, content FROM files" in sql:
                if params and any(
                    isinstance(
                        p,
                        str) and p.startswith(rid) for p in params):
                    return _Rows(
                        [(f"{rid}/Repo.java", "interface Repo extends JpaRepository<User,Long> {}")])
                return _Rows([])
            if "SELECT symbol_id, name, line FROM symbols" in sql:
                return _Rows([("sid-repo", "Repo", 1)])
            return _Rows([])

    class _DB:
        _read = _Conn()
    resp = execute_get_implementations(
        {"name": "JpaRepository", "repo": "target-repo"}, _DB(), [repo_root])
    text = resp["content"][0]["text"]
    assert f"implementer_path={rid}/Repo.java" in text


def test_get_implementations_sari_next_skips_noisy_candidate_path(monkeypatch):
    class _Svc:
        def __init__(self, _db):
            pass

        def get_implementations(self, **_kwargs):
            return [
                {"implementer_path": "/repo/site-packages/a.py", "implementer_symbol": "A", "implementer_sid": "sid-a", "rel_type": "impl", "line": 1},
                {"implementer_path": "/repo/src/service.py", "implementer_symbol": "Svc", "implementer_sid": "sid-s", "rel_type": "impl", "line": 2},
            ]

    monkeypatch.setattr("sari.mcp.tools.get_implementations.SymbolService", _Svc)
    resp = execute_get_implementations({"name": "Iface"}, MagicMock(), ["/tmp/ws"])
    text = resp["content"][0]["text"]
    assert "\nSARI_NEXT: read(" in text
    assert "/repo/src/service.py" in text
    assert "/repo/site-packages/a.py" not in text.split("SARI_NEXT: ", 1)[1]


def test_resolve_repo_scope_prefers_workspace_name(tmp_path):
    from sari.core.workspace import WorkspaceManager

    ws_a = tmp_path / "StockManager-v-1.0"
    ws_b = tmp_path / "stock-manager-front"
    ws_a.mkdir()
    ws_b.mkdir()
    repo, root_ids = resolve_repo_scope(
        "stock-manager-front", [str(ws_a), str(ws_b)], db=None)
    assert repo is None
    assert WorkspaceManager.root_id_for_workspace(str(ws_b)) in root_ids
    assert WorkspaceManager.root_id_for_workspace(str(ws_a)) not in root_ids


def test_resolve_repo_scope_uses_repo_bucket_when_not_workspace_name():
    from sari.core.workspace import WorkspaceManager
    ws_a = "/tmp/ws-a"
    ws_b = "/tmp/ws-b"
    rid_a = WorkspaceManager.root_id_for_workspace(ws_a)
    rid_b = WorkspaceManager.root_id_for_workspace(ws_b)

    class _Conn:
        def execute(self, sql, params=None):
            class _Rows:
                def __init__(self, rows):
                    self._rows = rows

                def fetchall(self_non):
                    return self_non._rows
            if "FROM files" in sql:
                return _Rows([(rid_a,), (rid_b,)])
            if "FROM roots" in sql:
                return _Rows([])
            return _Rows([])

    class _DB:
        _read = _Conn()

    repo, root_ids = resolve_repo_scope("src", [ws_a, ws_b], db=_DB())
    assert repo == "src"
    assert root_ids
