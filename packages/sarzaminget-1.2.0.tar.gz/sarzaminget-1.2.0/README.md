# `sarzaminget`
IR Downloader

## Sites
* [Aparat]
* [Sarzamin Download]
* [Soft98]
* [p30download]
* [dlrozaneh]
* [mp4.ir]

[Aparat]: https://aparat.com
[Sarzamin Download]: https://sarzamindownload.com
[Soft98]: https://soft98.ir
[p30download]: https://p30download.ir
[dlrozaneh]: https://dlrozaneh.ir
[mp4.ir]: https://mp4.ir

<!--
SPDX-License-Identifier: CC0-1.0
SPDX-FileCopyrightText: 2025 NexusSfan <nexussfan@duck.com>
-->