#!/usr/bin/env python
"""CLI entrypoint for sas2parquet."""
import argparse
import sys
from pathlib import Path
from .convert import main as _convert_main  # Import your existing main()

def main():
    parser = argparse.ArgumentParser(description="SAS to Parquet converter")
    parser.add_argument("sas_file", nargs="?", help="Single SAS file to convert")
    parser.add_argument("parquet_file", nargs="?", help="Output Parquet file")
    parser.add_argument("--dir-mode", action="store_true", 
                       help="Process entire SAS_INPUT_DIR (ignores file args)")
    
    args = parser.parse_args()
    
    # Patch sys.argv for your convert.main() if single file mode
    if args.sas_file and not args.dir_mode:
        sys.argv = [sys.argv[0], str(Path(args.sas_file)), str(Path(args.parquet_file))]
    
    _convert_main()

if __name__ == "__main__":
    main()