# sas2parquet

[![PyPI version](https://badge.fury.io/py/sas2parquet.svg)](https://pypi.org/project/sas2parquet/)
[![Python versions](https://img.shields.io/pypi/pyversions/sas2parquet.svg)](https://pypi.org/project/sas2parquet/)
[![License](https://img.shields.io/pypi/l/sas2parquet.svg)](LICENCE)

**The ultimate SAS (.sas7bdat) to Parquet converter** - handles problematic files that fail with standard tools. Automatic encoding detection, intelligent type inference, schema repair, and pixel-perfect validation.

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔄 **Auto Encoding** | Detects UTF-8, Latin1, CP1252 from metadata/fallback |
| 🧠 **Smart Types** | Infers datetime, numeric, string with 20+ fallback attempts |
| ✅ **Validation** | Compares SAS vs Parquet chunk-by-chunk (numeric + string) |
| 📊 **Memory Safe** | Chunked processing (96GB RAM optimized, configurable) |
| 💾 **ZSTD** | Level 6 compression for maximum efficiency |
| 📝 **Detailed Logs** | Mismatch reports + full conversion trace |
| 🎯 **Two Modes** | Single file OR recursive directory processing |

## Quick Start

### Install
```bash
pip install sas2parquet
```

### Single File
```bash
sas2parquet input.sas output.parquet
```

### Batch Directory (Recommended)
```bash
sas2parquet --dir-mode
```

## 📁 Directory Mode (Default Workflow)

### How it works

- You provide a `sasdata/` directory containing all `.sas7bdat` files (including nested subfolders).
- The tool automatically creates a `parquetdata/` directory in the same parent folder as `sasdata/`.
- All files are converted to Parquet and written into `parquetdata/`, mirroring the original folder structure.

```text
your-project/
├── sasdata/              # ← Put your .sas7bdat files here
│   ├── file1.sas7bdat
│   └── subfolder/
│       └── nested.sas7bdat
├── parquetdata/          # ← AUTO-CREATED (mirrors sasdata/)
│   ├── file1.parquet
│   └── subfolder/
│       └── nested.parquet
└── logging/             # ← AUTO-CREATED (detailed logs)
    └── conversion_20260205_1145.log
```

Just run:
```bash
sas2parquet --dir-mode
```

## 🛠️ CLI Reference
```bash
sas2parquet --help
```

```text
usage: sas2parquet [-h] [--dir-mode] [sas_file] [parquet_file]

Robust SAS to Parquet converter with validation
```

## 📊 Example Output
```text
🚀 SAS → Parquet Hybrid Fix & Validate (full folder)
Found 3 files.
============================================================
...
```

## ⚙️ Configuration (Advanced)

Edit `src/sas2parquet/convert.py` constants:

```python
AVAILABLE_RAM_GB = 96
RAM_USAGE_FACTOR = 0.5
ZSTD_COMPRESSION_LEVEL = 6
MIN_CHUNK_SIZE = 100_000
MAX_CHUNK_SIZE = 10_000_000
```

## 🧪 Validation Details
Each file undergoes 4-stage validation:
1. Metadata
2. Exact counts
3. Column order
4. Value comparison

## 📄 License
MIT License
