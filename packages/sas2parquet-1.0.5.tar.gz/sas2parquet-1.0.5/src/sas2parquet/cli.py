#!/usr/bin/env python
"""
CLI entrypoint for sas2parquet.
"""

import argparse
import sys
from pathlib import Path
import importlib.metadata

try:
    __version__ = importlib.metadata.version("sas2parquet")
except importlib.metadata.PackageNotFoundError:
    __version__ = "dev"

from .convert import main as convert_dir, reconvert_file_ultimate


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="sas2parquet",
        description="SAS to Parquet converter with validation",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    # Backward compatibility (optional)
    parser.add_argument(
        "--dir-mode",
        "-d",
        action="store_true",
        help="(Backward compatible) Treat input as a directory. "
             "If no path is provided, defaults to ./sasdata",
    )

    parser.add_argument(
        "path",
        nargs="?",
        help="Path to a .sas7bdat file OR a directory containing SAS files (recursively).",
    )

    parser.add_argument(
        "--out",
        "-o",
        default=None,
        help="Output Parquet file (file mode) OR output directory (dir mode). "
             "If omitted, dir mode uses sibling 'parquetdata/'.",
    )

    parser.add_argument(
        "--log-dir",
        default=None,
        help="Directory where logs are written (dir mode). "
             "If omitted, uses sibling 'logging/'.",
    )

    args = parser.parse_args()

    # -----------------------------
    # Resolve input path
    # -----------------------------
    if args.dir_mode and args.path is None:
        # Old behavior: default to ./sasdata
        p = Path("sasdata").expanduser().resolve()
    else:
        if args.path is None:
            parser.print_help()
            sys.exit(1)
        p = Path(args.path).expanduser().resolve()

    if not p.exists():
        print(f"❌ Path not found: {p}")
        sys.exit(2)

    # -----------------------------
    # Directory mode
    # -----------------------------
    if p.is_dir():
        out_dir = Path(args.out).expanduser().resolve() if args.out else None
        log_dir = Path(args.log_dir).expanduser().resolve() if args.log_dir else None

        rc = convert_dir(
            p,
            parquet_output_dir=out_dir,
            log_dir=log_dir,
        )
        sys.exit(rc)

    # -----------------------------
    # File mode
    # -----------------------------
    if p.is_file():
        if p.suffix.lower() != ".sas7bdat":
            print(f"❌ Not a .sas7bdat file: {p.name}")
            sys.exit(2)

        if args.out:
            out_file = Path(args.out).expanduser().resolve()
        else:
            out_file = p.with_suffix(".parquet")

        success = reconvert_file_ultimate(p, out_file)
        sys.exit(0 if success else 1)

    print(f"❌ Unsupported path type: {p}")
    sys.exit(2)


if __name__ == "__main__":
    main()