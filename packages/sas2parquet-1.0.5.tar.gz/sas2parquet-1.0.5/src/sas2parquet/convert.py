import os
import gc
import re
import warnings
import traceback
import sys
from pathlib import Path
from datetime import datetime
import pandas as pd
import polars as pl
import pyarrow as pa
import pyarrow.parquet as pq
import pyreadstat

warnings.simplefilter(action='ignore', category=FutureWarning)

KNOWN_DATETIME_COLUMNS = [
    'RPNA_DATE_UTC','RPNA_TIME_UTC','RPA_DATE_UTC','TIMESTAMP_UTC',
    'EVENT_START_DATE_UTC','EVENT_END_DATE_UTC',
    'REPORTING_START_DATE_UTC','REPORTING_END_DATE_UTC',
    'RANGE_START','RANGE_END','TTIMESTAMP_UTC','RRANGE_START'
]

# SAS formats that represent *names*, not actual dates/times
NAME_LIKE_SAS_FORMAT_TOKENS = {
    "DAY", "DAYNAME", "DOWNAME", "WEEKDAY",
    "MONNAME", "MONTH", "MONTHNAME",
    "QTR", "QTRR", "YYQ", "YYQC", "YYQP",
}

COLUMNS_TO_FORCE_AS_STRING = ['MATURITY','EARNINGS_TYPE']
ENCODING_TEST_ORDER = ['utf-8','latin1','cp1252']
ZSTD_COMPRESSION_LEVEL = 6

AVAILABLE_RAM_GB = 96
RAM_USAGE_FACTOR = 0.5
ESTIMATED_BYTES_PER_CELL = 10
MIN_CHUNK_SIZE = 100_000
MAX_CHUNK_SIZE = 10_000_000


# --- Logger ---
class Logger:
    def __init__(self, path: Path):
        self.terminal = sys.stdout
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.logfile = open(path, 'w', encoding='utf-8')

    def write(self, msg):
        self.terminal.write(msg)
        self.logfile.write(msg)

    def flush(self):
        self.terminal.flush()
        self.logfile.flush()

    def close(self):
        self.logfile.close()


# --- Mismatch report ---
def create_diff_report(sas_s: pl.Series, par_s: pl.Series, mask: pl.Series) -> str:
    cnt = int(mask.sum())
    sas_ex = sas_s.filter(mask).head(5).alias(f"{sas_s.name}_SAS")
    par_ex = par_s.filter(mask).head(5).alias(f"{par_s.name}_PARQ")
    df_ex = pl.DataFrame([sas_ex, par_ex])
    return f"Mismatch in '{sas_s.name}' ({cnt} rows):\n{df_ex}"


# --- Deep comparison ---
def compare_and_report_diffs(sas_path: Path, parquet_path: Path):
    print(f"\n🔎 Comparing {sas_path.name} ↔ {parquet_path.name}")
    issues = []
    try:
        _, sas_meta = pyreadstat.read_sas7bdat(sas_path, metadataonly=True)
        pq_meta = pq.read_metadata(parquet_path)

        # 1) metadata dims
        if (sas_meta.number_rows != pq_meta.num_rows
            or sas_meta.number_columns != pq_meta.num_columns):
            return "❌ MISMATCH", [
                f"Dimension mismatch: SAS=({sas_meta.number_rows},{sas_meta.number_columns}) "
                f"vs Parquet=({pq_meta.num_rows},{pq_meta.num_columns})"
            ]

        # 2) actual row-count
        CH = MAX_CHUNK_SIZE
        sas_cnt = sum(c.shape[0] for c in pd.read_sas(sas_path, chunksize=CH))
        pq_cnt  = sum(b.num_rows for b in
                      pq.ParquetFile(parquet_path).iter_batches(batch_size=CH))
        if sas_cnt != pq_cnt:
            return "❌ MISMATCH", [f"Row count mismatch: SAS={sas_cnt} vs Parquet={pq_cnt}"]

        # 3) column order
        sas_cols = sas_meta.column_names
        pq_cols  = pq_meta.schema.names
        if sas_cols != pq_cols:
            return "❌ MISMATCH", [
                f"Column/order mismatch:\n  SAS:     {sas_cols}\n  Parquet: {pq_cols}"
            ]

        # 4) chunked compare
        sas_it = pd.read_sas(sas_path, chunksize=CH)
        pq_it  = pq.ParquetFile(parquet_path).iter_batches(batch_size=CH)
        chunk_i = 0

        offset_us = int((pd.Timestamp("1970-01-01") -
                         pd.Timestamp("1960-01-01")).total_seconds() * 1e6)

        int_types   = {pl.Int8,pl.Int16,pl.Int32,pl.Int64,
                       pl.UInt8,pl.UInt16,pl.UInt32,pl.UInt64}
        float_types = {pl.Float32,pl.Float64}
        num_types   = int_types | float_types

        while True:
            chunk_i += 1
            sas_chunk = next(sas_it, None)
            pq_batch  = next(pq_it, None)
            if sas_chunk is None and pq_batch is None:
                break
            if sas_chunk is None or pq_batch is None:
                issues.append("Chunk count mismatch")
                break

            psas = pl.from_pandas(sas_chunk)
            ppq_raw = pl.from_arrow(pq_batch)

            # normalize empty strings -> nulls in parquet side
            ppq = ppq_raw.with_columns([
                pl.when(pl.col(c) == "").then(None).otherwise(pl.col(c)).alias(c)
                for c, d in zip(ppq_raw.columns, ppq_raw.dtypes)
                if d == pl.Utf8
            ])

            # 4a) numeric comparison
            for col in psas.columns:
                scol = psas.get_column(col)
                pcol = ppq.get_column(col)
                ds, dp = scol.dtype, pcol.dtype
                if ds in num_types and dp in num_types:
                    if ds in float_types and dp in int_types:
                        pcol = pcol.cast(ds)
                    elif dp in float_types and ds in int_types:
                        scol = scol.cast(dp)
                    mask = (scol != pcol) | (scol.is_null() != pcol.is_null())
                    if mask.any():
                        issues.append(f"Chunk {chunk_i} numeric mismatch '{col}'")
                        issues.append(create_diff_report(scol, pcol, mask))
                    continue

            # 4b) datetime & string
            for col in psas.columns:
                sser = psas.get_column(col)
                pser = ppq.get_column(col)

                if sser.dtype == pl.Datetime("us") and pser.dtype == pl.Datetime("us"):
                    raw = sas_chunk[col]
                    if pd.api.types.is_datetime64_ns_dtype(raw):
                        raw_us = raw.view('int64') // 1000
                    else:
                        raw_us = (raw * 1e6 + offset_us).astype('Int64')
                    pus = pser.cast(pl.Int64)
                    if not raw_us.equals(pus.to_pandas()):
                        msk = pus.to_pandas() != raw_us
                        issues.append(f"Chunk {chunk_i} epoch mismatch '{col}'")
                        issues.append(create_diff_report(
                            pl.Series(raw_us, name=col + "_SAS_us"),
                            pus.alias(col + "_PARQ_us"),
                            pl.Series(msk)
                        ))
                        continue

                s_str = sser.cast(pl.Utf8)
                p_str = pser.cast(pl.Utf8)
                mask  = (s_str != p_str) | (s_str.is_null() != p_str.is_null())
                m0    = s_str.str.ends_with(" 00:00:00.000")
                d0    = p_str.str.contains(r'^\d{4}-\d{2}-\d{2}$')
                sd    = s_str.str.slice(0, 10) == p_str
                mask &= ~(m0 & d0 & sd)
                if mask.any():
                    issues.append(
                        f"Chunk {chunk_i} value mismatch '{col}' ({int(mask.sum())} rows)"
                    )
                    issues.append(create_diff_report(s_str, p_str, mask))

            if issues:
                break

        return ("✔️ IDENTICAL", []) if not issues else ("❌ MISMATCH", issues)

    except Exception as e:
        return "❗ CRITICAL ERROR", [str(e), traceback.format_exc()]
    finally:
        gc.collect()


# --- Reconversion + validation ---
def reconvert_file_ultimate(sas_path: Path, parquet_path: Path) -> bool:
    print(f"🛠️ Fixing {sas_path.name}...")

    _, meta0 = pyreadstat.read_sas7bdat(sas_path, metadataonly=True)
    enc0 = getattr(meta0, 'file_encoding', None)
    if enc0:
        encoding = enc0
        print(f"   Detected encoding from metadata: {encoding}")
    else:
        encoding = None
        for e in ENCODING_TEST_ORDER:
            try:
                pyreadstat.read_sas7bdat(sas_path, metadataonly=True, encoding=e)
                encoding = e
                break
            except Exception:
                pass
        if not encoding:
            print("   ❌ Unable to detect encoding; skipping")
            return False
        print(f"   Fallback encoding: {encoding}")

    cols = meta0.column_names
    read_types = getattr(meta0, 'readstat_variable_types', {}) or {}

    fmt_map = {}
    if hasattr(meta0, 'formats'):
        for name, fmt in zip(meta0.column_names, meta0.formats):
            fmt_map[name] = fmt or ""

    # infer content types
    content, inf, cnt = {}, {}, 0
    it = pd.read_sas(sas_path, chunksize=MIN_CHUNK_SIZE, encoding=encoding)
    for chunk in it:
        tbl = pa.Table.from_pandas(chunk.convert_dtypes(), preserve_index=False)
        for f in tbl.schema:
            inf.setdefault(f.name, []).append(f.type)
        cnt += 1
        if cnt >= 5:
            break
    for c in cols:
        ts = inf.get(c, [])
        content[c] = ts[0] if len(set(ts)) == 1 else pa.string()

    meta_types = {
        c: (pa.float64() if read_types.get(c) == 'double' else pa.string())
        for c in cols
    }

    special_up = {x.upper() for x in KNOWN_DATETIME_COLUMNS + COLUMNS_TO_FORCE_AS_STRING}
    conflicts  = [c for c in cols if c.upper() not in special_up and meta_types[c] != content[c]]
    strat = 'metadata-first' if len(conflicts) <= 5 else 'content-first'
    print(f"   Strategy={strat}, conflicts={len(conflicts)}")

    overrides = {}
    for attempt in range(1, 21):
        print(f"   Attempt {attempt}…")
        fields = []
        for c in cols:
            if read_types.get(c) == 'double':
                at = pa.float64()
            else:
                cu = c.upper()
                if cu in {x.upper() for x in COLUMNS_TO_FORCE_AS_STRING}:
                    at = pa.string()
                else:
                    fmt = (fmt_map.get(c, "") or "").upper()

                    # If the SAS format implies a *name* (Monday/June/etc.), force string
                    if any(tok in fmt for tok in NAME_LIKE_SAS_FORMAT_TOKENS):
                        at = pa.string()

                    # Otherwise treat real date/time/datetime as temporal
                    elif (cu in {x.upper() for x in KNOWN_DATETIME_COLUMNS}
                        or "DATETIME" in fmt
                        or re.search(r"\bDATE\b", fmt)
                        or re.search(r"\bTIME\b", fmt)):
                        if "DATE" in fmt and "DATETIME" not in fmt:
                            at = pa.date32()
                        elif "TIME" in fmt and "DATETIME" not in fmt:
                            at = pa.time64("ms")
                        else:
                            at = pa.timestamp("ms")

                    else:
                        at = pa.string()

            if c in overrides:
                at = overrides[c]
            fields.append(pa.field(c, at))

        schema = pa.schema(fields)

        tgt       = int(AVAILABLE_RAM_GB * (1024**3) * RAM_USAGE_FACTOR)
        row_bytes = meta0.number_columns * ESTIMATED_BYTES_PER_CELL or 1
        cs        = max(MIN_CHUNK_SIZE, min(MAX_CHUNK_SIZE, int(tgt / row_bytes)))

        parquet_path.parent.mkdir(parents=True, exist_ok=True)
        writer = pq.ParquetWriter(
            parquet_path,
            schema,
            compression='zstd',
            compression_level=ZSTD_COMPRESSION_LEVEL
        )
        try:
            for chunk in pd.read_sas(sas_path, chunksize=cs, encoding=encoding):
                writer.write_table(
                    pa.Table.from_pandas(chunk, schema=schema, preserve_index=False)
                )
            writer.close()
            print("   ✅ Conversion succeeded")

            print("   🔍 Full Parquet validation...")
            try:
                pf = pq.ParquetFile(parquet_path)
                total_rows = 0
                num_groups = pf.metadata.num_row_groups
                batch_count = 0
                for batch in pf.iter_batches():
                    total_rows += batch.num_rows
                    batch_count += 1
                print(f"   ✅ Parquet fully validated: {total_rows:,} rows across {num_groups} groups ({batch_count} batches)")
                pf.close()
            except Exception as e:
                print(f"   ❌ Parquet validation failed: {e}")
                return False

            st, dt = compare_and_report_diffs(sas_path, parquet_path)
            print(f"   🔍 Validation: {st}")
            for d in dt:
                print("     -", d.replace("\n", "\n       "))
            return True

        except (pa.lib.ArrowTypeError, pa.lib.ArrowNotImplementedError) as e:
            writer.close()
            mm = re.search(r"column\s+`?(\w+)`?", str(e))
            if mm:
                bad = mm.group(1)
                print(f"   ⚠️ Override '{bad}' and retry…")
                try:
                    df0 = next(pd.read_sas(sas_path, chunksize=MIN_CHUNK_SIZE, encoding=encoding))
                    itype = pa.Table.from_pandas(df0[[bad]]).schema.field(bad).type
                    overrides[bad] = itype
                except Exception:
                    overrides[bad] = pa.string()
                continue
            else:
                print("   ❌ Unrecoverable:", e)
                break

        except Exception:
            writer.close()
            print("   ❌ Conversion failed:", traceback.format_exc())
            break

    print(f"   ❌ All attempts failed for {sas_path.name}")
    return False


def default_parquet_dir_for(sas_input_dir: Path) -> Path:
    # sibling parquetdata/ next to sas_input_dir
    return sas_input_dir.parent / "parquetdata"


def default_log_dir_for(sas_input_dir: Path) -> Path:
    # sibling logging/ next to sas_input_dir
    return sas_input_dir.parent / "logging"


def parquet_path_for_sas(sas_file: Path, sas_input_dir: Path, parquet_output_dir: Path) -> Path:
    rel = sas_file.relative_to(sas_input_dir)

    if rel.parent == Path("."):
        return (parquet_output_dir / rel.name).with_suffix(".parquet")

    parquet_dirs = [f"{p}_parquet" for p in rel.parent.parts]
    return (parquet_output_dir.joinpath(*parquet_dirs) / rel.name).with_suffix(".parquet")


# --- Main loop (directory mode) ---
def main(
    sas_input_dir: Path,
    parquet_output_dir: Path | None = None,
    log_dir: Path | None = None,
) -> int:
    sas_input_dir = Path(sas_input_dir).expanduser().resolve()
    if not sas_input_dir.exists() or not sas_input_dir.is_dir():
        print(f"❌ Input directory not found or not a directory: {sas_input_dir}")
        return 2

    parquet_output_dir = (Path(parquet_output_dir).expanduser().resolve()
                          if parquet_output_dir else default_parquet_dir_for(sas_input_dir))
    log_dir = (Path(log_dir).expanduser().resolve()
               if log_dir else default_log_dir_for(sas_input_dir))

    log_file_path = log_dir / f"conversion_{datetime.now():%Y%m%d_%H%M%S}.log"

    orig = sys.stdout
    sys.stdout = Logger(log_file_path)
    try:
        print("🚀 SAS → Parquet Hybrid Fix & Validate (full folder)\n")
        print(f"Input:   {sas_input_dir}")
        print(f"Output:  {parquet_output_dir}")
        print(f"Logs:    {log_file_path}\n")

        files = list(sas_input_dir.rglob("*.sas7bdat"))
        if not files:
            print("❌ No SAS files found. Exiting.")
            return 1

        print(f"Found {len(files)} files.\n" + "="*60)
        ok = 0
        bad = 0

        for sas in files:
            rel = sas.relative_to(sas_input_dir)
            print(f"\n🗂 Processing: {rel}")

            pqf = parquet_path_for_sas(sas, sas_input_dir, parquet_output_dir)
            success = reconvert_file_ultimate(sas, pqf)

            if success:
                ok += 1
            else:
                bad += 1

            print("-"*60)

        print(f"\n✅ Done. Success={ok}, Failed={bad}. See log at: {log_file_path}")
        return 0 if bad == 0 else 1

    finally:
        sys.stdout.close()
        sys.stdout = orig