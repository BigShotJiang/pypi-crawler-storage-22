# Instrumentation

The instrumentation package provides automatic instrumentation for Langroid agents and HTTP libraries, enabling observability and policy enforcement without modifying application code.

Currently, only dependencies within framework code are tracked automatically; in the long run, the instrumentation should support more sophisticated dependency inference (e.g. via static or dynamic analysis).

## Design

Instrumentation works by monkey-patching key methods in target libraries:

- **Langroid**: Patches `Agent` and `ChatAgent` responders, `Task` `init()` and `result()`, and related methods to record messages to the observability graph and check tool call authorization
- **HTTP Libraries**: Patches `requests.Session.request()` and `httpx.Client.request()` to route requests through the reference monitor

In addition, the instrumentation automatically configures OpenTelemetry to log fine-grained information on execution such as logs, exceptions, and tracebacks.

```
┌──────────────────────────────────────────────────────────────────────┐
│                        Application Code                              │
│  agent.llm_response()          requests.get("https://api.openai.com")│
└──────────┬────────────────────────────────────┬──────────────────────┘
           │                                    │
           │ (patched)                          │ (patched)
           ▼                                    ▼
┌─────────────────────┐              ┌─────────────────────┐
│ Langroid            │              │ HTTP                │
│ Instrumentation     │              │ Instrumentation     │
│ - Record events     │              │ - Route via RM      │
│ - Check tool auth   │              │ - Stream response   │
└──────────┬──────────┘              └──────────┬──────────┘
           │                                    │
           ▼                                    ▼
┌─────────────────────┐              ┌─────────────────────┐
│ Observability       │              │ Reference Monitor   │
│ Server              │              │                     │
└─────────────────────┘              └─────────────────────┘
```

## Usage

Usage is as follows:
```python
from instrumentation import instrument, configure, otel

# Optional: configure instrumentation
configure(
    auth_hook=OIDCAuthHook(
        token_url="https://domain.okta.com/oauth2/...",
        client_id="my-service",
        client_secret="secret",
    ),
    log_denials=True,
)

# Optional: configure OTel
otel.configure_otel(otel.OTelConfig(
   service_name = "my-service",
   use_logfire = True,
   log_level = "DEBUG",
)

# Enable all instrumentation (HTTP + Langroid)
instrument()

# Or, instrument HTTP only:
instrument(http=True, langroid=False)

# Your application code works normally
import requests
response = requests.get("https://api.openai.com/v1/models")
# ^ This request is automatically routed through the reference monitor
```

Much of the configuration can be set via environment variables, see [this section](#environment-variables).

The instrumentation supports the auth hooks defined in `observability_common.auth_hooks`, including API keys, mTLS (no hook required, but the servers must be configured to require clent credentials), and various OIDC authentication schemes (client credentials, PKCE, ...).

## Components

### HTTP Instrumentation (`http.py`)

Routes HTTP requests through the reference monitor:

```python
from instrumentation import instrument_http

instrument_http()

# Now all requests/httpx calls go through the reference monitor
import requests
response = requests.post(
    "https://api.openai.com/v1/chat/completions",
    json={"model": "gpt-4", "messages": [...]},
)
```

The reference monitor will then:
1. Check authorization
2. If authorized, apply request tranforms, e.g. API key injection
3. Proxy to OpenAI
4. Stream response back

### Langroid Instrumentation (`langroid.py`)

Records agent messages and checks tool authorization:

```python
from instrumentation import instrument_langroid

instrument_langroid()

# Agent methods are automatically instrumented
agent = MyAgent(config)
response = agent.llm_response("Hello")
# ^ This records the message and its dependencies to the observability graph

# Tool calls are checked before execution
result = agent.agent_response(tool_message)
# ^ If the tool call is denied by policy, an error is returned
```

### Feedback Handling (`feedback.py`)

Collect and display authorization feedback to users:

```python
from instrumentation import configure, FeedbackAccumulator

def feedback_callback(accumulator: FeedbackAccumulator, output, agent):
    """Called after each agent response with any accumulated denials."""
    if accumulator.has_denials():
        feedback = accumulator.format_for_llm()
        print(f"Authorization issues:\n{feedback}")
        # Optionally append to agent output
        if output:
            output.content += f"\n\n{feedback}"

configure(feedback_callback=feedback_callback)
```

the examples illustrate usage in `examples/malade/malade/utils/observability_rm.py` and `examples/information-flow/information_flow/main.py`.

## Configuration Options

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `REFERENCE_MONITOR_URL` | Reference monitor gRPC address | `localhost:10089` |
| `OBSERVABILITY_URL` | Observability server gRPC address | `localhost:10085` |
| `TLS_CA_PATH` | CA certificate path | None |
| `TLS_CERT_PATH` | Client certificate path (mTLS) | None |
| `TLS_KEY_PATH` | Client key path (mTLS) | None |

See `instrumentation/config.py` and `instrumentation/otel/config.py` for all options.

## Code Structure

| File | Description |
|------|-------------|
| `instrumentation/__init__.py` | Main entry point, `instrument()` function |
| `instrumentation/http.py` | HTTP library patching |
| `instrumentation/langroid.py` | Langroid agent patching |
| `instrumentation/config.py` | Configuration management |
| `instrumentation/feedback.py` | Denial feedback accumulation |
| `instrumentation/rm_client.py` | Reference monitor gRPC client |
| `instrumentation/otel/` | OpenTelemetry integration |

## Interaction with Other Services

- **Reference Monitor**: HTTP requests are proxied through the reference monitor for authorization and credential injection
- **Observability Server**: Agent messages and dependencies are recorded to the observability graph
