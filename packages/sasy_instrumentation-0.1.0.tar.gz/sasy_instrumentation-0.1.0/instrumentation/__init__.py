"""
Instrumentation for Langroid and HTTP libraries.

This package provides:
- Langroid agent/task instrumentation with observability and policy enforcement
- Tau2 agent instrumentation with observability and policy enforcement
- HTTP library patching (requests, httpx) that routes through the reference monitor
- Tool call authorization checking
- OpenTelemetry configuration and span exporter

Usage:
    # Instrument HTTP, Langroid, and Tau2 (recommended)
    from instrumentation import instrument
    instrument()

    # Or selectively enable instrumentation
    instrument(http=True, langroid=False, tau2=False)  # HTTP only
    instrument(http=False, langroid=True, tau2=False)  # Langroid only
    instrument(http=False, langroid=False, tau2=True)  # Tau2 only

    # Instrument HTTP libraries to route through reference monitor
    from instrumentation import instrument_http
    instrument_http()

    # Instrument Langroid for observability and policy enforcement
    from instrumentation import instrument_langroid
    instrument_langroid()

    # Instrument Tau2 for observability and policy enforcement
    from instrumentation import instrument_tau2
    instrument_tau2()

    # Check tool call authorization manually
    from instrumentation import check_tool_call
    response = check_tool_call(fn_name="my_tool", args='{"key": "value"}')
    if not response.authorized:
        # Handle denial
        pass

    # Configure OTel
    from instrumentation import otel
    otel.configure_otel()
"""

from typing import TYPE_CHECKING, Optional

from . import otel
from .http import instrument as _instrument_http
from .langroid import instrument as instrument_langroid
from .tau2 import instrument as instrument_tau2
from .config import configure, get_config, InstrumentationConfig, FeedbackCallback
from .feedback import (
    FeedbackAccumulator,
    get_current_feedback,
    add_denial,
    add_tool_denial,
)
from .rm_client import check_tool_call

if TYPE_CHECKING:
    from .http import AuthHook

# Re-export for convenience
instrument_http = _instrument_http


def instrument(
    http: bool = True,
    langroid: bool = True,
    tau2: bool = False,
    *,
    reference_monitor_url: Optional[str] = None,
    ca_path: Optional[str] = None,
    cert_path: Optional[str] = None,
    key_path: Optional[str] = None,
    auth_hook: Optional["AuthHook"] = None,
) -> None:
    """
    Instrument HTTP libraries and/or Langroid for observability and policy enforcement.

    This is the main entry point for enabling instrumentation. By default, it enables
    both HTTP and Langroid instrumentation.

    Args:
        http: Enable HTTP library instrumentation (requests, httpx). Routes HTTP
            requests through the reference monitor for policy enforcement and
            credential injection. Default: True.
        langroid: Enable Langroid instrumentation. Records agent messages and
            dependencies to the observability graph, and enforces tool call
            authorization. Default: True.
        tau2: Enable tau2 instrumentation, as with Langroid. Default: False.
        reference_monitor_url: Reference monitor server URL. If not provided,
            uses REFERENCE_MONITOR_URL environment variable or default.
        ca_path: Path to CA certificate for TLS. If not provided, uses
            TLS_CA_PATH environment variable.
        cert_path: Path to client certificate for mTLS authentication.
            If not provided, uses TLS_CERT_PATH environment variable.
        key_path: Path to client private key for mTLS authentication.
            If not provided, uses TLS_KEY_PATH environment variable.
        auth_hook: Authentication hook for providing credentials to the
            reference monitor (e.g., KeycloakAuthHook, StaticTokenAuthHook).

    Examples:
        # Enable instrumentation with defaults
        instrument()

        # Enable only HTTP instrumentation
        instrument(langroid=False)

        # Enable only Langroid instrumentation
        instrument(http=False)

        # Enable HTTP with custom reference monitor URL
        instrument(reference_monitor_url="localhost:10089")

        # Enable with Keycloak authentication
        from instrumentation.http import KeycloakAuthHook
        instrument(auth_hook=KeycloakAuthHook(
            server_url="https://keycloak:8443",
            realm="my-realm",
            client_id="my-client",
            username="user",
            password="pass",
        ))
    """
    if http:
        _instrument_http(
            reference_monitor_url=reference_monitor_url,
            ca_path=ca_path,
            cert_path=cert_path,
            key_path=key_path,
            auth_hook=auth_hook,
        )

    if langroid:
        instrument_langroid()

    if tau2:
        instrument_tau2()


__all__ = [
    # Main entry point
    "instrument",
    # Configuration
    "configure",
    "get_config",
    "InstrumentationConfig",
    "FeedbackCallback",
    # HTTP instrumentation
    "instrument_http",
    # Langroid instrumentation
    "instrument_langroid",
    # Tau2 instrumentation
    "instrument_tau2",
    # Tool call authorization
    "check_tool_call",
    # Feedback
    "FeedbackAccumulator",
    "get_current_feedback",
    "add_denial",
    "add_tool_denial",
    # OTel module
    "otel",
]
