"""
Shared configuration for instrumentation.

Configures connections to both the observability server and reference monitor
using shared TLS credentials.
"""

from typing import Any, Callable, Optional

from pydantic import Field
from pydantic_settings import SettingsConfigDict

from observability_common.tls import TLSConfigWithFallback
from observability_common.auth_hooks import AuthHook, NoAuthHook

# Type alias for feedback callback
# Signature: callback(accumulator: FeedbackAccumulator, output: ChatDocument | None, agent: Agent)
FeedbackCallback = Callable[[Any, Any, Any], None]


class InstrumentationConfig(TLSConfigWithFallback):
    """
    Configuration for instrumentation connections.

    Inherits TLS settings from TLSConfigWithFallback, which falls back to
    shared TLS_ env vars (TLS_CA_PATH, TLS_CERT_PATH, TLS_KEY_PATH).

    Environment variables:
        # Shared TLS (used by both servers)
        TLS_CA_PATH=certs/ca.crt
        TLS_CERT_PATH=certs/client.crt
        TLS_KEY_PATH=certs/client.key

        # Server URLs
        OBSERVABILITY_URL=localhost:10085
        REFERENCE_MONITOR_URL=localhost:10089
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
    )

    # Observability server
    observability_url: str = Field(
        default="localhost:10085",
        description="Observability server URL (host:port)",
        alias="OBSERVABILITY_URL",
    )

    # Reference monitor
    reference_monitor_url: str = Field(
        default="localhost:10089",
        description="Reference monitor URL (host:port)",
        alias="REFERENCE_MONITOR_URL",
    )

    # Auth hook for metadata-based auth (JWT, API key)
    auth_hook: AuthHook = Field(
        default_factory=NoAuthHook,
        description="Auth hook for JWT/OIDC/API key authentication",
    )

    # Feedback configuration (runtime-only, not from env vars)
    # Whether to log authorization denials at responder boundaries
    log_denials: bool = Field(
        default=True,
        description="Log authorization denials at responder boundaries",
    )

    # Callback for handling feedback after each responder completes
    # Signature: callback(accumulator, output, agent)
    feedback_callback: Optional[FeedbackCallback] = Field(
        default=None,
        description="Callback for handling authorization feedback",
    )

    # OpenTelemetry configuration
    otel_enabled: bool = Field(
        default=True,
        description="Enable OpenTelemetry tracing",
        alias="OTEL_ENABLED",
    )

    otel_service_name: str = Field(
        default="instrumentation",
        description="Service name for OTel traces",
        alias="OTEL_SERVICE_NAME",
    )

    # Tool policy enforcement
    tool_policy_fail_closed: bool = Field(
        default=True,
        description="If True, deny tool calls when reference monitor is unavailable. "
                    "If False, allow passthrough when RM is unreachable.",
    )

    def load_credentials(self) -> tuple[Optional[bytes], Optional[bytes], Optional[bytes]]:
        """
        Load TLS credentials as bytes.

        Returns:
            Tuple of (ca_cert, client_cert, client_key) - any may be None if not configured
        """
        ca_cert = self.load_ca_cert()
        client_cert = self.load_cert()
        client_key = self.load_key()
        return ca_cert, client_cert, client_key

    def has_tls(self) -> bool:
        """Check if TLS is configured (at minimum, CA cert is available)."""
        return self.load_ca_cert() is not None

    def has_mtls(self) -> bool:
        """Check if mTLS is configured (CA + client cert + key)."""
        ca, cert, key = self.load_credentials()
        return all([ca, cert, key])


# Global configuration instance
_config: Optional[InstrumentationConfig] = None


def get_config() -> InstrumentationConfig:
    """Get the global instrumentation configuration."""
    global _config
    if _config is None:
        _config = InstrumentationConfig()
    return _config


def configure(
    observability_url: Optional[str] = None,
    reference_monitor_url: Optional[str] = None,
    ca_path: Optional[str] = None,
    cert_path: Optional[str] = None,
    key_path: Optional[str] = None,
    auth_hook: Optional[AuthHook] = None,
    log_denials: Optional[bool] = None,
    feedback_callback: Optional[FeedbackCallback] = None,
    otel_enabled: Optional[bool] = None,
    otel_service_name: Optional[str] = None,
    tool_policy_fail_closed: Optional[bool] = None,
) -> InstrumentationConfig:
    """
    Configure instrumentation settings.

    Args:
        observability_url: Observability server URL (host:port)
        reference_monitor_url: Reference monitor URL (host:port)
        ca_path: Path to CA certificate for TLS
        cert_path: Path to client certificate for mTLS
        key_path: Path to client private key for mTLS
        auth_hook: Auth hook for JWT/API key authentication
        log_denials: Whether to log authorization denials at responder boundaries
        feedback_callback: Callback for handling authorization feedback after each
            responder completes. Signature: callback(accumulator, output, agent)
        otel_enabled: Enable OpenTelemetry tracing
        otel_service_name: Service name for OTel traces
        tool_policy_fail_closed: If True, deny tool calls when RM is unavailable.
            If False, allow passthrough when RM is unreachable.

    Returns:
        The updated configuration
    """
    global _config

    # Start with current config or create new one
    if _config is None:
        _config = InstrumentationConfig()

    # Apply overrides
    if observability_url is not None:
        _config.observability_url = observability_url
    if reference_monitor_url is not None:
        _config.reference_monitor_url = reference_monitor_url
    if ca_path is not None:
        _config.ca_path = ca_path
    if cert_path is not None:
        _config.cert_path = cert_path
    if key_path is not None:
        _config.key_path = key_path
    if auth_hook is not None:
        _config.auth_hook = auth_hook
    if log_denials is not None:
        _config.log_denials = log_denials
    if feedback_callback is not None:
        _config.feedback_callback = feedback_callback
    if otel_enabled is not None:
        _config.otel_enabled = otel_enabled
    if otel_service_name is not None:
        _config.otel_service_name = otel_service_name
    if tool_policy_fail_closed is not None:
        _config.tool_policy_fail_closed = tool_policy_fail_closed

    return _config
