"""
HTTP library instrumentation for routing requests through the reference monitor.

Patches requests and httpx libraries to intercept HTTP requests and route them
through the reference monitor for policy enforcement.
"""

from typing import Any, AsyncIterator, Iterator, Optional
from urllib.parse import urlparse

import httpx
import requests
import requests.adapters
import wrapt
from httpx import AsyncByteStream, SyncByteStream

from .config import get_config, configure
from .feedback import add_denial
from .otel import get_current_input_ids
from observability_common.auth_hooks import AuthHook
from observability_common.proto.reference_monitor_pb2 import HTTPRequest, HTTPResponse
from .rm_client import proxy_http, proxy_http_async
from .http_utils import (
    from_httpx_request,
    from_requests_request,
    to_httpx_response,
    to_requests_response,
)


class Stream(SyncByteStream):
    """Content stream extracted from the gRPC response stream."""

    def __init__(self, response_stream: Iterator[HTTPResponse]):
        super().__init__()
        self.response_stream = response_stream

    def __iter__(self) -> Iterator[bytes]:
        for msg in self.response_stream:
            yield msg.message.content


class AsyncStream(AsyncByteStream):
    """Async content stream extracted from the gRPC response stream."""

    def __init__(self, response_stream: AsyncIterator[HTTPResponse]):
        super().__init__()
        self.response_stream = response_stream

    async def __aiter__(self) -> AsyncIterator[bytes]:
        async for msg in self.response_stream:
            yield msg.message.content


# TODO support streamed requests
_instrumented = False


def instrument(
    reference_monitor_url: Optional[str] = None,
    ca_path: Optional[str] = None,
    cert_path: Optional[str] = None,
    key_path: Optional[str] = None,
    auth_hook: Optional[AuthHook] = None,
) -> None:
    """
    Instrument HTTP libraries to route through the reference monitor.

    Configuration is loaded from environment variables by default:
        REFERENCE_MONITOR_URL=localhost:10089
        TLS_CA_PATH=certs/ca.crt
        TLS_CERT_PATH=certs/client.crt  (for mTLS)
        TLS_KEY_PATH=certs/client.key   (for mTLS)

    Args:
        reference_monitor_url: Reference monitor server URL (overrides env var)
        ca_path: Path to CA certificate (overrides env var)
        cert_path: Path to client certificate for mTLS (overrides env var)
        key_path: Path to client private key for mTLS (overrides env var)
        auth_hook: Authentication hook for providing credentials to the reference monitor.
            Examples:
            - KeycloakAuthHook(server_url="http://keycloak:8080", username="user", password="pass")
            - StaticTokenAuthHook(token="my-jwt-token")
            - EnvironmentAuthHook(env_var="MY_TOKEN")
    """
    global _instrumented

    # Configure instrumentation settings from env vars and explicit args
    if any([reference_monitor_url, ca_path, cert_path, key_path, auth_hook]):
        configure(
            reference_monitor_url=reference_monitor_url,
            ca_path=ca_path,
            cert_path=cert_path,
            key_path=key_path,
            auth_hook=auth_hook,
        )

    # Only instrument once
    if _instrumented:
        return
    _instrumented = True
    # Hosts to bypass (not route through reference monitor)
    bypass_hosts = {"localhost", "127.0.0.1", "::1"}

    def wrapper_httpx_send(
        wrapped,
        instance: httpx._client.BaseClient,
        args: tuple[Any],
        kwargs: dict[str, Any],
    ):
        """
        Replace local httpx requests with the results
        from the reference monitor.
        """
        request = args[0] if args else kwargs.get("request", None)

        # Invalid args, allow original method to raise error
        if request is None:
            return wrapped(*args, **kwargs)

        # Bypass local requests
        if request.url.host in bypass_hosts:
            return wrapped(*args, **kwargs)

        base_request = from_httpx_request(request)
        input_node_ids = get_current_input_ids()
        metadata = get_config().auth_hook.get_metadata()

        response_iter = proxy_http(
            HTTPRequest(
                request=base_request,
                input_node_ids=input_node_ids,
            ),
            metadata=metadata if metadata else None,
        )
        base_response = next(response_iter)

        # Collect authorization feedback for denials (401/403)
        if base_response.status in (401, 403):
            message = ""
            suggestions: list[str] = []
            if base_response.message and base_response.message.content:
                raw_message = base_response.message.content.decode("utf-8", errors="replace")
                # Extract suggestions if embedded in message (format: "...\nSuggestion: ...\nSuggestion: ...")
                if "\nSuggestion: " in raw_message:
                    parts = raw_message.split("\nSuggestion: ")
                    message = parts[0]
                    suggestions = [s.strip() for s in parts[1:] if s.strip()]
                else:
                    message = raw_message
            add_denial(
                url=str(request.url),
                message=message or f"HTTP {base_response.status}",
                method=str(request.method),
                suggestions=suggestions,
            )

        response = to_httpx_response(
            base_response,
            Stream(response_iter),
            base_request=request,
        )

        instance.cookies.extract_cookies(response)
        response.default_encoding = instance._default_encoding
        return response

    async def wrapper_httpx_send_async(
        wrapped,
        instance: httpx._client.AsyncClient,
        args: tuple[Any],
        kwargs: dict[str, Any],
    ):
        """
        Replace local httpx async requests with the results
        from the reference monitor.
        """
        request = args[0] if args else kwargs.get("request", None)

        # Invalid args, allow original method to raise error
        if request is None:
            return await wrapped(*args, **kwargs)

        # Bypass local requests
        if request.url.host in bypass_hosts:
            return await wrapped(*args, **kwargs)

        base_request = from_httpx_request(request)
        input_node_ids = get_current_input_ids()
        metadata = get_config().auth_hook.get_metadata()

        response_iter = proxy_http_async(
            HTTPRequest(
                request=base_request,
                input_node_ids=input_node_ids,
            ),
            metadata=metadata if metadata else None,
        )
        base_response = await response_iter.__anext__()

        # Collect authorization feedback for denials (401/403)
        if base_response.status in (401, 403):
            message = ""
            suggestions: list[str] = []
            if base_response.message and base_response.message.content:
                raw_message = base_response.message.content.decode("utf-8", errors="replace")
                # Extract suggestions if embedded in message (format: "...\nSuggestion: ...\nSuggestion: ...")
                if "\nSuggestion: " in raw_message:
                    parts = raw_message.split("\nSuggestion: ")
                    message = parts[0]
                    suggestions = [s.strip() for s in parts[1:] if s.strip()]
                else:
                    message = raw_message
            add_denial(
                url=str(request.url),
                message=message or f"HTTP {base_response.status}",
                method=str(request.method),
                suggestions=suggestions,
            )

        response = to_httpx_response(
            base_response,
            AsyncStream(response_iter),
            base_request=request,
        )

        instance.cookies.extract_cookies(response)
        response.default_encoding = instance._default_encoding
        return response

    # Apply sync wrapper for sync Client
    wrapt.wrap_function_wrapper(
        "httpx._client",
        "Client._send_single_request",
        wrapper_httpx_send,
    )

    # Apply async wrapper for AsyncClient
    wrapt.wrap_function_wrapper(
        "httpx._client",
        "AsyncClient._send_single_request",
        wrapper_httpx_send_async,
    )

    def wrapper_requests_send(
        wrapped,
        instance: requests.adapters.HTTPAdapter,
        args: tuple[Any],
        kwargs: dict[str, Any],
    ):
        """
        Replace local requests with the results
        from the reference monitor.
        """
        request = args[0] if args else kwargs.get("request", None)

        # Invalid args, allow original method to raise error
        if request is None:
            return wrapped(*args, **kwargs)

        # Bypass local requests
        parsed = urlparse(request.url)
        if parsed.hostname in bypass_hosts:
            return wrapped(*args, **kwargs)

        base_request = from_requests_request(request)
        input_node_ids = get_current_input_ids()
        metadata = get_config().auth_hook.get_metadata()

        response = proxy_http(
            HTTPRequest(
                request=base_request,
                input_node_ids=input_node_ids,
            ),
            metadata=metadata if metadata else None,
        )

        # Process the request as would have been done by HTTPAdapter.build_response()
        httpx_response = next(response)

        # Collect authorization feedback for denials (401/403)
        if httpx_response.status in (401, 403):
            message = ""
            suggestions: list[str] = []
            if httpx_response.message and httpx_response.message.content:
                raw_message = httpx_response.message.content.decode("utf-8", errors="replace")
                # Extract suggestions if embedded in message (format: "...\nSuggestion: ...\nSuggestion: ...")
                if "\nSuggestion: " in raw_message:
                    parts = raw_message.split("\nSuggestion: ")
                    message = parts[0]
                    suggestions = [s.strip() for s in parts[1:] if s.strip()]
                else:
                    message = raw_message
            add_denial(
                url=request.url,
                message=message or f"HTTP {httpx_response.status}",
                method=request.method or "GET",
                suggestions=suggestions,
            )

        requests_response = to_requests_response(
            httpx_response,
            request,
            Stream(response),
        )
        requests_response.connection = instance

        return requests_response

    wrapt.wrap_function_wrapper(
        "requests.adapters",
        "HTTPAdapter.send",
        wrapper_requests_send,
    )
