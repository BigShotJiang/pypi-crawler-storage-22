"""
OpenTelemetry configuration, span exporter, and context utilities.

This package provides:
- OTelConfig: Configuration for OTel/Logfire integration
- configure_otel(): Setup function for OTel with observability server backend
- ObservabilitySpanExporter: Custom SpanExporter that sends spans to the observability server
- Context utilities for propagating input IDs through the call stack

Usage:
    from instrumentation.otel import configure_otel, OTelConfig, get_current_input_ids

    # Configure with environment variables
    configure_otel()

    # Or explicit configuration
    configure_otel(OTelConfig(service_name="my-app"))

    # Get input IDs in nested calls (e.g., HTTP interceptors)
    input_ids = get_current_input_ids()
"""

from .config import OTelConfig, configure_otel, get_tracer, is_configured
from .context import (
    _current_input_ids,
    get_current_input_ids,
    get_current_message_id,
    get_current_span,
    set_current_input_ids,
)
from .exporter import ObservabilitySpanExporter

__all__ = [
    "OTelConfig",
    "configure_otel",
    "get_tracer",
    "is_configured",
    "ObservabilitySpanExporter",
    "_current_input_ids",
    "get_current_input_ids",
    "get_current_message_id",
    "get_current_span",
    "set_current_input_ids",
]
