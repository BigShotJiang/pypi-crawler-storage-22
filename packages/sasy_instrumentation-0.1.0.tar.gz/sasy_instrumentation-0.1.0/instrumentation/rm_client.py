"""
Reference monitor gRPC client for HTTP proxying and tool call authorization.
"""

import asyncio
import logging
import threading
import time
from typing import AsyncGenerator, Generator, Optional

import grpc

logger = logging.getLogger(__name__)

from observability_common.proto import reference_monitor_pb2_grpc as reference_monitor_grpc
from observability_common.proto.reference_monitor_pb2 import (
    HTTPRequest,
    HTTPResponse,
    ToolCallRequest,
    ToolCallResponse,
)
from .config import get_config


# Cached channel for reference monitor (gRPC channels are thread-safe)
_channel_lock = threading.Lock()
_cached_channel: Optional[grpc.Channel] = None


def _get_rm_channel() -> grpc.Channel:
    """Get or create a shared gRPC channel for the reference monitor."""
    global _cached_channel

    if _cached_channel is not None:
        return _cached_channel

    with _channel_lock:
        # Double-check after acquiring lock
        if _cached_channel is not None:
            return _cached_channel

        config = get_config()
        ca_cert, client_cert, client_key = config.load_credentials()

        options = [
            ("grpc.max_message_length", -1),
            ("grpc.max_send_message_length", -1),
            ("grpc.max_receive_message_length", -1),
        ]

        if config.has_tls():
            channel_credentials = grpc.ssl_channel_credentials(
                root_certificates=ca_cert,
                private_key=client_key,
                certificate_chain=client_cert,
            )
            _cached_channel = grpc.secure_channel(
                config.reference_monitor_url, channel_credentials, options=options
            )
        else:
            _cached_channel = grpc.insecure_channel(
                config.reference_monitor_url, options=options
            )

        return _cached_channel


def proxy_http(
    request: HTTPRequest,
    metadata: Optional[list[tuple[str, str]]] = None,
) -> Generator[HTTPResponse, None, None]:
    """Make an HTTP request remotely via the reference monitor.

    Args:
        request: The HTTP request to proxy
        metadata: gRPC metadata (headers) to include with the request
    """
    channel = _get_rm_channel()
    stub = reference_monitor_grpc.RMProxyStub(channel)  # type:ignore
    yield from stub.ProxyHTTP(request, metadata=metadata)  # type: ignore


def check_tool_call(
    fn_name: str,
    args: str,
    input_node_ids: Optional[list[str]] = None,
    max_retries: int = 3,
) -> ToolCallResponse:
    """Check authorization for a tool call via the reference monitor.

    Uses the shared instrumentation config for connection settings.
    Uses a cached, thread-safe gRPC channel to handle parallel requests.
    Includes retry logic for transient failures.

    Args:
        fn_name: The tool function name
        args: The tool arguments (typically JSON string)
        input_node_ids: Node IDs from observability context
        max_retries: Maximum number of retry attempts for transient failures

    Returns:
        ToolCallResponse with authorization decision
    """
    config = get_config()
    metadata = config.auth_hook.get_metadata()

    request = ToolCallRequest(
        fn_name=fn_name,
        args=args,
        input_node_ids=input_node_ids or [],
    )

    last_error = None
    for attempt in range(max_retries):
        try:
            channel = _get_rm_channel()
            stub = reference_monitor_grpc.RMProxyStub(channel)  # type:ignore
            return stub.CheckToolCall(request, metadata=metadata or None)  # type: ignore
        except grpc.RpcError as e:
            last_error = e
            if e.code() in (grpc.StatusCode.CANCELLED, grpc.StatusCode.UNAVAILABLE):
                # Transient error - retry with backoff
                if attempt < max_retries - 1:
                    sleep_time = 0.1 * (2 ** attempt)  # 0.1s, 0.2s, 0.4s
                    logger.debug(f"Tool call check failed (attempt {attempt + 1}), retrying in {sleep_time}s: {e}")
                    time.sleep(sleep_time)
                    continue
            # Non-retryable error or max retries reached
            raise

    raise last_error  # type: ignore


# Cached async channel for reference monitor
_cached_async_channel: Optional[grpc.aio.Channel] = None


def _get_rm_channel_async() -> grpc.aio.Channel:
    """Get or create a shared async gRPC channel for the reference monitor."""
    global _cached_async_channel

    if _cached_async_channel is not None:
        return _cached_async_channel

    config = get_config()
    ca_cert, client_cert, client_key = config.load_credentials()

    options = [
        ("grpc.max_message_length", -1),
        ("grpc.max_send_message_length", -1),
        ("grpc.max_receive_message_length", -1),
    ]

    if config.has_tls():
        channel_credentials = grpc.ssl_channel_credentials(
            root_certificates=ca_cert,
            private_key=client_key,
            certificate_chain=client_cert,
        )
        _cached_async_channel = grpc.aio.secure_channel(
            config.reference_monitor_url, channel_credentials, options=options
        )
    else:
        _cached_async_channel = grpc.aio.insecure_channel(
            config.reference_monitor_url, options=options
        )

    return _cached_async_channel


async def proxy_http_async(
    request: HTTPRequest,
    metadata: Optional[list[tuple[str, str]]] = None,
) -> AsyncGenerator[HTTPResponse, None]:
    """Make an HTTP request remotely via the reference monitor (async version).

    Args:
        request: The HTTP request to proxy
        metadata: gRPC metadata (headers) to include with the request
    """
    channel = _get_rm_channel_async()
    stub = reference_monitor_grpc.RMProxyStub(channel)  # type:ignore
    async for response in stub.ProxyHTTP(request, metadata=metadata):  # type: ignore
        yield response


async def check_tool_call_async(
    fn_name: str,
    args: str,
    input_node_ids: Optional[list[str]] = None,
    max_retries: int = 3,
) -> ToolCallResponse:
    """Check authorization for a tool call via the reference monitor (async version).

    Args:
        fn_name: The tool function name
        args: The tool arguments (typically JSON string)
        input_node_ids: Node IDs from observability context
        max_retries: Maximum number of retry attempts for transient failures

    Returns:
        ToolCallResponse with authorization decision
    """
    config = get_config()
    metadata = config.auth_hook.get_metadata()

    request = ToolCallRequest(
        fn_name=fn_name,
        args=args,
        input_node_ids=input_node_ids or [],
    )

    last_error = None
    for attempt in range(max_retries):
        try:
            channel = _get_rm_channel_async()
            stub = reference_monitor_grpc.RMProxyStub(channel)  # type:ignore
            return await stub.CheckToolCall(request, metadata=metadata or None)  # type: ignore
        except grpc.RpcError as e:
            last_error = e
            if e.code() in (grpc.StatusCode.CANCELLED, grpc.StatusCode.UNAVAILABLE):
                # Transient error - retry with backoff
                if attempt < max_retries - 1:
                    sleep_time = 0.1 * (2 ** attempt)  # 0.1s, 0.2s, 0.4s
                    logger.debug(f"Tool call check failed (attempt {attempt + 1}), retrying in {sleep_time}s: {e}")
                    await asyncio.sleep(sleep_time)
                    continue
            # Non-retryable error or max retries reached
            raise

    raise last_error  # type: ignore
