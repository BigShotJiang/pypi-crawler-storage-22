"""
Observability instrumentation for Tau2 bench orchestration.
"""

import json
import logging
from functools import lru_cache
from typing import Optional, cast
from uuid import uuid4
from copy import deepcopy

from observability_common.proto.reference_monitor_pb2 import ToolCallResponse
from wrapt import wrap_function_wrapper  # type: ignore[import-untyped]
from opentelemetry.trace import StatusCode

from observability.api import record_dependencies, record_events
from observability_common.proto.observability_pb2 import Edge, Event, Role, Tool
from .feedback import (
    FeedbackScope,
    add_tool_denial,
)
from .config import get_config
from .otel import get_tracer
from .otel.context import (
    _current_input_ids,
    get_current_input_ids,
)

try:
    from pydantic import Extra
except ImportError:
    Extra = None

from .rm_client import check_tool_call

logger = logging.getLogger(__name__)

@lru_cache
def instrument() -> None:
    """
    Observability instrumentation for Tau2 benchmark
    for all concrete agents and user simulators.

    This function wraps Tau2 LLMAgent methods to:
    1. Record messages and dependencies to the observability graph
    2. Create OpenTelemetry spans for each responder
    3. Link spans to messages via special attributes
    4. Accumulate authorization feedback per-responder scope

    OTel is automatically configured if not already done. Spans are exported
    to the observability server via the ObservabilitySpanExporter.
    """
    # Initialize OTel (configures if not already done)
    TRACER = "instrumentation.tau2"
    get_tracer(TRACER)

    try:
        import tau2.data_model.message as message
        import tau2.agent.base as agent_base
        import tau2.agent.llm_agent as llm_agent
        import tau2.user.base as user_base
        import tau2.gym.gym_agent as gym_agent
        from tau2.data_model.message import (
            Message,
            ParticipantMessageBase,
        )

        def translate_roles(
                role: str 
        ) -> Role:
            """Convert Tau2 roles into proto Roles."""
            match role:
                case "system":
                    return Role.SYSTEM
                case "assistant":
                    return Role.LLM
                case "tool":
                    return Role.AGENT
                case _:
                    return Role.USER

        def get_id(msg: Message) -> Optional[str]:
            """
            Extract the Observability ID from the message.
            """
            if hasattr(msg, "_observability_id") and (
                id := getattr(msg, "_observability_id")
            ):
                return cast(str, id)

            return None

        def get_tools(
            msg: Message,
        ) -> list[Tool]:
            """Extracts the tools from a Message."""
            if isinstance(msg, ParticipantMessageBase):
                return [
                    Tool(name=tc.name, arguments=json.dumps(tc.arguments))
                    for tc in msg.tool_calls or []
                ]
            return []

        def record_events_and_dependencies(
            message_history: list[Event], record_index: bool = True
        ) -> list[str]:
            """
            Record the provided events to the observability server
            and the dependencies assuming that all but the final message
            in message_history are the input messages (in order) sent to the LLM,
            and that the final message is the generate message.
            """
            ids = record_events(message_history)
            dependencies = [
                Edge(
                    source=id,
                    destination=ids[-1],
                    message_index=i if record_index else None,
                    proximal=i == len(ids) - 2,
                )
                for i, id in enumerate(ids[:-1])
            ]
            record_dependencies(dependencies)
            return ids

        def llm_gen_wrapper(agent_name: str, user_simulator: bool = False):
            """Patched LLM generation step."""
            def wrapper(wrapped, instance, args, kwargs):
                # Extract the message argument from the responder call
                msg: agent_base.ValidAgentInputMessage = kwargs.get("message", args[0])
                state: (
                    llm_agent.LLMAgentState | user_base.UserState | gym_agent.GymUserState | gym_agent.GymAgentState
                ) = deepcopy(kwargs.get("state", args[1])) # Gym agents may have state manipulation during the responder execution

                # Replicate input logic prior to input ids computation
                if isinstance(msg, message.MultiToolMessage):
                    message_in = msg.tool_messages
                else:
                    message_in = [msg]

                # Collect input message IDs before execution (filter out None values)
                if user_simulator:
                    # Track flipped IDs
                    state_copy = user_base.UserState(
                        system_messages=state.system_messages,
                        messages=state.messages + message_in,
                    )
                    messages_in = state_copy.system_messages + state_copy.flip_roles()
                elif any(isinstance(state, c) for c in [gym_agent.GymAgentState, gym_agent.GymUserState]):
                    # Only uses messages, no separate system messages field
                    messages_in = state.messages + message_in
                else:
                    messages_in = state.system_messages + state.messages + message_in

                # Ensure all input messages have observability IDs
                # (fallback if monkey patching didn't apply due to import order)
                for msg in messages_in:
                    if not hasattr(msg, "_observability_id") or not msg._observability_id:
                        msg._observability_id = str(uuid4())

                input_ids = [
                    id
                    for msg in messages_in
                    if (id := get_id(msg)) is not None
                ]

                # Create span name
                span_name = "tau2.user_simulator" if user_simulator else "tau2.llm_gen"

                with get_tracer(TRACER).start_as_current_span(span_name) as span:
                    # Set attributes BEFORE execution so they're available
                    span.set_attribute("agent.name", agent_name)
                    span.set_attribute("responder.type", "llm_response")
                    if input_ids:
                        span.set_attribute(
                            "_input_message_ids", ",".join(input_ids)
                        )
                        # Propagate input IDs to nested calls via ContextVar
                        token = _current_input_ids.set(input_ids)
                    else:
                        token = None

                    try:
                        try:
                            # Generate edges from user simulator gen step
                            if not user_simulator:
                                for msg in messages_in: 
                                    if getattr(msg, "_generated_by_user_simulator", False) and hasattr(msg, "_flipped_observability_id"):
                                        current_agent_msg = Event(
                                            text=msg.content,
                                            role=translate_roles(msg.role),
                                            agent=agent_name,
                                            tools=get_tools(msg),
                                            id=get_id(msg),
                                        )
                                        flipped_msg = Event(
                                            text=msg.content,
                                            role=Role.LLM,
                                            agent="UserSimulator",
                                            tools=get_tools(msg),
                                            id=msg._flipped_observability_id,
                                        )
                                        record_events_and_dependencies([flipped_msg, current_agent_msg], record_index=False)
                                          
                            # FeedbackScope accumulates auth feedback during execution
                            with FeedbackScope(agent_name, "llm") as feedback_scope:
                                output_message, output_state = wrapped(*args, **kwargs)

                            if user_simulator and not hasattr(output_message, "_flipped_observability_id"):
                                output_message._flipped_observability_id = str(uuid4())
                                output_message._generated_by_user_simulator = True

                            # Process feedback after execution (callback can modify output)
                            # Pass the state to the "agent" field 
                            feedback_scope.process(output_message, output_state)

                            # Ensure output_message has an observability ID
                            # (fallback if monkey patching didn't apply due to import order)
                            if not hasattr(output_message, "_observability_id") or not output_message._observability_id:
                                output_message._observability_id = str(uuid4())

                            if output_message.tool_calls is not None:
                                for tc in output_message.tool_calls:
                                    tc._derived_from = get_id(output_message)

                        except Exception as e:
                            # Record exception on span and set error status
                            span.record_exception(e)
                            span.set_status(StatusCode.ERROR, str(e))
                            logger.error(str(e))
                            raise

                        if output_message and output_state:
                            history = [
                                Event(
                                    text=msg.content,
                                    role=translate_roles(msg.role),
                                    agent=agent_name,
                                    tools=get_tools(msg),
                                    id=get_id(msg),
                                )
                                for msg in messages_in + [output_message]
                            ]

                            # Record the actual generation step
                            if user_simulator:
                                history[-1].id = output_message._flipped_observability_id
                                history[-1].role = Role.LLM

                            # Record events and dependencies
                            ids = record_events_and_dependencies(
                                history, record_index=True,
                            )

                            if ids:
                                # The ID of the output message
                                span.set_attribute("_output_message_id", get_id(output_message) if user_simulator else ids[-1])
                                if user_simulator:
                                    # The ID of the generated message for user simulators
                                    span.set_attribute("_output_message_flipped_id", ids[-1])

                        span.set_status(StatusCode.OK)
                        return output_message, output_state
                    finally:
                        # Reset ContextVar to previous value
                        if token is not None:
                            _current_input_ids.reset(token)

            return wrapper

        for class_name in ["LLMAgent", "LLMGTAgent", "LLMSoloAgent"]:
            wrap_function_wrapper(
                "tau2.agent.llm_agent",
                f"{class_name}.generate_next_message",
                llm_gen_wrapper(class_name),
            )

        for class_name in ["GymAgent", "GymUser"]:
            wrap_function_wrapper(
                "tau2.gym.gym_agent",
                f"{class_name}.generate_next_message",
                llm_gen_wrapper(class_name),
            )

        def track_id_wrapper(wrapped, instance, args, kwargs):
            """Track unique ids in Messages."""
            wrapped(*args, **kwargs)
            if hasattr(instance, "model_config"):
                instance.model_config["extra"] = "allow"
            elif Extra is not None:
                # Fallback for Pydantic v1
                instance.__config__.extra = Extra.allow

            instance._observability_id = str(uuid4())


        for msg_class in [
            "SystemMessage",
            "AssistantMessage",
            "UserMessage",
            "ToolMessage",
            "MultiToolMessage",
        ]:
            wrap_function_wrapper(
                "tau2.data_model.message",
                f"{msg_class}.__init__",
                track_id_wrapper
            )


        def wrap_flip_roles(wrapped, instance: user_base.UserState, args, kwargs):
            for msg in instance.messages:
                if not hasattr(msg, "_observability_id"):
                    msg._observability_id = str(uuid4())
                if not hasattr(msg, "_flipped_observability_id"):
                    msg._flipped_observability_id = str(uuid4())
            flipped_messages = wrapped(*args, **kwargs)

            # Record the derivation of the flipped copies
            # (MERGE in Neo4j prevents duplicate edges)
            for flipped, orig in zip(flipped_messages, instance.messages):
                flipped._observability_id = orig._flipped_observability_id
                for i, tc in enumerate(getattr(flipped, "tool_calls", []) or []):
                    if hasattr(orig.tool_calls[i], "_derived_from"):
                       tc._derived_from = orig.tool_calls[i]._derived_from
            in_messages = [
                Event(
                    text=msg.content,
                    role=translate_roles(msg.role),
                    tools=get_tools(msg),
                    id=get_id(msg),
                )
                for msg in instance.messages
            ]
            out_messages = [
                Event(
                    text=msg.content,
                    role=translate_roles(msg.role),
                    agent="UserSimulator",
                    tools=get_tools(msg),
                    id=get_id(msg),
                )
                for msg in flipped_messages
            ]
            record_events(in_messages + out_messages)
            dependencies = [
                Edge(
                    source=in_msg.id,
                    destination=out_msg.id,
                )
                for in_msg, out_msg in zip(in_messages, out_messages)
            ]
            record_dependencies(dependencies)
            return flipped_messages

        wrap_function_wrapper(
            "tau2.user.base",
            "UserState.flip_roles",
            wrap_flip_roles,
        )

        wrap_function_wrapper(
            "tau2.user.user_simulator",
            "UserSimulator.generate_next_message",
            llm_gen_wrapper("UserSimulator", user_simulator=True),
        )

        # Tool call policy enforcement wrappers
        def _extract_denial_message(response: ToolCallResponse) -> str:
            """Extract denial message from ToolCallResponse, including all reasons."""
            if response.denial_trace:
                msg = response.denial_trace.action_description
                if response.denial_trace.reasons:
                    # Include all reasons with their details
                    reason_parts = [
                        reason.details if reason.details else str(reason.reason_type)
                        for reason in response.denial_trace.reasons
                    ]
                    msg += ": " + "; ".join(reason_parts)
                return msg
            return "Tool call not authorized"


        def _extract_suggestions(response: ToolCallResponse) -> list[str]:
            """Extract all suggestions from ToolCallResponse."""
            if response.denial_trace and response.denial_trace.suggested_fixes:
                return list(response.denial_trace.suggested_fixes)
            return []

        def wrap_tool_message_response(wrapped, instance, args, kwargs):
            """
            Check tool call authorization before executing the handler.

            If denied with deny_if_unauthorized=True, returns denial message
            instead of executing the tool.
            """
            tool: message.ToolCall = kwargs.get("message", args[0] if args else None)
            if tool is None:
                return wrapped(*args, **kwargs)

            fn_name = tool.name
            fn_args = json.dumps(tool.arguments)

            tool_id = getattr(tool, "_derived_from", None)
            input_ids = [tool_id] if tool_id is not None  else []
            config = get_config()

            span_name = "tau2.tool_call"

            with get_tracer(TRACER).start_as_current_span(span_name) as span:
                span.set_attribute("fn.name", fn_name)
                span.set_attribute("fn.args", fn_args)
                try:
                    response = check_tool_call(fn_name, fn_args, input_ids)

                    if not response.authorized:
                        denial_msg_text = _extract_denial_message(response)
                        suggestions = _extract_suggestions(response)
                        add_tool_denial(fn_name, denial_msg_text, fn_args, suggestions)
                        denial_content = f"[BLOCKED] {fn_name}: {denial_msg_text}"
                        if suggestions:
                            if len(suggestions) == 1:
                                denial_content += f"\nRequired action: {suggestions[0]}"
                            else:
                                denial_content += "\nRequired actions:\n" + "\n".join(f"  - {s}" for s in suggestions)
                        logger.info(f"Tool call denied: {fn_name} - {denial_msg_text}")
                        out = message.ToolMessage(
                            id=tool.id,
                            content=denial_content,
                            requestor=tool.requestor,
                            role="tool",
                            error=True,
                        )
                        record_events([
                            Event(
                                text=out.content,
                                role=translate_roles(out.role),
                                id=get_id(out),
                            )
                        ])
                        if tool_id is not None:
                            record_dependencies([
                                Edge(
                                    source=tool_id,
                                    destination=get_id(out),
                                    proximal=True,
                                )
                            ])
                        return out

                except Exception as e:
                    if config.tool_policy_fail_closed:
                        logger.warning(f"Tool call denied (RM unavailable, fail_closed=True): {fn_name} - {e}")
                        add_tool_denial(fn_name, "Reference monitor unavailable", fn_args, [])
                        out = message.ToolMessage(
                            id=tool.id,
                            content=f"[BLOCKED] {fn_name}: Reference monitor unavailable",
                            requestor=tool.requestor,
                            role="tool",
                            error=True,
                        )
                        return out
                    else:
                        logger.debug(f"Tool policy check failed (passthrough): {e}")

                out = wrapped(*args, **kwargs)

                record_events([
                    Event(
                        text=out.content,
                        role=translate_roles(out.role),
                        derived_from=Tool(name=fn_name, arguments=fn_args),
                        id=get_id(out),
                    )
                ])
                if tool_id is not None:
                    record_dependencies([
                        Edge(
                            source=tool_id,
                            destination=get_id(out),
                            proximal=True,
                        )
                    ])

                return out
                
        wrap_function_wrapper(
            module="tau2.environment.environment",
            name="Environment.get_response",
            wrapper=wrap_tool_message_response,
        )

    except ImportError:
        pass
