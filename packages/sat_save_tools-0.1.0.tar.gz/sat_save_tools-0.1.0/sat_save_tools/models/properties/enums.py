import enum

from sat_save_tools.utils import StrEnumDeserializerMixin, StrEnumSerializerMixin

__all__ = ("ArrayElementTypeName", "PropertyTypeName")


class PropertyTypeName(StrEnumSerializerMixin, StrEnumDeserializerMixin, enum.StrEnum):
    ARRAY = "ArrayProperty"
    BOOL = "BoolProperty"
    BYTE = "ByteProperty"
    ENUM = "EnumProperty"
    FLOAT = "FloatProperty"
    DOUBLE = "DoubleProperty"
    INT = "IntProperty"
    INT8 = "Int8Property"
    U_INT32 = "UInt32Property"
    INT64 = "Int64Property"
    MAP = "MapProperty"
    NAME = "NameProperty"
    OBJECT = "ObjectProperty"
    SOFT_OBJECT = "SoftObjectProperty"
    SET = "SetProperty"
    STR = "StrProperty"
    STRUCT = "StructProperty"
    TEXT = "TextProperty"


class ArrayElementTypeName(StrEnumSerializerMixin, StrEnumDeserializerMixin, enum.StrEnum):
    BYTE = "ByteProperty"
    ENUM = "EnumProperty"
    STR = "StrProperty"
    INTERFACE = "InterfaceProperty"
    OBJECT = "ObjectProperty"
    INT = "IntProperty"
    INT64 = "Int64Property"
    FLOAT = "FloatProperty"
    SOFT_OBJECT = "SoftObjectProperty"
    STRUCT = "StructProperty"


class StructTypeName(StrEnumSerializerMixin, StrEnumDeserializerMixin, enum.StrEnum):
    LINEAR_COLOR = "LinearColor"
    VECTOR = "Vector"
    SPAWN_DATA = "SpawnData"
    BLUEPRINT_CATEGORY_RECORD = "BlueprintCategoryRecord"
    BLUEPRINT_SUBCATEGORY_RECORD = "BlueprintSubCategoryRecord"
    DRONE_TRIP_INFORMATION = "DroneTripInformation"
    FACTORY_CUSTOMIZATION_COLOR_SLOT = "FactoryCustomizationColorSlot"
    FEET_OFFSET = "FeetOffset"
    FG_CACHED_CONNECTED_WIRE = "FGCachedConnectedWire"
    FG_DRONE_FUEL_RUNTIME_DATA = "FGDroneFuelRuntimeData"
    G_CHECKMARK_UNLOCK_DATA = "GCheckmarkUnlockData"
    GLOBAL_COLOR_PRESET = "GlobalColorPreset"
    HARD_DRIVE_DATA = "HardDriveData"
    HIGHLIGHTED_MARKER_PAIR = "HighlightedMarkerPair"
    HOTBAR = "Hotbar"
    INVENTORY_STACK = "InventoryStack"
    ITEM_AMOUNT = "ItemAmount"
    MAP_MARKER = "MapMarker"
    MESSAGE_DATA = "MessageData"
    MINI_GAME_RESULT = "MiniGameResult"
    PHASE_COST = "PhaseCost"
    PREFAB_ICON_ELEMENT_SAVE_DATA = "PrefabIconElementSaveData"
    PREFAB_TEXT_ELEMENT_SAVE_DATA = "PrefabTextElementSaveData"
    PROJECT_ASSEMBLY_LAUNCH_SEQUENCE_VALUE = "ProjectAssemblyLaunchSequenceValue"
    RESEARCH_DATA = "ResearchData"
    RESEARCH_TIME = "ResearchTime"
    RESOURCE_SINK_HISTORY = "ResourceSinkHistory"
    SCANNABLE_OBJECT_DATA = "ScannableObjectData"
    SCANNABLE_RESOURCE_PAIR = "ScannableResourcePair"
    SCHEMATIC_COST = "SchematicCost"
    SHOPPING_LIST_BLUEPRINT_ENTRY = "ShoppingListBlueprintEntry"
    SHOPPING_LIST_CLASS_ENTRY = "ShoppingListClassEntry"
    SHOPPING_LIST_RECIPE_ENTRY = "ShoppingListRecipeEntry"
    SPLINE_POINT_DATA = "SplinePointData"
    SPLITTER_SORT_RULE = "SplitterSortRule"
    SUBCATEGORY_MATERIAL_DEFAULT = "SubCategoryMaterialDefault"
    TIME_TABLE_STOP = "TimeTableStop"
    WIRE_INSTANCE = "WireInstance"
    GUID = "Guid"
    SWATCH_GROUP_DATA = "SwatchGroupData"
    COLOR = "Color"
    BLUEPRINT_RECORD = "BlueprintRecord"
    BOOM_BOX_PLAYER_STATE = "BoomBoxPlayerState"
    DRONE_DOCKING_STATE_INFO = "DroneDockingStateInfo"
    FG_PLAYER_PORTAL_DATA = "FGPlayerPortalData"
    FG_PORTAL_CACHED_FACTORY_TICK_DATA = "FGPortalCachedFactoryTickData"
    FACTORY_CUSTOMIZATION_DATA = "FactoryCustomizationData"
    LIGHT_SOURCE_CONTROL_DATA = "LightSourceControlData"
    PERSISTENT_GLOBAL_ICON_ID = "PersistentGlobalIconId"
    PLAYER_CUSTOMIZATION_DATA = "PlayerCustomizationData"
    PLAYER_RULES = "PlayerRules"
    SHOPPING_LIST_SETTINGS = "ShoppingListSettings"
    TIMER_HANDLE = "TimerHandle"
    TOP_LEVEL_ASSET_PATH = "TopLevelAssetPath"
    TRAIN_DOCKING_RULE_SET = "TrainDockingRuleSet"
    TRAIN_SIMULATION_DATA = "TrainSimulationData"
    TRANSFORM = "Transform"
    VECTOR_NET_QUANTIZE = "Vector_NetQuantize"
    FLUID_BOX = "FluidBox"
    RAILROAD_TRACK_POSITION = "RailroadTrackPosition"
    CLIENT_IDENTITY_INFO = "ClientIdentityInfo"
    LOCAL_USER_NET_ID_BUNDLE = "LocalUserNetIdBundle"
    SWITCH_DATA = "SwitchData"
    BOX = "Box"
    ELEVATOR_FLOOR_STOP_INFO = "ElevatorFloorStopInfo"
    INVENTORY_ITEM = "InventoryItem"
    QUAT = "Quat"
    DATE_TIME = "DateTime"

    SUB_CATEGORY_MATERIAL_DEFAULT = "SubCategoryMaterialDefault"
    DT_CONFIG_STRUCT = "DTConfigStruct"
    MANAGED_SIGN_CONNECTION_SETTINGS = "ManagedSignConnectionSettings"
    RESOURCE_NODE_DATA = "ResourceNodeData"
    SIGN_COMPONENT_DATA = "SignComponentData"
    SIGN_COMPONENT_VARIABLE_DATA = "SignComponentVariableData"
    SIGN_COMPONENT_VARIABLE_META_DATA = "SignComponentVariableMetaData"
    ROTATOR = "Rotator"

    @classmethod
    def _missing_(cls, value: object):  # noqa: ANN206
        if not isinstance(value, str):
            return None

        obj = str.__new__(cls, value)
        obj._name_ = value
        obj._value_ = value
        return obj
