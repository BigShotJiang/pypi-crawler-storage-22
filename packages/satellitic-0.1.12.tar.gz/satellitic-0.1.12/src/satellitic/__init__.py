name = "satellitic"
__version__ = "0.1.12"
