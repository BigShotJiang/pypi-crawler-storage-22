#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Allow running satellome as a module: python -m satellome"""

from satellome.main import main

if __name__ == "__main__":
    main()
