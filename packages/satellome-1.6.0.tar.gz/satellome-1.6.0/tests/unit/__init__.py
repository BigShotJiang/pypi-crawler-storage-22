"""Unit tests for Satellome core functions."""
