# satheesh

Official Python Identity Package

A lightweight, dependency-free Python package that provides identity and contact information for Satheesh.

## Installation

```bash
pip install satheesh
```

## Usage

### Basic Usage

```python
from satheesh import info, contact

# Get identity information
identity = info()
print(identity)

# Get contact information
contact_info = contact()
print(contact_info)
```

### CLI Usage

```bash
# Display identity information
satheesh --info

# Display contact information
satheesh --contact
```

