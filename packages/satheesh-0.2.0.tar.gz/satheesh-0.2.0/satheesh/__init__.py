"""Satheesh - Official Python Identity Package."""

from .core import contact, info
from .__version__ import __version__

__all__ = ["info", "contact", "__version__"]
