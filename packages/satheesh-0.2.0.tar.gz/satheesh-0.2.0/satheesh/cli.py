"""Command-line interface for the satheesh package."""

import argparse

from .core import contact, info


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        description="Satheesh - Official Python Identity Package"
    )
    parser.add_argument(
        "--info",
        action="store_true",
        help="Display identity information",
    )
    parser.add_argument(
        "--contact",
        action="store_true",
        help="Display contact information",
    )

    args = parser.parse_args()

    if args.info:
        print(info())

    if args.contact:
        print(contact())

    if not args.info and not args.contact:
        parser.print_help()


if __name__ == "__main__":
    main()
