"""Core business logic for the satheesh package."""


def info():
    """Return identity information as a dictionary.

    Returns:
        dict: Contains name, role, skills, and mission.
    """
    return {
        "name": "Satheesh",
        "role": "Python Backend Developer",
        "skills": ["Python", "FastAPI", "GEN_AI", "Machine learning"],
        "mission": "Find the paterns in the DATA",
    }


def contact():
    """Return contact information as a dictionary.

    Returns:
        dict: Contains email, github, and linkedin.
    """
    return {
        "email": "satheesh142002@gmail.com",
        "github": "https://github.com/satheesh142002",
        "linkedin": "https://www.linkedin.com/in/satheesh-kumar-k-ab5766255/",
    }
