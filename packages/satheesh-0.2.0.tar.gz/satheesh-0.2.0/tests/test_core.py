"""Tests for the satheesh core module."""

from satheesh import contact, info, __version__


def test_info_returns_dict():
    """Test that info() returns a dictionary."""
    result = info()
    assert isinstance(result, dict)


def test_info_contains_required_keys():
    """Test that info() contains all required keys."""
    result = info()
    assert "name" in result
    assert "role" in result
    assert "skills" in result
    assert "mission" in result


def test_info_data_structure():
    """Test that info() returns correctly structured data."""
    result = info()
    assert result["name"] == "Satheesh"
    assert result["role"] == "Python Developer"
    assert isinstance(result["skills"], list)
    assert "Python" in result["skills"]
    assert result["mission"] == "Building scalable backend systems"


def test_contact_returns_dict():
    """Test that contact() returns a dictionary."""
    result = contact()
    assert isinstance(result, dict)


def test_contact_contains_required_keys():
    """Test that contact() contains all required keys."""
    result = contact()
    assert "email" in result
    assert "github" in result
    assert "linkedin" in result


def test_contact_data_structure():
    """Test that contact() returns correctly structured data."""
    result = contact()
    assert result["email"] == "satheesh@example.com"
    assert result["github"] == "https://github.com/username"
    assert result["linkedin"] == "https://linkedin.com/in/username"


def test_version_is_accessible():
    """Test that __version__ is accessible."""
    assert __version__ == "0.1.0"
