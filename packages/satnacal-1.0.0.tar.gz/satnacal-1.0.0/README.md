# SatnaCal – Advanced Calculator Package

SatnaCal is a Python-based advanced calculator package that provides
basic and scientific mathematical operations using a simple
menu-driven command-line interface (CLI).

This package is beginner-friendly and useful for learning
Python functions, error handling, and packaging.

---

## 📦 Features

- Addition
- Subtraction
- Multiplication
- Division (with zero-division handling)
- Power calculation
- Square Root
- Factorial
- Trigonometric functions (sin, cos, tan)
- Menu-driven CLI calculator
- Proper exception handling

---

## Installation

```bash
pip install satnacal



