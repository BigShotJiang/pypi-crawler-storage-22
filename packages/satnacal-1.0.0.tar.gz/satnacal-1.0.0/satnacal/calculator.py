import math


# -------------------- Basic Operations --------------------

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    return a / b


# -------------------- Advanced Operations --------------------

def square_root(a):
    if a < 0:
        raise ValueError("Cannot calculate square root of negative number.")
    return math.sqrt(a)

def power(a, b):
    return math.pow(a, b)

def logarithm(a):
    if a <= 0:
        raise ValueError("Logarithm only defined for positive numbers.")
    return math.log(a)

def sine(a):
    return math.sin(math.radians(a))

def cosine(a):
    return math.cos(math.radians(a))

def factorial(a):
    if a < 0:
        raise ValueError("Factorial not defined for negative numbers.")
    if not float(a).is_integer():
        raise ValueError("Factorial only defined for integers.")
    return math.factorial(int(a))


# -------------------- Main Calculator --------------------

def main():
    while True:
        print("\n===== Advanced Calculator =====")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Square Root")
        print("6. Power")
        print("7. Logarithm (natural log)")
        print("8. Sine")
        print("9. Cosine")
        print("10. Factorial")
        print("0. Exit")

        try:
            choice = int(input("Enter your choice: "))

            if choice == 0:
                print("Exiting calculator. Goodbye!")
                break

            if choice in [1, 2, 3, 4, 6]:
                num1 = float(input("Enter first number: "))
                num2 = float(input("Enter second number: "))

                if choice == 1:
                    result = add(num1, num2)
                elif choice == 2:
                    result = subtract(num1, num2)
                elif choice == 3:
                    result = multiply(num1, num2)
                elif choice == 4:
                    result = divide(num1, num2)
                elif choice == 6:
                    result = power(num1, num2)

            elif choice in [5, 7, 8, 9, 10]:
                num = float(input("Enter number: "))

                if choice == 5:
                    result = square_root(num)
                elif choice == 7:
                    result = logarithm(num)
                elif choice == 8:
                    result = sine(num)
                elif choice == 9:
                    result = cosine(num)
                elif choice == 10:
                    result = factorial(num)

            else:
                print("Invalid choice. Please try again.")
                continue

            print("Result:", result)

        except ValueError as ve:
            print("Value Error:", ve)
        except ZeroDivisionError as zde:
            print("Math Error:", zde)
        except Exception as e:
            print("Unexpected Error:", e)


# Run the calculator
if __name__ == "__main__":
    main()
