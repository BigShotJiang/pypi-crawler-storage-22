from setuptools import setup, find_packages

setup(
    name="satnacal",   # must be unique on PyPI
    version="1.0.0",
    author="Prashant Rai",
    author_email="rairpa1992@gmail.com",
    description="A CLI based advanced calculator with scientific operations.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "satnacal=satnacal.calculator:main"
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
