# `save-page-as-md`

Download a webpage and save its content as Markdown, organizing the output on disk to mirror the webpage's domain and path.

## Installation

```bash
pip install save-page-as-md
```

## Usage

```bash
python -m save_page_as_md <URL> [-o OUTPUT]
```

- `-o OUTPUT`, `--output OUTPUT`: Optional. File path to write output Markdown.
  - Use `-` to print to stdout.
  - If not provided, output is saved in a folder structure based on the URL (see below).

## Examples

**Save the Python Wikipedia page in a folder structure mirroring its URL:**

```bash
python -m save_page_as_md https://en.wikipedia.org/wiki/Python_(programming_language)
```

Output will be placed in the directory:

```
./en.wikipedia.org/wiki/Python_(programming_language)/index.md
```

Save to a custom file:

```bash
python -m save_page_as_md https://example.com -o example.md
```

Print Markdown to the terminal:

```bash
python -m save_page_as_md https://example.com -o -
```

## Caveats

- For sites that require login or have JavaScript-loaded content, results may be incomplete.
- Only HTTP and HTTPS are supported.
- Some rare filenames/paths may be problematic on Windows due to reserved device names (e.g., `CON`, `AUX`) - review output on Windows systems.

## Contributing

Contributions are welcome! Please submit pull requests or open issues on the GitHub repository.

## License

This project is licensed under the [MIT License](LICENSE).
