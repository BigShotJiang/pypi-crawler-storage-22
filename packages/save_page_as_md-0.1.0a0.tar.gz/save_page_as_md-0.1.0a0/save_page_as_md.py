import argparse
import os
import os.path
import posixpath
import sys
from collections import deque
from fspathverbs import Root, Parent, Current, Child, compile_to_fspathverbs
from markdownify import markdownify as md

if sys.version_info < (3,):
    from urllib2 import urlopen
    from urlparse import urlparse
else:
    from urllib.request import urlopen
    from urllib.parse import urlparse


def save_html_as_md(url):
    response = urlopen(url)
    html_str = response.read()
    response.close()

    return md(html_str)


def url_to_path_components(url):
    parsed = urlparse(url)
    
    components = deque()
    
    verbs = compile_to_fspathverbs(
        parsed.path,
        split=posixpath.split
    )
    for verb in verbs:
        if isinstance(verb, Root):
            components.clear()
        elif isinstance(verb, Parent):
            components.pop()
        elif isinstance(verb, Current):
            pass
        elif isinstance(verb, Child):
            components.append(verb.child)

    components.appendleft(parsed.netloc)

    return components


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('url')
    parser.add_argument(
        '-o', '--output',
        required=False,
        help='Output file path (- for stdout)'
    )
    args = parser.parse_args()

    url = args.url
    output_file_path = args.output
    
    markdown_str = save_html_as_md(url)

    if not output_file_path:
        path_components = url_to_path_components(url)
        path = '.'
        for path_component in path_components:
            path = os.path.join(path, path_component)
            if not os.path.isdir(path):
                os.mkdir(path)
        output_file_path = os.path.join(path, 'index.md')

    if output_file_path == '-':
        print(markdown_str)
    else:
        with open(output_file_path, 'w') as f:
            f.write(markdown_str)


if __name__ == '__main__':
    main()
