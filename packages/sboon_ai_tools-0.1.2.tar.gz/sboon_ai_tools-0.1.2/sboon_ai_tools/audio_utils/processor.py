class processor:
    # statements (attributes and methods)
    pass