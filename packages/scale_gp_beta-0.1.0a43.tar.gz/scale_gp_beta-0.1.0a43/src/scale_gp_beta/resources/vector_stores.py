# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable
from typing_extensions import Literal

import httpx

from ..types import (
    vector_store_list_params,
    vector_store_count_params,
    vector_store_query_params,
    vector_store_create_params,
    vector_store_delete_params,
    vector_store_upsert_params,
    vector_store_vectors_params,
    vector_store_configure_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursorPage, AsyncCursorPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.vector_store import VectorStore
from ..types.vector_store_drop_response import VectorStoreDropResponse
from ..types.vector_store_count_response import VectorStoreCountResponse
from ..types.vector_store_query_response import VectorStoreQueryResponse
from ..types.vector_store_delete_response import VectorStoreDeleteResponse
from ..types.vector_store_upsert_response import VectorStoreUpsertResponse
from ..types.vector_store_vectors_response import VectorStoreVectorsResponse

__all__ = ["VectorStoresResource", "AsyncVectorStoresResource"]


class VectorStoresResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> VectorStoresResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/scaleapi/sgp-python-beta#accessing-raw-response-data-eg-headers
        """
        return VectorStoresResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> VectorStoresResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/scaleapi/sgp-python-beta#with_streaming_response
        """
        return VectorStoresResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        embedding_model: Literal[
            "sentence-transformers/all-MiniLM-L12-v2",
            "sentence-transformers/all-mpnet-base-v2",
            "sentence-transformers/multi-qa-distilbert-cos-v1",
            "sentence-transformers/paraphrase-multilingual-mpnet-base-v2",
            "openai/text-embedding-ada-002",
            "openai/text-embedding-3-small",
            "openai/text-embedding-3-large",
            "embed-english-v3.0",
            "embed-english-light-v3.0",
            "embed-multilingual-v3.0",
        ],
        name: str,
        indexed_metadata_fields: Dict[str, Literal["string", "number", "boolean", "object", "list"]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStore:
        """
        Create a new vector store.

        The vector store will be scoped to the authenticated account. The name must be
        unique within the account.

        Args: request: Vector store creation parameters including name, dimensions, and
        optional model vector_store_use_case: Injected vector store use case

        Returns: The created vector store details

        Args:
          embedding_model: The embedding model to use

          name: A unique name for the vector store within the account

          indexed_metadata_fields: Dictionary mapping metadata field names to their types for efficient filtering.
              Only STRING, NUMBER, and BOOLEAN types can be indexed.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v5/vector-stores/create",
            body=maybe_transform(
                {
                    "embedding_model": embedding_model,
                    "name": name,
                    "indexed_metadata_fields": indexed_metadata_fields,
                },
                vector_store_create_params.VectorStoreCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStore,
        )

    def retrieve(
        self,
        vector_store_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStore:
        """
        Get a vector store by name.

        Args: vector_store_name: The unique name of the vector store within the account
        vector_store_use_case: Injected vector store use case

        Returns: The vector store details

        Args:
          vector_store_name: The name of the vector store

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._get(
            f"/v5/vector-stores/{vector_store_name}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStore,
        )

    def list(
        self,
        *,
        ending_before: str | Omit = omit,
        limit: int | Omit = omit,
        sort_by: str | Omit = omit,
        sort_order: Literal["asc", "desc"] | Omit = omit,
        starting_after: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPage[VectorStore]:
        """
        List all vector stores for the current account with pagination.

        Returns a paginated list of vector stores owned by the authenticated account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v5/vector-stores",
            page=SyncCursorPage[VectorStore],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "ending_before": ending_before,
                        "limit": limit,
                        "sort_by": sort_by,
                        "sort_order": sort_order,
                        "starting_after": starting_after,
                    },
                    vector_store_list_params.VectorStoreListParams,
                ),
            ),
            model=VectorStore,
        )

    def delete(
        self,
        vector_store_name: str,
        *,
        filter: Dict[str, object] | Omit = omit,
        ids: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreDeleteResponse:
        """
        Delete documents from a vector store by IDs or filter.

        Args: request: Either IDs or filter criteria for deletion vector_store_name: The
        unique name of the vector store vector_store_use_case: Injected vector store use
        case

        Returns: Number of documents deleted

        Args:
          vector_store_name: The name of the vector store

          filter: Metadata filter expression for deletion

          ids: Array of document IDs to delete

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._post(
            f"/v5/vector-stores/{vector_store_name}/delete",
            body=maybe_transform(
                {
                    "filter": filter,
                    "ids": ids,
                },
                vector_store_delete_params.VectorStoreDeleteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreDeleteResponse,
        )

    def configure(
        self,
        vector_store_name: str,
        *,
        indexed_metadata_fields: Dict[str, Literal["string", "number", "boolean", "object", "list"]],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStore:
        """
        Configure the settings of a vector store.

        Currently only supports updating indexed_metadata_fields. The name,
        embedding_dimensions, and embedding_model are immutable after creation.

        Args: request: Configuration update with indexed_metadata_fields
        vector_store_name: The unique name of the vector store within the account
        vector_store_use_case: Injected vector store use case

        Returns: The updated vector store details

        Args:
          vector_store_name: The name of the vector store

          indexed_metadata_fields: Dictionary mapping metadata field names to their types. Only STRING, NUMBER, and
              BOOLEAN types can be indexed.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._post(
            f"/v5/vector-stores/{vector_store_name}/configure",
            body=maybe_transform(
                {"indexed_metadata_fields": indexed_metadata_fields},
                vector_store_configure_params.VectorStoreConfigureParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStore,
        )

    def count(
        self,
        vector_store_name: str,
        *,
        filter: Dict[str, object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreCountResponse:
        """
        Count documents in a vector store, optionally filtered by metadata.

        Args: vector_store_name: The unique name of the vector store request: Optional
        filter criteria (empty body counts all documents) vector_store_use_case:
        Injected vector store use case

        Returns: The count of documents matching the criteria

        Args:
          vector_store_name: The name of the vector store

          filter: Metadata filter expression

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._post(
            f"/v5/vector-stores/{vector_store_name}/count",
            body=maybe_transform({"filter": filter}, vector_store_count_params.VectorStoreCountParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreCountResponse,
        )

    def drop(
        self,
        vector_store_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreDropResponse:
        """
        Delete (drop) a vector store by name.

        This is a hard delete operation that permanently removes the vector store.

        Args: vector_store_name: The unique name of the vector store within the account
        vector_store_use_case: Injected vector store use case

        Returns: Deletion confirmation with the vector store ID

        Args:
          vector_store_name: The name of the vector store

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._post(
            f"/v5/vector-stores/{vector_store_name}/drop",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreDropResponse,
        )

    def query(
        self,
        vector_store_name: str,
        *,
        text: str,
        filter: Dict[str, object] | Omit = omit,
        include_vectors: bool | Omit = omit,
        query_type: Literal["semantic", "lexical", "hybrid"] | Omit = omit,
        rerank: bool | Omit = omit,
        rerank_model: str | Omit = omit,
        rerank_top_n: int | Omit = omit,
        top_k: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreQueryResponse:
        """
        Query documents by similarity search.

        Supports semantic (vector), lexical (text), or hybrid search modes.

        Args: request: Query parameters including text, filters, and reranking options
        vector_store_name: The unique name of the vector store vector_store_use_case:
        Injected vector store use case

        Returns: Matching documents with similarity scores and query metadata

        Args:
          vector_store_name: The name of the vector store

          text: Text query for automatic embedding (required)

          filter: Metadata filter expression

          include_vectors: Include embedding vectors in response

          query_type: Query type: semantic, lexical, or hybrid

          rerank: Enable reranking of search results

          rerank_model: Reranking model to use (uses system default if not specified)

          rerank_top_n: Number of results after reranking (defaults to top_k)

          top_k: Number of search results to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._post(
            f"/v5/vector-stores/{vector_store_name}/query",
            body=maybe_transform(
                {
                    "text": text,
                    "filter": filter,
                    "include_vectors": include_vectors,
                    "query_type": query_type,
                    "rerank": rerank,
                    "rerank_model": rerank_model,
                    "rerank_top_n": rerank_top_n,
                    "top_k": top_k,
                },
                vector_store_query_params.VectorStoreQueryParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreQueryResponse,
        )

    def upsert(
        self,
        vector_store_name: str,
        *,
        vectors: Iterable[vector_store_upsert_params.Vector],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreUpsertResponse:
        """
        Insert or update documents in a vector store.

        Existing documents (by ID) will be updated, new documents will be inserted.

        Args: request: Array of documents to upsert vector_store_name: The unique name
        of the vector store vector_store_use_case: Injected vector store use case

        Returns: Batch operation results with success/failure counts

        Args:
          vector_store_name: The name of the vector store

          vectors: Array of documents to upsert

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._post(
            f"/v5/vector-stores/{vector_store_name}/upsert",
            body=maybe_transform({"vectors": vectors}, vector_store_upsert_params.VectorStoreUpsertParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreUpsertResponse,
        )

    def vectors(
        self,
        vector_store_name: str,
        *,
        cursor: str | Omit = omit,
        filter: str | Omit = omit,
        include_vectors: bool | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreVectorsResponse:
        """
        List documents in a vector store with pagination.

        Args: vector_store_name: The unique name of the vector store limit: Maximum
        number of documents per page (max 100 with vectors, 1000 without) cursor:
        Pagination cursor from previous response filter_param: Optional metadata filter
        (JSON string) include_vectors: Whether to include embedding vectors
        vector_store_use_case: Injected vector store use case

        Returns: Paginated list of documents

        Args:
          vector_store_name: The name of the vector store

          cursor: Pagination cursor

          filter: Metadata filter expression (JSON)

          include_vectors: Include embedding vectors

          limit: Vectors per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return self._get(
            f"/v5/vector-stores/{vector_store_name}/vectors",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "filter": filter,
                        "include_vectors": include_vectors,
                        "limit": limit,
                    },
                    vector_store_vectors_params.VectorStoreVectorsParams,
                ),
            ),
            cast_to=VectorStoreVectorsResponse,
        )


class AsyncVectorStoresResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncVectorStoresResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/scaleapi/sgp-python-beta#accessing-raw-response-data-eg-headers
        """
        return AsyncVectorStoresResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncVectorStoresResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/scaleapi/sgp-python-beta#with_streaming_response
        """
        return AsyncVectorStoresResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        embedding_model: Literal[
            "sentence-transformers/all-MiniLM-L12-v2",
            "sentence-transformers/all-mpnet-base-v2",
            "sentence-transformers/multi-qa-distilbert-cos-v1",
            "sentence-transformers/paraphrase-multilingual-mpnet-base-v2",
            "openai/text-embedding-ada-002",
            "openai/text-embedding-3-small",
            "openai/text-embedding-3-large",
            "embed-english-v3.0",
            "embed-english-light-v3.0",
            "embed-multilingual-v3.0",
        ],
        name: str,
        indexed_metadata_fields: Dict[str, Literal["string", "number", "boolean", "object", "list"]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStore:
        """
        Create a new vector store.

        The vector store will be scoped to the authenticated account. The name must be
        unique within the account.

        Args: request: Vector store creation parameters including name, dimensions, and
        optional model vector_store_use_case: Injected vector store use case

        Returns: The created vector store details

        Args:
          embedding_model: The embedding model to use

          name: A unique name for the vector store within the account

          indexed_metadata_fields: Dictionary mapping metadata field names to their types for efficient filtering.
              Only STRING, NUMBER, and BOOLEAN types can be indexed.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v5/vector-stores/create",
            body=await async_maybe_transform(
                {
                    "embedding_model": embedding_model,
                    "name": name,
                    "indexed_metadata_fields": indexed_metadata_fields,
                },
                vector_store_create_params.VectorStoreCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStore,
        )

    async def retrieve(
        self,
        vector_store_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStore:
        """
        Get a vector store by name.

        Args: vector_store_name: The unique name of the vector store within the account
        vector_store_use_case: Injected vector store use case

        Returns: The vector store details

        Args:
          vector_store_name: The name of the vector store

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._get(
            f"/v5/vector-stores/{vector_store_name}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStore,
        )

    def list(
        self,
        *,
        ending_before: str | Omit = omit,
        limit: int | Omit = omit,
        sort_by: str | Omit = omit,
        sort_order: Literal["asc", "desc"] | Omit = omit,
        starting_after: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[VectorStore, AsyncCursorPage[VectorStore]]:
        """
        List all vector stores for the current account with pagination.

        Returns a paginated list of vector stores owned by the authenticated account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v5/vector-stores",
            page=AsyncCursorPage[VectorStore],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "ending_before": ending_before,
                        "limit": limit,
                        "sort_by": sort_by,
                        "sort_order": sort_order,
                        "starting_after": starting_after,
                    },
                    vector_store_list_params.VectorStoreListParams,
                ),
            ),
            model=VectorStore,
        )

    async def delete(
        self,
        vector_store_name: str,
        *,
        filter: Dict[str, object] | Omit = omit,
        ids: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreDeleteResponse:
        """
        Delete documents from a vector store by IDs or filter.

        Args: request: Either IDs or filter criteria for deletion vector_store_name: The
        unique name of the vector store vector_store_use_case: Injected vector store use
        case

        Returns: Number of documents deleted

        Args:
          vector_store_name: The name of the vector store

          filter: Metadata filter expression for deletion

          ids: Array of document IDs to delete

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._post(
            f"/v5/vector-stores/{vector_store_name}/delete",
            body=await async_maybe_transform(
                {
                    "filter": filter,
                    "ids": ids,
                },
                vector_store_delete_params.VectorStoreDeleteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreDeleteResponse,
        )

    async def configure(
        self,
        vector_store_name: str,
        *,
        indexed_metadata_fields: Dict[str, Literal["string", "number", "boolean", "object", "list"]],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStore:
        """
        Configure the settings of a vector store.

        Currently only supports updating indexed_metadata_fields. The name,
        embedding_dimensions, and embedding_model are immutable after creation.

        Args: request: Configuration update with indexed_metadata_fields
        vector_store_name: The unique name of the vector store within the account
        vector_store_use_case: Injected vector store use case

        Returns: The updated vector store details

        Args:
          vector_store_name: The name of the vector store

          indexed_metadata_fields: Dictionary mapping metadata field names to their types. Only STRING, NUMBER, and
              BOOLEAN types can be indexed.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._post(
            f"/v5/vector-stores/{vector_store_name}/configure",
            body=await async_maybe_transform(
                {"indexed_metadata_fields": indexed_metadata_fields},
                vector_store_configure_params.VectorStoreConfigureParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStore,
        )

    async def count(
        self,
        vector_store_name: str,
        *,
        filter: Dict[str, object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreCountResponse:
        """
        Count documents in a vector store, optionally filtered by metadata.

        Args: vector_store_name: The unique name of the vector store request: Optional
        filter criteria (empty body counts all documents) vector_store_use_case:
        Injected vector store use case

        Returns: The count of documents matching the criteria

        Args:
          vector_store_name: The name of the vector store

          filter: Metadata filter expression

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._post(
            f"/v5/vector-stores/{vector_store_name}/count",
            body=await async_maybe_transform({"filter": filter}, vector_store_count_params.VectorStoreCountParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreCountResponse,
        )

    async def drop(
        self,
        vector_store_name: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreDropResponse:
        """
        Delete (drop) a vector store by name.

        This is a hard delete operation that permanently removes the vector store.

        Args: vector_store_name: The unique name of the vector store within the account
        vector_store_use_case: Injected vector store use case

        Returns: Deletion confirmation with the vector store ID

        Args:
          vector_store_name: The name of the vector store

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._post(
            f"/v5/vector-stores/{vector_store_name}/drop",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreDropResponse,
        )

    async def query(
        self,
        vector_store_name: str,
        *,
        text: str,
        filter: Dict[str, object] | Omit = omit,
        include_vectors: bool | Omit = omit,
        query_type: Literal["semantic", "lexical", "hybrid"] | Omit = omit,
        rerank: bool | Omit = omit,
        rerank_model: str | Omit = omit,
        rerank_top_n: int | Omit = omit,
        top_k: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreQueryResponse:
        """
        Query documents by similarity search.

        Supports semantic (vector), lexical (text), or hybrid search modes.

        Args: request: Query parameters including text, filters, and reranking options
        vector_store_name: The unique name of the vector store vector_store_use_case:
        Injected vector store use case

        Returns: Matching documents with similarity scores and query metadata

        Args:
          vector_store_name: The name of the vector store

          text: Text query for automatic embedding (required)

          filter: Metadata filter expression

          include_vectors: Include embedding vectors in response

          query_type: Query type: semantic, lexical, or hybrid

          rerank: Enable reranking of search results

          rerank_model: Reranking model to use (uses system default if not specified)

          rerank_top_n: Number of results after reranking (defaults to top_k)

          top_k: Number of search results to return

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._post(
            f"/v5/vector-stores/{vector_store_name}/query",
            body=await async_maybe_transform(
                {
                    "text": text,
                    "filter": filter,
                    "include_vectors": include_vectors,
                    "query_type": query_type,
                    "rerank": rerank,
                    "rerank_model": rerank_model,
                    "rerank_top_n": rerank_top_n,
                    "top_k": top_k,
                },
                vector_store_query_params.VectorStoreQueryParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreQueryResponse,
        )

    async def upsert(
        self,
        vector_store_name: str,
        *,
        vectors: Iterable[vector_store_upsert_params.Vector],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreUpsertResponse:
        """
        Insert or update documents in a vector store.

        Existing documents (by ID) will be updated, new documents will be inserted.

        Args: request: Array of documents to upsert vector_store_name: The unique name
        of the vector store vector_store_use_case: Injected vector store use case

        Returns: Batch operation results with success/failure counts

        Args:
          vector_store_name: The name of the vector store

          vectors: Array of documents to upsert

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._post(
            f"/v5/vector-stores/{vector_store_name}/upsert",
            body=await async_maybe_transform({"vectors": vectors}, vector_store_upsert_params.VectorStoreUpsertParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VectorStoreUpsertResponse,
        )

    async def vectors(
        self,
        vector_store_name: str,
        *,
        cursor: str | Omit = omit,
        filter: str | Omit = omit,
        include_vectors: bool | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VectorStoreVectorsResponse:
        """
        List documents in a vector store with pagination.

        Args: vector_store_name: The unique name of the vector store limit: Maximum
        number of documents per page (max 100 with vectors, 1000 without) cursor:
        Pagination cursor from previous response filter_param: Optional metadata filter
        (JSON string) include_vectors: Whether to include embedding vectors
        vector_store_use_case: Injected vector store use case

        Returns: Paginated list of documents

        Args:
          vector_store_name: The name of the vector store

          cursor: Pagination cursor

          filter: Metadata filter expression (JSON)

          include_vectors: Include embedding vectors

          limit: Vectors per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not vector_store_name:
            raise ValueError(f"Expected a non-empty value for `vector_store_name` but received {vector_store_name!r}")
        return await self._get(
            f"/v5/vector-stores/{vector_store_name}/vectors",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "filter": filter,
                        "include_vectors": include_vectors,
                        "limit": limit,
                    },
                    vector_store_vectors_params.VectorStoreVectorsParams,
                ),
            ),
            cast_to=VectorStoreVectorsResponse,
        )


class VectorStoresResourceWithRawResponse:
    def __init__(self, vector_stores: VectorStoresResource) -> None:
        self._vector_stores = vector_stores

        self.create = to_raw_response_wrapper(
            vector_stores.create,
        )
        self.retrieve = to_raw_response_wrapper(
            vector_stores.retrieve,
        )
        self.list = to_raw_response_wrapper(
            vector_stores.list,
        )
        self.delete = to_raw_response_wrapper(
            vector_stores.delete,
        )
        self.configure = to_raw_response_wrapper(
            vector_stores.configure,
        )
        self.count = to_raw_response_wrapper(
            vector_stores.count,
        )
        self.drop = to_raw_response_wrapper(
            vector_stores.drop,
        )
        self.query = to_raw_response_wrapper(
            vector_stores.query,
        )
        self.upsert = to_raw_response_wrapper(
            vector_stores.upsert,
        )
        self.vectors = to_raw_response_wrapper(
            vector_stores.vectors,
        )


class AsyncVectorStoresResourceWithRawResponse:
    def __init__(self, vector_stores: AsyncVectorStoresResource) -> None:
        self._vector_stores = vector_stores

        self.create = async_to_raw_response_wrapper(
            vector_stores.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            vector_stores.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            vector_stores.list,
        )
        self.delete = async_to_raw_response_wrapper(
            vector_stores.delete,
        )
        self.configure = async_to_raw_response_wrapper(
            vector_stores.configure,
        )
        self.count = async_to_raw_response_wrapper(
            vector_stores.count,
        )
        self.drop = async_to_raw_response_wrapper(
            vector_stores.drop,
        )
        self.query = async_to_raw_response_wrapper(
            vector_stores.query,
        )
        self.upsert = async_to_raw_response_wrapper(
            vector_stores.upsert,
        )
        self.vectors = async_to_raw_response_wrapper(
            vector_stores.vectors,
        )


class VectorStoresResourceWithStreamingResponse:
    def __init__(self, vector_stores: VectorStoresResource) -> None:
        self._vector_stores = vector_stores

        self.create = to_streamed_response_wrapper(
            vector_stores.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            vector_stores.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            vector_stores.list,
        )
        self.delete = to_streamed_response_wrapper(
            vector_stores.delete,
        )
        self.configure = to_streamed_response_wrapper(
            vector_stores.configure,
        )
        self.count = to_streamed_response_wrapper(
            vector_stores.count,
        )
        self.drop = to_streamed_response_wrapper(
            vector_stores.drop,
        )
        self.query = to_streamed_response_wrapper(
            vector_stores.query,
        )
        self.upsert = to_streamed_response_wrapper(
            vector_stores.upsert,
        )
        self.vectors = to_streamed_response_wrapper(
            vector_stores.vectors,
        )


class AsyncVectorStoresResourceWithStreamingResponse:
    def __init__(self, vector_stores: AsyncVectorStoresResource) -> None:
        self._vector_stores = vector_stores

        self.create = async_to_streamed_response_wrapper(
            vector_stores.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            vector_stores.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            vector_stores.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            vector_stores.delete,
        )
        self.configure = async_to_streamed_response_wrapper(
            vector_stores.configure,
        )
        self.count = async_to_streamed_response_wrapper(
            vector_stores.count,
        )
        self.drop = async_to_streamed_response_wrapper(
            vector_stores.drop,
        )
        self.query = async_to_streamed_response_wrapper(
            vector_stores.query,
        )
        self.upsert = async_to_streamed_response_wrapper(
            vector_stores.upsert,
        )
        self.vectors = async_to_streamed_response_wrapper(
            vector_stores.vectors,
        )
