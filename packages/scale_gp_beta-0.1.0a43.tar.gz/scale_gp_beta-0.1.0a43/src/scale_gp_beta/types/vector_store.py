# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["VectorStore"]


class VectorStore(BaseModel):
    """Response model for vector store operations."""

    created_at: datetime
    """Timestamp of creation"""

    embedding_dimensions: int
    """Dimension size of the embeddings"""

    embedding_model: Literal[
        "sentence-transformers/all-MiniLM-L12-v2",
        "sentence-transformers/all-mpnet-base-v2",
        "sentence-transformers/multi-qa-distilbert-cos-v1",
        "sentence-transformers/paraphrase-multilingual-mpnet-base-v2",
        "openai/text-embedding-ada-002",
        "openai/text-embedding-3-small",
        "openai/text-embedding-3-large",
        "embed-english-v3.0",
        "embed-english-light-v3.0",
        "embed-multilingual-v3.0",
    ]
    """The embedding model"""

    name: str
    """The name of the vector store"""

    updated_at: datetime
    """Timestamp of last update"""

    indexed_metadata_fields: Optional[Dict[str, Literal["string", "number", "boolean", "object", "list"]]] = None
    """Dictionary mapping metadata field names to their types"""
