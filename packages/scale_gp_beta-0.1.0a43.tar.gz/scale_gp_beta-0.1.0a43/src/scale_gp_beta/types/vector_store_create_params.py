# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, TypedDict

__all__ = ["VectorStoreCreateParams"]


class VectorStoreCreateParams(TypedDict, total=False):
    embedding_model: Required[
        Literal[
            "sentence-transformers/all-MiniLM-L12-v2",
            "sentence-transformers/all-mpnet-base-v2",
            "sentence-transformers/multi-qa-distilbert-cos-v1",
            "sentence-transformers/paraphrase-multilingual-mpnet-base-v2",
            "openai/text-embedding-ada-002",
            "openai/text-embedding-3-small",
            "openai/text-embedding-3-large",
            "embed-english-v3.0",
            "embed-english-light-v3.0",
            "embed-multilingual-v3.0",
        ]
    ]
    """The embedding model to use"""

    name: Required[str]
    """A unique name for the vector store within the account"""

    indexed_metadata_fields: Dict[str, Literal["string", "number", "boolean", "object", "list"]]
    """Dictionary mapping metadata field names to their types for efficient filtering.

    Only STRING, NUMBER, and BOOLEAN types can be indexed.
    """
