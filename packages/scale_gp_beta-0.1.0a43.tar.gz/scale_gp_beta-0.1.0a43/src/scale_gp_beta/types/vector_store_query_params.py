# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, TypedDict

__all__ = ["VectorStoreQueryParams"]


class VectorStoreQueryParams(TypedDict, total=False):
    text: Required[str]
    """Text query for automatic embedding (required)"""

    filter: Dict[str, object]
    """Metadata filter expression"""

    include_vectors: bool
    """Include embedding vectors in response"""

    query_type: Literal["semantic", "lexical", "hybrid"]
    """Query type: semantic, lexical, or hybrid"""

    rerank: bool
    """Enable reranking of search results"""

    rerank_model: str
    """Reranking model to use (uses system default if not specified)"""

    rerank_top_n: int
    """Number of results after reranking (defaults to top_k)"""

    top_k: int
    """Number of search results to return"""
