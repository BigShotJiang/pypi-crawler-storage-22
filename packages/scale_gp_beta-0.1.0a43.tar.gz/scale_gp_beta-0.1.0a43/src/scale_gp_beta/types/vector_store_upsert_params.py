# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable
from typing_extensions import Required, TypedDict

__all__ = ["VectorStoreUpsertParams", "Vector"]


class VectorStoreUpsertParams(TypedDict, total=False):
    vectors: Required[Iterable[Vector]]
    """Array of documents to upsert"""


class Vector(TypedDict, total=False):
    """A document for insert/upsert operations."""

    id: str
    """Unique document ID (auto-generated if not provided)"""

    metadata: Dict[str, object]
    """Key-value metadata"""

    text: str
    """Text content to be embedded"""

    vector: Iterable[float]
    """Pre-computed embedding vector"""
