# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel

__all__ = ["VectorStoreUpsertResponse"]


class VectorStoreUpsertResponse(BaseModel):
    """Response for batch insert/upsert operations."""

    failed: int
    """Failed operation count"""

    successful: int
    """Successful operation count"""

    total_attempted: int
    """Total operations attempted"""

    error_messages: Optional[List[str]] = None
    """Error messages from failed operations"""
