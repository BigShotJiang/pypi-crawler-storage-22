# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["VectorStoreVectorsParams"]


class VectorStoreVectorsParams(TypedDict, total=False):
    cursor: str
    """Pagination cursor"""

    filter: str
    """Metadata filter expression (JSON)"""

    include_vectors: bool
    """Include embedding vectors"""

    limit: int
    """Vectors per page"""
