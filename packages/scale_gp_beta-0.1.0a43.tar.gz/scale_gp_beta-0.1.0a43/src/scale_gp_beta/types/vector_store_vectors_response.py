# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from .._models import BaseModel

__all__ = ["VectorStoreVectorsResponse", "Vector"]


class Vector(BaseModel):
    """A document in list/query responses."""

    id: str
    """Document ID"""

    metadata: Optional[Dict[str, object]] = None
    """Key-value metadata"""

    score: Optional[float] = None
    """Similarity score (for query results)"""

    text: Optional[str] = None
    """Text content"""

    vector: Optional[List[float]] = None
    """Embedding vector (if requested)"""


class VectorStoreVectorsResponse(BaseModel):
    """Response for list operation."""

    vectors: List[Vector]
    """Array of documents"""

    next_cursor: Optional[str] = None
    """Pagination cursor for next page"""
