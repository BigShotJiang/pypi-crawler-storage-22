declare function loadFetch(): void;

loadFetch();
