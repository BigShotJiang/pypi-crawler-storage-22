// Type declarations for tablesort.js
declare class Tablesort {
  constructor(el: Element, options?: { ascending?: boolean });
  refresh(): void;
}

export = Tablesort;
export default Tablesort;
