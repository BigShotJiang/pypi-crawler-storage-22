from pyproj import Proj
import time

time.sleep(1)
time.sleep(0.1)
