"""Tests for APIClient"""
