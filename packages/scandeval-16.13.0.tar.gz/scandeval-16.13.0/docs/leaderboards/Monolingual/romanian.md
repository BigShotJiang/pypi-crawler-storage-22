---
hide:
    - toc
---
# 🇷🇴 Romanian

See the [leaderboard page](/leaderboards) for more information about all the columns.

/// tab | Generative Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-CLBK0" src="https://datawrapper.dwcdn.net/CLBK0" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="917" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | NLU Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-bdoeS" src="https://datawrapper.dwcdn.net/bdoeS" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="886" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | Generative Scatter Plot
<iframe title="Performance of Generative Language Models on Romanian Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-uaz9i" src="https://datawrapper.dwcdn.net/uaz9i" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | NLU Scatter Plot
<iframe title="Performance of Language Models on Romanian NLU Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-QQdYf" src="https://datawrapper.dwcdn.net/QQdYf" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

<!-- This disables the requirement that all lines must be shorter than 88 characters -->
<!-- markdownlint-configure-file { "MD013": false } -->
