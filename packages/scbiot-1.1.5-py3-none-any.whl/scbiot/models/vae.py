from __future__ import annotations

import math
from collections.abc import Callable, Sequence
from typing import Literal, TypeAlias

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as nn_init
from torch import Tensor

Categories: TypeAlias = Sequence[int] | None
Initialization: TypeAlias = Literal["xavier", "kaiming"]





class Tokenizer(nn.Module):
    def __init__(
        self,
        d_numerical: int,
        categories: Categories,
        d_token: int,
        bias: bool,
    ) -> None:
        super().__init__()
        if categories is None:
            d_bias = d_numerical
            self.category_offsets = None
            self.category_embeddings = None
        else:
            d_bias = d_numerical + len(categories)
            category_offsets = torch.tensor([0] + categories[:-1]).cumsum(0)
            self.register_buffer('category_offsets', category_offsets)
            self.category_embeddings = nn.Embedding(sum(categories), d_token)
            nn_init.kaiming_uniform_(self.category_embeddings.weight, a=math.sqrt(5))
            print(f'{self.category_embeddings.weight.shape=}')

        # take [CLS] token into account
        self.weight = nn.Parameter(Tensor(d_numerical + 1, d_token))
        self.bias = nn.Parameter(Tensor(d_bias, d_token)) if bias else None
        # The initialization is inspired by nn.Linear
        nn_init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            nn_init.kaiming_uniform_(self.bias, a=math.sqrt(5))

    @property
    def n_tokens(self) -> int:
        return len(self.weight) + (
            0 if self.category_offsets is None else len(self.category_offsets)
        )

    def forward(self, x_num: Tensor | None, x_cat: Tensor | None) -> Tensor:
        x_some = x_num if x_cat is None else x_cat
        assert x_some is not None
        x_num = torch.cat(
            [torch.ones(len(x_some), 1, device=x_some.device)]  # [CLS]
            + ([] if x_num is None else [x_num]),
            dim=1,
        )
    
        x = self.weight[None] * x_num[:, :, None]

        if x_cat is not None:
            x = torch.cat(
                [x, self.category_embeddings(x_cat + self.category_offsets[None])],
                dim=1,
            )
        if self.bias is not None:
            bias = torch.cat(
                [
                    torch.zeros(1, self.bias.shape[1], device=x.device),
                    self.bias,
                ]
            )
            x = x + bias[None]

        return x
    
    

class MLP(nn.Module):
    def __init__(self, dims: Sequence[int]) -> None:
        super(MLP, self).__init__()
        self.dims = dims
        self.layers = []
        for in_dim, out_dim in zip(dims, dims[1:]):
            self.layers.append(nn.Linear(in_dim, out_dim))
            self.layers.append(nn.BatchNorm1d(out_dim))
            self.layers.append(nn.ReLU())

        self.mlp = nn.Sequential(*self.layers[:-1])  # Exclude final ReLU non-linearity

    def forward(self, x: Tensor) -> Tensor:
        x = self.mlp(x)
        return x



class MultiheadAttention(nn.Module):
    def __init__(
        self,
        d: int,
        n_heads: int,
        dropout: float,
        initialization: Initialization = "kaiming",
    ) -> None:

        if n_heads > 1:
            assert d % n_heads == 0
        assert initialization in ['xavier', 'kaiming']

        super().__init__()
        self.W_q = nn.Linear(d, d)
        self.W_k = nn.Linear(d, d)
        self.W_v = nn.Linear(d, d)
        self.W_out = nn.Linear(d, d) if n_heads > 1 else None
        self.n_heads = n_heads
        self.dropout = nn.Dropout(dropout) if dropout else None

        for m in [self.W_q, self.W_k, self.W_v]:
            if initialization == 'xavier' and (n_heads > 1 or m is not self.W_v):
                # gain is needed since W_qkv is represented with 3 separate layers
                nn_init.xavier_uniform_(m.weight, gain=1 / math.sqrt(2))
            nn_init.zeros_(m.bias)
        if self.W_out is not None:
            nn_init.zeros_(self.W_out.bias)

    def _reshape(self, x: Tensor) -> Tensor:
        batch_size, n_tokens, d = x.shape
        d_head = d // self.n_heads
        return (
            x.reshape(batch_size, n_tokens, self.n_heads, d_head)
            .transpose(1, 2)
            .reshape(batch_size * self.n_heads, n_tokens, d_head)
        )

    def forward(
        self,
        x_q: Tensor,
        x_kv: Tensor,
        key_compression: Callable[[Tensor], Tensor] | None = None,
        value_compression: Callable[[Tensor], Tensor] | None = None,
    ) -> Tensor:
  
        q, k, v = self.W_q(x_q), self.W_k(x_kv), self.W_v(x_kv)
        for tensor in [q, k, v]:
            assert tensor.shape[-1] % self.n_heads == 0
        if key_compression is not None:
            assert value_compression is not None
            k = key_compression(k.transpose(1, 2)).transpose(1, 2)
            v = value_compression(v.transpose(1, 2)).transpose(1, 2)
        else:
            assert value_compression is None

        q = self._reshape(q).unsqueeze(1)
        k = self._reshape(k).unsqueeze(1)
        v = self._reshape(v).unsqueeze(1)

        # Enable the Math or Efficient attention backends
        from torch.nn.attention import SDPBackend
        with torch.nn.attention.sdpa_kernel([SDPBackend.MATH, SDPBackend.EFFICIENT_ATTENTION]): # SDPBackend.FLASH_ATTENTION [SDPBackend.MATH, SDPBackend.EFFICIENT_ATTENTION]
            x = F.scaled_dot_product_attention(q, k, v).squeeze(1)

        # >>>>>> NEW: merge heads back to [B, N, d] before W_out <<<<<<
        B = x_q.shape[0]
        N = x.shape[1]
        Dh = x.shape[2]
        H = self.n_heads
        # x: [B*H, N, Dh] -> [B, H, N, Dh] -> [B, N, H*Dh] == [B, N, d]
        x = x.view(B, H, N, Dh).transpose(1, 2).contiguous().view(B, N, H * Dh)
        
        if self.W_out is not None:
            x = self.W_out(x)

        return x


        
class Transformer(nn.Module):

    def __init__(
        self,
        n_layers: int,
        d_token: int,
        n_heads: int,
        d_out: int,
        d_ffn_factor: int,
        attention_dropout: float = 0.0,
        ffn_dropout: float = 0.0,
        residual_dropout: float = 0.0,
        prenormalization: bool = True,
        initialization: Initialization = "kaiming",
    ) -> None:
        super().__init__()

        def make_normalization():
            return nn.LayerNorm(d_token)            

        d_hidden = int(d_token * d_ffn_factor)
        self.layers = nn.ModuleList([])
        for layer_idx in range(n_layers):
            layer = nn.ModuleDict(
                {
                    'attention': MultiheadAttention(
                        d_token, n_heads, attention_dropout, initialization
                    ),
                    'linear0': nn.Linear(
                        d_token, d_hidden
                    ),
                    'linear1': nn.Linear(d_hidden, d_token),
                    'norm1': make_normalization(),
                }
            )
            if not prenormalization or layer_idx:
                layer['norm0'] = make_normalization()
   
            self.layers.append(layer)

        self.activation = nn.ReLU()
        self.last_activation = nn.ReLU()        
        self.prenormalization = prenormalization
        self.last_normalization = make_normalization() if prenormalization else None
        self.ffn_dropout = ffn_dropout
        self.residual_dropout = residual_dropout
        self.head = nn.Linear(d_token, d_out)


    def _start_residual(self, x: Tensor, layer: nn.ModuleDict, norm_idx: int) -> Tensor:
        x_residual = x
        if self.prenormalization:
            norm_key = f'norm{norm_idx}'
            if norm_key in layer:
                x_residual = layer[norm_key](x_residual)
        return x_residual

    def _end_residual(
        self,
        x: Tensor,
        x_residual: Tensor,
        layer: nn.ModuleDict,
        norm_idx: int,
    ) -> Tensor:
        if self.residual_dropout:
            x_residual = F.dropout(x_residual, self.residual_dropout, self.training)
        x = x + x_residual
        if not self.prenormalization:
            x = layer[f'norm{norm_idx}'](x)
        return x

    def forward(self, x: Tensor) -> Tensor:
        for layer_idx, layer in enumerate(self.layers):
            is_last_layer = layer_idx + 1 == len(self.layers)

            x_residual = self._start_residual(x, layer, 0)
            x_residual = layer['attention'](
                # for the last attention, it is enough to process only [CLS]
                x_residual,
                x_residual,
            )

            x = self._end_residual(x, x_residual, layer, 0)

            x_residual = self._start_residual(x, layer, 1)
            x_residual = layer['linear0'](x_residual)
            x_residual = self.activation(x_residual)
            if self.ffn_dropout:
                x_residual = F.dropout(x_residual, self.ffn_dropout, self.training)
            x_residual = layer['linear1'](x_residual)
            x = self._end_residual(x, x_residual, layer, 1)
        return x



class VAE(nn.Module):
    def __init__(
        self,
        d_numerical: int,
        categories: Categories,
        num_layers: int,
        hid_dim: int,
        n_head: int = 1,
        factor: int = 4,
        bias: bool = True,
        num_batches: int = 1,
    ) -> None:
        super(VAE, self).__init__()
 
        self.d_numerical = d_numerical
        self.categories = categories
        self.hid_dim = hid_dim
        d_token = hid_dim
        self.n_head = n_head

        self.Tokenizer = Tokenizer(d_numerical, categories, d_token, bias = bias)
        self.encoder_mu = Transformer(num_layers, hid_dim, n_head, hid_dim, factor)
        self.encoder_logvar = Transformer(num_layers, hid_dim, n_head, hid_dim, factor)

        self.decoder = Transformer(num_layers, hid_dim, n_head, hid_dim, factor)


    def get_embedding(self, x: Tensor) -> Tensor:
        return self.encoder_mu(x, x).detach() 

    def reparameterize(self, mu: Tensor, logvar: Tensor) -> Tensor:
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(
        self, x_num: Tensor | None, x_cat: Tensor | None
    ) -> tuple[Tensor, Tensor, Tensor, Tensor]:

        x = self.Tokenizer(x_num, x_cat)

        mu_z = self.encoder_mu(x)
        std_z = self.encoder_logvar(x)

        z = self.reparameterize(mu_z, std_z)

        h = self.decoder(z[:,1:])

        return z, h, mu_z, std_z

class Reconstructor(nn.Module):
    def __init__(self, d_numerical: int, categories: Categories, d_token: int) -> None:
        super(Reconstructor, self).__init__()

        self.d_numerical = d_numerical
        self.categories = categories
        self.d_token = d_token


        self.weight = nn.Parameter(Tensor(d_numerical, d_token))

        nn.init.xavier_uniform_(self.weight, gain=1 / math.sqrt(2))
        self.cat_recons = nn.ModuleList()

        if categories:
            for d in categories:
                recon = nn.Linear(d_token, d)
                nn.init.xavier_uniform_(recon.weight, gain=1 / math.sqrt(2))
                self.cat_recons.append(recon)

    def forward(self, h: Tensor) -> tuple[Tensor, list[Tensor]]:
        h_num  = h[:, :self.d_numerical]
        h_cat  = h[:, self.d_numerical:]

        recon_x_num = torch.mul(h_num, self.weight.unsqueeze(0)).sum(-1)
        recon_x_cat = []

        for i, recon in enumerate(self.cat_recons):
      
            recon_x_cat.append(recon(h_cat[:, i]))

        return recon_x_num, recon_x_cat


class Model_VAE(nn.Module):
    def __init__(
        self,
        num_layers: int,
        d_numerical: int,
        categories: Categories,
        d_token: int,
        n_head: int = 1,
        factor: int = 4,
        bias: bool = True,
    ) -> None:
        super(Model_VAE, self).__init__()
        self.Tokenizer = Tokenizer(d_numerical, categories, d_token, bias)
        self.VAE = VAE(d_numerical, categories, num_layers, d_token, n_head = n_head, factor = factor, bias = bias)
        self.Reconstructor = Reconstructor(d_numerical, categories, d_token)     

    def get_embedding(self, x_num: Tensor | None, x_cat: Tensor | None) -> Tensor:
        x = self.Tokenizer(x_num, x_cat)
        return self.VAE.get_embedding(x)

    def forward(
        self, x_num: Tensor | None, x_cat: Tensor | None
    ) -> tuple[Tensor, Tensor, list[Tensor], Tensor, Tensor]:

        z, h, mu_z, std_z = self.VAE(x_num, x_cat)

        # recon_x_num, recon_x_cat = self.Reconstructor(h[:, 1:])
        recon_x_num, recon_x_cat = self.Reconstructor(h)

        return z, recon_x_num, recon_x_cat, mu_z, std_z



class Encoder_model(nn.Module):
    """
    Token-level encoder that can return (z) or (z, mu, std).

    Args:
      num_layers, d_numerical, categories, d_token, n_head, factor, bias: same as before.

    Forward:
      forward(x_num, x_cat, return_all=False)
        - if return_all == False (default): returns z  (B, T, d_token)  [backward-compatible]
        - if return_all == True : returns (z, mu, std) all (B, T, d_token)
    """
    def __init__(
        self,
        num_layers: int,
        d_numerical: int,
        categories: Categories,
        d_token: int,
        n_head: int,
        factor: int,
        bias: bool = True,
    ) -> None:
        super(Encoder_model, self).__init__()
        self.Tokenizer   = Tokenizer(d_numerical, categories, d_token, bias)
        # generic latent stream (matches your previous self.VAE_Encoder)
        self.VAE_Encoder = Transformer(num_layers, d_token, n_head, d_token, factor)
        # parameter branches to optionally expose mu/std
        self.encoder_mu  = Transformer(num_layers, d_token, n_head, d_token, factor)
        self.encoder_std = Transformer(num_layers, d_token, n_head, d_token, factor)
        self._min_std = 1e-6

    def load_weights(self, Pretrained_VAE: Model_VAE) -> None:
        # Tokenizer
        if hasattr(Pretrained_VAE, "VAE") and hasattr(Pretrained_VAE.VAE, "Tokenizer"):
            self.Tokenizer.load_state_dict(Pretrained_VAE.VAE.Tokenizer.state_dict(), strict=False)
        # shared trunk if present; else reuse encoder_mu weights
        if hasattr(Pretrained_VAE.VAE, "encoder"):
            self.VAE_Encoder.load_state_dict(Pretrained_VAE.VAE.encoder.state_dict(), strict=False)
        elif hasattr(Pretrained_VAE.VAE, "encoder_mu"):
            self.VAE_Encoder.load_state_dict(Pretrained_VAE.VAE.encoder_mu.state_dict(), strict=False)
        # mu/std branches
        if hasattr(Pretrained_VAE.VAE, "encoder_mu"):
            self.encoder_mu.load_state_dict(Pretrained_VAE.VAE.encoder_mu.state_dict(), strict=False)
        if hasattr(Pretrained_VAE.VAE, "encoder_std"):
            self.encoder_std.load_state_dict(Pretrained_VAE.VAE.encoder_std.state_dict(), strict=False)

    def forward(
        self,
        x_num: Tensor | None,
        x_cat: Tensor | None,
        return_all: bool = False,
    ) -> Tensor | tuple[Tensor, Tensor, Tensor]:
        """
        Returns:
          - if return_all=False (default): z
          - if return_all=True : (z, mu, std)
        Shapes are token-level: (B, T, d_token)
        """
        x = self.Tokenizer(x_num, x_cat)        # (B, T, d)
        x_fp32 = x.float()

        z_fp32   = self.VAE_Encoder(x_fp32)
        if not return_all:
            return z_fp32.to(x.dtype)

        mu_fp32  = self.encoder_mu(x_fp32)
        raw_fp32 = self.encoder_std(x_fp32)
        std_fp32 = F.softplus(raw_fp32).clamp_min(self._min_std)

        z   = z_fp32.to(x.dtype)
        mu  = mu_fp32.to(x.dtype)
        std = std_fp32.to(x.dtype)
        return z, mu, std




class Decoder_model(nn.Module):
   def __init__(
       self,
       num_layers: int,
       d_numerical: int,
       categories: Categories,
       d_token: int,
       n_head: int,
       factor: int,
       bias: bool = True,
   ) -> None:
       super(Decoder_model, self).__init__()
       self.VAE_Decoder = Transformer(num_layers, d_token, n_head, d_token, factor)
       self.Detokenizer = Reconstructor(d_numerical, categories, d_token)

   def load_weights(self, Pretrained_VAE: Model_VAE) -> None:
       self.VAE_Decoder.load_state_dict(Pretrained_VAE.VAE.decoder.state_dict())
       self.Detokenizer.load_state_dict(Pretrained_VAE.Reconstructor.state_dict())

   def forward(self, z: Tensor) -> tuple[Tensor, list[Tensor]]:                 
       h = self.VAE_Decoder(z)      
       x_hat_num, x_hat_cat = self.Detokenizer(h)
       return x_hat_num, x_hat_cat
