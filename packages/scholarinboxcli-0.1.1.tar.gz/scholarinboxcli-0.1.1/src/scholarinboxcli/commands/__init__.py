"""Command groups for scholarinboxcli."""
