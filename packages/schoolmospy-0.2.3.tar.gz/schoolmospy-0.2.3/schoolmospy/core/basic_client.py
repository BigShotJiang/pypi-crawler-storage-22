from typing import Any

import httpx
from pydantic import BaseModel

from schoolmospy.utils.exceptions import APIError, AuthError, HTTPError, NotFoundError, ServerError


class BasicClient:
    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        profile_id: int | None = None,
        profile_type: str = "student",
        timeout: float = 15.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.profile_id = profile_id
        self.profile_type = profile_type
        self.timeout = timeout
        self.extra_headers: dict[str, str] = {}

    @property
    def headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json;charset=UTF-8",
            "User-Agent": "dnevniklib/1.0 (Python httpx)",
            "X-mes-subsystem": "familyweb",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if self.profile_id:
            headers["Profile-Id"] = str(self.profile_id)
        if self.profile_type:
            headers["Profile-Type"] = self.profile_type
        if self.extra_headers:
            headers.update(self.extra_headers)
        return headers

    async def _handle_response(
        self,
        response: httpx.Response,
        response_model: type[BaseModel] | None = None,
    ) -> Any:
        if response.is_success:
            if response_model:
                return response_model.model_validate(response.json())
            return response.json()

        text = response.text.strip()
        status = response.status_code

        if status == 401:
            raise AuthError("Unauthorized or invalid token", status, text)
        if status == 404:
            raise NotFoundError("Resource not found", status, text)
        if status >= 500:
            raise ServerError("Server error", status, text)
        raise HTTPError(f"Unexpected response ({status})", status, text)

    async def get(
        self,
        endpoint: str,
        response_model: type[BaseModel] | None = None,
        **kwargs: Any,
    ) -> Any:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        headers = self.headers
        if "headers" in kwargs:
            headers = {**headers, **kwargs.pop("headers")}
        async with httpx.AsyncClient(headers=headers, timeout=self.timeout) as client:
            try:
                resp = await client.get(url, **kwargs)
            except httpx.RequestError as e:
                raise APIError(f"Request failed: {e}") from e
            return await self._handle_response(resp, response_model)

    async def post(
        self,
        endpoint: str,
        data: Any = None,
        response_model: type[BaseModel] | None = None,
        **kwargs: Any,
    ) -> Any:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        headers = self.headers
        if "headers" in kwargs:
            headers = {**headers, **kwargs.pop("headers")}
        async with httpx.AsyncClient(headers=headers, timeout=self.timeout) as client:
            try:
                resp = await client.post(url, json=data, **kwargs)
            except httpx.RequestError as e:
                raise APIError(f"Request failed: {e}") from e
            return await self._handle_response(resp, response_model)
