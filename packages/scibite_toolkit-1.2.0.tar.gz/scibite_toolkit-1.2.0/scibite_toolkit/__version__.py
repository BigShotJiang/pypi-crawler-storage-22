# scibite_toolkit/__version__.py

# Package metadata
__version__ = '1.2.0'
__author__ = 'SciBite'
__email__ = 'help@scibite.com'
__copyright__ = '(c) 2025, SciBite Ltd'
__license__ = 'Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License'