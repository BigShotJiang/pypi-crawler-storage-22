class OntologyAlreadyExistsError(Exception):
    """Raised when the ontology already exists and is loaded."""
    pass

class OntologyNotFoundError(Exception):
    """Raised when the ontology does not exist or cannot be found."""
    pass
