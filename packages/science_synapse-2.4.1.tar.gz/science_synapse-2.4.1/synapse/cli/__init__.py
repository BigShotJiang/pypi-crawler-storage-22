from synapse.cli.__main__ import main
