from synapse.api.channel_pb2 import Channel

__all__ = ["Channel"]
