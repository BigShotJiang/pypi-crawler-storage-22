# taken from https://github.com/mmatl/urdfpy/blob/master/urdfpy/urdf.py
#        and https://github.com/mmatl/urdfpy/blob/master/urdfpy/utils.py

import contextlib
import copy
from logging import getLogger
import os
import pickle
import sys

from skrobot.data import get_cache_dir
from skrobot.utils.checksum import checksum_md5


try:
    # for python3
    from urllib.parse import urlparse
except ImportError:
    # for python2
    from urlparse import urlparse

from lxml import etree as ET
import networkx as nx
import numpy as np
import PIL.Image
import six

from skrobot._lazy_imports import _lazy_trimesh
from skrobot.coordinates import normalize_vector
from skrobot.coordinates import rpy_matrix
from skrobot.coordinates.math import matrix2ypr
from skrobot.pycompat import lru_cache


try:
    import rospkg
except ImportError:
    rospkg = None


mesh_filenames_cache = {}
logger = getLogger(__name__)
_CONFIGURABLE_VALUES = {"mesh_simplify_factor": np.inf,
                        'no_mesh_load_mode': False,
                        'export_mesh_format': None,
                        'collision_mesh_format': None,
                        'decimation_area_ratio_threshold': None,
                        'simplify_vertex_clustering_voxel_size': None,
                        'target_triangles': None,
                        'enable_mesh_cache': False,
                        'force_visual_mesh_origin_to_zero': False,
                        'overwrite_mesh': False,
                        'scale_factor': 1.0,
                        'blender_remesh': False,
                        'blender_voxel_size': 0.002,
                        'blender_executable': None,
                        '_current_geometry_context': None,  # 'collision' or 'visual'
                        '_source_urdf_path': None,  # Original URDF file path for mesh resolution
                        }
_MESH_CACHE = {}
_REMESHED_FILES_CACHE = {}  # Cache to track which files have been remeshed


@contextlib.contextmanager
def mesh_simplify_factor(factor):
    _CONFIGURABLE_VALUES["mesh_simplify_factor"] = factor
    yield
    _CONFIGURABLE_VALUES["mesh_simplify_factor"] = np.inf


@contextlib.contextmanager
def no_mesh_load_mode():
    _CONFIGURABLE_VALUES["no_mesh_load_mode"] = True
    yield
    _CONFIGURABLE_VALUES["no_mesh_load_mode"] = False


@contextlib.contextmanager
def export_mesh_format(
        mesh_format,
        decimation_area_ratio_threshold=None,
        simplify_vertex_clustering_voxel_size=None,
        target_triangles=None,
        overwrite_mesh=False,
        collision_mesh_format=None,
        blender_remesh=False,
        blender_voxel_size=0.002,
        blender_executable=None,
        remeshed_suffix='_remeshed'):
    global _REMESHED_FILES_CACHE
    _CONFIGURABLE_VALUES["export_mesh_format"] = mesh_format
    _CONFIGURABLE_VALUES["collision_mesh_format"] = collision_mesh_format
    _CONFIGURABLE_VALUES["decimation_area_ratio_threshold"] = \
        decimation_area_ratio_threshold
    _CONFIGURABLE_VALUES["simplify_vertex_clustering_voxel_size"] = \
        simplify_vertex_clustering_voxel_size
    _CONFIGURABLE_VALUES["target_triangles"] = target_triangles
    _CONFIGURABLE_VALUES["overwrite_mesh"] = overwrite_mesh
    _CONFIGURABLE_VALUES["blender_remesh"] = blender_remesh
    _CONFIGURABLE_VALUES["blender_voxel_size"] = blender_voxel_size
    _CONFIGURABLE_VALUES["blender_executable"] = blender_executable
    _CONFIGURABLE_VALUES["remeshed_suffix"] = remeshed_suffix
    # Clear the remeshed files cache at the start of each export
    _REMESHED_FILES_CACHE.clear()
    yield
    _CONFIGURABLE_VALUES["export_mesh_format"] = None
    _CONFIGURABLE_VALUES["collision_mesh_format"] = None
    _CONFIGURABLE_VALUES["decimation_area_ratio_threshold"] = None
    _CONFIGURABLE_VALUES["simplify_vertex_clustering_voxel_size"] = None
    _CONFIGURABLE_VALUES["target_triangles"] = None
    _CONFIGURABLE_VALUES["overwrite_mesh"] = False
    _CONFIGURABLE_VALUES["blender_remesh"] = False
    _CONFIGURABLE_VALUES["blender_voxel_size"] = 0.002
    _CONFIGURABLE_VALUES["blender_executable"] = None
    _CONFIGURABLE_VALUES["remeshed_suffix"] = '_remeshed'
    # Clear cache after export is complete
    _REMESHED_FILES_CACHE.clear()


@contextlib.contextmanager
def enable_mesh_cache():
    _CONFIGURABLE_VALUES['enable_mesh_cache'] = True
    yield
    _CONFIGURABLE_VALUES['enable_mesh_cache'] = False


@contextlib.contextmanager
def force_visual_mesh_origin_to_zero():
    _CONFIGURABLE_VALUES['force_visual_mesh_origin_to_zero'] = True
    yield
    _CONFIGURABLE_VALUES['force_visual_mesh_origin_to_zero'] = False


@contextlib.contextmanager
def apply_scale(scale_factor):
    _CONFIGURABLE_VALUES['scale_factor'] = scale_factor
    yield
    _CONFIGURABLE_VALUES['scale_factor'] = 1.0


def get_transparency(mesh):
    if hasattr(mesh, 'visual') and hasattr(mesh.visual, 'material'):
        material = mesh.visual.material
        if hasattr(material, 'main_color'):
            return material.main_color[3]


def parse_origin(node):
    """Find the ``origin`` subelement of an XML node and convert it

    Find the ``origin`` subelement of an XML node and convert it into a 4x4
    homogenous transformation matrix.

    Parameters
    ----------
    node : :class`lxml.etree.Element`
        An XML node which (optionally) has a child node with the ``origin``
        tag.

    Returns
    -------
    matrix : (4,4) float
        The 4x4 homogneous transform matrix that corresponds to this node's
        ``origin`` child. Defaults to the identity matrix if no ``origin``
        child was found.
    """
    matrix = np.eye(4)
    origin_node = node.find('origin')
    if origin_node is not None:
        if 'xyz' in origin_node.attrib:
            matrix[:3, 3] = np.fromstring(origin_node.attrib['xyz'], sep=' ')
        if 'rpy' in origin_node.attrib:
            rpy = np.fromstring(origin_node.attrib['rpy'], sep=' ')
            roll, pitch, yaw = rpy
            matrix[:3, :3] = rpy_matrix(yaw, pitch, roll)
    return matrix


def unparse_origin(matrix):
    """Turn a 4x4 homogenous matrix into an ``origin`` XML node.

    Parameters
    ----------
    matrix : (4,4) float
        The 4x4 homogneous transform matrix to convert into an ``origin``
        XML node.

    Returns
    -------
    node : :class`lxml.etree.Element`
        An XML node whose tag is ``origin``. The node has two attributes:

        - ``xyz`` - A string with three space-delimited floats representing
          the translation of the origin.
        - ``rpy`` - A string with three space-delimited floats representing
          the rotation of the origin.
    """
    node = ET.Element('origin')
    node.attrib['xyz'] = '{} {} {}'.format(*matrix[:3, 3])
    yaw, pitch, roll = matrix2ypr(matrix[:3, :3])
    node.attrib['rpy'] = '{} {} {}'.format(roll, pitch, yaw)
    return node


@lru_cache(maxsize=None)
def get_path_with_cache(ros_package):
    ros_version = os.environ.get('ROS_VERSION', '1')

    if ros_version == '2':
        try:
            from ament_index_python.packages import get_package_share_directory
            return get_package_share_directory(ros_package)
        except ImportError:
            logger.warning("ament_index_python not available, falling back to rospkg")
        except Exception as e:
            logger.warning("Failed to find ROS2 package %s: %s", ros_package, e)

    # ROS1 or fallback: Use rospkg
    rospack = rospkg.RosPack()
    return rospack.get_path(ros_package)


def search_up(start_dir, relative_path):
    current_dir = start_dir
    while True:
        candidate = os.path.join(current_dir, relative_path)
        if os.path.exists(candidate):
            return candidate
        parent = os.path.dirname(current_dir)
        if parent == current_dir:
            return None
        current_dir = parent


def resolve_filepath(base_path, file_path):
    parsed_url = urlparse(file_path)
    base_path = os.path.abspath(base_path)

    if rospkg and parsed_url.scheme == 'package':
        try:
            ros_package = parsed_url.netloc
            package_path = get_path_with_cache(ros_package)
            pkg_relative_path = parsed_url.path.lstrip("/")
            resolved_filepath = os.path.join(package_path, pkg_relative_path)
            if os.path.exists(resolved_filepath):
                return resolved_filepath
        except rospkg.common.ResourceNotFound:
            pass

    rel_paths = [
        os.path.join(parsed_url.netloc, parsed_url.path.lstrip('/')),
        parsed_url.path.lstrip('/')
    ]
    for rel in rel_paths:
        found_path = search_up(base_path, rel)
        if found_path:
            return found_path
    return None


def get_filename(base_path, file_path, makedirs=False):
    """Formats a file path correctly for URDF loading.

    Parameters
    ----------
    base_path : str
        The base path to the URDF's folder.
    file_path : str
        The path to the file.
    makedirs : bool, optional
        If ``True``, the directories leading to the file will be created
        if needed.

    Returns
    -------
    resolved : str
        The resolved filepath -- just the normal ``file_path`` if it was an
        absolute path, otherwise that path joined to ``base_path``.
    """
    resolved_file_path = resolve_filepath(base_path, file_path)
    if resolved_file_path is None:
        logger.error('could not find %s', file_path)
        return None
    if not os.path.isabs(resolved_file_path):
        resolved_file_path = os.path.join(base_path, resolved_file_path)
    if makedirs:
        d, _ = os.path.split(resolved_file_path)
        if not os.path.exists(d):
            os.makedirs(d)
    return resolved_file_path


def resolve_simplified_mesh_path(filename, simplify_factor):
    hash_value = checksum_md5(filename)
    cache_base_path = os.path.join(get_cache_dir(), "simplified_mesh")

    if not os.path.exists(cache_base_path):
        os.makedirs(cache_base_path)

    rounded_simplify_factor = round(simplify_factor, 3)
    cache_path = os.path.join(cache_base_path, "{}-{}.pkl".format(
        hash_value, rounded_simplify_factor))
    return cache_path


def load_meshes(filename):
    enable_mesh_cache = _CONFIGURABLE_VALUES['enable_mesh_cache']
    if enable_mesh_cache:
        if filename in _MESH_CACHE:
            return _MESH_CACHE[filename]
    use_simplified_meshs = _CONFIGURABLE_VALUES["mesh_simplify_factor"] < 1.0

    if use_simplified_meshs:
        cache_path = resolve_simplified_mesh_path(
            filename, _CONFIGURABLE_VALUES["mesh_simplify_factor"])

        if os.path.exists(cache_path):
            with open(cache_path, mode="rb") as f:
                return pickle.load(f)
        else:
            meshes = _load_meshes(filename)

            assert sys.version_info.major > 2, "supported only for python3.x"
            try:
                import open3d  # noqa
            except ImportError:
                message = "to simplify mesh, you need to install open3d\n"
                message += "run 'pip install open3d'"
                raise ImportError(message)

            mesh_simplified_list = []
            for mesh in meshes:
                n_face = len(mesh.faces)
                n_face_reduced = int(
                    n_face * _CONFIGURABLE_VALUES["mesh_simplify_factor"])
                mesh_simplified = mesh.simplify_quadratic_decimation(
                    n_face_reduced)
                mesh_simplified_list.append(mesh_simplified)

            with open(cache_path, mode="wb") as f:
                pickle.dump(mesh_simplified_list, f)
            return mesh_simplified_list
    else:
        meshes = _load_meshes(filename)
        if enable_mesh_cache:
            _MESH_CACHE[filename] = meshes
        return meshes


def _load_meshes(filename):
    """Loads triangular meshes from a file.

    Parameters
    ----------
    filename : str
        Path to the mesh file.

    Returns
    -------
    meshes : list of :class:`~trimesh.base.Trimesh`
        The meshes loaded from the file.
    """
    trimesh = _lazy_trimesh()
    try:
        _, ext = os.path.splitext(filename)
        # It seems that .3DXML files assume [mm] unit.
        # Convert the mesh unit from [mm] to [m].
        # To convert the mesh unit from millimeters to meters,
        # use the function meshes.convert_units('meter').
        meshes = trimesh.load(filename)
        if meshes.units is not None and meshes.units != 'meter':
            meshes = meshes.convert_units('meter')
    except Exception as e:
        logger.error("Failed to load meshes from %s. Error: %s", filename, e)
        meshes = []

    # If we got a scene, dump the meshes
    if isinstance(meshes, trimesh.Scene):
        meshes = list(meshes.dump())
        meshes = [g for g in meshes if isinstance(g, trimesh.Trimesh)]

    if isinstance(meshes, (list, tuple, set)):
        meshes = list(meshes)
        if len(meshes) == 0:
            logger.error('At least one mesh must be present in file.'
                         ' Please check %s file', filename)
            meshes = []
        for r in meshes:
            if not isinstance(r, trimesh.Trimesh):
                raise TypeError('Could not load meshes from file {}'.
                                format(filename))
    elif isinstance(meshes, trimesh.Trimesh):
        meshes = [meshes]
    else:
        logger.error('Unable to load mesh from file %s', filename)
        meshes = []

    for mesh in meshes:
        transparency = get_transparency(mesh)
        if transparency is not None and transparency == 0.0:
            if isinstance(mesh.visual.material,
                          trimesh.visual.material.PBRMaterial):
                mesh.visual.material.baseColorFactor[3] = 255
    return meshes


def configure_origin(value):
    """Convert a value into a 4x4 transform matrix.

    Parameters
    ----------
    value : None, (6,) float, or (4,4) float
        The value to turn into the matrix.
        If (6,), interpreted as xyzrpy coordinates.

    Returns
    -------
    matrix : (4,4) float or None
        The created matrix.
    """
    if value is None:
        value = np.eye(4)
    elif isinstance(value, (list, tuple, np.ndarray)):
        value = np.asanyarray(value).astype(np.float64)
        if value.shape == (6,):
            value = np.eye(4).astype(np.float64)
            value[:3, 3] = value[:3]
            roll, pitch, yaw = value[3:]
            value[:3, :3] = rpy_matrix(yaw, pitch, roll)
        elif value.shape != (4, 4):
            raise ValueError('Origin must be specified as a 4x4 '
                             'homogenous transformation matrix')
    else:
        raise TypeError('Invalid type for origin, expect 4x4 matrix')
    return value


class URDFType(object):
    """Abstract base class for all URDF types.

    This has useful class methods for automatic parsing/unparsing
    of XML trees.

    There are three overridable class variables:

    - ``_ATTRIBS`` - This is a dictionary mapping attribute names to a tuple,
      ``(type, required)`` where ``type`` is the Python type for the
      attribute and ``required`` is a boolean stating whether the attribute
      is required to be present.
    - ``_ELEMENTS`` - This is a dictionary mapping element names to a tuple,
      ``(type, required, multiple)`` where ``type`` is the Python type for the
      element, ``required`` is a boolean stating whether the element
      is required to be present, and ``multiple`` is a boolean indicating
      whether multiple elements of this type could be present.
      Elements are child nodes in the XML tree, and their type must be a
      subclass of :class:`.URDFType`.
    - ``_TAG`` - This is a string that represents the XML tag for the node
      containing this type of object.
    """
    _ATTRIBS = {}   # Map from attrib name to (type, required)
    _ELEMENTS = {}  # Map from element name to (type, required, multiple)
    _TAG = ''       # XML tag for this element

    def __init__(self):
        pass

    @classmethod
    def _parse_attrib(cls, val_type, val):
        """Parse an XML attribute into a python value.

        Parameters
        ----------
        val_type : :class:`type`
            The type of value to create.
        val : :class:`object`
            The value to parse.

        Returns
        -------
        val : :class:`object`
            The parsed attribute.
        """
        if val_type == np.ndarray:
            val = np.fromstring(val, sep=' ')
        else:
            val = val_type(val)
        return val

    @classmethod
    def _parse_simple_attribs(cls, node):
        """Parse all attributes in the _ATTRIBS array for this class.

        Parameters
        ----------
        node : :class:`lxml.etree.Element`
            The node to parse attributes for.

        Returns
        -------
        kwargs : dict
            Map from attribute name to value. If the attribute is not
            required and is not present, that attribute's name will map to
            ``None``.
        """
        kwargs = {}
        for a in cls._ATTRIBS:
            t, r = cls._ATTRIBS[a]  # t = type, r = required (bool)
            if r:
                try:
                    v = cls._parse_attrib(t, node.attrib[a])
                except Exception:
                    logger.error(
                        'Missing required attribute %s when parsing an object '
                        'of type %s', a, cls.__name__
                    )
                    continue
            else:
                v = None
                if a in node.attrib:
                    v = cls._parse_attrib(t, node.attrib[a])
            kwargs[a] = v
        return kwargs

    @classmethod
    def _parse_simple_elements(cls, node, path):
        """Parse all elements in the _ELEMENTS array

        Parse all elements in the _ELEMENTS array from the children of
        this node.

        Parameters
        ----------
        node : :class:`lxml.etree.Element`
            The node to parse children for.
        path : str
            The string path where the XML file is located (used for resolving
            the location of mesh or image files).

        Returns
        -------
        kwargs : dict
            Map from element names to the :class:`URDFType` subclass (or list,
            if ``multiple`` was set) created for that element.
        """
        kwargs = {}
        for a in cls._ELEMENTS:
            t, r, m = cls._ELEMENTS[a]
            if not m:
                v = node.find(t._TAG)
                if r or v is not None:
                    v = t._from_xml(v, path)
            else:
                vs = node.findall(t._TAG)
                if len(vs) == 0 and r:
                    logger.error(
                        'Missing required %s tag for '
                        '<%s name="%s"> in %s.',
                        t._TAG, node.tag, node.attrib['name'], cls.__name__)
                v = [t._from_xml(n, path) for n in vs]
            kwargs[a] = v
        return kwargs

    @classmethod
    def _parse(cls, node, path):
        """Parse all elements and attributes in the _ELEMENTS and _ATTRIBS

        Parse all elements and attributes in the _ELEMENTS and _ATTRIBS
        arrays for a node.

        Parameters
        ----------
        node : :class:`lxml.etree.Element`
            The node to parse.
        path : str
            The string path where the XML file is located (used for resolving
            the location of mesh or image files).

        Returns
        -------
        kwargs : dict
            Map from names to Python classes created from the attributes
            and elements in the class arrays.
        """
        kwargs = cls._parse_simple_attribs(node)
        if node is not None:
            kwargs.update(cls._parse_simple_elements(node, path))
        return kwargs

    @classmethod
    def _from_xml(cls, node, path):
        """Create an instance of this class from an XML node.

        Parameters
        ----------
        node : :class:`lxml.etree.Element`
            The node to parse.
        path : str
            The string path where the XML file is located (used for resolving
            the location of mesh or image files).

        Returns
        -------
        obj : :class:`URDFType`
            An instance of this class parsed from the node.
        """
        return cls(**cls._parse(node, path))

    def _unparse_attrib(self, val_type, val):
        """Convert a value into a string for storage in an XML attribute.

        Parameters
        ----------
        val_type : :class:`type`
            The type of the Python object.
        val : :class:`object`
            The actual value.

        Returns
        -------
        s : str
            The attribute string.
        """
        if val_type == np.ndarray:
            val = np.array2string(val)[1:-1]
        else:
            val = str(val)
        return val

    def _unparse_simple_attribs(self, node):
        """Convert all Python types from the _ATTRIBS array

        Convert all Python types from the _ATTRIBS array
        back into attributes for an XML node.

        Parameters
        ----------
        node : :class:`object`
            The XML node to add the attributes to.
        """
        for a in self._ATTRIBS:
            t, r = self._ATTRIBS[a]
            v = getattr(self, a, None)
            if r or v is not None:
                node.attrib[a] = self._unparse_attrib(t, v)

    def _unparse_simple_elements(self, node, path):
        """Unparse all Python types from the _ELEMENTS array

        Unparse all Python types from the _ELEMENTS array
        back into child nodes of an XML node.

        Parameters
        ----------
        node : :class:`object`
            The XML node for this object. Elements will be added as children
            of this node.
        path : str
            The string path where the XML file is being written to (used for
            writing out meshes and image files).
        """
        for a in self._ELEMENTS:
            t, r, m = self._ELEMENTS[a]
            v = getattr(self, a, None)
            if not m:
                if r or v is not None:
                    node.append(v._to_xml(node, path))
            else:
                vs = v
                for v in vs:
                    node.append(v._to_xml(node, path))

    def _unparse(self, path):
        """Create a node

        Create a node for this object and unparse all elements and
        attributes in the class arrays.

        Parameters
        ----------
        path : str
            The string path where the XML file is being written to (used for
            writing out meshes and image files).

        Returns
        -------
        node : :class:`lxml.etree.Element`
            The newly-created node.
        """
        node = ET.Element(self._TAG)
        self._unparse_simple_attribs(node)
        self._unparse_simple_elements(node, path)
        return node

    def _to_xml(self, parent, path):
        """Create and return an XML node for this object.

        Parameters
        ----------
        parent : :class:`lxml.etree.Element`
            The parent node that this element will eventually be added to.
            This base implementation doesn't use this information, but
            classes that override this function may use it.
        path : str
            The string path where the XML file is being written to (used for
            writing out meshes and image files).

        Returns
        -------
        node : :class:`lxml.etree.Element`
            The newly-created node.
        """
        return self._unparse(path)

###############################################################################
# Link types
###############################################################################


class Box(URDFType):
    """A rectangular prism whose center is at the local origin.

    Parameters
    ----------
    size : (3,) float
        The length, width, and height of the box in meters.
    """

    _ATTRIBS = {
        'size': (np.ndarray, True)
    }
    _TAG = 'box'

    def __init__(self, size):
        self.size = size
        self._meshes = []

    @property
    def size(self):
        """(3,) float : The length, width, and height of the box in meters.

        """
        return self._size

    @size.setter
    def size(self, value):
        self._size = np.asanyarray(value).astype(np.float64)
        self._meshes = []

    @property
    def meshes(self):
        """Return list of Trimesh.

        list of :class:`~trimesh.base.Trimesh` : The triangular meshes
        that represent this object.
        """
        if len(self._meshes) == 0:
            if _CONFIGURABLE_VALUES['no_mesh_load_mode'] is False:
                trimesh = _lazy_trimesh()
                self._meshes = [trimesh.creation.box(extents=self.size)]
        return self._meshes

    def _to_xml(self, parent, path):
        # Apply scale factor to box size
        scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
        original_size = self.size.copy()
        if scale_factor != 1.0:
            self.size = original_size * scale_factor

        node = self._unparse(path)

        # Restore original size
        self.size = original_size
        return node


class Cylinder(URDFType):
    """A cylinder whose center is at the local origin.

    Parameters
    ----------
    radius : float
        The radius of the cylinder in meters.
    length : float
        The length of the cylinder in meters.
    """

    _ATTRIBS = {
        'radius': (float, True),
        'length': (float, True),
    }
    _TAG = 'cylinder'

    def __init__(self, radius, length):
        self.radius = radius
        self.length = length
        self._meshes = []

    @property
    def radius(self):
        """float : The radius of the cylinder in meters.

        """
        return self._radius

    @radius.setter
    def radius(self, value):
        self._radius = float(value)
        self._meshes = []

    @property
    def length(self):
        """float : The length of the cylinder in meters.

        """
        return self._length

    @length.setter
    def length(self, value):
        self._length = float(value)
        self._meshes = []

    @property
    def meshes(self):
        """Return list of Trimesh


        list of :class:`~trimesh.base.Trimesh` : The triangular meshes
        that represent this object.
        """
        if len(self._meshes) == 0:
            if _CONFIGURABLE_VALUES['no_mesh_load_mode'] is False:
                trimesh = _lazy_trimesh()
                self._meshes = [trimesh.creation.cylinder(
                    radius=self.radius, height=self.length
                )]
        return self._meshes

    def _to_xml(self, parent, path):
        # Apply scale factor to cylinder dimensions
        scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
        original_radius = self.radius
        original_length = self.length
        if scale_factor != 1.0:
            self.radius = original_radius * scale_factor
            self.length = original_length * scale_factor

        node = self._unparse(path)

        # Restore original dimensions
        self.radius = original_radius
        self.length = original_length
        return node


class Sphere(URDFType):
    """A sphere whose center is at the local origin.

    Parameters
    ----------
    radius : float
        The radius of the sphere in meters.
    """
    _ATTRIBS = {
        'radius': (float, True),
    }
    _TAG = 'sphere'

    def __init__(self, radius):
        self.radius = radius
        self._meshes = []

    @property
    def radius(self):
        """float : The radius of the sphere in meters.

        """
        return self._radius

    @radius.setter
    def radius(self, value):
        self._radius = float(value)
        self._meshes = []

    @property
    def meshes(self):
        """Return list of Trimesh

        list of :class:`~trimesh.base.Trimesh` : The triangular meshes
        that represent this object.
        """
        if len(self._meshes) == 0:
            if _CONFIGURABLE_VALUES['no_mesh_load_mode'] is False:
                trimesh = _lazy_trimesh()
                self._meshes = [trimesh.creation.icosphere(radius=self.radius)]
        return self._meshes

    def _to_xml(self, parent, path):
        # Apply scale factor to sphere radius
        scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
        original_radius = self.radius
        if scale_factor != 1.0:
            self.radius = original_radius * scale_factor

        node = self._unparse(path)

        # Restore original radius
        self.radius = original_radius
        return node


class Mesh(URDFType):
    """A triangular mesh object.

    Parameters
    ----------
    filename : str
        The path to the mesh that contains this object. This can be
        relative to the top-level URDF or an absolute path.
    scale : (3,) float, optional
        The scaling value for the mesh along the XYZ axes.
        If ``None``, assumes no scale is applied.
    meshes : list of :class:`~trimesh.base.Trimesh`
        A list of meshes that compose this mesh.
        The list of meshes is useful for visual geometries that
        might be composed of separate trimesh objects.
        If not specified, the mesh is loaded from the file using trimesh.
    """
    _ATTRIBS = {
        'filename': (str, True),
        'scale': (np.ndarray, False)
    }
    _TAG = 'mesh'

    def __init__(self, filename, scale=None, meshes=None):
        if meshes is None:
            meshes = load_meshes(filename)
        self.filename = filename
        self.scale = scale
        self.meshes = meshes

    @property
    def filename(self):
        """str : The path to the mesh file for this object.

        """
        return self._filename

    @filename.setter
    def filename(self, value):
        self._filename = value

    @property
    def scale(self):
        """(3,) float : A scaling for the mesh along its local XYZ axes.

        """
        return self._scale

    @scale.setter
    def scale(self, value):
        if value is not None:
            value = np.asanyarray(value).astype(np.float64)
        self._scale = value

    @property
    def meshes(self):
        """Return list of Trimesh.

        list of :class:`~trimesh.base.Trimesh` : The triangular meshes
        that represent this object.
        """
        return self._meshes

    @meshes.setter
    def meshes(self, value):
        if isinstance(value, six.string_types):
            value = load_meshes(value)
            self._meshes = value
            return

        if isinstance(value, (list, tuple, set)):
            value = list(value)
            trimesh = None
            for i, m in enumerate(value):
                if not hasattr(m, '__module__') or m.__module__ != 'trimesh':
                    if trimesh is None:
                        trimesh = _lazy_trimesh()
                    if not isinstance(m, trimesh.Trimesh):
                        raise TypeError('Mesh requires a trimesh.Trimesh or a '
                                        'list of them')
            self._meshes = value
            return

        trimesh = _lazy_trimesh()
        if isinstance(value, trimesh.Trimesh):
            self._meshes = [value]
            return
        raise TypeError('Mesh requires a trimesh.Trimesh')

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)

        # Load the mesh, combining collision geometry meshes but keeping
        # visual ones separate to preserve colors and textures
        if _CONFIGURABLE_VALUES['no_mesh_load_mode'] is False:
            fn = get_filename(path, kwargs['filename'])
            meshes = load_meshes(fn)
        else:
            meshes = []
        kwargs['meshes'] = meshes

        return Mesh(**kwargs)

    def _to_xml(self, parent, path):
        # Get the filename
        # Store original filename for remesh processing
        original_urdf_filename = self.filename

        # Use source URDF path for mesh resolution if available
        source_path = _CONFIGURABLE_VALUES.get('_source_urdf_path')
        if source_path is not None:
            fn = get_filename(source_path, self.filename, makedirs=False)
        else:
            fn = get_filename(path, self.filename, makedirs=True)

        if fn is None:
            # File not found, skip mesh processing and just apply scaling
            scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
            original_scale = None
            if scale_factor != 1.0:
                original_scale = self.scale.copy() if self.scale is not None else None
                if self.scale is None:
                    self.scale = np.array([scale_factor, scale_factor, scale_factor])
                else:
                    self.scale = self.scale * scale_factor

            node = self._unparse(path)

            # Restore original scale
            if original_scale is not None:
                self.scale = original_scale
            elif scale_factor != 1.0:
                self.scale = None

            return node

        # Determine which format to use based on context
        is_collision = (_CONFIGURABLE_VALUES.get('_current_geometry_context')
                        == 'collision')
        ext = (_CONFIGURABLE_VALUES['collision_mesh_format'] if is_collision
               else _CONFIGURABLE_VALUES['export_mesh_format'])

        if ext is not None:
            if not fn.endswith(ext):
                name, _ = os.path.splitext(fn)
                fn = name + ext
                self.filename = os.path.splitext(self.filename)[0] + ext
                if os.path.exists(fn):
                    # skip mesh save process but still apply scaling
                    scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
                    original_scale = None
                    if scale_factor != 1.0:
                        original_scale = self.scale.copy() if self.scale is not None else None
                        if self.scale is None:
                            self.scale = np.array([scale_factor, scale_factor, scale_factor])
                        else:
                            self.scale = self.scale * scale_factor

                    node = self._unparse(path)

                    # Restore original scale
                    if original_scale is not None:
                        self.scale = original_scale
                    elif scale_factor != 1.0:
                        self.scale = None

                    return node

        # Export the meshes as a single file
        meshes = self.meshes

        # Apply Blender remeshing if requested (before other simplifications)
        blender_remesh_applied = False
        if _CONFIGURABLE_VALUES['blender_remesh']:
            from pathlib import Path
            global _REMESHED_FILES_CACHE

            # Check if we already processed this file
            # Use source path to find the actual existing mesh file
            actual_source_file = get_filename(source_path if source_path is not None else path,
                                              original_urdf_filename, makedirs=False)
            if actual_source_file is None:
                # Mesh file not found, skip remeshing
                logger.warning("Source mesh file not found for remeshing: %s", original_urdf_filename)
                blender_remesh_applied = False
            else:
                original_mesh_path = Path(actual_source_file)
                remeshed_suffix = _CONFIGURABLE_VALUES.get('remeshed_suffix', '_remeshed')

                # Determine output filename based on remeshed_suffix
                # Blender always outputs DAE format, so use .dae for remeshed file
                remeshed_ext = '.dae'  # Blender remesh always creates DAE
                if remeshed_suffix == '':
                    # Empty suffix means overwrite original file
                    remeshed_path = original_mesh_path
                    remeshed_filename = original_mesh_path.name
                else:
                    # Create new file with specified suffix
                    remeshed_filename = original_mesh_path.stem + remeshed_suffix + remeshed_ext
                    remeshed_path = original_mesh_path.parent / remeshed_filename

                # Check if this file has already been remeshed in this export session
                cache_key = str(original_mesh_path.resolve())
                if cache_key in _REMESHED_FILES_CACHE:
                    # Already processed, just update the filename reference
                    logger.info("Reusing already remeshed file: %s", remeshed_path)
                    fn = str(remeshed_path)
                    # Load the remeshed mesh
                    meshes = _load_meshes(fn)
                    blender_remesh_applied = True
                # If remeshed file already exists and is newer than original, use it
                elif remeshed_suffix != '' and \
                   remeshed_path.exists() and not _CONFIGURABLE_VALUES['overwrite_mesh']:
                    orig_mtime = original_mesh_path.stat().st_mtime
                    remesh_mtime = remeshed_path.stat().st_mtime
                    if remesh_mtime > orig_mtime:
                        logger.info("Using existing remeshed file: %s", remeshed_path)
                        # Update fn to point to remeshed file
                        fn = str(remeshed_path)
                        # Load remeshed meshes
                        meshes = _load_meshes(fn)
                        blender_remesh_applied = True
                        # Mark as processed
                        _REMESHED_FILES_CACHE[cache_key] = str(remeshed_path)
                    else:
                        # Original is newer, need to remesh
                        logger.info("Original mesh is newer, remeshing: %s", original_mesh_path)
                        meshes = self._apply_blender_remesh(actual_source_file, ext, remeshed_path)
                        # Update fn to point to new remeshed file
                        fn = str(remeshed_path)
                        blender_remesh_applied = True
                        # Mark as processed
                        _REMESHED_FILES_CACHE[cache_key] = str(remeshed_path)
                else:
                    # No remeshed file exists, overwrite requested, or empty suffix
                    logger.info("Creating remeshed file: %s", remeshed_path)
                    meshes = self._apply_blender_remesh(actual_source_file, remeshed_ext, remeshed_path)
                    # Update fn to point to new remeshed file
                    fn = str(remeshed_path)
                    blender_remesh_applied = True
                    # Mark as processed
                    _REMESHED_FILES_CACHE[cache_key] = str(remeshed_path)

        if _CONFIGURABLE_VALUES["target_triangles"] is not None:
            from skrobot.utils.mesh import auto_simplify_quadric_decimation_with_texture_preservation
            meshes = auto_simplify_quadric_decimation_with_texture_preservation(
                meshes, target_number_of_triangles=_CONFIGURABLE_VALUES[
                    "target_triangles"], verbose=True)
        elif _CONFIGURABLE_VALUES[
                "decimation_area_ratio_threshold"] is not None:
            from skrobot.utils.mesh import auto_simplify_quadric_decimation
            meshes = auto_simplify_quadric_decimation(
                meshes, area_ratio_threshold=_CONFIGURABLE_VALUES[
                    "decimation_area_ratio_threshold"])
        if _CONFIGURABLE_VALUES['simplify_vertex_clustering_voxel_size']:
            from skrobot.utils.mesh import simplify_vertex_clustering
            meshes = simplify_vertex_clustering(
                meshes,
                _CONFIGURABLE_VALUES['simplify_vertex_clustering_voxel_size'],
            )

        # If collision mesh needs STL output, update fn to STL path
        if blender_remesh_applied and is_collision and ext == '.stl' and fn.endswith('.dae'):
            # fn currently points to remeshed DAE, but we need STL output for collision
            stl_path = fn.replace('.dae', '.stl')
            fn = stl_path

        trimesh = _lazy_trimesh()
        # Skip export if Blender remesh already saved the file, except for collision STL
        # Collision meshes need to be exported as STL even after Blender remesh (DAE->STL conversion)
        skip_export = blender_remesh_applied and not (is_collision and ext == '.stl' and fn.endswith('.stl'))

        if not skip_export:
            if fn.endswith('.dae'):
                from skrobot.utils.mesh import split_mesh_by_face_color
                export_meshes = []
                has_texture_visual = False
                for mesh in meshes:
                    has_texture_visual |= mesh.visual.kind == 'texture'
                    export_meshes.extend(split_mesh_by_face_color(mesh))
                meshes = export_meshes
                if _CONFIGURABLE_VALUES['overwrite_mesh'] is True \
                        or not (os.path.exists(fn) and has_texture_visual):
                    # don't overwrite textured mesh.
                    dae_data = trimesh.exchange.dae.export_collada(meshes)
                    with open(fn, 'wb') as f:
                        f.write(dae_data)
            elif fn.endswith('.stl'):
                if _CONFIGURABLE_VALUES['overwrite_mesh'] \
                        or not os.path.exists(fn):
                    meshes = trimesh.util.concatenate(meshes)
                    trimesh.exchange.export.export_mesh(meshes, fn)
            else:
                if _CONFIGURABLE_VALUES['overwrite_mesh'] \
                        or not os.path.exists(fn):
                    trimesh.exchange.export.export_mesh(meshes, fn)

        # Apply scale factor to the mesh if different from 1.0
        scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
        original_scale = None
        if scale_factor != 1.0:
            original_scale = self.scale.copy() if self.scale is not None else None
            if self.scale is None:
                self.scale = np.array([scale_factor, scale_factor, scale_factor])
            else:
                self.scale = self.scale * scale_factor

        # Update self.filename to point to remeshed file for URDF output
        if blender_remesh_applied:
            remeshed_suffix = _CONFIGURABLE_VALUES.get('remeshed_suffix', '_remeshed')
            if remeshed_suffix != '':
                # Determine the output file extension from fn (actual output file)
                # This handles cases where collision meshes are converted DAE->STL
                output_ext = os.path.splitext(fn)[1]

                # Extract just the filename part from the URDF path
                if original_urdf_filename.startswith('package://'):
                    # Handle ROS package:// URIs
                    from urllib.parse import urlparse
                    parsed = urlparse(original_urdf_filename)
                    pkg_path = parsed.netloc + parsed.path
                    base_name, _ = os.path.splitext(pkg_path)
                    self.filename = 'package://' + base_name + remeshed_suffix + output_ext
                else:
                    # Handle regular file paths
                    base_name, _ = os.path.splitext(original_urdf_filename)
                    self.filename = base_name + remeshed_suffix + output_ext

        # Unparse the node
        node = self._unparse(path)

        # Restore original scale (but NOT filename for remeshed meshes)
        # Only restore filename if remesh was not applied
        if not blender_remesh_applied:
            self.filename = original_urdf_filename
        if original_scale is not None:
            self.scale = original_scale
        elif scale_factor != 1.0:
            self.scale = None

        return node

    def _apply_blender_remesh(self, input_mesh_path, ext, output_path):
        """Apply Blender remeshing and save result.

        Parameters
        ----------
        input_mesh_path : str
            Path to input mesh file.
        ext : str
            File extension for output.
        output_path : pathlib.Path
            Path to save remeshed mesh.

        Returns
        -------
        list of trimesh.Trimesh
            Remeshed meshes.
        """
        import os

        from skrobot.utils.blender_mesh import remesh_with_blender

        # Apply Blender remeshing using the input file path directly
        # This preserves all color/material information from the original file
        trimesh = _lazy_trimesh()

        try:
            # remesh_with_blender will save directly to output_path
            os.makedirs(output_path.parent, exist_ok=True)
            remeshed = remesh_with_blender(
                input_mesh_path,
                voxel_size=_CONFIGURABLE_VALUES['blender_voxel_size'],
                output_format=ext.lstrip('.') if ext else 'dae',
                blender_executable=_CONFIGURABLE_VALUES['blender_executable'],
                verbose=True,
                output_file=output_path
            )

            # Extract meshes from Scene if needed
            if isinstance(remeshed, trimesh.Scene):
                geometries = list(remeshed.dump())
                remeshed_meshes = [g for g in geometries if isinstance(g, trimesh.Trimesh)]
                logger.info("Saved remeshed mesh to: %s", output_path)
                return remeshed_meshes if remeshed_meshes else [remeshed]
            else:
                logger.info("Saved remeshed mesh to: %s", output_path)
                return [remeshed]

        except Exception as e:
            logger.warning("Blender remeshing failed: %s", e)
            # Load original mesh as fallback
            return _load_meshes(input_mesh_path)


class Geometry(URDFType):
    """A wrapper for all geometry types.

    Only one of the following values can be set, all others should be set
    to ``None``.

    Parameters
    ----------
    box : :class:`.Box`, optional
        Box geometry.
    cylinder : :class:`.Cylinder`
        Cylindrical geometry.
    sphere : :class:`.Sphere`
        Spherical geometry.
    mesh : :class:`.Mesh`
        Mesh geometry.
    """

    _ELEMENTS = {
        'box': (Box, False, False),
        'cylinder': (Cylinder, False, False),
        'sphere': (Sphere, False, False),
        'mesh': (Mesh, False, False),
    }
    _TAG = 'geometry'

    def __init__(self, box=None, cylinder=None, sphere=None, mesh=None):
        # if (box is None and cylinder is None
        #         and sphere is None and mesh is None):
        #     raise ValueError('At least one geometry element must be set')
        self.box = box
        self.cylinder = cylinder
        self.sphere = sphere
        self.mesh = mesh

    @property
    def box(self):
        """:class:`.Box` : Box geometry.

        """
        return self._box

    @box.setter
    def box(self, value):
        if value is not None and not isinstance(value, Box):
            raise TypeError('Expected Box type')
        self._box = value

    @property
    def cylinder(self):
        """:class:`.Cylinder` : Cylinder geometry.

        """
        return self._cylinder

    @cylinder.setter
    def cylinder(self, value):
        if value is not None and not isinstance(value, Cylinder):
            raise TypeError('Expected Cylinder type')
        self._cylinder = value

    @property
    def sphere(self):
        """:class:`.Sphere` : Spherical geometry.

        """
        return self._sphere

    @sphere.setter
    def sphere(self, value):
        if value is not None and not isinstance(value, Sphere):
            raise TypeError('Expected Sphere type')
        self._sphere = value

    @property
    def mesh(self):
        """:class:`.Mesh` : Mesh geometry.

        """
        return self._mesh

    @mesh.setter
    def mesh(self, value):
        if value is not None and not isinstance(value, Mesh):
            raise TypeError('Expected Mesh type')
        self._mesh = value

    @property
    def geometry(self):
        """Return geometry shape

        :class:`.Box`, :class:`.Cylinder`, :class:`.Sphere`, or
        :class:`.Mesh` : The valid geometry element.
        """
        if self.box is not None:
            return self.box
        if self.cylinder is not None:
            return self.cylinder
        if self.sphere is not None:
            return self.sphere
        if self.mesh is not None:
            return self.mesh
        return None

    @property
    def meshes(self):
        """Return list of geometry mesh

        list of :class:`~trimesh.base.Trimesh` : The geometry's triangular
        mesh representation(s).
        """
        geo = self.geometry
        if geo is None:
            return []
        return geo.meshes


class Texture(URDFType):
    """An image-based texture.

    Parameters
    ----------
    filename : str
        The path to the image that contains this texture. This can be
        relative to the top-level URDF or an absolute path.
    image : :class:`PIL.Image.Image`, optional
        The image for the texture.
        If not specified, it is loaded automatically from the filename.
    """

    _ATTRIBS = {
        'filename': (str, True)
    }
    _TAG = 'texture'

    def __init__(self, filename, image=None):
        if image is None:
            if filename and os.path.exists(filename):
                image = PIL.image.open(filename)
            else:
                return
        self.filename = filename
        self.image = image

    @property
    def filename(self):
        """str : Path to the image for this texture.

        """
        return self._filename

    @filename.setter
    def filename(self, value):
        self._filename = str(value)

    @property
    def image(self):
        """:class:`PIL.Image.Image` : The image for this texture.

        """
        return self._image

    @image.setter
    def image(self, value):
        if isinstance(value, str):
            value = PIL.Image.open(value)
        if isinstance(value, np.ndarray):
            value = PIL.Image.fromarray(value)
        elif not isinstance(value, PIL.Image.Image):
            logger.error('Texture only supports numpy arrays '
                         'or PIL images')
        self._image = value

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)

        # Load image
        fn = get_filename(path, kwargs['filename'])
        if fn and os.path.exists(fn):
            kwargs['image'] = PIL.Image.open(fn)

        return Texture(**kwargs)

    def _to_xml(self, parent, path):
        # Save the image
        filepath = get_filename(path, self.filename, makedirs=True)
        try:
            self.image.save(filepath)
        except OSError as e:
            logger.error('Could not save texture image %s: %s', filepath, e)
        return self._unparse(path)


class Material(URDFType):
    """A material for some geometry.

    Parameters
    ----------
    name : str
        The name of the material.
    color : (4,) float, optional
        The RGBA color of the material in the range [0,1].
    texture : :class:`.Texture`, optional
        A texture for the material.
    """
    _ATTRIBS = {
        'name': (str, True)
    }
    _ELEMENTS = {
        'texture': (Texture, False, False),
    }
    _TAG = 'material'

    def __init__(self, name, color=None, texture=None):
        self.name = name
        self.color = color
        self.texture = texture

    @property
    def name(self):
        """str : The name of the material.

        """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def color(self):
        """(4,) float : The RGBA color of the material, in the range [0,1].

        """
        return self._color

    @color.setter
    def color(self, value):
        if value is not None:
            value = np.asanyarray(value).astype(np.float64)
            value = np.clip(value, 0.0, 1.0)
            if value.shape != (4,):
                raise ValueError('Color must be a (4,) float')
        self._color = value

    @property
    def texture(self):
        """:class:`.Texture` : The texture for the material.

        """
        return self._texture

    @texture.setter
    def texture(self, value):
        if value is not None:
            if isinstance(value, six.string_types):
                image = PIL.Image.open(value)
                value = Texture(filename=value, image=image)
            elif not isinstance(value, Texture):
                raise ValueError('Invalid type for texture -- expect path to '
                                 'image or Texture')
        self._texture = value

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)

        # Extract the color -- it's weirdly an attribute of a subelement
        color = node.find('color')
        if color is not None:
            color = np.fromstring(color.attrib['rgba'], sep=' ')
        kwargs['color'] = color

        return Material(**kwargs)

    def _to_xml(self, parent, path):
        # Simplify materials by collecting them at the top level.

        # For top-level elements, save the full material specification
        if parent.tag == 'robot':
            node = self._unparse(path)
            if self.color is not None:
                color = ET.Element('color')
                color.attrib['rgba'] = np.array2string(self.color)[1:-1]
                node.append(color)

        # For non-top-level elements just save the material with a name
        else:
            node = ET.Element('material')
            node.attrib['name'] = self.name
        return node


class Collision(URDFType):
    """Collision properties of a link.

    Parameters
    ----------
    geometry : :class:`.Geometry`
        The geometry of the element
    name : str, optional
        The name of the collision geometry.
    origin : (4,4) float, optional
        The pose of the collision element relative to the link frame.
        Defaults to identity.
    """

    _ATTRIBS = {
        'name': (str, False)
    }
    _ELEMENTS = {
        'geometry': (Geometry, True, False),
    }
    _TAG = 'collision'

    def __init__(self, name, origin, geometry):
        self.geometry = geometry
        self.name = name
        self.origin = origin
        if _CONFIGURABLE_VALUES['force_visual_mesh_origin_to_zero']:
            if self.geometry.mesh is not None and \
                self.geometry.mesh.filename not in mesh_filenames_cache:
                mesh_filenames_cache[self.geometry.mesh.filename] = True
                if self.geometry.mesh is not None:
                    new_mesh = []
                    for mesh in self.geometry.meshes:
                        mesh.apply_transform(self.origin)
                        new_mesh.append(mesh)
                    self.geometry.mesh.meshes = new_mesh
                    del new_mesh
            # force the origin to be zero
            self.origin = np.eye(4)

    @property
    def geometry(self):
        """:class:`.Geometry` : The geometry of this element.

        """
        return self._geometry

    @geometry.setter
    def geometry(self, value):
        if not isinstance(value, Geometry):
            raise TypeError('Must set geometry with Geometry object')
        self._geometry = value

    @property
    def name(self):
        """str : The name of this collision element.

        """
        return self._name

    @name.setter
    def name(self, value):
        if value is not None:
            value = str(value)
        self._name = value

    @property
    def origin(self):
        """(4,4) float : The pose of this element relative to the link frame.

        """
        return self._origin

    @origin.setter
    def origin(self, value):
        self._origin = configure_origin(value)

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)
        kwargs['origin'] = parse_origin(node)
        return Collision(**kwargs)

    def _to_xml(self, parent, path):
        # Set context for mesh conversion
        _CONFIGURABLE_VALUES['_current_geometry_context'] = 'collision'
        try:
            node = self._unparse(path)

            # Apply scale factor to collision origin
            scaled_origin = self.origin.copy()
            scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
            if scale_factor != 1.0:
                scaled_origin[:3, 3] *= scale_factor

            node.append(unparse_origin(scaled_origin))
            return node
        finally:
            _CONFIGURABLE_VALUES['_current_geometry_context'] = None


class Visual(URDFType):
    """Visual properties of a link.

    Parameters
    ----------
    geometry : :class:`.Geometry`
        The geometry of the element
    name : str, optional
        The name of the visual geometry.
    origin : (4,4) float, optional
        The pose of the visual element relative to the link frame.
        Defaults to identity.
    material : :class:`.Material`, optional
        The material of the element.
    """
    _ATTRIBS = {
        'name': (str, False)
    }
    _ELEMENTS = {
        'geometry': (Geometry, True, False),
        'material': (Material, False, False),
    }
    _TAG = 'visual'

    def __init__(self, geometry, name=None, origin=None, material=None):
        self.geometry = geometry
        self.name = name
        self.origin = origin
        self.material = material

        if _CONFIGURABLE_VALUES['force_visual_mesh_origin_to_zero']:
            if self.geometry.mesh is not None and \
                self.geometry.mesh.filename not in mesh_filenames_cache:
                mesh_filenames_cache[self.geometry.mesh.filename] = True
                if self.geometry.mesh is not None:
                    new_mesh = []
                    for mesh in self.geometry.meshes:
                        mesh.apply_transform(self.origin)
                        new_mesh.append(mesh)
                    self.geometry.mesh.meshes = new_mesh
                    del new_mesh
            # force the origin to be zero
            self.origin = np.eye(4)

    @property
    def geometry(self):
        """:class:`.Geometry` : The geometry of this element.

        """
        return self._geometry

    @geometry.setter
    def geometry(self, value):
        if not isinstance(value, Geometry):
            raise TypeError('Must set geometry with Geometry object')
        self._geometry = value

    @property
    def name(self):
        """str : The name of this visual element.

        """
        return self._name

    @name.setter
    def name(self, value):
        if value is not None:
            value = str(value)
        self._name = value

    @property
    def origin(self):
        """(4,4) float : The pose of this element relative to the link frame.

        """
        return self._origin

    @origin.setter
    def origin(self, value):
        self._origin = configure_origin(value)

    @property
    def material(self):
        """:class:`.Material` : The material for this element.

        """
        return self._material

    @material.setter
    def material(self, value):
        if value is not None:
            if not isinstance(value, Material):
                raise TypeError('Must set material with Material object')
        self._material = value

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)
        kwargs['origin'] = parse_origin(node)
        return Visual(**kwargs)

    def _to_xml(self, parent, path):
        # Set context for mesh conversion
        _CONFIGURABLE_VALUES['_current_geometry_context'] = 'visual'
        try:
            node = self._unparse(path)

            # Apply scale factor to visual origin
            scaled_origin = self.origin.copy()
            scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
            if scale_factor != 1.0:
                scaled_origin[:3, 3] *= scale_factor

            node.append(unparse_origin(scaled_origin))
            return node
        finally:
            _CONFIGURABLE_VALUES['_current_geometry_context'] = None


class Inertial(URDFType):
    """The inertial properties of a link.

    Parameters
    ----------
    mass : float
        The mass of the link in kilograms.
    inertia : (3,3) float
        The 3x3 symmetric rotational inertia matrix.
    origin : (4,4) float, optional
        The pose of the inertials relative to the link frame.
        Defaults to identity if not specified.
    """
    _TAG = 'inertial'

    def __init__(self, mass, inertia, origin=None):
        self.mass = mass
        self.inertia = inertia
        self.origin = origin

    @property
    def mass(self):
        """float : The mass of the link in kilograms.

        """
        return self._mass

    @mass.setter
    def mass(self, value):
        self._mass = float(value)

    @property
    def inertia(self):
        """(3,3) float : The 3x3 symmetric rotational inertia matrix.

        """
        return self._inertia

    @inertia.setter
    def inertia(self, value):
        value = np.asanyarray(value).astype(np.float64)
        if not np.allclose(value, value.T):
            raise ValueError('Inertia must be a symmetric matrix')
        self._inertia = value

    @property
    def origin(self):
        """(4,4) float : The pose of the inertials relative to the link frame.

        """
        return self._origin

    @origin.setter
    def origin(self, value):
        self._origin = configure_origin(value)

    @classmethod
    def _from_xml(cls, node, path):
        origin = parse_origin(node)
        mass = float(node.find('mass').attrib['value'])
        n = node.find('inertia')
        xx = float(n.attrib['ixx'])
        xy = float(n.attrib['ixy'])
        xz = float(n.attrib['ixz'])
        yy = float(n.attrib['iyy'])
        yz = float(n.attrib['iyz'])
        zz = float(n.attrib['izz'])
        inertia = np.array([
            [xx, xy, xz],
            [xy, yy, yz],
            [xz, yz, zz]
        ])
        return Inertial(mass=mass, inertia=inertia, origin=origin)

    def _to_xml(self, parent, path):
        node = ET.Element('inertial')

        # Apply scale factor to inertial origin
        scaled_origin = self.origin.copy()
        scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
        if scale_factor != 1.0:
            scaled_origin[:3, 3] *= scale_factor

        node.append(unparse_origin(scaled_origin))

        # Scale mass and inertia properties
        scaled_mass = self.mass
        scaled_inertia = self.inertia.copy()
        if scale_factor != 1.0:
            # Mass scales with volume (scale^3)
            scaled_mass = self.mass * (scale_factor ** 3)
            # Mass scales with volume (scale^3).
            # Reference: For a uniform scaling of a 3D object, the volume
            # (and thus mass, assuming constant density) scales with the cube of the linear scale factor.
            # See e.g. "Classical Mechanics" by J.R. Taylor, Section 4.4,
            # or https://en.wikipedia.org/wiki/Scaling_law#Dimensional_analysis
            scaled_mass = self.mass * (scale_factor ** 3)
            # Inertia scales with mass * length^2, so scale^5 total.
            # Reference: The moment of inertia for a rigid body is proportional
            # to mass times the square of the characteristic length. Under uniform scaling,
            # inertia scales as (scale^3) * (scale^2) = scale^5.
            # See e.g. "Classical Mechanics" by J.R. Taylor,
            # Section 10.2, or https://en.wikipedia.org/wiki/Moment_of_inertia#Scaling_of_moment_of_inertia
            scaled_inertia = self.inertia * (scale_factor ** 5)

        mass = ET.Element('mass')
        mass.attrib['value'] = str(scaled_mass)
        node.append(mass)
        inertia = ET.Element('inertia')
        inertia.attrib['ixx'] = str(scaled_inertia[0, 0])
        inertia.attrib['ixy'] = str(scaled_inertia[0, 1])
        inertia.attrib['ixz'] = str(scaled_inertia[0, 2])
        inertia.attrib['iyy'] = str(scaled_inertia[1, 1])
        inertia.attrib['iyz'] = str(scaled_inertia[1, 2])
        inertia.attrib['izz'] = str(scaled_inertia[2, 2])
        node.append(inertia)
        return node

###############################################################################
# Joint types
###############################################################################


class JointCalibration(URDFType):
    """The reference positions of the joint.

    Parameters
    ----------
    rising : float, optional
        When the joint moves in a positive direction, this position will
        trigger a rising edge.
    falling :
        When the joint moves in a positive direction, this position will
        trigger a falling edge.
    """
    _ATTRIBS = {
        'rising': (float, False),
        'falling': (float, False)
    }
    _TAG = 'calibration'

    def __init__(self, rising=None, falling=None):
        self.rising = rising
        self.falling = falling

    @property
    def rising(self):
        """float : description.

        """
        return self._rising

    @rising.setter
    def rising(self, value):
        if value is not None:
            value = float(value)
        self._rising = value

    @property
    def falling(self):
        """float : description.

        """
        return self._falling

    @falling.setter
    def falling(self, value):
        if value is not None:
            value = float(value)
        self._falling = value


class JointDynamics(URDFType):
    """The dynamic properties of the joint.

    Parameters
    ----------
    damping : float
        The damping value of the joint (Ns/m for prismatic joints,
        Nms/rad for revolute).
    friction : float
        The static friction value of the joint (N for prismatic joints,
        Nm for revolute).
    """
    _ATTRIBS = {
        'damping': (float, False),
        'friction': (float, False),
    }
    _TAG = 'dynamics'

    def __init__(self, damping, friction):
        self.damping = damping
        self.friction = friction

    @property
    def damping(self):
        """float : The damping value of the joint.

        """
        return self._damping

    @damping.setter
    def damping(self, value):
        if value is not None:
            value = float(value)
        self._damping = value

    @property
    def friction(self):
        """float : The static friction value of the joint.

        """
        return self._friction

    @friction.setter
    def friction(self, value):
        if value is not None:
            value = float(value)
        self._friction = value


class JointLimit(URDFType):
    """The limits of the joint.

    Parameters
    ----------
    effort : float
        The maximum joint effort (N for prismatic joints, Nm for revolute).
    velocity : float
        The maximum joint velocity (m/s for prismatic joints, rad/s for
        revolute).
    lower : float, optional
        The lower joint limit (m for prismatic joints, rad for revolute).
    upper : float, optional
        The upper joint limit (m for prismatic joints, rad for revolute).
    """

    _ATTRIBS = {
        'effort': (float, False),
        'velocity': (float, False),
        'lower': (float, False),
        'upper': (float, False),
    }
    _TAG = 'limit'

    def __init__(self, effort=None, velocity=None, lower=None, upper=None):
        if effort is None:
            logger.error('Joint effort is not set. Setting it to 0.0 by default.')
            effort = 0.0
        if velocity is None:
            logger.error('Joint velocity is not set. Setting it to 0.0 by default.')
            velocity = 0.0
        self.effort = effort
        self.velocity = velocity
        self.lower = lower
        self.upper = upper

    @property
    def effort(self):
        """float : The maximum joint effort.

        """
        return self._effort

    @effort.setter
    def effort(self, value):
        self._effort = float(value)

    @property
    def velocity(self):
        """float : The maximum joint velocity.

        """
        return self._velocity

    @velocity.setter
    def velocity(self, value):
        self._velocity = float(value)

    @property
    def lower(self):
        """float : The lower joint limit.

        """
        return self._lower

    @lower.setter
    def lower(self, value):
        if value is not None:
            value = float(value)
        self._lower = value

    @property
    def upper(self):
        """float : The upper joint limit.

        """
        return self._upper

    @upper.setter
    def upper(self, value):
        if value is not None:
            value = float(value)
        self._upper = value


class JointMimic(URDFType):
    """A mimicry tag for a joint.

    A mimicry tag for a joint, which forces its configuration to mimic
    another joint's.
    This joint's configuration value is set equal to
    ``multiplier * other_joint_cfg + offset``.

    Parameters
    ----------
    joint : str
        The name of the joint to mimic.
    multiplier : float
        The joint configuration multiplier. Defaults to 1.0.
    offset : float, optional
        The joint configuration offset. Defaults to 0.0.
    """
    _ATTRIBS = {
        'joint': (str, True),
        'multiplier': (float, False),
        'offset': (float, False),
    }
    _TAG = 'mimic'

    def __init__(self, joint, multiplier=None, offset=None):
        self.joint = joint
        self.multiplier = multiplier
        self.offset = offset

    @property
    def joint(self):
        """float : The name of the joint to mimic.

        """
        return self._joint

    @joint.setter
    def joint(self, value):
        self._joint = str(value)

    @property
    def multiplier(self):
        """float : The multiplier for the joint configuration.

        """
        return self._multiplier

    @multiplier.setter
    def multiplier(self, value):
        if value is not None:
            value = float(value)
        else:
            value = 1.0
        self._multiplier = value

    @property
    def offset(self):
        """float : The offset for the joint configuration

        """
        return self._offset

    @offset.setter
    def offset(self, value):
        if value is not None:
            value = float(value)
        else:
            value = 0.0
        self._offset = value


class SafetyController(URDFType):
    """A controller for joint movement safety.

    Parameters
    ----------
    k_velocity : float
        An attribute specifying the relation between the effort and velocity
        limits.
    k_position : float, optional
        An attribute specifying the relation between the position and velocity
        limits. Defaults to 0.0.
    soft_lower_limit : float, optional
        The lower joint boundary where the safety controller kicks in.
        Defaults to 0.0.
    soft_upper_limit : float, optional
        The upper joint boundary where the safety controller kicks in.
        Defaults to 0.0.
    """
    _ATTRIBS = {
        'k_velocity': (float, True),
        'k_position': (float, False),
        'soft_lower_limit': (float, False),
        'soft_upper_limit': (float, False),
    }
    _TAG = 'safety_controller'

    def __init__(self, k_velocity, k_position=None, soft_lower_limit=None,
                 soft_upper_limit=None):
        self.k_velocity = k_velocity
        self.k_position = k_position
        self.soft_lower_limit = soft_lower_limit
        self.soft_upper_limit = soft_upper_limit

    @property
    def soft_lower_limit(self):
        """float : The soft lower limit where the safety controller kicks in.

        """
        return self._soft_lower_limit

    @soft_lower_limit.setter
    def soft_lower_limit(self, value):
        if value is not None:
            value = float(value)
        else:
            value = 0.0
        self._soft_lower_limit = value

    @property
    def soft_upper_limit(self):
        """float : The soft upper limit where the safety controller kicks in.

        """
        return self._soft_upper_limit

    @soft_upper_limit.setter
    def soft_upper_limit(self, value):
        if value is not None:
            value = float(value)
        else:
            value = 0.0
        self._soft_upper_limit = value

    @property
    def k_position(self):
        """float : A relation between the position and velocity limits.

        """
        return self._k_position

    @k_position.setter
    def k_position(self, value):
        if value is not None:
            value = float(value)
        else:
            value = 0.0
        self._k_position = value

    @property
    def k_velocity(self):
        """float : A relation between the effort and velocity limits.

        """
        return self._k_velocity

    @k_velocity.setter
    def k_velocity(self, value):
        self._k_velocity = float(value)

###############################################################################
# Transmission types
###############################################################################


class Actuator(URDFType):
    """An actuator.

    Parameters
    ----------
    name : str
        The name of this actuator.
    mechanicalReduction : str, optional
        A specifier for the mechanical reduction at the joint/actuator
        transmission.
    hardwareInterfaces : list of str, optional
        The supported hardware interfaces to the actuator.
    """
    _ATTRIBS = {
        'name': (str, True),
    }
    _TAG = 'actuator'

    def __init__(self, name, mechanicalReduction=None,
                 hardwareInterfaces=None):
        self.name = name
        self.mechanicalReduction = mechanicalReduction
        self.hardwareInterfaces = hardwareInterfaces

    @property
    def name(self):
        """str : The name of this actuator.

        """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def mechanicalReduction(self):
        """str : A specifier for the type of mechanical reduction.

        """
        return self._mechanicalReduction

    @mechanicalReduction.setter
    def mechanicalReduction(self, value):
        if value is not None:
            value = str(value)
        self._mechanicalReduction = value

    @property
    def hardwareInterfaces(self):
        """list of str : The supported hardware interfaces.

        """
        return self._hardwareInterfaces

    @hardwareInterfaces.setter
    def hardwareInterfaces(self, value):
        if value is None:
            value = []
        else:
            value = list(value)
            for i, v in enumerate(value):
                value[i] = str(v)
        self._hardwareInterfaces = value

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)
        mr = node.find('mechanicalReduction')
        if mr is not None:
            mr = float(mr.text)
        kwargs['mechanicalReduction'] = mr
        hi = node.findall('hardwareInterface')
        if len(hi) > 0:
            hi = [h.text for h in hi]
        kwargs['hardwareInterfaces'] = hi
        return Actuator(**kwargs)

    def _to_xml(self, parent, path):
        node = self._unparse(path)
        if self.mechanicalReduction is not None:
            mr = ET.Element('mechanicalReduction')
            mr.text = str(self.mechanicalReduction)
            node.append(mr)
        if len(self.hardwareInterfaces) > 0:
            for hi in self.hardwareInterfaces:
                h = ET.Element('hardwareInterface')
                h.text = hi
                node.append(h)
        return node


class TransmissionJoint(URDFType):
    """A transmission joint specification.

    Parameters
    ----------
    name : str
        The name of this actuator.
    hardwareInterfaces : list of str, optional
        The supported hardware interfaces to the actuator.
    """
    _ATTRIBS = {
        'name': (str, True),
    }
    _TAG = 'joint'

    def __init__(self, name, hardwareInterfaces):
        self.name = name
        self.hardwareInterfaces = hardwareInterfaces

    @property
    def name(self):
        """str : The name of this transmission joint.

        """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def hardwareInterfaces(self):
        """list of str : The supported hardware interfaces.

        """
        return self._hardwareInterfaces

    @hardwareInterfaces.setter
    def hardwareInterfaces(self, value):
        if value is None:
            value = []
        else:
            value = list(value)
            for i, v in enumerate(value):
                value[i] = str(v)
        self._hardwareInterfaces = value

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)
        hi = node.findall('hardwareInterface')
        if len(hi) > 0:
            hi = [h.text for h in hi]
        kwargs['hardwareInterfaces'] = hi
        return TransmissionJoint(**kwargs)

    def _to_xml(self, parent, path):
        node = self._unparse(path)
        if len(self.hardwareInterfaces) > 0:
            for hi in self.hardwareInterfaces:
                h = ET.Element('hardwareInterface')
                h.text = hi
                node.append(h)
        return node

###############################################################################
# Top-level types
###############################################################################


class Transmission(URDFType):
    """Transmission class

    An element that describes the relationship between an actuator and a joint.

    Parameters
    ----------
    name : str
        The name of this transmission.
    trans_type : str
        The type of this transmission.
    joints : list of :class:`.TransmissionJoint`
        The joints connected to this transmission.
    actuators : list of :class:`.Actuator`
        The actuators connected to this transmission.
    """
    _ATTRIBS = {
        'name': (str, True),
    }
    _ELEMENTS = {
        'joints': (TransmissionJoint, True, True),
        'actuators': (Actuator, True, True),
    }
    _TAG = 'transmission'

    def __init__(self, name, trans_type, joints=None, actuators=None):
        self.name = name
        self.trans_type = trans_type
        self.joints = joints
        self.actuators = actuators

    @property
    def name(self):
        """str : The name of this transmission.

        """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def trans_type(self):
        """str : The type of this transmission.

        """
        return self._trans_type

    @trans_type.setter
    def trans_type(self, value):
        self._trans_type = str(value)

    @property
    def joints(self):
        """Return joint

        :class:`.TransmissionJoint` : The joints the transmission is
        connected to.

        """
        return self._joints

    @joints.setter
    def joints(self, value):
        if value is None:
            value = []
        else:
            value = list(value)
            for v in value:
                if not isinstance(v, TransmissionJoint):
                    raise TypeError(
                        'Joints expects a list of TransmissionJoint'
                    )
        self._joints = value

    @property
    def actuators(self):
        """:class:`.Actuator` : The actuators the transmission is connected to.

        """
        return self._actuators

    @actuators.setter
    def actuators(self, value):
        if value is None:
            value = []
        else:
            value = list(value)
            for v in value:
                if not isinstance(v, Actuator):
                    raise TypeError(
                        'Actuators expects a list of Actuator'
                    )
        self._actuators = value

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)
        if node.find('type') is not None:
            kwargs['trans_type'] = node.find('type').text
        else:
            kwargs['trans_type'] = 'transmission_interface/SimpleTransmission'
        return Transmission(**kwargs)

    def _to_xml(self, parent, path):
        node = self._unparse(path)
        ttype = ET.Element('type')
        ttype.text = self.trans_type
        node.append(ttype)
        return node


class Joint(URDFType):
    """A connection between two links.

    There are several types of joints, including:

    - ``fixed`` - a joint that cannot move.
    - ``prismatic`` - a joint that slides along the joint axis.
    - ``revolute`` - a hinge joint that rotates about the axis with a limited
      range of motion.
    - ``continuous`` - a hinge joint that rotates about the axis with an
      unlimited range of motion.
    - ``planar`` - a joint that moves in the plane orthogonal to the axis.
    - ``floating`` - a joint that can move in 6DoF.

    Parameters
    ----------
    name : str
        The name of this joint.
    parent : str
        The name of the parent link of this joint.
    child : str
        The name of the child link of this joint.
    joint_type : str
        The type of the joint. Must be one of :obj:`.Joint.TYPES`.
    axis : (3,) float, optional
        The axis of the joint specified in joint frame. Defaults to
        ``[1,0,0]``.
    origin : (4,4) float, optional
        The pose of the child link with respect to the parent link's frame.
        The joint frame is defined to be coincident with the child link's
        frame, so this is also the pose of the joint frame with respect to
        the parent link's frame.
    limit : :class:`.JointLimit`, optional
        Limit for the joint. Only required for revolute and prismatic
        joints.
    dynamics : :class:`.JointDynamics`, optional
        Dynamics for the joint.
    safety_controller : :class`.SafetyController`, optional
        The safety controller for this joint.
    calibration : :class:`.JointCalibration`, optional
        Calibration information for the joint.
    mimic : :class:`JointMimic`, optional
        Joint mimicry information.
    """
    TYPES = ['fixed', 'prismatic', 'revolute',
             'continuous', 'floating', 'planar']
    _ATTRIBS = {
        'name': (str, True),
    }
    _ELEMENTS = {
        'dynamics': (JointDynamics, False, False),
        'limit': (JointLimit, False, False),
        'mimic': (JointMimic, False, False),
        'safety_controller': (SafetyController, False, False),
        'calibration': (JointCalibration, False, False),
    }
    _TAG = 'joint'

    def __init__(self, name, joint_type, parent, child, axis=None, origin=None,
                 limit=None, dynamics=None, safety_controller=None,
                 calibration=None, mimic=None):
        self.name = name
        self.parent = parent
        self.child = child
        self.joint_type = joint_type
        self.axis = axis
        self.origin = origin
        self.limit = limit
        self.dynamics = dynamics
        self.safety_controller = safety_controller
        self.calibration = calibration
        self.mimic = mimic

    @property
    def name(self):
        """str : Name for this joint.

        """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def joint_type(self):
        """str : The type of this joint.

        """
        return self._joint_type

    @joint_type.setter
    def joint_type(self, value):
        value = str(value)
        if value not in Joint.TYPES:
            raise ValueError('Unsupported joint type {}'.format(value))
        self._joint_type = value

    @property
    def parent(self):
        """str : The name of the parent link.

        """
        return self._parent

    @parent.setter
    def parent(self, value):
        self._parent = str(value)

    @property
    def child(self):
        """str : The name of the child link.

        """
        return self._child

    @child.setter
    def child(self, value):
        self._child = str(value)

    @property
    def axis(self):
        """(3,) float : The joint axis in the joint frame.

        """
        return self._axis

    @axis.setter
    def axis(self, value):
        if value is None:
            value = np.array([1.0, 0.0, 0.0])
        else:
            value = np.asanyarray(value).astype(np.float64)
            if value.shape != (3,):
                raise ValueError('Invalid shape for axis, should be (3,)')
            value = normalize_vector(value)
        self._axis = value

    @property
    def origin(self):
        """Return matrix

        (4,4) float : The pose of child and joint frames relative to the
        parent link's frame.
        """
        return self._origin

    @origin.setter
    def origin(self, value):
        self._origin = configure_origin(value)

    @property
    def limit(self):
        """:class:`.JointLimit` : The limits for this joint.

        """
        return self._limit

    @limit.setter
    def limit(self, value):
        if value is None:
            if self.joint_type in ['prismatic', 'revolute']:
                logger.error('Require joint limit for prismatic and '
                                    'revolute joints')
                logger.error('Setting joint limit to 0.0')
                value = JointLimit(effort=0.0, velocity=0.0,
                                   lower=0, upper=0)
        elif not isinstance(value, JointLimit):
            raise TypeError('Expected JointLimit type')
        self._limit = value

    @property
    def dynamics(self):
        """:class:`.JointDynamics` : The dynamics for this joint.

        """
        return self._dynamics

    @dynamics.setter
    def dynamics(self, value):
        if value is not None:
            if not isinstance(value, JointDynamics):
                raise TypeError('Expected JointDynamics type')
        self._dynamics = value

    @property
    def safety_controller(self):
        """:class:`.SafetyController` : The safety controller for this joint.

        """
        return self._safety_controller

    @safety_controller.setter
    def safety_controller(self, value):
        if value is not None:
            if not isinstance(value, SafetyController):
                raise TypeError('Expected SafetyController type')
        self._safety_controller = value

    @property
    def calibration(self):
        """:class:`.JointCalibration` : The calibration for this joint.

        """
        return self._calibration

    @calibration.setter
    def calibration(self, value):
        if value is not None:
            if not isinstance(value, JointCalibration):
                raise TypeError('Expected JointCalibration type')
        self._calibration = value

    @property
    def mimic(self):
        """:class:`.JointMimic` : The mimic for this joint.

        """
        return self._mimic

    @mimic.setter
    def mimic(self, value):
        if value is not None:
            if not isinstance(value, JointMimic):
                raise TypeError('Expected JointMimic type')
        self._mimic = value

    def is_valid(self, cfg):
        """Check if the provided configuration value is valid for this joint.

        Parameters
        ----------
        cfg : float, (2,) float, (6,) float, or (4,4) float
            The configuration of the joint.

        Returns
        -------
        is_valid : bool
            True if the configuration is valid, and False otherwise.
        """
        if self.joint_type not in ['fixed', 'revolute']:
            return True
        if self.joint_limit is None:
            return True
        cfg = float(cfg)
        lower = -np.infty
        upper = np.infty
        if self.limit.lower is not None:
            lower = self.limit.lower
        if self.limit.upper is not None:
            upper = self.limit.upper
        return (cfg >= lower and cfg <= upper)

    def get_child_pose(self, cfg=None):
        """Return child pose

        Computes the child pose relative to a parent pose for a given
        configuration value.

        Parameters
        ----------
        cfg : float, (2,) float, (6,) float, or (4,4) float
            The configuration values for this joint. They are interpreted
            based on the joint type as follows:

            - ``fixed`` - not used.
            - ``prismatic`` - a translation along the axis in meters.
            - ``revolute`` - a rotation about the axis in radians.
            - ``continuous`` - a rotation about the axis in radians.
            - ``planar`` - the x and y translation values in the plane.
            - ``floating`` - the xyz values followed by the rpy values,
              or a (4,4) matrix.

            If ``cfg`` is ``None``, then this just returns the joint pose.

        Returns
        -------
        pose : (4,4) float
            The pose of the child relative to the parent.
        """
        if cfg is None:
            return self.origin
        elif self.joint_type == 'fixed':
            return self.origin
        elif self.joint_type in ['revolute', 'continuous']:
            if cfg is None:
                cfg = 0.0
            else:
                cfg = float(cfg)
            trimesh = _lazy_trimesh()
            R = trimesh.transformations.rotation_matrix(cfg, self.axis)
            return self.origin.dot(R)
        elif self.joint_type == 'prismatic':
            if cfg is None:
                cfg = 0.0
            else:
                cfg = float(cfg)
            translation = np.eye(4)
            translation[:3, 3] = self.axis * cfg
            return self.origin.dot(translation)
        elif self.joint_type == 'planar':
            if cfg is None:
                cfg = np.zeros(2)
            else:
                cfg = np.asanyarray(cfg)
            if cfg.shape != (2,):
                raise ValueError(
                    '(2,) float configuration required for planar joints'
                )
            translation = np.eye(4)
            translation[:3, 3] = self.origin[:3, :2].dot(cfg)
            return self.origin.dot(translation)
        elif self.joint_type == 'floating':
            if cfg is None:
                cfg = np.zeros(6)
            else:
                cfg = configure_origin(cfg)
            if cfg is None:
                raise ValueError('Invalid configuration for floating joint')
            return self.origin.dot(cfg)
        else:
            raise ValueError('Invalid configuration')

    @classmethod
    def _from_xml(cls, node, path):
        kwargs = cls._parse(node, path)
        kwargs['joint_type'] = str(node.attrib['type'])
        kwargs['parent'] = node.find('parent').attrib['link']
        kwargs['child'] = node.find('child').attrib['link']
        axis = node.find('axis')
        if axis is not None:
            if 'xyz' in axis.attrib:
                axis = np.fromstring(axis.attrib['xyz'], sep=' ')
            else:
                axis = np.array([0.0, 0.0, 0.0])
        kwargs['axis'] = axis
        kwargs['origin'] = parse_origin(node)
        return Joint(**kwargs)

    def _to_xml(self, parent, path):
        node = self._unparse(path)
        parent = ET.Element('parent')
        parent.attrib['link'] = self.parent
        node.append(parent)
        child = ET.Element('child')
        child.attrib['link'] = self.child
        node.append(child)
        if self.axis is not None:
            axis = ET.Element('axis')
            axis.attrib['xyz'] = np.array2string(self.axis)[1:-1]
            node.append(axis)

        # Apply scale factor to joint origin translation
        scaled_origin = self.origin.copy()
        scale_factor = _CONFIGURABLE_VALUES.get('scale_factor', 1.0)
        if scale_factor != 1.0:
            scaled_origin[:3, 3] *= scale_factor

        node.append(unparse_origin(scaled_origin))
        node.attrib['type'] = self.joint_type
        return node


class Link(URDFType):
    """A link of a rigid object.

    Parameters
    ----------
    name : str
        The name of the link.
    inertial : :class:`.Inertial`, optional
        The inertial properties of the link.
    visuals : list of :class:`.Visual`, optional
        The visual properties of the link.
    collisions : list of :class:`.Collision`, optional
        The collision properties of the link.
    """

    _ATTRIBS = {
        'name': (str, True),
    }
    _ELEMENTS = {
        'inertial': (Inertial, False, False),
        'visuals': (Visual, False, True),
        'collisions': (Collision, False, True),
    }
    _TAG = 'link'

    def __init__(self, name, inertial, visuals, collisions):
        self.name = name
        self.inertial = inertial
        self.visuals = visuals
        self.collisions = collisions

        self._visual_meshes = None
        self._collision_mesh = None

    @property
    def name(self):
        """str : The name of this link.

        """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def inertial(self):
        """:class:`.Inertial` : Inertial properties of the link.

        """
        return self._inertial

    @inertial.setter
    def inertial(self, value):
        if value is not None and not isinstance(value, Inertial):
            raise TypeError('Expected Inertial object')
        self._inertial = value

    @property
    def visuals(self):
        """list of :class:`.Visual` : The visual properties of this link.

        """
        return self._visuals

    @visuals.setter
    def visuals(self, value):
        if value is None:
            value = []
        else:
            value = list(value)
            for v in value:
                if not isinstance(v, Visual):
                    raise ValueError('Expected list of Visual objects')
        self._visuals = value

    @property
    def collisions(self):
        """list of :class:`.Collision` : The collision properties of this link.

        """
        return self._collisions

    @collisions.setter
    def collisions(self, value):
        if value is None:
            value = []
        else:
            value = list(value)
            for v in value:
                if not isinstance(v, Collision):
                    raise ValueError('Expected list of Collision objects')
        self._collisions = value

    @property
    def collision_mesh(self):
        """Return collision mesh

        :class:`~trimesh.base.Trimesh` : A single collision mesh for
        the link, specified in the link frame, or None if there isn't one.

        """
        if len(self.collisions) == 0:
            return None
        if self._collision_mesh is None:
            meshes = []
            for c in self.collisions:
                for m in c.geometry.meshes:
                    m = m.copy()
                    if c.geometry.mesh is None:
                        m.metadata["original_primitive_origin_for_sdf"] = c.origin.copy()  # noqa: E501
                    pose = c.origin
                    if c.geometry.mesh is not None:
                        if c.geometry.mesh.scale is not None:
                            S = np.eye(4)
                            S[:3, :3] = np.diag(c.geometry.mesh.scale)
                            pose = pose.dot(S)
                    m.apply_transform(pose)
                    meshes.append(m)
            if len(meshes) == 0:
                return None
            self._collision_mesh = (meshes[0] + meshes[1:])
        return self._collision_mesh


class URDF(URDFType):
    """The top-level URDF specification.

    The URDF encapsulates an articulated object, such as a robot or a gripper.
    It is made of links and joints that tie them together and define their
    relative motions.

    Parameters
    ----------
    name : str
        The name of the URDF.
    links : list of :class:`.Link`
        The links of the URDF.
    joints : list of :class:`.Joint`, optional
        The joints of the URDF.
    transmissions : list of :class:`.Transmission`, optional
        The transmissions of the URDF.
    materials : list of :class:`.Material`, optional
        The materials for the URDF.
    other_xml : str, optional
        A string containing any extra XML for extensions.
    """
    _ATTRIBS = {
        'name': (str, True),
    }
    _ELEMENTS = {
        'links': (Link, True, True),
        'joints': (Joint, False, True),
        'transmissions': (Transmission, False, True),
        'materials': (Material, False, True),
    }
    _TAG = 'robot'

    def __init__(self, name, links, joints=None,
                 transmissions=None, materials=None, other_xml=None):
        if joints is None:
            joints = []
        if transmissions is None:
            transmissions = []
        if materials is None:
            materials = []

        self.name = name
        self.other_xml = other_xml

        # No setters for these
        self._links = list(links)
        self._joints = list(joints)
        self._transmissions = list(transmissions)
        self._materials = list(materials)

        # Set up private helper maps from name to value
        self._link_map = {}
        self._joint_map = {}
        self._transmission_map = {}
        self._material_map = {}

        for x in self._links:
            if x.name in self._link_map:
                logger.error('Two links with name %s found', x.name)
                continue
            self._link_map[x.name] = x

        for x in self._joints:
            if x.name in self._joint_map:
                logger.error('Two joints with name %s '
                             'found', x.name)
                continue
            self._joint_map[x.name] = x

        for x in self._transmissions:
            if x.name in self._transmission_map:
                logger.error('Two transmissions with name %s '
                             'found', x.name)
                continue
            self._transmission_map[x.name] = x

        for x in self._materials:
            if x.name in self._material_map:
                logger.error('Two materials with name %s '
                             'found', x.name)
                continue
            self._material_map[x.name] = x

        # Synchronize materials between links and top-level set
        self._merge_materials()

        # Validate the joints and transmissions
        self._actuated_joints = self._validate_joints()
        self._validate_transmissions()

        # Create the link graph and base link/end link sets
        self._G = nx.DiGraph()

        # Add all links
        for link in self.links:
            self._G.add_node(link)

        # Add all edges from CHILDREN TO PARENTS, with joints as their object
        for joint in self.joints:
            if joint.parent not in self._link_map or joint.child not in self._link_map:
                logger.error(
                    'Joint %s has parent %s or child %s that is not in the link map',
                    joint.name, joint.parent, joint.child
                )
                continue
            parent = self._link_map[joint.parent]
            child = self._link_map[joint.child]
            self._G.add_edge(child, parent, joint=joint)

        if self._G.number_of_nodes() > 0:
            # Validate the graph and get the base and end links
            try:
                self._base_link, self._end_links = self._validate_graph()
            except ValueError as e:
                logger.error('Invalid URDF graph: %s', e)
                self._base_link = None
                self._end_links = []
                return

            # Cache the paths to the base link
            self._paths_to_base = nx.shortest_path(
                self._G, target=self._base_link
            )

            # Cache the reverse topological order (useful for speeding up FK,
            # as we want to start at the base and work outward to cache
            # computation.
            self._reverse_topo = list(reversed(list(nx.topological_sort(self._G))))
        else:
            self._base_link = None
            logger.error('No links found in the URDF, cannot create base link')

    @property
    def name(self):
        """str : The name of the URDF.

        """
        return self._name

    @name.setter
    def name(self, value):
        self._name = str(value)

    @property
    def links(self):
        """list of :class:`.Link` : The links of the URDF.

        This returns a copy of the links array which cannot be edited
        directly. If you want to add or remove links, use
        the appropriate functions.
        """
        return copy.copy(self._links)

    @property
    def link_map(self):
        """dict : Map from link names to the links themselves.

        This returns a copy of the link map which cannot be edited
        directly. If you want to add or remove links, use
        the appropriate functions.
        """
        return copy.copy(self._link_map)

    @property
    def joints(self):
        """list of :class:`.Joint` : The links of the URDF.

        This returns a copy of the joints array which cannot be edited
        directly. If you want to add or remove joints, use
        the appropriate functions.
        """
        return copy.copy(self._joints)

    @property
    def joint_map(self):
        """dict : Map from joint names to the joints themselves.

        This returns a copy of the joint map which cannot be edited
        directly. If you want to add or remove joints, use
        the appropriate functions.
        """
        return copy.copy(self._joint_map)

    @property
    def transmissions(self):
        """list of :class:`.Transmission` : The transmissions of the URDF.

        This returns a copy of the transmissions array which cannot be edited
        directly. If you want to add or remove transmissions, use
        the appropriate functions.
        """
        return copy.copy(self._transmissions)

    @property
    def transmission_map(self):
        """dict : Map from transmission names to the transmissions themselves.

        This returns a copy of the transmission map which cannot be edited
        directly. If you want to add or remove transmissions, use
        the appropriate functions.
        """
        return copy.copy(self._transmission_map)

    @property
    def materials(self):
        """list of :class:`.Material` : The materials of the URDF.

        This returns a copy of the materials array which cannot be edited
        directly. If you want to add or remove materials, use
        the appropriate functions.
        """
        return copy.copy(self._materials)

    @property
    def material_map(self):
        """dict : Map from material names to the materials themselves.

        This returns a copy of the material map which cannot be edited
        directly. If you want to add or remove materials, use
        the appropriate functions.
        """
        return copy.copy(self._material_map)

    @property
    def other_xml(self):
        """str : Any extra XML that belongs with the URDF.

        """
        return self._other_xml

    @other_xml.setter
    def other_xml(self, value):
        self._other_xml = value

    @property
    def actuated_joints(self):
        """Return actuated joints

        list of :class:`.Joint` : The joints that are independently
        actuated.
        This excludes mimic joints and fixed joints.
        """
        return self._actuated_joints

    @property
    def base_link(self):
        """:class:`.Link`: The base link for the URDF.

        The base link is the single link that has no parent.
        """
        return self._base_link

    @property
    def end_links(self):
        """list of :class:`.Link`: The end links for the URDF.

        The end links are the links that have no children.
        """
        return self._end_links

    def save(self, file_obj):
        """Save this URDF to a file.

        Parameters
        ----------
        file_obj : str or file-like object
            The file to save the URDF to. Should be the path to the
            ``.urdf`` XML file. Any paths in the URDF should be specified
            as relative paths to the ``.urdf`` file instead of as ROS
            resources.

        Returns
        -------
        urdf : :class:`.URDF`
            The parsed URDF.
        """
        if isinstance(file_obj, six.string_types):
            path, _ = os.path.split(file_obj)
        else:
            path, _ = os.path.split(os.path.realpath(file_obj.name))

        node = self._to_xml(None, path)
        tree = ET.ElementTree(node)
        tree.write(file_obj, pretty_print=True,
                   xml_declaration=True, encoding='utf-8')

    def _merge_materials(self):
        """Merge the top-level material set with the link materials.

        This method handles empty material names and duplicate names
        by creating unique internal names while preserving the original behavior.
        """
        material_name_counter = {}

        for link in self.links:
            for v in link.visuals:
                if v.material is None:
                    continue

                # Get the original material name
                original_name = v.material.name

                # If the name is empty or we need to handle duplicates
                if not original_name or original_name in material_name_counter:
                    # Create a unique name for internal use
                    if original_name not in material_name_counter:
                        material_name_counter[original_name] = 0
                    material_name_counter[original_name] += 1

                    # Create unique internal name
                    if original_name:
                        unique_name = "{}___{}".format(original_name, material_name_counter[original_name])
                    else:
                        unique_name = "__unnamed_material_{}".format(material_name_counter[original_name])

                    # Create a new material instance with the unique name
                    # but keeping all other properties
                    new_material = Material(
                        name=unique_name,
                        color=v.material.color,
                        texture=v.material.texture
                    )
                    v.material = new_material

                    # Add to materials list and map
                    self._materials.append(v.material)
                    self._material_map[unique_name] = v.material
                else:
                    # First occurrence of this name - use original behavior
                    if original_name in self.material_map:
                        v.material = self._material_map[original_name]
                    else:
                        self._materials.append(v.material)
                        self._material_map[original_name] = v.material
                        material_name_counter[original_name] = 0

    @staticmethod
    def load(file_obj):
        """Load a URDF from a file.

        Parameters
        ----------
        file_obj : str or file-like object
            The file to load the URDF from. Should be the path to the
            ``.urdf`` XML file. Any paths in the URDF should be specified
            as relative paths to the ``.urdf`` file instead of as ROS
            resources.

        Returns
        -------
        urdf : :class:`.URDF`
            The parsed URDF.
        """
        if isinstance(file_obj, six.string_types):
            # Handle package:// URLs
            if file_obj.startswith('package://'):
                resolved_path = resolve_filepath(os.getcwd(), file_obj)
                if resolved_path is None:
                    raise ValueError(
                        'Could not resolve package path: {}'.format(file_obj))
                file_obj = resolved_path

            if os.path.isfile(file_obj):
                parser = ET.XMLParser(remove_comments=True,
                                      remove_blank_text=True)
                try:
                    tree = ET.parse(file_obj, parser=parser)
                except ET.XMLSyntaxError as e:
                    logger.error('Failed to parse XML from file-like object: %s', e)
                    return URDF(name='INVALID_URDF', links=[])
                path, _ = os.path.split(file_obj)
            else:
                raise ValueError('{} is not a file'.format(file_obj))
        else:
            parser = ET.XMLParser(remove_comments=True, remove_blank_text=True)
            try:
                tree = ET.parse(file_obj, parser=parser)
            except ET.XMLSyntaxError as e:
                logger.error('Failed to parse XML from file-like object: %s', e)
                return URDF(name='INVALID_URDF', links=[])
            path, _ = os.path.split(file_obj.name)

        node = tree.getroot()
        return URDF._from_xml(node, path)

    def _validate_joints(self):
        """Raise an exception of any joints are invalidly specified.

        Checks for the following:

        - Joint parents are valid link names.
        - Joint children are valid link names that aren't the same as parent.
        - Joint mimics have valid joint names that aren't the same joint.

        Returns
        -------
        actuated_joints : list of :class:`.Joint`
            The joints in the model that are independently controllable.
        """
        actuated_joints = []
        for joint in self.joints:
            if joint.parent not in self._link_map:
                logger.error('Joint %s has invalid parent link name %s',
                             joint.name, joint.parent)
            if joint.child not in self._link_map:
                logger.error('Joint %s has invalid child link name %s',
                             joint.name, joint.child)
            if joint.child == joint.parent:
                logger.error('Joint %s has matching parent and child',
                             joint.name)
            if joint.mimic is not None:
                if joint.mimic.joint not in self._joint_map:
                    logger.error(
                        'Joint %s has an invalid mimic joint name %s',
                        joint.name, joint.mimic.joint
                    )
                if joint.mimic.joint == joint.name:
                    logger.error(
                        'Joint %s set up to mimic itself',
                        joint.mimic.joint
                    )
            elif joint.joint_type != 'fixed':
                actuated_joints.append(joint)
        return actuated_joints

    def _validate_transmissions(self):
        """Raise an exception of any transmissions are invalidly specified.

        Checks for the following:

        - Transmission joints have valid joint names.
        """
        for t in self.transmissions:
            for joint in t.joints:
                if joint.name not in self._joint_map:
                    logger.error('Transmission %s has invalid joint name %s',
                                 t.name, joint.name)

    def _validate_graph(self):
        """Raise an exception if the link-joint structure is invalid.

        Checks for the following:

        - The graph is connected in the undirected sense.
        - The graph is acyclic in the directed sense.
        - The graph has only one base link.

        Returns
        -------
        base_link : :class:`.Link`
            The base link of the URDF.
        end_links : list of :class:`.Link`
            The end links of the URDF.
        """

        # Check that the link graph is weakly connected
        if not nx.is_weakly_connected(self._G):
            link_clusters = []
            for cc in nx.weakly_connected_components(self._G):
                cluster = []
                for n in cc:
                    cluster.append(n.name)
                link_clusters.append(cluster)
            message = ('Links are not all connected. '
                       'Connected components are:')
            for lc in link_clusters:
                message += '\n\t'
                for n in lc:
                    message += ' {}'.format(n)
            raise ValueError(message)

        # Check that link graph is acyclic
        if not nx.is_directed_acyclic_graph(self._G):
            raise ValueError('There are cycles in the link graph')

        # Ensure that there is exactly one base link, which has no parent
        base_link = None
        end_links = []
        for n in self._G:
            if len(nx.descendants(self._G, n)) == 0:
                if base_link is None:
                    base_link = n
                else:
                    raise ValueError('Links {} and {} are both base links!'
                                     .format(n.name, base_link.name))
            if len(nx.ancestors(self._G, n)) == 0:
                end_links.append(n)
        return base_link, end_links

    @classmethod
    def _from_xml(cls, node, path):
        valid_tags = set(['joint', 'link', 'transmission', 'material'])
        kwargs = cls._parse(node, path)

        extra_xml_node = ET.Element('extra')
        for child in node:
            if child.tag not in valid_tags:
                extra_xml_node.append(child)

        data = ET.tostring(extra_xml_node)
        kwargs['other_xml'] = data
        if 'name' not in kwargs:
            kwargs['name'] = 'UNNAMED_URDF'
        return URDF(**kwargs)

    def _to_xml(self, parent, path):
        node = self._unparse(path)
        if self.other_xml:
            if isinstance(self.other_xml, bytes):
                extra_tree = ET.fromstring(self.other_xml.decode('utf-8'))
            else:
                extra_tree = ET.fromstring(self.other_xml)
            for child in extra_tree:
                node.append(child)
        return node
