# -*- coding: utf-8 -*-
# **************************************************************************
# *
# * Authors:     J.M. De la Rosa Trevin (delarosatrevin@scilifelab.se) [1]
# *
# * [1] SciLifeLab, Stockholm University
# *
# * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
# * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
# * 02111-1307  USA
# *
# *  All comments concerning this program package may be sent to the
# *  e-mail address 'scipion@cnb.csic.es'
# *
# **************************************************************************
"""

@article{Abrishami2013,
author = {Abrishami, V. and Zaldívar-Peraza, A. and de la Rosa-Trevín, J. M. and Vargas, J. and Otón, J. and Marabini, R. and Shkolnisky, Y. and Carazo, J. M. and Sorzano, C. O. S.},
title = {A pattern matching approach to the automatic selection of particles from low-contrast electron micrographs},
volume = {29},
number = {19},
pages = {2460-2468},
year = {2013},
doi = {http://dx.doi.org/10.1093/bioinformatics/btt429},
url = {http://bioinformatics.oxfordjournals.org/content/29/19/2460.abstract},
journal = {Bioinformatics}
}

@article{Abrishami2015,
title = "Alignment of direct detection device micrographs using a robust Optical Flow approach ",
journal = "Journal of Structural Biology ",
volume = "189",
number = "3",
pages = "163 - 176",
year = "2015",
note = "",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1016/j.jsb.2015.02.001",
url = "http://www.sciencedirect.com/science/article/pii/S1047847715000313",
author = "Vahid Abrishami and Javier Vargas and Xueming Li and Yifan Cheng and Roberto Marabini and Carlos Óscar Sánchez Sorzano and José María Carazo",
keywords = "Direct detection devices",
keywords = "Beam induced motion",
keywords = "Single particle analysis",
keywords = "Electron microscopy "
}

@article{Chen2013,
title = "Fast and accurate reference-free alignment of subtomograms ",
journal = "Journal of Structural Biology ",
volume = "182",
number = "3",
pages = "235 - 245",
year = "2013",
note = "",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1016/j.jsb.2013.03.002",
url = "http://www.sciencedirect.com/science/article/pii/S1047847713000737",
author = "Yuxiang Chen and Stefan Pfeffer and Thomas Hrabe and Jan Michael Schuller and Friedrich Förster",
keywords = "Cryo-electron tomography",
keywords = "Subtomogram averaging",
keywords = "Spherical harmonics "
}

@article{Cherian2013,
title = "Jensen-Bregman LogDet divergence with application to efficient similarity search for covariance matrices ",
journal = "IEEE Trans Pattern Anal Mach Intell ",
volume = "35",
pages = "2161-2174",
year = "2013",
doi = "http://dx.doi.org/10.1109/TPAMI.2012.259",
url = "http://ieeexplore.ieee.org/xpl/articleDetails.jsp?arnumber=6378374",
author = "Cherian, A. and Sra, S. and Banerjee, A. and Papanikolopoulos, N."
}

@article{delaRosaTrevin2013,
title = "Xmipp 3.0: An improved software suite for image processing in electron microscopy ",
journal = "JSB",
volume = "184",
number = "2",
pages = "321 - 328",
year = "2013",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1016/j.jsb.2013.09.015",
url = "http://www.sciencedirect.com/science/article/pii/S1047847713002566",
author = "de la Rosa-Trevín, J.M.  and Oton, J. and R. Marabini and A. Zaldívar and J. Vargas and J.M. Carazo and Sorzano, C.O.S.",
keywords = "Electron microscopy, Single particles analysis, Image processing, Software package "
}

@article{Jin2014,
title = "Iterative Elastic 3D-to-2D Alignment Method Using Normal Modes for Studying Structural Dynamics of Large Macromolecular Complexes",
journal = "Structure",
volume = "22",
pages = "1 - 11",
year = "2014",
doi = "http://dx.doi.org/10.1016/j.str.2014.01.004",
url = "http://www.ncbi.nlm.nih.gov/pubmed/24508340",
author = "Jin, Q. and Sorzano, C. O. S. and de la Rosa-Trevín, J. M. and Bilbao-Castro, J. R. and Núñez-Ramirez, R. and Llorca, O. and Tama, F. and Jonic, S.",
keywords = "Normal mode analysis, NMA "
}

@article{Jonic2005,
title = "Spline-based image-to-volume registration for three-dimensional electron microscopy ",
journal = "Ultramicroscopy ",
volume = "103",
number = "4",
pages = "303 - 317",
year = "2005",
issn = "0304-3991",
doi = "http://dx.doi.org/10.1016/j.ultramic.2005.02.002",
url = "http://www.sciencedirect.com/science/article/pii/S0304399105000173",
author = "Jonic, S. and C.O.S. Sorzano and P. Thevenaz and C. El-Bez and S. De Carlo and M. Unser",
keywords = "2D/3D registration, Splines, 3DEM, Angular assignment "
}

@article{Nogales2013,
title={3DEM Loupe: analysis of macromolecular dynamics using structures from electron microscopy},
author={Nogales-Cadenas, R. and Jonic, S. and Tama, F. and Arteni, A. A. and Tabas-Madrid, D. and V{\'a}zquez, M. and Pascual-Montano, A. and Sorzano, C. O. S.},
journal={Nucleic acids research},
year={2013},
publisher={Oxford Univ Press},
doi={http://dx.doi.org/10.1093/nar/gkt385}
}

@article{Otsu1979,
title = "A Threshold Selection Method from Gray-Level Histograms",
journal = "Systems, Man and Cybernetics, IEEE Transactions",
volume = "9",
number = "2",
pages = "62 - 66",
year = "1979",
issn = "0018-9472",
doi = "http://dx.doi.org/10.1109/TSMC.1979.4310076",
author = "Otsu, N.",
}

@article{Pascual2000,
title = "Mapping and fuzzy classification of macromolecular images using self-organizing neural networks ",
journal = "Ultramicroscopy",
volume = "84",
number = "1-2",
pages = "85 - 99",
year = "2000",
note = "",
issn = "0304-3991",
doi = "http://dx.doi.org/10.1016/S0304-3991(00)00022-X",
url = "http://www.sciencedirect.com/science/article/pii/S030439910000022X",
author = "Pascual-Montano, A and Montserrat Bárcena and J.J Merelo and José-María Carazo",
keywords = "Image processing, Cluster analysis, Neural networks, Self-organizing maps, Fuzzy logic "
}

@article{PascualMontano2001,
title = "A Novel Neural Network Technique for Analysis and Classification of \\{EM\\} Single-Particle Images",
journal = "JSB",
volume = "133",
number = "2 - 3",
pages = "233 - 245",
year = "2001",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1006/jsbi.2001.4369",
url = "http://www.sciencedirect.com/science/article/pii/S1047847701943692",
author = "Pascual-Montano, A and L.E Donate and M Valle and M Bárcena and R.D Pascual-Marqui and J.M Carazo",
keywords = "classification, cryo-EM, image processing, neural networks, self-organizing maps, probability density function, kernel functions",
}

@article{PascualMontano2002,
title = "Quantitative self-organizing maps for clustering electron tomograms ",
journal = "JSB",
volume = "138",
number = "1-2",
pages = "114 - 122",
year = "2002",
note = "",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1016/S1047-8477(02)00008-4",
url = "http://www.sciencedirect.com/science/article/pii/S1047847702000084",
author = "Pascual-Montano, A and K.A. Taylor and H. Winkler and R.D. Pascual-Marqui and J.-M. Carazo",
keywords = "Classification, Electron tomography, Image processing, Neural networks, Self-organizing maps, Probability density function, Kernel functions, Actin, Myosin, Muscle proteins "
}

@Article{Rosenthal2003,
   Author="Rosenthal, P. B.  and Henderson, R. ",
   Title="{{O}ptimal determination of particle orientation, absolute hand, and contrast loss in single-particle electron cryomicroscopy}",
   Journal="J. Mol. Biol.",
   Year="2003",
   Volume="333",
   Number="4",
   Pages="721--745",
   Month="Oct",
   url="http://www.sciencedirect.com/science/article/pii/S0022283603010222",
   doi={http://dx.doi.org/10.1016/j.jmb.2003.07.013}
}


@article{Scheres2005a,
title = "Maximum-likelihood Multi-reference Refinement for Electron Microscopy Images ",
   Journal="J. Mol. Biol.",
volume = "348",
number = "1",
pages = "139 - 149",
year = "2005",
issn = "0022-2836",
doi = "http://dx.doi.org/10.1016/j.jmb.2005.02.031",
url = "http://www.sciencedirect.com/science/article/pii/S0022283605001932",
author = "Scheres, Sjors H.W. and Valle, Mikel and Rafael Núñez and Carlos O.S. Sorzano and Roberto Marabini and Gabor T. Herman and Jose-Maria Carazo",
keywords = "maximum-likelihood, multi-reference refinement, single-particles, 2D-alignment, classification "
}

@article{Scheres2005b,
author = {Scheres, Sjors H.W. and Valle, Mikel and Carazo, José-María},
title = {Fast maximum-likelihood refinement of electron microscopy images.},
journal = {Bioinformatics},
year = {2005},
volume = {21 Suppl 2},
pages = {ii243--ii244},
month = {Sep},
doi = {http://dx.doi.org/10.1093/bioinformatics/bti1140},
url = {http://dx.doi.org/10.1093/bioinformatics/bti1140},
keywords = {Algorithms; Cryoelectron Microscopy, methods; Image Enhancement, methods;
  Image Interpretation, Computer-Assisted, methods; Imaging, Three-Dimensional,
  methods; Likelihood Functions; Reproducibility of Results; Sensitivity
  and Specificity}
}

@article{Scheres2007a,
  author = {Scheres, Sjors H. W. and Haixiao Gao and Mikel Valle and Gabor T Herman
    and Paul P B Eggermont and et.al.},
  title = {Disentangling conformational states of macromolecules in 3D-EM through
    likelihood optimization.},
  journal = {Nature Methods},
  year = {2007},
  volume = {4},
  pages = {27--29},
  number = {1},
  month = {Jan},
  doi = {http://dx.doi.org/10.1038/nmeth992}
  keywords = {Antigens, Polyomavirus Transforming; Escherichia coli; Image Processing,
    Computer-Assisted; Imaging, Three-Dimensional; Likelihood Functions;
    Microscopy, Electron; Models, Molecular; Protein Conformation; Ribosomes;
    Sensitivity and Specificity; Simian virus 40},
}

@article{Scheres2007b,
  author = {Scheres, Sjors H. W. and Núñez-Ramírez, Rafael and Gómez-Llorente,
    Yacob and {San Martín}, Carmen and Eggermont, Paul P B. and Carazo,
    José María},
  title = {Modeling experimental image formation for likelihood-based classification
    of electron microscopy data.},
  journal = {Structure},
  year = {2007},
  volume = {15},
  pages = {1167--1177},
  number = {10},
  month = {Oct},
  doi = {http://dx.doi.org/10.1016/j.str.2007.09.003},
  url = {http://dx.doi.org/10.1016/j.str.2007.09.003},
  keywords = {Algorithms; Antigens, Polyomavirus Transforming, chemistry/ultrastructure;
    Archaeal Proteins, chemistry/ultrastructure; Cryoelectron Microscopy,
    methods/statistics /&/ numerical data; DNA Helicases, chemistry/ultrastructure;
    Escherichia coli, metabolism; Imaging, Three-Dimensional; Likelihood
    Functions; Models, Molecular; Models, Statistical; Protein Conformation;
    Ribosomes, chemistry/ultrastructure}
}

@article{Scheres2009b,
  author = {Scheres, Sjors H W. and Carazo, José María},
  title = {Introducing robustness to maximum-likelihood refinement of electron-microscopy
    data.},
  journal = {Acta Crystallogr D Biol Crystallogr},
  year = {2009},
  volume = {65},
  pages = {672--678},
  number = {Pt 7},
  month = {Jul},
  doi = {http://dx.doi.org/10.1107/S0907444909012049},
  url = {http://dx.doi.org/10.1107/S0907444909012049},
  keywords = {Algorithms; Cryoelectron Microscopy; Escherichia coli, chemistry;
    Likelihood Functions; Models, Molecular; Peptide Elongation Factor
    G, chemistry/ultrastructure; Protein Structure, Tertiary}
}

@article{Scheres2009c,
  author = {Scheres, Sjors H W. and Melero, Roberto and Valle, Mikel and Carazo, José María},
  title = {Averaging of Electron Subtomograms and Random Conical Tilt Reconstructions through Likelihood Optimization},
  journal = {Structure},
  year = {2009},
  volume = {17},
  pages = {1563--1572},
  number = {12},
  month = {Dec},
  doi = {http://dx.doi.org/10.1016/j.str.2009.10.009}
}

@article{Sorzano2004b,
title = "A multiresolution approach to orientation assignment in 3D electron microscopy of single particles ",
journal = "JSB ",
volume = "146",
number = "3",
pages = "381 - 392",
year = "2004",
note = "",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1016/j.jsb.2004.01.006",
url = "http://www.sciencedirect.com/science/article/pii/S1047847704000073",
author = "Sorzano, C.O.S. and S. Jonic and C. El-Bez and J.M. Carazo and S. De Carlo and P. Thevenaz and M. Unser"
}

@Article{Sorzano2007a,
  Title                    = {Fast, robust and accurate determination of transmission electron microscopy contrast transfer function},
  Author                   = {Sorzano, C. O. S. and Jonic, S. and N\'u\\~nez-Ram\'irez, R. and Boisset, N. and Carazo, J. M.},
  Journal                  = {J. Structural Biology},
  Year                     = {2007},
  Pages                    = {249--262},
  Volume                   = {160},
  doi = {http://dx.doi.org/10.1016/j.jsb.2007.08.013},
  url = "http://www.sciencedirect.com/science/article/pii/S104784770700202X"
}

@article{Sorzano2009d,
title = "Effects of the downsampling scheme on three-dimensional electron microscopy of single particles",
journal = "Proc. of IEEE Workshop on Intelligent Signal Processing",
pages = "175-179",
year = "2009",
note = "",
issn = "978-1-4244-5059-6",
doi = "http://dx.doi.org/10.1109/WISP.2009.5286563",
url = "http://ieeexplore.ieee.org/xpl/articleDetails.jsp?arnumber=5286563",
author = "Sorzano, C. O. S. and Iriarte-Ruiz, A. and Marabini, R. and Carazo, J. M.",
keywords = "Downsampling, Single Particles, Electron microscopy"
}

@article{Sorzano2010a,
title = "A clustering approach to multireference alignment of single-particle projections in electron microscopy ",
journal = "Journal of Structural Biology ",
volume = "171",
number = "2",
pages = "197 - 206",
year = "2010",
note = "",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1016/j.jsb.2010.03.011",
url = "http://www.sciencedirect.com/science/article/pii/S1047847710000882",
author = "C.O.S. Sorzano and J.R. Bilbao-Castro and Y. Shkolnisky and M. Alcorlo and R. Melero and G. Caffarena-Fernández and M. Li and G. Xu and R. Marabini and J.M. Carazo",
keywords = "Single-particle analysis, 2D analysis, Multireference analysis, Electron microscopy "
}

@incollection{Sorzano2013,
title = "Semiautomatic, High-Throughput, High-Resolution Protocol for Three-Dimensional Reconstruction of Single Particles in Electron Microscopy",
booktitle = "Nanoimaging",
year = "2013",
isbn = "978-1-62703-136-3",
volume = "950",
journal = "Methods in Molecular Biology",
editor = "Sousa, Alioscka A. and Kruhlak, Michael J.",
doi = "http://dx.doi.org/10.1007/978-1-62703-137-0_11",
publisher = "Humana Press",
keywords = "Single particle analysis; Electron microscopy; Image processing; 3D reconstruction; Workflows",
author = "Sorzano, C.O.S. and de la Rosa-Trevín, J.M. and Otón, J. and Vega, J.J. and Cuenca, J. and Zaldívar-Peraza, A. and Gómez-Blanco, J. and Vargas, J. and Quintana, A. and Marabini, Roberto and Carazo, José María",
pages = "171-193",
}

@InProceedings{Sorzano2014,
  title                    = {Outlier detection for single particle analysis in Electron Microscopy},
  author                   = {Sorzano, C. O. S. and Vargas, J. and de la Rosa-Trevín, J. M. and Zaldívar-Peraza, A. and Otón, J. and Abrishami, V. and Foche, I. and Marabini, R. and Caffarena, G. and Carazo, J. M.},
  journal                  = {Proc. Intl. Work-Conference on Bioinformatics and Biomedical Engineering, IWBBIO},
  year                     = {2014},
  pages                    = {950},
  doi                      = {http://biocomp.cnb.csic.es/~coss/Articulos/Sorzano2014.pdf}
}

@article{Sorzano2015,
author = {Sorzano, C. O. S. and Vargas, J. and de la Rosa-Trevin,  J. M. and Oton, J. and Alvarez-Cabrera, A. L. and Abrishami, V. and Sesmero, E. and Marabini, R. and Carazo, J. M.},
title = {A Statistical approach to the initial volume problem in Single Particle Analysis by Electron Microscopy},
journal = "J. Structural Biology",
year = "2015",
volume = "189",
pages = "213-219",
doi = {http://dx.doi.org/10.1016/j.jsb.2015.01.009}
}

@article{Vargas2013a,
author = {Vargas, J. and Otón, J. and Marabini, R. and Jonic, S. and {de la
  Rosa-Trevín}, J. M. and et.al.},
title = {{FASTDEF}: Fast defocus and astigmatism estimation for high-throughput
  transmission electron microscopy.},
journal = "J. Structural Biology",
doi = "http://dx.doi.org/10.1016/j.jsb.2012.12.006",
year = {2013},
volume = {181},
pages = {136--148},
number = {2},
month = {Feb},
}

@article{Vargas2013b,
title = "Particle quality assessment and sorting for automatic and semiautomatic particle-picking techniques ",
journal = "J. Structural Biology",
volume = "183",
number = "3",
pages = "342 - 353",
year = "2013",
note = "",
issn = "1047-8477",
doi = "http://dx.doi.org/10.1016/j.jsb.2013.07.015",
url = "http://www.sciencedirect.com/science/article/pii/S1047847713001950",
author = "J. Vargas and V. Abrishami and R. Marabini and J.M. de la Rosa-Trevín and A. Zaldivar and J.M. Carazo and C.O.S. Sorzano",
keywords = "Electron microscopy, Particle picking, Machine learning, Single particle analysis "
}

@article{Vargas2014,
author = {Vargas, Javier and Álvarez-Cabrera, Ana-Lucia and Marabini, Roberto and Carazo, Jose M. and Sorzano, C. O. S.}, 
title = {Efficient initial volume determination from electron microscopy images of single particles},
volume = {30}, 
number = {20}, 
pages = {2891-2898}, 
year = {2014}, 
doi = {http://dx.doi.org/10.1093/bioinformatics/btu404}, 
abstract ={Motivation: Structural information of macromolecular complexes provides key insights into the way they carry out their biological functions. The reconstruction process leading to the final 3D map requires an approximate initial model. Generation of an initial model is still an open and challenging problem in single-particle analysis.Results: We present a fast and efficient approach to obtain a reliable, low-resolution estimation of the 3D structure of a macromolecule, without any a priori knowledge, addressing the well-known issue of initial volume estimation in the field of single-particle analysis. The input of the algorithm is a set of class average images obtained from individual projections of a biological object at random and unknown orientations by transmission electron microscopy micrographs. The proposed method is based on an initial non-lineal dimensionality reduction approach, which allows to automatically selecting representative small sets of class average images capturing the most of the structural information of the particle under study. These reduced sets are then used to generate volumes from random orientation assignments. The best volume is determined from these guesses using a random sample consensus (RANSAC) approach. We have tested our proposed algorithm, which we will term 3D-RANSAC, with simulated and experimental data, obtaining satisfactory results under the low signal-to-noise conditions typical of cryo-electron microscopy.Availability: The algorithm is freely available as part of the Xmipp 3.1 package [http://xmipp.cnb.csic.es].Contact: jvargas@cnb.csic.esSupplementary information: Supplementary data are available at Bioinformatics online.}, 
URL = {http://bioinformatics.oxfordjournals.org/content/30/20/2891.abstract}, 
eprint = {http://bioinformatics.oxfordjournals.org/content/30/20/2891.full.pdf+html}, 
journal = {Bioinformatics} 
}

@article{Vilas2016,
  title                    = "Fast and automatic identification of particle tilt pairs based on Delaunay triangulation.",
  author                   = "Vilas, J. L. and Navas, J. and Gomez-Blanco, J. and de la Rosa-Trevin, J. M. and Melero, and Peschiera, I. and Ferlenghi. I and Cuenca, J. and Marabini, R. and Carazo, J. M. and Vargas, J. and Sorzano, C. O. S.",
  journal                  = "Journal of Structural Biology",
  year                     = "2016",
  pages                    = "525-533",
  volume                   = "196",
  doi                      = "http://dx.doi.org/10.1016/j.jsb.2016.10.007",
  url                      = "http://www.sciencedirect.com/science/article/pii/S104784771630212X"
}

@article{zhao2013,
author = {Zhao, Zhizhen and Singer, Amit},
title = {Fourier-Bessel rotational invariant eigenimages},
volume = {30},
number = {5},
pages = {871--877},
year = {2013},
doi = {http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3711886/pdf/nihms484949.pdf},
abstract = {},
url = {http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3711886},
eprint = {http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3711886/pdf/nihms484949.pdf},
journal = {Journal of the Optical Society of America. A, Optics, image science, and vision}
}

@article{ponce2011,
author = {Ponce, Colin and Singer, Amit},
title = {Computing Steerable Principal Components of a Large Set of Images and Their Rotations},
volume = {20},
number = {11},
pages = {3051--3062},
year = {2011},
doi = {http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3719433/pdf/nihms485040.pdf},
abstract = {},
url = {http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3719433},
eprint = {http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3719433/pdf/nihms485040.pdf},
journal = {IEEE Trans Image Process}
}

@article{Radermacher1987,
author = {Radermacher, M. and Wagenknecht, T. and Frank, J.},
title = {Three-dimensional reconstruction from a single-exposure, random conical tilt series applied to the 50S ribosomal subunit of Escherichia coli.},
volume = {146},
number = {2},
pages = {113-36},
year = {1987},
doi = {http://www.ncbi.nlm.nih.gov/pubmed/3302267},
abstract = {},
url = {http://www.ncbi.nlm.nih.gov/pubmed/3302267},
eprint = {http://www.ncbi.nlm.nih.gov/pubmed/3302267},
journal = {Journal of Microscopy}
}

@article{Vargas2014a,
title = {Particle alignment reliability in single particle electron cryomicroscopy: a general approach},
journal = {Scientific reports},
volume = "",
number = "",
pages = "",
year = "2014",
note = "",
issn = "",
doi = {http://dx.doi.org/10.1038/srep21626},
url = {http://dx.doi.org/10.1038/srep21626},
author = {Vargas},
keywords = {Validation}
}

@article{Marabini2014a,
title = "CTF Challenge: Result summary",
journal = "J. Structural Biology",
volume = "",
number = "",
pages = "",
year = "2015",
note = "",
issn = "",
doi = "http://doi.org/10.1016/j.jsb.2015.04.003",
url = "http://doi.org/10.1016/j.jsb.2015.04.003",
author = "Marabini",
keywords = "Contrast transfer function"
}

@article{B.Heymann2015,
title = {Validation of 3D of 3DEM Reconstructions: The phantom in the noise},
journal = {AIMS Biophys},
volume = {2},
number = {1},
pages = {21-35},
year = {2015},
note = "",
issn = "",
doi = {10.3934/biophy.2015.1.21},
url = {http://www.ncbi.nlm.nih.gov/pmc/articles/PMC4440490/},
author = "B. Heymann",
keywords = ""
}

@article{Sorzano2016,
title = "StructMap: Elastic distance analysis of electron microscopy maps for studying conformational changes",
journal = "Biophysical J.",
volume = "110",
number = "",
pages = "1753-1765",
year = "2016",
note = "",
issn = "",
doi = "http://doi.org/10.1016/j.bpj.2016.03.019",
url = "http://doi.org/10.1016/j.bpj.2016.03.019",
author = "C.O.S. Sorzano, A.L. Álvarez-Cabrera, M. Kazemi, J.M. Carazo, S. Jonic",
keywords = ""
}

@article{Sorzano2015b,
  title                    = "Cryo-EM and the elucidation of new macromolecular structures: Random Conical Tilt revisited.",
  author                   = "Sorzano, C O S. and Alcorlo, M. and de la Rosa-Trevín, J. M. and Melero, R. and Foche, I. and Zaldívar-Peraza, A. and del Cano, L. and Vargas, J. and Abrishami, V. and Otón, J. and Marabini, R. and Carazo, J. M.",
  journal                  = "Scientific Reports",
  year                     = "2015",
  pages                    = "14290",
  volume                   = "5",
  doi                      = "http://dx.doi.org/10.1038/srep14290",
  url                      = "http://dx.doi.org/10.1038/srep14290"
}

@article{Vilas2018,
  title                    = {MonoRes: Automatic and Accurate Estimation of Local Resolution for Electron Microscopy Maps},
  author                   = {Vilas, J. L. and et al},
  year                     = "2018",
  journal                  = "Structure",
  pages                    = "337--344",
  volume                   = "26",
  doi = {10.1016/j.str.2017.12.018},
  url = {http://doi.org/10.1016/j.str.2017.12.018},
}


@Article{strelak2020flexalign,
AUTHOR = {Střelák, David and Filipovič, Jiří and Jiménez-Moreno, Amaya and Carazo, Jose María and Sánchez Sorzano, Carlos Óscar},
TITLE = {FlexAlign: An Accurate and Fast Algorithm for Movie Alignment in Cryo-Electron Microscopy},
JOURNAL = {Electronics},
VOLUME = {9},
YEAR = {2020},
NUMBER = {6},
ARTICLE-NUMBER = {1040},
URL = {http://www.mdpi.com/2079-9292/9/6/1040},
ISSN = {2079-9292},
DOI = {http://doi.org/10.3390/electronics9061040}
}

@Article{Vilas2023,
AUTHOR = {Vilas, JL and Tagare, HD},
TITLE = {A simple and intuitive measurement of directional resolution anisotropy of cryoEM maps},
JOURNAL = {Nature Methods},
VOLUME = {X},
YEAR = {2023},
NUMBER = {X},
ARTICLE-NUMBER = {in press},
URL = {https://github.com/I2PC/xmipp/wiki/FSO---Fourier-Shell-Occupancy},
}

@article{Fernandez-Gimenez2021,
title = {Cryo-EM density maps adjustment for subtraction, consensus and sharpening},
journal = {Journal of Structural Biology},
volume = {213},
number = {4},
year = {2021},
issn = {1047-8477},
doi = {https://doi.org/10.1016/j.jsb.2021.107780},
url = {https://www.sciencedirect.com/science/article/pii/S104784772100085X},
author = {E. Fernández-Giménez and M. Martínez and R. Sánchez-García and R. Marabini and E. Ramírez-Aportela and
P. Conesa and J.M. Carazo and C.O.S. Sorzano},
}

@Article{Strelak2021,
AUTHOR = {Strelak, David and Jiménez-Moreno, Amaya and Vilas, José L. and Ramírez-Aportela, Erney and Sánchez-García, Ruben and Maluenda, David and Vargas, Javier and Herreros, David and Fernández-Giménez, Estrella and de Isidro-Gómez, Federico P. and Horacek, Jan and Myska, David and Horacek, Martin and Conesa, Pablo and Fonseca-Reyna, Yunior C. and Jiménez, Jorge and Martínez, Marta and Harastani, Mohamad and Jonić, Slavica and Filipovic, Jiri and Marabini, Roberto and Carazo, José M. and Sorzano, Carlos O. S.},
TITLE = {Advances in Xmipp for Cryo–Electron Microscopy: From Xmipp to Scipion},
JOURNAL = {Molecules},
VOLUME = {26},
YEAR = {2021},
NUMBER = {20},
ARTICLE-NUMBER = {6224},
URL = {https://www.mdpi.com/1420-3049/26/20/6224},
PubMedID = {34684805},
ISSN = {1420-3049},
DOI = {https://doi.org/10.3390/molecules26206224}
}


@article{Fernandez-Gimenez2023a,
title = {A new algorithm for particle weighted subtraction to eliminate signals from unwanted components in Single Particle Analysis},
journal = {Journal of Structural Biology},
volume = {215},
number = {4},
year = {2023},
issn = {1047-8477},
doi = {https://doi.org/10.1016/j.jsb.2023.108024},
url = {https://www.sciencedirect.com/science/article/pii/S1047847723000874},
author = {E. Fernández-Giménez, M. Martínez, R. Marabini, D. Strelak, R. Sánchez-García, J.M. Carazo and C.O.S. Sorzano},
}

@article{Fernandez-Gimenez2023b,
title = {Local defocus estimation in Single Particle Analysis in Cryo-Electron Microscopy},
journal = {Journal of Structural Biology},
volume = {215},
number = {4},
year = {2023},
issn = {1047-8477},
doi = {https://doi.org/10.1016/j.jsb.2023.108030},
url = {https://www.sciencedirect.com/science/article/pii/S104784772300093X},
author = {E. Fernández-Giménez, J.M. Carazo and C.O.S. Sorzano},


@Article{Strelak2023performance,
AUTHOR = {Střelák, David and Marchán, Daniel and Carazo, José María and S. Sorzano, Carlos O.},
TITLE = {Performance and Quality Comparison of Movie Alignment Software for Cryogenic Electron Microscopy},
JOURNAL = {Micromachines},
VOLUME = {14},
YEAR = {2023},
NUMBER = {10},
ARTICLE-NUMBER = {1835},
URL = {https://www.mdpi.com/2072-666X/14/10/1835},
ISSN = {2072-666X},
DOI = {https://doi.org/10.3390/mi14101835}

}

"""

