#!/usr/bin/env python3
"""Scitex act module."""

from ._define import define

__all__ = [
    "define",
]
