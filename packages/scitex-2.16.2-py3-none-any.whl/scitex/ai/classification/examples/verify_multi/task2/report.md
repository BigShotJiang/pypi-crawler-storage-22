# Classification Results Report

Generated: 2025-09-07 11:26:20

## Experiment Configuration

- **Name**: verify_multi_task2
- **Classifier**: Unknown
- **Dataset**: Unknown
- **N Folds**: Unknown
- **Random Seed**: Unknown

## Summary Statistics

| Metric | Mean ± Std | Min | Max |
|--------|------------|-----|-----|
| fold_id | 0.000 ± 0.000 | 0.000 | 0.000 |

## Per-Fold Results

 Fold
    0

## Figures

### Confusion Matrix
![confusion_matrix](.dev/verify_multi/task2/plots/fold_00/confusion_matrix.jpg)

## Validation Report

**Status**: ✗ Incomplete
