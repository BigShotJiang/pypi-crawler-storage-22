#!/usr/bin/env python3
# File: __init__.py
"""MCP server components."""

