#!/usr/bin/env python3
"""PostgreSQL database module."""

from ._PostgreSQL import PostgreSQL

__all__ = ["PostgreSQL"]
