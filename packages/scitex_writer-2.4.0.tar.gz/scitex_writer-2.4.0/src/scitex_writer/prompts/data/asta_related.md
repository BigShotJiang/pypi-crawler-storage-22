I'm working on a research paper and need to find related work.
Please help me find relevant papers.

**Title:** {title}

**Abstract:**
{abstract}

**Keywords:** {keywords}

Please find papers that:
1. Address similar research questions
2. Use related methodologies
3. Are from the last 5 years (with seminal older works)
4. Are highly cited in this field
