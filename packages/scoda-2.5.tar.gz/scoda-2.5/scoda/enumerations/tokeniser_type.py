from __future__ import annotations

import enum


class TokeniserType(enum.Enum):
    MULTI_TRACK_LARGE_VOCABULARY_NOTELIKE_TOKENISER = "multi_track_large_vocabulary_notelike_tokeniser"
