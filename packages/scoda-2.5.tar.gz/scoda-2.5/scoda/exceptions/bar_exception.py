class BarException(Exception):
    """Represents an exceptions regarding a bar."""
    pass
