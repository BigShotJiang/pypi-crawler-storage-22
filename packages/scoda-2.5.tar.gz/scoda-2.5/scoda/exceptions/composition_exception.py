class CompositionException(Exception):
    """Represents an exceptions regarding a composition."""
    pass