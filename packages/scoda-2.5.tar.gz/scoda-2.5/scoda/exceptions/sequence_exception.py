class SequenceException(Exception):
    """Represents an exceptions regarding a sequence."""
    pass
