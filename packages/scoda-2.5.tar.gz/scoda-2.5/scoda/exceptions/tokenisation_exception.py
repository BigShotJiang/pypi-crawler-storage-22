class TokenisationException(Exception):
    """Represents an exceptions with the tokenisation or detokenisation process."""
    pass