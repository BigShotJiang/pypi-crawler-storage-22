class TrackException(Exception):
    """Represents an exceptions regarding a track."""
    pass
