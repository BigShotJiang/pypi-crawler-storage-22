Please report any vulnerabilities by opening an issue in the GitHub repository.
