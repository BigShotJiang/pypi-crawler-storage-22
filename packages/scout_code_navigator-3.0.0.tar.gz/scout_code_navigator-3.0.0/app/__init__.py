"""
Scout Code Navigator - MCP server for fast, incremental code exploration.
"""

__version__ = "3.0.0"
