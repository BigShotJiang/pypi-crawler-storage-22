import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'https://www.minecraftskins.net/'

class RecipeScraper:
    def __init__(self) -> None:
        self.soup = None
        self.data_frame = None

    def scrape_url(self, url: str) -> None:
        response = requests.get(url)
        response.encoding = 'utf-8'
        self.soup = BeautifulSoup(response.text, 'html.parser')

    def get_cards(self) -> pd.DataFrame:
        cardsArr = []
        cards = self.soup.find_all('div', class_='card')
        for card in cards:
            cardsArr.append({
                'card': card
            })
        return cardsArr

    def get_titles(self) -> pd.DataFrame:
        titlesArr = []
        titles = self.soup.find_all('h2', class_='card-title')
        for title in titles:
            titlesArr.append({
                "title": title.text
            })
        return pd.DataFrame(titlesArr)
    
    # def get_links(self) -> pd.DataFrame:
    #     linksArr = []
    #     links = self.soup.find_all('a', class_='control')
    #     for link in links:
    #         linksArr.append(url+str(link.get('href')))
    #         # print(url+str(link.get_attribute_list('href')[0]))
    #     return linksArr
    
    def get_links(self) -> pd.DataFrame:
        linksArr = []
        
        links = self.soup.find_all('a', class_='control')
        for i, link in enumerate(links):
            linksArr.append({
                "url": url + link["href"]
            })

        return pd.DataFrame(linksArr)

    

    


# rs = RecipeScraper()
# rs.scrape_url(url)
# print(rs.get_links())