from __future__ import annotations

from .api import AudioCandidate, ScrapeResult, scrape

__all__ = ["__version__", "AudioCandidate", "ScrapeResult", "scrape"]
__version__ = "0.1.0"
