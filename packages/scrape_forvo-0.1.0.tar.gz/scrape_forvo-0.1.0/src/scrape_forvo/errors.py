from __future__ import annotations


class ForvoError(RuntimeError):
    """Base error for scrape_forvo."""


class ContentNotFoundError(ForvoError):
    """Expected content was not found in page HTML."""


class ForvoBlockedError(ForvoError):
    """Raised when Forvo blocks non-browser requests (e.g., 403)."""

