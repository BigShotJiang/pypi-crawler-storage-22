from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class PlayItem:
    play_id: str
    label: str
    mp3_paths: Tuple[str, ...]
