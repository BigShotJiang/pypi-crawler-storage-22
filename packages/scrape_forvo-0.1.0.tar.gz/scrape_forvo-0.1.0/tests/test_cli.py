from __future__ import annotations

import scrape_forvo.cli as cli
from scrape_forvo.api import ScrapeResult


def test_cli_dry_run(monkeypatch, capsys) -> None:
    monkeypatch.setattr(cli, "scrape", lambda *args, **kwargs: ScrapeResult(downloaded_count=1, candidates=tuple()))

    code = cli.main(["https://forvo.com/search/egg/no/", "--dry-run", "--no-head"])
    assert code == 0

    _ = capsys.readouterr()


def test_cli_no_mp3s(monkeypatch, capsys) -> None:
    monkeypatch.setattr(cli, "scrape", lambda *args, **kwargs: ScrapeResult(downloaded_count=0, candidates=tuple()))

    code = cli.main(["https://forvo.com/search/egg/no/", "--dry-run", "--no-head"])
    assert code == 2

    captured = capsys.readouterr()
    assert "No MP3s downloaded" in (captured.out + captured.err)
