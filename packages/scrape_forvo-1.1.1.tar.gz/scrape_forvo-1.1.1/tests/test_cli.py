from __future__ import annotations

import scrape_forvo.cli as cli
from scrape_forvo.api import ScrapeResult


def test_cli_dry_run(monkeypatch, capsys) -> None:
    monkeypatch.setattr(cli, "scrape", lambda *args, **kwargs: ScrapeResult(downloaded_count=1, candidates=tuple()))

    code = cli.main(["egg", "--dry-run", "--no-head"])
    assert code == 0

    _ = capsys.readouterr()


def test_cli_forwards_lang(monkeypatch, capsys) -> None:
    captured: dict[str, object] = {}

    def _scrape(*args, **kwargs):
        captured.update(kwargs)
        return ScrapeResult(downloaded_count=1, candidates=tuple())

    monkeypatch.setattr(cli, "scrape", _scrape)

    code = cli.main(["egg", "--dry-run", "--no-head", "--lang", "en"])
    assert code == 0
    assert captured["lang"] == "en"

    _ = capsys.readouterr()


def test_cli_no_mp3s(monkeypatch, capsys) -> None:
    monkeypatch.setattr(cli, "scrape", lambda *args, **kwargs: ScrapeResult(downloaded_count=0, candidates=tuple()))

    code = cli.main(["egg", "--dry-run", "--no-head"])
    assert code == 2

    captured = capsys.readouterr()
    assert "No MP3s downloaded" in (captured.out + captured.err)
