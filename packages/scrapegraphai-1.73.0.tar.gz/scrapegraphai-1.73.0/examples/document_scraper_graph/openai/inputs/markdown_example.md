 Toggle navigation

  * About
  * Projects(current)

Projects

Competitions

  * CV
  * ____

# Projects

 ![project thumbnail Rotary Pendulum RL
Open Source project aimed at controlling a real life rotary pendulum using RL
algorithms ](/projects/rotary-pendulum-rl/)

 ![project thumbnail DQN
Implementation from scratch Developed a Deep Q-Network algorithm to train a
simple and double pendulum ](https://github.com/PeriniM/DQN-SwingUp)

 ![project thumbnail Multi Agents HAED
University project which focuses on simulating a multi-agent system to perform
environment mapping. Agents, equipped with sensors, explore and record their
surroundings, considering uncertainties in their readings.
](https://github.com/PeriniM/Multi-Agents-HAED)

 ![project thumbnail Wireless ESC for Modular
Drones Modular drone architecture proposal and proof of concept. The project
received maximum grade. ](/projects/wireless-esc-drone/)

© Copyright 2023 . Powered by Jekyll with
al-folio theme. Hosted by [GitHub
Pages](https://pages.github.com/).
