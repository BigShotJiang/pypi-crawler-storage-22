"""Mock HTTP server for testing ScrapeGraphAI."""
