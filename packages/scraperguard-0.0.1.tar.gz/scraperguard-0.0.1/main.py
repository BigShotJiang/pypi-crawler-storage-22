def main():
    print("Hello from scraperguard!")


if __name__ == "__main__":
    main()
