from .scribble_from_segmentation import generate_scribbles_from_segmentations

__all__ = ["generate_scribbles_from_segmentations"]
