"""Pluggable backend system for LLM code generation."""

from scry_run.backends.base import GeneratorBackend
from scry_run.backends.registry import get_backend, register_backend

__all__ = ["GeneratorBackend", "get_backend", "register_backend"]
