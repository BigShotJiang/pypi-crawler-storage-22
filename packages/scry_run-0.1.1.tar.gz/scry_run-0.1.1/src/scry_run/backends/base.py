"""Abstract base class for generator backends."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class GeneratedCode:
    """Result of structured code generation."""

    code: str
    code_type: str  # method, property, classmethod, staticmethod
    docstring: str
    dependencies: list[str]
    packages: list[str] = None  # PyPI packages to install

    def __post_init__(self):
        if self.packages is None:
            self.packages = []


class GeneratorBackend(ABC):
    """Abstract base class for LLM generator backends.
    
    Backends handle the actual communication with the LLM service,
    whether via CLI subprocess, direct API, or other methods.
    """
    
    name: str = "base"
    
    @abstractmethod
    def generate_text(self, prompt: str) -> str:
        """Generate freeform text from a prompt.
        
        Args:
            prompt: The prompt to send to the LLM
            
        Returns:
            Generated text response
        """
        pass
    
    @abstractmethod
    def generate_code(self, prompt: str) -> GeneratedCode:
        """Generate structured code from a prompt.
        
        Args:
            prompt: The prompt including context and requirements
            
        Returns:
            GeneratedCode with code, type, docstring, and dependencies
        """
        pass
    
    @classmethod
    def is_available(cls) -> bool:
        """Check if this backend is available for use.
        
        Override to check for required credentials, CLI tools, etc.
        
        Returns:
            True if backend can be used
        """
        return True
