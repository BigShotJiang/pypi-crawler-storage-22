"""Env command for displaying configuration as environment variables."""

import click

from scry_run.config import load_config, get_env_vars


@click.command()
def env() -> None:
    """Display configuration as shell environment variables.

    Outputs export statements that can be eval'd in your shell:

        eval "$(scry-run env)"

    This allows running apps directly without scry-run run:

        eval "$(scry-run env)"
        ~/.scry-run/apps/todo-app/app.py add "Buy milk"
    """
    config = load_config()
    env_vars = get_env_vars(config)

    # Output as shell export statements
    for key, value in sorted(env_vars.items()):
        # Quote values to handle special characters
        click.echo(f'export {key}="{value}"')
