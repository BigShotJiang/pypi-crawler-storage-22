"""Console output utilities for consistent styling."""

from datetime import datetime

from rich.console import Console

# Stderr console for status messages
err_console = Console(stderr=True, highlight=False)


def _timestamp() -> str:
    """Return current time as HH:MM:SS."""
    return datetime.now().strftime("%H:%M:%S")


def status(msg: str) -> None:
    """Print a dim status message."""
    err_console.print(f"[dim]{_timestamp()} \\[scry-run][/dim] {msg}")


def info(msg: str) -> None:
    """Print an info message (cyan)."""
    err_console.print(f"[dim]{_timestamp()}[/dim] [cyan]\\[scry-run][/cyan] {msg}")


def success(msg: str) -> None:
    """Print a success message (green)."""
    err_console.print(f"[dim]{_timestamp()}[/dim] [green]\\[scry-run][/green] {msg}")


def warning(msg: str) -> None:
    """Print a warning message (yellow)."""
    err_console.print(f"[dim]{_timestamp()}[/dim] [yellow]\\[scry-run][/yellow] {msg}")


def error(msg: str) -> None:
    """Print an error message (red)."""
    err_console.print(f"[dim]{_timestamp()}[/dim] [red]\\[scry-run][/red] {msg}")


def generating(class_name: str, attr_name: str) -> None:
    """Print a 'generating' message."""
    err_console.print(f"[dim]{_timestamp()}[/dim] [cyan]\\[scry-run][/cyan] Generating {class_name}.{attr_name}...")


def generated(class_name: str, attr_name: str) -> None:
    """Print a 'generated' success message."""
    err_console.print(f"[dim]{_timestamp()}[/dim] [green]\\[scry-run][/green] Generated {class_name}.{attr_name} ✓")


def using_cached(class_name: str, attr_name: str) -> None:
    """Print a 'using cached' message."""
    err_console.print(f"[dim]{_timestamp()} \\[scry-run][/dim] Using cached {class_name}.{attr_name}")


def backend_selected(backend_name: str, model: str | None, reason: str) -> None:
    """Print backend selection message."""
    model_str = f" (model={model})" if model else ""
    err_console.print(f"[dim]{_timestamp()} \\[scry-run][/dim] Using backend: {backend_name}{model_str} ({reason})")
