"""Home directory management for scry-run.

All paths are resolved through this module. Override with SCRY_HOME env var.
"""

import os
from pathlib import Path


def get_home() -> Path:
    """Get scry-run home directory.

    Resolution order:
    1. SCRY_HOME env var (for tests/custom setups)
    2. ~/.scry-run/
    """
    if env_home := os.environ.get("SCRY_HOME"):
        return Path(env_home)
    return Path.home() / ".scry-run"


def get_config_path() -> Path:
    """Get path to global config file."""
    return get_home() / "config.toml"


def get_apps_dir() -> Path:
    """Get path to apps directory."""
    return get_home() / "apps"


def get_app_dir(app_name: str) -> Path:
    """Get path to a specific app's directory."""
    return get_apps_dir() / app_name


def get_app_cache(app_name: str) -> Path:
    """Get path to an app's cache file."""
    return get_app_dir(app_name) / "cache.json"


def get_app_logs(app_name: str) -> Path:
    """Get path to an app's logs directory."""
    return get_app_dir(app_name) / "logs"


def ensure_home_exists() -> Path:
    """Ensure home directory structure exists.

    Creates:
    - ~/.scry-run/
    - ~/.scry-run/apps/

    Returns:
        Path to home directory
    """
    home = get_home()
    home.mkdir(parents=True, exist_ok=True)
    (home / "apps").mkdir(exist_ok=True)
    return home
