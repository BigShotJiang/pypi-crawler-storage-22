# scry-run

**Describe an app, run it.** A CLI tool that generates and runs Python applications from natural language descriptions.

## Installation

```bash
uv tool install scry-run
```

Or run without installing:

```bash
uvx scry-run --help
```

Requires [Claude Code CLI](https://github.com/anthropics/claude-code) to be installed.

## Quick Start

```bash
# Create an app
scry-run init --name=todoist --description='minimal web todo app'

# Run it
scry-run run todoist
```

## Demos

### Greet app

[![Greet Demo](demos/out/greet.gif)](demos/out/greet.webm)

### Timer app

[![Timer Demo](demos/out/timer.gif)](demos/out/timer.webm)

### Maze app

[![Maze Demo](demos/out/maze.gif)](demos/out/maze.webm)

## CLI Commands

```bash
# Create a new app
scry-run init --name=NAME --description=DESC

# List all apps
scry-run list

# Run an app
scry-run run myapp [args...]

# Get app info
scry-run info myapp
scry-run which myapp

# Remove or reset an app
scry-run rm myapp
scry-run reset myapp

# Cache management
scry-run cache list myapp
scry-run cache show myapp MyClass.method
scry-run cache export myapp --output=code.py
scry-run cache prune myapp --all
```

## Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `SCRY_RUN_BACKEND` | Backend: `claude`, `frozen`, or `auto` | `auto` |
| `SCRY_RUN_MODEL` | Model override (e.g., `opus`) | (backend default) |

## License

MIT
