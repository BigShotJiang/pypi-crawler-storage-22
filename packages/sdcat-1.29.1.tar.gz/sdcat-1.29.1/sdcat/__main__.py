# sdcat, Apache-2.0 license
# Filename: __main__.py
# Description: Main entry point for the sdcat command line interface
import os

# Configure Ray (used by Modin) before any import that loads modin/ray
os.environ["RAY_ACCEL_ENV_VAR_OVERRIDE_ON_ZERO"] = "0"
os.environ["RAY_METRICS_EXPORT_ENABLED"] = "0"
os.environ["RAY_DEDUP_LOGS"] = "0"
os.environ["RAY_TQDM_PATCH_PRINT"]="0"

import ray

from datetime import datetime, timezone
from pathlib import Path

import click
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from sdcat.logger import err, info, create_logger_file
from sdcat import __version__
from sdcat.cluster.commands import run_cluster_det, run_cluster_roi
from sdcat.detect.commands import run_detect


create_logger_file("sdcat")
default_data_path = Path(__file__).parent / "testdata"
default_model = "MBARI/megabenthic"


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, "-V", "--version", message="%(prog)s, version %(version)s")
def cli():
    """
    Process images either to detect or cluster similar objects from a command line.
    """
    pass


cli.add_command(run_detect)


@cli.group(name="cluster")
def cli_cluster():
    """
    Commands related to clustering images
    """
    pass


cli.add_command(cli_cluster)
cli_cluster.add_command(run_cluster_det)
cli_cluster.add_command(run_cluster_roi)


if __name__ == "__main__":
    exit_code = 0
    try:
        ray.init(ignore_reinit_error=True)
        start = datetime.now(timezone.utc)
        cli()
        end = datetime.now(timezone.utc)
        info(f"Done. Elapsed time: {end - start} seconds")
    except Exception as e:
        err(f"Exiting. Error: {e}")
        exit_code = 1
    finally:
        try:
            ray.shutdown()
        except Exception as e:
            err(f"Error shutting down Ray: {e}")
    sys.exit(exit_code)
