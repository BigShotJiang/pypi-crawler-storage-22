# SDEV

串口开发板控制器工具包：后台异步读缓冲、按行/按 flag 读、回显着色、组合命令、存活检测。

## 安装

```bash
pip install sdev
```

## 快速使用

```python
from sdev import Demoboard

with Demoboard("/dev/ttyUSB0", 115200) as board:
    board.check_alive("~ #")           # 确认板子存活（未接则轮询等待）
    out = board.execute_command("ls")  # 发命令并收到提示符为止，返回输出列表
    print(out)
```

## 主要接口

| 方法 | 说明 |
|------|------|
| `connect()` / `disconnect()` | 打开/关闭串口并启停后台读线程 |
| `send(text)` | 发送一行（自动加换行）；`text` 不得含换行符 |
| `read(display=..., timeout=...)` | 消费缓冲直至断开或超时，返回行列表 |
| `read_until(flag, timeout=..., skip_echo_of=...)` | 读到含 `flag` 且非「命令回显」的行为止 |
| `execute_command(cmd, flag=" #", stream=False, ...)` | 先 `clear()` 再 `send(cmd)` 再 `read_until(flag, skip_echo_of=cmd)` |
| `check_alive(reboot_flag=..., prompt_flag=" #", ...)` | 有缓冲数据或能响应 Ctrl-C 即视为存活；超时则轮询等待 |
| `clear()` | 清空读缓冲（保留 disconnect 用 sentinel） |
| `send_interrupt(prompt_flag=..., timeout=...)` | 发 Ctrl-C 并等到含 `prompt_flag` 的提示行 |

- 使用 `stream_read` / `stream_read_until` 可逐行迭代；`read` / `read_until` 为列表版。
- `display=True` 时：本机发送回显为青色，匹配 flag 行为绿色，其余为灰色；板端折行会拼成一行再显示。

## 特性

- 后台线程读串口入队，主流程不阻塞
- 不假定提示符左边格式（如 `~ #` / ` #` 均可），通过 `skip_echo_of` 区分命令回显与提示行
- 超时在底层 `get(timeout=...)` 实现，可靠
- 依赖：Python >= 3.7，pyserial >= 3.5，loguru >= 0.6.0
