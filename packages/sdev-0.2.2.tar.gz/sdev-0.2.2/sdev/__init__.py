"""
SDEV - 串口控制器工具包

Demoboard：串口连接、后台异步读、发送、按行/按 flag 读、回显、组合命令、存活检测。
"""

from .demoboard import Demoboard

__version__ = "0.2.2"
__author__ = "klrc"
__email__ = "144069824@qq.com"

__all__ = ["Demoboard"]
