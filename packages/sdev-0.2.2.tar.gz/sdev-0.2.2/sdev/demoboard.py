"""
Demoboard: 串口连接、后台异步读、发送、按行/按 flag 读、回显、组合命令、存活检测。
不兼容旧 SerialController/Demoboard 实现。
"""

import queue
import sys
import threading
import time
from typing import Generator, List, Optional, Union

from loguru import logger
import serial

CTRL_C = "\x03"

# ANSI（发送回显用青色，比紫色柔和、与绿色区分明显）
_GREY = "\033[90m"
_SENT = "\033[36m"  # cyan 青色，护眼
_GREEN = "\033[32m"
_RESET = "\033[0m"


def _echo_grey(line: str) -> None:
    """普通设备输出：整行灰色打印。flush 保证与串口交错时顺序正确。"""
    print(f"{_GREY}{line}{_RESET}", end="", flush=True)


def _echo_sent(line: str) -> None:
    """本机发送内容的回显：整行青色（含 CTRL_C 显示为 ^C 的行）。"""
    print(f"{_SENT}{line}{_RESET}", end="", flush=True)


def _echo_green(line: str) -> None:
    """read_until 匹配到 flag 的那一行：整行绿色（如提示符行）。"""
    print(f"{_GREEN}{line}{_RESET}", end="", flush=True)


class Demoboard:
    """
    串口开发板控制器：连接、后台异步读缓冲、发送、按行/按 flag 读、回显、组合命令、存活检测。

    构造后需显式 connect()，或使用 with Demoboard(port) as board。
    """

    def __init__(self, port: str, baudrate: int = 115200) -> None:
        """
        只保存端口和波特率，不打开串口、不启动读线程。

        - 连接需显式调用 connect() 或使用 with。
        - 未 connect 前调用 send/read 会抛 RuntimeError。
        """
        self.port = port
        self.baudrate = baudrate
        self._serial: Optional[serial.Serial] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._stop_reading = False
        self._connected = False
        self._pending_sent: Optional[str] = None  # 仅作标记，在 read 中匹配到时用 _echo_sent 打印一次
        self._pending_flag: Optional[str] = None  # 仅作标记，在 read 中匹配到时整行绿色打印一次

    def _serial_reader(self) -> None:
        """
        后台线程：从串口按行读入并放入 _buffer。

        行为：
            - 循环 readline()，UTF-8 解码并 strip，非空则 put(line)。
            - 解码失败则跳过该行；OSError/SerialException 则退出循环。

        原理：及时消费串口，避免缓冲满丢数，且不阻塞主流程。
        注意：daemon 线程；disconnect 时通过 _stop_reading 与 put(None) 结束并唤醒阻塞的 get()。
        """
        while not self._stop_reading and self._serial is not None and self._serial.is_open:
            try:
                raw = self._serial.readline()
                if raw:
                    try:
                        line = raw.decode("utf-8")
                        if line:
                            self._buffer.put(line)
                    except UnicodeDecodeError:
                        continue
            except (OSError, serial.SerialException):
                break
            except Exception:
                continue

    def _has_output_in_buffer(self) -> bool:
        """
        队列里是否已有数据（qsize > 0 即视为有）。

        用于 check_alive：有任意输出就认为设备存活，不依赖提示符格式。
        注意：多线程下 qsize() 为近似值，用于布尔判断足够。
        """
        return self._buffer.qsize() > 0

    def _is_echo_of(self, line: str, sent: str) -> bool:
        """
        判断该行是否为「刚发送内容」的回显。

        行为：
            - line 等于 sent，或以 " " + sent 结尾 → 视为回显。
            - sent 为 CTRL_C 时，设备常显示 "^C"，也视为回显。

        用于 read_until(..., skip_echo_of=...)：区分命令回显行（如 "~ # ls"）和纯提示符行（如 "~ #"），
        不假定提示符左边格式。仅做字符串匹配，sent 为普通命令或 CTRL_C 即可。
        """
        s = line.rstrip()
        if s == sent or s.endswith(" " + sent):
            return True
        if sent == CTRL_C and (s.strip() == "^C" or "^C" in line or CTRL_C in line):
            return True
        return False

    @property
    def is_connected(self) -> bool:
        """是否已连接（串口已打开且读线程已启动）。"""
        return self._connected

    def connect(self) -> None:
        """
        打开串口并启动后台读线程，后续数据写入 _buffer。

        行为：创建 Serial(port, baudrate, timeout=0.1)，启动 _serial_reader，置 _connected=True。
        已连接则直接 return（幂等）。
        注意：串口打开失败只打 error 日志并 return，不抛异常；调用方用 is_connected 判断。
        """
        if self._connected:
            return
        self._serial = serial.Serial(self.port, self.baudrate, timeout=0.1)
        if not self._serial.is_open:
            logger.error(f"无法打开串口 {self.port}")
            return
        self._stop_reading = False
        self._reader_thread = threading.Thread(target=self._serial_reader, daemon=True)
        self._reader_thread.start()
        self._connected = True

    def disconnect(self) -> None:
        """
        停止读线程并关闭串口，幂等。

        行为：置 _stop_reading，put(None) 唤醒阻塞的 get()，join 读线程，关闭串口。
        None 为 sentinel，stream_read 收到后结束迭代。未连接则直接 return。
        注意：join 最多等 2s，超时后仍会关串口，不抛异常。
        """
        if not self._connected:
            return
        self._stop_reading = True
        self._buffer.put(None)  # unblock any read() waiting on get()
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self._reader_thread = None
        if self._serial is not None and self._serial.is_open:
            self._serial.close()
            self._serial = None
        self._connected = False

    def send(self, text: str) -> None:
        """
        向串口发送 text + 换行，不等待回显。

        行为：写入 (text + "\\n") 并 flush，同时设 _pending_sent = text。
        回显在 stream_read 里在匹配到 sent 前扣押多行、去换行拼接，匹配后整行青色打印。
        未连接抛 RuntimeError；text 不得含换行符（便于与板端折行回显拼接匹配）。
        """
        if not self._connected or self._serial is None:
            raise RuntimeError("not connected")
        assert "\n" not in text and "\r" not in text, "send(text) 不得包含换行符"
        self._serial.write((text + "\n").encode("utf-8"))
        self._serial.flush()
        self._pending_sent = text

    def _sent_echo_matches(self, acc: str, sent: str) -> bool:
        """拼接后的 acc 行尾是否匹配本次发送内容（用于板端折行回显）。"""
        if not acc:
            return False
        s = acc.rstrip()
        if s == sent or s.endswith(" " + sent):
            return True
        if sent == CTRL_C and (s.strip() == "^C" or "^C" in acc or CTRL_C in acc):
            return True
        return False

    def stream_read(self, display: bool = True, timeout: Optional[float] = None) -> Generator[str, None, None]:
        """
        从 _buffer 逐行 yield，直到 disconnect 或超时。

        行为：
            - 收到 None 则结束迭代。
            - display 且 _pending_sent 不为 None 时：持续 get 并扣押，去换行拼接为 acc，直到 acc 行尾匹配 sent，再整行青色打印并 yield 已扣押的每一行；保证 send 的输入完整显示为一行（板端折行也会被拼回）。
            - 其余行：按 flag/sent 匹配做绿/青/灰单行显示。
        """
        if not self._connected:
            raise RuntimeError("not connected")
        deadline = (time.monotonic() + timeout) if timeout is not None else None
        get_timeout = 0.1 if deadline is not None else None
        while True:
            if deadline is not None and time.monotonic() > deadline:
                raise TimeoutError("read deadline exceeded")
            if display and self._pending_sent is not None:
                acc = ""
                lines_buf: List[str] = []
                while True:
                    try:
                        line = self._buffer.get(timeout=get_timeout) if get_timeout else self._buffer.get()
                    except queue.Empty:
                        continue
                    if line is None:
                        if lines_buf:
                            _echo_grey(acc + "\n")
                            for L in lines_buf:
                                yield L
                        self._buffer.put(None)
                        return
                    lines_buf.append(line)
                    acc += line.rstrip("\r\n")
                    if self._sent_echo_matches(acc, self._pending_sent):
                        self._pending_sent = None
                        _echo_sent(acc + "\n")
                        for L in lines_buf:
                            yield L
                        break
                continue
            try:
                line = self._buffer.get(timeout=get_timeout) if get_timeout else self._buffer.get()
            except queue.Empty:
                continue
            if line is None:
                return
            if display:
                flag_ok = self._pending_flag is not None and self._pending_flag in line
                if flag_ok:
                    self._pending_flag = None
                    _echo_green(line)
                else:
                    _echo_grey(line)
            yield line

    def stream_read_until(
        self,
        flag: str,
        timeout: Optional[float] = None,
        display: bool = True,
        skip_echo_of: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """
        从 _buffer 逐行 yield，直到某行「包含 flag 且不是 skip_echo_of 的回显」则结束（该行会 yield）。

        行为：
            - 设 _pending_flag=flag，迭代 stream_read。
            - 若行含 flag：当 skip_echo_of 不为 None 且该行是「刚发送内容的回显」则继续读（跳过 "~ # ls" 这类）；否则 return。

        与旧 SerialController 一致，不假定提示符左边格式；flag 如 " #"、"~ #" 通用。
        skip_echo_of=None 时等价于「包含 flag 即停」。超时抛带 flag/timeout 信息的 TimeoutError。
        """
        self._pending_flag = flag
        try:
            for line in self.stream_read(display=display, timeout=timeout):
                yield line
                if flag not in line:
                    continue
                if skip_echo_of is not None and self._is_echo_of(line, skip_echo_of):
                    continue
                return
        except TimeoutError:
            raise TimeoutError(f"read_until timeout: flag={flag!r}, timeout={timeout}s") from None
        finally:
            self._pending_flag = None

    def read(self, display: bool = True, timeout: Optional[float] = None) -> List[str]:
        """把 stream_read 全部消费成列表返回。超时抛 TimeoutError。"""
        return list(self.stream_read(display, timeout))

    def read_until(
        self,
        flag: str,
        timeout: Optional[float] = None,
        display: bool = True,
        skip_echo_of: Optional[str] = None,
    ) -> List[str]:
        """把 stream_read_until 全部消费成列表返回（含结束行）。超时抛 TimeoutError。"""
        return list(self.stream_read_until(flag, timeout, display, skip_echo_of))

    def clear(self) -> None:
        """
        清空 _buffer 里已入队的行，不丢弃 sentinel（None）。

        行为：循环 get_nowait()，取到 None 则 put(None) 后 return，否则丢弃；队列空则 return。
        用于 execute_command 前清残留（与旧 SerialController 的 clear_queue 一致），避免上次提示符干扰本次匹配。
        注意：取到 None 必须放回，否则 stream_read 无法正常结束。
        """
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is None:
                    self._buffer.put(None)
                    return
            except queue.Empty:
                return

    def send_interrupt(self, prompt_flag: str = " #", timeout: float = 0.5) -> None:
        """
        发送 CTRL_C，并等待出现含 prompt_flag 的提示行（跳过 ^C 回显行）。

        内部：send(CTRL_C) 后 read_until(prompt_flag, timeout, display=True, skip_echo_of=CTRL_C)。
        超时抛 TimeoutError，由 check_alive 等调用方处理。
        """
        self.send(CTRL_C)
        self.read_until(prompt_flag, timeout=timeout, display=True, skip_echo_of=CTRL_C)

    def check_alive(
        self,
        reboot_flag: Optional[str] = None,
        prompt_flag: str = " #",
        timeout: float = 0.5,
    ) -> None:
        """
        确认开发板存活；能正常返回即表示 alive。
        内容：若 _has_output_in_buffer() 为真则视为已有输出（如已进 shell），可选 read_until(reboot_flag) 吃到启动信息后 return；否则 send_interrupt(prompt_flag, timeout)，成功则 return。若 send_interrupt 超时则打 warning，然后死循环：每隔 timeout 秒检查 _has_output_in_buffer()，有则可选 read_until(reboot_flag) 后 return。
        原理：不依赖「正在输出」，只依赖「队列里曾有过数据」或「能响应 Ctrl-C 并回到 prompt」；重启上电后无输出则等 prompt，未接串口则一直轮询直到有输出。
        边界：reboot_flag 用于上电后等待特定行（如 "~ #"）；未接串口时会永久循环并周期性 warning。
        """
        # wait for boot
        time.sleep(timeout)
        if self._has_output_in_buffer():
            if reboot_flag is not None:
                self.read_until(reboot_flag, display=True)
            return

        # 测试是否能够接收ctrlc信号，若无反应, wait for boot
        try:
            self.send_interrupt(prompt_flag, timeout)
        except TimeoutError:
            logger.warning(f"请接入串口")
            while True:
                time.sleep(timeout)
                if self._has_output_in_buffer():
                    if reboot_flag is not None:
                        self.read_until(reboot_flag, display=True)
                    return

    def execute_command(
        self,
        cmd: str,
        flag: str = " #",
        stream: bool = False,
        timeout: Optional[float] = None,
        display: bool = True,
    ) -> Union[List[str], Generator[str, None, None]]:
        """
        执行单条命令，并收集到「含 flag 的结束行」为止的输出。

        行为：先 clear()，再 send(cmd)，再 stream_read_until(flag, ..., skip_echo_of=cmd)。
        stream=False 返回整段输出的列表；stream=True 返回生成器。

        与旧 SerialController 一致：clear 避免残留；skip_echo_of=cmd 让命令回显行（如 "~ # ls"）不当作结束，
        只在真正的新提示符行结束，不假定提示符左边格式。超时抛 TimeoutError；cmd 为 CTRL_C 时也会跳过 "^C" 行。
        """
        self.clear()
        self.send(cmd)
        gen = self.stream_read_until(flag, timeout=timeout, display=display, skip_echo_of=cmd)
        if stream:
            return gen
        return list(gen)

    def __enter__(self) -> "Demoboard":
        """with 入口：connect() 并返回 self。"""
        self.connect()
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        """with 出口：disconnect()；异常不吞，继续向外抛。"""
        self.disconnect()
        print()  # 强制换行以刷新可能的日志末尾


if __name__ == "__main__":
    with Demoboard("/dev/ttyUSB0", 115200) as board:
        board.check_alive("~ #")
        board.execute_command("ls")
