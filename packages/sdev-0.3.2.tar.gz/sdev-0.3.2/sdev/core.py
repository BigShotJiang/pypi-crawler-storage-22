"""
串口设备：连接、后台按行读、发送、按 flag 扫描/回显、执行命令、存活检测。
"""

from itertools import chain
import queue
import threading
import time
from typing import Literal, Optional

from loguru import logger
import serial

CTRL_C = "\x03"


def _content_contains_ctrl_c(text: str) -> bool:
    """是否包含设备回显的 Ctrl+C（\\x03 或 ^C、^C\\x00 等）。"""
    n = text.replace("\x00", "")
    return CTRL_C in n or "^C" in n


def _line_matches_flag(line: str, flag: str) -> bool:
    """行（rstrip 后）是否以 flag 结尾；CTRL_C 兼容 \\x03 / \"^C\" 等回显形式。"""
    stripped = line.rstrip()
    if flag != CTRL_C:
        return stripped.endswith(flag)
    normalized = stripped.strip().replace("\x00", "")
    return normalized == CTRL_C or normalized == "^C" or normalized.endswith("^C") or stripped.endswith(flag)


_GREY = "\033[90m"
_SENT = "\033[36m"
_GREEN = "\033[32m"
_RESET = "\033[0m"


class SerialDevice:
    STABLE_FLAG = " #"

    def __init__(self, port: str, baudrate: int = 115200, check_alive=True):
        self.port = port
        self.baudrate = baudrate
        self._serial: Optional[serial.Serial] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._is_connected = False
        self._stop_reading = False
        self._display = True
        self._check_alive = check_alive

        self._reboot_timeout = 20  # check_alive 时 wait_for_flag 等稳定提示符的最大秒数
        self._check_alive_timeout = 0.5
        self._scan_timeout = 0.1

    def _serial_reader(self) -> None:
        """后台 daemon：readline → UTF-8 解码 → put(line)；解码失败则跳过该行。disconnect 时 _stop_reading + put(None) 唤醒阻塞 get()。"""
        while not self._stop_reading and self._serial is not None and self._serial.is_open:
            raw = self._serial.readline()
            if raw:
                try:
                    line = raw.decode("utf-8")
                    if line:
                        self._buffer.put(line)
                except UnicodeDecodeError:
                    continue

    def connect(self):
        """打开串口、启动 _serial_reader；已连接则直接 return。若 check_alive 则 connect 后自动 check_alive(STABLE_FLAG)。"""
        if self._is_connected:
            return
        self._serial = serial.Serial(self.port, self.baudrate, timeout=self._scan_timeout)
        if not self._serial.is_open:
            raise RuntimeError(f"无法打开串口 {self.port}")
        self._stop_reading = False
        self._reader_thread = threading.Thread(target=self._serial_reader, daemon=True)
        self._reader_thread.start()
        self._is_connected = True

        self._max_lines_per_prompt = 4

        if self._check_alive:
            self.check_alive(self.STABLE_FLAG)

    def disconnect(self):
        """置 _stop_reading、put(None) 唤醒 get()、join 读线程、关串口；幂等。"""
        if not self._is_connected:
            return
        self._stop_reading = True
        self._buffer.put(None)  # unblock any read() waiting on get()
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join()
        self._reader_thread = None
        if self._serial is not None and self._serial.is_open:
            self._serial.close()
            self._serial = None
        self._is_connected = False

    def send(self, prompt: str):
        """发送 prompt + 换行并 flush；prompt 不得含 \\n/\\r。"""
        if not self._is_connected or self._serial is None:
            raise RuntimeError("not connected")
        assert "\n" not in prompt and "\r" not in prompt, "send(prompt) 不得包含换行符"
        self._serial.write((prompt + "\n").encode("utf-8"))
        self._serial.flush()

    def _scan(self, timeout: Optional[float] = None):
        """从 _buffer 逐行 yield；有 timeout 时每轮用 scan_timeout 轮询，总时长超时抛 TimeoutError；收到 None 结束。"""
        if not self._is_connected:
            raise RuntimeError("not connected")
        deadline = (time.monotonic() + timeout) if timeout is not None else None
        scan_timeout = self._scan_timeout if deadline is not None else None

        while True:  # timeout loop
            if deadline is not None and time.monotonic() > deadline:
                raise TimeoutError("scan deadline exceeded")
            try:
                line = self._buffer.get(timeout=scan_timeout) if scan_timeout else self._buffer.get()
            except queue.Empty:
                continue
            if line is None:  # _serial_reader sentinel
                return
            yield line

    def _echo_prompt(self, line: str) -> None:
        print(f"{_SENT}{line}{_RESET}", end="", flush=True)

    def _echo_normal(self, line: str) -> None:
        print(f"{_GREY}{line}{_RESET}", end="", flush=True)

    def _echo_flag(self, line: str) -> None:
        print(f"{_GREEN}{line}{_RESET}", end="", flush=True)

    def scan(self, end_flag: str, timeout: Optional[float] = None, replace_with_acc=False):
        """
        从 _buffer 逐行 yield，直到出现 end_flag 或超时/None。
        逻辑：用 acc_cache 保留最近几行，拼成 acc_line（无换行），避免设备折行把 flag 拆到两行导致 in 判不到；
        命中时若 replace_with_acc 则 yield 整段 acc_line 加换行，否则逐行 yield cache 后 break。CTRL_C 按 _content_contains_ctrl_c 判。
        """
        acc_cache = []
        for line in self._scan(timeout):
            acc_cache.append(line)
            if len(acc_cache) > self._max_lines_per_prompt:
                yield acc_cache.pop(0)
            acc_line = "".join([x.rstrip("\r\n") for x in acc_cache])
            found = end_flag in acc_line or (end_flag == CTRL_C and _content_contains_ctrl_c(acc_line))
            if found:
                if replace_with_acc:
                    yield acc_line + "\n"
                else:
                    for x in acc_cache:
                        yield x
                break

    def scan_and_display(self, flag: str, flag_type: Literal["end_flag", "prompt"], timeout: Optional[float] = None, replace_with_acc=False):
        """对 scan(flag) 的每一行按 flag_type 回显（end_flag 绿、prompt 青、其余灰）并 yield 该行；超时重抛。"""
        try:
            for line in self.scan(flag, timeout=timeout, replace_with_acc=replace_with_acc):
                if self._display:
                    find_flag = _line_matches_flag(line, flag)
                    if find_flag:
                        if flag_type == "end_flag":
                            self._echo_flag(line)
                        elif flag_type == "prompt":
                            self._echo_prompt(line)
                    else:
                        self._echo_normal(line)
                yield line
        except TimeoutError:
            t = f"{timeout}s" if timeout is not None else "None"
            raise TimeoutError(f"scan_and_display timeout: flag={flag!r}, flag_type={flag_type!r}, timeout={t}")

    def clear(self):
        """清空 _buffer 中已入队行；取到 None 则 put(None) 后 return（保留 sentinel），用于 execute_command 前清残留。"""
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is None:
                    self._buffer.put(None)
                    return
            except queue.Empty:
                return

    def execute_command(
        self,
        cmd: str,
        flag: str = " #",
        stream: bool = False,
        timeout: Optional[float] = None,
    ):
        """
        执行单条命令并收集到「含 flag 的结束行」为止的输出。
        逻辑：clear → send(cmd) → 两段 chain：先 scan(cmd) 跳过命令回显行，再 scan(flag) 收到提示符行；
        cmd=CTRL_C 时第一段会按 ^C 回显形式识别。stream=False 返回 list，True 返回生成器；超时抛 TimeoutError。
        """
        self.clear()
        self.send(cmd)
        gen = chain(self.scan_and_display(cmd, "prompt", timeout=timeout, replace_with_acc=True), self.scan_and_display(flag, "end_flag", timeout=timeout))
        if stream:
            return gen
        return list(gen)

    def _has_output_in_buffer(self) -> bool:
        """qsize() > 0 即视为有数据（多线程下为近似值）。"""
        return self._buffer.qsize() > 0

    def send_interrupt(self, timeout: float, end_flag: str = " #") -> None:
        """发送 CTRL_C 后 execute_command(cmd=CTRL_C, flag=end_flag, timeout=timeout)；超时抛 TimeoutError。"""
        self.execute_command(cmd=CTRL_C, flag=end_flag, timeout=timeout)

    def wait_for_flag(self, flag: str, timeout: float):
        """消费 scan_and_display(flag, \"end_flag\", timeout)，直到出现 flag 或超时。"""
        gen = self.scan_and_display(flag, "end_flag", timeout=timeout)
        _ = list(gen)

    def check_alive(self, stable_flag: str):
        """
        确认板子存活：有输出则 wait_for_flag(stable_flag) 后 return；否则 send_interrupt，成功则 return。
        若 send_interrupt 超时则打 warning 并轮询 _has_output_in_buffer()，有数据再 wait_for_flag 后 return；未接串口会一直循环。
        """
        time.sleep(self._check_alive_timeout)
        if self._has_output_in_buffer():  # 可能正在启动，等待稳定标志
            self.wait_for_flag(stable_flag, self._reboot_timeout)
            return

        # 测试是否能够接收ctrlc信号，若无反应, wait for boot
        try:
            self.send_interrupt(self._check_alive_timeout, stable_flag)
        except TimeoutError:
            logger.warning(f"请接入串口")
            while True:
                time.sleep(self._check_alive_timeout)
                if self._has_output_in_buffer():
                    self.wait_for_flag(stable_flag, self._reboot_timeout)
                    return

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.disconnect()
        print()


if __name__ == "__main__":
    with SerialDevice("/dev/ttyUSB0", 115200) as board:
        board.execute_command("ls")
