"""
SDEV - 串口控制器工具包

Demoboard：串口连接、后台异步读、发送、按行/按 flag 读、回显、组合命令、存活检测。
"""

from .core import SerialDevice

__version__ = "0.3.3"
__author__ = "klrc"
__email__ = "1440698245@qq.com"

__all__ = ["SerialDevice"]
