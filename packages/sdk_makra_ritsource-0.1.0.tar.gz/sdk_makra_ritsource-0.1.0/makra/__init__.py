import sys
from .src.makra import Makra
from .src import providers
from .src import enums
from .src import types
from .src import errors

sys.modules[f"{__name__}.errors"] = sys.modules[f"{__name__}.src.errors"]
sys.modules[f"{__name__}.providers"] = sys.modules[f"{__name__}.src.providers"]
sys.modules[f"{__name__}.enums"] = sys.modules[f"{__name__}.src.enums"]
sys.modules[f"{__name__}.types"] = sys.modules[f"{__name__}.src.types"]

__version__ = "0.1.0"

__all__ = [
    "Makra",
    "providers",
    "enums",
    "types",
    "errors",
]
