from enum import Enum


class ACTION(Enum):
    NAVIGATION = "navigation"
    PAGINATION = "pagination"


class FORMAT_TYPE(Enum):
    MARKDOWN = "markdown"
    TEXT = "text"


__all__ = ["ACTION", "FORMAT_TYPE"]
