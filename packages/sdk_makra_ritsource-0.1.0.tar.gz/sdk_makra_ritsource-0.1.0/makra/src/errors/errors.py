from typing import Any, Dict, Optional

from pydantic import BaseModel


class ErrorDetail(BaseModel):
    error: str
    message: str
    context: Optional[Dict[str, Any]] = None


class GenericError(Exception):
    """Base exception class for Makra SDK"""

    def __init__(
        self,
        message: str,
        error_code: str,
        status_code: int,
        context: Dict[str, Any] = None,
    ):
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        self.context = context or {}
        super().__init__(self.message)


class RequestError(GenericError):
    """Raised when an HTTP request fails"""

    def __init__(
        self,
        message: str,
        error_code: str,
        status_code: int,
        context: Dict[str, Any] = None,
    ):
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=status_code,
            context=context,
        )
