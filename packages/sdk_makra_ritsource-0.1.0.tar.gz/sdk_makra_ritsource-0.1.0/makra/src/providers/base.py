from abc import ABC, abstractmethod
from typing import Optional


class BaseProvider(ABC):
    """Base class for LLM providers."""

    def __init__(self, api_key: str, model: Optional[str] = None):
        if not api_key:
            raise ValueError("API key is required")

        self._api_key = api_key
        self._model = model

    @property
    def api_key(self) -> str:
        return self._api_key

    @property
    def model(self) -> Optional[str]:
        return self._model

    @abstractmethod
    def get_provider_name(self) -> str:
        """Return the provider identifier string."""
        pass

    def to_dict(self) -> dict:
        """Convert provider to dictionary for API requests."""
        return {
            "provider": self.get_provider_name(),
            "api_key": self._api_key,
            "model": self._model,
        }
