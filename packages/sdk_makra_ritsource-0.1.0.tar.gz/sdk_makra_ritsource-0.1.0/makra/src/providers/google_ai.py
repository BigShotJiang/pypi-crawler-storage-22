from typing import Optional
from .base import BaseProvider


class GoogleAI(BaseProvider):
    def __init__(self, api_key: str, model: Optional[str] = None):
        super().__init__(api_key, model or "gemini-1.5-flash")

    def get_provider_name(self) -> str:
        return "google_ai"
