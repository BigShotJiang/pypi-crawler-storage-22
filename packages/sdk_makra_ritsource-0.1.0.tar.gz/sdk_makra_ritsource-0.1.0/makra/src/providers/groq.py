from typing import Optional
from .base import BaseProvider


class Groq(BaseProvider):
    def __init__(self, api_key: str, model: Optional[str] = None):
        super().__init__(api_key, model or "mixtral-8x7b-32768")

    def get_provider_name(self) -> str:
        return "groq"
