from typing import Dict, Any
from pydantic import BaseModel


class PreprocessOptions(BaseModel):
    @staticmethod
    def default() -> "PreprocessOptions":
        return PreprocessOptions()

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()


# class NamespaceOptions(BaseModel):
#     @staticmethod
#     def default() -> "NamespaceOptions":
#         return NamespaceOptions()

#     def to_dict(self) -> Dict[str, Any]:
#         return self.model_dump()


class CrawlOptions(BaseModel):
    @staticmethod
    def default() -> "CrawlOptions":
        return CrawlOptions()

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()


class FormatOptions(BaseModel):
    @staticmethod
    def default() -> "FormatOptions":
        return FormatOptions()

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()


class ExtractOptions(BaseModel):
    disable_cache: bool = False
    disable_pagination: bool = False
    disable_navigation: bool = False

    @staticmethod
    def default() -> "ExtractOptions":
        return ExtractOptions(
            disable_cache=False,
            disable_pagination=False,
            disable_navigation=False,
        )

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()


SchemaDefinition = Dict[str, Any]

__all__ = [
    "ExtractOptions",
    "PreprocessOptions",
    "CrawlOptions",
    "FormatOptions",
    "SchemaDefinition",
]
