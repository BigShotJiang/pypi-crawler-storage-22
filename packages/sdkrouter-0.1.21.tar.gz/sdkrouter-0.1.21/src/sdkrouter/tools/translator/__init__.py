"""JSON Translator tool for SDKRouter.

Provides translation of JSON objects and text using LLM with smart caching.
"""

# Re-export from submodules for convenience
from .translator import (
    TranslatorResource,
    AsyncTranslatorResource,
    TranslationError,
)

__all__ = [
    "TranslatorResource",
    "AsyncTranslatorResource",
    "TranslationError",
]
