"""Speech-to-Text (STT) providers.

Supports:
- OpenAI Whisper (REST API)
- Deepgram (WebSocket streaming via SDKRouter server)
"""

from .openai import (
    OpenAISTT,
    AsyncOpenAISTT,
)
from .deepgram import (
    DeepgramClient,
    DeepgramSession,
    DeepgramConfig,
    TranscriptSegment,
    TranscriptWord,
    DeepgramConnectionError,
    DeepgramStreamError,
    create_deepgram_client,
)

__all__ = [
    # OpenAI Whisper
    "OpenAISTT",
    "AsyncOpenAISTT",
    # Deepgram
    "DeepgramClient",
    "DeepgramSession",
    "DeepgramConfig",
    "TranscriptSegment",
    "TranscriptWord",
    "DeepgramConnectionError",
    "DeepgramStreamError",
    "create_deepgram_client",
]
