import os

print(os.path.abspath('../../../files/master_specs.xlsx'))

print(os.path.exists('../../../files/master_specs.xlsx'))