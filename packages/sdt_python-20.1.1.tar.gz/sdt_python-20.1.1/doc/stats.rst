.. SPDX-FileCopyrightText: 2023 Lukas Schrangl <lukas.schrangl@boku.ac.at>

   SPDX-License-Identifier: CC-BY-4.0

.. automodule:: sdt.stats
