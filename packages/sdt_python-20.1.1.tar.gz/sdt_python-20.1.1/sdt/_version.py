# SPDX-FileCopyrightText: 2020 Lukas Schrangl <lukas.schrangl@tuwien.ac.at>
#
# SPDX-License-Identifier: BSD-3-Clause

# setup.py needs to be able to read the version string using the reg ex
# r"^__version__ = ['\"]([^'\"]*)['\"]"
__version__ = "20.1.1"
