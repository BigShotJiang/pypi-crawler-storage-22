def main():
    """Main function."""
    print("Hello from Seal!")
    return "Hello from Seal!"

if __name__ == "__main__":
    main()
