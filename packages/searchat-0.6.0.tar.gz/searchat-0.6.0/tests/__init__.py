"""Test suite for searchat."""
