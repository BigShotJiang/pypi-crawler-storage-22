"""Integration tests for searchat."""
