"""Unit tests for searchat."""
