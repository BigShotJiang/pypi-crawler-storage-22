"""
Public API functions for SeaSenseLib.

This module provides simple programmatic access to SeaSenseLib functionality
without requiring knowledge of the internal CLI structure.
"""

from typing import List, Dict, Optional, TYPE_CHECKING
from .core import DataIOManager

if TYPE_CHECKING:
    import xarray as xr


def read(filename: str, file_format: Optional[str] = None, 
         header_file: Optional[str] = None, **kwargs) -> 'xr.Dataset':
    """
    Read a sensor data file and return it as an xarray Dataset.
    
    This function provides programmatic access to SeaSenseLib's data reading
    capabilities, equivalent to using the CLI 'convert' command but returning
    the data as an xarray Dataset for further processing.
    
    Parameters
    ----------
    filename : str
        Path to the input file to read
    file_format : str, optional
        Format key to override automatic format detection.
        Use ssl.formats() to see available formats.
        Common formats: 'sbe-cnv', 'rbr-rsk', 'netcdf', 'csv'
        If None, format will be auto-detected from file extension.
    header_file : str, optional
        Path to header file (required for Nortek ASCII files)
    **kwargs
        Additional reader-specific parameters. Examples:
        - sanitize_input : bool (for SBE CNV files, default=True)
        - fix_missing_coords : bool (for SBE CNV files, default=True)
        - encoding : str (for Sea&Sun TOB files, default='latin-1')
        - time_dim : str (for ADCP readers, default='time')
        - mapping : dict (variable name mapping for all readers)
        
    Returns
    -------
    xarray.Dataset
        The sensor data as an xarray Dataset
        
    Raises
    ------
    FileNotFoundError
        If the input file does not exist
    ValueError
        If the file format is not supported or cannot be detected
    RuntimeError
        If there are issues reading or parsing the file
        
    Examples
    --------
    Read a CNV file with automatic format detection:
    
    ```python
    import seasenselib as ssl
    ds = ssl.read('ctd_profile.cnv')
    print(ds)
    ```
    
    Read a Seabird CNV file with explicit format:

    ```python
    ds = ssl.read('ctd_profile.cnv', file_format='sbe-cnv')
    print(ds)
    ```
    
    Read a Nortek ASCII file with header:

    ```python
    ds = ssl.read('adcp_profile.txt', file_format='nortek-ascii', 
                    header_file='adcp_header.hdr')
    ```
    
    Access the underlying pandas DataFrame:

    ```python
    df = ds.to_dataframe()
    print(df.head())
    ```
    """

    # Initialize the I/O manager
    io_manager = DataIOManager()

    try:
        # Use the existing I/O infrastructure to read the data
        data = io_manager.read_data(filename, file_format, header_file, **kwargs)
        return data

    except (FileNotFoundError, ValueError, RuntimeError):
        # Re-raise specific exceptions as-is
        raise
    except ImportError as e:
        # Handle missing dependencies
        raise RuntimeError(f"Missing required dependencies for reading {filename}: {e}") from e
    except OSError as e:
        # Handle file system issues
        raise FileNotFoundError(f"Cannot access file {filename}: {e}") from e
    except (KeyError, AttributeError, TypeError) as e:
        # Handle data format or parsing issues
        if "does not exist" in str(e):
            raise FileNotFoundError(f"Input file not found: {filename}") from e
        elif "Unknown format" in str(e) or "format detection" in str(e).lower():
            raise ValueError(f"Unsupported or undetectable file format: {filename}") from e
        else:
            raise RuntimeError(f"Error reading file {filename}: {e}") from e


def write(dataset: 'xr.Dataset', filename: str, 
          file_format: Optional[str] = None, **kwargs) -> None:
    """
    Write a xarray Dataset to a file in the specified format.
    
    This function provides programmatic access to SeaSenseLib's data writing
    capabilities, supporting various output formats for oceanographic data.
    
    Parameters
    ----------
    dataset : xarray.Dataset
        The dataset to write to file
    filename : str
        Path to the output file
    file_format : str, optional
        Output format. If None, format will be detected from file extension.
        Supported formats: 'netcdf', 'csv', 'excel'
    **kwargs
        Additional arguments passed to the specific writer
        
    Raises
    ------
    ValueError
        If the file format is not supported or cannot be detected
    RuntimeError
        If there are issues writing the file
        
    Examples
    --------
    Write to NetCDF (recommended for xarray datasets):
    
    ```python
    import seasenselib as ssl
    ds = ssl.read('data.cnv')
    ssl.write(ds, 'output.nc')
    ```
    
    Write to CSV with explicit format:

    ```python
    ssl.write(ds, 'output.csv', file_format='csv')
    ```
    """

    # Initialize the I/O manager
    io_manager = DataIOManager()

    try:
        # Use the existing I/O infrastructure to write the data
        io_manager.write_data(dataset, filename, file_format, **kwargs)

    except (ValueError, RuntimeError):
        # Re-raise specific exceptions as-is
        raise
    except ImportError as e:
        # Handle missing dependencies
        raise RuntimeError(f"Missing required dependencies for writing {filename}: {e}") from e
    except OSError as e:
        # Handle file system issues
        raise RuntimeError(f"Cannot write to file {filename}: {e}") from e
    except Exception as e:
        # Handle unexpected errors
        raise RuntimeError(f"Error writing file {filename}: {e}") from e


def formats() -> List[Dict[str, str]]:
    """
    List all supported input file formats.

    This function returns a list of all file formats that SeaSenseLib can
    read, along with their keys and typical file extensions. This is useful
    to determine which formats are available for reading data.
    
    Returns
    -------
    List[Dict[str, str]]
        List of dictionaries containing format information with keys:
        'name', 'key', 'class_name', 'extension', 'is_plugin'
        Note: 'extension' is always present (None if not applicable)
        
    Examples
    --------
    ```python
    import seasenselib as ssl
    formats = ssl.formats()
    for fmt in formats:
        ext = fmt['extension'] or 'N/A'
        print(f"{fmt['name']}: '{fmt['key']}' ({ext})")
    ```
    """
    return list_readers()


def list_readers() -> List[Dict[str, str]]:
    """
    List all available reader formats (including plugins).

    Returns a list of all file formats that SeaSenseLib can read,
    including both built-in readers and those provided by plugins.
    
    Returns
    -------
    List[Dict[str, str]]
        List of dictionaries containing reader information with keys:
        'name', 'key', 'class_name', 'extension', 'is_plugin'
        Note: 'extension' is always present (None if not applicable)
        
    Examples
    --------
    ```python
    import seasenselib as ssl
    readers = ssl.list_readers()
    for reader in readers:
        plugin_marker = ' [P]' if reader['is_plugin'] else ''
        print(f"{reader['name']}{plugin_marker}: {reader['key']}")
    ```
    """
    from .core.autodiscovery import ReaderDiscovery

    discovery = ReaderDiscovery()
    return discovery.get_format_info()


def list_writers() -> List[Dict[str, str]]:
    """
    List all available writer formats (including plugins).

    Returns a list of all file formats that SeaSenseLib can write to,
    including both built-in writers and those provided by plugins.
    
    Returns
    -------
    List[Dict[str, str]]
        List of dictionaries containing writer information with keys:
        'name', 'key', 'class_name', 'extension', 'is_plugin'
        Note: 'extension' is always present (None if not applicable)
        
    Examples
    --------
    ```python
    import seasenselib as ssl
    writers = ssl.list_writers()
    for writer in writers:
        plugin_marker = ' [P]' if writer['is_plugin'] else ''
        print(f"{writer['name']}{plugin_marker}: {writer['key']}")
    ```
    """
    from .core.autodiscovery import WriterDiscovery

    discovery = WriterDiscovery()
    return discovery.get_format_info()


def list_plotters() -> List[Dict[str, str]]:
    """
    List all available plotter types (including plugins).

    Returns a list of all plotter types available in SeaSenseLib,
    including both built-in plotters and those provided by plugins.
    
    Returns
    -------
    List[Dict[str, str]]
        List of dictionaries containing plotter information with keys:
        'name', 'key', 'class_name', 'is_plugin'
        Note: Plotters don't have 'extension' (only readers/writers do)
        
    Examples
    --------
    ```python
    import seasenselib as ssl
    plotters = ssl.list_plotters()
    for plotter in plotters:
        plugin_marker = ' [P]' if plotter['is_plugin'] else ''
        print(f"{plotter['name']}{plugin_marker}: {plotter['key']}")
    ```
    """
    from .core.autodiscovery import PlotterDiscovery

    discovery = PlotterDiscovery()
    return discovery.get_format_info()


def list_all() -> Dict[str, List[Dict[str, str]]]:
    """
    List all available resources: readers, writers, and plotters.

    Returns a comprehensive dictionary containing all available formats
    and plotters, organized by type. Includes both built-in resources
    and those provided by plugins.
    
    Returns
    -------
    Dict[str, List[Dict[str, str]]]
        Dictionary with keys 'readers', 'writers', 'plotters', each
        containing a list of resource information dictionaries
        
    Examples
    --------
    ```python
    import seasenselib as ssl
    all_resources = ssl.list_all()
    
    print(f"Readers: {len(all_resources['readers'])}")
    print(f"Writers: {len(all_resources['writers'])}")
    print(f"Plotters: {len(all_resources['plotters'])}")
    
    # Count plugins
    total_plugins = sum(
        sum(1 for item in items if item.get('is_plugin', False))
        for items in all_resources.values()
    )
    print(f"Total plugins: {total_plugins}")
    ```
    """
    return {
        'readers': list_readers(),
        'writers': list_writers(),
        'plotters': list_plotters()
    }


def plot(plotter_key: str, dataset: 'xr.Dataset', **kwargs) -> None:
    """
    Create a plot using any registered plotter (built-in or plugin).
    
    This function provides a unified interface to all plotters in the system,
    mirroring the CLI's `seasenselib plot <plotter-key>` command. It automatically
    discovers and uses the appropriate plotter based on the provided key.
    
    Parameters
    ----------
    plotter_key : str
        The key identifying which plotter to use. Use `seasenselib.list_plotters()`
        to see all available plotters.
        
        Built-in plotter keys:
        - 'ts-diagram' : Temperature-Salinity diagram with density isolines
        - 'vertical-profile' : Vertical profile plot
        - 'time-series' : Time series plot (single or multiple parameters)
        
    dataset : xarray.Dataset
        The dataset containing the data to plot
        
    **kwargs
        Additional keyword arguments passed to the plotter's plot() method.
        Each plotter accepts different arguments - use the plotter's documentation
        or `seasenselib plot <plotter-key> -h` in the CLI to see available options.
        
        Common arguments:
        - output_file : str, optional - Path to save the plot. If None, displays interactively.
        - title : str, optional - Custom plot title
        
    Returns
    -------
    None
        The plot is either displayed or saved to a file based on output_file parameter.
        
    Raises
    ------
    ValueError
        If the plotter_key is not recognized or if required arguments are missing.
    KeyError
        If the dataset is missing required variables for the chosen plotter.
        
    Examples
    --------
    Create a T-S diagram:
    
    >>> import seasenselib as ssl
    >>> ds = ssl.read('ctd_profile.cnv')
    >>> ssl.plot('ts-diagram', ds, dot_size=50, colormap='viridis')
    
    Create a time series plot:
    
    >>> ssl.plot('time-series', ds, parameter_names=['temperature'], 
    ...          ylim_min=10, ylim_max=20)
    
    Create a multi-parameter time series with dual axes:
    
    >>> ssl.plot('time-series', ds, 
    ...          parameter_names=['temperature', 'salinity'],
    ...          dual_axis=True, colors=['red', 'blue'])
    
    Create a vertical profile and save to file:
    
    >>> ssl.plot('vertical-profile', ds, output_file='profile.png',
    ...          dot_size=5, show_grid=False)
    
    Use a plugin plotter:
    
    >>> ssl.plot('histogram', ds, parameter_names=['temperature'], bins=50)
    
    List all available plotters:
    
    >>> ssl.list_plotters()
    
    See also
    --------
    list_plotters : List all available plotters with descriptions
    read : Read data from various sensor file formats
    write : Write datasets to various formats
    
    Notes
    -----
    The function uses lazy loading - plotter modules are only imported when needed.
    This keeps import times fast while still providing access to all functionality.
    
    The plotter discovery system automatically finds both built-in plotters and
    any plotters installed as plugins, making the API extensible without code changes.
    """
    # Lazy import to avoid heavy imports at package load time
    from .core.autodiscovery import PlotterDiscovery
    
    # Discover available plotters
    discovery = PlotterDiscovery()
    plotter_class = discovery.get_class_by_key(plotter_key)

    if not plotter_class:
        # Get list of available plotters for error message
        available = discovery.get_format_info()
        keys = [p['key'] for p in available]
        raise ValueError(
            f"Unknown plotter key '{plotter_key}'. "
            f"Available plotters: {', '.join(keys)}. "
            f"Use seasenselib.list_plotters() to see details about each plotter."
        )

    # Instantiate the plotter with the dataset
    plotter = plotter_class(dataset)

    # Call the plotter's plot method with provided kwargs
    try:
        plotter.plot(**kwargs)
    except TypeError as e:
        # Provide helpful error message if wrong arguments provided
        raise TypeError(
            f"Error calling plotter '{plotter_key}': {str(e)}. "
            f"Use 'seasenselib plot {plotter_key} -h' in the CLI to see available arguments."
        ) from e
