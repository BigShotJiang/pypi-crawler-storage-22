"""
Command-line argument parsing with lazy loading capabilities.
"""

import argparse
from typing import List, Optional


class _HideFormatsHelpFormatter(argparse.RawTextHelpFormatter):
    """Custom formatter that hides legacy commands from help output."""
    
    # Commands to hide from help
    HIDDEN_COMMANDS = {'formats'}
    
    def _format_action(self, action):
        """Override to filter out hidden commands from subcommand choices."""
        # Get the original formatted action
        result = super()._format_action(action)
        
        # If this is the subparsers action, clean up hidden commands
        if hasattr(action, 'choices') and action.choices:
            # Check if any hidden commands are present
            has_hidden = any(cmd in action.choices for cmd in self.HIDDEN_COMMANDS)
            
            if has_hidden:
                # Remove hidden commands from the metavar/choices display in usage line
                for cmd in self.HIDDEN_COMMANDS:
                    result = result.replace(f',{cmd}}}', '}')
                    result = result.replace(f'{{{cmd},', '{')
                    result = result.replace(f',{cmd},', ',')
                
                # Remove any line that contains ==SUPPRESS== (hidden command help lines)
                lines = result.split('\n')
                filtered_lines = []
                for line in lines:
                    if '==SUPPRESS==' in line:
                        continue
                    filtered_lines.append(line)
                result = '\n'.join(filtered_lines)
        
        return result
    
    def _format_usage(self, usage, actions, groups, prefix):
        """Override to remove hidden commands from usage line."""
        result = super()._format_usage(usage, actions, groups, prefix)
        # Remove hidden commands from the usage line
        for cmd in self.HIDDEN_COMMANDS:
            result = result.replace(f',{cmd}}}', '}')
            result = result.replace(f'{{{cmd},', '{')
            result = result.replace(f',{cmd},', ',')
        return result


class ArgumentParser:
    """
    Enhanced argument parser with lazy loading support.

    This class provides methods to quickly parse command names and create
    a full argument parser with all subcommands. It allows for lazy loading
    of dependencies, ensuring that only the necessary components are loaded
    when needed.

    Attributes:
    ----------
    base_parser : argparse.ArgumentParser
        The base argument parser used for quick command detection and full parsing.
    Methods:
    -------
    parse_command_quickly(args: List[str]) -> Optional[str]:
        Quickly parse the command name from the provided arguments.
    create_full_parser() -> argparse.ArgumentParser:
        Create the full argument parser with all subcommands and options.
    """

    def __init__(self):
        self.base_parser = None
        # Lazy load format lists when needed
        self._input_formats = None
        self._output_formats = None

    @property
    def INPUT_FORMATS(self):
        """Lazy load input formats."""
        if self._input_formats is None:
            from ..core.autodiscovery import get_input_formats
            self._input_formats = get_input_formats()
        return self._input_formats

    @property
    def OUTPUT_FORMATS(self):
        """Lazy load output formats."""
        if self._output_formats is None:
            from ..core.autodiscovery import get_output_formats
            self._output_formats = get_output_formats()
        return self._output_formats

    def parse_command_quickly(self, args: List[str]) -> Optional[str]:
        """
        Quick parse to extract just the command name without full parsing.
        
        This allows us to determine what dependencies to load before doing
        the full argument parsing.
        """
        if not args:
            return None

        # Create a minimal parser just for command detection
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument('command', nargs='?', help='Command to execute')

        try:
            parsed_args, _ = parser.parse_known_args(args)
            return parsed_args.command
        except SystemExit:
            # Handle --help or invalid args
            return None

    def create_plot_parser_for_plotter(self, plotter_key: str) -> argparse.ArgumentParser:
        """Create a specialized parser for a specific plotter.
        
        Parameters:
        -----------
        plotter_key : str
            The key of the plotter (e.g., 'time-series', 'ts-diagram', etc.)
            
        Returns:
        --------
        argparse.ArgumentParser
            A parser with only the arguments relevant to the specified plotter
        """
        parser = argparse.ArgumentParser(
            prog=f'seasenselib plot {plotter_key}',
            description=f'Create plots using the {plotter_key} plotter',
            formatter_class=_HideFormatsHelpFormatter
        )
        
        # Common arguments for all plotters
        parser.add_argument('-i', '--input', type=str, required=True,
                    help='Path of input file')
        parser.add_argument('-f', '--input-format', type=str,
                    default=None, choices=self.INPUT_FORMATS,
                    help='Format of input file')
        parser.add_argument('-H', '--header-input', type=str, default=None,
                    help='Path of header input file (for Nortek ASCII files)')
        parser.add_argument('-o', '--output', type=str,
                    help='Path of output file if plot shall be written')
        parser.add_argument('-t', '--title', type=str,
                    help='Title of the plot')
        
        # Reader configuration flags (for SeaBird CNV and similar formats)
        parser.add_argument('--no-sanitize', action='store_true', default=False,
                    help='Disable automatic file format fixes (stricter parsing)')
        parser.add_argument('--no-fix-coords', action='store_true', default=False,
                    help='Disable automatic coordinate defaults (require explicit lat/lon)')
        
        # Try to let the plotter class declare its own CLI args (plugins supported)
        try:
            # Lazy import discovery to avoid heavy imports when not needed
            from ..core.autodiscovery import PlotterDiscovery
            discovery = PlotterDiscovery()
            plotter_class = discovery.get_class_by_key(plotter_key)
            if plotter_class and hasattr(plotter_class, 'add_cli_arguments'):
                # Allow the plotter to add its arguments to the parser
                try:
                    plotter_class.add_cli_arguments(parser)
                except Exception:
                    # If the plotter's hook misbehaves, fall back to generic args
                    parser.add_argument('-p', '--parameter', type=str, nargs='*',
                                        help='Parameter(s) to plot (plotter-specific)')
            else:
                # Unknown or plugin without hook: provide a generic parameter option
                parser.add_argument('-p', '--parameter', type=str, nargs='*',
                                    help='Parameter(s) to plot (plotter-specific)')
        except Exception:
            # If discovery fails for any reason, provide the generic argument
            parser.add_argument('-p', '--parameter', type=str, nargs='*',
                                help='Parameter(s) to plot (plotter-specific)')
        
        return parser

    def create_full_parser(self) -> argparse.ArgumentParser:
        """Create the full argument parser with all subcommands."""
        parser = argparse.ArgumentParser(
            description='SeaSenseLib - Oceanographic sensor data processing',
            formatter_class=_HideFormatsHelpFormatter
        )

        subparsers = parser.add_subparsers(dest='command', help='Available commands')

        # Add all subcommands
        self._add_convert_parser(subparsers)
        self._add_show_parser(subparsers)
        self._add_list_parser(subparsers)
        self._add_plot_parser(subparsers)
        self._add_subset_parser(subparsers)
        self._add_calc_parser(subparsers)
        
        # Add hidden aliases for backward compatibility
        self._add_formats_alias(subparsers)

        return parser

    def _add_reader_config_args(self, parser):
        """Add reader configuration arguments (for CNV and other formats).
        
        Parameters
        ----------
        parser : argparse.ArgumentParser
            Parser to add arguments to
        """
        parser.add_argument('--no-sanitize', action='store_true', default=False,
                    help='Disable automatic file format fixes (stricter parsing)')
        parser.add_argument('--no-fix-coords', action='store_true', default=False,
                    help='Disable automatic coordinate defaults (require explicit lat/lon)')

    def _add_convert_parser(self, subparsers):
        """Add convert command parser."""
        # We'll import parameters only when needed
        try:
            # pylint: disable=C0415
            import seasenselib.parameters as params
            mapping_help = ('Map CNV column names to standard parameter names in the '
                           'format name=value. Allowed parameter names are: ' +
                           ', \n'.join(f"{k}" for k, v in params.allowed_parameters().items()))
        except ImportError:
            mapping_help = 'Map CNV column names to standard parameter names'

        format_help = 'Choose the output format. Allowed formats are: ' + ', '.join(self.OUTPUT_FORMATS)

        convert_parser = subparsers.add_parser('convert',
                    help='Convert a file to a specific format.')
        convert_parser.add_argument('-i', '--input', type=str, required=True,
                    help='Path of input file')
        convert_parser.add_argument('-f', '--input-format',
                    type=str, default=None, choices=self.INPUT_FORMATS,
                    help='Format of input file')
        convert_parser.add_argument('-H', '--header-input', type=str, default=None,
                    help='Path of header input file (for Nortek ASCII files)')
        convert_parser.add_argument('-o', '--output', type=str, required=True,
                    help='Path of output file')
        convert_parser.add_argument('-F', '--output-format', type=str, choices=self.OUTPUT_FORMATS, 
                    help=format_help)
        convert_parser.add_argument('-m', '--mapping', nargs='+',
                    help=mapping_help)
        self._add_reader_config_args(convert_parser)

    def _add_show_parser(self, subparsers):
        """Add show command parser."""
        show_parser = subparsers.add_parser('show',
                    help='Show contents of a file.')
        show_parser.add_argument('-i', '--input', type=str, required=True,
                    help='Path of input file')
        show_parser.add_argument('-f', '--input-format', type=str,
                    default=None, choices=self.INPUT_FORMATS,
                    help='Format of input file')
        show_parser.add_argument('-H', '--header-input', type=str, default=None,
                    help='Path of header input file (for Nortek ASCII files)')
        show_parser.add_argument('-s', '--schema', type=str,
                    choices=['summary', 'info', 'example'], default='summary',
                    help='What to show.')
        self._add_reader_config_args(show_parser)

    def _add_list_parser(self, subparsers):
        """Add list command parser."""
        list_parser = subparsers.add_parser('list',
                    help='List available readers, writers, and plotters.')
        list_parser.add_argument('resource_type', type=str, nargs='?', default='all',
                    choices=['all', 'readers', 'writers', 'plotters'],
                    help='Type of resources to list (default: all)')
        list_parser.add_argument('--output', '-o', type=str,
                    choices=['table', 'json', 'yaml', 'csv'], default='table',
                    help='Output format (default: table)')
        list_parser.add_argument('--filter', '-f', type=str,
                    help='Filter by name or extension (case-insensitive)')
        list_parser.add_argument('--sort', '-s', type=str,
                    choices=['name', 'key', 'extension', 'type'], default='name',
                    help='Sort by field (default: name)')
        list_parser.add_argument('--reverse', '-r', action='store_true',
                    help='Reverse sort order')
        list_parser.add_argument('--no-header', action='store_true',
                    help='Omit header row (useful for scripts)')
        list_parser.add_argument('--verbose', '-v', action='store_true',
                    help='Show additional information like class names')

    def _add_plot_parser(self, subparsers):
        """Add unified plot command parser (simplified for main help)."""
        plot_parser = subparsers.add_parser('plot',
                    help='Create plots using available plotters.')
        plot_parser.add_argument('plotter', type=str, nargs='?',
                    help='Plotter key (use --list-plotters to see available plotters)')
        plot_parser.add_argument('--list-plotters', action='store_true',
                    help='List available plotters and exit')
        # Add a dummy -i argument to prevent "required" error when just checking help
        plot_parser.add_argument('-i', '--input', type=str,
                    help='Path of input file (use "plot <plotter-key> -h" for plotter-specific help)')

    def _add_formats_alias(self, subparsers):
        """Add formats command as a hidden alias for 'list readers' (backward compatibility)."""
        # Create a hidden parser that acts like 'list readers'
        formats_parser = subparsers.add_parser('formats',
                    help=argparse.SUPPRESS)  # Hidden from help
        formats_parser.add_argument('--output', '-o', type=str,
                    choices=['table', 'json', 'yaml', 'csv'], default='table',
                    help='Output format (default: table)')
        formats_parser.add_argument('--filter', '-f', type=str,
                    help='Filter formats by name or extension (case-insensitive)')
        formats_parser.add_argument('--sort', '-s', type=str,
                    choices=['name', 'key', 'extension'], default='name',
                    help='Sort by field (default: name)')
        formats_parser.add_argument('--reverse', '-r', action='store_true',
                    help='Reverse sort order')
        formats_parser.add_argument('--no-header', action='store_true',
                    help='Omit header row (useful for scripts)')
        formats_parser.add_argument('--verbose', '-v', action='store_true',
                    help='Show additional information like class names')

    def _add_subset_parser(self, subparsers):
        """Add subset command parser."""
        format_help = 'Choose the output format. Allowed formats are: ' + ', '.join(self.OUTPUT_FORMATS)

        subset_parser = subparsers.add_parser('subset', 
                    help='Extract a subset of a file.')
        subset_parser.add_argument('-i', '--input', type=str, required=True, 
                    help='Path of input file')
        subset_parser.add_argument('-f', '--input-format', type=str, 
                    default=None, choices=self.INPUT_FORMATS,
                    help='Format of input file')
        subset_parser.add_argument('-H', '--header-input', type=str, default=None,
                    help='Path of header input file (for Nortek ASCII files)')
        subset_parser.add_argument('-o', '--output', type=str,
                    help='Path of output file')
        subset_parser.add_argument('-F', '--output-format', type=str, choices=self.OUTPUT_FORMATS, 
                    help=format_help)
        subset_parser.add_argument('--time-min', type=str, 
                    help='Minimum datetime value. Formats are: YYYY-MM-DD HH:ii:mm.ss')
        subset_parser.add_argument('--time-max', type=str, 
                    help='Maximum datetime value. Formats are: YYYY-MM-DD HH:ii:mm.ss')
        subset_parser.add_argument('--sample-min', type=int, 
                    help='Minimum sample/index value (integer)')
        subset_parser.add_argument('--sample-max', type=int, 
                    help='Maximum sample/index value (integer)')
        subset_parser.add_argument('--parameter', type=str, 
                    help='Standard name of a parameter, e.g. "temperature" or "salinity".')
        subset_parser.add_argument('--value-min', type=float, 
                    help='Minimum value for the specified parameter')
        subset_parser.add_argument('--value-max', type=float, 
                    help='Maximum value for the specified parameter')
        self._add_reader_config_args(subset_parser)

    def _add_calc_parser(self, subparsers):
        """Add calc command parser."""
        format_help = 'Choose the output format. Allowed formats are: ' + ', '.join(self.OUTPUT_FORMATS)
        method_choices = [
            'min', 'max', 'mean', 'arithmetic_mean', 'median', 'std',
            'standard_deviation', 'var', 'variance', 'sum'
        ]

        calc_parser = subparsers.add_parser('calc',
                    help='Run an aggregate function on parameters of a dataset.')
        calc_parser.add_argument('-i', '--input', type=str, required=True, 
                    help='Path of input file')
        calc_parser.add_argument('-f', '--input-format', type=str, default=None,
                    choices=self.INPUT_FORMATS, help='Format of input file')
        calc_parser.add_argument('-H', '--header-input', type=str, default=None,
                    help='Path of header input file (for Nortek ASCII files)')
        calc_parser.add_argument('-o', '--output', type=str, 
                    help='Path of output file')
        calc_parser.add_argument('-F', '--output-format', type=str, choices=self.OUTPUT_FORMATS,
                    help=format_help)
        calc_parser.add_argument('-M', '--method', type=str, choices=method_choices,
                    help='Mathematical method operated on the values.')
        calc_parser.add_argument('-p', '--parameter', type=str, required=True,
                    help='Standard name of a parameter, e.g. "temperature" or "salinity".')
        calc_parser.add_argument('-r', '--resample', default=False, action='store_true',
                    help='Resample the time series.')
        calc_parser.add_argument('-T', '--time-interval', type=str,
                    help='Time interval for resampling. Examples: 1M (one month)')
        self._add_reader_config_args(calc_parser)
