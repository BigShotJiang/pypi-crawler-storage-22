"""Tests for readers module."""
