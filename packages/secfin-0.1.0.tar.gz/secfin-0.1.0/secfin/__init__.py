"""
secfin - Fetch company financial records from SEC EDGAR
"""

__version__ = "0.1.0"

from .client import SECClient
from .company import Company
from .financials import IncomeStatement, BalanceSheet, CashFlow
from .batch import BatchFetcher
from .indices import IndexProvider, SP500_TICKERS, NASDAQ100_TICKERS
from .earnings import EarningsCalendar, EarningsDate

__all__ = [
    "SECClient",
    "Company",
    "IncomeStatement",
    "BalanceSheet",
    "CashFlow",
    "BatchFetcher",
    "IndexProvider",
    "SP500_TICKERS",
    "NASDAQ100_TICKERS",
    "EarningsCalendar",
    "EarningsDate",
]
