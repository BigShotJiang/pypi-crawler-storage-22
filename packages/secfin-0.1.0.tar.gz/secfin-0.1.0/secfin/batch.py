"""
Batch processing for fetching financials for multiple companies.
"""

import time
from typing import List, Dict, Any, Optional, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
import pandas as pd

from .client import SECClient
from .company import Company
from .indices import IndexProvider, SP500_TICKERS, NASDAQ100_TICKERS


class BatchFetcher:
    """
    Fetch financial data for multiple companies efficiently.

    Handles rate limiting, error recovery, and progress tracking.

    Parameters
    ----------
    client : SECClient
        SEC API client instance
    max_workers : int, default=1
        Number of concurrent workers (keep low to respect SEC rate limits)
    on_progress : callable, optional
        Callback function(current, total, ticker, status) for progress updates
    on_error : callable, optional
        Callback function(ticker, error) for error handling

    Examples
    --------
    >>> client = SECClient("MyApp contact@email.com")
    >>> fetcher = BatchFetcher(client)
    >>> results = fetcher.fetch_sp500()
    """

    def __init__(
        self,
        client: SECClient,
        max_workers: int = 1,
        on_progress: Optional[Callable] = None,
        on_error: Optional[Callable] = None,
    ):
        self.client = client
        self.max_workers = max_workers
        self.on_progress = on_progress or self._default_progress
        self.on_error = on_error or self._default_error
        self._index_provider = IndexProvider()

    def _default_progress(self, current: int, total: int, ticker: str, status: str):
        """Default progress callback - prints to console."""
        pct = (current / total) * 100
        print(f"[{current}/{total}] ({pct:.1f}%) {ticker}: {status}")

    def _default_error(self, ticker: str, error: Exception):
        """Default error callback - prints to console."""
        print(f"ERROR {ticker}: {error}")

    def _fetch_single(self, ticker: str, period: str = "annual") -> Dict[str, Any]:
        """Fetch financials for a single company."""
        try:
            company = Company(ticker, self.client)
            return {
                "ticker": ticker,
                "name": company.name,
                "cik": company.cik,
                "income_statement": company.get_income_statement(period),
                "balance_sheet": company.get_balance_sheet(period),
                "cash_flow": company.get_cash_flow(period),
                "status": "success",
                "error": None,
            }
        except Exception as e:
            return {
                "ticker": ticker,
                "name": None,
                "cik": None,
                "income_statement": None,
                "balance_sheet": None,
                "cash_flow": None,
                "status": "error",
                "error": str(e),
            }

    def fetch_tickers(
        self,
        tickers: List[str],
        period: str = "annual",
    ) -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for a list of tickers.

        Parameters
        ----------
        tickers : list[str]
            List of ticker symbols
        period : str
            "annual" or "quarterly"

        Returns
        -------
        dict
            Dictionary mapping ticker to financial data
        """
        results = {}
        total = len(tickers)

        for i, ticker in enumerate(tickers, 1):
            result = self._fetch_single(ticker, period)
            results[ticker] = result

            status = "OK" if result["status"] == "success" else f"FAILED: {result['error']}"
            self.on_progress(i, total, ticker, status)

            if result["status"] == "error":
                self.on_error(ticker, Exception(result["error"]))

            # Small delay between requests
            time.sleep(0.15)

        return results

    def fetch_sp500(self, period: str = "annual") -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for all S&P 500 companies.

        Parameters
        ----------
        period : str
            "annual" or "quarterly"

        Returns
        -------
        dict
            Dictionary mapping ticker to financial data
        """
        tickers = self._index_provider.get_sp500()
        if not tickers:
            tickers = SP500_TICKERS
        return self.fetch_tickers(tickers, period)

    def fetch_nasdaq100(self, period: str = "annual") -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for all NASDAQ 100 companies.

        Parameters
        ----------
        period : str
            "annual" or "quarterly"

        Returns
        -------
        dict
            Dictionary mapping ticker to financial data
        """
        tickers = self._index_provider.get_nasdaq100()
        if not tickers:
            tickers = NASDAQ100_TICKERS
        return self.fetch_tickers(tickers, period)

    def fetch_russell2000(
        self,
        tickers: Optional[List[str]] = None,
        period: str = "annual",
    ) -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for Russell 2000 companies.

        Note: Russell 2000 constituent list must be provided as it's
        not freely available.

        Parameters
        ----------
        tickers : list[str], optional
            List of Russell 2000 tickers. If not provided, attempts
            to fetch from index provider.
        period : str
            "annual" or "quarterly"

        Returns
        -------
        dict
            Dictionary mapping ticker to financial data
        """
        if tickers is None:
            tickers = self._index_provider.get_russell2000()
        if not tickers:
            raise ValueError(
                "Russell 2000 tickers not available. "
                "Please provide a list of tickers."
            )
        return self.fetch_tickers(tickers, period)

    def to_dataframe(
        self,
        results: Dict[str, Dict[str, Any]],
        statement: str = "income_statement",
        metric: str = "revenue",
    ) -> pd.DataFrame:
        """
        Convert batch results to a DataFrame.

        Parameters
        ----------
        results : dict
            Results from fetch_* methods
        statement : str
            "income_statement", "balance_sheet", or "cash_flow"
        metric : str
            Metric name (e.g., "revenue", "net_income", "total_assets")

        Returns
        -------
        pd.DataFrame
            DataFrame with tickers as rows and dates as columns
        """
        data = {}

        for ticker, result in results.items():
            if result["status"] != "success":
                continue

            stmt = result.get(statement)
            if stmt is None:
                continue

            metric_obj = getattr(stmt, metric, None)
            if metric_obj is None or not metric_obj.values:
                continue

            # Convert to series
            series = metric_obj.to_series()
            data[ticker] = series

        if not data:
            return pd.DataFrame()

        df = pd.DataFrame(data).T
        df.index.name = "ticker"
        return df

    def summary_dataframe(
        self,
        results: Dict[str, Dict[str, Any]],
    ) -> pd.DataFrame:
        """
        Create a summary DataFrame with latest values for key metrics.

        Parameters
        ----------
        results : dict
            Results from fetch_* methods

        Returns
        -------
        pd.DataFrame
            Summary with key metrics for each company
        """
        rows = []

        for ticker, result in results.items():
            if result["status"] != "success":
                continue

            row = {"ticker": ticker, "name": result.get("name", "")}

            # Income statement metrics
            income = result.get("income_statement")
            if income:
                if income.revenue.latest():
                    row["revenue"] = income.revenue.latest().get("val")
                if income.net_income.latest():
                    row["net_income"] = income.net_income.latest().get("val")
                if income.eps_diluted.latest():
                    row["eps"] = income.eps_diluted.latest().get("val")

            # Balance sheet metrics
            balance = result.get("balance_sheet")
            if balance:
                if balance.total_assets.latest():
                    row["total_assets"] = balance.total_assets.latest().get("val")
                if balance.cash.latest():
                    row["cash"] = balance.cash.latest().get("val")
                if balance.long_term_debt.latest():
                    row["debt"] = balance.long_term_debt.latest().get("val")

            # Cash flow metrics
            cashflow = result.get("cash_flow")
            if cashflow:
                if cashflow.operating_cash_flow.latest():
                    row["operating_cf"] = cashflow.operating_cash_flow.latest().get("val")
                if cashflow.free_cash_flow.latest():
                    row["free_cf"] = cashflow.free_cash_flow.latest().get("val")

            rows.append(row)

        return pd.DataFrame(rows)
