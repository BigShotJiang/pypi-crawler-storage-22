"""
SEC EDGAR API client for fetching company financial data.
"""

import time
import json
from typing import Optional
import requests


class SECClient:
    """
    HTTP client for SEC EDGAR API.

    SEC requires a User-Agent header identifying the application and contact info.
    Rate limiting is applied to respect SEC's 10 requests/second limit.

    Parameters
    ----------
    user_agent : str
        Required User-Agent string in format "AppName contact@email.com"
    rate_limit : float, default=0.1
        Minimum seconds between requests (default respects 10 req/s limit)
    """

    BASE_URL = "https://data.sec.gov"
    COMPANY_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"

    def __init__(self, user_agent: str, rate_limit: float = 0.1):
        if not user_agent or "@" not in user_agent:
            raise ValueError(
                "SEC requires a User-Agent with contact info. "
                "Example: 'MyApp contact@email.com'"
            )
        self.user_agent = user_agent
        self.rate_limit = rate_limit
        self._last_request_time = 0.0
        self._session = requests.Session()
        self._session.headers.update({
            "User-Agent": user_agent,
            "Accept": "application/json",
        })
        self._ticker_to_cik: Optional[dict] = None

    def _rate_limit_wait(self):
        """Wait if necessary to respect rate limit."""
        elapsed = time.time() - self._last_request_time
        if elapsed < self.rate_limit:
            time.sleep(self.rate_limit - elapsed)
        self._last_request_time = time.time()

    def _get(self, url: str) -> dict:
        """Make a GET request with rate limiting."""
        self._rate_limit_wait()
        response = self._session.get(url)
        response.raise_for_status()
        return response.json()

    def _load_ticker_mapping(self):
        """Load the ticker to CIK mapping from SEC."""
        if self._ticker_to_cik is None:
            data = self._get(self.COMPANY_TICKERS_URL)
            self._ticker_to_cik = {}
            for entry in data.values():
                ticker = entry.get("ticker", "").upper()
                cik = str(entry.get("cik_str", ""))
                if ticker and cik:
                    self._ticker_to_cik[ticker] = cik.zfill(10)

    def get_cik(self, ticker: str) -> str:
        """
        Get CIK number from ticker symbol.

        Parameters
        ----------
        ticker : str
            Stock ticker symbol (e.g., "AAPL", "MSFT")

        Returns
        -------
        str
            10-digit CIK number (zero-padded)

        Raises
        ------
        ValueError
            If ticker is not found
        """
        self._load_ticker_mapping()
        ticker_upper = ticker.upper()
        if ticker_upper not in self._ticker_to_cik:
            raise ValueError(f"Ticker '{ticker}' not found in SEC database")
        return self._ticker_to_cik[ticker_upper]

    def get_company_facts(self, cik: str) -> dict:
        """
        Fetch all XBRL facts for a company.

        This returns the complete set of financial data reported by the company
        to the SEC, including all historical values.

        Parameters
        ----------
        cik : str
            Company CIK number (will be zero-padded to 10 digits)

        Returns
        -------
        dict
            Company facts data including all XBRL concepts and values
        """
        cik_padded = cik.zfill(10)
        url = f"{self.BASE_URL}/api/xbrl/companyfacts/CIK{cik_padded}.json"
        return self._get(url)

    def get_company_info(self, cik: str) -> dict:
        """
        Get basic company information.

        Parameters
        ----------
        cik : str
            Company CIK number

        Returns
        -------
        dict
            Company name, CIK, and other metadata
        """
        facts = self.get_company_facts(cik)
        return {
            "cik": facts.get("cik"),
            "name": facts.get("entityName"),
        }

    def search_companies(self, query: str) -> list:
        """
        Search for companies by name or ticker.

        Parameters
        ----------
        query : str
            Search query (company name or ticker)

        Returns
        -------
        list[dict]
            List of matching companies with ticker, name, and CIK
        """
        self._load_ticker_mapping()
        query_upper = query.upper()
        results = []

        # First check for exact ticker match
        if query_upper in self._ticker_to_cik:
            cik = self._ticker_to_cik[query_upper]
            try:
                info = self.get_company_info(cik)
                results.append({
                    "ticker": query_upper,
                    "cik": cik,
                    "name": info.get("name", ""),
                })
            except Exception:
                pass

        return results
