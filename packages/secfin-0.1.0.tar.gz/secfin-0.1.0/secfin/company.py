"""
Company class for accessing financial data.
"""

from typing import Dict, Any, Optional
from .client import SECClient
from .financials import IncomeStatement, BalanceSheet, CashFlow
from .parser import parse_income_statement, parse_balance_sheet, parse_cash_flow
from .earnings import EarningsCalendar, parse_earnings_from_facts


class Company:
    """
    Represents a public company with access to financial statements.

    Parameters
    ----------
    ticker : str
        Stock ticker symbol (e.g., "AAPL", "MSFT")
    client : SECClient
        SEC API client instance

    Attributes
    ----------
    ticker : str
        Stock ticker symbol
    cik : str
        SEC CIK number
    name : str
        Company name

    Examples
    --------
    >>> client = SECClient("MyApp contact@email.com")
    >>> company = Company("AAPL", client)
    >>> income = company.get_income_statement()
    >>> print(income.revenue.latest())
    """

    def __init__(self, ticker: str, client: SECClient):
        self.ticker = ticker.upper()
        self._client = client
        self._cik: Optional[str] = None
        self._name: Optional[str] = None
        self._facts: Optional[dict] = None

    @property
    def cik(self) -> str:
        """Get the company's CIK number."""
        if self._cik is None:
            self._cik = self._client.get_cik(self.ticker)
        return self._cik

    @property
    def name(self) -> str:
        """Get the company name."""
        if self._name is None:
            self._load_facts()
            self._name = self._facts.get("entityName", "")
        return self._name

    def _load_facts(self):
        """Load company facts from SEC API."""
        if self._facts is None:
            self._facts = self._client.get_company_facts(self.cik)

    def get_income_statement(self, period: str = "annual") -> IncomeStatement:
        """
        Get income statement data.

        Parameters
        ----------
        period : str, default="annual"
            "annual" for 10-K filings, "quarterly" for 10-Q filings

        Returns
        -------
        IncomeStatement
            Income statement with revenue, profit, EPS, etc.
        """
        self._load_facts()
        return parse_income_statement(self._facts, period)

    def get_balance_sheet(self, period: str = "annual") -> BalanceSheet:
        """
        Get balance sheet data.

        Parameters
        ----------
        period : str, default="annual"
            "annual" for 10-K filings, "quarterly" for 10-Q filings

        Returns
        -------
        BalanceSheet
            Balance sheet with assets, liabilities, equity, etc.
        """
        self._load_facts()
        return parse_balance_sheet(self._facts, period)

    def get_cash_flow(self, period: str = "annual") -> CashFlow:
        """
        Get cash flow statement data.

        Parameters
        ----------
        period : str, default="annual"
            "annual" for 10-K filings, "quarterly" for 10-Q filings

        Returns
        -------
        CashFlow
            Cash flow with operating, investing, financing activities
        """
        self._load_facts()
        return parse_cash_flow(self._facts, period)

    def get_all_financials(self, period: str = "annual") -> Dict[str, Any]:
        """
        Get all financial statements.

        Parameters
        ----------
        period : str, default="annual"
            "annual" for 10-K filings, "quarterly" for 10-Q filings

        Returns
        -------
        dict
            Dictionary with income_statement, balance_sheet, cash_flow keys
        """
        return {
            "income_statement": self.get_income_statement(period),
            "balance_sheet": self.get_balance_sheet(period),
            "cash_flow": self.get_cash_flow(period),
        }

    def summary(self, period: str = "annual") -> Dict[str, Any]:
        """
        Get a summary of key financial metrics.

        Parameters
        ----------
        period : str, default="annual"
            "annual" for 10-K filings, "quarterly" for 10-Q filings

        Returns
        -------
        dict
            Summary with key metrics from all statements
        """
        income = self.get_income_statement(period)
        balance = self.get_balance_sheet(period)
        cashflow = self.get_cash_flow(period)

        return {
            "company": {
                "ticker": self.ticker,
                "name": self.name,
                "cik": self.cik,
            },
            "income_statement": income.summary(),
            "balance_sheet": balance.summary(),
            "cash_flow": cashflow.summary(),
        }

    def get_earnings_calendar(self) -> EarningsCalendar:
        """
        Get earnings calendar with historical and estimated future dates.

        Returns
        -------
        EarningsCalendar
            Calendar with historical filings and next estimated date
        """
        self._load_facts()
        return parse_earnings_from_facts(self._facts, self.ticker)

    def next_earnings(self) -> Optional[Dict[str, Any]]:
        """
        Get the estimated next earnings date.

        Returns
        -------
        dict or None
            Dictionary with estimated date, period_end, and form_type
        """
        calendar = self.get_earnings_calendar()
        if calendar.next_estimated:
            return {
                "date": calendar.next_estimated.date,
                "period_end": calendar.next_estimated.period_end,
                "form_type": calendar.next_estimated.form_type,
                "fiscal_quarter": calendar.next_estimated.fiscal_quarter,
            }
        return None

    def last_earnings(self) -> Optional[Dict[str, Any]]:
        """
        Get the most recent earnings date.

        Returns
        -------
        dict or None
            Dictionary with filing date, period_end, and form_type
        """
        calendar = self.get_earnings_calendar()
        last = calendar.last_earnings()
        if last:
            return {
                "date": last.date,
                "period_end": last.period_end,
                "form_type": last.form_type,
                "fiscal_quarter": last.fiscal_quarter,
            }
        return None

    def earnings_history(self, limit: int = 20) -> list:
        """
        Get historical earnings dates.

        Parameters
        ----------
        limit : int, default=20
            Maximum number of historical dates to return

        Returns
        -------
        list[dict]
            List of historical earnings dates
        """
        calendar = self.get_earnings_calendar()
        return [
            {
                "date": e.date,
                "period_end": e.period_end,
                "form_type": e.form_type,
                "fiscal_quarter": e.fiscal_quarter,
                "fiscal_year": e.fiscal_year,
            }
            for e in calendar.historical[:limit]
        ]

    def __repr__(self) -> str:
        return f"Company(ticker='{self.ticker}', cik='{self.cik}')"
