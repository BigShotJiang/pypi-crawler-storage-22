"""
Earnings dates and calendar functionality.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import pandas as pd


@dataclass
class EarningsDate:
    """A single earnings date record."""
    date: str  # Filing date (YYYY-MM-DD)
    period_end: str  # Fiscal period end date
    form_type: str  # 10-K or 10-Q
    fiscal_year: Optional[int] = None
    fiscal_quarter: Optional[str] = None  # Q1, Q2, Q3, Q4, FY


@dataclass
class EarningsCalendar:
    """
    Earnings calendar with historical and estimated future dates.
    """
    ticker: str
    company_name: str
    historical: List[EarningsDate] = field(default_factory=list)
    next_estimated: Optional[EarningsDate] = None
    fiscal_year_end: Optional[str] = None  # Month (e.g., "December", "September")

    def get_historical_df(self) -> pd.DataFrame:
        """Get historical earnings dates as DataFrame."""
        if not self.historical:
            return pd.DataFrame()

        data = [
            {
                "filing_date": e.date,
                "period_end": e.period_end,
                "form_type": e.form_type,
                "fiscal_year": e.fiscal_year,
                "fiscal_quarter": e.fiscal_quarter,
            }
            for e in self.historical
        ]
        df = pd.DataFrame(data)
        df["filing_date"] = pd.to_datetime(df["filing_date"])
        df["period_end"] = pd.to_datetime(df["period_end"])
        return df.sort_values("filing_date", ascending=False)

    def last_earnings(self) -> Optional[EarningsDate]:
        """Get the most recent earnings date."""
        if not self.historical:
            return None
        # Sort by filing date descending
        sorted_hist = sorted(self.historical, key=lambda x: x.date, reverse=True)
        return sorted_hist[0] if sorted_hist else None

    def summary(self) -> Dict[str, Any]:
        """Get a summary of earnings info."""
        last = self.last_earnings()
        return {
            "ticker": self.ticker,
            "company_name": self.company_name,
            "last_earnings_date": last.date if last else None,
            "last_period_end": last.period_end if last else None,
            "last_form_type": last.form_type if last else None,
            "next_estimated": self.next_estimated.date if self.next_estimated else None,
            "fiscal_year_end": self.fiscal_year_end,
            "total_filings": len(self.historical),
        }


def parse_earnings_from_facts(facts: dict, ticker: str) -> EarningsCalendar:
    """
    Extract earnings dates from SEC company facts.

    Parameters
    ----------
    facts : dict
        Company facts from SEC API
    ticker : str
        Company ticker symbol

    Returns
    -------
    EarningsCalendar
        Calendar with historical earnings dates
    """
    company_name = facts.get("entityName", "")

    # Extract filing dates from the facts
    # We look at key metrics that are filed each quarter
    historical_dates: Dict[str, EarningsDate] = {}

    # Check us-gaap facts for filing information
    us_gaap = facts.get("facts", {}).get("us-gaap", {})

    # Key concepts that appear in every earnings filing
    key_concepts = [
        "NetIncomeLoss",
        "Revenues",
        "RevenueFromContractWithCustomerExcludingAssessedTax",
        "Assets",
    ]

    for concept in key_concepts:
        concept_data = us_gaap.get(concept, {})
        units = concept_data.get("units", {})

        for unit_type, values in units.items():
            for val in values:
                form_type = val.get("form", "")
                if form_type not in ("10-K", "10-Q"):
                    continue

                filed_date = val.get("filed", "")
                period_end = val.get("end", "")
                fiscal_year = val.get("fy")
                fp = val.get("fp", "")  # FY, Q1, Q2, Q3, Q4

                if not filed_date or not period_end:
                    continue

                # Use period_end as key to deduplicate
                key = f"{period_end}_{form_type}"
                if key not in historical_dates:
                    historical_dates[key] = EarningsDate(
                        date=filed_date,
                        period_end=period_end,
                        form_type=form_type,
                        fiscal_year=fiscal_year,
                        fiscal_quarter=fp if fp else ("FY" if form_type == "10-K" else None),
                    )

    # Convert to list and sort by date
    historical = list(historical_dates.values())
    historical.sort(key=lambda x: x.date, reverse=True)

    # Estimate fiscal year end month
    fiscal_year_end = None
    annual_filings = [h for h in historical if h.form_type == "10-K"]
    if annual_filings:
        try:
            last_annual = annual_filings[0]
            end_date = datetime.strptime(last_annual.period_end, "%Y-%m-%d")
            fiscal_year_end = end_date.strftime("%B")  # Month name
        except (ValueError, TypeError):
            pass

    # Estimate next earnings date based on historical pattern
    next_estimated = estimate_next_earnings(historical)

    return EarningsCalendar(
        ticker=ticker,
        company_name=company_name,
        historical=historical,
        next_estimated=next_estimated,
        fiscal_year_end=fiscal_year_end,
    )


def estimate_next_earnings(historical: List[EarningsDate]) -> Optional[EarningsDate]:
    """
    Estimate the next earnings date based on historical patterns.

    Companies typically report ~30-45 days after quarter end,
    following a consistent schedule.
    """
    if len(historical) < 4:
        return None

    # Get the most recent quarterly filings
    quarterly = [h for h in historical if h.form_type == "10-Q"]
    annual = [h for h in historical if h.form_type == "10-K"]

    if not quarterly and not annual:
        return None

    # Calculate average days between period end and filing
    delays = []
    for h in historical[:8]:  # Look at last 8 filings
        try:
            period_end = datetime.strptime(h.period_end, "%Y-%m-%d")
            filed = datetime.strptime(h.date, "%Y-%m-%d")
            delay = (filed - period_end).days
            if 20 <= delay <= 90:  # Reasonable range
                delays.append(delay)
        except (ValueError, TypeError):
            continue

    if not delays:
        avg_delay = 40  # Default to ~40 days
    else:
        avg_delay = sum(delays) // len(delays)

    # Find the last period end and estimate next
    try:
        last = historical[0]
        last_period_end = datetime.strptime(last.period_end, "%Y-%m-%d")

        # Estimate next quarter end (~90 days after last)
        if last.form_type == "10-K":
            # After annual, next is Q1 (~90 days)
            next_period_end = last_period_end + timedelta(days=90)
            next_form = "10-Q"
            next_quarter = "Q1"
        elif last.fiscal_quarter == "Q3":
            # After Q3, next is annual (10-K)
            next_period_end = last_period_end + timedelta(days=90)
            next_form = "10-K"
            next_quarter = "FY"
        else:
            # Regular quarter
            next_period_end = last_period_end + timedelta(days=90)
            next_form = "10-Q"
            q_map = {"Q1": "Q2", "Q2": "Q3", "FY": "Q1"}
            next_quarter = q_map.get(last.fiscal_quarter, "Q2")

        # Estimate filing date
        next_filing = next_period_end + timedelta(days=avg_delay)

        # Only return if it's in the future
        if next_filing > datetime.now():
            return EarningsDate(
                date=next_filing.strftime("%Y-%m-%d"),
                period_end=next_period_end.strftime("%Y-%m-%d"),
                form_type=next_form,
                fiscal_quarter=next_quarter,
            )
    except (ValueError, TypeError):
        pass

    return None
