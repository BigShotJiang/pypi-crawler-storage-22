"""
Financial statement data classes.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import pandas as pd


@dataclass
class FinancialMetric:
    """A single financial metric with historical values."""
    name: str
    label: str
    values: List[Dict[str, Any]] = field(default_factory=list)

    def latest(self) -> Optional[Dict[str, Any]]:
        """Get the most recent value."""
        if not self.values:
            return None
        # Sort by end date and return most recent
        sorted_vals = sorted(self.values, key=lambda x: x.get("end", ""), reverse=True)
        return sorted_vals[0] if sorted_vals else None

    def to_series(self) -> pd.Series:
        """Convert to pandas Series indexed by date."""
        if not self.values:
            return pd.Series(dtype=float)
        data = {v.get("end"): v.get("val") for v in self.values if v.get("end")}
        return pd.Series(data, name=self.name).sort_index()


@dataclass
class IncomeStatement:
    """
    Income Statement financial data.

    Attributes contain lists of historical values with date and amount.
    """
    revenue: FinancialMetric = field(default_factory=lambda: FinancialMetric("revenue", "Revenue"))
    cost_of_revenue: FinancialMetric = field(default_factory=lambda: FinancialMetric("cost_of_revenue", "Cost of Revenue"))
    gross_profit: FinancialMetric = field(default_factory=lambda: FinancialMetric("gross_profit", "Gross Profit"))
    operating_expenses: FinancialMetric = field(default_factory=lambda: FinancialMetric("operating_expenses", "Operating Expenses"))
    operating_income: FinancialMetric = field(default_factory=lambda: FinancialMetric("operating_income", "Operating Income"))
    net_income: FinancialMetric = field(default_factory=lambda: FinancialMetric("net_income", "Net Income"))
    eps_basic: FinancialMetric = field(default_factory=lambda: FinancialMetric("eps_basic", "EPS (Basic)"))
    eps_diluted: FinancialMetric = field(default_factory=lambda: FinancialMetric("eps_diluted", "EPS (Diluted)"))

    def to_dataframe(self) -> pd.DataFrame:
        """Convert to pandas DataFrame with dates as index."""
        metrics = [
            self.revenue, self.cost_of_revenue, self.gross_profit,
            self.operating_expenses, self.operating_income, self.net_income,
            self.eps_basic, self.eps_diluted
        ]
        series_list = [m.to_series() for m in metrics if m.values]
        if not series_list:
            return pd.DataFrame()
        df = pd.concat(series_list, axis=1)
        df.index = pd.to_datetime(df.index)
        return df.sort_index()

    def summary(self) -> Dict[str, Any]:
        """Get a summary of the latest values."""
        return {
            "revenue": self.revenue.latest(),
            "gross_profit": self.gross_profit.latest(),
            "operating_income": self.operating_income.latest(),
            "net_income": self.net_income.latest(),
            "eps_diluted": self.eps_diluted.latest(),
        }


@dataclass
class BalanceSheet:
    """
    Balance Sheet financial data.
    """
    total_assets: FinancialMetric = field(default_factory=lambda: FinancialMetric("total_assets", "Total Assets"))
    current_assets: FinancialMetric = field(default_factory=lambda: FinancialMetric("current_assets", "Current Assets"))
    total_liabilities: FinancialMetric = field(default_factory=lambda: FinancialMetric("total_liabilities", "Total Liabilities"))
    current_liabilities: FinancialMetric = field(default_factory=lambda: FinancialMetric("current_liabilities", "Current Liabilities"))
    stockholders_equity: FinancialMetric = field(default_factory=lambda: FinancialMetric("stockholders_equity", "Stockholders Equity"))
    cash: FinancialMetric = field(default_factory=lambda: FinancialMetric("cash", "Cash and Equivalents"))
    inventory: FinancialMetric = field(default_factory=lambda: FinancialMetric("inventory", "Inventory"))
    accounts_receivable: FinancialMetric = field(default_factory=lambda: FinancialMetric("accounts_receivable", "Accounts Receivable"))
    long_term_debt: FinancialMetric = field(default_factory=lambda: FinancialMetric("long_term_debt", "Long-term Debt"))
    short_term_debt: FinancialMetric = field(default_factory=lambda: FinancialMetric("short_term_debt", "Short-term Debt"))

    def to_dataframe(self) -> pd.DataFrame:
        """Convert to pandas DataFrame with dates as index."""
        metrics = [
            self.total_assets, self.current_assets, self.total_liabilities,
            self.current_liabilities, self.stockholders_equity, self.cash,
            self.inventory, self.accounts_receivable, self.long_term_debt,
            self.short_term_debt
        ]
        series_list = [m.to_series() for m in metrics if m.values]
        if not series_list:
            return pd.DataFrame()
        df = pd.concat(series_list, axis=1)
        df.index = pd.to_datetime(df.index)
        return df.sort_index()

    def summary(self) -> Dict[str, Any]:
        """Get a summary of the latest values."""
        return {
            "total_assets": self.total_assets.latest(),
            "total_liabilities": self.total_liabilities.latest(),
            "stockholders_equity": self.stockholders_equity.latest(),
            "cash": self.cash.latest(),
            "long_term_debt": self.long_term_debt.latest(),
        }


@dataclass
class CashFlow:
    """
    Cash Flow Statement financial data.
    """
    operating_cash_flow: FinancialMetric = field(default_factory=lambda: FinancialMetric("operating_cash_flow", "Operating Cash Flow"))
    investing_cash_flow: FinancialMetric = field(default_factory=lambda: FinancialMetric("investing_cash_flow", "Investing Cash Flow"))
    financing_cash_flow: FinancialMetric = field(default_factory=lambda: FinancialMetric("financing_cash_flow", "Financing Cash Flow"))
    capital_expenditures: FinancialMetric = field(default_factory=lambda: FinancialMetric("capital_expenditures", "Capital Expenditures"))
    dividends_paid: FinancialMetric = field(default_factory=lambda: FinancialMetric("dividends_paid", "Dividends Paid"))
    free_cash_flow: FinancialMetric = field(default_factory=lambda: FinancialMetric("free_cash_flow", "Free Cash Flow"))

    def to_dataframe(self) -> pd.DataFrame:
        """Convert to pandas DataFrame with dates as index."""
        metrics = [
            self.operating_cash_flow, self.investing_cash_flow,
            self.financing_cash_flow, self.capital_expenditures,
            self.dividends_paid, self.free_cash_flow
        ]
        series_list = [m.to_series() for m in metrics if m.values]
        if not series_list:
            return pd.DataFrame()
        df = pd.concat(series_list, axis=1)
        df.index = pd.to_datetime(df.index)
        return df.sort_index()

    def summary(self) -> Dict[str, Any]:
        """Get a summary of the latest values."""
        return {
            "operating_cash_flow": self.operating_cash_flow.latest(),
            "investing_cash_flow": self.investing_cash_flow.latest(),
            "financing_cash_flow": self.financing_cash_flow.latest(),
            "free_cash_flow": self.free_cash_flow.latest(),
        }
