"""
XBRL parsing utilities for extracting financial data from SEC filings.
"""

from typing import Dict, List, Any, Optional
from .financials import (
    FinancialMetric, IncomeStatement, BalanceSheet, CashFlow
)


# XBRL concept mappings - maps standard concepts to our field names
# Multiple concepts may map to the same field (companies use different tags)

INCOME_STATEMENT_CONCEPTS = {
    # Revenue
    "Revenues": "revenue",
    "RevenueFromContractWithCustomerExcludingAssessedTax": "revenue",
    "SalesRevenueNet": "revenue",
    "SalesRevenueGoodsNet": "revenue",
    "RevenueFromContractWithCustomerIncludingAssessedTax": "revenue",

    # Cost of Revenue
    "CostOfRevenue": "cost_of_revenue",
    "CostOfGoodsAndServicesSold": "cost_of_revenue",
    "CostOfGoodsSold": "cost_of_revenue",

    # Gross Profit
    "GrossProfit": "gross_profit",

    # Operating Expenses
    "OperatingExpenses": "operating_expenses",
    "CostsAndExpenses": "operating_expenses",

    # Operating Income
    "OperatingIncomeLoss": "operating_income",

    # Net Income
    "NetIncomeLoss": "net_income",
    "ProfitLoss": "net_income",
    "NetIncomeLossAvailableToCommonStockholdersBasic": "net_income",

    # EPS
    "EarningsPerShareBasic": "eps_basic",
    "EarningsPerShareDiluted": "eps_diluted",
}

BALANCE_SHEET_CONCEPTS = {
    # Assets
    "Assets": "total_assets",
    "AssetsCurrent": "current_assets",

    # Liabilities
    "Liabilities": "total_liabilities",
    "LiabilitiesCurrent": "current_liabilities",

    # Equity
    "StockholdersEquity": "stockholders_equity",
    "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest": "stockholders_equity",

    # Cash
    "CashAndCashEquivalentsAtCarryingValue": "cash",
    "Cash": "cash",
    "CashCashEquivalentsAndShortTermInvestments": "cash",

    # Inventory
    "InventoryNet": "inventory",
    "Inventory": "inventory",

    # Receivables
    "AccountsReceivableNetCurrent": "accounts_receivable",
    "ReceivablesNetCurrent": "accounts_receivable",

    # Debt
    "LongTermDebt": "long_term_debt",
    "LongTermDebtNoncurrent": "long_term_debt",
    "ShortTermBorrowings": "short_term_debt",
    "DebtCurrent": "short_term_debt",
}

CASH_FLOW_CONCEPTS = {
    # Operating
    "NetCashProvidedByUsedInOperatingActivities": "operating_cash_flow",
    "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations": "operating_cash_flow",

    # Investing
    "NetCashProvidedByUsedInInvestingActivities": "investing_cash_flow",
    "NetCashProvidedByUsedInInvestingActivitiesContinuingOperations": "investing_cash_flow",

    # Financing
    "NetCashProvidedByUsedInFinancingActivities": "financing_cash_flow",
    "NetCashProvidedByUsedInFinancingActivitiesContinuingOperations": "financing_cash_flow",

    # CapEx
    "PaymentsToAcquirePropertyPlantAndEquipment": "capital_expenditures",
    "CapitalExpendituresIncurredButNotYetPaid": "capital_expenditures",

    # Dividends
    "PaymentsOfDividends": "dividends_paid",
    "PaymentsOfDividendsCommonStock": "dividends_paid",
}


def extract_concept_values(
    facts: dict,
    concept: str,
    taxonomy: str = "us-gaap",
    period_filter: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Extract values for a specific XBRL concept from company facts.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API
    concept : str
        XBRL concept name (e.g., "Revenues")
    taxonomy : str
        XBRL taxonomy ("us-gaap", "dei", etc.)
    period_filter : str, optional
        Filter by form type ("10-K" for annual, "10-Q" for quarterly)

    Returns
    -------
    list[dict]
        List of values with keys: val, end, start, form, filed, accn
    """
    try:
        concept_data = facts.get("facts", {}).get(taxonomy, {}).get(concept, {})
        units = concept_data.get("units", {})

        # Get values - try USD first, then shares, then pure numbers
        values = []
        for unit_type in ["USD", "shares", "pure", "USD/shares"]:
            if unit_type in units:
                values = units[unit_type]
                break

        if not values:
            return []

        # Filter to specific form types if requested
        if period_filter:
            values = [v for v in values if v.get("form") == period_filter]

        # Filter to only include values with end dates (exclude instant measurements without context)
        values = [v for v in values if v.get("end")]

        return values
    except (KeyError, TypeError):
        return []


def parse_income_statement(facts: dict, period: str = "annual") -> IncomeStatement:
    """
    Parse income statement data from company facts.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API
    period : str
        "annual" for 10-K filings, "quarterly" for 10-Q

    Returns
    -------
    IncomeStatement
        Parsed income statement data
    """
    form_filter = "10-K" if period == "annual" else "10-Q"
    statement = IncomeStatement()

    field_values: Dict[str, List] = {
        "revenue": [], "cost_of_revenue": [], "gross_profit": [],
        "operating_expenses": [], "operating_income": [], "net_income": [],
        "eps_basic": [], "eps_diluted": [],
    }

    for concept, field_name in INCOME_STATEMENT_CONCEPTS.items():
        values = extract_concept_values(facts, concept, period_filter=form_filter)
        if values:
            field_values[field_name].extend(values)

    # Assign to statement fields
    statement.revenue.values = field_values["revenue"]
    statement.cost_of_revenue.values = field_values["cost_of_revenue"]
    statement.gross_profit.values = field_values["gross_profit"]
    statement.operating_expenses.values = field_values["operating_expenses"]
    statement.operating_income.values = field_values["operating_income"]
    statement.net_income.values = field_values["net_income"]
    statement.eps_basic.values = field_values["eps_basic"]
    statement.eps_diluted.values = field_values["eps_diluted"]

    return statement


def parse_balance_sheet(facts: dict, period: str = "annual") -> BalanceSheet:
    """
    Parse balance sheet data from company facts.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API
    period : str
        "annual" for 10-K filings, "quarterly" for 10-Q

    Returns
    -------
    BalanceSheet
        Parsed balance sheet data
    """
    form_filter = "10-K" if period == "annual" else "10-Q"
    statement = BalanceSheet()

    field_values: Dict[str, List] = {
        "total_assets": [], "current_assets": [], "total_liabilities": [],
        "current_liabilities": [], "stockholders_equity": [], "cash": [],
        "inventory": [], "accounts_receivable": [], "long_term_debt": [],
        "short_term_debt": [],
    }

    for concept, field_name in BALANCE_SHEET_CONCEPTS.items():
        values = extract_concept_values(facts, concept, period_filter=form_filter)
        if values:
            field_values[field_name].extend(values)

    # Assign to statement fields
    statement.total_assets.values = field_values["total_assets"]
    statement.current_assets.values = field_values["current_assets"]
    statement.total_liabilities.values = field_values["total_liabilities"]
    statement.current_liabilities.values = field_values["current_liabilities"]
    statement.stockholders_equity.values = field_values["stockholders_equity"]
    statement.cash.values = field_values["cash"]
    statement.inventory.values = field_values["inventory"]
    statement.accounts_receivable.values = field_values["accounts_receivable"]
    statement.long_term_debt.values = field_values["long_term_debt"]
    statement.short_term_debt.values = field_values["short_term_debt"]

    return statement


def parse_cash_flow(facts: dict, period: str = "annual") -> CashFlow:
    """
    Parse cash flow statement data from company facts.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API
    period : str
        "annual" for 10-K filings, "quarterly" for 10-Q

    Returns
    -------
    CashFlow
        Parsed cash flow data
    """
    form_filter = "10-K" if period == "annual" else "10-Q"
    statement = CashFlow()

    field_values: Dict[str, List] = {
        "operating_cash_flow": [], "investing_cash_flow": [],
        "financing_cash_flow": [], "capital_expenditures": [],
        "dividends_paid": [], "free_cash_flow": [],
    }

    for concept, field_name in CASH_FLOW_CONCEPTS.items():
        values = extract_concept_values(facts, concept, period_filter=form_filter)
        if values:
            field_values[field_name].extend(values)

    # Assign to statement fields
    statement.operating_cash_flow.values = field_values["operating_cash_flow"]
    statement.investing_cash_flow.values = field_values["investing_cash_flow"]
    statement.financing_cash_flow.values = field_values["financing_cash_flow"]
    statement.capital_expenditures.values = field_values["capital_expenditures"]
    statement.dividends_paid.values = field_values["dividends_paid"]

    # Calculate free cash flow if we have the components
    if field_values["operating_cash_flow"] and field_values["capital_expenditures"]:
        ocf_by_date = {v["end"]: v["val"] for v in field_values["operating_cash_flow"]}
        capex_by_date = {v["end"]: v["val"] for v in field_values["capital_expenditures"]}

        fcf_values = []
        for date, ocf in ocf_by_date.items():
            if date in capex_by_date:
                fcf = ocf - capex_by_date[date]
                fcf_values.append({"end": date, "val": fcf})

        statement.free_cash_flow.values = fcf_values

    return statement
