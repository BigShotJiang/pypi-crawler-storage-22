"""
Utility functions for secfin.
"""

from typing import List, Dict, Any


def format_currency(value: float, decimals: int = 0) -> str:
    """
    Format a number as currency.

    Parameters
    ----------
    value : float
        The value to format
    decimals : int
        Number of decimal places

    Returns
    -------
    str
        Formatted currency string (e.g., "$1,234,567")
    """
    if value >= 1e12:
        return f"${value/1e12:,.{decimals}f}T"
    elif value >= 1e9:
        return f"${value/1e9:,.{decimals}f}B"
    elif value >= 1e6:
        return f"${value/1e6:,.{decimals}f}M"
    elif value >= 1e3:
        return f"${value/1e3:,.{decimals}f}K"
    else:
        return f"${value:,.{decimals}f}"


def deduplicate_values(values: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Remove duplicate values based on end date, keeping the most recent filing.

    Parameters
    ----------
    values : list[dict]
        List of financial values

    Returns
    -------
    list[dict]
        Deduplicated values
    """
    if not values:
        return []

    # Group by end date, keeping most recently filed
    by_date = {}
    for v in values:
        end_date = v.get("end")
        if not end_date:
            continue

        filed_date = v.get("filed", "")
        if end_date not in by_date or filed_date > by_date[end_date].get("filed", ""):
            by_date[end_date] = v

    return list(by_date.values())


def calculate_growth_rate(current: float, previous: float) -> float:
    """
    Calculate year-over-year growth rate.

    Parameters
    ----------
    current : float
        Current period value
    previous : float
        Previous period value

    Returns
    -------
    float
        Growth rate as a decimal (0.1 = 10% growth)
    """
    if previous == 0:
        return 0.0
    return (current - previous) / abs(previous)


def calculate_margin(numerator: float, denominator: float) -> float:
    """
    Calculate a margin/ratio.

    Parameters
    ----------
    numerator : float
        Top value (e.g., gross profit)
    denominator : float
        Bottom value (e.g., revenue)

    Returns
    -------
    float
        Margin as a decimal (0.4 = 40% margin)
    """
    if denominator == 0:
        return 0.0
    return numerator / denominator
