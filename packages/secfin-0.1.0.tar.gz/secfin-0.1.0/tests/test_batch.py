"""
Tests for BatchFetcher class.
"""

import pytest
from unittest.mock import Mock, patch
import pandas as pd
from secfin import BatchFetcher, SECClient
from secfin.financials import IncomeStatement, BalanceSheet, CashFlow, FinancialMetric


class TestBatchFetcherInit:
    """Tests for BatchFetcher initialization."""

    def test_basic_init(self, client):
        """BatchFetcher accepts client."""
        fetcher = BatchFetcher(client)
        assert fetcher.client is client
        assert fetcher.max_workers == 1

    def test_custom_workers(self, client):
        """Custom max_workers is accepted."""
        fetcher = BatchFetcher(client, max_workers=2)
        assert fetcher.max_workers == 2

    def test_custom_progress_callback(self, client):
        """Custom progress callback is stored."""
        progress_fn = Mock()
        fetcher = BatchFetcher(client, on_progress=progress_fn)
        assert fetcher.on_progress is progress_fn

    def test_custom_error_callback(self, client):
        """Custom error callback is stored."""
        error_fn = Mock()
        fetcher = BatchFetcher(client, on_error=error_fn)
        assert fetcher.on_error is error_fn


class TestBatchFetcherCallbacks:
    """Tests for callback behavior."""

    def test_progress_called_for_each_ticker(self, client):
        """Progress callback is called for each ticker."""
        progress_calls = []
        def track_progress(current, total, ticker, status):
            progress_calls.append((current, total, ticker))

        fetcher = BatchFetcher(client, on_progress=track_progress)

        with patch.object(fetcher, '_fetch_single') as mock_fetch:
            mock_fetch.return_value = {
                "ticker": "TEST",
                "status": "success",
                "error": None,
                "name": "Test",
                "cik": "123",
                "income_statement": None,
                "balance_sheet": None,
                "cash_flow": None,
            }
            fetcher.fetch_tickers(["A", "B", "C"])

        assert len(progress_calls) == 3
        assert progress_calls[0] == (1, 3, "A")
        assert progress_calls[1] == (2, 3, "B")
        assert progress_calls[2] == (3, 3, "C")

    def test_error_called_on_failure(self, client):
        """Error callback is called on fetch failure."""
        errors = []
        def track_error(ticker, error):
            errors.append((ticker, str(error)))

        fetcher = BatchFetcher(client, on_error=track_error)

        with patch.object(fetcher, '_fetch_single') as mock_fetch:
            mock_fetch.return_value = {
                "ticker": "BAD",
                "status": "error",
                "error": "Not found",
                "name": None,
                "cik": None,
                "income_statement": None,
                "balance_sheet": None,
                "cash_flow": None,
            }
            fetcher.fetch_tickers(["BAD"])

        assert len(errors) == 1
        assert errors[0][0] == "BAD"


class TestBatchFetcherFetchTickers:
    """Tests for fetch_tickers method."""

    def test_returns_dict(self, client):
        """fetch_tickers returns dictionary."""
        fetcher = BatchFetcher(client, on_progress=lambda *a: None)

        with patch.object(fetcher, '_fetch_single') as mock_fetch:
            mock_fetch.return_value = {
                "ticker": "TEST",
                "status": "success",
                "error": None,
                "name": "Test",
                "cik": "123",
                "income_statement": IncomeStatement(),
                "balance_sheet": BalanceSheet(),
                "cash_flow": CashFlow(),
            }
            result = fetcher.fetch_tickers(["TEST"])

        assert isinstance(result, dict)
        assert "TEST" in result

    def test_result_structure(self, client):
        """Each result has expected structure."""
        fetcher = BatchFetcher(client, on_progress=lambda *a: None)

        with patch.object(fetcher, '_fetch_single') as mock_fetch:
            mock_fetch.return_value = {
                "ticker": "TEST",
                "status": "success",
                "error": None,
                "name": "Test Co",
                "cik": "0001234567",
                "income_statement": IncomeStatement(),
                "balance_sheet": BalanceSheet(),
                "cash_flow": CashFlow(),
            }
            result = fetcher.fetch_tickers(["TEST"])

        item = result["TEST"]
        assert "ticker" in item
        assert "name" in item
        assert "cik" in item
        assert "income_statement" in item
        assert "balance_sheet" in item
        assert "cash_flow" in item
        assert "status" in item


class TestBatchFetcherIndices:
    """Tests for index fetching methods."""

    def test_fetch_sp500_uses_ticker_list(self, client):
        """fetch_sp500 calls fetch_tickers with SP500 list."""
        fetcher = BatchFetcher(client, on_progress=lambda *a: None)

        with patch.object(fetcher, 'fetch_tickers') as mock_fetch:
            mock_fetch.return_value = {}
            fetcher.fetch_sp500()

        mock_fetch.assert_called_once()
        args = mock_fetch.call_args[0]
        assert len(args[0]) > 400  # S&P 500 has ~500 tickers

    def test_fetch_nasdaq100_uses_ticker_list(self, client):
        """fetch_nasdaq100 calls fetch_tickers with NASDAQ list."""
        fetcher = BatchFetcher(client, on_progress=lambda *a: None)

        with patch.object(fetcher, 'fetch_tickers') as mock_fetch:
            mock_fetch.return_value = {}
            fetcher.fetch_nasdaq100()

        mock_fetch.assert_called_once()
        args = mock_fetch.call_args[0]
        assert len(args[0]) >= 100

    def test_fetch_russell2000_requires_tickers(self, client):
        """fetch_russell2000 raises without tickers."""
        fetcher = BatchFetcher(client)

        with pytest.raises(ValueError, match="tickers"):
            fetcher.fetch_russell2000()

    def test_fetch_russell2000_with_tickers(self, client):
        """fetch_russell2000 works with provided tickers."""
        fetcher = BatchFetcher(client, on_progress=lambda *a: None)

        with patch.object(fetcher, 'fetch_tickers') as mock_fetch:
            mock_fetch.return_value = {}
            fetcher.fetch_russell2000(tickers=["A", "B", "C"])

        mock_fetch.assert_called_once()
        args = mock_fetch.call_args[0]
        assert args[0] == ["A", "B", "C"]


class TestBatchFetcherDataFrames:
    """Tests for DataFrame conversion methods."""

    @pytest.fixture
    def sample_results(self):
        """Create sample batch results."""
        income = IncomeStatement()
        income.revenue = FinancialMetric(
            name="revenue",
            label="Revenue",
            values=[
                {"end": "2023-12-31", "val": 100000},
                {"end": "2022-12-31", "val": 90000},
            ]
        )
        income.net_income = FinancialMetric(
            name="net_income",
            label="Net Income",
            values=[
                {"end": "2023-12-31", "val": 10000},
            ]
        )

        return {
            "AAPL": {
                "ticker": "AAPL",
                "name": "Apple Inc.",
                "cik": "0000320193",
                "status": "success",
                "error": None,
                "income_statement": income,
                "balance_sheet": BalanceSheet(),
                "cash_flow": CashFlow(),
            },
            "BAD": {
                "ticker": "BAD",
                "name": None,
                "cik": None,
                "status": "error",
                "error": "Not found",
                "income_statement": None,
                "balance_sheet": None,
                "cash_flow": None,
            }
        }

    def test_to_dataframe_basic(self, client, sample_results):
        """to_dataframe returns DataFrame."""
        fetcher = BatchFetcher(client)
        df = fetcher.to_dataframe(sample_results, "income_statement", "revenue")

        assert isinstance(df, pd.DataFrame)
        assert "AAPL" in df.index
        assert "BAD" not in df.index  # Failed results excluded

    def test_to_dataframe_empty_results(self, client):
        """to_dataframe handles empty results."""
        fetcher = BatchFetcher(client)
        df = fetcher.to_dataframe({}, "income_statement", "revenue")

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 0

    def test_summary_dataframe(self, client, sample_results):
        """summary_dataframe returns summary DataFrame."""
        fetcher = BatchFetcher(client)
        df = fetcher.summary_dataframe(sample_results)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 1  # Only successful result
        assert df.iloc[0]["ticker"] == "AAPL"
        assert df.iloc[0]["name"] == "Apple Inc."

    def test_summary_excludes_errors(self, client, sample_results):
        """summary_dataframe excludes failed results."""
        fetcher = BatchFetcher(client)
        df = fetcher.summary_dataframe(sample_results)

        tickers = df["ticker"].tolist()
        assert "BAD" not in tickers


@pytest.mark.integration
class TestBatchFetcherIntegration:
    """Integration tests for BatchFetcher."""

    @pytest.fixture
    def client(self):
        return SECClient("TestApp test@example.com")

    def test_fetch_small_batch(self, client):
        """Fetch a small batch of tickers."""
        fetcher = BatchFetcher(client, on_progress=lambda *a: None)
        results = fetcher.fetch_tickers(["AAPL", "MSFT"])

        assert len(results) == 2
        assert "AAPL" in results
        assert "MSFT" in results
        assert results["AAPL"]["status"] == "success"
        assert results["MSFT"]["status"] == "success"

    def test_handles_invalid_ticker(self, client):
        """Handles invalid ticker gracefully."""
        fetcher = BatchFetcher(
            client,
            on_progress=lambda *a: None,
            on_error=lambda *a: None
        )
        results = fetcher.fetch_tickers(["INVALIDTICKER123"])

        assert "INVALIDTICKER123" in results
        assert results["INVALIDTICKER123"]["status"] == "error"

    def test_summary_dataframe_integration(self, client):
        """Create summary DataFrame from real data."""
        fetcher = BatchFetcher(client, on_progress=lambda *a: None)
        results = fetcher.fetch_tickers(["AAPL"])
        df = fetcher.summary_dataframe(results)

        assert len(df) == 1
        assert df.iloc[0]["ticker"] == "AAPL"
        assert "revenue" in df.columns or df.iloc[0].get("revenue") is not None
