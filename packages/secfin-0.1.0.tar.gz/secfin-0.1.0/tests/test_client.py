"""
Tests for SECClient class.
"""

import pytest
from secfin import SECClient


class TestSECClientInit:
    """Tests for SECClient initialization."""

    def test_valid_user_agent(self):
        """Client accepts valid user agent with email."""
        client = SECClient("MyApp test@example.com")
        assert client.user_agent == "MyApp test@example.com"

    def test_requires_user_agent(self):
        """Client rejects empty user agent."""
        with pytest.raises(ValueError, match="User-Agent"):
            SECClient("")

    def test_requires_email_in_user_agent(self):
        """Client rejects user agent without email."""
        with pytest.raises(ValueError, match="User-Agent"):
            SECClient("MyApp")

    def test_rate_limit_default(self):
        """Default rate limit is 0.1 seconds."""
        client = SECClient("MyApp test@example.com")
        assert client.rate_limit == 0.1

    def test_rate_limit_custom(self):
        """Custom rate limit is accepted."""
        client = SECClient("MyApp test@example.com", rate_limit=0.5)
        assert client.rate_limit == 0.5


class TestSECClientOffline:
    """Offline tests for SECClient methods."""

    @pytest.fixture
    def client(self):
        return SECClient("TestApp test@example.com")

    def test_session_headers(self, client):
        """Session has correct headers set."""
        assert "User-Agent" in client._session.headers
        assert client._session.headers["User-Agent"] == "TestApp test@example.com"
        assert client._session.headers["Accept"] == "application/json"


@pytest.mark.integration
class TestSECClientIntegration:
    """Integration tests requiring network access."""

    @pytest.fixture
    def client(self):
        return SECClient("TestApp test@example.com")

    def test_get_cik_apple(self, client):
        """Get CIK for Apple Inc."""
        cik = client.get_cik("AAPL")
        assert cik == "0000320193"

    def test_get_cik_microsoft(self, client):
        """Get CIK for Microsoft."""
        cik = client.get_cik("MSFT")
        assert cik == "0000789019"

    def test_get_cik_invalid_ticker(self, client):
        """Invalid ticker raises ValueError."""
        with pytest.raises(ValueError, match="not found"):
            client.get_cik("INVALIDTICKER123")

    def test_get_cik_case_insensitive(self, client):
        """Ticker lookup is case insensitive."""
        cik_upper = client.get_cik("AAPL")
        cik_lower = client.get_cik("aapl")
        assert cik_upper == cik_lower

    def test_get_company_facts(self, client):
        """Get company facts returns valid data."""
        facts = client.get_company_facts("0000320193")
        assert "cik" in facts
        assert "entityName" in facts
        assert "facts" in facts
        assert facts["entityName"] == "Apple Inc."

    def test_get_company_info(self, client):
        """Get company info returns name and CIK."""
        info = client.get_company_info("0000320193")
        assert info["name"] == "Apple Inc."
        assert info["cik"] == 320193
