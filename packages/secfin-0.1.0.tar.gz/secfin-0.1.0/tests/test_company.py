"""
Tests for Company class.
"""

import pytest
from unittest.mock import Mock, patch
from secfin import Company, SECClient
from secfin.financials import IncomeStatement, BalanceSheet, CashFlow
from secfin.earnings import EarningsCalendar


class TestCompanyInit:
    """Tests for Company initialization."""

    def test_ticker_uppercase(self, client):
        """Ticker is converted to uppercase."""
        company = Company("aapl", client)
        assert company.ticker == "AAPL"

    def test_stores_client(self, client):
        """Client is stored."""
        company = Company("AAPL", client)
        assert company._client is client

    def test_cik_initially_none(self, client):
        """CIK is None until accessed."""
        company = Company("AAPL", client)
        assert company._cik is None


class TestCompanyProperties:
    """Tests for Company lazy properties."""

    def test_cik_lazy_loaded(self):
        """CIK is fetched on first access."""
        mock_client = Mock(spec=SECClient)
        mock_client.get_cik.return_value = "0000320193"

        company = Company("AAPL", mock_client)
        cik = company.cik

        assert cik == "0000320193"
        mock_client.get_cik.assert_called_once_with("AAPL")

    def test_cik_cached(self):
        """CIK is cached after first access."""
        mock_client = Mock(spec=SECClient)
        mock_client.get_cik.return_value = "0000320193"

        company = Company("AAPL", mock_client)
        _ = company.cik
        _ = company.cik

        mock_client.get_cik.assert_called_once()

    def test_name_lazy_loaded(self, mock_company_facts):
        """Name is fetched on first access."""
        mock_client = Mock(spec=SECClient)
        mock_client.get_cik.return_value = "0000320193"
        mock_client.get_company_facts.return_value = mock_company_facts

        company = Company("AAPL", mock_client)
        name = company.name

        assert name == "Test Company Inc."

    def test_name_cached(self, mock_company_facts):
        """Name is cached after first access."""
        mock_client = Mock(spec=SECClient)
        mock_client.get_cik.return_value = "0000320193"
        mock_client.get_company_facts.return_value = mock_company_facts

        company = Company("AAPL", mock_client)
        _ = company.name
        _ = company.name

        mock_client.get_company_facts.assert_called_once()


class TestCompanyMethods:
    """Tests for Company methods with mocked client."""

    @pytest.fixture
    def mock_company(self, mock_company_facts):
        """Create Company with mocked client."""
        mock_client = Mock(spec=SECClient)
        mock_client.get_cik.return_value = "0000320193"
        mock_client.get_company_facts.return_value = mock_company_facts
        return Company("AAPL", mock_client)

    def test_get_income_statement_returns_type(self, mock_company):
        """get_income_statement returns IncomeStatement."""
        result = mock_company.get_income_statement()
        assert isinstance(result, IncomeStatement)

    def test_get_balance_sheet_returns_type(self, mock_company):
        """get_balance_sheet returns BalanceSheet."""
        result = mock_company.get_balance_sheet()
        assert isinstance(result, BalanceSheet)

    def test_get_cash_flow_returns_type(self, mock_company):
        """get_cash_flow returns CashFlow."""
        result = mock_company.get_cash_flow()
        assert isinstance(result, CashFlow)

    def test_get_all_financials_returns_dict(self, mock_company):
        """get_all_financials returns dict with all statements."""
        result = mock_company.get_all_financials()
        assert isinstance(result, dict)
        assert "income_statement" in result
        assert "balance_sheet" in result
        assert "cash_flow" in result

    def test_summary_returns_dict(self, mock_company):
        """summary() returns dict with company info and financials."""
        result = mock_company.summary()
        assert isinstance(result, dict)
        assert "company" in result
        assert result["company"]["ticker"] == "AAPL"

    def test_get_earnings_calendar_returns_type(self, mock_company):
        """get_earnings_calendar returns EarningsCalendar."""
        result = mock_company.get_earnings_calendar()
        assert isinstance(result, EarningsCalendar)

    def test_repr(self, mock_company):
        """__repr__ shows ticker and CIK."""
        repr_str = repr(mock_company)
        assert "AAPL" in repr_str
        assert "0000320193" in repr_str


class TestCompanyPeriods:
    """Tests for period parameter handling."""

    @pytest.fixture
    def mock_company(self, mock_company_facts):
        mock_client = Mock(spec=SECClient)
        mock_client.get_cik.return_value = "0000320193"
        mock_client.get_company_facts.return_value = mock_company_facts
        return Company("AAPL", mock_client)

    def test_annual_period(self, mock_company):
        """Annual period is accepted."""
        result = mock_company.get_income_statement(period="annual")
        assert isinstance(result, IncomeStatement)

    def test_quarterly_period(self, mock_company):
        """Quarterly period is accepted."""
        result = mock_company.get_income_statement(period="quarterly")
        assert isinstance(result, IncomeStatement)


@pytest.mark.integration
class TestCompanyIntegration:
    """Integration tests requiring network access."""

    @pytest.fixture
    def client(self):
        return SECClient("TestApp test@example.com")

    def test_apple_basic_info(self, client):
        """Get basic info for Apple."""
        company = Company("AAPL", client)
        assert company.ticker == "AAPL"
        assert company.cik == "0000320193"
        assert "Apple" in company.name

    def test_income_statement_has_data(self, client):
        """Income statement has revenue data."""
        company = Company("AAPL", client)
        income = company.get_income_statement()
        latest = income.revenue.latest()
        assert latest is not None
        assert latest.get("val") > 0

    def test_balance_sheet_has_data(self, client):
        """Balance sheet has assets data."""
        company = Company("AAPL", client)
        balance = company.get_balance_sheet()
        latest = balance.total_assets.latest()
        assert latest is not None
        assert latest.get("val") > 0

    def test_cash_flow_has_data(self, client):
        """Cash flow has operating cash flow data."""
        company = Company("AAPL", client)
        cashflow = company.get_cash_flow()
        latest = cashflow.operating_cash_flow.latest()
        assert latest is not None

    def test_earnings_calendar(self, client):
        """Can get earnings calendar."""
        company = Company("AAPL", client)
        calendar = company.get_earnings_calendar()
        assert calendar.ticker == "AAPL"
        assert len(calendar.historical) > 0

    def test_next_earnings(self, client):
        """Can get next earnings estimate."""
        company = Company("AAPL", client)
        next_e = company.next_earnings()
        # May or may not have next estimate
        if next_e:
            assert "date" in next_e
            assert "form_type" in next_e

    def test_last_earnings(self, client):
        """Can get last earnings date."""
        company = Company("AAPL", client)
        last = company.last_earnings()
        assert last is not None
        assert "date" in last
        assert "form_type" in last

    def test_earnings_history(self, client):
        """Can get earnings history."""
        company = Company("AAPL", client)
        history = company.earnings_history(limit=5)
        assert len(history) > 0
        assert len(history) <= 5
