"""
Tests for earnings calendar functionality.
"""

import pytest
from datetime import datetime, timedelta
import pandas as pd
from secfin.earnings import (
    EarningsDate,
    EarningsCalendar,
    parse_earnings_from_facts,
    estimate_next_earnings,
)


class TestEarningsDate:
    """Tests for EarningsDate dataclass."""

    def test_basic_creation(self):
        """Create EarningsDate with required fields."""
        ed = EarningsDate(
            date="2024-01-30",
            period_end="2023-12-31",
            form_type="10-K"
        )
        assert ed.date == "2024-01-30"
        assert ed.period_end == "2023-12-31"
        assert ed.form_type == "10-K"
        assert ed.fiscal_year is None
        assert ed.fiscal_quarter is None

    def test_full_creation(self):
        """Create EarningsDate with all fields."""
        ed = EarningsDate(
            date="2024-01-30",
            period_end="2023-12-31",
            form_type="10-K",
            fiscal_year=2023,
            fiscal_quarter="FY"
        )
        assert ed.fiscal_year == 2023
        assert ed.fiscal_quarter == "FY"


class TestEarningsCalendar:
    """Tests for EarningsCalendar class."""

    def test_basic_creation(self):
        """Create EarningsCalendar with required fields."""
        cal = EarningsCalendar(
            ticker="AAPL",
            company_name="Apple Inc."
        )
        assert cal.ticker == "AAPL"
        assert cal.company_name == "Apple Inc."
        assert cal.historical == []
        assert cal.next_estimated is None

    def test_get_historical_df(self, sample_earnings_calendar):
        """get_historical_df() returns DataFrame."""
        df = sample_earnings_calendar.get_historical_df()
        assert isinstance(df, pd.DataFrame)
        assert "filing_date" in df.columns
        assert "period_end" in df.columns
        assert "form_type" in df.columns
        assert len(df) == 4

    def test_get_historical_df_empty(self):
        """get_historical_df() returns empty DataFrame when no history."""
        cal = EarningsCalendar(ticker="TEST", company_name="Test")
        df = cal.get_historical_df()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 0

    def test_last_earnings(self, sample_earnings_calendar):
        """last_earnings() returns most recent."""
        last = sample_earnings_calendar.last_earnings()
        assert last is not None
        assert last.date == "2024-01-30"
        assert last.form_type == "10-K"

    def test_last_earnings_empty(self):
        """last_earnings() returns None when no history."""
        cal = EarningsCalendar(ticker="TEST", company_name="Test")
        assert cal.last_earnings() is None

    def test_summary(self, sample_earnings_calendar):
        """summary() returns dict with key info."""
        summary = sample_earnings_calendar.summary()
        assert summary["ticker"] == "TEST"
        assert summary["company_name"] == "Test Company Inc."
        assert summary["last_earnings_date"] == "2024-01-30"
        assert summary["fiscal_year_end"] == "December"
        assert summary["total_filings"] == 4


class TestEstimateNextEarnings:
    """Tests for next earnings estimation."""

    def test_requires_minimum_history(self):
        """Returns None with insufficient history."""
        short_history = [
            EarningsDate("2024-01-30", "2023-12-31", "10-K"),
            EarningsDate("2023-10-30", "2023-09-30", "10-Q"),
        ]
        result = estimate_next_earnings(short_history)
        assert result is None

    def test_returns_future_date(self, sample_earnings_dates):
        """Returns a date in the future."""
        # Create recent history so estimation is in future
        base = datetime.now() - timedelta(days=30)
        recent_history = []
        for i, q in enumerate(["FY", "Q3", "Q2", "Q1"]):
            period_end = base - timedelta(days=90 * i)
            filed = period_end + timedelta(days=40)
            recent_history.append(EarningsDate(
                date=filed.strftime("%Y-%m-%d"),
                period_end=period_end.strftime("%Y-%m-%d"),
                form_type="10-K" if q == "FY" else "10-Q",
                fiscal_quarter=q
            ))

        result = estimate_next_earnings(recent_history)
        if result:
            result_date = datetime.strptime(result.date, "%Y-%m-%d")
            assert result_date > datetime.now()

    def test_quarterly_after_annual(self):
        """After 10-K, estimates 10-Q."""
        base = datetime.now() - timedelta(days=30)
        recent_history = []

        # Create 10-K as most recent
        recent_history.append(EarningsDate(
            date=(base).strftime("%Y-%m-%d"),
            period_end=(base - timedelta(days=40)).strftime("%Y-%m-%d"),
            form_type="10-K",
            fiscal_quarter="FY"
        ))
        # Add more history
        for i in range(1, 5):
            period_end = base - timedelta(days=90 * i)
            recent_history.append(EarningsDate(
                date=(period_end + timedelta(days=40)).strftime("%Y-%m-%d"),
                period_end=period_end.strftime("%Y-%m-%d"),
                form_type="10-Q",
                fiscal_quarter=f"Q{4-i}" if i < 4 else "FY"
            ))

        result = estimate_next_earnings(recent_history)
        if result:
            assert result.form_type == "10-Q"
            assert result.fiscal_quarter == "Q1"

    def test_empty_history(self):
        """Returns None for empty history."""
        result = estimate_next_earnings([])
        assert result is None


class TestParseEarningsFromFacts:
    """Tests for parsing earnings from SEC facts."""

    def test_extracts_historical_dates(self, mock_company_facts):
        """Extracts earnings dates from facts."""
        cal = parse_earnings_from_facts(mock_company_facts, "TEST")
        assert cal.ticker == "TEST"
        assert cal.company_name == "Test Company Inc."
        assert len(cal.historical) > 0

    def test_extracts_company_name(self, mock_company_facts):
        """Extracts company name from facts."""
        cal = parse_earnings_from_facts(mock_company_facts, "TEST")
        assert cal.company_name == "Test Company Inc."

    def test_deduplicates_dates(self, mock_company_facts):
        """Does not create duplicate entries for same period."""
        cal = parse_earnings_from_facts(mock_company_facts, "TEST")
        # Check no duplicate period_end + form_type combinations
        seen = set()
        for h in cal.historical:
            key = f"{h.period_end}_{h.form_type}"
            assert key not in seen, f"Duplicate: {key}"
            seen.add(key)

    def test_handles_empty_facts(self):
        """Handles empty facts gracefully."""
        empty_facts = {"facts": {}}
        cal = parse_earnings_from_facts(empty_facts, "TEST")
        assert cal.ticker == "TEST"
        assert cal.historical == []
