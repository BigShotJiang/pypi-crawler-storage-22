"""
Tests for financial statement classes.
"""

import pytest
import pandas as pd
from secfin.financials import FinancialMetric, IncomeStatement, BalanceSheet, CashFlow


class TestFinancialMetric:
    """Tests for FinancialMetric class."""

    def test_latest_returns_most_recent(self, sample_financial_metric):
        """latest() returns the most recent value by date."""
        latest = sample_financial_metric.latest()
        assert latest is not None
        assert latest["end"] == "2023-12-31"
        assert latest["val"] == 100000000

    def test_latest_empty_returns_none(self, empty_financial_metric):
        """latest() returns None when no values."""
        assert empty_financial_metric.latest() is None

    def test_to_series_returns_pandas_series(self, sample_financial_metric):
        """to_series() returns a pandas Series."""
        series = sample_financial_metric.to_series()
        assert isinstance(series, pd.Series)
        assert len(series) == 3
        assert series.name == "revenue"

    def test_to_series_sorted_by_date(self, sample_financial_metric):
        """to_series() returns values sorted by date."""
        series = sample_financial_metric.to_series()
        dates = list(series.index)
        assert dates == sorted(dates)

    def test_to_series_empty_returns_empty(self, empty_financial_metric):
        """to_series() returns empty Series when no values."""
        series = empty_financial_metric.to_series()
        assert isinstance(series, pd.Series)
        assert len(series) == 0

    def test_metric_name_and_label(self):
        """Metric stores name and label correctly."""
        metric = FinancialMetric(name="test_name", label="Test Label")
        assert metric.name == "test_name"
        assert metric.label == "Test Label"
        assert metric.values == []


class TestIncomeStatement:
    """Tests for IncomeStatement class."""

    def test_default_initialization(self):
        """IncomeStatement has default empty metrics."""
        stmt = IncomeStatement()
        assert stmt.revenue.name == "revenue"
        assert stmt.net_income.name == "net_income"
        assert stmt.revenue.values == []

    def test_to_dataframe(self, sample_income_statement):
        """to_dataframe() returns DataFrame with metrics."""
        df = sample_income_statement.to_dataframe()
        assert isinstance(df, pd.DataFrame)
        assert "revenue" in df.columns
        assert "net_income" in df.columns

    def test_to_dataframe_empty(self):
        """to_dataframe() returns empty DataFrame when no data."""
        stmt = IncomeStatement()
        df = stmt.to_dataframe()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 0

    def test_summary_returns_dict(self, sample_income_statement):
        """summary() returns dict with latest values."""
        summary = sample_income_statement.summary()
        assert isinstance(summary, dict)
        assert "revenue" in summary
        assert "net_income" in summary
        assert summary["revenue"]["val"] == 100000000

    def test_has_all_income_metrics(self):
        """IncomeStatement has all expected metrics."""
        stmt = IncomeStatement()
        expected = [
            "revenue", "cost_of_revenue", "gross_profit",
            "operating_expenses", "operating_income", "net_income",
            "eps_basic", "eps_diluted"
        ]
        for metric in expected:
            assert hasattr(stmt, metric)


class TestBalanceSheet:
    """Tests for BalanceSheet class."""

    def test_default_initialization(self):
        """BalanceSheet has default empty metrics."""
        stmt = BalanceSheet()
        assert stmt.total_assets.name == "total_assets"
        assert stmt.cash.name == "cash"
        assert stmt.total_assets.values == []

    def test_to_dataframe(self, sample_balance_sheet):
        """to_dataframe() returns DataFrame with metrics."""
        df = sample_balance_sheet.to_dataframe()
        assert isinstance(df, pd.DataFrame)
        assert "total_assets" in df.columns
        assert "cash" in df.columns

    def test_summary_returns_dict(self, sample_balance_sheet):
        """summary() returns dict with latest values."""
        summary = sample_balance_sheet.summary()
        assert isinstance(summary, dict)
        assert "total_assets" in summary
        assert "cash" in summary

    def test_has_all_balance_metrics(self):
        """BalanceSheet has all expected metrics."""
        stmt = BalanceSheet()
        expected = [
            "total_assets", "current_assets", "total_liabilities",
            "current_liabilities", "stockholders_equity", "cash",
            "inventory", "accounts_receivable", "long_term_debt", "short_term_debt"
        ]
        for metric in expected:
            assert hasattr(stmt, metric)


class TestCashFlow:
    """Tests for CashFlow class."""

    def test_default_initialization(self):
        """CashFlow has default empty metrics."""
        stmt = CashFlow()
        assert stmt.operating_cash_flow.name == "operating_cash_flow"
        assert stmt.free_cash_flow.name == "free_cash_flow"

    def test_to_dataframe(self, sample_cash_flow):
        """to_dataframe() returns DataFrame with metrics."""
        df = sample_cash_flow.to_dataframe()
        assert isinstance(df, pd.DataFrame)
        assert "operating_cash_flow" in df.columns
        assert "free_cash_flow" in df.columns

    def test_summary_returns_dict(self, sample_cash_flow):
        """summary() returns dict with latest values."""
        summary = sample_cash_flow.summary()
        assert isinstance(summary, dict)
        assert "operating_cash_flow" in summary
        assert "free_cash_flow" in summary

    def test_has_all_cashflow_metrics(self):
        """CashFlow has all expected metrics."""
        stmt = CashFlow()
        expected = [
            "operating_cash_flow", "investing_cash_flow",
            "financing_cash_flow", "capital_expenditures",
            "dividends_paid", "free_cash_flow"
        ]
        for metric in expected:
            assert hasattr(stmt, metric)
