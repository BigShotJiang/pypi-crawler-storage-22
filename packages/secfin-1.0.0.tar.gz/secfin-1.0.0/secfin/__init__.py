"""
secfin - Fetch company financial records from SEC EDGAR.

A Python library for accessing financial data from the U.S. Securities and
Exchange Commission's EDGAR database. Provides easy access to income statements,
balance sheets, cash flow statements, and earnings calendars for publicly
traded companies.

Features
--------
- **Financial Statements**: Income Statement, Balance Sheet, Cash Flow Statement
- **Analytics**: TTM calculations, growth rates, CAGR, financial ratios
- **Earnings Calendar**: Historical and estimated future earnings dates
- **Batch Processing**: Fetch data for indices (S&P 500, NASDAQ 100)
- **Caching**: Automatic disk caching to reduce API calls
- **Async Support**: Concurrent fetching for large ticker lists

Quick Start
-----------
>>> from secfin import SECClient, Company
>>>
>>> # Initialize client (SEC requires contact info)
>>> client = SECClient("MyApp contact@email.com")
>>>
>>> # Get company financials
>>> company = Company("AAPL", client)
>>> income = company.get_income_statement()
>>>
>>> # Access metrics
>>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
>>> print(f"Net Margin: {income.net_margin():.1%}")
>>> print(f"Revenue Growth: {income.revenue.growth():.1%}")

Data Source
-----------
All data is sourced from the SEC EDGAR database via their public API.
SEC requires all API users to provide a User-Agent header with contact
information. See: https://www.sec.gov/os/accessing-edgar-data

Rate Limiting
-------------
The client automatically respects SEC's rate limit of 10 requests per second.
API responses are cached locally (default: 24 hours) to reduce redundant calls.

Classes
-------
SECClient
    HTTP client for SEC EDGAR API with rate limiting and caching.
Company
    High-level interface for accessing a company's financial data.
IncomeStatement
    Income statement data with revenue, expenses, and profitability metrics.
BalanceSheet
    Balance sheet data with assets, liabilities, and equity.
CashFlow
    Cash flow statement with operating, investing, and financing activities.
FinancialMetric
    A single metric with historical values and analytics methods.
BatchFetcher
    Batch processing for fetching multiple companies.
AsyncBatchFetcher
    Async version of BatchFetcher for concurrent requests.
EarningsCalendar
    Historical and estimated future earnings dates.
DiskCache
    Simple disk-based caching for API responses.

Examples
--------
**Get financial statements:**

>>> from secfin import SECClient, Company
>>> client = SECClient("MyApp contact@email.com")
>>> company = Company("MSFT", client)
>>>
>>> # Income Statement
>>> income = company.get_income_statement()
>>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
>>> print(f"Gross Margin: {income.gross_margin():.1%}")
>>>
>>> # Balance Sheet
>>> balance = company.get_balance_sheet()
>>> print(f"Total Assets: ${balance.total_assets.latest()['val']:,.0f}")
>>> print(f"Current Ratio: {balance.current_ratio():.2f}")
>>>
>>> # Cash Flow
>>> cashflow = company.get_cash_flow()
>>> print(f"Free Cash Flow: ${cashflow.free_cash_flow.latest()['val']:,.0f}")

**Calculate analytics:**

>>> # Year-over-year growth
>>> growth = income.revenue.growth()
>>>
>>> # 5-year CAGR
>>> cagr = income.revenue.cagr(years=5)
>>>
>>> # Trailing twelve months (from quarterly data)
>>> quarterly = company.get_income_statement(period="quarterly")
>>> ttm_revenue = quarterly.revenue.ttm()

**Batch fetch S&P 500:**

>>> from secfin import SECClient, BatchFetcher
>>> client = SECClient("MyApp contact@email.com")
>>> fetcher = BatchFetcher(client)
>>> results = fetcher.fetch_sp500()
>>> df = fetcher.summary_dataframe(results)

**Async batch fetch:**

>>> from secfin import SECClient, run_async_fetch
>>> client = SECClient("MyApp contact@email.com")
>>> results = run_async_fetch(client, ["AAPL", "MSFT", "GOOGL"])

Notes
-----
- SEC data is typically updated within 24 hours of a company filing.
- XBRL taxonomy varies between companies; some metrics may be unavailable.
- Financial values are in the units reported (typically USD, not thousands).

See Also
--------
SEC EDGAR API: https://www.sec.gov/edgar/sec-api-documentation
XBRL US GAAP Taxonomy: https://xbrl.us/home/filers/sec-reporting/taxonomies/

Version
-------
{version}
"""

__version__ = "1.0.0"

from .client import SECClient
from .company import Company
from .financials import IncomeStatement, BalanceSheet, CashFlow, FinancialMetric
from .batch import BatchFetcher
from .indices import IndexProvider, SP500_TICKERS, NASDAQ100_TICKERS
from .earnings import EarningsCalendar, EarningsDate
from .cache import DiskCache
from .async_batch import AsyncBatchFetcher, run_async_fetch

__all__ = [
    # Core classes
    "SECClient",
    "Company",
    # Financial statements
    "IncomeStatement",
    "BalanceSheet",
    "CashFlow",
    "FinancialMetric",
    # Batch processing
    "BatchFetcher",
    "AsyncBatchFetcher",
    "run_async_fetch",
    # Index data
    "IndexProvider",
    "SP500_TICKERS",
    "NASDAQ100_TICKERS",
    # Earnings
    "EarningsCalendar",
    "EarningsDate",
    # Utilities
    "DiskCache",
]

# Update module docstring with version (replace directly to avoid f-string conflicts)
__doc__ = __doc__.replace("{version}", __version__)
