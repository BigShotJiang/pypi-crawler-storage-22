"""
Async batch processing for fetching financials for multiple companies.

This module provides asynchronous batch fetching capabilities using
asyncio and aiohttp. It enables concurrent requests while respecting
SEC rate limits, significantly improving performance when fetching
data for large ticker lists.

Classes
-------
AsyncFetchResult
    Data class containing fetch results for a single company.
AsyncBatchFetcher
    Async batch fetcher for concurrent company data retrieval.

Functions
---------
run_async_fetch
    Convenience function to run async fetch synchronously.

Examples
--------
Using asyncio directly:

>>> import asyncio
>>> from secfin import SECClient, AsyncBatchFetcher
>>> client = SECClient("MyApp contact@email.com")
>>> fetcher = AsyncBatchFetcher(client, max_concurrent=5)
>>> results = asyncio.run(fetcher.fetch_tickers(["AAPL", "MSFT", "GOOGL"]))

Using the sync wrapper:

>>> from secfin import SECClient, run_async_fetch
>>> client = SECClient("MyApp contact@email.com")
>>> results = run_async_fetch(client, ["AAPL", "MSFT", "GOOGL"])

Notes
-----
Async fetching is typically 3-5x faster than synchronous BatchFetcher
for large ticker lists, while still respecting SEC rate limits. The
speedup comes from overlapping network latency across multiple requests.

See Also
--------
BatchFetcher : Synchronous batch fetcher.
Company : Single company data access.
"""

import asyncio
import aiohttp
from typing import List, Dict, Any, Optional, Callable
from dataclasses import dataclass

from .client import SECClient
from .company import Company
from .indices import SP500_TICKERS, NASDAQ100_TICKERS


@dataclass
class AsyncFetchResult:
    """
    Result of an async fetch operation for a single company.

    Contains the financial data and status from attempting to fetch
    a company's SEC filings asynchronously.

    Attributes
    ----------
    ticker : str
        Stock ticker symbol that was fetched.
    name : str or None
        Company name if successful, None if failed.
    cik : str or None
        SEC CIK number if successful, None if failed.
    income_statement : IncomeStatement or None
        Parsed income statement if successful, None if failed.
    balance_sheet : BalanceSheet or None
        Parsed balance sheet if successful, None if failed.
    cash_flow : CashFlow or None
        Parsed cash flow statement if successful, None if failed.
    status : str
        Status indicator: ``"success"`` or ``"error"``.
    error : str or None
        Error message if failed, None if successful.

    Examples
    --------
    >>> result = results["AAPL"]
    >>> if result.status == "success":
    ...     print(f"{result.name}: ${result.income_statement.revenue.latest()['val']:,.0f}")
    ... else:
    ...     print(f"Failed: {result.error}")
    """
    ticker: str
    name: Optional[str]
    cik: Optional[str]
    income_statement: Any
    balance_sheet: Any
    cash_flow: Any
    status: str  # "success" or "error"
    error: Optional[str]


class AsyncBatchFetcher:
    """
    Async batch fetcher for improved performance with large ticker lists.

    Uses asyncio and aiohttp to make concurrent HTTP requests while
    respecting SEC rate limits. Provides significant speedup compared
    to synchronous BatchFetcher by overlapping network latency.

    Parameters
    ----------
    client : SECClient
        SEC API client instance. Used for configuration (User-Agent,
        rate limit, cache) but requests are made directly via aiohttp.
    max_concurrent : int, default=5
        Maximum number of concurrent requests. Higher values increase
        speed but may trigger SEC rate limiting. Recommended: 3-10.
    on_progress : callable, optional
        Progress callback function with signature:
        ``callback(current: int, total: int, ticker: str, status: str)``
        If None, prints progress to console.
    on_error : callable, optional
        Error callback function with signature:
        ``callback(ticker: str, error: Exception)``
        If None, prints errors to console.

    Attributes
    ----------
    client : SECClient
        The SEC API client being used.
    max_concurrent : int
        Maximum concurrent requests.
    on_progress : callable
        Progress callback function.
    on_error : callable
        Error callback function.

    Examples
    --------
    Basic async usage:

    >>> import asyncio
    >>> from secfin import SECClient, AsyncBatchFetcher
    >>> client = SECClient("MyApp contact@email.com")
    >>> fetcher = AsyncBatchFetcher(client, max_concurrent=5)
    >>> results = asyncio.run(fetcher.fetch_tickers(["AAPL", "MSFT"]))
    >>> for ticker, result in results.items():
    ...     if result.status == "success":
    ...         print(f"{ticker}: {result.name}")

    With custom progress callback:

    >>> def my_progress(current, total, ticker, status):
    ...     print(f"[{current}/{total}] {ticker}")
    ...
    >>> fetcher = AsyncBatchFetcher(client, on_progress=my_progress)
    >>> results = asyncio.run(fetcher.fetch_sp500())

    Fetch NASDAQ 100:

    >>> results = asyncio.run(fetcher.fetch_nasdaq100())
    >>> successful = sum(1 for r in results.values() if r.status == "success")
    >>> print(f"Successfully fetched {successful} companies")

    Notes
    -----
    **Performance**

    AsyncBatchFetcher is typically 3-5x faster than synchronous
    BatchFetcher for large ticker lists. The exact speedup depends
    on network conditions and the ``max_concurrent`` setting.

    **Rate Limiting**

    Each request includes a delay based on the client's rate_limit
    setting. With ``max_concurrent=5`` and ``rate_limit=0.1``, you'll
    make approximately 10 requests per second (the SEC's limit).

    **Caching**

    AsyncBatchFetcher uses the same cache as the SECClient. Cached
    responses are returned immediately without making network requests.

    **Memory Usage**

    All results are kept in memory until the batch completes. For
    very large batches (1000+ tickers), monitor memory usage.

    See Also
    --------
    BatchFetcher : Synchronous batch fetcher.
    run_async_fetch : Convenience function for synchronous callers.
    """

    BASE_URL = "https://data.sec.gov"

    def __init__(
        self,
        client: SECClient,
        max_concurrent: int = 5,
        on_progress: Optional[Callable] = None,
        on_error: Optional[Callable] = None,
    ):
        self.client = client
        self.max_concurrent = max_concurrent
        self.on_progress = on_progress or self._default_progress
        self.on_error = on_error or self._default_error
        self._semaphore: Optional[asyncio.Semaphore] = None
        self._progress_lock: Optional[asyncio.Lock] = None
        self._current_count = 0
        self._total_count = 0

    def _default_progress(self, current: int, total: int, ticker: str, status: str):
        """
        Default progress callback - prints to console.

        Parameters
        ----------
        current : int
            Current progress count.
        total : int
            Total number of tickers.
        ticker : str
            Current ticker being processed.
        status : str
            Status message ("OK" or error description).
        """
        pct = (current / total) * 100
        print(f"[{current}/{total}] ({pct:.1f}%) {ticker}: {status}")

    def _default_error(self, ticker: str, error: Exception):
        """
        Default error callback - prints to console.

        Parameters
        ----------
        ticker : str
            Ticker that failed.
        error : Exception
            The exception that occurred.
        """
        print(f"ERROR {ticker}: {error}")

    async def _fetch_company_facts(
        self,
        session: aiohttp.ClientSession,
        cik: str
    ) -> dict:
        """
        Fetch company facts from SEC API asynchronously.

        Parameters
        ----------
        session : aiohttp.ClientSession
            Active aiohttp session for making requests.
        cik : str
            Company CIK number.

        Returns
        -------
        dict
            Company facts data from SEC API.
        """
        cik_padded = cik.zfill(10)
        url = f"{self.BASE_URL}/api/xbrl/companyfacts/CIK{cik_padded}.json"

        # Check cache first
        cached = self.client._cache.get(url)
        if cached is not None:
            return cached

        async with self._semaphore:
            # Rate limiting delay
            await asyncio.sleep(self.client.rate_limit)

            async with session.get(url) as response:
                response.raise_for_status()
                data = await response.json()

                # Cache the response
                self.client._cache.set(url, data)

                return data

    async def _fetch_single(
        self,
        session: aiohttp.ClientSession,
        ticker: str,
        period: str = "annual"
    ) -> AsyncFetchResult:
        """
        Fetch financials for a single company asynchronously.

        Parameters
        ----------
        session : aiohttp.ClientSession
            Active aiohttp session.
        ticker : str
            Stock ticker symbol.
        period : str
            "annual" or "quarterly".

        Returns
        -------
        AsyncFetchResult
            Result containing financial data or error info.
        """
        from .parser import parse_income_statement, parse_balance_sheet, parse_cash_flow

        try:
            # Get CIK (use sync client's mapping)
            cik = self.client.get_cik(ticker)

            # Fetch facts
            facts = await self._fetch_company_facts(session, cik)

            # Parse financial statements
            income = parse_income_statement(facts, period)
            balance = parse_balance_sheet(facts, period)
            cashflow = parse_cash_flow(facts, period)

            result = AsyncFetchResult(
                ticker=ticker,
                name=facts.get("entityName"),
                cik=cik,
                income_statement=income,
                balance_sheet=balance,
                cash_flow=cashflow,
                status="success",
                error=None
            )

        except Exception as e:
            result = AsyncFetchResult(
                ticker=ticker,
                name=None,
                cik=None,
                income_statement=None,
                balance_sheet=None,
                cash_flow=None,
                status="error",
                error=str(e)
            )
            self.on_error(ticker, e)

        # Update progress
        async with self._progress_lock:
            self._current_count += 1
            status = "OK" if result.status == "success" else f"FAILED: {result.error}"
            self.on_progress(self._current_count, self._total_count, ticker, status)

        return result

    async def fetch_tickers(
        self,
        tickers: List[str],
        period: str = "annual"
    ) -> Dict[str, AsyncFetchResult]:
        """
        Fetch financials for a list of tickers asynchronously.

        Makes concurrent requests for all tickers while respecting rate
        limits. Progress is reported via the configured callback.

        Parameters
        ----------
        tickers : list of str
            List of ticker symbols to fetch (e.g., ["AAPL", "MSFT"]).
        period : str, default="annual"
            Filing period type:

            - ``"annual"`` : Data from 10-K filings
            - ``"quarterly"`` : Data from 10-Q filings

        Returns
        -------
        dict
            Dictionary mapping ticker to AsyncFetchResult.

        Examples
        --------
        >>> import asyncio
        >>> results = asyncio.run(fetcher.fetch_tickers(["AAPL", "MSFT"]))
        >>> for ticker, result in results.items():
        ...     if result.status == "success":
        ...         print(f"{ticker}: {result.name}")
        """
        self._semaphore = asyncio.Semaphore(self.max_concurrent)
        self._progress_lock = asyncio.Lock()
        self._current_count = 0
        self._total_count = len(tickers)

        headers = {
            "User-Agent": self.client.user_agent,
            "Accept": "application/json",
        }

        async with aiohttp.ClientSession(headers=headers) as session:
            tasks = [
                self._fetch_single(session, ticker, period)
                for ticker in tickers
            ]
            results = await asyncio.gather(*tasks)

        return {r.ticker: r for r in results}

    async def fetch_sp500(self, period: str = "annual") -> Dict[str, AsyncFetchResult]:
        """
        Fetch financials for all S&P 500 companies asynchronously.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type (``"annual"`` or ``"quarterly"``).

        Returns
        -------
        dict
            Dictionary mapping ticker to AsyncFetchResult.

        Examples
        --------
        >>> results = asyncio.run(fetcher.fetch_sp500())
        >>> successful = [r for r in results.values() if r.status == "success"]
        >>> print(f"Fetched {len(successful)} companies successfully")
        """
        return await self.fetch_tickers(SP500_TICKERS, period)

    async def fetch_nasdaq100(self, period: str = "annual") -> Dict[str, AsyncFetchResult]:
        """
        Fetch financials for all NASDAQ 100 companies asynchronously.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type (``"annual"`` or ``"quarterly"``).

        Returns
        -------
        dict
            Dictionary mapping ticker to AsyncFetchResult.

        Examples
        --------
        >>> results = asyncio.run(fetcher.fetch_nasdaq100())
        >>> for ticker, result in results.items():
        ...     if result.status == "success":
        ...         rev = result.income_statement.revenue.latest()
        ...         print(f"{ticker}: ${rev['val']:,.0f}")
        """
        return await self.fetch_tickers(NASDAQ100_TICKERS, period)

    def to_dict(self, result: AsyncFetchResult) -> Dict[str, Any]:
        """
        Convert AsyncFetchResult to dictionary format.

        Useful for serialization or compatibility with code expecting
        dictionary results like those from BatchFetcher.

        Parameters
        ----------
        result : AsyncFetchResult
            Result object to convert.

        Returns
        -------
        dict
            Dictionary with same keys as BatchFetcher results.

        Examples
        --------
        >>> result = results["AAPL"]
        >>> data = fetcher.to_dict(result)
        >>> print(data.keys())
        dict_keys(['ticker', 'name', 'cik', 'income_statement', ...])
        """
        return {
            "ticker": result.ticker,
            "name": result.name,
            "cik": result.cik,
            "income_statement": result.income_statement,
            "balance_sheet": result.balance_sheet,
            "cash_flow": result.cash_flow,
            "status": result.status,
            "error": result.error,
        }


def run_async_fetch(
    client: SECClient,
    tickers: List[str],
    period: str = "annual",
    max_concurrent: int = 5,
    on_progress: Optional[Callable] = None
) -> Dict[str, Dict[str, Any]]:
    """
    Convenience function to run async fetch synchronously.

    Wraps AsyncBatchFetcher in asyncio.run() for easy use from
    synchronous code. Returns dictionary format results compatible
    with BatchFetcher.

    Parameters
    ----------
    client : SECClient
        SEC API client instance.
    tickers : list of str
        List of ticker symbols to fetch.
    period : str, default="annual"
        Filing period type (``"annual"`` or ``"quarterly"``).
    max_concurrent : int, default=5
        Maximum concurrent requests. Higher values increase speed
        but may trigger rate limiting. Recommended: 3-10.
    on_progress : callable, optional
        Progress callback with signature:
        ``callback(current: int, total: int, ticker: str, status: str)``

    Returns
    -------
    dict
        Dictionary mapping ticker to result dictionary. Each result has:

        - ``"ticker"`` : Ticker symbol
        - ``"name"`` : Company name (None if failed)
        - ``"cik"`` : CIK number (None if failed)
        - ``"income_statement"`` : IncomeStatement object
        - ``"balance_sheet"`` : BalanceSheet object
        - ``"cash_flow"`` : CashFlow object
        - ``"status"`` : "success" or "error"
        - ``"error"`` : Error message if failed

    Examples
    --------
    Basic usage:

    >>> from secfin import SECClient, run_async_fetch
    >>> client = SECClient("MyApp contact@email.com")
    >>> results = run_async_fetch(client, ["AAPL", "MSFT", "GOOGL"])
    >>> for ticker, data in results.items():
    ...     if data['status'] == 'success':
    ...         print(f"{ticker}: {data['name']}")

    With progress tracking:

    >>> def progress(current, total, ticker, status):
    ...     print(f"[{current}/{total}] {ticker}: {status}")
    ...
    >>> results = run_async_fetch(
    ...     client,
    ...     ["AAPL", "MSFT", "GOOGL", "AMZN", "META"],
    ...     max_concurrent=3,
    ...     on_progress=progress
    ... )

    Notes
    -----
    This function creates a new event loop via ``asyncio.run()``. If you're
    already in an async context, use AsyncBatchFetcher directly instead.

    See Also
    --------
    AsyncBatchFetcher : Full async batch fetcher class.
    BatchFetcher : Synchronous batch fetcher.
    """
    fetcher = AsyncBatchFetcher(
        client,
        max_concurrent=max_concurrent,
        on_progress=on_progress
    )

    results = asyncio.run(fetcher.fetch_tickers(tickers, period))

    # Convert to dict format
    return {ticker: fetcher.to_dict(result) for ticker, result in results.items()}
