"""
Batch processing for fetching financials for multiple companies.

This module provides the BatchFetcher class for efficiently fetching
financial data for multiple companies, with support for major stock
market indices like S&P 500 and NASDAQ 100.

Classes
-------
BatchFetcher
    Synchronous batch fetcher for multiple companies.

Examples
--------
Fetch data for a custom list of tickers:

>>> from secfin import SECClient, BatchFetcher
>>> client = SECClient("MyApp contact@email.com")
>>> fetcher = BatchFetcher(client)
>>> results = fetcher.fetch_tickers(["AAPL", "MSFT", "GOOGL"])

Fetch all S&P 500 companies:

>>> results = fetcher.fetch_sp500()
>>> print(f"Fetched {len(results)} companies")

Export to DataFrame:

>>> df = fetcher.summary_dataframe(results)
>>> print(df.head())

Notes
-----
BatchFetcher uses synchronous requests with automatic rate limiting to
respect SEC's 10 requests/second limit. For faster fetching of large
ticker lists, consider using AsyncBatchFetcher instead.

See Also
--------
AsyncBatchFetcher : Async version for faster concurrent fetching.
Company : Single company data access.
"""

import time
from typing import List, Dict, Any, Optional, Callable
import pandas as pd

from .client import SECClient
from .company import Company
from .indices import IndexProvider, SP500_TICKERS, NASDAQ100_TICKERS


class BatchFetcher:
    """
    Fetch financial data for multiple companies efficiently.

    BatchFetcher handles rate limiting, error recovery, and progress
    tracking when fetching financial statements for many companies.
    It provides methods for fetching index constituents (S&P 500,
    NASDAQ 100) or custom ticker lists.

    Parameters
    ----------
    client : SECClient
        SEC API client instance with valid User-Agent.
    max_workers : int, default=1
        Number of concurrent workers. Keep at 1 to respect SEC rate limits.
        For concurrent fetching, use AsyncBatchFetcher instead.
    on_progress : callable, optional
        Progress callback function with signature:
        ``callback(current: int, total: int, ticker: str, status: str)``
        If None, prints progress to console.
    on_error : callable, optional
        Error callback function with signature:
        ``callback(ticker: str, error: Exception)``
        If None, prints errors to console.

    Attributes
    ----------
    client : SECClient
        The SEC API client being used.
    max_workers : int
        Number of concurrent workers (usually 1).
    on_progress : callable
        Progress callback function.
    on_error : callable
        Error callback function.

    Examples
    --------
    Basic usage with progress tracking:

    >>> from secfin import SECClient, BatchFetcher
    >>> client = SECClient("MyApp contact@email.com")
    >>> fetcher = BatchFetcher(client)
    >>> results = fetcher.fetch_tickers(["AAPL", "MSFT"])
    [1/2] (50.0%) AAPL: OK
    [2/2] (100.0%) MSFT: OK

    Custom progress callback:

    >>> def my_progress(current, total, ticker, status):
    ...     print(f"Progress: {current}/{total} - {ticker}")
    ...
    >>> fetcher = BatchFetcher(client, on_progress=my_progress)
    >>> results = fetcher.fetch_nasdaq100()

    Fetch S&P 500 with error handling:

    >>> def on_error(ticker, error):
    ...     print(f"Failed: {ticker} - {error}")
    ...
    >>> fetcher = BatchFetcher(client, on_error=on_error)
    >>> results = fetcher.fetch_sp500()

    Export results to DataFrame:

    >>> df = fetcher.summary_dataframe(results)
    >>> print(df.columns)
    Index(['ticker', 'name', 'revenue', 'net_income', 'eps', ...])

    Get specific metric across all companies:

    >>> revenue_df = fetcher.to_dataframe(results, "income_statement", "revenue")
    >>> print(revenue_df.head())

    Notes
    -----
    **Rate Limiting**

    BatchFetcher automatically adds a 0.15 second delay between requests
    to respect SEC's rate limiting requirements. For large batches, this
    means fetching will take time proportional to the number of tickers.

    **Error Handling**

    Failed fetches are recorded in the results with ``status="error"`` and
    the error message in the ``error`` field. The fetcher continues with
    remaining tickers even if some fail.

    **Memory Considerations**

    When fetching large indices (S&P 500), results are kept in memory.
    Each company's data is typically 1-10 MB, so fetching 500 companies
    may require several GB of memory.

    See Also
    --------
    AsyncBatchFetcher : Async version for faster concurrent fetching.
    Company : Single company data access.
    run_async_fetch : Convenience function for async fetching.
    """

    def __init__(
        self,
        client: SECClient,
        max_workers: int = 1,
        on_progress: Optional[Callable] = None,
        on_error: Optional[Callable] = None,
    ):
        self.client = client
        self.max_workers = max_workers
        self.on_progress = on_progress or self._default_progress
        self.on_error = on_error or self._default_error
        self._index_provider = IndexProvider()

    def _default_progress(self, current: int, total: int, ticker: str, status: str):
        """
        Default progress callback - prints to console.

        Parameters
        ----------
        current : int
            Current progress count.
        total : int
            Total number of tickers.
        ticker : str
            Current ticker being processed.
        status : str
            Status message ("OK" or error description).
        """
        pct = (current / total) * 100
        print(f"[{current}/{total}] ({pct:.1f}%) {ticker}: {status}")

    def _default_error(self, ticker: str, error: Exception):
        """
        Default error callback - prints to console.

        Parameters
        ----------
        ticker : str
            Ticker that failed.
        error : Exception
            The exception that occurred.
        """
        print(f"ERROR {ticker}: {error}")

    def _fetch_single(self, ticker: str, period: str = "annual") -> Dict[str, Any]:
        """
        Fetch financials for a single company.

        Parameters
        ----------
        ticker : str
            Stock ticker symbol.
        period : str
            "annual" or "quarterly".

        Returns
        -------
        dict
            Result dictionary with financial data or error info.
        """
        try:
            company = Company(ticker, self.client)
            return {
                "ticker": ticker,
                "name": company.name,
                "cik": company.cik,
                "income_statement": company.get_income_statement(period),
                "balance_sheet": company.get_balance_sheet(period),
                "cash_flow": company.get_cash_flow(period),
                "status": "success",
                "error": None,
            }
        except Exception as e:
            return {
                "ticker": ticker,
                "name": None,
                "cik": None,
                "income_statement": None,
                "balance_sheet": None,
                "cash_flow": None,
                "status": "error",
                "error": str(e),
            }

    def fetch_tickers(
        self,
        tickers: List[str],
        period: str = "annual",
    ) -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for a list of tickers.

        Fetches income statement, balance sheet, and cash flow statement
        for each ticker in the list. Progress and errors are reported
        via the configured callbacks.

        Parameters
        ----------
        tickers : list of str
            List of ticker symbols to fetch (e.g., ["AAPL", "MSFT", "GOOGL"]).
        period : str, default="annual"
            Filing period type:

            - ``"annual"`` : Data from 10-K filings
            - ``"quarterly"`` : Data from 10-Q filings

        Returns
        -------
        dict
            Dictionary mapping ticker to result dictionary. Each result has:

            - ``"ticker"`` : Ticker symbol
            - ``"name"`` : Company name (None if failed)
            - ``"cik"`` : CIK number (None if failed)
            - ``"income_statement"`` : IncomeStatement object (None if failed)
            - ``"balance_sheet"`` : BalanceSheet object (None if failed)
            - ``"cash_flow"`` : CashFlow object (None if failed)
            - ``"status"`` : "success" or "error"
            - ``"error"`` : Error message if failed, else None

        Examples
        --------
        >>> results = fetcher.fetch_tickers(["AAPL", "MSFT", "INVALID"])
        >>> for ticker, data in results.items():
        ...     if data['status'] == 'success':
        ...         revenue = data['income_statement'].revenue.latest()
        ...         print(f"{ticker}: ${revenue['val']:,.0f}")
        ...     else:
        ...         print(f"{ticker}: Failed - {data['error']}")
        """
        results = {}
        total = len(tickers)

        for i, ticker in enumerate(tickers, 1):
            result = self._fetch_single(ticker, period)
            results[ticker] = result

            status = "OK" if result["status"] == "success" else f"FAILED: {result['error']}"
            self.on_progress(i, total, ticker, status)

            if result["status"] == "error":
                self.on_error(ticker, Exception(result["error"]))

            # Small delay between requests
            time.sleep(0.15)

        return results

    def fetch_sp500(self, period: str = "annual") -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for all S&P 500 companies.

        Fetches financial data for approximately 500 companies in the
        S&P 500 index. This operation may take significant time due to
        rate limiting.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type (``"annual"`` or ``"quarterly"``).

        Returns
        -------
        dict
            Dictionary mapping ticker to financial data (see ``fetch_tickers``).

        Examples
        --------
        >>> results = fetcher.fetch_sp500()
        >>> successful = [t for t, r in results.items() if r['status'] == 'success']
        >>> print(f"Successfully fetched {len(successful)} companies")

        Notes
        -----
        Fetching all S&P 500 companies takes approximately 1-2 hours due
        to rate limiting. Consider using AsyncBatchFetcher for faster
        concurrent fetching, or fetching a subset of tickers.

        See Also
        --------
        fetch_nasdaq100 : Fetch NASDAQ 100 (smaller, faster).
        fetch_tickers : Fetch custom list of tickers.
        """
        tickers = self._index_provider.get_sp500()
        if not tickers:
            tickers = SP500_TICKERS
        return self.fetch_tickers(tickers, period)

    def fetch_nasdaq100(self, period: str = "annual") -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for all NASDAQ 100 companies.

        Fetches financial data for approximately 100 companies in the
        NASDAQ 100 index.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type (``"annual"`` or ``"quarterly"``).

        Returns
        -------
        dict
            Dictionary mapping ticker to financial data (see ``fetch_tickers``).

        Examples
        --------
        >>> results = fetcher.fetch_nasdaq100()
        >>> df = fetcher.summary_dataframe(results)
        >>> top_revenue = df.nlargest(10, 'revenue')
        >>> print(top_revenue[['ticker', 'name', 'revenue']])

        See Also
        --------
        fetch_sp500 : Fetch S&P 500 (larger index).
        fetch_tickers : Fetch custom list of tickers.
        """
        tickers = self._index_provider.get_nasdaq100()
        if not tickers:
            tickers = NASDAQ100_TICKERS
        return self.fetch_tickers(tickers, period)

    def fetch_russell2000(
        self,
        tickers: Optional[List[str]] = None,
        period: str = "annual",
    ) -> Dict[str, Dict[str, Any]]:
        """
        Fetch financials for Russell 2000 companies.

        Fetches financial data for Russell 2000 small-cap companies.
        Unlike S&P 500 and NASDAQ 100, Russell 2000 constituents must
        be provided as the list is not freely available.

        Parameters
        ----------
        tickers : list of str, optional
            List of Russell 2000 ticker symbols. Required unless an
            IndexProvider with Russell 2000 data is available.
        period : str, default="annual"
            Filing period type (``"annual"`` or ``"quarterly"``).

        Returns
        -------
        dict
            Dictionary mapping ticker to financial data (see ``fetch_tickers``).

        Raises
        ------
        ValueError
            If tickers are not provided and IndexProvider doesn't have
            Russell 2000 data.

        Examples
        --------
        >>> # Load your Russell 2000 ticker list
        >>> russell_tickers = ["ABCB", "ACIW", "ACRE", ...]  # ~2000 tickers
        >>> results = fetcher.fetch_russell2000(tickers=russell_tickers)

        Notes
        -----
        Russell 2000 constituent data requires a data subscription.
        You must provide your own list of tickers obtained from a
        licensed data provider.

        See Also
        --------
        fetch_sp500 : Fetch S&P 500 (free constituent list).
        fetch_nasdaq100 : Fetch NASDAQ 100 (free constituent list).
        """
        if tickers is None:
            tickers = self._index_provider.get_russell2000()
        if not tickers:
            raise ValueError(
                "Russell 2000 tickers not available. "
                "Please provide a list of tickers."
            )
        return self.fetch_tickers(tickers, period)

    def to_dataframe(
        self,
        results: Dict[str, Dict[str, Any]],
        statement: str = "income_statement",
        metric: str = "revenue",
    ) -> pd.DataFrame:
        """
        Convert batch results to a DataFrame for a specific metric.

        Creates a DataFrame with tickers as rows and dates as columns,
        showing the historical values of a single metric across all
        successfully fetched companies.

        Parameters
        ----------
        results : dict
            Results dictionary from ``fetch_*`` methods.
        statement : str, default="income_statement"
            Financial statement to extract from:

            - ``"income_statement"`` : Revenue, income, EPS, etc.
            - ``"balance_sheet"`` : Assets, liabilities, equity, etc.
            - ``"cash_flow"`` : Cash flows, CapEx, dividends, etc.

        metric : str, default="revenue"
            Metric attribute name to extract. Must match an attribute
            of the statement class (e.g., "revenue", "net_income",
            "total_assets", "operating_cash_flow").

        Returns
        -------
        pd.DataFrame
            DataFrame with:

            - Index: Ticker symbols
            - Columns: Dates (period end dates)
            - Values: Metric values for each ticker/date combination

        Examples
        --------
        Get revenue across all companies:

        >>> revenue_df = fetcher.to_dataframe(results, "income_statement", "revenue")
        >>> print(revenue_df.head())

        Get net income:

        >>> ni_df = fetcher.to_dataframe(results, "income_statement", "net_income")

        Get total assets from balance sheet:

        >>> assets_df = fetcher.to_dataframe(results, "balance_sheet", "total_assets")

        See Also
        --------
        summary_dataframe : Get summary with latest values for key metrics.
        """
        data = {}

        for ticker, result in results.items():
            if result["status"] != "success":
                continue

            stmt = result.get(statement)
            if stmt is None:
                continue

            metric_obj = getattr(stmt, metric, None)
            if metric_obj is None or not metric_obj.values:
                continue

            # Convert to series
            series = metric_obj.to_series()
            data[ticker] = series

        if not data:
            return pd.DataFrame()

        df = pd.DataFrame(data).T
        df.index.name = "ticker"
        return df

    def summary_dataframe(
        self,
        results: Dict[str, Dict[str, Any]],
    ) -> pd.DataFrame:
        """
        Create a summary DataFrame with latest values for key metrics.

        Builds a DataFrame with one row per company, containing the most
        recent values for important financial metrics from all three
        financial statements.

        Parameters
        ----------
        results : dict
            Results dictionary from ``fetch_*`` methods.

        Returns
        -------
        pd.DataFrame
            Summary DataFrame with columns:

            - ``ticker`` : Stock ticker symbol
            - ``name`` : Company name
            - ``revenue`` : Most recent revenue
            - ``net_income`` : Most recent net income
            - ``eps`` : Most recent diluted EPS
            - ``total_assets`` : Most recent total assets
            - ``cash`` : Most recent cash and equivalents
            - ``debt`` : Most recent long-term debt
            - ``operating_cf`` : Most recent operating cash flow
            - ``free_cf`` : Most recent free cash flow

        Examples
        --------
        >>> results = fetcher.fetch_nasdaq100()
        >>> df = fetcher.summary_dataframe(results)
        >>> print(df.head())

        Find companies with highest profit margins:

        >>> df['net_margin'] = df['net_income'] / df['revenue']
        >>> top_margin = df.nlargest(10, 'net_margin')
        >>> print(top_margin[['ticker', 'name', 'net_margin']])

        Export to CSV:

        >>> df.to_csv("nasdaq100_summary.csv", index=False)

        See Also
        --------
        to_dataframe : Get historical data for a specific metric.
        """
        rows = []

        for ticker, result in results.items():
            if result["status"] != "success":
                continue

            row = {"ticker": ticker, "name": result.get("name", "")}

            # Income statement metrics
            income = result.get("income_statement")
            if income:
                if income.revenue.latest():
                    row["revenue"] = income.revenue.latest().get("val")
                if income.net_income.latest():
                    row["net_income"] = income.net_income.latest().get("val")
                if income.eps_diluted.latest():
                    row["eps"] = income.eps_diluted.latest().get("val")

            # Balance sheet metrics
            balance = result.get("balance_sheet")
            if balance:
                if balance.total_assets.latest():
                    row["total_assets"] = balance.total_assets.latest().get("val")
                if balance.cash.latest():
                    row["cash"] = balance.cash.latest().get("val")
                if balance.long_term_debt.latest():
                    row["debt"] = balance.long_term_debt.latest().get("val")

            # Cash flow metrics
            cashflow = result.get("cash_flow")
            if cashflow:
                if cashflow.operating_cash_flow.latest():
                    row["operating_cf"] = cashflow.operating_cash_flow.latest().get("val")
                if cashflow.free_cash_flow.latest():
                    row["free_cf"] = cashflow.free_cash_flow.latest().get("val")

            rows.append(row)

        return pd.DataFrame(rows)
