"""
Simple disk-based caching for SEC API responses.

This module provides the DiskCache class for caching SEC EDGAR API
responses to disk. Caching reduces redundant API calls and improves
performance, especially when working with the same companies repeatedly.

Classes
-------
DiskCache
    JSON file-based cache with time-to-live (TTL) support.

Examples
--------
Basic cache usage (typically used internally by SECClient):

>>> from secfin.cache import DiskCache
>>> cache = DiskCache(ttl=3600)  # 1 hour TTL
>>> cache.set("https://api.example.com/data", {"key": "value"})
>>> data = cache.get("https://api.example.com/data")
>>> print(data)
{'key': 'value'}

Cache management:

>>> stats = cache.stats()
>>> print(f"Cache: {stats['files']} files, {stats['size_mb']:.1f} MB")
>>> cache.clear_expired()  # Remove stale entries
>>> cache.clear()  # Remove all entries

Notes
-----
The cache stores responses as JSON files in a configurable directory.
Each URL is hashed to create a unique filename. Cache entries include
a timestamp for TTL expiration checking.

Default cache location: ``~/.secfin/cache``

See Also
--------
SECClient : Main API client that uses DiskCache internally.
"""

import json
import hashlib
import time
from pathlib import Path
from typing import Optional, Any, Dict


class DiskCache:
    """
    Simple JSON file-based cache with TTL support.

    DiskCache provides persistent caching of API responses to reduce
    redundant network requests. Each cached item is stored as a JSON
    file with an associated timestamp for TTL-based expiration.

    Parameters
    ----------
    cache_dir : str or Path, optional
        Directory to store cache files. If not specified, defaults to
        ``~/.secfin/cache``. The directory is created if it doesn't exist.
    ttl : int, default=86400
        Time-to-live in seconds. Cached items older than this are
        considered expired. Default is 24 hours (86400 seconds).
    enabled : bool, default=True
        Whether caching is enabled. When False, ``get()`` always returns
        None and ``set()`` does nothing.

    Attributes
    ----------
    cache_dir : Path
        Directory where cache files are stored.
    ttl : int
        Time-to-live in seconds for cached items.
    enabled : bool
        Whether caching is currently enabled.

    Examples
    --------
    Create a cache with custom settings:

    >>> cache = DiskCache(cache_dir="/tmp/my_cache", ttl=7200)  # 2 hours
    >>> cache.set("https://api.example.com/data", {"result": 42})
    >>> data = cache.get("https://api.example.com/data")
    >>> print(data)
    {'result': 42}

    Disable caching:

    >>> cache = DiskCache(enabled=False)
    >>> cache.set("url", {"data": 1})  # Does nothing
    >>> cache.get("url")  # Returns None
    None

    Check cache statistics:

    >>> stats = cache.stats()
    >>> print(f"Files: {stats['files']}, Size: {stats['size_mb']:.2f} MB")
    Files: 15, Size: 4.77 MB

    Clear expired entries:

    >>> deleted = cache.clear_expired()
    >>> print(f"Removed {deleted} expired cache files")

    Notes
    -----
    **Cache Key Generation**

    URLs are hashed using MD5 to generate cache keys. This ensures
    consistent, filesystem-safe filenames regardless of URL length
    or special characters.

    **File Format**

    Each cache file is a JSON object with:

    - ``timestamp``: Unix timestamp when the data was cached
    - ``url``: Original URL for debugging purposes
    - ``data``: The cached response data

    **Thread Safety**

    DiskCache is not thread-safe. If using from multiple threads,
    external synchronization should be used, though in practice
    concurrent writes to different cache keys work fine.

    **Error Handling**

    Cache operations fail silently on I/O errors to prevent cache
    issues from breaking the main application. A failed cache write
    simply means the data won't be cached.

    See Also
    --------
    SECClient : Uses DiskCache for caching API responses.
    """

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        ttl: int = 86400,
        enabled: bool = True
    ):
        self.ttl = ttl
        self.enabled = enabled

        if cache_dir:
            self.cache_dir = Path(cache_dir)
        else:
            self.cache_dir = Path.home() / ".secfin" / "cache"

        if self.enabled:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _get_cache_key(self, url: str) -> str:
        """
        Generate a cache key from URL.

        Creates an MD5 hash of the URL to use as a filesystem-safe
        cache key.

        Parameters
        ----------
        url : str
            The URL to hash.

        Returns
        -------
        str
            32-character hexadecimal hash string.
        """
        return hashlib.md5(url.encode()).hexdigest()

    def _get_cache_path(self, key: str) -> Path:
        """
        Get the file path for a cache key.

        Parameters
        ----------
        key : str
            Cache key (MD5 hash).

        Returns
        -------
        Path
            Full path to the cache file.
        """
        return self.cache_dir / f"{key}.json"

    def get(self, url: str) -> Optional[Any]:
        """
        Get cached data for a URL.

        Retrieves cached data if it exists and hasn't expired based on
        the configured TTL. Expired entries are automatically deleted.

        Parameters
        ----------
        url : str
            The URL to look up in the cache.

        Returns
        -------
        Any or None
            The cached data if found and valid, None otherwise.
            Returns None if:

            - Caching is disabled
            - URL is not in cache
            - Cache entry has expired
            - Cache file is corrupted

        Examples
        --------
        >>> data = cache.get("https://data.sec.gov/api/...")
        >>> if data is not None:
        ...     print("Cache hit!")
        ... else:
        ...     print("Cache miss - fetching from API")
        """
        if not self.enabled:
            return None

        key = self._get_cache_key(url)
        cache_path = self._get_cache_path(key)

        if not cache_path.exists():
            return None

        try:
            with open(cache_path, 'r') as f:
                cached = json.load(f)

            # Check TTL
            if time.time() - cached.get("timestamp", 0) > self.ttl:
                cache_path.unlink()  # Delete expired cache
                return None

            return cached.get("data")
        except (json.JSONDecodeError, IOError):
            return None

    def set(self, url: str, data: Any) -> None:
        """
        Cache data for a URL.

        Stores the data in a JSON file with a timestamp for TTL checking.
        Fails silently if the file cannot be written.

        Parameters
        ----------
        url : str
            The URL to use as the cache key.
        data : Any
            The data to cache. Must be JSON-serializable (dicts, lists,
            strings, numbers, booleans, None).

        Examples
        --------
        >>> response = {"cik": 320193, "entityName": "Apple Inc."}
        >>> cache.set("https://data.sec.gov/api/...", response)

        Notes
        -----
        If caching is disabled, this method does nothing. I/O errors
        are silently ignored to prevent cache issues from affecting
        the main application.
        """
        if not self.enabled:
            return

        key = self._get_cache_key(url)
        cache_path = self._get_cache_path(key)

        try:
            with open(cache_path, 'w') as f:
                json.dump({
                    "timestamp": time.time(),
                    "url": url,
                    "data": data
                }, f)
        except IOError:
            pass  # Silently fail if we can't write cache

    def clear(self) -> int:
        """
        Clear all cached data.

        Removes all cache files from the cache directory, regardless
        of whether they've expired.

        Returns
        -------
        int
            Number of cache files deleted.

        Examples
        --------
        >>> deleted = cache.clear()
        >>> print(f"Deleted {deleted} cached files")
        Deleted 15 cached files

        Notes
        -----
        Use this to force fresh data retrieval for all requests.
        Individual file deletion failures are silently ignored.
        """
        if not self.cache_dir.exists():
            return 0

        count = 0
        for cache_file in self.cache_dir.glob("*.json"):
            try:
                cache_file.unlink()
                count += 1
            except IOError:
                pass
        return count

    def clear_expired(self) -> int:
        """
        Clear only expired cache entries.

        Removes cache files that have exceeded the TTL, keeping valid
        cached data intact. Also removes corrupted cache files.

        Returns
        -------
        int
            Number of expired (or corrupted) cache files deleted.

        Examples
        --------
        >>> deleted = cache.clear_expired()
        >>> print(f"Removed {deleted} expired entries")
        Removed 3 expired entries

        Notes
        -----
        This is useful for periodic cache maintenance without losing
        all cached data. Consider calling this on application startup
        or on a schedule.
        """
        if not self.cache_dir.exists():
            return 0

        count = 0
        current_time = time.time()

        for cache_file in self.cache_dir.glob("*.json"):
            try:
                with open(cache_file, 'r') as f:
                    cached = json.load(f)

                if current_time - cached.get("timestamp", 0) > self.ttl:
                    cache_file.unlink()
                    count += 1
            except (json.JSONDecodeError, IOError):
                # Delete corrupted cache files
                try:
                    cache_file.unlink()
                    count += 1
                except IOError:
                    pass

        return count

    def stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns information about the current state of the cache,
        including file count and total size.

        Returns
        -------
        dict
            Cache statistics with keys:

            - ``files`` : Number of cache files
            - ``size_bytes`` : Total cache size in bytes
            - ``size_mb`` : Total cache size in megabytes (rounded to 2 decimals)

        Examples
        --------
        >>> stats = cache.stats()
        >>> print(f"Cache: {stats['files']} files, {stats['size_mb']:.1f} MB")
        Cache: 15 files, 4.8 MB

        >>> if stats['size_mb'] > 100:
        ...     print("Cache is getting large, consider clearing")
        """
        if not self.cache_dir.exists():
            return {"files": 0, "size_bytes": 0, "size_mb": 0.0}

        files = list(self.cache_dir.glob("*.json"))
        total_size = sum(f.stat().st_size for f in files)

        return {
            "files": len(files),
            "size_bytes": total_size,
            "size_mb": round(total_size / (1024 * 1024), 2)
        }
