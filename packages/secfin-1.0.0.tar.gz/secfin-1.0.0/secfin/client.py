"""
SEC EDGAR API client for fetching company financial data.

This module provides the core HTTP client for interacting with the SEC's
EDGAR database. It handles rate limiting, caching, and authentication
requirements.

The SEC requires all API users to provide a User-Agent header with contact
information. Failure to do so may result in blocked requests.

Classes
-------
SECClient
    HTTP client for SEC EDGAR API with rate limiting and caching.

Examples
--------
>>> from secfin import SECClient
>>> client = SECClient("MyApp contact@email.com")
>>> cik = client.get_cik("AAPL")
>>> facts = client.get_company_facts(cik)

Notes
-----
SEC Rate Limit: 10 requests per second maximum.
See: https://www.sec.gov/os/accessing-edgar-data
"""

import time
from typing import Optional, Union, List, Dict, Any
from pathlib import Path
import requests

from .cache import DiskCache


class SECClient:
    """
    HTTP client for SEC EDGAR API.

    Provides methods to fetch company data from SEC EDGAR with automatic
    rate limiting and response caching. SEC requires a User-Agent header
    identifying the application and providing contact information.

    Parameters
    ----------
    user_agent : str
        Required User-Agent string in format "AppName contact@email.com".
        SEC will block requests without proper identification.
    rate_limit : float, default=0.1
        Minimum seconds between requests. Default (0.1s) respects
        SEC's 10 requests/second limit.
    cache_enabled : bool, default=True
        Enable disk caching of API responses to reduce redundant calls.
    cache_ttl : int, default=86400
        Cache time-to-live in seconds. Default is 24 hours (86400s).
    cache_dir : str or Path, optional
        Custom cache directory. Default: ~/.secfin/cache

    Attributes
    ----------
    user_agent : str
        The User-Agent string used for requests.
    rate_limit : float
        Minimum seconds between requests.

    Raises
    ------
    ValueError
        If user_agent is empty or doesn't contain an email address.

    Examples
    --------
    >>> # Basic usage
    >>> client = SECClient("MyApp contact@email.com")
    >>> cik = client.get_cik("AAPL")
    >>> print(cik)
    0000320193

    >>> # Disable caching
    >>> client = SECClient("MyApp contact@email.com", cache_enabled=False)

    >>> # Custom cache TTL (1 hour)
    >>> client = SECClient("MyApp contact@email.com", cache_ttl=3600)

    >>> # View cache stats
    >>> print(client.cache_stats())
    {'files': 10, 'size_bytes': 5000000, 'size_mb': 4.77}

    Notes
    -----
    The SEC EDGAR API is free and does not require authentication beyond
    the User-Agent header. However, excessive requests may be rate-limited
    or blocked.

    See Also
    --------
    Company : High-level interface for accessing company financials.
    DiskCache : Cache implementation details.
    """

    BASE_URL = "https://data.sec.gov"
    COMPANY_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"

    def __init__(
        self,
        user_agent: str,
        rate_limit: float = 0.1,
        cache_enabled: bool = True,
        cache_ttl: int = 86400,
        cache_dir: Optional[Union[str, Path]] = None
    ):
        if not user_agent or "@" not in user_agent:
            raise ValueError(
                "SEC requires a User-Agent with contact info. "
                "Example: 'MyApp contact@email.com'"
            )
        self.user_agent = user_agent
        self.rate_limit = rate_limit
        self._last_request_time = 0.0
        self._session = requests.Session()
        self._session.headers.update({
            "User-Agent": user_agent,
            "Accept": "application/json",
        })
        self._ticker_to_cik: Optional[Dict[str, str]] = None
        self._cache = DiskCache(
            cache_dir=cache_dir,
            ttl=cache_ttl,
            enabled=cache_enabled
        )

    def _rate_limit_wait(self) -> None:
        """
        Wait if necessary to respect rate limit.

        Ensures minimum time between requests to comply with SEC's
        rate limiting requirements.
        """
        elapsed = time.time() - self._last_request_time
        if elapsed < self.rate_limit:
            time.sleep(self.rate_limit - elapsed)
        self._last_request_time = time.time()

    def _get(self, url: str, use_cache: bool = True) -> Dict[str, Any]:
        """
        Make a GET request with rate limiting and caching.

        Parameters
        ----------
        url : str
            The URL to fetch.
        use_cache : bool, default=True
            Whether to use cached response if available.

        Returns
        -------
        dict
            JSON response data.

        Raises
        ------
        requests.HTTPError
            If the request fails (404, 500, etc.).
        """
        # Check cache first
        if use_cache:
            cached = self._cache.get(url)
            if cached is not None:
                return cached

        # Make request with rate limiting
        self._rate_limit_wait()
        response = self._session.get(url)
        response.raise_for_status()
        data = response.json()

        # Cache the response
        if use_cache:
            self._cache.set(url, data)

        return data

    def _load_ticker_mapping(self) -> None:
        """
        Load the ticker to CIK mapping from SEC.

        Fetches and caches the complete mapping of stock ticker symbols
        to SEC CIK numbers. This is loaded lazily on first use.
        """
        if self._ticker_to_cik is None:
            data = self._get(self.COMPANY_TICKERS_URL)
            self._ticker_to_cik = {}
            for entry in data.values():
                ticker = entry.get("ticker", "").upper()
                cik = str(entry.get("cik_str", ""))
                if ticker and cik:
                    self._ticker_to_cik[ticker] = cik.zfill(10)

    def get_cik(self, ticker: str) -> str:
        """
        Get CIK number from ticker symbol.

        The CIK (Central Index Key) is the SEC's unique identifier for
        companies and individuals who file with the SEC.

        Parameters
        ----------
        ticker : str
            Stock ticker symbol (e.g., "AAPL", "MSFT").
            Case-insensitive.

        Returns
        -------
        str
            10-digit CIK number (zero-padded).

        Raises
        ------
        ValueError
            If ticker is not found in SEC database.

        Examples
        --------
        >>> client.get_cik("AAPL")
        '0000320193'

        >>> client.get_cik("msft")  # Case insensitive
        '0000789019'
        """
        self._load_ticker_mapping()
        ticker_upper = ticker.upper()
        if ticker_upper not in self._ticker_to_cik:
            raise ValueError(f"Ticker '{ticker}' not found in SEC database")
        return self._ticker_to_cik[ticker_upper]

    def get_company_facts(self, cik: str) -> Dict[str, Any]:
        """
        Fetch all XBRL facts for a company.

        Returns the complete set of financial data reported by the company
        to the SEC, including all historical values from 10-K and 10-Q
        filings.

        Parameters
        ----------
        cik : str
            Company CIK number. Will be zero-padded to 10 digits if needed.

        Returns
        -------
        dict
            Company facts data with structure:

            - ``cik``: Company CIK number
            - ``entityName``: Company name
            - ``facts``: Dict of taxonomies (us-gaap, dei, etc.)

            Each taxonomy contains concepts mapped to their units and values.

        Examples
        --------
        >>> facts = client.get_company_facts("320193")
        >>> print(facts['entityName'])
        Apple Inc.

        >>> # Access revenue data
        >>> revenue = facts['facts']['us-gaap']['Revenues']
        >>> print(revenue['units']['USD'][-1])  # Most recent value

        Notes
        -----
        Response size varies by company (typically 1-10 MB).
        Large companies with long histories have more data.
        """
        cik_padded = cik.zfill(10)
        url = f"{self.BASE_URL}/api/xbrl/companyfacts/CIK{cik_padded}.json"
        return self._get(url)

    def get_company_info(self, cik: str) -> Dict[str, Any]:
        """
        Get basic company information.

        A lightweight method to get just the company name and CIK
        without fetching all financial data.

        Parameters
        ----------
        cik : str
            Company CIK number.

        Returns
        -------
        dict
            Dictionary with keys:

            - ``cik``: Company CIK number (int)
            - ``name``: Company legal name

        Examples
        --------
        >>> info = client.get_company_info("320193")
        >>> print(info)
        {'cik': 320193, 'name': 'Apple Inc.'}
        """
        facts = self.get_company_facts(cik)
        return {
            "cik": facts.get("cik"),
            "name": facts.get("entityName"),
        }

    def search_companies(self, query: str) -> List[Dict[str, Any]]:
        """
        Search for companies by ticker symbol.

        Currently supports exact ticker matches only.

        Parameters
        ----------
        query : str
            Ticker symbol to search for.

        Returns
        -------
        list of dict
            List of matching companies. Each dict contains:

            - ``ticker``: Stock ticker symbol
            - ``cik``: SEC CIK number
            - ``name``: Company name

        Examples
        --------
        >>> results = client.search_companies("AAPL")
        >>> print(results[0])
        {'ticker': 'AAPL', 'cik': '0000320193', 'name': 'Apple Inc.'}

        Notes
        -----
        This method currently only supports exact ticker matches.
        Partial name searching is not yet implemented.
        """
        self._load_ticker_mapping()
        query_upper = query.upper()
        results = []

        if query_upper in self._ticker_to_cik:
            cik = self._ticker_to_cik[query_upper]
            try:
                info = self.get_company_info(cik)
                results.append({
                    "ticker": query_upper,
                    "cik": cik,
                    "name": info.get("name", ""),
                })
            except Exception:
                pass

        return results

    def clear_cache(self) -> int:
        """
        Clear all cached API responses.

        Removes all cached files from the cache directory.
        Use this to force fresh data retrieval.

        Returns
        -------
        int
            Number of cache files deleted.

        Examples
        --------
        >>> deleted = client.clear_cache()
        >>> print(f"Deleted {deleted} cached files")
        Deleted 15 cached files
        """
        return self._cache.clear()

    def cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns
        -------
        dict
            Cache statistics with keys:

            - ``files``: Number of cached files
            - ``size_bytes``: Total cache size in bytes
            - ``size_mb``: Total cache size in megabytes

        Examples
        --------
        >>> stats = client.cache_stats()
        >>> print(f"Cache: {stats['files']} files, {stats['size_mb']:.1f} MB")
        Cache: 15 files, 4.8 MB
        """
        return self._cache.stats()

    def __repr__(self) -> str:
        """Return string representation of client."""
        return f"SECClient(user_agent='{self.user_agent[:20]}...')"
