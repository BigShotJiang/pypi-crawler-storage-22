"""
Company class for accessing financial data from SEC EDGAR.

This module provides the Company class, which serves as the primary interface
for accessing a company's financial statements and earnings information.
The Company class wraps the SECClient and provides convenient methods for
retrieving income statements, balance sheets, cash flow statements, and
earnings calendars.

Classes
-------
Company
    High-level interface for accessing a company's financial data.

Examples
--------
Basic usage with the Company class:

>>> from secfin import SECClient, Company
>>> client = SECClient("MyApp contact@email.com")
>>> company = Company("AAPL", client)
>>> print(company.name)
Apple Inc.

Get financial statements:

>>> income = company.get_income_statement()
>>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
Revenue: $383,285,000,000

>>> balance = company.get_balance_sheet()
>>> print(f"Total Assets: ${balance.total_assets.latest()['val']:,.0f}")

>>> cashflow = company.get_cash_flow()
>>> print(f"Free Cash Flow: ${cashflow.free_cash_flow.latest()['val']:,.0f}")

Get earnings information:

>>> last = company.last_earnings()
>>> print(f"Last earnings: {last['date']}")

>>> next_est = company.next_earnings()
>>> print(f"Next expected: {next_est['date']}")

Notes
-----
The Company class lazily loads data from the SEC API. The first call to
any method that requires company facts will trigger an API request. Subsequent
calls use cached data to avoid redundant API calls.

See Also
--------
SECClient : Low-level HTTP client for SEC EDGAR API.
IncomeStatement : Income statement data structure.
BalanceSheet : Balance sheet data structure.
CashFlow : Cash flow statement data structure.
EarningsCalendar : Earnings dates and calendar.
"""

from typing import Dict, Any, Optional
from .client import SECClient
from .financials import IncomeStatement, BalanceSheet, CashFlow
from .parser import parse_income_statement, parse_balance_sheet, parse_cash_flow
from .earnings import EarningsCalendar, parse_earnings_from_facts


class Company:
    """
    High-level interface for accessing a company's financial data.

    The Company class provides convenient access to SEC EDGAR data for a
    publicly traded company. It handles CIK lookup, data fetching, and
    parsing of financial statements automatically.

    Parameters
    ----------
    ticker : str
        Stock ticker symbol (e.g., "AAPL", "MSFT"). Case-insensitive.
    client : SECClient
        SEC API client instance with valid User-Agent.

    Attributes
    ----------
    ticker : str
        Stock ticker symbol (uppercase).
    cik : str
        SEC Central Index Key - unique identifier for the company.
        Lazily loaded on first access.
    name : str
        Company's legal name as registered with the SEC.
        Lazily loaded on first access.

    Raises
    ------
    ValueError
        If the ticker symbol is not found in the SEC database.

    Examples
    --------
    Basic company information:

    >>> from secfin import SECClient, Company
    >>> client = SECClient("MyApp contact@email.com")
    >>> company = Company("AAPL", client)
    >>> print(f"Company: {company.name}")
    Company: Apple Inc.
    >>> print(f"CIK: {company.cik}")
    CIK: 0000320193

    Get income statement with annual data:

    >>> income = company.get_income_statement(period="annual")
    >>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
    >>> print(f"Net Margin: {income.net_margin():.1%}")

    Get quarterly financial data:

    >>> quarterly_income = company.get_income_statement(period="quarterly")
    >>> print(f"TTM Revenue: ${quarterly_income.revenue.ttm():,.0f}")

    Get a summary of all financials:

    >>> summary = company.summary()
    >>> print(summary['income_statement'])

    Check earnings dates:

    >>> last_earnings = company.last_earnings()
    >>> print(f"Last filing: {last_earnings['date']}")
    >>> next_earnings = company.next_earnings()
    >>> if next_earnings:
    ...     print(f"Next expected: {next_earnings['date']}")

    Notes
    -----
    **Data Loading**

    The Company class uses lazy loading for all SEC data. The first call to
    any method that requires company facts (``get_income_statement()``,
    ``get_balance_sheet()``, etc.) will trigger an API request. Subsequent
    calls use the cached data.

    **Annual vs Quarterly Data**

    - ``period="annual"`` returns data from 10-K filings (fiscal year reports)
    - ``period="quarterly"`` returns data from 10-Q filings (quarterly reports)

    Annual data provides a cleaner view for long-term analysis, while quarterly
    data is useful for TTM calculations and tracking recent performance.

    **CIK Numbers**

    The CIK (Central Index Key) is the SEC's unique identifier for companies
    and individuals. It's used internally to fetch data from the SEC API.
    CIKs are zero-padded to 10 digits (e.g., "0000320193" for Apple).

    See Also
    --------
    SECClient : HTTP client for SEC EDGAR API.
    IncomeStatement : Revenue, expenses, and profitability data.
    BalanceSheet : Assets, liabilities, and equity data.
    CashFlow : Operating, investing, and financing cash flows.
    EarningsCalendar : Historical and estimated earnings dates.
    """

    def __init__(self, ticker: str, client: SECClient):
        self.ticker = ticker.upper()
        self._client = client
        self._cik: Optional[str] = None
        self._name: Optional[str] = None
        self._facts: Optional[dict] = None

    @property
    def cik(self) -> str:
        """
        Get the company's CIK number.

        The CIK (Central Index Key) is the SEC's unique identifier for
        this company. It is zero-padded to 10 digits.

        Returns
        -------
        str
            10-digit CIK number (e.g., "0000320193").

        Examples
        --------
        >>> company = Company("AAPL", client)
        >>> print(company.cik)
        0000320193
        """
        if self._cik is None:
            self._cik = self._client.get_cik(self.ticker)
        return self._cik

    @property
    def name(self) -> str:
        """
        Get the company's legal name.

        Returns the company name as registered with the SEC. This triggers
        a data fetch if facts haven't been loaded yet.

        Returns
        -------
        str
            Company's legal name (e.g., "Apple Inc.").

        Examples
        --------
        >>> company = Company("MSFT", client)
        >>> print(company.name)
        MICROSOFT CORPORATION
        """
        if self._name is None:
            self._load_facts()
            self._name = self._facts.get("entityName", "")
        return self._name

    def _load_facts(self):
        """
        Load company facts from SEC API.

        Internal method that fetches all XBRL facts for the company.
        Called lazily when facts are first needed.
        """
        if self._facts is None:
            self._facts = self._client.get_company_facts(self.cik)

    def get_income_statement(self, period: str = "annual") -> IncomeStatement:
        """
        Get income statement data.

        Returns the company's income statement with revenue, expenses,
        and profitability metrics extracted from SEC 10-K or 10-Q filings.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type:

            - ``"annual"`` : Data from 10-K filings (fiscal year)
            - ``"quarterly"`` : Data from 10-Q filings (quarterly)

        Returns
        -------
        IncomeStatement
            Income statement containing:

            - ``revenue`` : Total revenue/sales
            - ``cost_of_revenue`` : Cost of goods sold
            - ``gross_profit`` : Revenue minus cost of revenue
            - ``operating_income`` : Operating profit
            - ``net_income`` : Bottom-line profit
            - ``eps_basic`` / ``eps_diluted`` : Earnings per share
            - And more (see IncomeStatement documentation)

        Examples
        --------
        Get annual income statement:

        >>> income = company.get_income_statement()
        >>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
        >>> print(f"Net Income: ${income.net_income.latest()['val']:,.0f}")
        >>> print(f"Gross Margin: {income.gross_margin():.1%}")

        Get quarterly data for TTM calculations:

        >>> quarterly = company.get_income_statement(period="quarterly")
        >>> print(f"TTM Revenue: ${quarterly.revenue.ttm():,.0f}")
        >>> print(f"YoY Growth: {quarterly.revenue.growth():.1%}")

        Convert to DataFrame for analysis:

        >>> df = income.to_dataframe()
        >>> print(df.head())

        See Also
        --------
        IncomeStatement : Full documentation of income statement metrics.
        """
        self._load_facts()
        return parse_income_statement(self._facts, period)

    def get_balance_sheet(self, period: str = "annual") -> BalanceSheet:
        """
        Get balance sheet data.

        Returns the company's balance sheet with assets, liabilities,
        and equity data extracted from SEC 10-K or 10-Q filings.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type:

            - ``"annual"`` : Data from 10-K filings (fiscal year)
            - ``"quarterly"`` : Data from 10-Q filings (quarterly)

        Returns
        -------
        BalanceSheet
            Balance sheet containing:

            - ``total_assets`` / ``current_assets`` : Asset values
            - ``total_liabilities`` / ``current_liabilities`` : Liability values
            - ``stockholders_equity`` : Book value of equity
            - ``cash`` : Cash and cash equivalents
            - ``long_term_debt`` / ``short_term_debt`` : Debt levels
            - And more (see BalanceSheet documentation)

        Examples
        --------
        Get balance sheet metrics:

        >>> balance = company.get_balance_sheet()
        >>> print(f"Total Assets: ${balance.total_assets.latest()['val']:,.0f}")
        >>> print(f"Cash: ${balance.cash.latest()['val']:,.0f}")
        >>> print(f"Current Ratio: {balance.current_ratio():.2f}")

        Analyze debt levels:

        >>> print(f"Debt/Equity: {balance.debt_to_equity():.2f}")
        >>> print(f"Debt Ratio: {balance.debt_ratio():.1%}")

        See Also
        --------
        BalanceSheet : Full documentation of balance sheet metrics.
        """
        self._load_facts()
        return parse_balance_sheet(self._facts, period)

    def get_cash_flow(self, period: str = "annual") -> CashFlow:
        """
        Get cash flow statement data.

        Returns the company's cash flow statement with operating, investing,
        and financing activities extracted from SEC 10-K or 10-Q filings.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type:

            - ``"annual"`` : Data from 10-K filings (fiscal year)
            - ``"quarterly"`` : Data from 10-Q filings (quarterly)

        Returns
        -------
        CashFlow
            Cash flow statement containing:

            - ``operating_cash_flow`` : Cash from operations
            - ``investing_cash_flow`` : Cash from investing
            - ``financing_cash_flow`` : Cash from financing
            - ``capital_expenditures`` : CapEx spending
            - ``free_cash_flow`` : OCF minus CapEx
            - ``dividends_paid`` : Dividend payments

        Examples
        --------
        Analyze cash generation:

        >>> cashflow = company.get_cash_flow()
        >>> ocf = cashflow.operating_cash_flow.latest()['val']
        >>> fcf = cashflow.free_cash_flow.latest()['val']
        >>> print(f"Operating Cash Flow: ${ocf:,.0f}")
        >>> print(f"Free Cash Flow: ${fcf:,.0f}")

        Track CapEx spending:

        >>> capex = cashflow.capital_expenditures.latest()['val']
        >>> print(f"Capital Expenditures: ${capex:,.0f}")

        See Also
        --------
        CashFlow : Full documentation of cash flow metrics.
        """
        self._load_facts()
        return parse_cash_flow(self._facts, period)

    def get_all_financials(self, period: str = "annual") -> Dict[str, Any]:
        """
        Get all financial statements at once.

        Convenience method that returns income statement, balance sheet,
        and cash flow statement in a single call.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type (``"annual"`` or ``"quarterly"``).

        Returns
        -------
        dict
            Dictionary with keys:

            - ``"income_statement"`` : IncomeStatement object
            - ``"balance_sheet"`` : BalanceSheet object
            - ``"cash_flow"`` : CashFlow object

        Examples
        --------
        >>> financials = company.get_all_financials()
        >>> income = financials['income_statement']
        >>> balance = financials['balance_sheet']
        >>> cashflow = financials['cash_flow']
        """
        return {
            "income_statement": self.get_income_statement(period),
            "balance_sheet": self.get_balance_sheet(period),
            "cash_flow": self.get_cash_flow(period),
        }

    def summary(self, period: str = "annual") -> Dict[str, Any]:
        """
        Get a summary of key financial metrics.

        Returns the most recent values for key metrics from all three
        financial statements, providing a quick overview of the company's
        financial position.

        Parameters
        ----------
        period : str, default="annual"
            Filing period type (``"annual"`` or ``"quarterly"``).

        Returns
        -------
        dict
            Summary dictionary with structure:

            - ``"company"`` : Company info (ticker, name, CIK)
            - ``"income_statement"`` : Key income metrics (latest values)
            - ``"balance_sheet"`` : Key balance sheet metrics (latest values)
            - ``"cash_flow"`` : Key cash flow metrics (latest values)

        Examples
        --------
        >>> summary = company.summary()
        >>> print(f"Company: {summary['company']['name']}")
        >>> print(f"Revenue: ${summary['income_statement']['revenue']:,.0f}")
        >>> print(f"Total Assets: ${summary['balance_sheet']['total_assets']:,.0f}")
        """
        income = self.get_income_statement(period)
        balance = self.get_balance_sheet(period)
        cashflow = self.get_cash_flow(period)

        return {
            "company": {
                "ticker": self.ticker,
                "name": self.name,
                "cik": self.cik,
            },
            "income_statement": income.summary(),
            "balance_sheet": balance.summary(),
            "cash_flow": cashflow.summary(),
        }

    def get_earnings_calendar(self) -> EarningsCalendar:
        """
        Get earnings calendar with historical and estimated future dates.

        Returns a calendar object containing all historical SEC filing dates
        and an estimated next earnings date based on the company's historical
        filing patterns.

        Returns
        -------
        EarningsCalendar
            Calendar object with:

            - ``historical`` : List of past EarningsDate objects
            - ``next_estimated`` : Estimated next filing date
            - ``fiscal_year_end`` : Company's fiscal year end month

        Examples
        --------
        >>> calendar = company.get_earnings_calendar()
        >>> print(f"Fiscal Year End: {calendar.fiscal_year_end}")
        >>> print(f"Total Historical Filings: {len(calendar.historical)}")

        Get historical data as DataFrame:

        >>> df = calendar.get_historical_df()
        >>> print(df.head())

        See Also
        --------
        EarningsCalendar : Full documentation of earnings calendar.
        last_earnings : Get most recent earnings date.
        next_earnings : Get estimated next earnings date.
        """
        self._load_facts()
        return parse_earnings_from_facts(self._facts, self.ticker)

    def next_earnings(self) -> Optional[Dict[str, Any]]:
        """
        Get the estimated next earnings date.

        Estimates the next earnings filing date based on the company's
        historical filing patterns. The estimate considers the typical
        delay between fiscal period end and filing date.

        Returns
        -------
        dict or None
            Dictionary with estimated earnings info, or None if unavailable:

            - ``"date"`` : Estimated filing date (YYYY-MM-DD)
            - ``"period_end"`` : Estimated fiscal period end date
            - ``"form_type"`` : Expected form type ("10-K" or "10-Q")
            - ``"fiscal_quarter"`` : Expected quarter ("Q1", "Q2", "Q3", "FY")

        Examples
        --------
        >>> next_est = company.next_earnings()
        >>> if next_est:
        ...     print(f"Expected: {next_est['date']}")
        ...     print(f"Form: {next_est['form_type']}")
        ...     print(f"Quarter: {next_est['fiscal_quarter']}")

        Notes
        -----
        The estimated date is based on the average delay between period
        end and filing date from recent historical filings. Actual dates
        may vary. Returns None if there isn't enough historical data to
        make an estimate.

        See Also
        --------
        last_earnings : Get most recent actual earnings date.
        get_earnings_calendar : Get full earnings calendar.
        """
        calendar = self.get_earnings_calendar()
        if calendar.next_estimated:
            return {
                "date": calendar.next_estimated.date,
                "period_end": calendar.next_estimated.period_end,
                "form_type": calendar.next_estimated.form_type,
                "fiscal_quarter": calendar.next_estimated.fiscal_quarter,
            }
        return None

    def last_earnings(self) -> Optional[Dict[str, Any]]:
        """
        Get the most recent earnings date.

        Returns information about the company's most recent SEC filing
        (either 10-K or 10-Q).

        Returns
        -------
        dict or None
            Dictionary with most recent filing info, or None if unavailable:

            - ``"date"`` : Filing date (YYYY-MM-DD)
            - ``"period_end"`` : Fiscal period end date
            - ``"form_type"`` : Form type ("10-K" or "10-Q")
            - ``"fiscal_quarter"`` : Quarter ("Q1", "Q2", "Q3", "FY")

        Examples
        --------
        >>> last = company.last_earnings()
        >>> if last:
        ...     print(f"Filed: {last['date']}")
        ...     print(f"Period End: {last['period_end']}")
        ...     print(f"Form: {last['form_type']}")
        Last Earnings:
          Filed: 2026-01-30
          Period End: 2025-12-27
          Form: 10-Q

        See Also
        --------
        next_earnings : Get estimated next earnings date.
        earnings_history : Get list of historical earnings dates.
        """
        calendar = self.get_earnings_calendar()
        last = calendar.last_earnings()
        if last:
            return {
                "date": last.date,
                "period_end": last.period_end,
                "form_type": last.form_type,
                "fiscal_quarter": last.fiscal_quarter,
            }
        return None

    def earnings_history(self, limit: int = 20) -> list:
        """
        Get historical earnings dates.

        Returns a list of past SEC filing dates, sorted from most recent
        to oldest. Includes both 10-K (annual) and 10-Q (quarterly) filings.

        Parameters
        ----------
        limit : int, default=20
            Maximum number of historical dates to return.

        Returns
        -------
        list of dict
            List of dictionaries, each containing:

            - ``"date"`` : Filing date (YYYY-MM-DD)
            - ``"period_end"`` : Fiscal period end date
            - ``"form_type"`` : Form type ("10-K" or "10-Q")
            - ``"fiscal_quarter"`` : Quarter ("Q1", "Q2", "Q3", "FY")
            - ``"fiscal_year"`` : Fiscal year number

        Examples
        --------
        Get last 10 earnings dates:

        >>> history = company.earnings_history(limit=10)
        >>> for h in history:
        ...     print(f"{h['date']} | {h['form_type']} | {h['fiscal_quarter']}")
        2026-01-30 | 10-Q | Q1
        2025-11-01 | 10-K | FY
        2025-08-02 | 10-Q | Q3
        ...

        See Also
        --------
        last_earnings : Get most recent earnings date only.
        get_earnings_calendar : Get full earnings calendar object.
        """
        calendar = self.get_earnings_calendar()
        return [
            {
                "date": e.date,
                "period_end": e.period_end,
                "form_type": e.form_type,
                "fiscal_quarter": e.fiscal_quarter,
                "fiscal_year": e.fiscal_year,
            }
            for e in calendar.historical[:limit]
        ]

    def __repr__(self) -> str:
        """Return string representation of the Company."""
        return f"Company(ticker='{self.ticker}', cik='{self.cik}')"
