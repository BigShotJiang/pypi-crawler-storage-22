"""
Earnings dates and calendar functionality.

This module provides classes and functions for working with company
earnings dates, including historical filing dates and estimated future
earnings announcements.

Classes
-------
EarningsDate
    A single earnings date record with filing and fiscal period info.
EarningsCalendar
    Collection of historical and estimated earnings dates for a company.

Functions
---------
parse_earnings_from_facts
    Extract earnings dates from SEC company facts data.
estimate_next_earnings
    Estimate the next earnings date based on historical patterns.

Examples
--------
Get earnings calendar for a company:

>>> from secfin import SECClient, Company
>>> client = SECClient("MyApp contact@email.com")
>>> company = Company("AAPL", client)
>>> calendar = company.get_earnings_calendar()

Check last and next earnings:

>>> last = calendar.last_earnings()
>>> print(f"Last filing: {last.date} ({last.form_type})")
Last filing: 2026-01-30 (10-Q)

>>> if calendar.next_estimated:
...     print(f"Next expected: {calendar.next_estimated.date}")

Get historical earnings as DataFrame:

>>> df = calendar.get_historical_df()
>>> print(df.head())

Notes
-----
Earnings dates are derived from SEC filing timestamps. The SEC requires
companies to file their 10-K (annual) within 60-90 days of fiscal year
end and 10-Q (quarterly) within 40-45 days of quarter end, depending
on company size.

See Also
--------
Company : High-level interface that includes earnings methods.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import pandas as pd


@dataclass
class EarningsDate:
    """
    A single earnings date record.

    Represents one SEC filing with its associated dates and fiscal period
    information. Used for both historical filings and estimated future dates.

    Attributes
    ----------
    date : str
        Filing date in YYYY-MM-DD format. For historical data, this is
        when the filing was submitted to the SEC. For estimates, this is
        the predicted filing date.
    period_end : str
        Fiscal period end date in YYYY-MM-DD format. This is the last day
        of the reporting period covered by the filing.
    form_type : str
        SEC form type, typically "10-K" (annual) or "10-Q" (quarterly).
    fiscal_year : int, optional
        Fiscal year number (e.g., 2025). May be None for estimated dates.
    fiscal_quarter : str, optional
        Fiscal quarter identifier:

        - ``"Q1"``, ``"Q2"``, ``"Q3"`` : Quarterly filings
        - ``"FY"`` : Full year (annual 10-K filing)
        - ``None`` : Unknown

    Examples
    --------
    >>> earnings = EarningsDate(
    ...     date="2026-01-30",
    ...     period_end="2025-12-27",
    ...     form_type="10-Q",
    ...     fiscal_year=2025,
    ...     fiscal_quarter="Q1"
    ... )
    >>> print(f"Filed {earnings.date} for {earnings.fiscal_quarter}")
    Filed 2026-01-30 for Q1
    """
    date: str  # Filing date (YYYY-MM-DD)
    period_end: str  # Fiscal period end date
    form_type: str  # 10-K or 10-Q
    fiscal_year: Optional[int] = None
    fiscal_quarter: Optional[str] = None  # Q1, Q2, Q3, Q4, FY


@dataclass
class EarningsCalendar:
    """
    Earnings calendar with historical and estimated future dates.

    Contains all known earnings filing dates for a company along with
    an estimated next earnings date based on historical patterns.

    Attributes
    ----------
    ticker : str
        Stock ticker symbol.
    company_name : str
        Company name as registered with the SEC.
    historical : list of EarningsDate
        Historical earnings dates, sorted by filing date (most recent first).
    next_estimated : EarningsDate, optional
        Estimated next earnings date based on historical patterns.
        None if insufficient data to make an estimate.
    fiscal_year_end : str, optional
        Month name when the company's fiscal year ends (e.g., "December",
        "September"). Derived from the most recent 10-K filing.

    Examples
    --------
    >>> calendar = company.get_earnings_calendar()
    >>> print(f"Company: {calendar.company_name}")
    >>> print(f"Fiscal Year End: {calendar.fiscal_year_end}")
    >>> print(f"Historical filings: {len(calendar.historical)}")

    Get last earnings:

    >>> last = calendar.last_earnings()
    >>> if last:
    ...     print(f"Last: {last.date} ({last.form_type})")

    Get historical data as DataFrame:

    >>> df = calendar.get_historical_df()
    >>> print(df[['filing_date', 'form_type', 'fiscal_quarter']].head())

    See Also
    --------
    Company.get_earnings_calendar : Get calendar for a company.
    Company.last_earnings : Get most recent earnings date.
    Company.next_earnings : Get estimated next earnings date.
    """
    ticker: str
    company_name: str
    historical: List[EarningsDate] = field(default_factory=list)
    next_estimated: Optional[EarningsDate] = None
    fiscal_year_end: Optional[str] = None  # Month (e.g., "December", "September")

    def get_historical_df(self) -> pd.DataFrame:
        """
        Get historical earnings dates as a DataFrame.

        Converts the historical earnings list to a pandas DataFrame
        for easier analysis and export.

        Returns
        -------
        pd.DataFrame
            DataFrame with columns:

            - ``filing_date`` : Date the filing was submitted (datetime)
            - ``period_end`` : Fiscal period end date (datetime)
            - ``form_type`` : "10-K" or "10-Q"
            - ``fiscal_year`` : Fiscal year number
            - ``fiscal_quarter`` : Quarter ("Q1", "Q2", "Q3", "FY")

            Sorted by filing_date descending (most recent first).

        Examples
        --------
        >>> df = calendar.get_historical_df()
        >>> print(df.head())
           filing_date period_end form_type  fiscal_year fiscal_quarter
        0   2026-01-30 2025-12-27      10-Q         2025             Q1
        1   2025-11-01 2025-09-27      10-K         2025             FY
        2   2025-08-02 2025-06-28      10-Q         2025             Q3

        Export to CSV:

        >>> df.to_csv("earnings_history.csv", index=False)
        """
        if not self.historical:
            return pd.DataFrame()

        data = [
            {
                "filing_date": e.date,
                "period_end": e.period_end,
                "form_type": e.form_type,
                "fiscal_year": e.fiscal_year,
                "fiscal_quarter": e.fiscal_quarter,
            }
            for e in self.historical
        ]
        df = pd.DataFrame(data)
        df["filing_date"] = pd.to_datetime(df["filing_date"])
        df["period_end"] = pd.to_datetime(df["period_end"])
        return df.sort_values("filing_date", ascending=False)

    def last_earnings(self) -> Optional[EarningsDate]:
        """
        Get the most recent earnings date.

        Returns
        -------
        EarningsDate or None
            The most recent historical earnings date, or None if no
            historical data is available.

        Examples
        --------
        >>> last = calendar.last_earnings()
        >>> if last:
        ...     print(f"Last filing: {last.date}")
        ...     print(f"Form: {last.form_type}")
        ...     print(f"Quarter: {last.fiscal_quarter}")
        """
        if not self.historical:
            return None
        # Sort by filing date descending
        sorted_hist = sorted(self.historical, key=lambda x: x.date, reverse=True)
        return sorted_hist[0] if sorted_hist else None

    def summary(self) -> Dict[str, Any]:
        """
        Get a summary of earnings information.

        Returns
        -------
        dict
            Summary dictionary with keys:

            - ``ticker`` : Stock ticker symbol
            - ``company_name`` : Company name
            - ``last_earnings_date`` : Most recent filing date
            - ``last_period_end`` : Most recent period end date
            - ``last_form_type`` : Most recent form type
            - ``next_estimated`` : Estimated next filing date (or None)
            - ``fiscal_year_end`` : Fiscal year end month
            - ``total_filings`` : Number of historical filings

        Examples
        --------
        >>> summary = calendar.summary()
        >>> print(f"Last: {summary['last_earnings_date']}")
        >>> print(f"Next: {summary['next_estimated']}")
        >>> print(f"Total filings: {summary['total_filings']}")
        """
        last = self.last_earnings()
        return {
            "ticker": self.ticker,
            "company_name": self.company_name,
            "last_earnings_date": last.date if last else None,
            "last_period_end": last.period_end if last else None,
            "last_form_type": last.form_type if last else None,
            "next_estimated": self.next_estimated.date if self.next_estimated else None,
            "fiscal_year_end": self.fiscal_year_end,
            "total_filings": len(self.historical),
        }


def parse_earnings_from_facts(facts: dict, ticker: str) -> EarningsCalendar:
    """
    Extract earnings dates from SEC company facts.

    Parses the SEC EDGAR company facts JSON to extract all historical
    earnings filing dates and estimate the next earnings date.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API (``companyfacts`` endpoint).
    ticker : str
        Company ticker symbol.

    Returns
    -------
    EarningsCalendar
        Calendar with historical earnings dates and estimated next date.

    Examples
    --------
    >>> # Usually called internally by Company.get_earnings_calendar()
    >>> facts = client.get_company_facts("0000320193")
    >>> calendar = parse_earnings_from_facts(facts, "AAPL")
    >>> print(f"Found {len(calendar.historical)} historical filings")

    Notes
    -----
    This function extracts filing dates by looking at key financial
    concepts (Revenue, Net Income, Assets) that appear in every 10-K
    and 10-Q filing. Dates are deduplicated by period end to avoid
    counting amendments.

    See Also
    --------
    EarningsCalendar : The returned calendar object.
    estimate_next_earnings : Next date estimation logic.
    """
    company_name = facts.get("entityName", "")

    # Extract filing dates from the facts
    # We look at key metrics that are filed each quarter
    historical_dates: Dict[str, EarningsDate] = {}

    # Check us-gaap facts for filing information
    us_gaap = facts.get("facts", {}).get("us-gaap", {})

    # Key concepts that appear in every earnings filing
    key_concepts = [
        "NetIncomeLoss",
        "Revenues",
        "RevenueFromContractWithCustomerExcludingAssessedTax",
        "Assets",
    ]

    for concept in key_concepts:
        concept_data = us_gaap.get(concept, {})
        units = concept_data.get("units", {})

        for unit_type, values in units.items():
            for val in values:
                form_type = val.get("form", "")
                if form_type not in ("10-K", "10-Q"):
                    continue

                filed_date = val.get("filed", "")
                period_end = val.get("end", "")
                fiscal_year = val.get("fy")
                fp = val.get("fp", "")  # FY, Q1, Q2, Q3, Q4

                if not filed_date or not period_end:
                    continue

                # Use period_end as key to deduplicate
                key = f"{period_end}_{form_type}"
                if key not in historical_dates:
                    historical_dates[key] = EarningsDate(
                        date=filed_date,
                        period_end=period_end,
                        form_type=form_type,
                        fiscal_year=fiscal_year,
                        fiscal_quarter=fp if fp else ("FY" if form_type == "10-K" else None),
                    )

    # Convert to list and sort by date
    historical = list(historical_dates.values())
    historical.sort(key=lambda x: x.date, reverse=True)

    # Estimate fiscal year end month
    fiscal_year_end = None
    annual_filings = [h for h in historical if h.form_type == "10-K"]
    if annual_filings:
        try:
            last_annual = annual_filings[0]
            end_date = datetime.strptime(last_annual.period_end, "%Y-%m-%d")
            fiscal_year_end = end_date.strftime("%B")  # Month name
        except (ValueError, TypeError):
            pass

    # Estimate next earnings date based on historical pattern
    next_estimated = estimate_next_earnings(historical)

    return EarningsCalendar(
        ticker=ticker,
        company_name=company_name,
        historical=historical,
        next_estimated=next_estimated,
        fiscal_year_end=fiscal_year_end,
    )


def estimate_next_earnings(historical: List[EarningsDate]) -> Optional[EarningsDate]:
    """
    Estimate the next earnings date based on historical patterns.

    Analyzes the company's historical filing patterns to predict when
    the next earnings report will be filed with the SEC.

    Parameters
    ----------
    historical : list of EarningsDate
        List of historical earnings dates, sorted by date descending.

    Returns
    -------
    EarningsDate or None
        Estimated next earnings date, or None if:

        - Fewer than 4 historical filings available
        - Estimated date is in the past
        - Unable to parse historical dates

    Examples
    --------
    >>> next_est = estimate_next_earnings(historical)
    >>> if next_est:
    ...     print(f"Expected: {next_est.date}")
    ...     print(f"Form: {next_est.form_type}")
    ...     print(f"Quarter: {next_est.fiscal_quarter}")

    Notes
    -----
    **Estimation Method**

    1. Calculate the average delay between period end and filing date
       from the last 8 filings
    2. Determine the next quarter based on the most recent filing
    3. Estimate the next period end date (~90 days after the last)
    4. Add the average delay to get the estimated filing date

    **Typical Filing Delays**

    - Large accelerated filers: 40-60 days after period end
    - Accelerated filers: 40-75 days after period end
    - Non-accelerated filers: 45-90 days after period end

    **Quarter Sequence**

    - After Q1 (10-Q) comes Q2 (10-Q)
    - After Q2 (10-Q) comes Q3 (10-Q)
    - After Q3 (10-Q) comes FY (10-K)
    - After FY (10-K) comes Q1 (10-Q)

    See Also
    --------
    parse_earnings_from_facts : Uses this function to estimate next date.
    """
    if len(historical) < 4:
        return None

    # Get the most recent quarterly filings
    quarterly = [h for h in historical if h.form_type == "10-Q"]
    annual = [h for h in historical if h.form_type == "10-K"]

    if not quarterly and not annual:
        return None

    # Calculate average days between period end and filing
    delays = []
    for h in historical[:8]:  # Look at last 8 filings
        try:
            period_end = datetime.strptime(h.period_end, "%Y-%m-%d")
            filed = datetime.strptime(h.date, "%Y-%m-%d")
            delay = (filed - period_end).days
            if 20 <= delay <= 90:  # Reasonable range
                delays.append(delay)
        except (ValueError, TypeError):
            continue

    if not delays:
        avg_delay = 40  # Default to ~40 days
    else:
        avg_delay = sum(delays) // len(delays)

    # Find the last period end and estimate next
    try:
        last = historical[0]
        last_period_end = datetime.strptime(last.period_end, "%Y-%m-%d")

        # Estimate next quarter end (~90 days after last)
        if last.form_type == "10-K":
            # After annual, next is Q1 (~90 days)
            next_period_end = last_period_end + timedelta(days=90)
            next_form = "10-Q"
            next_quarter = "Q1"
        elif last.fiscal_quarter == "Q3":
            # After Q3, next is annual (10-K)
            next_period_end = last_period_end + timedelta(days=90)
            next_form = "10-K"
            next_quarter = "FY"
        else:
            # Regular quarter
            next_period_end = last_period_end + timedelta(days=90)
            next_form = "10-Q"
            q_map = {"Q1": "Q2", "Q2": "Q3", "FY": "Q1"}
            next_quarter = q_map.get(last.fiscal_quarter, "Q2")

        # Estimate filing date
        next_filing = next_period_end + timedelta(days=avg_delay)

        # Only return if it's in the future
        if next_filing > datetime.now():
            return EarningsDate(
                date=next_filing.strftime("%Y-%m-%d"),
                period_end=next_period_end.strftime("%Y-%m-%d"),
                form_type=next_form,
                fiscal_quarter=next_quarter,
            )
    except (ValueError, TypeError):
        pass

    return None
