"""
Financial statement data classes.

This module provides dataclasses for representing financial statements
extracted from SEC EDGAR filings. Each statement contains multiple
:class:`FinancialMetric` objects with historical values.

Classes
-------
FinancialMetric
    A single financial metric with historical values and analytics methods.
IncomeStatement
    Income statement data with revenue, expenses, and profitability metrics.
BalanceSheet
    Balance sheet data with assets, liabilities, and equity.
CashFlow
    Cash flow statement with operating, investing, and financing activities.

Financial Metrics Guide
-----------------------
**Income Statement Metrics:**

- ``revenue``: Total sales/revenue from core business operations.
  Also known as "Net Sales" or "Total Revenue".

- ``cost_of_revenue``: Direct costs attributable to producing goods/services sold.
  Also known as "Cost of Goods Sold (COGS)".

- ``gross_profit``: Revenue minus Cost of Revenue. Measures profitability
  before operating expenses. Formula: Revenue - Cost of Revenue.

- ``research_and_development``: R&D expenses for developing new products,
  technologies, or services. Important for tech and pharma companies.

- ``selling_general_admin``: SG&A expenses including sales, marketing,
  administrative costs, and corporate overhead.

- ``operating_expenses``: Total operating costs including R&D, SG&A,
  depreciation, and other operational expenses.

- ``operating_income``: Profit from core operations before interest and taxes.
  Formula: Gross Profit - Operating Expenses. Also known as EBIT.

- ``interest_expense``: Cost of borrowed funds, including bond interest
  and loan payments.

- ``income_tax_expense``: Federal, state, and foreign income taxes.

- ``net_income``: Bottom-line profit after all expenses and taxes.
  Formula: Revenue - All Expenses - Taxes.

- ``eps_basic``: Basic Earnings Per Share. Net income divided by
  weighted average shares outstanding.

- ``eps_diluted``: Diluted EPS accounting for potential dilution from
  stock options, convertible securities, etc.

- ``shares_outstanding``: Number of shares currently held by shareholders.

**Balance Sheet Metrics:**

- ``total_assets``: Everything the company owns with economic value.
  Includes current assets, property, investments, and intangibles.

- ``current_assets``: Assets expected to be converted to cash within one year.
  Includes cash, receivables, inventory.

- ``total_liabilities``: Everything the company owes to others.
  Includes current and long-term obligations.

- ``current_liabilities``: Debts due within one year.
  Includes accounts payable, short-term debt, accrued expenses.

- ``stockholders_equity``: Book value belonging to shareholders.
  Formula: Total Assets - Total Liabilities.

- ``cash``: Cash and cash equivalents including money market funds
  and short-term investments.

- ``inventory``: Raw materials, work-in-progress, and finished goods.

- ``accounts_receivable``: Money owed by customers for goods/services sold.

- ``long_term_debt``: Debt obligations due beyond one year.

- ``short_term_debt``: Debt obligations due within one year.

**Cash Flow Metrics:**

- ``operating_cash_flow``: Cash generated from core business operations.
  Adjusts net income for non-cash items and working capital changes.

- ``investing_cash_flow``: Cash used for/from investments.
  Includes CapEx, acquisitions, and investment purchases/sales.

- ``financing_cash_flow``: Cash from/to financing activities.
  Includes debt issuance/repayment, stock issuance/buybacks, dividends.

- ``capital_expenditures``: Cash spent on property, plant, and equipment.
  Required to maintain and grow operations.

- ``dividends_paid``: Cash distributed to shareholders.

- ``free_cash_flow``: Cash available after maintaining operations.
  Formula: Operating Cash Flow - Capital Expenditures.

Examples
--------
>>> from secfin import SECClient, Company
>>> client = SECClient("MyApp contact@email.com")
>>> company = Company("AAPL", client)
>>> income = company.get_income_statement()
>>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
>>> print(f"Net Margin: {income.net_margin():.1%}")
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime
import pandas as pd


@dataclass
class FinancialMetric:
    """
    A single financial metric with historical values and analytics methods.

    Stores time-series financial data and provides methods for analysis
    including growth rates, trailing calculations, and data export.

    Parameters
    ----------
    name : str
        Internal identifier for the metric (e.g., "revenue").
    label : str
        Human-readable label (e.g., "Revenue").
    values : list of dict, optional
        Historical values, each dict containing at minimum:
        - ``end``: Period end date (YYYY-MM-DD)
        - ``val``: The numeric value

    Attributes
    ----------
    name : str
        Internal identifier for the metric.
    label : str
        Human-readable display label.
    values : list of dict
        Historical values with dates and amounts.

    Examples
    --------
    >>> metric = FinancialMetric("revenue", "Revenue")
    >>> metric.values = [
    ...     {"end": "2023-12-31", "val": 100000000},
    ...     {"end": "2022-12-31", "val": 90000000},
    ... ]
    >>> metric.latest()
    {'end': '2023-12-31', 'val': 100000000}
    >>> metric.growth()
    0.1111...  # 11.1% growth

    Notes
    -----
    Values are stored as dictionaries to preserve SEC filing metadata
    including filing dates, accession numbers, and fiscal period info.
    """

    name: str
    label: str
    values: List[Dict[str, Any]] = field(default_factory=list)

    def _sorted_values(self) -> List[Dict[str, Any]]:
        """
        Get values sorted by date descending (most recent first).

        Returns
        -------
        list of dict
            Values sorted by end date, most recent first.
        """
        return sorted(self.values, key=lambda x: x.get("end", ""), reverse=True)

    def latest(self) -> Optional[Dict[str, Any]]:
        """
        Get the most recent value.

        Returns
        -------
        dict or None
            Most recent value dict containing 'end' date and 'val',
            or None if no values exist.

        Examples
        --------
        >>> income.revenue.latest()
        {'end': '2023-12-31', 'val': 394328000000, 'form': '10-K', ...}
        >>> income.revenue.latest()['val']
        394328000000
        """
        if not self.values:
            return None
        sorted_vals = self._sorted_values()
        return sorted_vals[0] if sorted_vals else None

    def to_series(self) -> pd.Series:
        """
        Convert to pandas Series indexed by date.

        Returns
        -------
        pandas.Series
            Series with date index and metric values, sorted chronologically.

        Examples
        --------
        >>> series = income.revenue.to_series()
        >>> series.tail()
        2021-12-31    365817000000
        2022-12-31    394328000000
        2023-12-31    383285000000
        Name: revenue, dtype: float64
        """
        if not self.values:
            return pd.Series(dtype=float)
        data = {v.get("end"): v.get("val") for v in self.values if v.get("end")}
        return pd.Series(data, name=self.name).sort_index()

    def ttm(self) -> Optional[float]:
        """
        Calculate Trailing Twelve Months (TTM) value.

        Sums the last 4 quarterly values to get an annualized figure.
        Useful for getting current annualized metrics when only quarterly
        data is available, or when the fiscal year hasn't ended.

        Returns
        -------
        float or None
            TTM value (sum of last 4 quarters), or None if insufficient data.

        Notes
        -----
        - Requires at least 4 data points spanning roughly one year.
        - For annual data or if quarters don't span a full year, returns
          the latest value instead.
        - TTM is commonly used for P/E ratios and other valuation metrics.

        Examples
        --------
        >>> # Get TTM revenue from quarterly data
        >>> quarterly_income = company.get_income_statement(period="quarterly")
        >>> ttm_revenue = quarterly_income.revenue.ttm()
        >>> print(f"TTM Revenue: ${ttm_revenue:,.0f}")
        TTM Revenue: $394,328,000,000
        """
        if len(self.values) < 4:
            return None

        sorted_vals = self._sorted_values()
        recent_four = sorted_vals[:4]

        try:
            dates = [datetime.strptime(v["end"], "%Y-%m-%d") for v in recent_four]
            date_range = (dates[0] - dates[-1]).days

            # Validate quarterly data (~270-450 days for 4 quarters)
            if date_range < 270 or date_range > 450:
                latest = self.latest()
                return latest.get("val") if latest else None

        except (ValueError, KeyError):
            pass

        return sum(v.get("val", 0) for v in recent_four)

    def growth(self, periods: int = 1) -> Optional[float]:
        """
        Calculate period-over-period growth rate.

        Computes the percentage change between the most recent value
        and a prior period value.

        Parameters
        ----------
        periods : int, default=1
            Number of periods back to compare.
            - 1 = year-over-year for annual data
            - 4 = year-over-year for quarterly data

        Returns
        -------
        float or None
            Growth rate as a decimal (e.g., 0.10 = 10% growth).
            Returns None if insufficient data or division by zero.

        Examples
        --------
        >>> # Year-over-year revenue growth
        >>> growth = income.revenue.growth()
        >>> print(f"YoY Growth: {growth:.1%}")
        YoY Growth: 8.5%

        >>> # Compare to 2 years ago
        >>> two_year_growth = income.revenue.growth(periods=2)
        """
        sorted_vals = self._sorted_values()

        if len(sorted_vals) < periods + 1:
            return None

        current = sorted_vals[0].get("val")
        previous = sorted_vals[periods].get("val")

        if current is None or previous is None or previous == 0:
            return None

        return (current - previous) / abs(previous)

    def growth_rate(self) -> Optional[float]:
        """
        Calculate year-over-year growth rate.

        Convenience alias for ``growth(periods=1)``.

        Returns
        -------
        float or None
            YoY growth rate as decimal, or None if insufficient data.

        See Also
        --------
        growth : Calculate growth with custom period.
        cagr : Calculate compound annual growth rate.
        """
        return self.growth(periods=1)

    def cagr(self, years: int = 5) -> Optional[float]:
        """
        Calculate Compound Annual Growth Rate (CAGR).

        CAGR represents the constant annual growth rate that would be
        required to grow from the starting value to the ending value
        over the specified period.

        Parameters
        ----------
        years : int, default=5
            Number of years for CAGR calculation.

        Returns
        -------
        float or None
            CAGR as decimal (e.g., 0.10 = 10% CAGR).
            Returns None if insufficient data or invalid values.

        Notes
        -----
        Formula: CAGR = (End Value / Start Value)^(1/years) - 1

        CAGR smooths out volatility and provides a normalized growth rate,
        useful for comparing companies with different growth patterns.

        Examples
        --------
        >>> # 5-year revenue CAGR
        >>> cagr = income.revenue.cagr(years=5)
        >>> print(f"5-Year CAGR: {cagr:.1%}")
        5-Year CAGR: 8.7%

        >>> # 3-year CAGR
        >>> cagr_3yr = income.revenue.cagr(years=3)
        """
        sorted_vals = self._sorted_values()

        if len(sorted_vals) < years + 1:
            return None

        current = sorted_vals[0].get("val")
        past = sorted_vals[years].get("val")

        if current is None or past is None or past <= 0 or current <= 0:
            return None

        return (current / past) ** (1 / years) - 1

    def history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get historical values sorted by date (most recent first).

        Parameters
        ----------
        limit : int, default=10
            Maximum number of values to return.

        Returns
        -------
        list of dict
            Historical values, most recent first.

        Examples
        --------
        >>> for item in income.revenue.history(limit=5):
        ...     print(f"{item['end']}: ${item['val']:,.0f}")
        2023-12-31: $394,328,000,000
        2022-12-31: $365,817,000,000
        ...
        """
        return self._sorted_values()[:limit]

    def range(self, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Get values within a date range.

        Parameters
        ----------
        start_date : str
            Start date in YYYY-MM-DD format (inclusive).
        end_date : str
            End date in YYYY-MM-DD format (inclusive).

        Returns
        -------
        list of dict
            Values where start_date <= end <= end_date.

        Examples
        --------
        >>> values = income.revenue.range("2020-01-01", "2023-12-31")
        >>> len(values)
        4
        """
        return [
            v for v in self.values
            if v.get("end") and start_date <= v["end"] <= end_date
        ]

    def average(self, periods: int = 4) -> Optional[float]:
        """
        Calculate average of recent values.

        Parameters
        ----------
        periods : int, default=4
            Number of most recent periods to average.

        Returns
        -------
        float or None
            Average value, or None if insufficient data.

        Examples
        --------
        >>> # 4-quarter average revenue
        >>> avg = quarterly_income.revenue.average(periods=4)
        """
        sorted_vals = self._sorted_values()

        if len(sorted_vals) < periods:
            return None

        values = [v.get("val", 0) for v in sorted_vals[:periods]]
        return sum(values) / len(values)

    def __len__(self) -> int:
        """Return number of historical values."""
        return len(self.values)

    def __bool__(self) -> bool:
        """Return True if metric has values."""
        return len(self.values) > 0


@dataclass
class IncomeStatement:
    """
    Income Statement (Profit & Loss Statement) financial data.

    The income statement shows a company's revenues, expenses, and profits
    over a period of time. It answers the question: "Is the company profitable?"

    Attributes
    ----------
    revenue : FinancialMetric
        Total sales/revenue from business operations.
    cost_of_revenue : FinancialMetric
        Direct costs of producing goods/services (COGS).
    gross_profit : FinancialMetric
        Revenue minus cost of revenue.
    research_and_development : FinancialMetric
        R&D expenses for product/technology development.
    selling_general_admin : FinancialMetric
        SG&A expenses (sales, marketing, admin costs).
    operating_expenses : FinancialMetric
        Total operating expenses.
    operating_income : FinancialMetric
        Profit from core operations (EBIT).
    interest_expense : FinancialMetric
        Cost of debt/borrowed funds.
    income_tax_expense : FinancialMetric
        Income taxes paid.
    net_income : FinancialMetric
        Bottom-line profit after all expenses.
    eps_basic : FinancialMetric
        Basic earnings per share.
    eps_diluted : FinancialMetric
        Diluted earnings per share.
    shares_outstanding : FinancialMetric
        Number of shares outstanding.

    Examples
    --------
    >>> income = company.get_income_statement()
    >>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
    >>> print(f"Net Income: ${income.net_income.latest()['val']:,.0f}")
    >>> print(f"Gross Margin: {income.gross_margin():.1%}")
    >>> print(f"Net Margin: {income.net_margin():.1%}")

    See Also
    --------
    BalanceSheet : Company's assets and liabilities.
    CashFlow : Cash movements during the period.
    """

    revenue: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("revenue", "Revenue")
    )
    cost_of_revenue: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("cost_of_revenue", "Cost of Revenue")
    )
    gross_profit: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("gross_profit", "Gross Profit")
    )
    research_and_development: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("research_and_development", "R&D Expenses")
    )
    selling_general_admin: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("selling_general_admin", "SG&A Expenses")
    )
    operating_expenses: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("operating_expenses", "Operating Expenses")
    )
    operating_income: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("operating_income", "Operating Income")
    )
    interest_expense: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("interest_expense", "Interest Expense")
    )
    income_tax_expense: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("income_tax_expense", "Income Tax Expense")
    )
    net_income: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("net_income", "Net Income")
    )
    eps_basic: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("eps_basic", "EPS (Basic)")
    )
    eps_diluted: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("eps_diluted", "EPS (Diluted)")
    )
    shares_outstanding: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("shares_outstanding", "Shares Outstanding")
    )

    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert to pandas DataFrame with dates as index.

        Returns
        -------
        pandas.DataFrame
            DataFrame with date index and metric columns.
            Only includes metrics that have data.

        Examples
        --------
        >>> df = income.to_dataframe()
        >>> df.tail()
                       revenue    net_income     eps_diluted
        2021-12-31  365817000000  94680000000        6.15
        2022-12-31  394328000000  99803000000        6.11
        2023-12-31  383285000000  96995000000        6.13
        """
        metrics = [
            self.revenue, self.cost_of_revenue, self.gross_profit,
            self.research_and_development, self.selling_general_admin,
            self.operating_expenses, self.operating_income,
            self.interest_expense, self.income_tax_expense,
            self.net_income, self.eps_basic, self.eps_diluted,
            self.shares_outstanding
        ]
        series_list = [m.to_series() for m in metrics if m.values]
        if not series_list:
            return pd.DataFrame()
        df = pd.concat(series_list, axis=1)
        df.index = pd.to_datetime(df.index)
        return df.sort_index()

    def summary(self) -> Dict[str, Any]:
        """
        Get a summary of the latest values for key metrics.

        Returns
        -------
        dict
            Dictionary with latest values for key income metrics.

        Examples
        --------
        >>> summary = income.summary()
        >>> print(summary['revenue']['val'])
        394328000000
        """
        return {
            "revenue": self.revenue.latest(),
            "gross_profit": self.gross_profit.latest(),
            "operating_income": self.operating_income.latest(),
            "net_income": self.net_income.latest(),
            "eps_diluted": self.eps_diluted.latest(),
            "shares_outstanding": self.shares_outstanding.latest(),
        }

    def gross_margin(self) -> Optional[float]:
        """
        Calculate gross margin (gross profit / revenue).

        Gross margin measures the percentage of revenue retained after
        direct costs. Higher margins indicate pricing power or
        efficient production.

        Returns
        -------
        float or None
            Gross margin as decimal (e.g., 0.40 = 40%).
            Returns None if data unavailable.

        Notes
        -----
        - Tech companies typically have 60-80% gross margins
        - Retail/manufacturing typically 20-40%
        - Services companies often 50-70%

        Examples
        --------
        >>> margin = income.gross_margin()
        >>> print(f"Gross Margin: {margin:.1%}")
        Gross Margin: 43.3%
        """
        gp = self.gross_profit.latest()
        rev = self.revenue.latest()
        if gp and rev and rev.get("val", 0) != 0:
            return gp.get("val", 0) / rev.get("val")
        return None

    def operating_margin(self) -> Optional[float]:
        """
        Calculate operating margin (operating income / revenue).

        Operating margin shows profitability from core operations,
        before interest and taxes. It measures operational efficiency.

        Returns
        -------
        float or None
            Operating margin as decimal (e.g., 0.25 = 25%).
            Returns None if data unavailable.

        Notes
        -----
        - Also known as EBIT margin
        - Excludes financing decisions and tax effects
        - Useful for comparing companies regardless of capital structure

        Examples
        --------
        >>> margin = income.operating_margin()
        >>> print(f"Operating Margin: {margin:.1%}")
        Operating Margin: 29.8%
        """
        oi = self.operating_income.latest()
        rev = self.revenue.latest()
        if oi and rev and rev.get("val", 0) != 0:
            return oi.get("val", 0) / rev.get("val")
        return None

    def net_margin(self) -> Optional[float]:
        """
        Calculate net profit margin (net income / revenue).

        Net margin is the ultimate measure of profitability,
        showing what percentage of revenue becomes profit after
        all expenses.

        Returns
        -------
        float or None
            Net margin as decimal (e.g., 0.20 = 20%).
            Returns None if data unavailable.

        Notes
        -----
        - Includes all expenses, interest, and taxes
        - Highly variable by industry
        - Can be negative if company is unprofitable

        Examples
        --------
        >>> margin = income.net_margin()
        >>> print(f"Net Margin: {margin:.1%}")
        Net Margin: 25.3%
        """
        ni = self.net_income.latest()
        rev = self.revenue.latest()
        if ni and rev and rev.get("val", 0) != 0:
            return ni.get("val", 0) / rev.get("val")
        return None


@dataclass
class BalanceSheet:
    """
    Balance Sheet (Statement of Financial Position) data.

    The balance sheet shows what a company owns (assets), owes (liabilities),
    and the residual value for shareholders (equity) at a point in time.

    Fundamental equation: Assets = Liabilities + Stockholders' Equity

    Attributes
    ----------
    total_assets : FinancialMetric
        Everything the company owns with economic value.
    current_assets : FinancialMetric
        Assets convertible to cash within one year.
    total_liabilities : FinancialMetric
        Everything the company owes to others.
    current_liabilities : FinancialMetric
        Obligations due within one year.
    stockholders_equity : FinancialMetric
        Book value belonging to shareholders.
    cash : FinancialMetric
        Cash and cash equivalents.
    inventory : FinancialMetric
        Raw materials, WIP, and finished goods.
    accounts_receivable : FinancialMetric
        Money owed by customers.
    long_term_debt : FinancialMetric
        Debt due beyond one year.
    short_term_debt : FinancialMetric
        Debt due within one year.

    Examples
    --------
    >>> balance = company.get_balance_sheet()
    >>> print(f"Total Assets: ${balance.total_assets.latest()['val']:,.0f}")
    >>> print(f"Current Ratio: {balance.current_ratio():.2f}")
    >>> print(f"Debt/Equity: {balance.debt_to_equity():.2f}")

    See Also
    --------
    IncomeStatement : Revenue and profitability over time.
    CashFlow : Cash movements during the period.
    """

    total_assets: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("total_assets", "Total Assets")
    )
    current_assets: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("current_assets", "Current Assets")
    )
    total_liabilities: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("total_liabilities", "Total Liabilities")
    )
    current_liabilities: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("current_liabilities", "Current Liabilities")
    )
    stockholders_equity: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("stockholders_equity", "Stockholders Equity")
    )
    cash: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("cash", "Cash and Equivalents")
    )
    inventory: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("inventory", "Inventory")
    )
    accounts_receivable: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("accounts_receivable", "Accounts Receivable")
    )
    long_term_debt: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("long_term_debt", "Long-term Debt")
    )
    short_term_debt: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("short_term_debt", "Short-term Debt")
    )

    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert to pandas DataFrame with dates as index.

        Returns
        -------
        pandas.DataFrame
            DataFrame with date index and metric columns.
        """
        metrics = [
            self.total_assets, self.current_assets, self.total_liabilities,
            self.current_liabilities, self.stockholders_equity, self.cash,
            self.inventory, self.accounts_receivable, self.long_term_debt,
            self.short_term_debt
        ]
        series_list = [m.to_series() for m in metrics if m.values]
        if not series_list:
            return pd.DataFrame()
        df = pd.concat(series_list, axis=1)
        df.index = pd.to_datetime(df.index)
        return df.sort_index()

    def summary(self) -> Dict[str, Any]:
        """
        Get a summary of the latest values for key metrics.

        Returns
        -------
        dict
            Dictionary with latest values for key balance sheet metrics.
        """
        return {
            "total_assets": self.total_assets.latest(),
            "total_liabilities": self.total_liabilities.latest(),
            "stockholders_equity": self.stockholders_equity.latest(),
            "cash": self.cash.latest(),
            "long_term_debt": self.long_term_debt.latest(),
        }

    def current_ratio(self) -> Optional[float]:
        """
        Calculate current ratio (current assets / current liabilities).

        The current ratio measures a company's ability to pay short-term
        obligations. A ratio above 1.0 indicates the company can cover
        its near-term debts.

        Returns
        -------
        float or None
            Current ratio, or None if data unavailable.

        Notes
        -----
        - Ratio > 1.0: Can cover short-term obligations
        - Ratio < 1.0: May have liquidity issues
        - Ratio > 2.0: May have excess idle assets
        - Industry context matters significantly

        Examples
        --------
        >>> ratio = balance.current_ratio()
        >>> print(f"Current Ratio: {ratio:.2f}")
        Current Ratio: 1.07
        """
        ca = self.current_assets.latest()
        cl = self.current_liabilities.latest()
        if ca and cl and cl.get("val", 0) != 0:
            return ca.get("val", 0) / cl.get("val")
        return None

    def debt_to_equity(self) -> Optional[float]:
        """
        Calculate debt-to-equity ratio (total liabilities / stockholders equity).

        Measures financial leverage - how much debt is used to finance
        assets relative to shareholder investment.

        Returns
        -------
        float or None
            Debt-to-equity ratio, or None if data unavailable.

        Notes
        -----
        - Higher ratio = more leveraged, higher risk
        - Lower ratio = less leveraged, more conservative
        - Varies significantly by industry
        - Banks typically have high D/E (10+)
        - Tech companies often have low D/E (<1)

        Examples
        --------
        >>> ratio = balance.debt_to_equity()
        >>> print(f"Debt/Equity: {ratio:.2f}")
        Debt/Equity: 1.87
        """
        tl = self.total_liabilities.latest()
        eq = self.stockholders_equity.latest()
        if tl and eq and eq.get("val", 0) != 0:
            return tl.get("val", 0) / eq.get("val")
        return None

    def debt_ratio(self) -> Optional[float]:
        """
        Calculate debt ratio (total liabilities / total assets).

        Shows what proportion of assets is financed by debt.

        Returns
        -------
        float or None
            Debt ratio as decimal (0.6 = 60% of assets financed by debt).
            Returns None if data unavailable.

        Notes
        -----
        - Range is typically 0 to 1
        - Higher ratio = more financial risk
        - Also called "liabilities-to-assets ratio"

        Examples
        --------
        >>> ratio = balance.debt_ratio()
        >>> print(f"Debt Ratio: {ratio:.1%}")
        Debt Ratio: 65.2%
        """
        tl = self.total_liabilities.latest()
        ta = self.total_assets.latest()
        if tl and ta and ta.get("val", 0) != 0:
            return tl.get("val", 0) / ta.get("val")
        return None


@dataclass
class CashFlow:
    """
    Cash Flow Statement data.

    The cash flow statement shows how cash moves in and out of the company,
    categorized by operating, investing, and financing activities.
    It answers: "Where did cash come from and where did it go?"

    Attributes
    ----------
    operating_cash_flow : FinancialMetric
        Cash from core business operations.
    investing_cash_flow : FinancialMetric
        Cash from/used for investments and CapEx.
    financing_cash_flow : FinancialMetric
        Cash from/used for financing activities.
    capital_expenditures : FinancialMetric
        Cash spent on property, plant, and equipment.
    dividends_paid : FinancialMetric
        Cash distributed to shareholders.
    free_cash_flow : FinancialMetric
        Cash available after capital expenditures.

    Notes
    -----
    Free Cash Flow (FCF) is calculated as:
    FCF = Operating Cash Flow - Capital Expenditures

    FCF represents cash available for:
    - Paying dividends
    - Buying back stock
    - Paying down debt
    - Making acquisitions
    - Investing in growth

    Examples
    --------
    >>> cashflow = company.get_cash_flow()
    >>> print(f"Operating CF: ${cashflow.operating_cash_flow.latest()['val']:,.0f}")
    >>> print(f"Free CF: ${cashflow.free_cash_flow.latest()['val']:,.0f}")

    See Also
    --------
    IncomeStatement : Revenue and profitability.
    BalanceSheet : Assets and liabilities at a point in time.
    """

    operating_cash_flow: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("operating_cash_flow", "Operating Cash Flow")
    )
    investing_cash_flow: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("investing_cash_flow", "Investing Cash Flow")
    )
    financing_cash_flow: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("financing_cash_flow", "Financing Cash Flow")
    )
    capital_expenditures: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("capital_expenditures", "Capital Expenditures")
    )
    dividends_paid: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("dividends_paid", "Dividends Paid")
    )
    free_cash_flow: FinancialMetric = field(
        default_factory=lambda: FinancialMetric("free_cash_flow", "Free Cash Flow")
    )

    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert to pandas DataFrame with dates as index.

        Returns
        -------
        pandas.DataFrame
            DataFrame with date index and metric columns.
        """
        metrics = [
            self.operating_cash_flow, self.investing_cash_flow,
            self.financing_cash_flow, self.capital_expenditures,
            self.dividends_paid, self.free_cash_flow
        ]
        series_list = [m.to_series() for m in metrics if m.values]
        if not series_list:
            return pd.DataFrame()
        df = pd.concat(series_list, axis=1)
        df.index = pd.to_datetime(df.index)
        return df.sort_index()

    def summary(self) -> Dict[str, Any]:
        """
        Get a summary of the latest values for key metrics.

        Returns
        -------
        dict
            Dictionary with latest values for key cash flow metrics.
        """
        return {
            "operating_cash_flow": self.operating_cash_flow.latest(),
            "investing_cash_flow": self.investing_cash_flow.latest(),
            "financing_cash_flow": self.financing_cash_flow.latest(),
            "free_cash_flow": self.free_cash_flow.latest(),
        }
