"""
XBRL parsing utilities for extracting financial data from SEC filings.

This module provides functions and mappings for parsing XBRL (eXtensible
Business Reporting Language) data from SEC EDGAR company facts. It handles
the complexity of mapping various XBRL concepts to standardized financial
statement fields.

Functions
---------
extract_concept_values
    Extract values for a specific XBRL concept from company facts.
parse_income_statement
    Parse income statement data from company facts.
parse_balance_sheet
    Parse balance sheet data from company facts.
parse_cash_flow
    Parse cash flow statement data from company facts.

Concept Mappings
----------------
INCOME_STATEMENT_CONCEPTS
    Maps XBRL concepts to income statement fields.
BALANCE_SHEET_CONCEPTS
    Maps XBRL concepts to balance sheet fields.
CASH_FLOW_CONCEPTS
    Maps XBRL concepts to cash flow statement fields.

Notes
-----
**XBRL Taxonomy Variations**

Different companies may use different XBRL concepts for the same
financial metric. For example, revenue might be reported as:

- ``Revenues``
- ``RevenueFromContractWithCustomerExcludingAssessedTax``
- ``SalesRevenueNet``

This module handles these variations by mapping multiple concepts to
the same standardized field.

**Deduplication**

When multiple XBRL concepts map to the same field, values are deduplicated
based on the reporting period end date to avoid double-counting.

**Unit Handling**

Financial values are extracted with their original units. Most monetary
values are in USD, while EPS is in USD/shares and share counts are in
shares.

See Also
--------
Company : Uses these parsers to create financial statement objects.
IncomeStatement : Resulting income statement data structure.
BalanceSheet : Resulting balance sheet data structure.
CashFlow : Resulting cash flow data structure.
"""

from typing import Dict, List, Any, Optional
from .financials import (
    FinancialMetric, IncomeStatement, BalanceSheet, CashFlow
)
from .utils import deduplicate_values


# XBRL concept mappings - maps standard concepts to our field names
# Multiple concepts may map to the same field (companies use different tags)

INCOME_STATEMENT_CONCEPTS: Dict[str, str] = {
    # Revenue - Total sales or revenue from operations
    "Revenues": "revenue",
    "RevenueFromContractWithCustomerExcludingAssessedTax": "revenue",
    "SalesRevenueNet": "revenue",
    "SalesRevenueGoodsNet": "revenue",
    "RevenueFromContractWithCustomerIncludingAssessedTax": "revenue",

    # Cost of Revenue - Direct costs of producing goods/services
    "CostOfRevenue": "cost_of_revenue",
    "CostOfGoodsAndServicesSold": "cost_of_revenue",
    "CostOfGoodsSold": "cost_of_revenue",

    # Gross Profit - Revenue minus cost of revenue
    "GrossProfit": "gross_profit",

    # R&D Expenses - Research and development costs
    "ResearchAndDevelopmentExpense": "research_and_development",
    "ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost": "research_and_development",

    # SG&A - Selling, general, and administrative expenses
    "SellingGeneralAndAdministrativeExpense": "selling_general_admin",
    "GeneralAndAdministrativeExpense": "selling_general_admin",

    # Operating Expenses - Total operating costs
    "OperatingExpenses": "operating_expenses",
    "CostsAndExpenses": "operating_expenses",

    # Operating Income - Profit from core operations
    "OperatingIncomeLoss": "operating_income",

    # Interest Expense - Cost of debt financing
    "InterestExpense": "interest_expense",
    "InterestExpenseDebt": "interest_expense",
    "InterestAndDebtExpense": "interest_expense",

    # Income Tax Expense - Tax on earnings
    "IncomeTaxExpenseBenefit": "income_tax_expense",
    "IncomeTaxesPaidNet": "income_tax_expense",

    # Net Income - Bottom-line profit
    "NetIncomeLoss": "net_income",
    "ProfitLoss": "net_income",
    "NetIncomeLossAvailableToCommonStockholdersBasic": "net_income",

    # EPS - Earnings per share
    "EarningsPerShareBasic": "eps_basic",
    "EarningsPerShareDiluted": "eps_diluted",

    # Shares Outstanding - Number of shares
    "CommonStockSharesOutstanding": "shares_outstanding",
    "WeightedAverageNumberOfSharesOutstandingBasic": "shares_outstanding",
    "WeightedAverageNumberOfDilutedSharesOutstanding": "shares_outstanding",
}

BALANCE_SHEET_CONCEPTS: Dict[str, str] = {
    # Total Assets - All company resources
    "Assets": "total_assets",
    "AssetsCurrent": "current_assets",

    # Liabilities - What the company owes
    "Liabilities": "total_liabilities",
    "LiabilitiesCurrent": "current_liabilities",

    # Equity - Shareholders' ownership stake
    "StockholdersEquity": "stockholders_equity",
    "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest": "stockholders_equity",

    # Cash - Cash and cash equivalents
    "CashAndCashEquivalentsAtCarryingValue": "cash",
    "Cash": "cash",
    "CashCashEquivalentsAndShortTermInvestments": "cash",

    # Inventory - Goods held for sale
    "InventoryNet": "inventory",
    "Inventory": "inventory",

    # Receivables - Money owed to the company
    "AccountsReceivableNetCurrent": "accounts_receivable",
    "ReceivablesNetCurrent": "accounts_receivable",

    # Debt - Company borrowings
    "LongTermDebt": "long_term_debt",
    "LongTermDebtNoncurrent": "long_term_debt",
    "ShortTermBorrowings": "short_term_debt",
    "DebtCurrent": "short_term_debt",
}

CASH_FLOW_CONCEPTS: Dict[str, str] = {
    # Operating Cash Flow - Cash from core business
    "NetCashProvidedByUsedInOperatingActivities": "operating_cash_flow",
    "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations": "operating_cash_flow",

    # Investing Cash Flow - Cash from investments
    "NetCashProvidedByUsedInInvestingActivities": "investing_cash_flow",
    "NetCashProvidedByUsedInInvestingActivitiesContinuingOperations": "investing_cash_flow",

    # Financing Cash Flow - Cash from financing
    "NetCashProvidedByUsedInFinancingActivities": "financing_cash_flow",
    "NetCashProvidedByUsedInFinancingActivitiesContinuingOperations": "financing_cash_flow",

    # CapEx - Capital expenditures
    "PaymentsToAcquirePropertyPlantAndEquipment": "capital_expenditures",
    "CapitalExpendituresIncurredButNotYetPaid": "capital_expenditures",

    # Dividends - Cash returned to shareholders
    "PaymentsOfDividends": "dividends_paid",
    "PaymentsOfDividendsCommonStock": "dividends_paid",
}


def extract_concept_values(
    facts: dict,
    concept: str,
    taxonomy: str = "us-gaap",
    period_filter: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Extract values for a specific XBRL concept from company facts.

    Retrieves all reported values for an XBRL concept, optionally filtered
    by form type. Handles different unit types (USD, shares, etc.).

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API (``companyfacts`` endpoint).
    concept : str
        XBRL concept name (e.g., "Revenues", "NetIncomeLoss").
    taxonomy : str, default="us-gaap"
        XBRL taxonomy to search in. Most financial data is in "us-gaap",
        but some data may be in "dei" (document and entity information).
    period_filter : str, optional
        Filter results by SEC form type:

        - ``"10-K"`` : Annual reports only
        - ``"10-Q"`` : Quarterly reports only
        - ``None`` : All form types

    Returns
    -------
    list of dict
        List of value records, each containing:

        - ``val`` : The numeric value
        - ``end`` : Period end date (YYYY-MM-DD)
        - ``start`` : Period start date (if applicable)
        - ``form`` : SEC form type (10-K, 10-Q, etc.)
        - ``filed`` : Date filed with SEC
        - ``accn`` : Accession number

    Examples
    --------
    Get annual revenue values:

    >>> values = extract_concept_values(facts, "Revenues", period_filter="10-K")
    >>> for v in values[-3:]:  # Last 3 years
    ...     print(f"{v['end']}: ${v['val']:,.0f}")

    Get all net income values:

    >>> values = extract_concept_values(facts, "NetIncomeLoss")
    >>> print(f"Found {len(values)} values")

    Notes
    -----
    The function tries different unit types in order of preference:
    USD > shares > pure > USD/shares. This handles monetary values,
    share counts, ratios, and per-share values appropriately.
    """
    try:
        concept_data = facts.get("facts", {}).get(taxonomy, {}).get(concept, {})
        units = concept_data.get("units", {})

        # Get values - try USD first, then shares, then pure numbers
        values = []
        for unit_type in ["USD", "shares", "pure", "USD/shares"]:
            if unit_type in units:
                values = units[unit_type]
                break

        if not values:
            return []

        # Filter to specific form types if requested
        if period_filter:
            values = [v for v in values if v.get("form") == period_filter]

        # Filter to only include values with end dates (exclude instant measurements without context)
        values = [v for v in values if v.get("end")]

        return values
    except (KeyError, TypeError):
        return []


def parse_income_statement(facts: dict, period: str = "annual") -> IncomeStatement:
    """
    Parse income statement data from company facts.

    Extracts all income statement metrics from SEC company facts,
    handling multiple XBRL concept variations for each field.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API (``companyfacts`` endpoint).
    period : str, default="annual"
        Data period to extract:

        - ``"annual"`` : Data from 10-K filings (fiscal year)
        - ``"quarterly"`` : Data from 10-Q filings (quarterly)

    Returns
    -------
    IncomeStatement
        Parsed income statement with all available metrics.

    Examples
    --------
    >>> income = parse_income_statement(facts, period="annual")
    >>> print(f"Revenue: ${income.revenue.latest()['val']:,.0f}")
    >>> print(f"Gross Margin: {income.gross_margin():.1%}")

    Notes
    -----
    Multiple XBRL concepts may map to the same field (e.g., several
    revenue concepts all map to ``revenue``). Values are deduplicated
    by period end date to avoid double-counting.

    See Also
    --------
    IncomeStatement : The returned data structure.
    INCOME_STATEMENT_CONCEPTS : XBRL concept mappings used.
    """
    form_filter = "10-K" if period == "annual" else "10-Q"
    statement = IncomeStatement()

    field_values: Dict[str, List] = {
        "revenue": [], "cost_of_revenue": [], "gross_profit": [],
        "research_and_development": [], "selling_general_admin": [],
        "operating_expenses": [], "operating_income": [],
        "interest_expense": [], "income_tax_expense": [],
        "net_income": [], "eps_basic": [], "eps_diluted": [],
        "shares_outstanding": [],
    }

    for concept, field_name in INCOME_STATEMENT_CONCEPTS.items():
        values = extract_concept_values(facts, concept, period_filter=form_filter)
        if values:
            field_values[field_name].extend(values)

    # Assign to statement fields (deduplicate to handle multiple XBRL concepts)
    statement.revenue.values = deduplicate_values(field_values["revenue"])
    statement.cost_of_revenue.values = deduplicate_values(field_values["cost_of_revenue"])
    statement.gross_profit.values = deduplicate_values(field_values["gross_profit"])
    statement.research_and_development.values = deduplicate_values(field_values["research_and_development"])
    statement.selling_general_admin.values = deduplicate_values(field_values["selling_general_admin"])
    statement.operating_expenses.values = deduplicate_values(field_values["operating_expenses"])
    statement.operating_income.values = deduplicate_values(field_values["operating_income"])
    statement.interest_expense.values = deduplicate_values(field_values["interest_expense"])
    statement.income_tax_expense.values = deduplicate_values(field_values["income_tax_expense"])
    statement.net_income.values = deduplicate_values(field_values["net_income"])
    statement.eps_basic.values = deduplicate_values(field_values["eps_basic"])
    statement.eps_diluted.values = deduplicate_values(field_values["eps_diluted"])
    statement.shares_outstanding.values = deduplicate_values(field_values["shares_outstanding"])

    return statement


def parse_balance_sheet(facts: dict, period: str = "annual") -> BalanceSheet:
    """
    Parse balance sheet data from company facts.

    Extracts all balance sheet metrics from SEC company facts,
    handling multiple XBRL concept variations for each field.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API (``companyfacts`` endpoint).
    period : str, default="annual"
        Data period to extract:

        - ``"annual"`` : Data from 10-K filings (fiscal year)
        - ``"quarterly"`` : Data from 10-Q filings (quarterly)

    Returns
    -------
    BalanceSheet
        Parsed balance sheet with all available metrics.

    Examples
    --------
    >>> balance = parse_balance_sheet(facts, period="annual")
    >>> print(f"Total Assets: ${balance.total_assets.latest()['val']:,.0f}")
    >>> print(f"Current Ratio: {balance.current_ratio():.2f}")

    Notes
    -----
    Balance sheet values are point-in-time measurements as of the
    period end date. Unlike income statement items (which are flows
    over a period), balance sheet items represent balances at a
    specific moment.

    See Also
    --------
    BalanceSheet : The returned data structure.
    BALANCE_SHEET_CONCEPTS : XBRL concept mappings used.
    """
    form_filter = "10-K" if period == "annual" else "10-Q"
    statement = BalanceSheet()

    field_values: Dict[str, List] = {
        "total_assets": [], "current_assets": [], "total_liabilities": [],
        "current_liabilities": [], "stockholders_equity": [], "cash": [],
        "inventory": [], "accounts_receivable": [], "long_term_debt": [],
        "short_term_debt": [],
    }

    for concept, field_name in BALANCE_SHEET_CONCEPTS.items():
        values = extract_concept_values(facts, concept, period_filter=form_filter)
        if values:
            field_values[field_name].extend(values)

    # Assign to statement fields (deduplicate to handle multiple XBRL concepts)
    statement.total_assets.values = deduplicate_values(field_values["total_assets"])
    statement.current_assets.values = deduplicate_values(field_values["current_assets"])
    statement.total_liabilities.values = deduplicate_values(field_values["total_liabilities"])
    statement.current_liabilities.values = deduplicate_values(field_values["current_liabilities"])
    statement.stockholders_equity.values = deduplicate_values(field_values["stockholders_equity"])
    statement.cash.values = deduplicate_values(field_values["cash"])
    statement.inventory.values = deduplicate_values(field_values["inventory"])
    statement.accounts_receivable.values = deduplicate_values(field_values["accounts_receivable"])
    statement.long_term_debt.values = deduplicate_values(field_values["long_term_debt"])
    statement.short_term_debt.values = deduplicate_values(field_values["short_term_debt"])

    return statement


def parse_cash_flow(facts: dict, period: str = "annual") -> CashFlow:
    """
    Parse cash flow statement data from company facts.

    Extracts all cash flow metrics from SEC company facts, handling
    multiple XBRL concept variations. Also calculates free cash flow
    from operating cash flow and capital expenditures.

    Parameters
    ----------
    facts : dict
        Company facts data from SEC API (``companyfacts`` endpoint).
    period : str, default="annual"
        Data period to extract:

        - ``"annual"`` : Data from 10-K filings (fiscal year)
        - ``"quarterly"`` : Data from 10-Q filings (quarterly)

    Returns
    -------
    CashFlow
        Parsed cash flow statement with all available metrics.

    Examples
    --------
    >>> cashflow = parse_cash_flow(facts, period="annual")
    >>> ocf = cashflow.operating_cash_flow.latest()['val']
    >>> fcf = cashflow.free_cash_flow.latest()['val']
    >>> print(f"Operating Cash Flow: ${ocf:,.0f}")
    >>> print(f"Free Cash Flow: ${fcf:,.0f}")

    Notes
    -----
    **Free Cash Flow Calculation**

    Free cash flow is calculated as:

        FCF = Operating Cash Flow - Capital Expenditures

    Capital expenditures may be reported as positive (cash outflow amount)
    or negative depending on the company. This parser uses ``abs(capex)``
    to handle both cases correctly.

    See Also
    --------
    CashFlow : The returned data structure.
    CASH_FLOW_CONCEPTS : XBRL concept mappings used.
    """
    form_filter = "10-K" if period == "annual" else "10-Q"
    statement = CashFlow()

    field_values: Dict[str, List] = {
        "operating_cash_flow": [], "investing_cash_flow": [],
        "financing_cash_flow": [], "capital_expenditures": [],
        "dividends_paid": [], "free_cash_flow": [],
    }

    for concept, field_name in CASH_FLOW_CONCEPTS.items():
        values = extract_concept_values(facts, concept, period_filter=form_filter)
        if values:
            field_values[field_name].extend(values)

    # Assign to statement fields (deduplicate to handle multiple XBRL concepts)
    statement.operating_cash_flow.values = deduplicate_values(field_values["operating_cash_flow"])
    statement.investing_cash_flow.values = deduplicate_values(field_values["investing_cash_flow"])
    statement.financing_cash_flow.values = deduplicate_values(field_values["financing_cash_flow"])
    statement.capital_expenditures.values = deduplicate_values(field_values["capital_expenditures"])
    statement.dividends_paid.values = deduplicate_values(field_values["dividends_paid"])

    # Calculate free cash flow if we have the components
    # FCF = Operating Cash Flow - Capital Expenditures
    # CapEx is typically reported as positive (cash outflow amount), so we subtract it
    # Use abs() to handle cases where it might be reported as negative
    if field_values["operating_cash_flow"] and field_values["capital_expenditures"]:
        ocf_by_date = {v["end"]: v["val"] for v in field_values["operating_cash_flow"]}
        capex_by_date = {v["end"]: v["val"] for v in field_values["capital_expenditures"]}

        fcf_values = []
        for date, ocf in ocf_by_date.items():
            if date in capex_by_date:
                fcf = ocf - abs(capex_by_date[date])
                fcf_values.append({"end": date, "val": fcf})

        statement.free_cash_flow.values = fcf_values

    return statement
