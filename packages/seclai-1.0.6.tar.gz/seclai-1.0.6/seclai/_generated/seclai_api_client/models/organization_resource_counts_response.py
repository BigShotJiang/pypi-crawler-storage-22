from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="OrganizationResourceCountsResponse")


@_attrs_define
class OrganizationResourceCountsResponse:
    """Response model for organization resource counts.

    Attributes:
        knowledge_base_count (int):
        source_count (int):
    """

    knowledge_base_count: int
    source_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        knowledge_base_count = self.knowledge_base_count

        source_count = self.source_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "knowledge_base_count": knowledge_base_count,
                "source_count": source_count,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        knowledge_base_count = d.pop("knowledge_base_count")

        source_count = d.pop("source_count")

        organization_resource_counts_response = cls(
            knowledge_base_count=knowledge_base_count,
            source_count=source_count,
        )

        organization_resource_counts_response.additional_properties = d
        return organization_resource_counts_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
