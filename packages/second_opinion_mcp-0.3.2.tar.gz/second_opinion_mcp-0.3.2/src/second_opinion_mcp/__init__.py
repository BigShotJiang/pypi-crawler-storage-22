"""Second Opinion MCP Server - Multi-model AI analysis for Claude."""

__version__ = "0.3.2"
__author__ = "MarvinFS"

from second_opinion_mcp.server import mcp, second_opinion, challenge, code_review, consensus, review_synthesis

__all__ = [
    "__version__",
    "mcp",
    "second_opinion",
    "challenge",
    "code_review",
    "consensus",
    "review_synthesis",
]
