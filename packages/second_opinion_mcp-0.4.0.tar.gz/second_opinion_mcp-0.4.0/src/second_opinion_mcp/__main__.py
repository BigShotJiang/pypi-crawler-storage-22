#!/usr/bin/env python3
"""Entry point for running second-opinion-mcp as a module or CLI."""
import sys


def main():
    """Main entry point supporting both server and setup commands."""
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        from second_opinion_mcp.cli import setup_wizard
        sys.argv.pop(1)  # Remove 'setup' from argv
        setup_wizard()
    else:
        from second_opinion_mcp.server import main as server_main
        server_main()


if __name__ == "__main__":
    main()
