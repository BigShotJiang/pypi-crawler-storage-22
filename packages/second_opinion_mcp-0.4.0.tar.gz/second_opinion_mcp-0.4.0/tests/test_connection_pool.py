# tests/test_connection_pool.py
import pytest


class TestConnectionPool:
    def test_constants_defined(self):
        from second_opinion_mcp.server import HTTP_MAX_CONNECTIONS, HTTP_MAX_KEEPALIVE
        assert HTTP_MAX_CONNECTIONS == 10
        assert HTTP_MAX_KEEPALIVE == 5
