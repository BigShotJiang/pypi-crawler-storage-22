# tests/test_error_isolation.py
import pytest
from unittest.mock import AsyncMock, patch


class TestErrorIsolation:
    @pytest.mark.asyncio
    async def test_consensus_handles_single_provider_failure(self, monkeypatch):
        from second_opinion_mcp.server import consensus, MODELS

        call_count = {"deepseek": 0, "moonshot": 0}

        async def mock_call_model(provider, *args, **kwargs):
            call_count[provider] = call_count.get(provider, 0) + 1
            if provider == "deepseek":
                raise Exception("DeepSeek unavailable")
            return "Moonshot response"

        monkeypatch.setattr("second_opinion_mcp.server.call_model", mock_call_model)
        monkeypatch.setattr("second_opinion_mcp.server.MODELS", {
            "deepseek": {"enabled": True},
            "moonshot": {"enabled": True},
        })

        result = await consensus(topic="Test")
        # Should not raise, should contain some output
        assert result is not None
        assert "Test" in result or "unavailable" in result
