# tests/test_rate_limiting.py
import pytest


class TestRateLimiting:
    def test_moonshot_semaphore_exists(self):
        from second_opinion_mcp.server import _get_moonshot_semaphore, MOONSHOT_MAX_CONCURRENT
        sem = _get_moonshot_semaphore()
        assert sem._value == MOONSHOT_MAX_CONCURRENT

    def test_deepseek_has_no_rate_limiting(self):
        from second_opinion_mcp.server import MODELS
        # DeepSeek should not have rate limiting config
        assert "rate_limit" not in MODELS.get("deepseek", {})
