# tests/test_streaming_limits.py
import pytest


class TestStreamingLimits:
    def test_constants_defined(self):
        from second_opinion_mcp.server import MAX_STREAMING_CONTENT_BYTES, MAX_STREAMING_REASONING_BYTES
        assert MAX_STREAMING_CONTENT_BYTES == 10 * 1024 * 1024
        assert MAX_STREAMING_REASONING_BYTES == 5 * 1024 * 1024
