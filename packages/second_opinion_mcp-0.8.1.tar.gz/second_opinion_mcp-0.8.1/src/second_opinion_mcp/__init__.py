"""Second Opinion MCP Server - Multi-model AI analysis for Claude."""

__version__ = "0.8.1"
__author__ = "MarvinFS"

__all__ = ["__version__", "__author__"]
