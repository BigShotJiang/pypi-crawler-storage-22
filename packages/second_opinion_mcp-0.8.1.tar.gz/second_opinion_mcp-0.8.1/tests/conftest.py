# tests/conftest.py
import pytest


@pytest.fixture
def mock_keyring(monkeypatch):
    monkeypatch.setattr("second_opinion_mcp.server.keyring.get_password", lambda s, n: "test-api-key")
