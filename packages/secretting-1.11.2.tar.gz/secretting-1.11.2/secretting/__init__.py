from typing import Any
from secrets import choice as _choice, compare_digest
from secrets import token_hex as _tkhex
import random as _rand
from random import random as _random
from string import ascii_letters as letters, digits, punctuation
from hashlib import sha512 as s512, sha256 as s256
from getpass import getpass
import gc

__version__ = '1.11.1'
__author__ = 'kanderusss'

class SecrettingError(Exception):
    pass
class ChaosEngine:
    def __init__(self, level: int = 20):
        self.level = level
    def wrap(self, func, *args, **kw):
        return _choice([func(*args, **kw) for _ in range(self.level)])
    def superWrap(self, func, *args, **kw):
        return _choice([func(*args, **kw) for _ in range(self.level * self.level)])

defaultChaosEngine = ChaosEngine()
chars: tuple = (*letters, *digits, *punctuation)
def salt(length: int = 9) -> str:
    return ''.join(_choice(chars) for _ in range(length))
def sha256(text: str) -> str:
    return s256(text.encode()).hexdigest()
def sha512(text: str) -> str:
    return s512(text.encode()).hexdigest()
def secure256(text: str, customSalt: str = None) -> tuple:
    gSalt: str = customSalt or salt()
    return sha256(text + gSalt), gSalt
def secure512(text: str, customSalt: str = None) -> tuple:
    gSalt: str = customSalt or salt()
    return sha512(text + gSalt), gSalt
def multi256(text: str, times: int = 3) -> str:
    return sha256(text * times)
def multi512(text: str, times: int = 3) -> str:
    return sha512(text * times)
def hashByKey(text: str, key: str, delim: str = '') -> str:
	result = []
	for i, c in enumerate(text):
		result.append(str(ord(c) ^ ord(key[i % len(key)])))
	return delim.join(result)
def randint(min: int, max: int) -> int:
    return defaultChaosEngine.wrap(_rand.randint, min, max)
def choice(seq: list) -> Any:
    return defaultChaosEngine.wrap(_choice, seq)
def random() -> float:
    return defaultChaosEngine.wrap(_rand.random)
def tokenHex(nbytes: int = 32) -> str:
    return defaultChaosEngine.wrap(_tkhex, nbytes)
def safeFunc(func, *args, **kwargs) -> Any:
    return defaultChaosEngine.wrap(func, *args, **kwargs)
def shuffle(seq: list) -> list:
    def _temp():
        temp = list(seq)
        _rand.shuffle(temp)
        return temp
    return defaultChaosEngine.wrap(_temp)
def password(length: int = 12) -> str:
    def raw():
        return ''.join([_choice(chars) for _ in range(length)])
    return defaultChaosEngine.wrap(raw)
def roll(chance: int = 50) -> bool:
    def raw():
        return _rand.randint(1, 100) <= chance
    return defaultChaosEngine.wrap(raw)
def isEqual(a, b) -> bool:
    return compare_digest(a, b)
def loadEnv() -> dict:
    res = {}
    try:
        with open('.env', 'r') as f:
            datas = f.read()
            if datas:
                lines = datas.split('\n')
                for line in lines:
                    args = line.split('=')
                    res[args[0]] = args[1]
    except FileNotFoundError:
        raise SecrettingError("DotEnv file not found.")
    return res
def hiddenInput(prompt: str) -> str:
    return getpass(prompt)
def tokenNum(length: int = 16):
    def raw():
        cdigits = '1234567890'
        return ''.join([_choice(cdigits) for _ in range(length)])
    return defaultChaosEngine.wrap(raw)
def customToken(length: int = 16, symbols = 'kanderus') -> str:
    def raw():
        return ''.join(_choice(symbols) for _ in range(length))
    return defaultChaosEngine.wrap(raw)
def uuid() -> str:
    def raw():
        return '-'.join([''.join(choice([*letters, *digits]) for _ in range(4)) for _ in range(4)])
    return defaultChaosEngine.wrap(raw)
def hide(text: str) -> str:
    binary = ''.join([format(ord(c), '016b') for c in text])
    res = ''
    for c in binary:
        if c == '1':
            res += '\u200b'
        elif c == '0':
            res += '\u200c'
    return res
def reveal(hidden: str) -> str:
    res = ''
    for c in hidden:
        if c == '\u200b':
            res += '1'
        elif c == '\u200c':
            res += '0'
    return ''.join(chr(int(res[i:i+16], 2)) for i in range(0, len(res), 16))
def clearObjs(*objs):
    for obj in objs:
        obj = None
    gc.collect()
def simpleCipher(text: str, num: int = 13) -> str:
    return ''.join([chr(ord(c) + num) for c in text])
def mirrorCipher(text: str) -> str:
    return ''.join([chr(1114111 - ord(c)) for c in text])
def textCipher(text: str) -> str:
    return ''.join([chr(ord(c) ^ len(text)) for c in text])
def tempVar(var: Any) -> str:
    data = [var]
    def access():
        if data[0] == None:
            raise SecrettingError('Access denied.')
        else:
            nonlocal data
            temp = data[0]
            data[0] = None
            return temp
    return access

# you reached the end of secretting lib
# congrats
