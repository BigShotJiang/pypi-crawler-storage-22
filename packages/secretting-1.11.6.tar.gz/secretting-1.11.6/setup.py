from setuptools import setup, find_packages

version = '1.11.6'
desc = 'Stealthy text steganography and high-entropy secret generation.'

setup(
    name='secretting',
    version=version,
    description=desc,
    url="https://pypi.org/project/secretting/",
    project_urls={
        "Documentation": "https://pypi.org/project/secretting/",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    author='kanderusss',
    long_description=f'''# Secretting {version}

# {desc}
# Installation:
```bash
pip install secretting=={version}
```
## If wont work:
```bash
pip3 install secretting=={version}
```

# Example:
```python
from secretting import *

salt() # Output: salt
sha256("a") # Output: hash
secure256("a") # Output: (hash, salt)
isEqual(1, 1) # Output: True
isEqual(1, 2) # Output: False
chars # Output: (ascii_letters, digits, punctuation)
tokenHex(32) # Output: token with 32 bytes

# And more nice tools!
```
# Libs:
## Secrets (choice, compare_digest)
## Random (shuffle, random, randint)
## String (ascii_letters, digits, punctuation)
## Hashlib (sha256, sha512)
## GetPass (getpass)
## Typing (any)

# Github
## [My github account](https://www.youtube.com/watch?v=dQw4w9WgXcQ)

# Random scheme
## Secretting uses Chaos 20 system
## How it works:
```python
import secrets

def x_or_o():
    return secrets.choice(["x", "o"])
def chaos20system(func, *args, **kwargs):
    return secrets.choice([func(*args, **kwargs) for _ in range(20)])
# This is list of 20 funcs.
# Returns 1 random of this list.
# It is more random than secrets.choice and random.choice.
# Secretting made by only this scheme.
# And yeah its made by me.
# You can copy this scheme :-)
# :-) :-) :-) :-) :-) :-) :-) :-) :-)
# :-) :-) :-) :-) :-) :-) :-) :-) :-)
# :-) :-) :-) :-) :-) :-) :-) :-) :-)
# :-) :-) :-) :-) :-) :-) :-) :-) :-)
# :-) :-) :-) :-) :-) :-) :-) :-) :-)
```

# Enjoy it!



hi''',
    long_description_content_type='text/markdown',
    install_requires=[],
    packages=find_packages(),
)
