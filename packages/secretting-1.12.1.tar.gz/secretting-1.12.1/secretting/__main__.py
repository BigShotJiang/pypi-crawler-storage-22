import sys
from . import password, sha512, sha256, __version__, randint

def main():
    if len(sys.argv) < 2:
        print(f"--- Secretting {__version__} ---")
        print("Usage:")
        print("python -m secretting pass [len] - Generate secure password")
        print("python -m secretting sha256 [text] - Hashes text to SHA256")
        print("python -m secretting sha512 [text] - Hashes text to SHA512")
        print("python -m secretting random [min] [max] - Generates random number")
        return

    command = sys.argv[1].lower()

    if command == "pass":
        length = int(sys.argv[2]) if len(sys.argv) > 2 else 12
        print(f"Generated password: {password(length)}")
    elif command == "sha256":
        text = " ".join(sys.argv[2:])
        print(f"Hashed to SHA256: {sha256(text)}")
    elif command == 'sha512':
        text = " ".join(sys.argv[2:])
        print(f"Hashed to SHA512: {sha512(text)}")
    elif command == 'random':
        min = sys.argv[2]
        max = sys.argv[3]
        print(f'Random number from {min} to {max}: {randint(int(min), int(max))}')
    else:
        print(f'Unknown command: "{command}"')

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f'Error: {e.__class__.__name__}: {e}')