"""# Secretting lib.

# Stealthy text steganography and high-entropy secret generation.
# Installation:
```bash
pip install secretting
```
## If wont work:
```bash
pip3 install secretting
```

# Example:
```python
from secretting import *

salt() # Output: salt
sha256("a") # Output: hash
secure256("a") # Output: (hash, salt)
isEqual(1, 1) # Output: True
isEqual(1, 2) # Output: False
chars # Output: (ascii_letters, digits, punctuation)
tokenHex(32) # Output: token with 32 bytes

# And more nice tools!
```
# Libs:
## Secrets (choice, compare_digest)
## Random (shuffle, random, randint)
## String (ascii_letters, digits, punctuation)
## Hashlib (sha256, sha512)
## GetPass (getpass)
## Typing (any)

# Github
## [My github account](https://www.youtube.com/watch?v=dQw4w9WgXcQ)

# Random scheme
## Secretting uses Chaos 20 system
## How it works:
```python
import secrets

def x_or_o():
return secrets.choice(["x", "o"])
def chaos20system(func, *args, **kwargs):
return secrets.choice([func(*args, **kwargs) for _ in range(20)])
# This is list of 20 funcs.
# Returns 1 random of this list.
# It is more random than secrets.choice and random.choice.
# Secretting made by only this scheme.
# And yeah its made by me.
# You can copy this scheme.
```

# Enjoy it!



hi"""


from typing import Any
from secrets import choice as _choice, compare_digest
from secrets import token_hex as _tkhex
import random as _rand
from string import ascii_letters as letters, digits, punctuation, ascii_uppercase as upper
from string import ascii_lowercase as lower
from hashlib import sha512 as s512, sha256 as s256
from getpass import getpass
import gc
from .constants import DEFAULT_RATINGS as ratings, DEFAULT_CHARS as chars, DEFAULT_BLACKLIST as _blacklist
from .exceptions import SecrettingError, ChaosEngineError, BlacklistError

class ChaosEngine:
    """A chaos engine! Wow!"""
    def __init__(self, level: int = 20):
        if level > 4500:
            raise ChaosEngineError("Too big level for chaos engine. Max is 4500.")
        self.level = level
    def wrap(self, func, *args, **kw):
        """Returns safed func."""
        if self.level > 4500:
            raise ChaosEngineError("Too big level for chaos engine. Max is 4500.")
        return _choice([func(*args, **kw) for _ in range(self.level)])
    def superWrap(self, func, *args, **kw):
        """Returns MORE safed func. (Very laggy and very safed)"""
        if self.level > 4500:
            raise ChaosEngineError("Too big level for chaos engine. Max is 4500.")
        return _choice([func(*args, **kw) for _ in range(self.level * self.level)])

defaultChaosEngine = ChaosEngine()
def salt(length: int = 9) -> str:
    """Returns a random salt."""
    return ''.join(_choice(chars) for _ in range(length))
def sha256(text: str) -> str:
    """Returns text hashed to a sha256."""
    return s256(text.encode()).hexdigest()
def sha512(text: str) -> str:
    """Returns text hashed to a sha512."""
    return s512(text.encode()).hexdigest()
def secure256(text: str, customSalt: str = None) -> tuple:
    """Returns hashed to sha256 text and a salt!"""
    gSalt: str = customSalt or salt()
    return sha256(text + gSalt), gSalt
def secure512(text: str, customSalt: str = None) -> tuple:
    """Returns hashed to sha512 text and a salt!"""
    gSalt: str = customSalt or salt()
    return sha512(text + gSalt), gSalt
def multi256(text: str, times: int = 3) -> str:
    """Returns multi sha256"""
    return sha256(text * times)
def multi512(text: str, times: int = 3) -> str:
    """Returns multi sha512."""
    return sha512(text * times)
def hashByKey(text: str, key: str, delim: str = '') -> str:
    """Hashes text by key."""
    result = []
    for i, c in enumerate(text):
        result.append(str(ord(c) ^ ord(key[i % len(key)])))
    return delim.join(result)
def randint(min: int, max: int) -> int:
    """Returns random number between min and max."""
    return defaultChaosEngine.wrap(_rand.randint, min, max)
def choice(seq: list) -> Any:
    """Returns random item from seq."""
    return defaultChaosEngine.wrap(_choice, seq)
def random() -> float:
    """Random float number from 0 to 1."""
    return defaultChaosEngine.wrap(_rand.random)
def tokenHex(nbytes: int = 32) -> str:
    """Just the token hex, what are you looking at?"""
    return defaultChaosEngine.wrap(_tkhex, nbytes)
def safeFunc(func, *args, **kwargs) -> Any:
    """Like the Chaos 20 System!"""
    return defaultChaosEngine.wrap(func, *args, **kwargs)
def shuffle(seq: list) -> list:
    """Shuffles the list."""
    def _temp():
        temp = list(seq)
        _rand.shuffle(temp)
        return temp
    return defaultChaosEngine.wrap(_temp)
def password(length: int = 12) -> str:
    """Generates a new password."""
    def raw():
        return ''.join([_choice(chars) for _ in range(length)])
    return defaultChaosEngine.wrap(raw)
def roll(chance: int = 50) -> bool:
    """Rolls the fake cube. If chance is 30, then it can return True in 30/70 chance."""
    def raw():
        return _rand.randint(1, 100) <= chance
    return defaultChaosEngine.wrap(raw)
def isEqual(a, b) -> bool:
    """Checking is a == b, but safely."""
    return compare_digest(a, b)
def loadEnv() -> dict:
    """Loads the .env (donEnv) file."""
    res = {}
    try:
        with open('.env', 'r') as f:
            datas = f.read()
            if datas:
                lines = datas.split('\n')
                for line in lines:
                    args = line.split('=')
                    res[args[0]] = args[1]
    except FileNotFoundError:
        raise SecrettingError("DotEnv file not found.")
    return res
def hiddenInput(prompt: str) -> str:
    """Returns a hidden input. Basically hides thing that you type."""
    return getpass(prompt)
def tokenNum(length: int = 16):
    """Returns random token number. Sample: '010111212313414515616717818919'"""
    def raw():
        cdigits = '1234567890'
        return ''.join([_choice(cdigits) for _ in range(length)])
    return defaultChaosEngine.wrap(raw)
def customToken(length: int = 16, symbols = 'kanderus') -> str:
    """Returns random token which contains yours symbols."""
    def raw():
        return ''.join(_choice(symbols) for _ in range(length))
    return defaultChaosEngine.wrap(raw)
def uuid() -> str:
    """Generates new UUID. Sample: 'A1a-B2b-C3c-D4d'"""
    def raw():
        return '-'.join([''.join(choice([*letters, *digits]) for _ in range(4)) for _ in range(4)])
    return defaultChaosEngine.wrap(raw)
def hide(text: str) -> str:
    """Hides the text. It can be revealed with reveal() function."""
    binary = ''.join([format(ord(c), '016b') for c in text])
    res = ''
    for c in binary:
        if c == '1':
            res += '\u200b'
        elif c == '0':
            res += '\u200c'
    return res
def reveal(hidden: str) -> str:
    """Reveals the hidden text with hide() function."""
    res = ''
    for c in hidden:
        if c == '\u200b':
            res += '1'
        elif c == '\u200c':
            res += '0'
    return ''.join(chr(int(res[i:i+16], 2)) for i in range(0, len(res), 16))
def clearObjs(*objs):
    """Clears objects (its value after this func will be None)."""
    for obj in objs:
        obj = None
    gc.collect()
def simpleCipher(text: str, num: int = 13) -> str:
    """Classic sipher."""
    return ''.join([chr(ord(c) + num) for c in text])
def mirrorCipher(text: str) -> str:
    """It mirrors the text by unicode (length of unicode is 1114111)."""
    return ''.join([chr(1114111 - ord(c)) for c in text])
def textCipher(text: str) -> str:
    """Return cipher of the text by its length."""
    return ''.join([chr(ord(c) ^ len(text)) for c in text])
def tempVar(var: Any) -> str:
    """Deletes variable after 1 use."""
    data = [var]
    def access():
        nonlocal data
        if data[0] == None:
            raise SecrettingError('Access denied.')
        else:
            temp = data[0]
            data[0] = None
            return temp
    return access
def pwdStrength(pwd, customBlacklist: list = None, blacklistErrOk: bool = True):
    """Evaluates password strength. 0 if blacklisted, otherwise 0-5+."""
    blacklist = _blacklist
    blacklist = blacklist + (customBlacklist or [])

    if pwd.lower() in blacklist:
        if not blacklistErrOk:
            raise BlacklistError(f'Password "{pwd}" is blacklisted!')
        return 0, 'blacklisted'
    result = 0
    result += len(pwd) // 8
    result += int(any([c in digits for c in pwd]))
    result += int(any([c in lower for c in pwd]))
    result += int(any([c in upper for c in pwd]))
    def rate(res):
        label = 'monster'
        for rating, diff in ratings.items():
            parts = rating.split()
            first = int(parts[0])
            last = int(parts[1])
            if len(res) >= first and len(res) <= last:
                label = diff
        return label

    return result, rate(pwd)
def randbytes(nbytes: int = 32):
    return defaultChaosEngine.wrap(_rand.randbytes, nbytes)

# you reached the end of secretting lib
# congrats
