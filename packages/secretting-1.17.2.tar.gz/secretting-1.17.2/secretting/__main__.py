import sys
from . import password, sha512, sha256, randint, uuid, salt
from .constants import VERSION

def main():
    if len(sys.argv) < 2:
        print(f"--- Secretting {VERSION} CLI ---")
        print("Usage:")
        print("python -m secretting pass [len] - Generate secure password")
        print("python -m secretting sha256 [text] - Hashes text to SHA256")
        print("python -m secretting sha512 [text] - Hashes text to SHA512")
        print("python -m secretting random [min] [max] - Generates random number")
        print("python -m secretting uuid - Generates random UUID")
        print("python -m secretting salt [len] - Generates random salt")
        print("python -m secretting data - View all data of secretting")
        return

    cmd = sys.argv[1].lower()

    if cmd == "pass":
        length = int(sys.argv[2]) if len(sys.argv) > 2 else 12
        print(f"Generated password: {password(length)}")
    elif cmd == "sha256":
        text = " ".join(sys.argv[2:])
        print(f"Hashed to SHA256: {sha256(text)}")
    elif cmd == 'sha512':
        text = " ".join(sys.argv[2:])
        print(f"Hashed to SHA512: {sha512(text)}")
    elif cmd == 'random':
        min = sys.argv[2]
        max = sys.argv[3]
        print(f'Random number from {min} to {max}: {randint(int(min), int(max))}')
    elif cmd == 'uuid':
        print(f"UUID: {uuid()}")
    elif cmd == 'salt':
        length = int(sys.argv[2]) if len(sys.argv) > 2 else 12
        print(f"Generated salt: {salt(length)}")
    elif cmd == 'data':
        print(f"""Name: Secretting
Version: {VERSION}
Author: kanderusss
Author email: kanderusss.dev@gmail.com
Url: https://pypi.org/project/secretting/""")
    else:
        print(f'Unknown command: "{command}"')

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f'Error: {e.__class__.__name__}: {e}')
