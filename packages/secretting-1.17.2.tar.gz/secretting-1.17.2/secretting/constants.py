from string import ascii_letters as letters, digits, punctuation

DEFAULT_CHARS: tuple = (*letters, *digits, *punctuation)
DEFAULT_RATINGS = {
        "0 1": "easy",
        "2 5": "normal",
        "6 8": "hard",
        "9 15": "insane",
        "16 25": "extreme",
        "25 90": "impossible"}

DEFAULT_BLACKLIST = ["123456", "12345678", "password", "qwerty", "admin", "12345",
                 '55555', '88888888', '0000', '999999999']
AUTHOR = 'kanderusss'
VERSION = '1.17.2'
