class SecrettingError(Exception):
    """Secretting error. Yeah."""
    def __init__(self, msg, *args, **kw):
        super().__init__(msg, *args, **kw)
class BlacklistError(Exception):
    def __init__(self, msg, *args, **kw):
        super().__init__(msg, *args, **kw)
class ChaosEngineError(Exception):
    def __init__(self, msg, *args, **kw):
        super().__init__(msg, *args, **kw)