from setuptools import setup, find_packages

version = '1.17.2'

desc = 'Stealthy text steganography and high-entropy secret generation.'

setup(
    name='secretting',
    version=version,
    description=desc,
    author_email="kanderusss.dev@gmail.com",
    url="https://pypi.org/project/secretting/",
    project_urls={
        "Documentation": "https://pypi.org/project/secretting/",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Security :: Cryptography'
    ],
    python_requires='>=3.6',
    author='kanderusss',
    long_description=f'''# Secretting {version}

# {desc}
# Installation:
```bash
pip install secretting=={version}
```
## If wont work:
```bash
pip3 install secretting=={version}
```

# Example:
```python
from secretting import *

salt() # Output: salt
sha256("a") # Output: hash
secure256("a") # Output: (hash, salt)
isEqual(1, 1) # Output: True
isEqual(1, 2) # Output: False
chars # Output: (ascii_letters, digits, punctuation)
tokenHex(32) # Output: token with 32 bytes

# And more nice tools!
```
# Libs:
## Secrets (choice, compare_digest)
## Random (shuffle, random, randint)
## String (ascii_letters, digits, punctuation)
## Hashlib (sha256, sha512)
## GetPass (getpass)
## Typing (any)

# Github
## [My github account](https://www.youtube.com/watch?v=dQw4w9WgXcQ)

# Random scheme
## Secretting uses Chaos 20 system
## How it works:
```python
import secrets

def x_or_o():
    return secrets.choice(["x", "o"])
def chaos20system(func, *args, **kwargs):
    return secrets.choice([func(*args, **kwargs) for _ in range(20)])
# This is list of 20 functions runs.
# Chaos 20 System returns 1 random of this list.
# It is more random than secrets.choice and random.choice.
# Secretting made by this scheme only.
# And yeah its made by me.
# You can copy this scheme.
```

# Changelog

# [{version}]

## Fixed
- **CLI was fixed.**


# Enjoy it!

![PyPI - Version](https://img.shields.io/pypi/v/secretting)
![PyPI - Downloads](https://img.shields.io/pypi/dm/secretting)
![PyPI - License](https://img.shields.io/pypi/l/secretting)
![PyPi - Badge](https://img.shields.io/pypi/v/secretting?color=green&logo=python)
![PyPi - Status](https://img.shields.io/pypi/status/secretting)
![PyPi - Format](https://img.shields.io/pypi/format/secretting)
![PyPi - PyVersions](https://img.shields.io/pypi/pyversions/secretting)
![PyPi - Author](https://img.shields.io/badge/Author-Kanderusss-Color)
![PyPi - Thanks](https://img.shields.io/badge/Thanks_For_Using-Secretting-Green)
![PyPI Downloads](https://static.pepy.tech/personalized-badge/secretting?left_color=BLACK&right_color=GREEN&left_text=downloads)
''',
    long_description_content_type='text/markdown',
    install_requires=[],
    packages=find_packages(),
    license='MIT'
)
