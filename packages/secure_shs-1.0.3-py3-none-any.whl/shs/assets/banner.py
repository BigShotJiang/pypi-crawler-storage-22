"""Banner display module for SHS CLI."""

from __future__ import annotations

from pathlib import Path
import sys
from colorama import Fore, Style


def print_banner() -> None:
    """Print SHS banner to console."""
    banner_path = Path(__file__).parent / "banner.txt"
    
    try:
        banner_text = banner_path.read_text(encoding="utf-8")
        # Guard against console encoding errors (Windows CP1252 etc.)
        out_enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        safe = banner_text.encode(out_enc, errors="replace").decode(out_enc)
        print(Fore.CYAN + safe + Style.RESET_ALL)
    except FileNotFoundError:
        # Fallback banner if file not found
        print_fallback_banner()
    except Exception as e:
        # Catch any other errors (encoding issues, etc.)
        print_fallback_banner()


def print_fallback_banner() -> None:
    """Print fallback banner if banner.txt not found."""
    fallback = """
   ███████╗██╗  ██╗███████╗
   ██╔════╝██║  ██║██╔════╝
   ███████╗███████║███████╗
   ╚════██║██╔══██║╚════██║
   ███████║██║  ██║███████║
   ╚══════╝╚═╝  ╚═╝╚══════╝

   Security Hygiene Scanner (SHS)
   Detect bad security practices before attackers do.
   --------------------------------------------------
"""
    try:
        # Try to print with proper encoding handling
        print(Fore.CYAN + fallback + Style.RESET_ALL)
    except (UnicodeEncodeError, UnicodeDecodeError):
        # If still fails, use ASCII-only version
        print(Fore.CYAN)
        print("=" * 50)
        print("Security Hygiene Scanner (SHS)")
        print("Detect bad security practices before attackers do.")
        print("=" * 50)
        print(Style.RESET_ALL)

