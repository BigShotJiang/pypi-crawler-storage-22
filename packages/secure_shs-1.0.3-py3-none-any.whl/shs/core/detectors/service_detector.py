"""
Real service status detection via OS service managers.

This module queries actual service status using systemctl/service (Linux)
and sc query/Get-Service (Windows), not process checks.
Enterprise-grade, false-positive safe.
"""

from __future__ import annotations

import platform
import subprocess
import shlex
import sys
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Tuple


# ============================
# ENUMS & DATA MODELS
# ============================

class ServiceStatus(Enum):
    RUNNING = "running"
    STOPPED = "stopped"
    DISABLED = "disabled"
    UNKNOWN = "unknown"


@dataclass
class ServiceInfo:
    name: str
    status: ServiceStatus
    method_used: str
    details: Dict[str, str]
    confidence: float


# ============================
# PUBLIC API
# ============================

def get_service_status(service_name: str, debug: bool = False) -> ServiceInfo:
    os_type = platform.system()

    if debug:
        print(f"[DEBUG] Checking service '{service_name}' on {os_type}", file=sys.stderr)

    if os_type == "Windows":
        return _check_windows_service(service_name, debug)
    elif os_type == "Linux":
        return _check_linux_service(service_name, debug)
    else:
        return ServiceInfo(
            name=service_name,
            status=ServiceStatus.UNKNOWN,
            method_used="unsupported_os",
            details={"error": f"Unsupported OS: {os_type}"},
            confidence=0.0,
        )


# ============================
# WINDOWS SERVICE CHECK
# ============================

def _check_windows_service(service_name: str, debug: bool) -> ServiceInfo:
    details = {}

    # ---- METHOD 1: sc query ----
    rc, out = _run(f"sc query {service_name}")
    details["sc_query"] = out.strip()

    if rc == 0 and out:
        for line in out.splitlines():
            if "STATE" in line:
                if "RUNNING" in line:
                    return _ok(service_name, ServiceStatus.RUNNING, "sc_query", details)
                if "STOPPED" in line:
                    return _ok(service_name, ServiceStatus.STOPPED, "sc_query", details)

    # ---- METHOD 2: service start mode (DISABLED check) ----
    rc, out = _run(f"sc qc {service_name}")
    details["sc_qc"] = out.strip()

    if rc == 0 and "DISABLED" in out.upper():
        return _ok(service_name, ServiceStatus.DISABLED, "sc_qc", details)

    # ---- METHOD 3: PowerShell ----
    rc, out = _run(
        f"powershell -NoProfile -Command \"(Get-Service {service_name}).Status\""
    )
    details["powershell"] = out.strip()

    if "Running" in out:
        return _ok(service_name, ServiceStatus.RUNNING, "powershell", details)
    if "Stopped" in out:
        return _ok(service_name, ServiceStatus.STOPPED, "powershell", details)

    return _unknown(service_name, "windows_fallback", details)


# ============================
# LINUX SERVICE CHECK
# ============================

def _check_linux_service(service_name: str, debug: bool) -> ServiceInfo:
    details = {}

    # ---- METHOD 1: systemctl is-enabled ----
    rc, out = _run(f"systemctl is-enabled {service_name}")
    details["enabled_state"] = out.strip()

    if rc == 0 and "disabled" in out.lower():
        return _ok(service_name, ServiceStatus.DISABLED, "systemctl_is_enabled", details)

    # ---- METHOD 2: systemctl is-active ----
    rc, out = _run(f"systemctl is-active {service_name}")
    details["active_state"] = out.strip()

    if "active" in out:
        return _ok(service_name, ServiceStatus.RUNNING, "systemctl_is_active", details)
    if "inactive" in out:
        return _ok(service_name, ServiceStatus.STOPPED, "systemctl_is_active", details)

    # ---- METHOD 3: systemctl show ----
    rc, out = _run(f"systemctl show {service_name} --property=ActiveState")
    details["show_state"] = out.strip()

    if "ActiveState=active" in out:
        return _ok(service_name, ServiceStatus.RUNNING, "systemctl_show", details)
    if "ActiveState=inactive" in out:
        return _ok(service_name, ServiceStatus.STOPPED, "systemctl_show", details)

    return _unknown(service_name, "linux_fallback", details)


# ============================
# HELPERS
# ============================

def _ok(name: str, status: ServiceStatus, method: str, details: Dict[str, str]) -> ServiceInfo:
    return ServiceInfo(
        name=name,
        status=status,
        method_used=method,
        details=details,
        confidence=1.0,
    )


def _unknown(name: str, method: str, details: Dict[str, str]) -> ServiceInfo:
    return ServiceInfo(
        name=name,
        status=ServiceStatus.UNKNOWN,
        method_used=method,
        details=details,
        confidence=0.0,
    )


def _run(cmd: str) -> Tuple[int, str]:
    try:
        if isinstance(cmd, (list, tuple)):
            args = list(cmd)
            p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=5)
        else:
            if any(op in cmd for op in ("||", "&&", "|", ">", "2>")):
                p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=5)
            else:
                args = shlex.split(cmd)
                p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=5)
        return p.returncode, p.stdout or ""
    except subprocess.TimeoutExpired:
        return -1, "[TIMEOUT]"
    except Exception as e:
        return -1, f"[ERROR] {e}"
