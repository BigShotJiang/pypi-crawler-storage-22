from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path
from typing import Iterable, List

import psutil

from .rules import Finding, Severity

def auto_remediate(base_path: Path | None = None) -> List[Finding]:
    root = base_path or Path.cwd()
    findings: List[Finding] = []
    findings.extend(_enable_firewall())
    findings.extend(_fix_world_writable(root))
    findings.extend(_recommend_mfa())
    findings.extend(_suggest_user_cleanup())
    return findings


def _enable_firewall() -> List[Finding]:
    results: List[Finding] = []
    if not shutil.which("ufw"):
        return results
    code, output = _run_command("ufw status")
    if code != 0 or "Status: active" in output:
        return results
    if os.geteuid() != 0:
        results.append(
            Finding(
                id="FIX_FIREWALL_ENABLE_REQUIRED",
                title="Firewall not enabled and root privileges required to modify",
                severity=Severity.MEDIUM,
                category="fix",
                description="Firewall appears disabled but cannot be enabled without root",
                recommendation="Run SHS with elevated privileges to enable the firewall",
                metadata={},
            )
        )
        return results
    code, _ = _run_command("ufw --force enable")
    if code == 0:
        results.append(
            Finding(
                id="FIX_FIREWALL_ENABLED",
                title="Firewall enabled using ufw",
                severity=Severity.LOW,
                category="fix",
                description="Host-based firewall has been enabled",
                recommendation="Review ufw rules to ensure least privilege access",
                metadata={},
            )
        )
    return results


def _fix_world_writable(root: Path) -> List[Finding]:
    results: List[Finding] = []
    for dirpath, dirnames, filenames in os.walk(root):
        if ".git" in dirnames:
            dirnames.remove(".git")
        for name in filenames:
            path = Path(dirpath) / name
            try:
                st = path.stat()
            except OSError:
                continue
            if not st.st_mode & stat.S_IWOTH:
                continue
            try:
                new_mode = st.st_mode & ~stat.S_IWOTH
                os.chmod(path, new_mode)
                results.append(
                    Finding(
                        id="FIX_WORLD_WRITABLE_REMOVED",
                        title="World-writable permission removed",
                        severity=Severity.LOW,
                        category="fix",
                        description="World-writable bit cleared from file permissions",
                        recommendation="Verify file ownership and group membership if required",
                        metadata={"path": str(path)},
                    )
                )
            except PermissionError:
                continue
    return results


def _recommend_mfa() -> List[Finding]:
    return [
        Finding(
            id="FIX_MFA_RECOMMENDATION",
            title="Enable MFA for privileged accounts",
            severity=Severity.MEDIUM,
            category="fix",
            description="MFA is not something SHS can enable automatically",
            recommendation="Configure MFA for SSH and cloud administrator accounts",
            metadata={},
        )
    ]


def _suggest_user_cleanup() -> List[Finding]:
    results: List[Finding] = []
    try:
        import pwd
    except ImportError:
        return results
    inactive = []
    current = os.getenv("USER") or ""
    for user in pwd.getpwall():
        if user.pw_uid < 1000:
            continue
        if user.pw_name == current:
            continue
        if user.pw_shell in {"/bin/false", "/usr/sbin/nologin"}:
            continue
        inactive.append(user.pw_name)
    if inactive:
        results.append(
            Finding(
                id="FIX_INACTIVE_USER_SUGGEST",
                title="Review and remove inactive local users",
                severity=Severity.MEDIUM,
                category="fix",
                description="Several local accounts may no longer be needed",
                recommendation="Manually disable or remove inactive users after verification",
                metadata={"accounts": ",".join(sorted(inactive))},
            )
        )
    return results


def _run_command(command: str) -> tuple[int, str]:
    import subprocess
    import shlex

    try:
        # Prefer running with a list (no shell) when possible
        if isinstance(command, (list, tuple)):
            args = list(command)
            completed = subprocess.run(args, check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=10)
        else:
            # If command contains shell-specific operators, fall back to shell=True
            if any(op in command for op in ("||", "&&", "|", ">", "2>")):
                completed = subprocess.run(command, shell=True, check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=10)
            else:
                args = shlex.split(command)
                completed = subprocess.run(args, check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=10)
        return completed.returncode, completed.stdout or ""
    except subprocess.TimeoutExpired:
        return 1, "[TIMEOUT]"
    except Exception:
        return 1, ""


