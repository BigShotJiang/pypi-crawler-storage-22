from __future__ import annotations

import socket
import time
import subprocess
import shutil
import ipaddress
from typing import Dict, List, Tuple, Any

import psutil

from shs.core.rules import Finding, Severity
from shs.core.capabilities import CapabilityDetector


# ----------------------------
# Service risk map
# ----------------------------
CRITICAL_PORTS = {
    21: "FTP",
    23: "Telnet",
    6379: "Redis",
    27017: "MongoDB",
    3306: "MySQL",
    5432: "PostgreSQL",
    2375: "Docker API",
    6443: "Kubernetes API",
}

WARNING_PORTS = {
    22: "SSH",
    3389: "RDP",
    80: "HTTP",
    8080: "HTTP-alt",
    445: "SMB",
}


def _print(msg: str) -> None:
    print(msg)
    # small, professional pacing
    time.sleep(0.08)


def scan_interfaces() -> List[Dict[str, Any]]:
    _print("[*] Enumerating network interfaces")
    interfaces = []
    try:
        addrs = psutil.net_if_addrs()
    except Exception:
        return interfaces

    for name, addrs_list in addrs.items():
        ips = []
        for a in addrs_list:
            if a.family == socket.AF_INET or getattr(socket, "AF_INET6", None) and a.family == socket.AF_INET6:
                ip = a.address
                ips.append(ip)
        if not ips:
            continue
        interfaces.append({"name": name, "ips": ips})
        for ip in ips:
            _print(f"    Interface detected: {name} ({ip})")

    return interfaces


def scan_ports() -> List[Dict[str, Any]]:
    _print("[*] Enumerating listening services")
    results: List[Dict[str, Any]] = []
    seen = set()
    try:
        conns = psutil.net_connections(kind="inet")
    except Exception:
        return results

    for c in conns:
        # Skip entries without local address
        if not c.laddr:
            continue

        laddr = c.laddr
        port = getattr(laddr, "port", None)
        ip = getattr(laddr, "ip", None) or getattr(laddr, "address", None) or laddr[0]

        # Normalize for UDP sockets: treat UDP with a local address as listening
        is_listen = False
        try:
            if c.type == socket.SOCK_DGRAM:
                is_listen = True
            else:
                is_listen = c.status == psutil.CONN_LISTEN
        except Exception:
            is_listen = False

        if not is_listen:
            continue

        key = (ip, port, c.pid)
        if key in seen:
            continue
        seen.add(key)

        results.append({
            "ip": ip,
            "port": port,
            "pid": c.pid,
            "type": "udp" if c.type == socket.SOCK_DGRAM else "tcp",
            "raddr": getattr(c, "raddr", None),
        })

        _print(f"    Listening: {ip}:{port} (pid={c.pid})")

    return results


def map_processes(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    _print("[*] Mapping ports to processes")
    pid_cache: Dict[int, Tuple[str, str]] = {}
    mapped = []

    for e in entries:
        pid = e.get("pid")
        proc_name = "<unknown>"
        user = "<unknown>"
        if pid is None:
            proc_name = "kernel"
        else:
            if pid in pid_cache:
                proc_name, user = pid_cache[pid]
            else:
                try:
                    p = psutil.Process(pid)
                    proc_name = p.name()
                    try:
                        user = p.username()
                    except Exception:
                        user = "<unknown>"
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    proc_name = "<unknown>"
                    user = "<unknown>"
                pid_cache[pid] = (proc_name, user)

        e.update({"process": proc_name, "user": user})
        _print(f"    Port {e['port']} → {proc_name} → {user}")
        mapped.append(e)

    return mapped


def _check_firewall_enabled() -> Tuple[bool, dict]:
    caps = CapabilityDetector.detect()
    meta = {}
    if not caps.firewall_check:
        return True, {"note": "firewall check unsupported"}

    import platform

    try:
        if platform.system() == "Windows":
            p = subprocess.run(
                ["netsh", "advfirewall", "show", "allprofiles"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            out = p.stdout or ""
            enabled = "ON" in out
            meta["raw"] = out.splitlines()[:5]
            return enabled, meta

        if platform.system() == "Linux":
            # prefer shutil.which rather than shelling out to `which`
            if shutil.which("ufw"):
                p = subprocess.run(["ufw", "status"], stdout=subprocess.PIPE, text=True)
                out = p.stdout or ""
                enabled = "Status: active" in out
                meta["ufw"] = out.splitlines()[:3]
                return enabled, meta

            if shutil.which("firewall-cmd"):
                p = subprocess.run(["firewall-cmd", "--state"], stdout=subprocess.PIPE, text=True)
                out = p.stdout or ""
                enabled = "running" in out.lower()
                meta["firewalld"] = out.strip()
                return enabled, meta

            # fallback: check iptables existence
            if shutil.which("iptables"):
                p = subprocess.run(["iptables", "-L"], stdout=subprocess.PIPE, text=True)
                out = p.stdout or ""
                enabled = "Chain" in out
                meta["iptables"] = "rules present" if enabled else "no rules"
                return enabled, meta

        if platform.system() == "Darwin":
            p = subprocess.run(
                ["defaults", "read", "/Library/Preferences/com.apple.alf", "globalstate"],
                stdout=subprocess.PIPE,
                text=True,
            )
            out = p.stdout or ""
            enabled = out.strip() == "1"
            meta["raw"] = out.strip()
            return enabled, meta

    except Exception:
        pass

    return True, {"note": "unknown firewall state"}






def classify_services(entries: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    _print("[*] Classifying exposure")
    findings = []
    safe_log = []

    fw_enabled, fw_meta = _check_firewall_enabled()

    for e in entries:
        port = e.get("port")
        ip = e.get("ip")
        process = e.get("process")
        user = e.get("user")

        # Basic exposure checks
        try:
            ip_obj = ipaddress.ip_address(ip)
        except Exception:
            ip_obj = None

        is_listen_all = ip in ("0.0.0.0", "::")
        exposed_public = False
        if ip_obj and not ip_obj.is_private and not ip_obj.is_loopback:
            exposed_public = True

        # Risk classification
        severity = Severity.INFO
        category = "network"
        title = f"Service on port {port}"
        recommendation = "Review service exposure and restrict access"
        description = f"{process} listening on {ip}:{port}"

        # Known critical ports
        if port in CRITICAL_PORTS:
            severity = Severity.CRITICAL
            title = f"{CRITICAL_PORTS[port]} exposed"
            recommendation = f"Disable or restrict {CRITICAL_PORTS[port]}; bind to localhost or firewall rule"

        elif port in WARNING_PORTS:
            severity = Severity.MEDIUM
            title = f"{WARNING_PORTS[port]} service detected"
            recommendation = f"Verify {WARNING_PORTS[port]} access controls and harden authentication"

        # High ephemeral ports considered safe unless user is admin or bound to 0.0.0.0
        elif port and port > 49152:
            severity = Severity.INFO

        # Adjust severity for exposure
        if severity != Severity.INFO:
            if is_listen_all or exposed_public:
                # escalate one level when listening on all interfaces or public IP
                if severity == Severity.MEDIUM:
                    severity = Severity.HIGH
                elif severity == Severity.CRITICAL:
                    severity = Severity.CRITICAL

        # Penalize if firewall disabled and service is externally exposed
        if not fw_enabled and (is_listen_all or exposed_public):
            if severity == Severity.INFO:
                severity = Severity.MEDIUM
            elif severity == Severity.MEDIUM:
                severity = Severity.HIGH

        # Penalize if process runs as admin/root
        if isinstance(user, str) and user.lower() in ("root", "system", "nt authority\\system", "administrator"):
            if severity == Severity.INFO:
                severity = Severity.MEDIUM
            elif severity == Severity.MEDIUM:
                severity = Severity.HIGH

        meta = {
            "ip": ip,
            "port": port,
            "process": process,
            "user": user,
            "listen_all": is_listen_all,
            "public_exposed": exposed_public,
            "firewall_enabled": fw_enabled,
        }

        entry = {**e, "severity": severity, "title": title, "recommendation": recommendation, "description": description, "metadata": meta}

        if severity == Severity.INFO:
            # Safe: log for audit, not returned as a finding
            safe_log.append(entry)
        else:
            findings.append(entry)

    return findings, safe_log


def generate_findings(classified: List[Dict[str, Any]]) -> List[Finding]:
    _print("[*] Generating findings")
    result: List[Finding] = []
    for idx, e in enumerate(classified, start=1):
        sev = e.get("severity", Severity.INFO)
        title = e.get("title")
        desc = e.get("description")
        rec = e.get("recommendation")
        meta = e.get("metadata") or {}

        fid = f"NET_{e.get('port')}_{idx}"
        result.append(
            Finding(
                id=fid,
                title=title,
                severity=sev,
                category="network",
                description=desc,
                recommendation=rec,
                metadata=meta,
            )
        )

    return result


def summary(all_entries: List[Dict[str, Any]], safe: List[Dict[str, Any]], findings: List[Finding]) -> None:
    _print("[*] Summary")
    total = len(all_entries)
    safe_count = len(safe)
    critical = sum(1 for f in findings if f.severity == Severity.CRITICAL)
    high = sum(1 for f in findings if f.severity == Severity.HIGH)
    medium = sum(1 for f in findings if f.severity == Severity.MEDIUM)

    _print("Network summary:")
    _print(f"  Total ports scanned: {total}")
    _print(f"  Safe: {safe_count}")
    _print(f"  Warning/Medium: {medium}")
    _print(f"  High: {high}")
    _print(f"  Critical: {critical}")


def run_scan() -> List[Finding]:
    # Full passive scan flow
    interfaces = scan_interfaces()
    entries = scan_ports()
    mapped = map_processes(entries)
    classified, safe_log = classify_services(mapped)

    findings = generate_findings(classified)

    # Log safe ones to audit (INFO severity)
    for s in safe_log:
        # print brief audit lines but do not include as findings
        _print(f"[AUDIT] SAFE: {s['process']} on {s['ip']}:{s['port']}")

    summary(mapped, safe_log, findings)

    # Only return risky findings (Severity != INFO)
    return findings
