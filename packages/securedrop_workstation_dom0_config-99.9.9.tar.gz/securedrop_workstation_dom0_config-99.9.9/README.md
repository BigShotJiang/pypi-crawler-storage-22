# Steiner254  --- Security Research: Dependency Confusion PoC

## Overview
RCE POC -  **Dependency Confusion**. 

## Intent
**This package is harmless.** It does not collect sensitive data, modify system files, or establish persistent backdoors. Upon installation, it performs a single DNS/HTTP callback to a private listener to verify successful code execution.
## Contents
- `setup.py`: Contains a post-install hook to trigger a callback to a research-controlled OAST domain.

## Disclaimer
If you are not the intended audience and have accidentally installed this package, please uninstall it immediately:
`pip uninstall securedrop-workstation-dom0-config`

The author is not responsible for any accidental installations. This package will be removed once the research is concluded.
