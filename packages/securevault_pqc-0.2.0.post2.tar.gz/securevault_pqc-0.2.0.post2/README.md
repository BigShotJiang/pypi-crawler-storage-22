# SecureVault - Post-Quantum File Encryption
***Protect your files from future quantum computers.***

SecureVault is a cross-platform post-quantum encryption tool that protects files using NIST-standardized ML-KEM-768 combined with classical X25519 hybrid encryption.

![Python Version](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Platform](https://img.shields.io/badge/platform-linux%20%7C%20macos%20%7C%20windows-lightgrey)
![Cryptography](https://img.shields.io/badge/crypto-ML--KEM--768-purple)
![NIST](https://img.shields.io/badge/NIST-Post--Quantum-orange)
![Status](https://img.shields.io/badge/status-active-success)


## The Problem
Quantum computers will break RSA/ECC encryption within 10-20 years. 
Attackers are stealing encrypted data NOW to decrypt LATER.

This is called "**harvest now, decrypt later**" attacks.

## The Solution
SecureVault uses:

- ML-KEM-768 (NIST standardized post-quantum KEM)  
- X25519 (classical elliptic-curve)  
- Hybrid encryption (both together)

Even if one system is broken in the future, the other still protects your data (I like to call this defense in depth²)


## Features

- **Hybrid encryption**: X25519 + ML-KEM-768 (defense in depth²)
- **AES-256-GCM file encryption**
- **Password-protected keys**: PBKDF2 key derivation (100k iterations)
- **Cross-platform**: Works on Linux, macOS, and Windows
- **Future-proof**: Quantum-resistant for 30+ years
- **Digital signatures**: Ed25519 + ML-DSA-65  
- **Easy CLI + Desktop GUI**: Simple commands, no crypto knowledge needed; very easy to navigate
- **No installation required for GUI**: Download and run - works out of the box
- **Educational**: Shows security info about your files
- **Designed for long-term security**

## Choose Your Version

| Version | Best For | Installation |
|---------|----------|--------------|
| **Desktop GUI** | Most users, drag-and-drop simplicity | [Download](https://meganealexis.net/securevault/) |
| **CLI** | Developers, automation, scripting | `pip install securevault-pqc` |

## Installation

### Option 1: Desktop GUI (Recommended for most users)

Download the standalone application for your platform:

🔗 **[Download SecureVault GUI](https://meganealexis.net/securevault/)**

**Available for:**
- Windows (`.exe`)
- macOS (`.app`)
- Linux (executable)

**Security verification:**
Before running the downloaded file, verify its integrity using the checksums provided on the download page. This ensures your download wasn't modified or intercepted.
```bash
# macOS/Linux
shasum -a 256 SecureVault-macos

# Windows (PowerShell)
Get-FileHash SecureVault-windows.exe -Algorithm SHA256
```

Compare the output with the checksum at: https://meganealexis.net/securevault/

**No installation required** - just download, verify, and run!

---

### Option 2: Command-Line Interface (CLI)

For developers, automation, or advanced users who prefer the terminal.

#### Prerequisites
- Python 3.9 or higher
- pip

#### Platform-Specific Setup

##### macOS Setup
```bash
# 1. Install CMake (if not already installed)
brew install cmake

# 2. Build liboqs with shared library support
cd /tmp
git clone --branch 0.15.0 https://github.com/open-quantum-safe/liboqs.git
cd liboqs
mkdir build && cd build
cmake -DBUILD_SHARED_LIBS=ON -DCMAKE_INSTALL_PREFIX=/opt/homebrew/opt/liboqs ..
make -j$(sysctl -n hw.ncpu)
sudo make install

# 3. Create symlinks where liboqs-python expects the library
mkdir -p ~/.oqs/lib ~/.oqs/lib64
ln -sf /opt/homebrew/opt/liboqs/lib/liboqs.dylib ~/.oqs/lib/liboqs.dylib
ln -sf /opt/homebrew/opt/liboqs/lib/liboqs.dylib ~/.oqs/lib64/liboqs.dylib

# 4. Create and activate virtual environment
cd ~/Documents/Testing_securevault
python3 -m venv venv
source venv/bin/activate

# 5. Install SecureVault
pip install securevault-pqc

# 6. Test it!
securevault --help
```

##### Windows Setup
```bash
# 1. Install Chocolatey build tools (if not already installed)
choco install visualstudio2022buildtools visualstudio2022-workload-vctools -y

# 2. Build liboqs
cd $env:TEMP
git clone --branch 0.15.0 https://github.com/open-quantum-safe/liboqs.git
cd liboqs
mkdir build
cd build

cmake -DBUILD_SHARED_LIBS=ON `
  -DCMAKE_INSTALL_PREFIX="$env:USERPROFILE\_oqs" `
  -G "Visual Studio 17 2022" -A x64 ..

cmake --build . --config Release
cmake --install . --config Release

# 3. Verify DLL was created 
ls "$env:USERPROFILE\_oqs\bin\oqs.dll"

# 4. Create and activate virtual environment
cd ~/Documents/Testing_securevault
python -m venv venv
.\venv\Scripts\Activate.ps1

# 5. Install SecureVault
pip install securevault-pqc

# 6. Test it!
securevault --help
```

##### Linux Setup
```bash
# 1. Install dependencies (Ubuntu/Debian)
sudo apt-get update
sudo apt-get install cmake build-essential

# 2. Create and activate virtual environment
cd ~/Documents/Testing_securevault
python3 -m venv venv
source venv/bin/activate

# 3. Install SecureVault
pip install securevault-pqc

# 4. Test it!
securevault --help
```

## Quick Start

### Basic Workflow
```
Alice generates keys → Shares alice_public.key with Bob
Bob encrypts file.txt using alice_public.key + bob.key → Sends file.txt.vault to Alice
Alice decrypts file.txt.vault using alice.key + bob_public.key
```

### CLI Example
```bash
# 1. Generate your keypair
securevault keygen --output my_keys.key
# You'll be asked to enter a password - remember it, you'll need it for encrypting/decrypting
# Creates: my_keys.key (private) and my_keys_public.key (public)

# 2. Share your public key
# Send my_keys_public.key to anyone who wants to send you encrypted files
# Get their public key (e.g., alice_public.key) for sending files to them

# 3. Create a test file
echo "Secret data" > secret.txt

# 4. Encrypt a file (sending to Alice)
securevault encrypt secret.txt alice_public.key my_keys.key
# You'll be asked to enter your password
# Output: secret.txt.vault

# 5. Check security info
securevault info secret.txt.vault

# 6. Decrypt a file (Alice received your file)
securevault decrypt secret.txt.vault alice.key my_keys_public.key
# Alice enters her password
# Output: secret.txt
```

### Real Example with Names

If your private key is `bob.key` and you're sending to Alice (`alice_public.key`):
```bash
securevault encrypt document.pdf alice_public.key bob.key
```

If your private key is `alice.key` and you're receiving from Bob (`bob_public.key`):
```bash
securevault decrypt document.pdf.vault alice.key bob_public.key
```

### GUI Usage

The desktop GUI provides the same functionality with a visual interface:

1. **Generate Keys** - Create your keypair with password protection
2. **Encrypt Files** - Drag and drop files, select recipient's public key
3. **Decrypt Files** - Select .vault file and provide your private key
4. **View Info** - Check encryption details and security information

No command-line knowledge needed!

## Technical Details
- **Hybrid encryption**: X25519 + ML-KEM-768
- **Symmetric encryption**: AES-256-GCM
- **Key derivation**: PBKDF2 (100k iterations)
- **Digital signatures**: Ed25519 + ML-DSA-65

## Project Status
Active development.
Educational + experimental cryptography project.

## Bug Reports / Contact

GitHub issues are currently disabled.

If you find bugs or security concerns, contact:

📧 meganealexis12@gmail.com

🔗 LinkedIn: https://www.linkedin.com/in/megane-alexis/

## Author

Mégane Alexis  
Recent Grad in Computer Science · Cybersecurity · Cryptography

· Not yet independently audited.