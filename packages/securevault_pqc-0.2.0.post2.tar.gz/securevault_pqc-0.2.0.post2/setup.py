from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="securevault-pqc", 
    version="0.2.0.post2",
    author="Megane Alexis",
    author_email="meganealexis12@gmail.com",
    description="Post-quantum file encryption using ML-KEM-768 + X25519",
    long_description=long_description,
    long_description_content_type="text/markdown",
    # url="https://github.com/megane18/Security_Vault",
    # project_urls={
    #     "Bug Tracker": "https://github.com/megane18/Security_Vault/issues",
    # },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Topic :: Security :: Cryptography",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    py_modules=["securevault", "securevault_guittest"],
    python_requires=">=3.9",
    install_requires=[
        "liboqs-python>=0.8.0",
        "cryptography>=41.0.0",
        "click>=8.1.0",
    ],
    entry_points={
        "console_scripts": [
            "securevault=securevault:cli",  # Creates 'securevault' command
            "securevault-guittest=securevault_guittest:main", 
        ],
    },
)