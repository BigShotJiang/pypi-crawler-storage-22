# License Notice for Security Rules

## 📄 License Information

All security rules contained in this directory are licensed under the **Apache License 2.0**, the same license as the main AI Threat Monitor SDK.

## ⚖️ Full License Text

```
                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (which shall not include communications that are clearly marked
      or otherwise designated in writing by the copyright owner as
      "Not a Contribution").

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based upon (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and derivative works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control
      systems, and issue tracking systems that are managed by, or on behalf
      of, the Licensor for the purpose of discussing and improving the Work,
      but excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution".

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to use, reproduce, modify, distribute, prepare
      Derivative Works of, and publicly display, publicly perform,
      sublicense, and/or sell copies of the Work, and to permit persons
      to whom the Work is furnished to do so, subject to the following
      conditions:

      The above copyright notice and this permission notice shall be
      included in all copies or substantial portions of the Work.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" file as part of its
          distribution, then any Derivative Works that You distribute
          must include a readable copy of the attribution notices
          contained within such NOTICE file, excluding those notices
          that do not pertain to any part of the Derivative Works,
          in at least one of the following places: within a NOTICE file
          distributed as part of the Derivative Works; within the Source
          form or documentation, if provided along with the Derivative
          Works; or, within a display generated by the Derivative Works,
          if and wherever such third-party notices normally appear. The
          contents of the NOTICE file are for informational purposes only
          and do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. When redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS
```

## 🏢 Copyright Notice

```
Copyright (c) 2025 SecureVector Team

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

## 🔗 Third-Party Framework Attributions

### MITRE ATT&CK®

Some security rules reference MITRE ATT&CK® technique IDs for categorization and mapping purposes.

**Attribution:**
- MITRE ATT&CK® is a registered trademark of The MITRE Corporation
- Framework content available at: https://attack.mitre.org/
- Our use of MITRE ATT&CK® IDs is for informational and educational purposes
- This does not imply endorsement by or affiliation with The MITRE Corporation
- MITRE ATT&CK® framework is used under fair use for security research and threat detection

**License:** MITRE ATT&CK® content is available under [Terms of Use](https://attack.mitre.org/resources/terms-of-use/)

### OWASP Top 10 for LLMs

Some detection rules are informed by and reference the OWASP Top 10 for Large Language Model Applications project.

**Attribution:**
- OWASP® is a registered trademark of the OWASP Foundation
- Project URL: https://owasp.org/www-project-top-10-for-llm/
- OWASP materials are used under Creative Commons Attribution-ShareAlike 4.0 International License (CC BY-SA 4.0)
- Our detection patterns are inspired by OWASP research but represent independent implementations
- This does not imply endorsement by or affiliation with the OWASP Foundation

**License:** [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)

### Academic Research References

Some rules reference academic research papers for methodology and validation. All academic references are properly cited within the rule metadata. We do not claim ownership of referenced research and use citations for educational and research purposes under fair use.

### Third-Party AI Service Names

Detection rules may reference third-party AI services and products (OpenAI®, Anthropic®, ChatGPT®, Claude®, GPT®, etc.) in threat detection patterns. These names are trademarks of their respective owners. Our use is purely for functional security detection purposes and does not imply endorsement, affiliation, partnership, or sponsorship by these services or their providers.

---

## 📦 Desktop Application Dependencies

The optional desktop application (`pip install securevector-ai-monitor[app]`) includes the following third-party dependencies. **All dependencies use permissive open-source licenses that allow commercial use.**

| Package | Version | License | Purpose |
|---------|---------|---------|---------|
| SQLite | (built-in) | Public Domain | Database engine |
| aiosqlite | >=0.19.0 | MIT | Async SQLite wrapper |
| SQLAlchemy | >=2.0.0 | MIT | Database ORM |
| pywebview | >=5.0 | BSD-3-Clause | Lightweight cross-platform webview |
| FastAPI | >=0.100.0 | MIT | Local API server |
| Uvicorn | >=0.20.0 | BSD-3-Clause | ASGI server |
| Starlette | (FastAPI dep) | BSD-3-Clause | Web framework |
| Pydantic | (FastAPI dep) | MIT | Data validation |
| platformdirs | >=3.0.0 | MIT | Cross-platform paths |
| watchdog | >=3.0.0 | Apache-2.0 | File system events |
| httpx | >=0.24.0 | BSD-3-Clause | Async HTTP client |
| Click | (Uvicorn dep) | BSD-3-Clause | CLI framework |

### License Summary

| License Type | Packages | Commercial Use |
|--------------|----------|----------------|
| **Public Domain** | SQLite | ✅ Allowed |
| **MIT** | aiosqlite, SQLAlchemy, FastAPI, Pydantic, platformdirs | ✅ Allowed |
| **Apache-2.0** | watchdog | ✅ Allowed |
| **BSD-3-Clause** | pywebview, Uvicorn, Starlette, httpx, Click | ✅ Allowed |

### Commercial Use Statement

**All desktop application dependencies allow commercial use** with minimal attribution requirements:
- **MIT License**: Requires license and copyright notice in copies
- **Apache-2.0**: Requires license notice and attribution; includes patent grant
- **BSD-3-Clause**: Requires license and copyright notice; no endorsement clause
- **Public Domain**: No restrictions

Users may freely use, modify, and distribute the desktop application for commercial purposes while complying with each dependency's license terms.

---

## ⚠️ Important Legal Disclaimers

### No Warranty
THE SECURITY RULES ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. SECUREVECTOR DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.

### Limitation of Liability
IN NO EVENT SHALL SECUREVECTOR BE LIABLE FOR ANY DAMAGES ARISING FROM THE USE OF THESE SECURITY RULES, INCLUDING BUT NOT LIMITED TO FALSE POSITIVES, FALSE NEGATIVES, OR FAILURE TO DETECT THREATS.

### Compliance Disclaimer
These rules are provided as an aid to security and compliance efforts but do not guarantee compliance with any specific regulation, standard, or legal requirement. Users must conduct their own compliance assessments.

### Use at Your Own Risk
Users assume all risks associated with using these security rules. It is the user's responsibility to validate the appropriateness of these rules for their specific use case and environment.

---

**Document Version**: 2.0.0
**Effective Date**: January 2026
**Applicable Jurisdiction**: Rules distributed globally, governed by Apache License 2.0