"""Tests for security-controls-mcp."""
