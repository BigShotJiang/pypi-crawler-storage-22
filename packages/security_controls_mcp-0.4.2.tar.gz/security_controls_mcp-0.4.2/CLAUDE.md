# Security Controls MCP - Development Guide

**Part of the Ansvar MCP Suite** → See [ANSVAR_MCP_ARCHITECTURE.md](./docs/ANSVAR_MCP_ARCHITECTURE.md) for complete suite documentation

## Project Overview

MCP server providing access to 1,451 security controls across **261 frameworks**. Uses SCF (Secure Controls Framework) as a rosetta stone for bidirectional framework mapping.

## Key Features

- **261 Frameworks**: ISO 27001, NIST CSF, DORA, PCI DSS, SOC 2, CMMC, FedRAMP, and 254 more
- **AI Governance**: ISO 42001, NIST AI RMF, EU AI Act, Cyber Resilience Act
- **1,451 Controls**: Complete control catalog with descriptions
- **Bidirectional Mapping**: Map any framework to any other framework
- **Gap Analysis**: Compare control coverage between frameworks
- **Official Text Import**: Support for purchased ISO/NIST standards

## Tech Stack

- **Language**: Python 3.11+
- **Database**: SQLite with FTS5 full-text search
- **Package Manager**: Poetry
- **Distribution**: PyPI (`pipx install security-controls-mcp`)
- **Data Source**: SCF Framework (Creative Commons BY 4.0)

## Quick Start

```bash
# Install
pipx install security-controls-mcp

# Verify
scf-mcp --version

# Claude Desktop config (use full path for GUI apps)
{
  "mcpServers": {
    "security-controls": {
      "command": "/full/path/to/scf-mcp"
    }
  }
}
# Find your path with: which scf-mcp
```

## Project Structure

```
security-controls-mcp/
├── src/security_controls_mcp/
│   ├── __main__.py            # Entry point (stdio transport)
│   ├── server.py              # MCP server with 9 tools (stdio)
│   ├── http_server.py         # HTTP/SSE server for Ansvar AI
│   ├── data_loader.py         # SCF data loading & search logic
│   ├── config.py              # User config & paid standards paths
│   ├── registry.py            # Standard provider registry
│   ├── providers.py           # Paid standard providers
│   ├── legal_notice.py        # License compliance notices
│   ├── cli.py                 # PDF import CLI (optional)
│   └── data/
│       ├── scf-controls.json      # 1,451 controls with mappings
│       └── framework-to-scf.json  # Framework → SCF reverse index
├── tests/                     # 127 tests
├── docs/
│   ├── ANSVAR_MCP_ARCHITECTURE.md  # **Central architecture doc**
│   └── coverage.md            # Framework coverage details
└── pyproject.toml             # Package configuration
```

## Available Tools

### 1. `version_info`
Get MCP server version, statistics, and database info

### 2. `get_control`
Retrieve a specific control by ID (e.g., GOV-01)

### 3. `search_controls`
Full-text search across all controls by keyword

### 4. `list_frameworks`
List all 261 supported frameworks with control counts

### 5. `get_framework_controls`
Get all controls for a specific framework

### 6. `map_frameworks`
Map controls between any two frameworks (bidirectional)

### 7. `list_available_standards`
List all available standards (SCF built-in + purchased)

### 8. `query_standard`
Search within a purchased standard's official text

### 9. `get_clause`
Get full text of a specific clause from a purchased standard

## Framework IDs

```python
# Use these IDs with the tools
FRAMEWORKS = [
    "iso_27001_2022", "iso_27002_2022", "nist_csf_2.0",
    "nist_800_53_r5", "dora", "pci_dss_4.0.1", "soc_2_tsc",
    "cmmc_2.0_level_2", "fedramp_r5_high", "cis_csc_8.1",
    # ... 251 more (use list_frameworks tool to see all)
]
```

## Development

```bash
# Clone and install
git clone https://github.com/Ansvar-Systems/security-controls-mcp
cd security-controls-mcp
poetry install

# Run tests
poetry run pytest

# Run locally
poetry run python -m src.security_controls_mcp.server

# Build for PyPI
poetry build
```

## Data Updates

### SCF Framework Updates

When SCF releases new versions:

```bash
# 1. Download new scf-controls.json from SCF repo
# 2. Update src/security_controls_mcp/data/scf-controls.json
# 3. Run tests to validate
poetry run pytest

# 4. Update version
poetry version patch

# 5. Build and publish
poetry build
poetry publish
```

### Adding New Frameworks

1. Check if SCF includes the framework
2. If yes, it's automatically available (SCF is the mapper)
3. If no, request SCF team add it OR create manual mapping in `framework-to-scf.json`

## Testing

```bash
# Run all tests
poetry run pytest

# With coverage
poetry run pytest --cov=src --cov-report=html

# Specific test
poetry run pytest tests/test_map_frameworks.py -v
```

## Current Statistics

- **Frameworks**: 261 (expanded from 28 in v0.4.0)
- **Controls**: 1,451 unique controls
- **Mappings**: 50,000+ bidirectional relationships
- **Database Size**: ~7MB (JSON)
- **Tools**: 9 (6 core + 3 paid standards)
- **Tests**: 127 passing

## Version History

- **v0.4.0** (2026-02-05): Major framework expansion (28→261), AI governance support
- **v0.3.5** (2026-02-01): Entry point fix
- **v0.2.1** (2026-01-29): Framework expansion (16→28 frameworks)
- **v0.2.0**: Initial public release with 16 frameworks
- **v0.1.0**: Internal beta

## Integration with Other Ansvar MCPs

This server works seamlessly with:
- **EU Regulations MCP**: Map DORA/GDPR requirements to ISO 27001
- **US Regulations MCP**: Map HIPAA/SOX to NIST controls
- **OT Security MCP**: Bridge IT security controls to OT standards
- **Sanctions MCP**: Security controls for vendor assessments

See [ANSVAR_MCP_ARCHITECTURE.md](./docs/ANSVAR_MCP_ARCHITECTURE.md) for complete workflow examples.

## Coding Guidelines

- Python 3.11+ with type hints
- Pydantic for data validation
- SQLite for data storage
- Black for formatting
- Ruff for linting
- pytest for testing

## Support

- **GitHub Issues**: Bug reports and feature requests
- **GitHub Discussions**: Questions and use cases
- **Commercial**: hello@ansvar.eu

## License

Apache License 2.0 - See [LICENSE](./LICENSE)

---

**For complete Ansvar MCP suite documentation, see:**
📖 [docs/ANSVAR_MCP_ARCHITECTURE.md](./docs/ANSVAR_MCP_ARCHITECTURE.md)
