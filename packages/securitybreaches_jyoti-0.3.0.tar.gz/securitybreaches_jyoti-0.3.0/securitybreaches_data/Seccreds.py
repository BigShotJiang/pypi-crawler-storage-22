"c![]9[5d3Q2=24Cw7xng5?/FdTC/o8Q
rahate13111999@gmail.com
websecurity academy website

ping testphp.vulnweb.com
wireshark - search url -44.228.249.3
dude - 10.5.104.0/24

nessuse - side wala sytem ip 

havji : URL: http://redtiger.labs.overthewire.org/level1.php?cat=1 

