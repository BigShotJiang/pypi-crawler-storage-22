
SMAC for MAC Spoofing
https://smac-tool.com/

Caspa Network Analyser
https://www.colasoft.com/download/products/capsa_free.php
1. Double-click icon on the desktop. 
2. In the Start Page, select your NICs (multiple selections available) in the Capture panelfirst. 
3. Select any Network Profile in the Network Profile panel. 
4. Select Full Analysis in the Analysis Profile panel. 
5. Click the big Run button to start a capture right away 

Omnipeek Network Analyzer

Social Engineering 
1. Open Kali Linux   
2. Go to Application   
3. Click Social Engineering Tools   
4. Click Social Engineering(SE) Toolkit. 
5. Type “1” for Social Engineering Attacks 
6. Type “2” for website attack vector   
7. Type “3” for Credentials harvester attack method 
8. Type “2” for Site Cloner  
9. Type IP address of Kali Linux machine (192.168.1.114 in our case).   
10. Type target URL: http://testphp.vulnweb.com/login.php 
11. Enter Credentials in this counterfeit website, launched on our ip address 
12. Go back to Linux terminal and observe. Username admin and password is extracted

DDOS

HOIC
High Orbit Ion Cannon (HOIC) is a free, open-source network stress application developed by 
Anonymous.

LOIC
The tool is able to perform a simple dos attack by sending a large sequence of UDP, TCP or HTTP requests to the target server.
Step 1: Run the tool.   
Step 2: Enter the URL of the website in The URL field and click on Lock O. Then, select 
attack method (TCP, UDP or HTTP). I will recommend TCP to start. These 2 options are 
necessary to start the attack. 
Step 3: Change other parameters per your choice or leave it to the default. Now click on the Big Button labeled as “IMMA CHARGIN MAH LAZER.” You have just mounted an attack on the target. After starting the attack you will see some numbers in the Attack status fields. 
When the requested number stops increasing, restart the LOIC or change the IP. You can also give the UDP attack a try. Users can also set the speed of the attack by the slider. It is set to faster as default but you can slow down it with the slider. I don’t think anyone is going to slow down the attack.