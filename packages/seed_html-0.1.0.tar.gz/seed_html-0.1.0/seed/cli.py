#!/usr/bin/env python3
"""Seed CLI — init / dev / build"""

import mimetypes
import os
import select
import shutil
import sys
import threading
import time
import webbrowser
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path


# ─── Helpers ────────────────────────────────────────────────────────────────

SEED_ENGINE_DIR = Path(__file__).parent
STATIC_ENGINE_DIR = SEED_ENGINE_DIR / "static"

RELOAD_SNIPPET = b'<script>new EventSource("/__reload").onmessage=()=>location.reload()</script>'

reload_version = 0
reload_lock = threading.Condition()
python_restart_event = threading.Event()
_raw_mode = False  # True while terminal is in raw mode


def _load_seed_class():
    """Load Seed class in both package and direct-script execution modes."""
    try:
        from . import Seed
        return Seed
    except ImportError:
        pass

    try:
        from seed import Seed
        return Seed
    except ModuleNotFoundError:
        repo_root = Path(__file__).resolve().parent.parent
        if str(repo_root) not in sys.path:
            sys.path.insert(0, str(repo_root))
        from seed import Seed
        return Seed


def dev_print(msg=""):
    """Print respeitando modo raw do terminal (emite \\r\\n em vez de só \\n)."""
    if _raw_mode:
        sys.stdout.write(msg + "\r\n")
        sys.stdout.flush()
    else:
        print(msg)


def notify_reload():
    global reload_version
    with reload_lock:
        reload_version += 1
        reload_lock.notify_all()


def find_seed_files(src_dir: Path):
    return sorted(src_dir.rglob("*.seed"))


def build_file(seed_instance, seed_file: Path, src_dir: Path, dist_dir: Path):
    """Build a single .seed file. src/blog/post.seed → dist/blog/post.html"""
    rel = seed_file.relative_to(src_dir)
    out = dist_dir / rel.with_suffix(".html")
    out.parent.mkdir(parents=True, exist_ok=True)
    html = seed_instance.render_file(seed_file, full_page=True)
    out.write_text(html, encoding="utf-8")
    return rel


def build_all(seed_instance, src_dir: Path, dist_dir: Path):
    for f in find_seed_files(src_dir):
        rel = build_file(seed_instance, f, src_dir, dist_dir)
        dev_print(f"  built {rel}")


def copy_engine_static(dist_dir: Path):
    """Copy seed.css and seed.js from engine static/ to dist/"""
    for name in ("seed.css", "seed.js"):
        src = STATIC_ENGINE_DIR / name
        if src.is_file():
            shutil.copy2(src, dist_dir / name)


def copy_static_layered(dist_dir: Path, project_static: Path, theme_static: Path | None = None):
    """Copy static files in layers: theme first, project on top (project wins).

    Engine static (seed.css/seed.js) stays in dist/ root — handled by copy_engine_static().
    This function only populates dist/static/.
    Missing directories are skipped silently.
    """
    dest = dist_dir / "static"
    if theme_static and theme_static.is_dir():
        shutil.copytree(theme_static, dest, dirs_exist_ok=True)
    if project_static.is_dir() and any(project_static.iterdir()):
        shutil.copytree(project_static, dest, dirs_exist_ok=True)


def _load_theme_dir(folder: Path) -> Path | None:
    """Read seed.yaml and resolve theme_dir. Returns None if no theme configured.

    Validates:
    - seed.yaml must be a YAML mapping
    - theme name: only simple name (e.g. 'blog') or absolute path allowed
    - Path traversal (../) is rejected
    - theme directory must exist
    """
    import yaml

    seed_yaml = folder / "seed.yaml"
    if not seed_yaml.is_file():
        return None

    try:
        config = yaml.safe_load(seed_yaml.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"seed.yaml: erro de sintaxe YAML — {e}") from e

    if not isinstance(config, dict):
        raise ValueError("seed.yaml inválido: esperado mapeamento YAML (chave: valor)")

    theme_name = config.get("theme")
    if not theme_name:
        return None

    theme_path = Path(theme_name)
    if theme_path.is_absolute():
        theme_dir = theme_path
    elif theme_path.parts == (theme_name,):  # simple name, no separator
        theme_dir = folder / "themes" / theme_name
    else:
        raise ValueError(
            f"seed.yaml: theme '{theme_name}' inválido — use nome simples (ex: blog) "
            f"ou caminho absoluto. Caminhos relativos com separador não são permitidos."
        )

    if not theme_dir.is_dir():
        raise FileNotFoundError(
            f"Tema '{theme_name}' não encontrado em: {theme_dir}\n"
            f"Crie o diretório ou use 'seed init --theme {theme_name}' para inicializar."
        )

    return theme_dir


# ─── HTTP Handler ────────────────────────────────────────────────────────────

class SeedDevHandler(SimpleHTTPRequestHandler):
    """HTTP handler that:
    - Serves /static/* in layers: project static/ first, then theme static/ (no copy)
    - Injects live-reload SSE snippet into HTML responses
    - Serves everything else from dist/
    """

    static_dir: Path = None        # project static/ dir
    theme_static_dir: Path = None  # theme static/ dir (optional)

    def handle(self):
        try:
            super().handle()
        except ConnectionResetError:
            pass

    def do_GET(self):
        path = self.path.split("?")[0]

        # SSE endpoint for live reload
        if path == "/__reload":
            self._serve_reload_sse()
            return

        # Serve user static files directly (no copy to dist)
        # Priority: project static/ > theme static/
        if path.startswith("/static/"):
            rel = path[len("/static/"):]
            static_file = self.static_dir / rel if self.static_dir else None
            theme_file = self.theme_static_dir / rel if self.theme_static_dir else None
            if static_file and static_file.is_file():
                self._serve_static_file(static_file)
            elif theme_file and theme_file.is_file():
                self._serve_static_file(theme_file)
            else:
                self.send_error(404, f"Static file not found: {rel}")
            return

        # Serve HTML from dist/
        translated = Path(self.translate_path(path))
        if translated.is_dir():
            translated = translated / "index.html"
        if translated.is_file() and translated.suffix == ".html":
            self._serve_html(translated)
        else:
            super().do_GET()

    def _serve_reload_sse(self):
        """Serve SSE (Server-Sent Events) for live reload."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            last = reload_version
            while True:
                with reload_lock:
                    reload_lock.wait(timeout=30)
                if reload_version != last:
                    last = reload_version
                    self.wfile.write(b"data: reload\n\n")
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            return

    def _serve_html(self, filepath: Path):
        data = filepath.read_bytes()
        data = data.replace(b"</body>", RELOAD_SNIPPET + b"\n</body>")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_static_file(self, filepath: Path):
        mime_type, _ = mimetypes.guess_type(str(filepath))
        mime_type = mime_type or "application/octet-stream"
        data = filepath.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format, *args):
        pass


# ─── File Watcher ────────────────────────────────────────────────────────────

_last_rebuild_time: dict = {}
_REBUILD_COOLDOWN = 1.0


def _debounce(key: str) -> bool:
    """Returns True if we should skip (too soon since last rebuild)."""
    now = time.time()
    if now - _last_rebuild_time.get(key, 0) < _REBUILD_COOLDOWN:
        return True
    _last_rebuild_time[key] = now
    return False


def _rebuild_full(state: dict, src_dir: Path, dist_dir: Path):
    """Clear include cache and rebuild all files. Uses current state['seed']."""
    state["seed"].renderer.clear_includes()
    build_all(state["seed"], src_dir, dist_dir)


def make_change_handler(state: dict, src_dir: Path, dist_dir: Path, project_dir: Path, observer_ref: list):
    """Create file change handler. state is a mutable dict with keys:
        'seed'      : current Seed instance
        'theme_dir' : current active theme dir (Path | None)
    observer_ref is a list holding the current Observer so it can be replaced on theme change.
    """
    from watchdog.events import FileSystemEventHandler

    components_dir = project_dir / "components"

    class ChangeHandler(FileSystemEventHandler):
        def _handle(self, event):
            if event.is_directory:
                return
            src_path = Path(event.src_path)
            if _debounce(str(src_path)):
                return

            # seed.yaml changed → recalculate theme, recreate Seed, restart theme watcher
            if src_path.name == "seed.yaml" and src_path.parent == project_dir:
                dev_print("  seed.yaml changed — reloading theme config...")
                try:
                    new_theme_dir = _load_theme_dir(project_dir)
                    Seed = _load_seed_class()
                    from seed.components import reload_components_yaml
                    reload_components_yaml(
                        components_dir=components_dir if components_dir.exists() else None,
                        theme_dir=new_theme_dir,
                    )
                    state["seed"] = Seed(
                        project_dir=project_dir,
                        components_dir=components_dir if components_dir.exists() else None,
                        theme_dir=new_theme_dir,
                    )
                    old_theme_dir = state["theme_dir"]
                    state["theme_dir"] = new_theme_dir
                    # Restart theme directory watcher if theme changed
                    _restart_theme_watch(observer_ref, handler, old_theme_dir, new_theme_dir)
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all (new theme: {})".format(
                        new_theme_dir.name if new_theme_dir else "none"
                    ))
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error reloading theme: {e}")
                return

            if src_path.suffix == ".layout" and src_path.is_relative_to(src_dir):
                rel = src_path.relative_to(src_dir)
                dev_print(f"  layout changed: {rel}")
                try:
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix == ".layout" and state["theme_dir"] and src_path.is_relative_to(state["theme_dir"]):
                dev_print(f"  theme layout changed: {src_path.name}")
                try:
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix == ".seed" and src_path.is_relative_to(src_dir):
                rel = src_path.relative_to(src_dir)
                dev_print(f"  changed {rel}")
                try:
                    state["seed"].renderer.clear_includes()
                    build_file(state["seed"], src_path, src_dir, dist_dir)
                    dev_print(f"  rebuilt {rel}")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix in (".yaml", ".design"):
                dev_print(f"  component changed: {src_path.name}")
                try:
                    from seed.components import reload_components_yaml
                    reload_components_yaml(
                        components_dir=components_dir if components_dir.exists() else None,
                        theme_dir=state["theme_dir"],
                    )
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix == ".py":
                dev_print(f"  Python changed: {src_path.name} — restart required")
                python_restart_event.set()

        def on_modified(self, event):
            self._handle(event)

        def on_created(self, event):
            self._handle(event)

    handler = ChangeHandler()
    return handler


def _restart_theme_watch(observer_ref: list, handler, old_theme_dir: Path | None, new_theme_dir: Path | None):
    """Update the observer to watch the new theme directory instead of the old one.
    observer_ref[0] is the current Observer instance.
    """
    if old_theme_dir == new_theme_dir:
        return
    observer = observer_ref[0]
    # Unschedule old theme dir watches by restarting the observer
    # (watchdog doesn't support unscheduling individual watches cleanly on all platforms)
    observer.stop()
    observer.join()
    from watchdog.observers import Observer
    new_observer = Observer()
    for path, recursive in observer_ref[1]:  # restore non-theme watches
        new_observer.schedule(handler, path, recursive=recursive)
    if new_theme_dir and new_theme_dir.exists():
        new_observer.schedule(handler, str(new_theme_dir), recursive=True)
    new_observer.start()
    observer_ref[0] = new_observer


def watch(state: dict, src_dir: Path, dist_dir: Path, components_dir: Path, project_dir: Path):
    from watchdog.observers import Observer

    # observer_ref: [observer, [(path, recursive), ...]] — persistent watches (non-theme)
    persistent_watches = []
    if src_dir.exists():
        persistent_watches.append((str(src_dir), True))
    if components_dir.exists():
        persistent_watches.append((str(components_dir), True))
    if SEED_ENGINE_DIR.exists():
        persistent_watches.append((str(SEED_ENGINE_DIR), True))
    # Watch project root for seed.yaml changes
    persistent_watches.append((str(project_dir), False))

    observer = Observer()
    observer_ref = [observer, persistent_watches]

    handler = make_change_handler(state, src_dir, dist_dir, project_dir, observer_ref)

    for path, recursive in persistent_watches:
        observer.schedule(handler, path, recursive=recursive)

    # Watch active theme directory
    theme_dir = state.get("theme_dir")
    if theme_dir and theme_dir.exists():
        observer.schedule(handler, str(theme_dir), recursive=True)

    observer.start()
    try:
        while not python_restart_event.is_set():
            time.sleep(0.5)
    finally:
        observer_ref[0].stop()
        observer_ref[0].join()


# ─── Commands ────────────────────────────────────────────────────────────────

LAYOUT_TEMPLATE = """\
---
title: My Site
---
@div: class=min-h-screen flex
  {content}
"""

INDEX_SEED_TEMPLATE = """\
---
title: Home
---
@h1
  Hello, World!

Welcome to your new Seed project.
"""


def cmd_init(args):
    if not args:
        print("Usage: seed init <project-name> [--theme <name|path>]")
        sys.exit(1)

    # Parse args: name + optional --theme
    name = args[0]
    theme_arg = None
    remaining = args[1:]
    i = 0
    while i < len(remaining):
        if remaining[i] == "--theme" and i + 1 < len(remaining):
            theme_arg = remaining[i + 1]
            i += 2
        else:
            i += 1

    project_dir = Path(name)

    if project_dir.exists():
        print(f"Error: '{name}' already exists.")
        sys.exit(1)

    if theme_arg:
        # Resolve theme source directory
        theme_path = Path(theme_arg)
        if theme_path.is_absolute() and theme_path.is_dir():
            theme_src = theme_path
            theme_name = theme_path.name
        elif theme_path.parts == (theme_arg,):  # simple name → builtin
            theme_src = SEED_ENGINE_DIR / "themes" / theme_arg
            theme_name = theme_arg
            if not theme_src.is_dir():
                print(f"Error: tema builtin '{theme_arg}' não encontrado em {theme_src}")
                sys.exit(1)
        else:
            print(f"Error: --theme deve ser nome simples (ex: blog) ou caminho absoluto")
            sys.exit(1)

        # Create project structure with theme
        (project_dir / "src").mkdir(parents=True)
        (project_dir / "static").mkdir()
        (project_dir / "components").mkdir()
        (project_dir / "themes").mkdir()

        # Copy theme into themes/<name>/
        theme_dest = project_dir / "themes" / theme_name
        shutil.copytree(theme_src, theme_dest)

        # Create seed.yaml
        (project_dir / "seed.yaml").write_text(f"theme: {theme_name}\n", encoding="utf-8")

        # Create minimal index.seed (no default.layout in src/ — comes from theme)
        (project_dir / "src" / "index.seed").write_text(INDEX_SEED_TEMPLATE, encoding="utf-8")

        print(f"Created project '{name}' with theme '{theme_name}'")
        print()
        print(f"  seed.yaml              — config do projeto (theme: {theme_name})")
        print(f"  themes/{theme_name}/   — arquivos do tema")
        print(f"  src/index.seed         — página inicial")
        print(f"  components/            — overrides de componentes (opcional)")
        print(f"  static/                — assets do projeto (opcional)")
        print()
        print(f"Next steps:")
        print(f"  seed dev {name}")
    else:
        # No theme: original behavior
        (project_dir / "src").mkdir(parents=True)
        (project_dir / "static").mkdir()
        (project_dir / "components").mkdir()

        (project_dir / "src" / "default.layout").write_text(LAYOUT_TEMPLATE, encoding="utf-8")
        (project_dir / "src" / "index.seed").write_text(INDEX_SEED_TEMPLATE, encoding="utf-8")

        print(f"Created project '{name}'")
        print()
        print("  src/default.layout — layout padrão")
        print("  src/index.seed     — página inicial")
        print("  static/           — arquivos estáticos (CSS, JS, imagens)")
        print("  components/       — componentes do projeto (.yaml, .design)")
        print()
        print(f"Next steps:")
        print(f"  seed dev {name}")


def cmd_dev(args):
    if not args:
        print("Usage: seed dev <folder> [port]")
        sys.exit(1)

    folder = Path(args[0]).resolve()
    port = int(args[1]) if len(args) > 1 else 8000

    src_dir = folder / "src"
    static_dir = folder / "static"
    components_dir = folder / "components"
    dist_dir = folder / "dist"

    if not folder.is_dir():
        print(f"Error: '{folder}' is not a directory.")
        sys.exit(1)
    if not src_dir.is_dir():
        print(f"Error: '{src_dir}' not found. Is this a Seed project? (expected src/ folder)")
        sys.exit(1)

    try:
        theme_dir = _load_theme_dir(folder)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    dist_dir.mkdir(parents=True, exist_ok=True)

    Seed = _load_seed_class()
    seed_instance = Seed(
        project_dir=folder,
        components_dir=components_dir if components_dir.exists() else None,
        theme_dir=theme_dir,
    )

    # Mutable state shared with watcher
    state = {"seed": seed_instance, "theme_dir": theme_dir}

    print(f"Building {folder.name}...")
    if theme_dir:
        print(f"  theme: {theme_dir.name}")
    _rebuild_full(state, src_dir, dist_dir)
    copy_engine_static(dist_dir)
    print("Build complete.")
    print()

    # Build handler class with static dirs bound
    theme_static = theme_dir / "static" if theme_dir else None

    class Handler(SeedDevHandler):
        pass
    Handler.static_dir = static_dir
    Handler.theme_static_dir = theme_static

    handler_factory = partial(Handler, directory=str(dist_dir))
    server = ThreadingHTTPServer(("0.0.0.0", port), handler_factory)
    server.daemon_threads = True

    watcher_thread = threading.Thread(
        target=watch,
        args=(state, src_dir, dist_dir, components_dir, folder),
        daemon=True,
    )
    watcher_thread.start()

    import socket
    url = f"http://localhost:{port}"
    print(f"Serving at:")
    print(f"  Local:   {url}")
    try:
        local_ip = socket.gethostbyname(socket.gethostname())
        if local_ip and local_ip != "127.0.0.1":
            print(f"  Network: http://{local_ip}:{port}")
    except Exception:
        pass
    print("Press o to open, b to build, r to restart, q to quit")

    def handle_input():
        global _raw_mode
        import tty
        import termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            _raw_mode = True
            while True:
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    key = sys.stdin.read(1).lower()
                    if key == "o":
                        try:
                            import subprocess
                            subprocess.run(["open", "-g", url], check=True)
                        except Exception:
                            webbrowser.open(url)
                    elif key == "b":
                        from seed.components import reload_components_yaml
                        reload_components_yaml(
                            components_dir=components_dir if components_dir.exists() else None,
                            theme_dir=state["theme_dir"],
                        )
                        _rebuild_full(state, src_dir, dist_dir)
                        copy_engine_static(dist_dir)
                        dev_print("  Built all.")
                        notify_reload()
                    elif key == "r":
                        dev_print("  Restarting...")
                        _raw_mode = False
                        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                        server.shutdown()
                        os.execv(sys.executable, [sys.executable] + sys.argv)
                    elif key in ("q", "\x03"):  # q or Ctrl+C
                        server.shutdown()
                        break
        finally:
            _raw_mode = False
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    input_thread = threading.Thread(target=handle_input, daemon=True)
    input_thread.start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


def cmd_build(args):
    if not args:
        print("Usage: seed build <folder>")
        sys.exit(1)

    folder = Path(args[0]).resolve()
    src_dir = folder / "src"
    static_dir = folder / "static"
    components_dir = folder / "components"
    dist_dir = folder / "dist"

    if not folder.is_dir():
        print(f"Error: '{folder}' is not a directory.")
        sys.exit(1)
    if not src_dir.is_dir():
        print(f"Error: '{src_dir}' not found. Is this a Seed project?")
        sys.exit(1)

    try:
        theme_dir = _load_theme_dir(folder)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    # Clean dist/
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
    dist_dir.mkdir(parents=True)

    Seed = _load_seed_class()
    seed_instance = Seed(
        project_dir=folder,
        components_dir=components_dir if components_dir.exists() else None,
        theme_dir=theme_dir,
    )

    print(f"Building {folder.name}...")
    if theme_dir:
        print(f"  theme: {theme_dir.name}")
    build_all(seed_instance, src_dir, dist_dir)

    # Copy engine static files (to dist/ root)
    copy_engine_static(dist_dir)

    # Copy static in layers: theme → project → dist/static/
    theme_static = theme_dir / "static" if theme_dir else None
    copy_static_layered(dist_dir, static_dir, theme_static)
    if theme_static and theme_static.is_dir():
        print(f"  copied themes/{theme_dir.name}/static/ → dist/static/")
    if static_dir.is_dir() and any(static_dir.iterdir()):
        print(f"  copied static/ → dist/static/")

    # Summary
    html_files = list(dist_dir.rglob("*.html"))
    total_size = sum(f.stat().st_size for f in dist_dir.rglob("*") if f.is_file())
    print()
    print(f"Build complete: {len(html_files)} HTML file(s), {total_size // 1024} KB total → dist/")


# ─── Entry point ─────────────────────────────────────────────────────────────

COMMANDS = {
    "init": cmd_init,
    "dev": cmd_dev,
    "build": cmd_build,
}

def main(argv: list[str] | None = None):
    args = argv if argv is not None else sys.argv[1:]
    cmd = args[0] if args else None
    if cmd not in COMMANDS:
        print("Usage: seed <init|dev|build> [args]")
        print()
        print("  init <name>     Create a new Seed project")
        print("  dev  <folder>   Start development server with live reload")
        print("  build <folder>  Build for production")
        sys.exit(1)
    COMMANDS[cmd](args[1:])


if __name__ == "__main__":
    main()
