from __future__ import annotations
from typing import TYPE_CHECKING, Callable, Any
from pathlib import Path
import re
import yaml

if TYPE_CHECKING:
    from ..nodes import Component

# Registry now stores configs: {"class": "...", "variants": {"name": "classes"}}
_registry: dict[str, dict[str, Any]] = {}
_components_yaml_path = Path(__file__).parent / "components.yaml"

# Design cache: {component_name: {variant_name: Page}}
_design_cache: dict[str, dict[str, Any]] = {}

# Regex for finding slot placeholders like {title}, {children}, {image}
_SLOT_RE = re.compile(r"\{([\w-]+)\}")


def _merge_classes(base: str, extra: str) -> str:
    """Merge two class strings, removing duplicates while preserving order."""
    seen = set()
    result = []
    for cls in base.split() + extra.split():
        if cls and cls not in seen:
            seen.add(cls)
            result.append(cls)
    return " ".join(result)


def register(name: str, config: dict[str, Any], merge: bool = False):
    """Register a component. If merge=True and component exists:
    - class: extends (appends without duplicates)
    - variants: extends (adds new, overrides existing)
    - tag: overrides
    """
    if merge and name in _registry:
        existing = _registry[name]
        merged = {**existing}
        if "tag" in config:
            merged["tag"] = config["tag"]
        if "class" in config:
            merged["class"] = _merge_classes(existing.get("class", ""), config["class"])
        if "variants" in config:
            merged["variants"] = {**existing.get("variants", {}), **config["variants"]}
        _registry[name] = merged
    else:
        _registry[name] = config


def get_config(name: str) -> dict[str, Any] | None:
    """Get component config by name, resolving aliases transparently."""
    config = _registry.get(name)
    if isinstance(config, dict) and "alias" in config:
        target = config["alias"]
        resolved = _registry.get(target)
        if resolved is None:
            return config
        # Ensure the target's tag is explicit so the alias doesn't use its own name as tag
        base = {**resolved}
        if "tag" not in base:
            base["tag"] = target
        # Merge: target is base, alias overrides (except the 'alias' key itself)
        overrides = {k: v for k, v in config.items() if k != "alias"}
        return {**base, **overrides} if overrides else base
    return config


def is_registered(name: str) -> bool:
    """Check if a component is registered"""
    return name in _registry


def load_components():
    """Load component configs from YAML and registry"""
    # Load from YAML first
    load_components_from_yaml()


def load_components_from_yaml(path: Path | None = None):
    """Load component configs from YAML file(s).

    If path is a file, loads that file.
    If path is a directory, loads all .yaml files in that directory.
    If path is None, loads all .yaml files from seed/components/ directory.
    """
    if path is None:
        # Load all .yaml files from components directory
        components_dir = Path(__file__).parent
        _load_yaml_directory(components_dir)
        return

    if path.is_file():
        _load_yaml_file(path)
    elif path.is_dir():
        _load_yaml_directory(path)


def _load_yaml_file(path: Path):
    """Load component configs from a single YAML file"""
    with open(path, encoding="utf-8") as f:
        components = yaml.safe_load(f) or {}

    for name, config in components.items():
        register(name, config)


def _load_yaml_directory(directory: Path):
    """Load component configs from all .yaml files in a directory and discover component folders"""
    for yaml_file in sorted(directory.glob("*.yaml")):
        _load_yaml_file(yaml_file)

    # Discover component folders (subdirectories with .yaml files)
    for subfolder in sorted(directory.iterdir()):
        if subfolder.is_dir() and not subfolder.name.startswith("__"):
            _load_component_folder(subfolder)



def _load_component_folder(folder: Path):
    """Load a component folder: YAML config + .design files"""
    # Load YAML files in the folder
    for yaml_file in sorted(folder.glob("*.yaml")):
        _load_yaml_file(yaml_file)

    # Load .design files
    for design_file in sorted(folder.glob("*.design")):
        stem = design_file.stem
        if (folder / f"{stem}.yaml").exists():
            # Has its own .yaml → default design of that component
            component_name = stem
            variant_name = "default"
        else:
            # No own yaml → variant of the folder component (e.g. hero/center.design)
            component_name = folder.name
            variant_name = stem
            if variant_name == component_name:
                variant_name = "default"
        _load_design_file(component_name, variant_name, design_file)


def _load_design_file(component_name: str, variant_name: str, path: Path):
    """Parse a .design file and store in cache"""
    from ..parser import parse
    source = path.read_text(encoding="utf-8")
    page = parse(source)

    if component_name not in _design_cache:
        _design_cache[component_name] = {}
    _design_cache[component_name][variant_name] = page


def _extract_slots(page) -> list[str]:
    """Extract slot names from a design AST by finding {name} placeholders in Content nodes"""
    from ..nodes import Content, Component as CompNode
    slots = []

    def walk(children):
        for child in children:
            if isinstance(child, Content):
                for match in _SLOT_RE.finditer(child.text):
                    name = match.group(1)
                    if name not in slots:
                        slots.append(name)
            elif isinstance(child, CompNode) and child.children:
                walk(child.children)

    walk(page.children)
    return slots


def _resolve_alias_name(name: str) -> str:
    """Resolve an alias name to its target. Returns the original name if not an alias."""
    config = _registry.get(name)
    if isinstance(config, dict) and "alias" in config:
        return config["alias"]
    return name


def has_design(name: str) -> bool:
    """Check if a component has a design template (resolves alias automatically)"""
    target = _resolve_alias_name(name)
    return target in _design_cache


def get_design(name: str, variant: str = "default"):
    """Get design AST for a component. Resolves alias and falls back to 'default' variant."""
    target = _resolve_alias_name(name)
    designs = _design_cache.get(target)
    if not designs:
        return None
    return designs.get(variant) or designs.get("default")


def get_design_slot_names(name: str, variant: str = "default") -> list[str]:
    """Get slot names from a design (resolves alias automatically)"""
    design = get_design(name, variant)
    if not design:
        return []
    return _extract_slots(design)


def load_project_components(project_dir: Path):
    """Load project-level component YAML files, merging with existing globals.

    Loads all .yaml files from the project directory.
    Also discovers component folders in the project directory.
    """
    if not project_dir.exists():
        return

    # Load all .yaml files from project directory
    for yaml_file in sorted(project_dir.glob("*.yaml")):
        with open(yaml_file, encoding="utf-8") as f:
            components = yaml.safe_load(f) or {}
        for name, config in components.items():
            register(name, config, merge=name in _registry)

    # Discover component folders in project directory
    for subfolder in sorted(project_dir.iterdir()):
        if subfolder.is_dir() and not subfolder.name.startswith(("__", ".", "dist")):
            # Check if it's a component folder (has .yaml or .design files)
            has_yaml = any(subfolder.glob("*.yaml"))
            has_design_files = any(subfolder.glob("*.design"))
            if has_yaml or has_design_files:
                _load_component_folder(subfolder)


def reload_components_yaml(
    components_dir: Path | None = None,
    theme_dir: Path | None = None,
):
    """Reload all components (global → theme → project).

    Args:
        components_dir: project components directory (e.g. project/components/).
                        Pass explicitly to avoid accidentally scanning themes/.
        theme_dir: active theme root (e.g. project/themes/blog/).
    """
    _registry.clear()
    _design_cache.clear()
    load_components()                                          # 1. framework globals
    if theme_dir:
        theme_components = theme_dir / "components"
        if theme_components.exists():
            load_project_components(theme_components)         # 2. theme (merge)
    if components_dir and components_dir.exists():
        load_project_components(components_dir)              # 3. project (override)



def _get_class_prefix(cls: str) -> str:
    """Extract the deduplication key for a Tailwind class.

    Split on '-', drop the last segment, rejoin — that's the prefix.
    Two classes with the same prefix modify the same CSS property; last one wins.

    Examples:
      text-xs       → "text"      (size)
      text-gray-500 → "text-gray" (color) — different prefix, no conflict
      text-gray-700 → "text-gray" — conflicts with text-gray-500 ✓
      mb-4 / mb-6   → "mb" — conflict ✓
      flex / hidden  → "flex" / "hidden" — single segment, unique ✓

    Modifiers (hover:, lg:, md:) are kept so base and variant classes never conflict.
    """
    if not cls:
        return cls

    # Split off modifier prefix (hover:, lg:, md:text-lg, etc.)
    modifier = ""
    rest = cls
    if ":" in cls:
        modifier, rest = cls.split(":", 1)
        modifier = modifier + ":"

    # Arbitrary values [color:red] — treat as unique
    if rest.startswith("["):
        return cls

    parts = rest.split("-")
    if len(parts) == 1:
        # Single-segment class (flex, hidden, block…) — unique key
        return modifier + rest

    return modifier + "-".join(parts[:-1])


def build_classes(component_name: str, props: dict) -> str:
    """Build the complete class string for a component with proper deduplication.

    Order: base -> variant -> custom
    Classes with same prefix are deduplicated (last wins).
    Deduplication only happens between different sources (base vs variant vs custom),
    not within the same source.
    """
    config = get_config(component_name)

    if not config:
        # Not registered - return component name as class
        return component_name

    # Store all classes in order, then deduplicate by prefix at the end
    all_classes: list[str] = []

    # 1. Add base class from config first (lowest priority)
    base_class = config.get("class", "")
    if base_class:
        all_classes.extend(base_class.split())

    # 2. Add variant classes (overwrites base if same prefix)
    variant = props.get("variant", "")
    if variant:
        variants = config.get("variants", {})
        # Split variant string (e.g., "primary small" -> ["primary", "small"])
        variant_list = variant.split() if isinstance(variant, str) else [variant]
        for v in variant_list:
            v = v.strip()
            if v in variants:
                variant_classes = variants[v]
                if variant_classes:
                    all_classes.extend(variant_classes.split())

    # 3. Add custom class from props last (highest priority)
    if "class" in props:
        custom_class = props["class"]
        if custom_class:
            all_classes.extend(str(custom_class).split())

    # Deduplicate by prefix, keeping the LAST occurrence (highest priority wins)
    # Use a dict to track which classes to keep (last one wins)
    prefix_to_class: dict[str, str] = {}
    for cls in all_classes:
        if not cls:
            continue
        prefix = _get_class_prefix(cls)
        if prefix:  # Only deduplicate if we can extract a meaningful prefix
            prefix_to_class[prefix] = cls

    # Now rebuild the class list, but only include classes whose prefix is in our keep list
    # However, we also need to include classes without a detectable prefix
    keep_classes = set(prefix_to_class.values())

    result_classes = []
    for cls in all_classes:
        if not cls:
            continue
        # Include if it's in our keep set OR if it has no detectable prefix
        prefix = _get_class_prefix(cls)
        if not prefix or cls in keep_classes:
            result_classes.append(cls)

    # Remove duplicates while preserving order (keep first occurrence)
    seen = set()
    unique_classes = []
    for cls in result_classes:
        if cls not in seen:
            seen.add(cls)
            unique_classes.append(cls)

    return " ".join(unique_classes) if unique_classes else component_name


def build_extra_attrs(props: dict) -> str:
    """Build extra HTML attributes from props (excluding class, variant, and internal props)"""
    # Props that should not become HTML attributes
    excluded = {"class", "variant", "children", "design"}
    attrs = []
    for key, val in props.items():
        if key in excluded:
            continue
        if val is True:
            # Boolean attribute
            attrs.append(key)
        elif val:
            # Regular attribute
            attrs.append(f'{key}="{val}"')
    return " " + " ".join(attrs) if attrs else ""


def _wrap_in_link_if_needed(html: str, props: dict, tag: str) -> str:
    """Wrap content in <a> tag if component has href but is not already an anchor.

    Args:
        html: The rendered component HTML
        props: Component props containing potential href
        tag: The HTML tag being used for the component

    Returns:
        Wrapped HTML if needs link, otherwise original HTML
    """
    href = props.get("href")
    if href and tag != "a":
        # Get target and rel attrs if present
        target = props.get("target")
        rel = props.get("rel", "noopener noreferrer")  # Default for security

        # Build link attributes
        link_attrs = f'href="{href}"'
        if target:
            link_attrs += f' target="{target}"'
        if rel:
            link_attrs += f' rel="{rel}"'

        # Remove href and data-node-id from inner HTML to avoid duplication
        import re
        # Remove href attribute from the inner element
        inner_html = re.sub(r'\s+href="[^"]*"', '', html)
        # Remove duplicate data-node-id (keep only one on the wrapper)
        inner_html = re.sub(r'\s+data-node-id="[^"]*"', '', inner_html)

        return f'<a {link_attrs}>{inner_html}</a>'

    return html


# HTML tags whose content should be rendered as preformatted (whitespace preserved)
_PREFORMATTED_TAGS = frozenset(["pre", "code"])


def render_component(component: Component, render_children: Callable, render_children_raw: Callable | None = None) -> str:
    """Render a component based on its config"""
    # Check for design-based rendering
    if has_design(component.name):
        return _render_with_design(component, render_children)

    config = get_config(component.name)

    # Use raw (preformatted) renderer for pre/code tags
    effective_tag = config.get("tag", component.name) if config else component.name
    if effective_tag in _PREFORMATTED_TAGS and render_children_raw is not None:
        children_html = render_children_raw(component.children)
    else:
        children_html = render_children(component.children)

    if config:
        # Registered component - use config
        cls = build_classes(component.name, component.props)
        tag = effective_tag

        # Build extra attributes from props
        extra_attrs = build_extra_attrs(component.props)

        # Handle self-closing tags
        if tag in ("img", "input", "br", "hr"):
            html = f'<{tag} class="{cls}"{extra_attrs}{_data_attrs(component)} />'
            return _wrap_in_link_if_needed(html, component.props, tag)

        html = f'<{tag} class="{cls}"{extra_attrs}{_data_attrs(component)}>{children_html}</{tag}>'
        return _wrap_in_link_if_needed(html, component.props, tag)

    # Not registered - render as generic tag with same rules as registered components
    # (no base class, no variants, no design — but class and all other props apply normally)
    tag = component.name
    if tag in _PREFORMATTED_TAGS and render_children_raw is not None:
        children_html = render_children_raw(component.children)
    cls = component.props.get("class", "")
    extra_attrs = build_extra_attrs(component.props)
    if cls:
        html = f'<{tag} class="{cls}"{extra_attrs}{_data_attrs(component)}>{children_html}</{tag}>'
    else:
        html = f'<{tag}{extra_attrs}{_data_attrs(component)}>{children_html}</{tag}>'
    return _wrap_in_link_if_needed(html, component.props, tag)


def _render_with_design(component: Component, render_children: Callable) -> str:
    """Render a component using its design template"""
    from ..nodes import Component as CompNode, Content
    import copy

    # Determine design to use:
    # 1. design= explicit prop takes precedence (allows variant + design independently)
    # 2. variant= is used as design name if no matching design exists for it
    # 3. fallback to "default"
    explicit_design = component.props.get("design")
    variant = component.props.get("variant", "default")
    if explicit_design:
        design = get_design(component.name, explicit_design) or get_design(component.name, "default")
    else:
        design = get_design(component.name, variant) or get_design(component.name, "default")
    if not design:
        # Fallback to normal rendering if design not found
        return _render_without_design(component, render_children)

    # Get slot names from the design
    slot_names = _extract_slots(design)

    # Separate children into slots
    slots: dict[str, list] = {}
    slot_props: dict[str, dict] = {}  # props do filho-slot
    other_children: list = []

    for child in component.children:
        if isinstance(child, CompNode) and child.name in slot_names:
            # This child fills a named slot
            slots[child.name] = child.children if child.children else [child]
            slot_props[child.name] = child.props
        else:
            other_children.append(child)

    # Render each slot's content
    rendered_slots: dict[str, str] = {}
    for slot_name in slot_names:
        if slot_name == "children":
            rendered_slots["children"] = render_children(other_children)
        elif slot_name in slots:
            slot_content = slots[slot_name]
            # Check if it's a self-closing slot (Component with no children that was kept as-is)
            if (len(slot_content) == 1
                    and isinstance(slot_content[0], CompNode)
                    and slot_content[0].name in slot_names):
                # Self-closing slot component: render it as a regular component
                rendered_slots[slot_name] = render_component(slot_content[0], render_children, None)
            else:
                rendered_slots[slot_name] = render_children(slot_content)
            # Expose slot props as {slot-propname} placeholders
            for prop_key, prop_val in slot_props.get(slot_name, {}).items():
                rendered_slots[f"{slot_name}-{prop_key}"] = prop_val if isinstance(prop_val, str) else ""
        else:
            rendered_slots[slot_name] = ""

    # Render the design AST, substituting placeholders
    design_copy = copy.deepcopy(design)
    inner_html = _render_design_children(design_copy.children, rendered_slots, render_children)

    # Wrap in outer tag+class from YAML config
    config = get_config(component.name)
    if config:
        cls = build_classes(component.name, component.props)
        tag = config.get("tag", component.name)
        extra_attrs = build_extra_attrs(component.props)
        # Only include class attribute if there are real classes (not just component name fallback)
        has_real_class = cls and cls != component.name
        class_attr = f' class="{cls}"' if has_real_class else ""
        return f'<{tag}{class_attr}{extra_attrs}{_data_attrs(component)}>{inner_html}</{tag}>'

    # No config, just return inner HTML with wrapper
    cls = component.name
    extra_attrs = build_extra_attrs(component.props)
    return f'<div class="{cls}"{extra_attrs}{_data_attrs(component)}>{inner_html}</div>'


def _render_without_design(component: Component, render_children: Callable) -> str:
    """Fallback: render component without design (same as normal rendering)"""
    config = get_config(component.name)
    children_html = render_children(component.children)

    if config:
        cls = build_classes(component.name, component.props)
        tag = config.get("tag", component.name)
        extra_attrs = build_extra_attrs(component.props)
        if tag in ("img", "input", "br", "hr"):
            return f'<{tag} class="{cls}"{extra_attrs}{_data_attrs(component)} />'
        return f'<{tag} class="{cls}"{extra_attrs}{_data_attrs(component)}>{children_html}</{tag}>'

    cls = component.name
    extra_attrs = build_extra_attrs(component.props)
    return f'<{cls} class="{cls}"{extra_attrs}>{children_html}</{cls}>'


def _has_slot_placeholders(children: list) -> bool:
    """Check if any child (recursively) contains a {slot} placeholder in content or props."""
    from ..nodes import Component as CompNode, Content
    for child in children:
        if isinstance(child, Content) and _SLOT_RE.search(child.text):
            return True
        if isinstance(child, CompNode):
            # Check props values for placeholders
            if any(_SLOT_RE.search(str(v)) for v in child.props.values() if isinstance(v, str)):
                return True
            if _has_slot_placeholders(child.children):
                return True
    return False


def _render_design_children(children: list, rendered_slots: dict[str, str], render_children: Callable) -> str:
    """Render the design AST children, replacing {slot} placeholders with rendered slot content"""
    from ..nodes import Component as CompNode, Content

    parts = []
    for child in children:
        if isinstance(child, Content):
            # Replace all {slot_name} placeholders in content text
            text = child.text
            text = _SLOT_RE.sub(
                lambda m: rendered_slots.get(m.group(1), ""),
                text
            )
            if text.strip():
                parts.append(text.strip())
        elif isinstance(child, CompNode):
            # Render the design's structural components
            inner = _render_design_children(child.children, rendered_slots, render_children)
            # Substitute slot placeholders in props values
            # Resolve placeholders in props, tracking which had unresolved slots
            has_empty_slot_prop = False
            resolved_props = {}
            for k, v in child.props.items():
                if isinstance(v, str) and _SLOT_RE.search(v):
                    resolved = _SLOT_RE.sub(lambda m: rendered_slots.get(m.group(1), ""), v)
                    if not resolved:
                        has_empty_slot_prop = True
                    resolved_props[k] = resolved
                else:
                    resolved_props[k] = v

            # Omit element entirely if a required prop slot (e.g. href) resolved to empty
            if has_empty_slot_prop:
                continue

            cls = resolved_props.get("class", "")
            tag = child.name
            child.props = resolved_props
            extra_attrs = build_extra_attrs(resolved_props)
            if tag in ("img", "input", "br", "hr"):
                parts.append(f'<{tag} class="{cls}"{extra_attrs} />' if cls else f'<{tag}{extra_attrs} />')
            elif not inner.strip():
                # Only omit if this element (or its descendants) had slot placeholders that
                # were not filled. Pure structural elements (no slots) are always rendered.
                if _has_slot_placeholders(child.children):
                    pass  # slot was empty — omit this element
                else:
                    # Structural element with no slots — render even if visually empty
                    if cls:
                        parts.append(f'<{tag} class="{cls}"{extra_attrs}></{tag}>')
                    else:
                        parts.append(f'<{tag}{extra_attrs}></{tag}>')
            elif cls:
                parts.append(f'<{tag} class="{cls}"{extra_attrs}>{inner}</{tag}>')
            else:
                parts.append(f'<{tag}{extra_attrs}>{inner}</{tag}>')
    return "".join(parts)


def _data_attrs(component) -> str:
    return f' data-node-id="{component.node_id}"'


# Load components from YAML first
load_components_from_yaml()
