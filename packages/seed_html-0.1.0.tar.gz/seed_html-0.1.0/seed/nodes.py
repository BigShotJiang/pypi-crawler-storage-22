from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import uuid


def _node_id() -> str:
    return uuid.uuid4().hex[:8]


@dataclass
class Content:
    text: str
    line: int = 0
    node_id: str = field(default_factory=_node_id)


@dataclass
class RawContent:
    """Pre-rendered HTML — must be emitted as-is, never escaped."""
    html: str


@dataclass
class Component:
    name: str
    props: dict[str, Any] = field(default_factory=dict)
    children: list[Component | Content] = field(default_factory=list)
    line: int = 0
    node_id: str = field(default_factory=_node_id)


@dataclass
class Include:
    path: str
    line: int = 0
    node_id: str = field(default_factory=_node_id)


@dataclass
class Block:
    name: str
    children: list[Component | Content] = field(default_factory=list)
    line: int = 0
    node_id: str = field(default_factory=_node_id)


@dataclass
class Page:
    meta: dict[str, Any] = field(default_factory=dict)
    children: list[Component | Content | Include | Block] = field(default_factory=list)
