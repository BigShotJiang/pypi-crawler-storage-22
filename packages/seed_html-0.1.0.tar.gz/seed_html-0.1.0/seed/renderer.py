from __future__ import annotations

from pathlib import Path

from .markdown import render_markdown, render_inline, escape_html
from .nodes import Block, Component, Content, Include, Page, RawContent
from .components import render_component


def render_plain(text: str) -> str:
    """Render content as inline-processed text: escapes HTML and handles
    backtick code, bold, italic and links — but does NOT wrap in <p>."""
    return render_inline(text.strip())


def render_preformatted(text: str) -> str:
    """Render content preserving whitespace exactly (for @pre/@code blocks).
    Escapes HTML entities so literal tags display as text."""
    return escape_html(text)

_TEMPLATES_DIR = Path(__file__).parent / "templates"
_STATIC_DIR = Path(__file__).parent / "static"


class Renderer:
    def __init__(self):
        self.includes: dict[str, str] = {}      # resolved_path → rendered HTML
        self._include_paths: dict[str, str] = {}  # include_path → resolved_path

    def clear_includes(self):
        """Clear include cache. Call before each full rebuild to avoid stale entries."""
        self.includes.clear()
        self._include_paths.clear()

    def render(self, page: Page) -> str:
        return self.render_children(page.children)

    def _build_body_class(self, meta: dict) -> str:
        """Build body class from meta properties with 'body-' prefix"""
        classes = []
        for key, value in meta.items():
            if key.startswith("body-"):
                class_key = key[5:]  # Remove 'body-' prefix
                if value is True:
                    classes.append(class_key)
                elif value:
                    classes.append(f"{class_key}-{value}")
        return " ".join(classes)

    def render_page(self, page: Page, css_path: str = None, js_path: str = None) -> str:
        body = self.render_children(page.children)
        meta = page.meta
        
        # Allow overriding CSS/JS via meta (e.g., css: /custom.css in front matter)
        if css_path is None:
            css_path = meta.get("css", "seed.css")
        if js_path is None:
            js_path = meta.get("js", "seed.js")
        
        # Support extra_css (list of additional CSS files)
        extra_css = meta.get("extra_css", [])
        if isinstance(extra_css, str):
            extra_css = [extra_css]

        # Support extra_js (list of additional JS files)
        extra_js = meta.get("extra_js", [])
        if isinstance(extra_js, str):
            extra_js = [extra_js]

        template = (_TEMPLATES_DIR / "base.html").read_text(encoding="utf-8")

        # Garantir que caminhos de CSS/JS sejam relativos à raiz (começam com /)
        if css_path and not css_path.startswith("/") and not css_path.startswith("http"):
            css_path = f"/{css_path}"
        if js_path and not js_path.startswith("/") and not js_path.startswith("http"):
            js_path = f"/{js_path}"

        # Build body class from meta (properties starting with 'body-')
        body_class = self._build_body_class(meta)
        body_attrs = f' class="{body_class}"' if body_class else ""

        # Build extra CSS links
        extra_css_links = ""
        for css_file in extra_css:
            if css_file:
                if not css_file.startswith("/") and not css_file.startswith("http"):
                    css_file = f"/{css_file}"
                extra_css_links += f'  <link rel="stylesheet" href="{css_file}">\n'

        # Build extra JS scripts
        extra_js_scripts = ""
        for js_file in extra_js:
            if js_file:
                if not js_file.startswith("/") and not js_file.startswith("http"):
                    js_file = f"/{js_file}"
                extra_js_scripts += f'        <script src="{js_file}"></script>\n'

        return template.format(
            lang=meta.get("lang", "en"),
            title=meta.get("title", ""),
            css_path=css_path,
            js_path=js_path,
            body=body,
            body_attrs=body_attrs,
            body_class=body_class,
            extra_css=extra_css_links,
            extra_js=extra_js_scripts,
        )

    def resolve_includes(
        self,
        page: Page,
        base_dir: Path,
        templates_dir: Path | None = None,
        theme_includes_dir: Path | None = None,
    ):
        self._resolve_includes_recursive(page.children, base_dir, templates_dir, theme_includes_dir)

    def _resolve_includes_recursive(
        self,
        children: list,
        base_dir: Path,
        templates_dir: Path | None,
        theme_includes_dir: Path | None = None,
    ):
        for child in children:
            if isinstance(child, Include) and child.path not in self._include_paths:
                self._resolve_include(child.path, base_dir, templates_dir, theme_includes_dir)
            elif isinstance(child, Component) and child.children:
                self._resolve_includes_recursive(child.children, base_dir, templates_dir, theme_includes_dir)
            elif isinstance(child, Block) and child.children:
                self._resolve_includes_recursive(child.children, base_dir, templates_dir, theme_includes_dir)

    def _resolve_include(
        self,
        include_path: str,
        base_dir: Path,
        templates_dir: Path | None,
        theme_includes_dir: Path | None = None,
    ):
        from .parser import parse

        candidates = [base_dir / f"{include_path}.seed", base_dir / include_path]
        if templates_dir:
            candidates.extend([templates_dir / f"{include_path}.seed", templates_dir / include_path])
        if theme_includes_dir:
            candidates.extend([
                theme_includes_dir / f"{include_path}.seed",
                theme_includes_dir / include_path,
            ])

        for candidate in candidates:
            if candidate.is_file():
                resolved_key = str(candidate.resolve())
                self._include_paths[include_path] = resolved_key
                if resolved_key not in self.includes:
                    source = candidate.read_text(encoding="utf-8")
                    included_page = parse(source)
                    self.includes[resolved_key] = self.render_children(included_page.children)
                return

    def render_children(self, children: list, use_markdown: bool = False) -> str:
        """Render children. If use_markdown=True, process as markdown. Otherwise, render as plain text."""
        render_fn = render_markdown if use_markdown else render_plain
        parts = []
        for child in children:
            if isinstance(child, Component):
                parts.append(render_component(child, self.render_children, self.render_children_pre))
            elif isinstance(child, RawContent):
                parts.append(child.html)
            elif isinstance(child, Content):
                parts.append(render_fn(child.text))
            elif isinstance(child, Block):
                inner = self.render_children(child.children)
                parts.append(f'<div class="block" data-block="{child.name}">{inner}</div>')
            elif isinstance(child, Include):
                resolved_key = self._include_paths.get(child.path)
                parts.append(
                    self.includes.get(resolved_key, f"<!-- include: {child.path} -->")
                    if resolved_key else f"<!-- include: {child.path} -->"
                )
        return "".join(parts)

    def render_children_pre(self, children: list) -> str:
        """Render children for @pre/@code: preserve whitespace, join with newlines."""
        parts = []
        for child in children:
            if isinstance(child, Content):
                parts.append(render_preformatted(child.text))
        return "\n".join(parts)
    
    def render_children_md(self, children: list) -> str:
        """Render children as markdown"""
        return self.render_children(children, use_markdown=True)
