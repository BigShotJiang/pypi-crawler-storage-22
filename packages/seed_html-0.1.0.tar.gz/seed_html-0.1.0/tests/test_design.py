"""Tests for the design system (component folders with .design files)"""
from pathlib import Path

import pytest

from seed import Seed
from seed.components import (
    _design_cache,
    _registry,
    _extract_slots,
    _load_component_folder,
    get_design,
    get_design_slot_names,
    has_design,
    reload_components_yaml,
)


def _make_component_folder(tmp_path, name, yaml_content, designs: dict[str, str]):
    """Helper: create a component folder with yaml and .design files"""
    folder = tmp_path / name
    folder.mkdir()

    yaml_file = folder / f"{name}.yaml"
    yaml_file.write_text(yaml_content, encoding="utf-8")

    for design_name, design_content in designs.items():
        design_file = folder / f"{design_name}.design"
        design_file.write_text(design_content, encoding="utf-8")

    return folder


class TestDesignLoading:
    def test_load_component_folder_with_yaml_and_design(self, tmp_path):
        """Loading a component folder registers YAML config and parses .design files"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: section\n  class: my-class\n",
            {"mycomp": "@div class=wrapper\n  {title}\n  {children}"},
        )

        _load_component_folder(folder)

        assert "mycomp" in _registry
        assert _registry["mycomp"]["tag"] == "section"
        assert has_design("mycomp")
        assert get_design("mycomp", "default") is not None

    def test_load_design_variant(self, tmp_path):
        """Design files with names different from folder become named variants"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {
                "mycomp": "@div class=default-layout\n  {title}",
                "compact": "@div class=compact-layout\n  {title}",
            },
        )

        _load_component_folder(folder)

        assert get_design("mycomp", "default") is not None
        assert get_design("mycomp", "compact") is not None

    def test_get_design_falls_back_to_default(self, tmp_path):
        """get_design falls back to 'default' when requested variant doesn't exist"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {"mycomp": "@div\n  {title}"},
        )

        _load_component_folder(folder)

        # Request nonexistent variant → falls back to default
        design = get_design("mycomp", "nonexistent")
        assert design is not None

    def teardown_method(self):
        """Clean up design cache after each test"""
        _design_cache.clear()
        # Reload to restore original state
        reload_components_yaml()


class TestSlotExtraction:
    def test_extract_slots_from_design(self, tmp_path):
        """Slot names are extracted from {placeholder} in Content nodes"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {"mycomp": "@div\n  @h1\n    {title}\n  @p\n    {description}\n  {cta}"},
        )

        _load_component_folder(folder)

        slots = get_design_slot_names("mycomp")
        assert "title" in slots
        assert "description" in slots
        assert "cta" in slots

    def test_extract_children_slot(self, tmp_path):
        """The {children} placeholder is also a valid slot"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {"mycomp": "@div\n  {title}\n  {children}"},
        )

        _load_component_folder(folder)

        slots = get_design_slot_names("mycomp")
        assert "title" in slots
        assert "children" in slots

    def teardown_method(self):
        _design_cache.clear()
        reload_components_yaml()


class TestDesignRendering:
    def setup_method(self):
        # Ensure clean state with hero loaded from folder
        reload_components_yaml()

    def test_hero_renders_with_design(self):
        """Hero component with design produces structured HTML"""
        seed = Seed()
        source = (
            "@hero\n"
            "  @title\n"
            "    Build Amazing Websites\n"
            "  @description\n"
            "    The modern way to create\n"
            "  @cta\n"
            "    @button variant=primary\n"
            "      Get Started\n"
        )
        html = seed.render_string(source)

        # Outer wrapper from YAML config
        assert "<section" in html
        assert "min-h-96" in html

        # Design structure
        assert "flex-1" in html
        assert "text-5xl" in html

        # Slot content
        assert "Build Amazing Websites" in html
        assert "The modern way to create" in html
        assert "Get Started" in html

    def test_hero_with_center_design(self):
        """design=center selects the center.design template"""
        seed = Seed()
        source = (
            "@hero design=center\n"
            "  @title\n"
            "    Centered Title\n"
            "  @description\n"
            "    Centered description\n"
            "  @cta\n"
            "    @button\n"
            "      Click\n"
        )
        html = seed.render_string(source)

        # Center design structure
        assert "text-center" in html
        assert "max-w-2xl" in html
        assert "Centered Title" in html

    def test_hero_with_variant_css(self):
        """variant=dark applies CSS classes from YAML, independent of design="""
        seed = Seed()
        source = (
            "@hero variant=dark\n"
            "  @title\n"
            "    Dark Hero\n"
        )
        html = seed.render_string(source)

        assert "bg-gray-900" in html
        assert "text-white" in html
        assert "Dark Hero" in html

    def test_design_and_variant_independent(self):
        """design= and variant= work independently"""
        seed = Seed()
        source = (
            "@hero design=center, variant=primary\n"
            "  @title\n"
            "    Both\n"
        )
        html = seed.render_string(source)

        # CSS from variant
        assert "bg-indigo-600" in html
        # Structure from center design
        assert "text-center" in html
        assert "Both" in html

    def test_unfilled_slot_is_empty(self):
        """Slots not filled by user produce empty string (no leftover placeholder)"""
        seed = Seed()
        source = (
            "@hero\n"
            "  @title\n"
            "    Only Title\n"
        )
        html = seed.render_string(source)

        assert "Only Title" in html
        # No raw placeholders should remain
        assert "{description}" not in html
        assert "{cta}" not in html
        assert "{image}" not in html

    def test_self_closing_slot(self):
        """Self-closing slot like @image src=... is rendered as component"""
        seed = Seed()
        source = (
            "@hero\n"
            "  @title\n"
            "    Hello\n"
            "  @image src=hero.png, alt=Screenshot\n"
        )
        html = seed.render_string(source)

        assert "hero.png" in html
        assert "Screenshot" in html


class TestDesignWithTmpComponents:
    """Test design system with temporary component folders"""

    def test_render_with_custom_design(self, tmp_path):
        """Custom component folder with design renders correctly"""
        folder = _make_component_folder(
            tmp_path,
            "banner",
            "banner:\n  tag: div\n  class: banner-wrapper\n",
            {"banner": "@div class=inner\n  @h2\n    {title}\n  @div class=body\n    {children}"},
        )

        _load_component_folder(folder)

        seed = Seed()
        source = (
            "@banner\n"
            "  @title\n"
            "    Hello Banner\n"
            "  Some body content\n"
        )
        html = seed.render_string(source)

        assert "banner-wrapper" in html
        assert "inner" in html
        assert "Hello Banner" in html
        assert "Some body content" in html

    def test_children_catch_all(self, tmp_path):
        """Children not matching any slot go to {children} catch-all"""
        folder = _make_component_folder(
            tmp_path,
            "wrapper",
            "wrapper:\n  tag: div\n  class: wrap\n",
            {"wrapper": "@div class=header\n  {title}\n@div class=body\n  {children}"},
        )

        _load_component_folder(folder)

        seed = Seed()
        source = (
            "@wrapper\n"
            "  @title\n"
            "    My Title\n"
            "  @button\n"
            "    Click\n"
            "  Some text\n"
        )
        html = seed.render_string(source)

        assert "My Title" in html
        assert "Click" in html
        assert "Some text" in html

    def test_component_without_design_renders_normally(self):
        """Components without designs still render the normal way"""
        seed = Seed()
        source = "@section\n  Hello"
        html = seed.render_string(source)

        assert "<section" in html
        assert "Hello" in html

    def teardown_method(self):
        _design_cache.clear()
        reload_components_yaml()


class TestRetrocompatibility:
    """Ensure existing components still work after design system changes"""

    def test_button_still_works(self):
        seed = Seed()
        html = seed.render_string("@button variant=primary\n  Click")
        assert "Click" in html
        assert "bg-indigo-600" in html

    def test_section_still_works(self):
        seed = Seed()
        html = seed.render_string("@section\n  Content")
        assert "<section" in html
        assert "Content" in html

    def test_card_still_works(self):
        seed = Seed()
        html = seed.render_string("@card\n  Card content")
        assert "card" in html
        assert "Card content" in html

    def test_image_still_works(self):
        seed = Seed()
        html = seed.render_string('@image src=test.png, alt=Test')
        assert "test.png" in html
