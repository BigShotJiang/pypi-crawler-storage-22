from pathlib import Path

from seed import Seed


class TestRenderer:
    def setup_method(self):
        self.seed = Seed()

    def test_simple_hero(self):
        source = "@hero\n  @title\n    Hello\n  @description\n    Some text."
        html = self.seed.render_string(source)
        assert "<section" in html
        assert "min-h-96" in html
        assert "Hello" in html
        assert "Some text." in html

    def test_button_with_href(self):
        source = "@button: href=/signup, variant=primary\n  Click me"
        html = self.seed.render_string(source)
        assert 'href="/signup"' in html
        assert "Click me" in html
        assert "<a " in html

    def test_button_without_href(self):
        source = "@button: variant=primary\n  Click"
        html = self.seed.render_string(source)
        assert "<button " in html

    def test_image(self):
        source = '@image: src=/hero.jpg, alt="Hero Image"'
        html = self.seed.render_string(source)
        assert 'src="/hero.jpg"' in html
        assert 'alt="Hero Image"' in html

    def test_nested_columns(self):
        source = "@columns: count=2\n  @column:\n    # Left\n  @column:\n    # Right"
        html = self.seed.render_string(source)
        assert "columns" in html
        assert "column" in html
        assert "Left" in html
        assert "Right" in html

    def test_card(self):
        source = "@card:\n  Title\n  Description."
        html = self.seed.render_string(source)
        assert "card" in html
        assert "Title" in html

    def test_faq(self):
        source = '@faq:\n  @question: q="How?"\n    Answer here.'
        html = self.seed.render_string(source)
        assert "faq" in html
        assert "How?" in html
        assert "Answer here" in html

    def test_markdown_rendering(self):
        source = "@section:\n  **bold** and *italic*"
        html = self.seed.render_string(source)
        assert "<strong>bold</strong>" in html
        assert "<em>italic</em>" in html

    def test_inline_components(self):
        source = "@section:\n  Use {tag warning}cuidado{/tag} aqui."
        html = self.seed.render_string(source)
        assert "warning" in html
        assert "cuidado" in html

    def test_node_ids(self):
        source = "@hero\n  @title\n    Title"
        html = self.seed.render_string(source)
        assert "data-node-id" in html

    def test_features(self):
        source = "@features:\n  @card:\n    Item"
        html = self.seed.render_string(source)
        assert "features" in html
        assert "card" in html
        assert "Item" in html

    def test_header_meta(self):
        source = "---\ntitle: Test\ntemplate: base\n---\n@hero\n  @title\n    Hello"
        page = self.seed.parse(source)
        assert page.meta["title"] == "Test"
        html = self.seed.render_string(source)
        assert "Hello" in html

    def test_divider(self):
        html = self.seed.render_string("@divider:")
        assert "<hr" in html

    def test_spacer(self):
        html = self.seed.render_string("@spacer:")
        assert "h-8" in html

    def test_spacer_variant(self):
        html = self.seed.render_string("@spacer: variant=xl")
        assert "h-16" in html

    def test_video(self):
        html = self.seed.render_string("@video: src=/video.mp4")
        assert "<video" in html

    def test_quote(self):
        source = '@quote: cite="Author"\n  Some wise words.'
        html = self.seed.render_string(source)
        assert "<blockquote" in html
        assert "Author" in html

    def test_stat(self):
        source = "@stat: value=99%, label=Uptime"
        html = self.seed.render_string(source)
        assert "99%" in html
        assert "Uptime" in html

    def test_split(self):
        source = "@split:\n  @column:\n    Left side\n  @column:\n    Right side"
        html = self.seed.render_string(source)
        assert "split" in html
        assert "column" in html
        assert "Left side" in html
        assert "Right side" in html

    def test_accordion(self):
        source = '@accordion:\n  @item:\n    Content here.'
        html = self.seed.render_string(source)
        assert "space-y-2" in html
        assert "Content here." in html

    def test_empty_string(self):
        html = self.seed.render_string("")
        assert html == ""

    def test_code_fence_renders_as_code(self):
        source = "@section:\n  ```\n  @hero: bg=primary\n  ```"
        html = self.seed.render_string(source)
        assert "<code>" in html or "<code " in html
        assert "@hero: bg=primary" in html
        assert "seed-hero" not in html

    def test_plain_content(self):
        # Content outside components renders as plain text (no markdown processing)
        html = self.seed.render_string("Just some text.")
        assert "Just some text." in html

    def test_markdown_in_component(self):
        # Markdown is processed inside components that support it
        source = "@section:\n  **bold** and _italic_"
        html = self.seed.render_string(source)
        assert "<strong>bold</strong>" in html
        assert "<em>italic</em>" in html

    def test_render_file(self, tmp_path):
        seed_file = tmp_path / "test.seed"
        seed_file.write_text("@hero\n  @title\n    Hello")
        html = self.seed.render_file(seed_file)
        assert "<section" in html
        assert "Hello" in html


class TestFullPage:
    def setup_method(self):
        self.seed = Seed()

    def test_full_page_has_html_structure(self):
        source = "---\ntitle: My Page\nlang: pt-BR\n---\n@hero\n  @title\n    Hello"
        html = self.seed.render_string(source, full_page=True)
        assert "<!DOCTYPE html>" in html
        assert '<html lang="pt-BR">' in html
        assert "<title>My Page</title>" in html
        assert 'seed.css' in html
        assert 'seed.js' in html
        assert "Hello" in html

    def test_full_page_defaults(self):
        source = "@hero:\n  # Hello"
        html = self.seed.render_string(source, full_page=True)
        assert '<html lang="en">' in html
        assert "<title></title>" in html

    def test_full_page_false_no_doctype(self):
        source = "@hero:\n  # Hello"
        html = self.seed.render_string(source, full_page=False)
        assert "<!DOCTYPE" not in html

    def test_render_file_full_page(self, tmp_path):
        seed_file = tmp_path / "test.seed"
        seed_file.write_text("---\ntitle: File Test\n---\n@section\n  Content")
        html = self.seed.render_file(seed_file, full_page=True)
        assert "<!DOCTYPE html>" in html
        assert "<title>File Test</title>" in html
        assert "Content" in html


class TestIncludes:
    def test_include_resolves_from_file(self, tmp_path):
        navbar = tmp_path / "navbar.seed"
        navbar.write_text("@navbar:\n  @link: href=/\n    Home")

        index = tmp_path / "index.seed"
        index.write_text("@include: path=navbar\n@section:\n  Content")

        seed = Seed()
        html = seed.render_file(index)
        assert "<nav" in html
        assert "Home" in html
        assert "Content" in html

    def test_include_not_found_renders_comment(self):
        source = "@include: path=missing\n@section:\n  Content"
        seed = Seed()
        html = seed.render_string(source)
        assert "<!-- include: missing -->" in html
        assert "Content" in html


class TestBuild:
    def test_build_creates_output(self, tmp_path):
        src = tmp_path / "src"
        src.mkdir()
        seed_file = src / "index.seed"
        seed_file.write_text("---\ntitle: Build Test\n---\n@hero\n  @title\n    Hello")

        output = tmp_path / "output"
        seed = Seed()
        result = seed.build(seed_file, output)

        assert result.exists()
        assert (output / "index.html").exists()
        assert (output / "seed.css").exists()
        assert (output / "seed.js").exists()

        html = (output / "index.html").read_text()
        assert "<!DOCTYPE html>" in html
        assert "Build Test" in html
