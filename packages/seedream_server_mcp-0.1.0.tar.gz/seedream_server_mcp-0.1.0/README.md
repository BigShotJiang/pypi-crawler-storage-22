# seedream-mcp

基于火山方舟图片生成 API 的 MCP 服务，提供：

- 文生图：`seedream_text_to_image`
- 图生图：`seedream_image_to_image`

项目已改为 **uv 可运行 + 可发布包** 结构（`pyproject.toml` + `src/` 布局）。

## 1) 环境变量

复制 `.env.example` 为 `.env` 后填写：

```env
model=doubao-seedream-4.0
apikey=YOUR_ARK_API_KEY
```

兼容别名：

- `SEEDREAM_MODEL`
- `SEEDREAM_API_KEY` / `SEEDREAM_APIKEY`
- `ARK_API_KEY`

## 2) uv 运行（推荐）

在 `seedream-mcp/` 目录执行：

```bash
uv sync
uv run seedream-mcp --transport stdio
```

如果要跑 HTTP（给网关或手工调试）：

```bash
uv run seedream-mcp --transport http --host 127.0.0.1 --port 8004
```

也支持模块方式：

```bash
uv run python -m seedream_mcp --transport stdio
```

## 3) 发布包

```bash
uv build
uv publish
```

发布到 TestPyPI（如已配置 index）：

```bash
uv publish --index testpypi
```

## 4) OpenCode MCP 配置示例（参考你的 `opencode.json` 风格）

### 本地项目直接运行

```json
{
  "mcp": {
    "seedream-mcp": {
      "type": "local",
      "command": [
        "uv",
        "run",
        "--directory",
        "D:/OneDrive/WORK/Python/mcps/seedream-mcp",
        "seedream-mcp"
      ],
      "environment": {
        "model": "doubao-seedream-4.0",
        "apikey": "YOUR_ARK_API_KEY",
        "SEEDREAM_MCP_TRANSPORT": "stdio"
      }
    }
  }
}
```

### 已发布后通过 uvx 使用

```json
{
  "mcp": {
    "seedream-mcp": {
      "type": "local",
      "command": ["uvx", "seedream-server-mcp"],
      "environment": {
        "model": "doubao-seedream-4.0",
        "apikey": "YOUR_ARK_API_KEY",
        "SEEDREAM_MCP_TRANSPORT": "stdio"
      }
    }
  }
}
```

## 5) 接口说明（官方文档）

- Base URL：`https://ark.cn-beijing.volces.com/api/v3`
- 路径：`POST /images/generations`
- 鉴权：`Authorization: Bearer <apikey>`

文档：

- https://www.volcengine.com/docs/82379/1541523?lang=zh
- https://www.volcengine.com/docs/82379/1298459?lang=zh
