"""Output formatters for Segmenta."""

from segmenta.output.base import OutputFormatter
from segmenta.output.markdown_formatter import MarkdownFormatter

__all__ = [
    "OutputFormatter",
    "MarkdownFormatter",
]
