from setuptools import setup

with open("README_PYPI.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="seismo-framework",
    version="1.0.2",
    author="Samir Baladi",
    author_email="gitdeeper@gmail.com",
    description="Advanced seismic data analysis and monitoring framework",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/gitdeeper3/seismo",
    packages=['seismo_framework'],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Physics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
        "pandas>=1.3.0",
        "python-dateutil>=2.8.0",
        "pytz>=2021.3",
        "tzlocal>=4.0",
        "pyyaml>=6.0",
    ],
    keywords=["seismic", "earthquake", "monitoring", "geophysics"],
)
