# Sejal CLI Portfolio

A simple command line portfolio built with Python, Rich, and Click.

## Commands

sejal home
sejal projects
sejal skills
sejal contact
