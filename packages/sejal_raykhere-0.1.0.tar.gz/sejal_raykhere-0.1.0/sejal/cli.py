import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

# Create CLI group
@click.group()
def cli():
    """Sejal CLI Portfolio"""
    pass


# ---------------- HOME ----------------
@cli.command()
def home():
    console.print(
        Panel.fit(
            "[bold cyan]Hi, I am Sejal Raykhere[/bold cyan]\n"
            "B.Tech AIML Student\n"
            "Passionate about Data Science and Machine Learning",
            title="Welcome to Sejal Portfolio",
            border_style="cyan"
        )
    )


# ---------------- PROJECTS ----------------
@cli.command()
def projects():
    table = Table(title="My Projects")

    table.add_column("Project Name", style="cyan")
    table.add_column("Description", style="magenta")

    table.add_row(
        "YOLO Object Detection",
        "Built custom detection model with 75.7 mAP"
    )
    table.add_row(
        "Home Loan Price Prediction",
        "Built ML model using sklearn with 85% accuracy"
    )

    console.print(table)


# ---------------- SKILLS ----------------
@cli.command()
def skills():
    console.print(
        Panel.fit(
            "[bold]Languages:[/bold] Python, C++\n"
            "[bold]ML:[/bold] Scikit-learn, Pandas, NumPy, Matplotlib",
            title="Skills",
            border_style="green"
        )
    )


# ---------------- CONTACT ----------------
@cli.command()
def contact():
    console.print(
        Panel.fit(
            "📧 Email: sejalraykhere19@gmail.com\n"
            "🐙 GitHub: https://github.com/sejal_raykhere",
            title="Contact Me",
            border_style="yellow"
        )
    )


if __name__ == "__main__":
    cli()
