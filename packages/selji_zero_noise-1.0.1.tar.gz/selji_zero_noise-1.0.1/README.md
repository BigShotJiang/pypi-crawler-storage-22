# selji-zero-noise

Zero-Noise utilities for safer product research.

`selji-zero-noise` provides small, practical tools to support evidence-based buying decisions by analyzing review signals and confidence patterns.

This project is part of the **SELJI Zero-Noise Shopping** initiative.

Website: https://selji.com

---

## Features

- Product confidence scoring based on rating volume and averages
- Review noise signal detection (e.g. suspicious rating distributions)
- Clean Amazon search query construction

The tools are intentionally simple, transparent, and easy to integrate.

---

## Installation

```bash
pip install selji-zero-noise