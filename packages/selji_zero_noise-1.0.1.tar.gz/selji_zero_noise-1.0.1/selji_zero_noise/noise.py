def detect_review_noise(reviews):
    flags = []

    short_reviews = [r for r in reviews if len(r.get("text", "")) < 30]
    if len(short_reviews) / max(len(reviews), 1) > 0.4:
        flags.append("high_short_review_ratio")

    five_star = [r for r in reviews if r.get("rating") == 5]
    if len(five_star) / max(len(reviews), 1) > 0.85:
        flags.append("suspicious_five_star_density")

    return {
        "noise": len(flags),
        "flags": flags
    }