def build_amazon_query(
    keywords=None,
    exclude=None,
    min_rating=4,
    min_reviews=50
):
    keywords = keywords or []
    exclude = exclude or []

    parts = []
    if keywords:
        parts.append(" ".join(keywords))

    for word in exclude:
        parts.append(f"-{word}")

    parts.append(f"rating:{min_rating}+")
    parts.append(f"reviews:{min_reviews}+")

    return " ".join(parts)