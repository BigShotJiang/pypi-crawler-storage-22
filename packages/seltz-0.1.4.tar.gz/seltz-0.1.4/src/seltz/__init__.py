"""Seltz Python SDK for interacting with the Seltz API."""

from .exceptions import (
    SeltzAPIError,
    SeltzAuthenticationError,
    SeltzConfigurationError,
    SeltzConnectionError,
    SeltzError,
    SeltzRateLimitError,
    SeltzTimeoutError,
)
from .seltz import Seltz
from .types import Document, Includes, SearchResult

__all__ = [
    # Main client
    "Seltz",
    # Types
    "Includes",
    "SearchResult",
    "Document",
    # Exceptions
    "SeltzError",
    "SeltzConfigurationError",
    "SeltzAuthenticationError",
    "SeltzConnectionError",
    "SeltzAPIError",
    "SeltzTimeoutError",
    "SeltzRateLimitError",
]
