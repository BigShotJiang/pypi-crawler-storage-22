"""Type definitions for the Seltz SDK."""

from typing import Iterator, Optional

from seltz_public_api.proto.v1.seltz_pb2 import (
    Document as PbDocument,
)
from seltz_public_api.proto.v1.seltz_pb2 import (
    Includes as PbIncludes,
)
from seltz_public_api.proto.v1.seltz_pb2 import (
    SearchResponse as PbSearchResponse,
)


class Includes:
    """Configuration for what to include in search results.

    This class provides a user-friendly interface for configuring search result
    inclusions, wrapping the underlying protobuf Includes message.

    Supports both constructor and fluent builder patterns:

    Constructor pattern (simple):
        >>> includes = Includes(max_documents=5)
        >>> response = client.search("query", includes=includes)

    Fluent builder pattern (for multiple fields):
        >>> includes = Includes().max_documents(5)
        >>> response = client.search("query", includes=includes)

    Attributes:
        max_documents: Maximum number of documents to return in the response.
    """

    def __init__(
        self,
        max_documents: int = 10,
    ):
        """Initialize the Includes configuration.

        Args:
            max_documents: Maximum number of documents to return. If not specified,
                the server will use its default value.
        """
        self._max_documents = max_documents

    def max_documents(self, value: int) -> "Includes":
        """Set maximum number of documents (fluent builder method).

        Args:
            value: Maximum number of documents to return.

        Returns:
            Self for method chaining.

        Example:
            >>> includes = Includes().max_documents(10)
            >>> # Or chain multiple fields (when more fields are available)
            >>> includes = Includes().max_documents(10).include_metadata(True)
        """
        self._max_documents = value
        return self

    def _to_protobuf(self) -> PbIncludes:
        """Convert to protobuf Includes message.

        Internal method used by the SDK to convert this user-facing object
        to the underlying protobuf representation.

        Returns:
            PbIncludes: Protobuf Includes message.
        """
        pb_includes = PbIncludes()
        pb_includes.max_documents = self._max_documents
        return pb_includes

    def __repr__(self) -> str:
        """String representation for debugging."""
        params = []
        params.append(f"max_documents={self._max_documents}")
        return f"Includes({', '.join(params)})"


class Document:
    """A search result document.

    This class wraps the protobuf Document message with a more user-friendly
    interface and helper methods.

    Example:
        >>> doc = response.documents[0]
        >>> print(doc.url)
        >>> print(doc.content[:100])
        >>> if doc.has_content():
        ...     print("Document has content")

    Attributes:
        url: URL of the document (may be None for non-web documents)
        content: Content/snippet of the document
    """

    def __init__(self, pb_document: PbDocument):
        """Initialize from protobuf Document.

        Args:
            pb_document: Protobuf Document message
        """
        self._pb = pb_document

    @property
    def url(self) -> Optional[str]:
        """Get the document URL.

        Returns:
            URL string if available, None otherwise.
        """
        return self._pb.url if self._pb.HasField("url") else None

    @property
    def content(self) -> Optional[str]:
        """Get the document content.

        Returns:
            Content string if available, None otherwise.
        """
        return self._pb.content if self._pb.HasField("content") else None

    def has_url(self) -> bool:
        """Check if document has a URL.

        Returns:
            True if URL is present, False otherwise.
        """
        return self._pb.HasField("url")

    def has_content(self) -> bool:
        """Check if document has content.

        Returns:
            True if content is present, False otherwise.
        """
        return self._pb.HasField("content")

    def to_dict(self) -> dict:
        """Convert document to a dictionary.

        Useful for JSON serialization or logging.

        Returns:
            Dictionary with url and content fields (only if present).
        """
        result = {}
        if self.has_url():
            result["url"] = self.url
        if self.has_content():
            result["content"] = self.content
        return result

    def __repr__(self) -> str:
        """String representation for debugging."""
        parts = []
        if self.has_url():
            parts.append(f"url='{self.url}'")
        if self.content is not None:
            content_preview = (
                self.content[:50] + "..." if len(self.content) > 50 else self.content
            )
            parts.append(f"content='{content_preview}'")
        return f"Document({', '.join(parts)})"

    def __str__(self) -> str:
        """Human-readable string representation."""
        if self.url is not None:
            return f"{self.url}: {self.content[:100] if self.content is not None else 'No content'}"
        return self.content if self.content is not None else "Empty document"


class SearchResult:
    """Search result containing documents and metadata.

    This class wraps the protobuf SearchResponse message with a more user-friendly
    interface and helper methods.

    Example:
        >>> result = client.search("Python tutorial")
        >>> print(f"Found {len(result)} documents")
        >>> for doc in result:
        ...     print(doc.url)
        >>> first = result.first()
        >>> urls = result.get_urls()

    Attributes:
        documents: List of Document objects in the search results
    """

    def __init__(self, pb_response: PbSearchResponse):
        """Initialize from protobuf SearchResponse.

        Args:
            pb_response: Protobuf SearchResponse message
        """
        self._pb = pb_response
        self._documents = [Document(pb_doc) for pb_doc in pb_response.documents]

    @property
    def documents(self) -> list[Document]:
        """Get the list of documents.

        Returns:
            List of Document objects.
        """
        return self._documents

    def __len__(self) -> int:
        """Get the number of documents.

        Returns:
            Number of documents in the result.
        """
        return len(self._documents)

    def __iter__(self) -> Iterator[Document]:
        """Iterate over documents.

        Returns:
            Iterator over Document objects.
        """
        return iter(self._documents)

    def __getitem__(self, index: int) -> Document:
        """Get document by index.

        Args:
            index: Index of the document (supports negative indexing)

        Returns:
            Document at the specified index.

        Raises:
            IndexError: If index is out of range.
        """
        return self._documents[index]

    def first(self) -> Optional[Document]:
        """Get the first document.

        Returns:
            First document if available, None if result is empty.
        """
        return self._documents[0] if self._documents else None

    def get_urls(self) -> list[str]:
        """Get all document URLs.

        Returns:
            List of URLs from documents that have URLs.
        """
        return [doc.url for doc in self._documents if doc.url is not None]

    def get_contents(self) -> list[str]:
        """Get all document contents.

        Returns:
            List of content strings from documents that have content.
        """
        return [doc.content for doc in self._documents if doc.content is not None]

    def to_dict(self) -> dict:
        """Convert result to a dictionary.

        Useful for JSON serialization or logging.

        Returns:
            Dictionary with documents list.
        """
        return {"documents": [doc.to_dict() for doc in self._documents]}

    def __repr__(self) -> str:
        """String representation for debugging."""
        return f"SearchResult(documents={len(self._documents)})"

    def __str__(self) -> str:
        """Human-readable string representation."""
        return f"SearchResult with {len(self._documents)} document(s)"
