"""Service layer for indexing and search orchestration."""
