"""Semantic Code MCP Server."""

from semantic_code_mcp.cli import main

__all__ = ["main"]
