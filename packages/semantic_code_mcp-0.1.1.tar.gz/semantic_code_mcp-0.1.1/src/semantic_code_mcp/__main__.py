"""Entry point for python -m semantic_code_mcp."""

from semantic_code_mcp.cli import main

if __name__ == "__main__":
    main()
