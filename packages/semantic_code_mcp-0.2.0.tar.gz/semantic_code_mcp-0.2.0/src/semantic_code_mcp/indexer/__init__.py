"""Indexing components: chunking, embedding, orchestration."""
