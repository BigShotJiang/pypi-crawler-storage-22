# NNN: Title

**Status**: proposed | accepted | implemented | superseded
**Date**: YYYY-MM-DD

## Context

What problem are we solving? Why now?

## Decision

What did we decide?

## Alternatives Considered

What else did we consider and why was it rejected?

## Consequences

What are the implications of this decision?
