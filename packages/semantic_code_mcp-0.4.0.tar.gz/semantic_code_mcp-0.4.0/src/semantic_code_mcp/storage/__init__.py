"""Storage components: vector database and file cache."""
