"""Tests for semantic-code-mcp."""
