"""Sendspin GUI - A GUI wrapper for testing the aiosendspin server."""

__version__ = "0.1.0"
