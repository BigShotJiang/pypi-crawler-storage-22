# Sendviacli (svc)

A command-line tool for secure, fast, single-file sharing via short codes.

## Installation

```bash
pip install .
```

## Usage

### Upload a file
```bash
svc upload <file_path>
```

### Retrieve a file
```bash
svc get <code>
```
