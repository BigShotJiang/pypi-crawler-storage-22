from setuptools import setup, find_packages

setup(
    name='sendviacli',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'requests',
        'rich',
    ],
    entry_points={
        'console_scripts': [
            'svc=sendviacli.cli:main',
        ],
    },
    author='SendVia Team',
    description='A command-line tool for secure, fast, single-file sharing via short codes.',
    long_description=open('README.md').read() if open('README.md') else '',
    long_description_content_type='text/markdown',
    python_requires='>=3.6',
)
