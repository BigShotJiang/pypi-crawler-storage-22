"""SenoQuant napari plugin package."""

from ._widget import SenoQuantWidget

__version__ = "1.0.0b1"
__all__ = ["SenoQuantWidget"]
