"""Reader package for SenoQuant."""

from .core import get_reader

__all__ = ["get_reader"]
