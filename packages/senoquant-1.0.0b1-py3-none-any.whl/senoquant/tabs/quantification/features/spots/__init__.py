"""Spots feature UI package."""

from .feature import SpotsFeature

__all__ = ["SpotsFeature"]
