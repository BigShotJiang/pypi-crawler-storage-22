"""Perinuclear rings cytoplasmic segmentation model."""
