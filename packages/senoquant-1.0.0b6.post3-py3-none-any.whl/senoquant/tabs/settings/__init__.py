"""Settings tab modules."""
