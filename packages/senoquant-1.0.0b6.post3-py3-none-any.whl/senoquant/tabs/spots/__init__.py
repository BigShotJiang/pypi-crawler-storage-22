"""Spots tab modules."""
