"""Visualization tab."""
