import json
from dataclasses import dataclass
from typing import Any
from urllib.parse import urljoin


@dataclass
class APIError(Exception):
    message: str
    status_code: int | None = None
    suggestion: str | None = None

    def __str__(self) -> str:
        if self.suggestion:
            return f"{self.message} {self.suggestion}"
        return self.message


class APIClient:
    def __init__(self, base_url: str, token: str | None, timeout_seconds: int = 60):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout_seconds = timeout_seconds

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        timeout_seconds: int | None = None,
    ) -> Any:
        try:
            import requests
        except ImportError as e:
            raise APIError(
                "Missing dependency 'requests'. Install project dependencies to use CLI API calls."
            ) from e

        if not self.token:
            raise APIError(
                "Not logged in.",
                suggestion="Run `sense-cli login` or set SENSELAB_TOKEN.",
            )

        url = urljoin(f"{self.base_url}/", path.lstrip("/"))
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._headers(),
                json=json_body,
                params=params,
                timeout=timeout_seconds or self.timeout_seconds,
            )
        except requests.Timeout as e:
            raise APIError(
                "Request timed out while contacting SenseLab API.",
                suggestion="Try again or check backend availability.",
            ) from e
        except requests.RequestException as e:
            raise APIError(
                f"Failed to reach API: {e}",
                suggestion="Check network connectivity and --base-url.",
            ) from e

        if response.status_code == 401:
            raise APIError(
                "Not logged in.",
                status_code=401,
                suggestion="Run `sense-cli login` or set SENSELAB_TOKEN.",
            )

        if response.status_code >= 400:
            try:
                payload = response.json()
                message = payload.get("message") or json.dumps(payload)
            except Exception:
                message = response.text or "Unexpected API error."
            raise APIError(message, status_code=response.status_code)

        if not response.text:
            return {}
        try:
            return response.json()
        except Exception:
            return response.text

    def whoami(self) -> dict[str, Any]:
        result = self._request("GET", "/api/whoami/")
        return result if isinstance(result, dict) else {"raw": result}

    def get_projects(self) -> list[dict[str, Any]]:
        result = self._request("GET", "/api/projects")
        return result if isinstance(result, list) else []

    def get_specialists(self, project_guid: str) -> list[dict[str, Any]]:
        result = self._request("GET", f"/api/specialists/{project_guid}")
        return result if isinstance(result, list) else []

    def get_functions(
        self, project_guid: str, specialist_guid: str
    ) -> list[dict[str, Any]]:
        result = self._request(
            "GET", f"/api/specialists/{project_guid}/workflows/{specialist_guid}"
        )
        return result if isinstance(result, list) else []

    def generate_functions_for_specialist(
        self,
        project_guid: str,
        specialist_guid: str,
        workflow_prompts: list[dict[str, Any]],
    ) -> dict[str, Any] | list[dict[str, Any]]:
        payload = {"workflow_prompts": workflow_prompts}
        result = self._request(
            "POST",
            f"/api/specialists/{project_guid}/workflows/{specialist_guid}/generate",
            json_body=payload,
            timeout_seconds=600,
        )
        if isinstance(result, dict):
            return result
        if isinstance(result, list):
            return result
        return {"raw": result}

    def run_orchestrator_sync(
        self, project_guid: str, query: str, conversation_guid: str | None = None
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"query": query}
        if conversation_guid:
            payload["conversation_guid"] = conversation_guid
        return self._request(
            "POST",
            f"/api/orchestrator/{project_guid}/run-sync",
            json_body=payload,
            timeout_seconds=600,
        )

    def run_specialist_sync(
        self,
        project_guid: str,
        specialist_guid: str,
        query: str,
        conversation_guid: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"query": query, "specialist_guid": specialist_guid}
        if conversation_guid:
            payload["conversation_guid"] = conversation_guid
        return self._request(
            "POST",
            f"/api/specialist/{project_guid}/run-sync",
            json_body=payload,
            timeout_seconds=600,
        )

    def execute_function(
        self, project_guid: str, specialist_guid: str, workflow_id: str
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/specialists/{project_guid}/workflows/{specialist_guid}/{workflow_id}",
        )

    def get_execution_status(
        self, project_guid: str, workflow_id: str, execution_guid: str
    ) -> dict[str, Any]:
        result = self._request(
            "GET",
            f"/api/specialists/{project_guid}/workflows/{workflow_id}/{execution_guid}",
        )
        return result if isinstance(result, dict) else {"raw": result}

    def list_connectors(self) -> list[dict[str, Any]]:
        result = self._request("GET", "/api/connectors/list")
        return result if isinstance(result, list) else []

    def list_connector_instances(self, project_guid: str) -> list[dict[str, Any]]:
        result = self._request("GET", f"/api/connectors/{project_guid}")
        return result if isinstance(result, list) else []

    def create_specialist(
        self, project_guid: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._request("POST", f"/api/specialists/{project_guid}", json_body=payload)

    def update_specialist(
        self, project_guid: str, specialist_guid: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._request(
            "PUT",
            f"/api/specialists/{project_guid}/{specialist_guid}",
            json_body=payload,
        )

    def configure_specialist(
        self, project_guid: str, specialist_guid: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/specialists/{project_guid}/{specialist_guid}/config",
            json_body=payload,
        )

    def create_specialist_workflows(
        self,
        project_guid: str,
        specialist_guid: str,
        workflows: list[dict[str, Any]],
    ) -> list[dict[str, Any]] | dict[str, Any]:
        return self._request(
            "POST",
            f"/api/specialists/{project_guid}/workflows/{specialist_guid}",
            json_body={"workflows": workflows},
        )

