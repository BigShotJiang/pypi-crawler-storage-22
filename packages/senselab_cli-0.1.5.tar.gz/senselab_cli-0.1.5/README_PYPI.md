# SenseLab CLI

SenseLab CLI helps you manage AI agents and run specialist workflows from your terminal.

With this CLI you can:
- authenticate with your SenseLab account
- list your projects, specialists, and functions
- chat with orchestrator or specialist agents
- execute specialist functions/workflows
- discover and connect integrations
- apply assistant configuration from YAML

## Install

### Recommended (pipx)

```bash
pipx install senselab-cli
```

### pip

```bash
pip install senselab-cli
```

## Quick start

1) Login:

```bash
sense-cli login --token "<YOUR_JWT_TOKEN>"
```

2) Check configuration and auth:

```bash
sense-cli config list -o json
```

3) List your project/specialists/functions:

```bash
sense-cli projects
sense-cli specialists
sense-cli functions --specialist <specialist_guid>
```

4) Chat with SenseLab:

```bash
sense-cli chat --query "Summarize current production incidents"
```

or chat with a specific specialist:

```bash
sense-cli chat --specialist <specialist_guid> --query "Give me ECS status"
```

## Main commands

- `sense-cli login` - authenticate and save token
- `sense-cli logout` - clear local auth/session data
- `sense-cli config list` - show current CLI config + auth status
- `sense-cli projects` - list available project IDs
- `sense-cli specialists` - list available specialists
- `sense-cli functions` - list workflows/functions for a specialist
- `sense-cli chat` - run sync chat with orchestrator or specialist
- `sense-cli run` - execute a specialist function/workflow
- `sense-cli connectors list` - list available connector types
- `sense-cli connectors add <type>` - open connector auth/config flow
- `sense-cli apply -f assistant.yaml` - declaratively create/update assistant setup
- `sense-cli telemetry on|off` - enable/disable anonymous CLI telemetry
- `sense-cli completion bash|zsh` - generate shell completion script

## Configuration

Environment variables:
- `SENSELAB_API_URL` - override API base URL
- `SENSELAB_TOKEN` - override auth token
- `SENSELAB_CONFIG_PATH` - custom config file path

Default config path:
- `~/.sense-cli/config.json`

## Help

```bash
sense-cli --help
sense-cli <command> --help
```
