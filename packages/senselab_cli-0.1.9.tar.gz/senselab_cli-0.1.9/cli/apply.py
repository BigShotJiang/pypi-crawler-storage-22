from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
from uuid import UUID

import yaml

from cli.api import APIClient, APIError


@dataclass
class ApplyResult:
    specialist_guid: str
    connectors_attached: int
    workflows_created: int
    config_applied: bool


def _is_uuid(value: str) -> bool:
    try:
        UUID(value)
        return True
    except Exception:
        return False


def _extract_credential_guid(item: dict[str, Any]) -> str | None:
    for key in ("tool_cred_guid", "cred_guid", "db_secret", "guid", "id"):
        value = item.get(key)
        if value:
            return str(value)
    return None


def _extract_credential_name(item: dict[str, Any]) -> str | None:
    for key in ("tool_cred_name", "cred_name", "connection_name", "name"):
        value = item.get(key)
        if value:
            return str(value)
    return None


def _resolve_connector_reference(
    connector_ref: str, connector_instances: list[dict[str, Any]]
) -> str:
    if _is_uuid(connector_ref):
        return connector_ref

    for item in connector_instances:
        if _extract_credential_name(item) == connector_ref:
            cred_guid = _extract_credential_guid(item)
            if cred_guid:
                return cred_guid

    raise APIError(
        f"Connector reference '{connector_ref}' not found in project connector instances."
    )


def _build_specialist_payload(spec: dict[str, Any]) -> dict[str, Any]:
    required = ("name", "system_prompt", "prompt_template", "role_guid", "llm_guid")
    missing = [field for field in required if not spec.get(field)]
    if missing:
        raise APIError(f"assistant is missing required fields: {', '.join(missing)}")

    payload: dict[str, Any] = {
        "name": spec["name"],
        "system_prompt": spec["system_prompt"],
        "prompt_template": spec["prompt_template"],
        "role_guid": spec["role_guid"],
        "llm_guid": spec["llm_guid"],
    }
    if spec.get("description"):
        payload["description"] = spec["description"]
    if spec.get("is_default") is not None:
        payload["is_default"] = bool(spec["is_default"])
    return payload


def _build_config_payload(connectors: list[dict[str, Any]]) -> dict[str, Any]:
    config_payload: dict[str, Any] = {}
    generic_items: list[dict[str, Any]] = []
    for item in connectors:
        connector_type = item.get("type")
        cred_guid = item["resolved_cred_guid"]
        config = item.get("config", {})

        if connector_type == "github_repos":
            config_payload["github_repos"] = {
                "tool_cred_guid": cred_guid,
                "repos": config.get("repos", []),
            }
        elif connector_type == "gitlab_repos":
            config_payload["gitlab_repos"] = {
                "tool_cred_guid": cred_guid,
                "repos": config.get("repos", []),
            }
        elif connector_type == "aws_services":
            config_payload["aws_services"] = {
                "tool_cred_guid": cred_guid,
                "region": config.get("region", ""),
                "services": config.get("services", []),
                "context": config.get("context", ""),
            }
        elif connector_type == "gcp_services":
            config_payload["gcp_services"] = {
                "tool_cred_guid": cred_guid,
                "region": config.get("region", ""),
                "services": config.get("services", []),
                "context": config.get("context", ""),
            }
        elif connector_type == "generic":
            generic_items.append(
                {
                    "tool_cred_guid": cred_guid,
                    "plugin": config.get("plugin", ""),
                    "context": config.get("context", ""),
                }
            )
    if generic_items:
        config_payload["generic"] = generic_items
    return config_payload


def _build_workflows_payload(functions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    workflows: list[dict[str, Any]] = []
    for function in functions:
        if not isinstance(function, dict):
            raise APIError("functions entries must be objects.")
        if not function.get("workflow_name") or not function.get("definition"):
            raise APIError(
                "Each function must include workflow_name and definition fields."
            )
        workflows.append(
            {
                "workflow_name": function["workflow_name"],
                "definition": function["definition"],
                "variables": function.get("variables"),
                "schema_version": function.get("schema_version", "1.0.0"),
            }
        )
    return workflows


def load_apply_file(path: str) -> dict[str, Any]:
    apply_path = Path(path).expanduser()
    if not apply_path.exists():
        raise APIError(f"YAML file not found: {apply_path}")

    with apply_path.open("r", encoding="utf-8") as f:
        parsed = yaml.safe_load(f)
    if not isinstance(parsed, dict):
        raise APIError("YAML root must be an object.")
    return parsed


def apply_assistant_config(
    api: APIClient,
    project_guid: str,
    payload: dict[str, Any],
    dry_run: bool = False,
) -> ApplyResult:
    assistant = payload.get("assistant")
    if not isinstance(assistant, dict):
        raise APIError("Missing required 'assistant' section in YAML.")

    connectors = payload.get("connectors", [])
    if connectors is None:
        connectors = []
    if not isinstance(connectors, list):
        raise APIError("'connectors' must be a list.")

    functions = payload.get("functions", [])
    if functions is None:
        functions = []
    if not isinstance(functions, list):
        raise APIError("'functions' must be a list.")

    specialist_payload = _build_specialist_payload(assistant)
    connector_instances = api.list_connector_instances(project_guid)

    resolved_connectors: list[dict[str, Any]] = []
    for connector in connectors:
        if not isinstance(connector, dict):
            raise APIError("Each connector entry must be an object.")
        connector_ref = connector.get("connector")
        if not connector_ref:
            raise APIError("Each connector entry must include 'connector'.")
        resolved_guid = _resolve_connector_reference(str(connector_ref), connector_instances)
        resolved_connectors.append({**connector, "resolved_cred_guid": resolved_guid})

    workflows_payload = _build_workflows_payload(functions)
    config_payload = _build_config_payload(resolved_connectors)
    tool_cred_guids = [item["resolved_cred_guid"] for item in resolved_connectors]

    if dry_run:
        return ApplyResult(
            specialist_guid="dry-run",
            connectors_attached=len(tool_cred_guids),
            workflows_created=len(workflows_payload),
            config_applied=bool(config_payload),
        )

    create_payload = {**specialist_payload}
    if tool_cred_guids:
        create_payload["tool_cred_guids"] = tool_cred_guids
    specialist_result = api.create_specialist(project_guid, create_payload)
    specialist_guid = specialist_result.get("specialist_guid")
    if not specialist_guid:
        raise APIError("Failed to create specialist: missing specialist_guid in response.")

    if config_payload:
        api.configure_specialist(project_guid, specialist_guid, config_payload)

    if workflows_payload:
        api.create_specialist_workflows(project_guid, specialist_guid, workflows_payload)

    return ApplyResult(
        specialist_guid=str(specialist_guid),
        connectors_attached=len(tool_cred_guids),
        workflows_created=len(workflows_payload),
        config_applied=bool(config_payload),
    )

