from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import platform
import re
import sys
import time
import uuid
import webbrowser
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, urlparse

from cli import __version__
from cli.api import APIClient, APIError
from cli.config import CLIConfig, DEFAULT_API_URL, load_config, save_config


_USE_COLOR = False
_SPINNER_FRAMES = ("-", "\\", "|", "/")
_VERBOSITY = 0  # -1 quiet, 0 normal, 1 verbose
_COMPLETION_MARKER_START = "# >>> senselab-cli completion >>>"
_COMPLETION_MARKER_END = "# <<< senselab-cli completion <<<"


def _configure_ui(no_color: bool, verbose: bool, quiet: bool) -> None:
    global _USE_COLOR
    global _VERBOSITY
    _VERBOSITY = 1 if verbose else (-1 if quiet else 0)
    if no_color or os.getenv("NO_COLOR"):
        _USE_COLOR = False
        return
    if os.getenv("FORCE_COLOR"):
        _USE_COLOR = True
        return
    _USE_COLOR = bool(sys.stdout.isatty())


def _style(text: str, *, color: str | None = None, bold: bool = False) -> str:
    if not _USE_COLOR:
        return text
    colors = {
        "red": "31",
        "green": "32",
        "yellow": "33",
        "blue": "34",
        "cyan": "36",
    }
    codes: list[str] = []
    if bold:
        codes.append("1")
    if color in colors:
        codes.append(colors[color])
    if not codes:
        return text
    return f"\033[{';'.join(codes)}m{text}\033[0m"


def _print_status(
    level: str,
    message: str,
    *,
    next_step: str | None = None,
    stream: Any = sys.stdout,
) -> None:
    if _VERBOSITY < 0 and level != "error":
        return
    if _VERBOSITY == 0 and level == "info" and next_step is None:
        # Keep default output concise unless there is guidance attached.
        pass
    palette = {
        "info": ("[INFO]", "cyan"),
        "ok": ("[OK]", "green"),
        "warn": ("[WARN]", "yellow"),
        "error": ("[ERROR]", "red"),
    }
    label, color = palette.get(level, ("[INFO]", "cyan"))
    print(f"{_style(label, color=color, bold=True)} {message}", file=stream)
    if next_step:
        print(
            f"{_style('[NEXT]', color='blue', bold=True)} {next_step}",
            file=stream,
        )


def _print_senselab_banner(stream: Any = sys.stdout) -> None:
    lines = [
        "  ____  _____ _   _ ____  _____ _        _    ____  ",
        " / ___|| ____| \\ | / ___|| ____| |      / \\  | __ ) ",
        " \\___ \\|  _| |  \\| \\___ \\|  _| | |     / _ \\ |  _ \\ ",
        "  ___) | |___| |\\  |___) | |___| |___ / ___ \\| |_) |",
        " |____/|_____|_| \\_|____/|_____|_____/_/   \\_\\____/ ",
    ]
    for line in lines:
        print(_style(line, color="cyan", bold=True), file=stream)
    print(_style("SenseLab CLI", color="blue", bold=True), file=stream)


def _resolve_subcommand(args: argparse.Namespace) -> str | None:
    if getattr(args, "command", None) == "connectors":
        return getattr(args, "connectors_command", None) or "list"
    if getattr(args, "command", None) in {"agent", "agents", "specialists"}:
        return getattr(args, "agent_mode", None) or getattr(args, "agent_ref", None)
    if getattr(args, "command", None) == "config":
        return getattr(args, "config_command", None)
    return None


def _detect_shell(requested: str) -> str:
    if requested in {"bash", "zsh"}:
        return requested
    shell_path = os.getenv("SHELL", "")
    shell = shell_path.split("/")[-1].strip().lower()
    if shell in {"bash", "zsh"}:
        return shell
    return "zsh"


def _value_after_flag(argv: list[str], flag: str) -> str | None:
    for i, token in enumerate(argv):
        if token == flag and i + 1 < len(argv):
            return argv[i + 1]
    return None


def _rewrite_legacy_argv(argv: list[str]) -> list[str]:
    if not argv:
        return argv

    cmd = argv[0]
    if cmd == "specialists":
        rewritten = ["agent", "list"] + argv[1:]
        return rewritten

    if cmd == "chat":
        specialist = _value_after_flag(argv[1:], "--specialist")
        query = _value_after_flag(argv[1:], "--query")
        if specialist and query:
            rewritten = ["agent", specialist, "--chat", query]
            project = _value_after_flag(argv[1:], "--project")
            if project:
                rewritten.extend(["--project", project])
            output = _value_after_flag(argv[1:], "--output") or _value_after_flag(argv[1:], "-o")
            if output:
                rewritten.extend(["--output", output])
            return rewritten

    if cmd == "run":
        specialist = _value_after_flag(argv[1:], "--specialist")
        function = _value_after_flag(argv[1:], "--function")
        if specialist and function:
            rewritten = ["agent", specialist, "--run", function]
            project = _value_after_flag(argv[1:], "--project")
            if project:
                rewritten.extend(["--project", project])
            output = _value_after_flag(argv[1:], "--output") or _value_after_flag(argv[1:], "-o")
            if output:
                rewritten.extend(["--output", output])
            return rewritten

    if cmd == "functions":
        specialist = _value_after_flag(argv[1:], "--specialist")
        if specialist:
            rewritten = ["agent", specialist, "function"]
            project = _value_after_flag(argv[1:], "--project")
            if project:
                rewritten.extend(["--project", project])
            output = _value_after_flag(argv[1:], "--output") or _value_after_flag(argv[1:], "-o")
            if output:
                rewritten.extend(["--output", output])
            return rewritten

    return argv


def _prompt_if_missing(
    value: str | None,
    *,
    prompt_text: str,
    example: str | None = None,
) -> str:
    if value:
        return value
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        guidance = f" Example: {example}" if example else ""
        raise APIError(f"Missing required option.{guidance}")
    suffix = f" (e.g. {example})" if example else ""
    typed = input(f"{prompt_text}{suffix}: ").strip()
    if not typed:
        raise APIError("Missing required option.")
    return typed


def _normalize_error_message_for_hash(message: str) -> str:
    normalized = message.strip().lower()
    normalized = re.sub(
        r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
        "<uuid>",
        normalized,
    )
    normalized = re.sub(r"\b\d+\b", "<num>", normalized)
    return normalized


def _message_hash(message: str | None) -> str | None:
    if not message:
        return None
    normalized = _normalize_error_message_for_hash(message)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _categorize_api_error(error: APIError) -> str:
    status = error.status_code
    message = error.message.lower()
    if status in (401, 403) or "not logged in" in message or "token" in message:
        return "auth"
    if status == 404:
        return "not_found"
    if status == 429:
        return "rate_limit"
    if status in (400, 422):
        return "validation"
    if status and status >= 500:
        return "server"
    if "timed out" in message or "timeout" in message:
        return "timeout"
    if "failed to reach api" in message or "connection" in message:
        return "network"
    return "api"


def _print_output(data: Any, output: str = "table") -> None:
    if output == "json":
        print(json.dumps(data, indent=2, default=str))
        return
    if isinstance(data, (dict, list)):
        print(json.dumps(data, indent=2, default=str))
        return
    print(str(data))


def _print_compact_table(
    rows: list[dict[str, Any]],
    columns: list[tuple[str, str]],
) -> None:
    if not rows:
        _print_status("info", "No results found.")
        return
    keys = [k for k, _ in columns]
    headers = [h for _, h in columns]
    table_rows: list[list[str]] = []
    for row in rows:
        values = []
        for key in keys:
            val = row.get(key)
            if val is None:
                values.append("")
            elif isinstance(val, bool):
                values.append("yes" if val else "no")
            else:
                values.append(str(val))
        table_rows.append(values)
    widths = [
        max(len(headers[i]), max(len(r[i]) for r in table_rows))
        for i in range(len(headers))
    ]
    header_line = "  ".join(
        _style(headers[i].ljust(widths[i]), color="blue", bold=True)
        for i in range(len(headers))
    )
    sep_line = "  ".join("-" * widths[i] for i in range(len(headers)))
    print(header_line)
    print(sep_line)
    for row in table_rows:
        print("  ".join(row[i].ljust(widths[i]) for i in range(len(headers))))


def _render_projects_table(projects: list[dict[str, Any]]) -> None:
    rows = []
    for item in projects:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "project_guid": item.get("project_guid", ""),
                "name": item.get("name", ""),
                "description": item.get("description", ""),
            }
        )
    _print_compact_table(
        rows,
        [
            ("project_guid", "PROJECT [P]"),
            ("name", "NAME"),
            ("description", "DESCRIPTION"),
        ],
    )


def _render_specialists_table(specialists: list[dict[str, Any]]) -> None:
    def specialist_role(item: dict[str, Any]) -> str:
        direct = item.get("role_name")
        if direct:
            return str(direct)

        role = item.get("role")
        if isinstance(role, dict):
            for key in ("name", "role_name", "description"):
                value = role.get(key)
                if value:
                    return str(value)
        elif isinstance(role, str) and role.strip():
            return role.strip()

        for key in ("specialist_role", "role_info"):
            nested = item.get(key)
            if isinstance(nested, dict):
                for nested_key in ("name", "role_name", "description"):
                    value = nested.get(nested_key)
                    if value:
                        return str(value)

        return "-"

    rows = []
    for item in specialists:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "specialist_guid": item.get("specialist_guid") or item.get("id") or "",
                "name": item.get("name", ""),
                "role": specialist_role(item),
                "active": item.get("is_active"),
            }
        )
    _print_compact_table(
        rows,
        [
            ("specialist_guid", "AGENT [A]"),
            ("name", "NAME"),
            ("role", "ROLE"),
            ("active", "ACTIVE"),
        ],
    )


def _render_functions_table(functions: list[dict[str, Any]]) -> None:
    rows = []
    for item in functions:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "function_guid": item.get("workflow_guid") or item.get("id") or "",
                "name": item.get("name") or item.get("workflow_name") or "",
                "description": item.get("description", ""),
            }
        )
    _print_compact_table(
        rows,
        [
            ("function_guid", "FUNCTION [F]"),
            ("name", "NAME"),
            ("description", "DESCRIPTION"),
        ],
    )


def _connector_type(item: dict[str, Any]) -> str:
    connector_url = str(item.get("connector_url", "")).strip("/")
    parts = connector_url.split("/")
    if not parts:
        return str(item.get("name", "")).lower().replace(" ", "_")
    # /api/connectors/<type>/...
    if len(parts) >= 3 and parts[1] == "connectors":
        return parts[2]
    # /api/github/connect/..., /api/jira/connect/...
    if len(parts) >= 2 and parts[1] not in {"connectors"}:
        return parts[1]
    return str(item.get("name", "")).lower().replace(" ", "_")


def _connector_required_fields(item: dict[str, Any]) -> list[str]:
    required: list[str] = []
    form = item.get("form", [])
    for field in form:
        if not isinstance(field, dict):
            continue
        field_type = field.get("type")
        field_name = field.get("name")
        if field_type == "params":
            for nested in field.get("fields", []):
                if not isinstance(nested, dict):
                    continue
                nested_type = nested.get("type")
                if nested_type in {"hidden"}:
                    continue
                if nested.get("required", True):
                    required.append(str(nested.get("name")))
        elif field_type not in {"default"} and field_name:
            if field.get("required", True):
                required.append(str(field_name))
    deduped = []
    seen = set()
    for value in required:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


def _connector_summary_rows(connectors: list[dict[str, Any]]) -> list[dict[str, Any]]:
    summarized = []
    for item in connectors:
        if not isinstance(item, dict):
            continue
        summarized.append(
            {
                "name": item.get("name"),
                "type": _connector_type(item),
            }
        )
    summarized.sort(key=lambda x: str(x.get("name", "")).lower())
    return summarized


def _resolve_connector_reference(
    connectors: list[dict[str, Any]],
    connector_ref: str,
) -> dict[str, Any]:
    ref = connector_ref.strip()
    by_type: list[dict[str, Any]] = []
    by_name: list[dict[str, Any]] = []
    for item in connectors:
        if not isinstance(item, dict):
            continue
        ctype = _connector_type(item)
        name = str(item.get("name", "")).strip()
        if ctype.casefold() == ref.casefold():
            by_type.append(item)
        if name and name.casefold() == ref.casefold():
            by_name.append(item)
    matches = by_type or by_name
    if not matches:
        raise APIError(
            f"Connector '{ref}' was not found.",
            suggestion="Run `sense-cli connectors list` to see available connectors.",
        )
    return matches[0]


def _normalize_chat_answer(answer: str) -> str:
    normalized = answer
    if "\\n" in normalized and "\n" not in normalized:
        normalized = normalized.replace("\\n", "\n")
    return normalized


def _render_answer_with_styles(answer: str) -> None:
    for raw_line in answer.splitlines():
        line = raw_line.rstrip()
        if line.startswith("### "):
            print(_style(f"[SECTION] {line[4:]}", color="cyan", bold=True))
            continue
        if line.startswith("## "):
            print(_style(f"[TOPIC] {line[3:]}", color="blue", bold=True))
            continue
        if line.startswith("# "):
            print(_style(f"[TITLE] {line[2:]}", color="blue", bold=True))
            continue
        if re.match(r"^\d+\.\s", line):
            print(_style(line, color="green", bold=True))
            continue
        if line.lstrip().startswith("- "):
            print(_style(line, color="yellow"))
            continue
        print(line)


def _render_chat_response(
    result: dict[str, Any],
    *,
    output: str,
    source_label: str,
) -> None:
    if output == "json":
        _print_output(result, output)
        return

    answer = _normalize_chat_answer(str(result.get("answer", ""))).strip()
    if answer:
        print(_style(f"=== AGENT: {source_label} ===", color="blue", bold=True))
        _render_answer_with_styles(answer)
    else:
        _print_output(result, output)
        return


def _specialist_guid(item: dict[str, Any]) -> str | None:
    guid = item.get("specialist_guid") or item.get("id")
    return str(guid) if guid else None


def _specialist_name(item: dict[str, Any]) -> str:
    name = item.get("name")
    return str(name).strip() if name else ""


def _resolve_specialist_reference(
    api: APIClient,
    *,
    project_guid: str,
    specialist_ref: str,
) -> tuple[str, str]:
    specialists = api.get_specialists(project_guid)
    ref = specialist_ref.strip()

    by_guid = []
    by_name = []
    for specialist in specialists:
        if not isinstance(specialist, dict):
            continue
        guid = _specialist_guid(specialist)
        if guid and guid == ref:
            by_guid.append(specialist)
            continue

        name = _specialist_name(specialist)
        if not name:
            continue
        if name.casefold() == ref.casefold():
            by_name.append(specialist)

    if by_guid:
        resolved = by_guid[0]
        return _specialist_guid(resolved) or ref, _specialist_name(resolved) or ref

    if len(by_name) == 1:
        resolved = by_name[0]
        return _specialist_guid(resolved) or ref, _specialist_name(resolved) or ref

    if len(by_name) > 1:
        options = ", ".join(
            [
                f"{_specialist_name(item)} ({_specialist_guid(item)})"
                for item in by_name[:5]
                if _specialist_guid(item)
            ]
        )
        raise APIError(
            f"More than one specialist matches '{ref}'.",
            suggestion=f"Use the specialist ID instead. Matches: {options}",
        )

    raise APIError(
        "This agent does not exist in your project.",
        suggestion="Run `sense-cli agents` to list valid agents.",
    )


def _function_guid(item: dict[str, Any]) -> str | None:
    guid = item.get("workflow_guid") or item.get("id")
    return str(guid) if guid else None


def _function_name(item: dict[str, Any]) -> str:
    name = item.get("name") or item.get("workflow_name")
    return str(name).strip() if name else ""


def _resolve_function_reference(
    api: APIClient,
    *,
    project_guid: str,
    specialist_guid: str,
    function_ref: str,
) -> tuple[str, str]:
    functions = api.get_functions(project_guid, specialist_guid)
    ref = function_ref.strip()
    by_guid: list[dict[str, Any]] = []
    by_name: list[dict[str, Any]] = []
    for item in functions:
        if not isinstance(item, dict):
            continue
        guid = _function_guid(item)
        if guid and guid == ref:
            by_guid.append(item)
            continue
        name = _function_name(item)
        if name and name.casefold() == ref.casefold():
            by_name.append(item)

    if by_guid:
        chosen = by_guid[0]
        return _function_guid(chosen) or ref, _function_name(chosen) or ref
    if len(by_name) == 1:
        chosen = by_name[0]
        return _function_guid(chosen) or ref, _function_name(chosen) or ref
    if len(by_name) > 1:
        options = ", ".join(
            [
                f"{_function_name(item)} ({_function_guid(item)})"
                for item in by_name[:5]
                if _function_guid(item)
            ]
        )
        raise APIError(
            f"More than one function matches '{ref}'.",
            suggestion=f"Use the function ID instead. Matches: {options}",
        )
    raise APIError(
        "This function does not exist for the selected agent.",
        suggestion="Run `sense-cli functions --specialist <agent>` to list valid function IDs.",
    )


def _set_default_project_if_single(config: CLIConfig, api: APIClient) -> None:
    try:
        projects = api.get_projects()
    except Exception:
        return
    if len(projects) != 1:
        return
    only_guid = projects[0].get("project_guid")
    if not only_guid:
        return
    if config.default_project_guid != str(only_guid):
        config.default_project_guid = str(only_guid)
        save_config(config)


def _resolve_project_guid(
    explicit_project: str | None, config: CLIConfig, required: bool = True
) -> str | None:
    project_guid = explicit_project or config.default_project_guid
    if required and not project_guid:
        if config.token:
            try:
                api = _build_api(config)
                _set_default_project_if_single(config, api)
                project_guid = config.default_project_guid
            except Exception:
                pass
        if sys.stdin.isatty() and sys.stdout.isatty():
            project_guid = input(
                "Project GUID (e.g. 48c14bb7-6122-4773-9676-4840b95f631b): "
            ).strip()
        if not project_guid:
            raise APIError(
                "No default project configured.",
                suggestion="Run `sense-cli login` or provide --project <guid>.",
            )
    return project_guid


def _build_api(config: CLIConfig) -> APIClient:
    return APIClient(base_url=config.base_url, token=config.token)


def _derive_frontend_url(base_url: str) -> str:
    parsed = urlparse(base_url)
    host = parsed.netloc
    host_no_port = host.split(":", 1)[0].lower()

    # Default production mapping: api.example.com -> app.example.com
    if host_no_port.startswith("api."):
        host = "app." + host_no_port[len("api.") :]
    # SenseLab backend hostnames used in dev/prod deployments.
    elif host_no_port == "backend-api.app.raia.live":
        host = "app.raia.live"
    else:
        match = re.match(r"^([a-z0-9-]+)-backend-api\.app\.raia\.live$", host_no_port)
        if match:
            host = f"{match.group(1)}.app.raia.live"
    scheme = parsed.scheme or "https"
    return f"{scheme}://{host}"


def _build_connect_url(config: CLIConfig, explicit_url: str | None, flow: str) -> str:
    if explicit_url:
        return explicit_url
    base = config.frontend_url or _derive_frontend_url(config.base_url)
    # In current SenseLab deployments, login is served from the dashboard root.
    # Keep signup path explicit where supported.
    suffix = "/cli-signup" if flow == "signup" else ""
    return f"{base.rstrip('/')}{suffix}"


class _CallbackHandler(BaseHTTPRequestHandler):
    token: str | None = None
    state: str | None = None
    error: str | None = None

    def do_GET(self):  # noqa: N802
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        _CallbackHandler.token = params.get("token", [None])[0]
        _CallbackHandler.state = params.get("state", [None])[0]
        _CallbackHandler.error = params.get("error", [None])[0]
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        if _CallbackHandler.error:
            self.wfile.write(_callback_page_html(success=False))
            return
        self.wfile.write(_callback_page_html(success=True))

    def log_message(self, format: str, *args):  # noqa: A003
        return


def _callback_page_html(*, success: bool) -> bytes:
    title = "SenseLab CLI Connected" if success else "SenseLab CLI Connection Failed"
    subtitle = (
        "Authentication completed successfully. You can close this tab and return to the terminal."
        if success
        else "Authentication could not be completed. Return to the terminal and retry login."
    )
    status_label = "Connected" if success else "Failed"
    status_color = "#22d3ee" if success else "#fb7185"
    border_color = "#06b6d4" if success else "#f43f5e"
    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{title}</title>
  <style>
    :root {{
      color-scheme: dark;
      --bg: #020617;
      --panel: #0b1220;
      --text: #e2e8f0;
      --muted: #94a3b8;
      --accent: {status_color};
      --border: {border_color};
    }}
    body {{
      margin: 0;
      min-height: 100vh;
      display: grid;
      place-items: center;
      background:
        radial-gradient(1200px 500px at 10% -10%, rgba(34, 211, 238, 0.14), transparent 60%),
        radial-gradient(900px 400px at 90% 110%, rgba(34, 211, 238, 0.10), transparent 55%),
        var(--bg);
      color: var(--text);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      padding: 24px;
      box-sizing: border-box;
    }}
    .card {{
      width: min(580px, 92vw);
      border-radius: 16px;
      border: 1px solid rgba(148, 163, 184, 0.18);
      border-left: 4px solid var(--border);
      background: linear-gradient(180deg, rgba(11, 18, 32, 0.96), rgba(11, 18, 32, 0.92));
      box-shadow: 0 20px 50px rgba(2, 6, 23, 0.55);
      padding: 26px 24px;
    }}
    .brand {{
      display: inline-block;
      font-size: 12px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--accent);
      font-weight: 700;
      margin-bottom: 8px;
    }}
    h1 {{
      margin: 0 0 10px;
      font-size: 24px;
      line-height: 1.25;
      font-weight: 700;
    }}
    p {{
      margin: 0 0 14px;
      color: var(--muted);
      line-height: 1.5;
      font-size: 15px;
    }}
    .status {{
      margin-top: 8px;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--accent);
      font-weight: 700;
      font-size: 14px;
      border: 1px solid rgba(148, 163, 184, 0.2);
      border-radius: 999px;
      padding: 6px 11px;
    }}
    .dot {{
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: var(--accent);
      box-shadow: 0 0 10px var(--accent);
    }}
  </style>
</head>
<body>
  <main class="card">
    <span class="brand">SenseLab</span>
    <h1>{title}</h1>
    <p>{subtitle}</p>
    <div class="status"><span class="dot"></span>{status_label}</div>
  </main>
</body>
</html>"""
    return html.encode("utf-8")


def _maybe_set_default_project(config: CLIConfig, api: APIClient) -> None:
    _set_default_project_if_single(config, api)


def _run_browser_auth_flow(
    config: CLIConfig,
    *,
    connect_url: str,
    callback_mode: str,
    port: int,
    timeout: int,
) -> int:
    state = str(uuid.uuid4())
    callback_url = f"http://127.0.0.1:{port}/callback"
    if callback_mode == "scheme":
        callback_url = "senselab-cli://callback"

    target = (
        f"{connect_url}?callback={quote(callback_url, safe=':/?=&')}"
        f"&state={quote(state)}&source=cli"
    )
    _print_status("info", f"Opening browser: {target}")
    webbrowser.open(target)

    if callback_mode == "scheme":
        _print_status(
            "info",
            "Custom URL scheme mode selected. Ensure senselab-cli:// is registered "
            "on your OS and complete auth in browser.",
        )
        return 0

    _CallbackHandler.token = None
    _CallbackHandler.state = None
    _CallbackHandler.error = None
    server = HTTPServer(("127.0.0.1", port), _CallbackHandler)
    start = time.time()
    spin_index = 0
    while time.time() - start < timeout:
        elapsed = int(time.time() - start)
        spinner = _SPINNER_FRAMES[spin_index % len(_SPINNER_FRAMES)]
        spin_index += 1
        print(
            f"\r{_style('[WAIT]', color='blue', bold=True)} "
            f"Waiting for browser callback {spinner} ({elapsed}s/{timeout}s)",
            end="",
            file=sys.stderr,
            flush=True,
        )
        server.timeout = 1
        server.handle_request()
        if _CallbackHandler.error:
            print(file=sys.stderr)
            _print_status("error", f"Authentication failed: {_CallbackHandler.error}")
            return 1
        if _CallbackHandler.token:
            if _CallbackHandler.state != state:
                print(file=sys.stderr)
                _print_status("warn", "Ignoring callback with invalid state parameter.")
                _CallbackHandler.token = None
                _CallbackHandler.state = None
                continue
            config.token = _CallbackHandler.token
            api = _build_api(config)
            _maybe_set_default_project(config, api)
            try:
                who = api.whoami()
                config.email = who.get("email") or config.email
            except Exception:
                pass
            save_config(config)
            print(file=sys.stderr)
            _print_senselab_banner(stream=sys.stderr)
            _print_status(
                "ok",
                "Authentication succeeded and token saved.",
                next_step="Run `sense-cli projects -o json` to confirm project access.",
            )
            return 0
    print(file=sys.stderr)
    _print_status(
        "error",
        "Timed out waiting for callback token.",
        next_step="Retry `sense-cli login` and complete browser auth before timeout.",
    )
    return 1


def _handle_login(args: argparse.Namespace, config: CLIConfig) -> int:
    if args.prompt_token:
        if not (sys.stdin.isatty() and sys.stdout.isatty()):
            raise APIError(
                "Hidden token prompt requires an interactive terminal.",
                suggestion="Use `sense-cli login --token <token>` in non-interactive environments.",
            )
        try:
            typed_token = getpass.getpass("SenseLab token (input hidden): ").strip()
        except (EOFError, KeyboardInterrupt) as e:
            raise APIError(
                "Token prompt cancelled.",
                suggestion="Retry with `sense-cli login --prompt-token`.",
            ) from e
        if not typed_token:
            raise APIError(
                "No token entered.",
                suggestion="Run `sense-cli login --prompt-token` and paste a valid token.",
            )
        args.token = typed_token

    if args.token:
        previous_token = config.token
        candidate_token = args.token.strip()
        config.token = candidate_token
        api = _build_api(config)
        try:
            api.get_projects()
        except APIError as e:
            config.token = previous_token
            save_config(config)
            raise APIError(
                "Provided token is invalid.",
                suggestion="Get a valid token and run `sense-cli login --token <token>` again.",
            ) from e

        _set_default_project_if_single(config, api)
        try:
            who = api.whoami()
            config.email = who.get("email") or config.email
        except APIError:
            pass
        save_config(config)
        _print_senselab_banner()
        _print_status(
            "ok",
            "Token saved.",
            next_step="Run `sense-cli projects -o json` to validate access.",
        )
        return 0

    connect_url = _build_connect_url(config, args.connect_url, flow="login")
    return _run_browser_auth_flow(
        config,
        connect_url=connect_url,
        callback_mode=args.callback_mode,
        port=args.port,
        timeout=args.timeout,
    )


def _handle_config_list(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    who = None
    auth_status = "Not logged in"
    if config.token:
        try:
            auth_status = "Logged in"
            try:
                api.get_projects()
                _set_default_project_if_single(config, api)
            except APIError:
                auth_status = "Token invalid"
            try:
                who = api.whoami()
            except APIError:
                if auth_status == "Logged in":
                    auth_status = "Logged in (whoami unavailable)"
        except APIError:
            auth_status = "Token invalid"

    payload = {
        "api_base_url": config.base_url,
        "default_project_guid": config.default_project_guid,
        "email": config.email,
        "auth_status": auth_status,
        "whoami": who,
    }
    _print_output(payload, args.output)
    return 0


def _handle_projects(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    projects = api.get_projects()
    _set_default_project_if_single(config, api)
    if args.output == "json":
        _print_output(projects, args.output)
    else:
        _render_projects_table(projects)
    return 0


def _handle_specialists(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialists = api.get_specialists(project_guid)
    if args.output == "json":
        _print_output(specialists, args.output)
    else:
        _render_specialists_table(specialists)
    return 0


def _handle_agent(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    ref = (args.agent_ref or "").strip()

    if not ref or ref.casefold() == "list":
        specialists = api.get_specialists(project_guid)
        if args.output == "json":
            _print_output(specialists, args.output)
        else:
            _render_specialists_table(specialists)
        return 0

    specialist_guid, specialist_name = _resolve_specialist_reference(
        api,
        project_guid=project_guid,
        specialist_ref=ref,
    )

    if getattr(args, "chat", None) and getattr(args, "run", None):
        raise APIError("Use only one action at a time: --chat or --run.")

    if getattr(args, "chat", None):
        query = str(args.chat).strip()
        if not query:
            raise APIError("Chat prompt cannot be empty.")
        _print_status(
            "info",
            f"{specialist_name} is getting your response...",
            stream=sys.stderr,
        )
        result = api.run_specialist_sync(project_guid, specialist_guid, query)
        _render_chat_response(result, output=args.output, source_label=specialist_name)
        return 0

    if getattr(args, "run", None):
        function_ref = str(args.run).strip()
        function_guid, function_name = _resolve_function_reference(
            api,
            project_guid=project_guid,
            specialist_guid=specialist_guid,
            function_ref=function_ref,
        )
        _print_status(
            "info",
            f"Running {function_name} on {specialist_name}...",
            stream=sys.stderr,
        )
        started = api.execute_function(project_guid, specialist_guid, function_guid)
        execution_guid = started.get("execution_guid")
        if not execution_guid:
            _print_output(started, args.output)
            return 1
        _print_output(started, args.output)
        return 0

    if getattr(args, "agent_mode", None) == "function" and not getattr(args, "list", False):
        _print_status("info", f"Listing functions for {specialist_name}...")

    functions = api.get_functions(project_guid, specialist_guid)
    if args.output == "json":
        _print_output(functions, args.output)
    else:
        print(_style(f"=== AGENT: {specialist_name} ===", color="blue", bold=True))
        _render_functions_table(functions)
    return 0


def _handle_functions(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialist_guid = _prompt_if_missing(
        args.specialist,
        prompt_text="Specialist GUID",
        example="f2a92d52-9f42-4d8f-b0af-263cbcb4e2d1",
    )
    specialist_guid, _ = _resolve_specialist_reference(
        api,
        project_guid=project_guid,
        specialist_ref=specialist_guid,
    )
    functions = api.get_functions(project_guid, specialist_guid)
    if args.output == "json":
        _print_output(functions, args.output)
    else:
        _render_functions_table(functions)
    return 0


def _handle_chat(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialist_guid: str | None = None
    specialist_name: str | None = None
    if args.specialist:
        specialist_guid, specialist_name = _resolve_specialist_reference(
            api,
            project_guid=project_guid,
            specialist_ref=args.specialist,
        )

    if args.query:
        if specialist_guid:
            _print_status(
                "info",
                f"{specialist_name} is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_specialist_sync(project_guid, specialist_guid, args.query)
            _render_chat_response(
                result,
                output=args.output,
                source_label=specialist_name or "Specialist",
            )
        else:
            _print_status(
                "info",
                "SenseLab is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_orchestrator_sync(project_guid, args.query)
            _render_chat_response(
                result,
                output=args.output,
                source_label="SenseLab Orchestrator",
            )
        return 0

    conversation_guid: str | None = None
    _print_status("info", "Interactive chat mode. Empty line or Ctrl+C to exit.")
    while True:
        query = input("> ").strip()
        if not query:
            break
        if specialist_guid:
            _print_status(
                "info",
                f"{specialist_name} is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_specialist_sync(
                project_guid,
                specialist_guid,
                query,
                conversation_guid=conversation_guid,
            )
        else:
            _print_status(
                "info",
                "SenseLab is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_orchestrator_sync(
                project_guid,
                query,
                conversation_guid=conversation_guid,
            )
        conversation_guid = result.get("conversation_guid", conversation_guid)
        if args.output == "json":
            _print_output(result, args.output)
        else:
            _render_chat_response(
                result,
                output=args.output,
                source_label=specialist_name if specialist_guid else "SenseLab Orchestrator",
            )
    return 0


def _parse_status(payload: dict[str, Any]) -> str:
    for key in ("workflow_status", "status", "state"):
        if payload.get(key):
            return str(payload[key])
    return "UNKNOWN"


def _handle_run(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialist_guid = _prompt_if_missing(
        args.specialist,
        prompt_text="Specialist GUID",
        example="f2a92d52-9f42-4d8f-b0af-263cbcb4e2d1",
    )
    function_guid = _prompt_if_missing(
        args.function,
        prompt_text="Function/workflow GUID",
        example="4e4d2d87-83d7-4b62-a3e3-f3ce3720b2f3",
    )
    specialist_guid, _ = _resolve_specialist_reference(
        api,
        project_guid=project_guid,
        specialist_ref=specialist_guid,
    )

    started = api.execute_function(project_guid, specialist_guid, function_guid)
    execution_guid = started.get("execution_guid")
    if not execution_guid:
        _print_output(started, args.output)
        return 1

    if not args.wait:
        _print_output(started, args.output)
        return 0

    deadline = time.time() + args.timeout
    last_payload: dict[str, Any] = {}
    spin_index = 0
    while time.time() < deadline:
        elapsed = int(args.timeout - max(0, deadline - time.time()))
        spinner = _SPINNER_FRAMES[spin_index % len(_SPINNER_FRAMES)]
        spin_index += 1
        print(
            f"\r{_style('[WAIT]', color='blue', bold=True)} "
            f"Waiting workflow completion {spinner} ({elapsed}s/{args.timeout}s)",
            end="",
            file=sys.stderr,
            flush=True,
        )
        status_payload = api.get_execution_status(project_guid, function_guid, execution_guid)
        last_payload = status_payload
        status = _parse_status(status_payload)
        if status in {"COMPLETED", "FAILED", "TERMINATED"}:
            print(file=sys.stderr)
            _print_output(
                {
                    "execution_guid": execution_guid,
                    "status": status,
                    "result": status_payload,
                },
                args.output,
            )
            return 0 if status == "COMPLETED" else 1
        time.sleep(args.poll_interval)

    _print_output(
        {
            "execution_guid": execution_guid,
            "status": "TIMEOUT",
            "last_result": last_payload,
        },
        args.output,
    )
    return 1


def _handle_connectors_list(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    connectors = api.list_connectors()
    if getattr(args, "raw", False):
        _print_output(connectors, args.output)
        return 0
    rows = _connector_summary_rows(connectors)
    if args.output == "json":
        _print_output(rows, args.output)
    else:
        _print_compact_table(
            rows,
            [
                ("name", "CONNECTOR"),
                ("type", "TYPE"),
            ],
        )
    return 0


def _handle_connectors_describe(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    connectors = api.list_connectors()
    connector_ref = _prompt_if_missing(
        args.connector_ref,
        prompt_text="Connector name or type",
        example="github",
    )
    item = _resolve_connector_reference(connectors, connector_ref)

    payload = {
        "name": item.get("name"),
        "type": _connector_type(item),
        "description": item.get("description") or "No description provided.",
        "auth_mode": "oauth" if item.get("oauth") else "manual",
        "required_fields": _connector_required_fields(item),
        "add_command": f"sense-cli connectors add {_connector_type(item)}",
    }

    if args.output == "json":
        _print_output(payload, args.output)
        return 0

    print(_style(f"=== CONNECTOR: {payload['name']} ===", color="blue", bold=True))
    print(_style(f"Type: {payload['type']}", color="cyan"))
    print(_style(f"Auth mode: {payload['auth_mode']}", color="cyan"))
    print()
    print(_style("Description", color="blue", bold=True))
    print(payload["description"])
    print()
    print(_style("Required fields", color="blue", bold=True))
    if payload["required_fields"]:
        for field in payload["required_fields"]:
            print(_style(f"- {field}", color="yellow"))
    else:
        print("No required fields.")
    print()
    print(_style("Connect command", color="blue", bold=True))
    print(payload["add_command"])
    return 0


def _handle_connectors_add(args: argparse.Namespace, config: CLIConfig) -> int:
    base = args.frontend_url or config.frontend_url or _derive_frontend_url(config.base_url)
    url = f"{base.rstrip('/')}/connectors/{args.connector_type}"
    webbrowser.open(url)
    _print_status(
        "ok",
        f"Opened browser for connector OAuth: {url}",
        next_step="Complete connector auth in browser, then run `sense-cli connectors list`.",
    )
    return 0


def _handle_signup(args: argparse.Namespace, config: CLIConfig) -> int:
    connect_url = _build_connect_url(config, args.frontend_url, flow="signup")
    return _run_browser_auth_flow(
        config,
        connect_url=connect_url,
        callback_mode=args.callback_mode,
        port=args.port,
        timeout=args.timeout,
    )


def _handle_apply(args: argparse.Namespace, config: CLIConfig) -> int:
    try:
        from cli.apply import apply_assistant_config, load_apply_file
    except ImportError as e:
        raise APIError(
            "Missing dependency for apply command. Install project dependencies (PyYAML)."
        ) from e
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    file_path = _prompt_if_missing(
        args.file,
        prompt_text="Path to YAML file",
        example="assistant.yaml",
    )
    yaml_payload = load_apply_file(file_path)
    result = apply_assistant_config(
        api=api,
        project_guid=project_guid,
        payload=yaml_payload,
        dry_run=args.dry_run,
    )
    _print_output(asdict(result), args.output)
    return 0


def _handle_logout(config: CLIConfig) -> int:
    config.token = None
    config.email = None
    config.default_project_guid = None
    save_config(config)
    _print_status("ok", "Logged out.")
    return 0


def _handle_telemetry_toggle(args: argparse.Namespace, config: CLIConfig) -> int:
    config.telemetry_disabled = args.state == "off"
    save_config(config)
    _print_status(
        "ok",
        f"Telemetry {'disabled' if config.telemetry_disabled else 'enabled'}.",
    )
    return 0


def _render_completion_script(shell: str) -> str:
    commands = [
        "login",
        "logout",
        "signup",
        "projects",
        "agent",
        "connectors",
        "config",
        "whoami",
        "apply",
        "version",
        "completion",
        "telemetry",
    ]
    if shell == "bash":
        command_list = " ".join(commands)
        return (
            "_sense_cli_complete() {\n"
            "  local cur prev\n"
            "  local cmd\n"
            "  COMPREPLY=()\n"
            "  cur=\"${COMP_WORDS[COMP_CWORD]}\"\n"
            "  prev=\"${COMP_WORDS[COMP_CWORD-1]}\"\n"
            "  cmd=\"${COMP_WORDS[1]}\"\n"
            f"  local cmds=\"{command_list}\"\n"
            "  if [[ ${COMP_CWORD} -eq 1 ]]; then\n"
            "    COMPREPLY=( $(compgen -W \"${cmds}\" -- ${cur}) )\n"
            "    return 0\n"
            "  fi\n"
            "  case \"${prev}\" in\n"
            "    --output|-o) COMPREPLY=( $(compgen -W \"json table\" -- ${cur}) ); return 0 ;;\n"
            "    --callback-mode) COMPREPLY=( $(compgen -W \"localhost scheme\" -- ${cur}) ); return 0 ;;\n"
            "    connectors) COMPREPLY=( $(compgen -W \"list show describe add\" -- ${cur}) ); return 0 ;;\n"
            "    config) COMPREPLY=( $(compgen -W \"list\" -- ${cur}) ); return 0 ;;\n"
            "    telemetry) COMPREPLY=( $(compgen -W \"on off\" -- ${cur}) ); return 0 ;;\n"
            "    completion) COMPREPLY=( $(compgen -W \"bash zsh\" -- ${cur}) ); return 0 ;;\n"
            "  esac\n"
            "  case \"${cmd}\" in\n"
            "    login)\n"
            "      COMPREPLY=( $(compgen -W \"--token --prompt-token --connect-url --port --timeout --callback-mode\" -- ${cur}) ) ;;\n"
            "    signup)\n"
            "      COMPREPLY=( $(compgen -W \"--frontend-url --port --timeout --callback-mode\" -- ${cur}) ) ;;\n"
            "    projects)\n"
            "      COMPREPLY=( $(compgen -W \"--output -o\" -- ${cur}) ) ;;\n"
            "    agent)\n"
            "      COMPREPLY=( $(compgen -W \"list function --project --chat --run --list --output -o\" -- ${cur}) ) ;;\n"
            "    connectors)\n"
            "      COMPREPLY=( $(compgen -W \"list show describe add\" -- ${cur}) ) ;;\n"
            "    apply)\n"
            "      COMPREPLY=( $(compgen -W \"--file -f --project --dry-run --output -o\" -- ${cur}) ) ;;\n"
            "    config)\n"
            "      COMPREPLY=( $(compgen -W \"list\" -- ${cur}) ) ;;\n"
            "    completion)\n"
            "      COMPREPLY=( $(compgen -W \"bash zsh\" -- ${cur}) ) ;;\n"
            "    telemetry)\n"
            "      COMPREPLY=( $(compgen -W \"on off\" -- ${cur}) ) ;;\n"
            "  esac\n"
            "}\n"
            "complete -F _sense_cli_complete sense-cli\n"
        )
    # zsh
    return (
        "#compdef sense-cli\n"
        "_sense_cli() {\n"
        "  local context state line\n"
        "  _arguments -C \\\n"
        "    '1:command:(login logout signup projects agent connectors config whoami apply version completion telemetry)' \\\n"
        "    '*::arg:->args'\n"
        "  case $state in\n"
        "    args)\n"
        "      case $words[2] in\n"
        "        login)\n"
        "          _arguments '--token[CI/CD token]' '--prompt-token[Prompt for token with hidden input]' '--connect-url[Frontend connect URL]' '--port[Local callback port]' '--timeout[Callback timeout]' '--callback-mode[Callback mode]:mode:(localhost scheme)' ;;\n"
        "        signup)\n"
        "          _arguments '--frontend-url[Frontend base URL]' '--port[Local callback port]' '--timeout[Callback timeout]' '--callback-mode[Callback mode]:mode:(localhost scheme)' ;;\n"
        "        projects)\n"
        "          _arguments '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        agent)\n"
        "          _arguments '1:agent:(list)' '2:mode:(function)' '--project[Project GUID]' '--chat[Ask agent something]' '--run[Run function/workflow]' '--list[List functions for selected agent]' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        connectors)\n"
        "          _arguments '1:subcommand:(list show describe add)' '--frontend-url[Frontend base URL]' ;;\n"
        "        config)\n"
        "          _arguments '1:subcommand:(list)' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        whoami)\n"
        "          _arguments '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        apply)\n"
        "          _arguments '--file[YAML path]' '-f[YAML path]' '--project[Project GUID]' '--dry-run[Validate only]' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        completion)\n"
        "          _arguments '1:shell:(bash zsh)' ;;\n"
        "        telemetry)\n"
        "          _arguments '1:state:(on off)' ;;\n"
        "      esac\n"
        "      ;;\n"
        "  esac\n"
        "}\n"
        "compdef _sense_cli sense-cli\n"
    )


def _install_completion_script(shell: str) -> int:
    script = _render_completion_script(shell)
    rc_path = Path.home() / (".zshrc" if shell == "zsh" else ".bashrc")
    block = f"{_COMPLETION_MARKER_START}\n{script.rstrip()}\n{_COMPLETION_MARKER_END}\n"

    existing = rc_path.read_text(encoding="utf-8") if rc_path.exists() else ""
    pattern = re.compile(
        rf"{re.escape(_COMPLETION_MARKER_START)}.*?{re.escape(_COMPLETION_MARKER_END)}\n?",
        flags=re.DOTALL,
    )
    if pattern.search(existing):
        updated = pattern.sub(block, existing)
    else:
        updated = existing
        if updated and not updated.endswith("\n"):
            updated += "\n"
        updated += "\n" + block

    rc_path.write_text(updated, encoding="utf-8")
    _print_status(
        "ok",
        f"Installed completion for {shell} in {rc_path}.",
        next_step=f"Run `source {rc_path}` or open a new terminal.",
    )
    return 0


def _is_completion_installed(shell: str) -> bool:
    rc_path = Path.home() / (".zshrc" if shell == "zsh" else ".bashrc")
    if not rc_path.exists():
        return False
    content = rc_path.read_text(encoding="utf-8")
    return (
        _COMPLETION_MARKER_START in content and _COMPLETION_MARKER_END in content
    )


def _maybe_prompt_completion_install(config: CLIConfig, command: str | None) -> None:
    if config.completion_prompted:
        return
    if command in {"completion", "telemetry"}:
        return
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return

    shell = _detect_shell("auto")
    if shell not in {"bash", "zsh"}:
        config.completion_prompted = True
        save_config(config)
        return

    if _is_completion_installed(shell):
        config.completion_prompted = True
        save_config(config)
        return

    prompt = f"Install shell completion for {shell} now? [Y/n]: "
    try:
        answer = input(prompt).strip().lower()
    except EOFError:
        return

    if answer in {"", "y", "yes"}:
        _install_completion_script(shell)
    else:
        _print_status(
            "info",
            "Skipping completion install.",
            next_step="Run `sense-cli completion auto --install` anytime.",
        )

    config.completion_prompted = True
    save_config(config)


def _send_telemetry(
    config: CLIConfig,
    *,
    command: str,
    success: bool,
    error_code: str | None,
    http_status: int | None,
    error_category: str | None,
    backend_message_hash: str | None,
    subcommand: str | None,
    flags: dict[str, Any],
) -> None:
    if config.telemetry_disabled:
        return
    try:
        import requests
    except ImportError:
        return
    payload = {
        "command": command,
        "subcommand": subcommand,
        "success": success,
        "error_code": error_code,
        "http_status": http_status,
        "error_category": error_category,
        "backend_message_hash": backend_message_hash,
        "flags": flags,
        "cli_version": __version__,
        "platform": platform.platform(),
        "python_version": platform.python_version(),
    }
    endpoint = f"{config.base_url.rstrip('/')}/api/cli/telemetry"
    try:
        requests.post(endpoint, json=payload, timeout=2)
    except Exception:
        return


def _build_parser() -> argparse.ArgumentParser:
    examples = (
        "Examples:\n"
        "  sense-cli login --token <JWT>\n"
        "  sense-cli projects --output json\n"
        "  sense-cli agent list --project <project_guid>\n"
        "  sense-cli agent <agent_name_or_id> function --list\n"
        "  sense-cli agent <agent_name_or_id> --chat \"hello\"\n"
        "  sense-cli agent <agent_name_or_id> --run <function_name_or_id>\n"
        "  sense-cli apply -f assistant.yaml --project <project_guid>\n"
        "  sense-cli completion auto --install\n"
    )
    parser = argparse.ArgumentParser(
        prog="sense-cli",
        description="SenseLab CLI for managing AI agents.",
        epilog=examples,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI colors in CLI output.",
    )
    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument(
        "--verbose",
        action="store_true",
        help="Show additional progress and guidance output.",
    )
    verbosity.add_argument(
        "--quiet",
        action="store_true",
        help="Show only command results and errors.",
    )
    sub = parser.add_subparsers(dest="command")

    login = sub.add_parser("login", help="Authenticate and store token.")
    login_auth = login.add_mutually_exclusive_group()
    login_auth.add_argument("--token", help="CI/CD token to store as CLI token.")
    login_auth.add_argument(
        "--prompt-token",
        action="store_true",
        help="Prompt for token with hidden input (safer for local terminal use).",
    )
    login.add_argument(
        "--connect-url",
        help="Frontend Connect CLI URL; opens browser and waits callback.",
    )
    login.add_argument("--port", type=int, default=8765)
    login.add_argument("--timeout", type=int, default=180)
    login.add_argument(
        "--callback-mode",
        choices=("localhost", "scheme"),
        default="localhost",
        help="Callback target mode for browser login.",
    )

    sub.add_parser("logout", help="Clear stored credentials.")

    signup = sub.add_parser("signup", help="Open browser to sign-up flow.")
    signup.add_argument("--frontend-url", help="Frontend base URL.")
    signup.add_argument("--port", type=int, default=8765)
    signup.add_argument("--timeout", type=int, default=180)
    signup.add_argument(
        "--callback-mode",
        choices=("localhost", "scheme"),
        default="localhost",
        help="Callback target mode for browser signup.",
    )

    projects = sub.add_parser("projects", help="List projects.")
    projects.add_argument("-o", "--output", choices=("json", "table"), default="table")

    agent = sub.add_parser("agent", aliases=["agents"], help="Agent operations.")
    agent.add_argument("agent_ref", nargs="?", help="Agent name/id or 'list'.")
    agent.add_argument(
        "agent_mode",
        nargs="?",
        choices=("function",),
        help="Optional agent sub-mode.",
    )
    agent.add_argument("--project")
    agent.add_argument("--chat", help="Ask the selected agent a question.")
    agent.add_argument("--run", help="Run a function/workflow on the selected agent.")
    agent.add_argument(
        "--list",
        action="store_true",
        help="List functions for the selected agent (useful with `function`).",
    )
    agent.add_argument("-o", "--output", choices=("json", "table"), default="table")

    connectors = sub.add_parser("connectors", help="Connector operations.")
    connectors_sub = connectors.add_subparsers(dest="connectors_command")
    connectors_list = connectors_sub.add_parser("list", help="List available connectors.")
    connectors_list.add_argument(
        "-o", "--output", choices=("json", "table"), default="table"
    )
    connectors_list.add_argument(
        "--raw",
        action="store_true",
        help="Return full backend connector payload.",
    )
    connectors_sub.add_parser("show", help="Alias for list.")
    connectors_describe = connectors_sub.add_parser(
        "describe",
        help="Describe connector requirements.",
    )
    connectors_describe.add_argument("connector_ref", nargs="?")
    connectors_describe.add_argument(
        "-o",
        "--output",
        choices=("json", "table"),
        default="table",
    )
    connectors_add = connectors_sub.add_parser("add", help="Open OAuth flow for connector.")
    connectors_add.add_argument("connector_type")
    connectors_add.add_argument(
        "--frontend-url",
        help="Optional frontend base URL override (defaults from configured API URL).",
    )

    config_cmd = sub.add_parser("config", help="CLI config operations.")
    config_sub = config_cmd.add_subparsers(dest="config_command")
    config_list = config_sub.add_parser("list", help="Show current configuration and auth.")
    config_list.add_argument("-o", "--output", choices=("json", "table"), default="table")

    whoami = sub.add_parser("whoami", help="Show auth/user context.")
    whoami.add_argument("-o", "--output", choices=("json", "table"), default="table")

    apply_cmd = sub.add_parser("apply", help="Apply assistant config from YAML.")
    apply_cmd.add_argument("-f", "--file")
    apply_cmd.add_argument("--project")
    apply_cmd.add_argument("--dry-run", action="store_true")
    apply_cmd.add_argument("-o", "--output", choices=("json", "table"), default="table")

    sub.add_parser("version", help="Show CLI version.")

    completion = sub.add_parser("completion", help="Print shell completion instructions.")
    completion.add_argument("shell", nargs="?", choices=("bash", "zsh", "auto"), default="auto")
    completion.add_argument(
        "--install",
        action="store_true",
        help="Install completion into your shell rc file automatically.",
    )

    telemetry = sub.add_parser("telemetry", help="Enable or disable CLI telemetry.")
    telemetry.add_argument("state", choices=("on", "off"))

    return parser


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    argv = _rewrite_legacy_argv(argv)
    parser = _build_parser()
    args = parser.parse_args(argv)
    _configure_ui(
        getattr(args, "no_color", False),
        getattr(args, "verbose", False),
        getattr(args, "quiet", False),
    )
    config = load_config()
    if not config.base_url:
        config.base_url = DEFAULT_API_URL

    command = args.command or "help"
    _maybe_prompt_completion_install(config, command)
    success = False
    error_code: str | None = None
    http_status: int | None = None
    error_category: str | None = None
    backend_message_hash: str | None = None
    subcommand = _resolve_subcommand(args)
    try:
        if args.command == "login":
            rc = _handle_login(args, config)
            success = rc == 0
            return rc
        if args.command == "logout":
            rc = _handle_logout(config)
            success = rc == 0
            return rc
        if args.command == "signup":
            rc = _handle_signup(args, config)
            success = rc == 0
            return rc
        if args.command == "projects":
            rc = _handle_projects(args, config)
            success = rc == 0
            return rc
        if args.command in {"agent", "agents"}:
            rc = _handle_agent(args, config)
            success = rc == 0
            return rc
        if args.command == "connectors":
            if args.connectors_command in (None, "list", "show"):
                if not getattr(args, "output", None):
                    args.output = "table"
                rc = _handle_connectors_list(args, config)
                success = rc == 0
                return rc
            if args.connectors_command == "describe":
                rc = _handle_connectors_describe(args, config)
                success = rc == 0
                return rc
            if args.connectors_command == "add":
                rc = _handle_connectors_add(args, config)
                success = rc == 0
                return rc
        if args.command == "config" and args.config_command == "list":
            rc = _handle_config_list(args, config)
            success = rc == 0
            return rc
        if args.command == "whoami":
            rc = _handle_config_list(args, config)
            success = rc == 0
            return rc
        if args.command == "apply":
            rc = _handle_apply(args, config)
            success = rc == 0
            return rc
        if args.command == "version":
            print(__version__)
            success = True
            return 0
        if args.command == "completion":
            detected_shell = _detect_shell(args.shell)
            if getattr(args, "install", False):
                rc = _install_completion_script(detected_shell)
                success = rc == 0
                return rc
            print(_render_completion_script(detected_shell))
            success = True
            return 0
        if args.command == "telemetry":
            rc = _handle_telemetry_toggle(args, config)
            success = rc == 0
            return rc
        parser.print_help()
        return 1
    except APIError as e:
        _print_status(
            "error",
            str(e),
            next_step="Run `sense-cli --help` to check command usage and flags.",
            stream=sys.stderr,
        )
        error_code = "api_error"
        http_status = e.status_code
        error_category = _categorize_api_error(e)
        backend_message_hash = _message_hash(e.message)
        return 1
    except KeyboardInterrupt:
        error_code = "keyboard_interrupt"
        error_category = "interrupt"
        return 130
    except Exception as e:
        _print_status(
            "error",
            f"Unexpected error: {e}",
            next_step="Retry with `-o json` and check backend logs if issue persists.",
            stream=sys.stderr,
        )
        error_code = "unexpected_error"
        error_category = "unexpected"
        backend_message_hash = _message_hash(str(e))
        return 1
    finally:
        if command not in {"telemetry", "help"}:
            flags = {
                k: v
                for k, v in vars(args).items()
                if k != "command" and v not in (None, False, "")
            }
            _send_telemetry(
                config,
                command=command,
                success=success,
                error_code=error_code,
                http_status=http_status,
                error_category=error_category,
                backend_message_hash=backend_message_hash,
                subcommand=subcommand,
                flags=flags,
            )


if __name__ == "__main__":
    raise SystemExit(main())

