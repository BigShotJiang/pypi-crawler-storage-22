from importlib.metadata import version

__version__ = version("sensipy")


__all__ = ["__version__"]
