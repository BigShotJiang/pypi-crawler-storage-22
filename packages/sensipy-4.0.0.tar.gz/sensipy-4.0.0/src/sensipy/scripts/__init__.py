"""Sensipy CLI scripts and utilities."""

