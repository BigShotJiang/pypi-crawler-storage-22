# Changelog

## 0.3.0 (2026-01-28)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/sentdm/sent-dm-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** manual updates ([e02db1d](https://github.com/sentdm/sent-dm-python/commit/e02db1d8c3d8a1626bb6b34330e6c5a182b2bd4a))

## 0.2.0 (2026-01-27)

Full Changelog: [v0.1.1...v0.2.0](https://github.com/sentdm/sent-dm-python/compare/v0.1.1...v0.2.0)

### Features

* **api:** manual updates ([b88b8e4](https://github.com/sentdm/sent-dm-python/commit/b88b8e4f6d42e4699c8a4f3e7f4065e742353820))

## 0.1.1 (2026-01-27)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/sentdm/sent-dm-python/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([a712995](https://github.com/sentdm/sent-dm-python/commit/a712995ce16452fd8e30e519a766796c486370fa))

## 0.1.0 (2026-01-27)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/sentdm/sent-dm-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([5c655ad](https://github.com/sentdm/sent-dm-python/commit/5c655ad2d463283deb5857982bd52dc302f390aa))


### Chores

* update SDK settings ([ece63ca](https://github.com/sentdm/sent-dm-python/commit/ece63ca4e3e9228669d69b891b275da09e6e88d4))
