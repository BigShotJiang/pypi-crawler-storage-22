"""
Sentience SDK constants.
"""

# Sentience API endpoint
SENTIENCE_API_URL = "https://api.sentienceapi.com"
