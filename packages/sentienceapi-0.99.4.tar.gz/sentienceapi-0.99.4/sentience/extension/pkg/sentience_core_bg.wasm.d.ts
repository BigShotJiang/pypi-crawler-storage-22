/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const analyze_page: (a: number) => number;
export const analyze_page_with_options: (a: number, b: number) => number;
export const decide_and_act: (a: number) => void;
export const prune_for_api: (a: number) => number;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export3: (a: number) => void;
