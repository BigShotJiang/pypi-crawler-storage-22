"""
Integrations package (internal).

This package is intended for framework integrations (e.g., PydanticAI, LangChain/LangGraph).
Public APIs should be introduced deliberately once the integration surface is stable.
"""
