# FILE: sentinel/core/paths.py
import os
import sys
from pathlib import Path

# ==========================================
# 1. USER DATA STORAGE (Mutable)
# Stores DBs, Configs, Logs, and Auth Tokens
# Location: ~/.sentinel (Cross-platform)
# ==========================================

USER_DATA_DIR = Path.home() / ".sentinel"
USER_DATA_DIR.mkdir(parents=True, exist_ok=True)

# Subdirectories
LOGS_DIR = USER_DATA_DIR / "logs"
LOGS_DIR.mkdir(exist_ok=True)

DRAFTS_DIR = USER_DATA_DIR / "drafts"
DRAFTS_DIR.mkdir(exist_ok=True)

# Critical System Files
CONFIG_PATH = USER_DATA_DIR / "config.json"
DB_PATH = USER_DATA_DIR / "brain.db"
VECTOR_PATH = USER_DATA_DIR / "brain_vectors"  # ChromaDB folder
AUDIT_LOG_PATH = USER_DATA_DIR / "audit_log.jsonl"
MEMORY_FILE = USER_DATA_DIR / "memory.json"

# Search Indexes
FILE_INDEX_DB = USER_DATA_DIR / "file_index.db"
SMART_INDEX_DB = USER_DATA_DIR / "smart_files.db"

# Authentication
CREDENTIALS_PATH = USER_DATA_DIR / "credentials.json"
TOKEN_PATH = USER_DATA_DIR / "token.json"


# ==========================================
# 2. PACKAGE ASSETS (Immutable)
# Locates scripts/tools bundled inside the pip package
# Location: .../site-packages/sentinel/scripts/
# ==========================================

def get_script_path(filename: str) -> str:
    """
    Returns the absolute path to a script bundled inside the pip package.
    Expects scripts to be in: src/sentinel/scripts/
    """
    # This file is in: .../sentinel/core/paths.py
    # We want:         .../sentinel/scripts/filename

    # Get the directory of THIS file (core/)
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Go up one level to the package root (sentinel/)
    pkg_root = os.path.dirname(current_dir)

    # Target path
    script_path = os.path.join(pkg_root, "scripts", filename)

    if not os.path.exists(script_path):
        # Fallback for Development Mode (running from source without pip install)
        # In dev repo: sentinel/core/paths.py -> ../../../scripts/
        repo_root = os.path.dirname(os.path.dirname(pkg_root))
        dev_path = os.path.join(repo_root, "scripts", filename)

        if os.path.exists(dev_path):
            return dev_path

        # If we still can't find it, that's a build error
        raise FileNotFoundError(
            f"Could not find bundled script '{filename}'.\n"
            f"Checked: {script_path}\n"
            f"Checked: {dev_path}"
        )

    return script_path