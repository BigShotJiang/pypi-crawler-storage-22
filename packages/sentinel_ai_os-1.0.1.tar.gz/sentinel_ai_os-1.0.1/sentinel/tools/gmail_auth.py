import os.path
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

# --- FIX: IMPORT PATHS FROM CENTRAL MODULE ---
from sentinel.paths import CREDENTIALS_PATH, TOKEN_PATH

# The permissions the AI needs
SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/gmail.send'
]


def get_gmail_service():
    creds = None

    # 1. Check if we already logged in (using the centralized token path)
    if os.path.exists(TOKEN_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)

    # 2. If not logged in or token expired, log in
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            # Check if credentials file exists in the user data folder
            if not os.path.exists(CREDENTIALS_PATH):
                print(f"Error: credentials.json not found at {CREDENTIALS_PATH}")
                return None

            # This opens your browser to login
            flow = InstalledAppFlow.from_client_secrets_file(
                CREDENTIALS_PATH, SCOPES)
            creds = flow.run_local_server(port=0)

        # Save the token for next time
        # Ensure the directory exists
        TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)

        with open(TOKEN_PATH, 'w') as token:
            token.write(creds.to_json())

    # 3. Return the API Service
    from googleapiclient.discovery import build
    return build('gmail', 'v1', credentials=creds)