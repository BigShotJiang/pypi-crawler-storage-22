"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'amino/amino.proto')
_sym_db = _symbol_database.Default()
from google.protobuf import descriptor_pb2 as google_dot_protobuf_dot_descriptor__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x11amino/amino.proto\x12\x05amino\x1a google/protobuf/descriptor.proto:0\n\x04name\x12\x1f.google.protobuf.MessageOptions\x18\xf1\x8c\xa6\x05 \x01(\t:<\n\x10message_encoding\x12\x1f.google.protobuf.MessageOptions\x18\xf2\x8c\xa6\x05 \x01(\t:2\n\x08encoding\x12\x1d.google.protobuf.FieldOptions\x18\xf3\x8c\xa6\x05 \x01(\t:4\n\nfield_name\x12\x1d.google.protobuf.FieldOptions\x18\xf4\x8c\xa6\x05 \x01(\t:8\n\x0edont_omitempty\x12\x1d.google.protobuf.FieldOptions\x18\xf5\x8c\xa6\x05 \x01(\x08B-Z+github.com/cosmos/cosmos-sdk/types/tx/aminob\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'amino.amino_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'Z+github.com/cosmos/cosmos-sdk/types/tx/amino'