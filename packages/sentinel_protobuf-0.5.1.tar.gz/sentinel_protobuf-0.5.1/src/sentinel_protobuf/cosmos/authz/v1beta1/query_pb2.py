"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'cosmos/authz/v1beta1/query.proto')
_sym_db = _symbol_database.Default()
from ....google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from ....cosmos.base.query.v1beta1 import pagination_pb2 as cosmos_dot_base_dot_query_dot_v1beta1_dot_pagination__pb2
from ....cosmos.authz.v1beta1 import authz_pb2 as cosmos_dot_authz_dot_v1beta1_dot_authz__pb2
from ....cosmos_proto import cosmos_pb2 as cosmos__proto_dot_cosmos__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n cosmos/authz/v1beta1/query.proto\x12\x14cosmos.authz.v1beta1\x1a\x1cgoogle/api/annotations.proto\x1a*cosmos/base/query/v1beta1/pagination.proto\x1a cosmos/authz/v1beta1/authz.proto\x1a\x19cosmos_proto/cosmos.proto"\xbc\x01\n\x12QueryGrantsRequest\x12)\n\x07granter\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12)\n\x07grantee\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x14\n\x0cmsg_type_url\x18\x03 \x01(\t\x12:\n\npagination\x18\x04 \x01(\x0b2&.cosmos.base.query.v1beta1.PageRequest"\x7f\n\x13QueryGrantsResponse\x12+\n\x06grants\x18\x01 \x03(\x0b2\x1b.cosmos.authz.v1beta1.Grant\x12;\n\npagination\x18\x02 \x01(\x0b2\'.cosmos.base.query.v1beta1.PageResponse"\x82\x01\n\x19QueryGranterGrantsRequest\x12)\n\x07granter\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12:\n\npagination\x18\x02 \x01(\x0b2&.cosmos.base.query.v1beta1.PageRequest"\x93\x01\n\x1aQueryGranterGrantsResponse\x128\n\x06grants\x18\x01 \x03(\x0b2(.cosmos.authz.v1beta1.GrantAuthorization\x12;\n\npagination\x18\x02 \x01(\x0b2\'.cosmos.base.query.v1beta1.PageResponse"\x82\x01\n\x19QueryGranteeGrantsRequest\x12)\n\x07grantee\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12:\n\npagination\x18\x02 \x01(\x0b2&.cosmos.base.query.v1beta1.PageRequest"\x93\x01\n\x1aQueryGranteeGrantsResponse\x128\n\x06grants\x18\x01 \x03(\x0b2(.cosmos.authz.v1beta1.GrantAuthorization\x12;\n\npagination\x18\x02 \x01(\x0b2\'.cosmos.base.query.v1beta1.PageResponse2\xe7\x03\n\x05Query\x12\x83\x01\n\x06Grants\x12(.cosmos.authz.v1beta1.QueryGrantsRequest\x1a).cosmos.authz.v1beta1.QueryGrantsResponse"$\x82\xd3\xe4\x93\x02\x1e\x12\x1c/cosmos/authz/v1beta1/grants\x12\xaa\x01\n\rGranterGrants\x12/.cosmos.authz.v1beta1.QueryGranterGrantsRequest\x1a0.cosmos.authz.v1beta1.QueryGranterGrantsResponse"6\x82\xd3\xe4\x93\x020\x12./cosmos/authz/v1beta1/grants/granter/{granter}\x12\xaa\x01\n\rGranteeGrants\x12/.cosmos.authz.v1beta1.QueryGranteeGrantsRequest\x1a0.cosmos.authz.v1beta1.QueryGranteeGrantsResponse"6\x82\xd3\xe4\x93\x020\x12./cosmos/authz/v1beta1/grants/grantee/{grantee}B&Z$github.com/cosmos/cosmos-sdk/x/authzb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'cosmos.authz.v1beta1.query_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'Z$github.com/cosmos/cosmos-sdk/x/authz'
    _globals['_QUERYGRANTSREQUEST'].fields_by_name['granter']._loaded_options = None
    _globals['_QUERYGRANTSREQUEST'].fields_by_name['granter']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_QUERYGRANTSREQUEST'].fields_by_name['grantee']._loaded_options = None
    _globals['_QUERYGRANTSREQUEST'].fields_by_name['grantee']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_QUERYGRANTERGRANTSREQUEST'].fields_by_name['granter']._loaded_options = None
    _globals['_QUERYGRANTERGRANTSREQUEST'].fields_by_name['granter']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_QUERYGRANTEEGRANTSREQUEST'].fields_by_name['grantee']._loaded_options = None
    _globals['_QUERYGRANTEEGRANTSREQUEST'].fields_by_name['grantee']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_QUERY'].methods_by_name['Grants']._loaded_options = None
    _globals['_QUERY'].methods_by_name['Grants']._serialized_options = b'\x82\xd3\xe4\x93\x02\x1e\x12\x1c/cosmos/authz/v1beta1/grants'
    _globals['_QUERY'].methods_by_name['GranterGrants']._loaded_options = None
    _globals['_QUERY'].methods_by_name['GranterGrants']._serialized_options = b'\x82\xd3\xe4\x93\x020\x12./cosmos/authz/v1beta1/grants/granter/{granter}'
    _globals['_QUERY'].methods_by_name['GranteeGrants']._loaded_options = None
    _globals['_QUERY'].methods_by_name['GranteeGrants']._serialized_options = b'\x82\xd3\xe4\x93\x020\x12./cosmos/authz/v1beta1/grants/grantee/{grantee}'
    _globals['_QUERYGRANTSREQUEST']._serialized_start = 194
    _globals['_QUERYGRANTSREQUEST']._serialized_end = 382
    _globals['_QUERYGRANTSRESPONSE']._serialized_start = 384
    _globals['_QUERYGRANTSRESPONSE']._serialized_end = 511
    _globals['_QUERYGRANTERGRANTSREQUEST']._serialized_start = 514
    _globals['_QUERYGRANTERGRANTSREQUEST']._serialized_end = 644
    _globals['_QUERYGRANTERGRANTSRESPONSE']._serialized_start = 647
    _globals['_QUERYGRANTERGRANTSRESPONSE']._serialized_end = 794
    _globals['_QUERYGRANTEEGRANTSREQUEST']._serialized_start = 797
    _globals['_QUERYGRANTEEGRANTSREQUEST']._serialized_end = 927
    _globals['_QUERYGRANTEEGRANTSRESPONSE']._serialized_start = 930
    _globals['_QUERYGRANTEEGRANTSRESPONSE']._serialized_end = 1077
    _globals['_QUERY']._serialized_start = 1080
    _globals['_QUERY']._serialized_end = 1567