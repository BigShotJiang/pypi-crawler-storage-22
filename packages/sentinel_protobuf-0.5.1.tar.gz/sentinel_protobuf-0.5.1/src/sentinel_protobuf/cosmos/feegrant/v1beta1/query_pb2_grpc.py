"""Client and server classes corresponding to protobuf-defined services."""
import grpc
import warnings
from ....cosmos.feegrant.v1beta1 import query_pb2 as cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2
GRPC_GENERATED_VERSION = '1.71.0'
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower
    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(f'The grpc package installed is at version {GRPC_VERSION},' + f' but the generated code in cosmos/feegrant/v1beta1/query_pb2_grpc.py depends on' + f' grpcio>={GRPC_GENERATED_VERSION}.' + f' Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}' + f' or downgrade your generated code using grpcio-tools<={GRPC_VERSION}.')

class QueryStub(object):
    """Query defines the gRPC querier service.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Allowance = channel.unary_unary('/cosmos.feegrant.v1beta1.Query/Allowance', request_serializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowanceRequest.SerializeToString, response_deserializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowanceResponse.FromString, _registered_method=True)
        self.Allowances = channel.unary_unary('/cosmos.feegrant.v1beta1.Query/Allowances', request_serializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesRequest.SerializeToString, response_deserializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesResponse.FromString, _registered_method=True)
        self.AllowancesByGranter = channel.unary_unary('/cosmos.feegrant.v1beta1.Query/AllowancesByGranter', request_serializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesByGranterRequest.SerializeToString, response_deserializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesByGranterResponse.FromString, _registered_method=True)

class QueryServicer(object):
    """Query defines the gRPC querier service.
    """

    def Allowance(self, request, context):
        """Allowance returns fee granted to the grantee by the granter.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def Allowances(self, request, context):
        """Allowances returns all the grants for address.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def AllowancesByGranter(self, request, context):
        """AllowancesByGranter returns all the grants given by an address

        Since: cosmos-sdk 0.46
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_QueryServicer_to_server(servicer, server):
    rpc_method_handlers = {'Allowance': grpc.unary_unary_rpc_method_handler(servicer.Allowance, request_deserializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowanceRequest.FromString, response_serializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowanceResponse.SerializeToString), 'Allowances': grpc.unary_unary_rpc_method_handler(servicer.Allowances, request_deserializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesRequest.FromString, response_serializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesResponse.SerializeToString), 'AllowancesByGranter': grpc.unary_unary_rpc_method_handler(servicer.AllowancesByGranter, request_deserializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesByGranterRequest.FromString, response_serializer=cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesByGranterResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('cosmos.feegrant.v1beta1.Query', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('cosmos.feegrant.v1beta1.Query', rpc_method_handlers)

class Query(object):
    """Query defines the gRPC querier service.
    """

    @staticmethod
    def Allowance(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cosmos.feegrant.v1beta1.Query/Allowance', cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowanceRequest.SerializeToString, cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowanceResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def Allowances(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cosmos.feegrant.v1beta1.Query/Allowances', cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesRequest.SerializeToString, cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def AllowancesByGranter(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/cosmos.feegrant.v1beta1.Query/AllowancesByGranter', cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesByGranterRequest.SerializeToString, cosmos_dot_feegrant_dot_v1beta1_dot_query__pb2.QueryAllowancesByGranterResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)