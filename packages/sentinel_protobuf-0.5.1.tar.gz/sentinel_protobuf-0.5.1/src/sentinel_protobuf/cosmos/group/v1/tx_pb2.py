"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'cosmos/group/v1/tx.proto')
_sym_db = _symbol_database.Default()
from ....gogoproto import gogo_pb2 as gogoproto_dot_gogo__pb2
from ....cosmos_proto import cosmos_pb2 as cosmos__proto_dot_cosmos__pb2
from google.protobuf import any_pb2 as google_dot_protobuf_dot_any__pb2
from ....cosmos.group.v1 import types_pb2 as cosmos_dot_group_dot_v1_dot_types__pb2
from ....cosmos.msg.v1 import msg_pb2 as cosmos_dot_msg_dot_v1_dot_msg__pb2
from ....amino import amino_pb2 as amino_dot_amino__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x18cosmos/group/v1/tx.proto\x12\x0fcosmos.group.v1\x1a\x14gogoproto/gogo.proto\x1a\x19cosmos_proto/cosmos.proto\x1a\x19google/protobuf/any.proto\x1a\x1bcosmos/group/v1/types.proto\x1a\x17cosmos/msg/v1/msg.proto\x1a\x11amino/amino.proto"\xb1\x01\n\x0eMsgCreateGroup\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12:\n\x07members\x18\x02 \x03(\x0b2\x1e.cosmos.group.v1.MemberRequestB\t\xc8\xde\x1f\x00\xa8\xe7\xb0*\x01\x12\x10\n\x08metadata\x18\x03 \x01(\t:(\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\x19cosmos-sdk/MsgCreateGroup"*\n\x16MsgCreateGroupResponse\x12\x10\n\x08group_id\x18\x01 \x01(\x04"\xc6\x01\n\x15MsgUpdateGroupMembers\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x10\n\x08group_id\x18\x02 \x01(\x04\x12A\n\x0emember_updates\x18\x03 \x03(\x0b2\x1e.cosmos.group.v1.MemberRequestB\t\xc8\xde\x1f\x00\xa8\xe7\xb0*\x01:/\x82\xe7\xb0*\x05admin\x8a\xe7\xb0* cosmos-sdk/MsgUpdateGroupMembers"\x1f\n\x1dMsgUpdateGroupMembersResponse"\xac\x01\n\x13MsgUpdateGroupAdmin\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x10\n\x08group_id\x18\x02 \x01(\x04\x12+\n\tnew_admin\x18\x03 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString:-\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\x1ecosmos-sdk/MsgUpdateGroupAdmin"\x1d\n\x1bMsgUpdateGroupAdminResponse"\x97\x01\n\x16MsgUpdateGroupMetadata\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x10\n\x08group_id\x18\x02 \x01(\x04\x12\x10\n\x08metadata\x18\x03 \x01(\t:0\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*!cosmos-sdk/MsgUpdateGroupMetadata" \n\x1eMsgUpdateGroupMetadataResponse"\xea\x01\n\x14MsgCreateGroupPolicy\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x10\n\x08group_id\x18\x02 \x01(\x04\x12\x10\n\x08metadata\x18\x03 \x01(\t\x12Q\n\x0fdecision_policy\x18\x04 \x01(\x0b2\x14.google.protobuf.AnyB"\xca\xb4-\x1ecosmos.group.v1.DecisionPolicy:2\x88\xa0\x1f\x00\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\x1fcosmos-sdk/MsgCreateGroupPolicy"I\n\x1cMsgCreateGroupPolicyResponse\x12)\n\x07address\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString"\xde\x01\n\x19MsgUpdateGroupPolicyAdmin\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x126\n\x14group_policy_address\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12+\n\tnew_admin\x18\x03 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString:3\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*$cosmos-sdk/MsgUpdateGroupPolicyAdmin"#\n!MsgUpdateGroupPolicyAdminResponse"\xe0\x02\n\x18MsgCreateGroupWithPolicy\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12:\n\x07members\x18\x02 \x03(\x0b2\x1e.cosmos.group.v1.MemberRequestB\t\xc8\xde\x1f\x00\xa8\xe7\xb0*\x01\x12\x16\n\x0egroup_metadata\x18\x03 \x01(\t\x12\x1d\n\x15group_policy_metadata\x18\x04 \x01(\t\x12\x1d\n\x15group_policy_as_admin\x18\x05 \x01(\x08\x12Q\n\x0fdecision_policy\x18\x06 \x01(\x0b2\x14.google.protobuf.AnyB"\xca\xb4-\x1ecosmos.group.v1.DecisionPolicy:6\x88\xa0\x1f\x00\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*#cosmos-sdk/MsgCreateGroupWithPolicy"l\n MsgCreateGroupWithPolicyResponse\x12\x10\n\x08group_id\x18\x01 \x01(\x04\x126\n\x14group_policy_address\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString"\x94\x02\n"MsgUpdateGroupPolicyDecisionPolicy\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x126\n\x14group_policy_address\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12Q\n\x0fdecision_policy\x18\x03 \x01(\x0b2\x14.google.protobuf.AnyB"\xca\xb4-\x1ecosmos.group.v1.DecisionPolicy::\x88\xa0\x1f\x00\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\'cosmos-sdk/MsgUpdateGroupDecisionPolicy",\n*MsgUpdateGroupPolicyDecisionPolicyResponse"\xc9\x01\n\x1cMsgUpdateGroupPolicyMetadata\x12\'\n\x05admin\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x126\n\x14group_policy_address\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x10\n\x08metadata\x18\x03 \x01(\t:6\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\'cosmos-sdk/MsgUpdateGroupPolicyMetadata"&\n$MsgUpdateGroupPolicyMetadataResponse"\x98\x02\n\x11MsgSubmitProposal\x126\n\x14group_policy_address\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x11\n\tproposers\x18\x02 \x03(\t\x12\x10\n\x08metadata\x18\x03 \x01(\t\x12&\n\x08messages\x18\x04 \x03(\x0b2\x14.google.protobuf.Any\x12#\n\x04exec\x18\x05 \x01(\x0e2\x15.cosmos.group.v1.Exec\x12\r\n\x05title\x18\x06 \x01(\t\x12\x0f\n\x07summary\x18\x07 \x01(\t:9\x88\xa0\x1f\x00\x82\xe7\xb0*\tproposers\x8a\xe7\xb0*"cosmos-sdk/group/MsgSubmitProposal"0\n\x19MsgSubmitProposalResponse\x12\x13\n\x0bproposal_id\x18\x01 \x01(\x04"\x8c\x01\n\x13MsgWithdrawProposal\x12\x13\n\x0bproposal_id\x18\x01 \x01(\x04\x12)\n\x07address\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString:5\x82\xe7\xb0*\x07address\x8a\xe7\xb0*$cosmos-sdk/group/MsgWithdrawProposal"\x1d\n\x1bMsgWithdrawProposalResponse"\xd4\x01\n\x07MsgVote\x12\x13\n\x0bproposal_id\x18\x01 \x01(\x04\x12\'\n\x05voter\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12+\n\x06option\x18\x03 \x01(\x0e2\x1b.cosmos.group.v1.VoteOption\x12\x10\n\x08metadata\x18\x04 \x01(\t\x12#\n\x04exec\x18\x05 \x01(\x0e2\x15.cosmos.group.v1.Exec:\'\x82\xe7\xb0*\x05voter\x8a\xe7\xb0*\x18cosmos-sdk/group/MsgVote"\x11\n\x0fMsgVoteResponse"t\n\x07MsgExec\x12\x13\n\x0bproposal_id\x18\x01 \x01(\x04\x12*\n\x08executor\x18\x02 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString:(\x82\xe7\xb0*\x06signer\x8a\xe7\xb0*\x18cosmos-sdk/group/MsgExec"J\n\x0fMsgExecResponse\x127\n\x06result\x18\x02 \x01(\x0e2\'.cosmos.group.v1.ProposalExecutorResult"}\n\rMsgLeaveGroup\x12)\n\x07address\x18\x01 \x01(\tB\x18\xd2\xb4-\x14cosmos.AddressString\x12\x10\n\x08group_id\x18\x02 \x01(\x04:/\x82\xe7\xb0*\x07address\x8a\xe7\xb0*\x1ecosmos-sdk/group/MsgLeaveGroup"\x17\n\x15MsgLeaveGroupResponse**\n\x04Exec\x12\x14\n\x10EXEC_UNSPECIFIED\x10\x00\x12\x0c\n\x08EXEC_TRY\x10\x012\xca\x0b\n\x03Msg\x12W\n\x0bCreateGroup\x12\x1f.cosmos.group.v1.MsgCreateGroup\x1a\'.cosmos.group.v1.MsgCreateGroupResponse\x12l\n\x12UpdateGroupMembers\x12&.cosmos.group.v1.MsgUpdateGroupMembers\x1a..cosmos.group.v1.MsgUpdateGroupMembersResponse\x12f\n\x10UpdateGroupAdmin\x12$.cosmos.group.v1.MsgUpdateGroupAdmin\x1a,.cosmos.group.v1.MsgUpdateGroupAdminResponse\x12o\n\x13UpdateGroupMetadata\x12\'.cosmos.group.v1.MsgUpdateGroupMetadata\x1a/.cosmos.group.v1.MsgUpdateGroupMetadataResponse\x12i\n\x11CreateGroupPolicy\x12%.cosmos.group.v1.MsgCreateGroupPolicy\x1a-.cosmos.group.v1.MsgCreateGroupPolicyResponse\x12u\n\x15CreateGroupWithPolicy\x12).cosmos.group.v1.MsgCreateGroupWithPolicy\x1a1.cosmos.group.v1.MsgCreateGroupWithPolicyResponse\x12x\n\x16UpdateGroupPolicyAdmin\x12*.cosmos.group.v1.MsgUpdateGroupPolicyAdmin\x1a2.cosmos.group.v1.MsgUpdateGroupPolicyAdminResponse\x12\x93\x01\n\x1fUpdateGroupPolicyDecisionPolicy\x123.cosmos.group.v1.MsgUpdateGroupPolicyDecisionPolicy\x1a;.cosmos.group.v1.MsgUpdateGroupPolicyDecisionPolicyResponse\x12\x81\x01\n\x19UpdateGroupPolicyMetadata\x12-.cosmos.group.v1.MsgUpdateGroupPolicyMetadata\x1a5.cosmos.group.v1.MsgUpdateGroupPolicyMetadataResponse\x12`\n\x0eSubmitProposal\x12".cosmos.group.v1.MsgSubmitProposal\x1a*.cosmos.group.v1.MsgSubmitProposalResponse\x12f\n\x10WithdrawProposal\x12$.cosmos.group.v1.MsgWithdrawProposal\x1a,.cosmos.group.v1.MsgWithdrawProposalResponse\x12B\n\x04Vote\x12\x18.cosmos.group.v1.MsgVote\x1a .cosmos.group.v1.MsgVoteResponse\x12B\n\x04Exec\x12\x18.cosmos.group.v1.MsgExec\x1a .cosmos.group.v1.MsgExecResponse\x12T\n\nLeaveGroup\x12\x1e.cosmos.group.v1.MsgLeaveGroup\x1a&.cosmos.group.v1.MsgLeaveGroupResponse\x1a\x05\x80\xe7\xb0*\x01B&Z$github.com/cosmos/cosmos-sdk/x/groupb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'cosmos.group.v1.tx_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'Z$github.com/cosmos/cosmos-sdk/x/group'
    _globals['_MSGCREATEGROUP'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGCREATEGROUP'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGCREATEGROUP'].fields_by_name['members']._loaded_options = None
    _globals['_MSGCREATEGROUP'].fields_by_name['members']._serialized_options = b'\xc8\xde\x1f\x00\xa8\xe7\xb0*\x01'
    _globals['_MSGCREATEGROUP']._loaded_options = None
    _globals['_MSGCREATEGROUP']._serialized_options = b'\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\x19cosmos-sdk/MsgCreateGroup'
    _globals['_MSGUPDATEGROUPMEMBERS'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPMEMBERS'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPMEMBERS'].fields_by_name['member_updates']._loaded_options = None
    _globals['_MSGUPDATEGROUPMEMBERS'].fields_by_name['member_updates']._serialized_options = b'\xc8\xde\x1f\x00\xa8\xe7\xb0*\x01'
    _globals['_MSGUPDATEGROUPMEMBERS']._loaded_options = None
    _globals['_MSGUPDATEGROUPMEMBERS']._serialized_options = b'\x82\xe7\xb0*\x05admin\x8a\xe7\xb0* cosmos-sdk/MsgUpdateGroupMembers'
    _globals['_MSGUPDATEGROUPADMIN'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPADMIN'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPADMIN'].fields_by_name['new_admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPADMIN'].fields_by_name['new_admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPADMIN']._loaded_options = None
    _globals['_MSGUPDATEGROUPADMIN']._serialized_options = b'\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\x1ecosmos-sdk/MsgUpdateGroupAdmin'
    _globals['_MSGUPDATEGROUPMETADATA'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPMETADATA'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPMETADATA']._loaded_options = None
    _globals['_MSGUPDATEGROUPMETADATA']._serialized_options = b'\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*!cosmos-sdk/MsgUpdateGroupMetadata'
    _globals['_MSGCREATEGROUPPOLICY'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGCREATEGROUPPOLICY'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGCREATEGROUPPOLICY'].fields_by_name['decision_policy']._loaded_options = None
    _globals['_MSGCREATEGROUPPOLICY'].fields_by_name['decision_policy']._serialized_options = b'\xca\xb4-\x1ecosmos.group.v1.DecisionPolicy'
    _globals['_MSGCREATEGROUPPOLICY']._loaded_options = None
    _globals['_MSGCREATEGROUPPOLICY']._serialized_options = b'\x88\xa0\x1f\x00\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*\x1fcosmos-sdk/MsgCreateGroupPolicy'
    _globals['_MSGCREATEGROUPPOLICYRESPONSE'].fields_by_name['address']._loaded_options = None
    _globals['_MSGCREATEGROUPPOLICYRESPONSE'].fields_by_name['address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYADMIN'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYADMIN'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYADMIN'].fields_by_name['group_policy_address']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYADMIN'].fields_by_name['group_policy_address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYADMIN'].fields_by_name['new_admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYADMIN'].fields_by_name['new_admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYADMIN']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYADMIN']._serialized_options = b'\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*$cosmos-sdk/MsgUpdateGroupPolicyAdmin'
    _globals['_MSGCREATEGROUPWITHPOLICY'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGCREATEGROUPWITHPOLICY'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGCREATEGROUPWITHPOLICY'].fields_by_name['members']._loaded_options = None
    _globals['_MSGCREATEGROUPWITHPOLICY'].fields_by_name['members']._serialized_options = b'\xc8\xde\x1f\x00\xa8\xe7\xb0*\x01'
    _globals['_MSGCREATEGROUPWITHPOLICY'].fields_by_name['decision_policy']._loaded_options = None
    _globals['_MSGCREATEGROUPWITHPOLICY'].fields_by_name['decision_policy']._serialized_options = b'\xca\xb4-\x1ecosmos.group.v1.DecisionPolicy'
    _globals['_MSGCREATEGROUPWITHPOLICY']._loaded_options = None
    _globals['_MSGCREATEGROUPWITHPOLICY']._serialized_options = b'\x88\xa0\x1f\x00\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*#cosmos-sdk/MsgCreateGroupWithPolicy'
    _globals['_MSGCREATEGROUPWITHPOLICYRESPONSE'].fields_by_name['group_policy_address']._loaded_options = None
    _globals['_MSGCREATEGROUPWITHPOLICYRESPONSE'].fields_by_name['group_policy_address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY'].fields_by_name['group_policy_address']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY'].fields_by_name['group_policy_address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY'].fields_by_name['decision_policy']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY'].fields_by_name['decision_policy']._serialized_options = b'\xca\xb4-\x1ecosmos.group.v1.DecisionPolicy'
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY']._serialized_options = b"\x88\xa0\x1f\x00\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*'cosmos-sdk/MsgUpdateGroupDecisionPolicy"
    _globals['_MSGUPDATEGROUPPOLICYMETADATA'].fields_by_name['admin']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYMETADATA'].fields_by_name['admin']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYMETADATA'].fields_by_name['group_policy_address']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYMETADATA'].fields_by_name['group_policy_address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGUPDATEGROUPPOLICYMETADATA']._loaded_options = None
    _globals['_MSGUPDATEGROUPPOLICYMETADATA']._serialized_options = b"\x82\xe7\xb0*\x05admin\x8a\xe7\xb0*'cosmos-sdk/MsgUpdateGroupPolicyMetadata"
    _globals['_MSGSUBMITPROPOSAL'].fields_by_name['group_policy_address']._loaded_options = None
    _globals['_MSGSUBMITPROPOSAL'].fields_by_name['group_policy_address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGSUBMITPROPOSAL']._loaded_options = None
    _globals['_MSGSUBMITPROPOSAL']._serialized_options = b'\x88\xa0\x1f\x00\x82\xe7\xb0*\tproposers\x8a\xe7\xb0*"cosmos-sdk/group/MsgSubmitProposal'
    _globals['_MSGWITHDRAWPROPOSAL'].fields_by_name['address']._loaded_options = None
    _globals['_MSGWITHDRAWPROPOSAL'].fields_by_name['address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGWITHDRAWPROPOSAL']._loaded_options = None
    _globals['_MSGWITHDRAWPROPOSAL']._serialized_options = b'\x82\xe7\xb0*\x07address\x8a\xe7\xb0*$cosmos-sdk/group/MsgWithdrawProposal'
    _globals['_MSGVOTE'].fields_by_name['voter']._loaded_options = None
    _globals['_MSGVOTE'].fields_by_name['voter']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGVOTE']._loaded_options = None
    _globals['_MSGVOTE']._serialized_options = b'\x82\xe7\xb0*\x05voter\x8a\xe7\xb0*\x18cosmos-sdk/group/MsgVote'
    _globals['_MSGEXEC'].fields_by_name['executor']._loaded_options = None
    _globals['_MSGEXEC'].fields_by_name['executor']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGEXEC']._loaded_options = None
    _globals['_MSGEXEC']._serialized_options = b'\x82\xe7\xb0*\x06signer\x8a\xe7\xb0*\x18cosmos-sdk/group/MsgExec'
    _globals['_MSGLEAVEGROUP'].fields_by_name['address']._loaded_options = None
    _globals['_MSGLEAVEGROUP'].fields_by_name['address']._serialized_options = b'\xd2\xb4-\x14cosmos.AddressString'
    _globals['_MSGLEAVEGROUP']._loaded_options = None
    _globals['_MSGLEAVEGROUP']._serialized_options = b'\x82\xe7\xb0*\x07address\x8a\xe7\xb0*\x1ecosmos-sdk/group/MsgLeaveGroup'
    _globals['_MSG']._loaded_options = None
    _globals['_MSG']._serialized_options = b'\x80\xe7\xb0*\x01'
    _globals['_EXEC']._serialized_start = 3741
    _globals['_EXEC']._serialized_end = 3783
    _globals['_MSGCREATEGROUP']._serialized_start = 195
    _globals['_MSGCREATEGROUP']._serialized_end = 372
    _globals['_MSGCREATEGROUPRESPONSE']._serialized_start = 374
    _globals['_MSGCREATEGROUPRESPONSE']._serialized_end = 416
    _globals['_MSGUPDATEGROUPMEMBERS']._serialized_start = 419
    _globals['_MSGUPDATEGROUPMEMBERS']._serialized_end = 617
    _globals['_MSGUPDATEGROUPMEMBERSRESPONSE']._serialized_start = 619
    _globals['_MSGUPDATEGROUPMEMBERSRESPONSE']._serialized_end = 650
    _globals['_MSGUPDATEGROUPADMIN']._serialized_start = 653
    _globals['_MSGUPDATEGROUPADMIN']._serialized_end = 825
    _globals['_MSGUPDATEGROUPADMINRESPONSE']._serialized_start = 827
    _globals['_MSGUPDATEGROUPADMINRESPONSE']._serialized_end = 856
    _globals['_MSGUPDATEGROUPMETADATA']._serialized_start = 859
    _globals['_MSGUPDATEGROUPMETADATA']._serialized_end = 1010
    _globals['_MSGUPDATEGROUPMETADATARESPONSE']._serialized_start = 1012
    _globals['_MSGUPDATEGROUPMETADATARESPONSE']._serialized_end = 1044
    _globals['_MSGCREATEGROUPPOLICY']._serialized_start = 1047
    _globals['_MSGCREATEGROUPPOLICY']._serialized_end = 1281
    _globals['_MSGCREATEGROUPPOLICYRESPONSE']._serialized_start = 1283
    _globals['_MSGCREATEGROUPPOLICYRESPONSE']._serialized_end = 1356
    _globals['_MSGUPDATEGROUPPOLICYADMIN']._serialized_start = 1359
    _globals['_MSGUPDATEGROUPPOLICYADMIN']._serialized_end = 1581
    _globals['_MSGUPDATEGROUPPOLICYADMINRESPONSE']._serialized_start = 1583
    _globals['_MSGUPDATEGROUPPOLICYADMINRESPONSE']._serialized_end = 1618
    _globals['_MSGCREATEGROUPWITHPOLICY']._serialized_start = 1621
    _globals['_MSGCREATEGROUPWITHPOLICY']._serialized_end = 1973
    _globals['_MSGCREATEGROUPWITHPOLICYRESPONSE']._serialized_start = 1975
    _globals['_MSGCREATEGROUPWITHPOLICYRESPONSE']._serialized_end = 2083
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY']._serialized_start = 2086
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICY']._serialized_end = 2362
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICYRESPONSE']._serialized_start = 2364
    _globals['_MSGUPDATEGROUPPOLICYDECISIONPOLICYRESPONSE']._serialized_end = 2408
    _globals['_MSGUPDATEGROUPPOLICYMETADATA']._serialized_start = 2411
    _globals['_MSGUPDATEGROUPPOLICYMETADATA']._serialized_end = 2612
    _globals['_MSGUPDATEGROUPPOLICYMETADATARESPONSE']._serialized_start = 2614
    _globals['_MSGUPDATEGROUPPOLICYMETADATARESPONSE']._serialized_end = 2652
    _globals['_MSGSUBMITPROPOSAL']._serialized_start = 2655
    _globals['_MSGSUBMITPROPOSAL']._serialized_end = 2935
    _globals['_MSGSUBMITPROPOSALRESPONSE']._serialized_start = 2937
    _globals['_MSGSUBMITPROPOSALRESPONSE']._serialized_end = 2985
    _globals['_MSGWITHDRAWPROPOSAL']._serialized_start = 2988
    _globals['_MSGWITHDRAWPROPOSAL']._serialized_end = 3128
    _globals['_MSGWITHDRAWPROPOSALRESPONSE']._serialized_start = 3130
    _globals['_MSGWITHDRAWPROPOSALRESPONSE']._serialized_end = 3159
    _globals['_MSGVOTE']._serialized_start = 3162
    _globals['_MSGVOTE']._serialized_end = 3374
    _globals['_MSGVOTERESPONSE']._serialized_start = 3376
    _globals['_MSGVOTERESPONSE']._serialized_end = 3393
    _globals['_MSGEXEC']._serialized_start = 3395
    _globals['_MSGEXEC']._serialized_end = 3511
    _globals['_MSGEXECRESPONSE']._serialized_start = 3513
    _globals['_MSGEXECRESPONSE']._serialized_end = 3587
    _globals['_MSGLEAVEGROUP']._serialized_start = 3589
    _globals['_MSGLEAVEGROUP']._serialized_end = 3714
    _globals['_MSGLEAVEGROUPRESPONSE']._serialized_start = 3716
    _globals['_MSGLEAVEGROUPRESPONSE']._serialized_end = 3739
    _globals['_MSG']._serialized_start = 3786
    _globals['_MSG']._serialized_end = 5268