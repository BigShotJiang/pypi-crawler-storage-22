"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'google/api/apikeys/v2/apikeys.proto')
_sym_db = _symbol_database.Default()
from .....google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from .....google.api.apikeys.v2 import resources_pb2 as google_dot_api_dot_apikeys_dot_v2_dot_resources__pb2
from .....google.api import client_pb2 as google_dot_api_dot_client__pb2
from .....google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from .....google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from .....google.longrunning import operations_pb2 as google_dot_longrunning_dot_operations__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from google.protobuf import field_mask_pb2 as google_dot_protobuf_dot_field__mask__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n#google/api/apikeys/v2/apikeys.proto\x12\x15google.api.apikeys.v2\x1a\x1cgoogle/api/annotations.proto\x1a%google/api/apikeys/v2/resources.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a#google/longrunning/operations.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a google/protobuf/field_mask.proto"\x84\x01\n\x10CreateKeyRequest\x122\n\x06parent\x18\x01 \x01(\tB"\xe0A\x02\xfaA\x1c\x12\x1aapikeys.googleapis.com/Key\x12,\n\x03key\x18\x02 \x01(\x0b2\x1a.google.api.apikeys.v2.KeyB\x03\xe0A\x02\x12\x0e\n\x06key_id\x18\x03 \x01(\t"\x91\x01\n\x0fListKeysRequest\x122\n\x06parent\x18\x01 \x01(\tB"\xe0A\x02\xfaA\x1c\x12\x1aapikeys.googleapis.com/Key\x12\x16\n\tpage_size\x18\x02 \x01(\x05B\x03\xe0A\x01\x12\x17\n\npage_token\x18\x03 \x01(\tB\x03\xe0A\x01\x12\x19\n\x0cshow_deleted\x18\x06 \x01(\x08B\x03\xe0A\x01"U\n\x10ListKeysResponse\x12(\n\x04keys\x18\x01 \x03(\x0b2\x1a.google.api.apikeys.v2.Key\x12\x17\n\x0fnext_page_token\x18\x02 \x01(\t"A\n\rGetKeyRequest\x120\n\x04name\x18\x01 \x01(\tB"\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key"G\n\x13GetKeyStringRequest\x120\n\x04name\x18\x01 \x01(\tB"\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key"*\n\x14GetKeyStringResponse\x12\x12\n\nkey_string\x18\x01 \x01(\t"q\n\x10UpdateKeyRequest\x12,\n\x03key\x18\x01 \x01(\x0b2\x1a.google.api.apikeys.v2.KeyB\x03\xe0A\x02\x12/\n\x0bupdate_mask\x18\x02 \x01(\x0b2\x1a.google.protobuf.FieldMask"W\n\x10DeleteKeyRequest\x120\n\x04name\x18\x01 \x01(\tB"\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key\x12\x11\n\x04etag\x18\x02 \x01(\tB\x03\xe0A\x01"F\n\x12UndeleteKeyRequest\x120\n\x04name\x18\x01 \x01(\tB"\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key"+\n\x10LookupKeyRequest\x12\x17\n\nkey_string\x18\x01 \x01(\tB\x03\xe0A\x02"1\n\x11LookupKeyResponse\x12\x0e\n\x06parent\x18\x01 \x01(\t\x12\x0c\n\x04name\x18\x02 \x01(\t2\xbe\x0b\n\x07ApiKeys\x12\xbd\x01\n\tCreateKey\x12\'.google.api.apikeys.v2.CreateKeyRequest\x1a\x1d.google.longrunning.Operation"h\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\xdaA\x11parent,key,key_id\x82\xd3\xe4\x93\x02/"(/v2/{parent=projects/*/locations/*}/keys:\x03key\x12\x96\x01\n\x08ListKeys\x12&.google.api.apikeys.v2.ListKeysRequest\x1a\'.google.api.apikeys.v2.ListKeysResponse"9\xdaA\x06parent\x82\xd3\xe4\x93\x02*\x12(/v2/{parent=projects/*/locations/*}/keys\x12\x83\x01\n\x06GetKey\x12$.google.api.apikeys.v2.GetKeyRequest\x1a\x1a.google.api.apikeys.v2.Key"7\xdaA\x04name\x82\xd3\xe4\x93\x02*\x12(/v2/{name=projects/*/locations/*/keys/*}\x12\xaa\x01\n\x0cGetKeyString\x12*.google.api.apikeys.v2.GetKeyStringRequest\x1a+.google.api.apikeys.v2.GetKeyStringResponse"A\xdaA\x04name\x82\xd3\xe4\x93\x024\x122/v2/{name=projects/*/locations/*/keys/*}/keyString\x12\xbf\x01\n\tUpdateKey\x12\'.google.api.apikeys.v2.UpdateKeyRequest\x1a\x1d.google.longrunning.Operation"j\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\xdaA\x0fkey,update_mask\x82\xd3\xe4\x93\x0232,/v2/{key.name=projects/*/locations/*/keys/*}:\x03key\x12\xab\x01\n\tDeleteKey\x12\'.google.api.apikeys.v2.DeleteKeyRequest\x1a\x1d.google.longrunning.Operation"V\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\xdaA\x04name\x82\xd3\xe4\x93\x02**(/v2/{name=projects/*/locations/*/keys/*}\x12\xb4\x01\n\x0bUndeleteKey\x12).google.api.apikeys.v2.UndeleteKeyRequest\x1a\x1d.google.longrunning.Operation"[\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\x82\xd3\xe4\x93\x026"1/v2/{name=projects/*/locations/*/keys/*}:undelete:\x01*\x12z\n\tLookupKey\x12\'.google.api.apikeys.v2.LookupKeyRequest\x1a(.google.api.apikeys.v2.LookupKeyResponse"\x1a\x82\xd3\xe4\x93\x02\x14\x12\x12/v2/keys:lookupKey\x1a\x83\x01\xcaA\x16apikeys.googleapis.com\xd2Aghttps://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/cloud-platform.read-onlyB\xb3\x01\n\x19com.google.api.apikeys.v2B\x0cApiKeysProtoP\x01Z5cloud.google.com/go/apikeys/apiv2/apikeyspb;apikeyspb\xaa\x02\x17Google.Cloud.ApiKeys.V2\xca\x02\x17Google\\Cloud\\ApiKeys\\V2\xea\x02\x1aGoogle::Cloud::ApiKeys::V2b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'google.api.apikeys.v2.apikeys_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19com.google.api.apikeys.v2B\x0cApiKeysProtoP\x01Z5cloud.google.com/go/apikeys/apiv2/apikeyspb;apikeyspb\xaa\x02\x17Google.Cloud.ApiKeys.V2\xca\x02\x17Google\\Cloud\\ApiKeys\\V2\xea\x02\x1aGoogle::Cloud::ApiKeys::V2'
    _globals['_CREATEKEYREQUEST'].fields_by_name['parent']._loaded_options = None
    _globals['_CREATEKEYREQUEST'].fields_by_name['parent']._serialized_options = b'\xe0A\x02\xfaA\x1c\x12\x1aapikeys.googleapis.com/Key'
    _globals['_CREATEKEYREQUEST'].fields_by_name['key']._loaded_options = None
    _globals['_CREATEKEYREQUEST'].fields_by_name['key']._serialized_options = b'\xe0A\x02'
    _globals['_LISTKEYSREQUEST'].fields_by_name['parent']._loaded_options = None
    _globals['_LISTKEYSREQUEST'].fields_by_name['parent']._serialized_options = b'\xe0A\x02\xfaA\x1c\x12\x1aapikeys.googleapis.com/Key'
    _globals['_LISTKEYSREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTKEYSREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTKEYSREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTKEYSREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTKEYSREQUEST'].fields_by_name['show_deleted']._loaded_options = None
    _globals['_LISTKEYSREQUEST'].fields_by_name['show_deleted']._serialized_options = b'\xe0A\x01'
    _globals['_GETKEYREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_GETKEYREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key'
    _globals['_GETKEYSTRINGREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_GETKEYSTRINGREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key'
    _globals['_UPDATEKEYREQUEST'].fields_by_name['key']._loaded_options = None
    _globals['_UPDATEKEYREQUEST'].fields_by_name['key']._serialized_options = b'\xe0A\x02'
    _globals['_DELETEKEYREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_DELETEKEYREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key'
    _globals['_DELETEKEYREQUEST'].fields_by_name['etag']._loaded_options = None
    _globals['_DELETEKEYREQUEST'].fields_by_name['etag']._serialized_options = b'\xe0A\x01'
    _globals['_UNDELETEKEYREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_UNDELETEKEYREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1c\n\x1aapikeys.googleapis.com/Key'
    _globals['_LOOKUPKEYREQUEST'].fields_by_name['key_string']._loaded_options = None
    _globals['_LOOKUPKEYREQUEST'].fields_by_name['key_string']._serialized_options = b'\xe0A\x02'
    _globals['_APIKEYS']._loaded_options = None
    _globals['_APIKEYS']._serialized_options = b'\xcaA\x16apikeys.googleapis.com\xd2Aghttps://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/cloud-platform.read-only'
    _globals['_APIKEYS'].methods_by_name['CreateKey']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['CreateKey']._serialized_options = b'\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\xdaA\x11parent,key,key_id\x82\xd3\xe4\x93\x02/"(/v2/{parent=projects/*/locations/*}/keys:\x03key'
    _globals['_APIKEYS'].methods_by_name['ListKeys']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['ListKeys']._serialized_options = b'\xdaA\x06parent\x82\xd3\xe4\x93\x02*\x12(/v2/{parent=projects/*/locations/*}/keys'
    _globals['_APIKEYS'].methods_by_name['GetKey']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['GetKey']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02*\x12(/v2/{name=projects/*/locations/*/keys/*}'
    _globals['_APIKEYS'].methods_by_name['GetKeyString']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['GetKeyString']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x024\x122/v2/{name=projects/*/locations/*/keys/*}/keyString'
    _globals['_APIKEYS'].methods_by_name['UpdateKey']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['UpdateKey']._serialized_options = b'\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\xdaA\x0fkey,update_mask\x82\xd3\xe4\x93\x0232,/v2/{key.name=projects/*/locations/*/keys/*}:\x03key'
    _globals['_APIKEYS'].methods_by_name['DeleteKey']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['DeleteKey']._serialized_options = b'\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\xdaA\x04name\x82\xd3\xe4\x93\x02**(/v2/{name=projects/*/locations/*/keys/*}'
    _globals['_APIKEYS'].methods_by_name['UndeleteKey']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['UndeleteKey']._serialized_options = b'\xcaA\x1c\n\x03Key\x12\x15google.protobuf.Empty\x82\xd3\xe4\x93\x026"1/v2/{name=projects/*/locations/*/keys/*}:undelete:\x01*'
    _globals['_APIKEYS'].methods_by_name['LookupKey']._loaded_options = None
    _globals['_APIKEYS'].methods_by_name['LookupKey']._serialized_options = b'\x82\xd3\xe4\x93\x02\x14\x12\x12/v2/keys:lookupKey'
    _globals['_CREATEKEYREQUEST']._serialized_start = 317
    _globals['_CREATEKEYREQUEST']._serialized_end = 449
    _globals['_LISTKEYSREQUEST']._serialized_start = 452
    _globals['_LISTKEYSREQUEST']._serialized_end = 597
    _globals['_LISTKEYSRESPONSE']._serialized_start = 599
    _globals['_LISTKEYSRESPONSE']._serialized_end = 684
    _globals['_GETKEYREQUEST']._serialized_start = 686
    _globals['_GETKEYREQUEST']._serialized_end = 751
    _globals['_GETKEYSTRINGREQUEST']._serialized_start = 753
    _globals['_GETKEYSTRINGREQUEST']._serialized_end = 824
    _globals['_GETKEYSTRINGRESPONSE']._serialized_start = 826
    _globals['_GETKEYSTRINGRESPONSE']._serialized_end = 868
    _globals['_UPDATEKEYREQUEST']._serialized_start = 870
    _globals['_UPDATEKEYREQUEST']._serialized_end = 983
    _globals['_DELETEKEYREQUEST']._serialized_start = 985
    _globals['_DELETEKEYREQUEST']._serialized_end = 1072
    _globals['_UNDELETEKEYREQUEST']._serialized_start = 1074
    _globals['_UNDELETEKEYREQUEST']._serialized_end = 1144
    _globals['_LOOKUPKEYREQUEST']._serialized_start = 1146
    _globals['_LOOKUPKEYREQUEST']._serialized_end = 1189
    _globals['_LOOKUPKEYRESPONSE']._serialized_start = 1191
    _globals['_LOOKUPKEYRESPONSE']._serialized_end = 1240
    _globals['_APIKEYS']._serialized_start = 1243
    _globals['_APIKEYS']._serialized_end = 2713