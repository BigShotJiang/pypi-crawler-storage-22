"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'google/api/backend.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x18google/api/backend.proto\x12\ngoogle.api"1\n\x07Backend\x12&\n\x05rules\x18\x01 \x03(\x0b2\x17.google.api.BackendRule"\xb2\x04\n\x0bBackendRule\x12\x10\n\x08selector\x18\x01 \x01(\t\x12\x0f\n\x07address\x18\x02 \x01(\t\x12\x10\n\x08deadline\x18\x03 \x01(\x01\x12\x18\n\x0cmin_deadline\x18\x04 \x01(\x01B\x02\x18\x01\x12\x1a\n\x12operation_deadline\x18\x05 \x01(\x01\x12A\n\x10path_translation\x18\x06 \x01(\x0e2\'.google.api.BackendRule.PathTranslation\x12\x16\n\x0cjwt_audience\x18\x07 \x01(\tH\x00\x12\x16\n\x0cdisable_auth\x18\x08 \x01(\x08H\x00\x12\x10\n\x08protocol\x18\t \x01(\t\x12^\n\x1doverrides_by_request_protocol\x18\n \x03(\x0b27.google.api.BackendRule.OverridesByRequestProtocolEntry\x1aZ\n\x1fOverridesByRequestProtocolEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12&\n\x05value\x18\x02 \x01(\x0b2\x17.google.api.BackendRule:\x028\x01"e\n\x0fPathTranslation\x12 \n\x1cPATH_TRANSLATION_UNSPECIFIED\x10\x00\x12\x14\n\x10CONSTANT_ADDRESS\x10\x01\x12\x1a\n\x16APPEND_PATH_TO_ADDRESS\x10\x02B\x10\n\x0eauthenticationBn\n\x0ecom.google.apiB\x0cBackendProtoP\x01ZEgoogle.golang.org/genproto/googleapis/api/serviceconfig;serviceconfig\xa2\x02\x04GAPIb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'google.api.backend_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x0ecom.google.apiB\x0cBackendProtoP\x01ZEgoogle.golang.org/genproto/googleapis/api/serviceconfig;serviceconfig\xa2\x02\x04GAPI'
    _globals['_BACKENDRULE_OVERRIDESBYREQUESTPROTOCOLENTRY']._loaded_options = None
    _globals['_BACKENDRULE_OVERRIDESBYREQUESTPROTOCOLENTRY']._serialized_options = b'8\x01'
    _globals['_BACKENDRULE'].fields_by_name['min_deadline']._loaded_options = None
    _globals['_BACKENDRULE'].fields_by_name['min_deadline']._serialized_options = b'\x18\x01'
    _globals['_BACKEND']._serialized_start = 40
    _globals['_BACKEND']._serialized_end = 89
    _globals['_BACKENDRULE']._serialized_start = 92
    _globals['_BACKENDRULE']._serialized_end = 654
    _globals['_BACKENDRULE_OVERRIDESBYREQUESTPROTOCOLENTRY']._serialized_start = 443
    _globals['_BACKENDRULE_OVERRIDESBYREQUESTPROTOCOLENTRY']._serialized_end = 533
    _globals['_BACKENDRULE_PATHTRANSLATION']._serialized_start = 535
    _globals['_BACKENDRULE_PATHTRANSLATION']._serialized_end = 636