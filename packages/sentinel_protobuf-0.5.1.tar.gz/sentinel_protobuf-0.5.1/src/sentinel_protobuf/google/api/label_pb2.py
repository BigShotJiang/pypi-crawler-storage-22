"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'google/api/label.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x16google/api/label.proto\x12\ngoogle.api"\x9c\x01\n\x0fLabelDescriptor\x12\x0b\n\x03key\x18\x01 \x01(\t\x129\n\nvalue_type\x18\x02 \x01(\x0e2%.google.api.LabelDescriptor.ValueType\x12\x13\n\x0bdescription\x18\x03 \x01(\t",\n\tValueType\x12\n\n\x06STRING\x10\x00\x12\x08\n\x04BOOL\x10\x01\x12\t\n\x05INT64\x10\x02B\\\n\x0ecom.google.apiB\nLabelProtoP\x01Z5google.golang.org/genproto/googleapis/api/label;label\xa2\x02\x04GAPIb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'google.api.label_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x0ecom.google.apiB\nLabelProtoP\x01Z5google.golang.org/genproto/googleapis/api/label;label\xa2\x02\x04GAPI'
    _globals['_LABELDESCRIPTOR']._serialized_start = 39
    _globals['_LABELDESCRIPTOR']._serialized_end = 195
    _globals['_LABELDESCRIPTOR_VALUETYPE']._serialized_start = 151
    _globals['_LABELDESCRIPTOR_VALUETYPE']._serialized_end = 195