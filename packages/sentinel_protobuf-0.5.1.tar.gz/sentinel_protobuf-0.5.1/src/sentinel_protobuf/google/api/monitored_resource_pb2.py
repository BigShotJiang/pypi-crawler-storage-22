"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'google/api/monitored_resource.proto')
_sym_db = _symbol_database.Default()
from ...google.api import label_pb2 as google_dot_api_dot_label__pb2
from ...google.api import launch_stage_pb2 as google_dot_api_dot_launch__stage__pb2
from google.protobuf import struct_pb2 as google_dot_protobuf_dot_struct__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n#google/api/monitored_resource.proto\x12\ngoogle.api\x1a\x16google/api/label.proto\x1a\x1dgoogle/api/launch_stage.proto\x1a\x1cgoogle/protobuf/struct.proto"\xc0\x01\n\x1bMonitoredResourceDescriptor\x12\x0c\n\x04name\x18\x05 \x01(\t\x12\x0c\n\x04type\x18\x01 \x01(\t\x12\x14\n\x0cdisplay_name\x18\x02 \x01(\t\x12\x13\n\x0bdescription\x18\x03 \x01(\t\x12+\n\x06labels\x18\x04 \x03(\x0b2\x1b.google.api.LabelDescriptor\x12-\n\x0claunch_stage\x18\x07 \x01(\x0e2\x17.google.api.LaunchStage"\x8b\x01\n\x11MonitoredResource\x12\x0c\n\x04type\x18\x01 \x01(\t\x129\n\x06labels\x18\x02 \x03(\x0b2).google.api.MonitoredResource.LabelsEntry\x1a-\n\x0bLabelsEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01"\xca\x01\n\x19MonitoredResourceMetadata\x12.\n\rsystem_labels\x18\x01 \x01(\x0b2\x17.google.protobuf.Struct\x12J\n\x0buser_labels\x18\x02 \x03(\x0b25.google.api.MonitoredResourceMetadata.UserLabelsEntry\x1a1\n\x0fUserLabelsEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01Bv\n\x0ecom.google.apiB\x16MonitoredResourceProtoP\x01ZCgoogle.golang.org/genproto/googleapis/api/monitoredres;monitoredres\xa2\x02\x04GAPIb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'google.api.monitored_resource_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x0ecom.google.apiB\x16MonitoredResourceProtoP\x01ZCgoogle.golang.org/genproto/googleapis/api/monitoredres;monitoredres\xa2\x02\x04GAPI'
    _globals['_MONITOREDRESOURCE_LABELSENTRY']._loaded_options = None
    _globals['_MONITOREDRESOURCE_LABELSENTRY']._serialized_options = b'8\x01'
    _globals['_MONITOREDRESOURCEMETADATA_USERLABELSENTRY']._loaded_options = None
    _globals['_MONITOREDRESOURCEMETADATA_USERLABELSENTRY']._serialized_options = b'8\x01'
    _globals['_MONITOREDRESOURCEDESCRIPTOR']._serialized_start = 137
    _globals['_MONITOREDRESOURCEDESCRIPTOR']._serialized_end = 329
    _globals['_MONITOREDRESOURCE']._serialized_start = 332
    _globals['_MONITOREDRESOURCE']._serialized_end = 471
    _globals['_MONITOREDRESOURCE_LABELSENTRY']._serialized_start = 426
    _globals['_MONITOREDRESOURCE_LABELSENTRY']._serialized_end = 471
    _globals['_MONITOREDRESOURCEMETADATA']._serialized_start = 474
    _globals['_MONITOREDRESOURCEMETADATA']._serialized_end = 676
    _globals['_MONITOREDRESOURCEMETADATA_USERLABELSENTRY']._serialized_start = 627
    _globals['_MONITOREDRESOURCEMETADATA_USERLABELSENTRY']._serialized_end = 676