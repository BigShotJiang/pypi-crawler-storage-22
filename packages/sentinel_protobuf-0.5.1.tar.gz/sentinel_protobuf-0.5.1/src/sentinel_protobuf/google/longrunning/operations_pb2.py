"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'google/longrunning/operations.proto')
_sym_db = _symbol_database.Default()
from ...google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from ...google.api import client_pb2 as google_dot_api_dot_client__pb2
from ...google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.protobuf import any_pb2 as google_dot_protobuf_dot_any__pb2
from google.protobuf import descriptor_pb2 as google_dot_protobuf_dot_descriptor__pb2
from google.protobuf import duration_pb2 as google_dot_protobuf_dot_duration__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from ...google.rpc import status_pb2 as google_dot_rpc_dot_status__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n#google/longrunning/operations.proto\x12\x12google.longrunning\x1a\x1cgoogle/api/annotations.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/protobuf/any.proto\x1a google/protobuf/descriptor.proto\x1a\x1egoogle/protobuf/duration.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a\x17google/rpc/status.proto"\xa8\x01\n\tOperation\x12\x0c\n\x04name\x18\x01 \x01(\t\x12&\n\x08metadata\x18\x02 \x01(\x0b2\x14.google.protobuf.Any\x12\x0c\n\x04done\x18\x03 \x01(\x08\x12#\n\x05error\x18\x04 \x01(\x0b2\x12.google.rpc.StatusH\x00\x12(\n\x08response\x18\x05 \x01(\x0b2\x14.google.protobuf.AnyH\x00B\x08\n\x06result"#\n\x13GetOperationRequest\x12\x0c\n\x04name\x18\x01 \x01(\t"|\n\x15ListOperationsRequest\x12\x0c\n\x04name\x18\x04 \x01(\t\x12\x0e\n\x06filter\x18\x01 \x01(\t\x12\x11\n\tpage_size\x18\x02 \x01(\x05\x12\x12\n\npage_token\x18\x03 \x01(\t\x12\x1e\n\x16return_partial_success\x18\x05 \x01(\x08"~\n\x16ListOperationsResponse\x121\n\noperations\x18\x01 \x03(\x0b2\x1d.google.longrunning.Operation\x12\x17\n\x0fnext_page_token\x18\x02 \x01(\t\x12\x18\n\x0bunreachable\x18\x03 \x03(\tB\x03\xe0A\x06"&\n\x16CancelOperationRequest\x12\x0c\n\x04name\x18\x01 \x01(\t"&\n\x16DeleteOperationRequest\x12\x0c\n\x04name\x18\x01 \x01(\t"P\n\x14WaitOperationRequest\x12\x0c\n\x04name\x18\x01 \x01(\t\x12*\n\x07timeout\x18\x02 \x01(\x0b2\x19.google.protobuf.Duration"=\n\rOperationInfo\x12\x15\n\rresponse_type\x18\x01 \x01(\t\x12\x15\n\rmetadata_type\x18\x02 \x01(\t2\xaa\x05\n\nOperations\x12\x94\x01\n\x0eListOperations\x12).google.longrunning.ListOperationsRequest\x1a*.google.longrunning.ListOperationsResponse"+\xdaA\x0bname,filter\x82\xd3\xe4\x93\x02\x17\x12\x15/v1/{name=operations}\x12\x7f\n\x0cGetOperation\x12\'.google.longrunning.GetOperationRequest\x1a\x1d.google.longrunning.Operation"\'\xdaA\x04name\x82\xd3\xe4\x93\x02\x1a\x12\x18/v1/{name=operations/**}\x12~\n\x0fDeleteOperation\x12*.google.longrunning.DeleteOperationRequest\x1a\x16.google.protobuf.Empty"\'\xdaA\x04name\x82\xd3\xe4\x93\x02\x1a*\x18/v1/{name=operations/**}\x12\x88\x01\n\x0fCancelOperation\x12*.google.longrunning.CancelOperationRequest\x1a\x16.google.protobuf.Empty"1\xdaA\x04name\x82\xd3\xe4\x93\x02$"\x1f/v1/{name=operations/**}:cancel:\x01*\x12Z\n\rWaitOperation\x12(.google.longrunning.WaitOperationRequest\x1a\x1d.google.longrunning.Operation"\x00\x1a\x1d\xcaA\x1alongrunning.googleapis.com:Z\n\x0eoperation_info\x12\x1e.google.protobuf.MethodOptions\x18\x99\x08 \x01(\x0b2!.google.longrunning.OperationInfoB\xa2\x01\n\x16com.google.longrunningB\x0fOperationsProtoP\x01ZCcloud.google.com/go/longrunning/autogen/longrunningpb;longrunningpb\xa2\x02\x05GLRUN\xaa\x02\x12Google.LongRunning\xca\x02\x12Google\\LongRunningb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'google.longrunning.operations_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x16com.google.longrunningB\x0fOperationsProtoP\x01ZCcloud.google.com/go/longrunning/autogen/longrunningpb;longrunningpb\xa2\x02\x05GLRUN\xaa\x02\x12Google.LongRunning\xca\x02\x12Google\\LongRunning'
    _globals['_LISTOPERATIONSRESPONSE'].fields_by_name['unreachable']._loaded_options = None
    _globals['_LISTOPERATIONSRESPONSE'].fields_by_name['unreachable']._serialized_options = b'\xe0A\x06'
    _globals['_OPERATIONS']._loaded_options = None
    _globals['_OPERATIONS']._serialized_options = b'\xcaA\x1alongrunning.googleapis.com'
    _globals['_OPERATIONS'].methods_by_name['ListOperations']._loaded_options = None
    _globals['_OPERATIONS'].methods_by_name['ListOperations']._serialized_options = b'\xdaA\x0bname,filter\x82\xd3\xe4\x93\x02\x17\x12\x15/v1/{name=operations}'
    _globals['_OPERATIONS'].methods_by_name['GetOperation']._loaded_options = None
    _globals['_OPERATIONS'].methods_by_name['GetOperation']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02\x1a\x12\x18/v1/{name=operations/**}'
    _globals['_OPERATIONS'].methods_by_name['DeleteOperation']._loaded_options = None
    _globals['_OPERATIONS'].methods_by_name['DeleteOperation']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02\x1a*\x18/v1/{name=operations/**}'
    _globals['_OPERATIONS'].methods_by_name['CancelOperation']._loaded_options = None
    _globals['_OPERATIONS'].methods_by_name['CancelOperation']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02$"\x1f/v1/{name=operations/**}:cancel:\x01*'
    _globals['_OPERATION']._serialized_start = 295
    _globals['_OPERATION']._serialized_end = 463
    _globals['_GETOPERATIONREQUEST']._serialized_start = 465
    _globals['_GETOPERATIONREQUEST']._serialized_end = 500
    _globals['_LISTOPERATIONSREQUEST']._serialized_start = 502
    _globals['_LISTOPERATIONSREQUEST']._serialized_end = 626
    _globals['_LISTOPERATIONSRESPONSE']._serialized_start = 628
    _globals['_LISTOPERATIONSRESPONSE']._serialized_end = 754
    _globals['_CANCELOPERATIONREQUEST']._serialized_start = 756
    _globals['_CANCELOPERATIONREQUEST']._serialized_end = 794
    _globals['_DELETEOPERATIONREQUEST']._serialized_start = 796
    _globals['_DELETEOPERATIONREQUEST']._serialized_end = 834
    _globals['_WAITOPERATIONREQUEST']._serialized_start = 836
    _globals['_WAITOPERATIONREQUEST']._serialized_end = 916
    _globals['_OPERATIONINFO']._serialized_start = 918
    _globals['_OPERATIONINFO']._serialized_end = 979
    _globals['_OPERATIONS']._serialized_start = 982
    _globals['_OPERATIONS']._serialized_end = 1664