"""Client and server classes corresponding to protobuf-defined services."""
import grpc
import warnings
from ......ibc.applications.interchain_accounts.controller.v1 import query_pb2 as ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2
GRPC_GENERATED_VERSION = '1.71.0'
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower
    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(f'The grpc package installed is at version {GRPC_VERSION},' + f' but the generated code in ibc/applications/interchain_accounts/controller/v1/query_pb2_grpc.py depends on' + f' grpcio>={GRPC_GENERATED_VERSION}.' + f' Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}' + f' or downgrade your generated code using grpcio-tools<={GRPC_VERSION}.')

class QueryStub(object):
    """Query provides defines the gRPC querier service.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.InterchainAccount = channel.unary_unary('/ibc.applications.interchain_accounts.controller.v1.Query/InterchainAccount', request_serializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryInterchainAccountRequest.SerializeToString, response_deserializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryInterchainAccountResponse.FromString, _registered_method=True)
        self.Params = channel.unary_unary('/ibc.applications.interchain_accounts.controller.v1.Query/Params', request_serializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryParamsRequest.SerializeToString, response_deserializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryParamsResponse.FromString, _registered_method=True)

class QueryServicer(object):
    """Query provides defines the gRPC querier service.
    """

    def InterchainAccount(self, request, context):
        """InterchainAccount returns the interchain account address for a given owner address on a given connection
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def Params(self, request, context):
        """Params queries all parameters of the ICA controller submodule.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_QueryServicer_to_server(servicer, server):
    rpc_method_handlers = {'InterchainAccount': grpc.unary_unary_rpc_method_handler(servicer.InterchainAccount, request_deserializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryInterchainAccountRequest.FromString, response_serializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryInterchainAccountResponse.SerializeToString), 'Params': grpc.unary_unary_rpc_method_handler(servicer.Params, request_deserializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryParamsRequest.FromString, response_serializer=ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryParamsResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ibc.applications.interchain_accounts.controller.v1.Query', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ibc.applications.interchain_accounts.controller.v1.Query', rpc_method_handlers)

class Query(object):
    """Query provides defines the gRPC querier service.
    """

    @staticmethod
    def InterchainAccount(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ibc.applications.interchain_accounts.controller.v1.Query/InterchainAccount', ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryInterchainAccountRequest.SerializeToString, ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryInterchainAccountResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def Params(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ibc.applications.interchain_accounts.controller.v1.Query/Params', ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryParamsRequest.SerializeToString, ibc_dot_applications_dot_interchain__accounts_dot_controller_dot_v1_dot_query__pb2.QueryParamsResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)