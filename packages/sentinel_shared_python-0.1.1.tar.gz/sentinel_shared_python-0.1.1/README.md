Here is the reformatted guide in Markdown. I have added a few best practices—like cleaning old builds—to ensure you don't accidentally upload outdated versions of your code.

```markdown
# PyPI Release Guide

Follow these steps to build and publish the shared library to PyPI.

## 1. Install Build Tools
Ensure you have the necessary tools to package and upload your library.
```bash
pip install build twine

```

## 2. Prepare the Distribution

Clean up any previous builds and generate the new Source Distribution (`sdist`) and Built Distribution (`wheel`).

```bash
# Optional: Remove old build artifacts
rm -rf dist/ build/ *.egg-info

# Build the package
python -m build

```

## 3. Upload to PyPI

Use `twine` to securely upload the contents of the `dist/` folder to PyPI.

```bash
python -m twine upload dist/*

```

## 4. Authentication

When prompted by `twine`, use your API token credentials:

| Field | Value |
| --- | --- |
| **Username** | `__token__` |
| **Password** | `pypi-<your-secret-api-token>` |

---

> **Note:** Ensure your `pyproject.toml` version number is incremented before every release, as PyPI will reject uploads with a version that already exists.