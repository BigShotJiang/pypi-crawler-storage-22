from time import perf_counter

PROGRAM_START = perf_counter()

import os
import logging
from collections import defaultdict
from contextlib import contextmanager

import cv2
import numpy as np
from turbojpeg import TurboJPEG, TJPF_BGR, TJFLAG_FASTDCT, TJFLAG_FASTUPSAMPLE
from tflite_runtime.interpreter import Interpreter, load_delegate

cv2.setNumThreads(2)
_TJ = TurboJPEG()

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)

logger = logging.getLogger("Vela-Inference")


class Profiler(object):
    def __init__(self):
        self.totals_ms = defaultdict(float)
        self.counts = defaultdict(int)

    @contextmanager
    def timed(self, label):
        if not PROFILE:
            yield
            # Skip timing if disabled
            return
        t0 = perf_counter()
        try:
            yield
        finally:
            dt = (perf_counter() - t0) * 1000.0
            self.totals_ms[label] += dt
            self.counts[label] += 1

    def report(self, logger, num_images):
        # Build a sorted table by total time
        # items = sorted(self.totals_ms.items(), key=lambda kv: kv[1], reverse=True)
        # Build a table by processing order
        items = self.totals_ms.items()
        grand_total = sum(v for _, v in items) or 1.0
        logger.info(f"{'Stage':24s} {'Total(ms)':>12s} {'Avg/img(ms)':>12s} {'Count':>8s} {'Share':>8s}")
        for label, total in items:
            avg = total / max(num_images, 1)
            share = 100.0 * total / grand_total
            logger.info(f"{label:24s} {total:12.1f} {avg:12.1f} {self.counts[label]:8d} {share:7.1f}%")


class BoundingBox(object):
    def __init__(self, id, score, bbox, sub_id=None, sub_score=None):
        self.id = id  # Stage-1 label (e.g. 'animal')
        self.score = score  # Stage-1 confidence (0.0-1.0)
        self.bbox = bbox  # [x1,y1,x2,y2] normalized to original image
        self.sub_id = sub_id  # Stage-2 label (e.g. 'kiwi')
        self.sub_score = sub_score  # Stage-2 probability (0.0-1.0)


class DetectionModel(object):

    def __init__(self, model_file, classes, conf_thresh=0.2, iou_thresh=0.45, filter_classes=None, agnostic_nms=False,
                 max_det=1000, use_vela=False):
        """
        Creates an object for running a YOLOv5 model (optionally via Ethos-U)

        Inputs:
          - model_file: path to int8 or Vela-compiled .tflite file
          - classes: list of class names
          - conf_thresh: detection threshold
          - iou_thresh: NMS threshold
          - filter_classes: only output certain classes
          - agnostic_nms: use class-agnostic NMS
          - max_det: max number of detections
          - use_vela: use Ethos-U NPU
        """

        model_file = os.path.abspath(model_file)

        self.model_file = model_file
        self.conf_thresh = conf_thresh
        self.iou_thresh = iou_thresh
        self.filter_classes = filter_classes
        self.agnostic_nms = agnostic_nms
        self.max_det = max_det
        self.use_vela = use_vela

        self.inference_time = None
        self.nms_time = None
        self.interpreter = None
        self.classes = classes
        self.make_interpreter()
        self.get_input_size()

    def make_interpreter(self):
        """
        Loads a TFLite model and creates an interpreter that interacts with the Ethos-U NPU
        """

        # Load the model
        if self.use_vela:
            # Run the Vela-compiled tflite on Ethos-U NPU
            self.interpreter = Interpreter(
                model_path=self.model_file,
                experimental_delegates=[load_delegate('/usr/lib/libethosu_delegate.so')]
            )
        else:
            # Run the int8 tflite on CPU
            self.interpreter = Interpreter(model_path=self.model_file)

        # Allocate tensors
        self.interpreter.allocate_tensors()

        self.input_details = self.interpreter.get_input_details()
        self.output_details = self.interpreter.get_output_details()

        logger.debug(self.input_details)
        logger.debug(self.output_details)

        self.input_dtype = self.input_details[0]['dtype']
        self.input_scale = self.input_details[0]['quantization'][0]
        self.input_zero = self.input_details[0]['quantization'][1]

        self.output_dtype = self.output_details[0]['dtype']
        self.output_scale = self.output_details[0]['quantization'][0]
        self.output_zero = self.output_details[0]['quantization'][1]

        # If the model isn't quantized then these should be zero
        # Check against small epsilon to avoid comparing float/int
        if self.input_scale < 1e-9:
            self.input_scale = 1.0

        if self.output_scale < 1e-9:
            self.output_scale = 1.0

        # logger.info("Input scale: {}".format(self.input_scale))
        # logger.info("Input zero: {}".format(self.input_zero))
        # logger.info("Output scale: {}".format(self.output_scale))
        # logger.info("Output zero: {}".format(self.output_zero))

        logger.info("Successfully loaded {}".format(self.model_file))

    def get_input_size(self):
        """
        Returns the expected size of the input image tensor
        """

        if self.interpreter is not None:
            self.input_size = self.input_details[0]['shape']
            logger.info("Detector input shape: {}".format(self.input_size))
            return self.input_size
        else:
            logger.warning("Interpreter is not yet loaded")

    def predict(self, image_buffer):
        """
        Runs the full inference pipeline on an input image

        Input:
            image in BGR format with shape (H, W, 3), dtype uint8

        Returns:
            A list of `BoundingBox` objects, where each item contains:
                - class_name : str
                - confidence : float in [0, 1]
                - bbox : List[float] as [x1, y1, x2, y2] normalized to the original image dimensions [0, 1]
        """

        # Model input size (e.g. 640)
        size = int(self.input_size[1])
        # Image dimensions
        h, w = image_buffer.shape[:2]

        with prof.timed("resize_letterbox"):
            # Letterbox to size x size, never upscale
            scale = min(1.0, size / w)
            nw, nh = int(round(w * scale)), int(round(h * scale))
            # Resize image
            resized = image_buffer if scale == 1.0 else cv2.resize(image_buffer, (nw, nh), interpolation=cv2.INTER_AREA)
            # Create a square canvas filled with padding color (114,114,114)
            canvas_bgr = np.full((size, size, 3), 114, dtype=np.uint8)
            # Compute padding to center the resized image
            dx = (size - nw) // 2
            dy = (size - nh) // 2
            padding = [dx / size, dy / size]
            # Paste the resized image onto the canvas
            canvas_bgr[dy:dy + nh, dx:dx + nw] = resized

        with prof.timed("bgr2rgb"):
            canvas_rgb = cv2.cvtColor(canvas_bgr, cv2.COLOR_BGR2RGB)

        # with prof.timed("normalize"):
        #    canvas_rgb = canvas_rgb.astype(np.float32) / 255.0

        with prof.timed("vela_inference"):
            prediction = self.forward(canvas_rgb)

        with prof.timed("postprocess"):
            detection = self.process_predictions(prediction[0], padding)

        return detection

    def forward(self, x, with_nms=True):
        """
        Invokes the TFLite interpreter and applies NMS on model output

        Inputs:
            x: image tensor (H, W, C) NHWC, dtype uint8
            with_nms: apply NMS on output
        Returns:
            prediction array (with or without NMS applied)
        """

        # Transpose if C, H, W
        # if x.shape[0] == 3:
        #    x = x.transpose((1,2,0))

        # Convert to float32
        # x = x.astype('float32')

        # Scale input, conversion is: real = (int_8 - zero)*scale
        # x = (x/self.input_scale) + self.input_zero
        # x = x[np.newaxis].astype(np.uint8)

        # Add batch dimension (NHWC)
        x = x[np.newaxis, ...]

        # Set input tensor
        self.interpreter.set_tensor(self.input_details[0]['index'], x)

        # Run inference
        self.interpreter.invoke()

        # Dequantize and scale output
        result = (self.interpreter.get_tensor(self.output_details[0]['index']).astype(
            'float32') - self.output_zero) * self.output_scale

        if with_nms:
            nms_result = self.non_max_suppression(result, self.conf_thresh, self.iou_thresh, self.filter_classes,
                                                  self.agnostic_nms, max_det=self.max_det)
            return nms_result

        else:
            return result

    def process_predictions(self, detection, padding):
        """
        Processes predictions and outputs confidence scores with bounding boxes in normalized coordinates
        """

        output = []

        if len(detection):
            # Write results
            for *xyxy, conf, cls in reversed(detection):
                # Append instances to list
                xyxy = self.map_bbox(xyxy, padding)
                # output.append(BoundingBox(self.classes[int(cls)], round(conf*100,3), [round(x,3) for x in xyxy]))
                output.append(BoundingBox(self.classes[int(cls)], round(conf, 3), [round(x, 3) for x in xyxy]))

        return output

    def map_bbox(self, xyxy, padding):
        # Assuming xyxy is [x_min, y_min, x_max, y_max] in normalized coordinates
        # Adjust the bounding box by the normalized padding amount

        # Extract the bounding box coordinates
        x_min, y_min, x_max, y_max = xyxy

        # Adjust the x-coordinates for horizontal padding
        x_min = (x_min - padding[0]) / (1 - 2 * padding[0])
        x_max = (x_max - padding[0]) / (1 - 2 * padding[0])

        # Adjust the y-coordinates for vertical padding
        y_min = (y_min - padding[1]) / (1 - 2 * padding[1])
        y_max = (y_max - padding[1]) / (1 - 2 * padding[1])

        # Clip the coordinates to be within [0, 1]
        x_min = max(0, min(x_min, 1))
        y_min = max(0, min(y_min, 1))
        x_max = max(0, min(x_max, 1))
        y_max = max(0, min(y_max, 1))

        # Return the adjusted bounding box
        return [x_min, y_min, x_max, y_max]

    def xywh2xyxy(self, x):
        # Convert nx4 boxes from [x, y, w, h] to [x1, y1, x2, y2] where xy1=top-left, xy2=bottom-right
        y = np.copy(x)
        y[:, 0] = x[:, 0] - x[:, 2] / 2  # Top left x
        y[:, 1] = x[:, 1] - x[:, 3] / 2  # Top left y
        y[:, 2] = x[:, 0] + x[:, 2] / 2  # Bottom right x
        y[:, 3] = x[:, 1] + x[:, 3] / 2  # Bottom right y
        return y

    def calculate_iou(self, bbox1, bbox2):
        x1 = max(bbox1[0], bbox2[0])
        y1 = max(bbox1[1], bbox2[1])
        x2 = min(bbox1[2], bbox2[2])
        y2 = min(bbox1[3], bbox2[3])

        inter_area = max(0, x2 - x1) * max(0, y2 - y1)

        bbox1_area = (bbox1[2] - bbox1[0]) * (bbox1[3] - bbox1[1])
        bbox2_area = (bbox2[2] - bbox2[0]) * (bbox2[3] - bbox2[1])

        iou = inter_area / (bbox1_area + bbox2_area - inter_area)

        return iou

    def non_max_suppression(self, prediction, conf_thres=0.4, iou_thres=0.2, classes=None, labels=(), max_det=30):

        nc = prediction.shape[2] - 5  # Number of classes
        xc = prediction[..., 4] > conf_thres  # Candidates

        # Settings
        max_nms = 500  # Maximum number of boxes

        output = [np.zeros((0, 6))] * prediction.shape[0]

        for xi, x in enumerate(prediction):  # Image index, image inference
            # Apply constraints
            # x[((x[..., 2:4] < min_wh) | (x[..., 2:4] > max_wh)).any(1), 4] = 0  # width-height
            x = x[xc[xi]]  # Confidence

            # Cat apriori labels if autolabelling
            if labels and len(labels[xi]):
                l = labels[xi]
                v = np.zeros((len(l), nc + 5))
                v[:, :4] = l[:, 1:5]  # Box
                v[:, 4] = 1.0  # Conf
                v[range(len(l)), l[:, 0].long() + 5] = 1.0  # Cls
                x = np.concatenate((x, v), 0)

            # If none remain process next image
            if not x.shape[0]:
                continue

            # Compute conf
            x[:, 5:] *= x[:, 4:5]  # Conf = obj_conf * cls_conf

            # Box (center x, center y, width, height) to (x1, y1, x2, y2)
            box = self.xywh2xyxy(x[:, :4])

            # Detections matrix nx6 (xyxy, conf, cls)
            conf = np.amax(x[:, 5:], axis=1, keepdims=True)
            j = np.argmax(x[:, 5:], axis=1).reshape(conf.shape)
            x = np.concatenate((box, conf, j.astype(float)), axis=1)[conf.flatten() > conf_thres]

            # Filter by class
            if classes is not None:
                x = x[(x[:, 5:6] == np.array(classes)).any(1)]

            # Check shape
            n = x.shape[0]  # Number of boxes
            if not n:  # No boxes
                continue
            elif n > max_nms:  # Excess boxes
                x = x[x[:, 4].argsort()[::-1]][:max_nms]  # Sort by confidence

            # Batched NMS
            unordered_dets, unordered_scores = x[:, :4], x[:, 4]  # Boxes (offset by class), scores

            ordered_score_index = unordered_scores.argsort()[::-1]  # Get higher scores first

            dets = [list(unordered_dets[i]) for i in ordered_score_index]

            # Calculate IoU for each pair of bounding boxes
            keep_index = []

            while len(dets) > 0:
                base_det = dets[0]

                # Remove base_det from dets (as it is already being kept)
                removal_list = [0]

                # Find index of base_det in original order
                base_det_index = np.where(np.all(unordered_dets == base_det, axis=1))[0][0]
                keep_index.append(base_det_index)

                iou_scores = []

                for j in range(1, len(dets)):
                    iou = self.calculate_iou(base_det, dets[j])
                    iou_scores.append(iou)
                    if iou > iou_thres:
                        removal_list.append(j)

                dets = [dets[i] for i in range(len(dets)) if i not in removal_list]

            # Find index of original order
            i = keep_index
            # Limit detections
            if len(i) > max_det:
                i = i[:max_det]

            output[xi] = x[i]

        return output


class ClassifierModel(object):

    def __init__(self, model_file, classes, color="RGB", size=224, use_vela=False):
        """
        Creates an object for running a TFLite classification model (optionally via Ethos-U)

        Inputs:
          - model_file: path to int8 or Vela-compiled .tflite file
          - classes: list of class names
          - color: 'RGB' or 'L' (grayscale)
          - size: square resize target (if None, uses model input H/W)
          - use_vela: use Ethos-U NPU
        """

        model_file = os.path.abspath(model_file)

        self.model_file = model_file
        self.classes = classes
        self.color = color
        self.size = size
        self.use_vela = use_vela

        # For now this only handles RGB and grayscale (L)
        self.n_channels = 3 if self.color == 'RGB' else 1

        self.interpreter = None
        self.input_details = None
        self.output_details = None
        self.input_scale = 1.0
        self.input_zero_point = 0
        self.output_scale = 1.0
        self.output_zero_point = 0

        self.make_interpreter()
        self.get_input_size()

    def make_interpreter(self):
        """
        Loads a TFLite model and creates an interpreter that interacts with the Ethos-U NPU
        """

        # Load the model
        if self.use_vela:
            # Run the Vela-compiled tflite on Ethos-U NPU
            self.interpreter = Interpreter(
                model_path=self.model_file,
                experimental_delegates=[load_delegate('/usr/lib/libethosu_delegate.so')]
            )
        else:
            # Run the int8 tflite on CPU
            self.interpreter = Interpreter(model_path=self.model_file)

        # Allocate tensors
        self.interpreter.allocate_tensors()

        self.input_details = self.interpreter.get_input_details()
        self.output_details = self.interpreter.get_output_details()

        logger.debug(self.input_details)
        logger.debug(self.output_details)

        self.input_scale, self.input_zero_point = self.input_details[0]['quantization']
        self.output_scale, self.output_zero_point = self.output_details[1]['quantization']

        logger.info("Successfully loaded classifier {}".format(self.model_file))

    def get_input_size(self):
        """
        Returns the expected size of the input image tensor
        """

        if self.interpreter is not None:
            self.input_size = self.input_details[0]['shape']
            logger.info("Classifier input shape: {}".format(self.input_size))
            return self.input_size
        else:
            logger.warning("Interpreter is not yet loaded")

    def classify(self, image_crop):
        """
        Classify an image crop using OpenCV preprocessing (input assumed BGR)

        Returns:
            class_label (string): Class label predicted by the model
            class_prob (float): Probability associated with the predicted class
        """

        # Model input size
        size = int(self.size)
        # Image crop size
        h, w = image_crop.shape[:2]

        # Resize so the long side becomes `size`
        scale = size / max(w, h)
        nw, nh = int(round(w * scale)), int(round(h * scale))
        resized = cv2.resize(image_crop, (nw, nh), interpolation=cv2.INTER_AREA)

        # Create a square black canvas and center-paste the resized crop
        canvas_crop = np.full((size, size, 3), 0, dtype=np.uint8)
        dx = (size - nw) // 2
        dy = (size - nh) // 2
        canvas_crop[dy:dy + nh, dx:dx + nw] = resized

        # Convert image to RGB or grayscale depending on model input
        if self.n_channels == 3:
            image = cv2.cvtColor(canvas_crop, cv2.COLOR_BGR2RGB)
        elif self.n_channels == 1:
            image = cv2.cvtColor(canvas_crop, cv2.COLOR_BGR2GRAY)

        # Cast to float32 explicitly (optional but consistent)
        # image = image.astype(np.float32)

        # Normalize
        image = self.normalize_image(image)

        # Quantize to int8
        image = (image / self.input_scale + self.input_zero_point)

        # Reshape to 1,H,W,C
        # (For grayscale, this will reshape (H,W) -> (1,H,W,1) since self.n_channels==1)
        image = image.astype(np.int8).reshape(1, self.size, self.size, self.n_channels)

        # Set input tensor
        self.interpreter.set_tensor(self.input_details[0]['index'], image)
        # Run inference
        self.interpreter.invoke()

        # Scale output
        output_data = self.interpreter.get_tensor(self.output_details[1]['index']).astype(np.float32)

        # Apply class label
        class_id = np.argmax(output_data, axis=1)[0]
        class_label = self.classes[class_id]

        # Dequantize logits
        dequantized_logits = self.output_scale * (output_data - self.output_zero_point)
        # Calculate class probability
        class_prob = self.softmax(dequantized_logits, axis=1)[0][class_id]

        return class_label, class_prob

    def normalize_image(self, image, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]):
        image = image / 255.0

        if len(image.shape) == 3:  # RGB image
            # Normalize each channel
            image = (image - np.array(mean)) / np.array(std)
        elif len(image.shape) == 2:  # Grayscale image
            # Normalize using the mean and std of all channels
            image = (image - np.mean(mean)) / np.mean(std)

        return image

    def softmax(self, x, axis=None):
        # Shift x for numerical stability and convert to float64 for precision
        shift_x = x - np.max(x, axis=axis, keepdims=True)
        exps = np.exp(shift_x)

        return exps / np.sum(exps, axis=axis, keepdims=True)


def crop_from_bbox(image_buffer, bbox, expand=0.0):
    """
    Crops a region from an OpenCV image using a normalized bbox

    Inputs:
        image_buffer (np.ndarray): Input image in OpenCV (H, W, C) or (H, W)
        bbox (list): [x1, y1, x2, y2] in normalized [0,1] relative to the original image
        expand (float): Optional expansion factor (e.g., 0.05 = 5%)

    Returns:
        np.ndarray: Cropped image region
    """

    H, W = image_buffer.shape[:2]
    x1, y1, x2, y2 = [float(v) for v in bbox]

    # Expand around center
    if expand > 0.0:
        cx = (x1 + x2) * 0.5
        cy = (y1 + y2) * 0.5
        w = (x2 - x1) * (1.0 + expand)
        h = (y2 - y1) * (1.0 + expand)
        x1, y1, x2, y2 = cx - w / 2.0, cy - h / 2.0, cx + w / 2.0, cy + h / 2.0

    # Convert to pixel coords and clip
    px1 = max(0, min(int(round(x1 * W)), W - 1))
    py1 = max(0, min(int(round(y1 * H)), H - 1))
    px2 = max(0, min(int(round(x2 * W)), W))
    py2 = max(0, min(int(round(y2 * H)), H))

    # Ensure at least 1px
    if px2 <= px1: px2 = min(W, px1 + 1)
    if py2 <= py1: py2 = min(H, py1 + 1)

    # Crop with NumPy slicing
    image_crop = image_buffer[py1:py2, px1:px2]

    return image_crop


def draw_boxes(image_buffer, detections, save_conf=True, class_colors=None, default_color=(0, 255, 0)):
    """
    Draws detections where bbox is mapped back to the ORIGINAL image size
    bbox format: [x1, y1, x2, y2], each in [0,1]
    Colors can be customized per class via class_colors (label -> (B,G,R))
    """

    if class_colors is None:
        class_colors = {}

    H, W = image_buffer.shape[:2]

    for detection in detections:
        # Prefer stage-2 classification label
        if detection.sub_id is not None:
            label = detection.sub_id
        else:
            label = detection.id
        # Set per class bounding box color
        color = class_colors.get(label, default_color)
        # Scale normalized bounding box to original image pixels
        x1 = int(detection.bbox[0] * W);
        y1 = int(detection.bbox[1] * H)
        x2 = int(detection.bbox[2] * W);
        y2 = int(detection.bbox[3] * H)
        # Draw bounding box
        cv2.rectangle(image_buffer, (x1, y1), (x2, y2), color, 3)

        if save_conf:
            # Prefer stage-2 class probability
            if detection.sub_score is not None:
                confidence = detection.sub_score
            else:
                confidence = detection.score / 100.0 if detection.score > 1.0 else detection.score
            label = f"{label} {confidence:.2f}"

        # Measure text
        (tw, th), base = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
        y0 = max(0, y1 - th - 6)
        # Draw text box
        cv2.rectangle(image_buffer, (x1 - 2, y0), (x1 + tw + 8, y0 + th + 6), color, -1)
        # Draw label text
        cv2.putText(image_buffer, label, (x1 + 4, y0 + th + 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2, cv2.LINE_AA)

    return image_buffer



def execute():
    PROFILE = True
    STAGES = 2  # Set to 1 to disable classifier stage
    DETECTOR_PATH = "/mnt/sdcard/models/mdv51-tiny_vela.tflite"  # Vela-compiled detection model for Ethos-U
    CLASSIFIER_PATH = "/mnt/sdcard/models/6058_vela.tflite"  # Vela-compiled classifier model for Ethos-U

    STAGE_1_CLASSES = ['animal', 'person', 'vehicle']
    STAGE_2_CLASSES = ['bird',
                       'cervidae',
                       'cow',
                       'dog',
                       'felidae',
                       'hare_rabbit',
                       'hedgehog',
                       'kiwi',
                       'mustelidae',
                       'nestor_spp',
                       'other_rail',
                       'other_ungulate',
                       'penguin',
                       'pig',
                       'possum',
                       'rodentia',
                       'sealion',
                       'wallaby',
                       'weka']

    CLASS_COLORS = {
        # "felidae": (0, 165, 255),   # Orange
        "rodentia": (0, 0, 255),  # Red
    }
    DEFAULT_BOX_COLOR = (0, 255, 0)  # Green

    INPUT_DIR = "/mnt/sdcard/backlog"
    OUTPUT_DIR = "/mnt/sdcard/data"
    APPEND_CLASS_TO_FILENAME = False
    TARGET_WIDTH = 2000

    # Init detection model with Vela
    detector = DetectionModel(
        DETECTOR_PATH,
        STAGE_1_CLASSES,
        conf_thresh=0.50,
        iou_thresh=0.45,
        agnostic_nms=False,
        max_det=300,
        use_vela=True,
    )

    # Init classifier model with Vela (only if 2-stage selected)
    if STAGES > 1:
        # Init classifier model with Vela
        classifer = ClassifierModel(
            CLASSIFIER_PATH,
            STAGE_2_CLASSES,
            color="RGB",
            size=224,
            use_vela=True,
        )

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    loading_time = (perf_counter() - PROGRAM_START) * 1000  # ms
    logger.info(f"Loading time: {loading_time:.0f} ms")

    # Timing variables
    prof = Profiler()
    per_image_ms = []
    start_time = perf_counter()

    # Collect files
    files = []

    for file in sorted(os.listdir(INPUT_DIR)):
        path = os.path.join(INPUT_DIR, file)
        if os.path.isfile(path) and path.lower().endswith((".jpg", ".jpeg")):
            files.append(path)

    if not files:
        logger.warning(f"No images found in '{INPUT_DIR}'")
        raise SystemExit(0)

    for image_path in files:
        t0 = perf_counter()

        if APPEND_CLASS_TO_FILENAME:
            image_label = "empty"
            image_score = -1.0

        logger.info(f"Processing: {os.path.basename(image_path)}")

        with prof.timed("read_file"):
            with open(image_path, "rb") as file:
                buffer = file.read()

        with prof.timed("header_peek"):
            # Get image dimensions without decoding
            width, height, subsamp, colorspace = _TJ.decode_header(buffer)

            if width > TARGET_WIDTH * 4:
                # Quarter scale
                scaling = (1, 4)
            elif width > TARGET_WIDTH * 2:
                # Half scale
                scaling = (1, 2)
            else:
                # Full scale
                scaling = (1, 1)

        # Fast JPEG decode with TurboJPEG (BGR)
        with prof.timed("jpeg_decode"):
            image_buffer = _TJ.decode(
                buffer, pixel_format=TJPF_BGR,
                scaling_factor=scaling,
                flags=TJFLAG_FASTDCT | TJFLAG_FASTUPSAMPLE
            )

        # Run detection model over image
        detections = detector.predict(image_buffer)

        for index, detection in enumerate(detections[:5]):

            if STAGES > 1 and detection.id == "animal":
                with prof.timed("classification"):
                    # Crop the image
                    image_crop = crop_from_bbox(image_buffer, detection.bbox, expand=0.00)
                    # Run classifier model over image crop
                    sub_label, sub_prob = classifer.classify(image_crop)  # Returns (class_name, probability)
                    detection.sub_id = sub_label
                    detection.sub_score = sub_prob

            class_label = detection.sub_id if getattr(detection, "sub_id", None) is not None else detection.id
            class_score = detection.sub_score if getattr(detection, "sub_score", None) is not None else detection.score
            logger.info(f"Detected class: {class_label}, score: {class_score:.2f}, bbox: {detection.bbox}")

            if APPEND_CLASS_TO_FILENAME:
                # Update image label with class of highest confidence
                if class_score > image_score:
                    image_label = class_label

        # Draw boxes on full image (OpenCV)
        with prof.timed("draw_boxes"):
            image_buffer = draw_boxes(image_buffer, detections, save_conf=True, class_colors=CLASS_COLORS,
                                      default_color=DEFAULT_BOX_COLOR)

        # Save with OpenCV
        with prof.timed("jpeg_encode"):
            ok, jpg_bytes = cv2.imencode(".jpg", image_buffer, [cv2.IMWRITE_JPEG_QUALITY, 85])
            if not ok:
                logger.warning("cv2.imencode failed")
                continue

        with prof.timed("write_file"):
            file_name, ext = os.path.splitext(os.path.basename(image_path))

            if APPEND_CLASS_TO_FILENAME:
                output_file = f"{file_name}_{image_label}{ext}"
            else:
                output_file = f"{file_name}{ext}"
            output_path = os.path.join(OUTPUT_DIR, output_file)

            with open(output_path, "wb") as f:
                jpg_bytes.tofile(f)

        # logger.info(f"Output: {output_path}")

        # Per-image timing
        process_time = (perf_counter() - t0) * 1000.0
        per_image_ms.append(process_time)
        logger.info(f"{process_time:.0f} ms")

    # Overall timing summary
    total_time = perf_counter() - start_time
    avg_ms = sum(per_image_ms) / len(per_image_ms)
    logger.info(
        f"Processed {len(files)} image(s) in {total_time:.2f} seconds, (average {avg_ms:.0f} ms/image, {len(files) / total_time:.2f} images/second)")
    prof.report(logger, num_images=len(files))