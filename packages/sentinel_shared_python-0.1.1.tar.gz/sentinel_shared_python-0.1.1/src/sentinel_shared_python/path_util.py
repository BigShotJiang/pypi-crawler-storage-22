def get_path_to_backlog():
    return "/mnt/sdcard/backlog"

def get_path_to_db():
    return "/mnt/sdcard/local.db"
