def greet(name):
    return f"Hello, {name}! This is from the shared library."