import os
import shutil
from pathlib import Path

def creer_fichier(chemin, contenu):
    """Crée un fichier avec le contenu spécifié"""
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    with open(chemin, 'w', encoding='utf-8') as f:
        f.write(contenu)

def copier_dossier(source, destination):
    """Copie récursivement un dossier"""
    source = Path(source)
    destination = Path(destination)
    
    destination.mkdir(parents=True, exist_ok=True)
    
    for item in source.iterdir():
        # Skip .gitignore and other hidden files that might have encoding issues
        if item.name.startswith('.'):
            continue
            
        dest_item = destination / item.name
        if item.is_dir():
            copier_dossier(item, dest_item)
        else:
            # Use shutil.copy2 to preserve metadata and handle binary files
            try:
                shutil.copy2(item, dest_item)
            except Exception as e:
                print(f"⚠️ Erreur lors de la copie de {item.name}: {e}")