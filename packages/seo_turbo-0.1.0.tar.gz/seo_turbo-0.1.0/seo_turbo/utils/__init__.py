﻿# Utils initialization
