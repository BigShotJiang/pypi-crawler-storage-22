"""Package to customize the display of the widgets.

`IpyvuetfyWidget` and ìpyleaflet.Map` are not working together natively. This package provide helpers, css, js and js workaround to help user build safe application including both widgets and maps.
"""
