"""Logger module for SEPAL UI."""

from .logger import log, setup_logging  # noqa: I
