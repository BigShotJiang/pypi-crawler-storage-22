"""Wrapper package for the ``Model`` object."""

from .model import *
