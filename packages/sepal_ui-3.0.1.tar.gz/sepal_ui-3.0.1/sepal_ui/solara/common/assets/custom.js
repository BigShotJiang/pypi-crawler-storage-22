// Set default theme to dark mode when the page loads
function setDarkTheme() {
  localStorage.setItem(":solara:theme.variant", '"dark"');
}
setDarkTheme();
