Panel app
=========

.. warning::

    The english documentation of the module have not been set.

.. tip::

    Please open an issue on their repository : https://github.com/12rambau/sepal_ui/issues/new
