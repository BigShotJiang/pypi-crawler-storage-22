"""Wrapper package for the ``Translator`` object."""

from .translator import *
