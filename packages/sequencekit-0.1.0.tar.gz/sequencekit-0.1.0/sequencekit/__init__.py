"""
sequencekit
--------------

Lightweight utility functions for working with
strings, lists, and tuples.
"""

from .core import (
    frequency,
    contains_duplicates,
    uniqueonly,
    duplicates,
    most_frequent,
    least_frequent,
    remove_duplicates,
)

__all__ = [
    "frequency",
    "contains_duplicates",
    "uniqueonly",
    "duplicates",
    "most_frequent",
    "least_frequent",
    "remove_duplicates",
]

__version__ = "0.1.0"