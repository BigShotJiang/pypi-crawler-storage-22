from ._internals import (
    _validate_sequence,
    _frequency_map,
    _convert_output,
)

def frequency(sequence):
    """
    Return a dictionary mapping each element in the sequence
    to its number of occurrences.

    Parameters
    ----------
    sequence : str | list | tuple

    Returns
    -------
    dict
    """
    _validate_sequence(sequence)
    return dict(_frequency_map(sequence))

def contains_duplicates(sequence):
    """
    Return True if the sequence contains duplicate elements, otherwise return False.

    Parameters
    ----------
    sequence : str | list | tuple

    Returns
    -------
    bool
    """
    _validate_sequence(sequence)

    seen = set() 

    for item in sequence: 
        if item in seen:
            return True 
        seen.add(item)
    
    return False 

def uniqueonly(sequence, out="list"):
    """
    Return elements that appear exactly once in the sequence,
    preserving original order.

    Parameters
    ----------
    sequence : str | list | tuple

    Returns
    -------
    list | tuple | str
    """
    _validate_sequence(sequence)

    freq = _frequency_map(sequence)
    result = [item for item in sequence if freq[item] == 1]

    return _convert_output(result, out)

def duplicates(sequence, out="list"):
    """
    Return elements that appear more than once in the sequence.
    Each duplicate appears only once in the result, preserving
    order of first duplicate occurrence.

    Parameters
    ----------
    sequence : str | list | tuple

    Returns
    -------
    list | tuple | str
    """
    _validate_sequence(sequence)

    seen = set()
    added = set() 
    result = []

    for item in sequence:
        if item in seen:
            if item not in added:
                result.append(item)
                added.add(item)
        else:
            seen.add(item)

    return _convert_output(result, out)

def most_frequent(sequence):
    """
    Return the element with the highest frequency in the sequence.
    If multiple elements share the same maximum frequency,
    the first occurring element is returned.

    Parameters
    ----------
    sequence : str | list | tuple

    Returns
    -------
    Any
        The most frequent element.
    """
    _validate_sequence(sequence)

    if not sequence:
        raise ValueError(
            "most_frequent() arg is an empty sequence"
        )
    
    freq = _frequency_map(sequence)
    return max(freq, key=freq.get)

def least_frequent(sequence):
    """
    Return the element with the lowest frequency in the sequence.
    If multiple elements share the same minimum frequency,
    the first occurring element is returned.

    Parameters
    ----------
    sequence : str | list | tuple

    Returns
    -------
    Any
        The least frequent element.
    """
    _validate_sequence(sequence)

    if not sequence:
        raise ValueError(
            "least_frequent() arg is an empty sequence"
        )
    
    freq = _frequency_map(sequence)
    return min(freq, key=freq.get)

def remove_duplicates(sequence, out="list"):
    """
    Return elements in order of first occurrence,
    removing duplicate entries.

    Parameters
    ----------
    sequence : str | list | tuple

    Returns
    -------
    list | tuple | str
    """
    _validate_sequence(sequence)

    seen = set() 
    result = [] 

    for item in sequence: 
        if item not in seen: 
            result.append(item)
            seen.add(item)
    
    return _convert_output(result, out)