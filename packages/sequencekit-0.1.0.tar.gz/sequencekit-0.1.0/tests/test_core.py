import pytest

from sequencekit import (
    frequency,
    contains_duplicates,
    uniqueonly,
    duplicates,
    most_frequent,
    least_frequent,
    remove_duplicates,
)


# ==========================
# frequency()
# ==========================

def test_frequency_string():
    assert frequency("banana") == {"b": 1, "a": 3, "n": 2}


def test_frequency_list():
    assert frequency([1, 2, 2, 3]) == {1: 1, 2: 2, 3: 1}


def test_frequency_tuple():
    assert frequency((1, 1, 2)) == {1: 2, 2: 1}


def test_frequency_empty():
    assert frequency("") == {}
    assert frequency([]) == {}
    assert frequency(()) == {}


def test_frequency_invalid_type():
    with pytest.raises(TypeError):
        frequency(123)


# ==========================
# contains_duplicates()
# ==========================

def test_contains_duplicates_true():
    assert contains_duplicates("banana") is True
    assert contains_duplicates([1, 2, 1]) is True


def test_contains_duplicates_false():
    assert contains_duplicates("abc") is False
    assert contains_duplicates([1, 2, 3]) is False


def test_contains_duplicates_empty():
    assert contains_duplicates("") is False


# ==========================
# uniqueonly()
# ==========================

def test_uniqueonly_basic():
    assert uniqueonly("banana") == ["b"]
    assert uniqueonly([1, 2, 2, 3]) == [1, 3]


def test_uniqueonly_output_types():
    assert uniqueonly("banana", out="tuple") == ("b",)
    assert uniqueonly("banana", out="str") == "b"


def test_uniqueonly_empty():
    assert uniqueonly("") == []


def test_uniqueonly_invalid_out():
    with pytest.raises(ValueError):
        uniqueonly("abc", out="invalid")


def test_uniqueonly_str_conversion_failure():
    with pytest.raises(TypeError):
        uniqueonly([1, 2, 3], out="str")


# ==========================
# duplicates()
# ==========================

def test_duplicates_basic():
    assert duplicates("banana") == ["a", "n"]
    assert duplicates([1, 2, 2, 3, 3]) == [2, 3]


def test_duplicates_no_duplicates():
    assert duplicates("abc") == []


def test_duplicates_output_types():
    assert duplicates("banana", out="tuple") == ("a", "n")
    assert duplicates("banana", out="str") == "an"


def test_duplicates_invalid_out():
    with pytest.raises(ValueError):
        duplicates("banana", out="invalid")


# ==========================
# most_frequent()
# ==========================

def test_most_frequent_basic():
    assert most_frequent("banana") == "a"
    assert most_frequent([1, 2, 2, 3]) == 2


def test_most_frequent_tie_returns_first():
    assert most_frequent("aabb") == "a"
    assert most_frequent([1, 2, 1, 2]) == 1


def test_most_frequent_empty():
    with pytest.raises(ValueError):
        most_frequent("")


# ==========================
# least_frequent()
# ==========================

def test_least_frequent_basic():
    assert least_frequent("banana") == "b"
    assert least_frequent([1, 2, 2, 3, 3]) == 1


def test_least_frequent_tie_returns_first():
    assert least_frequent("aabbcc") == "a"
    assert least_frequent([1, 2, 3]) == 1


def test_least_frequent_empty():
    with pytest.raises(ValueError):
        least_frequent([])


# ==========================
# remove_duplicates()
# ==========================

def test_remove_duplicates_basic():
    assert remove_duplicates("banana") == ["b", "a", "n"]
    assert remove_duplicates([1, 2, 1, 3]) == [1, 2, 3]


def test_remove_duplicates_output_types():
    assert remove_duplicates("banana", out="tuple") == ("b", "a", "n")
    assert remove_duplicates("banana", out="str") == "ban"


def test_remove_duplicates_empty():
    assert remove_duplicates("") == []


def test_remove_duplicates_invalid_out():
    with pytest.raises(ValueError):
        remove_duplicates("abc", out="invalid")