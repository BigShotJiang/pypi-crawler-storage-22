"""
Empty test file
"""

from __future__ import annotations

import serialpacker  # noqa:F401 pylint: disable=unused-import


def test_nothing():
    """
    Empty test
    """
