"""
SerpApi Python Client
"""

__version__ = "0.1.5"
