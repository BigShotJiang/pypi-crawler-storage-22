"""
CLI entry point for the documentation server.
"""

from .main import main

if __name__ == "__main__":
    main()
