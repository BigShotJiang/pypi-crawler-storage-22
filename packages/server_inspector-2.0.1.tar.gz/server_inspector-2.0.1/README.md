# server-inspector

Hardware detection and inventory tool for home servers.

## Purpose

Automatically detects and inventories server hardware:

- CPU (model, cores, virtualization support)
- Memory (size, type, speed)
- Storage devices (disks, NVMe, SSDs with identifiers)
- Network interfaces (NICs, MACs, IPs)
- GPU (discrete graphics cards)
- Motherboard and IPMI/BMC
- System capabilities (UEFI, boot mode)

## Usage

```bash
# Inspect server and save with server name
sudo server-inspector white
# → outputs server-specs-white.json

# Multiple servers on same USB
sudo server-inspector white
sudo server-inspector black
# → server-specs-white.json, server-specs-black.json

# Override output path
sudo server-inspector white --output /custom/path.json
```

## Output

JSON file containing:

- `collection_info` - timestamp, version, server name
- `server` - CPU, memory info
- `storage` - disks with serial/WWN identifiers
- `network` - interfaces with MACs and IPs
- `gpu` - graphics cards
- `motherboard` - vendor, model
- `ipmi` - BMC info if present
- `system` - boot mode, virtualization

## Requirements

- Must run as root for full hardware access
- Python 3.13+

## Installation

```bash
uv sync
```

## Integration

Designed to work with:

- [proxmox-wizard](https://github.com/casaeureka/proxmox-wizard) - imports specs for automated Proxmox setup
- [live-usb-helper](https://github.com/casaeureka/live-usb-helper) - stores specs on USB persistence

## License

AGPL-3.0-or-later

## Support

[![GitHub Sponsors](https://img.shields.io/badge/GitHub-Sponsor-ea4aaa?logo=github)](https://github.com/sponsors/W3Max)
[![Ko-fi](https://img.shields.io/badge/Ko--fi-Support-ff5f5f?logo=ko-fi)](https://ko-fi.com/w3max)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-ffdd00?logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/w3max)
