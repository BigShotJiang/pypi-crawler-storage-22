"""PCI and hardware parsing utilities"""
