from __future__ import annotations
from sqlalchemy.orm import declarative_base
from service_forge.utils.register import Register

_Base = declarative_base()

class SfDbBase(_Base):
    __abstract__ = True
    
    def __init_subclass__(cls) -> None:
        if cls.__name__ not in ["SfDbBase"]:
            sf_dbbase_register.register(cls.__name__, cls)
        return super().__init_subclass__()

sf_dbbase_register = Register[SfDbBase]()
