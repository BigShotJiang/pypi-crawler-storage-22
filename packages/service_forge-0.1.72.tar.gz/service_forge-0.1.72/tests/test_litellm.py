# from litellm import completion
# import os

# response = completion(
#     model="openai/ark-deepseek-v3",
#     api_base="http://litellm.vps.shiweinan.com:37919/v1",
#     api_key="sk-2tEpI1fSejYERchVInDU_w",
#     messages=[
#         {"role": "user", "content": "你好，用一句话介绍你自己"}
#     ],
# )

# print(response.choices[0].message.content)

from service_forge.llm import SfLLM, Model
import litellm


# llm = SfLLM(api_base="http://litellm.vps.shiweinan.com:37919/v1", api_key="sk-2tEpI1fSejYERchVInDU_w")
llm = SfLLM(api_base="http://litellm.vps.shiweinan.com:37919/v1", api_key="sk-KVgpceAPL0bg3FXViwuaYw")


response = llm.completion(
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "What’s in this image?"
                },
                {
                    "type": "image_url",
                    "image_url": {
                    "url": "https://awsmp-logos.s3.amazonaws.com/seller-xw5kijmvmzasy/c233c9ade2ccb5491072ae232c814942.png"
                    }
                }
            ]
        }
    ],
    model=Model.QWEN_VL_PLUS,
)

print(response.choices[0].message.content)