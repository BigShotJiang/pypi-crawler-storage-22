#!/usr/bin/python
# coding: utf-8

from servicenow_api.servicenow_mcp import servicenow_mcp

if __name__ == "__main__":
    servicenow_mcp()
