---
name: servicenow-custom-api
description: Handles custom ServiceNow API requests. Use for uncategorized endpoints. Triggers - advanced calls.
---

### Overview
Arbitrary API via MCP.

### Key Tools
- `api_request`: Custom HTTP.

### Usage Instructions
1. Method, endpoint, data/json.

### Examples
- GET: `api_request` with method="GET", endpoint="custom/endpoint".

### Error Handling
- Validate responses.
