def test_padrap():
    result = 1
    assert result == 1
