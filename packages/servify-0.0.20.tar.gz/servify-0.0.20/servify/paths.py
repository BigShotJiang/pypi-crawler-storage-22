class EstaticPath:

    def __init__(self):
        pass

    monitor_log: str = "<path>"
