import os

os.environ["PYTEST_RUNNING"] = "1"
