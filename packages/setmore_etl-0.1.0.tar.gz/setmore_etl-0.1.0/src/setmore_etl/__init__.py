"""
Setmore ETL Library

Production-grade ETL utilities for Setmore API integration with Databricks.
All imports are explicit—no side effects on import.
"""

from setmore_etl.config import SetmoreConfig
from setmore_etl.client import SetmoreAPIClient
from setmore_etl.watermark import WatermarkManager
from setmore_etl.audit import AuditLogger
from setmore_etl.schema import (
    APPOINTMENT_SCHEMA,
    STAFF_SCHEMA,
    SERVICE_SCHEMA,
)
from setmore_etl.transforms import (
    flatten_appointment,
    process_staff_record,
    process_service_record,
    generate_extraction_id,
    parse_iso_timestamp,
)
from setmore_etl.utils import table_exists

__version__ = "0.1.0"

__all__ = [
    "SetmoreConfig",
    "SetmoreAPIClient",
    "WatermarkManager",
    "AuditLogger",
    "APPOINTMENT_SCHEMA",
    "STAFF_SCHEMA",
    "SERVICE_SCHEMA",
    "flatten_appointment",
    "process_staff_record",
    "process_service_record",
    "generate_extraction_id",
    "parse_iso_timestamp",
    "table_exists",
]