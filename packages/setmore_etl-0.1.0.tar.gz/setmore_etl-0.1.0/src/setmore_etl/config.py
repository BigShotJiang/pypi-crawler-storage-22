"""
Configuration management for Setmore ETL.
Immutable, explicit configuration with no runtime dependencies.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class SetmoreConfig:
    """
    Immutable configuration for Setmore ETL pipelines.
    
    All values must be provided explicitly—no widget access, no globals.
    
    Attributes:
        catalog: Unity Catalog name
        schema: Schema name (e.g., "setmore_dev", "setmore_prod")
        landing_volume: Volume name for raw data landing
        base_url: Setmore API base URL
        lookback_hours: Hours to look back for late-arriving data
        watermark_table: Override default watermark table name
        audit_table: Override default audit table name
    """
    
    catalog: str
    schema: str
    landing_volume: str
    base_url: str = "https://developer.setmore.com/api/v1"
    lookback_hours: int = 2
    watermark_table: str = "setmore_watermark"
    audit_table: str = "setmore_audit_log"
    
    @property
    def landing_path(self) -> str:
        """Full path to landing zone base directory (parent of raw/)."""
        return f"/Volumes/{self.catalog}/{self.schema}/{self.landing_volume}/setmore"
    
    @property
    def watermark_table_fqn(self) -> str:
        """Fully qualified watermark table name."""
        return f"{self.catalog}.{self.schema}.{self.watermark_table}"
    
    @property
    def audit_table_fqn(self) -> str:
        """Fully qualified audit table name."""
        return f"{self.catalog}.{self.schema}.{self.audit_table}"
    
    def with_overrides(
        self,
        catalog: str | None = None,
        schema: str | None = None,
        landing_volume: str | None = None,
    ) -> "SetmoreConfig":
        """Create new config with selective overrides."""
        return SetmoreConfig(
            catalog=catalog or self.catalog,
            schema=schema or self.schema,
            landing_volume=landing_volume or self.landing_volume,
            base_url=self.base_url,
            lookback_hours=self.lookback_hours,
            watermark_table=self.watermark_table,
            audit_table=self.audit_table,
        )