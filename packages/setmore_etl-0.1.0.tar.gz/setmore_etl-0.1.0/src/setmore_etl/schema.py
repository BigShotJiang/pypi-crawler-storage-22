"""
PySpark schema definitions for Setmore entities.
"""

from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    TimestampType,
    IntegerType,
    DoubleType,
    ArrayType,
)


APPOINTMENT_SCHEMA = StructType([
    StructField("key", StringType(), True),
    StructField("start_time", TimestampType(), True),
    StructField("end_time", TimestampType(), True),
    StructField("duration", IntegerType(), True),
    StructField("staff_key", StringType(), True),
    StructField("service_key", StringType(), True),
    StructField("customer_key", StringType(), True),
    StructField("cost", DoubleType(), True),
    StructField("currency", StringType(), True),
    StructField("comment", StringType(), True),
    StructField("label", StringType(), True),
    StructField("customer_first_name", StringType(), True),
    StructField("customer_last_name", StringType(), True),
    StructField("customer_email", StringType(), True),
    StructField("customer_phone", StringType(), True),
    StructField("ingestion_timestamp", TimestampType(), False),
    StructField("date_key", StringType(), False),
    StructField("source_file", StringType(), True),
    StructField("extraction_id", StringType(), True),
])

STAFF_SCHEMA = StructType([
    StructField("key", StringType(), True),
    StructField("first_name", StringType(), True),
    StructField("last_name", StringType(), True),
    StructField("email_id", StringType(), True),
    StructField("country_code", StringType(), True),
    StructField("work_phone", StringType(), True),
    StructField("image_url", StringType(), True),
    StructField("comment", StringType(), True),
    StructField("ingestion_timestamp", TimestampType(), False),
    StructField("source_file", StringType(), True),
    StructField("extraction_id", StringType(), True),
])

SERVICE_SCHEMA = StructType([
    StructField("key", StringType(), True),
    StructField("service_name", StringType(), True),
    StructField("staff_keys", ArrayType(StringType()), True),
    StructField("duration", IntegerType(), True),
    StructField("buffer_duration", IntegerType(), True),
    StructField("cost", DoubleType(), True),
    StructField("currency", StringType(), True),
    StructField("image_url", StringType(), True),
    StructField("description", StringType(), True),
    StructField("ingestion_timestamp", TimestampType(), False),
    StructField("source_file", StringType(), True),
    StructField("extraction_id", StringType(), True),
])