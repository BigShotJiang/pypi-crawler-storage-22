"""
Utility functions for Delta table operations.
"""

from pyspark.sql import SparkSession


def table_exists(spark: SparkSession, catalog: str, schema: str, table: str) -> bool:
    """
    Check if table exists using Spark SQL.
    
    Serverless-compatible implementation.
    """
    try:
        result = spark.sql(f"SHOW TABLES IN {catalog}.{schema} LIKE '{table}'")
        return result.count() > 0
    except Exception:
        return False