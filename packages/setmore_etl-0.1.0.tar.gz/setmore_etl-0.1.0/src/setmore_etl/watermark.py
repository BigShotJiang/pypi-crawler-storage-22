"""
Watermark management for incremental processing with exactly-once semantics.
"""

from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple, Callable

from pyspark.sql import SparkSession

from setmore_etl.config import SetmoreConfig
from setmore_etl.transforms import generate_extraction_id


class WatermarkManager:
    """
    Manages high watermark for incremental processing using actual timestamps.
    
    Tracks precise extraction windows with lookback for late arrivals.
    No side effects on initialization—lazy table creation.
    """
    
    def __init__(
        self,
        spark: SparkSession,
        config: SetmoreConfig,
        clock: Optional[Callable[[], datetime]] = None,
    ):
        self.spark = spark
        self.config = config
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._initialized = False
    
    @property
    def table_name(self) -> str:
        """Fully qualified watermark table name."""
        return self.config.watermark_table_fqn
    
    def _ensure_initialized(self) -> None:
        """Lazy initialization of schema and table."""
        if self._initialized:
            return
        
        # Create schema if not exists
        self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {self.config.catalog}.{self.config.schema}")
        
        # Create watermark table
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS {self.table_name} (
                pipeline_name STRING NOT NULL,
                extraction_id STRING NOT NULL,
                extraction_start TIMESTAMP,
                extraction_end TIMESTAMP,
                records_processed INT,
                run_type STRING,
                status STRING,
                completed_at TIMESTAMP
            ) USING DELTA
        """)
        
        self._initialized = True
    
    def get_last_successful_window(self, pipeline_name: str) -> Optional[Tuple[datetime, datetime]]:
        """Get the actual extraction window of last successful run."""
        self._ensure_initialized()
        
        result = self.spark.sql(f"""
            SELECT extraction_start, extraction_end 
            FROM {self.table_name} 
            WHERE pipeline_name = '{pipeline_name}'
              AND status = 'success'
            ORDER BY completed_at DESC 
            LIMIT 1
        """).collect()
        
        if result and result[0][0] and result[0][1]:
            return (result[0][0], result[0][1])
        return None
    
    def calculate_extraction_window(
        self,
        pipeline_name: str,
        is_full_refresh: bool = False,
    ) -> Tuple[datetime, datetime, str]:
        """
        Calculate extraction window based on last successful run.
        
        Returns:
            Tuple of (window_start, window_end, extraction_id)
        """
        now = self._clock()
        
        if is_full_refresh:
            window_start = datetime(1999, 1, 1, tzinfo=timezone.utc)
            window_end = now
            extraction_id = generate_extraction_id(window_start, window_end)
            return (window_start, window_end, extraction_id)
        
        # Incremental: resume from last end minus lookback
        last_window = self.get_last_successful_window(pipeline_name)
        
        if last_window:
            _, last_end = last_window
            window_start = last_end - timedelta(hours=self.config.lookback_hours)
        else:
            # First incremental run - default to 7 days ago
            window_start = now - timedelta(days=7)
        
        window_end = now
        extraction_id = generate_extraction_id(window_start, window_end)

        # Ensure UTC timezone
        if window_start.tzinfo is None:
            window_start = window_start.replace(tzinfo=timezone.utc)
        if window_end.tzinfo is None:
            window_end = window_end.replace(tzinfo=timezone.utc)
        
        return (window_start, window_end, extraction_id)
    
    def check_extraction_exists(self, extraction_id: str) -> bool:
        """Check idempotency—has this extraction already succeeded?"""
        self._ensure_initialized()
        
        result = self.spark.sql(f"""
            SELECT COUNT(*) as cnt 
            FROM {self.table_name} 
            WHERE extraction_id = '{extraction_id}' 
              AND status = 'success'
        """).collect()
        
        return result[0][0] > 0
    
    def set_watermark(
        self,
        pipeline_name: str,
        extraction_id: str,
        window_start: datetime,
        window_end: datetime,
        records: int,
        run_type: str = "incremental",
        status: str = "success",
    ) -> None:
        """Record extraction window completion."""
        self._ensure_initialized()
        
        self.spark.sql(f"""
            INSERT INTO {self.table_name} 
            VALUES (
                '{pipeline_name}', 
                '{extraction_id}',
                '{window_start}',
                '{window_end}',
                {records},
                '{run_type}',
                '{status}',
                current_timestamp()
            )
        """)