"""
Django TrafficMonitor
A comprehensive Django app for logging HTTP requests with analytics dashboard
"""

__version__ = '2.0.1'
__author__ = 'FarmSetu Team'
__email__ = 'tech@farmsetu.com'
__license__ = 'MIT'

default_app_config = 'trafficmonitor.apps.TrafficmonitorConfig'
