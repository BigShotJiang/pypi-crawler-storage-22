from django.contrib import admin
from django.utils.html import format_html
try:
    from import_export.admin import ImportExportModelAdmin
    BaseAdmin = ImportExportModelAdmin
except Exception:  # import-export is optional
    BaseAdmin = admin.ModelAdmin

from trafficmonitor.models import RequestLog


@admin.register(RequestLog)
class RequestLogAdmin(BaseAdmin):
    """
    Admin interface for viewing and managing request logs.
    """
    list_display = [
        'timestamp',
        'method_colored',
        'path_truncated',
        'status_code_colored',
        'user_display',
        'ip_address',
        'response_time_display',
        'query_count',
    ]

    list_filter = [
        'method',
        'status_code',
        'timestamp',
        'requested_user_id',
    ]

    search_fields = [
        'path',
        'full_url',
        'ip_address',
        'requested_user_id',
        'exception',
    ]

    fields = [
        'id',
        'timestamp',
        'method',
        'path',
        'full_url',
        'status_code',
        'requested_user_id',
        'ip_address',
        'user_agent',
        'request_headers_formatted',
        'request_body_formatted',
        'response_body_formatted',
        'response_time_ms',
        'query_count',
        'exception_formatted',
        'content_length',
    ]

    readonly_fields = [
        'id',
        'method',
        'path',
        'full_url',
        'status_code',
        'requested_user_id',
        'ip_address',
        'user_agent',
        'request_headers_formatted',
        'request_body_formatted',
        'response_body_formatted',
        'response_time_ms',
        'query_count',
        'exception_formatted',
        'content_length',
        'timestamp',
    ]

    date_hierarchy = 'timestamp'

    ordering = ['-timestamp']

    # Disable add and edit permissions - this is a read-only log
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        # Allow view permission but not edit
        if obj is None:
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        # Allow deletion through admin
        return True

    def method_colored(self, obj):
        """Display HTTP method with color coding."""
        colors = {
            'GET': '#28a745',      # Green
            'POST': '#007bff',     # Blue
            'PUT': '#ffc107',      # Yellow
            'PATCH': '#fd7e14',    # Orange
            'DELETE': '#dc3545',   # Red
        }
        color = colors.get(obj.method, '#6c757d')
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color,
            obj.method
        )
    method_colored.short_description = 'Method'

    def status_code_colored(self, obj):
        """Display status code with color coding."""
        if obj.status_code < 300:
            color = '#28a745'  # Green for success
        elif obj.status_code < 400:
            color = '#17a2b8'  # Teal for redirects
        elif obj.status_code < 500:
            color = '#ffc107'  # Yellow for client errors
        else:
            color = '#dc3545'  # Red for server errors

        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color,
            obj.status_code
        )
    status_code_colored.short_description = 'Status'

    def path_truncated(self, obj):
        """Display truncated path for readability."""
        max_length = 50
        if len(obj.path) > max_length:
            return obj.path[:max_length] + '...'
        return obj.path
    path_truncated.short_description = 'Path'

    def user_display(self, obj):
        """Display user information."""
        if obj.requested_user_id:
            return f"{obj.requested_user_id}"
        return "Anonymous"
    user_display.short_description = 'User'

    def response_time_display(self, obj):
        """Display response time with color coding."""
        if obj.response_time_ms is None:
            return '-'

        # Color code based on response time
        if obj.response_time_ms < 100:
            color = '#28a745'  # Green - fast
        elif obj.response_time_ms < 500:
            color = '#ffc107'  # Yellow - medium
        elif obj.response_time_ms < 1000:
            color = '#fd7e14'  # Orange - slow
        else:
            color = '#dc3545'  # Red - very slow

        # Format the time value first, then pass to format_html
        time_str = f"{obj.response_time_ms:.2f} ms"
        return format_html(
            '<span style="color: {};">{}</span>',
            color,
            time_str
        )
    response_time_display.short_description = 'Response Time'

    def request_headers_formatted(self, obj):
        """Display formatted request headers."""
        if obj.request_headers:
            import json
            return format_html(
                '<pre style="max-height: 300px; overflow: auto;">{}</pre>',
                json.dumps(obj.request_headers, indent=2)
            )
        return '-'
    request_headers_formatted.short_description = 'Request Headers'

    def request_body_formatted(self, obj):
        """Display formatted request body."""
        if obj.request_body:
            return format_html(
                '<pre style="max-height: 400px; overflow: auto;">{}</pre>',
                obj.request_body
            )
        return '-'
    request_body_formatted.short_description = 'Request Body'

    def response_body_formatted(self, obj):
        """Display formatted response body."""
        if obj.response_body:
            return format_html(
                '<pre style="max-height: 400px; overflow: auto;">{}</pre>',
                obj.response_body
            )
        return '-'
    response_body_formatted.short_description = 'Response Body'

    def exception_formatted(self, obj):
        """Display formatted exception traceback."""
        if obj.exception:
            return format_html(
                '<pre style="color: #dc3545; max-height: 500px; overflow: auto;">{}</pre>',
                obj.exception
            )
        return '-'
    exception_formatted.short_description = 'Exception Traceback'

    def get_queryset(self, request):
        """Optimize queryset."""
        qs = super().get_queryset(request)
        return qs
