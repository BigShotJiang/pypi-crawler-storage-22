"""
Enhanced Analytics Queries for Enterprise-Level Insights
Focus on Read/Write operations, API performance, and actionable metrics.
"""
from datetime import timedelta
from django.db.models import Count, Avg, Max, Min, Q, F, FloatField, ExpressionWrapper
from django.db.models.functions import TruncDate, TruncHour, TruncDay
from django.utils import timezone
from trafficmonitor.models import RequestLog


class EnhancedAnalyticsQueries:
    """
    Enterprise-grade analytics queries focused on actionable insights.
    """
    
    @staticmethod
    def get_read_write_summary(start_date, end_date, **filters):
        """
        Get summary of Read vs Write operations.
        Essential for understanding application usage patterns.
        
        Returns:
            dict: {
                'read_count': int,
                'write_count': int,
                'delete_count': int,
                'read_percentage': float,
                'write_percentage': float,
                'avg_read_time_ms': float,
                'avg_write_time_ms': float
            }
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        
        summary = qs.aggregate(
            read_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_READ)),
            write_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_WRITE)),
            delete_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_DELETE)),
            total_count=Count('id'),
            avg_read_time=Avg('response_time_ms', filter=Q(
                operation_type=RequestLog.OPERATION_READ,
                response_time_ms__isnull=False
            )),
            avg_write_time=Avg('response_time_ms', filter=Q(
                operation_type=RequestLog.OPERATION_WRITE,
                response_time_ms__isnull=False
            )),
            avg_delete_time=Avg('response_time_ms', filter=Q(
                operation_type=RequestLog.OPERATION_DELETE,
                response_time_ms__isnull=False
            )),
        )
        
        # Calculate percentages
        total = summary['total_count'] or 1
        summary['read_percentage'] = (summary['read_count'] / total) * 100
        summary['write_percentage'] = (summary['write_count'] / total) * 100
        summary['delete_percentage'] = (summary['delete_count'] / total) * 100
        
        return summary
    
    @staticmethod
    def get_read_write_over_time(start_date, end_date, granularity='day', **filters):
        """
        Get Read vs Write operations over time.
        Useful for identifying usage patterns and peak times.
        
        Returns:
            List of dicts with period, read_count, write_count
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        
        trunc_func = TruncHour if granularity == 'hour' else TruncDay
        
        results = qs.annotate(
            period=trunc_func('timestamp')
        ).values('period').annotate(
            read_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_READ)),
            write_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_WRITE)),
            delete_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_DELETE)),
            total_count=Count('id')
        ).order_by('period')
        
        return list(results)
    
    @staticmethod
    def get_api_health_metrics(start_date, end_date, **filters):
        """
        Get API health metrics including success rates and error rates.
        Critical for SRE/DevOps monitoring.
        
        Returns:
            dict with success_rate, error_rate, p50, p95, p99 response times
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        qs = qs.filter(is_api_request=True)
        
        total = qs.count()
        if total == 0:
            return {
                'total_requests': 0,
                'success_rate': 0,
                'error_rate': 0,
                'p50_response_time': 0,
                'p95_response_time': 0,
                'p99_response_time': 0,
            }
        
        # Success and error rates
        success_count = qs.filter(status_code__lt=400).count()
        error_count = qs.filter(status_code__gte=400).count()
        
        # Response time percentiles (approximation using aggregates)
        response_times = qs.filter(response_time_ms__isnull=False).values_list(
            'response_time_ms', flat=True
        ).order_by('response_time_ms')
        
        response_times_list = list(response_times)
        count = len(response_times_list)
        
        p50 = response_times_list[int(count * 0.50)] if count > 0 else 0
        p95 = response_times_list[int(count * 0.95)] if count > 0 else 0
        p99 = response_times_list[int(count * 0.99)] if count > 0 else 0
        
        return {
            'total_requests': total,
            'success_count': success_count,
            'error_count': error_count,
            'success_rate': (success_count / total) * 100,
            'error_rate': (error_count / total) * 100,
            'p50_response_time': round(p50, 2),
            'p95_response_time': round(p95, 2),
            'p99_response_time': round(p99, 2),
        }
    
    @staticmethod
    def get_endpoint_category_breakdown(start_date, end_date, limit=10, **filters):
        """
        Get request breakdown by endpoint category.
        Helps identify which microservices/modules are most used.
        
        Returns:
            List of dicts with category, count, avg_response_time, error_rate
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        qs = qs.filter(endpoint_category__isnull=False)
        
        results = qs.values('endpoint_category').annotate(
            total_count=Count('id'),
            success_count=Count('id', filter=Q(status_code__lt=400)),
            error_count=Count('id', filter=Q(status_code__gte=400)),
            avg_response_time=Avg('response_time_ms', filter=Q(response_time_ms__isnull=False)),
            max_response_time=Max('response_time_ms'),
        ).order_by('-total_count')[:limit]
        
        # Add error_rate calculation
        for item in results:
            total = item['total_count'] or 1
            item['error_rate'] = (item['error_count'] / total) * 100
            item['success_rate'] = (item['success_count'] / total) * 100
        
        return list(results)
    
    @staticmethod
    def get_user_activity_detailed(start_date, end_date, limit=20, **filters):
        """
        Get detailed user activity with Read/Write breakdown.
        
        Returns:
            List of dicts with user_id, total_requests, read_count, write_count
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        qs = qs.filter(requested_user_id__isnull=False)
        
        results = qs.values('requested_user_id').annotate(
            total_count=Count('id'),
            read_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_READ)),
            write_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_WRITE)),
            delete_count=Count('id', filter=Q(operation_type=RequestLog.OPERATION_DELETE)),
            avg_response_time=Avg('response_time_ms', filter=Q(response_time_ms__isnull=False)),
            error_count=Count('id', filter=Q(status_code__gte=400)),
        ).order_by('-total_count')[:limit]
        
        # Add percentages
        for item in results:
            total = item['total_count'] or 1
            item['read_percentage'] = (item['read_count'] / total) * 100
            item['write_percentage'] = (item['write_count'] / total) * 100
            item['error_rate'] = (item['error_count'] / total) * 100
        
        return list(results)
    
    @staticmethod
    def get_performance_outliers(start_date, end_date, threshold_percentile=95, limit=10, **filters):
        """
        Identify endpoints with performance issues (beyond 95th percentile).
        Critical for performance optimization.
        
        Returns:
            List of endpoints exceeding performance threshold
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        qs = qs.filter(response_time_ms__isnull=False)
        
        # Calculate 95th percentile threshold
        response_times = list(qs.values_list('response_time_ms', flat=True).order_by('response_time_ms'))
        if not response_times:
            return []
        
        threshold = response_times[int(len(response_times) * (threshold_percentile / 100))]
        
        # Find endpoints exceeding threshold
        outliers = qs.filter(
            response_time_ms__gte=threshold
        ).values('path', 'operation_type').annotate(
            count=Count('id'),
            avg_response_time=Avg('response_time_ms'),
            max_response_time=Max('response_time_ms'),
            min_response_time=Min('response_time_ms'),
        ).order_by('-avg_response_time')[:limit]
        
        return list(outliers)
    
    @staticmethod
    def get_error_analysis_by_category(start_date, end_date, **filters):
        """
        Analyze errors by endpoint category and status code.
        Helps identify problematic services.
        
        Returns:
            List of dicts with category, status_code, count
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        qs = qs.filter(status_code__gte=400, endpoint_category__isnull=False)
        
        results = qs.values('endpoint_category', 'status_code').annotate(
            count=Count('id'),
            example_path=Max('path')  # Show an example path
        ).order_by('endpoint_category', '-count')
        
        return list(results)
    
    @staticmethod
    def get_throughput_metrics(start_date, end_date, **filters):
        """
        Calculate throughput metrics (requests per second/minute).
        
        Returns:
            dict with avg_rps, peak_rps, total_requests
        """
        from trafficmonitor.analytics.views import AnalyticsQueryHelper
        qs = AnalyticsQueryHelper.get_base_queryset(start_date, end_date, **filters)
        
        total_requests = qs.count()
        time_diff_seconds = (end_date - start_date).total_seconds()
        
        if time_diff_seconds == 0:
            return {'avg_rps': 0, 'total_requests': 0}
        
        avg_rps = total_requests / time_diff_seconds
        
        # Get peak hourly throughput
        hourly = qs.annotate(
            hour=TruncHour('timestamp')
        ).values('hour').annotate(
            count=Count('id')
        ).order_by('-count').first()
        
        peak_rph = hourly['count'] if hourly else 0
        peak_rps = peak_rph / 3600  # Convert to per second
        
        return {
            'total_requests': total_requests,
            'avg_rps': round(avg_rps, 2),
            'avg_rpm': round(avg_rps * 60, 2),
            'peak_rps': round(peak_rps, 2),
            'peak_rph': peak_rph,
        }
