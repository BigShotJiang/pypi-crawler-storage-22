from rest_framework import serializers


class StatusCodeDataSerializer(serializers.Serializer):
    """
    Serializer for status code distribution data.
    """
    status_code = serializers.IntegerField()
    count = serializers.IntegerField()


class MethodDataSerializer(serializers.Serializer):
    """
    Serializer for HTTP method distribution data.
    """
    method = serializers.CharField()
    count = serializers.IntegerField()


class EndpointDataSerializer(serializers.Serializer):
    """
    Serializer for endpoint statistics.
    """
    path = serializers.CharField()
    count = serializers.IntegerField()
    avg_response_time = serializers.FloatField(allow_null=True)
    min_response_time = serializers.FloatField(allow_null=True, required=False)
    max_response_time = serializers.FloatField(allow_null=True, required=False)


class IPAddressDataSerializer(serializers.Serializer):
    """
    Serializer for IP address statistics.
    """
    ip_address = serializers.IPAddressField()
    count = serializers.IntegerField()


class TimeSeriesDataSerializer(serializers.Serializer):
    """
    Serializer for time series data.
    """
    period = serializers.DateTimeField()
    count = serializers.IntegerField()


class ErrorTrendDataSerializer(serializers.Serializer):
    """
    Serializer for error trend data.
    """
    period = serializers.DateTimeField()
    client_errors = serializers.IntegerField()
    server_errors = serializers.IntegerField()
    total_errors = serializers.IntegerField()


class HourlyHeatmapDataSerializer(serializers.Serializer):
    """
    Serializer for hourly heatmap data.
    """
    hour = serializers.IntegerField(min_value=0, max_value=23)
    count = serializers.IntegerField()


class StatusCodeSummarySerializer(serializers.Serializer):
    """
    Serializer for status code summary.
    """
    success = serializers.IntegerField()
    redirect = serializers.IntegerField()
    client_error = serializers.IntegerField()
    server_error = serializers.IntegerField()
    total = serializers.IntegerField()


class PerformanceSummarySerializer(serializers.Serializer):
    """
    Serializer for performance metrics summary.
    """
    avg_response_time = serializers.FloatField(allow_null=True)
    max_response_time = serializers.FloatField(allow_null=True)
    min_response_time = serializers.FloatField(allow_null=True)
    avg_query_count = serializers.FloatField(allow_null=True)
    max_query_count = serializers.IntegerField(allow_null=True)


class UserActivityDataSerializer(serializers.Serializer):
    """
    Serializer for authenticated user activity.
    """
    user__username = serializers.CharField()
    user__email = serializers.EmailField()
    count = serializers.IntegerField()


class UserActivitySerializer(serializers.Serializer):
    """
    Serializer for user activity summary.
    """
    authenticated = UserActivityDataSerializer(many=True)
    anonymous_count = serializers.IntegerField()


class TotalsSerializer(serializers.Serializer):
    """
    Serializer for total request counts by period.
    """
    today = serializers.IntegerField()
    last_7_days = serializers.IntegerField()
    last_30_days = serializers.IntegerField()
    selected_range = serializers.IntegerField()


class MetadataSerializer(serializers.Serializer):
    """
    Serializer for analytics metadata.
    """
    range_type = serializers.CharField()
    start_date = serializers.DateTimeField()
    end_date = serializers.DateTimeField()
    filters = serializers.DictField()
    generated_at = serializers.DateTimeField()


class ComprehensiveAnalyticsSerializer(serializers.Serializer):
    """
    Main serializer for comprehensive analytics response.
    Combines all analytics data into a single response.
    """
    totals = TotalsSerializer()
    status_summary = StatusCodeSummarySerializer()
    status_codes = StatusCodeDataSerializer(many=True)
    methods = MethodDataSerializer(many=True)
    top_endpoints = EndpointDataSerializer(many=True)
    slowest_endpoints = EndpointDataSerializer(many=True)
    top_ips = IPAddressDataSerializer(many=True)
    performance = PerformanceSummarySerializer()
    users = UserActivitySerializer()
    requests_over_time = TimeSeriesDataSerializer(many=True)
    error_trend = ErrorTrendDataSerializer(many=True)
    hourly_heatmap = HourlyHeatmapDataSerializer(many=True)
    metadata = MetadataSerializer()


class ChartDataSerializer(serializers.Serializer):
    """
    Serializer for individual chart data responses.
    """
    chart_type = serializers.CharField()
    data = serializers.JSONField()
    metadata = serializers.DictField()


# Sample JSON response formats for documentation
SAMPLE_ANALYTICS_RESPONSE = {
    "totals": {
        "today": 1543,
        "last_7_days": 12876,
        "last_30_days": 54321,
        "selected_range": 12876
    },
    "status_summary": {
        "success": 10234,
        "redirect": 543,
        "client_error": 1876,
        "server_error": 223,
        "total": 12876
    },
    "status_codes": [
        {"status_code": 200, "count": 8765},
        {"status_code": 404, "count": 1234},
        {"status_code": 500, "count": 123}
    ],
    "methods": [
        {"method": "GET", "count": 8000},
        {"method": "POST", "count": 3000},
        {"method": "PUT", "count": 1000}
    ],
    "top_endpoints": [
        {
            "path": "/api/v1/monitoring/",
            "count": 3456,
            "avg_response_time": 145.5,
            "min_response_time": 23.1,
            "max_response_time": 2345.6
        }
    ],
    "slowest_endpoints": [
        {
            "path": "/api/v1/reports/generate/",
            "avg_response_time": 3456.7,
            "count": 234,
            "max_response_time": 8765.4
        }
    ],
    "top_ips": [
        {"ip_address": "192.168.1.100", "count": 567}
    ],
    "performance": {
        "avg_response_time": 234.5,
        "max_response_time": 5678.9,
        "min_response_time": 12.3,
        "avg_query_count": 15.6,
        "max_query_count": 234
    },
    "users": {
        "authenticated": [
            {
                "user__username": "john_doe",
                "user__email": "john@example.com",
                "count": 567
            }
        ],
        "anonymous_count": 123
    },
    "requests_over_time": [
        {"period": "2024-01-01T00:00:00Z", "count": 1234}
    ],
    "error_trend": [
        {
            "period": "2024-01-01T00:00:00Z",
            "client_errors": 56,
            "server_errors": 12,
            "total_errors": 68
        }
    ],
    "hourly_heatmap": [
        {"hour": 0, "count": 123},
        {"hour": 1, "count": 89}
    ],
    "metadata": {
        "range_type": "last_7_days",
        "start_date": "2024-01-01T00:00:00Z",
        "end_date": "2024-01-08T00:00:00Z",
        "filters": {},
        "generated_at": "2024-01-08T12:00:00Z"
    }
}
