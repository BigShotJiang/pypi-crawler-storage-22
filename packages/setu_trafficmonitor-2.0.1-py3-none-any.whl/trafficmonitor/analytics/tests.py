from datetime import timedelta
from django.contrib.auth import get_user_model
from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone
from rest_framework.test import APIClient

from trafficmonitor.models import RequestLog
from trafficmonitor.analytics.views import AnalyticsQueryHelper


User = get_user_model()


class AnalyticsQueryHelperTest(TestCase):
    """
    Test cases for AnalyticsQueryHelper optimized queries.
    """

    def setUp(self):
        """Set up test fixtures."""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        self.staff_user = User.objects.create_user(
            username='staffuser',
            email='staff@example.com',
            password='staffpass123',
            is_staff=True
        )

        # Create test data
        now = timezone.now()
        self.test_logs = []

        # Create logs for the last 7 days
        for i in range(7):
            timestamp = now - timedelta(days=i, hours=i)

            # Success requests
            for j in range(5):
                log = RequestLog.objects.create(
                    method='GET',
                    path=f'/api/test/endpoint{j}/',
                    full_url=f'http://test.com/api/test/endpoint{j}/',
                    status_code=200,
                    user=self.user,
                    ip_address=f'192.168.1.{j}',
                    response_time_ms=100 + (i * 50),
                    query_count=5 + i,
                    timestamp=timestamp
                )
                self.test_logs.append(log)

            # Error requests
            RequestLog.objects.create(
                method='POST',
                path='/api/test/error/',
                full_url='http://test.com/api/test/error/',
                status_code=500,
                user=self.user,
                ip_address='192.168.1.100',
                response_time_ms=1500,
                exception='Internal Server Error',
                timestamp=timestamp
            )

            # Client error
            RequestLog.objects.create(
                method='GET',
                path='/api/test/notfound/',
                full_url='http://test.com/api/test/notfound/',
                status_code=404,
                ip_address='192.168.1.200',
                response_time_ms=50,
                timestamp=timestamp
            )

    def test_get_date_range_today(self):
        """Test date range calculation for 'today'."""
        start, end = AnalyticsQueryHelper.get_date_range('today')
        now = timezone.now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

        self.assertEqual(start.date(), today_start.date())
        self.assertEqual(start.hour, 0)

    def test_get_date_range_last_7_days(self):
        """Test date range calculation for 'last_7_days'."""
        start, end = AnalyticsQueryHelper.get_date_range('last_7_days')
        expected_start = timezone.now() - timedelta(days=7)

        self.assertAlmostEqual(
            (expected_start - start).total_seconds(),
            0,
            delta=2  # Allow 2 seconds difference
        )

    def test_get_total_requests(self):
        """Test total request count query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        total = AnalyticsQueryHelper.get_total_requests(start, now)

        # 7 days * (5 success + 1 error + 1 client error) = 49
        self.assertEqual(total, 49)

    def test_get_total_requests_with_method_filter(self):
        """Test total request count with method filter."""
        now = timezone.now()
        start = now - timedelta(days=7)

        total = AnalyticsQueryHelper.get_total_requests(start, now, method='GET')

        # 7 days * (5 GET + 1 GET 404) = 42
        self.assertEqual(total, 42)

    def test_get_total_requests_with_status_filter(self):
        """Test total request count with status code filter."""
        now = timezone.now()
        start = now - timedelta(days=7)

        total = AnalyticsQueryHelper.get_total_requests(
            start, now,
            status_code_range=(500, 599)
        )

        # 7 days * 1 500 error = 7
        self.assertEqual(total, 7)

    def test_get_requests_by_status_code(self):
        """Test requests grouped by status code."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_requests_by_status_code(start, now)

        # Should have 3 status codes: 200, 404, 500
        self.assertEqual(len(results), 3)

        # 200 should have the most requests
        status_200 = next(r for r in results if r['status_code'] == 200)
        self.assertEqual(status_200['count'], 35)

    def test_get_requests_by_method(self):
        """Test requests grouped by HTTP method."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_requests_by_method(start, now)

        # Should have GET and POST
        self.assertGreaterEqual(len(results), 2)

        # GET should have more than POST
        get_count = next(r for r in results if r['method'] == 'GET')['count']
        post_count = next(r for r in results if r['method'] == 'POST')['count']
        self.assertGreater(get_count, post_count)

    def test_get_top_endpoints(self):
        """Test top endpoints query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_top_endpoints(start, now, limit=5)

        # Should return up to 5 endpoints
        self.assertLessEqual(len(results), 5)
        self.assertGreater(len(results), 0)

        # Each result should have required fields
        for result in results:
            self.assertIn('path', result)
            self.assertIn('count', result)
            self.assertIn('avg_response_time', result)

    def test_get_slowest_endpoints(self):
        """Test slowest endpoints query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_slowest_endpoints(start, now, limit=5)

        self.assertGreater(len(results), 0)

        # Results should be ordered by response time descending
        for i in range(len(results) - 1):
            self.assertGreaterEqual(
                results[i]['avg_response_time'],
                results[i + 1]['avg_response_time']
            )

    def test_get_top_ip_addresses(self):
        """Test top IP addresses query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_top_ip_addresses(start, now, limit=10)

        self.assertGreater(len(results), 0)

        # Each result should have ip_address and count
        for result in results:
            self.assertIn('ip_address', result)
            self.assertIn('count', result)

    def test_get_requests_over_time_daily(self):
        """Test requests over time with daily granularity."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_requests_over_time(
            start, now, granularity='day'
        )

        # Should have entries for each day
        self.assertGreater(len(results), 0)

        # Each result should have period and count
        for result in results:
            self.assertIn('period', result)
            self.assertIn('count', result)

    def test_get_requests_over_time_hourly(self):
        """Test requests over time with hourly granularity."""
        now = timezone.now()
        start = now - timedelta(days=1)

        results = AnalyticsQueryHelper.get_requests_over_time(
            start, now, granularity='hour'
        )

        self.assertGreater(len(results), 0)

    def test_get_error_trend(self):
        """Test error trend query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_error_trend(start, now)

        self.assertGreater(len(results), 0)

        # Each result should have error counts
        for result in results:
            self.assertIn('period', result)
            self.assertIn('client_errors', result)
            self.assertIn('server_errors', result)
            self.assertIn('total_errors', result)

    def test_get_hourly_heatmap(self):
        """Test hourly heatmap query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        results = AnalyticsQueryHelper.get_hourly_heatmap(start, now)

        # Results should have hours
        self.assertGreater(len(results), 0)

        # Hours should be between 0-23
        for result in results:
            self.assertGreaterEqual(result['hour'], 0)
            self.assertLessEqual(result['hour'], 23)

    def test_get_status_code_summary(self):
        """Test status code summary aggregation."""
        now = timezone.now()
        start = now - timedelta(days=7)

        summary = AnalyticsQueryHelper.get_status_code_summary(start, now)

        # Should have all status categories
        self.assertIn('success', summary)
        self.assertIn('redirect', summary)
        self.assertIn('client_error', summary)
        self.assertIn('server_error', summary)
        self.assertIn('total', summary)

        # Total should equal sum of categories
        total_calculated = (
            summary['success'] +
            summary['redirect'] +
            summary['client_error'] +
            summary['server_error']
        )
        self.assertEqual(summary['total'], total_calculated)

    def test_get_performance_summary(self):
        """Test performance metrics summary."""
        now = timezone.now()
        start = now - timedelta(days=7)

        summary = AnalyticsQueryHelper.get_performance_summary(start, now)

        # Should have performance metrics
        self.assertIn('avg_response_time', summary)
        self.assertIn('max_response_time', summary)
        self.assertIn('min_response_time', summary)
        self.assertIn('avg_query_count', summary)

        # Values should be reasonable
        self.assertIsNotNone(summary['avg_response_time'])
        self.assertGreater(summary['avg_response_time'], 0)

    def test_get_user_activity(self):
        """Test user activity query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        activity = AnalyticsQueryHelper.get_user_activity(start, now)

        # Should have authenticated and anonymous counts
        self.assertIn('authenticated', activity)
        self.assertIn('anonymous_count', activity)

        # Should have authenticated user data
        self.assertGreater(len(activity['authenticated']), 0)

    def test_get_comprehensive_analytics(self):
        """Test comprehensive analytics query."""
        now = timezone.now()
        start = now - timedelta(days=7)

        data = AnalyticsQueryHelper.get_comprehensive_analytics(start, now)

        # Verify all expected keys are present
        expected_keys = [
            'totals', 'status_summary', 'status_codes', 'methods',
            'top_endpoints', 'slowest_endpoints', 'top_ips',
            'performance', 'users', 'requests_over_time',
            'error_trend', 'hourly_heatmap'
        ]

        for key in expected_keys:
            self.assertIn(key, data, f"Missing key: {key}")

    def test_filtering_by_path(self):
        """Test path filtering."""
        now = timezone.now()
        start = now - timedelta(days=7)

        # Filter by specific path
        total = AnalyticsQueryHelper.get_total_requests(
            start, now,
            path_contains='endpoint0'
        )

        # Should only include endpoint0
        self.assertEqual(total, 7)  # 7 days

    def test_filtering_by_user(self):
        """Test user filtering."""
        now = timezone.now()
        start = now - timedelta(days=7)

        # Filter by user
        total = AnalyticsQueryHelper.get_total_requests(
            start, now,
            user_id=self.user.id
        )

        # Should only include user's requests (not the 404s which have no user)
        self.assertEqual(total, 42)  # 7 days * 6 requests with user


class AnalyticsAPITest(TestCase):
    """
    Test cases for Analytics API endpoints.
    """

    def setUp(self):
        """Set up test fixtures."""
        self.client = APIClient()

        # Create regular user
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )

        # Create staff user
        self.staff_user = User.objects.create_user(
            username='staffuser',
            email='staff@example.com',
            password='staffpass123',
            is_staff=True
        )

        # Create test logs
        now = timezone.now()
        for i in range(10):
            RequestLog.objects.create(
                method='GET',
                path='/api/test/',
                full_url='http://test.com/api/test/',
                status_code=200,
                user=self.user,
                ip_address='192.168.1.100',
                response_time_ms=100,
                timestamp=now - timedelta(hours=i)
            )

    def test_analytics_overview_requires_authentication(self):
        """Test that API requires authentication."""
        url = reverse('analytics:api-overview')
        # No authentication
        response = self.client.get(url)

        # Should return 401 (unauthorized)
        self.assertIn(response.status_code, [401, 403])

    def test_analytics_overview_success(self):
        """Test successful analytics overview API call."""
        url = reverse('analytics:api-overview')

        # Authenticate as staff user
        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)

        # Verify response structure
        data = response.json()
        self.assertIn('totals', data)
        self.assertIn('status_summary', data)
        self.assertIn('status_codes', data)
        self.assertIn('methods', data)
        self.assertIn('metadata', data)

    def test_analytics_overview_with_filters(self):
        """Test analytics API with filters."""
        url = reverse('analytics:api-overview')

        # Authenticate as staff user
        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(url, {
            'range': 'today',
            'method': 'GET',
            'status': '200'
        })

        self.assertEqual(response.status_code, 200)
        data = response.json()

        # Verify filters were applied
        self.assertIn('filters', data['metadata'])

    def test_analytics_overview_custom_date_range(self):
        """Test analytics API with custom date range."""
        url = reverse('analytics:api-overview')

        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(url, {
            'range': 'custom',
            'start_date': '2024-01-01',
            'end_date': '2024-01-31'
        })

        self.assertEqual(response.status_code, 200)

    def test_analytics_overview_invalid_custom_range(self):
        """Test analytics API with invalid custom range."""
        url = reverse('analytics:api-overview')

        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(url, {
            'range': 'custom',
            'start_date': 'invalid-date',
            'end_date': '2024-01-31'
        })

        self.assertEqual(response.status_code, 400)
        self.assertIn('error', response.json())

    def test_analytics_overview_missing_custom_dates(self):
        """Test analytics API with missing custom dates."""
        url = reverse('analytics:api-overview')

        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(url, {
            'range': 'custom',
        })

        self.assertEqual(response.status_code, 400)

    def test_chart_data_api_success(self):
        """Test chart data API endpoint."""
        url = reverse('analytics:api-chart-data', kwargs={'chart_type': 'time-series'})

        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)

        data = response.json()
        self.assertIn('chart_type', data)
        self.assertIn('data', data)
        self.assertIn('metadata', data)

    def test_chart_data_api_invalid_chart_type(self):
        """Test chart data API with invalid chart type."""
        url = reverse('analytics:api-chart-data', kwargs={'chart_type': 'invalid-chart'})

        self.client.force_authenticate(user=self.staff_user)
        response = self.client.get(url)

        self.assertEqual(response.status_code, 400)

    def test_chart_data_api_all_types(self):
        """Test all chart types are accessible."""
        chart_types = [
            'time-series', 'status-codes', 'methods', 'endpoints',
            'performance', 'heatmap', 'errors'
        ]

        self.client.force_authenticate(user=self.staff_user)

        for chart_type in chart_types:
            url = reverse('analytics:api-chart-data', kwargs={'chart_type': chart_type})
            response = self.client.get(url)

            self.assertEqual(
                response.status_code, 200,
                f"Failed for chart type: {chart_type}"
            )


class AnalyticsDashboardViewTest(TestCase):
    """
    Test cases for Analytics Dashboard view.
    """

    def setUp(self):
        """Set up test fixtures."""
        self.client = Client()

        # Create regular user
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )

        # Create staff user
        self.staff_user = User.objects.create_user(
            username='staffuser',
            email='staff@example.com',
            password='staffpass123',
            is_staff=True
        )

    def test_dashboard_requires_login(self):
        """Test that dashboard requires authentication."""
        url = reverse('analytics:dashboard')
        response = self.client.get(url)

        # Should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertIn('/accounts/login/', response.url)

    def test_dashboard_requires_staff(self):
        """Test that dashboard requires staff permission."""
        url = reverse('analytics:dashboard')

        # Login as regular user
        self.client.login(username='testuser', password='testpass123')
        response = self.client.get(url)

        # Should redirect to login or show 403
        self.assertIn(response.status_code, [302, 403])

    def test_dashboard_accessible_to_staff(self):
        """Test that staff users can access dashboard."""
        url = reverse('analytics:dashboard')

        # Login as staff user
        self.client.login(username='staffuser', password='staffpass123')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertIn(b'API Analytics Dashboard', response.content)

    def test_dashboard_with_filters(self):
        """Test dashboard with filter parameters."""
        url = reverse('analytics:dashboard')

        self.client.login(username='staffuser', password='staffpass123')
        response = self.client.get(url, {
            'range': 'last_7_days',
            'method': 'GET',
            'status': '200'
        })

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context['filters']['method'], 'GET')


class AnalyticsPerformanceTest(TestCase):
    """
    Test cases for query performance and optimization.
    """

    def setUp(self):
        """Set up test fixtures."""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )

        # Create a larger dataset
        now = timezone.now()
        self.logs_count = 1000

        # Bulk create logs for performance testing
        logs_to_create = []
        for i in range(self.logs_count):
            logs_to_create.append(
                RequestLog(
                    method='GET' if i % 3 == 0 else 'POST',
                    path=f'/api/endpoint{i % 10}/',
                    full_url=f'http://test.com/api/endpoint{i % 10}/',
                    status_code=200 if i % 5 != 0 else 500,
                    user=self.user,
                    ip_address=f'192.168.1.{i % 255}',
                    response_time_ms=50 + (i % 100),
                    query_count=5 + (i % 10),
                    timestamp=now - timedelta(hours=i % 168)  # Last 7 days
                )
            )

        RequestLog.objects.bulk_create(logs_to_create)

    def test_query_performance_with_large_dataset(self):
        """Test that queries remain efficient with large dataset."""
        from django.test.utils import override_settings
        from django.db import connection
        from django.test.utils import CaptureQueriesContext

        now = timezone.now()
        start = now - timedelta(days=7)

        # Test comprehensive analytics query count
        with CaptureQueriesContext(connection) as context:
            data = AnalyticsQueryHelper.get_comprehensive_analytics(start, now)

        # Should use a reasonable number of queries (not N+1)
        # Each aggregation is a separate query, so expect ~12-15 queries
        self.assertLess(len(context.captured_queries), 20,
                       "Too many queries - possible N+1 issue")

        # Verify data was returned
        self.assertGreater(data['totals']['selected_range'], 0)

    def test_top_endpoints_uses_single_query(self):
        """Test that top endpoints uses a single optimized query."""
        from django.db import connection
        from django.test.utils import CaptureQueriesContext

        now = timezone.now()
        start = now - timedelta(days=7)

        with CaptureQueriesContext(connection) as context:
            results = AnalyticsQueryHelper.get_top_endpoints(start, now)

        # Should be a single query with aggregation
        self.assertEqual(len(context.captured_queries), 1)
        self.assertGreater(len(results), 0)


class AnalyticsIntegrationTest(TestCase):
    """
    Integration tests for the complete analytics flow.
    """

    def setUp(self):
        """Set up test fixtures."""
        self.client = Client()
        self.api_client = APIClient()

        self.staff_user = User.objects.create_user(
            username='staffuser',
            email='staff@example.com',
            password='staffpass123',
            is_staff=True
        )

        # Create diverse test data
        now = timezone.now()

        # Mix of methods
        for method in ['GET', 'POST', 'PUT', 'DELETE']:
            RequestLog.objects.create(
                method=method,
                path='/api/test/',
                full_url='http://test.com/api/test/',
                status_code=200,
                user=self.staff_user,
                response_time_ms=100,
                timestamp=now
            )

        # Mix of status codes
        for status in [200, 201, 400, 401, 404, 500]:
            RequestLog.objects.create(
                method='GET',
                path=f'/api/status{status}/',
                full_url=f'http://test.com/api/status{status}/',
                status_code=status,
                response_time_ms=100,
                timestamp=now
            )

    def test_full_dashboard_workflow(self):
        """Test complete dashboard workflow."""
        # Login
        self.client.login(username='staffuser', password='staffpass123')

        # Access dashboard
        dashboard_url = reverse('analytics:dashboard')
        response = self.client.get(dashboard_url)
        self.assertEqual(response.status_code, 200)

        # Fetch analytics data via API
        self.api_client.force_authenticate(user=self.staff_user)
        api_url = reverse('analytics:api-overview')
        api_response = self.api_client.get(api_url)

        self.assertEqual(api_response.status_code, 200)

        # Verify data structure
        data = api_response.json()
        self.assertGreater(data['totals']['today'], 0)
        self.assertGreater(len(data['methods']), 0)
        self.assertGreater(len(data['status_codes']), 0)

    def test_dashboard_filter_workflow(self):
        """Test dashboard with various filters."""
        self.api_client.force_authenticate(user=self.staff_user)

        # Test different range filters
        ranges = ['today', 'yesterday', 'last_7_days', 'last_30_days']

        for range_type in ranges:
            url = reverse('analytics:api-overview')
            response = self.api_client.get(url, {'range': range_type})

            self.assertEqual(response.status_code, 200,
                           f"Failed for range: {range_type}")

            data = response.json()
            self.assertEqual(data['metadata']['range_type'], range_type)
