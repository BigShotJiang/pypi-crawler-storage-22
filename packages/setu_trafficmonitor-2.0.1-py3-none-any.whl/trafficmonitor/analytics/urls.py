from django.urls import path

from trafficmonitor.analytics.views import (
    AnalyticsDashboardView,
    analytics_overview_api,
    analytics_chart_data_api,
)

app_name = 'analytics'

urlpatterns = [
    # Dashboard UI
    path('analytics/dashboard/', AnalyticsDashboardView.as_view(), name='dashboard'),

    # API Endpoints
    path('api/analytics/overview/', analytics_overview_api, name='api-overview'),
    path('api/analytics/chart/<str:chart_type>/', analytics_chart_data_api, name='api-chart-data'),
]
