from django.apps import AppConfig


class TrafficmonitorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'trafficmonitor'
    verbose_name = 'Traffic Monitor'
