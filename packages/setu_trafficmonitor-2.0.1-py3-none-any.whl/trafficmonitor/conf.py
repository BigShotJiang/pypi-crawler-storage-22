"""
TrafficMonitor Configuration
Enterprise-grade configuration management with environment support.
"""
import os
from django.conf import settings
from typing import List, Dict, Any


class TrafficMonitorConfig:
    """
    Centralized configuration for TrafficMonitor.
    Supports environment variables and Django settings override.
    """
    
    # Environment Detection
    ENVIRONMENT = os.getenv('DJANGO_ENV', getattr(settings, 'ENVIRONMENT', 'development'))
    IS_PRODUCTION = ENVIRONMENT.lower() in ['production', 'prod']
    
    # Role-based Access Control
    VIEWER_ROLES = getattr(settings, 'TRAFFICMONITOR_VIEWER_ROLES', 
                          os.getenv('TRAFFICMONITOR_VIEWER_ROLES', 'analyst,viewer,developer').split(','))
    ADMIN_ROLES = getattr(settings, 'TRAFFICMONITOR_ADMIN_ROLES', 
                         os.getenv('TRAFFICMONITOR_ADMIN_ROLES', 'admin,superuser').split(','))
    
    # Authentication Headers
    USER_ID_HEADER = getattr(settings, 'TRAFFICMONITOR_USER_ID_HEADER', 
                            os.getenv('TRAFFICMONITOR_USER_ID_HEADER', 'X-User-ID'))
    USER_ROLE_HEADER = getattr(settings, 'TRAFFICMONITOR_USER_ROLE_HEADER', 
                              os.getenv('TRAFFICMONITOR_USER_ROLE_HEADER', 'X-User-Role'))
    
    # Data Retention
    RETENTION_DAYS = int(getattr(settings, 'TRAFFICMONITOR_RETENTION_DAYS', 
                                os.getenv('TRAFFICMONITOR_RETENTION_DAYS', '90')))
    
    # Performance Settings
    ASYNC_LOGGING = getattr(settings, 'TRAFFICMONITOR_ASYNC_LOGGING', 
                           os.getenv('TRAFFICMONITOR_ASYNC_LOGGING', 'false').lower() == 'true')
    
    ENABLE_SAMPLING = getattr(settings, 'TRAFFICMONITOR_ENABLE_SAMPLING', 
                             os.getenv('TRAFFICMONITOR_ENABLE_SAMPLING', 'false').lower() == 'true')
    
    SAMPLE_RATE = float(getattr(settings, 'TRAFFICMONITOR_SAMPLE_RATE', 
                               os.getenv('TRAFFICMONITOR_SAMPLE_RATE', '1.0')))
    
    # Database Settings
    BULK_CREATE_BATCH_SIZE = int(getattr(settings, 'TRAFFICMONITOR_BULK_BATCH_SIZE', 
                                        os.getenv('TRAFFICMONITOR_BULK_BATCH_SIZE', '1000')))
    
    # Circuit Breaker Settings
    CIRCUIT_BREAKER_ENABLED = getattr(settings, 'TRAFFICMONITOR_CIRCUIT_BREAKER_ENABLED', 
                                     os.getenv('TRAFFICMONITOR_CIRCUIT_BREAKER_ENABLED', 'true').lower() == 'true')
    
    CIRCUIT_BREAKER_FAILURE_THRESHOLD = int(getattr(settings, 'TRAFFICMONITOR_CB_FAILURE_THRESHOLD', 
                                                   os.getenv('TRAFFICMONITOR_CB_FAILURE_THRESHOLD', '5')))
    
    # Security Settings
    ENABLE_PII_SANITIZATION = getattr(settings, 'TRAFFICMONITOR_ENABLE_PII_SANITIZATION', 
                                     os.getenv('TRAFFICMONITOR_ENABLE_PII_SANITIZATION', 'true').lower() == 'true')
    
    MAX_BODY_LENGTH = int(getattr(settings, 'TRAFFICMONITOR_MAX_BODY_LENGTH', 
                                 os.getenv('TRAFFICMONITOR_MAX_BODY_LENGTH', '10000')))
    
    # Excluded Paths (production optimized)
    DEFAULT_EXCLUDED_PATHS = [
        '/admin/jsi18n/',
        '/static/',
        '/media/',
        '/__debug__/',
        '/favicon.ico',
        '/health/',
        '/healthz/',
        '/metrics/',
        '/prometheus/',
    ]
    
    EXCLUDED_PATHS = getattr(settings, 'TRAFFICMONITOR_EXCLUDED_PATHS', DEFAULT_EXCLUDED_PATHS)
    
    # Monitoring & Alerting
    ENABLE_METRICS = getattr(settings, 'TRAFFICMONITOR_ENABLE_METRICS', 
                            os.getenv('TRAFFICMONITOR_ENABLE_METRICS', 'true').lower() == 'true')
    
    ALERT_ERROR_THRESHOLD = int(getattr(settings, 'TRAFFICMONITOR_ALERT_ERROR_THRESHOLD', 
                                       os.getenv('TRAFFICMONITOR_ALERT_ERROR_THRESHOLD', '100')))
    
    @classmethod
    def validate_configuration(cls) -> List[str]:
        """Validate configuration and return list of issues"""
        issues = []
        
        if cls.SAMPLE_RATE < 0 or cls.SAMPLE_RATE > 1:
            issues.append("SAMPLE_RATE must be between 0 and 1")
        
        if cls.RETENTION_DAYS < 1:
            issues.append("RETENTION_DAYS must be positive")
        
        if cls.BULK_CREATE_BATCH_SIZE < 1:
            issues.append("BULK_CREATE_BATCH_SIZE must be positive")
        
        return issues
    
    @classmethod
    def get_production_settings(cls) -> Dict[str, Any]:
        """Get recommended production settings"""
        return {
            'ASYNC_LOGGING': True,
            'ENABLE_SAMPLING': True,
            'SAMPLE_RATE': 0.1,  # 10% sampling in production
            'CIRCUIT_BREAKER_ENABLED': True,
            'ENABLE_PII_SANITIZATION': True,
            'ENABLE_METRICS': True,
            'BULK_CREATE_BATCH_SIZE': 5000,
        }
    
    @classmethod
    def is_user_authorized(cls, user_role, required_roles=None):
        """
        Check if user role has access.
        
        Args:
            user_role: Role from header (X-User-Role)
            required_roles: List of required roles (defaults to VIEWER_ROLES + ADMIN_ROLES)
        
        Returns:
            Boolean indicating if user is authorized
        """
        if not user_role:
            return False
        
        if required_roles is None:
            required_roles = cls.VIEWER_ROLES + cls.ADMIN_ROLES
        
        return user_role.lower() in [r.lower() for r in required_roles]
    
    @classmethod
    def is_admin(cls, user_role):
        """Check if user has admin role"""
        return cls.is_user_authorized(user_role, cls.ADMIN_ROLES)
    
    @classmethod
    def get_user_info_from_request(cls, request):
        """
        Extract user ID and role from request headers.
        
        Returns:
            dict: {'user_id': str, 'role': str}
        """
        # Primary header check (defaults to HTTP_X_USER_ID)
        user_id = request.META.get(f'HTTP_{cls.USER_ID_HEADER.replace("-", "_").upper()}')
        
        # Fallback: standard User-Id (HTTP_USER_ID)
        if not user_id:
            user_id = request.META.get('HTTP_USER_ID')
            
        user_role = request.META.get(f'HTTP_{cls.USER_ROLE_HEADER.replace("-", "_").upper()}')
        
        return {
            'user_id': user_id,
            'role': user_role
        }
