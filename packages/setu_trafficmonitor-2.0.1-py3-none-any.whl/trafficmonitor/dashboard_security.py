"""
Dashboard security middleware and utilities
"""
from django.http import HttpResponseForbidden, JsonResponse
from django.utils.deprecation import MiddlewareMixin
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.clickjacking import xframe_options_deny
from django.views.decorators.cache import never_cache
from functools import wraps
import logging

logger = logging.getLogger(__name__)


class DashboardSecurityMiddleware(MiddlewareMixin):
    """Security middleware specifically for dashboard endpoints"""
    
    def process_request(self, request):
        # Only apply to analytics endpoints
        if not request.path.startswith('/analytics/') and not request.path.startswith('/api/analytics/'):
            return None
        
        # Add security headers
        return None
    
    def process_response(self, request, response):
        # Only apply to analytics endpoints
        if not request.path.startswith('/analytics/') and not request.path.startswith('/api/analytics/'):
            return response
        
        # Security headers for dashboard
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'DENY'
        response['X-XSS-Protection'] = '1; mode=block'
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        
        # CSP for dashboard
        csp = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "font-src 'self'; "
            "connect-src 'self'; "
            "frame-ancestors 'none';"
        )
        response['Content-Security-Policy'] = csp
        
        return response


def dashboard_auth_required(view_func):
    """
    Decorator for dashboard views requiring authentication
    """
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        from trafficmonitor.conf import TrafficMonitorConfig
        
        # Get user info from headers
        user_info = TrafficMonitorConfig.get_user_info_from_request(request)
        
        if not TrafficMonitorConfig.is_user_authorized(user_info.get('role')):
            logger.warning(f"Unauthorized dashboard access attempt from {request.META.get('REMOTE_ADDR')}")
            
            if request.path.startswith('/api/'):
                return JsonResponse({'error': 'Unauthorized'}, status=401)
            else:
                return HttpResponseForbidden("Access denied. Required role not found in headers.")
        
        # Add user info to request for logging
        request.trafficmonitor_user = user_info
        
        return view_func(request, *args, **kwargs)
    
    return wrapper


def rate_limit_dashboard(max_requests=100, window_seconds=3600):
    """
    Simple rate limiting for dashboard endpoints
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            from django.core.cache import cache
            
            # Get client identifier
            client_ip = request.META.get('REMOTE_ADDR', 'unknown')
            user_id = getattr(request, 'trafficmonitor_user', {}).get('user_id', 'anonymous')
            
            cache_key = f"dashboard_rate_limit:{client_ip}:{user_id}"
            
            # Get current request count
            current_requests = cache.get(cache_key, 0)
            
            if current_requests >= max_requests:
                logger.warning(f"Rate limit exceeded for {client_ip}:{user_id}")
                
                if request.path.startswith('/api/'):
                    return JsonResponse({'error': 'Rate limit exceeded'}, status=429)
                else:
                    return HttpResponseForbidden("Rate limit exceeded. Please try again later.")
            
            # Increment counter
            cache.set(cache_key, current_requests + 1, timeout=window_seconds)
            
            return view_func(request, *args, **kwargs)
        
        return wrapper
    return decorator
