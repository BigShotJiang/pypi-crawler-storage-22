"""
Database utilities for enterprise-grade performance
"""
from django.db import transaction
from django.core.cache import cache
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)


class DatabaseManager:
    """Handles database operations with connection pooling and bulk operations"""
    
    @staticmethod
    @transaction.atomic
    def bulk_create_logs(log_data: List[Dict[str, Any]], batch_size: int = 1000):
        """Bulk create request logs with proper transaction handling"""
        from trafficmonitor.models import RequestLog
        
        logs = []
        for data in log_data:
            logs.append(RequestLog(**data))
            
        # Use bulk_create with ignore_conflicts for high concurrency
        RequestLog.objects.bulk_create(logs, batch_size=batch_size, ignore_conflicts=True)
        
    @staticmethod
    def get_cached_analytics(cache_key: str, query_func, ttl: int = 300):
        """Cache analytics queries with proper invalidation"""
        cached_result = cache.get(cache_key)
        if cached_result is not None:
            return cached_result
            
        result = query_func()
        cache.set(cache_key, result, ttl)
        return result
