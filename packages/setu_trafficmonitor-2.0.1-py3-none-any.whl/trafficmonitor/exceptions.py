"""
Custom exceptions and error handling for TrafficMonitor
"""
import time
import functools
from typing import Callable, Any, Type, Tuple
import logging

logger = logging.getLogger(__name__)


class TrafficMonitorException(Exception):
    """Base exception for TrafficMonitor"""
    pass


class DatabaseConnectionError(TrafficMonitorException):
    """Database connection related errors"""
    pass


class ConfigurationError(TrafficMonitorException):
    """Configuration validation errors"""
    pass


class AuthenticationError(TrafficMonitorException):
    """Authentication/authorization errors"""
    pass


def retry_on_exception(
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0
):
    """
    Decorator for retrying functions on specific exceptions
    
    Args:
        exceptions: Tuple of exception types to retry on
        max_attempts: Maximum number of retry attempts
        delay: Initial delay between retries (seconds)
        backoff: Multiplier for delay on each retry
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            current_delay = delay
            
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts - 1:
                        logger.error(f"Function {func.__name__} failed after {max_attempts} attempts: {e}")
                        raise
                    
                    logger.warning(f"Attempt {attempt + 1} failed for {func.__name__}: {e}. Retrying in {current_delay}s")
                    time.sleep(current_delay)
                    current_delay *= backoff
            
            return None  # Should never reach here
        return wrapper
    return decorator


class ErrorHandler:
    """Centralized error handling"""
    
    @staticmethod
    def handle_database_error(error: Exception, context: dict) -> None:
        """Handle database-related errors"""
        logger.error("Database error occurred", extra={
            "error_type": type(error).__name__,
            "error_message": str(error),
            "context": context
        }, exc_info=True)
        
        # Could integrate with alerting system here
        
    @staticmethod
    def handle_middleware_error(error: Exception, request) -> None:
        """Handle middleware errors gracefully"""
        logger.error("Middleware error occurred", extra={
            "error_type": type(error).__name__,
            "error_message": str(error),
            "path": getattr(request, 'path', 'unknown'),
            "method": getattr(request, 'method', 'unknown')
        }, exc_info=True)
        
        # Don't let middleware errors break the request flow
