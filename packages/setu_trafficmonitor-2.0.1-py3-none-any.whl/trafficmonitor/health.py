"""
Health checks for TrafficMonitor
"""
from django.db import connection
from django.core.cache import cache
from django.http import JsonResponse
from django.views import View
from typing import Dict, Any
import time


class HealthCheckView(View):
    """Health check endpoint for load balancers"""
    
    def get(self, request):
        """Perform health checks"""
        health_status = {
            'status': 'healthy',
            'timestamp': time.time(),
            'checks': {}
        }
        
        # Database check
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
            health_status['checks']['database'] = {'status': 'healthy'}
        except Exception as e:
            health_status['checks']['database'] = {'status': 'unhealthy', 'error': str(e)}
            health_status['status'] = 'unhealthy'
        
        # Cache check
        try:
            cache.set('health_check', 'ok', 30)
            cache.get('health_check')
            health_status['checks']['cache'] = {'status': 'healthy'}
        except Exception as e:
            health_status['checks']['cache'] = {'status': 'unhealthy', 'error': str(e)}
            health_status['status'] = 'unhealthy'
        
        # Configuration check
        from trafficmonitor.conf import TrafficMonitorConfig
        config_issues = TrafficMonitorConfig.validate_configuration()
        if config_issues:
            health_status['checks']['configuration'] = {'status': 'unhealthy', 'issues': config_issues}
            health_status['status'] = 'unhealthy'
        else:
            health_status['checks']['configuration'] = {'status': 'healthy'}
        
        status_code = 200 if health_status['status'] == 'healthy' else 503
        return JsonResponse(health_status, status=status_code)


class ReadinessCheckView(View):
    """Readiness check for Kubernetes"""
    
    def get(self, request):
        """Check if application is ready to serve traffic"""
        from trafficmonitor.models import RequestLog
        
        try:
            # Check if we can query the database
            RequestLog.objects.first()
            return JsonResponse({'status': 'ready'})
        except Exception as e:
            return JsonResponse({'status': 'not_ready', 'error': str(e)}, status=503)
