"""
Aggressive Load Testing Script for Analytics Dashboard
Tests dashboard performance under extreme load with various HTTP methods.

Usage:
    python trafficmonitor/load_test.py --threads 10 --requests 1000
    python trafficmonitor/load_test.py --aggressive --duration 60
"""

import argparse
import json
import os
import random
import string
import sys
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from queue import Queue

# Add project directory to path
project_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_dir))

import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'setu.settings')
django.setup()

from django.contrib.auth import get_user_model
from django.utils import timezone
from trafficmonitor.models import RequestLog

User = get_user_model()


class LoadTestStats:
    """Thread-safe statistics collector."""

    def __init__(self):
        self.lock = threading.Lock()
        self.total_requests = 0
        self.successful_requests = 0
        self.failed_requests = 0
        self.total_time = 0
        self.errors = []
        self.start_time = None
        self.end_time = None
        self.response_times = []

    def record_success(self, response_time):
        with self.lock:
            self.total_requests += 1
            self.successful_requests += 1
            self.total_time += response_time
            self.response_times.append(response_time)

    def record_failure(self, error):
        with self.lock:
            self.total_requests += 1
            self.failed_requests += 1
            self.errors.append(str(error))

    def get_stats(self):
        with self.lock:
            duration = (self.end_time - self.start_time).total_seconds() if self.end_time and self.start_time else 0
            avg_time = self.total_time / self.successful_requests if self.successful_requests > 0 else 0

            sorted_times = sorted(self.response_times)
            p50 = sorted_times[len(sorted_times) // 2] if sorted_times else 0
            p95 = sorted_times[int(len(sorted_times) * 0.95)] if sorted_times else 0
            p99 = sorted_times[int(len(sorted_times) * 0.99)] if sorted_times else 0

            return {
                'total_requests': self.total_requests,
                'successful': self.successful_requests,
                'failed': self.failed_requests,
                'duration_seconds': duration,
                'requests_per_second': self.total_requests / duration if duration > 0 else 0,
                'avg_response_time_ms': avg_time * 1000,
                'p50_ms': p50 * 1000,
                'p95_ms': p95 * 1000,
                'p99_ms': p99 * 1000,
                'error_rate': self.failed_requests / self.total_requests * 100 if self.total_requests > 0 else 0,
                'errors': self.errors[:10],  # First 10 errors
            }


class RequestGenerator:
    """Generates realistic test requests."""

    METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']
    STATUS_CODES = [200, 201, 400, 401, 403, 404, 500, 502, 503]
    ENDPOINTS = [
        '/api/v1/users/',
        '/api/v1/products/',
        '/api/v1/orders/',
        '/api/v1/monitoring/',
        '/api/v1/operations/',
        '/api/v1/nursery/',
        '/api/v1/reports/',
        '/api/v1/contracts/',
        '/api/v1/finance/',
        '/api/v1/integrations/',
    ]

    def __init__(self, user=None):
        self.user = user

    def generate_random_request(self):
        """Generate a random request log entry."""
        method = random.choice(self.METHODS)
        endpoint = random.choice(self.ENDPOINTS)
        status_code = random.choice(self.STATUS_CODES)

        # Weighted towards success
        if random.random() < 0.7:
            status_code = 200 if method == 'GET' else 201

        response_time = random.uniform(10, 2000)  # 10ms to 2s
        if status_code >= 500:
            response_time = random.uniform(500, 5000)  # Errors are slower

        return {
            'method': method,
            'path': endpoint + self._random_id(),
            'full_url': f'http://localhost:8000{endpoint}',
            'status_code': status_code,
            'requested_user_id': str(self.user.pk) if self.user else None,
            'ip_address': self._random_ip(),
            'user_agent': self._random_user_agent(),
            'response_time_ms': response_time,
            'query_count': random.randint(1, 50),
            'content_length': random.randint(100, 10000),
            'timestamp': timezone.now() - timedelta(seconds=random.randint(0, 3600)),
        }

    def _random_id(self):
        """Generate random ID for URL."""
        return str(random.randint(1, 10000))

    def _random_ip(self):
        """Generate random IP address."""
        return f'192.168.{random.randint(1, 255)}.{random.randint(1, 255)}'

    def _random_user_agent(self):
        """Generate random user agent."""
        agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            'PostmanRuntime/7.29.2',
            'python-requests/2.28.1',
        ]
        return random.choice(agents)


class LoadTester:
    """Main load testing coordinator."""

    def __init__(self, num_threads=10, requests_per_thread=100, duration=None, aggressive=False):
        self.num_threads = num_threads
        self.requests_per_thread = requests_per_thread
        self.duration = duration  # Duration in seconds
        self.aggressive = aggressive
        self.stats = LoadTestStats()
        self.stop_flag = threading.Event()

        # Create test user
        self.user, _ = User.objects.get_or_create(
            username='loadtest_user',
            defaults={'email': 'loadtest@test.com'}
        )

        self.generator = RequestGenerator(user=self.user)

    def _worker_thread(self, thread_id, task_queue):
        """Worker thread that processes load testing tasks."""
        while not self.stop_flag.is_set():
            try:
                # Check if we should stop
                if self.duration:
                    if (datetime.now() - self.stats.start_time).total_seconds() >= self.duration:
                        break

                # Get task from queue
                try:
                    task = task_queue.get(timeout=0.1)
                except:
                    if not self.duration:
                        break
                    continue

                # Execute task
                start = time.time()
                try:
                    self._create_request_log()
                    elapsed = time.time() - start
                    self.stats.record_success(elapsed)
                except Exception as e:
                    self.stats.record_failure(e)
                finally:
                    if not self.duration:
                        task_queue.task_done()

                # In aggressive mode, don't sleep
                if not self.aggressive:
                    time.sleep(random.uniform(0.001, 0.01))

            except Exception as e:
                print(f"Thread {thread_id} error: {e}")

    def _create_request_log(self):
        """Create a request log entry."""
        log_data = self.generator.generate_random_request()
        RequestLog.objects.create(**log_data)

    def _bulk_create_requests(self, count):
        """Bulk create request logs for initial data."""
        print(f"Creating {count} initial request logs...")

        logs = []
        for i in range(count):
            log_data = self.generator.generate_random_request()
            logs.append(RequestLog(**log_data))

            if len(logs) >= 1000:
                RequestLog.objects.bulk_create(logs, ignore_conflicts=True)
                logs = []
                print(f"  Created {i + 1}/{count}...")

        if logs:
            RequestLog.objects.bulk_create(logs, ignore_conflicts=True)

        print(f"✓ Created {count} initial logs")

    def run(self, create_initial_data=0):
        """Run the load test."""
        print("=" * 70)
        print("ANALYTICS DASHBOARD LOAD TEST")
        print("=" * 70)
        print(f"Threads: {self.num_threads}")
        print(f"Requests per thread: {self.requests_per_thread if not self.duration else 'unlimited'}")
        print(f"Duration: {self.duration}s" if self.duration else "Duration: Until complete")
        print(f"Mode: {'AGGRESSIVE' if self.aggressive else 'NORMAL'}")
        print("=" * 70)

        # Create initial data if requested
        if create_initial_data > 0:
            self._bulk_create_requests(create_initial_data)

        # Create task queue
        task_queue = Queue()

        if not self.duration:
            # Queue-based: Fixed number of requests
            total_requests = self.num_threads * self.requests_per_thread
            for i in range(total_requests):
                task_queue.put(i)
            print(f"\nQueued {total_requests} requests\n")
        else:
            # Time-based: Run for duration
            print(f"\nRunning for {self.duration} seconds\n")

        # Start timer
        self.stats.start_time = datetime.now()

        # Create and start worker threads
        threads = []
        for i in range(self.num_threads):
            t = threading.Thread(
                target=self._worker_thread,
                args=(i, task_queue),
                daemon=True
            )
            t.start()
            threads.append(t)

        # Progress reporter
        def report_progress():
            while not self.stop_flag.is_set():
                time.sleep(5)
                current_stats = self.stats.get_stats()
                print(f"Progress: {current_stats['total_requests']} requests, "
                      f"{current_stats['requests_per_second']:.1f} req/s, "
                      f"{current_stats['error_rate']:.1f}% errors")

        reporter = threading.Thread(target=report_progress, daemon=True)
        reporter.start()

        # Wait for completion
        try:
            if self.duration:
                time.sleep(self.duration)
                self.stop_flag.set()
            else:
                task_queue.join()

            # Wait for threads
            for t in threads:
                t.join(timeout=5)

        except KeyboardInterrupt:
            print("\n\nStopping load test...")
            self.stop_flag.set()

        self.stats.end_time = datetime.now()

        # Print results
        self._print_results()

    def _print_results(self):
        """Print test results."""
        stats = self.stats.get_stats()

        print("\n" + "=" * 70)
        print("LOAD TEST RESULTS")
        print("=" * 70)
        print(f"Total Requests:      {stats['total_requests']:,}")
        print(f"Successful:          {stats['successful']:,}")
        print(f"Failed:              {stats['failed']:,}")
        print(f"Duration:            {stats['duration_seconds']:.2f}s")
        print(f"Requests/sec:        {stats['requests_per_second']:.2f}")
        print(f"Error Rate:          {stats['error_rate']:.2f}%")
        print("\nResponse Times:")
        print(f"  Average:           {stats['avg_response_time_ms']:.2f}ms")
        print(f"  50th percentile:   {stats['p50_ms']:.2f}ms")
        print(f"  95th percentile:   {stats['p95_ms']:.2f}ms")
        print(f"  99th percentile:   {stats['p99_ms']:.2f}ms")

        if stats['errors']:
            print("\nSample Errors:")
            for i, error in enumerate(stats['errors'], 1):
                print(f"  {i}. {error}")

        print("=" * 70)

        # Database stats
        total_logs = RequestLog.objects.count()
        print(f"\nTotal logs in database: {total_logs:,}")

        # Test analytics query performance
        print("\nTesting Analytics Dashboard Performance...")
        self._test_dashboard_performance()

    def _test_dashboard_performance(self):
        """Test how long analytics queries take."""
        from trafficmonitor.analytics.views import AnalyticsQueryHelper

        now = timezone.now()
        start = now - timedelta(days=7)

        tests = [
            ("Total Requests", lambda: AnalyticsQueryHelper.get_total_requests(start, now)),
            ("Status Codes", lambda: AnalyticsQueryHelper.get_requests_by_status_code(start, now)),
            ("Top Endpoints", lambda: AnalyticsQueryHelper.get_top_endpoints(start, now)),
            ("Comprehensive Analytics", lambda: AnalyticsQueryHelper.get_comprehensive_analytics(start, now)),
        ]

        print("\nQuery Performance:")
        for test_name, test_func in tests:
            start_time = time.time()
            try:
                result = test_func()
                elapsed = (time.time() - start_time) * 1000
                print(f"  {test_name:.<35} {elapsed:>8.2f}ms ✓")
            except Exception as e:
                elapsed = (time.time() - start_time) * 1000
                print(f"  {test_name:.<35} {elapsed:>8.2f}ms ✗ ({str(e)[:30]})")


def main():
    parser = argparse.ArgumentParser(description='Load test the analytics dashboard')
    parser.add_argument('--threads', '-t', type=int, default=10,
                        help='Number of concurrent threads (default: 10)')
    parser.add_argument('--requests', '-r', type=int, default=100,
                        help='Requests per thread (default: 100)')
    parser.add_argument('--duration', '-d', type=int,
                        help='Run for specified seconds (overrides --requests)')
    parser.add_argument('--aggressive', '-a', action='store_true',
                        help='Aggressive mode: no delays between requests')
    parser.add_argument('--initial-data', '-i', type=int, default=0,
                        help='Create N initial logs before test (default: 0)')
    parser.add_argument('--preset', choices=['light', 'medium', 'heavy', 'extreme'],
                        help='Use preset configuration')

    args = parser.parse_args()

    # Handle presets
    if args.preset == 'light':
        args.threads = 5
        args.requests = 100
        args.initial_data = 1000
    elif args.preset == 'medium':
        args.threads = 20
        args.requests = 500
        args.initial_data = 10000
    elif args.preset == 'heavy':
        args.threads = 50
        args.requests = 1000
        args.initial_data = 50000
        args.aggressive = True
    elif args.preset == 'extreme':
        args.threads = 100
        args.duration = 60
        args.initial_data = 100000
        args.aggressive = True

    # Create and run load tester
    tester = LoadTester(
        num_threads=args.threads,
        requests_per_thread=args.requests,
        duration=args.duration,
        aggressive=args.aggressive
    )

    tester.run(create_initial_data=args.initial_data)


if __name__ == '__main__':
    main()
