"""
Management command to cleanup old request logs
"""
from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from trafficmonitor.models import RequestLog
from trafficmonitor.conf import TrafficMonitorConfig


class Command(BaseCommand):
    help = 'Cleanup old request logs based on retention policy'

    def add_arguments(self, parser):
        parser.add_argument(
            '--days',
            type=int,
            default=TrafficMonitorConfig.RETENTION_DAYS,
            help=f'Number of days to retain (default: {TrafficMonitorConfig.RETENTION_DAYS})'
        )
        parser.add_argument(
            '--batch-size',
            type=int,
            default=10000,
            help='Batch size for deletion (default: 10000)'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be deleted without actually deleting'
        )

    def handle(self, *args, **options):
        days = options['days']
        batch_size = options['batch_size']
        dry_run = options['dry_run']
        
        cutoff_date = timezone.now() - timedelta(days=days)
        
        # Count logs to be deleted
        logs_to_delete = RequestLog.objects.filter(timestamp__lt=cutoff_date)
        total_count = logs_to_delete.count()
        
        if total_count == 0:
            self.stdout.write(
                self.style.SUCCESS(f'No logs older than {days} days found.')
            )
            return
        
        if dry_run:
            self.stdout.write(
                self.style.WARNING(
                    f'DRY RUN: Would delete {total_count} logs older than {cutoff_date}'
                )
            )
            return
        
        # Delete in batches
        deleted_total = 0
        while True:
            batch_ids = list(
                logs_to_delete.values_list('id', flat=True)[:batch_size]
            )
            
            if not batch_ids:
                break
            
            deleted_count, _ = RequestLog.objects.filter(id__in=batch_ids).delete()
            deleted_total += deleted_count
            
            self.stdout.write(f'Deleted {deleted_count} logs (total: {deleted_total}/{total_count})')
        
        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully deleted {deleted_total} logs older than {days} days'
            )
        )
