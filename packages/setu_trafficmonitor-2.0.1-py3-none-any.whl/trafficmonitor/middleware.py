import json
import logging
import time
import traceback
import random
from io import BytesIO
from threading import local
from contextlib import contextmanager

from django.db import connection, transaction
from django.utils.deprecation import MiddlewareMixin
from django.core.cache import cache

from trafficmonitor.models import RequestLog
from trafficmonitor.conf import TrafficMonitorConfig
from trafficmonitor.circuit_breaker import CircuitBreaker

logger = logging.getLogger(__name__)

# Thread-local storage for request context
_local = local()


class RequestLoggingMiddleware(MiddlewareMixin):
    """
    Enterprise-grade middleware for HTTP request logging.
    Features: Circuit breaker, async logging, PII sanitization, metrics collection.
    """
    
    EXCLUDED_PATHS = [
        '/admin/jsi18n/',
        '/static/',
        '/media/',
        '/__debug__/',
        '/favicon.ico',
        '/health/',
    ]

    def __init__(self, get_response):
        super().__init__(get_response)
        self.circuit_breaker = CircuitBreaker() if TrafficMonitorConfig.CIRCUIT_BREAKER_ENABLED else None
        
    def process_request(self, request):
        """Initialize request tracking"""
        request._logging_start_time = time.time()
        request._logging_query_count_start = len(connection.queries)
        return None

    def process_response(self, request, response):
        """Log request with enterprise features"""
        try:
            # Skip excluded paths
            if self._should_exclude_path(request.path):
                return response
            
            # Apply sampling
            if TrafficMonitorConfig.ENABLE_SAMPLING and random.random() > TrafficMonitorConfig.SAMPLE_RATE:
                return response
            
            # Collect metrics
            if TrafficMonitorConfig.ENABLE_METRICS:
                self._collect_metrics(request, response)
            
            # Log request
            if self.circuit_breaker:
                self.circuit_breaker.call(self._log_request_safe, request, response)
            else:
                self._log_request_safe(request, response)
                
        except Exception as e:
            # Never let logging break the request
            logger.error(f"Request logging failed: {e}", exc_info=True)
        
        return response
    
    def _log_request_safe(self, request, response):
        """Safely log request with error handling"""
        from trafficmonitor.security import DataSanitizer, SecurityValidator
        from trafficmonitor.monitoring import performance_timer
        
        with performance_timer("request_logging_duration"):
            log_data = self._build_log_data(request, response)
            
            if TrafficMonitorConfig.ASYNC_LOGGING:
                self._log_async(log_data)
            else:
                self._log_sync(log_data)
    
    def _build_log_data(self, request, response):
        """Build sanitized log data"""
        from trafficmonitor.security import DataSanitizer, SecurityValidator
        
        # Calculate metrics
        duration_ms = (time.time() - request._logging_start_time) * 1000
        query_count = len(connection.queries) - request._logging_query_count_start
        
        # Get user info
        user_info = TrafficMonitorConfig.get_user_info_from_request(request)
        
        # Sanitize data
        headers = DataSanitizer.sanitize_headers(dict(request.META))
        body = self._get_request_body(request)
        if TrafficMonitorConfig.ENABLE_PII_SANITIZATION:
            body = DataSanitizer.sanitize_body(body, TrafficMonitorConfig.MAX_BODY_LENGTH)
        
        return {
            'method': request.method,
            'path': request.path,
            'full_url': request.build_absolute_uri(),
            'status_code': response.status_code,
            'requested_user_id': user_info.get('user_id'),
            'ip_address': SecurityValidator.get_client_ip(request),
            'user_agent': request.META.get('HTTP_USER_AGENT', ''),
            'request_headers': headers,
            'request_body': body,
            'operation_type': RequestLog.get_operation_type(request.method),
            'endpoint_category': RequestLog.extract_endpoint_category(request.path),
            'is_api_request': request.path.startswith('/api/'),
            'response_time_ms': duration_ms,
            'query_count': query_count,
            'content_length': len(response.content) if hasattr(response, 'content') else None,
        }
    
    def _collect_metrics(self, request, response):
        """Collect application metrics"""
        from trafficmonitor.monitoring import metrics
        
        tags = {
            'method': request.method,
            'status_code': str(response.status_code),
            'endpoint': request.path[:50]  # Truncate long paths
        }
        
        metrics.increment('requests_total', tags=tags)
        
        if response.status_code >= 400:
            metrics.increment('requests_errors', tags=tags)
        
        if response.status_code >= 500:
            metrics.increment('requests_server_errors', tags=tags)
    
    def _log_async(self, log_data):
        """Log asynchronously using Celery"""
        try:
            from trafficmonitor.tasks import log_request_async
            log_request_async.delay(log_data)
        except ImportError:
            logger.warning("Celery not available, falling back to sync logging")
            self._log_sync(log_data)
    
    def _log_sync(self, log_data):
        """Log synchronously"""
        try:
            RequestLog.objects.create(**log_data)
        except Exception as e:
            logger.error(f"Failed to create RequestLog: {e}", exc_info=True)
    
    def _should_exclude_path(self, path):
        """Check if path should be excluded from logging"""
        return any(excluded in path for excluded in TrafficMonitorConfig.EXCLUDED_PATHS)
    
    def _get_request_body(self, request):
        """Safely get request body"""
        try:
            if hasattr(request, '_body'):
                return request._body.decode('utf-8')
            elif hasattr(request, 'body'):
                return request.body.decode('utf-8')
        except Exception as e:
            logger.debug(f"Error extracting request body: {str(e)}")

        return None

    def process_exception(self, request, exception):
        """
        Called when a view raises an exception.
        Logs the exception details.
        """
        # Skip logging for excluded paths
        if self._should_exclude_path(request.path):
            return None

        try:
            # Calculate response time
            response_time_ms = None
            if hasattr(request, '_logging_start_time'):
                response_time_ms = (time.time() - request._logging_start_time) * 1000

            # Calculate query count
            query_count = None
            if hasattr(request, '_logging_query_count_start'):
                query_count = len(connection.queries) - request._logging_query_count_start

            # Extract request data
            request_headers = self._get_request_headers(request)
            request_body = self._get_request_body(request)

            # Get user ID from header
            requested_user_id = request.META.get('HTTP_X_USER_ID') or request.headers.get('X-User-ID')

            # Get IP address
            ip_address = self._get_client_ip(request)
            
            # Determine operation type and endpoint category
            operation_type = RequestLog.get_operation_type(request.method)
            endpoint_category = RequestLog.extract_endpoint_category(request.path)
            is_api_request = request.path.startswith('/api/')

            # Get exception traceback
            exception_traceback = ''.join(traceback.format_exception(
                type(exception), exception, exception.__traceback__
            ))

            # Prepare log data with exception
            log_data = {
                'method': request.method,
                'path': request.path,
                'full_url': request.build_absolute_uri(),
                'status_code': 500,  # Internal Server Error
                'requested_user_id': requested_user_id,
                'ip_address': ip_address,
                'user_agent': request.META.get('HTTP_USER_AGENT', ''),
                'request_headers': request_headers,
                'request_body': request_body,
                'operation_type': operation_type,
                'endpoint_category': endpoint_category,
                'is_api_request': is_api_request,
                'response_time_ms': response_time_ms,
                'query_count': query_count,
                'exception': exception_traceback,
            }
            
            # Log asynchronously or synchronously
            if TrafficMonitorConfig.ASYNC_LOGGING:
                self._log_async(log_data)
            else:
                RequestLog.objects.create(**log_data)

        except Exception as e:
            # Log the error but don't break the request/response cycle
            logger.error(f"Error logging exception: {str(e)}", exc_info=True)

        return None

    def _should_exclude_path(self, path):
        """
        Check if the request path should be excluded from logging.
        """
        for excluded_path in self.EXCLUDED_PATHS:
            if path.startswith(excluded_path):
                return True
        return False
    
    def _log_async(self, log_data):
        """
        Log request data asynchronously using Celery.
        Falls back to synchronous logging if Celery is unavailable.
        """
        try:
            from trafficmonitor.tasks import log_request_async
            log_request_async.delay(log_data)
        except Exception as e:
            logger.warning(f"Async logging failed, falling back to sync: {e}")
            RequestLog.objects.create(**log_data)

    def _get_request_body(self, request):
        """
        Extract and return the request body.
        Handles both JSON and form data.
        """
        try:
            if request.method in ['POST', 'PUT', 'PATCH']:
                # Try to get JSON body
                if request.content_type and 'application/json' in request.content_type:
                    body = request.body.decode('utf-8')
                    # Truncate if too long
                    if len(body) > self.MAX_BODY_LENGTH:
                        body = body[:self.MAX_BODY_LENGTH] + '... [truncated]'
                    return body
                # For form data, log the POST data
                elif request.POST:
                    body = json.dumps(dict(request.POST))
                    if len(body) > self.MAX_BODY_LENGTH:
                        body = body[:self.MAX_BODY_LENGTH] + '... [truncated]'
                    return body
        except Exception as e:
            logger.debug(f"Error extracting request body: {str(e)}")

        return None

    def _get_request_headers(self, request):
        """
        Extract and return request headers as a dictionary.
        Filters out sensitive headers and ensures JSON serializable values.
        """
        sensitive_headers = [
            'HTTP_AUTHORIZATION',
            'HTTP_COOKIE',
            'HTTP_X_CSRFTOKEN',
        ]

        headers = {}
        for key, value in request.META.items():
            if key.startswith('HTTP_') and key not in sensitive_headers:
                # Remove HTTP_ prefix and convert to title case
                header_name = key[5:].replace('_', '-').title()
                # Ensure value is JSON serializable
                try:
                    headers[header_name] = str(value)
                except:
                    headers[header_name] = '<non-serializable>'

        return headers

    def _get_client_ip(self, request):
        """
        Extract and return the client's IP address.
        Handles X-Forwarded-For header for proxied requests.
        """
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            # Get the first IP in the chain
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')

        return ip
