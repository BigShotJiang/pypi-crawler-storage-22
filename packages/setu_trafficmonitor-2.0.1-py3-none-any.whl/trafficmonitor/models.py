import uuid
from django.conf import settings
from django.db import models
from django.core.serializers.json import DjangoJSONEncoder
from django.utils import timezone
from datetime import timedelta


class RequestLogManager(models.Manager):
    """Custom manager for RequestLog with optimized queries"""
    
    def get_recent_logs(self, days: int = 7):
        """Get logs from the last N days"""
        cutoff_date = timezone.now() - timedelta(days=days)
        return self.filter(timestamp__gte=cutoff_date)
    
    def get_error_logs(self, days: int = 1):
        """Get error logs (4xx, 5xx) from the last N days"""
        cutoff_date = timezone.now() - timedelta(days=days)
        return self.filter(
            timestamp__gte=cutoff_date,
            status_code__gte=400
        )
    
    def cleanup_old_logs(self, retention_days: int = 90):
        """Delete logs older than retention period"""
        cutoff_date = timezone.now() - timedelta(days=retention_days)
        deleted_count, _ = self.filter(timestamp__lt=cutoff_date).delete()
        return deleted_count


class RequestLog(models.Model):
    """
    Enterprise-grade model for HTTP request logging.
    Optimized for high-volume traffic with partitioning support.
    """
    
    # Operation Types
    OPERATION_READ = 'READ'
    OPERATION_WRITE = 'WRITE'
    OPERATION_DELETE = 'DELETE'
    
    OPERATION_CHOICES = [
        (OPERATION_READ, 'Read Operation'),
        (OPERATION_WRITE, 'Write Operation'),
        (OPERATION_DELETE, 'Delete Operation'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    # Basic Request Info
    method = models.CharField(max_length=10, db_index=True, help_text="HTTP method (GET, POST, etc.)")
    path = models.CharField(max_length=2048, db_index=True, help_text="Request path/URL")
    full_url = models.TextField(help_text="Complete URL including query parameters")

    # Response Info
    status_code = models.IntegerField(db_index=True, help_text="HTTP response status code")

    # User & IP Tracking (Enterprise: Header-based user ID)
    requested_user_id = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_index=True,
        help_text="User ID from request header (X-User-ID)"
    )
    ip_address = models.GenericIPAddressField(
        null=True,
        blank=True,
        db_index=True,
        help_text="Client IP address"
    )
    user_agent = models.TextField(
        null=True,
        blank=True,
        help_text="User agent string from request headers"
    )

    # Request Metadata
    request_headers = models.JSONField(
        null=True,
        blank=True,
        encoder=DjangoJSONEncoder,
        help_text="Request headers as JSON (sensitive headers excluded)"
    )
    request_body = models.TextField(
        null=True,
        blank=True,
        help_text="Request body content (truncated for large payloads)"
    )

    # Operation Classification
    operation_type = models.CharField(
        max_length=10,
        choices=OPERATION_CHOICES,
        null=True,
        blank=True,
        db_index=True,
        help_text="Operation type: READ (GET, HEAD, OPTIONS), WRITE (POST, PUT, PATCH), DELETE"
    )
    
    endpoint_category = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        db_index=True,
        help_text="Endpoint category extracted from path (e.g., /api/users -> users)"
    )
    
    is_api_request = models.BooleanField(
        default=False,
        db_index=True,
        help_text="Whether this is an API request (starts with /api/)"
    )

    # Performance Metrics
    response_time_ms = models.FloatField(
        null=True,
        blank=True,
        db_index=True,
        help_text="Response time in milliseconds"
    )
    query_count = models.IntegerField(
        null=True,
        blank=True,
        help_text="Number of database queries executed"
    )

    # Error Tracking
    exception = models.TextField(
        null=True,
        blank=True,
        help_text="Exception traceback if request failed"
    )
    content_length = models.IntegerField(
        null=True,
        blank=True,
        help_text="Response content length in bytes"
    )

    # Timestamps
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)
    
    # Custom manager
    objects = RequestLogManager()

    class Meta:
        db_table = "request_log"
        verbose_name = "Request Log"
        verbose_name_plural = "Request Logs"
        ordering = ["-timestamp"]
        
        # Optimized indexes for enterprise queries
        indexes = [
            # Primary query patterns
            models.Index(fields=["-timestamp", "status_code"], name="idx_timestamp_status"),
            models.Index(fields=["requested_user_id", "-timestamp"], name="idx_user_timestamp"),
            models.Index(fields=["path", "-timestamp"], name="idx_path_timestamp"),
            models.Index(fields=["operation_type", "-timestamp"], name="idx_operation_timestamp"),
            models.Index(fields=["endpoint_category", "-timestamp"], name="idx_category_timestamp"),
            
            # Analytics queries
            models.Index(fields=["is_api_request", "status_code", "-timestamp"], name="idx_api_status_timestamp"),
            models.Index(fields=["method", "status_code", "-timestamp"], name="idx_method_status_timestamp"),
            
            # Performance monitoring
            models.Index(fields=["response_time_ms", "-timestamp"], name="idx_response_time"),
            models.Index(fields=["query_count", "-timestamp"], name="idx_query_count"),
            
            # Error tracking
            models.Index(fields=["status_code", "-timestamp"], condition=models.Q(status_code__gte=400), name="idx_errors_only"),
        ]
        
        # Database constraints
        constraints = [
            models.CheckConstraint(
                check=models.Q(status_code__gte=100) & models.Q(status_code__lt=600),
                name="valid_status_code"
            ),
            models.CheckConstraint(
                check=models.Q(response_time_ms__gte=0),
                name="positive_response_time"
            ),
        ]

    def __str__(self):
        user_str = self.requested_user_id or "Anonymous"
        op_type = f"[{self.operation_type}]" if self.operation_type else ""
        return f"{self.method} {self.path} [{self.status_code}] {op_type} - {user_str} at {self.timestamp}"
    
    @staticmethod
    def get_operation_type(method):
        """Determine operation type from HTTP method"""
        if method in ['GET', 'HEAD', 'OPTIONS']:
            return RequestLog.OPERATION_READ
        elif method == 'DELETE':
            return RequestLog.OPERATION_DELETE
        elif method in ['POST', 'PUT', 'PATCH']:
            return RequestLog.OPERATION_WRITE
        return None
    
    @staticmethod
    def extract_endpoint_category(path):
        """Extract category from path (e.g., /api/users/123 -> users)"""
        parts = [p for p in path.split('/') if p and p != 'api']
        return parts[0] if parts else None
