"""
Monitoring and observability utilities
"""
import time
import logging
from typing import Dict, Any, Optional
from contextlib import contextmanager
from django.core.cache import cache
from django.conf import settings

logger = logging.getLogger(__name__)


class MetricsCollector:
    """Collects application metrics"""
    
    def __init__(self):
        self.metrics = {}
    
    def increment(self, metric_name: str, value: int = 1, tags: Optional[Dict[str, str]] = None):
        """Increment a counter metric"""
        key = f"trafficmonitor.{metric_name}"
        current = cache.get(key, 0)
        cache.set(key, current + value, timeout=3600)
        
        # Log structured metric
        logger.info("metric.increment", extra={
            "metric_name": metric_name,
            "value": value,
            "tags": tags or {},
            "timestamp": time.time()
        })
    
    def gauge(self, metric_name: str, value: float, tags: Optional[Dict[str, str]] = None):
        """Set a gauge metric"""
        key = f"trafficmonitor.gauge.{metric_name}"
        cache.set(key, value, timeout=3600)
        
        logger.info("metric.gauge", extra={
            "metric_name": metric_name,
            "value": value,
            "tags": tags or {},
            "timestamp": time.time()
        })
    
    def timing(self, metric_name: str, duration_ms: float, tags: Optional[Dict[str, str]] = None):
        """Record timing metric"""
        logger.info("metric.timing", extra={
            "metric_name": metric_name,
            "duration_ms": duration_ms,
            "tags": tags or {},
            "timestamp": time.time()
        })


class StructuredLogger:
    """Structured logging for enterprise applications"""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
    
    def log_request(self, request, response, duration_ms: float, **kwargs):
        """Log request with structured format"""
        self.logger.info("http.request", extra={
            "method": request.method,
            "path": request.path,
            "status_code": response.status_code,
            "duration_ms": duration_ms,
            "user_agent": request.META.get('HTTP_USER_AGENT', ''),
            "ip_address": self._get_client_ip(request),
            **kwargs
        })
    
    def log_error(self, error: Exception, context: Dict[str, Any]):
        """Log error with context"""
        self.logger.error("application.error", extra={
            "error_type": type(error).__name__,
            "error_message": str(error),
            "context": context,
            "timestamp": time.time()
        }, exc_info=True)
    
    def _get_client_ip(self, request) -> str:
        """Get client IP address"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR', '')


@contextmanager
def performance_timer(metric_name: str, tags: Optional[Dict[str, str]] = None):
    """Context manager for timing operations"""
    start_time = time.time()
    try:
        yield
    finally:
        duration_ms = (time.time() - start_time) * 1000
        metrics.timing(metric_name, duration_ms, tags)


# Global instances
metrics = MetricsCollector()
structured_logger = StructuredLogger('trafficmonitor')
