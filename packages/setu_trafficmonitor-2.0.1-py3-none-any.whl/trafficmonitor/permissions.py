"""
Role-based permission classes for TrafficMonitor analytics.
Enterprise-grade access control using header-based authentication.
"""
from rest_framework import permissions
from trafficmonitor.conf import TrafficMonitorConfig


class HasTrafficMonitorAccess(permissions.BasePermission):
    """
    Permission class for analytics access.
    Allows access if:
    1. User is authenticated via Django (staff or superuser)
    2. No role header exists (open access)
    3. Role header exists and is authorized
    """
    message = "You do not have permission to access traffic monitoring analytics."
    
    def has_permission(self, request, view):
        # Allow Django authenticated staff/superusers
        if request.user and request.user.is_authenticated:
            if request.user.is_staff or request.user.is_superuser:
                return True
        
        # Check role-based access via headers
        user_info = TrafficMonitorConfig.get_user_info_from_request(request)
        user_role = user_info.get('role')
        
        # If no role header, allow access
        if not user_role:
            return True
        
        # If role header exists, check if user role is in allowed roles
        return TrafficMonitorConfig.is_user_authorized(user_role)



class HasTrafficMonitorAdminAccess(permissions.BasePermission):
    """
    Permission class for admin-only analytics access.
    Allows access if:
    1. User is Django superuser
    2. No role header exists (open access)
    3. Role header exists and has admin role
    """
    message = "You need admin privileges to access this resource."
    
    def has_permission(self, request, view):
        # Allow Django superusers
        if request.user and request.user.is_authenticated:
            if request.user.is_superuser:
                return True
        
        # Check role-based access via headers
        user_info = TrafficMonitorConfig.get_user_info_from_request(request)
        user_role = user_info.get('role')
        
        # If no role header, allow access
        if not user_role:
            return True
        
        # If role header exists, check if user has admin role
        return TrafficMonitorConfig.is_admin(user_role)

