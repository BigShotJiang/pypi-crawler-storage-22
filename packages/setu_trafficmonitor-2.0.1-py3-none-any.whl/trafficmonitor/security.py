"""
Security utilities for PII protection and data sanitization
"""
import re
import json
import datetime
import decimal
from uuid import UUID
from typing import Dict, Any, Optional
from django.conf import settings


class DataSanitizer:
    """Sanitizes sensitive data from requests/responses"""
    
    # PII patterns
    EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
    PHONE_PATTERN = re.compile(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b')
    SSN_PATTERN = re.compile(r'\b\d{3}-\d{2}-\d{4}\b')
    CREDIT_CARD_PATTERN = re.compile(r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b')
    
    SENSITIVE_KEYS = {
        'password', 'passwd', 'pwd', 'secret', 'token', 'key', 'auth',
        'authorization', 'credential', 'api_key', 'access_token', 'refresh_token',
        'ssn', 'social_security', 'credit_card', 'card_number', 'cvv', 'pin'
    }
    
    @staticmethod
    def sanitize_for_json(obj):
        """
        Recursively sanitize any Python object so it becomes JSON serializable.
        Handles datetime, Decimal, UUID, Django objects, and any non-serializable type.
        """
        if obj is None:
            return None

        # Ellipsis
        if obj is Ellipsis:
            return None

        # Primitives
        if isinstance(obj, (str, int, float, bool)):
            # Truncate very long strings
            if isinstance(obj, str) and len(obj) > 1000:
                return obj[:1000] + '...'
            return obj

        # Decimal
        if isinstance(obj, decimal.Decimal):
            return float(obj)

        # UUID
        if isinstance(obj, UUID):
            return str(obj)

        # Date/Time
        if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
            try:
                from django.utils.timezone import is_aware
                # Make datetime timezone-naive ISO if aware
                if isinstance(obj, datetime.datetime) and is_aware(obj):
                    obj = obj.astimezone(datetime.timezone.utc).replace(tzinfo=None)
            except ImportError:
                pass
            return obj.isoformat()

        # Lists / Tuples
        if isinstance(obj, (list, tuple)):
            return [DataSanitizer.sanitize_for_json(item) for item in obj]

        # Sets
        if isinstance(obj, set):
            return [DataSanitizer.sanitize_for_json(item) for item in obj]

        # Dict
        if isinstance(obj, dict):
            return {
                DataSanitizer.sanitize_for_json(k): DataSanitizer.sanitize_for_json(v) 
                for k, v in obj.items()
            }

        # Django model instance — return pk if exists
        if hasattr(obj, "pk"):
            return str(obj.pk)

        # Fallback: string representation
        return str(obj)
    
    @classmethod
    def sanitize_headers(cls, headers: Dict[str, Any]) -> Dict[str, Any]:
        """Remove sensitive headers and ensure JSON serializable values"""
        if not isinstance(headers, dict):
            return {}
        
        sanitized = {}
        for key, value in headers.items():
            # Skip WSGI internal objects completely (not serializable)
            if isinstance(key, str) and key.startswith('wsgi.'):
                continue
            
            # Skip non-string keys
            if not isinstance(key, str):
                key = str(key)
            
            # Redact sensitive keys
            if any(sensitive in key.lower() for sensitive in cls.SENSITIVE_KEYS):
                sanitized[key] = "[REDACTED]"
            else:
                # Use sanitize_for_json to handle any type of value
                sanitized[key] = cls.sanitize_for_json(value)
        
        return sanitized
    
    @classmethod
    def sanitize_body(cls, body: str, max_length: int = 10000) -> str:
        """Sanitize request/response body"""
        if not body:
            return body
            
        # Truncate if too long
        if len(body) > max_length:
            body = body[:max_length] + "...[TRUNCATED]"
        
        # Remove PII patterns
        body = cls.EMAIL_PATTERN.sub('[EMAIL_REDACTED]', body)
        body = cls.PHONE_PATTERN.sub('[PHONE_REDACTED]', body)
        body = cls.SSN_PATTERN.sub('[SSN_REDACTED]', body)
        body = cls.CREDIT_CARD_PATTERN.sub('[CARD_REDACTED]', body)
        
        # Try to parse as JSON and sanitize keys
        try:
            data = json.loads(body)
            if isinstance(data, dict):
                data = cls._sanitize_dict(data)
                return json.dumps(data)
        except (json.JSONDecodeError, TypeError):
            pass
            
        return body
    
    @classmethod
    def _sanitize_dict(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively sanitize dictionary keys"""
        sanitized = {}
        for key, value in data.items():
            if any(sensitive in key.lower() for sensitive in cls.SENSITIVE_KEYS):
                sanitized[key] = "[REDACTED]"
            elif isinstance(value, dict):
                sanitized[key] = cls._sanitize_dict(value)
            elif isinstance(value, list):
                sanitized[key] = [cls._sanitize_dict(item) if isinstance(item, dict) else item for item in value]
            else:
                sanitized[key] = value
        return sanitized


class SecurityValidator:
    """Validates security requirements"""
    
    @staticmethod
    def validate_user_access(user_id: str, user_role: str, required_roles: list) -> bool:
        """Validate user access with proper logging"""
        if not user_id or not user_role:
            return False
        
        # Add audit logging here
        return user_role.lower() in [r.lower() for r in required_roles]
    
    @staticmethod
    def get_client_ip(request) -> Optional[str]:
        """Get real client IP considering proxies"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        
        x_real_ip = request.META.get('HTTP_X_REAL_IP')
        if x_real_ip:
            return x_real_ip
            
        return request.META.get('REMOTE_ADDR')
