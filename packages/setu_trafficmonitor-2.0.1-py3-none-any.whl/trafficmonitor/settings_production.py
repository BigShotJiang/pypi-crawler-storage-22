"""
Production settings template for TrafficMonitor
Copy these settings to your Django settings.py and adjust as needed.
"""

# TrafficMonitor Production Configuration
TRAFFICMONITOR_ASYNC_LOGGING = True
TRAFFICMONITOR_ENABLE_SAMPLING = True
TRAFFICMONITOR_SAMPLE_RATE = 0.1  # Log 10% of requests in production

# Circuit Breaker
TRAFFICMONITOR_CIRCUIT_BREAKER_ENABLED = True
TRAFFICMONITOR_CB_FAILURE_THRESHOLD = 5

# Security
TRAFFICMONITOR_ENABLE_PII_SANITIZATION = True
TRAFFICMONITOR_MAX_BODY_LENGTH = 5000  # Smaller in production

# Performance
TRAFFICMONITOR_BULK_BATCH_SIZE = 5000
TRAFFICMONITOR_ENABLE_METRICS = True

# Data Retention
TRAFFICMONITOR_RETENTION_DAYS = 30  # Shorter retention in production

# Authentication (adjust based on your auth system)
TRAFFICMONITOR_USER_ID_HEADER = 'X-User-ID'
TRAFFICMONITOR_USER_ROLE_HEADER = 'X-User-Role'
TRAFFICMONITOR_VIEWER_ROLES = ['analyst', 'viewer', 'developer']
TRAFFICMONITOR_ADMIN_ROLES = ['admin', 'superuser']

# Excluded paths (add your specific paths)
TRAFFICMONITOR_EXCLUDED_PATHS = [
    '/admin/jsi18n/',
    '/static/',
    '/media/',
    '/__debug__/',
    '/favicon.ico',
    '/health/',
    '/healthz/',
    '/metrics/',
    '/prometheus/',
    # Add your application-specific paths
    '/api/health/',
    '/api/metrics/',
]

# Logging Configuration
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'structured': {
            'format': '%(asctime)s %(name)s %(levelname)s %(message)s',
        },
    },
    'handlers': {
        'trafficmonitor': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'structured',
        },
    },
    'loggers': {
        'trafficmonitor': {
            'handlers': ['trafficmonitor'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# Database Configuration (example for PostgreSQL)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'your_db_name',
        'USER': 'your_db_user',
        'PASSWORD': 'your_db_password',
        'HOST': 'your_db_host',
        'PORT': '5432',
        'OPTIONS': {
            'MAX_CONNS': 20,  # Connection pooling
        },
    }
}

# Cache Configuration (Redis recommended)
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/1',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'CONNECTION_POOL_KWARGS': {'max_connections': 50},
        }
    }
}

# Celery Configuration (for async logging)
CELERY_BROKER_URL = 'redis://localhost:6379/0'
CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'
CELERY_TASK_SERIALIZER = 'json'
CELERY_ACCEPT_CONTENT = ['json']
CELERY_RESULT_SERIALIZER = 'json'
