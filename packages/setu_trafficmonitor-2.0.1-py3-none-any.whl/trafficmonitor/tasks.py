"""
Celery tasks for async request logging.
Enterprise-grade async processing to avoid request latency.
"""
import logging

logger = logging.getLogger(__name__)

try:
    from celery import shared_task
    CELERY_AVAILABLE = True
except ImportError:
    CELERY_AVAILABLE = False
    # Provide a no-op decorator if Celery is not available
    def shared_task(*args, **kwargs):
        def decorator(func):
            return func
        return decorator


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def log_request_async(self, log_data):
    """
    Async task to log request to database.
    Reduces response time by offloading DB writes to background worker.
    
    Args:
        log_data (dict): Dictionary containing all request log fields
    
    Returns:
        str: Log entry ID
    """
    try:
        from trafficmonitor.models import RequestLog
        
        log_entry = RequestLog.objects.create(**log_data)
        return str(log_entry.id)
    
    except Exception as exc:
        logger.error(f"Failed to log request asynchronously: {exc}")
        # Retry the task
        if self.request.retries < self.max_retries:
            raise self.retry(exc=exc)
        return None


@shared_task
def cleanup_old_logs(retention_days=90):
    """
    Celery task to clean up old request logs.
    Should be scheduled to run daily (e.g., via Celery Beat).
    
    Args:
        retention_days (int): Number of days to retain logs
    
    Returns:
        dict: Cleanup statistics
    """
    from datetime import timedelta
    from django.utils import timezone
    from trafficmonitor.models import RequestLog
    
    cutoff_date = timezone.now() - timedelta(days=retention_days)
    
    # Delete in batches to avoid locking
    batch_size = 1000
    total_deleted = 0
    
    while True:
        # Get IDs of logs to delete
        log_ids = list(
            RequestLog.objects.filter(
                timestamp__lt=cutoff_date
            ).values_list('id', flat=True)[:batch_size]
        )
        
        if not log_ids:
            break
        
        # Delete batch
        deleted_count, _ = RequestLog.objects.filter(id__in=log_ids).delete()
        total_deleted += deleted_count
        
        logger.info(f"Deleted {deleted_count} old request logs (batch)")
    
    logger.info(f"Cleanup complete. Total deleted: {total_deleted} logs older than {retention_days} days")
    
    return {
        'deleted_count': total_deleted,
        'cutoff_date': cutoff_date.isoformat(),
        'retention_days': retention_days,
    }


@shared_task
def aggregate_daily_stats(date=None):
    """
    Pre-compute daily statistics for faster dashboard loading.
    Should be scheduled to run daily after midnight.
    
    Args:
        date: Date to aggregate (defaults to yesterday)
    
    Returns:
        dict: Aggregated statistics
    """
    from datetime import timedelta
    from django.utils import timezone
    from trafficmonitor.models import RequestLog
    from trafficmonitor.analytics.enhanced_queries import EnhancedAnalyticsQueries
    
    if date is None:
        # Default to yesterday
        date = (timezone.now() - timedelta(days=1)).date()
    
    start_date = timezone.make_aware(timezone.datetime.combine(date, timezone.datetime.min.time()))
    end_date = timezone.make_aware(timezone.datetime.combine(date, timezone.datetime.max.time()))
    
    # Compute statistics
    stats = {
        'date': date.isoformat(),
        'total_requests': RequestLog.objects.filter(
            timestamp__gte=start_date,
            timestamp__lte=end_date
        ).count(),
        'read_write_summary': EnhancedAnalyticsQueries.get_read_write_summary(
            start_date, end_date
        ),
        'api_health': EnhancedAnalyticsQueries.get_api_health_metrics(
            start_date, end_date
        ),
    }
    
    # Store in cache or separate stats table (implement as needed)
    logger.info(f"Daily stats aggregated for {date}: {stats['total_requests']} requests")
    
    return stats
