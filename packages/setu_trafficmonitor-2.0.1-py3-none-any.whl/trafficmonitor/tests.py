from django.test import TestCase, RequestFactory, override_settings
from django.contrib.auth import get_user_model
from django.http import HttpResponse

from trafficmonitor.models import RequestLog
from trafficmonitor.middleware import RequestLoggingMiddleware


User = get_user_model()


class RequestLoggingMiddlewareTest(TestCase):
    """
    Test cases for RequestLoggingMiddleware.
    """

    def setUp(self):
        """Set up test fixtures."""
        self.factory = RequestFactory()
        self.middleware = RequestLoggingMiddleware(get_response=lambda r: HttpResponse())
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )

    def test_middleware_logs_get_request(self):
        """Test that GET requests are logged."""
        # Create a GET request
        request = self.factory.get('/api/test/')
        request.user = self.user

        # Process request through middleware
        self.middleware.process_request(request)
        response = HttpResponse(status=200)
        self.middleware.process_response(request, response)

        # Verify log was created
        self.assertEqual(RequestLog.objects.count(), 1)
        log = RequestLog.objects.first()
        self.assertEqual(log.method, 'GET')
        self.assertEqual(log.path, '/api/test/')
        self.assertEqual(log.status_code, 200)
        self.assertEqual(log.user, self.user)

    def test_middleware_logs_post_request_with_body(self):
        """Test that POST requests with body are logged."""
        # Create a POST request with JSON body
        request = self.factory.post(
            '/api/test/',
            data={'key': 'value'},
            content_type='application/json'
        )
        request.user = self.user

        # Process request through middleware
        self.middleware.process_request(request)
        response = HttpResponse(status=201)
        self.middleware.process_response(request, response)

        # Verify log was created with request body
        self.assertEqual(RequestLog.objects.count(), 1)
        log = RequestLog.objects.first()
        self.assertEqual(log.method, 'POST')
        self.assertEqual(log.status_code, 201)
        self.assertIsNotNone(log.request_body)

    def test_middleware_logs_anonymous_request(self):
        """Test that anonymous requests are logged."""
        # Create request without user
        request = self.factory.get('/api/public/')
        request.user = None

        # Process request through middleware
        self.middleware.process_request(request)
        response = HttpResponse(status=200)
        self.middleware.process_response(request, response)

        # Verify log was created without user
        self.assertEqual(RequestLog.objects.count(), 1)
        log = RequestLog.objects.first()
        self.assertIsNone(log.user)

    def test_middleware_excludes_static_paths(self):
        """Test that excluded paths are not logged."""
        # Create requests for excluded paths
        excluded_paths = [
            '/static/css/style.css',
            '/media/uploads/image.jpg',
            '/admin/jsi18n/',
            '/favicon.ico',
        ]

        for path in excluded_paths:
            request = self.factory.get(path)
            request.user = self.user

            self.middleware.process_request(request)
            response = HttpResponse(status=200)
            self.middleware.process_response(request, response)

        # Verify no logs were created
        self.assertEqual(RequestLog.objects.count(), 0)

    def test_middleware_logs_exception(self):
        """Test that exceptions are logged."""
        # Create request
        request = self.factory.get('/api/error/')
        request.user = self.user

        # Process request and simulate exception
        self.middleware.process_request(request)
        try:
            raise ValueError("Test exception")
        except ValueError as e:
            self.middleware.process_exception(request, e)

        # Verify log was created with exception
        self.assertEqual(RequestLog.objects.count(), 1)
        log = RequestLog.objects.first()
        self.assertIsNotNone(log.exception)
        self.assertIn('ValueError', log.exception)
        self.assertIn('Test exception', log.exception)
        self.assertEqual(log.status_code, 500)

    def test_middleware_tracks_response_time(self):
        """Test that response time is tracked."""
        # Create request
        request = self.factory.get('/api/test/')
        request.user = self.user

        # Process request through middleware
        self.middleware.process_request(request)
        response = HttpResponse(status=200)
        self.middleware.process_response(request, response)

        # Verify response time was recorded
        log = RequestLog.objects.first()
        self.assertIsNotNone(log.response_time_ms)
        self.assertGreaterEqual(log.response_time_ms, 0)

    def test_middleware_extracts_ip_address(self):
        """Test that IP address is extracted correctly."""
        # Create request with IP
        request = self.factory.get('/api/test/')
        request.user = self.user
        request.META['REMOTE_ADDR'] = '192.168.1.100'

        # Process request through middleware
        self.middleware.process_request(request)
        response = HttpResponse(status=200)
        self.middleware.process_response(request, response)

        # Verify IP was recorded
        log = RequestLog.objects.first()
        self.assertEqual(log.ip_address, '192.168.1.100')

    def test_middleware_handles_x_forwarded_for(self):
        """Test that X-Forwarded-For header is handled correctly."""
        # Create request with X-Forwarded-For
        request = self.factory.get('/api/test/')
        request.user = self.user
        request.META['HTTP_X_FORWARDED_FOR'] = '203.0.113.1, 192.168.1.1'
        request.META['REMOTE_ADDR'] = '192.168.1.100'

        # Process request through middleware
        self.middleware.process_request(request)
        response = HttpResponse(status=200)
        self.middleware.process_response(request, response)

        # Verify first IP from X-Forwarded-For was used
        log = RequestLog.objects.first()
        self.assertEqual(log.ip_address, '203.0.113.1')

    def test_request_log_str_method(self):
        """Test RequestLog string representation."""
        # Create a log entry
        request = self.factory.get('/api/test/')
        request.user = self.user

        self.middleware.process_request(request)
        response = HttpResponse(status=200)
        self.middleware.process_response(request, response)

        # Verify string representation
        log = RequestLog.objects.first()
        str_repr = str(log)
        self.assertIn('GET', str_repr)
        self.assertIn('/api/test/', str_repr)
        self.assertIn('200', str_repr)
        self.assertIn('testuser', str_repr)


class RequestLogModelTest(TestCase):
    """
    Test cases for RequestLog model.
    """

    def setUp(self):
        """Set up test fixtures."""
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )

    def test_create_request_log(self):
        """Test creating a RequestLog entry."""
        log = RequestLog.objects.create(
            method='GET',
            path='/api/test/',
            full_url='http://example.com/api/test/',
            status_code=200,
            user=self.user,
            ip_address='192.168.1.100',
            user_agent='Test Agent',
            response_time_ms=50.5,
            query_count=5,
        )

        self.assertIsNotNone(log.id)
        self.assertEqual(log.method, 'GET')
        self.assertEqual(log.path, '/api/test/')
        self.assertEqual(log.status_code, 200)
        self.assertEqual(log.user, self.user)
        self.assertEqual(log.ip_address, '192.168.1.100')
        self.assertEqual(log.response_time_ms, 50.5)
        self.assertEqual(log.query_count, 5)

    def test_request_log_ordering(self):
        """Test that logs are ordered by timestamp descending."""
        # Create multiple logs
        for i in range(3):
            RequestLog.objects.create(
                method='GET',
                path=f'/api/test/{i}/',
                full_url=f'http://example.com/api/test/{i}/',
                status_code=200,
            )

        # Verify ordering
        logs = list(RequestLog.objects.all())
        self.assertEqual(len(logs), 3)
        # Most recent should be first
        self.assertGreater(logs[0].timestamp, logs[1].timestamp)
        self.assertGreater(logs[1].timestamp, logs[2].timestamp)
