"""
WebSocket consumers for real-time dashboard updates
"""
import json
import asyncio
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.core.cache import cache
from trafficmonitor.conf import TrafficMonitorConfig
import logging

logger = logging.getLogger(__name__)


class DashboardConsumer(AsyncWebsocketConsumer):
    """WebSocket consumer for real-time dashboard updates"""
    
    async def connect(self):
        """Handle WebSocket connection"""
        # Authenticate user
        user_info = await self.get_user_info()
        
        if not TrafficMonitorConfig.is_user_authorized(user_info.get('role')):
            await self.close(code=4001)  # Unauthorized
            return
        
        # Join dashboard group
        self.group_name = 'dashboard_updates'
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        
        await self.accept()
        
        # Send initial data
        await self.send_dashboard_update()
        
        # Start periodic updates
        asyncio.create_task(self.periodic_updates())
    
    async def disconnect(self, close_code):
        """Handle WebSocket disconnection"""
        if hasattr(self, 'group_name'):
            await self.channel_layer.group_discard(
                self.group_name,
                self.channel_name
            )
    
    async def receive(self, text_data):
        """Handle messages from WebSocket"""
        try:
            data = json.loads(text_data)
            message_type = data.get('type')
            
            if message_type == 'request_update':
                await self.send_dashboard_update()
            elif message_type == 'subscribe_filters':
                # Handle filter subscriptions
                filters = data.get('filters', {})
                await self.send_filtered_update(filters)
                
        except json.JSONDecodeError:
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': 'Invalid JSON'
            }))
    
    async def send_dashboard_update(self):
        """Send dashboard update to client"""
        try:
            # Get cached dashboard data
            dashboard_data = cache.get('dashboard_realtime_data')
            
            if not dashboard_data:
                dashboard_data = await self.get_dashboard_data()
                cache.set('dashboard_realtime_data', dashboard_data, timeout=30)
            
            await self.send(text_data=json.dumps({
                'type': 'dashboard_update',
                'data': dashboard_data
            }))
            
        except Exception as e:
            logger.error(f"Error sending dashboard update: {e}")
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': 'Failed to get dashboard data'
            }))
    
    async def periodic_updates(self):
        """Send periodic updates every 30 seconds"""
        while True:
            try:
                await asyncio.sleep(30)
                await self.send_dashboard_update()
            except Exception as e:
                logger.error(f"Error in periodic updates: {e}")
                break
    
    @database_sync_to_async
    def get_user_info(self):
        """Get user info from headers"""
        return TrafficMonitorConfig.get_user_info_from_request(self.scope)
    
    @database_sync_to_async
    def get_dashboard_data(self):
        """Get real-time dashboard data"""
        from trafficmonitor.models import RequestLog
        from django.utils import timezone
        from datetime import timedelta
        
        # Get last 5 minutes of data
        now = timezone.now()
        start_time = now - timedelta(minutes=5)
        
        recent_logs = RequestLog.objects.filter(
            timestamp__gte=start_time
        )
        
        return {
            'recent_requests': recent_logs.count(),
            'recent_errors': recent_logs.filter(status_code__gte=400).count(),
            'avg_response_time': recent_logs.aggregate(
                avg=models.Avg('response_time_ms')
            )['avg'] or 0,
            'timestamp': now.isoformat(),
        }
