# seven-reaper

7DT image-specific Tractor photometry pipeline.
This distribution is licensed under MIT.

## Quick start

1) Install Tractor's prerequisites (see Tractor docs):

2) Install Tractor (from source or your preferred method).

3) Create a YAML config (see `seven_reaper/data/sample_config.yaml`).

4) Run the full pipeline:

```bash
seven-reaper run --config /path/to/config.yaml
```

## Commands

- `run`: full pipeline (load → ePSF → patches → patch inputs → patch runs → merge)
- `run-epsf`: build ePSF only
- `build-patches`: build patch definitions only
- `build-patch-inputs`: build patch inputs only
- `run-patches`: run Tractor on patch inputs
- `merge`: merge patch results into final catalog

## Notes

- The package preserves the reference behavior; changes are limited to packaging and path handling.
- Tractor and `astrometry.net` must be installed separately.
- Python prerequisites like `numpy` and `scipy` are included in dependencies; optional extras (eg `fitsio`, `emcee`) are included for safety.
- Input images are provided via a text file (one FITS path per line).
- Parameter mapping reference: `docs/CONFIG_MAPPING.md`.
