from __future__ import annotations

import argparse

from .config import load_config
from .pipeline import (
    build_epsf,
    build_patch_inputs,
    build_patches,
    load_inputs,
    merge_results,
    run_patch_subprocesses,
    run_pipeline,
)


def _add_common(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--config", required=True, help="Path to YAML config")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="seven-reaper")
    sub = ap.add_subparsers(dest="cmd", required=True)

    ap_run = sub.add_parser("run", help="Run full pipeline")
    _add_common(ap_run)

    ap_epsf = sub.add_parser("run-epsf", help="Build ePSF only")
    _add_common(ap_epsf)

    ap_patches = sub.add_parser("build-patches", help="Build patch definitions only")
    _add_common(ap_patches)

    ap_inputs = sub.add_parser("build-patch-inputs", help="Build patch inputs only")
    _add_common(ap_inputs)

    ap_run_p = sub.add_parser("run-patches", help="Run patch subprocesses only")
    _add_common(ap_run_p)

    ap_merge = sub.add_parser("merge", help="Merge patch outputs only")
    _add_common(ap_merge)

    args = ap.parse_args(argv)
    cfg = load_config(args.config)

    if args.cmd == "run":
        run_pipeline(cfg)
    elif args.cmd == "run-epsf":
        state = load_inputs(cfg)
        build_epsf(cfg, state)
    elif args.cmd == "build-patches":
        state = load_inputs(cfg)
        build_patches(cfg, state)
    elif args.cmd == "build-patch-inputs":
        state = load_inputs(cfg)
        build_patches(cfg, state)
        build_patch_inputs(cfg, state)
    elif args.cmd == "run-patches":
        run_patch_subprocesses(cfg)
    elif args.cmd == "merge":
        merge_results(cfg)
    else:
        raise SystemExit(f"Unknown command: {args.cmd}")

    return 0
