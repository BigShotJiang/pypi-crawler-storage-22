"""Bundled worker scripts for SLURM execution."""
