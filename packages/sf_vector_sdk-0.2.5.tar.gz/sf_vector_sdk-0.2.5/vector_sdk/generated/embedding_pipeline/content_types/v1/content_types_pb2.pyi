from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ContentType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTENT_TYPE_UNSPECIFIED: _ClassVar[ContentType]
    CONTENT_TYPE_TOPIC: _ClassVar[ContentType]
    CONTENT_TYPE_FLASHCARD: _ClassVar[ContentType]
    CONTENT_TYPE_TEST_QUESTION: _ClassVar[ContentType]
    CONTENT_TYPE_SPACED_TEST_QUESTION: _ClassVar[ContentType]
    CONTENT_TYPE_AUDIO_RECAP: _ClassVar[ContentType]
    CONTENT_TYPE_DOCUMENT: _ClassVar[ContentType]
    CONTENT_TYPE_NOTE: _ClassVar[ContentType]

class EmbeddingProvider(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EMBEDDING_PROVIDER_UNSPECIFIED: _ClassVar[EmbeddingProvider]
    EMBEDDING_PROVIDER_GOOGLE: _ClassVar[EmbeddingProvider]
    EMBEDDING_PROVIDER_OPENAI: _ClassVar[EmbeddingProvider]

class EmbeddingModel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EMBEDDING_MODEL_UNSPECIFIED: _ClassVar[EmbeddingModel]
    EMBEDDING_MODEL_GEMINI_001: _ClassVar[EmbeddingModel]
    EMBEDDING_MODEL_TEXT_004: _ClassVar[EmbeddingModel]
    EMBEDDING_MODEL_MULTILINGUAL_002: _ClassVar[EmbeddingModel]
    EMBEDDING_MODEL_OPENAI_3_SMALL: _ClassVar[EmbeddingModel]
    EMBEDDING_MODEL_OPENAI_3_LARGE: _ClassVar[EmbeddingModel]

class Priority(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PRIORITY_UNSPECIFIED: _ClassVar[Priority]
    PRIORITY_CRITICAL: _ClassVar[Priority]
    PRIORITY_HIGH: _ClassVar[Priority]
    PRIORITY_NORMAL: _ClassVar[Priority]
    PRIORITY_LOW: _ClassVar[Priority]

class VectorDatabase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    VECTOR_DATABASE_UNSPECIFIED: _ClassVar[VectorDatabase]
    VECTOR_DATABASE_MONGODB: _ClassVar[VectorDatabase]
    VECTOR_DATABASE_TURBOPUFFER: _ClassVar[VectorDatabase]
    VECTOR_DATABASE_PINECONE: _ClassVar[VectorDatabase]
CONTENT_TYPE_UNSPECIFIED: ContentType
CONTENT_TYPE_TOPIC: ContentType
CONTENT_TYPE_FLASHCARD: ContentType
CONTENT_TYPE_TEST_QUESTION: ContentType
CONTENT_TYPE_SPACED_TEST_QUESTION: ContentType
CONTENT_TYPE_AUDIO_RECAP: ContentType
CONTENT_TYPE_DOCUMENT: ContentType
CONTENT_TYPE_NOTE: ContentType
EMBEDDING_PROVIDER_UNSPECIFIED: EmbeddingProvider
EMBEDDING_PROVIDER_GOOGLE: EmbeddingProvider
EMBEDDING_PROVIDER_OPENAI: EmbeddingProvider
EMBEDDING_MODEL_UNSPECIFIED: EmbeddingModel
EMBEDDING_MODEL_GEMINI_001: EmbeddingModel
EMBEDDING_MODEL_TEXT_004: EmbeddingModel
EMBEDDING_MODEL_MULTILINGUAL_002: EmbeddingModel
EMBEDDING_MODEL_OPENAI_3_SMALL: EmbeddingModel
EMBEDDING_MODEL_OPENAI_3_LARGE: EmbeddingModel
PRIORITY_UNSPECIFIED: Priority
PRIORITY_CRITICAL: Priority
PRIORITY_HIGH: Priority
PRIORITY_NORMAL: Priority
PRIORITY_LOW: Priority
VECTOR_DATABASE_UNSPECIFIED: VectorDatabase
VECTOR_DATABASE_MONGODB: VectorDatabase
VECTOR_DATABASE_TURBOPUFFER: VectorDatabase
VECTOR_DATABASE_PINECONE: VectorDatabase

class ContentTypeConfig(_message.Message):
    __slots__ = ("content_type", "model", "dimensions", "default_priority", "mongodb", "turbopuffer", "pinecone")
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    MODEL_FIELD_NUMBER: _ClassVar[int]
    DIMENSIONS_FIELD_NUMBER: _ClassVar[int]
    DEFAULT_PRIORITY_FIELD_NUMBER: _ClassVar[int]
    MONGODB_FIELD_NUMBER: _ClassVar[int]
    TURBOPUFFER_FIELD_NUMBER: _ClassVar[int]
    PINECONE_FIELD_NUMBER: _ClassVar[int]
    content_type: ContentType
    model: EmbeddingModel
    dimensions: int
    default_priority: Priority
    mongodb: MongoDBStorageConfig
    turbopuffer: TurboPufferStorageConfig
    pinecone: PineconeStorageConfig
    def __init__(self, content_type: _Optional[_Union[ContentType, str]] = ..., model: _Optional[_Union[EmbeddingModel, str]] = ..., dimensions: _Optional[int] = ..., default_priority: _Optional[_Union[Priority, str]] = ..., mongodb: _Optional[_Union[MongoDBStorageConfig, _Mapping]] = ..., turbopuffer: _Optional[_Union[TurboPufferStorageConfig, _Mapping]] = ..., pinecone: _Optional[_Union[PineconeStorageConfig, _Mapping]] = ...) -> None: ...

class MongoDBStorageConfig(_message.Message):
    __slots__ = ("database", "collection", "embedding_field", "upsert_key")
    DATABASE_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    EMBEDDING_FIELD_FIELD_NUMBER: _ClassVar[int]
    UPSERT_KEY_FIELD_NUMBER: _ClassVar[int]
    database: str
    collection: str
    embedding_field: str
    upsert_key: str
    def __init__(self, database: _Optional[str] = ..., collection: _Optional[str] = ..., embedding_field: _Optional[str] = ..., upsert_key: _Optional[str] = ...) -> None: ...

class TurboPufferStorageConfig(_message.Message):
    __slots__ = ("namespace", "id_field", "metadata_fields")
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELDS_FIELD_NUMBER: _ClassVar[int]
    namespace: str
    id_field: str
    metadata_fields: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, namespace: _Optional[str] = ..., id_field: _Optional[str] = ..., metadata_fields: _Optional[_Iterable[str]] = ...) -> None: ...

class PineconeStorageConfig(_message.Message):
    __slots__ = ("index_name", "namespace", "id_field", "metadata_fields")
    INDEX_NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELDS_FIELD_NUMBER: _ClassVar[int]
    index_name: str
    namespace: str
    id_field: str
    metadata_fields: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, index_name: _Optional[str] = ..., namespace: _Optional[str] = ..., id_field: _Optional[str] = ..., metadata_fields: _Optional[_Iterable[str]] = ...) -> None: ...

class EmbeddingConfig(_message.Message):
    __slots__ = ("model", "dimensions")
    MODEL_FIELD_NUMBER: _ClassVar[int]
    DIMENSIONS_FIELD_NUMBER: _ClassVar[int]
    model: EmbeddingModel
    dimensions: int
    def __init__(self, model: _Optional[_Union[EmbeddingModel, str]] = ..., dimensions: _Optional[int] = ...) -> None: ...

class ContentTypeRegistry(_message.Message):
    __slots__ = ("configs",)
    CONFIGS_FIELD_NUMBER: _ClassVar[int]
    configs: _containers.RepeatedCompositeFieldContainer[ContentTypeConfig]
    def __init__(self, configs: _Optional[_Iterable[_Union[ContentTypeConfig, _Mapping]]] = ...) -> None: ...
