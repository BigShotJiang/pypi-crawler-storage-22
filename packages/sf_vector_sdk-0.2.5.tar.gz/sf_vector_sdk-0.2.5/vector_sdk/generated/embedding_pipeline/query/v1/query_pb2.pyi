from embedding_pipeline.content_types.v1 import content_types_pb2 as _content_types_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class QueryRequest(_message.Message):
    __slots__ = ("request_id", "query_text", "database", "embedding_config", "query_config", "priority", "metadata", "created_at")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    QUERY_TEXT_FIELD_NUMBER: _ClassVar[int]
    DATABASE_FIELD_NUMBER: _ClassVar[int]
    EMBEDDING_CONFIG_FIELD_NUMBER: _ClassVar[int]
    QUERY_CONFIG_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    query_text: str
    database: _content_types_pb2.VectorDatabase
    embedding_config: _content_types_pb2.EmbeddingConfig
    query_config: QueryConfig
    priority: _content_types_pb2.Priority
    metadata: _containers.ScalarMap[str, str]
    created_at: str
    def __init__(self, request_id: _Optional[str] = ..., query_text: _Optional[str] = ..., database: _Optional[_Union[_content_types_pb2.VectorDatabase, str]] = ..., embedding_config: _Optional[_Union[_content_types_pb2.EmbeddingConfig, _Mapping]] = ..., query_config: _Optional[_Union[QueryConfig, _Mapping]] = ..., priority: _Optional[_Union[_content_types_pb2.Priority, str]] = ..., metadata: _Optional[_Mapping[str, str]] = ..., created_at: _Optional[str] = ...) -> None: ...

class QueryConfig(_message.Message):
    __slots__ = ("top_k", "min_score", "filters", "namespace", "collection", "database", "include_vectors", "include_metadata")
    class FiltersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TOP_K_FIELD_NUMBER: _ClassVar[int]
    MIN_SCORE_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    COLLECTION_FIELD_NUMBER: _ClassVar[int]
    DATABASE_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_VECTORS_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_METADATA_FIELD_NUMBER: _ClassVar[int]
    top_k: int
    min_score: float
    filters: _containers.ScalarMap[str, str]
    namespace: str
    collection: str
    database: str
    include_vectors: bool
    include_metadata: bool
    def __init__(self, top_k: _Optional[int] = ..., min_score: _Optional[float] = ..., filters: _Optional[_Mapping[str, str]] = ..., namespace: _Optional[str] = ..., collection: _Optional[str] = ..., database: _Optional[str] = ..., include_vectors: _Optional[bool] = ..., include_metadata: _Optional[bool] = ...) -> None: ...

class QueryResult(_message.Message):
    __slots__ = ("request_id", "status", "matches", "error", "timing", "completed_at")
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MATCHES_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    TIMING_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    status: str
    matches: _containers.RepeatedCompositeFieldContainer[VectorMatch]
    error: str
    timing: QueryTiming
    completed_at: str
    def __init__(self, request_id: _Optional[str] = ..., status: _Optional[str] = ..., matches: _Optional[_Iterable[_Union[VectorMatch, _Mapping]]] = ..., error: _Optional[str] = ..., timing: _Optional[_Union[QueryTiming, _Mapping]] = ..., completed_at: _Optional[str] = ...) -> None: ...

class VectorMatch(_message.Message):
    __slots__ = ("id", "score", "metadata", "vector")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    VECTOR_FIELD_NUMBER: _ClassVar[int]
    id: str
    score: float
    metadata: _containers.ScalarMap[str, str]
    vector: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, id: _Optional[str] = ..., score: _Optional[float] = ..., metadata: _Optional[_Mapping[str, str]] = ..., vector: _Optional[_Iterable[float]] = ...) -> None: ...

class QueryTiming(_message.Message):
    __slots__ = ("queue_wait_ms", "embedding_ms", "search_ms", "total_ms")
    QUEUE_WAIT_MS_FIELD_NUMBER: _ClassVar[int]
    EMBEDDING_MS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_MS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_MS_FIELD_NUMBER: _ClassVar[int]
    queue_wait_ms: int
    embedding_ms: int
    search_ms: int
    total_ms: int
    def __init__(self, queue_wait_ms: _Optional[int] = ..., embedding_ms: _Optional[int] = ..., search_ms: _Optional[int] = ..., total_ms: _Optional[int] = ...) -> None: ...
