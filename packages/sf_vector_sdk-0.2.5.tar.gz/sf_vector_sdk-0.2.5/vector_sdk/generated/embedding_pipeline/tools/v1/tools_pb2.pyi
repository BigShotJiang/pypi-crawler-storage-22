from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class ToolCollection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TOOL_COLLECTION_UNSPECIFIED: _ClassVar[ToolCollection]
    TOOL_COLLECTION_FLASHCARD: _ClassVar[ToolCollection]
    TOOL_COLLECTION_TEST_QUESTION: _ClassVar[ToolCollection]
    TOOL_COLLECTION_SPACED_TEST_QUESTION: _ClassVar[ToolCollection]
    TOOL_COLLECTION_AUDIO_RECAP_V2_SECTION: _ClassVar[ToolCollection]
    TOOL_COLLECTION_TOPIC: _ClassVar[ToolCollection]

class FlashCardType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FLASH_CARD_TYPE_UNSPECIFIED: _ClassVar[FlashCardType]
    FLASH_CARD_TYPE_BASIC: _ClassVar[FlashCardType]
    FLASH_CARD_TYPE_CLOZE: _ClassVar[FlashCardType]
    FLASH_CARD_TYPE_FILL_IN_THE_BLANK: _ClassVar[FlashCardType]
    FLASH_CARD_TYPE_MULTIPLE_CHOICE: _ClassVar[FlashCardType]
TOOL_COLLECTION_UNSPECIFIED: ToolCollection
TOOL_COLLECTION_FLASHCARD: ToolCollection
TOOL_COLLECTION_TEST_QUESTION: ToolCollection
TOOL_COLLECTION_SPACED_TEST_QUESTION: ToolCollection
TOOL_COLLECTION_AUDIO_RECAP_V2_SECTION: ToolCollection
TOOL_COLLECTION_TOPIC: ToolCollection
FLASH_CARD_TYPE_UNSPECIFIED: FlashCardType
FLASH_CARD_TYPE_BASIC: FlashCardType
FLASH_CARD_TYPE_CLOZE: FlashCardType
FLASH_CARD_TYPE_FILL_IN_THE_BLANK: FlashCardType
FLASH_CARD_TYPE_MULTIPLE_CHOICE: FlashCardType

class TopicMetadata(_message.Message):
    __slots__ = ("user_id", "topic_id", "extra")
    class ExtraEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    TOPIC_ID_FIELD_NUMBER: _ClassVar[int]
    EXTRA_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    topic_id: str
    extra: _containers.ScalarMap[str, str]
    def __init__(self, user_id: _Optional[str] = ..., topic_id: _Optional[str] = ..., extra: _Optional[_Mapping[str, str]] = ...) -> None: ...
