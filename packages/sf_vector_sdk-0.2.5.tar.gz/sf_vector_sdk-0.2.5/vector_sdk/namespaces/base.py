"""
Base namespace class providing shared context for all namespace implementations.
"""

from typing import Optional

from redis import Redis


class BaseNamespace:
    """
    Base class for all namespace implementations.
    Provides access to shared Redis and HTTP clients.
    """

    def __init__(self, redis: Redis, http_url: Optional[str] = None):
        """
        Initialize the base namespace.

        Args:
            redis: Redis client instance
            http_url: Optional HTTP URL for query-gateway API
        """
        self._redis = redis
        self._http_url = http_url

    def _require_http_url(self, method_name: str) -> str:
        """
        Helper to require http_url for HTTP-based operations.

        Args:
            method_name: Name of the method requiring http_url

        Returns:
            The http_url

        Raises:
            ValueError: If http_url is not configured
        """
        if not self._http_url:
            raise ValueError(
                f"http_url is required for {method_name}. "
                "Set it in VectorClient constructor."
            )
        return self._http_url
