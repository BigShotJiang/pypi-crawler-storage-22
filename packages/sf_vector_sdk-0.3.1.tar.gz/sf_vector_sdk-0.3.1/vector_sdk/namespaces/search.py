"""
Search namespace for vector similarity search operations.
"""

import json
import uuid
from datetime import datetime
from typing import Optional

from vector_sdk.namespaces.base import BaseNamespace
from vector_sdk.types import (
    EmbeddingConfigOverride,
    QueryConfig,
    QueryRequest,
    QueryResult,
    get_query_stream_for_priority,
    validate_model,
)


class SearchNamespace(BaseNamespace):
    """
    Namespace for vector search operations.

    Example:
        ```python
        client = VectorClient("redis://localhost:6379")

        # Search for similar vectors
        result = client.search.query_and_wait(
            query_text="What is machine learning?",
            database="turbopuffer",
            namespace="topic_vectors",
            top_k=10,
        )

        for match in result.matches:
            print(f"{match.id}: {match.score}")
        ```
    """

    def query(
        self,
        query_text: str,
        database: str,
        top_k: int = 10,
        min_score: Optional[float] = None,
        filters: Optional[dict[str, str]] = None,
        namespace: Optional[str] = None,
        collection: Optional[str] = None,
        database_name: Optional[str] = None,
        include_vectors: bool = False,
        include_metadata: bool = True,
        embedding_model: Optional[str] = None,
        embedding_dimensions: Optional[int] = None,
        priority: str = "normal",
        metadata: Optional[dict[str, str]] = None,
        request_id: Optional[str] = None,
    ) -> str:
        """
        Submit a vector search query.

        This method embeds the query text and searches for similar vectors in
        the specified database. Returns a request ID - use `wait_for()` to get
        the results, or use `query_and_wait()` for a combined operation.

        Args:
            query_text: The text to search for (will be embedded)
            database: Which vector database to search ("mongodb", "turbopuffer", "pinecone")
            top_k: Number of results to return (default: 10)
            min_score: Minimum similarity score threshold (0.0 to 1.0)
            filters: Metadata filters for filtering results
            namespace: Namespace for Pinecone/TurboPuffer
            collection: Collection name for MongoDB
            database_name: Database name for MongoDB
            include_vectors: Whether to include vector values in response
            include_metadata: Whether to include metadata in response
            embedding_model: Optional embedding model override
            embedding_dimensions: Optional embedding dimensions override
            priority: Queue priority (default: "normal")
            metadata: Optional key-value pairs for tracking
            request_id: Optional custom request ID

        Returns:
            The request ID for tracking the query

        Raises:
            ValueError: If query_text is empty
            ModelValidationError: If embedding model is not supported
        """
        if not query_text or query_text.strip() == "":
            raise ValueError("query_text cannot be empty")

        # Validate embedding model if specified
        if embedding_model:
            validate_model(embedding_model, embedding_dimensions)

        if request_id is None:
            request_id = str(uuid.uuid4())

        query_config = QueryConfig(
            top_k=top_k,
            min_score=min_score,
            filters=filters,
            namespace=namespace,
            collection=collection,
            database=database_name,
            include_vectors=include_vectors,
            include_metadata=include_metadata,
        )

        embedding_config = None
        if embedding_model or embedding_dimensions:
            embedding_config = EmbeddingConfigOverride(
                model=embedding_model,
                dimensions=embedding_dimensions,
            )

        request = QueryRequest(
            request_id=request_id,
            query_text=query_text,
            database=database,
            priority=priority,
            query_config=query_config,
            embedding_config=embedding_config,
            metadata={
                **(metadata or {}),
                "apiKey": self._api_key,
            },
            created_at=datetime.utcnow(),
        )

        stream = get_query_stream_for_priority(priority)
        payload = json.dumps(request.to_dict())
        self._redis.xadd(stream, {"data": payload})

        return request_id

    def wait_for(
        self,
        request_id: str,
        timeout: int = 30,
    ) -> QueryResult:
        """
        Wait for a search query to complete.

        Args:
            request_id: The request ID to wait for
            timeout: Maximum time to wait in seconds (default: 30)

        Returns:
            The query result

        Raises:
            TimeoutError: If no result is received within the timeout
        """
        list_key = f"query:response:{request_id}"

        # BRPOP blocks until result is available or timeout
        result = self._redis.brpop(list_key, timeout=timeout)

        if result is None:
            raise TimeoutError(
                f"No query result received for {request_id} within {timeout}s"
            )

        # result = (key, value)
        data = json.loads(result[1])
        # Cleanup the response list
        self._redis.delete(list_key)
        return QueryResult.from_dict(data)

    def query_and_wait(
        self,
        query_text: str,
        database: str,
        top_k: int = 10,
        min_score: Optional[float] = None,
        filters: Optional[dict[str, str]] = None,
        namespace: Optional[str] = None,
        collection: Optional[str] = None,
        database_name: Optional[str] = None,
        include_vectors: bool = False,
        include_metadata: bool = True,
        embedding_model: Optional[str] = None,
        embedding_dimensions: Optional[int] = None,
        priority: str = "normal",
        metadata: Optional[dict[str, str]] = None,
        timeout: int = 30,
    ) -> QueryResult:
        """
        Submit a search query and wait for the result.

        Uses BRPOP for efficient blocking wait - no race condition since the result
        is pushed to a list that persists until consumed.

        Args:
            query_text: The text to search for
            database: Which vector database to search
            top_k: Number of results to return
            min_score: Minimum similarity score threshold
            filters: Metadata filters
            namespace: Namespace for Pinecone/TurboPuffer
            collection: Collection name for MongoDB
            database_name: Database name for MongoDB
            include_vectors: Include vectors in response
            include_metadata: Include metadata in response
            embedding_model: Optional embedding model override
            embedding_dimensions: Optional embedding dimensions override
            priority: Queue priority
            metadata: Optional metadata for tracking
            timeout: Maximum time to wait in seconds

        Returns:
            The query result
        """
        request_id = str(uuid.uuid4())

        # Submit the request first
        self.query(
            query_text=query_text,
            database=database,
            top_k=top_k,
            min_score=min_score,
            filters=filters,
            namespace=namespace,
            collection=collection,
            database_name=database_name,
            include_vectors=include_vectors,
            include_metadata=include_metadata,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            priority=priority,
            metadata=metadata,
            request_id=request_id,
        )

        # Wait for result via BRPOP
        return self.wait_for(request_id, timeout)
