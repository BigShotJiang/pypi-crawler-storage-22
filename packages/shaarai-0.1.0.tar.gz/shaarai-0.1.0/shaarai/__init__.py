"""ShaarAI - The AI Revenue Control Plane SDK.

Track AI vendor attribution, measure ROI, and optimize AI-driven revenue.

Usage:
    from shaarai import ShaarClient, TokenUsage

    client = ShaarClient(api_key="shaar_...")
    offers = client.get_offers(ai_vendor="openai", category="saas")
"""

from shaarai.client import ShaarClient, TokenUsage, Offer

__version__ = "0.1.0"
__all__ = ["ShaarClient", "TokenUsage", "Offer"]
