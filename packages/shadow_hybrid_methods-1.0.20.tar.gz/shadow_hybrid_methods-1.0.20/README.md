# hybrid-methods
Collection of algorithms that combine raytracing with wave optics, to improve accuracy
