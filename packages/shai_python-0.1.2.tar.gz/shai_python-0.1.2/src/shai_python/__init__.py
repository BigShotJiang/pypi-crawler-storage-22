"""Shai - AI-powered shell command generator using LLM models."""

__version__ = "0.1.2"
__author__ = "zonghai"
__email__ = "zonghai@gmail.com"