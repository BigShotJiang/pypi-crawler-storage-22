# Shakal Scorer

Face analysis scoring using Face++ API.

## Install

```bash
pip install shakal-scorer
```

## Usage

```python
from shakal_scorer import ShakalScorer

scorer = ShakalScorer(
    api_key="your_facepp_key",
    api_secret="your_facepp_secret"
)

with open("photo.jpg", "rb") as f:
    result = scorer.analyze(f.read())

print(result.overall_score)  # 7.2
print(result.category)       # "Theek Thaak"
print(result.breakdown)      # {beauty: 7.1, symmetry: 6.8, ...}
print(result.metadata)       # {age: 24, gender: "Male", ...}
```

## Score Categories

| Score | Category |
|-------|----------|
| 8.5+  | Mashallah Boss! |
| 7.0+  | Solid Hai Yaar |
| 5.5+  | Theek Thaak |
| 4.0+  | Kuch Karna Parega |
| <4.0  | Bhai... Serious Talk |
