"""
Shakal Scorer - Face analysis with scoring
"""
from .scorer import ShakalScorer
from .models import ShakalResult

__version__ = "0.1.0"
__all__ = ["ShakalScorer", "ShakalResult"]
