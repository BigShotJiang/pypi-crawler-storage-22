"""
Data models for Shakal Scorer
"""
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class ShakalResult:
    """Result from face analysis"""
    overall_score: float
    category: str
    breakdown: Dict[str, float]
    metadata: Dict[str, any]

    def to_dict(self) -> dict:
        return {
            "overall_score": self.overall_score,
            "category": self.category,
            "breakdown": self.breakdown,
            "metadata": self.metadata
        }
