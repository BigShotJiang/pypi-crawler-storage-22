"""
Main Shakal Scorer class - Face++ integration + scoring
"""
import requests
import base64
from typing import Dict, Any, Optional
from .models import ShakalResult


class ShakalScorer:
    """
    Face analysis scorer using Face++ API

    Usage:
        scorer = ShakalScorer(api_key="xxx", api_secret="xxx")
        result = scorer.analyze(image_bytes)
        print(result.overall_score)  # 7.2
    """

    FACEPP_URL = "https://api-us.faceplusplus.com/facepp/v3/detect"

    WEIGHTS = {
        'beauty': 0.25,
        'symmetry': 0.20,
        'skin': 0.15,
        'smile': 0.10,
        'grooming': 0.10,
        'angle': 0.10,
        'lighting': 0.05,
        'eyes': 0.05
    }

    CATEGORIES = [
        (8.5, "Mashallah Boss!"),
        (7.0, "Solid Hai Yaar"),
        (5.5, "Theek Thaak"),
        (4.0, "Kuch Karna Parega"),
        (0.0, "Bhai... Serious Talk")
    ]

    def __init__(self, api_key: str, api_secret: str):
        self.api_key = api_key
        self.api_secret = api_secret

    def analyze(self, image_bytes: bytes) -> ShakalResult:
        """
        Analyze face in image and return scores

        Args:
            image_bytes: Image as bytes

        Returns:
            ShakalResult with scores and metadata

        Raises:
            ValueError: If no face found or API error
        """
        face_data = self._call_facepp(image_bytes)
        return self._calculate_scores(face_data)

    def _call_facepp(self, image_bytes: bytes) -> Dict[str, Any]:
        """Call Face++ API and parse response"""
        image_base64 = base64.b64encode(image_bytes).decode('utf-8')

        response = requests.post(
            self.FACEPP_URL,
            data={
                'api_key': self.api_key,
                'api_secret': self.api_secret,
                'image_base64': image_base64,
                'return_landmark': '1',
                'return_attributes': 'gender,age,smiling,headpose,facequality,blur,eyestatus,emotion,beauty,mouthstatus,skinstatus'
            },
            timeout=30
        )

        data = response.json()

        if 'error_message' in data:
            raise ValueError(f"Face++ error: {data['error_message']}")

        faces = data.get('faces', [])
        if len(faces) == 0:
            raise ValueError("Bhai face nazar nahi aa raha!")
        if len(faces) > 1:
            raise ValueError("Ek hi shakal dikhao yaar!")

        return self._parse_face(faces[0])

    def _parse_face(self, face: Dict) -> Dict[str, Any]:
        """Parse Face++ response into our format"""
        attr = face.get('attributes', {})
        landmark = face.get('landmark', {})

        # Basic attributes
        age = attr.get('age', {}).get('value', 25)
        gender = attr.get('gender', {}).get('value', 'Male')
        smile_val = attr.get('smile', {}).get('value', 0)
        headpose = attr.get('headpose', {})
        quality = attr.get('facequality', {}).get('value', 50)
        blur = attr.get('blur', {}).get('blurness', {}).get('value', 0)
        emotion = attr.get('emotion', {})
        beauty = attr.get('beauty', {})
        eyestatus = attr.get('eyestatus', {})
        mouthstatus = attr.get('mouthstatus', {})
        skinstatus = attr.get('skinstatus', {})

        # Dominant emotion
        dom_emotion = max(emotion.items(), key=lambda x: x[1]) if emotion else ('neutral', 0)
        emotion_map = {
            'anger': 'ANGRY', 'disgust': 'DISGUSTED', 'fear': 'FEAR',
            'happiness': 'HAPPY', 'neutral': 'CALM', 'sadness': 'SAD', 'surprise': 'SURPRISED'
        }

        # Eye status
        left_eye = eyestatus.get('left_eye_status', {})
        right_eye = eyestatus.get('right_eye_status', {})
        eyes_open = (
            left_eye.get('normal_glass_eye_open', 0) + left_eye.get('no_glass_eye_open', 0) +
            right_eye.get('normal_glass_eye_open', 0) + right_eye.get('no_glass_eye_open', 0)
        ) / 2
        has_glasses = (left_eye.get('normal_glass_eye_open', 0) + right_eye.get('normal_glass_eye_open', 0)) > 50
        has_sunglasses = (left_eye.get('dark_glasses', 0) + right_eye.get('dark_glasses', 0)) / 2 > 50

        # Skin quality
        skin_health = skinstatus.get('health', 0)
        skin_stain = skinstatus.get('stain', 0)
        skin_acne = skinstatus.get('acne', 0)
        skin_quality = skin_health - (skin_stain + skin_acne) / 2

        # Beauty score (gender-specific)
        beauty_score = beauty.get('male_score', 50) if gender == 'Male' else beauty.get('female_score', 50)

        # Landmarks for symmetry
        landmarks = []
        lm_map = {
            'left_eye_center': 'eyeLeft', 'right_eye_center': 'eyeRight',
            'nose_tip': 'nose', 'mouth_left_corner': 'mouthLeft', 'mouth_right_corner': 'mouthRight'
        }
        for fpp, our in lm_map.items():
            if fpp in landmark:
                landmarks.append({'Type': our, 'X': landmark[fpp].get('x', 0) / 1000, 'Y': landmark[fpp].get('y', 0) / 1000})

        return {
            'age': age,
            'gender': gender,
            'smile': smile_val > 50,
            'smile_confidence': smile_val,
            'dominant_emotion': emotion_map.get(dom_emotion[0], 'CALM'),
            'yaw': headpose.get('yaw_angle', 0),
            'pitch': headpose.get('pitch_angle', 0),
            'roll': headpose.get('roll_angle', 0),
            'brightness': quality,
            'sharpness': 100 - blur,
            'beauty_score': beauty_score,
            'skin_quality': skin_quality,
            'eyes_open': eyes_open > 50,
            'eyes_open_confidence': eyes_open,
            'eyeglasses': has_glasses,
            'sunglasses': has_sunglasses,
            'mouth_open': mouthstatus.get('open', 0) > 50,
            'landmarks': landmarks
        }

    def _calculate_scores(self, data: Dict) -> ShakalResult:
        """Calculate all scores from parsed face data"""
        scores = {
            'beauty': self._score_beauty(data),
            'symmetry': self._score_symmetry(data),
            'skin': self._score_skin(data),
            'smile': self._score_smile(data),
            'grooming': self._score_grooming(data),
            'angle': self._score_angle(data),
            'lighting': self._score_lighting(data),
            'eyes': self._score_eyes(data)
        }

        overall = sum(scores[k] * self.WEIGHTS[k] for k in self.WEIGHTS)
        category = next(cat for thresh, cat in self.CATEGORIES if overall >= thresh)

        return ShakalResult(
            overall_score=round(overall, 1),
            category=category,
            breakdown={k: round(v, 1) for k, v in scores.items()},
            metadata={
                'age': data['age'],
                'gender': data['gender'],
                'emotion': data['dominant_emotion'],
                'yaw': round(data['yaw'], 1),
                'pitch': round(data['pitch'], 1),
                'roll': round(data['roll'], 1),
                'has_glasses': data['eyeglasses'],
                'has_sunglasses': data['sunglasses'],
                'is_smiling': data['smile']
            }
        )

    def _score_beauty(self, d: Dict) -> float:
        return max(1.0, min(10.0, d['beauty_score'] / 10))

    def _score_symmetry(self, d: Dict) -> float:
        landmarks = d.get('landmarks', [])
        if len(landmarks) < 3:
            return 6.0
        lm = {l['Type']: l for l in landmarks}
        nose = lm.get('nose', {})
        mid = nose.get('X', 0.5)
        left = lm.get('eyeLeft', {})
        right = lm.get('eyeRight', {})
        if not left or not right:
            return 6.0
        l_dist = abs(left.get('X', 0) - mid)
        r_dist = abs(right.get('X', 0) - mid)
        if l_dist + r_dist == 0:
            return 6.0
        dev = abs(l_dist - r_dist) / ((l_dist + r_dist) / 2)
        return max(1.0, min(10.0, 10 - dev * 20))

    def _score_skin(self, d: Dict) -> float:
        sq = d.get('skin_quality', 0)
        score = (sq + 100) / 20 if sq != 0 else d.get('sharpness', 50) / 10
        return max(1.0, min(10.0, score))

    def _score_smile(self, d: Dict) -> float:
        if d['smile']:
            return max(1.0, min(10.0, d['smile_confidence'] / 10))
        em = d['dominant_emotion']
        if em in ['ANGRY', 'SAD', 'DISGUSTED', 'FEAR']:
            return 3.0
        return 5.0

    def _score_grooming(self, d: Dict) -> float:
        if d['sunglasses']:
            return 4.0
        return 8.0 if d['eyeglasses'] else 7.5

    def _score_angle(self, d: Dict) -> float:
        yaw, pitch, roll = abs(d['yaw']), abs(d['pitch']), abs(d['roll'])
        penalty = 0
        penalty += 5.0 if yaw > 30 else (yaw - 15) / 6 if yaw > 15 else yaw / 30
        penalty += 3.0 if pitch > 20 else (pitch - 10) / 5 if pitch > 10 else pitch / 20
        penalty += 2.0 if roll > 15 else (roll - 5) / 5 if roll > 5 else roll / 15
        return max(1.0, min(10.0, 10 - penalty))

    def _score_lighting(self, d: Dict) -> float:
        b = d.get('brightness', 50)
        if 40 <= b <= 70: return 10.0
        if 30 <= b < 40 or 70 < b <= 80: return 8.0
        if 20 <= b < 30 or 80 < b <= 90: return 6.0
        if b < 20: return 3.0
        return 5.0

    def _score_eyes(self, d: Dict) -> float:
        if d['eyes_open']:
            return max(5.0, min(10.0, d['eyes_open_confidence'] / 10))
        return 3.0
