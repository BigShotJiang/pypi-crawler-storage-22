# shalinee-text-utils

A simple Python package for basic text utilities like cleaning text and counting words.

##installation
```bash
pip install shalinee-text-utils


#3 usage

from shalinee-text-utils import clean_text,word_count

text = " Hello   welcome   to   the world    of anlytics"


print(clean_text(text))
print(word_count(text))






