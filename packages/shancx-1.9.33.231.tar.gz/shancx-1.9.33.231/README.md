# Welecome to shancx

A simple Python package that provides a timer decorator to measure the execution time of functions.

## Installation
 
pip install shancx
 
 