#!/usr/bin/env python3
# Copyright (c) 2025 Damien Boureille
# Licensed under the MIT License.

"""
Sheaf Console - Interactive REPL for the Sheaf language.

Usage:
    python -m sheaf.repl
    or
    sheaf console
"""

import os
import sys

import jax.numpy as jnp

from sheaf import __version__
from sheaf.core.compiler import Sheaf
from sheaf.core.error_handler import install_exception_handler
from sheaf.core.tracer import shf_tracer
from sheaf.repl.help import get_help

# Try to import readline for line editing and history
try:
    import readline

    HAS_READLINE = True
except ImportError:
    HAS_READLINE = False


class SheafCompleter:
    """Auto-completion for Sheaf REPL."""

    def __init__(self, compiler):
        self.compiler = compiler
        self.commands = [
            ":help",
            ":h",
            ":?",
            ":quit",
            ":q",
            ":exit",
            ":trace",
            ":scope",
            ":env",
            ":registry",
            ":reg",
            ":show",
        ]

    def complete(self, text, state):
        """Return the state-th completion for text."""
        if state == 0:
            # First call: compute all matches
            if text.startswith(":"):
                # Complete commands
                self.matches = [cmd for cmd in self.commands if cmd.startswith(text)]
            else:
                # Complete function/variable names
                all_names = []

                # Add functions from registry
                if self.compiler.registry:
                    all_names.extend(self.compiler.registry.keys())

                # Add variables from environment
                if self.compiler.env:
                    all_names.extend(self.compiler.env.keys())

                # Add special forms (vmap, scan, let, defn, etc.)
                if self.compiler.special_forms:
                    all_names.extend(self.compiler.special_forms.keys())

                # Filter matches
                self.matches = [name for name in all_names if name.startswith(text)]
                self.matches = sorted(set(self.matches))  # Unique and sorted

        # Return the state-th match, or None if exhausted
        try:
            return self.matches[state]
        except IndexError:
            return None


def is_balanced(text):
    """Check if parentheses and brackets are balanced in the text."""
    stack = []
    pairs = {"(": ")", "[": "]", "{": "}"}

    in_string = False
    in_comment = False

    i = 0
    while i < len(text):
        char = text[i]

        # Handle comments (from ; to end of line)
        if char == ";":
            in_comment = True
        elif char == "\n":
            in_comment = False

        # Skip if we're in a comment
        if in_comment:
            i += 1
            continue

        # Handle strings
        if char == '"':
            in_string = not in_string

        # Skip if we're in a string
        if in_string:
            i += 1
            continue

        # Check brackets/parens
        if char in pairs:
            stack.append(char)
        elif char in pairs.values():
            if not stack:
                return False  # Closing without opening
            opener = stack.pop()
            if pairs[opener] != char:
                return False  # Mismatched

        i += 1

    # All brackets should be closed
    return len(stack) == 0


def format_result(value):
    if isinstance(value, jnp.ndarray):
        # Format JAX arrays with shape and dtype info
        shape_str = "x".join(str(d) for d in value.shape)
        dtype_str = (
            str(value.dtype)
            .replace("bfloat16", "bf16")
            .replace("float32", "f32")
            .replace("int32", "i32")
        )

        # Show actual values for small arrays
        if value.size <= 10:
            return f"Tensor {dtype_str}[{shape_str}] = {value}"
        else:
            # For larger arrays, show shape and stats
            import numpy as np

            mean_val = float(np.mean(value))
            min_val = float(np.min(value))
            max_val = float(np.max(value))

            stats = f"μ={mean_val:.3f} min={min_val:.3f} max={max_val:.3f}"
            return f"Tensor {dtype_str}[{shape_str}] ({stats})"

    elif value is None:
        return ""  # Don't print anything for None (e.g., from def, use)

    elif isinstance(value, dict):
        # Format dictionaries (like params trees)
        return f"Dict with {len(value)} keys: {list(value.keys())}"

    else:
        # Default Python repr
        return repr(value)


def print_help():
    print("""
Sheaf Console - Interactive REPL

Commands:
  :help, :h           Show this help message
  :?, :? <name>       Show help for a function/special-form
  :quit, :q, :exit    Exit the REPL
  :trace <mode>       Set trace mode: off, fast, normal, verbose
  :scope <name>       Filter traces to functions matching <name>
  :scope off          Disable scope filtering
  :env                Show current environment (defined variables)
  :registry, :reg     List user-defined functions
  :show <name>        Show value of variable or function source

Expression evaluation:
  Type any Sheaf expression and press Enter to evaluate it.

Examples:
  (+ 1 2)
  (let (x [1 2 3]) (shape x))
  [1 2 3 4] :bf16

Tab: Completes the current command (or lists all commands if empty).

Press Ctrl+C or Ctrl+D to exit.
""")


def run_repl():
    """Run the main REPL loop."""
    # NOTE: We don't install the exception handler here because we handle
    # exceptions manually in the REPL loop for better control

    # Create compiler instance
    compiler = Sheaf()

    # Setup readline history and completion if available
    history_file = os.path.expanduser("~/.sheaf_history")
    if HAS_READLINE:
        # Load history, grouping multi-line commands back together
        if os.path.exists(history_file):
            try:
                with open(history_file, "r", encoding="utf-8") as f:
                    lines = f.readlines()

                # Group lines into complete commands based on bracket balance
                commands = []
                current_cmd = ""
                for line in lines:
                    line = line.rstrip("\n")
                    current_cmd += line

                    if is_balanced(current_cmd):
                        if current_cmd.strip():
                            commands.append(current_cmd)
                        current_cmd = ""
                    else:
                        current_cmd += "\n"

                # Add any remaining incomplete command (shouldn't happen)
                if current_cmd.strip():
                    commands.append(current_cmd)

                # Add all commands to readline history (skip quit commands and empty)
                for cmd in commands:
                    stripped = cmd.strip()
                    # Skip quit commands and empty lines
                    if stripped and stripped not in (":q", ":quit"):
                        readline.add_history(cmd)

            except (FileNotFoundError, PermissionError, UnicodeDecodeError):
                pass  # No history file yet or encoding issue

        readline.set_history_length(1000)

        # Setup auto-completion
        completer = SheafCompleter(compiler)
        readline.set_completer(completer.complete)

        # Set delimiters to make Lisp symbols work better
        # Don't break on '-' so we can complete 'multi-head-attention'
        readline.set_completer_delims(" \t\n()[]{}")

        # Configure tab completion (compatible with both GNU readline and libedit)
        if "libedit" in readline.__doc__:
            # macOS uses libedit
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            # Linux/BSD use GNU readline
            readline.parse_and_bind("tab: complete")

    print(f"Welcome to Sheaf Console v{__version__}")
    print("Type :help or :h for help, :quit or :q to exit")
    print()

    while True:
        try:
            # Read input (potentially multi-line)
            try:
                line = input("sheaf> ")

                # Check for unclosed parentheses/brackets - continue reading
                while not is_balanced(line):
                    continuation = input("...    ")
                    line += "\n" + continuation

            except EOFError:
                print("\nBye!")
                break

            # Skip empty lines
            if not line.strip():
                continue

            # Handle commands
            if line.startswith(":"):
                cmd_parts = line[1:].strip().split(maxsplit=1)
                cmd = cmd_parts[0].lower()
                cmd_arg = cmd_parts[1] if len(cmd_parts) > 1 else None

                if cmd in ("quit", "q", "exit"):
                    print("Bye!")
                    break

                elif cmd in ("help", "h"):
                    print_help()
                    continue

                elif cmd == "?":
                    # Help for specific function/special-form
                    if cmd_arg:
                        help_text = get_help(cmd_arg)
                        print(help_text)
                    else:
                        print_help()
                    continue

                elif cmd == "trace":
                    if not cmd_arg:
                        # Show current trace mode
                        status = "enabled" if shf_tracer.enabled else "disabled"
                        mode = shf_tracer.mode if shf_tracer.enabled else "off"
                        print(f"Trace: {status} (mode: {mode})")
                    elif cmd_arg == "off":
                        shf_tracer.enabled = False
                        print("Trace disabled")
                    elif cmd_arg in ("fast", "normal", "verbose"):
                        shf_tracer.enabled = True
                        shf_tracer.mode = cmd_arg
                        print(f"Trace enabled: {cmd_arg} mode")
                    else:
                        print(f"Unknown trace mode: {cmd_arg}")
                        print("Valid modes: off, fast, normal, verbose")
                    continue

                elif cmd == "scope":
                    if not cmd_arg:
                        # Show current scope filter
                        if shf_tracer.scope_filter:
                            print(f"Scope filter: {shf_tracer.scope_filter}")
                        else:
                            print("Scope filter: none (tracing all functions)")
                    elif cmd_arg == "off":
                        shf_tracer.scope_filter = None
                        print("Scope filter disabled")
                    else:
                        shf_tracer.scope_filter = cmd_arg
                        print(f"Scope filter set to: {cmd_arg}")
                    continue

                elif cmd == "env":
                    # Show environment
                    registry = compiler.registry
                    env = compiler.env

                    print("Registry (functions):")
                    if registry:
                        for name in sorted(registry.keys()):
                            print(f"  {name}")
                    else:
                        print("  (empty)")

                    print("\nEnvironment (variables):")
                    if env:
                        for name in sorted(env.keys()):
                            val = env[name]
                            if callable(val):
                                print(f"  {name}: <function>")
                            elif hasattr(val, "shape"):
                                shape_str = "x".join(str(d) for d in val.shape)
                                dtype_str = (
                                    str(val.dtype)
                                    .replace("float32", "f32")
                                    .replace("int32", "i32")
                                )
                                print(f"  {name}: Tensor {dtype_str}[{shape_str}]")
                            else:
                                print(f"  {name}: {type(val).__name__}")
                    else:
                        print("  (empty)")
                    continue

                elif cmd in ("registry", "reg"):
                    # List user-defined functions
                    registry = compiler.registry
                    if registry:
                        print("User-defined functions:")
                        for name in sorted(registry.keys()):
                            print(f"  {name}")
                    else:
                        print("No user-defined functions yet.")
                        print("Try: (defn square [x] (* x x))")
                    continue

                elif cmd == "show":
                    # Show variable value or function source
                    if not cmd_arg:
                        print("Usage: :show <name>")
                        continue

                    # Check if it's in registry (user function)
                    if cmd_arg in compiler.registry:
                        func = compiler.registry[cmd_arg]
                        if hasattr(func, "__sheaf_source__"):
                            print(f"⇒ {func.__sheaf_source__}")
                        else:
                            print(f"⇒ <function {cmd_arg}>")
                    # Check if it's in environment (variable or builtin)
                    elif cmd_arg in compiler.env:
                        val = compiler.env[cmd_arg]
                        formatted = format_result(val)
                        if formatted:
                            print(f"⇒ {formatted}")
                        else:
                            print(f"⇒ {val}")
                    else:
                        print(f"Error: '{cmd_arg}' not found")
                        print("Try :env to see all available names")
                    continue

                else:
                    print(f"Unknown command: :{cmd}")
                    print("Type :help for available commands")
                    continue

            # Evaluate Sheaf expression
            try:
                from sheaf.core.error_handler import set_source
                from sheaf.core.parser import (
                    SheafRuntimeError,
                    SheafSyntaxError,
                    parse_full,
                )

                # Parse the input
                set_source(line, "<repl>")
                expressions = parse_full(line, "<repl>")

                # Evaluate each expression and keep the last result
                result = None
                for expr in expressions:
                    result = compiler.compile(expr, {})

                # Format and print result
                formatted = format_result(result)
                if formatted:
                    print(f"⇒ {formatted}")

            except KeyboardInterrupt:
                print("\nInterrupted")
                continue
            except (SheafRuntimeError, SheafSyntaxError) as e:
                # Sheaf errors - they come pre-formatted as the message
                # Just print the exception message
                print(f"\n{e}")
                continue
            except Exception as e:
                # Other exceptions - format nicely
                print(f"\nerror: {type(e).__name__}: {e}")
                continue

        except KeyboardInterrupt:
            print("\nUse :quit to exit")
            continue

    # Save history on exit
    if HAS_READLINE:
        try:
            # Let readline write the history file
            readline.write_history_file(history_file)

            # Then clean up the escaped sequences that readline may have added
            # (especially on macOS with libedit)
            import re

            try:
                with open(history_file, "r", encoding="latin-1") as f:
                    content = f.read()

                # Decode readline's octal escaping: \040 → space, \012 → newline, etc.
                def decode_octal(match):
                    octal_str = match.group(1)
                    return chr(int(octal_str, 8))

                content = re.sub(r"\\([0-7]{3})", decode_octal, content)

                # Filter out quit commands and clean up empty lines
                lines = content.split("\n")
                filtered_lines = []
                current_cmd = ""

                for line in lines:
                    current_cmd += line

                    # Check if this line completes a command (balanced brackets)
                    if is_balanced(current_cmd):
                        stripped = current_cmd.strip()
                        # Only keep non-empty, non-quit commands
                        if stripped and stripped not in (":q", ":quit", ":exit"):
                            filtered_lines.append(current_cmd)
                        current_cmd = ""
                    else:
                        current_cmd += "\n"

                # Write back as UTF-8
                with open(history_file, "w", encoding="utf-8") as f:
                    f.write("\n".join(filtered_lines))
                    if filtered_lines:
                        f.write("\n")  # Trailing newline
            except Exception:
                pass  # If cleanup fails, at least readline saved something
        except Exception:
            pass  # Ignore errors saving history


def main():
    """Entry point for the REPL."""
    try:
        run_repl()
    except KeyboardInterrupt:
        print("\nBye!")
        sys.exit(0)


if __name__ == "__main__":
    main()
