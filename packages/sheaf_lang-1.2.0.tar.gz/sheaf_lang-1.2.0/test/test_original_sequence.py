#!/usr/bin/env python3

import jax
import jax.numpy as jnp
from sheaf import Sheaf

def main():
    # Initialize Sheaf
    shf = Sheaf()
    
    # Load Sheaf code
    with open('rnn_model.shf', 'r') as f:
        shf.load(f.read())
    
    # First train on simple sequence
    print("Training on simple sequence [1, 1, 1, 1] -> 1")
    simple_seq = jnp.array([1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
    simple_target = jnp.array([1.0], dtype=jnp.float32)
    
    hidden_size = 8
    lr = 0.005
    
    # Initialize
    key = jax.random.PRNGKey(42)
    key_rnn, key_out = jax.random.split(key)
    
    params = {
        "rnn": {
            "W_hh": jax.random.normal(key_rnn, (hidden_size, hidden_size)) * 0.05,
            "W_xh": jax.random.normal(key_rnn, (hidden_size, 1)) * 0.05,
            "b_h": jnp.zeros((hidden_size,))
        },
        "output": {
            "W_out": jax.random.normal(key_out, (1, hidden_size)) * 0.05,
            "b_out": jnp.zeros((1,))
        }
    }
    
    m = jax.tree_util.tree_map(lambda x: jnp.zeros_like(x), params)
    v = jax.tree_util.tree_map(lambda x: jnp.zeros_like(x), params)
    t = 1
    
    # Train on simple sequence
    for epoch in range(150):  # We know this converges quickly
        result = shf.train_step(params, m, v, t, simple_seq, simple_target, lr)
        params = result["params"]
        m = result["m"]
        v = result["v"]
        t = result["t"]
    
    # Test on simple sequence
    simple_pred = shf.forward(simple_seq, params)
    print(f"Simple sequence prediction: {simple_pred[0]:.3f} (target: 1.0)")
    
    # Now test on original sequence
    print("\nTesting on original sequence [1, 2, 3, 4] -> 5")
    original_seq = jnp.array([1.0, 2.0, 3.0, 4.0], dtype=jnp.float32)
    original_target = jnp.array([5.0], dtype=jnp.float32)
    
    original_pred = shf.forward(original_seq, params)
    print(f"Prediction: {original_pred[0]:.3f}")
    print(f"Target: {original_target[0]:.1f}")
    print(f"Error: {abs(original_pred[0] - original_target[0]):.3f}")
    
    # Test on Fibonacci sequence
    print("\nTesting on Fibonacci sequence [1, 1, 2, 3] -> 5")
    fib_seq = jnp.array([1.0, 1.0, 2.0, 3.0], dtype=jnp.float32)
    fib_target = jnp.array([5.0], dtype=jnp.float32)
    
    fib_pred = shf.forward(fib_seq, params)
    print(f"Prediction: {fib_pred[0]:.3f}")
    print(f"Target: {fib_target[0]:.1f}")
    print(f"Error: {abs(fib_pred[0] - fib_target[0]):.3f}")
    
    # Test on linear sequence
    print("\nTesting on linear sequence [2, 4, 6, 8] -> 10")
    linear_seq = jnp.array([2.0, 4.0, 6.0, 8.0], dtype=jnp.float32)
    linear_target = jnp.array([10.0], dtype=jnp.float32)
    
    linear_pred = shf.forward(linear_seq, params)
    print(f"Prediction: {linear_pred[0]:.3f}")
    print(f"Target: {linear_target[0]:.1f}")
    print(f"Error: {abs(linear_pred[0] - linear_target[0]):.3f}")

if __name__ == "__main__":
    main()