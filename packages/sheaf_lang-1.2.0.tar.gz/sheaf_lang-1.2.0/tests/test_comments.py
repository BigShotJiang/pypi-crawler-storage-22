"""
Test that inline comments work with both ; and ;;
"""

import sys

sys.path.insert(0, ".")

from sheaf import Sheaf


def test_comments():
    code = """
(defn add-numbers (a b)
  ;; This is a double semicolon comment
  (+ a b))  ; This is a single semicolon comment

(defn multiply (x y)
  (* x y))  ; Another inline comment

;; Call the functions
(add-numbers 5 10)
(multiply 3 4)
"""

    print("Testing comments support...\n")
    print("Code with comments:")
    print(code)
    print("\nLoading...")

    shf = Sheaf()
    shf.load(code, filename="test_comments.shf")

    print("✅ Code loaded successfully!")
    print(f"add-numbers(5, 10) = {shf.add_numbers(5, 10)}")
    print(f"multiply(3, 4) = {shf.multiply(3, 4)}")


if __name__ == "__main__":
    test_comments()
