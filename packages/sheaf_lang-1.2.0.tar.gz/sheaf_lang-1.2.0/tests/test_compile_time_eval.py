#!/usr/bin/env python3
"""
Test suite for compile-time evaluation in macros
"""

from sheaf import Sheaf


def test_simple_compile_time_eval():
    """Test basic compile-time evaluation with map"""
    print("=" * 60)
    print("Testing Simple Compile-Time Evaluation")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Define a helper function that transforms data
    code = """
    (defn double [x]
      (* x 2))

    ;; Macro that uses map at compile-time
    (defmacro make-doubled-list [& nums]
      `(list ~@(map double nums)))

    (defn test-doubled []
      (make-doubled-list 1 2 3))
    """

    print("Code:")
    print(code)
    print()

    shf.load(code)
    result = shf.test_doubled()

    print(f"Result: {result}")
    print(f"Expected: [2, 4, 6]")

    assert result == [2, 4, 6], f"Expected [2, 4, 6], got {result}"
    print("✓ Compile-time map works!\n")

    return True


def test_compile_time_list_manipulation():
    """Test compile-time list manipulation with rest"""
    print("=" * 60)
    print("Testing Compile-Time List Manipulation")
    print("=" * 60 + "\n")

    shf = Sheaf()

    code = """
    ;; Helper that adds 10 to a number
    (defn add-ten [x]
      (+ x 10))

    ;; Macro that transforms rest of arguments
    (defmacro transform-rest [first & rest-args]
      `(list ~first ~@(map add-ten rest-args)))

    (defn test-rest []
      (transform-rest 1 2 3 4))
    """

    print("Code:")
    print(code)
    print()

    shf.load(code)
    result = shf.test_rest()

    print(f"Result: {result}")
    print(f"Expected: [1, 12, 13, 14]")

    # Convert JAX arrays to ints for comparison
    result_ints = [int(x) for x in result]
    assert result_ints == [1, 12, 13, 14], (
        f"Expected [1, 12, 13, 14], got {result_ints}"
    )
    print("✓ Compile-time rest and map work!\n")

    return True


def test_compile_time_cons():
    """Test compile-time cons for building expressions"""
    print("=" * 60)
    print("Testing Compile-Time cons")
    print("=" * 60 + "\n")

    shf = Sheaf()

    code = """
    ;; Macro that builds a + expression at compile-time
    (defmacro make-sum [a b]
      `~(cons '+ (list a b)))

    (defn test-sum []
      (make-sum 10 20))
    """

    print("Code:")
    print(code)
    print()

    shf.load(code)
    result = shf.test_sum()

    print(f"Result: {result}")
    print(f"Expected: 30")

    assert result == 30, f"Expected 30, got {result}"
    print("✓ Compile-time cons works!\n")

    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("COMPILE-TIME EVALUATION TEST SUITE")
    print("=" * 60 + "\n")

    simple_ok = test_simple_compile_time_eval()
    list_ok = test_compile_time_list_manipulation()
    cons_ok = test_compile_time_cons()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Simple eval:      {'PASS ✓' if simple_ok else 'FAIL ✗'}")
    print(f"List manipulation: {'PASS ✓' if list_ok else 'FAIL ✗'}")
    print(f"Cons:             {'PASS ✓' if cons_ok else 'FAIL ✗'}")
    print("=" * 60)

    if all([simple_ok, list_ok, cons_ok]):
        print("\n✓ All compile-time evaluation tests passed!")
    else:
        print("\n✗ Some tests failed!")
        exit(1)
