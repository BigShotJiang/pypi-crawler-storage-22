#!/usr/bin/env python3
"""
Test defmacro special form with quasiquote.
"""

from sheaf import Sheaf


def test_defmacro_when():
    """Test defining 'when' macro in Sheaf."""
    print("=" * 60)
    print("Testing defmacro: when macro")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Define the 'when' macro in Sheaf
    code = """
    (defmacro when [cond body]
      `(if ~cond ~body nil))

    (defn test-when [x]
      (when (> x 0)
        (+ x 10)))
    """

    print("Loading code:")
    print(code)
    print()

    shf.load(code)

    print("✓ Macro defined and function compiled\n")

    # Test the function
    result1 = shf.test_when(5)
    result2 = shf.test_when(-5)

    print(f"test-when(5) = {result1} (expected: 15)")
    print(f"test-when(-5) = {result2} (expected: None)")

    assert result1 == 15, f"Expected 15, got {result1}"
    assert result2 is None, f"Expected None, got {result2}"

    print("\n✓ when macro works correctly\n")
    return True


def test_defmacro_unless():
    """Test defining 'unless' macro in Sheaf."""
    print("=" * 60)
    print("Testing defmacro: unless macro")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Define the 'unless' macro in Sheaf
    code = """
    (defmacro unless [cond body]
      `(if ~cond nil ~body))

    (defn test-unless [x]
      (unless (> x 0)
        (+ x 100)))
    """

    print("Loading code:")
    print(code)
    print()

    shf.load(code)

    print("✓ Macro defined and function compiled\n")

    # Test the function
    result1 = shf.test_unless(5)
    result2 = shf.test_unless(-5)

    print(f"test-unless(5) = {result1} (expected: None)")
    print(f"test-unless(-5) = {result2} (expected: 95)")

    assert result1 is None, f"Expected None, got {result1}"
    assert result2 == 95, f"Expected 95, got {result2}"

    print("\n✓ unless macro works correctly\n")
    return True


def test_defmacro_with_splicing():
    """Test macro with unquote-splicing."""
    print("=" * 60)
    print("Testing defmacro: with splicing")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # This won't work perfectly yet because we need list operations
    # But let's test the splicing mechanism
    code = """
    (defmacro mylet [bindings body]
      `(let ~bindings ~body))

    (defn test-mylet [x y]
      (mylet [z (+ x y)]
        (* z 2)))
    """

    print("Loading code:")
    print(code)
    print()

    shf.load(code)

    print("✓ Macro with bindings compiled\n")

    # Test
    result = shf.test_mylet(3, 4)

    print(f"test-mylet(3, 4) = {result} (expected: 14)")

    assert result == 14, f"Expected 14, got {result}"

    print("\n✓ Macro with splicing works\n")
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("DEFMACRO TEST SUITE")
    print("=" * 60 + "\n")

    when_ok = test_defmacro_when()
    unless_ok = test_defmacro_unless()
    splicing_ok = test_defmacro_with_splicing()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"when macro:    {'PASS ✓' if when_ok else 'FAIL ✗'}")
    print(f"unless macro:  {'PASS ✓' if unless_ok else 'FAIL ✗'}")
    print(f"splicing test: {'PASS ✓' if splicing_ok else 'FAIL ✗'}")

    if when_ok and unless_ok and splicing_ok:
        print("\n✓ All defmacro tests passed!")
    else:
        print("\n✗ Some tests failed")
