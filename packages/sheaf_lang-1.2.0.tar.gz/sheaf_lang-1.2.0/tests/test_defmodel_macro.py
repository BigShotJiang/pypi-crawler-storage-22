#!/usr/bin/env python3
"""
Test the defmodel macro.
"""

import jax
import jax.numpy as jnp

from sheaf import Sheaf


def test_defmodel():
    print("Testing defmodel macro...\n")

    shf = Sheaf()

    # Define a simple MLP using defmodel
    code = """
    (defmodel my-mlp [x]
      (layer :l1 (linear 128) :relu)
      (layer :l2 (linear 10) :softmax))
    """

    print("Loading defmodel code:")
    print(code)
    print()

    try:
        shf.load(code)
        print("✓ Macro expanded and compiled successfully\n")

        # Check that the function was registered
        if "my-mlp" not in shf.registry:
            print("✗ FAILED: my-mlp not found in registry")
            return False

        print(f"✓ Function registered: {list(shf.registry.keys())}\n")

        # Initialize parameters
        print("Initializing parameters...")
        key = jax.random.PRNGKey(42)
        k1, k2 = jax.random.split(key)

        params = {
            "l1": {
                "W": jax.random.normal(k1, (4, 128)),
                "b": jnp.zeros(128),
            },
            "l2": {
                "W": jax.random.normal(k2, (128, 10)),
                "b": jnp.zeros(10),
            },
        }

        print(f"✓ Parameters initialized\n")

        # Test forward pass
        print("Running forward pass...")
        x = jnp.ones((1, 4))

        result = shf.my_mlp(x, params)

        print(f"✓ Forward pass successful")
        print(f"  Input shape: {x.shape}")
        print(f"  Output shape: {result.shape}")
        print(f"  Expected: (1, 10)")
        print(f"  Output sum (should be ~1 after softmax): {jnp.sum(result):.4f}\n")

        if result.shape != (1, 10):
            print("✗ FAILED: Shape mismatch")
            return False

        # Check softmax sum
        if not jnp.allclose(jnp.sum(result), 1.0):
            print("✗ FAILED: Softmax output doesn't sum to 1")
            return False

        print("✓ ALL TESTS PASSED\n")
        return True

    except Exception as e:
        print(f"✗ FAILED: {e}")
        import traceback

        traceback.print_exc()
        return False


def test_macro_expansion():
    """Test that the macro expands correctly."""
    print("\n" + "=" * 60)
    print("Testing macro expansion details...")
    print("=" * 60 + "\n")

    from sheaf.core.macro_engine import defmodel_macro

    # Macro call: (defmodel my-mlp [x] ...)
    args = [
        "my-mlp",
        ["x"],
        ["layer", ":l1", ["linear", 128], ":relu"],
        ["layer", ":l2", ["linear", 10], ":softmax"],
    ]

    expanded = defmodel_macro(args)

    print("Macro arguments:")
    print(f"  {args}\n")

    print("Expanded to:")
    print(f"  {expanded}\n")

    # Check structure
    if expanded[0] != "defn":
        print("✗ FAILED: Should expand to defn")
        return False

    if expanded[1] != "my-mlp":
        print("✗ FAILED: Name should be my-mlp")
        return False

    if expanded[2] != ["x", "p"]:
        print("✗ FAILED: Should have [x p] params")
        return False

    print("✓ Expansion structure looks correct\n")
    return True


if __name__ == "__main__":
    print("=" * 60)
    print("DEFMODEL MACRO TEST SUITE")
    print("=" * 60 + "\n")

    # Test expansion
    expansion_ok = test_macro_expansion()

    # Test compilation and execution
    defmodel_ok = test_defmodel()

    # Summary
    print("=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Macro expansion: {'PASS ✓' if expansion_ok else 'FAIL ✗'}")
    print(f"defmodel test:   {'PASS ✓' if defmodel_ok else 'FAIL ✗'}")

    if expansion_ok and defmodel_ok:
        print("\n✓ All macro tests passed!")
    else:
        print("\n✗ Some tests failed")
