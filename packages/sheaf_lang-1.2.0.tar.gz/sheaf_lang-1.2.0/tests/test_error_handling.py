# 2025 Damien Boureille | MIT License
# Part of the Sheaf Language - https://github.com/sheaf/sheaf

"""
Translates Python/JAX exceptions into human-readable Sheaf diagnostics
with source code context and automated troubleshooting suggestions.
"""

import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from sheaf import Sheaf


def test_error():
    print("Testing Sheaf error handling...\n")

    shf = Sheaf()

    # Read the buggy file
    with open("test_error.shf", "r") as f:
        code = f.read()

    try:
        shf.load(code, filename="test_error.shf")
        print("No error occurred (unexpected!)")
    except Exception as e:
        print(f"Caught error (this is what the user sees):")
        print(str(e))


if __name__ == "__main__":
    test_error()
