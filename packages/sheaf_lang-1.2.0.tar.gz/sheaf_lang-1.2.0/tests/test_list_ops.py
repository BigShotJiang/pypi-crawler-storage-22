#!/usr/bin/env python3
"""
Test suite for list manipulation functions (cons, rest, empty?, count)
"""

from sheaf import Sheaf


def test_cons():
    """Test cons function for constructing lists"""
    print("=" * 60)
    print("Testing cons")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test 1: cons with numbers
    shf.load("(defn test-cons-numbers [] (cons 1 (list 2 3)))")
    result = shf.test_cons_numbers()
    print(f"(cons 1 (list 2 3)) = {result}")
    assert result == [1, 2, 3], f"Expected [1, 2, 3], got {result}"
    print("✓ cons with numbers works\n")

    # Test 2: cons with empty list
    shf.load("(defn test-cons-empty [] (cons 'a (list)))")
    result = shf.test_cons_empty()
    print(f"(cons 'a (list)) = {result}")
    assert result == ["a"], f"Expected ['a'], got {result}"
    print("✓ cons with empty list works\n")

    # Test 3: cons with symbols
    shf.load("(defn test-cons-symbols [] (cons 'x (list 'y 'z)))")
    result = shf.test_cons_symbols()
    print(f"(cons 'x (list 'y 'z)) = {result}")
    assert result == ["x", "y", "z"], f"Expected ['x', 'y', 'z'], got {result}"
    print("✓ cons with symbols works\n")

    # Test 4: nested cons
    shf.load("(defn test-nested-cons [] (cons 1 (cons 2 (list 3))))")
    result = shf.test_nested_cons()
    print(f"(cons 1 (cons 2 (list 3))) = {result}")
    assert result == [1, 2, 3], f"Expected [1, 2, 3], got {result}"
    print("✓ nested cons works\n")

    print("=" * 60)
    print("✓ All cons tests passed!")
    print("=" * 60 + "\n")
    return True


def test_rest():
    """Test rest function for getting tail of list"""
    print("=" * 60)
    print("Testing rest")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test 1: rest with multiple elements
    shf.load("(defn test-rest-multiple [] (rest (list 1 2 3)))")
    result = shf.test_rest_multiple()
    print(f"(rest (list 1 2 3)) = {result}")
    assert result == [2, 3], f"Expected [2, 3], got {result}"
    print("✓ rest with multiple elements works\n")

    # Test 2: rest with single element
    shf.load("(defn test-rest-single [] (rest (list 'a)))")
    result = shf.test_rest_single()
    print(f"(rest (list 'a)) = {result}")
    assert result == [], f"Expected [], got {result}"
    print("✓ rest with single element works\n")

    # Test 3: rest with empty list
    shf.load("(defn test-rest-empty [] (rest (list)))")
    result = shf.test_rest_empty()
    print(f"(rest (list)) = {result}")
    assert result == [], f"Expected [], got {result}"
    print("✓ rest with empty list works\n")

    print("=" * 60)
    print("✓ All rest tests passed!")
    print("=" * 60 + "\n")
    return True


def test_empty_q():
    """Test empty? predicate"""
    print("=" * 60)
    print("Testing empty?")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test 1: empty list
    shf.load("(defn test-empty-true [] (empty? (list)))")
    result = shf.test_empty_true()
    print(f"(empty? (list)) = {result}")
    assert result is True, f"Expected True, got {result}"
    print("✓ empty? on empty list works\n")

    # Test 2: non-empty list
    shf.load("(defn test-empty-false [] (empty? (list 1 2)))")
    result = shf.test_empty_false()
    print(f"(empty? (list 1 2)) = {result}")
    assert result is False, f"Expected False, got {result}"
    print("✓ empty? on non-empty list works\n")

    print("=" * 60)
    print("✓ All empty? tests passed!")
    print("=" * 60 + "\n")
    return True


def test_count():
    """Test count function"""
    print("=" * 60)
    print("Testing count")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test 1: count elements
    shf.load("(defn test-count-three [] (count (list 1 2 3)))")
    result = shf.test_count_three()
    print(f"(count (list 1 2 3)) = {result}")
    assert result == 3, f"Expected 3, got {result}"
    print("✓ count with elements works\n")

    # Test 2: count empty
    shf.load("(defn test-count-zero [] (count (list)))")
    result = shf.test_count_zero()
    print(f"(count (list)) = {result}")
    assert result == 0, f"Expected 0, got {result}"
    print("✓ count empty list works\n")

    print("=" * 60)
    print("✓ All count tests passed!")
    print("=" * 60 + "\n")
    return True


def test_list_construction():
    """Test building lists with cons and quote"""
    print("=" * 60)
    print("Testing List Construction with Quote")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test constructing a list of symbols
    code = """
    (defn make-call []
      (cons '+ (cons 1 (cons 2 (list)))))
    """
    shf.load(code)
    result = shf.make_call()
    print(f"(cons '+ (cons 1 (cons 2 (list)))) = {result}")
    assert result == ["+", 1, 2], f"Expected ['+', 1, 2], got {result}"
    print("✓ List construction with cons and quote works\n")

    print("=" * 60)
    print("✓ List construction test passed!")
    print("=" * 60 + "\n")
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("LIST OPERATIONS TEST SUITE")
    print("=" * 60 + "\n")

    cons_ok = test_cons()
    rest_ok = test_rest()
    empty_ok = test_empty_q()
    count_ok = test_count()
    construct_ok = test_list_construction()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"cons tests:      {'PASS ✓' if cons_ok else 'FAIL ✗'}")
    print(f"rest tests:      {'PASS ✓' if rest_ok else 'FAIL ✗'}")
    print(f"empty? tests:    {'PASS ✓' if empty_ok else 'FAIL ✗'}")
    print(f"count tests:     {'PASS ✓' if count_ok else 'FAIL ✗'}")
    print(f"construction:    {'PASS ✓' if construct_ok else 'FAIL ✗'}")
    print("=" * 60)

    if all([cons_ok, rest_ok, empty_ok, count_ok, construct_ok]):
        print("\n✓ All list operation tests passed!")
    else:
        print("\n✗ Some tests failed!")
        exit(1)
