#!/usr/bin/env python3
"""
Test the lib/macros.shf standard library.
"""

from sheaf import Sheaf


def test_macros_lib():
    """Test loading and using macros from lib/macros.shf"""
    print("=" * 60)
    print("Testing lib/macros.shf")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Load the macro library
    print("Loading lib/macros.shf...")
    shf.load("(use macros)")
    print("✓ Macros loaded\n")

    # Test when macro
    print("Testing 'when' macro from library...")
    shf.load("""
    (defn test-when [x]
      (when (> x 0)
        (* x 2)))
    """)

    result1 = shf.test_when(5)
    result2 = shf.test_when(-3)

    print(f"test-when(5) = {result1} (expected: 10)")
    print(f"test-when(-3) = {result2} (expected: None)")

    assert result1 == 10, f"Expected 10, got {result1}"
    assert result2 is None, f"Expected None, got {result2}"
    print("✓ 'when' macro works\n")

    # Test unless macro
    print("Testing 'unless' macro from library...")
    shf.load("""
    (defn test-unless [x]
      (unless (< x 0)
        (+ x 100)))
    """)

    result3 = shf.test_unless(5)
    result4 = shf.test_unless(-3)

    print(f"test-unless(5) = {result3} (expected: 105)")
    print(f"test-unless(-3) = {result4} (expected: None)")

    assert result3 == 105, f"Expected 105, got {result3}"
    assert result4 is None, f"Expected None, got {result4}"
    print("✓ 'unless' macro works\n")

    # Test comment macro
    print("Testing 'comment' macro from library...")
    shf.load("""
    (defn test-comment [x]
      (comment
        (print "This should not execute")
        (/ x 0))
      (+ x 5))
    """)

    result5 = shf.test_comment(10)
    print(f"test-comment(10) = {result5} (expected: 15)")
    assert result5 == 15, f"Expected 15, got {result5}"
    print("✓ 'comment' macro works (code was ignored)\n")

    print("=" * 60)
    print("✓ All lib/macros.shf tests passed!")
    print("=" * 60)
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("LIB/MACROS.SHF TEST SUITE")
    print("=" * 60 + "\n")

    success = test_macros_lib()

    if success:
        print("\n✓ Library integration successful!")
    else:
        print("\n✗ Library tests failed")
