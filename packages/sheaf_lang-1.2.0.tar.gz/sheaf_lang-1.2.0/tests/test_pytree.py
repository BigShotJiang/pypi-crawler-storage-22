# Copyright (c) 2025 Damien Boureille
# Licensed under the MIT License.
# See LICENSE file in the project root for full license information.

"""
Tests for pytree serialization (to_pytree / from_pytree).
"""

import jax
import jax.numpy as jnp
import pytest

from sheaf import Sheaf


def test_to_pytree_scalar():
    """Test conversion of scalar values."""
    shf = Sheaf()

    assert shf.to_pytree(42) == 42
    assert shf.to_pytree(3.14) == 3.14
    assert shf.to_pytree(True) is True
    assert shf.to_pytree(None) is None


def test_to_pytree_tensor():
    """Test conversion of JAX arrays."""
    shf = Sheaf()

    arr = jnp.array([1, 2, 3])
    result = shf.to_pytree(arr)
    assert isinstance(result, jnp.ndarray)
    assert jnp.array_equal(result, arr)


def test_to_pytree_list():
    """Test conversion of lists."""
    shf = Sheaf()

    data = [1, 2, jnp.array([3, 4]), 5.0]
    result = shf.to_pytree(data)

    assert isinstance(result, list)
    assert len(result) == 4
    assert result[0] == 1
    assert result[1] == 2
    assert jnp.array_equal(result[2], jnp.array([3, 4]))
    assert result[3] == 5.0


def test_to_pytree_dict():
    """Test conversion of dictionaries."""
    shf = Sheaf()

    data = {
        "weights": jnp.array([[1, 2], [3, 4]]),
        "bias": jnp.array([0.1, 0.2]),
        "learning_rate": 0.001,
    }

    result = shf.to_pytree(data)

    assert isinstance(result, dict)
    assert set(result.keys()) == {"weights", "bias", "learning_rate"}
    assert jnp.array_equal(result["weights"], data["weights"])
    assert jnp.array_equal(result["bias"], data["bias"])
    assert result["learning_rate"] == 0.001


def test_to_pytree_nested():
    """Test conversion of nested structures."""
    shf = Sheaf()

    data = {
        "layer1": {
            "w": jnp.array([[1, 2]]),
            "b": jnp.array([0.5]),
        },
        "layer2": {
            "w": jnp.array([[3, 4]]),
            "b": jnp.array([1.0]),
        },
        "config": {
            "hidden_size": 128,
            "dropout": 0.1,
        },
    }

    result = shf.to_pytree(data)

    assert isinstance(result, dict)
    assert isinstance(result["layer1"], dict)
    assert isinstance(result["config"], dict)
    assert jnp.array_equal(result["layer1"]["w"], jnp.array([[1, 2]]))
    assert result["config"]["hidden_size"] == 128


def test_to_pytree_rejects_functions():
    """Test that functions cannot be serialized."""
    shf = Sheaf()

    def my_func():
        pass

    with pytest.raises(TypeError, match="Cannot serialize type.*function"):
        shf.to_pytree(my_func)


def test_to_pytree_rejects_functions_in_dict():
    """Test that functions in dicts are rejected."""
    shf = Sheaf()

    def my_func():
        pass

    data = {"valid": 42, "invalid": my_func}

    with pytest.raises(TypeError, match="Cannot serialize type.*function"):
        shf.to_pytree(data)


def test_from_pytree_scalar():
    """Test reconstruction of scalar values."""
    shf = Sheaf()

    assert shf.from_pytree(42) == 42
    assert shf.from_pytree(3.14) == 3.14
    assert shf.from_pytree(True) is True
    assert shf.from_pytree(None) is None


def test_from_pytree_tensor():
    """Test reconstruction of JAX arrays."""
    shf = Sheaf()

    arr = jnp.array([1, 2, 3])
    result = shf.from_pytree(arr)
    assert isinstance(result, jnp.ndarray)
    assert jnp.array_equal(result, arr)


def test_from_pytree_dict():
    """Test reconstruction of dictionaries."""
    shf = Sheaf()

    tree = {
        "weights": jnp.array([[1, 2]]),
        "bias": jnp.array([0.5]),
        "lr": 0.001,
    }

    result = shf.from_pytree(tree)

    assert isinstance(result, dict)
    assert jnp.array_equal(result["weights"], tree["weights"])
    assert result["lr"] == 0.001


def test_roundtrip():
    """Test that from_pytree(to_pytree(x)) == x."""
    shf = Sheaf()

    original = {
        "params": {
            "w1": jnp.array([[1.0, 2.0], [3.0, 4.0]]),
            "b1": jnp.array([0.1, 0.2]),
            "w2": jnp.array([[5.0, 6.0]]),
            "b2": jnp.array([0.3]),
        },
        "state": {
            "step": 100,
            "lr": 0.001,
        },
        "metrics": [0.95, 0.87, 0.92],
    }

    # Roundtrip
    tree = shf.to_pytree(original)
    restored = shf.from_pytree(tree)

    # Check structure
    assert set(restored.keys()) == set(original.keys())
    assert set(restored["params"].keys()) == set(original["params"].keys())

    # Check values
    assert jnp.array_equal(restored["params"]["w1"], original["params"]["w1"])
    assert jnp.array_equal(restored["params"]["b2"], original["params"]["b2"])
    assert restored["state"]["step"] == 100
    assert restored["state"]["lr"] == 0.001
    assert restored["metrics"] == [0.95, 0.87, 0.92]


def test_pytree_compatible_with_jax():
    """Test that converted pytree works with JAX utilities."""
    shf = Sheaf()

    data = {
        "w": jnp.array([1.0, 2.0, 3.0]),
        "b": jnp.array([0.5]),
        "nested": {
            "x": jnp.array([10.0]),
        },
    }

    tree = shf.to_pytree(data)

    # Test with jax.tree_util.tree_map
    scaled = jax.tree_util.tree_map(
        lambda x: x * 2 if isinstance(x, jnp.ndarray) else x, tree
    )

    assert jnp.array_equal(scaled["w"], jnp.array([2.0, 4.0, 6.0]))
    assert jnp.array_equal(scaled["b"], jnp.array([1.0]))
    assert jnp.array_equal(scaled["nested"]["x"], jnp.array([20.0]))


def test_pytree_with_jit():
    """Test that pytree can be passed to JIT functions."""
    shf = Sheaf()

    @jax.jit
    def sum_params(params):
        return jax.tree_util.tree_reduce(
            lambda acc, x: acc + jnp.sum(x) if isinstance(x, jnp.ndarray) else acc,
            params,
            0.0,
        )

    params = {
        "w1": jnp.array([1.0, 2.0]),
        "w2": jnp.array([3.0, 4.0]),
    }

    tree = shf.to_pytree(params)
    result = sum_params(tree)

    assert float(result) == 10.0


def test_empty_structures():
    """Test conversion of empty structures."""
    shf = Sheaf()

    assert shf.to_pytree({}) == {}
    assert shf.to_pytree([]) == []

    assert shf.from_pytree({}) == {}
    assert shf.from_pytree([]) == []
