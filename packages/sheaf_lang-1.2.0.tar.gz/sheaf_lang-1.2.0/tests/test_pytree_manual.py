#!/usr/bin/env python3
"""Manual test for pytree serialization."""

import jax
import jax.numpy as jnp

from sheaf import Sheaf


def test_basic():
    """Test basic conversions."""
    print("Testing basic types...")
    shf = Sheaf()

    # Scalars
    assert shf.to_pytree(42) == 42
    assert shf.to_pytree(3.14) == 3.14
    assert shf.to_pytree(True) is True
    print("✓ Scalars work")

    # Arrays
    arr = jnp.array([1, 2, 3])
    result = shf.to_pytree(arr)
    assert jnp.array_equal(result, arr)
    print("✓ Arrays work")

    # Lists
    data = [1, 2, jnp.array([3, 4]), 5.0]
    result = shf.to_pytree(data)
    assert len(result) == 4
    assert jnp.array_equal(result[2], jnp.array([3, 4]))
    print("✓ Lists work")

    # Dicts
    data = {
        "weights": jnp.array([[1, 2], [3, 4]]),
        "bias": jnp.array([0.1, 0.2]),
        "lr": 0.001,
    }
    result = shf.to_pytree(data)
    assert jnp.array_equal(result["weights"], data["weights"])
    print("✓ Dicts work")


def test_roundtrip():
    """Test roundtrip conversion."""
    print("\nTesting roundtrip...")
    shf = Sheaf()

    original = {
        "params": {
            "w1": jnp.array([[1.0, 2.0], [3.0, 4.0]]),
            "b1": jnp.array([0.1, 0.2]),
        },
        "state": {
            "step": 100,
            "lr": 0.001,
        },
        "metrics": [0.95, 0.87],
    }

    tree = shf.to_pytree(original)
    restored = shf.from_pytree(tree)

    assert jnp.array_equal(restored["params"]["w1"], original["params"]["w1"])
    assert restored["state"]["step"] == 100
    assert restored["metrics"] == [0.95, 0.87]
    print("✓ Roundtrip preserves structure and values")


def test_jax_integration():
    """Test integration with JAX utilities."""
    print("\nTesting JAX integration...")
    shf = Sheaf()

    data = {
        "w": jnp.array([1.0, 2.0, 3.0]),
        "b": jnp.array([0.5]),
    }

    tree = shf.to_pytree(data)

    # Test with tree_map
    scaled = jax.tree_util.tree_map(
        lambda x: x * 2 if isinstance(x, jnp.ndarray) else x, tree
    )
    assert jnp.array_equal(scaled["w"], jnp.array([2.0, 4.0, 6.0]))
    print("✓ Works with jax.tree_util.tree_map")

    # Test with JIT
    @jax.jit
    def sum_params(params):
        return jax.tree_util.tree_reduce(
            lambda acc, x: acc + jnp.sum(x) if isinstance(x, jnp.ndarray) else acc,
            params,
            0.0,
        )

    result = sum_params(tree)
    assert float(result) == 6.5  # 1+2+3+0.5
    print("✓ Works with jax.jit")


def test_error_handling():
    """Test that invalid types are rejected."""
    print("\nTesting error handling...")
    shf = Sheaf()

    def my_func():
        pass

    try:
        shf.to_pytree(my_func)
        assert False, "Should have raised TypeError"
    except TypeError as e:
        assert "Cannot serialize" in str(e)
        print("✓ Functions are rejected correctly")


if __name__ == "__main__":
    test_basic()
    test_roundtrip()
    test_jax_integration()
    test_error_handling()
    print("\n✅ All tests passed!")
