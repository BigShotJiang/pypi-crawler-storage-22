#!/usr/bin/env python3
"""
Test quasiquote, unquote, and unquote-splicing functionality.
"""

from sheaf.core.macro_engine import MacroEngine
from sheaf.core.parser import parse_full


def test_parser_reader_macros():
    """Test that the parser correctly handles `, ~, and ~@ reader macros."""
    print("=" * 60)
    print("Testing Parser Reader Macros")
    print("=" * 60 + "\n")

    # Test backtick
    code1 = "`(a b c)"
    parsed1 = parse_full(code1)[0]
    print(f"Input:  {code1}")
    print(f"Parsed: {parsed1}")
    print(f"Expected: ['quasiquote', ['a', 'b', 'c']]")
    assert parsed1 == ["quasiquote", ["a", "b", "c"]]
    print("✓ Backtick works\n")

    # Test unquote
    code2 = "`(a ~b c)"
    parsed2 = parse_full(code2)[0]
    print(f"Input:  {code2}")
    print(f"Parsed: {parsed2}")
    print(f"Expected: ['quasiquote', ['a', ['unquote', 'b'], 'c']]")
    assert parsed2 == ["quasiquote", ["a", ["unquote", "b"], "c"]]
    print("✓ Unquote works\n")

    # Test unquote-splicing
    code3 = "`(a ~@b c)"
    parsed3 = parse_full(code3)[0]
    print(f"Input:  {code3}")
    print(f"Parsed: {parsed3}")
    print(f"Expected: ['quasiquote', ['a', ['unquote-splicing', 'b'], 'c']]")
    assert parsed3 == ["quasiquote", ["a", ["unquote-splicing", "b"], "c"]]
    print("✓ Unquote-splicing works\n")

    print("=" * 60)
    print("✓ All parser tests passed!")
    print("=" * 60 + "\n")
    return True


def test_quasiquote_expansion():
    """Test that quasiquote expansion works correctly."""
    print("=" * 60)
    print("Testing Quasiquote Expansion")
    print("=" * 60 + "\n")

    engine = MacroEngine()

    # Test 1: Simple quasiquote with unquote
    print("Test 1: Simple unquote")
    template = ["quasiquote", ["if", ["unquote", "cond"], "then", "else"]]
    bindings = {"cond": [">", "x", 0]}

    result = engine._expand_quasiquote(template[1], bindings, depth=0)
    print(f"Template: {template}")
    print(f"Bindings: {bindings}")
    print(f"Result:   {result}")
    print(f"Expected: ['if', ['>', 'x', 0], 'then', 'else']")
    assert result == ["if", [">", "x", 0], "then", "else"]
    print("✓ Simple unquote works\n")

    # Test 2: Unquote-splicing
    print("Test 2: Unquote-splicing")
    template2 = ["quasiquote", ["let", ["unquote-splicing", "bindings"], "body"]]
    bindings2 = {"bindings": [["x", 1], ["y", 2]]}

    result2 = engine._expand_quasiquote(template2[1], bindings2, depth=0)
    print(f"Template: {template2}")
    print(f"Bindings: {bindings2}")
    print(f"Result:   {result2}")
    print(f"Expected: ['let', ['x', 1], ['y', 2], 'body']")
    assert result2 == ["let", ["x", 1], ["y", 2], "body"]
    print("✓ Unquote-splicing works\n")

    # Test 3: Nested quasiquote
    print("Test 3: Multiple unquotes and splicing")
    template3 = [
        "quasiquote",
        [
            "defn",
            ["unquote", "name"],
            ["unquote", "params"],
            ["unquote-splicing", "body"],
        ],
    ]
    bindings3 = {
        "name": "my-func",
        "params": ["x", "y"],
        "body": [["let", ["z", ["+", "x", "y"]]], ["*", "z", 2]],
    }

    result3 = engine._expand_quasiquote(template3[1], bindings3, depth=0)
    print(f"Template: {template3}")
    print(f"Bindings: {bindings3}")
    print(f"Result:   {result3}")
    expected3 = [
        "defn",
        "my-func",
        ["x", "y"],
        ["let", ["z", ["+", "x", "y"]]],
        ["*", "z", 2],
    ]
    print(f"Expected: {expected3}")
    assert result3 == expected3
    print("✓ Multiple unquotes and splicing work\n")

    print("=" * 60)
    print("✓ All expansion tests passed!")
    print("=" * 60 + "\n")
    return True


def test_macro_with_quasiquote():
    """Test defining a macro using quasiquote syntax."""
    print("=" * 60)
    print("Testing Macro with Quasiquote")
    print("=" * 60 + "\n")

    engine = MacroEngine()

    # Define a simple 'when' macro using quasiquote
    def when_macro_qq(args):
        """(when cond body) => `(if ~cond ~body nil)"""
        if len(args) < 2:
            raise ValueError("when requires condition and body")

        cond = args[0]
        body = args[1]

        # Use quasiquote template
        template = [
            "quasiquote",
            ["if", ["unquote", "cond"], ["unquote", "body"], "nil"],
        ]
        bindings = {"cond": cond, "body": body}

        return engine._expand_quasiquote(template[1], bindings, depth=0)

    engine.defmacro_native("when", when_macro_qq)

    # Test expansion
    macro_call = ["when", [">", "x", 0], ["print", '"positive"']]
    expanded = engine.expand(macro_call)

    print(f"Macro call: {macro_call}")
    print(f"Expanded:   {expanded}")
    print(f"Expected:   ['if', ['>', 'x', 0], ['print', '\"positive\"'], 'nil']")

    assert expanded == ["if", [">", "x", 0], ["print", '"positive"'], "nil"]
    print("✓ Macro with quasiquote works\n")

    print("=" * 60)
    print("✓ Macro test passed!")
    print("=" * 60 + "\n")
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("QUASIQUOTE TEST SUITE")
    print("=" * 60 + "\n")

    parser_ok = test_parser_reader_macros()
    expansion_ok = test_quasiquote_expansion()
    macro_ok = test_macro_with_quasiquote()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Parser reader macros: {'PASS ✓' if parser_ok else 'FAIL ✗'}")
    print(f"Quasiquote expansion: {'PASS ✓' if expansion_ok else 'FAIL ✗'}")
    print(f"Macro with quasiquote: {'PASS ✓' if macro_ok else 'FAIL ✗'}")

    if parser_ok and expansion_ok and macro_ok:
        print("\n✓ All quasiquote tests passed!")
    else:
        print("\n✗ Some tests failed")
