#!/usr/bin/env python3
"""
Test quote special form and ' reader macro.
"""

from sheaf import Sheaf
from sheaf.core.parser import parse_full


def test_quote_reader_macro():
    """Test that the parser correctly handles ' reader macro."""
    print("=" * 60)
    print("Testing Quote Reader Macro")
    print("=" * 60 + "\n")

    # Test simple quote
    code1 = "'symbol"
    parsed1 = parse_full(code1)[0]
    print(f"Input:  {code1}")
    print(f"Parsed: {parsed1}")
    print(f"Expected: ['quote', 'symbol']")
    assert parsed1 == ["quote", "symbol"]
    print("✓ Simple quote works\n")

    # Test quoted list
    code2 = "'(a b c)"
    parsed2 = parse_full(code2)[0]
    print(f"Input:  {code2}")
    print(f"Parsed: {parsed2}")
    print(f"Expected: ['quote', ['a', 'b', 'c']]")
    assert parsed2 == ["quote", ["a", "b", "c"]]
    print("✓ Quoted list works\n")

    # Test nested quote
    code3 = "'(+ 1 2)"
    parsed3 = parse_full(code3)[0]
    print(f"Input:  {code3}")
    print(f"Parsed: {parsed3}")
    print(f"Expected: ['quote', ['+', 1, 2]]")
    assert parsed3 == ["quote", ["+", 1, 2]]
    print("✓ Quoted expression works\n")

    print("=" * 60)
    print("✓ All parser tests passed!")
    print("=" * 60 + "\n")
    return True


def test_quote_evaluation():
    """Test that quote prevents evaluation."""
    print("=" * 60)
    print("Testing Quote Evaluation")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test 1: Quote prevents symbol lookup
    print("Test 1: Quote prevents symbol lookup")
    shf.load("(defn test-quote-symbol [] 'x)")
    result1 = shf.test_quote_symbol()
    print(f"(defn test-quote-symbol [] 'x)")
    print(f"Result: {result1}")
    print(f"Type: {type(result1)}")
    assert result1 == "x", f"Expected 'x', got {result1}"
    print("✓ Symbol quote works\n")

    # Test 2: Quote prevents list evaluation
    print("Test 2: Quote prevents list evaluation")
    shf.load("(defn test-quote-list [] '(+ 1 2))")
    result2 = shf.test_quote_list()
    print(f"(defn test-quote-list [] '(+ 1 2))")
    print(f"Result: {result2}")
    assert result2 == ["+", 1, 2], f"Expected ['+', 1, 2], got {result2}"
    print("✓ List quote works\n")

    # Test 3: Compare quote vs no quote
    print("Test 3: Compare quote vs no quote")
    shf.load("""
    (defn without-quote [] (+ 1 2))
    (defn with-quote [] '(+ 1 2))
    """)

    result_eval = shf.without_quote()
    result_quote = shf.with_quote()

    print(f"without-quote: {result_eval} (evaluated)")
    print(f"with-quote: {result_quote} (not evaluated)")

    assert result_eval == 3, f"Without quote should evaluate to 3"
    assert result_quote == ["+", 1, 2], f"With quote should return list"
    print("✓ Quote prevents evaluation\n")

    # Test 4: Long form (quote expr)
    print("Test 4: Long form (quote expr)")
    shf.load("(defn test-quote-long [] (quote (a b c)))")
    result4 = shf.test_quote_long()
    print(f"(defn test-quote-long [] (quote (a b c)))")
    print(f"Result: {result4}")
    assert result4 == ["a", "b", "c"], f"Expected ['a', 'b', 'c'], got {result4}"
    print("✓ Long form quote works\n")

    print("=" * 60)
    print("✓ All evaluation tests passed!")
    print("=" * 60 + "\n")
    return True


def test_quote_in_macros():
    """Test using quote in macros."""
    print("=" * 60)
    print("Testing Quote in Macros")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Define a simple macro that uses quote to prevent evaluation
    code = """
    (defmacro return-quoted [x]
      `'~x)

    (defn test-quoted-macro []
      (return-quoted foo))
    """

    print("Macro definition:")
    print(code)

    shf.load(code)
    result = shf.test_quoted_macro()

    print(f"Result: {result}")
    print(f"Type: {type(result)}")
    print(f"Expected: 'foo' (symbol)")

    assert result == "foo", f"Expected 'foo', got {result}"
    assert isinstance(result, str), f"Expected symbol/string, got {type(result)}"
    print("✓ Quote in macros works\n")

    print("=" * 60)
    print("✓ Macro test passed!")
    print("=" * 60 + "\n")
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("QUOTE TEST SUITE")
    print("=" * 60 + "\n")

    parser_ok = test_quote_reader_macro()
    eval_ok = test_quote_evaluation()
    macro_ok = test_quote_in_macros()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Parser tests:     {'PASS ✓' if parser_ok else 'FAIL ✗'}")
    print(f"Evaluation tests: {'PASS ✓' if eval_ok else 'FAIL ✗'}")
    print(f"Macro tests:      {'PASS ✓' if macro_ok else 'FAIL ✗'}")

    if parser_ok and eval_ok and macro_ok:
        print("\n✓ All quote tests passed!")
    else:
        print("\n✗ Some tests failed")
