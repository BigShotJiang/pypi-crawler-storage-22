#!/usr/bin/env python3
"""
Test suite for symbol manipulation functions
"""

from sheaf import Sheaf


def test_symbol_q():
    """Test symbol? predicate"""
    print("=" * 60)
    print("Testing symbol?")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test 1: symbol? on symbol
    shf.load("(defn test-symbol-true [] (symbol? 'foo))")
    result = shf.test_symbol_true()
    print(f"(symbol? 'foo) = {result}")
    assert result is True, f"Expected True, got {result}"
    print("✓ symbol? on symbol works\n")

    # Test 2: symbol? on number
    shf.load("(defn test-symbol-false-number [] (symbol? 42))")
    result = shf.test_symbol_false_number()
    print(f"(symbol? 42) = {result}")
    assert result is False, f"Expected False, got {result}"
    print("✓ symbol? on number works\n")

    # Test 3: symbol? on list
    shf.load("(defn test-symbol-false-list [] (symbol? (list 1 2)))")
    result = shf.test_symbol_false_list()
    print(f"(symbol? (list 1 2)) = {result}")
    assert result is False, f"Expected False, got {result}"
    print("✓ symbol? on list works\n")

    print("=" * 60)
    print("✓ All symbol? tests passed!")
    print("=" * 60 + "\n")
    return True


def test_gensym():
    """Test gensym for unique symbol generation"""
    print("=" * 60)
    print("Testing gensym")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test 1: default gensym
    shf.load("(defn test-gensym-default [] (gensym))")
    result1 = shf.test_gensym_default()
    result2 = shf.test_gensym_default()
    print(f"(gensym) = {result1}")
    print(f"(gensym) = {result2}")
    assert result1 != result2, "gensym should generate unique symbols"
    assert result1.startswith("G__"), f"Expected 'G__' prefix, got {result1}"
    print("✓ gensym generates unique symbols\n")

    # Test 2: gensym with custom prefix
    shf.load('(defn test-gensym-custom [] (gensym "tmp_"))')
    result = shf.test_gensym_custom()
    print(f'(gensym "tmp_") = {result}')
    assert result.startswith("tmp_"), f"Expected 'tmp_' prefix, got {result}"
    print("✓ gensym with custom prefix works\n")

    print("=" * 60)
    print("✓ All gensym tests passed!")
    print("=" * 60 + "\n")
    return True


def test_symbols_in_macros():
    """Test using symbol manipulation in macros"""
    print("=" * 60)
    print("Testing Symbols in Macros")
    print("=" * 60 + "\n")

    shf = Sheaf()

    # Test using symbol? in a function
    code = """
    (defn test-sym-check []
      (symbol? 'test))
    """
    shf.load(code)
    result = shf.test_sym_check()
    print(f"(symbol? 'test) = {result}")
    assert result is True, f"Expected True, got {result}"
    print("✓ symbol? in functions works\n")

    print("=" * 60)
    print("✓ Symbols in macros test passed!")
    print("=" * 60 + "\n")
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("SYMBOL OPERATIONS TEST SUITE")
    print("=" * 60 + "\n")

    symbol_q_ok = test_symbol_q()
    gensym_ok = test_gensym()
    macros_ok = test_symbols_in_macros()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"symbol? tests:       {'PASS ✓' if symbol_q_ok else 'FAIL ✗'}")
    print(f"gensym tests:        {'PASS ✓' if gensym_ok else 'FAIL ✗'}")
    print(f"macros tests:        {'PASS ✓' if macros_ok else 'FAIL ✗'}")
    print("=" * 60)

    if all([symbol_q_ok, gensym_ok, macros_ok]):
        print("\n✓ All symbol operation tests passed!")
    else:
        print("\n✗ Some tests failed!")
        exit(1)
