"""
Test suite for trace and guard functionality in Sheaf.

This module tests:
- Console trace mode
- JSON trace mode
- Guard functionality with silent monitoring
- Different trace modes (fast, normal, verbose)

Note: Guard failure tests are not included as they use os._exit()
which cannot be caught in the same process.
"""

import json
import os
import tempfile

from sheaf import Sheaf
from sheaf.core.tracer import shf_tracer


def test_console_trace():
    """Test that console trace works with enabled=True"""
    shf = Sheaf()
    shf.load("(defn add-ten [x] (+ x 10))")

    # Enable console trace
    shf_tracer.enabled = True
    shf_tracer.mode = "normal"
    shf_tracer.log_format = "console"

    # Should not crash
    result = shf.add_ten(5)

    # Reset tracer
    shf_tracer.enabled = False
    shf_tracer.reset_ring_buffer()

    assert result == 15


def test_json_trace():
    """Test that JSON trace exports correctly"""
    with tempfile.TemporaryDirectory() as tmpdir:
        json_path = os.path.join(tmpdir, "test_trace.jsonl")

        shf = Sheaf()
        shf.load("""
        (defn inner [x]
          (+ x 10))

        (defn outer [x y]
          (+ (inner x) (inner y)))
        """)

        # Enable JSON trace
        shf_tracer.enabled = True
        shf_tracer.mode = "verbose"
        shf_tracer.log_format = "json"
        shf_tracer.json_path = json_path

        result = shf.outer(5, 7)

        # Reset tracer
        shf_tracer.enabled = False
        shf_tracer.log_format = "console"
        shf_tracer.reset_ring_buffer()

        # Check result
        assert result == 32

        # Check JSON file was created
        assert os.path.exists(json_path), "JSON trace file not created"

        # Parse and validate JSON events
        with open(json_path, "r") as f:
            events = [json.loads(line) for line in f]

        assert len(events) > 0, "No events logged"

        # Check structure of first event
        first_event = events[0]
        assert "type" in first_event
        assert "op" in first_event
        assert "level" in first_event
        assert "timestamp" in first_event
        assert "data" in first_event

        # Check we have call, arg, and return events
        event_types = set(e["type"] for e in events)
        assert "call" in event_types
        assert "arg" in event_types
        assert "return" in event_types


def test_guard_range_success():
    """Test that :range guards pass with valid values"""
    shf = Sheaf()
    shf.load("(defn test-guard [x] (let [y (+ x 10)] (guard :range [0 20] y) y))")

    # Enable silent monitoring for guards
    shf_tracer.enabled = False
    shf_tracer.monitoring = True

    # Test multiple valid values
    assert shf.test_guard(0) == 10  # Edge case: 0+10=10
    assert shf.test_guard(5) == 15  # Middle value
    assert shf.test_guard(10) == 20  # Edge case: 10+10=20

    # Reset tracer
    shf_tracer.monitoring = False
    shf_tracer.reset_ring_buffer()


def test_guard_shape_success():
    """Test that :shape guards pass with correct shapes"""
    shf = Sheaf()
    shf.load("(defn test-shape [x] (guard :shape [3] x) x)")

    # Enable silent monitoring
    shf_tracer.enabled = False
    shf_tracer.monitoring = True

    # Should pass with correct shape
    result = shf.test_shape([1, 2, 3])
    assert len(result) == 3

    # Reset tracer
    shf_tracer.monitoring = False
    shf_tracer.reset_ring_buffer()


def test_trace_modes():
    """Test different trace modes (fast, normal, verbose)"""
    shf = Sheaf()
    shf.load("(defn simple [x] (+ x 1))")

    for mode in ["fast", "normal", "verbose"]:
        shf_tracer.enabled = True
        shf_tracer.mode = mode
        shf_tracer.log_format = "console"

        result = shf.simple(10)
        assert result == 11

        shf_tracer.enabled = False
        shf_tracer.reset_ring_buffer()


def test_silent_monitoring():
    """Test that silent monitoring (for guards) fills ring buffer"""
    shf = Sheaf()
    shf.load("(defn compute [x] (+ (* x 2) 5))")

    # Enable silent monitoring (no console output, but ring buffer active)
    shf_tracer.enabled = False
    shf_tracer.monitoring = True
    shf_tracer.reset_ring_buffer()

    result = shf.compute(10)

    # Ring buffer should have entries
    assert len(shf_tracer.ring_buffer) > 0, (
        "Ring buffer should be filled in silent monitoring mode"
    )

    # Reset
    shf_tracer.monitoring = False
    shf_tracer.reset_ring_buffer()

    assert result == 25


if __name__ == "__main__":
    import sys

    print("Sheaf Trace and Guard Test Suite")
    print("=" * 60)
    print()

    tests = [
        ("test_console_trace", test_console_trace, "Console trace"),
        ("test_json_trace", test_json_trace, "JSON trace export"),
        (
            "test_guard_range_success",
            test_guard_range_success,
            "Guard :range (success)",
        ),
        (
            "test_guard_shape_success",
            test_guard_shape_success,
            "Guard :shape (success)",
        ),
        ("test_trace_modes", test_trace_modes, "Trace modes (fast/normal/verbose)"),
        (
            "test_silent_monitoring",
            test_silent_monitoring,
            "Silent monitoring (ring buffer)",
        ),
    ]

    results = []

    for test_name, test_func, description in tests:
        try:
            test_func()
            status = "PASS"
            error_msg = ""
            print(f"{description:40} {status}")
        except AssertionError as e:
            status = "FAIL"
            error_msg = str(e)
            print(f"{description:40} {status} - {error_msg}")
        except Exception as e:
            status = "ERROR"
            error_msg = f"{type(e).__name__}: {str(e)}"
            print(f"{description:40} {status} - {error_msg}")

        results.append((description, status, error_msg))

    print()
    print("=" * 60)
    pass_count = len([r for r in results if r[1] == "PASS"])
    fail_count = len([r for r in results if r[1] != "PASS"])
    print(f"Test Summary: {pass_count} PASS, {fail_count} FAIL")

    if fail_count > 0:
        print(f"\nFailures:")
        for desc, status, error in results:
            if status != "PASS":
                print(f"  {desc}: {error}")

    sys.exit(fail_count)
