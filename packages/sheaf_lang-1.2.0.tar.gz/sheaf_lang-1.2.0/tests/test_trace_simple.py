"""Test trace with simple nested expression"""

import sys

sys.path.insert(0, "/Users/damien/bin/AI/sheaf")

from sheaf import Sheaf

code = """
(defn math-test ()
  (+ (* 2 3) 4))
"""

s = Sheaf()
s.load(code)
result = s.math_test(trace="verbose")
print(f"\nResult: {result}")
