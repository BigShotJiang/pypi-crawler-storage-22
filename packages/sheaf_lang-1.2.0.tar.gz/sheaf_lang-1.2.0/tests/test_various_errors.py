"""
Test various types of Sheaf errors
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from sheaf import Sheaf


def test_errors():
    print("=" * 80)
    print("TESTING VARIOUS SHEAF ERRORS")
    print("=" * 80)

    shf = Sheaf()

    # Test 1: Wrong number of arguments
    print("\n\n### Test 1: Wrong number of arguments ###\n")
    with open("test_various_errors.shf", "r") as f:
        code = f.read()

    try:
        shf.load(code, filename="test_various_errors.shf")
    except Exception as e:
        print(str(e))

    # Test 2: Missing parenthesis
    print("\n\n### Test 2: Missing closing parenthesis ###\n")
    bad_code = """
(defn test (x)
  (+ x 1
"""
    try:
        shf.load(bad_code, filename="bad_syntax.shf")
    except Exception as e:
        print(str(e))

    # Test 3: Undefined function
    print("\n\n### Test 3: Calling undefined function ###\n")
    bad_code2 = """
(defn my-func ()
  (undefined-function 42))

(my-func)
"""
    try:
        shf.load(bad_code2, filename="undefined_func.shf")
    except Exception as e:
        print(str(e))


if __name__ == "__main__":
    test_errors()
