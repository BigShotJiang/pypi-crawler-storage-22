# Copyright (c) 2025 Damien Boureille
# Licensed under the MIT License.
# See LICENSE file in the project root for full license information.

"""
Tests for vmap special form.
"""

import jax.numpy as jnp

from sheaf import Sheaf


def test_vmap_basic():
    """Test basic vmap over axis 0."""
    shf = Sheaf()

    # Define function and create vmapped version in Sheaf
    result = shf.load(
        """
    (defn square [x]
      (* x x))

    (defn batched-square [X]
      ((vmap square) X))
    """
    )

    # Test with batch of inputs
    X = jnp.array([1.0, 2.0, 3.0, 4.0])
    result = shf.batched_square(X)

    expected = jnp.array([1.0, 4.0, 9.0, 16.0])
    assert jnp.allclose(result, expected)


def test_vmap_with_params():
    """Test vmap with multiple arguments (both batched)."""
    shf = Sheaf()
    shf.load(
        """
    (defn add-two [x y]
      (+ x y))

    (defn batched-add [X Y]
      ((vmap add-two) X Y))
    """
    )

    # Batch of x and y (both batched)
    X = jnp.array([1.0, 2.0, 3.0])
    Y = jnp.array([10.0, 20.0, 30.0])

    result = shf.batched_add(X, Y)
    expected = jnp.array([11.0, 22.0, 33.0])
    assert jnp.allclose(result, expected)


def test_vmap_matrix_multiply():
    """Test vmap with matrix operations (batch first arg only)."""
    shf = Sheaf()
    shf.load(
        """
    (defn linear [x w b]
      (+ (@ x w) b))

    (defn batched-linear [X w b]
      ((vmap linear [0 nil nil]) X w b))
    """
    )

    # Batch of inputs [batch, features]
    X = jnp.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])  # [3, 2]
    W = jnp.array([[0.5, 1.0], [1.5, 2.0]])  # [2, 2]
    b = jnp.array([0.1, 0.2])  # [2]

    result = shf.batched_linear(X, W, b)

    # Check shape
    assert result.shape == (3, 2)

    # Verify computation
    expected = jnp.array([X[i] @ W + b for i in range(3)])
    assert jnp.allclose(result, expected)


def test_vmap_with_lambda():
    """Test vmap with lambda functions."""
    shf = Sheaf()
    shf.load(
        """
    (defn apply-add-ten [X]
      ((vmap (lambda [x] (+ x 10))) X))
    """
    )

    X = jnp.array([1.0, 2.0, 3.0])
    result = shf.apply_add_ten(X)

    expected = jnp.array([11.0, 12.0, 13.0])
    assert jnp.allclose(result, expected)


def test_vmap_nested():
    """Test nested vmap for 2D batching."""
    shf = Sheaf()
    shf.load(
        """
    (defn add-one [x]
      (+ x 1))

    (defn double-batched [X]
      ((vmap (vmap add-one)) X))
    """
    )

    # 2D array
    X = jnp.array([[1.0, 2.0], [3.0, 4.0]])
    result = shf.double_batched(X)

    expected = jnp.array([[2.0, 3.0], [4.0, 5.0]])
    assert jnp.allclose(result, expected)


def test_vmap_composition():
    """Test that vmap composes with other transforms."""
    shf = Sheaf()
    shf.load(
        """
    (defn :jit compute [x]
      (* x x))

    (defn batched-compute [X]
      ((vmap compute) X))
    """
    )

    X = jnp.array([1.0, 2.0, 3.0, 4.0])
    result = shf.batched_compute(X)

    expected = jnp.array([1.0, 4.0, 9.0, 16.0])
    assert jnp.allclose(result, expected)


def test_vmap_with_dict_params():
    """Test vmap with dictionary parameters (batch first arg only)."""
    shf = Sheaf()
    shf.load(
        """
    (defn forward [x params]
      (+ (@ x (get params :w)) (get params :b)))

    (defn batched-forward [X params]
      ((vmap forward [0 nil]) X params))
    """
    )

    # Batch of inputs
    X = jnp.array([[1.0, 2.0], [3.0, 4.0]])  # [2, 2]
    params = {"w": jnp.array([[1.0], [2.0]]), "b": jnp.array([0.5])}  # [2, 1], [1]

    result = shf.batched_forward(X, params)

    # Check shape
    assert result.shape == (2, 1)

    # Verify
    expected = jnp.array([[5.5], [11.5]])  # [1*1 + 2*2 + 0.5], [3*1 + 4*2 + 0.5]
    assert jnp.allclose(result, expected)


def test_vmap_preserves_shape():
    """Test that vmap correctly handles tensor dimensions."""
    shf = Sheaf()
    shf.load(
        """
    (defn sum-elements [x]
      (sum x))

    (defn batched-sum [X]
      ((vmap sum-elements) X))
    """
    )

    # Batch of 2D tensors: [batch, rows, cols]
    # Each batch element is a 3x4 matrix
    X = jnp.ones([5, 3, 4])
    results = shf.batched_sum(X)

    # Each element should sum to 12 (3*4*1)
    assert results.shape == (5,)
    expected = jnp.array([12.0] * 5)
    assert jnp.allclose(results, expected)


if __name__ == "__main__":
    print("Running vmap tests...")
    test_vmap_basic()
    print("✓ Basic vmap works")

    test_vmap_with_params()
    print("✓ Vmap with parameters works")

    test_vmap_matrix_multiply()
    print("✓ Vmap with matrix operations works")

    test_vmap_with_lambda()
    print("✓ Vmap with lambda works")

    test_vmap_nested()
    print("✓ Nested vmap works")

    test_vmap_composition()
    print("✓ Vmap with JIT works")

    test_vmap_with_dict_params()
    print("✓ Vmap with dict params works")

    test_vmap_preserves_shape()
    print("✓ Vmap preserves shapes correctly")

    print("\n✅ All vmap tests passed!")
