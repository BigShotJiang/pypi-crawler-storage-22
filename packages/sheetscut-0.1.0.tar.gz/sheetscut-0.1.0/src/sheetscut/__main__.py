"""
Entry point for running sheetscut as a module: python -m sheetscut
"""

from .cli import main

if __name__ == '__main__':
    main()
