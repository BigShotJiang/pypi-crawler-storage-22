import unittest
class TestStdLib(unittest.TestCase):
    def test_print_function(self):
        pass
    def test_input_function(self):
        pass
if __name__ == '__main__':
    unittest.main()
