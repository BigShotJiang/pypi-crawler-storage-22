"""Adapter layer: converts MEDS format data to CORE-BEHRT input format."""
