"""Map MEDS code strings to integer concept tokens for CORE-BEHRT.

MEDS uses string codes like "ICD10CM/E11.9" or "LOINC/2345-7".
CORE-BEHRT expects integer concept tokens from a vocabulary.

This mapper builds a vocabulary from the data and provides the mapping.
"""

from __future__ import annotations

import json
from pathlib import Path

import polars as pl


class ConceptMapper:
    """Bidirectional mapping between MEDS code strings and BEHRT integer tokens."""

    # Reserved tokens matching CORE-BEHRT's tokenizer
    SPECIAL_TOKENS = {
        "[PAD]": 0,
        "[CLS]": 1,
        "[SEP]": 2,
        "[UNK]": 3,
        "[MASK]": 4,
    }

    def __init__(self) -> None:
        self.code_to_idx: dict[str, int] = dict(self.SPECIAL_TOKENS)
        self.idx_to_code: dict[int, str] = {v: k for k, v in self.SPECIAL_TOKENS.items()}
        self._next_idx = len(self.SPECIAL_TOKENS)
        self._frozen = False

    @property
    def vocab_size(self) -> int:
        return len(self.code_to_idx)

    def build_vocabulary(
        self,
        meds_dir: str | Path,
        min_frequency: int = 5,
    ) -> None:
        """Build vocabulary from MEDS parquet files, filtering rare codes.

        Args:
            meds_dir: Directory containing MEDS parquet shards.
            min_frequency: Minimum number of occurrences to include a code.
        """
        meds_dir = Path(meds_dir)
        parquet_files = sorted(meds_dir.rglob("*.parquet"))
        if not parquet_files:
            raise FileNotFoundError(f"No parquet files found in {meds_dir}")

        # Count code frequencies across all shards
        code_counts = (
            pl.scan_parquet(parquet_files)
            .filter(~pl.col("code").str.starts_with("MEDS_"))
            .group_by("code")
            .agg(pl.len().alias("count"))
            .filter(pl.col("count") >= min_frequency)
            .sort("count", descending=True)
            .collect()
        )

        for row in code_counts.iter_rows(named=True):
            code = row["code"]
            if code not in self.code_to_idx:
                self.code_to_idx[code] = self._next_idx
                self.idx_to_code[self._next_idx] = code
                self._next_idx += 1

    def freeze(self) -> None:
        """Freeze the vocabulary so no new codes can be added."""
        self._frozen = True

    def map(self, code: str) -> int:
        """Map a MEDS code string to an integer token.

        Returns [UNK] token for codes not in the vocabulary.
        """
        if code in self.code_to_idx:
            return self.code_to_idx[code]
        if self._frozen:
            return self.SPECIAL_TOKENS["[UNK]"]
        # Auto-add if not frozen
        self.code_to_idx[code] = self._next_idx
        self.idx_to_code[self._next_idx] = code
        self._next_idx += 1
        return self.code_to_idx[code]

    def reverse(self, idx: int) -> str:
        """Map an integer token back to a MEDS code string."""
        return self.idx_to_code.get(idx, "[UNK]")

    def save(self, path: str | Path) -> None:
        """Save vocabulary to a JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.code_to_idx, f, indent=2)

    @classmethod
    def load(cls, path: str | Path) -> ConceptMapper:
        """Load vocabulary from a JSON file."""
        mapper = cls()
        with open(path) as f:
            mapper.code_to_idx = json.load(f)
        mapper.idx_to_code = {v: k for k, v in mapper.code_to_idx.items()}
        mapper._next_idx = max(mapper.code_to_idx.values()) + 1
        mapper._frozen = True
        return mapper
