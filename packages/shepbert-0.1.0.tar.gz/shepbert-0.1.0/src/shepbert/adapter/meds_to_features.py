"""Convert MEDS-format parquet data to CORE-BEHRT feature dictionaries.

MEDS schema (per row):
    subject_id (int64), time (timestamp), code (str),
    numeric_value (float, optional), text_value (str, optional)

CORE-BEHRT expects dict-of-lists with keys:
    PID, concept, age, abspos, segment, background (GENDER, RACE, etc.)

This module bridges the two formats.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import polars as pl

from shepbert.adapter.concept_mapper import ConceptMapper


def load_meds_data(meds_dir: str | Path) -> pl.LazyFrame:
    """Load all MEDS parquet shards from a directory into a single LazyFrame."""
    meds_dir = Path(meds_dir)
    parquet_files = sorted(meds_dir.rglob("*.parquet"))
    if not parquet_files:
        raise FileNotFoundError(f"No parquet files found in {meds_dir}")
    return pl.scan_parquet(parquet_files)


def extract_demographics(df: pl.LazyFrame) -> dict[int, dict[str, str]]:
    """Extract background demographics from MEDS events.

    In MEDS, demographics are encoded as events with special codes:
        - MEDS_BIRTH: birth event (time = date of birth)
        - MEDS_DEATH: death event (time = date of death)
        - Gender: codes matching pattern *gender* or *sex* (source-dependent)
        - Race/Ethnicity: codes matching pattern *ethnicity* or *race*

    OMOP→MEDS encodes these as e.g.:
        - mimiciv_per_ethnicity/WHITE
        - Gender may come from person table or coded observations
    """
    # Demographic code prefixes to look for
    demo_filter = (
        pl.col("code").is_in(["MEDS_BIRTH", "MEDS_DEATH"])
        | pl.col("code").str.contains("(?i)ethnicity|race")
        | pl.col("code").str.contains("(?i)gender|sex")
    )

    demo_df = (
        df.filter(demo_filter)
        .select(["subject_id", "time", "code"])
        .collect()
    )

    demographics: dict[int, dict[str, str]] = {}
    for row in demo_df.iter_rows(named=True):
        sid = row["subject_id"]
        if sid not in demographics:
            demographics[sid] = {}
        code = row["code"]
        if code == "MEDS_BIRTH":
            demographics[sid]["DATE_OF_BIRTH"] = str(row["time"])
        elif code == "MEDS_DEATH":
            demographics[sid]["DATE_OF_DEATH"] = str(row["time"])
        elif "ethnicity" in code.lower() or "race" in code.lower():
            # Extract the value after the last slash: "mimiciv_per_ethnicity/WHITE" -> "WHITE"
            value = code.rsplit("/", 1)[-1] if "/" in code else code
            demographics[sid]["RACE"] = value
        elif "gender" in code.lower() or "sex" in code.lower():
            value = code.rsplit("/", 1)[-1] if "/" in code else code
            demographics[sid]["GENDER"] = value

    return demographics


def compute_age_at_event(
    event_time: datetime, birth_time: datetime | None
) -> float:
    """Compute age in years at the time of an event."""
    if birth_time is None:
        return 0.0
    delta = event_time - birth_time
    return round(delta.days / 365.25, 2)


def compute_abspos(event_time: datetime, reference_date: datetime) -> float:
    """Compute absolute position as days from a reference date."""
    delta = event_time - reference_date
    return round(delta.total_seconds() / 86400, 2)


def assign_segments(
    times: list[datetime], gap_hours: float = 24.0
) -> list[int]:
    """Assign visit/segment IDs based on time gaps between events.

    Events more than `gap_hours` apart are considered separate visits.
    """
    if not times:
        return []
    segments = [0]
    current_segment = 0
    for i in range(1, len(times)):
        delta_hours = (times[i] - times[i - 1]).total_seconds() / 3600
        if delta_hours > gap_hours:
            current_segment += 1
        segments.append(current_segment)
    return segments


def meds_to_behrt_features(
    meds_dir: str | Path,
    concept_mapper: ConceptMapper,
    reference_date: str = "2020-01-01",
    gap_hours: float = 24.0,
    min_events: int = 3,
) -> dict:
    """Convert MEDS data to CORE-BEHRT-compatible feature dictionaries.

    Returns a dict with keys matching CORE-BEHRT's expected format:
        {
            'concept': [[codes_patient1], [codes_patient2], ...],
            'age': [[ages_patient1], [ages_patient2], ...],
            'abspos': [[abspos_patient1], [abspos_patient2], ...],
            'segment': [[segs_patient1], [segs_patient2], ...],
            'PID': [pid1, pid2, ...],
            'background': {
                'GENDER': [g1, g2, ...],
                ...
            }
        }
    """
    ref_dt = datetime.fromisoformat(reference_date)

    # Load MEDS data
    df = load_meds_data(meds_dir)

    # Extract demographics first
    demographics = extract_demographics(df)

    # Filter out demographic-only codes, keep clinical events
    demographic_filter = (
        pl.col("code").str.starts_with("MEDS_")
        | pl.col("code").str.contains("(?i)ethnicity|race")
        | pl.col("code").str.contains("(?i)gender|sex")
    )
    clinical_df = (
        df.filter(~demographic_filter)
        .sort(["subject_id", "time"])
        .collect()
    )

    # Group by patient and build feature lists
    result: dict = {
        "concept": [],
        "age": [],
        "abspos": [],
        "segment": [],
        "PID": [],
        "background": {"GENDER": [], "RACE": []},
    }

    for (subject_id,), group in clinical_df.group_by(
        ["subject_id"], maintain_order=True
    ):
        events = group.to_dicts()
        if len(events) < min_events:
            continue

        demo = demographics.get(subject_id, {})
        birth_str = demo.get("DATE_OF_BIRTH")
        birth_dt = datetime.fromisoformat(birth_str) if birth_str else None

        times = [row["time"] for row in events]
        codes = [concept_mapper.map(row["code"]) for row in events]
        ages = [compute_age_at_event(t, birth_dt) for t in times]
        abspos = [compute_abspos(t, ref_dt) for t in times]
        segments = assign_segments(times, gap_hours)

        result["PID"].append(subject_id)
        result["concept"].append(codes)
        result["age"].append(ages)
        result["abspos"].append(abspos)
        result["segment"].append(segments)
        result["background"]["GENDER"].append(demo.get("GENDER", "unknown"))
        result["background"]["RACE"].append(demo.get("RACE", "unknown"))

    return result
