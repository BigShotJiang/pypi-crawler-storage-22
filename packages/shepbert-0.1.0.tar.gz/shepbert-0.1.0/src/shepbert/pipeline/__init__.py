"""Pipeline orchestration scripts for ETL, pre-training, and fine-tuning."""
