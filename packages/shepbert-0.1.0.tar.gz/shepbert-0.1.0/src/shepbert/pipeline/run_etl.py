"""Run OMOP → MEDS ETL conversion.

Wraps the `meds_etl_omop` CLI tool from the meds_etl package.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import hydra
from omegaconf import DictConfig


@hydra.main(version_base=None, config_path="../../../configs", config_name="pipeline")
def main(cfg: DictConfig) -> None:
    """Convert OMOP CDM exports to MEDS format."""
    source_dir = Path(cfg.omop.source_dir)
    output_dir = Path(cfg.meds_etl.output_dir)

    if not source_dir.exists():
        print(f"Error: OMOP source directory not found: {source_dir}")
        print("Expected CSV files: person.csv, condition_occurrence.csv, etc.")
        sys.exit(1)

    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable, "-m", "meds_etl.omop",
        str(source_dir),
        str(output_dir),
        "--num_shards", str(cfg.meds_etl.num_shards),
        "--num_proc", str(cfg.meds_etl.num_proc),
        "--backend", cfg.meds_etl.backend,
    ]

    print(f"Running OMOP → MEDS ETL:")
    print(f"  Source: {source_dir}")
    print(f"  Output: {output_dir}")
    print(f"  Shards: {cfg.meds_etl.num_shards}")

    result = subprocess.run(cmd, check=True)
    if result.returncode == 0:
        print(f"MEDS data written to {output_dir}")
    else:
        print("ETL failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
