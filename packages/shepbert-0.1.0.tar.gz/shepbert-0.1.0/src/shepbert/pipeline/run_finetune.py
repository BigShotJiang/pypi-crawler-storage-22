"""Fine-tune a pre-trained BEHRT model on downstream tasks.

Steps:
    1. Load pre-trained model checkpoint
    2. Load MEDS data and convert via adapter
    3. Prepare outcome labels
    4. Run cross-validated fine-tuning using CORE-BEHRT
"""

from __future__ import annotations

from pathlib import Path

import hydra
from omegaconf import DictConfig

from shepbert.adapter.concept_mapper import ConceptMapper
from shepbert.adapter.meds_to_features import meds_to_behrt_features


@hydra.main(version_base=None, config_path="../../../configs", config_name="finetune")
def main(cfg: DictConfig) -> None:
    """Run BEHRT fine-tuning with cross-validation."""
    meds_dir = Path(cfg.paths.meds_dir)
    output_dir = Path(cfg.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load pre-built vocabulary
    pretrain_dir = Path(cfg.model.pretrained_path).parent
    vocab_path = pretrain_dir / "vocab.json"
    if not vocab_path.exists():
        raise FileNotFoundError(
            f"Vocabulary not found at {vocab_path}. Run pre-training first."
        )
    mapper = ConceptMapper.load(vocab_path)
    print(f"Loaded vocabulary: {mapper.vocab_size} codes")

    # Convert MEDS → CORE-BEHRT features
    print("Converting MEDS data to BEHRT features...")
    features = meds_to_behrt_features(
        meds_dir=meds_dir,
        concept_mapper=mapper,
        reference_date=cfg.features.abspos.reference_date,
        gap_hours=24.0,
        min_events=cfg.excluder.min_len,
    )
    print(f"Patients: {len(features['PID'])}")

    # Fine-tune with CORE-BEHRT
    # TODO: Integrate with ehr2vec fine-tuning once data is available
    # from ehr2vec.trainer.trainer import EHRTrainer
    print(f"Fine-tuning with {cfg.evaluation.n_folds}-fold CV: pending real data")
    print(f"Metrics: {cfg.evaluation.metrics}")


if __name__ == "__main__":
    main()
