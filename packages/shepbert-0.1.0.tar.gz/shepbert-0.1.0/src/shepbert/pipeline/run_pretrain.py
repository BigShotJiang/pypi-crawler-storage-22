"""Pre-train BEHRT model on MEDS data via the adapter layer.

Steps:
    1. Load MEDS parquet data
    2. Convert to CORE-BEHRT features using the adapter
    3. Tokenize with CORE-BEHRT's EHRTokenizer
    4. Run CORE-BEHRT pre-training
"""

from __future__ import annotations

from pathlib import Path

import hydra
from omegaconf import DictConfig

from shepbert.adapter.concept_mapper import ConceptMapper
from shepbert.adapter.meds_to_features import meds_to_behrt_features


@hydra.main(version_base=None, config_path="../../../configs", config_name="pretrain")
def main(cfg: DictConfig) -> None:
    """Run BEHRT pre-training on MEDS-converted data."""
    meds_dir = Path(cfg.paths.meds_dir)
    output_dir = Path(cfg.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Step 1: Build concept vocabulary from MEDS data
    print("Building concept vocabulary...")
    mapper = ConceptMapper()
    mapper.build_vocabulary(meds_dir, min_frequency=5)
    mapper.freeze()
    mapper.save(output_dir / "vocab.json")
    print(f"Vocabulary size: {mapper.vocab_size}")

    # Step 2: Convert MEDS → CORE-BEHRT features
    print("Converting MEDS data to BEHRT features...")
    features = meds_to_behrt_features(
        meds_dir=meds_dir,
        concept_mapper=mapper,
        reference_date=cfg.features.abspos.reference_date,
        gap_hours=24.0,
        min_events=cfg.excluder.min_len,
    )
    print(f"Patients: {len(features['PID'])}")

    # Step 3: Tokenize and pre-train using CORE-BEHRT
    # TODO: Integrate with ehr2vec tokenizer and trainer once data is available
    # from ehr2vec.data.tokenizer import EHRTokenizer
    # from ehr2vec.trainer.trainer import EHRTrainer
    print("Pre-training integration with CORE-BEHRT: pending real data")


if __name__ == "__main__":
    main()
