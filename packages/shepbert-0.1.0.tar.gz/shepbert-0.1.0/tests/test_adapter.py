"""Tests for the MEDS → CORE-BEHRT adapter layer."""

from datetime import datetime

from shepbert.adapter.concept_mapper import ConceptMapper
from shepbert.adapter.meds_to_features import (
    assign_segments,
    compute_abspos,
    compute_age_at_event,
)


def test_concept_mapper_special_tokens():
    mapper = ConceptMapper()
    assert mapper.vocab_size == 5
    assert mapper.map("[PAD]") == 0
    assert mapper.map("[CLS]") == 1
    assert mapper.map("[MASK]") == 4


def test_concept_mapper_new_codes():
    mapper = ConceptMapper()
    idx = mapper.map("ICD10CM/E11.9")
    assert idx == 5  # First non-special token
    assert mapper.map("ICD10CM/E11.9") == idx  # Same code, same idx
    assert mapper.map("LOINC/2345-7") == 6  # Next code


def test_concept_mapper_frozen():
    mapper = ConceptMapper()
    mapper.map("ICD10CM/E11.9")
    mapper.freeze()
    assert mapper.map("UNKNOWN_CODE") == 3  # [UNK]


def test_concept_mapper_reverse():
    mapper = ConceptMapper()
    idx = mapper.map("ICD10CM/E11.9")
    assert mapper.reverse(idx) == "ICD10CM/E11.9"
    assert mapper.reverse(9999) == "[UNK]"


def test_compute_age_at_event():
    birth = datetime(1980, 1, 1)
    event = datetime(2020, 1, 1)
    age = compute_age_at_event(event, birth)
    assert abs(age - 40.0) < 0.1


def test_compute_age_no_birth():
    assert compute_age_at_event(datetime(2020, 1, 1), None) == 0.0


def test_compute_abspos():
    ref = datetime(2020, 1, 1)
    event = datetime(2020, 1, 11)
    assert compute_abspos(event, ref) == 10.0


def test_assign_segments_single():
    times = [datetime(2020, 1, 1, 10, 0)]
    assert assign_segments(times) == [0]


def test_assign_segments_same_visit():
    times = [
        datetime(2020, 1, 1, 10, 0),
        datetime(2020, 1, 1, 12, 0),  # 2 hours later, same visit
        datetime(2020, 1, 1, 15, 0),  # 3 hours later, same visit
    ]
    assert assign_segments(times, gap_hours=24.0) == [0, 0, 0]


def test_assign_segments_new_visit():
    times = [
        datetime(2020, 1, 1, 10, 0),
        datetime(2020, 1, 3, 10, 0),  # 48 hours later, new visit
    ]
    assert assign_segments(times, gap_hours=24.0) == [0, 1]


def test_assign_segments_empty():
    assert assign_segments([]) == []
