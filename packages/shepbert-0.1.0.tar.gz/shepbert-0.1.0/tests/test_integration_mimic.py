"""Integration tests: OMOP → MEDS → CORE-BEHRT adapter pipeline.

These tests require MIMIC-IV demo data converted to MEDS format.
Run the OMOP→MEDS ETL first:
    meds_etl_omop data/raw/.../1_omop_data_csv data/meds --num_shards 4

Skip these tests if MEDS data is not available (CI-friendly).
"""

from pathlib import Path

import pytest

MEDS_DIR = Path("data/meds/data")
HAS_MEDS_DATA = MEDS_DIR.exists() and list(MEDS_DIR.glob("*.parquet"))

skip_no_data = pytest.mark.skipif(
    not HAS_MEDS_DATA,
    reason="MEDS data not available (run OMOP→MEDS ETL first)",
)


@skip_no_data
class TestConceptMapperOnMIMIC:
    def test_build_vocabulary(self):
        from shepbert.adapter.concept_mapper import ConceptMapper

        mapper = ConceptMapper()
        mapper.build_vocabulary(MEDS_DIR, min_frequency=5)

        # Should have special tokens + real medical codes
        assert mapper.vocab_size > 10, f"Expected >10 codes, got {mapper.vocab_size}"

        # Special tokens should still be in place
        assert mapper.map("[PAD]") == 0
        assert mapper.map("[CLS]") == 1

    def test_vocabulary_save_load(self, tmp_path):
        from shepbert.adapter.concept_mapper import ConceptMapper

        mapper = ConceptMapper()
        mapper.build_vocabulary(MEDS_DIR, min_frequency=5)
        original_size = mapper.vocab_size

        vocab_path = tmp_path / "vocab.json"
        mapper.save(vocab_path)

        loaded = ConceptMapper.load(vocab_path)
        assert loaded.vocab_size == original_size
        assert loaded._frozen is True

    def test_unknown_codes_after_freeze(self):
        from shepbert.adapter.concept_mapper import ConceptMapper

        mapper = ConceptMapper()
        mapper.build_vocabulary(MEDS_DIR, min_frequency=5)
        mapper.freeze()

        assert mapper.map("TOTALLY_FAKE_CODE_12345") == 3  # [UNK]


@skip_no_data
class TestMedsToFeaturesOnMIMIC:
    @pytest.fixture(scope="class")
    def features(self):
        """Build features once for all tests in this class."""
        from shepbert.adapter.concept_mapper import ConceptMapper
        from shepbert.adapter.meds_to_features import meds_to_behrt_features

        mapper = ConceptMapper()
        mapper.build_vocabulary(MEDS_DIR, min_frequency=5)
        mapper.freeze()

        return meds_to_behrt_features(
            meds_dir=MEDS_DIR,
            concept_mapper=mapper,
            reference_date="2020-01-01",
            gap_hours=24.0,
            min_events=3,
        )

    def test_all_expected_keys(self, features):
        expected_keys = {"concept", "age", "abspos", "segment", "PID", "background"}
        assert set(features.keys()) == expected_keys

    def test_patient_count(self, features):
        # MIMIC-IV demo has 100 patients
        n_patients = len(features["PID"])
        assert n_patients > 0, "No patients converted"
        assert n_patients <= 100, f"More patients than expected: {n_patients}"

    def test_feature_lengths_consistent(self, features):
        """All per-patient feature lists should have the same length."""
        n = len(features["PID"])
        assert len(features["concept"]) == n
        assert len(features["age"]) == n
        assert len(features["abspos"]) == n
        assert len(features["segment"]) == n
        assert len(features["background"]["GENDER"]) == n
        assert len(features["background"]["RACE"]) == n

    def test_per_patient_event_lengths(self, features):
        """For each patient, concept/age/abspos/segment lists must match."""
        for i in range(len(features["PID"])):
            n_events = len(features["concept"][i])
            assert n_events >= 3, f"Patient {i} has <3 events"
            assert len(features["age"][i]) == n_events
            assert len(features["abspos"][i]) == n_events
            assert len(features["segment"][i]) == n_events

    def test_concept_tokens_are_ints(self, features):
        for patient_concepts in features["concept"]:
            for token in patient_concepts:
                assert isinstance(token, int), f"Non-int token: {token}"

    def test_ages_are_non_negative(self, features):
        for patient_ages in features["age"]:
            for age in patient_ages:
                assert age >= 0, f"Negative age: {age}"

    def test_segments_are_monotonic(self, features):
        """Segment IDs should be non-decreasing for each patient."""
        for patient_segs in features["segment"]:
            for j in range(1, len(patient_segs)):
                assert patient_segs[j] >= patient_segs[j - 1], (
                    f"Non-monotonic segments: {patient_segs[j-1]} -> {patient_segs[j]}"
                )

    def test_race_is_populated(self, features):
        """At least some patients should have a known race/ethnicity."""
        races = features["background"]["RACE"]
        known = [r for r in races if r != "unknown"]
        assert len(known) > 0, "No patients have known race/ethnicity"

    def test_no_meds_special_codes_in_concepts(self, features):
        """MEDS_BIRTH, MEDS_DEATH should not appear as clinical concept tokens."""
        from shepbert.adapter.concept_mapper import ConceptMapper

        mapper = ConceptMapper()
        mapper.build_vocabulary(MEDS_DIR, min_frequency=5)

        # MEDS_ codes should not be in the vocabulary (filtered during build)
        for code in mapper.code_to_idx:
            if code.startswith("["):  # Skip special tokens
                continue
            assert not code.startswith("MEDS_"), f"MEDS_ code in vocab: {code}"
