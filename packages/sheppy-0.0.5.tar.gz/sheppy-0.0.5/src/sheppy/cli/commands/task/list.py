import asyncio
import json
import os
import sys
from datetime import datetime
from enum import Enum
from typing import Annotated

import typer
from rich.table import Table

from sheppy import Queue
from sheppy._config import config
from sheppy.queue import _create_backend_from_url

from ...utils import OutputFormat, console, humanize_datetime


class StatusFilter(str, Enum):
    all = "all"
    pending = "pending"
    scheduled = "scheduled"
    completed = "completed"
    failed = "failed"



def list_tasks(
    queue: Annotated[str, typer.Option("--queue", "-q", help="Queue name. Env: SHEPPY_QUEUE")] = config.queue_list[0],
    backend_url: Annotated[str | None, typer.Option("--backend-url", "-u", help="Backend URL. Env: SHEPPY_BACKEND_URL")] = config.backend_url,
    status_filter: Annotated[StatusFilter, typer.Option("--status", "-s", help="Filter by status")] = StatusFilter.all,
    # limit: Annotated[int, typer.Option("--limit", "-l", help="Maximum number of tasks to show")] = 100,
    format_output: Annotated[OutputFormat, typer.Option("--format", "-f", help="Output format")] = OutputFormat.table,
) -> None:
    """List all tasks."""

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    async def _list(backend_url: str | None) -> None:
        if backend_url is None:
            backend_url = "redis://127.0.0.1:6379"
        backend_instance = _create_backend_from_url(backend_url)
        q = Queue(backend_instance, queue)

        tasks = []

        all_backend_tasks = await q.get_all_tasks()

        #if status_filter in ["all", "completed", "failed"]:

        for task in all_backend_tasks:
            if task.status == 'completed':
                queue_status = "[green]completed[/green]"
            elif task.error:
                queue_status = "[red]failed[/red]"
            #elif str(task.id) in all_scheduled_task_ids:
            elif task.status == 'scheduled':
                queue_status = "[magenta]scheduled[/magenta]"
            else:
                queue_status = task.status

            tasks.append((task, queue_status))

        tasks.sort(key=lambda x: x[0].created_at or datetime.min, reverse=True)

        if format_output == OutputFormat.json:

            tasks_for_json = []
            for task, queue_status in tasks:
                task_dict = task.model_dump(mode='json')
                task_dict["queue_status"] = queue_status
                tasks_for_json.append(task_dict)

            output = {
                "queue": queue,
                "count": len(tasks),
                "tasks": tasks_for_json
            }
            console.print(json.dumps(output, indent=2, default=str))
        else:
            if not tasks:
                console.print(f"[yellow]No tasks found in queue '{queue}' with status '{status_filter.value}'[/yellow]")
                return

            table = Table(title=f"Tasks in [bold cyan]{queue}[/bold cyan] (showing {len(tasks)} of {len(tasks)})")
            table.add_column("Task ID", style="dim")
            table.add_column("Function", style="blue")
            table.add_column("Status", style="yellow")
            table.add_column("Created (UTC)", style="blue")
            table.add_column("Finished (UTC)", style="blue")
            table.add_column("Scheduled (UTC)", style="blue")

            for (task, queue_status) in tasks:  # enumerate(tasks[:limit], 1):


                table.add_row(
                    str(task.id),
                    task.spec.func,
                    queue_status,
                    humanize_datetime(task.created_at),
                    humanize_datetime(task.finished_at),
                    humanize_datetime(task.scheduled_at if not task.finished_at else None),
                )

            console.print(table)

    asyncio.run(_list(backend_url))
