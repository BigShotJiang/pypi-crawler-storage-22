from .core import PasswordManager

__version__ = "1.0.2"
__author__ = "angyedz"