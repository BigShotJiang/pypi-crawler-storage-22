from importlib.metadata import PackageNotFoundError, version

from switch_sdk.auto_model import AutoModelSelection
from switch_sdk.byok import AzureBYOKConfig, AzureBYOKResolvedRequest, AzureRegionCredential
from switch_sdk.client import SwitchClient
from switch_sdk.context import switch_trace, trace_execution
from switch_sdk.errors import (
    SwitchAPIError,
    SwitchClientNotStartedError,
    SwitchLocalModelError,
    SwitchNetworkError,
    SwitchSDKError,
    SwitchTimeoutError,
)
from switch_sdk.executorch_runtime import (
    ExecuTorchRuntimeConfig,
    ExecuTorchTextRuntime,
    build_executorch_text_runtime,
)
from switch_sdk.impact import ImpactEstimate, ModelImpactEstimator
from switch_sdk.local_models import HardwareProfile, LocalModelHandle, LocalModelManager, LocalModelSpec
from switch_sdk.local_runtime import LocalChatRuntime, default_stub_local_runtime
from switch_sdk.models import (
    CarbonLiveResponse,
    CandidateScoreBreakdown,
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletion,
    ChatMessage,
    ChatRequest,
    ChatUsage,
    DashboardFeedItem,
    DashboardFeedResponse,
    ModelGardenResponse,
    ModelGardenTarget,
    DashboardSummary,
    DashboardSummaryResponse,
    RouteDecision,
    RouteRequest,
    RouteTarget,
    RoutingWeights,
    TelemetryEvent,
    TelemetryIngestResult,
)

try:
    __version__ = version('shift-sdk')
except PackageNotFoundError:
    try:
        __version__ = version('switch-sdk')
    except PackageNotFoundError:
        __version__ = '0.0.0'

__all__ = [
    '__version__',
    'AutoModelSelection',
    'AzureBYOKConfig',
    'AzureBYOKResolvedRequest',
    'AzureRegionCredential',
    'CarbonLiveResponse',
    'CandidateScoreBreakdown',
    'ChatChoice',
    'ChatChoiceMessage',
    'ChatCompletion',
    'ChatMessage',
    'ChatRequest',
    'ChatUsage',
    'DashboardFeedItem',
    'DashboardFeedResponse',
    'ModelGardenResponse',
    'ModelGardenTarget',
    'DashboardSummary',
    'DashboardSummaryResponse',
    'RouteDecision',
    'RouteRequest',
    'RouteTarget',
    'RoutingWeights',
    'SwitchAPIError',
    'SwitchClient',
    'SwitchClientNotStartedError',
    'SwitchLocalModelError',
    'SwitchNetworkError',
    'SwitchSDKError',
    'SwitchTimeoutError',
    'TelemetryEvent',
    'TelemetryIngestResult',
    'ExecuTorchRuntimeConfig',
    'ExecuTorchTextRuntime',
    'build_executorch_text_runtime',
    'ImpactEstimate',
    'ModelImpactEstimator',
    'HardwareProfile',
    'LocalModelSpec',
    'LocalModelHandle',
    'LocalModelManager',
    'LocalChatRuntime',
    'default_stub_local_runtime',
    'switch_trace',
    'trace_execution',
]
