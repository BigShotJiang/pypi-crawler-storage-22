from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from switch_sdk.models import ChatMessage

_URL_RE = re.compile(r'https?://\S+', re.IGNORECASE)
_CODE_HINT_RE = re.compile(
    r'```|`[^`]+`|\b(def |class |function|import |select |insert |update |delete |create table|docker|kubernetes|terraform)\b',
    re.IGNORECASE,
)
_SIMPLE_MATH_RE = re.compile(r'^[\d\s\+\-\*/\(\)\.=]+$')

_AUTO_MODEL_ALIASES = {'auto', 'shift-auto', 'router'}

_SIMPLE_PREFIXES = (
    'reply with exactly',
    'reply only with',
    'classify',
    'label this',
    'sentiment',
    'is this',
    'extract',
    'fix grammar',
    'correct grammar',
    'rewrite this sentence',
    'translate to',
)

_COMPLEX_HINTS = (
    'step by step',
    'detailed',
    'in depth',
    'architecture',
    'design a',
    'implement',
    'debug',
    'traceback',
    'root cause',
    'compare and contrast',
    'pros and cons',
    'research',
    'latest',
    'news',
    'financial advice',
    'medical advice',
    'legal advice',
    'long form',
    'write a blog',
    'essay',
)


@dataclass(slots=True)
class AutoModelSelection:
    selected_model: str
    reason: str
    confidence: float
    inspected_text: str
    features: dict[str, Any]

    def to_metadata(self) -> dict[str, Any]:
        return {
            'selected_model': self.selected_model,
            'reason': self.reason,
            'confidence': self.confidence,
            'features': self.features,
            'inspected_text': self.inspected_text[:160],
        }

    def to_safe_metadata(self) -> dict[str, Any]:
        payload = self.to_metadata()
        payload.pop('inspected_text', None)
        return payload


def is_auto_model_requested(model: str, capability_flags: dict[str, Any] | None = None) -> bool:
    flags = capability_flags or {}
    normalized = str(model or '').strip().lower()
    return normalized in _AUTO_MODEL_ALIASES or bool(flags.get('auto_model'))


def select_model(
    messages: list[ChatMessage],
    capability_flags: dict[str, Any] | None = None,
    *,
    frontier_model: str = 'gpt-5',
    mid_model: str = 'gpt-5-mini',
    small_model: str = 'gpt-5-nano',
    fast_model: str = 'gpt-5-nano',
) -> AutoModelSelection:
    flags = capability_flags or {}

    preferred = str(flags.get('preferred_model', '')).strip()
    if preferred:
        return AutoModelSelection(
            selected_model=preferred,
            reason='preferred_model capability flag',
            confidence=1.0,
            inspected_text='',
            features={'preferred_model': preferred},
        )

    optimize_for = str(flags.get('optimize_for', '')).strip().lower()
    text = _extract_primary_text(messages).strip()
    normalized = text.lower()
    words = len(normalized.split())
    chars = len(text)
    has_url = bool(_URL_RE.search(text))
    has_code = bool(_CODE_HINT_RE.search(text))
    has_complex_hint = any(hint in normalized for hint in _COMPLEX_HINTS)
    is_simple_math = bool(_SIMPLE_MATH_RE.match(normalized))
    simple_greeting = normalized in {'hi', 'hello', 'hey', 'thanks', 'thank you'}
    simple_prefix = normalized.startswith(_SIMPLE_PREFIXES)

    features = {
        'optimize_for': optimize_for,
        'word_count': words,
        'char_count': chars,
        'contains_url': has_url,
        'contains_code_hint': has_code,
        'contains_complex_hint': has_complex_hint,
    }

    if flags.get('vision') or flags.get('tool_use'):
        return AutoModelSelection(
            selected_model=frontier_model,
            reason='advanced capabilities requested',
            confidence=0.95,
            inspected_text=text,
            features=features,
        )

    if optimize_for == 'latency':
        return AutoModelSelection(
            selected_model=fast_model,
            reason='latency optimization requested',
            confidence=0.85,
            inspected_text=text,
            features=features,
        )

    if optimize_for == 'cost':
        return AutoModelSelection(
            selected_model=small_model,
            reason='cost optimization requested',
            confidence=0.85,
            inspected_text=text,
            features=features,
        )

    if has_code or has_url or has_complex_hint or words > 90 or chars > 500:
        return AutoModelSelection(
            selected_model=frontier_model,
            reason='complex prompt characteristics',
            confidence=0.85,
            inspected_text=text,
            features=features,
        )

    if is_simple_math or simple_greeting or simple_prefix or (words <= 20 and chars <= 120):
        return AutoModelSelection(
            selected_model=small_model,
            reason='lightweight prompt characteristics',
            confidence=0.8,
            inspected_text=text,
            features=features,
        )

    return AutoModelSelection(
        selected_model=mid_model,
        reason='default balanced prompt profile',
        confidence=0.7,
        inspected_text=text,
        features=features,
    )


def _extract_primary_text(messages: list[ChatMessage]) -> str:
    for message in reversed(messages):
        if message.role == 'user':
            return message.content
    if messages:
        return messages[-1].content
    return ''
