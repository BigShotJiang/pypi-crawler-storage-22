from __future__ import annotations

import json
import tempfile
from pathlib import Path

import httpx
import pytest
import respx

from switch_sdk import (
    AzureBYOKConfig,
    AzureRegionCredential,
    ChatMessage,
    SwitchAPIError,
    SwitchClient,
    SwitchClientNotStartedError,
)
from switch_sdk.local_models import LocalModelManager


@pytest.mark.asyncio
@respx.mock
async def test_route_returns_typed_decision() -> None:
    route_mock = respx.post('http://localhost:8000/v1/route').mock(
        return_value=httpx.Response(
            200,
            json={
                'target': {
                    'name': 'azure_openai-eastus',
                    'provider': 'azure_openai',
                    'region': 'eastus',
                    'mode': 'green-cloud',
                    'estimated_latency_ms': 140,
                    'estimated_cost_usd': 0.01,
                    'carbon_intensity_gco2_kwh': 288,
                },
                'routing_reason': 'picked eastus',
                'carbon_intensity': {'eastus': 288, 'westus': 435},
                'scores': {'azure_openai-eastus': 0.0, 'azure_openai-westus': 0.9},
                'weights': {'carbon': 0.8, 'latency': 0.1, 'cost': 0.1},
                'candidate_breakdown': {
                    'azure_openai-eastus': {
                        'carbon_intensity_gco2_kwh': 288,
                        'latency_ms': 140,
                        'cost_usd': 0.01,
                        'normalized_carbon': 0,
                        'normalized_latency': 0,
                        'normalized_cost': 0,
                        'weighted_score': 0,
                    }
                },
            },
        )
    )

    async with SwitchClient(base_url='http://localhost:8000', api_key='aura_test') as client:
        decision = await client.route(model='gpt-5', residency='US', capability_flags={'force_cloud': True})

    assert route_mock.called
    assert decision.target.region == 'eastus'
    assert decision.weights.carbon == 0.8
    assert 'azure_openai-eastus' in decision.candidate_breakdown


@pytest.mark.asyncio
@respx.mock
async def test_get_model_garden_returns_typed_targets() -> None:
    model_garden_mock = respx.get('http://localhost:8000/dashboard/model-garden').mock(
        return_value=httpx.Response(
            200,
            json={
                'targets': [
                    {
                        'id': 'target-1',
                        'provider': 'azure_openai',
                        'region': 'eastus',
                        'model': 'gpt-5-nano',
                        'tier': 'small',
                        'endpoint_url': 'https://shift-eastus.openai.azure.com',
                        'capability_flags': {'streaming': True},
                        'cost_per_1k': 0.0008,
                        'latency_p50_ms': 90.0,
                        'is_enabled': True,
                        'created_at': '2026-02-17T12:00:00Z',
                    }
                ]
            },
        )
    )

    async with SwitchClient(base_url='http://localhost:8000', api_key='shift_test_key') as client:
        response = await client.get_model_garden()

    assert model_garden_mock.called
    assert len(response.targets) == 1
    assert response.targets[0].id == 'target-1'
    assert response.targets[0].model == 'gpt-5-nano'
    assert response.targets[0].is_enabled is True


@pytest.mark.asyncio
@respx.mock
async def test_set_model_garden_target_enabled_sends_patch() -> None:
    toggle_mock = respx.patch('http://localhost:8000/dashboard/model-garden/targets/target-1').mock(
        return_value=httpx.Response(
            200,
            json={
                'id': 'target-1',
                'provider': 'azure_openai',
                'region': 'westus',
                'model': 'gpt-5',
                'tier': 'frontier',
                'endpoint_url': 'https://shift-westus.openai.azure.com',
                'capability_flags': {'streaming': True},
                'cost_per_1k': 0.01,
                'latency_p50_ms': 145.0,
                'is_enabled': False,
                'created_at': '2026-02-17T12:00:00Z',
            },
        )
    )

    async with SwitchClient(base_url='http://localhost:8000', api_key='shift_test_key') as client:
        updated = await client.set_model_garden_target_enabled(
            target_id='target-1',
            is_enabled=False,
        )

    assert toggle_mock.called
    request_body = json.loads(toggle_mock.calls[0].request.content.decode('utf-8'))
    assert request_body == {'is_enabled': False}
    assert updated.id == 'target-1'
    assert updated.is_enabled is False


@pytest.mark.asyncio
@respx.mock
async def test_chat_tracks_telemetry_event() -> None:
    respx.post('http://localhost:8000/v1/chat').mock(
        return_value=httpx.Response(
            200,
            json={
                'id': 'chatcmpl-test',
                'object': 'chat.completion',
                'created': 1700000000,
                'model': 'gpt-5',
                'choices': [
                    {
                        'index': 0,
                        'message': {'role': 'assistant', 'content': 'EASTUS_OK'},
                        'finish_reason': 'stop',
                    }
                ],
                'usage': {'prompt_tokens': 5, 'completion_tokens': 2, 'total_tokens': 7},
                'switch_meta': {
                    'route': {
                        'target': {'name': 'azure_openai-eastus', 'region': 'eastus'}
                    }
                },
            },
        )
    )
    events_mock = respx.post('http://localhost:8000/v1/events').mock(
        return_value=httpx.Response(200, json={'accepted': 1})
    )

    async with SwitchClient(base_url='http://localhost:8000', api_key='aura_test') as client:
        result = await client.chat(
            model='gpt-5',
            messages=[ChatMessage(role='user', content='Reply with EASTUS_OK')],
            residency='US',
            capability_flags={'force_cloud': True, 'preferred_region': 'eastus'},
        )

    assert result.choices[0].message.content == 'EASTUS_OK'
    assert events_mock.called

    request_body = json.loads(events_mock.calls[0].request.content.decode('utf-8'))
    assert request_body['events'][0]['event_type'] == 'sdk_chat_call'
    assert request_body['events'][0]['execution_target'] == 'azure_openai-eastus'


@pytest.mark.asyncio
@respx.mock
async def test_retries_on_retryable_status() -> None:
    route_mock = respx.post('http://localhost:8000/v1/route').mock(
        side_effect=[
            httpx.Response(503, json={'detail': 'temporarily unavailable'}),
            httpx.Response(
                200,
                json={
                    'target': {
                        'name': 'azure_openai-westus',
                        'provider': 'azure_openai',
                        'region': 'westus',
                        'mode': 'green-cloud',
                        'estimated_latency_ms': 150,
                        'estimated_cost_usd': 0.01,
                        'carbon_intensity_gco2_kwh': 435,
                    },
                    'routing_reason': 'picked westus',
                    'carbon_intensity': {'westus': 435},
                    'scores': {'azure_openai-westus': 0.0},
                    'weights': {'carbon': 0.8, 'latency': 0.1, 'cost': 0.1},
                    'candidate_breakdown': {
                        'azure_openai-westus': {
                            'carbon_intensity_gco2_kwh': 435,
                            'latency_ms': 150,
                            'cost_usd': 0.01,
                            'normalized_carbon': 0,
                            'normalized_latency': 0,
                            'normalized_cost': 0,
                            'weighted_score': 0,
                        }
                    },
                },
            ),
        ]
    )

    async with SwitchClient(
        base_url='http://localhost:8000',
        api_key='aura_test',
        max_retries=1,
        retry_backoff_seconds=0,
    ) as client:
        result = await client.route(model='gpt-5', residency='US')

    assert route_mock.call_count == 2
    assert result.target.region == 'westus'


@pytest.mark.asyncio
@respx.mock
async def test_raises_api_error_for_unauthorized() -> None:
    respx.post('http://localhost:8000/v1/route').mock(
        return_value=httpx.Response(401, json={'detail': 'Invalid API key'})
    )

    async with SwitchClient(base_url='http://localhost:8000', api_key='bad_key', telemetry_enabled=False) as client:
        with pytest.raises(SwitchAPIError) as exc:
            await client.route(model='gpt-5')

    assert exc.value.status_code == 401
    assert 'Invalid API key' in exc.value.detail


@pytest.mark.asyncio
async def test_requires_start_or_context() -> None:
    client = SwitchClient(base_url='http://localhost:8000', api_key='aura_test')

    with pytest.raises(SwitchClientNotStartedError):
        await client.route(model='gpt-5')


@pytest.mark.asyncio
async def test_chat_hybrid_local_success_without_cloud_call() -> None:
    temp_dir = tempfile.TemporaryDirectory()
    cache_dir = Path(temp_dir.name)
    model_path = cache_dir / 'tiny-chat' / 'v1' / 'model.pte'
    model_path.parent.mkdir(parents=True, exist_ok=True)
    model_path.write_bytes(b'local-model')

    manager = LocalModelManager(
        cache_dir=cache_dir,
        manifest=[
            {
                'model_id': 'tiny-chat',
                'task': 'chat',
                'download_url': '',
                'size_mb': 1,
                'min_ram_gb': 1,
                'max_prompt_chars': 300,
                'rank': 1,
            }
        ],
    )
    spec = manager.manifest[0]
    # Force cached path expected by manager.
    expected_path = cache_dir / spec.model_id / 'unversioned' / 'model.pte'
    expected_path.parent.mkdir(parents=True, exist_ok=True)
    expected_path.write_bytes(b'local-model')

    async with SwitchClient(
        base_url='http://localhost:8000',
        api_key='aura_test',
        telemetry_enabled=False,
        local_model_manager=manager,
    ) as client:
        completion = await client.chat_hybrid(
            model='auto',
            messages=[ChatMessage(role='user', content='Reply exactly: LOCAL_OK')],
            capability_flags={'auto_model': True},
        )

    assert completion.choices[0].message.content == 'LOCAL_OK'
    assert completion.switch_meta['source'] == 'sdk-local'
    assert completion.switch_meta['route']['target']['provider'] == 'executorch'
    temp_dir.cleanup()


@pytest.mark.asyncio
@respx.mock
async def test_chat_hybrid_falls_back_to_cloud_when_local_unavailable() -> None:
    respx.post('http://localhost:8000/v1/chat').mock(
        return_value=httpx.Response(
            200,
            json={
                'id': 'chatcmpl-cloud',
                'object': 'chat.completion',
                'created': 1700000000,
                'model': 'gpt-5',
                'choices': [
                    {
                        'index': 0,
                        'message': {'role': 'assistant', 'content': 'CLOUD_OK'},
                        'finish_reason': 'stop',
                    }
                ],
                'usage': {'prompt_tokens': 5, 'completion_tokens': 2, 'total_tokens': 7},
                'switch_meta': {
                    'route': {
                        'target': {'name': 'azure_openai-westus', 'region': 'westus'}
                    }
                },
            },
        )
    )
    respx.post('http://localhost:8000/v1/events').mock(return_value=httpx.Response(200, json={'accepted': 1}))

    # No matching model for this task forces fallback.
    manager = LocalModelManager(cache_dir=Path(tempfile.mkdtemp()), manifest=[])

    async with SwitchClient(
        base_url='http://localhost:8000',
        api_key='aura_test',
        telemetry_enabled=True,
        local_model_manager=manager,
    ) as client:
        completion = await client.chat_hybrid(
            model='auto',
            messages=[ChatMessage(role='user', content='Build a detailed architecture.')],
            capability_flags={'auto_model': True},
        )

    assert completion.choices[0].message.content == 'CLOUD_OK'
    assert completion.switch_meta['local_fallback']['mode'] == 'cloud'


def test_from_env_uses_primary_env_vars(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv('SHIFT_BASE_URL', 'http://localhost:8000')
    monkeypatch.setenv('SHIFT_API_KEY', 'shift_test_key')

    client = SwitchClient.from_env(telemetry_enabled=False)

    assert client.base_url == 'http://localhost:8000'
    assert client.api_key == 'shift_test_key'


def test_from_env_uses_fallback_env_vars(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('SHIFT_BASE_URL', raising=False)
    monkeypatch.delenv('SHIFT_API_URL', raising=False)
    monkeypatch.delenv('SHIFT_API_KEY', raising=False)
    monkeypatch.setenv('SWITCH_BASE_URL', 'http://localhost:8000')
    monkeypatch.setenv('SWITCH_API_KEY', 'switch_test_key')

    client = SwitchClient.from_env(telemetry_enabled=False)

    assert client.base_url == 'http://localhost:8000'
    assert client.api_key == 'switch_test_key'


def test_from_env_uses_shift_api_url_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('SHIFT_BASE_URL', raising=False)
    monkeypatch.setenv('SHIFT_API_URL', 'https://shift-api.example.com')
    monkeypatch.setenv('SHIFT_API_KEY', 'shift_test_key')

    client = SwitchClient.from_env(telemetry_enabled=False)

    assert client.base_url == 'https://shift-api.example.com'
    assert client.api_key == 'shift_test_key'


def test_from_env_uses_default_base_url_when_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('SHIFT_BASE_URL', raising=False)
    monkeypatch.delenv('SHIFT_API_URL', raising=False)
    monkeypatch.delenv('SWITCH_BASE_URL', raising=False)
    monkeypatch.setenv('SHIFT_API_KEY', 'shift_test_key')

    client = SwitchClient.from_env(telemetry_enabled=False)

    assert client.base_url == SwitchClient.DEFAULT_BASE_URL
    assert client.api_key == 'shift_test_key'


def test_client_uses_default_base_url_when_not_provided(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('SHIFT_BASE_URL', raising=False)
    monkeypatch.delenv('SHIFT_API_URL', raising=False)
    monkeypatch.delenv('SWITCH_BASE_URL', raising=False)

    client = SwitchClient(api_key='shift_test_key', telemetry_enabled=False)
    assert client.base_url == SwitchClient.DEFAULT_BASE_URL


def test_from_env_raises_when_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv('SHIFT_BASE_URL', raising=False)
    monkeypatch.delenv('SHIFT_API_URL', raising=False)
    monkeypatch.delenv('SHIFT_API_KEY', raising=False)
    monkeypatch.delenv('SWITCH_BASE_URL', raising=False)
    monkeypatch.delenv('SWITCH_API_KEY', raising=False)
    monkeypatch.delenv('API_KEY', raising=False)

    with pytest.raises(ValueError) as exc:
        SwitchClient.from_env(telemetry_enabled=False)

    assert 'missing required environment values' in str(exc.value)


@pytest.mark.asyncio
@respx.mock
async def test_chat_byok_routes_without_sending_prompt_to_gateway() -> None:
    route_mock = respx.post('http://localhost:8000/v1/route').mock(
        return_value=httpx.Response(
            200,
            json={
                'target': {
                    'name': 'azure_openai-eastus',
                    'provider': 'azure_openai',
                    'region': 'eastus',
                    'mode': 'green-cloud',
                    'estimated_latency_ms': 90,
                    'estimated_cost_usd': 0.0008,
                    'carbon_intensity_gco2_kwh': 280,
                },
                'routing_reason': 'picked eastus',
                'carbon_intensity': {'eastus': 280, 'westus': 430},
                'scores': {'azure_openai-eastus': 0.0, 'azure_openai-westus': 0.8},
                'weights': {'carbon': 0.8, 'latency': 0.1, 'cost': 0.1},
                'candidate_breakdown': {
                    'azure_openai-eastus': {
                        'carbon_intensity_gco2_kwh': 280,
                        'latency_ms': 90,
                        'cost_usd': 0.0008,
                        'normalized_carbon': 0,
                        'normalized_latency': 0,
                        'normalized_cost': 0,
                        'weighted_score': 0,
                    }
                },
            },
        )
    )
    provider_mock = respx.post(
        'https://shift-eastus.openai.azure.com/openai/deployments/gpt-5-nano/chat/completions?api-version=2025-01-01-preview'
    ).mock(
        return_value=httpx.Response(
            200,
            json={
                'id': 'chatcmpl-byok',
                'created': 1700000000,
                'model': 'gpt-5-nano',
                'choices': [{'index': 0, 'message': {'role': 'assistant', 'content': 'PRIVATE_OK'}}],
                'usage': {'prompt_tokens': 4, 'completion_tokens': 2, 'total_tokens': 6},
            },
        )
    )
    events_mock = respx.post('http://localhost:8000/v1/events').mock(
        return_value=httpx.Response(200, json={'accepted': 1})
    )

    byok = AzureBYOKConfig(
        regions={
            'eastus': AzureRegionCredential(
                endpoint='https://shift-eastus.openai.azure.com',
                api_key='azure-byok-key',
            )
        },
        api_version='2025-01-01-preview',
    )

    async with SwitchClient(base_url='http://localhost:8000', api_key='shift_test_key', byok_azure=byok) as client:
        completion = await client.chat_byok(
            model='auto',
            messages=[ChatMessage(role='user', content='Reply exactly: PRIVATE_OK')],
            residency='US',
            capability_flags={'auto_model': True},
        )

    assert route_mock.called
    assert provider_mock.called
    assert events_mock.called
    assert completion.choices[0].message.content == 'PRIVATE_OK'
    assert completion.switch_meta.get('source') == 'sdk-byok'
    assert completion.switch_meta.get('resolved_model') == 'gpt-5-nano'

    route_body = json.loads(route_mock.calls[0].request.content.decode('utf-8'))
    assert route_body['model'] == 'gpt-5-nano'
    assert 'messages' not in route_body
    assert route_body['capability_flags']['force_cloud'] is True

    provider_headers = provider_mock.calls[0].request.headers
    assert provider_headers.get('api-key') == 'azure-byok-key'

    event_body = json.loads(events_mock.calls[0].request.content.decode('utf-8'))
    event = event_body['events'][0]
    assert event['event_type'] == 'sdk_byok_chat'
    assert event['execution_target'] == 'azure_openai-eastus'
    assert event['region'] == 'eastus'
    assert event['metadata']['privacy_mode'] == 'provider-direct'
    assert 'PRIVATE_OK' not in json.dumps(event['metadata'])


@pytest.mark.asyncio
async def test_chat_byok_requires_byok_config() -> None:
    async with SwitchClient(base_url='http://localhost:8000', api_key='shift_test_key', telemetry_enabled=False) as client:
        with pytest.raises(ValueError) as exc:
            await client.chat_byok(
                model='gpt-5',
                messages=[ChatMessage(role='user', content='hello')],
            )
    assert 'No Azure BYOK config configured' in str(exc.value)


def test_from_env_loads_byok_config(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv('SHIFT_BASE_URL', 'http://localhost:8000')
    monkeypatch.setenv('SHIFT_API_KEY', 'shift_test_key')
    monkeypatch.setenv('SHIFT_BYOK_AZURE_EASTUS_ENDPOINT', 'https://shift-eastus.openai.azure.com')
    monkeypatch.setenv('SHIFT_BYOK_AZURE_EASTUS_API_KEY', 'eastus-byok-key')
    monkeypatch.setenv('SHIFT_BYOK_AZURE_API_VERSION', '2025-01-01-preview')

    client = SwitchClient.from_env(load_byok_azure_from_env=True, telemetry_enabled=False)
    assert client.byok_azure is not None
    assert client.byok_azure.api_version == '2025-01-01-preview'
    assert 'eastus' in client.byok_azure.regions
