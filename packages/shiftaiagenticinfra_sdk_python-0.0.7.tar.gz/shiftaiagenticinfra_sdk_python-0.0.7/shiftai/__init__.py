"""
Shiftai Agentic Infra Python SDK

A Python client library for the Shiftai Agentic Infra REST API.
"""

from .client import ShiftaiagenticinfraClient

__version__ = "0.0.6"
__all__ = ["ShiftaiagenticinfraClient"]

