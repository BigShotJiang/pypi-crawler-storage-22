from setuptools import setup

if __name__ == "__main__":
    setup(
        name="shingram",
        version="0.2.0",
        packages=["shingram"],
        package_data={"shingram": ["py.typed"]},
    )
