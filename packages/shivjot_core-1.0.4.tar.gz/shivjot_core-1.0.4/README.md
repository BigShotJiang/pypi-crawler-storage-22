# 🚀 Shivjot-Core

**High-performance Python utilities for AI/ML workflows, computer vision, and data engineering.**

---

## 📢 A Note from the Author
Hi! I'm a Shivjot choudhary, and this is my professional utility library. I built **shivjot-core** to bridge the gap between raw data and actionable AI insights. This project is a continuous journey into high-performance computing and package distribution.

## 🛠️ Key Features
* **📊 AI Data Analysis:** Custom Pandas accessors for instant statistical deep-dives.
* **🖼️ Image Processing:** Frequency domain transformations (FFT) for advanced CV.
* **⚡ Optimized Performance:** Leveraging the power of NumPy and Pandas for speed.
* **📦 Lightweight:** Easy to install with minimal footprint.

## 📦 Installation
```bash
pip install shivjot-core