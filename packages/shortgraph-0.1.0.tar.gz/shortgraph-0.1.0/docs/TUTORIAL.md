# ShortGraph 极简教程：从零构建智能 Agent

> **目标用户**：Python 新手、希望快速落地 Agent 的开发者。
> **核心优势**：比 LangGraph 少写 70% 代码，内置可视化与记忆管理。

---

## 📚 目录
1. [为什么选择 ShortGraph？](#1-为什么选择-shortgraph)
2. [一分钟上手](#2-一分钟上手)
3. [核心概念详解](#3-核心概念详解)
4. [实战：构建一个天气助手](#4-实战构建一个天气助手)
5. [进阶功能](#5-进阶功能)
6. [ShortGraph vs LangGraph 对比](#6-shortgraph-vs-langgraph-对比)

---

## 1. 为什么选择 ShortGraph？

构建 Agent（智能体）通常很难。你需要管理：
- **Prompt**（提示词）
- **Memory**（上下文记忆）
- **Tools**（工具调用）
- **State**（状态流转）

主流框架（如 LangGraph）虽然强大，但需要定义复杂的图结构、状态类和条件边。
**ShortGraph** 的设计哲学是：**把复杂留给框架，把简单留给用户。**

---

## 2. 一分钟上手

### 安装
```bash
pip install -r requirements.txt
```

### Hello World (极简代码)
```python
from shortgraph.paradigms.smart_agent import SmartAgent
from shortgraph.core.llm_factory import LLMFactory

# 1. 创建模型 (支持 OpenAI, DeepSeek, Ollama 等)
llm = LLMFactory.create_openai(api_key="your-key")

# 2. 创建 Agent (自动可视化)
agent = SmartAgent(llm=llm, auto_visualize=True)

# 3. 对话
print(agent.run("你好，你是谁？"))
```
运行这段代码，你的浏览器会自动弹出一张 Agent 的架构图！

---

## 3. 核心概念详解

在使用 ShortGraph 时，你只需要关注两个概念：

### 🛠️ 工具 (Tools)
工具是 Agent 的“手”。在 ShortGraph 中，**任何 Python 函数都可以直接变成工具**。
只需加上 `@tool` 装饰器：

```python
from shortgraph.tools.base import tool

@tool
def calculate(expression: str) -> str:
    """计算数学表达式。输入示例: '1 + 1'"""
    return str(eval(expression))
```

### 🧠 智能体 (SmartAgent)
SmartAgent 是 Agent 的“大脑”。它内置了：
- **思考回路** (ReAct 范式)
- **记忆系统** (自动管理对话历史)
- **可视化引擎** (自动生成流程图)

---

## 4. 实战：构建一个天气助手

让我们把所有知识点串起来，做一个能查询天气的助手。

### 第一步：定义工具
```python
from shortgraph.tools.base import tool

@tool
def get_weather(city: str) -> str:
    """查询指定城市的天气"""
    # 这里模拟返回数据，实际可以调用 API
    return f"{city} 今日晴朗，气温 25℃"
```

### 第二步：组装 Agent
```python
import os
from shortgraph.core.llm_factory import LLMFactory
from shortgraph.paradigms.smart_agent import SmartAgent

# 自动处理 API Key，如果没有则使用模拟模式 (Mock)
api_key = os.getenv("OPENAI_API_KEY")
llm = LLMFactory.create_openai(api_key=api_key) if api_key else LLMFactory.create_mock()

agent = SmartAgent(
    llm=llm,
    tools=[get_weather], # 注册工具
    system_prompt="你是一个专业的气象员，回答要简洁。",
    auto_visualize=True  # 开启自动可视化
)
```

### 第三步：运行
```python
response = agent.run("帮我查一下北京的天气")
print(response)
```

---

## 5. 进阶功能

### 📊 自动可视化 (Auto-Visualize)
不需要写一行绘图代码。只要设置 `auto_visualize=True`，框架会自动生成 Mermaid 流程图并在浏览器中展示。

### 🏭 多模型支持 (LLMFactory)
一键切换不同的大模型，无需修改业务代码。
```python
# OpenAI
llm = LLMFactory.create_openai()

# DeepSeek
llm = LLMFactory.create_deepseek(api_key="sk-...")

# Ollama (本地)
llm = LLMFactory.create_ollama(model="llama3")
```

---

## 6. ShortGraph vs LangGraph 对比

| 特性 | LangGraph | ShortGraph |
| :--- | :--- | :--- |
| **代码量** | 高 (需定义 State, Node, Edge) | **极低** (仅需定义工具) |
| **工具定义** | 手动解析 JSON | **@tool 装饰器自动处理** |
| **可视化** | 需额外配置 | **开箱即用 (自动弹窗)** |
| **上手难度** | 专家级 | **入门级** |

---

> **总结**：如果你需要极致的控制力，选择 LangGraph；如果你需要**快速落地、代码简洁、自带可视化**，ShortGraph 是你的最佳选择。
