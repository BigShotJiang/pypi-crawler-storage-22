from shortgraph.graph.state import StateGraph
from shortgraph.channels.manager import AgentState

# 1. 定义节点函数
def step_1(state: AgentState):
    print("执行步骤 1")
    state.set_variable("count", 1)
    return state

def step_2(state: AgentState):
    val = state.get_variable("count")
    print(f"执行步骤 2, 当前计数: {val}")
    state.set_variable("count", val + 1)
    return state

# 2. 构建图
workflow = StateGraph()
workflow.add_node("node_1", step_1)
workflow.add_node("node_2", step_2)

# 3. 定义流向
workflow.set_entry_point("node_1")
workflow.add_edge("node_1", "node_2")
workflow.add_edge("node_2", "__end__")

# 4. 编译
app = workflow.compile()

# 5. 运行
if __name__ == "__main__":
    state = AgentState()
    app.invoke(state)
