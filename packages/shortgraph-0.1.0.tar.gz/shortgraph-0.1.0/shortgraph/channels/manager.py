from typing import Dict, Any, List, Optional, Callable, Type
from dataclasses import dataclass, field, asdict
import datetime
import operator
import copy

def default_reducer(current: Any, new: Any) -> Any:
    """Default: Overwrite."""
    return new

def append_reducer(current: list, new: list) -> list:
    """Append new items to current list."""
    if current is None:
        current = []
    if new is None:
        return current
    return current + new

@dataclass
class Channel:
    """
    Defines how a specific field in the state should be updated.
    """
    name: str
    reducer: Callable[[Any, Any], Any] = default_reducer
    default: Any = None

class AgentState:
    """
    Enhanced AgentState with reducer support.
    """
    def __init__(self, data: Optional[Dict[str, Any]] = None, channels: Optional[Dict[str, Channel]] = None):
        self._data = data or {}
        self._channels = channels or {}
        
        # Ensure default channels exist
        if "messages" not in self._channels:
            self._channels["messages"] = Channel("messages", reducer=append_reducer, default=[])
        if "history" not in self._channels:
            self._channels["history"] = Channel("history", reducer=append_reducer, default=[])
        
        # Initialize defaults
        for name, channel in self._channels.items():
            if name not in self._data:
                self._data[name] = channel.default

    def update(self, updates: Dict[str, Any]):
        """
        Apply updates using the defined reducers.
        """
        for key, value in updates.items():
            if key in self._channels:
                current_val = self._data.get(key, self._channels[key].default)
                self._data[key] = self._channels[key].reducer(current_val, value)
            else:
                # Default behavior for unknown keys: overwrite
                self._data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]
        
    def __setitem__(self, key: str, value: Any):
        self.update({key: value})

    def to_dict(self) -> Dict[str, Any]:
        return copy.deepcopy(self._data)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentState':
        return cls(data=data)

    # Helper methods for backward compatibility
    @property
    def messages(self) -> List[Dict[str, Any]]:
        return self.get("messages", [])

    @property
    def history(self) -> List[str]:
        return self.get("history", [])

    def add_message(self, role: str, content: str):
        msg = {"role": role, "content": content, "timestamp": datetime.datetime.now().isoformat()}
        self.update({"messages": [msg]}) # List for append_reducer

    def set_variable(self, key: str, value: Any):
        self.update({key: value})

    def get_variable(self, key: str, default: Any = None) -> Any:
        return self.get(key, default)
