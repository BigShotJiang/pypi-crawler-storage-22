from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
import json
import copy

@dataclass
class Snapshot:
    state: Dict[str, Any]
    next_node: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

class BaseCheckpoint(ABC):
    """
    Abstract base class for saving and loading graph state.
    """
    
    @abstractmethod
    def put(self, thread_id: str, checkpoint_id: str, snapshot: Dict[str, Any]) -> None:
        """Save a snapshot (state + execution metadata)."""
        pass

    @abstractmethod
    def get(self, thread_id: str, checkpoint_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Retrieve a snapshot. 
        """
        pass

    @abstractmethod
    def list_history(self, thread_id: str) -> Dict[str, Any]:
        """List all checkpoints for a thread."""
        pass

class MemoryCheckpoint(BaseCheckpoint):
    """
    In-memory implementation.
    """
    def __init__(self):
        # Structure: {thread_id: {checkpoint_id: snapshot_dict}}
        self.storage: Dict[str, Dict[str, Any]] = {}
        # Track order: {thread_id: [checkpoint_id_1, checkpoint_id_2]}
        self.order: Dict[str, list] = {}

    def put(self, thread_id: str, checkpoint_id: str, snapshot: Dict[str, Any]) -> None:
        if thread_id not in self.storage:
            self.storage[thread_id] = {}
            self.order[thread_id] = []
        
        self.storage[thread_id][checkpoint_id] = copy.deepcopy(snapshot)
        self.order[thread_id].append(checkpoint_id)

    def get(self, thread_id: str, checkpoint_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if thread_id not in self.storage:
            return None
        
        if checkpoint_id is None:
            # Get latest
            if not self.order[thread_id]:
                return None
            latest_id = self.order[thread_id][-1]
            return copy.deepcopy(self.storage[thread_id][latest_id])
        
        return copy.deepcopy(self.storage[thread_id].get(checkpoint_id))

    def list_history(self, thread_id: str) -> list:
        if thread_id not in self.order:
            return []
        return list(self.order[thread_id])

class FileCheckpoint(BaseCheckpoint):
    """
    Simple file-based checkpointing.
    """
    def __init__(self, filepath: str = "checkpoints.json"):
        self.filepath = filepath
        self._load()

    def _load(self):
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.storage = data.get("storage", {})
                self.order = data.get("order", {})
        except FileNotFoundError:
            self.storage = {}
            self.order = {}

    def _save(self):
        with open(self.filepath, 'w', encoding='utf-8') as f:
            json.dump({"storage": self.storage, "order": self.order}, f, indent=2, default=str)

    def put(self, thread_id: str, checkpoint_id: str, snapshot: Dict[str, Any]) -> None:
        if thread_id not in self.storage:
            self.storage[thread_id] = {}
            self.order[thread_id] = []
        
        self.storage[thread_id][checkpoint_id] = snapshot 
        self.order[thread_id].append(checkpoint_id)
        self._save()

    def get(self, thread_id: str, checkpoint_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if thread_id not in self.storage:
            return None
        
        if checkpoint_id is None:
            if not self.order[thread_id]:
                return None
            latest_id = self.order[thread_id][-1]
            return self.storage[thread_id][latest_id]
        
        return self.storage[thread_id].get(checkpoint_id)

    def list_history(self, thread_id: str) -> list:
        return self.order.get(thread_id, [])
