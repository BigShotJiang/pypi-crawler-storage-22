from typing import Dict, Any, List, Callable, Union, Optional
import time
from shortgraph.channels.manager import AgentState
from shortgraph.checkpoint.base import BaseCheckpoint
from shortgraph.pregel.main import Pregel

# Special constants
START = "__start__"
END = "__end__"

class StateGraph:
    """
    A lightweight graph engine for defining agent workflows.
    Structure definition only.
    """
    def __init__(self):
        self.nodes: Dict[str, Callable] = {}
        self.edges: Dict[str, str] = {}
        self.conditional_edges: Dict[str, Callable] = {}
        self.conditional_edge_metadata: Dict[str, Dict[str, str]] = {} # Store path_map for visualization
        self.entry_point: str = ""
        self.node_metadata: Dict[str, Dict[str, Any]] = {}

    def add_node(self, name: str, func: Union[Callable, 'Pregel'], retry: int = 0):
        """
        Add a node. Can be a function or another Pregel graph (SubGraph).
        :param retry: Number of times to retry if the node raises an exception.
        """
        self.nodes[name] = func
        self.node_metadata[name] = {"retry": retry}

    def add_edge(self, start_key: str, end_key: str):
        if start_key == END:
            raise ValueError("END node cannot have outgoing edges")
        self.edges[start_key] = end_key

    def add_conditional_edges(
        self,
        source_key: str,
        condition_func: Callable[[AgentState], str],
        path_map: Optional[Dict[str, str]] = None
    ):
        if source_key == END:
            raise ValueError("END node cannot have outgoing edges")
            
        def router(state: AgentState) -> str:
            result = condition_func(state)
            if path_map:
                return path_map.get(result, result)
            return result
            
        self.conditional_edges[source_key] = router
        if path_map:
            self.conditional_edge_metadata[source_key] = path_map

    def set_entry_point(self, key: str):
        self.entry_point = key

    def compile(
        self, 
        checkpointer: Optional[BaseCheckpoint] = None,
        interrupt_before: Optional[List[str]] = None,
        interrupt_after: Optional[List[str]] = None
    ) -> Pregel:
        if not self.entry_point:
            raise ValueError("Graph must have an entry point.")
        
        pregel_app = Pregel(
            self, 
            checkpointer, 
            interrupt_before=interrupt_before, 
            interrupt_after=interrupt_after
        )
        
        return pregel_app
