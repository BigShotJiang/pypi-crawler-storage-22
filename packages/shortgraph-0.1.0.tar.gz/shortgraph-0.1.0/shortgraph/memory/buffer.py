from typing import List, Dict, Any, Optional
from abc import ABC, abstractmethod

class BaseMemory(ABC):
    """
    Abstract base class for memory management.
    """
    @abstractmethod
    def load(self, state: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Load messages from state and prepare them for LLM (e.g., trimming)."""
        pass

    @abstractmethod
    def save(self, state: Dict[str, Any], new_messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Save new messages to state."""
        pass

class WindowBufferMemory(BaseMemory):
    """
    Keeps a sliding window of the most recent k messages.
    Preserves the System message if present.
    """
    def __init__(self, window_size: int = 10):
        self.window_size = window_size

    def load(self, state_messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Returns the most recent k messages.
        Always keeps the first message if it's a 'system' message.
        """
        if not state_messages:
            return []
            
        if len(state_messages) <= self.window_size:
            return state_messages
            
        # Check for system message
        result = []
        start_idx = 0
        if state_messages[0].get("role") == "system":
            result.append(state_messages[0])
            start_idx = 1
            
        # Calculate how many to take from the end
        remaining_slots = self.window_size - len(result)
        if remaining_slots > 0:
            # Take the last 'remaining_slots' messages
            recent = state_messages[-remaining_slots:]
            # Ensure we don't duplicate if overlap (though logic above handles it)
            result.extend(recent)
            
        return result

    def save(self, current_messages: List[Dict[str, Any]], new_messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        In ShortGraph, state updates are usually handled by Reducers (append).
        So this method might be used if we were manually managing state, 
        but usually we just return what needs to be added.
        """
        return new_messages
