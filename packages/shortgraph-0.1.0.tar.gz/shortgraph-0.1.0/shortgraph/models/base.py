from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Union

class BaseLLM(ABC):
    """
    Abstract base class for LLMs to ensure neutrality.
    """
    
    @abstractmethod
    def generate(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        """
        Generate text based on prompt.
        """
        pass

    @abstractmethod
    def chat(self, messages: List[Dict[str, str]], stop: Optional[List[str]] = None) -> str:
        """
        Chat completion interface.
        messages format: [{"role": "user", "content": "hello"}, ...]
        """
        pass

class MockLLM(BaseLLM):
    """
    A mock LLM for testing purposes.
    """
    def generate(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        return f"Mock response to: {prompt[:20]}..."

    def chat(self, messages: List[Dict[str, str]], stop: Optional[List[str]] = None) -> str:
        last_msg = messages[-1]['content']
        return f"Mock chat response to: {last_msg[:20]}..."
