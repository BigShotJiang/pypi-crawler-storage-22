from typing import Optional, Any
import os
from shortgraph.models.base import BaseLLM
from shortgraph.models.openai import OpenAILLM

class LLMFactory:
    """
    A simple factory to create LLM instances for various providers.
    """

    @staticmethod
    def create_openai(
        api_key: Optional[str] = None, 
        model: str = "gpt-3.5-turbo"
    ) -> BaseLLM:
        """Create a standard OpenAI LLM instance."""
        return OpenAILLM(api_key=api_key, model=model)

    @staticmethod
    def create_deepseek(
        api_key: Optional[str] = None, 
        model: str = "deepseek-chat"
    ) -> BaseLLM:
        """
        Create a DeepSeek LLM instance.
        Default Base URL: https://api.deepseek.com
        """
        return OpenAILLM(
            api_key=api_key or os.environ.get("DEEPSEEK_API_KEY"),
            base_url="https://api.deepseek.com",
            model=model
        )

    @staticmethod
    def create_moonshot(
        api_key: Optional[str] = None, 
        model: str = "moonshot-v1-8k"
    ) -> BaseLLM:
        """
        Create a Moonshot (Kimi) LLM instance.
        Default Base URL: https://api.moonshot.cn/v1
        """
        return OpenAILLM(
            api_key=api_key or os.environ.get("MOONSHOT_API_KEY"),
            base_url="https://api.moonshot.cn/v1",
            model=model
        )

    @staticmethod
    def create_zhipu(
        api_key: Optional[str] = None,
        model: str = "glm-4"
    ) -> BaseLLM:
        """
        Create a ZhipuAI (ChatGLM) LLM instance.
        Default Base URL: https://open.bigmodel.cn/api/paas/v4/
        """
        return OpenAILLM(
            api_key=api_key or os.environ.get("ZHIPU_API_KEY"),
            base_url="https://open.bigmodel.cn/api/paas/v4/",
            model=model
        )

    @staticmethod
    def create_ollama(
        base_url: str = "http://localhost:11434/v1",
        model: str = "llama3"
    ) -> BaseLLM:
        """
        Create a local Ollama LLM instance (via OpenAI compatibility).
        """
        return OpenAILLM(
            api_key="ollama", # API key is required but ignored by Ollama
            base_url=base_url,
            model=model
        )

    @staticmethod
    def create_custom(
        api_key: str,
        base_url: str,
        model: str
    ) -> BaseLLM:
        """Create a custom OpenAI-compatible LLM instance."""
        return OpenAILLM(api_key=api_key, base_url=base_url, model=model)

    @staticmethod
    def create_mock() -> BaseLLM:
        """Create a Mock LLM for testing/demo purposes."""
        class MockSmartLLM(BaseLLM):
            def generate(self, prompt: str, stop: Optional[list] = None) -> str:
                # Simple logic to simulate weather tool usage
                if "Observation:" in prompt:
                    return "Final Answer: 根据天气预报, 北京今天天气不错, 晴转多云, 适合出行!"
                return 'Thought: 用户想查询北京的天气, 我需要调用 get_weather 工具.\nAction: get_weather\nAction Input: "北京"'
            
            def chat(self, messages: list, stop: Optional[list] = None) -> str:
                # Fallback to generate for chat interface
                prompt = "\n".join([f"{m['role']}: {m['content']}" for m in messages])
                return self.generate(prompt)
        
        return MockSmartLLM()
