from typing import List, Dict, Optional, Any
import os
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

from shortgraph.models.base import BaseLLM

class OpenAILLM(BaseLLM):
    """
    Adapter for OpenAI's GPT models and OpenAI-compatible APIs (DeepSeek, Moonshot, etc.).
    """
    def __init__(
        self, 
        api_key: Optional[str] = None, 
        model: str = "gpt-3.5-turbo",
        base_url: Optional[str] = None
    ):
        if OpenAI is None:
            raise ImportError("Please install openai package: `pip install openai`")
        
        self.client = OpenAI(
            api_key=api_key or os.environ.get("OPENAI_API_KEY"),
            base_url=base_url or os.environ.get("OPENAI_BASE_URL")
        )
        self.model = model

    def generate(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                stop=stop
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"Error generating response: {str(e)}"

    def chat(self, messages: List[Dict[str, str]], stop: Optional[List[str]] = None) -> str:
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                stop=stop
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"Error chatting: {str(e)}"
