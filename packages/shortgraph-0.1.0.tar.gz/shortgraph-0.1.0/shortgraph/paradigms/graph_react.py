from typing import List, Optional, Dict, Any
from shortgraph.models.base import BaseLLM
from shortgraph.channels.manager import AgentState
from shortgraph.tools.base import Tool
from shortgraph.permissions.guard import PermissionGuard
from shortgraph.graph.state import StateGraph, END
import re

class GraphReActAgent:
    """
    ReAct Agent implemented using the ShortGraph Graph Engine.
    """
    def __init__(
        self, 
        llm: BaseLLM, 
        tools: List[Tool], 
        guard: Optional[PermissionGuard] = None
    ):
        self.llm = llm
        self.tools = {t.name: t for t in tools}
        self.guard = guard or PermissionGuard()
        self.graph = self._build_graph()

    def _build_graph(self) -> StateGraph:
        workflow = StateGraph()
        
        # Add nodes
        workflow.add_node("reason", self._reason_node)
        workflow.add_node("action", self._action_node)
        
        # Set entry point
        workflow.set_entry_point("reason")
        
        # Add conditional edges
        # From 'reason' node, decide whether to go to 'action' or 'end'
        workflow.add_conditional_edges(
            "reason",
            self._decide_next_step,
            {
                "continue": "action",
                "end": END
            }
        )
        
        # From 'action' node, always go back to 'reason'
        workflow.add_edge("action", "reason")
        
        return workflow.compile()

    def _reason_node(self, state: AgentState) -> AgentState:
        """
        Node 1: Reasoning. Call LLM to decide what to do.
        """
        # Construct prompt from state history
        user_input = state.get_variable("user_input")
        history_str = "\n".join(state.history)
        
        tool_desc = "\n".join([f"- {t.name}: {t.description}" for t in self.tools.values()])
        prompt = f"""You are a helpful assistant. Solve the following task:
Task: {user_input}

Available Tools:
{tool_desc}

Use the following format:
Thought: your reasoning about what to do next.
Action: the tool name to use (must be one of [{', '.join(self.tools.keys())}]).
Action Input: the input to the tool.
Observation: the result of the action.
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer.
Final Answer: the final answer to the original input question.

Current History:
{history_str}

Begin!
"""
        response = self.llm.generate(prompt, stop=["Observation:"])
        response = self.guard.mask_sensitive_info(response)
        
        # Update state
        state.add_message("assistant", response)
        state.history.append(response)
        
        # Parse output for next steps
        if "Final Answer:" in response:
             state.set_variable("final_answer", response.split("Final Answer:")[-1].strip())
             state.set_variable("next_action", "finish")
        elif "Action:" in response:
            action_match = re.search(r"Action:\s*(.*)", response)
            action_input_match = re.search(r"Action Input:\s*(.*)", response)
            
            if action_match and action_input_match:
                state.set_variable("tool_name", action_match.group(1).strip())
                state.set_variable("tool_input", action_input_match.group(1).strip())
                state.set_variable("next_action", "tool")
            else:
                # Malformed action, try to force end or retry (here we just end to avoid loop)
                state.set_variable("next_action", "finish")
                state.history.append("\nObservation: Could not parse Action/Action Input.")
        else:
             state.set_variable("next_action", "finish")

        return state

    def _action_node(self, state: AgentState) -> AgentState:
        """
        Node 2: Action. Execute the tool.
        """
        tool_name = state.get_variable("tool_name")
        tool_input = state.get_variable("tool_input")
        
        observation = ""
        if tool_name in self.tools:
            if self.guard.is_tool_allowed(tool_name):
                observation = self.tools[tool_name].run(tool_input)
            else:
                observation = f"Permission Denied: Tool '{tool_name}' is not allowed."
        else:
            observation = f"Error: Tool '{tool_name}' not found."
            
        observation = self.guard.mask_sensitive_info(observation)
        
        # Update state
        obs_text = f"\nObservation: {observation}\n"
        state.history.append(obs_text)
        # We don't necessarily add observation as a chat message unless we want to, 
        # but for ReAct prompt building, history is key.
        
        return state

    def _decide_next_step(self, state: AgentState) -> str:
        """
        Conditional Logic: Check state variable to decide route.
        """
        action = state.get_variable("next_action")
        if action == "tool":
            return "continue"
        return "end"

    def run(self, user_input: str) -> str:
        # Initialize state
        state = AgentState()
        state.set_variable("user_input", user_input)
        state.add_message("user", user_input)
        
        # Run graph
        final_state = self.graph.invoke(state)
        
        return final_state.get_variable("final_answer", "No answer found.")
