from typing import List, Dict, Any, Optional
from shortgraph.channels.manager import AgentState
from shortgraph.graph.state import StateGraph, END
from shortgraph.models.base import BaseLLM
from shortgraph.tools.base import Tool
import re

class PlanExecuteAgent:
    """
    Implements the Plan-and-Execute paradigm.
    1. Planner: Breaks down the user request into a list of steps.
    2. Executor: Executes steps one by one.
    3. Replanner: Updates the plan based on execution results.
    """
    def __init__(self, llm: BaseLLM, tools: List[Tool]):
        self.llm = llm
        self.tools = {t.name: t for t in tools}
        self.graph = self._build_graph()

    def _build_graph(self) -> StateGraph:
        workflow = StateGraph()
        
        # Nodes
        workflow.add_node("planner", self._plan_node)
        workflow.add_node("executor", self._execute_node)
        workflow.add_node("replanner", self._replan_node)
        
        # Edges
        workflow.set_entry_point("planner")
        workflow.add_edge("planner", "executor")
        workflow.add_edge("executor", "replanner")
        
        # Conditional edge from replanner
        workflow.add_conditional_edges(
            "replanner",
            self._should_continue,
            {
                "continue": "executor",
                "end": END
            }
        )
        
        return workflow.compile()

    def _plan_node(self, state: AgentState) -> Dict[str, Any]:
        """Generate initial plan."""
        user_input = state.get_variable("user_input")
        prompt = f"""
Task: {user_input}
Available Tools: {list(self.tools.keys())}

Please create a step-by-step plan to solve the task. 
Format your response as a numbered list.
Example:
1. Step one
2. Step two
"""
        response = self.llm.generate(prompt)
        plan = [line.strip() for line in response.split('\n') if line.strip() and (line[0].isdigit() or line.startswith('-'))]
        
        return {
            "plan": plan,
            "original_plan": plan,
            "past_steps": []
        }

    def _execute_node(self, state: AgentState) -> Dict[str, Any]:
        """Execute the first step of the plan."""
        plan = state.get_variable("plan", [])
        if not plan:
            return {"response": "No plan to execute."}

        current_step = plan[0]
        past_steps = state.get_variable("past_steps", [])
        
        # Simple execution logic: ask LLM which tool to use for this step
        tool_desc = "\n".join([f"- {t.name}: {t.description}" for t in self.tools.values()])
        prompt = f"""
Current Step: {current_step}
Context (Past Steps): {past_steps}
Available Tools:
{tool_desc}

Provide the tool call to execute this step. 
Format: Action: tool_name, Action Input: input
"""
        response = self.llm.generate(prompt)
        
        observation = "No action taken."
        action_match = re.search(r"Action:\s*(.*)", response)
        input_match = re.search(r"Action Input:\s*(.*)", response)
        
        if action_match and input_match:
            tool_name = action_match.group(1).strip()
            tool_input = input_match.group(1).strip()
            if tool_name in self.tools:
                try:
                    observation = self.tools[tool_name].run(tool_input)
                except Exception as e:
                    observation = str(e)
        
        return {
            "past_steps": [(current_step, observation)], # Append reducer will handle this if configured? No, we need to be careful.
            # Here we assume past_steps is replaced or we need a reducer. 
            # For simplicity in this example, let's assume we update the list manually or use a custom reducer.
            # In our current State, "past_steps" uses default overwrite. So we need to read and append manually or configure channel.
            # Let's use the return-dict update mechanism which merges.
             "current_observation": observation
        }

    def _replan_node(self, state: AgentState) -> Dict[str, Any]:
        """Update plan based on result."""
        plan = state.get_variable("plan", [])
        current_step = plan[0]
        observation = state.get_variable("current_observation")
        
        # Remove finished step
        new_plan = plan[1:]
        
        # Logic to check if done or need new steps could go here
        # For MVP, we just proceed to next step
        
        # Save history
        past = state.get_variable("past_steps", [])
        past.append((current_step, observation))
        
        if not new_plan:
             return {"plan": [], "past_steps": past, "is_done": True, "final_response": f"Task completed. Result: {observation}"}
        
        return {"plan": new_plan, "past_steps": past, "is_done": False}

    def _should_continue(self, state: AgentState) -> str:
        if state.get_variable("is_done"):
            return "end"
        return "continue"

    def run(self, user_input: str) -> str:
        state = AgentState(
            channels={
                "past_steps": Channel("past_steps", default=[]), # Overwrite is fine if we manage list manually
                "plan": Channel("plan", default=[])
            }
        )
        state.set_variable("user_input", user_input)
        final_state = self.graph.invoke(state)
        return final_state.get_variable("final_response", "Done.")
