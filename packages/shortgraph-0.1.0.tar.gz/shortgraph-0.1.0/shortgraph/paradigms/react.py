from typing import List, Optional
from shortgraph.models.base import BaseLLM
from shortgraph.channels.manager import AgentState
from shortgraph.tools.base import Tool
from shortgraph.permissions.guard import PermissionGuard
import re

class ReActAgent:
    """
    Standard ReAct (Reasoning and Acting) paradigm implementation.
    """
    def __init__(
        self, 
        llm: BaseLLM, 
        tools: List[Tool], 
        guard: Optional[PermissionGuard] = None,
        max_steps: int = 5
    ):
        self.llm = llm
        self.tools = {t.name: t for t in tools}
        self.guard = guard or PermissionGuard()
        self.max_steps = max_steps
        self.state = AgentState()

    def _generate_prompt(self, user_input: str, history: str) -> str:
        tool_desc = "\n".join([f"- {t.name}: {t.description}" for t in self.tools.values()])
        prompt = f"""You are a helpful assistant. Solve the following task:
Task: {user_input}

Available Tools:
{tool_desc}

Use the following format:
Thought: your reasoning about what to do next.
Action: the tool name to use (must be one of [{', '.join(self.tools.keys())}]).
Action Input: the input to the tool.
Observation: the result of the action.
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer.
Final Answer: the final answer to the original input question.

Begin!
History:
{history}
"""
        return prompt

    def run(self, user_input: str) -> str:
        self.state.add_message("user", user_input)
        history = ""
        
        for step in range(self.max_steps):
            prompt = self._generate_prompt(user_input, history)
            response = self.llm.generate(prompt, stop=["Observation:"])
            
            # Mask sensitive info in LLM output
            response = self.guard.mask_sensitive_info(response)
            history += response
            
            if "Final Answer:" in response:
                final_answer = response.split("Final Answer:")[-1].strip()
                self.state.add_message("assistant", final_answer)
                return final_answer
            
            # Parse action
            try:
                action_match = re.search(r"Action:\s*(.*)", response)
                action_input_match = re.search(r"Action Input:\s*(.*)", response)
                
                if action_match and action_input_match:
                    tool_name = action_match.group(1).strip()
                    tool_input = action_input_match.group(1).strip()
                    
                    if tool_name in self.tools:
                        if self.guard.is_tool_allowed(tool_name):
                            observation = self.tools[tool_name].run(tool_input)
                        else:
                            observation = f"Permission Denied: Tool '{tool_name}' is not allowed."
                    else:
                        observation = f"Error: Tool '{tool_name}' not found."
                    
                    observation = self.guard.mask_sensitive_info(observation)
                    history += f"\nObservation: {observation}\n"
                else:
                    # If no action found but not final answer, just return response or try again
                    history += "\nObservation: No action specified. Please provide an Action or Final Answer.\n"
            except Exception as e:
                history += f"\nObservation: Error parsing action: {str(e)}\n"
        
        return "Max steps reached without final answer."
