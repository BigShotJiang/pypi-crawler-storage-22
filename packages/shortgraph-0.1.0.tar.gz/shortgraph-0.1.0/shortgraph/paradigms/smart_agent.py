from typing import List, Dict, Any, Optional
from shortgraph.channels.manager import AgentState
from shortgraph.graph.state import StateGraph, END
from shortgraph.pregel.main import Pregel
from shortgraph.models.base import BaseLLM
from shortgraph.tools.base import Tool
from shortgraph.prebuilt.tool_node import ToolNode
from shortgraph.memory.buffer import WindowBufferMemory
import re
import json

class SmartAgent:
    """
    A 'Batteries-Included' Agent that integrates:
    1. Memory: Sliding window context management.
    2. Planning: Simple thought-process decomposition.
    3. Action: Robust tool execution.
    """
    def __init__(
        self, 
        llm: BaseLLM, 
        tools: List[Tool], 
        memory_window: int = 10,
        system_prompt: str = "You are a helpful AI assistant."
    ):
        self.llm = llm
        self.tools = tools
        self.memory = WindowBufferMemory(window_size=memory_window)
        self.system_prompt = system_prompt
        
        # Initialize ToolNode
        self.tool_node = ToolNode(tools)
        
        self.graph = self._build_graph()

    def _build_graph(self) -> Pregel:
        workflow = StateGraph()
        
        # Define Nodes
        workflow.add_node("think", self._think_node)
        workflow.add_node("act", self._act_node)
        
        # Define Edges
        workflow.set_entry_point("think")
        
        workflow.add_conditional_edges(
            "think",
            self._decide_next,
            {
                "act": "act",
                "end": END
            }
        )
        
        workflow.add_edge("act", "think")
        
        return workflow.compile()

    def _think_node(self, state: AgentState) -> AgentState:
        # 1. Manage Memory (Load Window)
        all_messages = state.get("messages", [])
        
        # If empty, add system prompt
        if not all_messages:
            state.add_message("system", self.system_prompt)
            all_messages = state.get("messages")
            
        context_messages = self.memory.load(all_messages)
        
        # 2. Construct Prompt for Planning/Reasoning
        # We convert messages to a string format for the LLM
        history_str = ""
        for msg in context_messages:
            history_str += f"{msg['role'].upper()}: {msg['content']}\n"
            
        tool_desc = "\n".join([f"- {t.name}: {t.description}" for t in self.tools])
        
        prompt = f"""
{history_str}

Available Tools:
{tool_desc}

You need to solve the user's request. 
Think step-by-step.
If you need to use a tool, output:
Thought: <your reasoning>
Action: <tool_name>
Action Input: <input_json_or_string>

If you have the final answer, output:
Final Answer: <your answer>
"""
        # 3. Call LLM
        response = self.llm.generate(prompt, stop=["Observation:"])
        
        # 4. Save to State
        state.add_message("assistant", response)
        state.set_variable("last_response", response)
        
        return state

    def _decide_next(self, state: AgentState) -> str:
        last_response = state.get_variable("last_response", "")
        
        if "Action:" in last_response:
            return "act"
        return "end"

    def _act_node(self, state: AgentState) -> AgentState:
        last_response = state.get_variable("last_response", "")
        
        # Parse Action
        action_match = re.search(r"Action:\s*(.*)", last_response)
        input_match = re.search(r"Action Input:\s*(.*)", last_response)
        
        if action_match and input_match:
            tool_name = action_match.group(1).strip()
            tool_input = input_match.group(1).strip()
            
            # Set variables for ToolNode
            state.set_variable("tool_name", tool_name)
            state.set_variable("tool_input", tool_input)
            
            # Execute ToolNode
            state = self.tool_node(state)
            
            # ToolNode adds "tool output" to variables, we need to add it to messages for history
            tool_output = state.get_variable("tool_output")
            state.add_message("user", f"Observation: {tool_output}")
            
        else:
            state.add_message("user", "Observation: Invalid Action Format.")
            
        return state

    def run(self, user_input: str, thread_id: str = "default"):
        state = AgentState()
        state.add_message("user", user_input)
        
        print(f"--- SmartAgent Thinking (Thread: {thread_id}) ---")
        final_state = self.graph.invoke(state, thread_id=thread_id)
        
        # Extract final answer
        messages = final_state.get("messages", [])
        if messages:
            last_msg = messages[-1]
            if "Final Answer:" in last_msg["content"]:
                return last_msg["content"].split("Final Answer:")[-1].strip()
            return last_msg["content"]
        return "No response."
