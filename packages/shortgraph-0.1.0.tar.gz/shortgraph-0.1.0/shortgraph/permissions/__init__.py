from .guard import PermissionGuard

__all__ = ["PermissionGuard"]
