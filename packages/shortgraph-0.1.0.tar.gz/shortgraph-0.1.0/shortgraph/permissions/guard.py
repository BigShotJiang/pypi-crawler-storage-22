from typing import List, Optional, Callable, Any
import re

class PermissionGuard:
    """
    Core module for permission and safety control.
    """
    def __init__(self, sensitive_keywords: Optional[List[str]] = None):
        self.sensitive_keywords = sensitive_keywords or []
        self.tool_permissions = {}

    def add_sensitive_keyword(self, keyword: str):
        if keyword not in self.sensitive_keywords:
            self.sensitive_keywords.append(keyword)

    def set_tool_permission(self, tool_name: str, allowed: bool):
        self.tool_permissions[tool_name] = allowed

    def is_tool_allowed(self, tool_name: str) -> bool:
        return self.tool_permissions.get(tool_name, True)

    def mask_sensitive_info(self, text: str) -> str:
        """
        Simple redaction of sensitive keywords.
        """
        masked_text = text
        for kw in self.sensitive_keywords:
            masked_text = re.sub(re.escape(kw), "***", masked_text, flags=re.IGNORECASE)
        return masked_text

    def validate_input(self, input_text: str) -> bool:
        """
        Validate input for basic safety.
        """
        # Basic check: could be expanded to use LLM for safety check
        return True
