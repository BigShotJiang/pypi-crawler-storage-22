from typing import List, Dict, Any, Union
from shortgraph.channels.manager import AgentState
from shortgraph.tools.base import Tool
import json

class ToolNode:
    """
    A generic node that executes tools based on state.
    It expects 'tool_name' and 'tool_input' to be present in the state.
    It writes 'tool_output' to the state.
    """
    def __init__(self, tools: List[Tool]):
        self.tools = {t.name: t for t in tools}

    def __call__(self, state: AgentState) -> AgentState:
        tool_name = state.get_variable("tool_name")
        tool_input = state.get_variable("tool_input")
        
        # Support for parallel tool calls could be added here
        # checking for 'tool_calls' list
        
        if not tool_name:
            # No tool requested
            return state
            
        if tool_name not in self.tools:
            result = f"Error: Tool '{tool_name}' not found. Available tools: {list(self.tools.keys())}"
        else:
            tool = self.tools[tool_name]
            print(f"    [ToolNode] Executing {tool_name} with input: {tool_input}")
            try:
                # Try to parse input as JSON if it looks like it
                # simplistic approach
                if isinstance(tool_input, str) and (tool_input.startswith("{") or tool_input.startswith("[")):
                     try:
                         args = json.loads(tool_input)
                         if isinstance(args, dict):
                             result = tool.run(**args)
                         elif isinstance(args, list):
                             result = tool.run(*args)
                         else:
                             result = tool.run(args)
                     except:
                         result = tool.run(tool_input)
                else:
                    result = tool.run(tool_input)
            except Exception as e:
                result = f"Error executing {tool_name}: {str(e)}"
                
        state.set_variable("tool_output", result)
        # Clear the request to avoid re-execution if looping
        state.set_variable("tool_name", None)
        state.set_variable("tool_input", None)
        
        # Append to history for LLM context
        state.add_message("tool", f"Tool Output: {result}")
        
        return state
