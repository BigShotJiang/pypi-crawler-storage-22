from typing import Any, Dict, Optional, Callable
from shortgraph.channels.manager import AgentState

def apply_writes(state: AgentState, writes: Any) -> AgentState:
    """
    Apply updates to the state.
    """
    if isinstance(writes, AgentState):
        return writes
    elif isinstance(writes, dict):
        state.update(writes)
        return state
    return state

def should_interrupt(node: str, interrupt_before: list, interrupt_after: list) -> bool:
    """
    Check if we should interrupt.
    """
    # This logic is usually handled inside the loop with specific checks
    pass 

def prepare_next_tasks(graph: Any, current_node: str, state: AgentState) -> str:
    """
    Determine the next node to execute.
    """
    # Special constants
    END = "__end__"
    
    if current_node in graph.conditional_edges:
        return graph.conditional_edges[current_node](state)
    elif current_node in graph.edges:
        return graph.edges[current_node]
    
    return END
