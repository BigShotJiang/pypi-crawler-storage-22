from typing import List, Optional, Dict, Any, TYPE_CHECKING
import time
from shortgraph.channels.manager import AgentState
from shortgraph.checkpoint.base import BaseCheckpoint
from shortgraph.pregel.algo import apply_writes, prepare_next_tasks

if TYPE_CHECKING:
    from shortgraph.graph.state import StateGraph

# Special constants
START = "__start__"
END = "__end__"

class PregelLoop:
    """
    Manages the execution loop of the graph.
    """
    def __init__(
        self, 
        graph: 'StateGraph', 
        checkpointer: BaseCheckpoint,
        thread_id: str = "default"
    ):
        self.graph = graph
        self.checkpointer = checkpointer
        self.thread_id = thread_id
        self.step = 0
    
    def run(self, initial_state: AgentState, interrupt_before: List[str], interrupt_after: List[str], max_steps: int = 25):
        """
        Generator that yields events.
        """
        # 1. Load Snapshot (State + Next Node)
        snapshot = self.checkpointer.get(self.thread_id)
        current_node = self.graph.entry_point
        state = initial_state
        resuming_node = None 
        
        if snapshot:
            # Resume functionality
            saved_state_dict = snapshot.get("state")
            saved_next_node = snapshot.get("next_node")
            status = snapshot.get("status")
            
            if saved_state_dict:
                # Merge initial state if provided, otherwise use saved
                state = AgentState.from_dict(saved_state_dict)
                if initial_state._data:
                    state.update(initial_state._data)
            
            if saved_next_node and saved_next_node != END:
                current_node = saved_next_node
                if status == "interrupted":
                    resuming_node = current_node
                yield {"event": "resume", "node": current_node, "state": state.to_dict()}
        else:
            yield {"event": "start", "node": START, "state": state.to_dict()}

        while current_node != END and self.step < max_steps:
            if current_node not in self.graph.nodes:
                yield {"event": "error", "error": f"Node {current_node} not found"}
                return
            
            # --- Check Interrupt Before ---
            if current_node in interrupt_before:
                if resuming_node == current_node:
                    # We just resumed on this node, so we skip the interrupt
                    resuming_node = None
                else:
                    self._save_checkpoint(state, current_node, "interrupted", "interrupt_before")
                    yield {"event": "interrupt", "node": current_node, "type": "before"}
                    return 
            
            # --- Execute Node ---
            yield {"event": "node_start", "node": current_node}
            
            # Logic to execute node (could be moved to Runner, but keeping here for simplicity/ShortGraph philosophy)
            try:
                result = self._execute_node(current_node, state)
            except Exception as e:
                yield {"event": "error", "error": str(e), "node": current_node}
                raise e

            # Apply updates (Algo)
            state = apply_writes(state, result)
            yield {"event": "node_end", "node": current_node, "state": state.to_dict()}

            # --- Determine Next Node (Algo) ---
            next_node = prepare_next_tasks(self.graph, current_node, state)
            
            # --- Check Interrupt After ---
            if current_node in interrupt_after:
                self._save_checkpoint(state, next_node, "interrupted", "interrupt_after")
                yield {"event": "interrupt", "node": current_node, "type": "after"}
                return 

            # --- Checkpoint (Normal) ---
            self._save_checkpoint(state, next_node, "running", "step")
            
            current_node = next_node
            self.step += 1
            
        yield {"event": "end", "node": END, "state": state.to_dict()}

    def _save_checkpoint(self, state: AgentState, next_node: str, status: str, prefix: str):
        checkpoint_id = f"{prefix}_{next_node}_{int(time.time())}"
        self.checkpointer.put(self.thread_id, checkpoint_id, {
            "state": state.to_dict(),
            "next_node": next_node,
            "status": status
        })

    def _execute_node(self, node_name: str, state: AgentState) -> Any:
        node_obj = self.graph.nodes[node_name]
        node_meta = self.graph.node_metadata.get(node_name, {})
        max_retries = node_meta.get("retry", 0)
        
        last_error = None
        for attempt in range(max_retries + 1):
            try:
                # Support SubGraph Execution
                # Note: We need to avoid circular import if we check isinstance(node_obj, Pregel)
                # So we check if it has 'invoke' method
                if hasattr(node_obj, "invoke"):
                    return node_obj.invoke(state, thread_id=f"{self.thread_id}_sub_{node_name}")
                else:
                    return node_obj(state)
            except Exception as e:
                last_error = e
                if attempt < max_retries:
                    # Logic for retry delay could go here
                    continue
        
        if last_error:
            raise last_error
