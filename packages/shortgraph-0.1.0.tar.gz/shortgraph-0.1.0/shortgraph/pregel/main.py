from typing import List, Optional, Union, Dict, Any
from shortgraph.channels.manager import AgentState
from shortgraph.checkpoint.base import BaseCheckpoint, MemoryCheckpoint
from shortgraph.pregel.loop import PregelLoop

class Pregel:
    """
    The main runtime entry point for executing graphs.
    Replaces the old CompiledGraph.
    """
    def __init__(
        self, 
        graph, 
        checkpointer: Optional[BaseCheckpoint] = None,
        interrupt_before: Optional[List[str]] = None,
        interrupt_after: Optional[List[str]] = None
    ):
        self.graph = graph
        self.checkpointer = checkpointer or MemoryCheckpoint()
        self.interrupt_before = interrupt_before or []
        self.interrupt_after = interrupt_after or []

    def stream(self, initial_state: Union[AgentState, Dict[str, Any]], thread_id: str = "default", max_steps: int = 25):
        """
        Yields events as the graph executes.
        """
        # Ensure initial_state is AgentState
        if not isinstance(initial_state, AgentState):
            state = AgentState(data=initial_state)
        else:
            state = initial_state

        loop = PregelLoop(self.graph, self.checkpointer, thread_id)
        yield from loop.run(state, self.interrupt_before, self.interrupt_after, max_steps)

    def invoke(self, initial_state: Union[AgentState, Dict[str, Any]], thread_id: str = "default", max_steps: int = 25) -> AgentState:
        """
        Run the graph synchronously and return the final state.
        """
        # Ensure initial_state is AgentState (for consistency with stream, though stream handles it too)
        if not isinstance(initial_state, AgentState):
            state = AgentState(data=initial_state)
        else:
            state = initial_state

        final_state = state
        for event in self.stream(state, thread_id, max_steps):
            if "state" in event:
                final_state = AgentState.from_dict(event["state"])
            if event.get("event") == "interrupt":
                print(f"\n[INFO] Workflow interrupted {event['type']} node '{event['node']}'. State saved.")
                break
        return final_state
