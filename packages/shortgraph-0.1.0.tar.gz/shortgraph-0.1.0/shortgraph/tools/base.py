from typing import Callable, Any, Optional
from dataclasses import dataclass
import functools

@dataclass
class Tool:
    """
    Base class for tools that can be used by the agent.
    """
    name: str
    func: Callable
    description: str
    args_schema: Optional[Any] = None

    def run(self, *args, **kwargs) -> str:
        try:
            return str(self.func(*args, **kwargs))
        except Exception as e:
            return f"Error executing tool {self.name}: {str(e)}"

def tool(name: Optional[str] = None, description: Optional[str] = None):
    """
    Decorator to define a tool from a function.
    Usage:
        @tool(name="weather", description="Get weather info")
        def get_weather(city: str): ...
        
        OR
        
        @tool
        def get_weather(city: str): ...
    """
    def decorator(func):
        tool_name = name or func.__name__
        tool_desc = description or func.__doc__ or "No description provided."
        return Tool(name=tool_name, func=func, description=tool_desc)
    
    # Handle usage as @tool without arguments
    if callable(name):
        func = name
        name = None
        return decorator(func)
        
    return decorator
