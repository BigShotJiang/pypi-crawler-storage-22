from shortgraph import StateGraph, AgentState

def test_basic_graph():
    workflow = StateGraph()
    state = AgentState()
    assert workflow is not None
    assert state is not None
