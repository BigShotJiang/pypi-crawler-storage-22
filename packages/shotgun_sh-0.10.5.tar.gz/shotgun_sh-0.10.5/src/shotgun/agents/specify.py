"""Specify agent factory and functions using Pydantic AI with file-based memory."""

from functools import partial

from pydantic_ai.agent import AgentRunResult
from pydantic_ai.messages import ModelMessage

from shotgun.agents.config import ProviderType
from shotgun.agents.models import ShotgunAgent
from shotgun.logging_config import get_logger

from .common import (
    EventStreamHandler,
    add_system_status_message,
    build_agent_system_prompt,
    create_base_agent,
    create_usage_limits,
    run_agent,
)
from .models import AgentDeps, AgentResponse, AgentRuntimeOptions, AgentType

logger = get_logger(__name__)


async def create_specify_agent(
    agent_runtime_options: AgentRuntimeOptions,
    provider: ProviderType | None = None,
    for_sub_agent: bool = False,
) -> tuple[ShotgunAgent, AgentDeps]:
    """Create a specify agent with artifact management capabilities.

    Args:
        agent_runtime_options: Agent runtime options for the agent
        provider: Optional provider override. If None, uses configured default
        for_sub_agent: If True, use cheaper model for cost optimization

    Returns:
        Tuple of (Configured Pydantic AI agent for specification tasks, Agent dependencies)
    """
    logger.debug("Initializing specify agent")
    # Use partial to create system prompt function for specify agent
    system_prompt_fn = partial(build_agent_system_prompt, "specify")

    agent, deps = await create_base_agent(
        system_prompt_fn,
        agent_runtime_options,
        load_codebase_understanding_tools=True,
        additional_tools=None,
        provider=provider,
        agent_mode=AgentType.SPECIFY,
        for_sub_agent=for_sub_agent,
    )
    return agent, deps


async def run_specify_agent(
    agent: ShotgunAgent,
    prompt: str,
    deps: AgentDeps,
    message_history: list[ModelMessage] | None = None,
    event_stream_handler: EventStreamHandler | None = None,
) -> AgentRunResult[AgentResponse]:
    """Create or update specifications based on the given prompt.

    Args:
        agent: The configured specify agent
        prompt: The specification prompt or instruction
        deps: Agent dependencies
        message_history: Optional message history for conversation continuity
        event_stream_handler: Optional callback for streaming events

    Returns:
        AgentRunResult containing the specification process output
    """
    logger.debug("📋 Starting specification for prompt: %s", prompt)

    try:
        # Create usage limits for responsible API usage
        usage_limits = create_usage_limits()

        message_history = await add_system_status_message(deps, message_history)

        result = await run_agent(
            agent=agent,
            prompt=prompt,
            deps=deps,
            message_history=message_history,
            usage_limits=usage_limits,
            event_stream_handler=event_stream_handler,
        )

        logger.debug("✅ Specification completed successfully")
        return result

    except Exception as e:
        import traceback

        logger.error("Full traceback:\n%s", traceback.format_exc())
        logger.error("❌ Specification failed: %s", str(e))
        raise
