"""Python language extractor."""

from __future__ import annotations

from .extractor import PythonExtractor

__all__ = ["PythonExtractor"]
