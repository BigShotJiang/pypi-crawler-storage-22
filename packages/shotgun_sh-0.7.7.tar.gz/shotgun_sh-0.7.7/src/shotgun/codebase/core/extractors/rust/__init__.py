"""Rust language extractor."""

from __future__ import annotations

from .extractor import RustExtractor

__all__ = ["RustExtractor"]
