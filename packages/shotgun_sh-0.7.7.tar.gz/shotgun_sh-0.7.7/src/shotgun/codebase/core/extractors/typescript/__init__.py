"""TypeScript language extractor."""

from __future__ import annotations

from .extractor import TypeScriptExtractor

__all__ = ["TypeScriptExtractor"]
