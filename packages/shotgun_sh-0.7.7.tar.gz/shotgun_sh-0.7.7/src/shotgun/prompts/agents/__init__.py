"""Agent-specific prompt templates."""
