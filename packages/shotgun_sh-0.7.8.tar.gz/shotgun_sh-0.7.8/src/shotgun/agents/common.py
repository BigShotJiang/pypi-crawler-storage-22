"""Common utilities for agent creation and management."""

from collections.abc import AsyncIterable, Awaitable, Callable
from pathlib import Path
from typing import Any

import aiofiles
from pydantic_ai import (
    Agent,
    RunContext,
    UsageLimits,
)
from pydantic_ai.agent import AgentRunResult
from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
)
from pydantic_ai.settings import ModelSettings

from shotgun.agents.config import ProviderType, get_provider_model
from shotgun.agents.models import (
    AgentResponse,
    AgentSystemPromptContext,
    AgentType,
    ShotgunAgent,
)
from shotgun.logging_config import get_logger
from shotgun.prompts import PromptLoader
from shotgun.sdk.services import get_codebase_service
from shotgun.utils import ensure_shotgun_directory_exists
from shotgun.utils.datetime_utils import get_datetime_context
from shotgun.utils.file_system_utils import get_shotgun_base_path

from .conversation.history import token_limit_compactor
from .messages import AgentSystemPrompt, SystemStatusPrompt
from .models import AgentDeps, AgentRuntimeOptions, PipelineConfigEntry
from .tools import (
    append_file,
    codebase_shell,
    directory_lister,
    file_read,
    insert_markdown_section,
    query_graph,
    read_file,
    remove_markdown_section,
    replace_markdown_section,
    retrieve_code,
    validate_mermaid,
    validate_mermaid_in_content,
    write_file,
)

logger = get_logger(__name__)

# Global prompt loader instance
prompt_loader = PromptLoader()


async def add_system_status_message(
    deps: AgentDeps,
    message_history: list[ModelMessage] | None = None,
) -> list[ModelMessage]:
    """Add a system status message to the message history.

    Args:
        deps: Agent dependencies containing runtime options
        message_history: Existing message history

    Returns:
        Updated message history with system status message prepended
    """
    message_history = message_history or []
    # Only show graphs for the current working directory
    codebase_understanding_graphs = (
        await deps.codebase_service.list_graphs_for_directory()
    )

    # Get graphs currently being indexed
    indexing_graph_ids: set[str] = set()
    if deps.codebase_service:
        indexing_graph_ids = deps.codebase_service.indexing.get_active_ids()

    # Get existing files for the agent
    existing_files = get_agent_existing_files(deps.agent_mode)

    # Extract table of contents from the agent's markdown file
    markdown_toc = await extract_markdown_toc(deps.agent_mode)

    # Get current datetime with timezone information
    dt_context = get_datetime_context()

    # Get execution plan and pending approval state if this is the Router agent
    execution_plan = None
    pending_approval = False
    if deps.agent_mode == AgentType.ROUTER:
        # Import here to avoid circular imports
        from shotgun.agents.router.models import RouterDeps

        if isinstance(deps, RouterDeps):
            if deps.current_plan is not None:
                execution_plan = deps.current_plan.format_for_display()
            # Check if plan is pending approval (multi-step plan in Planning mode)
            pending_approval = deps.pending_approval is not None

    system_state = prompt_loader.render(
        "agents/state/system_state.j2",
        codebase_understanding_graphs=codebase_understanding_graphs,
        indexing_graph_ids=indexing_graph_ids,
        is_tui_context=deps.is_tui_context,
        existing_files=existing_files,
        markdown_toc=markdown_toc,
        current_datetime=dt_context.datetime_formatted,
        timezone_name=dt_context.timezone_name,
        utc_offset=dt_context.utc_offset,
        execution_plan=execution_plan,
        pending_approval=pending_approval,
    )

    message_history.append(
        ModelRequest(
            parts=[
                SystemStatusPrompt(content=system_state),
            ]
        )
    )
    return message_history


async def create_base_agent(
    system_prompt_fn: Callable[[RunContext[AgentDeps]], str],
    agent_runtime_options: AgentRuntimeOptions,
    load_codebase_understanding_tools: bool = True,
    additional_tools: list[Any] | None = None,
    provider: ProviderType | None = None,
    agent_mode: AgentType | None = None,
    for_sub_agent: bool = False,
) -> tuple[ShotgunAgent, AgentDeps]:
    """Create a base agent with common configuration.

    Args:
        system_prompt_fn: Function that will be decorated as system_prompt
        agent_runtime_options: Agent runtime options for the agent
        load_codebase_understanding_tools: Whether to load codebase understanding tools
        additional_tools: Optional list of additional tools
        provider: Optional provider override. If None, uses configured default
        agent_mode: The mode of the agent (research, plan, tasks, specify, export)
        for_sub_agent: If True, use cheaper model for cost optimization

    Returns:
        Tuple of (Configured Pydantic AI agent, Agent dependencies)
    """
    ensure_shotgun_directory_exists()

    # Get configured model - use inherited config from parent agent if available
    try:
        # Check if we have an inherited model config (e.g., from Router to sub-agents)
        # This ensures sub-agents use the same model as their parent (e.g., Ollama model)
        if agent_runtime_options.inherited_model_config is not None:
            model_config = agent_runtime_options.inherited_model_config
            logger.debug(
                "🤖 Creating agent with inherited model config: %s",
                model_config.name,
            )
        else:
            # Fall back to getting provider model from global config
            model_config = await get_provider_model(
                provider, for_sub_agent=for_sub_agent
            )
            logger.debug(
                "🤖 Creating agent with configured %s model: %s",
                model_config.provider.value.upper(),
                model_config.name,
            )

        # Use the Model instance directly (has API key baked in)
        model = model_config.model_instance

        # Create deps with model config and services
        # Exclude inherited_model_config from model_dump to avoid passing it to AgentDeps
        runtime_options_dict = agent_runtime_options.model_dump(
            exclude={"inherited_model_config"}
        )
        codebase_service = get_codebase_service()
        deps = AgentDeps(
            **runtime_options_dict,
            llm_model=model_config,
            codebase_service=codebase_service,
            system_prompt_fn=system_prompt_fn,
            agent_mode=agent_mode,
        )

    except Exception as e:
        logger.warning("Failed to load configured model, using fallback: %s", e)
        logger.debug("🤖 Creating agent with fallback OpenAI GPT-4o")
        raise ValueError("Configured model is required") from e

    # Create a history processor that has access to deps via closure
    async def history_processor(messages: list[ModelMessage]) -> list[ModelMessage]:
        """History processor with access to deps via closure."""

        # Create a minimal context for compaction
        class ProcessorContext:
            def __init__(self, deps: AgentDeps):
                self.deps = deps
                self.usage = None  # Will be estimated from messages

        ctx = ProcessorContext(deps)
        return await token_limit_compactor(ctx, messages)

    agent = Agent(
        model,
        output_type=AgentResponse,
        deps_type=AgentDeps,
        instrument=True,
        history_processors=[history_processor],
        retries=3,  # Default retry count for tool calls and output validation
    )

    # System prompt function is stored in deps and will be called manually in run_agent
    func_name = getattr(system_prompt_fn, "__name__", str(system_prompt_fn))
    logger.debug("🔧 System prompt function stored: %s", func_name)

    # Register additional tools first (agent-specific)
    for tool in additional_tools or []:
        agent.tool_plain(tool)

    # Register common file management tools (always available)
    agent.tool(write_file)
    agent.tool(append_file)
    agent.tool(read_file)
    agent.tool(replace_markdown_section)
    agent.tool(insert_markdown_section)
    agent.tool(remove_markdown_section)

    # Register mermaid validation tools (always available)
    agent.tool(validate_mermaid)
    agent.tool(validate_mermaid_in_content)

    # Register codebase understanding tools (conditional)
    if load_codebase_understanding_tools:
        agent.tool(query_graph)
        agent.tool(retrieve_code)
        agent.tool(file_read)
        agent.tool(directory_lister)
        agent.tool(codebase_shell)
        logger.debug("🧠 Codebase understanding tools registered")
    else:
        logger.debug("🚫🧠 Codebase understanding tools not registered")

    logger.debug("✅ Agent creation complete with codebase tools")
    return agent, deps


async def _extract_file_toc_content(
    file_path: Path, max_depth: int | None = None, max_chars: int = 500
) -> str | None:
    """Extract TOC from a single file with depth and character limits.

    Args:
        file_path: Path to the markdown file
        max_depth: Maximum heading depth (1=#, 2=##, None=all)
        max_chars: Maximum characters for the TOC

    Returns:
        Formatted TOC string or None if file doesn't exist
    """
    if not file_path.exists():
        return None

    try:
        async with aiofiles.open(file_path, encoding="utf-8") as f:
            content = await f.read()
        lines = content.split("\n")

        # Extract headings
        toc_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("#"):
                # Count the heading level
                level = 0
                for char in stripped:
                    if char == "#":
                        level += 1
                    else:
                        break

                # Skip if exceeds max_depth
                if max_depth and level > max_depth:
                    continue

                # Get the heading text (remove the # symbols and clean up)
                heading_text = stripped[level:].strip()
                if heading_text:
                    # Add indentation based on level
                    indent = "  " * (level - 1)
                    toc_lines.append(f"{indent}{'#' * level} {heading_text}")

                    # Check if we're approaching the character limit
                    current_length = sum(len(line) + 1 for line in toc_lines)
                    if current_length > max_chars:
                        # Remove the last line and add ellipsis
                        toc_lines.pop()
                        if toc_lines:
                            toc_lines.append("  ...")
                        break

        if not toc_lines:
            return None

        return "\n".join(toc_lines)

    except Exception as e:
        logger.debug(f"Failed to extract TOC from {file_path}: {e}")
        return None


async def extract_markdown_toc(agent_mode: AgentType | None) -> str | None:
    """Extract TOCs from current and prior agents' files in the pipeline.

    Shows full TOC of agent's own file and high-level summaries of prior agents'
    files to maintain context awareness while keeping context window tight.

    Args:
        agent_mode: The agent mode to extract TOC for

    Returns:
        Formatted multi-file TOC string or None if not applicable
    """
    # Skip if no mode
    if not agent_mode:
        return None

    # Define pipeline order and dependencies
    pipeline_config: dict[AgentType, PipelineConfigEntry] = {
        AgentType.RESEARCH: PipelineConfigEntry(
            own_file="research.md",
            prior_files=[],  # First in pipeline
        ),
        AgentType.SPECIFY: PipelineConfigEntry(
            own_file="specification.md",
            prior_files=["research.md"],
        ),
        AgentType.PLAN: PipelineConfigEntry(
            own_file="plan.md",
            prior_files=["research.md", "specification.md"],
        ),
        AgentType.TASKS: PipelineConfigEntry(
            own_file="tasks.md",
            prior_files=["research.md", "specification.md", "plan.md"],
        ),
        AgentType.EXPORT: PipelineConfigEntry(
            own_file=None,  # Export uses directory
            prior_files=["research.md", "specification.md", "plan.md", "tasks.md"],
        ),
    }

    # Get configuration for current agent
    if agent_mode not in pipeline_config:
        return None

    config = pipeline_config[agent_mode]
    base_path = get_shotgun_base_path()
    toc_sections: list[str] = []

    # Extract TOCs from prior files (high-level only)
    for prior_file in config.prior_files:
        file_path = base_path / prior_file
        # Only show # and ## headings from prior files, max 500 chars each
        prior_toc = await _extract_file_toc_content(
            file_path, max_depth=2, max_chars=500
        )
        if prior_toc:
            # Add section with XML tags
            toc_sections.append(
                f'<TABLE_OF_CONTENTS file_name="{prior_file}">\n'
                f"{prior_toc}\n"
                f"</TABLE_OF_CONTENTS>"
            )

    # Extract TOC from own file (full detail)
    if config.own_file:
        own_path = base_path / config.own_file
        own_toc = await _extract_file_toc_content(
            own_path, max_depth=None, max_chars=2000
        )
        if own_toc:
            # Put own file TOC at the beginning with XML tags
            toc_sections.insert(
                0,
                f'<TABLE_OF_CONTENTS file_name="{config.own_file}">\n'
                f"{own_toc}\n"
                f"</TABLE_OF_CONTENTS>",
            )

    # Combine all sections
    if not toc_sections:
        return None

    combined_toc = "\n\n".join(toc_sections)

    # Final truncation if needed (should rarely happen with our limits)
    max_total = 3500  # Conservative total limit
    if len(combined_toc) > max_total:
        combined_toc = combined_toc[: max_total - 3] + "..."

    return combined_toc


def get_agent_existing_files(agent_mode: AgentType | None = None) -> list[str]:
    """Get list of all existing files in .shotgun directory.

    All agents can read any file in .shotgun/, so we list all files regardless
    of agent mode. This includes user-added files that agents should be aware of.

    Args:
        agent_mode: Unused, kept for backwards compatibility.

    Returns:
        List of existing file paths relative to .shotgun directory
    """
    base_path = get_shotgun_base_path()
    existing_files: list[str] = []

    if not base_path.exists():
        return existing_files

    # List all files in .shotgun directory and subdirectories
    for item in base_path.iterdir():
        if item.is_file():
            existing_files.append(item.name)
        elif item.is_dir():
            # List files in subdirectories (one level deep to avoid too much noise)
            for subitem in item.iterdir():
                if subitem.is_file():
                    relative_path = subitem.relative_to(base_path)
                    existing_files.append(str(relative_path))

    return existing_files


def build_agent_system_prompt(
    agent_type: str,
    ctx: RunContext[AgentDeps],
    context_name: str | None = None,
) -> str:
    """Build system prompt for any agent type.

    Args:
        agent_type: Type of agent ('research', 'plan', 'tasks')
        ctx: RunContext containing AgentDeps
        context_name: Optional context name for template rendering

    Returns:
        Rendered system prompt
    """
    prompt_loader = PromptLoader()

    # Add logging if research agent
    if agent_type == "research":
        logger.debug("🔧 Building research agent system prompt...")
        logger.debug("Interactive mode: %s", ctx.deps.interactive_mode)

    # Build template context using Pydantic model for type safety and testability
    # Import here to avoid circular imports (same pattern as add_system_status_message)
    from shotgun.agents.router.models import RouterDeps

    router_mode = None
    if isinstance(ctx.deps, RouterDeps):
        router_mode = ctx.deps.router_mode.value

    # Get model capabilities from deps
    model_config = ctx.deps.llm_model
    supports_pdf = model_config.supports_pdf if model_config else True
    supports_images = model_config.supports_images if model_config else True

    template_context = AgentSystemPromptContext(
        interactive_mode=ctx.deps.interactive_mode,
        mode=agent_type,
        sub_agent_context=ctx.deps.sub_agent_context,
        router_mode=router_mode,
        supports_pdf=supports_pdf,
        supports_images=supports_images,
    )

    result = prompt_loader.render(
        f"agents/{agent_type}.j2",
        **template_context.model_dump(),
    )

    if agent_type == "research":
        logger.debug(
            "✅ Research system prompt built successfully (length: %d chars)",
            len(result),
        )

    return result


def create_usage_limits() -> UsageLimits:
    """Create reasonable usage limits for agent runs.

    Returns:
        UsageLimits configured for responsible API usage
    """
    return UsageLimits(
        request_limit=100,  # Maximum number of model requests per run
        tool_calls_limit=100,  # Maximum number of successful tool calls
    )


async def add_system_prompt_message(
    deps: AgentDeps,
    message_history: list[ModelMessage] | None = None,
) -> list[ModelMessage]:
    """Add the system prompt as the first message in the message history.

    Args:
        deps: Agent dependencies containing system_prompt_fn
        message_history: Existing message history

    Returns:
        Updated message history with system prompt prepended as first message
    """
    message_history = message_history or []

    # Create a minimal RunContext to call the system prompt function
    # We'll pass None for model and usage since they're not used
    # by our system prompt functions
    context = type(
        "RunContext", (), {"deps": deps, "retry": 0, "model": None, "usage": None}
    )()

    # Render the system prompt using the stored function
    system_prompt_content = deps.system_prompt_fn(context)
    logger.debug(
        "🎯 Rendered system prompt (length: %d chars)", len(system_prompt_content)
    )

    # Create system message and prepend to message history
    system_message = ModelRequest(
        parts=[
            AgentSystemPrompt(content=system_prompt_content, agent_mode=deps.agent_mode)
        ]
    )
    message_history.insert(0, system_message)
    logger.debug("✅ System prompt prepended as first message")

    return message_history


EventStreamHandler = Callable[
    [RunContext[AgentDeps], AsyncIterable[Any]], Awaitable[None]
]


async def run_agent(
    agent: ShotgunAgent,
    prompt: str,
    deps: AgentDeps,
    message_history: list[ModelMessage] | None = None,
    usage_limits: UsageLimits | None = None,
    event_stream_handler: EventStreamHandler | None = None,
    model_settings: ModelSettings | None = None,
) -> AgentRunResult[AgentResponse]:
    """Run an agent with optional streaming support.

    Args:
        agent: The agent to run.
        prompt: The prompt to send to the agent.
        deps: Agent dependencies.
        message_history: Optional message history to continue from.
        usage_limits: Optional usage limits for the run.
        event_stream_handler: Optional callback for streaming events.
            When provided, enables real-time streaming of agent responses.
        model_settings: Optional model settings for the run.
            Can be used to configure model behavior like parallel_tool_calls.

    Returns:
        The agent run result.
    """
    # Clear file tracker for new run
    deps.file_tracker.clear()
    logger.debug("🔧 Cleared file tracker for new agent run")

    # Add system prompt as first message
    message_history = await add_system_prompt_message(deps, message_history)

    result = await agent.run(
        prompt,
        deps=deps,
        usage_limits=usage_limits,
        message_history=message_history,
        event_stream_handler=event_stream_handler,
        model_settings=model_settings,
    )

    # Log file operations summary if any files were modified
    if deps.file_tracker.operations:
        summary = deps.file_tracker.format_summary()
        logger.info("📁 %s", summary)

    return result
