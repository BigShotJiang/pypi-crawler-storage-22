
import numpy as np
import math

from dataclasses import dataclass

try:
    from numba import njit as jit 
    from numba import prange
    jit(lambda x: x**2)(1.0)  # test if numba is available

except:
    prange = range
    def jit(*_, **__):
        def _decorator(func):
            return func
        return _decorator


@dataclass
class _Element:
    nodes: tuple # of int
  # gauss: tuple # of Gauss
    shape: str
    model: dict = None
    group: int = 0
    tag: int = 0

import numpy as np


# T6 shape terms in barycentric form: list of (a,b,c,coef)
Ni_terms = [
    [(2,0,0, 2.0), (1,0,0,-1.0)],        # N1
    [(0,2,0, 2.0), (0,1,0,-1.0)],        # N2
    [(0,0,2, 2.0), (0,0,1,-1.0)],        # N3
    [(1,1,0, 4.0)],                      # N4
    [(0,1,1, 4.0)],                      # N5
    [(1,0,1, 4.0)],                      # N6
]

# dN/dL1, dN/dL2, dN/dL3 for each Ni 
dN_dL = [
    ([(1,0,0, 4.0), (0,0,0,-1.0)], [], []),      # N1
    ([], [(0,1,0, 4.0), (0,0,0,-1.0)], []),      # N2
    ([], [], [(0,0,1, 4.0), (0,0,0,-1.0)]),      # N3
    ([(0,1,0, 4.0)], [(1,0,0, 4.0)], []),        # N4
    ([], [(0,0,1, 4.0)], [(0,1,0, 4.0)]),        # N5
    ([(0,0,1, 4.0)], [], [(1,0,0, 4.0)]),        # N6
]

#
# Exact barycentric monomial integral:
# ∫_Ω L1^a L2^b L3^c dΩ = 2A * (a! b! c!) / (a+b+c+2)!

def _I(A, a, b, c):
    return 2.0*A * math.factorial(a)*math.factorial(b)*math.factorial(c) / math.factorial(a+b+c+2)

# Exact barycentric monomial integral WITHOUT area factor:
# I0(a,b,c) = ∫ L1^a L2^b L3^c dΩ / A 
#           = 2 * (a! b! c!) / (a+b+c+2)!   (since ∫ = A * I0)
def _I0(a, b, c):
    return 2.0 * math.factorial(a)*math.factorial(b)*math.factorial(c) / math.factorial(a+b+c+2)


def _init_hilbert():
    # 
    # M0: 6x6 matrix with ∫ Ni Nj dΩ = A * M0[i,j]
    M0 = np.zeros((6,6))
    for i in range(6):
        for j in range(6):
            s = 0.0
            for (a1,b1,c1,ci) in Ni_terms[i]:
                for (a2,b2,c2,cj) in Ni_terms[j]:
                    s += ci*cj * _I0(a1+a2, b1+b2, c1+c2)
            M0[i,j] = s

    return M0


def _init_poisson():
    # Convection terms ,like ∫ N (c . ∇u) dΩ

    # IJ0: 6x6x3 with ∫ (dNi/dLk) Nj dΩ = A * IJ0[i,j,k], k=0..2 for L1,L2,L3
    IJ0 = np.zeros((6,6,3))
    for i in range(6):
        for j in range(6):
            for k in range(3):
                s = 0.0
                for (a1,b1,c1,ci) in dN_dL[i][k]:
                    for (a2,b2,c2,cj) in Ni_terms[j]:
                        s += ci*cj * _I0(a1+a2, b1+b2, c1+c2)
                IJ0[i,j,k] = s

    return IJ0

def _init_sobolev():
    # Stiffness, or diffusion terms

    # IK0: 6x6x3x3 with ∫ (dNi/dLk)(dNj/dLl) dΩ = A * IK0[i,j,k,l]
    IK0 = np.zeros((6,6,3,3))
    for i in range(6):
        for j in range(6):
            for k in range(3):
                for l in range(3):
                    s = 0.0
                    for (a1,b1,c1,ci) in dN_dL[i][k]:
                        for (a2,b2,c2,cj) in dN_dL[j][l]:
                            s += ci*cj * _I0(a1+a2, b1+b2, c1+c2)
                    IK0[i,j,k,l] = s
    return IK0


def _init_burgers():
    # Barycentric moments
    # J0[i,j,k,m] = ∫ (dNi/dLm) Nj Nk dΩ / A   (i,j,k=0..5, m=0..2 for L1..L3)
    J0 = np.zeros((6,6,6,3))
    for i in range(6):
        for j in range(6):
            for k in range(6):

                # multiply dNi/dLm term-by-term with Nj and Nk
                for m in range(3):
                    s = 0.0
                    for (a1,b1,c1,ci) in dN_dL[i][m]:
                        for (a2,b2,c2,cj) in Ni_terms[j]:
                            for (a3,b3,c3,ck) in Ni_terms[k]:
                                s += ci*cj*ck * _I0(a1+a2+a3, b1+b2+b3, c1+c2+c3)
                    J0[i,j,k,m] = s

    return J0


M0_T6  = _init_hilbert()  # 6x6 matrix for Hilbert integral
IJ0_T6 = _init_poisson()
IK0_T6 = _init_sobolev()
IK0_flat = IK0_T6.reshape(9, 36)
J0_T6  = _init_burgers()

# P = np.array([0, 1, 2, 4, 5, 3], dtype=np.int64)

# M0_T6  = M0_T6[np.ix_(P, P)]
# IJ0_T6 = IJ0_T6[P][:, P, :]
# IK0_T6 = IK0_T6[P][:, P, :, :]
# J0_T6  = J0_T6[P][:, P][:, :, P, :]


M0_T3 = np.array([[2,1,1],
                  [1,2,1],
                  [1,1,2]],dtype=float)/12


def _barycentric_T3(r, p1, p2, p3):
    """
    r  : (y,z) point
    p1,p2,p3 : corner points (y,z)
    returns (L1,L2,L3)
    """
    
    y, z = r
    y1, z1 = p1
    y2, z2 = p2
    y3, z3 = p3
    T = np.array([[y1 - y3, y2 - y3],
                  [z1 - z3, z2 - z3]])
    L1, L2 = np.linalg.solve(T, np.array([y - y3, z - z3]))
    L3 = 1.0 - L1 - L2
    return L1, L2, L3

    # signed area * 2
    den = (y2 - y1)*(z3 - z1) - (y3 - y1)*(z2 - z1)
    if abs(den) < 1e-30:
        raise ValueError("Degenerate triangle (zero area).")
    

    L1 = ((y2 - y)*(z3 - z) - (y3 - y)*(z2 - z)) / den
    L2 = ((y3 - y)*(z1 - z) - (y1 - y)*(z3 - z)) / den
    L3 = 1.0 - L1 - L2
    return L1, L2, L3



def barycentric_T3_and_grads(r, p1, p2, p3):
    y, z = r
    y1, z1 = p1
    y2, z2 = p2
    y3, z3 = p3

    den = (y2 - y1)*(z3 - z1) - (y3 - y1)*(z2 - z1)  # = 2A (signed)
    if abs(den) < 1e-30:
        raise ValueError("Degenerate triangle (zero area).")

    L1 = ((y2 - y)*(z3 - z) - (y3 - y)*(z2 - z)) / den
    L2 = ((y3 - y)*(z1 - z) - (y1 - y)*(z3 - z)) / den
    L3 = 1.0 - L1 - L2

    # ∇Li = [dLi/dy, dLi/dz] (constant over the element)
    dL1 = np.array([(z2 - z3)/den, (y3 - y2)/den])
    dL2 = np.array([(z3 - z1)/den, (y1 - y3)/den])
    dL3 = -dL1 - dL2

    return (L1, L2, L3), (dL1, dL2, dL3)


class T6(_Element):
    _triangles = [
        (0, 1, 3),
        (1, 2, 4),
        (2, 0, 5),
        (3, 4, 5)
    ]
    _quadrature = [
        ((1/6, 1/6, 2/3), 1/3),
        ((1/6, 2/3, 1/6), 1/3),
        ((2/3, 1/6, 1/6), 1/3)
    ]

    @property 
    def fibers(self):
        for point, weight in self._quadrature:
            L1, L2, L3 = point
            r = L1*self.model.nodes[self.nodes[0]] + \
                L2*self.model.nodes[self.nodes[1]] + \
                L3*self.model.nodes[self.nodes[2]]
            yield r, self.area * weight

    @property
    def area(self):
        y, z = self.model.nodes[self.nodes[:3]].T
        z1, z2, z3 = z
        y1, y2, y3 = y
        a = float(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))
        return a


    def interp(self, field, r):
        # compute L1,L2,L3 from corners 1..3
        P = self.model.nodes[self.nodes]
        p1, p2, p3 = P[0], P[1], P[2]
        L1, L2, L3 = _barycentric_T3(r, p1, p2, p3)

        N = np.array([
             L1*(2*L1 - 1),
             L2*(2*L2 - 1),
             L3*(2*L3 - 1),
             4*L1*L2,   # edge (1,2)
             4*L2*L3,   # edge (2,3)
             4*L3*L1,   # edge (3,1)
        ])
        return np.dot(N, field[self.nodes])

        u1, u2, u3, u4, u5, u6 = field[self.nodes]

        # Triangle: u4 on (2,3), u5 on (3,1), u6 on (1,2)
        return (
            N1*u1 + N2*u2 + N3*u3
            + N5*u4   # (2,3)
            + N6*u5   # (3,1)
            + N4*u6   # (1,2)
        )

    def gradient(self, field, r):
        # Corners are nodes 1..3 from Triangle -o2
        P = self.model.nodes[self.nodes]   # (6,2) -> (y,z)
        p1, p2, p3 = P[0], P[1], P[2]

        (L1, L2, L3), (dL1, dL2, dL3) = barycentric_T3_and_grads(r, p1, p2, p3)

        # Shape function gradients
        dN = np.array([
           (4*L1 - 1) * dL1,
           (4*L2 - 1) * dL2,
           (4*L3 - 1) * dL3,
           4*(L2*dL1 + L1*dL2),  # edge (1,2)
           4*(L3*dL2 + L2*dL3),  # edge (2,3)
           4*(L1*dL3 + L3*dL1)   # edge (3,1)
        ])
        return np.dot(dN.T, field[self.nodes])  # [du/dy, du/dz]

    def inertia(self, u, v, *, weight='e'):
        w = self.model._assigns[self.group][weight]*self.area 
        return u.dot(M0_T6 @ v) * w

    @staticmethod
    @jit(cache=True, fastmath=True)
    def poisson(me, ke, by, bz, area, x, y):
        # gy = (1/(2A)) * (b_k * A * IJ0[:,:,k]) = 0.5 * Σ_k b_k IJ0[:,:,k]
        Py = 0.5 * (by[0]*IJ0_T6[:,:,0] + by[1]*IJ0_T6[:,:,1] + by[2]*IJ0_T6[:,:,2])

        # gz = 0.5 * Σ_k c_k IJ0[:,:,k]
        Pz = 0.5 * (bz[0]*IJ0_T6[:,:,0] + bz[1]*IJ0_T6[:,:,1] + bz[2]*IJ0_T6[:,:,2])
        return Py@x + Pz@y

    @staticmethod
    @jit(cache=True, fastmath=True)
    def hilbert(me, ke, by, bz, area, f):
        return area*M0_T6 @ f

    @staticmethod
    def state(xyz):
        ((y1, y2, y3), (z1, z2, z3)) = xyz[:, :3]

        z12, z23, z31 = z1 - z2, z2 - z3, z3 - z1
        y32, y13, y21 = y3 - y2, y1 - y3, y2 - y1

        area = abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))

        #  ∫ N^T N dΩ
        me = area*M0_T6

        # ∫ (∇N)^T (∇N) dΩ
        by = np.array([ z23,  z31,  z12])
        bz = np.array([ y32,  y13,  y21])

        me = area * M0_T6

        # ke = (1/(4A)) * Σ_{k,l} (b_k b_l + c_k c_l) * IK0[:,:,k,l]
        W  = np.outer(bz,bz) + np.outer(by,by)       # 3x3
        # ke = (1.0/(4.0*A)) * np.einsum('kl,ijkl->ij', W, IK0)
        ke = (1.0/(4.0*area)) * np.tensordot(W, IK0_T6, axes=([0,1],[2,3]))  # (6,6)

        return me, ke, by, bz, area


class T3(_Element):
    _triangles = [(0,1,2)]

    @property
    def fibers(self):
        yield sum(self.model.nodes[self.nodes])/3.0, self.area

    @property
    def area(self):
        y, z = self.model.nodes[self.nodes].T
        z1, z2, z3 = z
        y1, y2, y3 = y
        a = float(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))
        return abs(a)
    
    def interp(self, field, r):
        # compute L1,L2,L3 from corners 1..3
        P = self.model.nodes[self.nodes]
        p1, p2, p3 = P[0], P[1], P[2]
        L1, L2, L3 = _barycentric_T3(r, p1, p2, p3)

        N = np.array([
             L1,#*(2*L1 - 1),
             L2,#*(2*L2 - 1),
             L3,#*(2*L3 - 1)
        ])
        return np.dot(N, field[self.nodes])
    # def interp(self, field, r):
    #     return sum(field[self.nodes]) / 3.0

    # def interp(self, field, r):
    #     u1, u2, u3 = field[self.nodes]
    #     ((y1, y2, y3), (z1, z2, z3)) = self.model.nodes[self.nodes].T
    #     z12 = z1 - z2
    #     z23 = z2 - z3
    #     z31 = z3 - z1
    #     y32 = y3 - y2
    #     y13 = y1 - y3
    #     y21 = y2 - y1
    #     A = self.area
    #     N1 = 1/(2*A)*(z23*(r[0]-y3) + y32*(r[1]-z3))
    #     N2 = 1/(2*A)*(z31*(r[0]-y3) + y13*(r[1]-z3))
    #     N3 = 1/(2*A)*(z12*(r[0]-y3) + y21*(r[1]-z3))
    #     return N1*u1 + N2*u2 + N3*u3

    def inertia(self, u, v, *, weight='e'):
        w = self.model._assigns[self.group][weight]*self.area 
        return u.dot(M0_T3 @ v) * w

    def gradient(self, field, r):
        # May also try Cook equation 3.4-6
        u1, u2, u3 = field[self.nodes]
        ((y1, y2, y3), (z1, z2, z3)) = self.model.nodes[self.nodes].T
        z12 = z1 - z2
        z23 = z2 - z3
        z31 = z3 - z1
        y32 = y3 - y2
        y13 = y1 - y3
        y21 = y2 - y1
        A = self.area
        return 1/(2*A)*np.array([
            z23*u1 + z31*u2 + z12*u3,
            y32*u1 + y13*u2 + y21*u3
        ])


    @staticmethod
    # @jit(cache=True, fastmath=True)
    def state(xyz):
        ((y1, y2, y3), (z1, z2, z3)) = xyz

        z12, z23, z31 = z1-z2, z2-z3, z3-z1
        y32, y13, y21 = y3-y2, y1-y3, y2-y1

        by, bz, area = T3.tangent(xyz)

        #  ∫ N^T N dΩ
        me = area*M0_T3

        # ∫ (∇N)^T (∇N) dΩ

        k11 =  y32**2  + z23**2
        k12 =  y13*y32 + z23*z31
        k13 =  y21*y32 + z12*z23
        k22 =  y13**2  + z31**2
        k23 =  y13*y21 + z12*z31
        k33 =  y21**2  + z12**2
        ke  = 1/(4.0*area) * np.array([[k11, k12, k13],
                                       [k12, k22, k23],
                                       [k13, k23, k33]])

        return me, ke, by, bz, area


    @staticmethod
    @jit(cache=True, fastmath=True)
    def tangent(xyz): # _map_triangle

        ((y1, y2, y3), (z1, z2, z3)) = xyz

        z12, z23, z31 = z1-z2, z2-z3, z3-z1
        y32, y13, y21 = y3-y2, y1-y3, y2-y1

        area = abs(0.5 * ((y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1)))


        # ∇N
        by = np.array([ z23,  z31,  z12])
        bz = np.array([ y32,  y13,  y21])

        return by, bz, area
    

    @staticmethod
    @jit(cache=True, fastmath=True)
    def poisson(me, ke, by, bz, area, fy, fz):
        #  ∫ (∂N/∂y)^T N dΩ
        Py = (1.0/6.0) * np.outer( by, [1.0, 1.0, 1.0])
        #  ∫ (∂N/∂z)^T N dΩ
        Pz = (1.0/6.0) * np.outer( bz, [1.0, 1.0, 1.0])
        return Py@fy + Pz@fz
    
    @staticmethod
    @jit(cache=True, fastmath=True)
    def hilbert(me, ke, by, bz, area, f):
        return area*M0_T3 @ f