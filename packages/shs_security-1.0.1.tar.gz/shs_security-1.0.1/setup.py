from setuptools import setup, find_packages

setup(
    name="shs",
    version="1.0.0",
    description="Security Hygiene Scanner",
    author="Mahima Kumawat",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "psutil",
        "colorama",
        "pyyaml",
        "boto3",
        "regex"
    ],
    entry_points={
        "console_scripts": [
            "shs=shs.cli:main"
        ]
    },
)
