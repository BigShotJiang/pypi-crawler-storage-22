"""Assets package for SHS."""
