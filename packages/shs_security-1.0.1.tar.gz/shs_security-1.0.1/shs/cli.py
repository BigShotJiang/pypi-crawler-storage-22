def main():
    import argparse
    from shs.core.engine import run

    parser = argparse.ArgumentParser(
        prog="shs",
        description="Security Hygiene Scanner - Detect security issues before attackers do"
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    scan_parser = subparsers.add_parser("scan", help="Run security scan")
    scan_parser.add_argument("--system", action="store_true", help="Scan system configuration")
    scan_parser.add_argument("--network", action="store_true", help="Scan network configuration")
    scan_parser.add_argument("--users", action="store_true", help="Scan user accounts and permissions")
    scan_parser.add_argument("--files", action="store_true", help="Scan files for secrets")
    scan_parser.add_argument("--cloud", action="store_true", help="Scan cloud credentials")
    scan_parser.add_argument("--apps", action="store_true", help="Scan application configuration")

    args = parser.parse_args()

    if args.command == "scan":
        # Collect enabled modules
        modules = []
        if args.system:
            modules.append("system")
        if args.network:
            modules.append("network")
        if args.users:
            modules.append("users")
        if args.files:
            modules.append("files")
        if args.cloud:
            modules.append("cloud")
        if args.apps:
            modules.append("apps")

        # If no modules specified, run full scan
        if not modules:
            modules = None

        run(modules=modules)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
