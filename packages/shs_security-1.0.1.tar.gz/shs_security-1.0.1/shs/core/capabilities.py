"""
System Capabilities Detection Module

Determines what security checks are supported on the current system.
Prevents false CRITICAL findings by skipping OS-incompatible checks.

Follows enterprise scanner patterns (Lynis, osquery, OpenSCAP).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Set

from .os_detector import OSDetector, OSType
from .privilege import PrivilegeDetector, PrivilegeLevel


@dataclass
class SystemCapabilities:
    """
    System capability/feature support matrix.
    
    Tracks which security checks can be run on this system.
    Boolean flags indicate if check is supported.
    
    Attributes:
        firewall_check: Can detect firewall status
        antivirus_check: Can detect antivirus presence
        update_check: Can check for OS updates
        user_check: Can enumerate users/groups
        service_check: Can enumerate services
        file_integrity: Can check file integrity
        selinux_check: Can check SELinux status
        apparmor_check: Can check AppArmor status
        requires_root: Current system checks require root
    """
    firewall_check: bool = True
    antivirus_check: bool = True
    update_check: bool = True
    user_check: bool = True
    service_check: bool = True
    file_integrity: bool = True
    selinux_check: bool = False
    apparmor_check: bool = False
    requires_root: bool = False
    
    # Track which checks were explicitly disabled
    skipped_checks: Set[str] = field(default_factory=set)


class CapabilityDetector:
    """
    System capability detection engine.
    
    Determines which security checks can run on the current system
    based on OS type, privilege level, and installed tools.
    
    Example:
        detector = CapabilityDetector()
        caps = detector.detect()
        if caps.firewall_check:
            # Run firewall check
            pass
        else:
            # Skip firewall check and report SKIP
            pass
    """

    @staticmethod
    def detect() -> SystemCapabilities:
        """
        Detect system capabilities.
        
        Returns:
            SystemCapabilities: Feature support matrix
        """
        os_info = OSDetector.detect()
        priv_info = PrivilegeDetector.detect()
        
        caps = SystemCapabilities()
        
        # Branch on OS type
        if os_info.os_type == OSType.LINUX:
            CapabilityDetector._detect_linux_capabilities(caps, os_info, priv_info)
        elif os_info.os_type == OSType.WINDOWS:
            CapabilityDetector._detect_windows_capabilities(caps, os_info, priv_info)
        elif os_info.os_type == OSType.MACOS:
            CapabilityDetector._detect_macos_capabilities(caps, os_info, priv_info)
        else:
            # Unknown OS: disable most checks
            CapabilityDetector._detect_unknown_capabilities(caps, priv_info)

        # Post-processing based on privilege level
        CapabilityDetector._apply_privilege_restrictions(caps, priv_info)

        return caps

    @staticmethod
    def _detect_linux_capabilities(
        caps: SystemCapabilities,
        os_info,
        priv_info,
    ) -> None:
        """Detect capabilities on Linux systems."""
        import shutil
        
        # Firewall checks always supported on Linux
        caps.firewall_check = True
        
        # Antivirus checks available
        caps.antivirus_check = True
        
        # Update checks via apt, yum, dnf, pacman
        update_tools = ["apt-get", "apt", "yum", "dnf", "pacman"]
        caps.update_check = any(shutil.which(tool) for tool in update_tools)
        
        # User/service checks
        caps.user_check = True
        caps.service_check = True
        caps.file_integrity = True
        
        # SELinux support (typically RHEL-based)
        caps.selinux_check = shutil.which("getenforce") is not None
        
        # AppArmor support (typically Ubuntu/Debian)
        caps.apparmor_check = shutil.which("aa-status") is not None or (
            shutil.which("apparmor_status") is not None
        )

    @staticmethod
    def _detect_windows_capabilities(
        caps: SystemCapabilities,
        os_info,
        priv_info,
    ) -> None:
        """Detect capabilities on Windows systems."""
        # Windows Firewall always present
        caps.firewall_check = True
        
        # Antivirus detection (Defender + third-party)
        caps.antivirus_check = True
        
        # Windows Update check
        caps.update_check = True
        
        # User enumeration
        caps.user_check = True
        
        # Service enumeration (via WMI or sc.exe)
        caps.service_check = True
        
        # File integrity checks
        caps.file_integrity = True
        
        # Windows-specific checks not applicable
        caps.selinux_check = False
        caps.apparmor_check = False

    @staticmethod
    def _detect_macos_capabilities(
        caps: SystemCapabilities,
        os_info,
        priv_info,
    ) -> None:
        """Detect capabilities on macOS systems."""
        # macOS firewall (pf, Application Firewall)
        caps.firewall_check = True
        
        # macOS antivirus (XProtect, third-party)
        caps.antivirus_check = True
        
        # macOS updates via softwareupdate
        caps.update_check = True
        
        # User enumeration
        caps.user_check = True
        
        # Services (launchd)
        caps.service_check = True
        
        # File integrity checks
        caps.file_integrity = True
        
        # Unix-specific checks not on macOS (but similar to Linux)
        caps.selinux_check = False
        caps.apparmor_check = False

    @staticmethod
    def _detect_unknown_capabilities(
        caps: SystemCapabilities,
        priv_info,
    ) -> None:
        """Detect capabilities on unknown/unsupported OS."""
        # Conservative: disable most checks on unknown OS
        caps.firewall_check = False
        caps.antivirus_check = False
        caps.update_check = False
        caps.selinux_check = False
        caps.apparmor_check = False
        caps.file_integrity = False
        
        # Still allow user/service enumeration
        caps.user_check = True
        caps.service_check = True

    @staticmethod
    def _apply_privilege_restrictions(
        caps: SystemCapabilities,
        priv_info,
    ) -> None:
        """
        Apply privilege-level restrictions to capabilities.
        
        Some checks may require root/admin privileges.
        """
        if not priv_info.is_elevated:
            # Non-root/admin users have limited capability
            # File integrity checks may fail without elevated privileges
            # This varies by system configuration
            caps.requires_root = True
        else:
            # Full capability when running as root/admin
            caps.requires_root = False

    @staticmethod
    def get_check_support(caps: SystemCapabilities) -> dict:
        """
        Get human-readable capability support summary.
        
        Returns:
            dict: Mapping of check name to supported status
        """
        return {
            "firewall": caps.firewall_check,
            "antivirus": caps.antivirus_check,
            "updates": caps.update_check,
            "users": caps.user_check,
            "services": caps.service_check,
            "file_integrity": caps.file_integrity,
            "selinux": caps.selinux_check,
            "apparmor": caps.apparmor_check,
        }
