"""
Real cloud credential detection from filesystem.
Searches ~/.aws, ~/.azure, environment variables, and common config files.
"""

import os
import platform
from pathlib import Path
from typing import Dict, List, Callable
import re
import time


class CredentialFinding:
    """Single credential finding."""
    def __init__(self, provider: str, location: str, credential_type: str, severity: str):
        self.provider = provider
        self.location = location
        self.credential_type = credential_type
        self.severity = severity


class SystemCredentialScanner:
    """
    Scan system for cloud credentials in standard locations.
    AWS: ~/.aws/credentials, ~/.aws/config
    Azure: ~/.azure, environment vars
    GCP: ~/.config/gcloud, environment vars
    """
    
    def __init__(self, progress_callback: Callable[[str], None] = None):
        self.progress_callback = progress_callback or self._default_progress
        self.findings: List[CredentialFinding] = []
        self.home_dir = str(Path.home())
        
    def _default_progress(self, msg: str):
        """Default progress output."""
        print(f"  > {msg}")
    
    def scan(self) -> Dict:
        """Scan for credentials."""
        self.progress_callback(f"Scanning for cloud credentials in {self.home_dir}")
        time.sleep(0.2)
        
        # Scan AWS
        self._scan_aws()
        time.sleep(0.1)
        
        # Scan Azure
        self._scan_azure()
        time.sleep(0.1)
        
        # Scan GCP
        self._scan_gcp()
        time.sleep(0.1)
        
        # Scan environment variables
        self._scan_env_vars()
        time.sleep(0.1)
        
        # Scan other locations
        self._scan_misc_credentials()
        
        # Group results
        return self._group_findings()
    
    def _scan_aws(self):
        """Scan for AWS credentials."""
        self.progress_callback("Checking AWS credentials...")
        
        aws_dir = os.path.join(self.home_dir, '.aws')
        if not os.path.exists(aws_dir):
            self.progress_callback("  AWS directory not found")
            return
        
        # Check credentials file
        cred_file = os.path.join(aws_dir, 'credentials')
        if os.path.exists(cred_file):
            try:
                with open(cred_file, 'r') as f:
                    content = f.read()
                    if 'aws_access_key_id' in content:
                        self.findings.append(CredentialFinding(
                            provider='AWS',
                            location=cred_file,
                            credential_type='Access Key ID',
                            severity='critical'
                        ))
                        self.progress_callback(f"  Found AWS access key in {cred_file}")
            except:
                pass
        
        # Check config file
        config_file = os.path.join(aws_dir, 'config')
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    content = f.read()
                    if 'region' in content:
                        self.findings.append(CredentialFinding(
                            provider='AWS',
                            location=config_file,
                            credential_type='Configuration',
                            severity='medium'
                        ))
                        self.progress_callback(f"  Found AWS config in {config_file}")
            except:
                pass
    
    def _scan_azure(self):
        """Scan for Azure credentials."""
        self.progress_callback("Checking Azure credentials...")
        
        azure_dir = os.path.join(self.home_dir, '.azure')
        if not os.path.exists(azure_dir):
            self.progress_callback("  Azure directory not found")
            return
        
        # Check for token cache
        token_file = os.path.join(azure_dir, 'msal_token_cache.json')
        if os.path.exists(token_file):
            self.findings.append(CredentialFinding(
                provider='Azure',
                location=token_file,
                credential_type='Token Cache',
                severity='high'
            ))
            self.progress_callback(f"  Found Azure token cache in {token_file}")
        
        # Check config files
        config_file = os.path.join(azure_dir, 'config')
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    content = f.read()
                    if 'subscription' in content:
                        self.findings.append(CredentialFinding(
                            provider='Azure',
                            location=config_file,
                            credential_type='Configuration',
                            severity='medium'
                        ))
                        self.progress_callback(f"  Found Azure config in {config_file}")
            except:
                pass
    
    def _scan_gcp(self):
        """Scan for GCP credentials."""
        self.progress_callback("Checking GCP credentials...")
        
        gcp_dir = os.path.join(self.home_dir, '.config', 'gcloud')
        if not os.path.exists(gcp_dir):
            return
        
        # Check for service account key
        for root, dirs, files in os.walk(gcp_dir):
            for file in files:
                if file.endswith('.json'):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r') as f:
                            content = f.read()
                            if 'service_account_email' in content or 'private_key_id' in content:
                                self.findings.append(CredentialFinding(
                                    provider='GCP',
                                    location=file_path,
                                    credential_type='Service Account',
                                    severity='critical'
                                ))
                                self.progress_callback(f"  Found GCP service account in {file}")
                    except:
                        pass
    
    def _scan_env_vars(self):
        """Scan environment variables for credentials."""
        self.progress_callback("Checking environment variables...")
        
        suspicious_vars = [
            'AWS_ACCESS_KEY_ID',
            'AWS_SECRET_ACCESS_KEY',
            'AZURE_CLIENT_ID',
            'AZURE_CLIENT_SECRET',
            'AZURE_SUBSCRIPTION_ID',
            'GOOGLE_APPLICATION_CREDENTIALS',
            'GITHUB_TOKEN',
            'GITHUB_PAT',
            'API_KEY',
            'SECRET_KEY',
            'DATABASE_URL',
            'SLACK_TOKEN',
            'DISCORD_TOKEN',
        ]
        
        found_count = 0
        for var in suspicious_vars:
            if var in os.environ:
                provider = var.split('_')[0]
                self.findings.append(CredentialFinding(
                    provider=provider,
                    location='Environment Variable',
                    credential_type=var,
                    severity='high'
                ))
                found_count += 1
        
        if found_count > 0:
            self.progress_callback(f"  Found {found_count} sensitive environment variables")
    
    def _scan_misc_credentials(self):
        """Scan misc locations for credentials."""
        self.progress_callback("Checking misc credential locations...")
        
        # Check for SSH keys
        ssh_dir = os.path.join(self.home_dir, '.ssh')
        if os.path.exists(ssh_dir):
            ssh_keys = []
            try:
                for file in os.listdir(ssh_dir):
                    if not file.endswith('.pub'):
                        ssh_keys.append(os.path.join(ssh_dir, file))
                
                if ssh_keys:
                    self.findings.append(CredentialFinding(
                        provider='SSH',
                        location=ssh_dir,
                        credential_type='Private Keys',
                        severity='high'
                    ))
                    self.progress_callback(f"  Found {len(ssh_keys)} SSH private keys")
            except:
                pass
        
        # Check for .env files
        common_env_locations = [
            os.path.join(self.home_dir, '.env'),
            os.path.join(self.home_dir, 'projects', '.env'),
            os.path.join(self.home_dir, 'code', '.env'),
            os.path.join(self.home_dir, 'work', '.env'),
        ]
        
        for env_file in common_env_locations:
            if os.path.exists(env_file):
                try:
                    with open(env_file, 'r') as f:
                        content = f.read()
                        if any(key in content for key in ['KEY=', 'SECRET=', 'PASSWORD=', 'TOKEN=']):
                            self.findings.append(CredentialFinding(
                                provider='Application',
                                location=env_file,
                                credential_type='.env file',
                                severity='high'
                            ))
                            self.progress_callback(f"  Found credentials in {env_file}")
                except:
                    pass
    
    def _group_findings(self) -> Dict:
        """Group findings by provider."""
        grouped = {
            'found': len(self.findings) > 0,
            'credentials': self.findings,
            'summary': {}
        }
        
        # Count by provider
        for finding in self.findings:
            provider = finding.provider
            if provider not in grouped['summary']:
                grouped['summary'][provider] = 0
            grouped['summary'][provider] += 1
        
        return grouped


def scan_cloud_credentials(progress_callback: Callable = None) -> Dict:
    """Main entry point for credential scanning."""
    scanner = SystemCredentialScanner(progress_callback)
    return scanner.scan()


if __name__ == "__main__":
    def progress(msg):
        print(f"[PROGRESS] {msg}")
    
    results = scan_cloud_credentials(progress)
    if results['found']:
        print(f"\n[CREDENTIALS FOUND]")
        print(f"Summary: {results['summary']}")
        for finding in results['credentials']:
            print(f"  {finding.provider}: {finding.credential_type} at {finding.location}")
    else:
        print("\n[NO CREDENTIALS FOUND]")
