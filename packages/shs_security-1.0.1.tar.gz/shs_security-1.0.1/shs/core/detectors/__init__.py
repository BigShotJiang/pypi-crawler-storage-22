"""Detectors module - OS-level state detection with verification."""
