"""
Real OS-level antivirus/endpoint protection status detection.
Uses actual OS commands to verify antivirus/security software state.
"""

import subprocess
import platform
import shutil
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class AntivirusStatus(Enum):
    """Antivirus service state."""
    RUNNING = "running"
    STOPPED = "stopped"
    UNKNOWN = "unknown"
    NOT_FOUND = "not_found"
    ERROR = "error"


@dataclass
class AntivirusDetectionResult:
    """Result from antivirus detection."""
    status: AntivirusStatus
    product_name: str
    verified: bool
    method_used: str
    details: str
    confidence: float  # 0-100%


def detect_antivirus(debug: bool = False) -> AntivirusDetectionResult:
    """
    Detect antivirus status using real OS commands.
    
    Windows: Get-MpComputerStatus, Get-Service WinDefend
    Linux: Check clamd, rkhunter, ClamAV
    """
    os_name = platform.system()
    
    if os_name == "Windows":
        return _detect_windows_antivirus(debug)
    elif os_name == "Linux":
        return _detect_linux_antivirus(debug)
    elif os_name == "Darwin":  # macOS
        return _detect_macos_antivirus(debug)
    else:
        return AntivirusDetectionResult(
            status=AntivirusStatus.UNKNOWN,
            product_name="Unknown OS",
            verified=False,
            method_used="unknown_os",
            details=f"OS not supported: {os_name}",
            confidence=0.0
        )


def _detect_windows_antivirus(debug: bool) -> AntivirusDetectionResult:
    """
    Windows: Use Get-MpComputerStatus to check Windows Defender.
    
    Also check for third-party antivirus via WMI or registry.
    """
    try:
        # Method 1: Windows Defender (built-in)
        ps_cmd = """
        $defender = Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($defender) {
            $defender | Select-Object AntivirusEnabled, AntispywareEnabled, RealTimeProtectionEnabled
        }
        """
        
        result = subprocess.run(
            ["powershell", "-Command", ps_cmd],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if debug:
            print("[DEBUG] === WINDOWS ANTIVIRUS DETECTION ===")
            print(f"[DEBUG] METHOD 1: Get-MpComputerStatus")
            print(f"[DEBUG] Return code: {result.returncode}")
            print(f"[DEBUG] Output:\n{result.stdout}")
        
        if result.returncode == 0 and result.stdout.strip():
            # Parse output
            av_enabled = "True" in result.stdout
            aw_enabled = "True" in result.stdout
            rtp_enabled = "True" in result.stdout
            
            if debug:
                print(f"[DEBUG] AntivirusEnabled: {av_enabled}")
                print(f"[DEBUG] AntispywareEnabled: {aw_enabled}")
                print(f"[DEBUG] RealTimeProtectionEnabled: {rtp_enabled}")
            
            # Windows Defender is running if any protection is enabled
            status = AntivirusStatus.RUNNING if (av_enabled or aw_enabled or rtp_enabled) else AntivirusStatus.STOPPED
            
            # Method 2: Service status
            svc_result = subprocess.run(
                ["powershell", "-Command", "Get-Service WinDefend | Select-Object Status"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if debug:
                print(f"[DEBUG] METHOD 2: Service WinDefend status")
                print(f"[DEBUG] Output:\n{svc_result.stdout}")
            
            svc_running = "Running" in svc_result.stdout if svc_result.returncode == 0 else False
            verified = (status == AntivirusStatus.RUNNING) == svc_running
            
            if debug:
                print(f"[DEBUG] Service running: {svc_running}, verified: {verified}")
            
            return AntivirusDetectionResult(
                status=status,
                product_name="Windows Defender",
                verified=verified,
                method_used="PowerShell + Service",
                details=f"AV:{av_enabled}, ASW:{aw_enabled}, RTP:{rtp_enabled}",
                confidence=100.0 if verified else 80.0
            )
        else:
            if debug:
                print("[DEBUG] Get-MpComputerStatus not available or failed")
            
            # Fall back to service check
            svc_result = subprocess.run(
                ["powershell", "-Command", "Get-Service WinDefend | Select-Object Status"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if svc_result.returncode == 0:
                status = AntivirusStatus.RUNNING if "Running" in svc_result.stdout else AntivirusStatus.STOPPED
                return AntivirusDetectionResult(
                    status=status,
                    product_name="Windows Defender",
                    verified=True,
                    method_used="Service Status",
                    details=svc_result.stdout.strip(),
                    confidence=90.0
                )
            else:
                return AntivirusDetectionResult(
                    status=AntivirusStatus.NOT_FOUND,
                    product_name="Windows Defender",
                    verified=False,
                    method_used="service_check_failed",
                    details="Could not determine service status",
                    confidence=0.0
                )
    
    except Exception as e:
        return AntivirusDetectionResult(
            status=AntivirusStatus.ERROR,
            product_name="Unknown",
            verified=False,
            method_used="windows_exception",
            details=str(e),
            confidence=0.0
        )


def _detect_linux_antivirus(debug: bool) -> AntivirusDetectionResult:
    """
    Linux: Comprehensive antivirus and security software detection.
    Checks for: ClamAV, rkhunter, chkrootkit, ESET, Norton, Kaspersky, Bitdefender,
    McAfee, OSSEC, Tripwire, AIDE, Osquery, Auditd, Falco, Wazuh, Sophos, Trend Micro, AVG, Avast
    """
    import shutil
    
    if debug:
        print("[DEBUG] === LINUX ANTIVIRUS DETECTION ===")
    
    try:
        detected_tools = []
        
        # Comprehensive list of antivirus/security tools to check
        # Format: (binary/service, product_name, check_type)
        security_tools = [
            # Antivirus Engines
            ("clamd", "ClamAV", "service"),
            ("freshclam", "ClamAV Update", "binary"),
            ("esets_daemon", "ESET Antivirus", "service"),
            ("livenortond", "Norton Lifelock", "service"),
            ("kav", "Kaspersky", "binary"),
            ("bitdefender-scan", "Bitdefender", "binary"),
            ("mcafeefw", "McAfee", "service"),
            ("sophos-av", "Sophos Antivirus", "service"),
            ("trendmicro", "Trend Micro", "service"),
            ("avgd", "AVG/Avast", "service"),
            ("avast", "Avast Antivirus", "binary"),
            ("savd", "Sophos Daemon", "service"),
            
            # Rootkit/Malware Scanners
            ("rkhunter", "Rootkit Hunter", "binary"),
            ("chkrootkit", "Chkrootkit", "binary"),
            ("aide", "AIDE (File Integrity)", "binary"),
            ("tripwire", "Tripwire (File Integrity)", "binary"),
            
            # Security Monitoring/Detection
            ("osqueryd", "Osquery", "service"),
            ("osqueryi", "Osquery", "binary"),
            ("auditd", "Linux Audit Daemon", "service"),
            ("falco", "Falco (Runtime Security)", "service"),
            ("wazuh-agent", "Wazuh Agent", "service"),
            ("ossec", "OSSEC HIDS", "service"),
            
            # Intrusion Detection
            ("snort", "Snort IDS", "service"),
            ("suricata", "Suricata IDS", "service"),
            ("zeek", "Zeek IDS", "binary"),
            
            # EDR/XDR
            ("crowdstrike", "CrowdStrike Falcon", "service"),
            ("sentinel-agent", "Microsoft Sentinel", "service"),
            ("elastic-defend", "Elastic Defend", "service"),
        ]
        
        # METHOD 1: Check if binaries exist in PATH
        if debug:
            print("[DEBUG] METHOD 1: Checking for binaries in PATH")
        
        for binary, product, check_type in security_tools:
            if check_type == "binary" and shutil.which(binary):
                detected_tools.append(product)
                if debug:
                    print(f"[DEBUG]   FOUND: {product} ({binary})")
        
        # METHOD 2: Check systemctl for active services
        if shutil.which("systemctl"):
            if debug:
                print("[DEBUG] METHOD 2: Checking systemctl for active services")
            
            for service, product, check_type in security_tools:
                if check_type == "service":
                    try:
                        result = subprocess.run(
                            ["systemctl", "is-active", service],
                            capture_output=True,
                            text=True,
                            timeout=3
                        )
                        
                        if result.returncode == 0 and "active" in result.stdout.lower():
                            if product not in detected_tools:
                                detected_tools.append(product)
                            if debug:
                                print(f"[DEBUG]   RUNNING: {product} ({service})")
                    except Exception:
                        pass
        
        # METHOD 3: Check installed packages (better error handling)
        if debug:
            print("[DEBUG] METHOD 3: Checking installed packages")
        
        package_tools = [
            ("clamav", "ClamAV"),
            ("rkhunter", "Rootkit Hunter"),
            ("chkrootkit", "Chkrootkit"),
            ("aide", "AIDE"),
            ("tripwire", "Tripwire"),
            ("osquery", "Osquery"),
            ("auditd", "Linux Audit Daemon"),
            ("falco", "Falco"),
            ("wazuh-agent", "Wazuh"),
            ("ossec-hids", "OSSEC"),
            ("snort", "Snort"),
            ("suricata", "Suricata"),
            ("zeek", "Zeek"),
            ("eset", "ESET"),
            ("norton", "Norton"),
            ("kaspersky", "Kaspersky"),
            ("bitdefender", "Bitdefender"),
            ("mcafee", "McAfee"),
            ("sophos", "Sophos"),
            ("avg", "AVG"),
            ("avast", "Avast"),
        ]
        
        # Check apt-cache (Debian/Ubuntu)
        if shutil.which("apt-cache"):
            try:
                result = subprocess.run(
                    ["apt-cache", "search", "--names-only", "^" + "$|^".join([p[0] for p in package_tools]) + "$"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode == 0:
                    for pkg, product in package_tools:
                        if pkg in result.stdout and product not in detected_tools:
                            detected_tools.append(product)
                            if debug:
                                print(f"[DEBUG]   INSTALLED: {product} ({pkg})")
            except Exception as e:
                if debug:
                    print(f"[DEBUG]   apt-cache check failed: {e}")
        
        # Check rpm (RedHat/CentOS)
        if shutil.which("rpm"):
            try:
                result = subprocess.run(
                    ["rpm", "-qa"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode == 0:
                    rpm_output = result.stdout.lower()
                    for pkg, product in package_tools:
                        if pkg in rpm_output and product not in detected_tools:
                            detected_tools.append(product)
                            if debug:
                                print(f"[DEBUG]   INSTALLED: {product} ({pkg})")
            except Exception as e:
                if debug:
                    print(f"[DEBUG]   rpm check failed: {e}")
        
        if debug:
            print(f"[DEBUG] Total security tools detected: {len(detected_tools)}")
            if detected_tools:
                print(f"[DEBUG] Tools: {', '.join(detected_tools)}")
        
        # Return result based on findings
        if detected_tools:
            product_str = ", ".join(detected_tools[:3])  # Show first 3
            if len(detected_tools) > 3:
                product_str += f" + {len(detected_tools) - 3} more"
            
            return AntivirusDetectionResult(
                status=AntivirusStatus.RUNNING,
                product_name=product_str,
                verified=True,
                method_used="comprehensive_scan",
                details=f"Found {len(detected_tools)} security tools: {', '.join(detected_tools)}",
                confidence=100.0 * min(len(detected_tools) / 3, 1.0)  # Scale confidence by number of tools
            )
        else:
            return AntivirusDetectionResult(
                status=AntivirusStatus.NOT_FOUND,
                product_name="None detected",
                verified=True,
                method_used="comprehensive_scan",
                details="No antivirus/security software detected",
                confidence=90.0
            )
        
    except Exception as e:
        return AntivirusDetectionResult(
            status=AntivirusStatus.ERROR,
            product_name="Unknown",
            verified=False,
            method_used="linux_exception",
            details=str(e),
            confidence=0.0
        )


def _detect_macos_antivirus(debug: bool) -> AntivirusDetectionResult:
    """
    macOS: Check for XProtect and third-party AV.
    """
    try:
        # Check XProtect status
        result = subprocess.run(
            ["ls", "-la", "/Library/Apple/System/Library/CoreServices/XProtect.bundle"],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if debug:
            print("[DEBUG] === MACOS ANTIVIRUS DETECTION ===")
            print(f"[DEBUG] XProtect check: {result.returncode}")
        
        xprotect_installed = result.returncode == 0
        
        return AntivirusDetectionResult(
            status=AntivirusStatus.RUNNING if xprotect_installed else AntivirusStatus.STOPPED,
            product_name="XProtect" if xprotect_installed else "None",
            verified=True,
            method_used="filesystem_check",
            details="macOS XProtect is built-in",
            confidence=90.0
        )
        
    except Exception as e:
        return AntivirusDetectionResult(
            status=AntivirusStatus.ERROR,
            product_name="Unknown",
            verified=False,
            method_used="macos_exception",
            details=str(e),
            confidence=0.0
        )


if __name__ == "__main__":
    result = detect_antivirus(debug=True)
    print(f"\n[RESULT] Status: {result.status.value}")
    print(f"[RESULT] Product: {result.product_name}")
    print(f"[RESULT] Verified: {result.verified}")
    print(f"[RESULT] Confidence: {result.confidence}%")
    print(f"[RESULT] Details: {result.details}")
