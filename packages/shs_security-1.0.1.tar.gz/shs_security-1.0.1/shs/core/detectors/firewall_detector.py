"""Real firewall status detection with verification layers and debug output.

This module uses actual OS-level commands to detect firewall status.
It NEVER assumes values - it verifies with 2+ methods.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional, Tuple


class FirewallStatus(Enum):
    """Firewall operational status."""
    ENABLED = "enabled"
    DISABLED = "disabled"
    UNKNOWN = "unknown"
    ERROR = "error"


@dataclass
class FirewallDetectionResult:
    """Result of firewall detection."""
    status: FirewallStatus
    methods_used: list[str]  # Which detection methods were tried
    verified: bool  # Whether status was verified by 2+ independent methods
    details: Dict[str, str]  # Raw output and parsed data
    confidence: float  # 0.0-1.0, higher = more reliable


def detect_firewall(debug: bool = False) -> FirewallDetectionResult:
    """
    Detect firewall status with real OS-level commands.
    
    Args:
        debug: If True, print detailed debug info
        
    Returns:
        FirewallDetectionResult with status and verification details
    """
    import platform
    
    os_type = platform.system()
    
    if debug:
        print(f"[DEBUG] OS detected: {os_type}", file=sys.stderr)
    
    if os_type == "Windows":
        return _detect_windows_firewall(debug=debug)
    elif os_type == "Linux":
        return _detect_linux_firewall(debug=debug)
    elif os_type == "Darwin":
        return _detect_macos_firewall(debug=debug)
    else:
        return FirewallDetectionResult(
            status=FirewallStatus.UNKNOWN,
            methods_used=[],
            verified=False,
            details={"error": f"Unsupported OS: {os_type}"},
            confidence=0.0
        )


def _detect_windows_firewall(debug: bool = False) -> FirewallDetectionResult:
    """Detect Windows Firewall (WinDefender Firewall) status.
    
    Windows Firewall has three profiles: Domain, Private, Public.
    All must be checked separately.
    """
    if debug:
        print("\n[DEBUG] === WINDOWS FIREWALL DETECTION ===", file=sys.stderr)
    
    methods_used = []
    details = {}
    all_on = []
    all_off = []
    
    # METHOD 1: netsh advfirewall show allprofiles state
    method1_name = "netsh_allprofiles_state"
    methods_used.append(method1_name)
    
    if debug:
        print(f"[DEBUG] METHOD 1: netsh advfirewall show allprofiles state", file=sys.stderr)
    
    rc, output = _run_command("netsh advfirewall show allprofiles state")
    
    if debug:
        print(f"[DEBUG]   Return code: {rc}", file=sys.stderr)
        print(f"[DEBUG]   Raw output:\n{output}", file=sys.stderr)
    
    details[method1_name + "_rc"] = str(rc)
    details[method1_name + "_output"] = output
    
    if rc == 0 and output:
        # Parse profiles
        profiles = {
            "Domain": None,
            "Private": None,
            "Public": None
        }
        
        for line in output.split("\n"):
            line = line.strip()
            if "Domain Profile" in line:
                if "State" in output[output.find(line):output.find(line)+200]:
                    for subline in output[output.find(line):].split("\n")[:3]:
                        if "State" in subline and ("On" in subline or "Off" in subline):
                            state = "On" in subline
                            profiles["Domain"] = state
                            if debug:
                                print(f"[DEBUG]   Domain Profile: {state}", file=sys.stderr)
                            break
            elif "Private Profile" in line:
                for subline in output[output.find(line):].split("\n")[:3]:
                    if "State" in subline and ("On" in subline or "Off" in subline):
                        state = "On" in subline
                        profiles["Private"] = state
                        if debug:
                            print(f"[DEBUG]   Private Profile: {state}", file=sys.stderr)
                        break
            elif "Public Profile" in line:
                for subline in output[output.find(line):].split("\n")[:3]:
                    if "State" in subline and ("On" in subline or "Off" in subline):
                        state = "On" in subline
                        profiles["Public"] = state
                        if debug:
                            print(f"[DEBUG]   Public Profile: {state}", file=sys.stderr)
                        break
        
        details["profiles"] = str(profiles)
        
        # Check if ANY profile is ON (firewall is enabled)
        enabled_profiles = [name for name, state in profiles.items() if state is True]
        disabled_profiles = [name for name, state in profiles.items() if state is False]
        
        if enabled_profiles:
            all_on.append(f"{method1_name}:enabled_profiles={enabled_profiles}")
        if disabled_profiles:
            all_off.append(f"{method1_name}:disabled_profiles={disabled_profiles}")
    
    # METHOD 2: PowerShell Get-NetFirewallProfile
    method2_name = "powershell_netfirewallprofile"
    methods_used.append(method2_name)
    
    if debug:
        print(f"\n[DEBUG] METHOD 2: powershell Get-NetFirewallProfile", file=sys.stderr)
    
    rc, output = _run_command(
        "powershell -NoProfile -Command \"Get-NetFirewallProfile -PolicyStore ActiveStore | Select-Object Name,Enabled | Format-List 2>$null\""
    )
    
    if debug:
        print(f"[DEBUG]   Return code: {rc}", file=sys.stderr)
        print(f"[DEBUG]   Raw output:\n{output}", file=sys.stderr)
    
    details[method2_name + "_rc"] = str(rc)
    details[method2_name + "_output"] = output
    
    if rc == 0 and output:
        # Parse "Name : X" and "Enabled : True/False"
        enabled_count = output.count("Enabled : True")
        disabled_count = output.count("Enabled : False")
        
        if debug:
            print(f"[DEBUG]   Enabled profiles: {enabled_count}", file=sys.stderr)
            print(f"[DEBUG]   Disabled profiles: {disabled_count}", file=sys.stderr)
        
        if enabled_count > 0:
            all_on.append(f"{method2_name}:enabled_count={enabled_count}")
        if disabled_count > 0:
            all_off.append(f"{method2_name}:disabled_count={disabled_count}")
    
    # DECISION LOGIC
    if debug:
        print(f"\n[DEBUG] === DECISION ===", file=sys.stderr)
        print(f"[DEBUG] Methods reporting ON:  {all_on}", file=sys.stderr)
        print(f"[DEBUG] Methods reporting OFF: {all_off}", file=sys.stderr)
    
    # Firewall is ON if ANY method reports it on AND it's verified (2+ methods agree)
    verified = len(all_on) > 0 and len(all_off) == 0
    firewall_on = len(all_on) > 0
    confidence = len(all_on) / float(len(methods_used)) if len(methods_used) > 0 else 0.0
    
    status = FirewallStatus.ENABLED if firewall_on else FirewallStatus.DISABLED
    
    if debug:
        print(f"[DEBUG] Final status: {status.value}", file=sys.stderr)
        print(f"[DEBUG] Verified: {verified}", file=sys.stderr)
        print(f"[DEBUG] Confidence: {confidence:.1%}", file=sys.stderr)
    
    return FirewallDetectionResult(
        status=status,
        methods_used=methods_used,
        verified=verified,
        details=details,
        confidence=confidence
    )


def _detect_linux_firewall(debug: bool = False) -> FirewallDetectionResult:
    """Detect Linux firewall (ufw, firewalld, iptables, nftables) status."""
    if debug:
        print("\n[DEBUG] === LINUX FIREWALL DETECTION ===", file=sys.stderr)
    
    methods_used = []
    details = {}
    all_on = []
    all_off = []
    firewall_tools = {}  # Track which tools are active
    
    # METHOD 1: ufw status
    if shutil.which("ufw"):
        method_name = "ufw_status"
        methods_used.append(method_name)
        
        if debug:
            print(f"[DEBUG] METHOD: ufw status", file=sys.stderr)
        
        rc, output = _run_command("ufw status 2>/dev/null")
        
        if debug:
            print(f"[DEBUG]   Return code: {rc}", file=sys.stderr)
            print(f"[DEBUG]   Output: {output.strip()}", file=sys.stderr)
        
        details[method_name + "_rc"] = str(rc)
        details[method_name + "_output"] = output.strip()
        
        if rc == 0:
            if "Status: active" in output:
                all_on.append("ufw:active")
                firewall_tools["ufw"] = "active"
                if debug:
                    print(f"[DEBUG]   Result: ENABLED", file=sys.stderr)
            elif "Status: inactive" in output:
                all_off.append("ufw:inactive")
                firewall_tools["ufw"] = "inactive"
                if debug:
                    print(f"[DEBUG]   Result: DISABLED", file=sys.stderr)
    
    # METHOD 2: firewall-cmd --state (firewalld)
    if shutil.which("firewall-cmd"):
        method_name = "firewalld_state"
        methods_used.append(method_name)
        
        if debug:
            print(f"[DEBUG] METHOD: firewall-cmd --state", file=sys.stderr)
        
        rc, output = _run_command("firewall-cmd --state 2>/dev/null")
        
        if debug:
            print(f"[DEBUG]   Return code: {rc}", file=sys.stderr)
            print(f"[DEBUG]   Output: {output.strip()}", file=sys.stderr)
        
        details[method_name + "_rc"] = str(rc)
        details[method_name + "_output"] = output.strip()
        
        if rc == 0:
            if "running" in output.lower():
                all_on.append("firewalld:running")
                firewall_tools["firewalld"] = "running"
                if debug:
                    print(f"[DEBUG]   Result: ENABLED", file=sys.stderr)
            elif "not running" in output.lower():
                all_off.append("firewalld:not_running")
                firewall_tools["firewalld"] = "not_running"
                if debug:
                    print(f"[DEBUG]   Result: DISABLED", file=sys.stderr)
    
    # METHOD 3: iptables status (check if rules exist)
    if shutil.which("iptables"):
        method_name = "iptables_rules"
        methods_used.append(method_name)
        
        if debug:
            print(f"[DEBUG] METHOD: iptables -L -n", file=sys.stderr)
        
        rc, output = _run_command("iptables -L -n 2>/dev/null || sudo -n iptables -L -n 2>/dev/null")
        
        if debug:
            print(f"[DEBUG]   Return code: {rc}", file=sys.stderr)
            print(f"[DEBUG]   Output lines: {len(output.split(chr(10)))}", file=sys.stderr)
        
        details[method_name + "_rc"] = str(rc)
        details[method_name + "_output"] = f"Lines: {len(output.split(chr(10)))}"
        
        if rc == 0:
            # Check for any non-default rules
            has_rules = output.count("ACCEPT") > 2 or output.count("DROP") > 0 or output.count("REJECT") > 0
            if has_rules:
                all_on.append("iptables:rules_configured")
                firewall_tools["iptables"] = "rules_active"
                if debug:
                    print(f"[DEBUG]   Result: ENABLED (rules found)", file=sys.stderr)
            else:
                all_off.append("iptables:default_rules")
                firewall_tools["iptables"] = "default_rules"
                if debug:
                    print(f"[DEBUG]   Result: DISABLED (default rules only)", file=sys.stderr)
    
    # METHOD 4: nftables status (check if rules exist)
    if shutil.which("nft"):
        method_name = "nftables_rules"
        methods_used.append(method_name)
        
        if debug:
            print(f"[DEBUG] METHOD: nft list ruleset", file=sys.stderr)
        
        rc, output = _run_command("nft list ruleset 2>/dev/null || sudo -n nft list ruleset 2>/dev/null")
        
        if debug:
            print(f"[DEBUG]   Return code: {rc}", file=sys.stderr)
            print(f"[DEBUG]   Output lines: {len(output.split(chr(10)))}", file=sys.stderr)
        
        details[method_name + "_rc"] = str(rc)
        details[method_name + "_output"] = f"Lines: {len(output.split(chr(10)))}"
        
        if rc == 0:
            # Check for any rules (nft output is verbose)
            has_rules = "rule" in output.lower() or "chain" in output.lower()
            if has_rules and len(output.strip()) > 50:
                all_on.append("nftables:rules_configured")
                firewall_tools["nftables"] = "rules_active"
                if debug:
                    print(f"[DEBUG]   Result: ENABLED (rules found)", file=sys.stderr)
            else:
                all_off.append("nftables:no_rules")
                firewall_tools["nftables"] = "no_rules"
                if debug:
                    print(f"[DEBUG]   Result: DISABLED (no rules)", file=sys.stderr)
    
    # METHOD 5: Check systemctl for firewall services
    firewall_services = ["ufw", "firewalld", "iptables", "nftables"]
    for service in firewall_services:
        if shutil.which("systemctl"):
            method_name = f"systemctl_{service}"
            
            rc, output = _run_command(f"systemctl is-active {service} 2>/dev/null")
            
            if debug:
                print(f"[DEBUG] METHOD: systemctl is-active {service}", file=sys.stderr)
                print(f"[DEBUG]   Return code: {rc}, Output: {output.strip()}", file=sys.stderr)
            
            details[method_name + "_rc"] = str(rc)
            details[method_name + "_output"] = output.strip()
            
            if rc == 0 and "active" in output.lower():
                all_on.append(f"{service}:active")
                firewall_tools[service] = "active"
                methods_used.append(method_name)
                if debug:
                    print(f"[DEBUG]   Result: {service} is ACTIVE", file=sys.stderr)
    
    if debug:
        print(f"\n[DEBUG] === DECISION ===", file=sys.stderr)
        print(f"[DEBUG] Methods reporting ON:  {all_on}", file=sys.stderr)
        print(f"[DEBUG] Methods reporting OFF: {all_off}", file=sys.stderr)
        print(f"[DEBUG] Firewall tools detected: {firewall_tools}", file=sys.stderr)
    
    firewall_on = len(all_on) > 0
    verified = len(all_on) > 0 or len(all_off) > 0  # At least one method gave clear answer
    confidence = len(all_on) / float(len(methods_used)) if len(methods_used) > 0 else 0.0
    
    status = FirewallStatus.ENABLED if firewall_on else (FirewallStatus.DISABLED if verified else FirewallStatus.UNKNOWN)
    
    # Add tool summary to details
    details["firewall_tools_detected"] = str(firewall_tools)
    
    if debug:
        print(f"[DEBUG] Final status: {status.value}", file=sys.stderr)
        print(f"[DEBUG] Verified: {verified}", file=sys.stderr)
        print(f"[DEBUG] Confidence: {confidence:.1%}", file=sys.stderr)
    
    return FirewallDetectionResult(
        status=status,
        methods_used=methods_used,
        verified=verified,
        details=details,
        confidence=confidence
    )


def _detect_macos_firewall(debug: bool = False) -> FirewallDetectionResult:
    """Detect macOS firewall (pf, Application Firewall) status."""
    if debug:
        print("\n[DEBUG] === MACOS FIREWALL DETECTION ===", file=sys.stderr)
    
    methods_used = []
    details = {}
    all_on = []
    all_off = []
    
    # METHOD 1: defaults read com.apple.alf globalstate
    method_name = "appfirewall_globalstate"
    methods_used.append(method_name)
    
    if debug:
        print(f"[DEBUG] METHOD: defaults read /Library/Preferences/com.apple.alf globalstate", file=sys.stderr)
    
    rc, output = _run_command(
        "defaults read /Library/Preferences/com.apple.alf globalstate 2>/dev/null"
    )
    
    if debug:
        print(f"[DEBUG]   Return code: {rc}", file=sys.stderr)
        print(f"[DEBUG]   Output: {output.strip()}", file=sys.stderr)
    
    details[method_name + "_rc"] = str(rc)
    details[method_name + "_output"] = output.strip()
    
    if rc == 0:
        try:
            state_val = int(output.strip())
            if state_val == 1:
                all_on.append("appfirewall:enabled")
                if debug:
                    print(f"[DEBUG]   Result: ENABLED (value=1)", file=sys.stderr)
            elif state_val == 0:
                all_off.append("appfirewall:disabled")
                if debug:
                    print(f"[DEBUG]   Result: DISABLED (value=0)", file=sys.stderr)
        except ValueError:
            pass
    
    if debug:
        print(f"\n[DEBUG] === DECISION ===", file=sys.stderr)
        print(f"[DEBUG] Methods reporting ON:  {all_on}", file=sys.stderr)
        print(f"[DEBUG] Methods reporting OFF: {all_off}", file=sys.stderr)
    
    firewall_on = len(all_on) > 0
    verified = len(all_on) > 0 or len(all_off) > 0
    confidence = len(all_on) / float(len(methods_used)) if len(methods_used) > 0 else 0.0
    
    status = FirewallStatus.ENABLED if firewall_on else (FirewallStatus.DISABLED if verified else FirewallStatus.UNKNOWN)
    
    if debug:
        print(f"[DEBUG] Final status: {status.value}", file=sys.stderr)
        print(f"[DEBUG] Verified: {verified}", file=sys.stderr)
        print(f"[DEBUG] Confidence: {confidence:.1%}", file=sys.stderr)
    
    return FirewallDetectionResult(
        status=status,
        methods_used=methods_used,
        verified=verified,
        details=details,
        confidence=confidence
    )


def _run_command(command: str) -> Tuple[int, str]:
    """Execute command and return (returncode, stdout+stderr)."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return -1, "[TIMEOUT]"
    except Exception as e:
        return -1, f"[ERROR: {e}]"
