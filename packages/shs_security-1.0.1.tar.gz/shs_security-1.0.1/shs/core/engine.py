from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import yaml
from colorama import Fore, Style, init as colorama_init

from .os_detector import OSDetector
from .privilege import PrivilegeDetector
from .capabilities import CapabilityDetector
from .remediation import auto_remediate
from .rules import Finding, RiskScore, Severity, calculate_risk, load_weights
from .scanner import Scanner


# -------------------------------
# PATHS (INSTALL-SAFE)
# -------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = BASE_DIR / "config" / "shs.yaml"
DEFAULT_DB_PATH = Path.home() / ".shs" / "shs.db"


class SHSEngine:
    def __init__(
        self,
        config_path: Path | None = None,
        db_path: Path | None = None,
        profile: str = "default",
    ) -> None:
        colorama_init(autoreset=True)

        self.config_path = config_path or DEFAULT_CONFIG_PATH
        self.db_path = db_path or DEFAULT_DB_PATH
        self.profile = profile

        self.config = self._load_config()
        self.weights = load_weights(self.config.get("risk_weights"))

        # Detect environment ONCE
        self.os_info = OSDetector.detect()
        self.privilege_info = PrivilegeDetector.detect()
        self.capabilities = CapabilityDetector.detect()

        # Scanner with enabled modules
        self.scanner = Scanner(
            enabled_modules=self._enabled_modules()
        )

        self._init_db()

    # -------------------------------
    # INFO
    # -------------------------------
    def _print_system_info(self) -> None:
        print(Fore.CYAN + f"[INFO] OS detected: {self.os_info.name}" + Style.RESET_ALL)

        if self.privilege_info.is_elevated:
            print(
                Fore.YELLOW
                + f"[WARN] Elevated privileges detected"
                + Style.RESET_ALL
            )
        else:
            print(
                Fore.GREEN
                + f"[INFO] Running as {self.privilege_info.level.value}"
                + Style.RESET_ALL
            )

    # -------------------------------
    # MAIN SCAN (4-PHASE PROFESSIONAL FLOW)
    # -------------------------------
    def run_scan(
        self,
        modules: Sequence[str] | None = None,
    ) -> Tuple[RiskScore, List[Finding]]:
        """
        Professional 4-phase scanning flow:
        Phase 1: Print all scanning steps (what will be scanned)
        Phase 2: Execute modules silently (collect findings only)
        Phase 3: Print findings after completion
        Phase 4: Print final score
        """
        start = time.time()

        # ============================================================================
        # PHASE 1: ANNOUNCE ALL SCANNING STEPS
        # ============================================================================
        self._print_scan_header()
        self.scanner.print_scanning_plan(modules)

        # ============================================================================
        # PHASE 2: EXECUTE MODULES SILENTLY (collect findings only, no output)
        # ============================================================================
        findings = self.scanner.run(modules)

        # Deduplicate findings by title and category
        unique_findings: Dict[Tuple[str, str], Finding] = {}
        for f in findings:
            key = (f.title, f.category)
            if key not in unique_findings:
                unique_findings[key] = f
        findings = list(unique_findings.values())

        score = calculate_risk(findings, self.weights)
        duration = time.time() - start

        # ============================================================================
        # PHASE 3: PRINT FINDINGS (after scan completes)
        # ============================================================================
        self._print_scan_complete(duration)
        self._print_findings(findings)

        # ============================================================================
        # PHASE 4: PRINT FINAL SCORE
        # ============================================================================
        self._print_score(score)

        # Persist to database
        scan_id = self._persist_scan(score, findings, duration, modules)

        return score, findings

    # -------------------------------
    # AUTO FIX
    # -------------------------------
    def run_fix(self) -> List[Finding]:
        findings = auto_remediate()
        for finding in findings:
            self._print_fix(finding)
        return findings

    # -------------------------------
    # LOAD LAST SCAN
    # -------------------------------
    def latest_scan(self) -> Tuple[Optional[int], Optional[RiskScore], List[Finding]]:
        if not self.db_path.exists():
            return None, None, []

        conn = sqlite3.connect(self.db_path)
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT id, score, label, explanation FROM scans ORDER BY started_at DESC LIMIT 1"
            )
            row = cur.fetchone()
            if not row:
                return None, None, []

            scan_id = int(row[0])
            score = RiskScore(score=int(row[1]), label=row[2], explanation=row[3])
            findings = self._load_findings(conn, scan_id)
            return scan_id, score, findings
        finally:
            conn.close()

    # -------------------------------
    # DB LOAD
    # -------------------------------
    def _load_findings(self, conn: sqlite3.Connection, scan_id: int) -> List[Finding]:
        cur = conn.cursor()
        cur.execute(
            """
            SELECT finding_id, title, severity, category,
                   description, recommendation, metadata
            FROM findings WHERE scan_id = ?
            """,
            (scan_id,),
        )

        rows = cur.fetchall()
        results: List[Finding] = []

        for row in rows:
            metadata = json.loads(row[6]) if row[6] else {}
            results.append(
                Finding(
                    id=row[0],
                    title=row[1],
                    severity=Severity(row[2]),
                    category=row[3],
                    description=row[4],
                    recommendation=row[5],
                    metadata=metadata,
                )
            )
        return results

    # -------------------------------
    # CONFIG
    # -------------------------------
    def _load_config(self) -> Dict[str, Any]:
        if not self.config_path.exists():
            return {}
        with self.config_path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def _enabled_modules(self) -> Iterable[str]:
        profiles = self.config.get("profiles") or {}
        profile_cfg = profiles.get(self.profile) or {}

        enabled = []
        for name in ("system", "network", "users", "files", "cloud", "apps"):
            section = profile_cfg.get(name) or {}
            if section.get("enabled", True):
                enabled.append(name)
        return enabled

    # -------------------------------
    # DB INIT
    # -------------------------------
    def _init_db(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path)
        try:
            cur = conn.cursor()

            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_at REAL NOT NULL,
                    duration REAL NOT NULL,
                    score INTEGER NOT NULL,
                    label TEXT NOT NULL,
                    explanation TEXT NOT NULL,
                    modules TEXT
                )
                """
            )

            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS findings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id INTEGER NOT NULL,
                    finding_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    category TEXT NOT NULL,
                    description TEXT NOT NULL,
                    recommendation TEXT NOT NULL,
                    metadata TEXT,
                    FOREIGN KEY(scan_id) REFERENCES scans(id) ON DELETE CASCADE
                )
                """
            )

            conn.commit()
        finally:
            conn.close()

    # -------------------------------
    # DB SAVE
    # -------------------------------
    def _persist_scan(
        self,
        score: RiskScore,
        findings: Iterable[Finding],
        duration: float,
        modules: Sequence[str] | None,
    ) -> int:
        conn = sqlite3.connect(self.db_path)
        try:
            cur = conn.cursor()
            started_at = time.time()
            modules_str = ",".join(modules) if modules else ""

            cur.execute(
                """
                INSERT INTO scans (started_at, duration, score, label, explanation, modules)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (started_at, duration, score.score, score.label, score.explanation, modules_str),
            )

            scan_id = int(cur.lastrowid)

            for finding in findings:
                cur.execute(
                    """
                    INSERT INTO findings (
                        scan_id, finding_id, title, severity, category,
                        description, recommendation, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        scan_id,
                        finding.id,
                        finding.title,
                        finding.severity.value,
                        finding.category,
                        finding.description,
                        finding.recommendation,
                        json.dumps(finding.metadata or {}),
                    ),
                )

            conn.commit()
            return scan_id
        finally:
            conn.close()

    # -------------------------------
    # OUTPUT (4-PHASE)
    # -------------------------------
    def _print_scan_header(self) -> None:
        """Phase 1: Print scan header with system info."""
        print()
        print(Fore.CYAN + "Security Hygiene Scanner (SHS)" + Style.RESET_ALL)
        print(Fore.CYAN + "-" * 40 + Style.RESET_ALL)
        print()
        
        # Print OS info with status
        os_status = f"{Fore.GREEN}VERIFIED{Style.RESET_ALL}"
        print(f"OS detected: {self.os_info.name:<30} {os_status}")
        
        # Print privilege info with status
        if self.privilege_info.is_elevated:
            priv_status = f"{Fore.YELLOW}ELEVATED{Style.RESET_ALL}"
        else:
            priv_status = f"{Fore.GREEN}SECURE{Style.RESET_ALL}"
        print(f"Privileges: {self.privilege_info.level.value:<30} {priv_status}")
        
        print()

    def _print_scan_complete(self, duration: float) -> None:
        """Phase 2->3 transition: Print scan completion message."""
        print(Fore.GREEN + f"Scan completed successfully in {duration:.2f}s" + Style.RESET_ALL)
        print(Fore.GREEN + "-" * 40 + Style.RESET_ALL)
        print()

    def _print_findings(self, findings: Iterable[Finding]) -> None:
        """Phase 3: Print findings grouped by severity."""
        items = list(findings)
        if not items:
            print(Fore.GREEN + "OK - No major hygiene issues found" + Style.RESET_ALL)
            print()
            return

        # Group by severity
        critical = [f for f in items if f.severity == Severity.CRITICAL]
        high = [f for f in items if f.severity == Severity.HIGH]
        medium = [f for f in items if f.severity == Severity.MEDIUM]
        low = [f for f in items if f.severity == Severity.LOW]
        info = [f for f in items if f.severity == Severity.INFO]

        # Print CRITICAL issues
        if critical:
            print(Fore.RED + "[CRITICAL] CRITICAL ISSUES" + Style.RESET_ALL)
            print(Fore.RED + "-" * 40 + Style.RESET_ALL)
            for f in critical:
                print(f"  * {f.title}")
                if f.metadata:
                    for key, value in f.metadata.items():
                        print(f"    | {key}: {value}")
            print()

        # Print HIGH RISK issues
        if high:
            print(Fore.MAGENTA + "[HIGH] HIGH RISK ISSUES" + Style.RESET_ALL)
            print(Fore.MAGENTA + "-" * 40 + Style.RESET_ALL)
            for f in high:
                print(f"  * {f.title}")
                if f.metadata:
                    for key, value in f.metadata.items():
                        print(f"    | {key}: {value}")
            print()

        # Print MEDIUM issues
        if medium:
            print(Fore.YELLOW + "[MEDIUM] MEDIUM ISSUES" + Style.RESET_ALL)
            print(Fore.YELLOW + "-" * 40 + Style.RESET_ALL)
            for f in medium:
                print(f"  * {f.title}")
                if f.metadata:
                    for key, value in f.metadata.items():
                        print(f"    | {key}: {value}")
            print()

        # Print LOW issues
        if low:
            print(Fore.CYAN + "[LOW] LOW ISSUES" + Style.RESET_ALL)
            print(Fore.CYAN + "-" * 40 + Style.RESET_ALL)
            for f in low:
                print(f"  * {f.title}")
                if f.metadata:
                    for key, value in f.metadata.items():
                        print(f"    | {key}: {value}")
            print()

        # Print INFO items
        if info:
            print(Fore.CYAN + "[INFO] ADDITIONAL INFORMATION" + Style.RESET_ALL)
            print(Fore.CYAN + "-" * 40 + Style.RESET_ALL)
            for f in info:
                print(f"  * {f.title}")
            print()

    def _severity_prefix(self, severity: Severity) -> str:
        label = f"[{severity.value}]"
        if severity is Severity.CRITICAL:
            return Fore.RED + label + Style.RESET_ALL
        if severity is Severity.HIGH:
            return Fore.MAGENTA + label + Style.RESET_ALL
        if severity is Severity.MEDIUM:
            return Fore.YELLOW + label + Style.RESET_ALL
        return Fore.CYAN + label + Style.RESET_ALL

    def _print_score(self, score: RiskScore) -> None:
        """Phase 4: Print final security score."""
        if score.score < 40:
            color = Fore.RED
            label_icon = "[CRITICAL]"
        elif score.score < 60:
            color = Fore.MAGENTA
            label_icon = "[HIGH]"
        elif score.score < 80:
            color = Fore.YELLOW
            label_icon = "[MEDIUM]"
        else:
            color = Fore.GREEN
            label_icon = "[GOOD]"

        print(color + f"{label_icon} Security Score: {score.score}% ({score.label})" + Style.RESET_ALL)
        print()

    def _print_fix(self, finding: Finding) -> None:
        print(f"[FIX] {finding.title} ({finding.description})")


def run(modules: Sequence[str] | None = None) -> None:
    """
    CLI entry point for SHS with optional module filtering.

    Prints banner and runs scan with 4-phase professional flow:
    Phase 1: Scanning plan with system info
    Phase 2: Execute modules silently
    Phase 3: Display findings
    Phase 4: Display final score
    """
    from shs.assets.banner import print_banner

    print_banner()
    engine = SHSEngine()
    engine.run_scan(modules=modules)
