"""
Enhanced engine integration with real-time progress output and live scanning phases.
Wraps the existing engine to add scanning progress visibility.
"""

import time
from typing import Sequence, Tuple, List
from colorama import Fore, Style

from shs.core.rules import Finding, RiskScore
from shs.core.progress_output import ScanningPhaseOutput
from shs.core.engine import SHSEngine


class EnhancedSHSEngine(SHSEngine):
    """
    Extended SHSEngine with real-time progress output.
    Manages two-phase output: scanning phase (with live progress) + findings phase.
    """
    
    def run_scan_with_progress(
        self,
        modules: Sequence[str] | None = None,
    ) -> Tuple[RiskScore, List[Finding]]:
        """
        Enhanced 4-phase scanning with live progress:
        Phase 1: Announce plan
        Phase 2: Execute with live progress output
        Phase 3: Display findings
        Phase 4: Display score
        """
        start = time.time()
        progress = ScanningPhaseOutput()
        
        # ============================================================================
        # PHASE 1: ANNOUNCE SCANNING PLAN
        # ============================================================================
        self._print_scan_header()
        self.scanner.print_scanning_plan(modules)
        
        # ============================================================================
        # PHASE 2: EXECUTE WITH LIVE PROGRESS
        # ============================================================================
        print("\n" + Fore.CYAN + "Starting security scan with real-time progress..." + Style.RESET_ALL)
        
        progress.start_scanning_phase()
        
        # Run modules with progress callbacks
        findings = self._run_modules_with_progress(modules, progress)
        
        # Deduplicate findings
        unique_findings = {}
        for f in findings:
            key = (f.title, f.category)
            if key not in unique_findings:
                unique_findings[key] = f
        findings = list(unique_findings.values())
        
        duration = time.time() - start
        progress.end_scanning_phase(duration)
        
        # Calculate score
        score = self._calculate_risk_score(findings)
        
        # ============================================================================
        # PHASE 3: PRINT FINDINGS
        # ============================================================================
        self._print_scan_complete(duration)
        self._print_findings(findings)
        
        # ============================================================================
        # PHASE 4: PRINT SCORE
        # ============================================================================
        self._print_score(score)
        
        # Persist to database
        scan_id = self._persist_scan(score, findings, duration, modules)
        
        return score, findings
    
    def _run_modules_with_progress(
        self,
        modules: Sequence[str] | None,
        progress: ScanningPhaseOutput
    ) -> List[Finding]:
        """
        Run modules with progress callbacks.
        Adds realistic delays and progress output.
        """
        findings = []
        
        # Get enabled modules
        enabled_modules = list(modules) if modules else list(self.scanner.enabled_modules)
        
        for module_name in enabled_modules:
            try:
                progress.print_progress(module_name, "starting...")
                time.sleep(0.2)
                
                # Get module function
                module_func = self.scanner._get_module_func(module_name)
                if module_func is None:
                    continue
                
                progress.print_progress(module_name, "scanning...")
                time.sleep(0.3)
                
                # Run module
                module_findings = module_func()
                findings.extend(module_findings)
                
                progress.mark_module_complete(module_name)
                time.sleep(0.1)
                
            except Exception as e:
                progress.print_progress(module_name, f"error: {str(e)[:30]}")
                time.sleep(0.1)
        
        return findings
    
    def _calculate_risk_score(self, findings: List[Finding]) -> RiskScore:
        """Calculate risk score from findings."""
        from shs.core.rules import calculate_risk
        return calculate_risk(findings, self.weights)


def create_enhanced_engine():
    """Factory function to create enhanced engine."""
    return EnhancedSHSEngine()


if __name__ == "__main__":
    engine = create_enhanced_engine()
    score, findings = engine.run_scan_with_progress()
    print(f"\nFinal Score: {score.label} ({score.score}%)")
    print(f"Findings: {len(findings)} issues detected")
