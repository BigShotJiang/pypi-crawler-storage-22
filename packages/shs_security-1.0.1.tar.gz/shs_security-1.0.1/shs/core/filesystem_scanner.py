"""
System-wide file security scanning with real OS path traversal.
Scans from C:/ on Windows or / on Linux.
Detects secrets, misconfigurations, and permission issues.
"""

import os
import sys
import platform
from pathlib import Path
from typing import List, Dict, Callable
import re
import time


class FileSecurityIssue:
    """Single file security issue."""
    def __init__(self, path: str, issue_type: str, severity: str, details: str):
        self.path = path
        self.issue_type = issue_type  # secret, world_writable, suspicious_config, etc.
        self.severity = severity  # critical, high, medium, low
        self.details = details


class SystemWideFileScanner:
    """
    Scan entire filesystem for security issues.
    Real scanning with progress output.
    """
    
    def __init__(self, progress_callback: Callable[[str], None] = None):
        self.progress_callback = progress_callback or self._default_progress
        self.issues: List[FileSecurityIssue] = []
        self.scanned_dirs = 0
        self.scanned_files = 0
        
        # Secrets patterns
        self.secret_patterns = {
            'aws_key': re.compile(r'AKIA[0-9A-Z]{16}', re.IGNORECASE),
            'private_key': re.compile(r'-----BEGIN (?:RSA|DSA|EC|OPENSSH|PGP) PRIVATE KEY', re.IGNORECASE),
            'api_key': re.compile(r'(api[_-]?key|apikey)\s*[:=]\s*["\']?[A-Za-z0-9_]{20,}["\']?', re.IGNORECASE),
            'db_password': re.compile(r'(password|passwd|pwd)\s*[:=]\s*["\'][^"\']+["\']', re.IGNORECASE),
            'github_token': re.compile(r'ghp_[A-Za-z0-9_]{36}', re.IGNORECASE),
            'azure_key': re.compile(r'[A-Za-z0-9+/]{88}==', re.IGNORECASE),
        }
        
        # Directories to exclude (system, temporary, cache)
        self.excluded_dirs = self._get_excluded_dirs()
        
    def _default_progress(self, msg: str):
        """Default progress output."""
        print(f"  > {msg}")
        sys.stdout.flush()
    
    def _get_excluded_dirs(self) -> set:
        """Get OS-specific directories to exclude."""
        os_name = platform.system()
        
        if os_name == "Windows":
            return {
                '$Recycle.Bin', 'System Volume Information', 'hiberfil.sys',
                'pagefile.sys', 'ProgramData', '$WinREAgent', 'PerfLogs',
                '.git', '.venv', 'node_modules', '__pycache__', '.pytest_cache',
                'venv', 'env', '.tox', '.eggs', '*.egg-info', 'dist', 'build',
                '.idea', '.vscode', 'target', '.gradle', '.m2'
            }
        else:  # Linux/macOS
            return {
                '.git', '.venv', 'node_modules', '__pycache__', '.pytest_cache',
                'venv', 'env', '.tox', '.eggs', '.egg-info', 'dist', 'build',
                '.idea', '.vscode', 'target', '.gradle', '.m2',
                'proc', 'sys', 'dev', 'run', 'boot', 'root', 'var/log',
                '.cache', '.local', '.config', 'lost+found', '.snapshots',
                '.trash'
            }
    
    def _should_skip_dir(self, dir_path: str) -> bool:
        """Check if directory should be skipped."""
        # Skip hidden dirs on Linux unless important
        if dir_path.startswith('.') and platform.system() != "Windows":
            dir_name = os.path.basename(dir_path)
            if not dir_name.startswith('.aws') and not dir_name.startswith('.azure'):
                return True
        
        # Skip excluded dirs
        dir_name = os.path.basename(dir_path)
        if dir_name in self.excluded_dirs:
            return True
        
        # Skip system dirs
        if platform.system() == "Windows":
            lower_path = dir_path.lower()
            skip_prefixes = ['c:\\windows', 'c:\\program files', 'c:\\programdata']
            if any(lower_path.startswith(p) for p in skip_prefixes):
                return True
        else:
            skip_prefixes = ['/usr/', '/bin/', '/sbin/', '/lib/']
            if any(dir_path.startswith(p) for p in skip_prefixes):
                return True
        
        return False
    
    def _can_read_dir(self, dir_path: str) -> bool:
        """Check if we have permission to read directory."""
        return os.access(dir_path, os.R_OK)
    
    def _check_file_secrets(self, file_path: str) -> List[Dict]:
        """Check file for secret patterns."""
        secrets = []
        
        # Only check readable text files
        if not os.access(file_path, os.R_OK):
            return secrets
        
        try:
            file_size = os.path.getsize(file_path)
            if file_size > 10 * 1024 * 1024:  # Skip files >10MB
                return secrets
        except:
            return secrets
        
        # Try to read as text
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(100000)  # First 100KB only
        except:
            return secrets
        
        # Check patterns
        for pattern_name, pattern in self.secret_patterns.items():
            matches = pattern.finditer(content)
            for match in matches:
                secrets.append({
                    'type': pattern_name,
                    'match': match.group(0)[:50],  # Truncate long matches
                    'position': match.start()
                })
        
        return secrets
    
    def _check_file_permissions(self, file_path: str) -> List[Dict]:
        """Check for dangerous file permissions."""
        issues = []
        
        if platform.system() == "Windows":
            # Windows doesn't use Unix-style world-writable
            return issues
        
        try:
            mode = os.stat(file_path).st_mode
            
            # Check if world-writable
            if mode & 0o002:
                issues.append({
                    'type': 'world_writable',
                    'severity': 'high',
                    'details': f'File is world-writable (mode {oct(mode)})'
                })
            
            # Check if world-readable (for sensitive files)
            if (mode & 0o004) and file_path.endswith(('.pem', '.key', '.crt')):
                issues.append({
                    'type': 'world_readable_key',
                    'severity': 'critical',
                    'details': f'Key file is world-readable (mode {oct(mode)})'
                })
        except:
            pass
        
        return issues
    
    def scan(self, start_path: str = None) -> List[FileSecurityIssue]:
        """
        Scan filesystem starting from start_path.
        On Windows: C:/ by default
        On Linux: / by default
        """
        if start_path is None:
            start_path = "C:\\" if platform.system() == "Windows" else "/"
        
        self.progress_callback(f"Starting filesystem scan from {start_path}")
        time.sleep(0.2)
        
        # Recursive directory walk
        self._walk_directory(start_path)
        
        self.progress_callback(f"Scan complete: {self.scanned_files} files, {self.scanned_dirs} dirs")
        return self.issues
    
    def _walk_directory(self, root_dir: str):
        """Recursively walk directory structure."""
        try:
            # Check access
            if not self._can_read_dir(root_dir):
                return
            
            entries = os.listdir(root_dir)
            self.scanned_dirs += 1
            
            # Progress every 10 dirs
            if self.scanned_dirs % 10 == 0:
                self.progress_callback(f"Scanned {self.scanned_dirs} directories ({self.scanned_files} files checked)")
                time.sleep(0.1)
            
            for entry in entries:
                try:
                    full_path = os.path.join(root_dir, entry)
                    
                    # Skip directories
                    if os.path.isdir(full_path):
                        if not self._should_skip_dir(full_path):
                            self._walk_directory(full_path)
                    else:
                        # Check file
                        self.scanned_files += 1
                        self._check_file(full_path)
                except Exception as e:
                    pass
        
        except PermissionError:
            return
        except Exception as e:
            pass
    
    def _check_file(self, file_path: str):
        """Check single file for issues."""
        # Check for secrets
        secrets = self._check_file_secrets(file_path)
        for secret in secrets:
            self.issues.append(FileSecurityIssue(
                path=file_path,
                issue_type=secret['type'],
                severity='critical',
                details=f"Potential {secret['type']} detected: {secret['match']}"
            ))
        
        # Check permissions
        perms = self._check_file_permissions(file_path)
        for perm in perms:
            self.issues.append(FileSecurityIssue(
                path=file_path,
                issue_type=perm['type'],
                severity=perm['severity'],
                details=perm['details']
            ))


def scan_filesystem(progress_callback: Callable = None) -> Dict:
    """
    Main entry point for filesystem scanning.
    Returns dict of issues grouped by severity.
    """
    scanner = SystemWideFileScanner(progress_callback)
    
    # Scan system
    issues = scanner.scan()
    
    # Group by severity
    grouped = {
        'critical': [],
        'high': [],
        'medium': [],
        'low': []
    }
    
    for issue in issues:
        grouped[issue.severity].append(issue)
    
    return grouped


if __name__ == "__main__":
    def progress(msg):
        print(f"[PROGRESS] {msg}")
        sys.stdout.flush()
    
    results = scan_filesystem(progress)
    print(f"\n[RESULTS] Found {sum(len(v) for v in results.values())} issues")
    for severity in ['critical', 'high', 'medium', 'low']:
        if results[severity]:
            print(f"  {severity.upper()}: {len(results[severity])} issues")
