"""
OS & System Detection Module

Provides robust cross-platform OS detection following enterprise security
scanning standards (Lynis, osquery, CrowdStrike patterns).

Supports: Linux, Windows, macOS with detailed version/distro information.
"""

from __future__ import annotations

import platform
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class OSType(Enum):
    """Supported operating system types."""
    LINUX = "linux"
    WINDOWS = "windows"
    MACOS = "macos"
    UNKNOWN = "unknown"


class LinuxDistro(Enum):
    """Known Linux distributions."""
    UBUNTU = "ubuntu"
    DEBIAN = "debian"
    KALI = "kali"
    RHEL = "rhel"
    CENTOS = "centos"
    FEDORA = "fedora"
    OPENSUSE = "opensuse"
    ARCH = "arch"
    ALPINE = "alpine"
    UNKNOWN = "unknown"


@dataclass
class OSInfo:
    """
    Complete OS information structure.
    
    Attributes:
        os_type: Detected OS (Linux/Windows/macOS)
        distro: Linux distribution (if applicable)
        version: OS version string
        release: OS release/codename
        machine: System architecture (x86_64, aarch64, etc.)
        name: Human-readable OS name
    """
    os_type: OSType
    distro: Optional[LinuxDistro] = None
    version: str = ""
    release: str = ""
    machine: str = ""
    name: str = ""

    def __str__(self) -> str:
        """Pretty print OS info."""
        if self.os_type == OSType.LINUX:
            return f"{self.name} ({self.release})"
        return self.name


class OSDetector:
    """
    Cross-platform OS detection engine.
    
    Provides accurate OS identification using:
    - platform module (base)
    - distro module (Linux distributions)
    - Windows registry inspection (optional, via capabilities)
    - macOS system_profiler (optional, via capabilities)
    
    Example:
        detector = OSDetector()
        os_info = detector.detect()
        print(os_info)  # "Ubuntu (jammy)"
    """

    @staticmethod
    def detect() -> OSInfo:
        """
        Detect current operating system.
        
        Returns:
            OSInfo: Detailed OS information
            
        Raises:
            None (always returns valid OSInfo, worst case UNKNOWN)
        """
        system = platform.system().lower()
        
        if system == "linux":
            return OSDetector._detect_linux()
        elif system == "windows":
            return OSDetector._detect_windows()
        elif system == "darwin":
            return OSDetector._detect_macos()
        else:
            return OSInfo(
                os_type=OSType.UNKNOWN,
                version="unknown",
                machine=platform.machine(),
                name=f"Unknown OS: {system}",
            )

    @staticmethod
    def _detect_linux() -> OSInfo:
        """
        Detect Linux distribution and version.
        
        Uses distro module for accurate detection, falls back to
        /etc/os-release and lsb_release if needed.
        """
        try:
            import distro as distro_module
            
            distro_name = distro_module.name().lower()
            distro_version = distro_module.version()
            distro_codename = distro_module.codename() or distro_version
            
        except ImportError:
            # Fallback: parse /etc/os-release manually
            distro_name = OSDetector._parse_os_release_name()
            distro_version = platform.release()
            distro_codename = distro_version

        # Identify distro type
        distro_enum = OSDetector._classify_distro(distro_name)
        
        # Build human-readable name
        distro_display = distro_name.capitalize()
        full_name = f"{distro_display} {distro_version}" if distro_version else distro_display

        return OSInfo(
            os_type=OSType.LINUX,
            distro=distro_enum,
            version=distro_version,
            release=distro_codename,
            machine=platform.machine(),
            name=full_name,
        )

    @staticmethod
    def _parse_os_release_name() -> str:
        """Parse /etc/os-release for distro name (fallback method)."""
        try:
            with open("/etc/os-release", "r") as f:
                for line in f:
                    if line.startswith("ID="):
                        return line.split("=")[1].strip().strip('"')
        except (FileNotFoundError, IndexError):
            pass
        return "linux"

    @staticmethod
    def _classify_distro(distro_name: str) -> LinuxDistro:
        """Map distro name string to LinuxDistro enum."""
        distro_name_lower = distro_name.lower().strip()
        
        if "ubuntu" in distro_name_lower:
            return LinuxDistro.UBUNTU
        elif "kali" in distro_name_lower:
            return LinuxDistro.KALI
        elif "debian" in distro_name_lower:
            return LinuxDistro.DEBIAN
        elif "rhel" in distro_name_lower or "red hat" in distro_name_lower:
            return LinuxDistro.RHEL
        elif "centos" in distro_name_lower:
            return LinuxDistro.CENTOS
        elif "fedora" in distro_name_lower:
            return LinuxDistro.FEDORA
        elif "opensuse" in distro_name_lower:
            return LinuxDistro.OPENSUSE
        elif "arch" in distro_name_lower or "manjaro" in distro_name_lower:
            return LinuxDistro.ARCH
        elif "alpine" in distro_name_lower:
            return LinuxDistro.ALPINE
        else:
            return LinuxDistro.UNKNOWN

    @staticmethod
    def _detect_windows() -> OSInfo:
        """
        Detect Windows version.
        
        Returns info for Windows 10/11. Uses platform.version() for
        detailed version information.
        """
        release = platform.release()  # e.g., "10", "11"
        version = platform.version()  # e.g., "10.0.19045"
        
        # Determine Windows version name
        if release == "10":
            name = "Windows 10"
        elif release == "11":
            name = "Windows 11"
        else:
            name = f"Windows {release}"

        return OSInfo(
            os_type=OSType.WINDOWS,
            version=version,
            release=release,
            machine=platform.machine(),
            name=name,
        )

    @staticmethod
    def _detect_macos() -> OSInfo:
        """
        Detect macOS version.
        
        Extracts version info from platform.mac_ver() or platform.version().
        """
        mac_ver = platform.mac_ver()  # Returns (release, versioninfo, machine)
        release = mac_ver[0] or platform.release()
        version = platform.version()

        return OSInfo(
            os_type=OSType.MACOS,
            version=version,
            release=release,
            machine=platform.machine(),
            name=f"macOS {release}",
        )
