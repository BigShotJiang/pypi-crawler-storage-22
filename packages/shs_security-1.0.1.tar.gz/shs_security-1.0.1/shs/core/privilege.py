"""
Privilege Detection Module

Detects user privileges and execution context (root, admin, etc.)
following enterprise security standards.

Supports: Linux (UID checking), Windows (admin group), macOS (root/sudo)
"""

from __future__ import annotations

import os
import platform
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class PrivilegeLevel(Enum):
    """User privilege levels."""
    ROOT = "root"           # Linux/macOS root (UID 0)
    ADMIN = "admin"         # Windows administrator
    SYSTEM = "system"       # Windows SYSTEM account
    SUDO_CAPABLE = "sudo"   # Can escalate via sudo
    STANDARD_USER = "user"  # Standard unprivileged user
    UNKNOWN = "unknown"


@dataclass
class PrivilegeInfo:
    """
    User privilege information structure.
    
    Attributes:
        level: Current privilege level
        uid: Unix UID (if applicable)
        gid: Unix GID (if applicable)
        username: Current username
        is_elevated: True if running with elevated privileges
        can_escalate: True if user can escalate to higher privileges
    """
    level: PrivilegeLevel
    uid: Optional[int] = None
    gid: Optional[int] = None
    username: str = ""
    is_elevated: bool = False
    can_escalate: bool = False

    def __str__(self) -> str:
        """Pretty print privilege info."""
        if self.is_elevated:
            return f"{self.level.value} (elevated)"
        return self.level.value


class PrivilegeDetector:
    """
    Cross-platform privilege detection engine.
    
    Determines current user's privilege level and ability to escalate.
    Uses OS-specific methods:
    
    - Linux/macOS: UID checking (0=root), /etc/sudoers parsing
    - Windows: token elevation checking, admin group membership
    
    Example:
        detector = PrivilegeDetector()
        priv_info = detector.detect()
        if priv_info.is_elevated:
            print(f"Running as {priv_info.level.value}")
    """

    @staticmethod
    def detect() -> PrivilegeInfo:
        """
        Detect current user privilege level.
        
        Returns:
            PrivilegeInfo: Detailed privilege information
            
        Raises:
            None (always returns valid PrivilegeInfo)
        """
        system = platform.system().lower()
        
        if system == "linux" or system == "darwin":
            return PrivilegeDetector._detect_unix()
        elif system == "windows":
            return PrivilegeDetector._detect_windows()
        else:
            return PrivilegeInfo(
                level=PrivilegeLevel.UNKNOWN,
                username=os.getenv("USER", "unknown"),
            )

    @staticmethod
    def _detect_unix() -> PrivilegeInfo:
        """
        Detect Unix/Linux privilege level.
        
        Checks:
        1. UID (0 = root)
        2. Sudo capability via /etc/sudoers
        """
        # Get UID/GID
        uid = None
        gid = None
        username = "unknown"
        level = PrivilegeLevel.STANDARD_USER
        is_elevated = False
        can_escalate = False

        # Try to get UID (requires os module)
        try:
            uid = os.getuid()
            gid = os.getgid()
            is_elevated = (uid == 0)
            
            if is_elevated:
                level = PrivilegeLevel.ROOT
            else:
                # Check if user can escalate via sudo
                can_escalate = PrivilegeDetector._can_sudo()
                if can_escalate:
                    level = PrivilegeLevel.SUDO_CAPABLE
                    
        except AttributeError:
            # os.getuid() not available (shouldn't happen on Unix)
            pass

        # Get username
        username = os.getenv("USER", os.getenv("LOGNAME", "unknown"))

        return PrivilegeInfo(
            level=level,
            uid=uid,
            gid=gid,
            username=username,
            is_elevated=is_elevated,
            can_escalate=can_escalate,
        )

    @staticmethod
    def _can_sudo() -> bool:
        """
        Check if current user has sudo privileges.
        
        Parses /etc/sudoers and /etc/sudoers.d/* entries.
        Returns True if current user is in sudoers.
        """
        username = os.getenv("USER", "")
        if not username:
            return False

        # Check /etc/sudoers and /etc/sudoers.d
        sudoers_paths = ["/etc/sudoers"]
        try:
            sudoers_d = "/etc/sudoers.d"
            if os.path.isdir(sudoers_d):
                for filename in os.listdir(sudoers_d):
                    sudoers_paths.append(os.path.join(sudoers_d, filename))
        except (OSError, PermissionError):
            pass

        for path in sudoers_paths:
            try:
                with open(path, "r") as f:
                    for line in f:
                        line = line.strip()
                        # Skip comments and empty lines
                        if not line or line.startswith("#"):
                            continue
                        
                        # Simple check: if username or ALL appears in sudoers line
                        # This is a basic check; comprehensive parsing is complex
                        if username in line and "ALL" in line:
                            return True
                        
                        # Check for group sudoers (e.g., %sudo, %wheel)
                        if line.startswith("%"):
                            group_name = line.split()[0][1:]  # Remove %
                            if PrivilegeDetector._is_user_in_group(username, group_name):
                                return True
                                
            except (OSError, PermissionError):
                # Can't read sudoers file (expected without root)
                continue

        return False

    @staticmethod
    def _is_user_in_group(username: str, group_name: str) -> bool:
        """Check if user is member of specified group."""
        try:
            import grp
            group = grp.getgrnam(group_name)
            return username in group.gr_mem
        except (KeyError, ImportError):
            return False

    @staticmethod
    def _detect_windows() -> PrivilegeInfo:
        """
        Detect Windows privilege level.
        
        Checks:
        1. Token elevation status (Is admin?)
        2. User account type via WMI or token
        """
        username = os.getenv("USERNAME", "unknown")
        level = PrivilegeLevel.STANDARD_USER
        is_elevated = False

        try:
            # Try using ctypes to check admin status (most reliable)
            import ctypes
            is_elevated = bool(ctypes.windll.shell32.IsUserAnAdmin())
            if is_elevated:
                level = PrivilegeLevel.ADMIN
                
        except (ImportError, AttributeError, OSError):
            # Fallback: check via environment or other method
            try:
                import subprocess
                # Use 'whoami /groups' to check for admin group
                result = subprocess.run(
                    ["whoami", "/groups"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0:
                    output = result.stdout.lower()
                    # Check for admin-related SIDs/groups
                    admin_indicators = [
                        "administrators",
                        "s-1-5-32-544",  # BUILTIN\Administrators SID
                        "domain admins",
                    ]
                    if any(indicator in output for indicator in admin_indicators):
                        is_elevated = True
                        level = PrivilegeLevel.ADMIN
                        
            except (ImportError, OSError, subprocess.TimeoutExpired):
                pass

        return PrivilegeInfo(
            level=level,
            username=username,
            is_elevated=is_elevated,
            can_escalate=False,  # Windows doesn't have direct escalation like sudo
        )
