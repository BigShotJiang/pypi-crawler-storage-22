from __future__ import annotations

import sys
import time
from typing import Optional

from colorama import Fore, Style, init as colorama_init


class Progress:
    """Lightweight progress/status line manager for SHS.

    Usage:
        p = Progress()
        p.info("Starting...")
        p.step("System hygiene checks")
        ...run work...
        p.done()
    """

    def __init__(self) -> None:
        colorama_init(autoreset=True)
        self._current_label: Optional[str] = None
        self._start_time: Optional[float] = None

    def info(self, msg: str) -> None:
        print(Fore.CYAN + f"[i] {msg}" + Style.RESET_ALL)

    def step(self, label: str) -> None:
        # Print a progress line (no newline), will be updated by done()/skip()/fail()
        self._current_label = label
        self._start_time = time.time()
        sys.stdout.write(Fore.CYAN + f"[*] {label} ... " + Style.RESET_ALL)
        sys.stdout.flush()

    def done(self, elapsed: float | None = None) -> None:
        label = self._current_label or "step"
        if elapsed is None and self._start_time:
            elapsed = time.time() - self._start_time
        elapsed_str = f" ({elapsed:.1f}s)" if elapsed else ""
        sys.stdout.write("\r")
        sys.stdout.write(Fore.GREEN + f"[*] {label} ... done{elapsed_str}" + Style.RESET_ALL + "\n")
        sys.stdout.flush()

    def skip(self) -> None:
        label = self._current_label or "step"
        sys.stdout.write("\r")
        sys.stdout.write(Fore.YELLOW + f"[*] {label} ... skipped" + Style.RESET_ALL + "\n")
        sys.stdout.flush()

    def fail(self) -> None:
        label = self._current_label or "step"
        sys.stdout.write("\r")
        sys.stdout.write(Fore.RED + f"[*] {label} ... failed" + Style.RESET_ALL + "\n")
        sys.stdout.flush()
