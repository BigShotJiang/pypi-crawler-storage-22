"""
Live progress manager for nmap-style scanning output.
Manages per-module progress and timing.
"""

import time
from typing import Callable, Dict, Optional
from colorama import Fore, Style


class ProgressManager:
    """Manage live progress output during scanning phases."""
    
    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.module_progress: Dict[str, str] = {}
        self.start_time = None
        self.last_update = 0
        self.update_interval = 0.1  # Minimum time between progress updates
    
    def start(self):
        """Start progress tracking."""
        self.start_time = time.time()
    
    def update(self, module: str, status: str):
        """Update progress for a module."""
        if not self.enabled:
            return
        
        # Rate limit updates
        now = time.time()
        if now - self.last_update < self.update_interval:
            return
        
        self.module_progress[module] = status
        self.last_update = now
        self._print_progress()
    
    def _print_progress(self):
        """Print current progress state."""
        if not self.enabled or not self.module_progress:
            return
        
        elapsed = time.time() - (self.start_time or time.time())
        
        # Print progress line
        progress_line = f"  [{elapsed:.1f}s] "
        
        for module, status in self.module_progress.items():
            progress_line += f"{module}: {status}  "
        
        # Overwrite line (terminal magic)
        print(f"\r{progress_line}", end='', flush=True)
    
    def complete(self, module: str):
        """Mark module as complete."""
        if module in self.module_progress:
            self.module_progress[module] = Fore.GREEN + "✓" + Style.RESET_ALL
        self._print_progress()
    
    def finish(self):
        """Finish progress tracking."""
        if self.enabled and self.module_progress:
            print()  # Newline after progress line


class ScanningPhaseOutput:
    """
    Manages two-phase output: scanning phase and findings phase.
    Phase 1: Live progress during scan
    Phase 2: Findings after scan complete
    """
    
    def __init__(self):
        self.scanning_output: list = []
        self.in_scanning_phase = False
        self.progress_manager = ProgressManager()
    
    def start_scanning_phase(self):
        """Begin scanning phase."""
        self.in_scanning_phase = True
        self.progress_manager.start()
        print("\nStarting real-time scanning...\n")
    
    def print_progress(self, module: str, status: str):
        """Print progress during scanning."""
        if self.in_scanning_phase:
            self.progress_manager.update(module, status)
            self.scanning_output.append((module, status, time.time()))
    
    def mark_module_complete(self, module: str):
        """Mark module scanning as complete."""
        if self.in_scanning_phase:
            self.progress_manager.complete(module)
    
    def end_scanning_phase(self, elapsed_seconds: float):
        """End scanning phase and prepare for findings."""
        self.in_scanning_phase = False
        self.progress_manager.finish()
        print(f"\nScan completed in {elapsed_seconds:.2f}s\n")
    
    def get_scanning_summary(self) -> str:
        """Get summary of scanning phase."""
        if not self.scanning_output:
            return ""
        
        summary = "Scanning Summary:\n"
        for module, status, timestamp in self.scanning_output:
            summary += f"  {module}: {status}\n"
        return summary


# Global progress instance
_progress_instance: Optional[ScanningPhaseOutput] = None


def get_progress_manager() -> ScanningPhaseOutput:
    """Get global progress manager instance."""
    global _progress_instance
    if _progress_instance is None:
        _progress_instance = ScanningPhaseOutput()
    return _progress_instance


def progress_print(msg: str):
    """Print progress message."""
    print(f"  > {msg}")


def progress_update(module: str, status: str):
    """Update progress for a module."""
    manager = get_progress_manager()
    manager.print_progress(module, status)


def progress_complete(module: str):
    """Mark module as complete."""
    manager = get_progress_manager()
    manager.mark_module_complete(module)


if __name__ == "__main__":
    # Test progress output
    pm = ScanningPhaseOutput()
    pm.start_scanning_phase()
    
    for i in range(5):
        pm.print_progress("system", f"checking {i+1}/10")
        time.sleep(0.3)
    
    pm.mark_module_complete("system")
    
    for i in range(3):
        pm.print_progress("files", f"scanned {i+1}/3")
        time.sleep(0.2)
    
    pm.mark_module_complete("files")
    pm.end_scanning_phase(2.5)
