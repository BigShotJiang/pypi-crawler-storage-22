from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Iterable, List, Tuple


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"  # For informational findings that don't affect score


@dataclass
class Finding:
    id: str
    title: str
    severity: Severity
    category: str
    description: str
    recommendation: str
    metadata: Dict[str, Any]


@dataclass
class RiskScore:
    score: int
    label: str
    explanation: str


DEFAULT_WEIGHTS: Dict[Severity, int] = {
    Severity.CRITICAL: 10,
    Severity.HIGH: 7,
    Severity.MEDIUM: 4,
    Severity.LOW: 1,
    Severity.INFO: 0,  # INFO findings don't affect score
}


def load_weights(raw: Dict[str, int] | None) -> Dict[Severity, int]:
    if not raw:
        return dict(DEFAULT_WEIGHTS)
    result: Dict[Severity, int] = {}
    for severity in Severity:
        key = severity.value
        if key in raw and isinstance(raw[key], int):
            result[severity] = raw[key]
        else:
            result[severity] = DEFAULT_WEIGHTS[severity]
    return result


def calculate_risk(findings: Iterable[Finding], weights: Dict[Severity, int]) -> RiskScore:
    total_risk = 0
    counts: Dict[Severity, int] = {s: 0 for s in Severity}
    for finding in findings:
        # Skip INFO findings from risk calculation (they're informational only)
        if finding.severity == Severity.INFO:
            counts[finding.severity] += 1
            continue
        
        weight = weights.get(finding.severity, DEFAULT_WEIGHTS[finding.severity])
        total_risk += weight
        counts[finding.severity] += 1

    if total_risk <= 0:
        return RiskScore(score=100, label="Excellent", explanation="No issues detected")

    penalty = min(100, total_risk * 2)
    score_value = max(0, 100 - penalty)

    # Professional scanners never score below 10% when issues exist
    if total_risk > 0:
        score_value = max(10, score_value)

    label, explanation = _score_label(score_value, counts)
    return RiskScore(score=score_value, label=label, explanation=explanation)


def _score_label(score: int, counts: Dict[Severity, int]) -> Tuple[str, str]:
    critical = counts.get(Severity.CRITICAL, 0)
    high = counts.get(Severity.HIGH, 0)

    if score >= 90:
        return "Excellent", "System shows strong security hygiene"
    if score >= 75:
        return "Good", "Minor issues detected that should be reviewed"
    if score >= 60:
        return "Needs Attention", "Multiple medium issues detected; review recommended"
    if score >= 40:
        if critical or high:
            return "High Risk", "Critical or high-risk issues detected; remediation required"
        return "High Risk", "Security hygiene weaknesses detected; review configuration"
    return "Critical Risk", "Multiple critical issues detected; immediate remediation required"


