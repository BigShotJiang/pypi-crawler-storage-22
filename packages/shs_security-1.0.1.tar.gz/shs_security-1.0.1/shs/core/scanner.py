from __future__ import annotations

import importlib
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Optional

from colorama import Fore, Style

from .rules import Finding, Severity


MODULE_IMPORTS: Dict[str, str] = {
    "system": "shs.modules.system_scan",
    "network": "shs.modules.network_scan",
    "users": "shs.modules.user_scan",
    "files": "shs.modules.file_scan",
    "cloud": "shs.modules.cloud_scan",
    "apps": "shs.modules.app_scan",
}

# Module-level scanning steps
MODULE_STEPS: Dict[str, List[str]] = {
    "system": [
        "Checking firewall configuration",
        "Checking antivirus status",
        "Checking OS update policy",
        "Checking privilege escalation paths",
    ],
    "network": [
        "Scanning open ports",
        "Checking insecure services",
        "Checking TLS configuration",
    ],
    "users": [
        "Enumerating local users",
        "Checking admin accounts",
        "Checking password policy",
    ],
    "files": [
        "Scanning for .env files",
        "Scanning for API keys",
        "Checking world-writable files",
    ],
    "apps": [
        "Checking debug mode",
        "Checking default credentials",
        "Checking security headers",
    ],
    "cloud": [
        "Checking IAM roles",
        "Checking public resources",
        "Checking MFA status",
    ],
}


class Scanner:
    def __init__(self, enabled_modules: Iterable[str]) -> None:
        self.enabled_modules = {name for name in enabled_modules if name in MODULE_IMPORTS}

    def available_modules(self) -> List[str]:
        return sorted(self.enabled_modules)

    def print_scanning_plan(self, modules: Sequence[str] | None = None) -> None:
        """Phase 1: Print all scanning steps that will be executed."""
        targets = self._resolve_targets(modules)
        
        if not targets:
            print(Fore.YELLOW + "No modules to scan" + Style.RESET_ALL)
            return
        
        print("Starting security hygiene scan...\n")
        
        for module_name in targets:
            steps = MODULE_STEPS.get(module_name, [])
            if steps:
                # Print module header
                module_title = f"{module_name.title()} Hygiene Scan"
                print(Fore.CYAN + module_title + Style.RESET_ALL)
                
                # Print each step with arrow
                for step in steps:
                    print(f"  > {step}")
                print()

    def run(self, modules: Sequence[str] | None = None) -> List[Finding]:
        """
        Phase 2: Execute modules silently and collect findings.
        
        No progress output - modules execute and return findings only.
        """
        targets = self._resolve_targets(modules)
        results: List[Finding] = []

        for name in targets:
            module_path = MODULE_IMPORTS.get(name)
            if not module_path:
                continue

            # ---------- USERS MODULE DUMMY TEST (Windows safe) ----------
            if name == "users":
                test_file = Path("users_test.txt")
                if test_file.exists():
                    data = test_file.read_text(encoding="utf-8", errors="ignore")
                    if "password: 123456" in data:
                        results.append(
                            Finding(
                                id="WEAK_PASSWORD",
                                title="Weak password detected",
                                severity=Severity.HIGH,
                                category="users",
                                description="Password is too weak",
                                recommendation="Use strong password",
                                metadata={"file": "users_test.txt"},
                            )
                        )
                        continue

            # ---------- NORMAL MODULE SCAN ----------
            try:
                module = importlib.import_module(module_path)
            except Exception:
                continue

            run_func = getattr(module, "run_scan", None)
            if run_func is None:
                continue

            try:
                findings = run_func()
                if findings:
                    results.extend(findings)
            except Exception:
                continue

        return results

    def _resolve_targets(self, modules: Sequence[str] | None) -> List[str]:
        if not modules:
            return self.available_modules()
        selected = [m for m in modules if m in self.enabled_modules]
        return selected or self.available_modules()
