"""Module registry for SHS modules.

Note: The `app_inventory` and `antivirus_scan` modules were added previously
as experimental SOC-focused features but have been removed to restore SHS to
its core, minimal hygiene scanner surface. Removal rationale:
	- These features increased scope beyond the core scanner and added
		additional external dependencies and heuristics.
	- To keep the codebase lean and production-ready for interviews, the
		inventory and external AV probes were reverted.

If these features are re-introduced in future, prefer adding them behind a
clear feature flag and with dedicated integration tests.
"""

__all__ = []

