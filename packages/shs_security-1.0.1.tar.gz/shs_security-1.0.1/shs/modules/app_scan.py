from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Iterable, List

from shs.core.rules import Finding, Severity


DEBUG_PATTERN = re.compile(r"DEBUG\s*=\s*True", re.IGNORECASE)

# Secret detection regexes (line-based)
# AWS access key id (AKIA...)
RE_AWS_KEY_ID = re.compile(r"AKIA[0-9A-Z]{16}")
# Generic secret assignment (e.g., SECRET_KEY = "..." or apiKey: '...')
RE_SECRET_ASSIGN = re.compile(r'(secret|secret_key|api[_-]?key|access[_-]?token|aws[_-]?secret)["\'\s]*[:=]{1,2}["\']([A-Za-z0-9/+=._-]{8,})["\']', re.IGNORECASE)
# Private key BEGIN marker
RE_PRIVATE_KEY = re.compile(r"-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----")


def run_scan(root: Path | None = None) -> List[Finding]:
    base = root or Path.cwd()
    findings: List[Finding] = []
    # App scan: include secret detection and server config analysis
    findings.extend(_check_hardcoded_secrets(base))
    findings.extend(_check_debug_env())
    findings.extend(_check_debug_files(base))
    findings.extend(_check_default_credentials(base))
    findings.extend(_check_missing_security_headers(base))
    findings.extend(_check_outdated_dependencies(base))
    return findings


def _check_debug_env() -> List[Finding]:
    results: List[Finding] = []
    if os.getenv("FLASK_DEBUG") == "1" or os.getenv("DJANGO_DEBUG") == "1":
        results.append(
            Finding(
                id="APP_DEBUG_ENV",
                title="Application debug mode enabled via environment",
                severity=Severity.HIGH,
                category="apps",
                description="Debug mode can expose sensitive information and weaken security controls",
                recommendation="Disable debug mode in non-development environments",
                metadata={},
            )
        )
    return results


def _check_debug_files(root: Path) -> List[Finding]:
    results: List[Finding] = []
    for path in _iter_candidate_files(root):
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if DEBUG_PATTERN.search(content):
            results.append(
                Finding(
                    id="APP_DEBUG_CONFIG",
                    title="Debug configuration detected in source file",
                    severity=Severity.MEDIUM,
                    category="apps",
                    description="Source files reference debug configuration set to true",
                    recommendation="Guard debug settings with environment checks and disable in production",
                    metadata={"file": str(path)},
                )
            )
    return results


def _check_default_credentials(root: Path) -> List[Finding]:
    results: List[Finding] = []
    patterns = [
        "admin:admin",
        "root:root",
        "password=password",
    ]
    for path in _iter_candidate_files(root):
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for token in patterns:
            if token in content:
                results.append(
                    Finding(
                        id="APP_DEFAULT_CREDENTIALS",
                        title="Potential default credentials found in configuration",
                        severity=Severity.HIGH,
                        category="apps",
                        description="Configuration files appear to reference common default credentials",
                        recommendation="Remove default credentials and use strong, unique secrets",
                        metadata={"file": str(path), "pattern": token},
                    )
                )
                break
    return results


def _check_hardcoded_secrets(root: Path) -> List[Finding]:
    results: List[Finding] = []
    # candidate extensions for secret scanning
    exts = {".py", ".js", ".ts", ".env"}
    for path in _iter_candidate_files(root):
        if path.suffix.lower() not in exts:
            continue
        try:
            with path.open("r", encoding="utf-8", errors="ignore") as fh:
                for lineno, line in enumerate(fh, start=1):
                    # Trim whitespace
                    txt = line.strip()
                    if not txt:
                        continue

                    if RE_AWS_KEY_ID.search(txt) or RE_SECRET_ASSIGN.search(txt) or RE_PRIVATE_KEY.search(txt):
                        results.append(
                            Finding(
                                id="APP_HARDCODED_SECRET",
                                title="Hardcoded secret in source code",
                                severity=Severity.CRITICAL,
                                category="apps",
                                description="Potential hardcoded secret detected in source code",
                                recommendation="Remove hardcoded secrets and use secure secret storage or environment variables",
                                metadata={"file": str(path), "line": lineno},
                            )
                        )
                        # continue scanning file to collect multiple findings
        except OSError:
            continue
    return results


def _check_missing_security_headers(root: Path) -> List[Finding]:
    results: List[Finding] = []
    headers = [
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]

    # Look specifically for common server config filenames
    target_names = {"nginx.conf", "httpd.conf", "apache2.conf"}
    found_configs: List[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        name = path.name.lower()
        if name in target_names or path.suffix.lower() in {".conf"}:
            # exclude large vendor dirs
            if _is_excluded(path):
                continue
            found_configs.append(path)

    for path in found_configs:
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        missing = [h for h in headers if h not in content]
        if missing:
            results.append(
                Finding(
                    id="APP_MISSING_SECURITY_HEADERS",
                    title="Missing security headers in server config",
                    severity=Severity.MEDIUM,
                    category="apps",
                    description=f"Config missing headers: {', '.join(missing)}",
                    recommendation="Add common security headers such as CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy",
                    metadata={"file": str(path), "missing": missing},
                )
            )

    return results


def _check_outdated_dependencies(root: Path) -> List[Finding]:
    results: List[Finding] = []
    requirements = root / "requirements.txt"
    if not requirements.exists():
        return results
    try:
        lines = requirements.read_text(encoding="utf-8").splitlines()
    except OSError:
        return results
    unpinned = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "==" not in line and ">=" not in line and "<=" not in line:
            unpinned.append(line)
    if unpinned:
        results.append(
            Finding(
                id="APP_UNPINNED_DEPENDENCIES",
                title="Dependencies not strictly pinned",
                severity=Severity.LOW,
                category="apps",
                description="Some dependencies are not pinned to specific versions and may include outdated packages",
                recommendation="Pin critical dependencies to vetted versions and review them regularly",
                metadata={"packages": ",".join(unpinned)},
            )
        )
    return results


def _iter_candidate_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        # Exclude common large or virtual environment folders
        if _is_excluded(path):
            continue
        if path.suffix.lower() in {".py", ".env", ".ini", ".cfg", ".conf", ".yaml", ".yml", ".js", ".ts"}:
            yield path


def _is_excluded(path: Path) -> bool:
    # Exclude .venv, node_modules, __pycache__ and similar
    parts = {p.lower() for p in path.parts}
    excluded = {".venv", "venv", "node_modules", "__pycache__"}
    return bool(parts & excluded)

