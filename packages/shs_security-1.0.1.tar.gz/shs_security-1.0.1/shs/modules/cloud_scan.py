from __future__ import annotations

from typing import List, Dict, Any
import os

try:
    import boto3
    from botocore.exceptions import BotoCoreError, ClientError, NoCredentialsError, NoRegionError
except Exception:
    boto3 = None  # type: ignore
    # Define fallback exception names so code can reference them safely
    class _BotoStubExc(Exception):
        pass

    BotoCoreError = ClientError = NoCredentialsError = NoRegionError = _BotoStubExc

from shs.core.rules import Finding, Severity


def run_scan() -> List[Finding]:
    # Demo/test mode: return a single cloud finding when SHS_CLOUD_TEST is set
    if os.getenv("SHS_CLOUD_TEST"):
        return [
            Finding(
                id="CLOUD_TEST_MODE",
                title="Cloud test finding (demo mode)",
                severity=Severity.MEDIUM,
                category="cloud",
                description="Cloud scan running in test/demo mode",
                recommendation="Disable SHS_CLOUD_TEST for real scan",
                metadata={"mode": "demo"},
            )
        ]

    # Quick check for credentials/config: use STS to detect configured credentials
    try:
        sts = boto3.client("sts")
        sts.get_caller_identity()
    except (NoCredentialsError, ClientError, NoRegionError):
        return [
            Finding(
                id="CLOUD_AWS_SKIPPED_NO_CREDS",
                title="Cloud scan skipped – AWS not configured",
                severity=Severity.INFO,
                category="cloud",
                description="AWS credentials or region not configured; cloud checks skipped",
                recommendation="Configure AWS credentials or run on an instance with an appropriate IAM role to enable cloud scanning",
                metadata={},
            )
        ]
    except Exception:
        # If STS can't be reached for other reasons, proceed but individual calls will handle errors
        pass

    findings: List[Finding] = []
    findings.extend(_check_aws_root_mfa())
    findings.extend(_check_aws_public_buckets())
    findings.extend(_check_aws_admin_entities())
    findings.extend(_check_aws_open_security_groups())
    return findings


def _check_aws_root_mfa() -> List[Finding]:
    results: List[Finding] = []
    try:
        client = boto3.client("iam")
        summary = client.get_account_summary()["SummaryMap"]
        root_mfa = summary.get("AccountMFAEnabled")
        # If value is missing we cannot determine
        if root_mfa is None:
            results.append(
                Finding(
                    id="CLOUD_ROOT_MFA_UNKNOWN",
                    title="Root MFA status unknown",
                    severity=Severity.INFO,
                    category="cloud",
                    description="Could not determine whether the AWS root account has MFA enabled",
                    recommendation="Verify root account MFA in the AWS Console",
                    metadata={},
                )
            )
        elif int(root_mfa) == 0:
            results.append(
                Finding(
                    id="CLOUD_ROOT_MFA_DISABLED",
                    title="AWS root MFA not enabled",
                    severity=Severity.CRITICAL,
                    category="cloud",
                    description="AWS root account does not appear to have MFA enabled",
                    recommendation="Enable MFA for the AWS root account immediately",
                    metadata={},
                )
            )
    except (NoCredentialsError, NoRegionError):
        return results
    except (BotoCoreError, ClientError):
        return results
    return results


def _check_aws_public_buckets() -> List[Finding]:
    results: List[Finding] = []
    try:
        s3 = boto3.client("s3")
        buckets = s3.list_buckets().get("Buckets", [])
        for bucket in buckets:
            name = bucket.get("Name")
            if not name:
                continue
            public_read = False
            public_write = False
            reasons = []
            # ACL
            try:
                acl = s3.get_bucket_acl(Bucket=name)
                for grant in acl.get("Grants", []):
                    grantee = grant.get("Grantee", {})
                    uri = grantee.get("URI", "")
                    perm = grant.get("Permission")
                    if uri and ("AllUsers" in uri or "AuthenticatedUsers" in uri):
                        if perm in ("READ", "FULL_CONTROL"):
                            public_read = True
                            reasons.append("ACL grants public READ/FULL_CONTROL")
                        if perm in ("WRITE", "FULL_CONTROL"):
                            public_write = True
                            reasons.append("ACL grants public WRITE/FULL_CONTROL")
            except Exception:
                pass

            # Public access block settings
            try:
                pab = s3.get_public_access_block(Bucket=name)
                cfg = pab.get("PublicAccessBlockConfiguration", {})
                # if blocking is not fully enabled, warn
                if not cfg.get("BlockPublicAcls", False) or not cfg.get("IgnorePublicAcls", False):
                    reasons.append("PublicAccessBlock not fully enforced")
            except Exception:
                pass

            # Policy status
            try:
                status = s3.get_bucket_policy_status(Bucket=name)
                if status.get("PolicyStatus", {}).get("IsPublic"):
                    public_read = True
                    reasons.append("Bucket policy allows public access")
            except Exception:
                pass

            if public_read or public_write:
                results.append(
                    Finding(
                        id="CLOUD_S3_PUBLIC",
                        title=f"Public S3 bucket: {name}",
                        severity=Severity.CRITICAL,
                        category="cloud",
                        description="S3 bucket is publicly accessible (read or write).",
                        recommendation="Restrict bucket ACLs and policies; enable Block Public Access and review object ACLs.",
                        metadata={"bucket": name, "public_read": public_read, "public_write": public_write, "reasons": reasons},
                    )
                )
    except (NoCredentialsError, NoRegionError):
        return results
    except (BotoCoreError, ClientError):
        return results
    return results


def _check_aws_admin_entities() -> List[Finding]:
    """Detect IAM users and roles attached to AdministratorAccess managed policy.

    Returns HIGH severity finding if such principals are found.
    """
    results: List[Finding] = []
    try:
        iam = boto3.client("iam")
        admins: List[Dict[str, Any]] = []

        # Users
        try:
            paginator = iam.get_paginator("list_users")
            for page in paginator.paginate():
                for u in page.get("Users", []):
                    name = u.get("UserName")
                    if not name:
                        continue
                    try:
                        attached = iam.list_attached_user_policies(UserName=name).get("AttachedPolicies", [])
                        for p in attached:
                            if p.get("PolicyName") == "AdministratorAccess" or "AdministratorAccess" in p.get("PolicyArn", ""):
                                admins.append({"type": "user", "name": name, "policy": p.get("PolicyArn")})
                                break
                    except Exception:
                        continue
        except Exception:
            pass

        # Roles
        try:
            paginator = iam.get_paginator("list_roles")
            for page in paginator.paginate():
                for r in page.get("Roles", []):
                    name = r.get("RoleName")
                    if not name:
                        continue
                    try:
                        attached = iam.list_attached_role_policies(RoleName=name).get("AttachedPolicies", [])
                        for p in attached:
                            if p.get("PolicyName") == "AdministratorAccess" or "AdministratorAccess" in p.get("PolicyArn", ""):
                                admins.append({"type": "role", "name": name, "policy": p.get("PolicyArn")})
                                break
                    except Exception:
                        continue
        except Exception:
            pass

        if admins:
            results.append(
                Finding(
                    id="CLOUD_IAM_ADMIN_ENTITIES",
                    title="IAM principals with AdministratorAccess detected",
                    severity=Severity.HIGH,
                    category="cloud",
                    description="IAM users or roles were found with AdministratorAccess managed policy",
                    recommendation="Review administrative IAM principals and remove unnecessary AdministratorAccess",
                    metadata={"principals": admins},
                )
            )
    except (NoCredentialsError, NoRegionError):
        return results
    except (BotoCoreError, ClientError):
        return results
    return results


def _check_aws_open_security_groups() -> List[Finding]:
    results: List[Finding] = []
    try:
        ec2 = boto3.client("ec2")
        groups = ec2.describe_security_groups().get("SecurityGroups", [])
        # Sensitive ports mapping -> severity and label
        sensitive_map = {22: (Severity.CRITICAL, "SSH"), 3389: (Severity.CRITICAL, "RDP"), 3306: (Severity.HIGH, "MySQL")}
        for sg in groups:
            sg_id = sg.get("GroupId")
            ingress = sg.get("IpPermissions", [])
            for rule in ingress:
                from_port = rule.get("FromPort")
                to_port = rule.get("ToPort")
                cidrs = [ip_range.get("CidrIp") for ip_range in rule.get("IpRanges", []) if ip_range.get("CidrIp")]
                if "0.0.0.0/0" not in cidrs:
                    continue

                # If ports are None treat as all ports -> consider as exposing sensitive ports
                if from_port is None or to_port is None:
                    # all ports open; report CRITICAL for SSH/RDP and HIGH for DB
                    for port, (sev, label) in sensitive_map.items():
                        results.append(
                            Finding(
                                id="CLOUD_SG_OPEN_PORT",
                                title=f"Security group {sg_id} ({sg.get('GroupName')}) allows {label} to 0.0.0.0/0",
                                severity=sev,
                                category="cloud",
                                description=f"Security group {sg_id} has a rule exposing {label} to the public internet",
                                recommendation="Restrict the security group to known IP ranges or use a bastion/VPN",
                                metadata={"group_id": sg_id, "port": port, "cidr": "0.0.0.0/0"},
                            )
                        )
                    continue

                # explicit port range
                try:
                    ports = range(int(from_port), int(to_port) + 1)
                except Exception:
                    continue
                for p in ports:
                    if p in sensitive_map:
                        sev, label = sensitive_map[p]
                        results.append(
                            Finding(
                                id="CLOUD_SG_OPEN_PORT",
                                title=f"Security group {sg_id} ({sg.get('GroupName')}) allows {label} (port {p}) to 0.0.0.0/0",
                                severity=sev,
                                category="cloud",
                                description=f"Security group {sg_id} contains a rule exposing port {p} ({label}) to the public internet",
                                recommendation="Restrict the security group to required CIDR ranges and ports",
                                metadata={"group_id": sg_id, "port": p, "cidr": "0.0.0.0/0"},
                            )
                        )
    except (NoCredentialsError, NoRegionError):
        return results
    except (BotoCoreError, ClientError):
        return results
    return results


def _check_aws_access_keys() -> List[Finding]:
    results: List[Finding] = []
    try:
        client = boto3.client("iam")
        paginator = client.get_paginator("list_users")
        for page in paginator.paginate():
            for user in page.get("Users", []):
                username = user["UserName"]
                keys = client.list_access_keys(UserName=username).get("AccessKeyMetadata", [])
                if not keys:
                    continue
                for key in keys:
                    if key.get("Status") == "Inactive":
                        results.append(
                            Finding(
                                id="CLOUD_AWS_UNUSED_KEY",
                                title="Inactive AWS access key detected",
                                severity=Severity.MEDIUM,
                                category="cloud",
                                description="IAM user has inactive access keys that should be removed",
                                recommendation="Remove inactive or unused IAM access keys",
                                metadata={"user": username, "access_key_id": key.get("AccessKeyId")},
                            )
                        )
    except (NoCredentialsError, NoRegionError):
        return results
    except (BotoCoreError, ClientError):
        return results
    return results

