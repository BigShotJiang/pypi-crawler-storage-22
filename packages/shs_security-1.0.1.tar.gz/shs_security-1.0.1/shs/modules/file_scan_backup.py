from __future__ import annotations

import os
import platform
import re
import stat
import sys
from pathlib import Path
from typing import Iterable, List

from shs.core.rules import Finding, Severity
from shs.core.privilege import PrivilegeDetector


# ✅ EXCLUDED DIRECTORIES (safe/noisy dirs)
EXCLUDE_DIRS = {
    ".venv", "venv", "site-packages", "__pycache__", ".git",
    "node_modules", "dist", "build", "target",
    ".idea", ".vscode", "miniconda3", ".conda",
    ".pytest_cache", ".egg-info", "eggs",
    "Library", "Caches", ".cache"
}

# Secret detection patterns
AWS_KEY_PATTERN = re.compile(r"AKIA[0-9A-Z]{16}")
GENERIC_KEY_PATTERN = re.compile(
    r"(api_key|apikey|secret_key|access_token|auth_token|password)\s*=\s*[\"'][A-Za-z0-9/\+=]{16,}[\"']",
    re.IGNORECASE
)
PRIVATE_KEY_PATTERN = re.compile(
    r"-----BEGIN (RSA|DSA|EC|OPENSSH|PGP) PRIVATE KEY",
    re.IGNORECASE
)


def _get_system_scan_paths(is_elevated: bool) -> List[Path]:
    """Get OS-specific directories to scan based on privilege level."""
    os_type = platform.system()
    paths = []
    
    if os_type == "Windows":
        # Windows paths
        home = Path.home()
        paths = [
            home,                                    # C:\Users\<user>
            home / "Documents",                      # Explicitly add Documents
            Path(os.environ.get("APPDATA", "")),    # C:\Users\<user>\AppData\Roaming
            Path(os.environ.get("LOCALAPPDATA", "")),  # C:\Users\<user>\AppData\Local
        ]
        
        # Check for OneDrive Documents (might be cloud-synced)
        onedrive_docs = home / "OneDrive" / "Documents"
        if onedrive_docs.exists():
            paths.append(onedrive_docs)
        
        if is_elevated:
            # Admin can scan more
            paths.extend([
                Path("C:\\Temp") if Path("C:\\Temp").exists() else None,
                Path("C:\\Windows\\Temp") if Path("C:\\Windows\\Temp").exists() else None,
            ])
    else:
        # Linux/macOS paths
        home = Path.home()
        paths = [
            home,                           # /home/<user> or /Users/<user>
            Path("/tmp"),                   # /tmp
            Path("/var/tmp") if Path("/var/tmp").exists() else None,
        ]
        
        if is_elevated:
            # Root can scan system-wide
            paths.extend([
                Path("/opt") if Path("/opt").exists() else None,
                Path("/srv") if Path("/srv").exists() else None,
                Path("/var/www") if Path("/var/www").exists() else None,
                Path("/etc") if Path("/etc").exists() else None,
            ])
    
    # Filter out None and non-existent paths
    return [p for p in paths if p and p.exists()]


# ✅ System directory scan (Windows & Linux aware)
def run_scan(root: Path | None = None) -> List[Finding]:
    findings: List[Finding] = []
    
    if root:
        # Explicit path provided (e.g., for testing)
        scan_paths = [root]
    else:
        # Use OS-specific system paths
        priv_info = PrivilegeDetector.detect()
        is_elevated = priv_info.is_elevated
        scan_paths = _get_system_scan_paths(is_elevated)
    
    for scan_path in scan_paths:
        if not scan_path.exists():
            continue
        
        try:
            findings.extend(_detect_env_files(scan_path))
            findings.extend(_scan_for_secrets(scan_path))
            findings.extend(_find_world_writable(scan_path))
            findings.extend(_find_backup_files(scan_path))
            findings.extend(_find_private_keys(scan_path))
        except PermissionError:
            # Skip directories we can't read
            continue
    
    return findings


def _detect_env_files(root: Path) -> List[Finding]:
    results: List[Finding] = []
    for path in _iter_files(root):
        if path.name == ".env" or path.suffix.lower() in {".env", ".env.local"}:
            results.append(
                Finding(
                    id="FILE_ENV_PRESENT",
                    title=".env file detected",
                    severity=Severity.MEDIUM,
                    category="files",
                    description=".env files may contain secrets in plaintext",
                    recommendation="Move secrets to secret manager",
                    metadata={"path": str(path)},
                )
            )
    return results


def _scan_for_secrets(root: Path) -> List[Finding]:
    results: List[Finding] = []
    for path in _iter_files(root):
        try:
            if path.stat().st_size > 1024 * 1024:
                continue
        except OSError:
            continue

        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue

        if AWS_KEY_PATTERN.search(content):
            results.append(
                Finding(
                    id="FILE_AWS_KEY",
                    title="Potential AWS access key detected",
                    severity=Severity.CRITICAL,
                    category="files",
                    description="AWS key found",
                    recommendation="Rotate immediately",
                    metadata={"path": str(path)},
                )
            )

        if GENERIC_KEY_PATTERN.search(content):
            results.append(
                Finding(
                    id="FILE_GENERIC_SECRET",
                    title="Potential API key or secret detected",
                    severity=Severity.HIGH,
                    category="files",
                    description="Plaintext secret found",
                    recommendation="Move to env variables",
                    metadata={"path": str(path)},
                )
            )

    return results


# ❌ Windows permission scan skip
def _find_world_writable(root: Path) -> List[Finding]:
    if sys.platform.startswith("win"):
        return []

    results: List[Finding] = []
    for path in _iter_files(root):
        try:
            mode = path.stat().st_mode
        except OSError:
            continue

        if mode & stat.S_IWOTH:
            results.append(
                Finding(
                    id="FILE_WORLD_WRITABLE",
                    title="World-writable file detected",
                    severity=Severity.MEDIUM,
                    category="files",
                    description="File writable by all users",
                    recommendation="Restrict permissions",
                    metadata={"path": str(path)},
                )
            )

    return results


def _find_backup_files(root: Path) -> List[Finding]:
    results: List[Finding] = []
    backup_suffixes = {".bak", ".back", ".backup", ".old", ".orig", ".tmp", ".swp"}

    for path in _iter_files(root):
        if path.suffix.lower() in backup_suffixes or path.name.endswith("~"):
            results.append(
                Finding(
                    id="FILE_BACKUP_PRESENT",
                    title="Potential backup file detected",
                    severity=Severity.LOW,
                    category="files",
                    description="Old backup file found",
                    recommendation="Remove backup files",
                    metadata={"path": str(path)},
                )
            )

    return results


def _find_private_keys(root: Path) -> List[Finding]:
    """Detect private keys (RSA, OpenSSH, PGP, etc.) in plaintext."""
    results: List[Finding] = []
    
    # Common private key file extensions and names
    key_patterns = {".key", ".pem", ".ppk", ".pub", "id_rsa", "id_dsa", "id_ed25519"}
    
    for path in _iter_files(root):
        # Check by filename/extension
        if path.suffix.lower() in key_patterns or any(pat in path.name for pat in ["id_", "key"]):
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
                if PRIVATE_KEY_PATTERN.search(content):
                    results.append(
                        Finding(
                            id="FILE_PRIVATE_KEY",
                            title="Private key file detected",
                            severity=Severity.CRITICAL,
                            category="files",
                            description="RSA/OpenSSH/PGP private key found in plaintext",
                            recommendation="Move to secure key manager, never commit keys",
                            metadata={"path": str(path)},
                        )
                    )
            except (OSError, UnicodeDecodeError):
                continue
    
    return results


# ✅ FIXED WALKER (FAST + SAFE - handles permission errors gracefully)
def _iter_files(root: Path) -> Iterable[Path]:
    """Recursively yield files in root, skipping excluded directories."""
    try:
        for dirpath, dirnames, filenames in os.walk(root, topdown=True, onerror=lambda e: None):
            dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]

            for filename in filenames:
                try:
                    yield Path(dirpath) / filename
                except (OSError, PermissionError):
                    continue
    except (OSError, PermissionError):
        return
