"""
Full-System File Scanner for SHS (Security Hygiene Scanner)

Scans entire system (all drives/directories) for sensitive files.
- Supports Windows and Linux
- Detects .env, secrets, private keys, backups
- Respects permissions and handles errors gracefully
- Optimized for performance and safety
"""

from __future__ import annotations

import os
import platform
import re
import stat
import sys
from pathlib import Path
from typing import Generator, Iterable, List, Set

from shs.core.rules import Finding, Severity
from shs.core.privilege import PrivilegeDetector


# ============================================================================
# CONFIGURATION
# ============================================================================

# Directories to skip (noisy/system/cache directories)
EXCLUDE_DIRS = {
    # Version control
    ".git", ".hg", ".svn", ".bzr",
    
    # Python
    ".venv", "venv", "env", "ENV", "site-packages", "__pycache__",
    ".pytest_cache", ".mypy_cache", ".egg-info", "eggs", "*.egg",
    
    # Node.js
    "node_modules", ".npm", "bower_components",
    
    # Ruby
    "gems", ".bundle", "vendor/bundle",
    
    # Java
    ".gradle", ".m2", "target", "build", "dist",
    
    # IDE/Editor
    ".idea", ".vscode", ".vim", ".emacs.d", "*.swp",
    
    # Build artifacts
    "dist", "build", "out", "obj", "bin",
    
    # Package managers
    "miniconda3", ".conda", ".nvm", ".rvm",
    
    # System/OS
    "System Volume Information", "$Recycle.Bin", ".Trash", 
    "Library", "Caches", ".cache", ".local", ".config",
    "boots", "proc", "sys", "run", "dev", "tmp",
    
    # Cloud/Sync
    ".dropbox", ".icloud", "OneDrive", "Sync.com", "GoogleDrive"
}

# Symlink recursion limit
MAX_SYMLINK_DEPTH = 3

# File size limit for content scanning (1GB)
MAX_FILE_SIZE = 1024 * 1024 * 1024

# Sensitive file patterns
SENSITIVE_FILE_PATTERNS = {
    # Environment files
    ".env": re.compile(r"\.env.*", re.IGNORECASE),
    
    # Secret/key files
    "private_keys": re.compile(
        r"\.(key|pem|ppk|p12|p8|pfx|jks|keystore)$|id_rsa|id_dsa|id_ed25519|id_ecdsa|ssh_key",
        re.IGNORECASE
    ),
    
    # Backup files
    "backups": re.compile(
        r"\.(bak|backup|back|old|orig|tmp|swp|swo|tmp|cache)$|~$",
        re.IGNORECASE
    ),
    
    # Compressed files (may contain source)
    "archives": re.compile(
        r"\.(zip|tar|tar\.gz|tar\.bz2|rar|7z)$",
        re.IGNORECASE
    ),
    
    # Config files with potential secrets
    "configs": re.compile(
        r"\.(conf|config|cfg|yml|yaml|json|xml|properties|env|ini)$",
        re.IGNORECASE
    ),
}

# Secret detection patterns (content-based)
SECRET_PATTERNS = {
    "aws_key": re.compile(r"AKIA[0-9A-Z]{16}"),
    "private_key": re.compile(
        r"-----BEGIN\s+(RSA|DSA|EC|OPENSSH|PGP)\s+PRIVATE\s+KEY",
        re.IGNORECASE | re.MULTILINE
    ),
    "api_key": re.compile(
        r"(api[_-]?key|apikey|api[_-]?secret|secret[_-]?key)\s*[:=]\s*[\"']([A-Za-z0-9/\+=\-_]{16,256})[\"']",
        re.IGNORECASE
    ),
    "jwt_token": re.compile(
        r"(eyJ[A-Za-z0-9_\-\.]+\.eyJ[A-Za-z0-9_\-\.]+\.)",
        re.IGNORECASE
    ),
    "aws_secret": re.compile(
        r"(aws[_-]?secret|aws[_-]?access[_-]?key[_-]?id)\s*[:=]",
        re.IGNORECASE
    ),
    "password": re.compile(
        r"(password|passwd|pwd)\s*[:=]\s*[\"']([^\s\"']{8,})[\"']",
        re.IGNORECASE
    ),
    "github_token": re.compile(
        r"(github[_-]?token|ghp_[A-Za-z0-9_]{36,})",
        re.IGNORECASE
    ),
    "slack_token": re.compile(
        r"(xox[baprs]-[0-9]{10,13}-[0-9a-zA-Z]{24,26})",
    ),
}


# ============================================================================
# SYSTEM DISCOVERY
# ============================================================================

def _get_system_roots() -> List[Path]:
    """Get all accessible system roots (drives on Windows, / on Linux)."""
    roots = []
    os_type = platform.system()
    
    if os_type == "Windows":
        # Get all drive letters
        import string
        import ctypes
        
        for drive_letter in string.ascii_uppercase:
            drive = f"{drive_letter}:\\"
            if ctypes.windll.kernel32.GetDriveTypeW(drive) != 0:  # Drive exists
                roots.append(Path(drive))
    else:
        # Linux/macOS - start from root
        roots.append(Path("/"))
    
    return roots


def _get_mounted_paths(root: Path) -> List[Path]:
    """Get all mounted filesystems accessible from root."""
    paths = [root]
    
    # Check for common mounted locations
    if root == Path("/"):
        mounted = [
            Path("/mnt"),      # Manual mounts
            Path("/media"),    # Auto mounts
            Path("/home"),     # User home
            Path("/var"),      # Variable data
            Path("/srv"),      # Services
        ]
        paths.extend([p for p in mounted if p.exists()])
    
    return paths


# ============================================================================
# SCANNING ENGINE
# ============================================================================

def run_full_system_scan(debug: bool = False) -> List[Finding]:
    """
    Scan entire accessible system for sensitive files.
    
    Windows: Scans all drives (C:, D:, etc.)
    Linux: Scans / and all mounted filesystems
    
    Args:
        debug: If True, print debug information
        
    Returns:
        List of Finding objects with detected sensitive files
    """
    findings: List[Finding] = []
    priv_info = PrivilegeDetector.detect()
    
    if debug:
        print(f"[DEBUG] === FULL SYSTEM FILE SCAN ===", file=sys.stderr)
        print(f"[DEBUG] OS: {platform.system()}", file=sys.stderr)
        print(f"[DEBUG] Privilege: {priv_info.level.value}", file=sys.stderr)
        print(f"[DEBUG] Elevated: {priv_info.is_elevated}", file=sys.stderr)
    
    # Get system roots
    roots = _get_system_roots()
    
    if debug:
        print(f"[DEBUG] Scanning {len(roots)} root path(s)", file=sys.stderr)
    
    for root in roots:
        if not root.exists():
            continue
        
        if debug:
            print(f"[DEBUG] Scanning: {root}", file=sys.stderr)
        
        try:
            findings.extend(_scan_directory_tree(
                root,
                is_elevated=priv_info.is_elevated,
                debug=debug
            ))
        except Exception as e:
            if debug:
                print(f"[DEBUG] Error scanning {root}: {e}", file=sys.stderr)
            continue
    
    return findings


def _scan_directory_tree(
    root: Path,
    is_elevated: bool,
    symlink_depth: int = 0,
    debug: bool = False
) -> List[Finding]:
    """Recursively scan directory tree for sensitive files."""
    findings: List[Finding] = []
    visited_inodes: Set[int] = set()
    
    def _walk(path: Path, depth: int = 0) -> Generator[Finding, None, None]:
        """Walk directory tree with safety checks."""
        
        # Prevent symlink loops
        if depth > 10:  # Max recursion depth
            return
        
        try:
            # Check for symlink loops (via inode)
            try:
                inode = path.stat().st_ino
                if inode in visited_inodes:
                    return
                visited_inodes.add(inode)
            except (OSError, AttributeError):
                pass
        
        except PermissionError:
            if debug and is_elevated:
                print(f"[DEBUG] Permission denied: {path}", file=sys.stderr)
            return
        except OSError as e:
            # Catch other OS errors gracefully
            return
        
        # Skip excluded directories
        if path.name in EXCLUDE_DIRS or any(
            path.name.lower().startswith(excl.lower()) 
            for excl in EXCLUDE_DIRS
        ):
            if debug:
                print(f"[DEBUG] Skipping excluded: {path}", file=sys.stderr)
            return
        
        # List directory
        try:
            entries = list(path.iterdir())
        except (PermissionError, OSError):
            return
        
        # Process entries
        for entry in entries:
            # Files
            if entry.is_file(follow_symlinks=False):
                try:
                    for finding in _scan_file(entry):
                        yield finding
                except Exception as e:
                    if debug:
                        print(f"[DEBUG] Error scanning file {entry}: {e}", file=sys.stderr)
                    continue
            
            # Directories (recurse)
            elif entry.is_dir(follow_symlinks=False):
                # Prevent /dev, /proc, /sys on Linux
                if entry.name in {"dev", "proc", "sys"} and entry.parent.name == "":
                    continue
                
                try:
                    for finding in _walk(entry, depth + 1):
                        yield finding
                except RecursionError:
                    return
    
    findings.extend(list(_walk(root)))
    return findings


def _scan_file(file_path: Path) -> Generator[Finding, None, None]:
    """Check single file for sensitive content."""
    
    # Check by filename
    for file_finding in _check_filename(file_path):
        yield file_finding
    
    # Check by content (if safe)
    try:
        size = file_path.stat().st_size
        if size <= MAX_FILE_SIZE:  # Only scan files under size limit
            for content_finding in _check_content(file_path):
                yield content_finding
    except (OSError, ValueError):
        pass


def _check_filename(file_path: Path) -> Generator[Finding, None, None]:
    """Detect sensitive files by filename pattern."""
    filename = file_path.name
    
    # .env files
    if filename.startswith(".env"):
        yield Finding(
            id="FILE_ENV_DETECTED",
            title=".env file detected",
            severity=Severity.MEDIUM,
            category="files",
            description=f"Environment file may contain secrets: {file_path}",
            recommendation="Move secrets to secret manager, never commit .env files",
            metadata={"path": str(file_path), "type": "env"}
        )
        return
    
    # Private keys
    if _matches_pattern(filename, "private_keys"):
        yield Finding(
            id="FILE_PRIVATE_KEY_DETECTED",
            title="Private key file detected",
            severity=Severity.CRITICAL,
            category="files",
            description=f"RSA/SSH private key detected: {file_path}",
            recommendation="Protect with strong passphrase, never commit, rotate if exposed",
            metadata={"path": str(file_path), "type": "private_key"}
        )
        return
    
    # Backup files
    if _matches_pattern(filename, "backups"):
        yield Finding(
            id="FILE_BACKUP_DETECTED",
            title="Backup/temporary file detected",
            severity=Severity.LOW,
            category="files",
            description=f"Old backup or temporary file: {file_path}",
            recommendation="Delete old backup files to reduce attack surface",
            metadata={"path": str(file_path), "type": "backup"}
        )
        return


def _check_content(file_path: Path) -> Generator[Finding, None, None]:
    """Detect sensitive content by regex patterns."""
    
    try:
        # Read file content safely
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read(10 * 1024 * 1024)  # Max 10MB read
        except (UnicodeDecodeError, OSError):
            return
        
        # Check secret patterns
        for pattern_name, pattern in SECRET_PATTERNS.items():
            matches = pattern.findall(content)
            if matches:
                if pattern_name == "private_key":
                    yield Finding(
                        id="FILE_PRIVATE_KEY_CONTENT",
                        title="Private key detected in file",
                        severity=Severity.CRITICAL,
                        category="files",
                        description=f"RSA/SSH private key found in: {file_path}",
                        recommendation="Remove immediately, rotate keys if exposed",
                        metadata={"path": str(file_path), "pattern": pattern_name}
                    )
                
                elif pattern_name == "aws_key":
                    yield Finding(
                        id="FILE_AWS_KEY_DETECTED",
                        title="AWS access key detected",
                        severity=Severity.CRITICAL,
                        category="files",
                        description=f"AWS key (AKIA*) found in: {file_path}",
                        recommendation="Rotate key immediately, check AWS for unauthorized access",
                        metadata={"path": str(file_path), "pattern": pattern_name}
                    )
                
                elif pattern_name == "github_token":
                    yield Finding(
                        id="FILE_GITHUB_TOKEN_DETECTED",
                        title="GitHub token detected",
                        severity=Severity.CRITICAL,
                        category="files",
                        description=f"GitHub personal access token found in: {file_path}",
                        recommendation="Revoke token immediately in GitHub UI",
                        metadata={"path": str(file_path), "pattern": pattern_name}
                    )
                
                elif pattern_name == "slack_token":
                    yield Finding(
                        id="FILE_SLACK_TOKEN_DETECTED",
                        title="Slack token detected",
                        severity=Severity.CRITICAL,
                        category="files",
                        description=f"Slack API token found in: {file_path}",
                        recommendation="Revoke token immediately in Slack workspace",
                        metadata={"path": str(file_path), "pattern": pattern_name}
                    )
                
                elif pattern_name == "api_key":
                    yield Finding(
                        id="FILE_API_KEY_DETECTED",
                        title="API key/secret detected",
                        severity=Severity.HIGH,
                        category="files",
                        description=f"Hardcoded API key found in: {file_path}",
                        recommendation="Move to environment variables or secret manager",
                        metadata={"path": str(file_path), "pattern": pattern_name}
                    )
                
                elif pattern_name == "password":
                    yield Finding(
                        id="FILE_PASSWORD_DETECTED",
                        title="Hardcoded password detected",
                        severity=Severity.HIGH,
                        category="files",
                        description=f"Hardcoded password found in: {file_path}",
                        recommendation="Remove immediately, use secure credential storage",
                        metadata={"path": str(file_path), "pattern": pattern_name}
                    )
                
                elif pattern_name == "jwt_token":
                    yield Finding(
                        id="FILE_JWT_TOKEN_DETECTED",
                        title="JWT token detected",
                        severity=Severity.HIGH,
                        category="files",
                        description=f"JWT bearer token found in: {file_path}",
                        recommendation="Rotate token, check if exposed in logs",
                        metadata={"path": str(file_path), "pattern": pattern_name}
                    )
    
    except Exception:
        pass


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def _matches_pattern(filename: str, pattern_type: str) -> bool:
    """Check if filename matches pattern."""
    if pattern_type not in SENSITIVE_FILE_PATTERNS:
        return False
    
    return bool(SENSITIVE_FILE_PATTERNS[pattern_type].search(filename))


def run_scan(root: Path | None = None) -> List[Finding]:
    """
    Main entry point for file scanning.
    
    If root is provided, scans only that directory.
    Otherwise, performs full system scan.
    """
    if root:
        # Specific directory scan (for testing)
        return _scan_directory_tree(root, is_elevated=True)
    else:
        # Full system scan
        return run_full_system_scan()
