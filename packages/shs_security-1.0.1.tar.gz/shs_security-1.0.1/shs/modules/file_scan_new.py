"""
Production-Grade File System Scanner for SHS

Scans system directories and mounted drives for sensitive files.
- Full system scan (all drives on Windows, / on Linux)
- Detects .env, secrets, private keys, backups
- Safe permission handling and error recovery
- Performance optimized for large systems
"""

from __future__ import annotations

import os
import platform
import re
import stat
import sys
import string
from pathlib import Path
from typing import Generator, Iterable, List, Set

from shs.core.rules import Finding, Severity
from shs.core.privilege import PrivilegeDetector


# ============================================================================
# CONFIGURATION
# ============================================================================

# Directories to skip (system/cache/build/vcs)
EXCLUDE_DIRS = {
    # Version control
    ".git", ".hg", ".svn", ".bzr",
    
    # Python
    ".venv", "venv", "env", "site-packages", "__pycache__",
    ".pytest_cache", ".mypy_cache", ".egg-info", "eggs",
    
    # Node.js
    "node_modules", ".npm", "bower_components",
    
    # Build
    ".gradle", ".m2", "target", "build", "dist", "out", "obj", "bin",
    
    # IDE
    ".idea", ".vscode", ".vim", ".emacs.d",
    
    # System (Linux)
    "proc", "sys", "run", "dev",
    
    # System (General)
    "System Volume Information", "$Recycle.Bin", ".Trash",
    "Library", "Caches", ".cache", ".local", ".config",
    
    # Cloud sync
    ".dropbox", ".icloud", "OneDrive", "GoogleDrive"
}

# File type detection patterns
PATTERNS = {
    # Environment files
    "env_file": re.compile(r"^\.env(\..+)?$", re.IGNORECASE),
    
    # Private keys
    "private_key_file": re.compile(
        r"\.(key|pem|ppk|p12|p8|pfx|jks)$|^id_(rsa|dsa|ed25519|ecdsa)$",
        re.IGNORECASE
    ),
    
    # Backups
    "backup_file": re.compile(
        r"\.(bak|back|backup|old|orig|tmp|tmp|cache|swp|swo)$|~$",
        re.IGNORECASE
    ),
}

# Secret content patterns
SECRETS = {
    "aws_key_id": re.compile(r"AKIA[0-9A-Z]{16}"),
    "private_key_header": re.compile(
        r"-----BEGIN\s+(RSA|DSA|EC|OPENSSH|PGP)\s+PRIVATE\s+KEY",
        re.IGNORECASE
    ),
    "api_key": re.compile(
        r"(api[_-]?key|apikey|secret)\s*[:=]\s*[\"']([A-Za-z0-9/+=\-_]{16,})[\"']",
        re.IGNORECASE
    ),
    "github_token": re.compile(r"(ghp_|ghu_)[A-Za-z0-9_]{36,}"),
    "slack_token": re.compile(r"(xox[baprs]-[0-9]{10,13}-[0-9a-zA-Z]{24,26})"),
    "password": re.compile(
        r"(password|passwd)\s*[:=]\s*[\"']([^\s\"']{8,})[\"']",
        re.IGNORECASE
    ),
}

# Size limit for content scanning (100MB)
MAX_SCAN_SIZE = 100 * 1024 * 1024


# ============================================================================
# SYSTEM DISCOVERY
# ============================================================================

def _get_scan_roots() -> List[Path]:
    """Get all accessible system roots to scan."""
    roots = []
    os_type = platform.system()
    
    if os_type == "Windows":
        # Scan all drive letters
        try:
            import ctypes
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                # Check if drive exists
                if ctypes.windll.kernel32.GetDriveTypeW(drive) != 0:
                    roots.append(Path(drive))
        except Exception:
            # Fallback to common drives
            for letter in "CDEFGH":
                drive = f"{letter}:\\"
                if Path(drive).exists():
                    roots.append(Path(drive))
    else:
        # Linux/macOS - scan from root
        roots.append(Path("/"))
    
    return roots


def _should_skip(path: Path) -> bool:
    """Check if path should be skipped."""
    name = path.name
    
    # Skip excluded names
    if name in EXCLUDE_DIRS:
        return True
    
    # Skip hidden system directories on Linux
    if path.parent.name == "" and name in {"proc", "sys", "dev", "var"}:
        return True
    
    return False


# ============================================================================
# FILE SCANNING
# ============================================================================

def run_scan(root: Path | None = None, debug: bool = False) -> List[Finding]:
    """
    Scan for sensitive files.
    
    Args:
        root: If provided, scan only this directory. Otherwise, full system scan.
        debug: Print debug output
        
    Returns:
        List of findings
    """
    findings = []
    
    if root:
        # Specific directory scan
        if debug:
            print(f"[DEBUG] Scanning: {root}", file=sys.stderr)
        findings.extend(_scan_tree(root, debug=debug))
    else:
        # Full system scan
        priv_info = PrivilegeDetector.detect()
        is_elevated = priv_info.is_elevated
        
        roots = _get_scan_roots()
        if debug:
            print(f"[DEBUG] Full system scan on {len(roots)} root(s)", file=sys.stderr)
            print(f"[DEBUG] Elevated: {is_elevated}", file=sys.stderr)
        
        for scan_root in roots:
            if not scan_root.exists():
                continue
            
            try:
                findings.extend(_scan_tree(scan_root, debug=debug))
            except KeyboardInterrupt:
                raise
            except Exception as e:
                if debug:
                    print(f"[DEBUG] Error scanning {scan_root}: {e}", file=sys.stderr)
                continue
    
    return findings


def _scan_tree(
    root: Path,
    visited: Set[int] | None = None,
    depth: int = 0,
    debug: bool = False
) -> Generator[Finding, None, None]:
    """
    Recursively scan directory tree.
    
    Args:
        root: Directory to scan
        visited: Set of inode numbers already visited (prevent loops)
        depth: Current recursion depth
        debug: Print debug info
        
    Yields:
        Finding objects
    """
    if visited is None:
        visited = set()
    
    # Prevent infinite recursion
    if depth > 20:
        return
    
    # Prevent symlink loops via inode tracking
    try:
        inode = root.stat().st_ino
        if inode in visited:
            return
        visited.add(inode)
    except (OSError, AttributeError):
        return
    
    # Skip excluded paths
    if _should_skip(root):
        return
    
    # List directory
    try:
        entries = list(root.iterdir())
    except (PermissionError, OSError):
        return
    
    for entry in entries:
        try:
            if entry.is_file(follow_symlinks=False):
                # Scan file
                yield from _scan_file(entry, debug=debug)
            
            elif entry.is_dir(follow_symlinks=False):
                # Recurse into subdirectory
                yield from _scan_tree(entry, visited, depth + 1, debug=debug)
        
        except KeyboardInterrupt:
            raise
        except Exception:
            # Skip problematic entries
            continue


def _scan_file(file_path: Path, debug: bool = False) -> Generator[Finding, None, None]:
    """Scan single file for sensitive content."""
    
    # Check filename
    yield from _check_filename(file_path)
    
    # Check content if safe
    try:
        size = file_path.stat().st_size
        if size > 0 and size <= MAX_SCAN_SIZE:
            yield from _check_content(file_path, debug=debug)
    except (OSError, ValueError):
        pass


def _check_filename(file_path: Path) -> Generator[Finding, None, None]:
    """Detect sensitive files by filename."""
    name = file_path.name
    
    # .env files
    if PATTERNS["env_file"].match(name):
        yield Finding(
            id="FILE_ENV_DETECTED",
            title=".env file detected",
            severity=Severity.MEDIUM,
            category="files",
            description=f"Environment configuration file may contain secrets",
            recommendation="Never commit .env files; use secret vault instead",
            metadata={"path": str(file_path)}
        )
    
    # Private keys
    elif PATTERNS["private_key_file"].match(name):
        yield Finding(
            id="FILE_PRIVATE_KEY_DETECTED",
            title="Private key file detected",
            severity=Severity.CRITICAL,
            category="files",
            description=f"SSH/RSA private key file found",
            recommendation="Protect with passphrase; rotate if exposed; never commit",
            metadata={"path": str(file_path)}
        )
    
    # Backup files
    elif PATTERNS["backup_file"].match(name):
        yield Finding(
            id="FILE_BACKUP_DETECTED",
            title="Backup file detected",
            severity=Severity.LOW,
            category="files",
            description=f"Backup or temporary file found",
            recommendation="Delete old backups; reduce attack surface",
            metadata={"path": str(file_path)}
        )


def _check_content(file_path: Path, debug: bool = False) -> Generator[Finding, None, None]:
    """Scan file content for secrets."""
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, IOError):
        return
    
    # AWS keys
    if SECRETS["aws_key_id"].search(content):
        yield Finding(
            id="FILE_AWS_KEY_DETECTED",
            title="AWS access key detected",
            severity=Severity.CRITICAL,
            category="files",
            description="AWS key ID (AKIA*) found in file content",
            recommendation="Rotate key immediately; check CloudTrail for misuse",
            metadata={"path": str(file_path), "secret_type": "aws_key"}
        )
    
    # Private keys in content
    if SECRETS["private_key_header"].search(content):
        yield Finding(
            id="FILE_PRIVATE_KEY_CONTENT",
            title="Private key detected in file",
            severity=Severity.CRITICAL,
            category="files",
            description="RSA/SSH private key header found in file content",
            recommendation="Remove immediately; rotate key; check git history",
            metadata={"path": str(file_path), "secret_type": "private_key"}
        )
    
    # GitHub tokens
    if SECRETS["github_token"].search(content):
        yield Finding(
            id="FILE_GITHUB_TOKEN_DETECTED",
            title="GitHub token detected",
            severity=Severity.CRITICAL,
            category="files",
            description="GitHub personal access token found",
            recommendation="Revoke immediately in GitHub settings; rotate",
            metadata={"path": str(file_path), "secret_type": "github_token"}
        )
    
    # Slack tokens
    if SECRETS["slack_token"].search(content):
        yield Finding(
            id="FILE_SLACK_TOKEN_DETECTED",
            title="Slack token detected",
            severity=Severity.CRITICAL,
            category="files",
            description="Slack API token found",
            recommendation="Revoke immediately in Slack admin panel",
            metadata={"path": str(file_path), "secret_type": "slack_token"}
        )
    
    # API keys
    if SECRETS["api_key"].search(content):
        yield Finding(
            id="FILE_API_KEY_DETECTED",
            title="API key detected",
            severity=Severity.HIGH,
            category="files",
            description="Hardcoded API key/secret found",
            recommendation="Use environment variables or secret manager",
            metadata={"path": str(file_path), "secret_type": "api_key"}
        )
    
    # Passwords
    if SECRETS["password"].search(content):
        yield Finding(
            id="FILE_PASSWORD_DETECTED",
            title="Hardcoded password detected",
            severity=Severity.HIGH,
            category="files",
            description="Hardcoded password found in file",
            recommendation="Remove; use secure credential storage",
            metadata={"path": str(file_path), "secret_type": "password"}
        )


# World-writable file detection (Linux only)
def _check_permissions(file_path: Path) -> Generator[Finding, None, None]:
    """Detect world-writable files (Unix only)."""
    if not sys.platform.startswith("linux") and not sys.platform == "darwin":
        return
    
    try:
        mode = file_path.stat().st_mode
        if mode & stat.S_IWOTH:  # World writable
            yield Finding(
                id="FILE_WORLD_WRITABLE",
                title="World-writable file detected",
                severity=Severity.MEDIUM,
                category="files",
                description="File is writable by all users",
                recommendation="Restrict permissions (chmod o-w)",
                metadata={"path": str(file_path), "mode": oct(stat.S_IMODE(mode))}
            )
    except (OSError, ValueError):
        pass
