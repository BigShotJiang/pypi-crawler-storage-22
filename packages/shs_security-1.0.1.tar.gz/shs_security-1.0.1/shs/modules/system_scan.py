from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import List, Tuple, Dict, Optional

import psutil

from shs.core.rules import Finding, Severity
from shs.core.os_detector import OSDetector, OSType
from shs.core.privilege import PrivilegeDetector
from shs.core.capabilities import CapabilityDetector


# ----------------------------
# CACHED DETECTION
# ----------------------------
_OS_INFO = None
_PRIV_INFO = None
_CAPS = None


def _os():
    global _OS_INFO
    if _OS_INFO is None:
        _OS_INFO = OSDetector.detect()
    return _OS_INFO


def _priv():
    global _PRIV_INFO
    if _PRIV_INFO is None:
        _PRIV_INFO = PrivilegeDetector.detect()
    return _PRIV_INFO


def _caps():
    global _CAPS
    if _CAPS is None:
        _CAPS = CapabilityDetector.detect()
    return _CAPS


# ----------------------------
# MAIN ENTRY
# ----------------------------
def run_scan() -> List[Finding]:
    findings: List[Finding] = []

    os_info = _os()
    priv = _priv()
    caps = _caps()

    findings.extend(_check_privileges(priv))

    if caps.firewall_check:
        findings.extend(_check_firewall(os_info))

    if caps.antivirus_check:
        findings.extend(_check_antivirus(os_info))

    if caps.update_check:
        findings.extend(_check_updates(os_info))

    findings.extend(_check_insecure_services())

    # --- Integrated end-of-system-scan checks (inventory, AV, coverage) ---
    # These run automatically as part of `shs scan --system` and are appended
    # to the end of the system findings so SOC/ops teams see them last.
    try:
        findings.extend(_check_app_inventory(os_info))
    except Exception:
        # Fail-safe: do not interrupt system scan on inventory errors
        pass

    try:
        findings.extend(_check_av_detection(os_info))
    except Exception:
        pass

    try:
        # Compute a lightweight security coverage summary and append as INFO
        cov = _compute_security_coverage(findings, os_info)
        if cov:
            findings.append(cov)
    except Exception:
        pass

    return findings


# ----------------------------
# PRIVILEGES
# ----------------------------
def _check_privileges(priv) -> List[Finding]:
    if not priv.is_elevated:
        return []

    return [
        Finding(
            id="SYSTEM_ELEVATED",
            title=f"Scanner running with {priv.level.value} privileges",
            severity=Severity.HIGH,
            category="system",
            description="Scanner is running with elevated privileges",
            recommendation="Run as normal user when possible",
            metadata={"user": priv.username, "level": priv.level.value},
        )
    ]


# ----------------------------
# FIREWALL (FIXED)
# ----------------------------
def _check_firewall(os_info) -> List[Finding]:
    if os_info.os_type == OSType.WINDOWS:
        enabled, meta = _windows_firewall()
    elif os_info.os_type == OSType.LINUX:
        enabled, meta = _linux_firewall()
    elif os_info.os_type == OSType.MACOS:
        enabled, meta = _macos_firewall()
    else:
        return []

    if not enabled:
        return [
            Finding(
                id="FIREWALL_DISABLED",
                title="Host firewall disabled",
                severity=Severity.CRITICAL,
                category="system",
                description="No active firewall profile detected",
                recommendation="Enable host firewall immediately",
                metadata=meta,
            )
        ]

    return [
        Finding(
            id="FIREWALL_ENABLED",
            title="Host firewall enabled",
            severity=Severity.INFO,
            category="system",
            description="Active firewall profile detected",
            recommendation="Verify rules are restrictive",
            metadata=meta,
        )
    ]


def _windows_firewall() -> Tuple[bool, Dict]:
    code, output = _run("netsh advfirewall show allprofiles")
    if code != 0:
        return False, {"error": "cannot read firewall state"}

    enabled_profiles = []
    for line in output.splitlines():
        if "State" in line and "ON" in line.upper():
            enabled_profiles.append(line.strip())

    return bool(enabled_profiles), {"profiles": enabled_profiles}


def _linux_firewall() -> Tuple[bool, Dict]:
    if shutil.which("ufw"):
        code, out = _run("ufw status")
        return "Status: active" in out, {"ufw": out.strip()}

    if shutil.which("firewall-cmd"):
        code, out = _run("firewall-cmd --state")
        return "running" in out.lower(), {"firewalld": out.strip()}

    if shutil.which("iptables"):
        code, out = _run("iptables -L")
        return "Chain" in out, {"iptables": "rules present"}

    return False, {}


def _macos_firewall() -> Tuple[bool, Dict]:
    code, out = _run("defaults read /Library/Preferences/com.apple.alf globalstate")
    return out.strip() == "1", {"macos_firewall": out.strip()}


# ----------------------------
# ANTIVIRUS (CORRECT)
# ----------------------------
def _check_antivirus(os_info) -> List[Finding]:
    if os_info.os_type == OSType.WINDOWS:
        found, meta = _windows_antivirus()
    elif os_info.os_type == OSType.LINUX:
        found, meta = _linux_antivirus()
    else:
        found, meta = False, {}

    if not found:
        return [
            Finding(
                id="ANTIVIRUS_MISSING",
                title="No antivirus detected",
                severity=Severity.MEDIUM,
                category="system",
                description="No endpoint protection detected",
                recommendation="Install antivirus or EDR",
                metadata=meta,
            )
        ]

    return [
        Finding(
            id="ANTIVIRUS_FOUND",
            title="Antivirus detected",
            severity=Severity.INFO,
            category="system",
            description="Endpoint protection detected",
            recommendation="Ensure real-time protection is enabled",
            metadata=meta,
        )
    ]


def _windows_antivirus() -> Tuple[bool, Dict]:
    code, out = _run(
        'powershell -Command "Get-MpComputerStatus | Select -ExpandProperty RealTimeProtectionEnabled"'
    )
    return "True" in out, {"windows_defender": out.strip()}


def _linux_antivirus() -> Tuple[bool, Dict]:
    for proc in psutil.process_iter(attrs=["name"]):
        if "clam" in (proc.info.get("name") or "").lower():
            return True, {"av": "ClamAV"}
    return False, {}


# ----------------------------
# UPDATES
# ----------------------------
def _check_updates(os_info) -> List[Finding]:
    if os_info.os_type == OSType.LINUX:
        return _linux_updates()
    if os_info.os_type == OSType.WINDOWS:
        return _windows_updates()
    return []


def _linux_updates() -> List[Finding]:
    apt = Path("/var/lib/apt/lists")
    if not apt.exists():
        return []

    age = (psutil.boot_time() - apt.stat().st_mtime) / 86400
    if age > 30:
        return [
            Finding(
                id="UPDATES_OUTDATED",
                title="System updates outdated",
                severity=Severity.HIGH,
                category="system",
                description="APT lists not updated recently",
                recommendation="Run apt update && upgrade",
                metadata={"days": int(age)},
            )
        ]
    return []


def _windows_updates() -> List[Finding]:
    code, out = _run(
        'powershell -Command "(New-Object -ComObject Microsoft.Update.AutoUpdate).Results.LastInstallationSuccessDate"'
    )
    if out.strip():
        return [
            Finding(
                id="WINDOWS_UPDATE",
                title="Windows update checked",
                severity=Severity.INFO,
                category="system",
                description="Windows update configured",
                recommendation="Ensure auto updates enabled",
                metadata={"last_update": out.strip()},
            )
        ]
    return []


# ----------------------------
# INSECURE SERVICES
# ----------------------------
def _check_insecure_services() -> List[Finding]:
    bad_ports = {21: "FTP", 23: "Telnet", 512: "rsh", 513: "rlogin"}
    seen = set()
    findings = []

    for c in psutil.net_connections(kind="inet"):
        if c.laddr and c.laddr.port in bad_ports and c.laddr.port not in seen:
            seen.add(c.laddr.port)
            findings.append(
                Finding(
                    id="INSECURE_SERVICE",
                    title=f"Insecure service {bad_ports[c.laddr.port]} running",
                    severity=Severity.CRITICAL,
                    category="system",
                    description="Legacy insecure service exposed",
                    recommendation="Disable service",
                    metadata={"port": c.laddr.port},
                )
            )

    return findings


# ----------------------------
# UTILITY
# ----------------------------
def _run(cmd: str) -> Tuple[int, str]:
    try:
        p = subprocess.run(
            cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True
        )
        return p.returncode, p.stdout
    except Exception:
        return 1, ""


# ----------------------------
# APPLICATION INVENTORY
# ----------------------------
def _check_app_inventory(os_info) -> List[Finding]:
    """Detect installed applications and risky legacy packages.

    Linux: use `dpkg-query` where available. Windows: best-effort PowerShell query.
    Returns INFO finding for total count and HIGH findings for each risky app.
    """
    results: List[Finding] = []
    risky = ["ftp", "telnet", "rsh", "netcat"]

    # Linux primary path
    if os_info.os_type == OSType.LINUX:
        try:
            code, out = _run("dpkg-query -W -f='${Package}\n'")
            if code == 0 and out:
                pkgs = [l.strip() for l in out.splitlines() if l.strip()]
                total = len(pkgs)
                results.append(
                    Finding(
                        id="APP_INVENTORY_COUNT",
                        title=f"Installed applications detected: {total}",
                        severity=Severity.INFO,
                        category="system",
                        description="Count of installed packages detected by dpkg",
                        recommendation="Use inventory to review installed software",
                        metadata={"total_installed": total},
                    )
                )
                lower = {p.lower() for p in pkgs}
                for r in risky:
                    # netcat may appear as 'nc'
                    check_names = [r]
                    if r == "netcat":
                        check_names.append("nc")
                    for name in check_names:
                        if name in lower:
                            results.append(
                                Finding(
                                    id="APP_RISKY_DETECTED",
                                    title=f"Risky application detected: {r}",
                                    severity=Severity.HIGH,
                                    category="system",
                                    description=f"Legacy or insecure application {r} is installed",
                                    recommendation="Remove or replace legacy services with secure alternatives",
                                    metadata={"package": name},
                                )
                            )
                            break
                return results
        except Exception:
            # Fall through to empty result on error
            pass

    # Windows best-effort via PowerShell
    if os_info.os_type == OSType.WINDOWS:
        try:
            code, out = _run(
                'powershell -Command "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object -ExpandProperty DisplayName"'
            )
            if code == 0 and out:
                apps = [l.strip() for l in out.splitlines() if l.strip()]
                total = len(apps)
                results.append(
                    Finding(
                        id="APP_INVENTORY_COUNT",
                        title=f"Installed applications detected: {total}",
                        severity=Severity.INFO,
                        category="system",
                        description="Count of installed applications (Windows registry)",
                        recommendation="Use inventory to review installed software",
                        metadata={"total_installed": total},
                    )
                )
                lower = {a.lower() for a in apps}
                for r in risky:
                    if r in lower:
                        results.append(
                            Finding(
                                id="APP_RISKY_DETECTED",
                                title=f"Risky application detected: {r}",
                                severity=Severity.HIGH,
                                category="system",
                                description=f"Legacy or insecure application {r} is installed",
                                recommendation="Remove or replace legacy services with secure alternatives",
                                metadata={"app": r},
                            )
                        )
                return results
        except Exception:
            pass

    # Unsupported / no data
    return []


# ----------------------------
# ANTIVIRUS / EDR DETECTION
# ----------------------------
def _check_av_detection(os_info) -> List[Finding]:
    """Detect common antivirus/EDR on host.

    Returns per-product findings. OS-specific detection based on platform.
    Detection methods: systemctl, process list, package presence. Read-only.
    """
    results: List[Finding] = []
    
    # OS-specific product lists
    if os_info.os_type == OSType.WINDOWS:
        # Windows products
        products = [
            {"name": "Windows Defender", "svc": ["WinDefend"], "procs": ["MsMpEng"], "pkgs": []},
            {"name": "Malwarebytes", "svc": ["MBAMService"], "procs": ["mbamtray", "mbam"], "pkgs": []},
        ]
    elif os_info.os_type == OSType.LINUX:
        # Linux products
        products = [
            {"name": "ClamAV", "svc": ["clamav-daemon", "clamd"], "procs": ["clamd", "freshclam"], "pkgs": ["clamav"]},
            {"name": "Sophos", "svc": ["sav-protect"], "procs": ["sav-protect"], "pkgs": ["sophos-av"]},
            {"name": "CrowdStrike Falcon", "svc": ["falcon-sensor"], "procs": ["falcon-sensor", "falcon"], "pkgs": ["falcon-sensor"]},
            {"name": "SentinelOne", "svc": ["sentinel-agent"], "procs": ["sentinel-agent", "sentinelctl"], "pkgs": ["sentinelone"]},
        ]
    elif os_info.os_type == OSType.MACOS:
        # macOS products
        products = [
            {"name": "XProtect", "svc": [], "procs": ["XProtect"], "pkgs": []},
            {"name": "Sophos", "svc": ["sophos-av"], "procs": ["sophos"], "pkgs": ["sophos-av"]},
        ]
    else:
        # Unknown OS
        products = []

    import shutil
    import psutil as _ps

    any_active = False
    any_installed = False
    active_count = 0

    # Windows best-effort: query SecurityCenter2 and Defender state once
    windows_av_names = set()
    defender_realtime = None
    if os_info.os_type == OSType.WINDOWS:
        try:
            code, out = _run(
                'powershell -Command "Get-CimInstance -Namespace root\\SecurityCenter2 -ClassName AntiVirusProduct | Select-Object -ExpandProperty displayName"'
            )
            if code == 0 and out:
                for l in out.splitlines():
                    if l.strip():
                        windows_av_names.add(l.strip().lower())
        except Exception:
            pass

        try:
            code, out = _run(
                'powershell -Command "(Get-MpComputerStatus).RealTimeProtectionEnabled"'
            )
            if code == 0 and out:
                defender_realtime = "true" in out.strip().lower()
        except Exception:
            defender_realtime = None

    for p in products:
        name = p["name"]
        status = "not_detected"

        # 1) systemctl
        for svc in p.get("svc", []):
            try:
                if shutil.which("systemctl"):
                    code, out = _run(f"systemctl is-active {svc}")
                    if code == 0 and "active" in out.lower():
                        status = "active"
                        break
            except Exception:
                pass

        # 2) process list
        if status != "active":
            try:
                procs = "\n".join([proc.info.get("name", "") for proc in _ps.process_iter(attrs=["name"])])
                for kw in p.get("procs", []):
                    if kw.lower() in procs.lower():
                        status = "active"
                        break
            except Exception:
                pass

        # 3) package/binary presence -> installed
        if status != "active":
            try:
                # dpkg check
                code, out = _run("dpkg-query -W -f='${Package}\n'")
                if code == 0 and out:
                    pkgs = {l.strip().lower() for l in out.splitlines()}
                    for pkg in p.get("pkgs", []):
                        if pkg and pkg.lower() in pkgs:
                            status = "installed"
                            break
            except Exception:
                pass

        # Windows checks could be added here (best-effort)

        if status == "active":
            results.append(
                Finding(
                    id=f"AV_{name.upper().replace(' ', '_')}",
                    title=f"Antivirus detected: {name} (active)",
                    severity=Severity.INFO,
                    category="system",
                    description=f"{name} appears to be installed and active",
                    recommendation="Ensure product is up-to-date and monitored",
                    metadata={"product": name, "status": "active"},
                )
            )
            any_active = True
            any_installed = True
            active_count += 1
        elif status == "installed":
            results.append(
                Finding(
                    id=f"AV_{name.upper().replace(' ', '_')}",
                    title=f"Antivirus installed: {name} (inactive)",
                    severity=Severity.MEDIUM,
                    category="system",
                    description=f"{name} appears installed but no active service/process detected",
                    recommendation="Start the agent or verify installation",
                    metadata={"product": name, "status": "installed"},
                )
            )
            any_installed = True
        else:
            # not detected: report later if nothing active
            results.append(
                Finding(
                    id=f"AV_{name.upper().replace(' ', '_')}_MISSING",
                    title=f"Antivirus not detected: {name}",
                    severity=Severity.HIGH,
                    category="system",
                    description=f"No evidence of {name} installation or active process",
                    recommendation="Install endpoint protection or verify agent deployment",
                    metadata={"product": name, "status": "not_detected"},
                )
            )

    # If at least one active AV found, suppress global HIGH warning; otherwise leave per-product HIGHs
    if any_active:
        # add summary INFO that antivirus coverage exists
        results.insert(0, Finding(
            id="AV_SUMMARY_ACTIVE",
            title="Antivirus/EDR detected and active",
            severity=Severity.INFO,
            category="system",
            description="One or more endpoint protection products are active",
            recommendation="Ensure endpoint alerts are sent to SOC",
            metadata={"active_count": active_count},
        ))

    return results


# ----------------------------
# SECURITY COVERAGE SUMMARY
# ----------------------------
def _compute_security_coverage(findings: List[Finding], os_info) -> Optional[Finding]:
    """Compute a simple defensive coverage summary based on findings and lightweight checks.

    Checks performed:
      - Firewall enabled
      - Antivirus present (active)
      - MFA detected (best-effort via PAM/sshd)
      - System updates enabled (APT lists not stale)

    Returns one INFO Finding summarizing coverage and missing controls.
    """
    score = 0
    total = 4
    missing = []

    # Firewall: look for FIREWALL_ENABLED finding
    fw = any(f.id == "FIREWALL_ENABLED" for f in findings)
    if fw:
        score += 1
    else:
        missing.append("Firewall")

    # Antivirus: check AV_SUMMARY_ACTIVE or any AV_* active
    av_active = any(f.id == "AV_SUMMARY_ACTIVE" for f in findings)
    if av_active:
        score += 1
    else:
        missing.append("Antivirus")

    # MFA: best-effort PAM/sshd check
    mfa_ok = False
    try:
        pam = Path("/etc/pam.d/sshd")
        if pam.exists():
            txt = pam.read_text(encoding="utf-8", errors="ignore")
            if "pam_google_authenticator.so" in txt or "pam_oath.so" in txt or "pam_duo.so" in txt:
                mfa_ok = True
    except Exception:
        pass
    if mfa_ok:
        score += 1
    else:
        missing.append("MFA")

    # Updates: if there is no UPDATES_OUTDATED finding, consider updates enabled
    updates_ok = not any(f.id == "UPDATES_OUTDATED" for f in findings)
    if updates_ok:
        score += 1
    else:
        missing.append("System updates")

    title = f"Security Coverage: {score} / {total}"
    desc = "Defensive coverage indicator. Not a vulnerability score."
    if missing:
        desc += " Missing controls: " + ", ".join(missing)

    return Finding(
        id="SECURITY_COVERAGE_SUMMARY",
        title=title,
        severity=Severity.INFO,
        category="system",
        description=desc,
        recommendation="Address missing controls to improve defensive posture",
        metadata={"score": score, "total": total, "missing": missing},
    )
