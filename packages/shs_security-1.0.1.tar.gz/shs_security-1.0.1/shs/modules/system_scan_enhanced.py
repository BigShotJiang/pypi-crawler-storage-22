"""
Enhanced system scanning with real OS-level detectors.
Enterprise-grade system hygiene scanner (firewall, AV, services).
"""

from typing import List, Callable
import time
import platform

from shs.core.rules import Finding, Severity
from shs.core.detectors.firewall_detector import detect_firewall
from shs.core.detectors.service_detector import get_service_status, ServiceStatus
from shs.core.detectors.antivirus_detector import detect_antivirus


class EnhancedSystemScanner:
    """System security scanner with real OS-level detection."""

    def __init__(self, progress_callback: Callable[[str], None] = None):
        self.progress_callback = progress_callback or self._default_progress
        self.findings: List[Finding] = []

    def _default_progress(self, msg: str):
        print(f"  > {msg}")

    # ============================
    # MAIN ENTRY
    # ============================
    def run(self) -> List[Finding]:
        self.findings = []

        self.progress_callback("Checking firewall configuration")
        self._check_firewall()
        time.sleep(0.3)

        self.progress_callback("Checking antivirus protection")
        self._check_antivirus()
        time.sleep(0.3)

        self.progress_callback("Checking critical system services")
        self._check_critical_services()
        time.sleep(0.3)

        return self.findings

    # ============================
    # FIREWALL
    # ============================
    def _check_firewall(self):
        try:
            result = detect_firewall(debug=False)

            if result.status.value == "enabled":
                self.findings.append(Finding(
                    id="FIREWALL_ENABLED",
                    title="Host firewall enabled",
                    severity=Severity.INFO,
                    category="system",
                    description=f"{result.product_name} firewall is enabled",
                    recommendation="Keep firewall enabled",
                    metadata={
                        "firewall": result.product_name,
                        "confidence": result.confidence,
                        "verified": result.verified,
                    }
                ))
            else:
                self.findings.append(Finding(
                    id="FIREWALL_DISABLED",
                    title="Host firewall disabled",
                    severity=Severity.CRITICAL,
                    category="system",
                    description=f"{result.product_name} firewall is {result.status.value}",
                    recommendation="Enable firewall immediately",
                    metadata={
                        "firewall": result.product_name,
                        "status": result.status.value,
                        "confidence": result.confidence,
                    }
                ))

        except Exception as e:
            self.findings.append(Finding(
                id="FIREWALL_ERROR",
                title="Firewall check failed",
                severity=Severity.MEDIUM,
                category="system",
                description=str(e),
                recommendation="Manually verify firewall status",
                metadata={"error": str(e)}
            ))

    # ============================
    # ANTIVIRUS
    # ============================
    def _check_antivirus(self):
        try:
            result = detect_antivirus(debug=False)

            if result.status.value == "running":
                self.findings.append(Finding(
                    id="ANTIVIRUS_RUNNING",
                    title="Antivirus protection active",
                    severity=Severity.INFO,
                    category="system",
                    description=f"{result.product_name} is running",
                    recommendation="Keep antivirus updated",
                    metadata={
                        "antivirus": result.product_name,
                        "confidence": result.confidence,
                    }
                ))

            elif result.status.value == "not_found":
                self.findings.append(Finding(
                    id="ANTIVIRUS_NOT_FOUND",
                    title="No antivirus detected",
                    severity=Severity.HIGH,
                    category="system",
                    description="No endpoint protection software detected",
                    recommendation="Install antivirus or EDR",
                    metadata={}
                ))

            else:
                self.findings.append(Finding(
                    id="ANTIVIRUS_STOPPED",
                    title="Antivirus not running",
                    severity=Severity.CRITICAL,
                    category="system",
                    description=f"{result.product_name} status: {result.status.value}",
                    recommendation="Enable antivirus immediately",
                    metadata={
                        "antivirus": result.product_name,
                        "status": result.status.value,
                    }
                ))

        except Exception:
            # Antivirus detection may not be supported
            pass

    # ============================
    # CRITICAL SERVICES
    # ============================
    def _check_critical_services(self):
        os_name = platform.system()

        if os_name == "Windows":
            services = {
                "wuauserv": "Windows Update",
                "WinDefend": "Microsoft Defender",
                "MpsSvc": "Windows Firewall",
                "LanmanServer": "SMB Server",
            }
        elif os_name == "Linux":
            services = {
                "ssh": "SSH Service",
                "ufw": "Firewall (UFW)",
            }
        else:
            return

        for svc, label in services.items():
            result = get_service_status(svc, debug=False)

            if result.status in (ServiceStatus.STOPPED, ServiceStatus.DISABLED):
                self.findings.append(Finding(
                    id=f"SERVICE_{svc.upper()}_STOPPED",
                    title=f"{label} service not running",
                    severity=Severity.HIGH if svc == "wuauserv" else Severity.MEDIUM,
                    category="system",
                    description=f"{label} service is {result.status.value}",
                    recommendation=f"Start and enable {label} service",
                    metadata={
                        "service": svc,
                        "status": result.status.value,
                        "method": result.method_used,
                    }
                ))

            elif result.status == ServiceStatus.UNKNOWN:
                self.findings.append(Finding(
                    id=f"SERVICE_{svc.upper()}_UNKNOWN",
                    title=f"{label} service status unknown",
                    severity=Severity.MEDIUM,
                    category="system",
                    description="Unable to determine service state",
                    recommendation=f"Verify {label} manually",
                    metadata={
                        "service": svc,
                        "method": result.method_used,
                    }
                ))


# ============================
# ENTRY POINT
# ============================
def run_enhanced_system_scan(progress_callback: Callable = None) -> List[Finding]:
    scanner = EnhancedSystemScanner(progress_callback)
    return scanner.run()


if __name__ == "__main__":
    def progress(msg):
        print(msg)

    findings = run_enhanced_system_scan(progress)
    print("\nFindings:")
    for f in findings:
        print(f"- {f.severity.value.upper()}: {f.title}")
