"""User security scanning module for SHS.

Features implemented:
- Enumerate all users via the `pwd` module (does not rely on `who` or similar).
- Classify system users (UID < 1000) vs normal users (UID >= 1000).
- Detect inactive users using `lastlog` (>= 90 days default or never logged in).
- Detect privileged users via sudo/wheel groups and sudoers files.
- Check password age using `chage -l <username>` (>= 180 days default) and flag "never expires".
- Best-effort MFA detection via PAM and SSH configs.
- All operations are read-only and handle permission errors gracefully.

The module returns a list of Finding objects compatible with SHS architecture.
"""

from __future__ import annotations

import os
import grp
import pwd
import subprocess
import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from shs.core.rules import Finding, Severity


def run_scan() -> List[Finding]:
    """Main entry point for the user scan.

    Returns:
        List[Finding]: structured findings for the `--users` scan.
    """
    findings: List[Finding] = []

    users = enumerate_users()

    # privileged accounts
    findings.extend(_check_sudo_and_privileged(users))

    # inactive users (lastlog)
    findings.extend(_check_inactive_users(users))

    # password age checks (chage)
    findings.extend(_check_password_age(users))

    # MFA / PAM awareness
    findings.extend(_check_mfa())

    # password policy checks
    findings.extend(_check_password_policy())

    return findings


def enumerate_users() -> List[Dict[str, object]]:
    """Enumerate all local users using the `pwd` module.

    Returns a list of dicts with keys: username, uid, gid, home, shell.
    """
    results: List[Dict[str, object]] = []
    try:
        for entry in pwd.getpwall():
            results.append(
                {
                    "username": entry.pw_name,
                    "uid": entry.pw_uid,
                    "gid": entry.pw_gid,
                    "home": entry.pw_dir,
                    "shell": entry.pw_shell,
                }
            )
    except Exception:
        # In restricted environments return an empty list rather than raising.
        return []
    return results


def _check_sudo_and_privileged(users: List[Dict[str, object]]) -> List[Finding]:
    """Detect users with sudo/wheel/admin group membership and sudoers entries.

    Returns a HIGH severity finding listing privileged accounts.
    """
    results: List[Finding] = []
    privileged = set()

    # Group-based membership
    for group_name in ("sudo", "wheel", "admin"):
        try:
            g = grp.getgrnam(group_name)
            privileged.update(g.gr_mem)
        except KeyError:
            continue
        except Exception:
            continue

    # Parse /etc/sudoers and /etc/sudoers.d (best-effort, read-only)
    try:
        sudo_main = Path("/etc/sudoers")
        sudo_dir = Path("/etc/sudoers.d")
        files = [sudo_main] + ([p for p in sudo_dir.iterdir()] if sudo_dir.exists() else [])
        for p in files:
            try:
                text = p.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split()
                if parts and parts[0].isidentifier():
                    privileged.add(parts[0])
    except Exception:
        pass

    # Also include any user entries that are UID 0
    try:
        for u in users:
            if isinstance(u.get("uid"), int) and u.get("uid") == 0:
                privileged.add(u.get("username"))
    except Exception:
        pass

    if privileged:
        results.append(
            Finding(
                id="USER_PRIVILEGED_ACCOUNTS",
                title="Privileged accounts detected",
                severity=Severity.HIGH,
                category="users",
                description="Accounts with sudo or root-equivalent privileges were found",
                recommendation="Enforce least privilege: restrict sudoers, use role-based access, and audit privileged accounts",
                metadata={"accounts": ",".join(sorted(privileged))},
            )
        )

    return results


def _check_inactive_users(users: List[Dict[str, object]]) -> List[Finding]:
    """Detect inactive users using `lastlog`.

    - Only normal users (UID >= 1000) are considered for inactivity.
    - Default threshold is 90 days (override with SHS_INACTIVE_DAYS env var).
    - Users who never logged in are treated as inactive.
    - Privileged inactive users are returned as HIGH severity; regular inactive as MEDIUM.
    """
    results: List[Finding] = []
    threshold = int(os.getenv("SHS_INACTIVE_DAYS", "90"))
    current = os.getenv("USER") or ""

    inactive_regular: List[Tuple[str, int]] = []
    inactive_privileged: List[Tuple[str, int]] = []

    for u in users:
        try:
            username = u.get("username")
            uid = int(u.get("uid"))
        except Exception:
            continue

        # Only check normal users
        if uid < 1000:
            continue
        if username == current:
            continue

        days = _get_days_since_last_login(username)
        if days is None:
            continue

        if days >= threshold:
            if _is_user_privileged(username):
                inactive_privileged.append((username, days))
            else:
                inactive_regular.append((username, days))

    for username, days in sorted(inactive_privileged):
        results.append(
            Finding(
                id="USER_PRIVILEGED_INACTIVE",
                title=f"Privileged user '{username}' inactive for {int(days)} days",
                severity=Severity.HIGH,
                category="users",
                description=f"Privileged account {username} has not logged in for {int(days)} days",
                recommendation="Review and disable or reassign privileged accounts that are not active",
                metadata={"account": username, "days_inactive": int(days)},
            )
        )

    if inactive_regular:
        accounts = ",".join(sorted([n for n, _ in inactive_regular]))
        results.append(
            Finding(
                id="USER_INACTIVE_REGULAR",
                title=f"Regular user accounts inactive >= {threshold} days",
                severity=Severity.MEDIUM,
                category="users",
                description=f"Regular user accounts inactive for >= {threshold} days: {accounts}",
                recommendation="Review and disable or archive inactive accounts",
                metadata={"accounts": accounts, "threshold_days": threshold},
            )
        )

    return results


def _get_days_since_last_login(username: str) -> Optional[int]:
    """Return days since last login for `username` using `lastlog -u`.

    Returns None when the output cannot be parsed. 'Never logged in' is returned
    as a large sentinel value so it will be flagged by inactivity threshold.
    """
    try:
        proc = subprocess.run(["lastlog", "-u", username], capture_output=True, text=True, timeout=3)
        out = proc.stdout.strip()
        if not out:
            return None
        lines = out.splitlines()
        if len(lines) < 2:
            return None
        line = lines[1].strip()
        if "Never logged in" in line or "**Never logged in**" in line:
            return 99999

        # Try to extract a date substring at the end of the line
        import re as _re
        m = _re.search(r"([A-Za-z]{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+\S+\s+\d{4})$", line)
        dt = None
        if m:
            datestr = m.group(1)
            try:
                dt = datetime.datetime.strptime(datestr, "%b %d %H:%M:%S %z %Y")
            except Exception:
                try:
                    dt = datetime.datetime.strptime(datestr, "%b %d %H:%M:%S %Y")
                except Exception:
                    dt = None
        else:
            m2 = _re.search(r"([A-Za-z]{3}\s+\d{1,2}\s+\d{4})$", line)
            if m2:
                datestr = m2.group(1)
                try:
                    dt = datetime.datetime.strptime(datestr, "%b %d %Y")
                except Exception:
                    dt = None

        if not dt:
            return None

        now = datetime.datetime.now(dt.tzinfo) if dt.tzinfo else datetime.datetime.now()
        delta = now - (dt.replace(tzinfo=None) if dt.tzinfo else dt)
        return int(delta.total_seconds() / 86400)
    except Exception:
        return None


def _is_user_privileged(username: str) -> bool:
    """Return True if user likely has administrator privileges.

    Uses UID 0, group membership (sudo/wheel/admin), and sudoers heuristics.
    """
    try:
        try:
            pw = pwd.getpwnam(username)
            if pw.pw_uid == 0:
                return True
        except KeyError:
            pass

        for group_name in ("sudo", "wheel", "admin"):
            try:
                g = grp.getgrnam(group_name)
                if username in g.gr_mem:
                    return True
            except KeyError:
                continue

        sudo_main = Path("/etc/sudoers")
        if sudo_main.exists():
            try:
                text = sudo_main.read_text(encoding="utf-8", errors="ignore")
                if username in text:
                    return True
            except Exception:
                pass
    except Exception:
        pass
    return False


def _check_password_age(users: List[Dict[str, object]]) -> List[Finding]:
    """Check password age using `chage -l <username>` for each user.

    Flags users with password last change older than 180 days (default) as MEDIUM.
    Does not expose password values and handles permission errors gracefully.
    """
    results: List[Finding] = []
    threshold = int(os.getenv("SHS_PASSWORD_MAX_DAYS", "180"))

    for u in users:
        username = u.get("username")
        try:
            proc = subprocess.run(["chage", "-l", username], capture_output=True, text=True, timeout=3)
            if proc.returncode != 0:
                continue
            out = proc.stdout
        except Exception:
            continue

        last_change_days = None
        for line in out.splitlines():
            if line.lower().startswith("last password change"):
                parts = line.split(":", 1)
                if len(parts) < 2:
                    continue
                date_str = parts[1].strip()
                if date_str.lower() in ("never", "not set"):
                    last_change_days = 99999
                    break
                for fmt in ("%b %d, %Y", "%Y-%m-%d", "%d %b %Y"):
                    try:
                        dt = datetime.datetime.strptime(date_str, fmt)
                        last_change_days = (datetime.datetime.now() - dt).days
                        break
                    except Exception:
                        continue
                break

        if last_change_days is None:
            continue

        if last_change_days >= threshold:
            sev = Severity.MEDIUM
            if _is_user_privileged(username):
                sev = Severity.HIGH
            results.append(
                Finding(
                    id="USER_PASSWORD_AGE",
                    title=f"Password for {username} older than {threshold} days",
                    severity=sev,
                    category="users",
                    description="Password last change exceeds recommended maximum age",
                    recommendation="Enforce password rotation and review impacted accounts",
                    metadata={"account": username, "days_since_last_change": int(last_change_days)},
                )
            )

        for line in out.splitlines():
            if line.lower().startswith("maximum"):
                parts = line.split(":", 1)
                if len(parts) < 2:
                    continue
                val = parts[1].strip().lower()
                if val in ("never", "not set"):
                    results.append(
                        Finding(
                            id="USER_PASSWORD_NEVER_EXPIRES",
                            title=f"Password never expires for {username}",
                            severity=Severity.HIGH,
                            category="users",
                            description="Account configured with non-expiring password",
                            recommendation="Set a maximum password age and enforce rotation",
                            metadata={"account": username},
                        )
                    )
                break

    return results


def _check_mfa() -> List[Finding]:
    """Best-effort MFA detection.

    Checks PAM SSHD configuration for common MFA modules and looks for SSH
    configuration suggesting additional authentication methods. If MFA cannot
    be determined, returns an INFO finding stating status is unknown.
    """
    results: List[Finding] = []
    pam_sshd = Path("/etc/pam.d/sshd")
    try:
        if pam_sshd.exists():
            content = pam_sshd.read_text(encoding="utf-8", errors="ignore")
            if any(mod in content for mod in ("pam_google_authenticator.so", "pam_oath.so", "pam_duo.so")):
                results.append(
                    Finding(
                        id="USER_MFA_DETECTED",
                        title="MFA-related PAM module detected",
                        severity=Severity.INFO,
                        category="users",
                        description="PAM configuration references known MFA modules",
                        recommendation="Verify MFA enforcement and coverage for privileged accounts",
                        metadata={},
                    )
                )
                return results
    except Exception:
        # If we cannot read PAM config, fall through to unknown
        pass

    sshd = Path("/etc/ssh/sshd_config")
    try:
        if sshd.exists():
            sshc = sshd.read_text(encoding="utf-8", errors="ignore")
            if "AuthenticationMethods" in sshc or "ChallengeResponseAuthentication yes" in sshc:
                results.append(
                    Finding(
                        id="USER_MFA_SSH_HINT",
                        title="SSH configuration indicates additional authentication methods",
                        severity=Severity.INFO,
                        category="users",
                        description="SSH config suggests multi-factor or challenge-response authentication may be in use",
                        recommendation="Verify MFA enforcement for SSH and privileged users",
                        metadata={},
                    )
                )
                return results
    except Exception:
        pass

    results.append(
        Finding(
            id="USER_MFA_UNKNOWN",
            title="MFA status unknown for local users",
            severity=Severity.INFO,
            category="users",
            description="Could not detect system-level MFA enforcement for local logins",
            recommendation="Enforce MFA for privileged and administrative access where possible",
            metadata={},
        )
    )
    return results


def _check_password_policy() -> List[Finding]:
    results: List[Finding] = []
    pam_file = Path("/etc/pam.d/common-password")
    if not pam_file.exists():
        return results
    try:
        content = pam_file.read_text(encoding="utf-8")
    except OSError:
        return results
    if "pam_pwquality.so" not in content:
        results.append(
            Finding(
                id="USER_PASSWORD_POLICY_WEAK",
                title="Password quality enforcement not detected",
                severity=Severity.MEDIUM,
                category="users",
                description="PAM configuration does not reference pam_pwquality for password strength",
                recommendation="Enable strong password policies using pam_pwquality or equivalent",
                metadata={},
            )
        )
    return results
