from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

from shs.core.rules import Finding, RiskScore, Severity


def generate_html(
    scan_id: Optional[int],
    score: RiskScore,
    findings: Iterable[Finding],
    output_path: Path,
) -> Path:
    rows = []
    for f in findings:
        rows.append(
            "<tr>"
            f"<td>{f.id}</td>"
            f"<td>{f.category}</td>"
            f"<td>{f.severity.value}</td>"
            f"<td>{f.title}</td>"
            f"<td>{f.description}</td>"
            f"<td>{f.recommendation}</td>"
            f"<td>{_format_metadata(f)}</td>"
            "</tr>"
        )
    table_rows = "\n".join(rows)
    now = datetime.utcnow().isoformat() + "Z"
    scan_label = str(scan_id) if scan_id is not None else "N/A"
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Security Hygiene Scanner Report</title>
  <style>
    body {{ font-family: Arial, sans-serif; background: #0b1020; color: #f5f7ff; }}
    h1, h2 {{ color: #e0e4ff; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
    th, td {{ border: 1px solid #333a5c; padding: 0.5rem; font-size: 0.9rem; }}
    th {{ background: #1b2340; }}
    tr:nth-child(even) {{ background: #151b33; }}
    .severity-CRITICAL {{ color: #ff6b6b; font-weight: bold; }}
    .severity-HIGH {{ color: #ffb347; font-weight: bold; }}
    .severity-MEDIUM {{ color: #ffd56b; }}
    .severity-LOW {{ color: #8be9fd; }}
    .score {{ font-size: 1.2rem; margin-top: 0.5rem; }}
  </style>
</head>
<body>
  <h1>Security Hygiene Scanner Report</h1>
  <p>Scan ID: {scan_label}</p>
  <p>Generated at: {now}</p>
  <div class="score">
    Security Score: {score.score}% ({score.label})<br/>
    {score.explanation}
  </div>
  <h2>Findings</h2>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Category</th>
        <th>Severity</th>
        <th>Title</th>
        <th>Description</th>
        <th>Recommendation</th>
        <th>Metadata</th>
      </tr>
    </thead>
    <tbody>
      {table_rows}
    </tbody>
  </table>
</body>
</html>
"""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    return output_path


def _format_metadata(finding: Finding) -> str:
    if not finding.metadata:
        return ""
    parts = [f"{k}={v}" for k, v in finding.metadata.items()]
    return ", ".join(parts)


