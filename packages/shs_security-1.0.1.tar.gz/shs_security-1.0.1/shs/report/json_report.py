from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

from shs.core.rules import Finding, RiskScore


def generate_json(
    scan_id: Optional[int],
    score: RiskScore,
    findings: Iterable[Finding],
    output_path: Path,
) -> Path:
    data = {
        "scan_id": scan_id,
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "score": {
            "value": score.score,
            "label": score.label,
            "explanation": score.explanation,
        },
        "findings": [
            {
                "id": f.id,
                "title": f.title,
                "severity": f.severity.value,
                "category": f.category,
                "description": f.description,
                "recommendation": f.recommendation,
                "metadata": f.metadata,
            }
            for f in findings
        ],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return output_path


