"""Sia Code - Local-first codebase intelligence.

Semantic search, multi-hop research, and 12-language AST support.
"""

__version__ = "0.6.0"
__all__ = ["__version__"]
