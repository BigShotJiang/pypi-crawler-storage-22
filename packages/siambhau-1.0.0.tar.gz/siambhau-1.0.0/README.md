# siambhau 🎮

**Free Fire Info Python Package by SiamBhau**

[![Telegram](https://img.shields.io/badge/Telegram-SiamBhau-blue)](https://t.me/SiamBhau)
[![PyPI](https://img.shields.io/pypi/v/siambhau)](https://pypi.org/project/siambhau)
[![Python](https://img.shields.io/pypi/pyversions/siambhau)](https://pypi.org/project/siambhau)

---

## 📦 Installation

```bash
pip install siambhau
```

---

## ⚡ Usage

```python
from siambhau import bhauxffinfo

client = bhauxffinfo.FFClient()

# ✅ Player Info পেতে
info = client.get_player_info(uid="4147917569", region="IND")
print(info)

# ✅ Player Stats পেতে
stats = client.get_player_stats(uid="4147917569", region="IND", matchmode="CAREER")
print(stats)

# ✅ নাম দিয়ে Player খুঁজতে
results = client.search_player(keyword="SiamBhau", region="IND")
print(results)
```

অথবা সরাসরি class import করতে:

```python
from siambhau.bhauxffinfo import FFClient

client = FFClient()
info = client.get_player_info(uid="4147917569", region="IND")
```

---

## 📖 Methods

### `get_player_info(uid, region)`
Player এর সম্পূর্ণ profile info নিয়ে আসে।

| Parameter | Type | Description |
|-----------|------|-------------|
| `uid` | str / int | Player এর UID |
| `region` | str | Server Region |

---

### `get_player_stats(uid, region, matchmode)`
Player এর battle stats নিয়ে আসে।

| Parameter | Type | Description |
|-----------|------|-------------|
| `uid` | str / int | Player এর UID |
| `region` | str | Server Region |
| `matchmode` | str | `CAREER`, `NORMAL`, বা `RANKED` (Default: `CAREER`) |

---

### `search_player(keyword, region)`
নাম দিয়ে player খোঁজে।

| Parameter | Type | Description |
|-----------|------|-------------|
| `keyword` | str | Player name বা keyword |
| `region` | str | Server Region |

---

### `refresh_tokens(regions=None)`
JWT tokens manually refresh করে।

---

## ⚡ Async Usage

```python
import asyncio
from siambhau import bhauxffinfo

client = bhauxffinfo.FFClient()

async def main():
    info = await client.async_get_player_info(uid="4147917569", region="IND")
    print(info)

asyncio.run(main())
```

---

## 🌍 Supported Regions

`IND` `BD` `SG` `BR` `US` `NA` `SAC` `RU` `ID` `TW` `VN` `TH` `ME` `PK` `CIS` `EUROPE`

---

## 👨‍💻 Developer

**SiamBhau**
📱 Telegram: [t.me/SiamBhau](https://t.me/SiamBhau)
