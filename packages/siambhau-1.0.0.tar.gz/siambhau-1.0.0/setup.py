from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="siambhau",
    version="1.0.0",
    author="SiamBhau",
    author_email="",
    description="Free Fire Info Tools by SiamBhau — use: from siambhau import bhauxffinfo",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://t.me/SiamBhau",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "httpx",
        "pycryptodome>=3.20.0",
        "protobuf>=6.30.0",
        "cachetools",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    keywords=["freefire", "ff", "siambhau", "bhauxffinfo", "game", "api"],
)
