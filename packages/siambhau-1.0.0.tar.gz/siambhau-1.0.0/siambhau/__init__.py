"""
siambhau - Free Fire Tools by SiamBhau
Telegram: t.me/SiamBhau
"""

from . import bhauxffinfo

__version__ = "1.0.0"
__author__ = "SiamBhau"
__all__ = ["bhauxffinfo"]
