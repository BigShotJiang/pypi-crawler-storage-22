"""
bhauxffinfo - Free Fire Info Module
Part of siambhau package

Usage:
    from siambhau import bhauxffinfo

    client = bhauxffinfo.FFClient()
    info = client.get_player_info(uid="4147917569", region="IND")

    # অথবা directly class import করতে:
    from siambhau.bhauxffinfo import FFClient
"""

from .client import FFClient

__version__ = "1.0.0"
__author__ = "SiamBhau"
__all__ = ["FFClient"]
