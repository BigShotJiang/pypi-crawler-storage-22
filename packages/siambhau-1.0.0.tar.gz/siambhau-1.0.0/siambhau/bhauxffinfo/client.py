"""
bhauxffinfo - Free Fire Info Python Module
Core client for interacting with Free Fire API
"""

import asyncio
import time
import json
import base64
from collections import defaultdict
from typing import Optional, Union

import httpx
from google.protobuf import json_format, message
from google.protobuf.message import Message
from Crypto.Cipher import AES

from .proto import FreeFire_pb2, main_pb2, AccountPersonalShow_pb2, PlayerStats_pb2, SearchAccountByName_pb2

# === Constants ===
MAIN_KEY = base64.b64decode('WWcmdGMlREV1aDYlWmNeOA==')
MAIN_IV = base64.b64decode('Nm95WkRyMjJFM3ljaGpNJQ==')
RELEASEVERSION = "OB52"
USERAGENT = "Dalvik/2.1.0 (Linux; U; Android 13; CPH2095 Build/RKQ1.211119.001)"
SUPPORTED_REGIONS = {"IND", "BR", "US", "SAC", "NA", "SG", "RU", "ID", "TW", "VN", "TH", "ME", "PK", "CIS", "BD", "EUROPE"}


# === Internal Helpers ===
def _pad(text: bytes) -> bytes:
    padding_length = AES.block_size - (len(text) % AES.block_size)
    return text + bytes([padding_length] * padding_length)

def _aes_cbc_encrypt(key: bytes, iv: bytes, plaintext: bytes) -> bytes:
    aes = AES.new(key, AES.MODE_CBC, iv)
    return aes.encrypt(_pad(plaintext))

def _decode_protobuf(encoded_data: bytes, message_type) -> message.Message:
    instance = message_type()
    instance.ParseFromString(encoded_data)
    return instance

async def _json_to_proto(json_data: str, proto_message: Message) -> bytes:
    json_format.ParseDict(json.loads(json_data), proto_message)
    return proto_message.SerializeToString()

def _get_account_credentials(region: str) -> str:
    r = region.upper()
    if r in {"IND", "BR", "US", "SAC", "BD"}:
        return "uid=4147917569&password=8415C426BBE3371DADD82F5B25A8FE75806ACF26CC01E219F0D828DBDF3148DD"
    else:
        return "uid=3301239795&password=DD40EE772FCBD61409BB15033E3DE1B1C54EDA83B75DF0CDD24C34C7C8798475"


class FFClient:
    """
    Free Fire Info Client
    
    Usage Example:
    --------------
        from bhauxffinfo import FFClient

        client = FFClient()

        # Player info
        info = client.get_player_info(uid="4147917569", region="IND")
        print(info)

        # Player stats
        stats = client.get_player_stats(uid="4147917569", region="IND", matchmode="CAREER")
        print(stats)

        # Search by name
        results = client.search_player(keyword="SiamBhau", region="IND")
        print(results)
    """

    def __init__(self, auto_init: bool = True):
        """
        Initialize FFClient.

        Parameters:
        -----------
        auto_init : bool
            If True, tokens will be fetched automatically on first use.
            Default: True
        """
        self._cached_tokens = defaultdict(dict)
        self._auto_init = auto_init

    # ==================== ASYNC INTERNAL METHODS ====================

    async def _get_access_token(self, account: str):
        url = "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant"
        payload = account + "&response_type=token&client_type=2&client_secret=2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3&client_id=100067"
        headers = {
            'User-Agent': USERAGENT,
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/x-www-form-urlencoded"
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, data=payload, headers=headers)
            data = resp.json()
            return data.get("access_token", "0"), data.get("open_id", "0")

    async def _create_jwt(self, region: str):
        account = _get_account_credentials(region)
        token_val, open_id = await self._get_access_token(account)
        body = json.dumps({
            "open_id": open_id,
            "open_id_type": "4",
            "login_token": token_val,
            "orign_platform_type": "4"
        })
        proto_bytes = await _json_to_proto(body, FreeFire_pb2.LoginReq())
        payload = _aes_cbc_encrypt(MAIN_KEY, MAIN_IV, proto_bytes)
        url = "https://loginbp.ggblueshark.com/MajorLogin"
        headers = {
            'User-Agent': USERAGENT,
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/octet-stream",
            'Expect': "100-continue",
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': RELEASEVERSION
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, data=payload, headers=headers)
            msg = json.loads(json_format.MessageToJson(_decode_protobuf(resp.content, FreeFire_pb2.LoginRes)))
            self._cached_tokens[region] = {
                'token': f"Bearer {msg.get('token', '0')}",
                'region': msg.get('lockRegion', '0'),
                'server_url': msg.get('serverUrl', '0'),
                'expires_at': time.time() + 25200
            }

    async def _get_token_info(self, region: str):
        info = self._cached_tokens.get(region)
        if info and time.time() < info['expires_at']:
            return info['token'], info['region'], info['server_url']
        await self._create_jwt(region)
        info = self._cached_tokens[region]
        return info['token'], info['region'], info['server_url']

    async def _async_get_player_info(self, uid: str, region: str) -> dict:
        region = region.upper()
        if region not in SUPPORTED_REGIONS:
            raise ValueError(f"Unsupported region: {region}. Supported: {SUPPORTED_REGIONS}")
        payload = await _json_to_proto(json.dumps({'a': uid, 'b': '7'}), main_pb2.GetPlayerPersonalShow())
        data_enc = _aes_cbc_encrypt(MAIN_KEY, MAIN_IV, payload)
        token, _, server_url = await self._get_token_info(region)
        headers = {
            'User-Agent': USERAGENT,
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/octet-stream",
            'Expect': "100-continue",
            'Authorization': token,
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': RELEASEVERSION
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(server_url + "/GetPlayerPersonalShow", data=data_enc, headers=headers)
            return json.loads(json_format.MessageToJson(
                _decode_protobuf(resp.content, AccountPersonalShow_pb2.AccountPersonalShowInfo)
            ))

    async def _async_get_player_stats(self, uid: str, region: str, matchmode: str = "CAREER") -> dict:
        region = region.upper()
        if region not in SUPPORTED_REGIONS:
            raise ValueError(f"Unsupported region: {region}. Supported: {SUPPORTED_REGIONS}")
        
        type_mapping = {"CAREER": 0, "NORMAL": 1, "RANKED": 2}
        matchmode = matchmode.upper()
        if matchmode not in type_mapping:
            raise ValueError(f"Invalid matchmode: {matchmode}. Use: CAREER, NORMAL, RANKED")

        token, _, server_url = await self._get_token_info(region)
        payload_data = {"accountid": int(uid), "matchmode": type_mapping[matchmode]}
        payload = await _json_to_proto(json.dumps(payload_data), PlayerStats_pb2.request())
        data_enc = _aes_cbc_encrypt(MAIN_KEY, MAIN_IV, payload)
        headers = {
            'User-Agent': USERAGENT,
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/octet-stream",
            'Expect': "100-continue",
            'Authorization': token,
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': RELEASEVERSION
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(server_url + "/GetPlayerStats", data=data_enc, headers=headers)
            return json.loads(json_format.MessageToJson(
                _decode_protobuf(resp.content, PlayerStats_pb2.response)
            ))

    async def _async_search_player(self, keyword: str, region: str) -> dict:
        region = region.upper()
        if region not in SUPPORTED_REGIONS:
            raise ValueError(f"Unsupported region: {region}. Supported: {SUPPORTED_REGIONS}")
        
        token, _, server_url = await self._get_token_info(region)
        payload = await _json_to_proto(json.dumps({'keyword': keyword}), SearchAccountByName_pb2.request())
        data_enc = _aes_cbc_encrypt(MAIN_KEY, MAIN_IV, payload)
        headers = {
            'User-Agent': USERAGENT,
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Content-Type': "application/octet-stream",
            'Expect': "100-continue",
            'Authorization': token,
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': RELEASEVERSION
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(server_url + "/FuzzySearchAccountByName", data=data_enc, headers=headers)
            return json.loads(json_format.MessageToJson(
                _decode_protobuf(resp.content, SearchAccountByName_pb2.response)
            ))

    async def _async_refresh_tokens(self, regions: Optional[list] = None):
        targets = regions if regions else list(SUPPORTED_REGIONS)
        tasks = [self._create_jwt(r) for r in targets]
        await asyncio.gather(*tasks)

    # ==================== PUBLIC SYNC METHODS ====================

    def get_player_info(self, uid: Union[str, int], region: str) -> dict:
        """
        Get Free Fire player info by UID and region.

        Parameters:
        -----------
        uid : str or int
            Player's Free Fire UID
        region : str
            Server region (e.g., "IND", "BD", "SG", "BR", "US", etc.)

        Returns:
        --------
        dict : Player information data

        Example:
        --------
            client = FFClient()
            info = client.get_player_info(uid="4147917569", region="IND")
            print(info)
        """
        return asyncio.run(self._async_get_player_info(str(uid), region))

    def get_player_stats(self, uid: Union[str, int], region: str, matchmode: str = "CAREER") -> dict:
        """
        Get Free Fire player battle stats.

        Parameters:
        -----------
        uid : str or int
            Player's Free Fire UID
        region : str
            Server region (e.g., "IND", "BD", "SG")
        matchmode : str
            Match type - "CAREER", "NORMAL", or "RANKED"
            Default: "CAREER"

        Returns:
        --------
        dict : Player stats data

        Example:
        --------
            client = FFClient()
            stats = client.get_player_stats(uid="4147917569", region="IND", matchmode="RANKED")
            print(stats)
        """
        return asyncio.run(self._async_get_player_stats(str(uid), region, matchmode))

    def search_player(self, keyword: str, region: str) -> dict:
        """
        Search Free Fire players by name/keyword.

        Parameters:
        -----------
        keyword : str
            Player name or keyword to search
        region : str
            Server region (e.g., "IND", "BD", "SG")

        Returns:
        --------
        dict : Search results

        Example:
        --------
            client = FFClient()
            results = client.search_player(keyword="SiamBhau", region="IND")
            print(results)
        """
        return asyncio.run(self._async_search_player(keyword, region))

    def refresh_tokens(self, regions: Optional[list] = None):
        """
        Manually refresh JWT tokens for all or specific regions.

        Parameters:
        -----------
        regions : list, optional
            List of regions to refresh. If None, refreshes all supported regions.

        Example:
        --------
            client = FFClient()
            client.refresh_tokens()  # refresh all
            client.refresh_tokens(regions=["IND", "BD"])  # refresh specific
        """
        asyncio.run(self._async_refresh_tokens(regions))

    # ==================== ASYNC PUBLIC METHODS ====================

    async def async_get_player_info(self, uid: Union[str, int], region: str) -> dict:
        """Async version of get_player_info"""
        return await self._async_get_player_info(str(uid), region)

    async def async_get_player_stats(self, uid: Union[str, int], region: str, matchmode: str = "CAREER") -> dict:
        """Async version of get_player_stats"""
        return await self._async_get_player_stats(str(uid), region, matchmode)

    async def async_search_player(self, keyword: str, region: str) -> dict:
        """Async version of search_player"""
        return await self._async_search_player(keyword, region)

    @staticmethod
    def get_supported_regions() -> set:
        """Returns all supported server regions."""
        return SUPPORTED_REGIONS.copy()

    def __repr__(self):
        return f"<FFClient by SiamBhau | t.me/SiamBhau>"
