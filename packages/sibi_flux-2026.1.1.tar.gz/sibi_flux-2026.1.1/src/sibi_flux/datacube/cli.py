import sys
import os
import json
import yaml
import re
import typer
import subprocess
import importlib.util
import importlib
import sqlalchemy as sa
from pathlib import Path
from typing import Optional, Callable, Set, Dict, Any, Iterable, Mapping
from sqlalchemy import inspect
from rich.console import Console
from rich.table import Table

# --- Core Library Imports ---
from sibi_flux.datacube.generator import (
    is_secure_path,
    check_drift,
    resolve_db_url,
    load_environment,
    filter_global_imports,
    DatacubeRegistry,
    perform_discovery,
    generate_datacube_module_code,
    generate_field_map_files,
    ensure_directories_exist,
)
from sibi_flux.datacube.orchestrator import DiscoveryOrchestrator
from sibi_flux.datacube.field_factory import FieldMapFactory

import sibi_flux.datacube.generator


app = typer.Typer(help="Sibi-Flux Data Cube Generator")
console = Console()

# --- Context Management ---

class CLIContext:
    def __init__(self):
        self.default_config: Optional[Path] = None
        self.field_translations_file: Optional[Path] = None
        self.valid_paths: list[str] = []
        self.valid_fieldmap_paths: list[str] = []
        self.params: dict = {}

    def configure(
        self,
        default_config: Path,
        field_translations_file: Path,
        valid_paths: list[str],
        valid_fieldmap_paths: list[str],
        params: Optional[dict] = None
    ):
        self.default_config = default_config
        self.field_translations_file = field_translations_file
        self.valid_paths = valid_paths
        self.valid_fieldmap_paths = valid_fieldmap_paths
        self.params = params or {}

context = CLIContext()

def set_context_defaults(
    default_config: Path,
    field_translations_file: Path,
    valid_paths: list[str],
    valid_fieldmap_paths: list[str],
    params: Optional[dict] = None
):
    """Configures the CLI context with project-specific defaults."""
    context.configure(default_config, field_translations_file, valid_paths, valid_fieldmap_paths, params)
    
    # Ensure directories exist based on configured params
    if params:
        ensure_directories_exist(params, logger=console.log)

def _get_db_url_callback(registry: DatacubeRegistry, db_url_map: Optional[str]) -> Callable[[str], str]:
    """Helper to create a callback that resolves DB URLs from CLI overrides or registry."""
    cli_urls = json.loads(db_url_map) if db_url_map else {}

    def get_url(conf_name: str) -> str:
        # 1. CLI Override
        if conf_name in cli_urls:
            return cli_urls[conf_name]
        # 2. Dynamic Resolution
        url = resolve_db_url(conf_name, registry.global_imports)
        if url:
            return url
        raise ValueError(f"Could not resolve DB URL for '{conf_name}'. Provide via --db-urls or check imports.")

    return get_url

# --- Commands ---

@app.command()
def sync(
    config_file: Optional[Path] = typer.Option(None, "--config"),
    db_url_map: Optional[str] = typer.Option(None, "--db-urls", help="Optional JSON mapping. If omitted, tries to resolve from code."),
    force: bool = typer.Option(False, "--force", "-f"),
    env_file: Optional[Path] = typer.Option(None, "--env-file", "-e", help="Path to environment file"),
    dry_run: bool = typer.Option(False, "--dry-run")
) -> None:
    """Generates all Datacube classes based on the whitelists and field maps."""
    config_path = config_file or context.default_config
    if not config_path:
        console.print("[red]No config file specified and no default configured.[/red]")
        raise typer.Exit(code=1)

    # Resolve env_file: CLI > Params > Default
    if env_file:
        env_path = env_file
    elif context.params and context.params.get("defaults", {}).get("env_file"):
        env_path = Path(context.params.get("defaults", {})["env_file"])
    else:
        env_path = Path(".env.linux")

    load_environment(env_path, logger=console.print)

    # Start with empty/default registry
    with open(config_path, 'r') as f:
         config_data = yaml.safe_load(f)
    registry = DatacubeRegistry(config_data, params=context.params)
    
    # --- Aggregation Phase ---
    params = context.params
    databases = params.get("databases", [])
    
    # 0. Generate Field Maps (if enabled)
    # Check generation.enable_field_maps (defaults to True)
    if params.get("generation", {}).get("enable_field_maps", True):
        import json
        cli_urls = json.loads(db_url_map) if db_url_map else {}
        
        def get_url_safe(conf_name, db_imp):
             if conf_name in cli_urls: return cli_urls[conf_name]
             imp = [db_imp] if db_imp else registry.global_imports
             return resolve_db_url(conf_name, imp)

        _run_field_map_generation(context, config_path, databases, get_url_safe, force=force)
        # Ensure new modules are picked up
        importlib.invalidate_caches()

    # Inject valid paths for security from context
    


    # Inject valid paths for security from context
    registry.valid_paths = context.valid_paths
    registry.valid_fieldmap_paths = context.valid_fieldmap_paths
    
    get_url = _get_db_url_callback(registry, db_url_map)

    # Group tables by target file
    file_groups = registry.group_tables_by_file()

    summary_table = Table(title="Sync Results")
    


    summary_table.add_column("File", style="magenta")
    summary_table.add_column("Classes", style="cyan")
    summary_table.add_column("Status")

    for file_path_str, items in file_groups.items():
        if not is_secure_path(file_path_str, registry.valid_paths):
            console.print(f"[bold red]Blocked:[/bold red] {file_path_str} is outside allowed paths.")
            continue

        file_path = Path(file_path_str)
        
        is_append = False
        existing_content = ""
        
        if file_path.exists() and not force:
            with open(file_path, 'r') as f:
                existing_content = f.read()
            
            missing_items = []
            for item in items:
                # item is (table_name, conf_obj, base_cls, base_imp, cls_name)
                # Check if cls_name is already in file
                cls_name = item[4]
                if f"class {cls_name}" not in existing_content:
                    missing_items.append(item)
            
            if not missing_items:
                summary_table.add_row(file_path_str, str(len(items)), "[yellow]Skipped (All Exist)[/yellow]")
                continue
            
            items = missing_items
            is_append = True
            
        if dry_run:
            status = "[blue]Dry Run (Append)[/blue]" if is_append else "[blue]Dry Run[/blue]"
            summary_table.add_row(file_path_str, str(len(items)), status)
            continue

        # Prepare File Content
        imports_list, classes_code = generate_datacube_module_code(
             items=items, 
             registry=registry, 
             get_db_url_callback=get_url, 
             logger=console.print
        )
        imports = set(imports_list)

        # Collect used config objects for this file to filter imports
        used_configs = set(item[1] for item in items if item[1]) # item[1] is conf_obj
        filtered_global_imports = filter_global_imports(registry.global_imports, used_configs, ignored_prefixes=["solutions.conf"])
        
        if not classes_code:
             if not is_append:
                 summary_table.add_row(file_path_str, "0", "[red]Failed (No Classes Generated)[/red]")
             else:
                 summary_table.add_row(file_path_str, "0", "[red]Failed to Append[/red]")
             continue

        if not is_append:
            # We are generating the field map with Mapping type hint, so we should allow it in the generator
            # but this file writes the datacube class.
            
            full_content = sorted(list(imports)) + filtered_global_imports + ["\n# --- Generated ---"] + classes_code
            file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, "w") as f:
                f.write("\n".join(full_content))
            status_msg = "[green]Generated[/green]"
        else:
            # Append only the new classes
            with open(file_path, "a") as f:
                f.write("\n\n" + "\n".join(classes_code))
            status_msg = f"[green]Appended {len(classes_code)} Classes[/green]"

        # Format using Ruff
        subprocess.run(["uv", "run", "ruff", "format", str(file_path)], capture_output=True)
        summary_table.add_row(file_path_str, str(len(items)), status_msg)

    console.print(summary_table)

@app.command()
def discover(
    config_file: Optional[Path] = typer.Option(None, "--config"),
    db_conf: str = typer.Option("replica_db_conf", help="Config object to use for discovery introspection"),
    db_url_map: Optional[str] = typer.Option(None, "--db-urls"),
    env_file: Optional[Path] = typer.Option(None, "--env-file", "-e", help="Path to environment file"),
    update: bool = typer.Option(False, "--update", help="Update the registry file in place"),
    prune: bool = typer.Option(False, "--prune", help="Remove tables from registry if they are not in the discovery result"),
    run_sync: bool = typer.Option(False, "--sync", help="Run sync immediately after update"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without saving (overrides --update)"),
    generate_fields: bool = typer.Option(False, "--generate-fields", help="Generate field_map files for discovered tables"),
    force: bool = typer.Option(False, "--force", "-f", help="Force overwrite of existing field maps"),
    fields_root: str = typer.Option("solutions.conf.transforms.fields", "--fields-root", help="Python path root for field maps"),
) -> None:
    config_path = config_file or context.default_config
    if not config_path:
        console.print("[red]No config file specified and no default configured.[/red]")
        raise typer.Exit(code=1)

    gen_config_path = config_path.parent / "generator_config.yaml"
    
    # Resolve env_file: CLI > Params > Default
    if env_file:
        env_path = env_file
    elif context.params and context.params.get("defaults", {}).get("env_file"):
        env_path = Path(context.params.get("defaults", {})["env_file"])
    else:
        env_path = Path(".env.linux")
    
    load_environment(env_path, logger=console.print)

    
    with open(config_path, 'r') as f:
        config_data = yaml.safe_load(f)
    registry = DatacubeRegistry(config_data)

    import json
    # Resolve DB URL
    cli_urls = json.loads(db_url_map) if db_url_map else {}
    def get_url(conf_name):
        if conf_name in cli_urls:
            return cli_urls[conf_name]
        url = resolve_db_url(conf_name, registry.global_imports)
        if url:
            return url
        raise ValueError(f"Could not resolve DB URL for '{conf_name}'. Provide via --db-urls or check imports.")

    # --- Initialize Global Field Registry (DEPRECATED) ---
    field_registry = None
    # if context.field_registry_path:
    #     field_registry = GlobalFieldRegistry(context.field_registry_path)

    # --- Core Workflow via Orchestrator ---

    # Remove global rules_path resolution from outside the loop
    # rules_path = config_path.parent / "discovery_rules.yaml" # MOVED INSIDE LOOP

    params = context.params
    databases = params.get("databases", [])
    
    # Fallback to single DB mode if no databases defined (Backwards Compatibility)
    if not databases:
        databases = [{
            "name": db_conf,
            "connection_obj": db_conf,
            # Use standard name if not defined
            "whitelist_file": "discovery_whitelist.yaml",
            "rules_file": "discovery_rules.yaml" 
        }]

    # Filter if user requested specific DB via CLI (using db_conf arg as filter name)
    # The `db_conf` argument defaults to "replica_db_conf". 
    target_db_name = None
    
    aggregated_entries = {}
    last_orchestrator = None

    for db_config in databases:
        db_name = db_config.get("id") or db_config.get("name", "unknown")
        conn_obj = db_config.get("connection_ref") or db_config.get("connection_obj")
        
        # Determine whitelist path
        wl_filename = db_config.get("whitelist_file")
        if not wl_filename:
             # Try global param fallback
             wl_filename = params.get("discovery", {}).get("whitelist_file") or params.get("whitelist_file")
        
        if not wl_filename:
            # Default convention: discovery_whitelist_<db_name>.yaml
            wl_filename = f"discovery_whitelist_{conn_obj}.yaml"
        whitelist_path = config_path.parent / wl_filename

        # Determine rules path
        rules_filename = db_config.get("rules_file")
        if not rules_filename:
            rules_filename = params.get("discovery", {}).get("rules_file") or params.get("rules_file")
            
        if not rules_filename:
             rules_filename = f"discovery_rules_{conn_obj}.yaml"
        rules_path = config_path.parent / rules_filename

        # Determine blacklist path
        bl_filename = db_config.get("blacklist_file", f"discovery_blacklist_{conn_obj}.yaml")
        blacklist_path = config_path.parent / bl_filename

        console.print(f"[bold cyan]Discovering: {db_name} ({conn_obj})[/]")

        try:
            # Use specific import for this DB if available, else standard registry imports (which might be empty now)
            # Support both single string and list in config for robustness
            # Support proper import_spec from new config or legacy global_import
            import_spec = db_config.get("import_spec")
            if import_spec and isinstance(import_spec, dict):
                 imp = import_spec.get("module")
            else:
                 imp = db_config.get("global_import")
            db_imports = [imp] if imp else registry.global_imports
            if not db_imports and registry.global_imports:
                 db_imports = registry.global_imports
            
            db_conn_str = resolve_db_url(conn_obj, db_imports)
        except Exception:
            console.print(f"[red]Could not resolve connection {conn_obj}. Skipping.[/red]")
            continue

        orchestrator = DiscoveryOrchestrator(
            field_registry=field_registry,
            params=context.params,
            rules_path=str(rules_path),
            whitelist_path=str(whitelist_path),
            registry_path=str(config_path),
            db_connection_str=db_conn_str,
            db_config=db_config
        )
        
        try:
            entries = orchestrator.discover()
            aggregated_entries.update(entries)
            last_orchestrator = orchestrator
        except Exception as e:
             console.print(f"[red]Discovery failed for {db_name}: {e}[/red]")
             if not dry_run:
                 raise # Fail hard if not dry run? Or continue? Let's buffer errors? 
                 # For now, log and continue might result in partial registry which is bad (prune would wipe missing).
                 # Fail safe:
                 return

    # Aggregate global imports from ALL databases to ensure registry has them
    aggregated_global_imports = set(params.get("global_imports", []))
    for db in databases:
        if "global_import" in db:
            aggregated_global_imports.add(db["global_import"])
    
    # Save Aggregated Registry
    if last_orchestrator:
        console.print("")
        # Inject aggregated imports into the last orchestrator's update logic?
        # The orchestrator's save_registry loads existing, updates tables, and saves.
        # It DOES NOT currently update global_imports. We need to add that cap.
        
        # Helper manual update for now, or update Orchestrator to support it?
        # Let's update Orchestrator.save_registry to accept global_imports update.
        last_orchestrator.save_registry(
            aggregated_entries, 
            dry_run=dry_run, 
            prune=prune, 
            global_imports=list(aggregated_global_imports)
        )
    
    # Save Registry changes (collected during discovery)
    if not dry_run and field_registry:
        field_registry.save()

    # Generate Field Maps (Bootstrap)
    if generate_fields and not dry_run:
        console.print("")
        console.rule("[bold blue]Generating Field Maps[/]")
        
        # Reload registry to ensure we have latest discovered tables
        with open(config_path, 'r') as f:
            updated_config_data = yaml.safe_load(f)
        updated_registry = DatacubeRegistry(updated_config_data, params=context.params)

        # Convert python path to physical path
        phys_root = Path(fields_root.replace('.', '/'))
        
        # Group tables by connection to use correct inspector
        tables_by_conn = {}
        for t_name, t_data in updated_registry.tables.items():
            conn = t_data.get('connection_obj', updated_registry.default_connection_obj)
            if conn not in tables_by_conn:
                tables_by_conn[conn] = {}
            tables_by_conn[conn][t_name] = t_data
            
        for conn_obj, table_group in tables_by_conn.items():
            try:
                db_url = get_url(conn_obj)
                engine = sa.create_engine(db_url)
                inspector = inspect(engine)
                
                # Use the promoted Generator
                generate_field_map_files(
                    discovered_entries=table_group,
                    inspector=inspector,
                    root_path=phys_root,
                    force=force,
                    logger=console.print,
                    allowed_paths=updated_registry.valid_fieldmap_paths if hasattr(updated_registry, 'valid_fieldmap_paths') else None
                )
            except Exception as e:
                console.print(f"[red]Error generating fields for connection {conn_obj}: {e}[/red]")
    
    # Chained Sync
    if run_sync:
        if dry_run:
            console.print("[yellow]Skipping sync in dry-run mode.[/yellow]")
        elif not update:
             console.print("[yellow]Sync skipped: Registry not updated (use --update to enable chaining).[/yellow]")
        else:
             console.print("")
             console.rule("[bold blue]Auto-Syncing Datacubes[/]")
             # Call sync command directly with current context options
             sync(
                 config_file=config_path,
                 db_url_map=db_url_map, 
                 force=True,
                 env_file=env_file,
                 dry_run=False
             )

@app.command()
def scan(
    config_file: Optional[Path] = typer.Option(None, "--config"),
    db_url_map: Optional[str] = typer.Option(None, "--db-urls"),
    env_file: Optional[Path] = typer.Option(None, "--env-file", "-e"),
    db_name: Optional[str] = typer.Option(None, "--db", help="Target specific database from params"),
) -> None:
    """
    Introspects configured databases and dumps table lists to YAML.
    Step 2 of the workflow.
    """
    config_path = config_file or context.default_config
    if not config_path:
        console.print("[red]No config file specified and no default configured.[/red]")
        raise typer.Exit(code=1)

    # Resolve env_file: CLI > Params > Default
    if env_file:
        env_path = env_file
    elif context.params and "env_file" in context.params:
        env_path = Path(context.params["env_file"])
    else:
        env_path = Path(".env.linux")
    load_environment(env_path, logger=console.print)

    with open(config_path, 'r') as f:
        config_data = yaml.safe_load(f)
    registry = DatacubeRegistry(config_data, params=context.params)

    import json
    cli_urls = json.loads(db_url_map) if db_url_map else {}
    
    # Helper Resolution
    def get_url_safe(conf_name, db_imp):
         if conf_name in cli_urls: return cli_urls[conf_name]
         imp = [db_imp] if db_imp else registry.global_imports
         return resolve_db_url(conf_name, imp)

    params = context.params
    databases = params.get("databases", [])
    
    # Filter targets
    target_dbs = databases
    if db_name:
        target_dbs = [d for d in databases if d.get("name") == db_name]
        if not target_dbs:
             console.print(f"[red]Database '{db_name}' not found.[/red]")
             raise typer.Exit(code=1)

    
    # Resolve global output file
    global_tables_file = params.get("all_tables_file") or "all_tables.yaml"
    global_tables_path = config_path.parent / global_tables_file
    
    # Load existing data to preserve config for DBs not being scanned
    all_tables_data = {}
    if global_tables_path.exists():
        with open(global_tables_path, "r") as f:
            all_tables_data = yaml.safe_load(f) or {}

    for db in target_dbs:
        name = db.get("name")
        conn_obj = db.get("connection_obj")
        
        console.print(f"[bold cyan]Scanning: {name} ...[/bold cyan]")
        try:
            db_url = get_url_safe(conn_obj, db.get("global_import"))
            if not db_url:
                console.print(f"[red]Could not resolve URL for {conn_obj}[/red]")
                continue
                
            engine = sa.create_engine(db_url)
            inspector = inspect(engine)
            tables = sorted(inspector.get_table_names())
            
            # Update shared dictionary
            all_tables_data[conn_obj] = tables
            console.print(f"[green]Found {len(tables)} tables for {conn_obj}[/green]")
            
        except Exception as e:
            console.print(f"[red]Scan failed for {name}: {e}[/red]")
            if params.get("debug"): raise e

    # Persist aggregated result
    with open(global_tables_path, "w") as f:
        yaml.dump(all_tables_data, f, sort_keys=False)
        
    console.print(f"[bold green]Updated table list at {global_tables_path}[/bold green]")

@app.command()
def drift(
    config_file: Optional[Path] = typer.Option(None, "--config"),
    db_url_map: Optional[str] = typer.Option(None, "--db-urls", help="Optional JSON mapping. If omitted, tries to resolve from code."),
    env_file: Optional[Path] = typer.Option(None, "--env-file", "-e", help="Path to environment file"),
) -> None:
    """
    Checks for 'drift' between the generated Python classes and the DB schema.
    """
    config_path = config_file or context.default_config
    if not config_path:
        console.print("[red]No config file specified and no default configured.[/red]")
        raise typer.Exit(code=1)

    # Resolve env_file: CLI > Params > Default
    if env_file:
        env_path = env_file
    elif context.params and "env_file" in context.params:
        env_path = Path(context.params["env_file"])
    else:
        env_path = Path(".env.linux")

    load_environment(env_path, logger=console.print)


    with open(config_path, 'r') as f:
        config_data = yaml.safe_load(f)
    
    registry = DatacubeRegistry(config_data)
    get_url = _get_db_url_callback(registry, db_url_map)
    cli_urls = json.loads(db_url_map) if db_url_map else {}
    
    drift_table = Table(title="Schema Drift Analysis")
    drift_table.add_column("Class", style="cyan")
    drift_table.add_column("Status", style="bold")
    drift_table.add_column("Issues", style="red")

    # The keys in processed_mappings correspond to the attribute names we need to check
    attribute_names = list(registry.processed_mappings.keys())

    for table_name, details in registry.tables.items():
        target = details.get('save_to_path', details.get('path'))
        if not target:
             drift_table.add_row(table_name, "[red]Config Error[/red]", "Missing save_to_path")
             continue
        path = Path(target)
        if not path.exists():
            console.print(f"[yellow]Skipping {table_name}: File {path} not found.[/yellow]")
            continue

        # 1. Determine Class Name
        provided_class_name = details.get('class_name')
        class_name = provided_class_name if provided_class_name else "".join(w.capitalize() for w in table_name.split('_')) + "Dc"

        # 2. Dynamically load the generated class from the file
        try:
            spec = importlib.util.spec_from_file_location(f"dynamic_mod_{table_name}", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            dc_class = getattr(mod, class_name)
        except Exception as e:
            drift_table.add_row(class_name, "[red]Load Error[/red]", str(e))
            continue

        # 3. Determine DB URL
        # Priority: CLI Override > Class Attribute > Registry Config
        db_url = None
        conf_obj = details.get('connection_obj', details.get('config_obj', registry.default_connection_obj))

        if conf_obj in cli_urls:
            db_url = cli_urls[conf_obj]
        elif hasattr(dc_class, 'connection_url'):
            db_url = getattr(dc_class, 'connection_url')
        elif hasattr(dc_class, 'config') and isinstance(dc_class.config, dict):
            db_url = dc_class.config.get('connection_url')
        
        # Fallback to registry resolution
        if not db_url:
            try:
                db_url = get_url(conf_obj)
            except Exception:
                pass 

        # 4. Introspect DB
        try:
            engine = sa.create_engine(db_url)
            inspector = inspect(engine)
            db_cols = {c['name'] for c in inspector.get_columns(table_name)}
        except Exception as e:
             drift_table.add_row(class_name, "[red]DB Error[/red]", repr(e))
             continue

        # 5. Extract Field Map (if any)
        field_map = getattr(dc_class, 'field_map', None)
        if not field_map and hasattr(dc_class, 'config') and isinstance(dc_class.config, dict):
             field_map = dc_class.config.get('field_map')

        # 6. Check Drift
        issues = check_drift(dc_class, db_cols, attribute_names, field_map=field_map)

        if not issues:
            drift_table.add_row(class_name, "[green]Synced[/green]", "None")
        else:
            drift_table.add_row(class_name, "[yellow]DRIFT[/yellow]", "\n".join(issues))

    console.print(drift_table)




@app.command()
def match(
    config_file: Optional[Path] = typer.Option(None, "--config"),
    db_name: Optional[str] = typer.Option(None, "--db", help="Target specific database from params"),
) -> None:
    """
    Applies discovery rules to scanned tables and generates whitelists (registry).
    Step 3 of the workflow.
    """
    config_path = config_file or context.default_config
    if not config_path:
        console.print("[red]No config file specified and no default configured.[/red]")
        raise typer.Exit(code=1)

    import yaml
    
    # Load Params
    params_path = config_path.parent / "discovery_params.yaml" # Assuming relative location or loaded via context
    # Context should already have params if set_context_defaults ran, but to be safe/standalone:
    params = context.params
    databases = params.get("databases", [])
    folder_prefix = params.get("folder_prefix", "solutions/dataobjects/gencubes/")
    fields_suffix = params.get("fields_module_root", "fields")



    target_dbs = databases
    if db_name:
        target_dbs = [d for d in databases if d.get("name") == db_name]
        if not target_dbs:
             console.print(f"[red]Database '{db_name}' not found.[/red]")
             raise typer.Exit(code=1)

    for db in target_dbs:
        name = db.get("name")
        all_tables_file = db.get("all_tables_file")
        rules_file = db.get("rules_file")
        whitelist_file = db.get("whitelist_file")
        conn_obj = db.get("connection_obj")
        
        # Path Composition
        db_domain = db.get("db_domain")
        import_base = Path(folder_prefix)
        if db_domain:
            import_base = import_base / db_domain
        import_base = import_base / fields_suffix
        
        try:
            import_base = import_base.relative_to(Path.cwd())
        except ValueError:
            pass
        fields_module_base = str(import_base).replace("/", ".")
        
        if not (all_tables_file and rules_file and whitelist_file):
             console.print(f"[yellow]Skipping {name}: Missing file config.[/yellow]")
             continue

        tables_path = config_path.parent / all_tables_file
        rules_path = config_path.parent / rules_file
        out_path = config_path.parent / whitelist_file
        
        if not tables_path.exists():
            console.print(f"[red]Skipping {name}: {all_tables_file} not found. Run 'scan' first.[/red]")
            continue
            
        if not rules_path.exists():
             console.print(f"[yellow]Skipping {name}: Rules file {rules_file} not found.[/yellow]")
             continue
        
        # Load existing whitelist to preserve customizations
        existing_whitelist = {}
        if out_path.exists():
            with open(out_path, "r") as f:
                data = yaml.safe_load(f) or {}
                existing_whitelist = data.get("tables", {})

        with open(tables_path, "r") as f:
            all_tables = yaml.safe_load(f) or []
            
        with open(rules_path, "r") as f:
            rules_data = yaml.safe_load(f) or []
            
        # Match Logic
        console.print(f"[bold cyan]Matching: {name} ({len(all_tables)} tables)[/bold cyan]")
        
        matches = {}
        matched_count = 0
        
        for table in sorted(all_tables):
            # Find first matching rule
            matched_rule = None
            for r in rules_data:
                pattern = r.get("pattern")
                mtype = r.get("match_type", "exact")
                
                is_match = False
                if mtype == "exact" and table == pattern:
                    is_match = True
                elif mtype == "prefix" and table.startswith(pattern):
                    is_match = True
                elif mtype == "regex":
                     import re
                     if re.search(pattern, table):
                         is_match = True
                
                if is_match:
                    matched_rule = r
                    break
            
            if matched_rule:
                # Construct Registry Entry
                # Resolve path using folder_prefix
                template = matched_rule.get("output_template", f"{table}_cubes.py")
                domain = matched_rule.get("domain", "common")
                
                # Path Construction: folder_prefix + db_domain + domain + output_template
                db_domain = db.get("db_domain", "")
                
                # Careful not to double slash if db_domain is empty, but Path handles it.
                # template should now be just filename per rule updates.
                full_path_obj = Path(folder_prefix)
                if db_domain:
                    full_path_obj = full_path_obj / db_domain
                
                full_path_obj = full_path_obj / domain / template
                full_path = str(full_path_obj)
                
                # Class Name Generation
                # Check if exists in old whitelist
                existing_entry = existing_whitelist.get(table, {})
                
                custom_name = existing_entry.get("custom_name")
                
                if custom_name:
                    class_name = custom_name
                elif existing_entry.get("class_name"):
                    class_name = existing_entry.get("class_name")
                else:
                    class_suffix = params.get("class_suffix", "Dc")
                    class_name = "".join(w.capitalize() for w in table.split("_")) + class_suffix

                field_map_template = matched_rule.get("field_map_template", f"{fields_module_base}.{{domain}}.{{table}}.field_map")
                
                # Construct defaults
                entry = {
                    "path": full_path,
                    "connection_obj": matched_rule.get("db_conn_override") or conn_obj,
                    "domain": domain,
                    "class_name": class_name,
                    # Ensure field_map is assigned
                    "field_map": field_map_template.format(domain=domain, table=table)
                }
                
                # Preserve custom_name if present, else default to None
                entry["custom_name"] = custom_name if custom_name else None
                
                # Preserve other fields if needed? 
                # User asked specifically for keys on class_name preservation.
                # But generally we might want to respect other overrides? 
                # For now, strict to class_name per request + generation logic.
                
                matches[table] = entry
                matched_count += 1

        # Write Whitelist (Registry)
        output_data = {"tables": matches}
        with open(out_path, "w") as f:
            yaml.dump(output_data, f, sort_keys=False)
            
        console.print(f"[green]Matched {matched_count} tables. Written to {out_path}[/green]")

@app.command()
def map(
    config_file: Optional[Path] = typer.Option(None, "--config"),
    db_url_map: Optional[str] = typer.Option(None, "--db-urls"),
    env_file: Optional[Path] = typer.Option(None, "--env-file", "-e"),
    db_name: Optional[str] = typer.Option(None, "--db", help="Target specific database from params"),
    force: bool = typer.Option(False, "--force", "-f"),
) -> None:
    """
    Generates YAML field maps for tables in the whitelist.
    Step 4 of the workflow.
    """
    config_path = config_file or context.default_config
    if not config_path:
        console.print("[red]No config file specified.[/red]")
        raise typer.Exit(code=1)

    # Env Load
    if env_file:
        env_path = env_file
    elif context.params and "env_file" in context.params:
        env_path = Path(context.params["env_file"])
    else:
        env_path = Path(".env.linux")
    load_environment(env_path, logger=console.print)
    
    import json
    cli_urls = json.loads(db_url_map) if db_url_map else {}
    registry = DatacubeRegistry({}, params=context.params) # Dummy reg for imports

    def get_url_safe(conf_name, db_imp):
         if conf_name in cli_urls: return cli_urls[conf_name]
         imp = [db_imp] if db_imp else registry.global_imports
         return resolve_db_url(conf_name, imp)

    params = context.params
    databases = params.get("databases", [])
    
    target_dbs = databases
    if db_name:
        target_dbs = [d for d in databases if d.get("name") == db_name]
        
    _run_field_map_generation(context, config_path, target_dbs, get_url_safe, force=force)
    return
@app.command()
def init(
    config_file: Optional[Path] = typer.Option(None, "--config"),
    db_conf: Optional[str] = typer.Option(None, help="Config object to use for introspection"),
    db_name: Optional[str] = typer.Option(None, "--db", help="Target specific database from params"),
    db_url_map: Optional[str] = typer.Option(None, "--db-urls"),
    env_file: Optional[Path] = typer.Option(None, "--env-file", "-e"),
    dump_schema: Optional[Path] = typer.Option(None, "--dump-schema", help="Dump database schema"),
    init_whitelist: Optional[Path] = typer.Option(None, "--init-whitelist", help="Initialize whitelist from DB tables"),
    init_rules: Optional[Path] = typer.Option(None, "--init-rules", help="Initialize discovery rules from DB tables"),
    reset: bool = typer.Option(False, "--reset", help="Reset registry and config to defaults"),
) -> None:
    """
    Initializes configuration, schema dumps, and whitelists.
    """
    params = context.params
    
    # Determine Targets
    databases = params.get("databases", [])
    target_dbs = []

    if db_name:
        # Filter specific DB
        target_dbs = [d for d in databases if d.get("name") == db_name]
        if not target_dbs:
             console.print(f"[red]Database '{db_name}' not found in params.[/red]")
             raise typer.Exit(code=1)
    elif databases:
        # All DBs
        target_dbs = databases
    else:
        # Legacy Fallback
        target_db_conf = db_conf or params.get("default_connection_obj", "replica_db_conf")
        target_dbs = [{"name": target_db_conf, "connection_obj": target_db_conf, "whitelist_file": "discovery_whitelist.yaml"}]

    # Validate db_conf override if provided (only if single target or legacy)
    if db_conf and not db_name and not databases:
         target_dbs[0]["connection_obj"] = db_conf

    # Resolve env_file: CLI > Params > Default
    if env_file:
        env_path = env_file
    elif context.params and "env_file" in context.params:
        env_path = Path(context.params["env_file"])
    else:
        env_path = Path(".env.linux")
    load_environment(env_path, logger=console.print)


    # Resolve Context (Registry/Config Paths)
    # Be robust if config_file doesn't exist yet
    config_path = config_file or context.default_config
    
    if not config_path:
        console.print("[red]No config file target specified.[/red]")
        raise typer.Exit(code=1)

    import json
    cli_urls = json.loads(db_url_map) if db_url_map else {}

    # Helper to resolve URL without a full registry instance if file missing
    def resolve_url_safe(conf_name):
        if conf_name in cli_urls: return cli_urls[conf_name]
        
        # Check params first
        for db in databases:
             if db.get("connection_obj") == conf_name:
                 imp = db.get("global_import")
                 if imp:
                     url = resolve_db_url(conf_name, [imp])
                     if url: return url
        
        # Try loading defaults if registry file exists
        if config_path.exists():
            with open(config_path, 'r') as f:
                data = yaml.safe_load(f)
            # Minimal registry just to get imports/resolution
            reg = DatacubeRegistry(data, params=context.params)
            url = resolve_db_url(conf_name, reg.global_imports)
            if url: return url
        
        # Fallback: try raw resolve (might fail if imports missing)
        url = resolve_db_url(conf_name, []) 
        if url: return url
        raise ValueError("Cannot resolve DB URL. Please ensure registry exists or use --db-urls.")

    # 1. Reset / Initialize Files (Global)
    if reset:
        if typer.confirm("Are you sure you want to reset the registry?"):
             # We rely on params being provided by the wrapper/context now.
             if not params:
                 console.print("[yellow]Warning: No params loaded from context. Defaults may be minimal.[/yellow]")

             # Registry Default
             default_registry = {
                 "global_imports": params.get("global_imports", []),
                 "tables": {}
             }
             with open(config_path, "w") as f:
                 yaml.dump(default_registry, f, sort_keys=False)
             console.print(f"[green]Reset {config_path}[/green]")

    # Loop over targets for DB-specific actions
    for db in target_dbs:
        db_name = db.get("name")
        conn_obj = db.get("connection_obj")
        
        try:
            db_url = resolve_url_safe(conn_obj)
            engine = sa.create_engine(db_url)
        except Exception as e:
            console.print(f"[red]Skipping {db_name}: Cannot check DB connection ({e})[/red]")
            continue

        # 2. Dump Schema
        if dump_schema:
            from sibi_flux.datacube.generator import dump_db_schema
            console.print(f"[bold]Dumping schema for {db_name}...[/bold]")
            dump_db_schema(
                engine=engine,
                db_name=db_name,
                output_dir=dump_schema,
                logger=console.print
            )
        
        # 3. Initialize Whitelist
        if init_whitelist:
            insp = inspect(engine)
            tables = insp.get_table_names()
            
            # Determine path
            if init_whitelist.name == "discovery_whitelist.yaml": # CLI Default value check? 
                # Actually Typer might pass the value even if default.
                # If valid path provided, usage is ambiguous with multi-db.
                # If explicit path provided, we write to IT. (Overwriting per loop? Bad).
                # Convention: If explicit path provided, we assume single DB mode or user knows what they do.
                # BUT here we want to use the config-defined whitelist file if available.
                
                wl_file = db.get("whitelist_file", f"discovery_whitelist_{db_name}.yaml")
                target_path = config_path.parent / wl_file
            else:
                target_path = init_whitelist
                if not target_path.is_absolute():
                     target_path = config_path.parent / target_path
                
            console.print(f"Initializing whitelist at {target_path} for {db_name} with {len(tables)} tables...")
            dump_data = sorted(tables)
            with open(target_path, 'w') as f:
                yaml.dump({'tables': dump_data}, f, sort_keys=False)
            console.print(f"[green]whitelist initialized for {db_name}.[/green]")

        # 4. Initialize Rules (Global/Merged?)
        # Rules are usually global. Initializing from ONE db might miss others, 
        # or overwriting rules file repeatedly.
        # We'll skip complex merging for now and just append or warn.
        if init_rules:
             insp = inspect(engine)
             tables = insp.get_table_names()
             
             target_path = init_rules
             if not target_path.is_absolute():
                 target_path = config_path.parent / target_path
             
             # Load existing to append?
             existing_rules = []
             if target_path.exists():
                 with open(target_path, 'r') as f:
                     existing_rules = yaml.safe_load(f) or []
                     
             console.print(f"Appending rules for {db_name} tables...")
             
             new_rules = []
             for table in sorted(tables):
                 # Check existence
                 if any(r['pattern'] == table for r in existing_rules):
                     continue
                     
                 new_rules.append({
                     "pattern": table,
                     "match_type": "exact",
                     "domain": "common",
                     "output_template": f"common/{table}_cubes.py",
                     "db_conn_override": conn_obj 
                 })
                 
             all_rules = existing_rules + new_rules
             
             with open(target_path, 'w') as f:
                 yaml.dump(all_rules, f, sort_keys=False)
             console.print(f"[green]Rules updated for {db_name}.[/green]")



def _run_field_map_generation(context, config_path, target_dbs, url_resolver, force=False):
    """Shared logic for generating field map files."""
    params = context.params
    folder_prefix = params.get("folder_prefix", "solutions/dataobjects/gencubes/")
    fields_suffix = params.get("fields_module_root", "fields")
    
    from sibi_flux.datacube.field_mapper import FieldTranslationManager
    
    # Initialize Manager & Load Global Repo
    repo_rel_path = context.params.get("global_repo_path", "solutions/conf/global_field_repository.yaml")
    global_repo_path = Path(repo_rel_path).resolve()
    
    manager = FieldTranslationManager()
    
    if global_repo_path.exists():
        with open(global_repo_path, "r") as f:
            repo_data = yaml.safe_load(f) or []
            manager.load_from_list(repo_data)
        console.print(f"[green]Loaded {len(manager.fields)} fields from Global Repository.[/green]")
    else:
        console.print(f"[dim]Global Repository not found at {global_repo_path}, creating new...[/dim]")

    for db in target_dbs:
        name = db.get("id") or db.get("name")
        conn_obj = db.get("connection_ref") or db.get("connection_obj")
        
        if not db.get("enable_field_map_generation", True) and not params.get("generation", {}).get("enable_field_maps", True):
             console.print(f"[dim]Skipping {name}: Field map generation disabled.[/dim]")
             continue

        # Language Settings
        source_lang = db.get("db_source_lang", "es")
        target_lang = db.get("db_target_lang", "en")

        # Path Composition
        db_domain = db.get("db_domain")
        fields_root_path = Path(folder_prefix)
        if db_domain:
            fields_root_path = fields_root_path / db_domain
        fields_root_path = fields_root_path / fields_suffix
        
        
        # Resolve global whitelist path
        # Try nested discovery param first, then legacy flat
        global_whitelist_file = (
            params.get("discovery", {}).get("whitelist_file") or 
            params.get("whitelist_file") or 
            "whitelist.yaml"
        )
        
        # If absolute, use directly (handled by gen_dc.py resolution), else resolve
        if Path(global_whitelist_file).is_absolute():
            wl_path = Path(global_whitelist_file)
        else:
            wl_path = config_path.parent / global_whitelist_file
        
        if not wl_path.exists():
            console.print(f"[yellow]Skipping {name}: Whitelist {global_whitelist_file} not found.[/yellow]")
            continue
            
        with open(wl_path, "r") as f:
            registry_data = yaml.safe_load(f) or {}

        # Default to empty dict if key not found
        scoped_data = registry_data.get(conn_obj, {})
        tables = scoped_data.get("tables", {})
        if not tables:
             console.print(f"[dim]No tables in whitelist for {name}.[/dim]")
             continue

        console.print(f"[bold cyan]Mapping fields for {name} ({len(tables)} tables) [Src:{source_lang} -> Tgt:{target_lang}]...[/bold cyan]")
        
        try:
            db_url = url_resolver(conn_obj, db.get("global_import"))
            engine = sa.create_engine(db_url)
            inspector = inspect(engine)
            
            for table_name, details in tables.items():
                if not details.get("field_map"):
                     continue

                domain = details.get("domain", "common")
                
                # Target Dir
                target_dir = fields_root_path / domain
                target_dir.mkdir(parents=True, exist_ok=True)
                if not (target_dir / "__init__.py").exists():
                    (target_dir / "__init__.py").touch()
                
                # Python Target File
                target_file = target_dir / f"{table_name}.py"
                
                # Skip if exists and not force
                if target_file.exists() and not force:
                    # console.print(f"DEBUG: Skipping existing {table_name}")
                    continue
                
                try:
                    cols = inspector.get_columns(table_name)
                    # console.print(f"DEBUG: Generating {table_name} with {len(cols)} columns")
                    field_map = {}
                    
                    full_table_name = f"{domain}.{table_name}"
                    
                    for c in cols:
                        col_name = c["name"]
                        col_type = str(c["type"])
                        
                        # 1. Register / Get Canonical Field
                        trans_msg = manager.register_field(col_name, col_type, full_table_name)
                        if trans_msg:
                            console.print(f"  [dim]{trans_msg}[/dim]")
                            
                        # 2. Get Field Definition
                        fid = manager._generate_id(col_name, col_type)
                        field_def = manager.fields.get(fid)
                        
                        if field_def:
                            # 3. Translate if needed
                            if target_lang not in field_def.aliases:
                                manager.translate_alias(fid, target_lang)
                            
                            # 4. Determine Target Column
                            target_alias = field_def.aliases.get(target_lang) or field_def.aliases.get("en") or col_name
                            target_col = manager.generate_target_column(target_alias)
                            
                            if not field_def.target_column:
                                field_def.target_column = target_col
                            else:
                                target_col = field_def.target_column

                            field_map[col_name] = target_col
                        else:
                            field_map[col_name] = col_name

                    # GENERATE PYTHON CODE USING FACTORY
                    lines = [
                        "from typing import Mapping, Any, List",
                        "from sibi_flux.datacube.field_factory import FieldMapFactory",
                        "",
                        "COLUMNS: List[str] = [",
                    ]
                    for col_name in field_map.keys():
                        lines.append(f'    "{col_name}",')
                    lines.append("]")
                    
                    lines.append("")
                    lines.append(f'field_map: Mapping[str, str] = FieldMapFactory.create("{table_name}", COLUMNS)')
                    
                    # Generate metadata call
                    lines.append("")
                    lines.append(f'metadata: Mapping[str, Any] = FieldMapFactory.create_metadata("{table_name}", COLUMNS)')
                    
                    with open(target_file, "w") as f:
                        f.write("\n".join(lines))
                        
                except Exception as e:
                    console.print(f"[red]Error mapping {table_name}: {e}[/red]")
                    if context.params.get("debug"): raise e
                    
        except Exception as e:
             console.print(f"[red]Error processing DB {name}: {e}[/red]")

    # Save Global Repo
    manager.save_to_yaml(global_repo_path)
    console.print("Saved Global Field Repository.")


if __name__ == "__main__":
    app()
