import yaml
import os
from typing import Set, Dict, Any, Optional, Mapping, Iterable
from sqlalchemy import create_engine, inspect
from rich.console import Console

# Import the ConfigurationEngine
from .config_engine import ConfigurationEngine

console = Console()


class DiscoveryOrchestrator:
    def __init__(
        self,
        params: Mapping[str, Any],
        rules_path: Optional[str] = "discovery_rules.yaml",
        whitelist_path: str = "discovery_whitelist.yaml",
        registry_path: str = "datacube_registry.yaml",
        db_connection_str: Optional[str] = None,
        field_registry: Optional[Any] = None,
        db_config: Optional[dict] = None,
    ):
        context_key = (
            db_config.get("connection_ref") or 
            db_config.get("connection_obj") 
        ) if db_config else None
        self.config_engine = ConfigurationEngine(params, rules_path, context_key=context_key)

        self.whitelist_path = whitelist_path
        self.whitelist_path = whitelist_path
        self.registry_path = registry_path
        self.db_url = db_connection_str
        self.field_registry = field_registry
        self.db_config = db_config

    def run(self, dry_run: bool = False, prune: bool = False):
        """
        Executes the full discovery workflow (Discover + Save).
        Maintained for backward compatibility or single-run calls.
        """
        entries = self.discover()
        self.save_registry(entries, dry_run, prune)

    def discover(self) -> Mapping[str, Any]:
        """
        Executes Steps 1-3 (Read -> Whitelist -> Blacklist -> Rules).
        Returns the dictionary of discovered registry entries.
        """
        db_name = self.db_config.get("id") or self.db_config.get("name") or "default" if self.db_config else "default"
        console.rule(f"[bold blue]Step 1: Read Schema ({db_name})[/]")
        db_tables = self._step_1_read_schema()

        console.rule("[bold blue]Step 2: Apply Whitelist[/]")
        whitelisted_map = self._step_2_apply_whitelist(db_tables)

        # console.rule("[bold blue]Step 2b: Apply Blacklist[/]")
        # Blacklist logic removed

        console.rule("[bold blue]Step 3: Apply Discovery Rules[/]")
        return self._step_3_apply_rules(whitelisted_map)

    # ... (Step 1 and Step 2 omitted for brevity) ...

    # --- Step 2b: Apply Blacklist ---
    # Step 2b Removed
        """
        Removes tables that match any pattern in the blacklist.
        """
        if not self.blacklist_path or not os.path.exists(self.blacklist_path):
            console.print("[dim]No blacklist file configured or found. Skipping.[/dim]")
            return table_map

        with open(self.blacklist_path, "r") as f:
            data = yaml.safe_load(f) or {}

        blacklist_rules = data.get("blacklist", [])
        if not blacklist_rules:
             console.print("[dim]Blacklist is empty. Skipping.[/dim]")
             return table_map

        filtered_map = {}
        blacklisted_count = 0
        
        for table, meta in table_map.items():
            is_blacklisted = False
            for rule in blacklist_rules:
                pattern = rule.get("pattern")
                match_type = rule.get("match_type", "exact")
                
                if match_type == "exact" and table == pattern:
                    is_blacklisted = True
                    break
                elif match_type == "prefix" and table.startswith(pattern):
                    is_blacklisted = True
                    break
                elif match_type == "regex":
                    import re
                    if re.search(pattern, table):
                        is_blacklisted = True
                        break
            
            if is_blacklisted:
                blacklisted_count += 1
            else:
                filtered_map[table] = meta

        if blacklisted_count > 0:
            console.print(f"[yellow]Excluded {blacklisted_count} tables based on blacklist rules.[/yellow]")
        
        console.print(f"Proceeding with [green]{len(filtered_map)}[/] tables.")
        return filtered_map

    def _step_1_read_schema(self) -> Set[str]:
        """Introspects the database to get the raw list of actual tables."""
        if not self.db_url:
            raise ValueError("No database connection string provided.")

        try:
            engine = create_engine(self.db_url)
            inspector = inspect(engine)
            tables = set(inspector.get_table_names())
            console.print(f"Found [green]{len(tables)}[/] tables in the database.")
            return tables
        except Exception as e:
            console.print(f"[red]Error connecting to DB: {e}[/red]")
            raise

    # --- Step 2: Read Whitelist ---
    def _step_2_apply_whitelist(self, db_tables: Set[str]) -> Dict[str, Any]:
        """
        Intersects the DB tables with the whitelist.
        Returns a map {table_name: whitelist_metadata}.
        If metadata is missing (legacy whitelist), value is {}.
        """
        if not os.path.exists(self.whitelist_path):
            console.print(
                "[dim]No whitelist file found. Proceeding in Rule-Driven Mode (using configurator exclusions).[/dim]"
            )
            return {t: {} for t in db_tables}

        with open(self.whitelist_path, "r") as f:
            data = yaml.safe_load(f) or {}

        # 1. Scoped Lookup (New Standard)
        key = self.config_engine.context_key
        raw = data
        if key and isinstance(data, dict) and key in data:
            raw = data[key]
            # Unwrap 'tables' if nested
            if isinstance(raw, dict) and "tables" in raw:
                raw = raw["tables"]
        
        # 2. Legacy/Global Fallback
        elif isinstance(data, dict) and "tables" in data:
            raw = data["tables"]
        
        whitelisted_map = {}
        if isinstance(raw, dict):
            whitelisted_map = raw
        elif isinstance(raw, list):
            whitelisted_map = {t: {} for t in raw}
        
        if not whitelisted_map:
            console.print(
                "[yellow]Whitelist found but empty. Processing ALL tables.[/]"
            )
            return {t: {} for t in db_tables}

        # 1. Validation: Whitelisted items missing from DB
        wl_keys = set(whitelisted_map.keys())
        missing = wl_keys - db_tables
        if missing:
            console.print(
                f"[red]Warning: {len(missing)} tables in whitelist not found in DB:[/]"
            )
            for t in missing:
                console.print(f"  - {t}")

        # 2. Filtering: Only process tables that exist in both
        valid_keys = db_tables.intersection(wl_keys)
        
        final_map = {k: whitelisted_map[k] for k in valid_keys}
        
        console.print(
            f"Proceeding with [green]{len(final_map)}[/] whitelisted tables."
        )

        return final_map

    # --- Step 3: Apply Rules ---
    def _step_3_apply_rules(self, table_map: Dict[str, Any]) -> Mapping[str, Any]:
        """
        Runs the ConfigurationEngine against the filtered table map.
        Prioritizes metadata from whitelist (e.g. 'path') over rules.
        """
        registry_updates = {}
        tables = set(table_map.keys())

        # Optional: Register columns if field_registry is present
        if self.field_registry and self.db_url:
            try:
                engine = create_engine(self.db_url)
                inspector = inspect(engine)
                console.print(f"Registering fields for {len(tables)} tables in Global Registry...")
                
                for table in tables:
                    try:
                        cols = inspector.get_columns(table)
                        for col in cols:
                            # Register with default logic (creates TODO if new)
                            self.field_registry.register_field(original_name=col['name'])
                    except Exception as e:
                        # Log but don't fail discovery
                        pass
                        
            except Exception as e:
                console.print(f"[red]Error during field registration: {e}[/red]")

        for table, meta in table_map.items():
            # delegated to the Logic Engine
            match_result = self.config_engine.resolve_table(table, db_config=self.db_config)

            if match_result:
                # Merge Whitelist Meta (Priority) > Rule Match Result
                final_entry = match_result.copy()
                if meta:
                    # Update fields if present in whitelist meta
                    # Common overrides: path, field_map, class_name
                    for k in ["path", "field_map", "connection_obj", "class_name", "custom_name"]:
                        if k in meta:
                            final_entry[k] = meta[k]
                
                # Priority: custom_name > class_name
                if final_entry.get("custom_name"):
                    final_entry["class_name"] = final_entry["custom_name"]

                registry_updates[table] = {
                    "path": final_entry["path"],
                    "field_map": final_entry["field_map"],
                    "connection_obj": final_entry["connection_obj"],
                    "class_name": final_entry.get("class_name") # Preserve class_name if exists
                }
                # Always include custom_name, defaulting to None
                registry_updates[table]["custom_name"] = final_entry.get("custom_name")
            else:
                console.print(f"[dim]Skipping {table}: No matching discovery rule.[/]")

        console.print(
            f"Mapped [green]{len(registry_updates)}[/] tables to configuration rules."
        )
        return registry_updates

    # --- Step 4: Generate Datacube Registry ---
    def save_registry(
        self, 
        new_entries: Mapping[str, Any], 
        dry_run: bool, 
        prune: bool,
        global_imports: Optional[Iterable[str]] = None
    ):
        """
        Merges new entries into existing registry and saved.
        """
        console.rule("[bold blue]Step 4: Generate Registry[/]")
        # Load existing
        current_data = {}
        if os.path.exists(self.registry_path):
            with open(self.registry_path, "r") as f:
                current_data = yaml.safe_load(f) or {}

        if "tables" not in current_data:
            current_data["tables"] = {}

        # Update Global Imports if provided
        if global_imports:
            current_data["global_imports"] = sorted(list(set(current_data.get("global_imports", [])).union(global_imports)))

        if prune:
            current_data["tables"] = new_entries
            console.print(
                "[yellow]Prune active: Registry replaced with discovery results.[/]"
            )
        else:
            # Merge: Update existing keys, add new ones.
            current_data["tables"].update(new_entries)

        # Sort tables for readability
        current_data["tables"] = dict(sorted(current_data["tables"].items()))

        if dry_run:
            console.print("[yellow]DRY RUN: Registry would be updated with keys:[/]")
            console.print(list(new_entries.keys()))
        else:
            with open(self.registry_path, "w") as f:
                yaml.dump(current_data, f, sort_keys=False)
            console.print(f"[bold green]Success! Updated {self.registry_path}[/]")
