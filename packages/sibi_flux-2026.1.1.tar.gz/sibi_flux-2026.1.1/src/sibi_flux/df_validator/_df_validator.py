import dask.dataframe as dd
import pandas as pd

try:
    from dask.distributed import Client, get_client
except ImportError:
    Client = object
    get_client = None
from typing import Dict, Optional
import warnings

from sibi_flux.core.type_maps import DASK_TO_CLICKHOUSE_DTYPE
from sibi_flux.logger import Logger


class DfValidator:
    def __init__(
        self,
        df: pd.DataFrame | dd.DataFrame,
        dask_client: Optional[Client] = None,
        debug: bool = False,
        logger: Optional[Logger] = None,
    ):
        """
        Initializes the Validator with an existing DataFrame (Dask or Pandas).
        The class's role is to ensure the DF meets target schema and quality standards.
        """
        self.df = df
        self.is_dask = isinstance(df, dd.DataFrame)
        self.dask_client = dask_client  # Stores the dask_client reference

        # 1. Initialize the logger consistently
        # Determine log level based on debug flag (assuming Logger has a similar standard)
        log_level = 10 if debug else 20
        # If logger is not provided, use a default factory method (assuming Logger has one)
        self.logger = logger or Logger.default_logger(
            logger_name=self.__class__.__name__, log_level=log_level
        )
        self.logger.info("--- DfValidator Initialized ---")

        self._establish_dask_dask_client()  # Renamed and simplified the dask_client helper

    # --- 1. Internal Helpers ---

    def _establish_dask_dask_client(self):
        """Finds or confirms the Dask client connection."""
        if self.is_dask:
            try:
                if get_client is None:
                    raise ImportError("Dask Distributed not installed.")
                self.dask_client = self.dask_client or get_client()
                self.logger.info(
                    f"✅ Dask Client detected. Dashboard: {self.dask_client.dashboard_link}"
                )
            except ValueError:
                self.logger.warning("⚠️ No Dask Client found. Running synchronously.")
        else:
            self.logger.info("Initialized with Pandas DataFrame (local mode).")

    def _normalize_dtype_alias(self, dtype_str: str) -> str:
        """
        Helper to normalize Dask/PyArrow dtype string aliases to the canonical
        Pandas Extension type string for robust comparison.

        This fixes the common test failures caused by 'int64[pyarrow]' vs 'Int64[pyarrow]'.
        """
        #
        mapping = {
            "int64[pyarrow]": "Int64[pyarrow]",
            "int64": "Int64[pyarrow]",
            "int32[pyarrow]": "Int32[pyarrow]",
            "int32": "Int32[pyarrow]",
            "double[pyarrow]": "Float64[pyarrow]",
            "float64[pyarrow]": "Float64[pyarrow]",
            "float64": "Float64[pyarrow]",
            "string": "string[pyarrow]",
            "timestamp[ns][pyarrow]": "datetime64[ns, UTC]",
            "bool": "boolean[pyarrow]",
        }
        return mapping.get(dtype_str, dtype_str)

    # --- 2. Schema Enforcement ---

    def apply_schema_map(self, schema_map: Dict[str, str]):
        """
        Enforces type correctness by casting the current DF to the target dtypes.
        """
        dtype_map = {
            col: dtype for col, dtype in schema_map.items() if col in self.df.columns
        }
        if not dtype_map:
            self.logger.warning(
                "Schema map contained no matching columns. Skipping type application."
            )
            warnings.warn(
                "Schema map contained no matching columns. Skipping type application."
            )
            return self

        self.logger.info(f"Applying strict schema to {len(dtype_map)} columns...")
        self.logger.debug(f"Schema map applied: {dtype_map}")

        self.df = self.df.astype(dtype_map)
        self.logger.info("Schema application complete.")
        return self

    def validate_schema(self, expected_schema_map: Dict[str, str]):
        """
        The primary validation method: checks if the current DF's dtypes match the expected map.
        Raises TypeError on mismatch.
        """
        self.logger.info("Validating current schema against expected standards...")
        errors = []
        for col, expected_dtype in expected_schema_map.items():
            if col in self.df.columns:
                current_dtype_raw = str(self.df.dtypes.get(col))

                # Use the normalizer for robust comparison
                current_dtype_normalized = self._normalize_dtype_alias(
                    current_dtype_raw
                )

                self.logger.debug(
                    f"Checking column '{col}': Current='{current_dtype_raw}' (Norm: '{current_dtype_normalized}'), Expected='{expected_dtype}'"
                )

                # Comparison uses the normalized type
                if current_dtype_normalized != expected_dtype:
                    errors.append(
                        f"❌ Col '{col}': Expected '{expected_dtype}', Found '{current_dtype_raw}' (Normalized: '{current_dtype_normalized}')"
                    )

        if errors:
            error_msg = (
                "Schema Validation FAILED. Discrepancy between DF and expected map:\n"
                + "\n".join(errors)
            )
            self.logger.error(error_msg)
            raise TypeError(error_msg)

        self.logger.info("✅ Schema Validation PASSED. Data structure is compliant.")
        return self

    def standardize_data_quality(self):
        """
        Applies non-type-changing fixes: column name standardization, string cleanup,
        and datetime normalization.
        """
        self.logger.info("Applying data quality standardization...")

        # 1. Column Name Standardization
        new_cols = (
            self.df.columns.str.strip()
            .str.lower()
            .str.replace(" ", "_", regex=False)
            .str.replace(r"[^a-z0-9_]", "", regex=True)
        )
        self.logger.debug(
            f"Renaming columns from {list(self.df.columns)} to {list(new_cols)}"
        )
        self.df.columns = new_cols

        # 2. String Cleanup (Trimming and Null Literal Replacement)
        string_cols = self.df.select_dtypes(
            include=["string[pyarrow]", "object", "category"]
        ).columns
        self.logger.debug(f"Applying string cleanup to columns: {list(string_cols)}")
        for col in string_cols:
            self.df[col] = (
                self.df[col]
                .astype(str)
                .str.strip()
                .replace({"nan": None, "None": None, "": None})
            )

        # 3. Datetime Normalization (Timezone removal for target DB compatibility)
        datetime_cols = self.df.select_dtypes(include=["datetime64"]).columns
        self.logger.debug(f"Normalizing datetime columns: {list(datetime_cols)}")
        for col in datetime_cols:
            # Enforces naive datetime, crucial for most database exports (ClickHouse, Parquet)
            self.df[col] = self.df[col].dt.tz_localize(None)

        self.logger.info("Data quality standardization complete.")
        return self

    # --- 3. METADATA EXPORT (Final Output) ---

    def generate_clickhouse_ddl(
        self, table_name: str, type_map: Dict[str, str] = DASK_TO_CLICKHOUSE_DTYPE
    ) -> str:
        """
        Generates a ClickHouse CREATE TABLE statement based on the VALIDATED Dask schema.
        """
        self.logger.info(f"Generating ClickHouse DDL for table '{table_name}'...")
        ddl_parts = []
        for col, dtype in self.df.dtypes.items():
            dtype_str = str(dtype)

            # Normalize dtype before lookup for robustness
            normalized_dtype = self._normalize_dtype_alias(dtype_str)
            ch_type = type_map.get(normalized_dtype)

            if normalized_dtype == "category":
                # Explicit optimization for LowCardinality
                ch_type = "LowCardinality(String)"
            elif ch_type is None:
                self.logger.warning(
                    f"No map found for Dask type {dtype_str} on column {col}. Defaulting to String."
                )
                warnings.warn(
                    f"No map found for Dask type {dtype_str} on column {col}. Defaulting to String."
                )
                ch_type = "String"

            self.logger.debug(f"Mapped {col} ({dtype_str}) -> {ch_type}")
            ddl_parts.append(f"    {col} {ch_type}")

        ddl = f"CREATE TABLE {table_name} (\n"
        ddl += ",\n".join(ddl_parts)
        ddl += "\n) ENGINE = MergeTree ORDER BY tuple()"  #

        self.logger.info("✅ DDL generation complete.")
        return ddl

    def get_df(self) -> pd.DataFrame | dd.DataFrame:
        """Returns the final, validated Dask or Pandas DataFrame."""
        return self.df
