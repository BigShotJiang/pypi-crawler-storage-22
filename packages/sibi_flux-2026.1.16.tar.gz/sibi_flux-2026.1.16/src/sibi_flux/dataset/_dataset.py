from __future__ import annotations

import asyncio
import inspect
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
)

import dask.dataframe as dd

from sibi_flux.core.managed_resource import ManagedResource
from sibi_flux.dataset.hybrid_loader import HybridDataLoader
from sibi_flux.dataset.protocols import DatasetReaderType

if TYPE_CHECKING:
    from sibi_flux.logger import Logger


class Dataset(ManagedResource):
    """
    Base class for Hybrid Datasets.
    Merges historical (Parquet) and live (Datacube) data.
    """

    # Declarative Configuration
    historical_reader: ClassVar[DatasetReaderType | None] = None
    live_reader: ClassVar[DatasetReaderType | None] = None
    date_field: ClassVar[str] = ""

    def __init__(
        self,
        start_date: str,
        end_date: str,
        logger: Logger | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(logger=logger, **kwargs)
        self.start_date = start_date
        self.end_date = end_date
        self.df: dd.DataFrame | None = None

        if not self.date_field:
            raise ValueError(f"{self.__class__.__name__} must define date_field.")
        if not self.historical_reader and not self.live_reader:
            raise ValueError(
                f"{self.__class__.__name__} must define at least one reader."
            )

    def load(self, *, source: str = "auto", **kwargs: Any) -> dd.DataFrame:
        """
        Synchronous wrapper for aload.
        Bridges sync call to async implementation safely.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # If already in a loop, we run in a separate thread to avoid nested asyncio.run
            from concurrent.futures import ThreadPoolExecutor

            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(
                    lambda: asyncio.run(self.aload(source=source, **kwargs))
                )
                return future.result()
        else:
            return asyncio.run(self.aload(source=source, **kwargs))

    async def aload(self, *, source: str = "auto", **kwargs: Any) -> dd.DataFrame:
        """
        Asynchronously loads data from configured sources.
        """
        self.logger.info(
            f"Loading {self.__class__.__name__} [{source}] "
            f"from {self.start_date} to {self.end_date}"
        )

        try:
            if source == "auto":
                if self.historical_reader and self.live_reader:
                    self.df = await self._load_hybrid(**kwargs)
                elif self.live_reader:
                    self.df = await self._load_live(**kwargs)
                elif self.historical_reader:
                    self.df = await self._load_historical(**kwargs)
            elif source == "live":
                self.df = await self._load_live(**kwargs)
            elif source == "historical":
                self.df = await self._load_historical(**kwargs)
            else:
                raise ValueError(f"Invalid source: {source}")

            # Hook for post-processing
            self.df = self._post_process(self.df)

            if self.df is not None:
                self.logger.debug(
                    f"{self.__class__.__name__} loaded. "
                    f"Columns: {list(self.df.columns)}"
                )
            return self.df  # type: ignore

        except Exception as e:
            self.logger.error(f"Failed to load {self.__class__.__name__}: {e}")
            raise

    async def _load_hybrid(self, **kwargs: Any) -> dd.DataFrame:
        loader = HybridDataLoader(
            start_date=self.start_date,
            end_date=self.end_date,
            historical_reader=self.historical_reader,  # type: ignore
            live_reader=self.live_reader,  # type: ignore
            date_field=self.date_field,
            logger=self.logger,
            debug=self.debug,
        )
        return await loader.aload(**kwargs)

    async def _load_live(self, **kwargs: Any) -> dd.DataFrame:
        if not self.live_reader:
            raise ValueError("No live_reader configured.")

        # Instantiate reader according to protocol
        reader = self.live_reader(logger=self.logger, debug=self.debug)

        filter_kwargs = kwargs.copy()
        if self.date_field and self.start_date and self.end_date:
            filter_kwargs[f"{self.date_field}__date__range"] = [
                self.start_date,
                self.end_date,
            ]

        return await reader.aload(**filter_kwargs)

    async def _load_historical(self, **kwargs: Any) -> dd.DataFrame:
        if not self.historical_reader:
            raise ValueError("No historical_reader configured.")

        # Historical readers usually follow standard initialization
        # We try to pass date range explicitly if supported
        reader_params = {"logger": self.logger, "debug": self.debug}
        
        # Inspection of __init__ is still a reasonable fallback if not fully standardized
        sig = inspect.signature(self.historical_reader.__init__)
        if "parquet_start_date" in sig.parameters:
            reader_params["parquet_start_date"] = self.start_date
            reader_params["parquet_end_date"] = self.end_date

        reader = self.historical_reader(**reader_params)
        return await reader.aload(**kwargs)

    def _post_process(self, df: dd.DataFrame) -> dd.DataFrame:
        """
        Override to apply custom post-processing.
        """
        return df
