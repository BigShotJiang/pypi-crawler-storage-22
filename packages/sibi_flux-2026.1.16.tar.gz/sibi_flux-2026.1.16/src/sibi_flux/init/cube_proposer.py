
import yaml
from pathlib import Path
import os
from typing import List, Dict, Any
from rich.console import Console
import typer
import sys

console = Console()

def propose_cubes(db_domain: str, app_name: str, force: bool = False) -> None:
    """
    Scans the global datacube registry for cubes matching 'db_domain'
    and adds them to the app's datacubes.yaml.
    
    Args:
        db_domain: The database domain / folder name to filter by (e.g., 'ibis_dev', 'istmo360n').
        app_name: The name of the target application.
        force: If True, overwrites existing configuration.
    """
    cwd = Path(os.getcwd())
    
    # 1. Validate App Directory
    app_dir = cwd / app_name
    if not app_dir.exists() or not app_dir.is_dir():
        console.print(f"[red]Error: Application directory '{app_name}' not found.[/red]")
        raise typer.Exit(code=1)
        
    datacubes_dir = app_dir / "datacubes"
    datacubes_dir.mkdir(parents=True, exist_ok=True) # Ensure exists
    
    registry_path = datacubes_dir / "datacubes.yaml"
    
    # 2. Locate Global Registry
    # Heuristic: dataobjects/globals/datacube_registry.yaml
    global_reg_path = cwd / "dataobjects/globals/datacube_registry.yaml"
    
    if not global_reg_path.exists():
         console.print(f"[red]Error: Global registry not found at {global_reg_path}[/red]")
         console.print("Run 'uv run sibi-flux dc sync' first to generate the registry.")
         raise typer.Exit(code=1)
         
    try:
        with open(global_reg_path, "r") as f:
            global_data = yaml.safe_load(f)
    except Exception as e:
        console.print(f"[red]Error parsing global registry: {e}[/red]")
        raise typer.Exit(code=1)
        
    if not global_data:
        console.print("[yellow]Global registry is empty.[/yellow]")
        return

    # 3. Find Matches
    matches = []
    
    # Registry Structure: {conf_obj: {table_name: {class_name: ..., path: ...}}}
    for conf_obj, tables in global_data.items():
        if not isinstance(tables, dict):
             continue
        for table_name, meta in tables.items():
            if not isinstance(meta, dict):
                console.print(f"[yellow]Warning: Skipping table '{table_name}' in {conf_obj} (meta is not a dictionary).[/yellow]")
                continue
                
            path_str = meta.get("path", "")
            class_name = meta.get("class_name")
            
            # Check if domain matches path logic
            # e.g. path="dataobjects/gencubes/istmo360n/..." and db_domain="istmo360n"
            if db_domain in path_str.split("/"):
                # Clean source path for python import
                # "dataobjects/gencubes/..." -> "dataobjects.gencubes...."
                # remove extension .py
                module_path = path_str.replace("/", ".").rstrip(".py")
                source_path = f"{module_path}.{class_name}"
                
                # Determine target module name (the last part of the path directory?)
                # e.g. .../biometric/biometric_cubes.py -> "biometric"
                try:
                    # heuristic: parent dir name or filename base?
                    # path: dataobjects/gencubes/istmo360n/biometric/biometric_cubes.py
                    # logical group: biometric
                    
                    p = Path(path_str)
                    module_group = p.parent.name # biometric
                    if module_group == db_domain:
                         # fallback if nested directly under domain
                         module_group = p.stem.replace("_cubes", "")
                         
                except Exception:
                    module_group = "common"
                
                matches.append({
                    "source": source_path,
                    "name": f"{app_name.capitalize()}{class_name}", # Default naming: App + Class
                    "module": module_group,
                    "original_class": class_name
                })
    
    if not matches:
        console.print(f"[yellow]No datacubes found for domain '{db_domain}' in registry.[/yellow]")
        return
        
    console.print(f"[green]Found {len(matches)} matching datacubes.[/green]")
    
    # 4. Update App Registry
    
    current_config = {"cubes": []}
    
    if registry_path.exists():
        try:
            with open(registry_path, "r") as f:
                loaded = yaml.safe_load(f)
                if loaded:
                     current_config = loaded
                     if "cubes" not in current_config or current_config["cubes"] is None:
                         current_config["cubes"] = []
    
        except Exception:
            pass

    if force:
        console.print(f"[yellow]Force active: Pruning existing entries for domain '{db_domain}'...[/yellow]")
        # Filter out entries where source contains the domain segment
        # Heuristic: source looks like 'some.path.domain.module.Class'
        # We check if f".{db_domain}." is present in source string, or startswith f"{db_domain}." (unlikely given full path)
        # Safer: split by dot and check presence?
        
        pruned_cubes = []
        for c in current_config["cubes"]:
            src = c.get("source", "")
            # Check if domain segment exists in source path
            parts = src.split(".")
            if db_domain not in parts:
                pruned_cubes.append(c)
        
        current_config["cubes"] = pruned_cubes
            
    # Deduplicate
    existing_sources = {c.get("source") for c in current_config["cubes"]}
    added_count = 0
    
    for m in matches:
        if m["source"] not in existing_sources:
            entry = {
                "source": m["source"],
                "name": m["name"],
                "module": m["module"]
            }
            current_config["cubes"].append(entry)
            existing_sources.add(m["source"])
            added_count += 1
            
    # Save
    with open(registry_path, "w") as f:
        yaml.dump(current_config, f, sort_keys=False)
        
    console.print(f"[bold green]Added {added_count} new entries to {registry_path}[/bold green]")
    console.print(f"Next: Run [blue]uv run sibi-flux create-cubes {app_name}[/blue] to generate code.")
