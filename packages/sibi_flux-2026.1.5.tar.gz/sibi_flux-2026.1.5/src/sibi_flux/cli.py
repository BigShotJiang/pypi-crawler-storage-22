import typer
from typing import Optional
from pathlib import Path
from rich.console import Console
from sibi_flux.init.core import initialize_project

app = typer.Typer(help="Sibi Flux CLI")
console = Console()


@app.callback()
def callback():
    """
    Sibi Flux CLI
    """


@app.command()
def init(
    project_name: str = typer.Argument(..., help="Name of the project to create"),
    lib: bool = typer.Option(
        False, "--lib", help="Initialize as a library project (passed to uv init)"
    ),
    app: bool = typer.Option(
        False, "--app", help="Initialize as an application project (passed to uv init)"
    ),
):
    """
    Initialize a new Sibi Flux project.

    Creates a new directory <project_name>, initializes it with 'uv',
    and adds 'sibi-flux' as a dependency.
    """
    initialize_project(project_name, lib, app)


@app.command()
def env(
    project_path: Path = typer.Argument(Path("."), help="Project root directory"),
    env_file: Optional[Path] = typer.Option(
        None, "--env-file", "-e", help="Path to environment file (defaults to .env)"
    ),
    cleanup: bool = typer.Option(
        False, "--cleanup", help="Remove existing configuration files"
    ),
    production: bool = typer.Option(
        False,
        "--production",
        "-p",
        help="Generate production skeleton (no hardcoded values)",
    ),
):
    """
    Initialize configuration files (settings.py, credentials) based on .env
    """
    from sibi_flux.init.env import init_env

    init_env(project_path, env_file, cleanup=cleanup, production_mode=production)


# Mount Datacube CLI
from sibi_flux.datacube.cli import app as dc_app

app.add_typer(dc_app, name="dc", help="Datacube generation and management commands")


if __name__ == "__main__":
    app()
