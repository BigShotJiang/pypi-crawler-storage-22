import datetime
from typing import Optional
import pandas as pd
import dask.dataframe as dd
from sibi_flux.logger import Logger

TODAY = datetime.date.today()
YESTERDAY = TODAY - datetime.timedelta(days=1)
TODAY_STR = TODAY.strftime("%Y-%m-%d")
YESTERDAY_STR = YESTERDAY.strftime("%Y-%m-%d")


class HybridDataLoader:
    """
    Hybrid loader that merges historical (Parquet) and live (API/DB) data
    in a consistent, schema-safe, timezone-normalized way.
    """

    def __init__(
        self,
        start_date: str,
        end_date: str,
        historical_reader,
        live_reader,
        date_field: str,
        **kwargs,
    ):
        self.start_date = self._validate_date_format(start_date)
        self.end_date = self._validate_date_format(end_date)
        self.historical_reader = historical_reader
        self.live_reader = live_reader
        self.date_field = date_field

        self.logger = kwargs.get("logger", Logger.default_logger(logger_name=__name__))
        self.debug = kwargs.get("debug", False)
        self.logger.set_level(Logger.DEBUG if self.debug else Logger.INFO)

        self._validate_date_range()

        self._read_live_flag = self.end_date == TODAY_STR
        self._is_single_today = self.start_date == self.end_date == TODAY_STR
        self._is_single_historical = self.start_date == self.end_date != TODAY_STR

    # ------------------------------------------------------------------ #
    # Validation
    # ------------------------------------------------------------------ #
    @staticmethod
    def _validate_date_format(date_str: str) -> str:
        try:
            datetime.datetime.strptime(date_str, "%Y-%m-%d")
            return date_str
        except ValueError:
            raise ValueError(f"Date '{date_str}' is not in valid YYYY-MM-DD format")

    def _validate_date_range(self):
        start = datetime.datetime.strptime(self.start_date, "%Y-%m-%d").date()
        end = datetime.datetime.strptime(self.end_date, "%Y-%m-%d").date()
        if end < start:
            raise ValueError(
                f"End date ({self.end_date}) cannot be before start date ({self.start_date})"
            )

    @staticmethod
    def _normalize_datetimes(df: dd.DataFrame, cols: list[str]) -> dd.DataFrame:
        """Normalize datetime columns to UTC safely."""
        if not cols:
            return df

        def _to_ts(pdf: pd.DataFrame) -> pd.DataFrame:
            for c in cols:
                if c in pdf.columns:
                    pdf[c] = pd.to_datetime(pdf[c], errors="coerce", utc=True)
            return pdf

        return df.map_partitions(_to_ts)

    @staticmethod
    def _create_empty_dataframe(meta: Optional[pd.DataFrame] = None) -> dd.DataFrame:
        if meta is not None and not meta.empty:
            return dd.from_pandas(meta.iloc[0:0], npartitions=1)
        return dd.from_pandas(pd.DataFrame(), npartitions=1)

    # ------------------------------------------------------------------ #
    # Data loading methods
    # ------------------------------------------------------------------ #
    async def _load_today_data(self, **kwargs) -> Optional[dd.DataFrame]:
        """Load today's live data."""
        self.logger.debug("Loading today's live data...")
        date_filter = {f"{self.date_field}__date": TODAY_STR}
        filters = {**kwargs, **date_filter}

        try:
            reader_obj = self.live_reader(logger=self.logger, debug=self.debug)
            if not hasattr(reader_obj, "aload"):
                raise TypeError("live_reader must expose an async aload() method")
            today_df = await reader_obj.aload(**filters)
            if today_df is not None:
                today_df = self._normalize_datetimes(today_df, [self.date_field])
            return today_df
        except Exception as e:
            self.logger.error(f"Failed to load today's data: {e}")
            return None if not self.debug else (_ for _ in ()).throw(e)

    async def _load_historical_data(
        self, start_date: str, end_date: str, **kwargs
    ) -> dd.DataFrame:
        """Load historical data."""
        self.logger.debug(f"Loading historical data from {start_date} to {end_date}...")
        try:
            reader_obj = self.historical_reader(
                parquet_start_date=start_date,
                parquet_end_date=end_date,
                logger=self.logger,
                debug=self.debug,
            )
            if not hasattr(reader_obj, "aload"):
                raise TypeError("historical_reader must expose an async aload() method")
            df = await reader_obj.aload(**kwargs)
            df = self._normalize_datetimes(df, [self.date_field])
            return df
        except Exception as e:
            self.logger.error(f"Failed to load historical data: {e}")
            if self.debug:
                raise
            return self._create_empty_dataframe()

    # ------------------------------------------------------------------ #
    # Orchestrator
    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    # Orchestrator
    # ------------------------------------------------------------------ #
    async def aload(self, **kwargs) -> dd.DataFrame:
        """Load and concatenate data from historical and live sources."""
        self.logger.debug(
            f"[HybridLoader] start={self.start_date}, end={self.end_date}, "
            f"read_live={self._read_live_flag}"
        )

        # Case 1: only today
        if self._is_single_today:
            today_df = await self._load_today_data(**kwargs)
            return today_df if today_df is not None else self._create_empty_dataframe()

        # Case 2: purely historical
        if not self._read_live_flag:
            return await self._load_historical_data(
                self.start_date, self.end_date, **kwargs
            )

        # Case 3: mixed historical + live
        hist_df = await self._load_historical_data(
            self.start_date, YESTERDAY_STR, **kwargs
        )
        live_df = await self._load_today_data(**kwargs)

        if hist_df is None:
            hist_df = self._create_empty_dataframe()
        if live_df is None:
            live_df = self._create_empty_dataframe()

        # Standardize / Validate both before concat if schema is enforced
        # (Assuming the caller might want to check schemas here)
        # For now, we rely on the readers returning relatively clean data,
        # but we can do a naive concat.

        # Note: Previous implementation did heavy schema alignment.
        # Dask concat handles most alignment if columns differ but dtypes are compatible.
        # If columns are completely missing, Dask might warn or error.

        try:
            return dd.concat(
                [hist_df, live_df],
                ignore_unknown_divisions=True,
                interleave_partitions=True,
            )
        except Exception as e:
            self.logger.warning(
                f"Simple concat failed: {e}. Attempting robust alignment..."
            )
            # Robust alignment fallback can be implemented here if strictly needed,
            # possibly offloaded to a thread.
            self.logger.error(
                "Robust alignment not yet reimplemented with DfValidator."
            )
            raise e

    # ------------------------------------------------------------------ #
    def __repr__(self):
        return (
            f"HybridDataLoader(start='{self.start_date}', end='{self.end_date}', "
            f"read_live={self._read_live_flag})"
        )
