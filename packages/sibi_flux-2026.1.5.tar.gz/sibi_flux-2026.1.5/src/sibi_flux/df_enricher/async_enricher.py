"""
Async Enricher module.

Provides asynchronous enrichment capabilities for DataFrames using Dask.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional, Sequence, Tuple

import pandas as pd
from sibi_flux.utils.dask_utils import sanitize_dask_df
import dask.dataframe as dd

from sibi_flux.core import ManagedResource
from .types import DdfLike
from .specs import AttachmentSpec
from .merger import DfMerger


class AsyncDfEnricher(ManagedResource):
    """
    Generic async DataFrame enricher driven by AttachmentSpec definitions.

    - Uses a base DataFrame (Pandas or Dask).
    - Chooses applicable AttachmentSpecs based on required_cols.
    - Extracts unique values per spec.col_to_kwarg.
    - Runs all attachment_fn calls concurrently.
    - Merges results using DfMerger.
    """

    MAX_UNIQUE_LIMIT = 500000

    def __init__(
        self,
        base_df: DdfLike,
        specs: Sequence[AttachmentSpec],
        max_unique: int = MAX_UNIQUE_LIMIT,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.specs = list(specs)
        self.max_unique = max_unique
        self.df: dd.DataFrame = (
            base_df
            if isinstance(base_df, dd.DataFrame)
            else dd.from_pandas(base_df, npartitions=1)
        )

        if self.df is not None:
            self.df = sanitize_dask_df(self.df)

    async def _get_unique_values(self, col_name: str) -> List[Any]:
        """
        Asynchronously retrieve unique values from a column with a safety limit.
        """

        def _fetch():
            series = self.df[col_name]
            if isinstance(series, pd.Series):
                # Pandemic Series in-memory
                uniques = series.dropna().unique()
            else:
                # Dask Series
                # Use head(limit) logic if we can, but unique() on dask is tricky to limit efficiently
                # without computing the whole thing or careful head-ing.
                # Safe approach: compute unique on dask, but if it's too huge, we risk OOM.
                # Better: use value_counts().head(limit) or similar?
                # For pure unique, we can try to compute, but we should verify size if possible.
                # Given dask limitations, we'll assume the user wants the list,
                # but we can try to safety check via head if we suspect it's huge?
                # Actually, let's stick to the plan: compute but check length after?
                # Or better: head(limit) on the unique series?
                uniques = series.dropna().unique().compute()

            if len(uniques) > self.max_unique:
                raise ValueError(
                    f"Column '{col_name}' has {len(uniques)} unique values, "
                    f"exceeding limit of {self.max_unique}. Enrichment aborted to prevent OOM."
                )
            return uniques.tolist()

        return await asyncio.to_thread(_fetch)

    async def _resolve_spec_kwargs(
        self, spec: AttachmentSpec
    ) -> Optional[Dict[str, Any]]:
        """
        Resolve kwargs for a single spec concurrently.
        """
        available_cols = self.df.columns
        if not spec.is_applicable(available_cols):
            return None

        kwargs_for_fn: Dict[str, Any] = {}

        # We need to fetch unique values for each mapped column
        # Ideally, we do this in parallel too?
        # For simplicity within a spec, we can just await one by one or gather them.
        # Let's gather them since a spec might depend on multiple keys.

        tasks = []
        col_names = []
        kw_names = []

        for col, kw in spec.col_to_kwarg.items():
            if col not in available_cols:
                continue
            col_names.append(col)
            kw_names.append(kw)
            tasks.append(self._get_unique_values(col))

        if not tasks:
            return None

        # Run all unique value extractions for this spec concurrent
        unique_lists = await asyncio.gather(*tasks)

        for kw, ulist in zip(kw_names, unique_lists):
            kwargs_for_fn[kw] = ulist

        return kwargs_for_fn

    async def _run_attachments(
        self,
        cols: Sequence[str],
    ) -> Tuple[Dict[str, Optional[DdfLike]], List[AttachmentSpec]]:

        # 1. Prepare specs that apply
        applicable_specs = [s for s in self.specs if s.is_applicable(self.df.columns)]
        if not applicable_specs:
            return {}, []

        # 2. Resolve kwargs for ALL specs in parallel
        # This prevents the sequential bottleneck of "calc unique -> next spec"
        resolve_tasks = [self._resolve_spec_kwargs(s) for s in applicable_specs]
        resolved_kwargs_list = await asyncio.gather(
            *resolve_tasks, return_exceptions=True
        )

        # 3. Launch attachment functions for successfully resolved kwargs
        attach_tasks: Dict[str, asyncio.Task] = {}
        valid_specs: List[AttachmentSpec] = []

        for spec, result in zip(applicable_specs, resolved_kwargs_list):
            if isinstance(result, Exception) or not isinstance(result, dict):
                self.logger.warning(f"Spec setup failed for {spec.key}: {result}")
                continue
            if not result:  # None or empty dict
                continue

            # Launch the actual enrichment (API call / DB fetch)
            # Mypy needs explicit cast or confirmation that result is a dict
            attach_tasks[spec.key] = asyncio.create_task(spec.attachment_fn(**result))
            valid_specs.append(spec)

        results: Dict[str, Optional[DdfLike]] = {}
        if attach_tasks:
            done = await asyncio.gather(*attach_tasks.values(), return_exceptions=True)
            for name, result in zip(attach_tasks.keys(), done):
                if isinstance(result, Exception):
                    self.logger.warning("Attachment %s failed: %s", name, result)
                    results[name] = None
                else:
                    results[name] = result

        return results, valid_specs

    async def enrich(
        self,
        cols: Sequence[str],
        *,
        normalize_persist: bool = False,
        persist_result: bool = False,
    ) -> dd.DataFrame:
        if not cols:
            raise ValueError("Pass at least one column to drive enrichment.")

        results, used_specs = await self._run_attachments(cols)
        if not used_specs:
            return self.df.persist() if persist_result else self.df

        merge_plan: List[Tuple[str, List[str], List[str], List[str]]] = [
            (spec.key, spec.left_on, spec.right_on, spec.drop_cols)
            for spec in used_specs
        ]

        merger = DfMerger(logger=self.logger, debug=self.debug)
        enriched = merger.apply_merges(
            base_df=self.df,
            results=results,
            merge_plan=merge_plan,
            normalize_persist=normalize_persist,
        )

        if persist_result:
            enriched = enriched.persist()

        self.df = enriched
        return enriched
