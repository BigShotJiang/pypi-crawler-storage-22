"""
DataFrame Merger module.

Handles merging of Dask and Pandas DataFrames with schema alignment.
"""

from __future__ import annotations

from collections.abc import Mapping, MutableMapping
from typing import Any, Iterable, Optional, Sequence, Tuple

import pandas as pd
import dask.dataframe as dd

from sibi_flux.core import ManagedResource

DdfLike = dd.DataFrame | pd.DataFrame


class DfMerger(ManagedResource):
    """
    Generic Dask/Pandas DataFrame merger with integrated join-key normalization.

    Responsibilities:
      - Normalize incoming objects to Dask DataFrames.
      - Normalize join-key dtypes (left/right) to 'string' when mismatched.
      - Apply a sequence of left merges according to a merge plan.

    Parameters (via **kwargs):
      - logger, debug: handled by ManagedResource.
      - dask_client: optional, kept for symmetry with other components.
    """

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.dask_client = kwargs.get("dask_client")
        # Track dtype normalization changes for logging/inspection
        self._dtype_changes: MutableMapping[str, MutableMapping[str, str]] = {}

    def _normalize_merge_dtypes(
        self,
        df: dd.DataFrame,
        results: Mapping[str, Optional[dd.DataFrame]],
        merge_plan: Iterable[Tuple[str, Sequence[str], Sequence[str], Sequence[str]]],
        persist: bool = False,
    ) -> Tuple[dd.DataFrame, dict[str, Optional[dd.DataFrame]]]:
        """
        Normalize join key dtypes using safe promotion rules:
          1. Numeric Mismatch (Int vs Float) -> Cast both to Float64.
          2. String/Object Mismatch -> Cast both to String.
          3. Mixed Numeric/String -> Cast both to String.
        """
        if not results:
            return df, results

        base_casts: MutableMapping[str, str] = {}
        # We might need to cast the right-side DFs too if we promote to a supertype
        # (e.g. Int vs Float -> Both Float). But Dask merge handles Right-side
        # promotion automatically better than Left-side demotion.
        # For simplicity/safety, we focus on aligning the BASE (Left) to be compatible.

        for key, left_on, right_on, _ in merge_plan:
            other = results.get(key)
            if other is None:
                continue

            for lcol, rcol in zip(left_on, right_on):
                if lcol in df.columns and rcol in other.columns:
                    l_dtype = df._meta[lcol].dtype
                    r_dtype = other._meta[rcol].dtype

                    if l_dtype == r_dtype:
                        continue

                    # Mismatch Detected - Decide on Target Type
                    target_type = None

                    is_l_num = pd.api.types.is_numeric_dtype(l_dtype)
                    is_r_num = pd.api.types.is_numeric_dtype(r_dtype)

                    if is_l_num and is_r_num:
                        # Both numeric (e.g. Int vs Float) -> Promote to Float
                        target_type = "float64"
                    else:
                        # At least one is non-numeric -> Fallback to String
                        target_type = "string"

                    # If Left needs casting
                    if str(l_dtype) != target_type:
                        base_casts[lcol] = target_type
                        if self.logger:
                            self.logger.debug(
                                f"Merge Type Fix: '{lcol}' ({l_dtype}) vs '{rcol}' ({r_dtype}) -> Casting '{lcol}' to {target_type}"
                            )

        # Apply casts to Base DataFrame
        if base_casts:
            self._dtype_changes.clear()
            for col, dtype in base_casts.items():
                self._dtype_changes[col] = {str(df._meta[col].dtype): dtype}

            df = df.astype(base_casts)

        if persist:
            df = df.persist()
            results = {
                k: v.persist() if isinstance(v, dd.DataFrame) else v
                for k, v in results.items()
            }

        return df, results

    def log_normalization_changes(self) -> None:
        """Log dtype alignment actions."""
        if not self.logger or not self._dtype_changes:
            return

        for col, mapping in self._dtype_changes.items():
            for src, tgt in mapping.items():
                self.logger.info(
                    f"Merge Normalization: Cast Base Column '{col}' from {src} to {tgt}"
                )

    # ------------------------------------------------------------------
    # Generic Dask/Pandas helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_ddf(obj: Any) -> Optional[dd.DataFrame]:
        """Normalize arbitrary objects into a Dask DataFrame or None."""
        if obj is None:
            return None
        if isinstance(obj, dd.DataFrame):
            return obj
        if isinstance(obj, pd.DataFrame):
            return dd.from_pandas(obj, npartitions=1)
        if isinstance(obj, dict):
            return dd.from_pandas(pd.DataFrame([obj]), npartitions=1)
        if isinstance(obj, list) and obj and all(isinstance(r, dict) for r in obj):
            return dd.from_pandas(pd.DataFrame(obj), npartitions=1)
        raise TypeError(f"Unexpected type for merge: {type(obj)}")

    @staticmethod
    def _drop_cols(df: dd.DataFrame, cols_to_drop: Sequence[str]) -> dd.DataFrame:
        """Drop columns that actually exist in the frame."""
        to_drop = [c for c in cols_to_drop if c in df.columns]
        return df.drop(columns=to_drop) if to_drop else df

    # ------------------------------------------------------------------
    # Single merge (assumes dtypes already normalized)
    # ------------------------------------------------------------------

    def _merge_left(
        self,
        left: dd.DataFrame,
        right_like: Optional[dd.DataFrame],
        *,
        left_on: Sequence[str],
        right_on: Sequence[str],
    ) -> dd.DataFrame:
        """
        Perform a left merge between `left` and `right_like` on the given keys.
        Assumes join-key dtypes have already been normalized.
        """
        if right_like is None:
            return left

        right = right_like
        return left.merge(
            right,
            how="left",
            left_on=list(left_on),
            right_on=list(right_on),
        )

    # ------------------------------------------------------------------
    # Merge driver
    # ------------------------------------------------------------------

    def apply_merges(
        self,
        base_df: DdfLike,
        results: Mapping[str, Optional[DdfLike]],
        merge_plan: Iterable[Tuple[str, Sequence[str], Sequence[str], Sequence[str]]],
        *,
        normalize_persist: bool = False,
    ) -> dd.DataFrame:
        """
        Apply a sequence of left merges defined by `merge_plan`.

        Parameters
        ----------
        base_df:
            Base DataFrame (Pandas or Dask) to be enriched.
        results:
            Mapping from merge key to auxiliary frame (or None).
        merge_plan:
            Iterable of tuples:
                (key, left_on, right_on, drop_cols)
        normalize_persist:
            If True, persist base and auxiliary frames after dtype normalization.

        Returns
        -------
        dd.DataFrame
            Enriched Dask DataFrame.
        """
        # Ensure we work with Dask for the base
        df = (
            base_df
            if isinstance(base_df, dd.DataFrame)
            else dd.from_pandas(base_df, npartitions=1)
        )

        # Ensure all auxiliary results are dd.DataFrame or None
        dd_results: MutableMapping[str, Optional[dd.DataFrame]] = {}
        for key, val in results.items():
            dd_results[key] = self._to_ddf(val) if val is not None else None

        # Normalize join-key dtypes across base and related frames
        df, norm_results = self._normalize_merge_dtypes(
            df, dd_results, merge_plan, persist=normalize_persist
        )
        self.log_normalization_changes()

        # Apply merges
        out = df
        for i, (key, left_on, right_on, drop_cols) in enumerate(merge_plan):
            other = norm_results.get(key)
            if other is None:
                continue
            out = self._merge_left(out, other, left_on=left_on, right_on=right_on)
            out = self._drop_cols(out, drop_cols)

            # Resilience: Break graph lineage after multiple joins
            # Prevents "scheduler overload" on deep chains
            if i > 0 and i % 3 == 0:
                if self.logger:
                    self.logger.info(
                        f"Refactoring merge graph at step {i} (Repartition + Persist)"
                    )
                try:
                    # Consolidate small partitions
                    out = out.repartition(partition_size="100MB")
                    if normalize_persist:
                        out = out.persist()
                except Exception as e:
                    if self.logger:
                        self.logger.warning(
                            f"Failed to repartition merge intermediate: {e}"
                        )

        return out
