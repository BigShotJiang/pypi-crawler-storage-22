import yaml
from pathlib import Path
from typing import List, Dict, Any
from sibi_flux.init.env_engine import EnvFile, EnvSection
from rich.console import Console

console = Console()


class DiscoveryParamsUpdater:
    """
    Updates generators/datacubes/discovery_params.yaml to include
    database connections found in the generated env configuration.
    """

    @staticmethod
    def _is_database(section: EnvSection) -> bool:
        return section.type.upper() in [
            "POSTGRES",
            "MYSQL",
            "CLICKHOUSE",
            "SQLALCHEMY_DATABASE",
        ]

    @staticmethod
    def _is_filesystem(section: EnvSection) -> bool:
        return section.type.upper() in ["S3", "MINIO", "FILESYSTEM"]

    @staticmethod
    def update(project_path: Path, env_data: EnvFile) -> None:
        params_path = (
            project_path / "generators" / "datacubes" / "discovery_params.yaml"
        )
        if not params_path.exists():
            console.print(
                f"[yellow]Warning: {params_path} not found. Skipping discovery params update.[/yellow]"
            )
            return

        try:
            # 1. Read existing YAML
            with open(params_path, "r") as f:
                data = yaml.safe_load(f) or {}

            # 2. Extract DBs from Env
            db_sections = [
                s for s in env_data.sections if DiscoveryParamsUpdater._is_database(s)
            ]

            if not db_sections:
                if "databases" in data:
                    del data["databases"]
                    with open(params_path, "w") as f:
                        yaml.dump(data, f, sort_keys=False, default_flow_style=False)
                    console.print(
                        f"[yellow]Removed databases section from discovery_params.yaml (no databases found in env).[/yellow]"
                    )
                return

            # Ensure databases list exists
            if "databases" not in data:
                data["databases"] = []

            # Map existing entries by ID to avoid duplicates (upsert behavior)
            existing_dbs = {db.get("id"): db for db in data["databases"]}

            changes_made = False

            for section in db_sections:
                db_id = section.name.lower()

                # Check exclusion? No, default to include all.

                # Generate entry
                conf_name = f"{section.name.lower()}_conf"

                # Extract DB Name for db_domain
                db_domain = db_id  # Fallback
                for var in section.vars:
                    # Check for common DB name keys.
                    # Note: Keys in EnvSection are fully qualified (e.g. REPLICA_DATABASE)
                    # We check if the suffix matches DATABASE
                    if var.key.endswith("_DATABASE") or var.key == "DATABASE":
                        db_domain = var.value
                        break

                new_entry = {
                    "id": db_id,
                    "connection_ref": conf_name,
                    "db_domain": db_domain,
                    "import_spec": {"module": "conf.credentials", "symbol": conf_name},
                }

                # Upsert
                if db_id in existing_dbs:
                    # Update existing? Only if significantly different?
                    # For now, let's update strict fields but preserve extra if any.
                    # Or simpler: Overwrite specific keys.
                    existing_dbs[db_id].update(new_entry)
                else:
                    data["databases"].append(new_entry)
                    changes_made = True

            # 3. Extract Filesystems (S3) from Env
            fs_sections = [
                s for s in env_data.sections if DiscoveryParamsUpdater._is_filesystem(s)
            ]

            # Update filesystems if present
            if fs_sections:
                if "filesystems" not in data:
                    data["filesystems"] = []

                existing_fs = {fs.get("id"): fs for fs in data["filesystems"]}

                for section in fs_sections:
                    fs_id = section.name.lower()
                    conf_name = f"{section.name.lower()}_conf"

                    # Extract path/bucket
                    fs_path = ""
                    for var in section.vars:
                        if var.key.endswith("_FS_PATH") or var.key == "FS_PATH":
                            fs_path = var.value
                            break

                    new_entry = {
                        "id": fs_id,
                        "connection_ref": conf_name,
                        "path": fs_path,
                        "import_spec": {
                            "module": "conf.credentials",
                            "symbol": conf_name,
                        },
                    }

                    if fs_id in existing_fs:
                        existing_fs[fs_id].update(new_entry)
                    else:
                        data["filesystems"].append(new_entry)
                        changes_made = True

            # 4. Write back
            # Use sort_keys=False to preserve order roughly
            with open(params_path, "w") as f:
                yaml.dump(data, f, sort_keys=False, default_flow_style=False)

            console.print(
                f"[green]Updated discovery_params.yaml with {len(db_sections)} databases and {len(fs_sections)} filesystems.[/green]"
            )

        except Exception as e:
            console.print(f"[red]Failed to update discovery_params.yaml: {e}[/red]")
