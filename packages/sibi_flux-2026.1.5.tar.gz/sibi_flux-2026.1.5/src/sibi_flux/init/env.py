from pathlib import Path
from rich.console import Console
from typing import Optional

from sibi_flux.init.env_engine import EnvParser
from sibi_flux.init.env_generator import EnvGenerator

console = Console()


def init_env(
    project_path: Path,
    env_file: Optional[Path] = None,
    cleanup: bool = False,
    production_mode: bool = False,
):
    """
    Initializes configuration files for the project.
    Parses .env file (or defaults) and dynamically generates settings.py and credentials.
    If cleanup is True, removes generated configuration files.
    If production_mode is True, generates a 'skeleton' settings.py without hardcoded values.
    """
    conf_dir = project_path / "conf"

    if cleanup:
        settings_path = conf_dir / "settings.py"
        creds_path = conf_dir / "credentials" / "__init__.py"

        removed = []
        if settings_path.exists():
            settings_path.unlink()
            removed.append("conf/settings.py")

        if creds_path.exists():
            creds_path.unlink()
            removed.append("conf/credentials/__init__.py")

        if removed:
            console.print(f"[green]Removed: {', '.join(removed)}[/green]")
        else:
            console.print("[yellow]No configuration files found to remove.[/yellow]")
        return

    # Parse Environment
    if env_file:
        if not env_file.exists():
            console.print(
                f"[red]Error: Environment file {env_file} does not exist.[/red]"
            )
            return

        content = env_file.read_text().strip()
        if not content or all(
            line.strip().startswith("#")
            for line in content.splitlines()
            if line.strip()
        ):
            console.print(
                f"[yellow]Environment file {env_file} is empty or contains only comments. No action taken.[/yellow]"
            )
            return

        env_data = EnvParser.parse(content)
        env_filename = env_file.name
    else:
        # Implicit default: try to find .env, but if not found or empty, maybe generate skeleton?
        # User request implies: "if an .env file is empty, message that nothing will be done"
        # But if NO file passed, we assume .env in project root.

        default_env = project_path / ".env"
        if not default_env.exists():
            console.print(
                f"[yellow]No .env file found at {default_env}. Skipping generation.[/yellow]"
            )
            return

        content = default_env.read_text().strip()
        if not content or all(
            line.strip().startswith("#")
            for line in content.splitlines()
            if line.strip()
        ):
            console.print(
                f"[yellow]Environment file .env is empty or contains only comments. No action taken.[/yellow]"
            )
            return

        env_data = EnvParser.parse(content)
        env_filename = ".env"

    conf_dir.mkdir(exist_ok=True)

    # 1. settings.py
    settings_code = EnvGenerator.generate_pydantic_code(
        env_data, env_file_name=env_filename, production_mode=production_mode
    )
    (conf_dir / "settings.py").write_text(settings_code)
    console.print(
        f"[green]Created conf/settings.py (parsed {len(env_data.sections)} sections)[/green]"
    )

    # 2. credentials/__init__.py
    creds_dir = conf_dir / "credentials"
    creds_dir.mkdir(exist_ok=True)

    creds_code = EnvGenerator.generate_credentials_code(env_data)
    (creds_dir / "__init__.py").write_text(creds_code)
    console.print(f"[green]Created conf/credentials/__init__.py[/green]")

    # 3. Update discovery_params.yaml
    from sibi_flux.init.discovery_updater import DiscoveryParamsUpdater

    DiscoveryParamsUpdater.update(project_path, env_data)
