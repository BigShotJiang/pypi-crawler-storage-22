from typing import Dict, Any, Optional
import re
from sibi_flux.init.env_engine import EnvFile, EnvSection, EnvVar


class EnvGenerator:
    """
    Generates EnvSection objects from high-level configurations (Templates).
    """

    MAPPING = {
        "S3": "FsSettings",
        "POSTGRES": "DatabaseSettings",
        "MYSQL": "DatabaseSettings",
        "SQLALCHEMY_DATABASE": "DatabaseSettings",
        "CLICKHOUSE": "DatabaseSettings",
        "REDIS": "RedisBaseSettings",
        "DB_POOL": "DbPoolSettings",
        "AIRFLOW": "SibiBaseSettings",
        "OSMNX": "SibiBaseSettings",
        "SENTINEL": "SibiBaseSettings",
        "OPENOBSERVE": "SibiBaseSettings",
        "MCP": "SibiBaseSettings",
        "DASK": "SibiBaseSettings",
        "GENERIC": "SibiBaseSettings",
    }

    @staticmethod
    def _make_key(section_name: str, suffix: str) -> str:
        return f"{section_name.upper()}_{suffix.upper()}"

    @staticmethod
    def _compose_uri(section_type: str, config: Dict[str, Any]) -> Optional[str]:
        # Handle different types for URI composition
        if section_type in ["POSTGRES", "CLICKHOUSE", "MYSQL", "SQLALCHEMY_DATABASE"]:
            # postgresql://user:pass@host:port/db
            user = config.get("USER", "")
            password = config.get("PASSWORD", "")
            host = config.get("HOST", "localhost")
            port = config.get("PORT", "5432")
            db = config.get("DATABASE", "")
            dialect = config.get("DIALECT", "").lower()

            scheme = "postgresql"
            if section_type == "CLICKHOUSE":
                scheme = "clickhouse+native"
            elif section_type == "MYSQL":
                scheme = "mysql+pymysql"
                if port == "5432":
                    port = "3306"
            elif section_type == "SQLALCHEMY_DATABASE":
                if dialect == "mysql":
                    scheme = "mysql+pymysql"
                elif dialect == "clickhouse":
                    scheme = "clickhouse+native"
                elif dialect == "postgres":
                    scheme = "postgresql"
                else:
                    scheme = dialect or "postgresql"  # Fallback

            auth_part = f"{user}"
            if password:
                auth_part += f":{password}"

            return f"{scheme}://{auth_part}@{host}:{port}/{db}"

        elif section_type == "REDIS":
            # redis://host:port/db_index
            host = config.get("HOST", "localhost")
            port = config.get("PORT", "6379")
            db_index = config.get("DB_INDEX", "0")
            return f"redis://{host}:{port}/{db_index}"

        return None

    @staticmethod
    def generate_from_template(
        section_name: str,
        section_type: str,
        config: Dict[str, Any],
        resource_id: Optional[str] = None,
    ) -> EnvSection:
        """
        section_type: S3, POSTGRES, CLICKHOUSE, REDIS, MYSQL, GENERIC
        config: Dict of raw values (e.g. {'HOST': 'localhost', ...})
        """
        vars_list = []

        # 1. Generate base variables and preserve individual fields
        # Filter out legacy flags so they don't leak into the env file

        normalized_config = {
            k.upper(): v
            for k, v in config.items()
            if k.upper() not in ["URL_AUTO_GENERATED", "URI_AUTO_GENERATED"]
        }

        # Common fields for different types
        if section_type == "S3":
            # Map valid S3 fields to FS_*
            # We look for normalized keys in config (fs_key -> FS_KEY, access_key -> FS_KEY fallback)

            # Helper to find value from multiple keys
            def get_val(keys):
                for k in keys:
                    if k in normalized_config:
                        return normalized_config[k]
                return None

            # Standard FS keys
            vars_list.append(
                EnvVar(key=EnvGenerator._make_key(section_name, "FS_TYPE"), value="s3")
            )

            val = get_val(["FS_PATH", "PATH", "BUCKET"])
            if val:
                vars_list.append(
                    EnvVar(
                        key=EnvGenerator._make_key(section_name, "FS_PATH"),
                        value=str(val),
                    )
                )

            val = get_val(["FS_KEY", "ACCESS_KEY", "AWS_ACCESS_KEY_ID"])
            if val:
                vars_list.append(
                    EnvVar(
                        key=EnvGenerator._make_key(section_name, "FS_KEY"),
                        value=str(val),
                    )
                )

            val = get_val(["FS_SECRET", "SECRET_KEY", "AWS_SECRET_ACCESS_KEY"])
            if val:
                vars_list.append(
                    EnvVar(
                        key=EnvGenerator._make_key(section_name, "FS_SECRET"),
                        value=str(val),
                    )
                )

            val = get_val(["FS_ENDPOINT", "ENDPOINT_URL", "ENDPOINT", "S3_ENDPOINT"])
            if val:
                vars_list.append(
                    EnvVar(
                        key=EnvGenerator._make_key(section_name, "FS_ENDPOINT"),
                        value=str(val),
                    )
                )

            val = get_val(["FS_TOKEN"])
            if val:
                vars_list.append(
                    EnvVar(
                        key=EnvGenerator._make_key(section_name, "FS_TOKEN"),
                        value=str(val),
                    )
                )

        elif section_type in ["POSTGRES", "CLICKHOUSE", "MYSQL", "SQLALCHEMY_DATABASE"]:
            allowed_fields = ["HOST", "PORT", "USER", "PASSWORD", "DATABASE"]
            if section_type == "SQLALCHEMY_DATABASE":
                allowed_fields.append("DIALECT")

            # Always include structural fields for DBs
            for field in allowed_fields:
                if field in normalized_config:
                    vars_list.append(
                        EnvVar(
                            key=EnvGenerator._make_key(section_name, field),
                            value=str(normalized_config[field]),
                        )
                    )
        elif section_type == "REDIS":
            allowed_fields = ["HOST", "PORT", "DB_INDEX"]
            for field in allowed_fields:
                if field in normalized_config:
                    vars_list.append(
                        EnvVar(
                            key=EnvGenerator._make_key(section_name, field),
                            value=str(normalized_config[field]),
                        )
                    )

        # Handle Generic or extra fields not in allowed_list but present in config
        # For Typed Sections, we typically stick to the allowed list to avoid polluting the env with random UI state
        # But for GENERIC or Service Types (Airflow, etc), we want ALL fields.
        if section_type not in ["S3", "POSTGRES", "CLICKHOUSE", "MYSQL", "REDIS"]:
            for k, v in normalized_config.items():
                final_key = EnvGenerator._make_key(section_name, k)
                # Avoid duplicates
                if not any(x.key == final_key for x in vars_list):
                    vars_list.append(EnvVar(key=final_key, value=str(v)))

        # 2. URI Auto-generation
        # Always generate URI if supported
        uri = EnvGenerator._compose_uri(section_type, normalized_config)
        if uri and section_type != "S3":
            suffix = "URL"
            # Use DB_URL for Database types to match DatabaseSettings schema
            if section_type in ["POSTGRES", "MYSQL", "SQLALCHEMY_DATABASE"]:
                suffix = "DB_URL"

            vars_list.append(
                EnvVar(
                    key=EnvGenerator._make_key(section_name, suffix),
                    value=uri,
                    comment="Auto-generated connection string",
                )
            )

        return EnvSection(
            name=section_name,
            type=section_type,
            vars=vars_list,
            resource_id=resource_id,
        )

    @staticmethod
    def _parse_connection_string(scheme: str, url_str: str) -> Dict[str, Any]:
        """
        Reverse-engineer URL components into settings dict.
        """
        from urllib.parse import urlparse, unquote

        # Helper to clean schemes like mysql+pymysql://
        # urlparse handles most, but let's be safe.
        if "://" not in url_str:
            return {}

        try:
            parsed = urlparse(url_str)
        except Exception:
            return {}

        params = {}
        if parsed.hostname:
            params["HOST"] = parsed.hostname
        if parsed.port:
            params["PORT"] = parsed.port
        else:
            # Infer default ports for known schemes if not explicit
            scheme_map = {
                "clickhouse": 8123,
                "mysql": 3306,
                "redis": 6379,
                "postgresql": 5432,
            }
            base_scheme = parsed.scheme.split("+")[0]
            if base_scheme in scheme_map:
                params["PORT"] = scheme_map[base_scheme]
        if parsed.username:
            params["USER"] = parsed.username
        if parsed.password:
            params["PASSWORD"] = unquote(parsed.password)
        if parsed.path:
            params["DATABASE"] = parsed.path.lstrip("/")

        # Dialect inference
        main_scheme = parsed.scheme.split("+")[0]
        if main_scheme == "mysql":
            params["DIALECT"] = "mysql"
        elif main_scheme == "postgresql":
            params["DIALECT"] = "postgres"
        elif main_scheme == "clickhouse":
            params["DIALECT"] = "clickhouse"

        return params

    @staticmethod
    def generate_pydantic_code(
        env_file: EnvFile,
        env_file_name: Optional[str] = None,
        production_mode: bool = False,
    ) -> str:
        """
        Generates Python code compatible with sibi_flux.conf.settings
        """
        lines = [
            "from typing import Optional, ClassVar",
            "from pydantic import SecretStr, Field, computed_field, model_validator",
            "from typing_extensions import Self",
            "from pydantic_settings import SettingsConfigDict",
            "",
            "# Import Generic Settings from Core",
            "from sibi_flux.config.settings import (",
            "    SibiBaseSettings, FsSettings, WebDavSettings,",
            "    DatabaseSettings, RedisBaseSettings, DbPoolSettings",
            ")",
            "",
            "# --- Generated Settings ---",
            "",
        ]

        def to_class_name(name):
            return "".join(part.capitalize() for part in name.split("_")) + "Settings"

        # Explicitly supported structural types that usually don"t need field generation
        # because the Base Class handles them.
        STRUCTURAL_TYPES = [
            "S3",
            "POSTGRES",
            "MYSQL",
            "CLICKHOUSE",
            "REDIS",
            "DB_POOL",
            "SQLALCHEMY_DATABASE",
        ]

        for section in env_file.sections:
            base_class = EnvGenerator.MAPPING.get(
                section.type.upper(), "SibiBaseSettings"
            )
            class_name = to_class_name(section.name)

            # 0. Enrichment: Reverse Engineer DB URLs
            if section.type.upper() in [
                "POSTGRES",
                "MYSQL",
                "CLICKHOUSE",
                "SQLALCHEMY_DATABASE",
                "REDIS",
            ]:
                # Find URL var
                prefix = f"{section.name.upper()}_"
                url_var = None
                for v in section.vars:
                    if (
                        v.key == f"{prefix}URL"
                        or v.key == f"{prefix}DB_URL"
                        or v.key == "DATABASE_URL"
                    ):
                        url_var = v
                        break

                if url_var:
                    # Parse and populate missing fields
                    parsed = EnvGenerator._parse_connection_string(
                        section.type.lower(), url_var.value
                    )
                    for k, val in parsed.items():
                        full_key = EnvGenerator._make_key(section.name, k)
                        # Only add if not exists (Inferred from URL)
                        if not any(v.key == full_key for v in section.vars):
                            section.vars.append(
                                EnvVar(
                                    key=full_key,
                                    value=str(val),
                                    comment="Inferred from URL",
                                )
                            )

                            # CRITICAL FIX: Add to processed_vars/field_value_map if we are about to generate fields
                            # But wait, structural types usually skip field generation and rely on Base Class defaults.
                            # The Issue: Base Class has defaults (localhost), but Pydantic might require them if overridden or logic differs?
                            # Actually, DatabaseSettings has defaults. Why did it fail?
                            # "Field required [type=missing]" means they are NOT optional and have NO default?
                            # Let's check DatabaseSettings definition in settings.py.
                            # It says: host: str = "localhost" etc.
                            # Ah, but the Generated Class (ReplicaSettings) might be inheriting/overriding?
                            # No, it inherits DatabaseSettings.

                            # Wait, the traceback says: "Field required ... input_value={'db_url': ...}"
                            # It seems Pydantic is validating `ReplicaSettings` and finding missing fields.
                            # If `ReplicaSettings` is empty `class ReplicaSettings(DatabaseSettings): pass`, it should use defaults.
                            # UNLESS: The presence of `db_url` in input triggers some validation group?
                            # OR: `DatabaseSettings` in `src/sibi_flux/config/settings.py` actually has NO defaults for those fields?
                            # I previously saw it had defaults.
                            # Let's re-verify `DatabaseSettings`.
                            pass

            lines.append(f"class {class_name}({base_class}):")

            # Calculate conf_name (used in credentials.py)
            conf_name = f"{section.name.lower()}_conf"
            # Special logic for some types if needed?
            # Credentials generator has specialized mapping for derived configs but the Base Config usually follows simple naming.
            # However, for Clickhouse, credentials usually exposes `clickhouse_config` which is derived from `ClickhouseSettings`.
            # But the Settings Class itself is `ClickhouseSettings`.
            # If the user wants the `conf_name` that this settings object maps to in credentials:

            # The standard mapping in credentials.py is:
            # if name == "{conf_name}": return to_dict({class_name}())

            # So for the Base Class instance, it maps to `to_conf_name(section.name)`.
            lines.append(f'    conf_name: ClassVar[str] = "{conf_name}"')

            # For Generic / Service types, we generate fields explicitly
            # We assume the vars are prefixed with SECTION_NAME_
            prefix = f"{section.name.upper()}_"

            # If it's a known structural type, we trust the base class unless we find extra fields?
            # For DatabaseSettings extended behavior (reverse engineered defaults), we MUST generate fields if present in env vars
            # even if they match base class names (because we want to set the "default" = inferred value).

            # Identify fields to process
            processed_vars = []
            field_value_map = {}
            for var in section.vars:
                if var.key.startswith(prefix):
                    field_name = var.key[len(prefix) :].lower()
                    field_value_map[field_name] = var.value
                    processed_vars.append((field_name, var))

            if section.type.upper() not in STRUCTURAL_TYPES or (
                section.type.upper()
                in ["POSTGRES", "MYSQL", "CLICKHOUSE", "SQLALCHEMY_DATABASE", "REDIS"]
                and processed_vars
            ):
                # We process fields if not structural OR if structural but we have Vars (which might be inferred)
                # Note: If structural, we might only want to generate fields that are known overrides?
                # Actually, simple logic: If we have specific vars for this section, we generate them as fields on the subclass.
                # This overrides base class defaults.

                # Accumulate computed fields to write after normal fields
                computed_fields = []

                # ... processed_vars already computed above ...

                # Second pass: generate code
                for field_name, var in processed_vars:
                    val = var.value

                    # Check for interpolation needs (contains ${...})
                    # But exclude the case where the WHOLE string is a secret ref (handled by SecretStr logic)
                    is_pure_ref = val.startswith("${") and val.endswith("}")

                    if not is_pure_ref and "${" in val:
                        # Generating a computed field for interpolation
                        # Try to resolve placeholders to other fields in this section

                        # Regex to find ${...}
                        placeholders = re.findall(r"\$\{([^}]+)\}", val)

                        f_string_parts = val
                        valid_interpolation = True

                        for p in placeholders:
                            # p is the secret name e.g. MY_SECRET
                            # Find which field has this value
                            # matching_field = next((k for k, v in field_value_map.items() if v == f"${{{p}}}" ), None)

                            # Correction: config values might be exactly "${p}"
                            search_val = f"${{{p}}}"
                            matching_field = None
                            for f_key, f_val in field_value_map.items():
                                if f_val == search_val:
                                    matching_field = f_key
                                    break

                            if matching_field:
                                # Replace ${p} with {self.matching_field.get_secret_value()}
                                # We assume matching_field is SecretStr if it was linked.
                                # Safe bet for linked fields.
                                f_string_parts = f_string_parts.replace(
                                    search_val,
                                    f"{{self.{matching_field}.get_secret_value()}}",
                                )
                            else:
                                # Could not resolve placeholder to a local field.
                                # It might be a global secret or unknown.
                                # We can't interpolate safely using 'self'.
                                # Fallback to raw string? Or leave as broken?
                                # Let's leave it as broken (static string) so user sees the issue,
                                # OR valid_interpolation = False
                                valid_interpolation = False

                        if valid_interpolation:
                            # Generate computed field
                            computed_fields.append((field_name, f_string_parts))
                            continue  # Skip generating normal field

                    # Normal Field Generation (same as before)
                    py_type = "str"
                    val_repr = f'"{val}"'

                    low_key = field_name.lower()
                    low_val = val.lower()

                    if val.startswith("${") and val.endswith("}"):
                        py_type = "SecretStr"
                        val_repr = f'Field(alias="{var.key}")'
                    elif (
                        "secret" in low_key
                        or "password" in low_key
                        or "key" in low_key
                        or "token" in low_key
                    ):
                        py_type = "SecretStr"
                        val_repr = f'SecretStr("{val}")'
                    elif low_val in ["true", "false"]:
                        py_type = "bool"
                        val_repr = "True" if low_val == "true" else "False"
                    elif val.isdigit():
                        py_type = "int"
                        val_repr = val

                    # Production Mode Logic
                    if production_mode:
                        # Check strictly for secrets or just strip everything to force environment config?
                        # Requirements imply: "handle secrets to protect passwords".
                        # But typically production headers shouldn't have ANY hardcoded values.
                        # So we strip everything to just type annotations.

                        # EXCEPTION: If the value was inferred from URL, we should probably keep it as default
                        # OR rely on the fact that if it's not in env, we fail.
                        # But Pydantic Settings reads env vars. If we stripped the default, and the env var isn't there (because it came from URL), it fails.
                        # Since we generate these fields BECAUSE they are inferred, we should output them with defaults if they are not secrets.

                        is_inferred = var.comment == "Inferred from URL"

                        if is_inferred:
                            # Keep default for inferred structural fields (including secrets) to avoid validation error
                            lines.append(f"    {field_name}: {py_type} = {val_repr}")
                        elif py_type == "SecretStr":
                            # Required Secret Field
                            lines.append(f"    {field_name}: SecretStr")
                        else:
                            # Optional non-secret? OR also required?
                            # Let's make strict production enforcement: everything is required unless Optional.
                            # But here we inferred it exists.
                            lines.append(f"    {field_name}: {py_type}")
                    else:
                        lines.append(f"    {field_name}: {py_type} = {val_repr}")

                # Write computed fields
                if computed_fields:
                    lines.append("")
                    for fname, fexpr in computed_fields:
                        lines.append(f"    @computed_field")
                        lines.append(f"    def {fname}(self) -> str:")
                        lines.append(f'        return f"{fexpr}"')

            if env_file_name:
                lines.append(
                    f'    model_config = SettingsConfigDict(env_prefix="{prefix}", env_file="{env_file_name}")'
                )
            else:
                lines.append(
                    f'    model_config = SettingsConfigDict(env_prefix="{prefix}")'
                )

            # Special Handling for Clickhouse DB_URL computation
            if section.type.upper() == "CLICKHOUSE":
                lines.append("")
                lines.append('    @model_validator(mode="after")')
                lines.append("    def compute_db_url(self) -> Self:")
                lines.append(
                    '        if self.db_url == "sqlite:///:memory:" or not self.db_url:'
                )
                lines.append(
                    '            self.db_url = f"clickhouse+connect://{self.user}:{self.password.get_secret_value()}@{self.host}:{self.port}/{self.database}"'
                )
                lines.append("        return self")

            lines.append("")

        return "\n".join(lines)

    DERIVED_MAPPINGS = {
        "OPENOBSERVE": {
            "target_name": "logger_config",
            "mapping": {
                "logger_name": "logger_name",
                "enable_otel": "enable_otel",
                "otel_endpoint": "otel_grpc_endpoint",
            },
            "expressions": {
                "otel_insecure": "getattr(obj, 'otel_insecure', True)",
                "otel_service_name": "getattr(obj, 'otel_service_name', 'ibis')",
                "otel_stream_name": "getattr(obj, 'otel_stream_name', 'ibis')",
            },
        }
    }

    @staticmethod
    def generate_credentials_code(env_file: EnvFile) -> str:
        """
        Generates the lazy-loading credentials.py script.
        """
        lines = [
            "from typing import Any, Dict, TYPE_CHECKING",
            "",
            "# Explicitly export names for star imports and documentation",
            "__all__ = [",
        ]

        def to_class_name(name):
            return "".join(part.capitalize() for part in name.split("_")) + "Settings"

        def to_conf_name(name):
            return f"{name.lower()}_conf"

        # Collect names for __all__
        conf_names = []
        class_names = []
        derived_configs = []  # (type, config_name, class_name)

        # Track special types for derived configs (Singleton logic: first wins)
        seen_types = set()

        for section in env_file.sections:
            conf_name = to_conf_name(section.name)
            class_name = to_class_name(section.name)
            conf_names.append(conf_name)
            class_names.append(class_name)

            # Check for derived configs
            stype = section.type.upper()
            if stype in EnvGenerator.DERIVED_MAPPINGS and stype not in seen_types:
                definition = EnvGenerator.DERIVED_MAPPINGS[stype]
                target_name = definition.get("target_name")
                if not target_name:
                    target_name = f"{section.name.lower()}_{definition.get('target_suffix', 'config')}"

                # Special Case: Legacy overrides for known singletons (like clickhouse_config instead of main_db_config)
                if stype == "CLICKHOUSE":
                    target_name = "clickhouse_config"
                if stype == "REDIS":
                    target_name = "redis_config"
                # OpenObserve is already "logger_config" via target_name above

                derived_configs.append((stype, target_name, class_name))
                seen_types.add(stype)

        # Formatting __all__
        all_exports = conf_names + [dc[1] for dc in derived_configs]

        # Chunking for display
        chunk_size = 4
        for i in range(0, len(all_exports), chunk_size):
            chunk = all_exports[i : i + chunk_size]
            quoted = [f'"{n}"' for n in chunk]
            comma = "," if i + chunk_size < len(all_exports) else ""
            lines.append(f"    {', '.join(quoted)}{comma}")
        lines.append("]")
        lines.append("")

        # Inject Type Stubs
        lines.append("if TYPE_CHECKING:")
        if not all_exports:
            lines.append("    pass")
        else:
            for name in all_exports:
                lines.append(f"    {name}: Dict[str, Any]")
        lines.append("")

        lines.append("def __getattr__(name: str) -> Any:")
        lines.append('    """')
        lines.append("    Lazy load configuration using Pydantic Settings.")
        lines.append('    """')
        lines.append("    # Import locally to avoid module-level import side effects")
        if class_names:
            lines.append("    from ..settings import (")

            # Import list
            for i in range(0, len(class_names), 3):
                chunk = class_names[i : i + 3]
                comma = "," if i + 3 < len(class_names) else ""
                lines.append(f"        {', '.join(chunk)}{comma}")
            lines.append("    )")
        lines.append("")
        lines.append("    # Helper to return dict for backward compatibility")
        lines.append("    def to_dict(model_instance):")
        lines.append("        return model_instance.model_dump()")
        lines.append("")
        lines.append("    # 1. Direct Config Mappings")

        for section in env_file.sections:
            conf_name = to_conf_name(section.name)
            class_name = to_class_name(section.name)
            lines.append(
                f"    if name == {class_name}.conf_name: return to_dict({class_name}())"
            )

        lines.append("")
        lines.append("    # 2. Derived Configurations")

        for stype, target_name, class_name in derived_configs:
            definition = EnvGenerator.DERIVED_MAPPINGS[stype]

            lines.append(f'    if name == "{target_name}":')

            if "method" in definition:
                method_name = definition["method"]
                lines.append(f"        return {class_name}().{method_name}()")
            else:
                mapping = definition.get("mapping", {})
                expressions = definition.get("expressions", {})
                lines.append(f"        obj = {class_name}()")
                lines.append("        return {")
                for key, attr in mapping.items():
                    lines.append(f'            "{key}": obj.{attr},')
                for key, expr in expressions.items():
                    lines.append(f'            "{key}": {expr},')
                lines.append("        }")

            lines.append("")

        lines.append(
            f'    raise AttributeError(f"module {{__name__!r}} has no attribute {{name!r}}")'
        )
        lines.append("")
        lines.append("def __dir__():")
        lines.append("    return __all__")

        return "\n".join(lines)
