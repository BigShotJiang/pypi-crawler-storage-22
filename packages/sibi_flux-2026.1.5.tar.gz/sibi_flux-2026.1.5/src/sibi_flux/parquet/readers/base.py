import importlib
from typing import Optional, Any
from .parquet import ParquetReader


class BaseReader(ParquetReader):
    """
    Base reader for Data Objects that supports lazy configuration resolution.

    This class avoids import-time side effects by resolving the filesystem and
    storage paths at runtime (initialization) using declarative configuration keys.

    Class Attributes:
        fs_name (str): The name of the filesystem to retrieve via `get_fs_instance`.
                       Defaults to "etl_source".
        storage_variable (Optional[str]): The variable name in the configuration module
                                          that holds the base path.
        storage_subpath (Optional[str]): The sub-path to append to the base path.
        storage_module_path (str): The python path to the configuration module.
                                   Defaults to "solutions.conf.storage".
    """

    # Declarative Defaults
    fs_name: str = "etl_source"
    storage_variable: Optional[str] = None
    storage_subpath: Optional[str] = None
    storage_module_path: str = "solutions.conf.storage"

    def __init__(
        self,
        parquet_start_date: Optional[str] = None,
        parquet_end_date: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        # 1. Resolve Configuration (Class attributes + kwargs overrides)
        fs_name = kwargs.pop("fs_name", self.fs_name)
        storage_variable = kwargs.pop("storage_variable", self.storage_variable)
        storage_subpath = kwargs.pop("storage_subpath", self.storage_subpath)
        storage_module_path = kwargs.pop(
            "storage_module_path", self.storage_module_path
        )

        # 2. Dynamic import to avoid hard dependency on project structure
        try:
            storage = importlib.import_module(storage_module_path)
        except ImportError:
            # If the default module doesn't exist, we can't auto-resolve.
            # But if the user passed 'fs' manually, we might be fine.
            storage = None

        # 3. Resolve Filesystem
        if "fs" in kwargs:
            kw_fs = kwargs.pop("fs")
        elif storage:
            kw_fs = storage.get_fs_instance(fs_name)
        else:
            # No FS provided and no config module found. ParquetReader likely needs FS.
            # We pass None and let ParquetReader handle/fail it.
            kw_fs = None

        # 4. Resolve Storage Path
        # Only resolve if not explicitly provided in kwargs (ParquetReader arg)
        if "parquet_storage_path" not in kwargs and storage:
            if storage_variable and storage_subpath:
                try:
                    base_path = getattr(storage, storage_variable)
                    kwargs["parquet_storage_path"] = f"{base_path}/{storage_subpath}"
                except AttributeError:
                    # Fallback or allow parent to handle missing path
                    pass

        # 5. Initialize Parent
        super().__init__(
            parquet_start_date=parquet_start_date,
            parquet_end_date=parquet_end_date,
            fs=kw_fs,
            **kwargs,
        )


# Alias for backward compatibility if needed
SolutionsBaseReader = BaseReader
