"""
Parquet Readers module.

Provides specialized readers for Parquet files handling partitioning and types.
"""

from __future__ import annotations
from collections.abc import Mapping
from typing import Optional, ClassVar, Any

import dask.dataframe as dd
import pandas as pd

from sibi_flux.df_helper._df_helper import DfHelper


class ParquetReader(DfHelper):
    """
    This class is a specialised helper for reading and managing Parquet files.

    The `ParquetReader` class is designed to facilitate working with Parquet
    datasets stored across different filesystems. It initialises the required
    resources, ensures the existence of the specified Parquet directory,
    and provides an abstraction to load the data into a Dask DataFrame.

    The class requires configuration for the storage path and dates defining
    a range of interest. It also supports various filesystem types through
    `fsspec`.

    :ivar config: Holds the final configuration for this instance, combining
        `DEFAULT_CONFIG` with user-provided configuration.
    :type config: dict
    :ivar df: Stores the loaded Dask DataFrame after the `load()` method is
        invoked. Initially set to None.
    :type df: Optional[dd.DataFrame | pd.DataFrame]
    :ivar parquet_storage_path: The path to the Parquet storage directory.
    :type parquet_storage_path: str
    :ivar parquet_start_date: Start date for Parquet data selection. Must
        be set in the configuration.
    :type parquet_start_date: str
    :ivar parquet_end_date: End date for Parquet data selection. Must be
        set in the configuration.
    :type parquet_end_date: str

    :ivar fs: Instance of `fsspec` filesystem used to interact with the
        Parquet storage.
    :type fs: fsspec.AbstractFileSystem
    """

    DEFAULT_CONFIG: ClassVar[Mapping[str, Any]] = {
        "backend": "parquet",
        "partition_on": ["partition_date"],
    }
    df: Optional[dd.DataFrame | pd.DataFrame] = None

    def __init__(
        self,
        parquet_start_date: Optional[str] = None,
        parquet_end_date: Optional[str] = None,
        **kwargs: Any,
    ):
        # Merge explicitly provided dates into kwargs config
        if parquet_start_date:
            kwargs["parquet_start_date"] = parquet_start_date
        if parquet_end_date:
            kwargs["parquet_end_date"] = parquet_end_date

        self.config = {
            **self.DEFAULT_CONFIG,
            **kwargs,
        }
        super().__init__(**self.config)

        # Access validated properties from self.backend_parquet (the Pydantic model)
        # instead of the raw config dict, ensuring type safety.
        # Note: You might need to adjust attribute access depending on your DfHelper structure
        if hasattr(self, "backend_params"):
            self.parquet_storage_path = self.backend_params.parquet_storage_path
            self.parquet_start_date = self.backend_params.parquet_start_date
            self.parquet_end_date = self.backend_params.parquet_end_date
            self.fs = self.backend_params.fs
        else:
            # Fallback if DfHelper structure differs
            self.parquet_storage_path = self.config.get("parquet_storage_path")
            self.parquet_start_date = self.config.get("parquet_start_date")
            self.parquet_end_date = self.config.get("parquet_end_date")
            self.fs = self.config.get("fs")

        # Additional filesystem checks can remain
        if not self.directory_exists():
            raise ValueError(f"{self.parquet_storage_path} does not exist")

    def load(self, **kwargs) -> pd.DataFrame | dd.DataFrame:
        self.df = super().load(**kwargs)
        return self.df

    async def aload(self, **kwargs) -> pd.DataFrame | dd.DataFrame:
        self.df = await super().aload(**kwargs)
        return self.df

    def directory_exists(self) -> bool:
        try:
            info = self.fs.info(self.parquet_storage_path)
            return info["type"] == "directory"
        except FileNotFoundError:
            return False
