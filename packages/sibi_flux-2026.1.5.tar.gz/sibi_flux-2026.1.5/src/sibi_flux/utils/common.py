def ensure_slash(path: str) -> str:
    """Ensures that the path string ends with a slash."""
    if not path:
        return ""
    if not path.endswith("/"):
        return path + "/"
    return path
