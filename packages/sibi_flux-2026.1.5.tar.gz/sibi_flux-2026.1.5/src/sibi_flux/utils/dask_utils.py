import dask.dataframe as dd
import pandas as pd
from typing import Any


def sanitize_dask_df(df: Any) -> dd.DataFrame:
    """
    Ensure the dataframe is a valid Dask DataFrame.
    """
    if isinstance(df, dd.DataFrame):
        return df
    if isinstance(df, pd.DataFrame):
        return dd.from_pandas(df, npartitions=1)
    raise TypeError(f"Expected Dask or Pandas DataFrame, got {type(df)}")
