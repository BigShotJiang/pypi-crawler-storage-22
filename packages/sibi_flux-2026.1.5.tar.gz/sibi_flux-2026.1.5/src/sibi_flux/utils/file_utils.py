import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def count_lines_in_files(directory: str | Path, extension: str) -> dict[str, int]:
    """Finds all files with the given extension and counts their lines.

    Args:
        directory (str | Path): Path to the target directory.
        extension (str): File extension to filter by (e.g., ".txt" or "txt").

    Returns:
        dict[str, int]: A dictionary mapping filenames to their line counts.
            Returns -1 as the line count for files that could not be read.

    Raises:
        FileNotFoundError: If the directory does not exist.
        NotADirectoryError: If the path is not a directory.
    """
    results: dict[str, int] = {}
    dir_path = Path(directory)

    if not dir_path.exists():
        raise FileNotFoundError(f"Directory not found: {directory}")
    if not dir_path.is_dir():
        raise NotADirectoryError(f"Path is not a directory: {directory}")

    # Ensure extension starts with dot
    if not extension.startswith("."):
        extension = f".{extension}"

    # Iterate over files matching the extension
    for file_path in dir_path.glob(f"*{extension}"):
        if not file_path.is_file():
            continue

        try:
            # Try efficient line counting
            with file_path.open("r", encoding="utf-8", errors="ignore") as f:
                line_count = sum(1 for _ in f)
                results[file_path.name] = line_count
        except OSError as e:
            logger.warning(f"Could not read file {file_path}: {e}")
            results[file_path.name] = -1

    return results
