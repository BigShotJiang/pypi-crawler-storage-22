
import yaml
from pathlib import Path
import os
from typing import List, Dict, Any
from rich.console import Console
import typer
import importlib.util
import sys

console = Console()

def create_cubes(app_name: str) -> None:
    """
    Generate app-specific Datacube extensions based on local configuration.
    
    Args:
        app_name: The name of the application (must exist in project root).
    """
    cwd = Path(os.getcwd())
    
    # 1. Validate App Directory
    app_dir = cwd / app_name
    if not app_dir.exists() or not app_dir.is_dir():
        console.print(f"[red]Error: Application directory '{app_name}' not found.[/red]")
        raise typer.Exit(code=1)
        
    datacubes_dir = app_dir / "datacubes"
    if not datacubes_dir.exists():
        console.print(f"[yellow]Creating 'datacubes' directory for {app_name}...[/yellow]")
        datacubes_dir.mkdir(parents=True, exist_ok=True)
        (datacubes_dir / "__init__.py").touch()
        
    # 2. Load Registry (datacubes.yaml)
    registry_path = datacubes_dir / "datacubes.yaml"
    if not registry_path.exists():
        console.print(f"[red]Error: Registry file not found at {registry_path}[/red]")
        console.print("Please define your extensions in this file first.")
        # Create a template if missing?
        template = """
cubes:
  # - source: dataobjects.gencubes.ibis_dev.products.products_cubes.ProductsDc
  #   name: LogisticsProductsDc
  #   module: products
"""
        registry_path.write_text(template.strip())
        console.print(f"[green]Created template at {registry_path}. Edit it and run again.[/green]")
        raise typer.Exit(code=1)
        
    try:
        with open(registry_path, "r") as f:
            config = yaml.safe_load(f)
    except Exception as e:
        console.print(f"[red]Error parsing {registry_path}: {e}[/red]")
        raise typer.Exit(code=1)
        
    if not config or "cubes" not in config or not isinstance(config["cubes"], list):
        console.print(f"[yellow]Warning: No 'cubes' list found in {registry_path}.[/yellow]")
        return

    # 3. Group by Module
    from collections import defaultdict
    cubes_by_module = defaultdict(list)
    for entry in config["cubes"]:
        mod = entry.get("module")
        if mod:
            cubes_by_module[mod].append(entry)

    console.print(f"[bold blue]Processing {len(config['cubes'])} datacube extensions across {len(cubes_by_module)} modules...[/bold blue]")
    
    for module_name, entries in cubes_by_module.items():
        process_module_group(module_name, entries, datacubes_dir, app_name)


def process_module_group(module_name: str, entries: List[Dict[str, Any]], datacubes_dir: Path, app_name: str) -> None:
    target_file = datacubes_dir / f"{module_name}.py"
    
    # Read existing content if file exists
    existing_content = ""
    if target_file.exists():
        existing_content = target_file.read_text()
    
    new_imports = set()
    new_classes = []
    
    for entry in entries:
        source_path = entry.get("source")
        class_name = entry.get("name")
        
        if not all([source_path, class_name]):
            console.print(f"[red]Skipping invalid entry in {module_name}: {entry}[/red]")
            continue

        # Check for idempotency: does class definition already exist?
        if f"class {class_name}" in existing_content:
            console.print(f"[dim]Skipping {class_name} (already exists in {module_name}.py)[/dim]")
            continue
            
        # Parse Source
        try:
            source_module_str, source_class = source_path.rsplit(".", 1)
        except ValueError:
            console.print(f"[red]Invalid source format '{source_path}' for {class_name}[/red]")
            continue
            
        # Prepare Import
        import_stmt = f"from {source_module_str} import {source_class}"
        
        # Check if import exists in file or is already queued
        if import_stmt not in existing_content:
            new_imports.add(import_stmt)
            
        # Prepare Class
        class_code = f"""
class {class_name}({source_class}):
    \"\"\"
    App-specific extension of {source_class} for '{app_name}'.
    
    Source: {source_path}
    \"\"\"
    pass
"""
        new_classes.append(class_code.strip())
        console.print(f"[green]Queued generation for {class_name}[/green]")

    if new_classes:
        mode = "a" if target_file.exists() else "w"
        
        content_parts = []
        
        # Add imports first
        if new_imports:
            sorted_imports = sorted(list(new_imports))
            content_parts.extend(sorted_imports)
            content_parts.append("") # Spacer
            
        # Add classes
        content_parts.extend(new_classes)
        
        with open(target_file, mode) as f:
            if mode == "a" and existing_content.strip():
                f.write("\n\n") # Ensure separation from previous content
            
            f.write("\n\n".join(content_parts))
            f.write("\n")
            
        console.print(f"[green]Updated {target_file.name} with {len(new_classes)} new classes.[/green]")
    else:
        console.print(f"[dim]No changes needed for {target_file.name}[/dim]")
