from __future__ import annotations

from pathlib import Path


class PathUtils:
    @staticmethod
    def to_module_path(path_str: str, root_path: Path | None = None) -> str:
        """
        Converts a file path to a Python module path (dot notation).
        Example: 'solutions/dataobjects/fields/common/table.py' -> 'solutions.dataobjects.fields.common.table'
        """
        try:
            p = Path(path_str)
            if root_path and p.is_absolute():
                try:
                    p = p.relative_to(root_path)
                except ValueError:
                    pass
            
            # Remove .py suffix
            if p.suffix == ".py":
                p = p.with_suffix("")
            
            # Convert slash to dot
            return str(p).replace("/", ".").strip(".")
        except Exception:
            return path_str
