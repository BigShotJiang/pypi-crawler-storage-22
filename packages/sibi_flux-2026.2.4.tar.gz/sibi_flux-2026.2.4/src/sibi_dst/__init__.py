from __future__ import annotations

import importlib
import sys as _sys
import warnings

warnings.warn(
    "sibi_dst is deprecated; use sibi_flux instead.",
    FutureWarning,
    stacklevel=2,
)

# Canonical package
_CANON = "sibi_flux"

# Make `import skt` behave like `import sibi_flux`
_pkg = importlib.import_module(_CANON)

# Populate this module’s namespace with the canonical package attributes
globals().update(_pkg.__dict__)

# Expose a clean public surface
__all__ = getattr(_pkg, "__all__", [])
__version__ = getattr(_pkg, "__version__", "0.0.0")

# Critical: alias module entries so `import skt.df_helper` maps to `sibi_flux.df_helper`
_sys.modules[__name__] = _pkg
_sys.modules[__name__ + ".__init__"] = _pkg  # defensive (rarely needed)


def __getattr__(name: str):
    # Lazy-load submodules on demand: skt.df_helper, skt.osmnx, etc.
    try:
        mod = importlib.import_module(f"{_CANON}.{name}")
    except ModuleNotFoundError as e:
        raise AttributeError(f"module '{__name__}' has no attribute '{name}'") from e
    _sys.modules[f"{__name__}.{name}"] = mod
    return mod


def __dir__():
    # Combine canonical attrs + subpackages for nicer autocomplete
    base = set(globals().keys())
    return sorted(base)
