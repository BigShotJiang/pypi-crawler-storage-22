from __future__ import annotations
from importlib.metadata import version as _pkg_version, PackageNotFoundError

try:
    __version__ = _pkg_version("sibi-flux")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "0.0.0"


# Dialect Registrations
from sibi_flux.core import dialects

# Core Exports
from sibi_flux.logger import Logger
from sibi_flux.core import ManagedResource
from sibi_flux.datacube import Datacube, DatacubeConfig
from sibi_flux.dataset import Dataset
from sibi_flux.pipelines import BasePipeline

# Helper Exports
from sibi_flux.df_helper import DfHelper
from sibi_flux.df_enricher import AsyncDfEnricher as DfEnricher
from sibi_flux.df_validator._df_validator import DfValidator

# Artifacts
from sibi_flux.artifacts import ParquetArtifact, BaseArtifact as Artifact
from sibi_flux.parquet import ParquetReader

# Utilities (Sub-packages)
from sibi_flux import dask_cluster
from sibi_flux.utils import clickhouse_writer
from sibi_flux import parquet

__all__ = [
    "__version__",
    "Logger",
    "ManagedResource",
    "Datacube",
    "DatacubeConfig",
    "Dataset",
    "BasePipeline",
    "DfHelper",
    "DfEnricher",
    "DfValidator",
    "ParquetArtifact",
    "Artifact",
    "ParquetReader",
    "dask_cluster",
    "parquet",
    "clickhouse_writer",
]
