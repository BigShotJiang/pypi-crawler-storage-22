from .base import BaseArtifact
from .parquet import ParquetArtifact

__all__ = [
    "BaseArtifact",
    "ParquetArtifact",
]
