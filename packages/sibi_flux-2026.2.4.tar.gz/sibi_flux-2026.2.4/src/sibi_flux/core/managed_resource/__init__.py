from ._managed_resource import ManagedResource

__all__ = ["ManagedResource"]
