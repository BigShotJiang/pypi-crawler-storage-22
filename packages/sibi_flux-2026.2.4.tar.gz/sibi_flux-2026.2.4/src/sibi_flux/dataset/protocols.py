# src/sibi_flux/dataset/protocols.py
from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    Protocol,
    runtime_checkable,
)

import dask.dataframe as dd

if TYPE_CHECKING:
    from sibi_flux.logger import Logger

@runtime_checkable
class DatasetReaderProtocol(Protocol):
    """
    Protocol defining the interface for Dataset Readers (both live and historical).
    """

    def __init__(self, **kwargs: Any) -> None:
        ...

    async def aload(self, **kwargs: Any) -> dd.DataFrame:
        """Asynchronously loads the data."""
        ...

    @property
    def logger(self) -> Logger | None:
        ...

    @property
    def debug(self) -> bool:
        ...

DatasetReaderType = type[DatasetReaderProtocol]
