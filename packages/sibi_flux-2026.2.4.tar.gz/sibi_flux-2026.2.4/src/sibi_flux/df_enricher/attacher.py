# src/sibi_flux/df_enricher/attacher.py
from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Callable,
    Sequence,
)

if TYPE_CHECKING:
    from sibi_flux.dataset.protocols import DatasetReaderType
    from sibi_flux.logger import Logger
    from .types import DdfLike


class AttachmentMaker:
    """
    Async attacher class.
    Skips work if any param value is falsy ([], None, {}, etc.).
    """

    def __init__(
        self,
        cube_cls: DatasetReaderType,
        fieldnames: Sequence[str],
        column_names: Sequence[str],
    ) -> None:
        self.cube_cls = cube_cls
        self.fieldnames = tuple(fieldnames)
        self.column_names = list(column_names)

    async def attach(
        self,
        *,
        logger: Logger | None = None,
        debug: bool = False,
        **params: Any,
    ) -> DdfLike | None:
        if any(not v for v in params.values()):
            return None
        call_params = {
            "fieldnames": self.fieldnames,
            "column_names": self.column_names,
            **params,
        }
        return await self.cube_cls(logger=logger, debug=debug).aload(**call_params)


# Factory function for backward compatibility
def make_attacher(
    cube_cls: DatasetReaderType,
    fieldnames: Sequence[str],
    column_names: Sequence[str],
) -> Callable[..., Awaitable[DdfLike | None]]:
    """
    Factory for async attachers.
    Skips work if any param value is falsy ([], None, {}, etc.).
    """
    attacher = AttachmentMaker(cube_cls, fieldnames, column_names)
    return attacher.attach


__all__ = ["AttachmentMaker", "make_attacher"]
