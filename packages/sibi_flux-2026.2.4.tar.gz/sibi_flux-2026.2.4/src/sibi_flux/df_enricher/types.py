# src/sibi_flux/df_enricher/types.py
"""
Enricher Types module.

Type definitions for the DataFrame enrichment subsystem.
"""

from __future__ import annotations

import dask.dataframe as dd
import pandas as pd

DdfLike = dd.DataFrame | pd.DataFrame
