# Propose-Readers Command

The `propose-readers` command automates the generation of reader configurations for Sibi Flux applications by analyzing S3 storage layouts.

## Usage

```bash
uv run sibi-flux propose-readers <app_name> [--layout <layout_name>] [--force]
```

- `<app_name>`: The name of the application (e.g., `logistics`).
- `--layout`: (Optional) The name of the S3 layout defined in `conf/storage.yaml`. If omitted, the first layout found will be used.
- `--force`: (Optional) Overwrite an existing `<app_name>/readers/readers.yaml` file.

## How it works

1. Scans `conf/storage.yaml` for `s3_layouts`.
2. For each depot and subdirectory in the selected layout, it proposes a reader class name and the corresponding storage variable alias.
3. Generates or updates `<app_name>/readers/readers.yaml`.

## Example

Given a layout `mobile_layout` with a depot `mobile_data` and subdirectory `gps`, it will propose:
- Class Name: `MobileDataGpsReader`
- Storage Variable: `gps_storage`
