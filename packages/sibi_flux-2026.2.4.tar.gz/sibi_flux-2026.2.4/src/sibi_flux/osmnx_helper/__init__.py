from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._pbf_handler import PBFHandler
    from .graph_loader import GraphLoader


def __getattr__(name: str):
    if name == "PBFHandler":
        try:
            from ._pbf_handler import PBFHandler

            return PBFHandler
        except ImportError as e:
            raise ImportError(
                "Optional dependency 'osmnx' (or 'geopandas') missing. Install 'sibi-flux[geospatial]'."
            ) from e
    if name == "GraphLoader":
        try:
            from .graph_loader import GraphLoader

            return GraphLoader
        except ImportError as e:
            raise ImportError(
                "Optional dependency 'osmnx' (or 'geopandas') missing. Install 'sibi-flux[geospatial]'."
            ) from e
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["PBFHandler", "GraphLoader"]
