import time
from threading import RLock
from collections.abc import MutableMapping
from typing import Any

from sibi_flux.logger import Logger


class FsRegistry:
    """
    Thread-safe registry and cache for filesystem instances.
    Provides TTL-based invalidation and integrates fsspec cache clearing.
    """

    def __init__(
        self,
        logger: "Logger | None" = None,
        ttl_seconds: int = 3600,
        debug: bool = False,
    ):
        self._storage_registry: MutableMapping[str, Any] = {}
        self._fs_instance_cache: MutableMapping[str, tuple] = (
            {}
        )  # {name: (fs, timestamp)}
        self._lock = RLock()
        self.ttl_seconds = ttl_seconds

        self.logger = logger or Logger.default_logger(logger_name="FsRegistry")
        self.logger.set_level(Logger.DEBUG if debug else Logger.INFO)

    # ----------------------------------------------------------------------
    # Registration
    # ----------------------------------------------------------------------
    def register(self, name: str, manager: Any):
        """
        Register a storage manager that provides get_fs_instance().
        """
        if not hasattr(manager, "get_fs_instance"):
            raise TypeError("Manager must have a 'get_fs_instance' method.")
        with self._lock:
            self._storage_registry[name] = manager
            self.logger.debug(f"Registered storage '{name}'")

    # ----------------------------------------------------------------------
    # Retrieval
    # ----------------------------------------------------------------------
    def get_fs_instance(self, name: str = "source", reload: bool = False):
        """
        Retrieve a filesystem instance by name.
        - Uses cache unless TTL expired or reload=True.
        - Automatically clears fsspec cache to avoid FileExpired errors.
        """
        now = time.time()
        with self._lock:
            cached = self._fs_instance_cache.get(name)

            # TTL check
            if cached and not reload and (now - cached[1]) < self.ttl_seconds:
                fs = cached[0]
                return fs

            manager = self._storage_registry.get(name)
            if not manager:
                raise ValueError(
                    f"Storage '{name}' not registered. "
                    f"Available: {list(self._storage_registry.keys())}"
                )

            fs = manager.get_fs_instance()

            # Invalidate fsspec internal cache
            if hasattr(fs, "invalidate_cache"):
                try:
                    fs.invalidate_cache()
                    self.logger.debug(f"Cleared fsspec cache for '{name}'")
                except Exception as e:
                    self.logger.warning(f"Failed to invalidate cache for '{name}': {e}")

            self._fs_instance_cache[name] = (fs, now)
            self.logger.debug(f"Refreshed fs instance for '{name}'")
            return fs

    # ----------------------------------------------------------------------
    # Cache control
    # ----------------------------------------------------------------------
    def invalidate_fs(self, name: str):
        """
        Invalidate and remove cached fs instance for a given name.
        """
        with self._lock:
            if name in self._fs_instance_cache:
                del self._fs_instance_cache[name]
                self.logger.debug(f"Invalidated fs cache for '{name}'")
            else:
                self.logger.debug(f"No cached fs found for '{name}'")

    def clear_fs_cache(self):
        """
        Clear all cached filesystem instances.
        """
        with self._lock:
            self._fs_instance_cache.clear()
            self.logger.debug("Cleared all filesystem caches")

    def unregister_fs(self, name: str):
        """
        Unregister a storage configuration and clear its cached instance.
        """
        with self._lock:
            self._storage_registry.pop(name, None)
            self._fs_instance_cache.pop(name, None)
            self.logger.debug(f"Unregistered storage '{name}' and cleared cache")

    def flatten(self, cache_dict: MutableMapping[str, Any]) -> None:
        """
        Populate the provided dictionary with flattened paths from all registered managers.
        Enables concise imports like 'from my_app.conf.storage import mobile_storage'.
        
        Hardened: Includes collision detection for subdirectories with the same name,
        and prevents overwriting existing keys (depots) in the cache.
        """
    def flatten(self, cache_dict: MutableMapping[str, Any]) -> None:
        """
        Populate the provided dictionary with flattened paths from all registered managers.
        Enables concise imports like 'from my_app.conf.storage import mobile_storage'.
        
        Hardened: Systematic collision detection for both depots and subdirectories
        across all registered managers. Disambiguates using manager IDs when necessary.
        """
        with self._lock:
            # candidate_alias -> list of (manager_id, path, is_depot)
            all_candidates: dict[str, list[tuple[str, str, bool]]] = {}

            # 1. Collect all potential aliases
            for manager_id, manager in self._storage_registry.items():
                if not hasattr(manager, "_depot_config"):
                    continue

                depots = getattr(manager, "_depot_config", {})
                for depot, subdirs in depots.items():
                    # A. Depot Alias Candidate
                    depot_alias = depot if depot.endswith("_storage") else f"{depot}_storage"
                    depot_path = manager.join_paths(manager.storage_path, depot)
                    
                    if depot_alias not in all_candidates:
                        all_candidates[depot_alias] = []
                    
                    candidate_entry = (manager_id, depot_path, True)
                    if candidate_entry not in all_candidates[depot_alias]:
                        all_candidates[depot_alias].append(candidate_entry)
                    
                    # B. Subdirectory Alias Candidates
                    for subdir in subdirs:
                        subdir_alias = f"{subdir}_storage"
                        subdir_path = manager.join_paths(manager.storage_path, depot, subdir)
                        
                        if subdir_alias not in all_candidates:
                            all_candidates[subdir_alias] = []
                        
                        subdir_entry = (manager_id, subdir_path, False)
                        if subdir_entry not in all_candidates[subdir_alias]:
                            all_candidates[subdir_alias].append(subdir_entry)

            # 2. Resolve aliases and handle collisions
            for alias, sources in all_candidates.items():
                # We also check if the alias itself is already a manager ID (unlikely but possible)
                collision_with_manager_id = alias in self._storage_registry
                
                # If unique and no shadowing of manager ID
                if len(sources) == 1 and not collision_with_manager_id:
                    cache_dict[alias] = sources[0][1]
                else:
                    # COLLISION! We must disambiguate all sources
                    for manager_id, path, is_depot in sources:
                        # Full disambiguation: {manager}_{alias}
                        # e.g., etl_logistics_storage, source_logistics_storage
                        # e.g., etl_mobile_storage, source_mobile_storage
                        disambiguated = f"{manager_id}_{alias}"
                        cache_dict[disambiguated] = path
                        
                        self.logger.warning(
                            f"Storage collision for '{alias}'! Resolved as '{disambiguated}'."
                        )
                    
                    # We do NOT register the short alias to prevent ambiguity
                    if alias in cache_dict and not collision_with_manager_id:
                        # If a previous manager registered it (though unlikely with current loop), clean it up
                        del cache_dict[alias]

            self.logger.debug(f"Flattened registry into cache. Total keys: {len(cache_dict)}")
