#!/usr/bin/env python3
"""
Admin script to delete all sideload-* packages from PyPI using browser automation.
Uses the shared pypi_cleanup module for login and project deletion.
"""

import os
import sys
import asyncio
import random

from playwright.async_api import async_playwright, Page

from sideloader.pypi_cleanup import (
    pypi_login,
    delete_pypi_project,
    PYPI_USER,
    PYPI_PASSWORD,
    PYPI_TOTP,
)

if not PYPI_USER or not PYPI_PASSWORD:
    print("❌ PYPI_USER and PYPI_PASSWORD environment variables must be set")
    sys.exit(1)


async def get_user_projects(page: Page) -> list[str]:
    """Get all projects owned by the user that start with sideload-"""
    try:
        print("🔍 Fetching your PyPI projects...")

        await page.goto("https://pypi.org/manage/projects/")
        await page.wait_for_load_state("networkidle")

        projects = await page.evaluate(
            """() => {
            const links = Array.from(document.querySelectorAll('a[href*="/manage/project/"]'));
            return links.map(link => {
                const match = link.href.match(/\\/manage\\/project\\/([^\\/]+)\\//);
                return match ? match[1] : null;
            }).filter(name => name && name.startsWith('sideload-'));
        }"""
        )

        return projects

    except Exception as e:
        print(f"❌ Error fetching projects: {e}")
        return []


async def wait_for_login(page: Page):
    """Wait for user to manually complete login (captcha / manual 2FA)."""
    current_url = page.url
    if "/account/two-factor/" in current_url or "/account/login/" in current_url:
        print("\n" + "=" * 60)
        print("   👤 Please complete login in the browser window")
        print("   ⏳ Waiting for you to finish...")
        print("=" * 60 + "\n")

        while True:
            await asyncio.sleep(2)
            current_url = page.url
            if (
                "/account/two-factor/" not in current_url
                and "/account/login/" not in current_url
            ):
                break
            print("   ⏳ Still waiting...", end="\r")
        print("\n   ✓ Login completed!")


async def main():
    print("🧹 PyPI Sideload Package Cleanup Tool")
    print("=" * 50)
    if PYPI_TOTP:
        print("🔐 TOTP auto-generation enabled")
    else:
        print("⚠️  TOTP auto-generation disabled (set PYPI_TOTP to enable)")
    print()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        try:
            # Login using shared module (handles credentials + TOTP)
            await pypi_login(page)

            # If we're still on a login/2FA page (e.g. captcha), wait for manual completion
            await wait_for_login(page)

            # Get all sideload projects
            projects = await get_user_projects(page)

            if not projects:
                print("❌ No sideload-* projects found")
                return

            print(f"\n📋 Found {len(projects)} sideload projects:")
            for pkg in projects:
                print(f"  - {pkg}")

            # Delete each project using shared module
            print("\n🗑️  Deleting projects...\n")
            deleted = 0
            for pkg in projects:
                if await delete_pypi_project(page, pkg):
                    deleted += 1
                await asyncio.sleep(random.uniform(1.0, 3.0))

            print(f"\n✅ Deleted {deleted}/{len(projects)} projects")

        finally:
            await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
