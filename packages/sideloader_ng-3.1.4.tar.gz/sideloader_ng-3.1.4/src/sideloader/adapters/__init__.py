"""Adapters module - External service integrations for Sideload."""
