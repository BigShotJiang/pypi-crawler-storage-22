"""Hookdeck module - Integration utilities for Hookdeck event management."""

from sideloader.adapters.hookdeck.client import HookdeckClient

__all__ = ["HookdeckClient"]
