"""Hookdeck integration client for sending events and notifications."""

from typing import Optional

import httpx
from rich.console import Console


console = Console()


class HookdeckClient:
    """Client for interacting with Hookdeck's Publish API."""

    def __init__(
        self,
        source_id: Optional[str] = None,
        api_key: Optional[str] = None,
        verify_ssl: bool = True,
    ):
        """
        Initialize the Hookdeck client.

        Args:
            source_id: Hookdeck source ID
            api_key: Hookdeck API key
            verify_ssl: Whether to verify SSL certificates
        """
        self.source_id = source_id
        self.api_key = api_key
        self.verify_ssl = verify_ssl
        self.enabled = bool(source_id and api_key)

    def notify(self, bin_id: str, event_type: str = "start") -> bool:
        """
        Send an event to Hookdeck via the Publish API to trigger server-side processing.

        Args:
            bin_id: The bin/request ID to send in the event
            event_type: Type of event (e.g., 'start', 'complete', 'error')

        Returns:
            True if notification was sent successfully, False otherwise
        """
        if not self.enabled or not self.source_id or not self.api_key:
            return False

        try:
            response = httpx.post(
                "https://hkdk.events/v1/publish",
                headers={"x-hookdeck-source-id": str(self.source_id)},
                auth=(str(self.api_key), ""),
                json={"request_id": bin_id, "event_type": event_type},
                verify=self.verify_ssl,
            )
            response.raise_for_status()
            console.print(
                f"📡 Hookdeck {event_type} event sent for request [bold cyan]{bin_id}[/bold cyan]"
            )
            return True
        except Exception as e:
            console.print(
                f"⚠️  Failed to send Hookdeck {event_type} event: {e}", style="yellow"
            )
            return False
