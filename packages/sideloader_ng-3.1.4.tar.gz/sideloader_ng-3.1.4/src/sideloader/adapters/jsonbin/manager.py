"""High-level manager for Sideload-specific JSONBin operations."""

import time
from typing import Dict, List, Optional, Any

from sideloader.adapters.jsonbin.connector import JSONBinConnector


class SideloadBinManager:
    """High-level manager for Sideload-specific JSONBin operations"""

    def __init__(self, connector: JSONBinConnector):
        """
        Initialize the sideload bin manager

        Args:
            connector: JSONBin connector instance
        """
        self.connector = connector

    def create_sideload_request(
        self, url: str, collection_id: Optional[str] = None
    ) -> str:
        """
        Create a new sideload request

        Args:
            url: The URL to sideload
            collection_id: Optional collection ID

        Returns:
            The created bin ID
        """
        data = {"url": url, "status": "CREATED", "created_at": time.time()}
        return self.connector.create_bin(data, collection_id)

    def update_sideload_status(
        self, bin_id: str, status: str, **additional_data: Any
    ) -> None:
        """
        Update sideload request status

        Args:
            bin_id: The bin ID to update
            status: The new status
            **additional_data: Additional data to update
        """
        self.connector.update_bin(bin_id, status=status, **additional_data)

    def update_progress(self, bin_id: str, progress: int) -> None:
        """
        Update download progress

        Args:
            bin_id: The bin ID to update
            progress: Progress percentage (0-100)
        """
        self.connector.update_bin(bin_id, progress=progress)

    def mark_completed(
        self,
        bin_id: str,
        package_names: List[str],
        original_filename: str,
        file_size: int,
    ) -> None:
        """
        Mark sideload request as completed

        Args:
            bin_id: The bin ID to update
            package_names: List of created package names
            original_filename: Original filename
            file_size: Original file size
        """
        self.connector.update_bin(
            bin_id,
            status="UPLOADED",
            package_names=package_names,
            total_packages=len(package_names),
            original_filename=original_filename,
            file_size=file_size,
        )

    def mark_failed(self, bin_id: str, reason: str) -> None:
        """
        Mark sideload request as failed

        Args:
            bin_id: The bin ID to update
            reason: Failure reason
        """
        self.connector.update_bin(bin_id, status="FAILED", reason=reason)

    def mark_rejected(self, bin_id: str, reason: str) -> None:
        """
        Mark sideload request as rejected

        Args:
            bin_id: The bin ID to update
            reason: Rejection reason
        """
        self.connector.update_bin(bin_id, status="REJECTED", reason=reason)

    def get_sideload_data(self, bin_id: str) -> Dict[str, Any]:
        """
        Get sideload request data

        Args:
            bin_id: The bin ID to retrieve

        Returns:
            The sideload data
        """
        return self.connector.get_bin(bin_id)

    def find_sideload_collections(self) -> List[Dict[str, Any]]:
        """
        Find collections that start with 'sideload_'

        Returns:
            List of sideload collections
        """
        collections = self.connector.get_collections()
        return [
            collection
            for collection in collections
            if collection["collectionMeta"]["name"].startswith("sideload_")
        ]

    def get_pending_requests(
        self, collection_id: str, after_bin_id: Optional[str] = None
    ) -> List[str]:
        """
        Get pending sideload requests from a collection

        Args:
            collection_id: The collection ID to check
            after_bin_id: Optional bin ID for pagination

        Returns:
            List of bin IDs that need processing
        """
        bins = self.connector.get_collection_bins(collection_id, after_bin_id)
        pending_bins = []

        for bin_data in bins:
            bin_id = bin_data["record"]
            try:
                data = self.get_sideload_data(bin_id)
                if data.get("status") == "CREATED":
                    pending_bins.append(bin_id)
            except Exception:
                # Skip bins that can't be read
                continue

        return pending_bins
