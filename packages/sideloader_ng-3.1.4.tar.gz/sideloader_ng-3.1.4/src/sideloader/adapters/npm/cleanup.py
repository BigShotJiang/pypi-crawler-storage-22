"""NPM package cleanup utilities."""

from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import tempfile
from typing import List, Tuple

from sideloader.adapters.npm.token_generator import get_or_generate_token


NPM_REGISTRY = os.environ.get("NPM_REGISTRY", "https://registry.npmjs.org/")

__all__ = [
    "npm_unpublish_package",
    "npm_unpublish_packages",
    "npm_unpublish_packages_sync",
    "NPM_REGISTRY",
]


def _ensure_npm_available() -> bool:
    if shutil.which("npm"):
        return True
    print("  npm CLI is not installed in this runtime image (missing `npm` binary)")
    return False


def _create_user_config(npm_token: str) -> str:
    registry_url = NPM_REGISTRY.rstrip("/")
    if "://" in registry_url:
        registry_host = registry_url.split("://", 1)[1].rstrip("/")
    else:
        registry_host = registry_url.rstrip("/")

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".npmrc", delete=False, encoding="utf-8"
    ) as file_handle:
        file_handle.write(f"registry={registry_url}/\n")
        file_handle.write(f"//{registry_host}/:_authToken={npm_token}\n")
        file_handle.write("always-auth=true\n")
        return file_handle.name


def npm_unpublish_package(package_name: str, npm_token: str | None = None) -> bool:
    """Unpublish a single package spec from npm with force flag."""

    try:
        print(f"  Unpublishing {package_name}...")
        if not _ensure_npm_available():
            return False

        token = npm_token or get_or_generate_token()
        if not token:
            print("    npm token not available, skipping cleanup")
            return False

        npmrc_path = _create_user_config(token)

        try:
            result = subprocess.run(
                [
                    "npm",
                    "unpublish",
                    package_name,
                    "--force",
                    f"--userconfig={npmrc_path}",
                ],
                capture_output=True,
                text=True,
            )

            if result.returncode == 0:
                print(f"    Unpublished {package_name} from npm")
                return True

            stderr_output = (result.stderr or "").lower()
            if "404" in stderr_output or "not found" in stderr_output:
                print(f"    Package {package_name} was not found on npm")
                return False

            details = result.stderr.strip() or result.stdout.strip() or "unknown error"
            print(f"    Error unpublishing {package_name}: {details}")
            return False
        finally:
            os.unlink(npmrc_path)
    except Exception as exc:
        print(f"    Error unpublishing {package_name}: {exc}")
        return False


async def npm_unpublish_packages(package_names: List[str]) -> Tuple[int, int]:
    """Unpublish a list of package specs from npm."""

    token = get_or_generate_token()
    if not token:
        print("  npm token not available, skipping npm cleanup")
        return 0, 0

    deleted = 0
    errors = 0

    for package_name in package_names:
        if npm_unpublish_package(package_name, npm_token=token):
            deleted += 1
        else:
            errors += 1

        await asyncio.sleep(0.3)

    return deleted, errors


def npm_unpublish_packages_sync(package_names: List[str]) -> Tuple[int, int]:
    """Synchronous wrapper for npm_unpublish_packages."""

    return asyncio.run(npm_unpublish_packages(package_names))
