"""NPM token management with Kubernetes-backed caching and regeneration."""

from __future__ import annotations

import asyncio
import base64
from contextlib import contextmanager
import email
import imaplib
import json
import os
import re
import shutil
import subprocess
import time
from datetime import datetime, timedelta, timezone
from email import policy
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Optional

import requests


NPM_REGISTRY = os.environ.get("NPM_REGISTRY", "https://registry.npmjs.org/")
NPM_TOKEN_SECRET_NAME = os.environ.get("NPM_TOKEN_SECRET_NAME", "sideloader-npm-token")
NPM_TOKEN_EXPIRATION_DAYS = int(os.environ.get("NPM_TOKEN_EXPIRATION_DAYS", "90"))
NPM_TOKEN_EXPIRY_BUFFER_SECONDS = int(
    os.environ.get("NPM_TOKEN_EXPIRY_BUFFER_SECONDS", "600")
)

SERVICE_ACCOUNT_TOKEN_FILE = Path("/var/run/secrets/kubernetes.io/serviceaccount/token")
SERVICE_ACCOUNT_CA_FILE = Path("/var/run/secrets/kubernetes.io/serviceaccount/ca.crt")
SERVICE_ACCOUNT_NAMESPACE_FILE = Path(
    "/var/run/secrets/kubernetes.io/serviceaccount/namespace"
)

# npm email OTPs are typically numeric and can vary by length.
OTP_PATTERN = re.compile(r"\b(\d{6,8})\b")
TOKEN_PATTERN = re.compile(r"\bnpm_[A-Za-z0-9]{20,}\b")


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _to_iso8601(value: datetime) -> str:
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat()


def _parse_iso8601(value: str) -> Optional[datetime]:
    if not value:
        return None
    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = f"{normalized[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _decode_secret_data(data: dict, key: str) -> str:
    encoded_value = data.get(key, "")
    if not encoded_value:
        return ""
    try:
        return base64.b64decode(encoded_value).decode("utf-8")
    except Exception:
        return ""


def _mask_token(token: str) -> str:
    if not token:
        return ""
    if len(token) <= 12:
        return token[:2] + "***"
    return f"{token[:6]}...{token[-4:]}"


def _render_secret_yaml(
    secret_name: str,
    namespace: str,
    token: str,
    created_at: str,
    expires_at: str,
) -> str:
    return "\n".join(
        [
            "apiVersion: v1",
            "kind: Secret",
            "metadata:",
            f"  name: {secret_name}",
            f"  namespace: {namespace}",
            "type: Opaque",
            "stringData:",
            f"  token: {json.dumps(token)}",
            f"  created_at: {json.dumps(created_at)}",
            f"  expires_at: {json.dumps(expires_at)}",
        ]
    )


def _bool_env(var_name: str, default: bool) -> bool:
    value = os.environ.get(var_name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


def _playwright_debug_enabled() -> bool:
    return _bool_env("NPM_PLAYWRIGHT_DEBUG", True)


def _playwright_log(message: str):
    if _playwright_debug_enabled():
        print(f"[npm-playwright] {message}")


async def _capture_debug_screenshot(page, label: str) -> Optional[Path]:
    if not _playwright_debug_enabled():
        return None

    screenshot_dir = Path(
        os.environ.get("NPM_PLAYWRIGHT_DEBUG_DIR", "/tmp")
    ).expanduser()
    try:
        screenshot_dir.mkdir(parents=True, exist_ok=True)
        output_path = screenshot_dir / (
            f"npm-playwright-{label}-{int(time.time() * 1000)}.png"
        )
        await page.screenshot(path=str(output_path), full_page=True)
        return output_path
    except Exception:
        return None


@contextmanager
def _maybe_virtual_framebuffer(headless: bool):
    """
    Start Xvfb when explicitly requested for non-headless mode.

    Useful in CI/Kubernetes where no real display server exists.
    """
    use_xvfb = _bool_env("NPM_PLAYWRIGHT_USE_XVFB", False)
    if headless or not use_xvfb:
        yield
        return

    existing_display = os.environ.get("DISPLAY", "").strip()
    if existing_display:
        _playwright_log(
            "DISPLAY already set "
            f"({existing_display}); skipping internal Xvfb startup"
        )
        yield
        return

    xvfb_binary = os.environ.get("NPM_XVFB_BIN", "Xvfb")
    xvfb_path = shutil.which(xvfb_binary)
    if not xvfb_path:
        raise RuntimeError(
            "NPM_PLAYWRIGHT_USE_XVFB=true but Xvfb was not found in PATH"
        )

    display_name = os.environ.get("NPM_XVFB_DISPLAY", ":99")
    screen_spec = os.environ.get("NPM_XVFB_SCREEN", "1920x1080x24")
    command = [
        xvfb_path,
        display_name,
        "-screen",
        "0",
        screen_spec,
        "-nolisten",
        "tcp",
        "-ac",
    ]

    process = subprocess.Popen(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    previous_display = os.environ.get("DISPLAY")
    os.environ["DISPLAY"] = display_name

    try:
        _playwright_log(f"Starting Xvfb on {display_name} with screen {screen_spec}")
        time.sleep(0.3)
        if process.poll() is not None:
            raise RuntimeError(
                f"Failed to start Xvfb process (binary={xvfb_path}, display={display_name})"
            )
        yield
    finally:
        if previous_display is None:
            os.environ.pop("DISPLAY", None)
        else:
            os.environ["DISPLAY"] = previous_display

        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
        _playwright_log("Stopped Xvfb")


def _read_service_account_namespace() -> Optional[str]:
    try:
        if SERVICE_ACCOUNT_NAMESPACE_FILE.exists():
            namespace = SERVICE_ACCOUNT_NAMESPACE_FILE.read_text(
                encoding="utf-8"
            ).strip()
            if namespace:
                return namespace
    except Exception:
        return None
    return None


class KubernetesSecretTokenCache:
    """Small helper for reading/writing token data in a Kubernetes secret."""

    def __init__(self, secret_name: str = NPM_TOKEN_SECRET_NAME):
        self.secret_name = secret_name
        self.namespace = (
            os.environ.get("NPM_TOKEN_SECRET_NAMESPACE")
            or _read_service_account_namespace()
            or os.environ.get("NAMESPACE")
            or "default"
        )
        host = os.environ.get("KUBERNETES_SERVICE_HOST", "").strip()
        port = os.environ.get("KUBERNETES_SERVICE_PORT_HTTPS", "443").strip() or "443"
        self.api_base = f"https://{host}:{port}" if host else ""

    def is_available(self) -> bool:
        return bool(self.api_base and SERVICE_ACCOUNT_TOKEN_FILE.exists())

    def _build_headers(
        self, extra_headers: Optional[dict[str, str]] = None
    ) -> dict[str, str]:
        token = SERVICE_ACCOUNT_TOKEN_FILE.read_text(encoding="utf-8").strip()
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def _verify_target(self):
        if SERVICE_ACCOUNT_CA_FILE.exists():
            return str(SERVICE_ACCOUNT_CA_FILE)
        return False

    @property
    def _secret_url(self) -> str:
        return f"{self.api_base}/api/v1/namespaces/{self.namespace}/secrets/{self.secret_name}"

    @property
    def _namespace_secrets_url(self) -> str:
        return f"{self.api_base}/api/v1/namespaces/{self.namespace}/secrets"

    def _request(
        self,
        method: str,
        url: str,
        payload: Optional[dict] = None,
        extra_headers: Optional[dict[str, str]] = None,
        allow_404: bool = False,
    ) -> Optional[requests.Response]:
        try:
            response = requests.request(
                method,
                url,
                headers=self._build_headers(extra_headers),
                json=payload,
                verify=self._verify_target(),
                timeout=10,
            )
        except Exception as exc:
            print(f"Error communicating with Kubernetes API: {exc}")
            return None

        if allow_404 and response.status_code == 404:
            return response

        if not response.ok:
            print(
                "Kubernetes secret API request failed "
                f"({response.status_code}): {response.text}"
            )
            return None
        return response

    def get_valid_token(
        self,
        expiry_buffer_seconds: int = NPM_TOKEN_EXPIRY_BUFFER_SECONDS,
    ) -> Optional[str]:
        if not self.is_available():
            return None

        response = self._request("GET", self._secret_url, allow_404=True)
        if response is None or response.status_code == 404:
            return None

        payload = response.json()
        data = payload.get("data", {})
        token = _decode_secret_data(data, "token")
        expires_at_raw = _decode_secret_data(data, "expires_at")

        if not token or not expires_at_raw:
            return None

        expires_at = _parse_iso8601(expires_at_raw)
        if not expires_at:
            return None

        if expires_at <= _utc_now() + timedelta(seconds=expiry_buffer_seconds):
            return None

        return token

    def get_token_info(self) -> Optional[dict[str, str | bool]]:
        """Return decoded token metadata from cache secret, if present."""
        if not self.is_available():
            return None

        response = self._request("GET", self._secret_url, allow_404=True)
        if response is None or response.status_code == 404:
            return None

        payload = response.json()
        data = payload.get("data", {})
        token = _decode_secret_data(data, "token")
        created_at_raw = _decode_secret_data(data, "created_at")
        expires_at_raw = _decode_secret_data(data, "expires_at")

        created_at = _parse_iso8601(created_at_raw)
        expires_at = _parse_iso8601(expires_at_raw)
        is_valid = bool(
            token
            and expires_at
            and expires_at
            > _utc_now() + timedelta(seconds=NPM_TOKEN_EXPIRY_BUFFER_SECONDS)
        )

        return {
            "token": token,
            "created_at": _to_iso8601(created_at) if created_at else "",
            "expires_at": _to_iso8601(expires_at) if expires_at else "",
            "is_valid": is_valid,
        }

    def store_token(
        self, token: str, expires_at: datetime, created_at: datetime
    ) -> bool:
        if not self.is_available():
            return False

        string_data = {
            "token": token,
            "created_at": _to_iso8601(created_at),
            "expires_at": _to_iso8601(expires_at),
        }

        existing = self._request("GET", self._secret_url, allow_404=True)
        if existing is None:
            return False

        if existing.status_code == 404:
            create_payload = {
                "apiVersion": "v1",
                "kind": "Secret",
                "metadata": {
                    "name": self.secret_name,
                    "namespace": self.namespace,
                    "labels": {
                        "app": "sideload",
                    },
                    "annotations": {
                        "sideload.io/token-created-at": _to_iso8601(created_at),
                        "sideload.io/token-expires-at": _to_iso8601(expires_at),
                    },
                },
                "type": "Opaque",
                "stringData": string_data,
            }
            return (
                self._request(
                    "POST",
                    self._namespace_secrets_url,
                    payload=create_payload,
                )
                is not None
            )

        patch_payload = {
            "metadata": {
                "annotations": {
                    "sideload.io/token-created-at": _to_iso8601(created_at),
                    "sideload.io/token-expires-at": _to_iso8601(expires_at),
                }
            },
            "stringData": string_data,
        }
        return (
            self._request(
                "PATCH",
                self._secret_url,
                payload=patch_payload,
                extra_headers={"Content-Type": "application/merge-patch+json"},
            )
            is not None
        )


def _extract_text_candidates(message: email.message.Message) -> list[str]:
    values: list[str] = []

    if message.is_multipart():
        for part in message.walk():
            content_type = (part.get_content_type() or "").lower()
            if content_type not in {"text/plain", "text/html"}:
                continue
            payload = part.get_payload(decode=True)
            if payload is None:
                continue
            charset = part.get_content_charset() or "utf-8"
            values.append(payload.decode(charset, errors="replace"))
        return values

    payload = message.get_payload(decode=True)
    if payload is not None:
        charset = message.get_content_charset() or "utf-8"
        values.append(payload.decode(charset, errors="replace"))
    return values


def _extract_otp_from_message(
    message: email.message.Message,
    sent_after: datetime,
) -> Optional[str]:
    message_date = message.get("Date", "")
    try:
        parsed_date = parsedate_to_datetime(message_date)
        if parsed_date.tzinfo is None:
            parsed_date = parsed_date.replace(tzinfo=timezone.utc)
        if parsed_date.astimezone(timezone.utc) < sent_after:
            return None
    except Exception:
        # If parsing fails, continue and inspect the body.
        pass

    for body_text in _extract_text_candidates(message):
        match = OTP_PATTERN.search(body_text)
        if match:
            return match.group(1)

    return None


def wait_for_mail_otp(timeout_seconds: int = 180) -> Optional[str]:
    """Poll an IMAP mailbox for npm OTP email and extract the numeric OTP code."""

    imap_host = os.environ.get("NPM_OTP_EMAIL_IMAP_HOST", "").strip()
    imap_port = int(os.environ.get("NPM_OTP_EMAIL_IMAP_PORT", "993"))
    imap_username = os.environ.get("NPM_OTP_EMAIL_USERNAME", "").strip()
    imap_password = os.environ.get("NPM_OTP_EMAIL_PASSWORD", "").strip()
    imap_folder = os.environ.get("NPM_OTP_EMAIL_FOLDER", "INBOX").strip() or "INBOX"
    sender_filter = os.environ.get("NPM_OTP_EMAIL_FROM", "support@npmjs.com").strip()
    subject_filter = os.environ.get(
        "NPM_OTP_EMAIL_SUBJECT", "Your npm one-time password"
    ).strip()
    poll_interval_seconds = max(
        2,
        int(os.environ.get("NPM_OTP_POLL_INTERVAL_SECONDS", "5")),
    )

    if not imap_host or not imap_username or not imap_password:
        print(
            "Missing IMAP configuration (NPM_OTP_EMAIL_IMAP_HOST/USERNAME/PASSWORD), "
            "cannot read npm OTP email"
        )
        return None

    start_time = _utc_now() - timedelta(minutes=2)
    deadline = time.monotonic() + timeout_seconds

    while time.monotonic() < deadline:
        try:
            with imaplib.IMAP4_SSL(imap_host, imap_port) as mailbox:
                mailbox.login(imap_username, imap_password)
                mailbox.select(imap_folder)

                search_args = ["UNSEEN", "SINCE", start_time.strftime("%d-%b-%Y")]
                if sender_filter:
                    search_args.extend(["FROM", f'"{sender_filter}"'])
                if subject_filter:
                    search_args.extend(["SUBJECT", f'"{subject_filter}"'])

                status, search_data = mailbox.search(None, *search_args)
                if status != "OK":
                    raise RuntimeError(f"imap search failed: {search_data}")

                message_ids = search_data[0].split()
                for message_id in reversed(message_ids[-15:]):
                    fetch_status, message_data = mailbox.fetch(message_id, "(RFC822)")
                    if fetch_status != "OK":
                        continue

                    for part in message_data:
                        if not isinstance(part, tuple) or len(part) < 2:
                            continue
                        message = email.message_from_bytes(
                            part[1], policy=policy.default
                        )
                        otp_code = _extract_otp_from_message(message, start_time)
                        if otp_code:
                            return otp_code

        except Exception as exc:
            print(f"Error while checking mailbox for npm OTP: {exc}")

        time.sleep(poll_interval_seconds)

    return None


async def _fill_first(
    page, selectors: list[str], value: str, timeout_ms: int = 4000
) -> bool:
    for selector in selectors:
        locator = page.locator(selector).first
        try:
            if await locator.count() == 0:
                continue
            await locator.fill(value, timeout=timeout_ms)
            return True
        except Exception:
            continue
    return False


async def _click_first(page, selectors: list[str], timeout_ms: int = 4000) -> bool:
    for selector in selectors:
        locator = page.locator(selector).first
        try:
            if await locator.count() == 0:
                continue
            await locator.click(timeout=timeout_ms)
            return True
        except Exception:
            continue
    return False


async def _check_first(page, selectors: list[str], timeout_ms: int = 4000) -> bool:
    for selector in selectors:
        locator = page.locator(selector).first
        try:
            if await locator.count() == 0:
                continue
            try:
                await locator.check(timeout=timeout_ms, force=True)
            except Exception:
                await locator.click(timeout=timeout_ms, force=True)
            return True
        except Exception:
            continue
    return False


async def _get_first_text(page, selectors: list[str]) -> str:
    for selector in selectors:
        locator = page.locator(selector).first
        try:
            if await locator.count() == 0:
                continue
            return ((await locator.inner_text()) or "").strip()
        except Exception:
            continue
    return ""


async def _select_dropdown_option(
    page,
    trigger_selectors: list[str],
    option_selectors: list[str],
    expected_text: str = "",
    timeout_ms: int = 4000,
) -> bool:
    # Option might already be visible/selected.
    if await _click_first(page, option_selectors, timeout_ms=1000):
        return True

    for trigger in trigger_selectors:
        trigger_locator = page.locator(trigger).first
        try:
            if await trigger_locator.count() == 0:
                continue
            await trigger_locator.click(timeout=timeout_ms, force=True)
            await page.wait_for_timeout(300)
            if await _click_first(page, option_selectors, timeout_ms=timeout_ms):
                return True
        except Exception:
            continue

    if expected_text:
        summary_text = await _get_first_text(page, trigger_selectors)
        if expected_text.lower() in summary_text.lower():
            return True

    return False


async def _has_any_selector(page, selectors: list[str]) -> bool:
    for selector in selectors:
        try:
            if await page.locator(selector).count() > 0:
                return True
        except Exception:
            continue
    return False


async def _wait_for_any_selector(
    page,
    selectors: list[str],
    timeout_ms: int = 15000,
) -> bool:
    deadline = time.monotonic() + (timeout_ms / 1000.0)
    while time.monotonic() < deadline:
        if await _has_any_selector(page, selectors):
            return True
        await page.wait_for_timeout(250)
    return False


async def _detect_cloudflare_challenge(page) -> tuple[bool, str]:
    cloudflare_markers = [
        "text=Performing security verification",
        "text=Verify you are human",
        "text=Ray ID",
        "text=Cloudflare",
        "iframe[src*='challenges.cloudflare.com']",
        "iframe[title*='challenge']",
        "input[name='cf-turnstile-response']",
    ]
    if await _has_any_selector(page, cloudflare_markers):
        return True, "cloudflare-marker"

    try:
        page_url = (page.url or "").lower()
    except Exception:
        page_url = ""
    if "cloudflare" in page_url or "cf-chl" in page_url:
        return True, "cloudflare-url"

    try:
        page_title = ((await page.title()) or "").lower()
    except Exception:
        page_title = ""
    if "cloudflare" in page_title:
        return True, "cloudflare-title"

    try:
        html = (await page.content()).lower()
    except Exception:
        html = ""
    if "cloudflare" in html and (
        "security verification" in html or "verify you are human" in html
    ):
        return True, "cloudflare-html"

    return False, ""


async def _detect_bot_challenge(page) -> tuple[bool, str]:
    challenge_markers = [
        "text=Checking your browser",
        "text=Please verify you are human",
        "text=Just a moment",
        "text=Enable JavaScript and cookies to continue",
        "iframe[title*='challenge']",
    ]
    if await _has_any_selector(page, challenge_markers):
        return True, "generic-marker"

    cloudflare_detected, cloudflare_reason = await _detect_cloudflare_challenge(page)
    if cloudflare_detected:
        return True, f"cloudflare:{cloudflare_reason}"

    try:
        page_title = ((await page.title()) or "").lower()
    except Exception:
        page_title = ""
    if (
        "just a moment" in page_title
        or "attention required" in page_title
        or "checking your browser" in page_title
    ):
        return True, "generic-title"

    return False, ""


async def _extract_token_from_page(page) -> Optional[str]:
    candidate_selectors = [
        "input[readonly]",
        "input[type='text']",
        "code",
        "pre",
        "textarea",
        "p",
        "div",
    ]

    for selector in candidate_selectors:
        locator = page.locator(selector)
        try:
            count = min(await locator.count(), 30)
        except Exception:
            continue

        for idx in range(count):
            item = locator.nth(idx)
            values: list[str] = []
            try:
                values.append(await item.input_value())
            except Exception:
                pass
            try:
                values.append((await item.inner_text()) or "")
            except Exception:
                pass

            for value in values:
                token_match = TOKEN_PATTERN.search(value or "")
                if token_match:
                    return token_match.group(0)

    try:
        html = await page.content()
        token_match = TOKEN_PATTERN.search(html)
        if token_match:
            return token_match.group(0)
    except Exception:
        return None

    return None


async def _generate_npm_token_with_playwright_async(
    username: str,
    password: str,
    expiration_days: int,
) -> Optional[str]:
    from playwright.async_api import async_playwright

    headless = _bool_env("NPM_PLAYWRIGHT_HEADLESS", True)
    otp_timeout_seconds = int(os.environ.get("NPM_OTP_TIMEOUT_SECONDS", "180"))
    login_form_timeout_ms = int(
        os.environ.get("NPM_LOGIN_FORM_TIMEOUT_SECONDS", "25")
    ) * 1000
    navigation_timeout_ms = int(
        os.environ.get("NPM_NAVIGATION_TIMEOUT_SECONDS", "60")
    ) * 1000
    token_label = (
        os.environ.get("NPM_TOKEN_LABEL", "sideloader-token").strip()
        or "sideloader-token"
    )
    token_name = f"{token_label}-{int(time.time())}"
    expires_on = (_utc_now() + timedelta(days=expiration_days)).date().isoformat()

    username_selectors = [
        "input[name='username']",
        "input[name='user']",
        "input[type='email']",
    ]
    password_selectors = [
        "input[name='password']",
        "input[type='password']",
    ]
    login_submit_selectors = [
        "button[type='submit']",
        "button:has-text('Sign In')",
        "button:has-text('Log In')",
    ]
    otp_input_selectors = [
        "input[name='otp']",
        "input[name='one-time-password']",
        "input[autocomplete='one-time-code']",
        "input[inputmode='numeric']",
    ]
    otp_submit_selectors = [
        "button[type='submit']",
        "button:has-text('Verify')",
        "button:has-text('Continue')",
    ]
    new_token_selectors = [
        "a:has-text('Generate New Token')",
        "button:has-text('Generate New Token')",
        "button:has-text('Create Token')",
        "a:has-text('Create Token')",
    ]
    token_name_selectors = [
        "input[name='tokenName']",
        "input[name='name']",
        "input[id='create-gat_name']",
        "input[id*='token']",
        "input[placeholder*='name']",
    ]
    bypass_2fa_checkbox_selectors = [
        "#create-gat_bypass2FA",
        "input[id='create-gat_bypass2FA']",
    ]
    permission_dropdown_trigger_selectors = [
        "summary[aria-labelledby*='create-gat_packagesAndScopesPermission_label']",
        "div:has(#create-gat_packagesAndScopesPermission_label) summary",
        "summary:has-text('No access')",
        "summary:has-text('Read only')",
        "summary:has-text('Read and write')",
    ]
    read_write_permission_selectors = [
        "input[type='radio'][value='read-and-write']",
        "input[type='radio'][value='read_write']",
        "input[type='radio'][value='readWrite']",
        "input[type='radio'][value='rw']",
        "input[type='radio'][name*='permission'][value*='write']",
        "button[role='menuitemcheckbox']:has-text('Read and write')",
        "button[role='menuitemradio']:has-text('Read and write')",
        "button:has(span:has-text('Read and write'))",
        "label:has-text('Read and write')",
    ]
    all_packages_radio_selectors = [
        "input[type='radio'][value='all-packages']",
        "input[type='radio'][value='all_packages']",
        "input[type='radio'][value='all']",
        "input[type='radio'][name*='package'][value*='all']",
        "input[id*='all-packages']",
        "label[for*='all-packages']",
        "button[role='radio']:has-text('All packages')",
        "button[role='menuitemradio']:has-text('All packages')",
        "label:has-text('All packages')",
    ]
    token_expiration_selectors = [
        "select[name='expiration']",
        "select[name='expires']",
        "select[id*='expir']",
    ]
    expiration_date_input_selectors = [
        "input[type='date'][name*='expir']",
        "input[type='date'][id*='expir']",
        "input[type='date'][name*='expire']",
    ]
    token_generate_selectors = [
        "button:has-text('Generate Token')",
        "button:has-text('Create token')",
        "button:has-text('Create Token')",
        "button:has-text('Generate')",
    ]

    with _maybe_virtual_framebuffer(headless=headless):
        async with async_playwright() as playwright:
            _playwright_log(
                "Launching Chromium "
                f"(headless={headless}, nav_timeout_ms={navigation_timeout_ms}, "
                f"login_form_timeout_ms={login_form_timeout_ms})"
            )
            browser = await playwright.chromium.launch(headless=headless)
            context = await browser.new_context()
            page = await context.new_page()
            page.set_default_navigation_timeout(navigation_timeout_ms)
            page.set_default_timeout(max(login_form_timeout_ms, 10000))

            try:
                _playwright_log("Navigating to npm login page")
                await page.goto(
                    "https://www.npmjs.com/login",
                    wait_until="domcontentloaded",
                    timeout=navigation_timeout_ms,
                )

                if not await _wait_for_any_selector(
                    page, username_selectors, timeout_ms=login_form_timeout_ms
                ):
                    # Retry once with load wait; networkidle can hang on npm pages.
                    _playwright_log(
                        "Username input not visible after first load, retrying login page"
                    )
                    await page.goto(
                        "https://www.npmjs.com/login",
                        wait_until="load",
                        timeout=navigation_timeout_ms,
                    )
                    if not await _wait_for_any_selector(
                        page, username_selectors, timeout_ms=login_form_timeout_ms
                    ):
                        challenge_detected, challenge_reason = await _detect_bot_challenge(
                            page
                        )
                        if challenge_detected:
                            screenshot_path = await _capture_debug_screenshot(
                                page, "challenge-login"
                            )
                            if screenshot_path:
                                _playwright_log(
                                    f"Saved challenge screenshot: {screenshot_path}"
                                )
                            raise RuntimeError(
                                "npm login page appears to be presenting a bot/challenge page "
                                f"({challenge_reason}) "
                                "in headless mode; retry with NPM_PLAYWRIGHT_HEADLESS=false "
                                "or use NPM_PLAYWRIGHT_USE_XVFB=true"
                            )
                        screenshot_path = await _capture_debug_screenshot(
                            page, "login-missing-username"
                        )
                        if screenshot_path:
                            _playwright_log(
                                f"Saved login failure screenshot: {screenshot_path}"
                            )
                        raise RuntimeError("Could not find npm username input field")

                _playwright_log("Login form detected, filling credentials")
                if not await _fill_first(page, username_selectors, username):
                    raise RuntimeError("Could not find npm username input field")
                if not await _fill_first(page, password_selectors, password):
                    raise RuntimeError("Could not find npm password input field")

                _playwright_log("Submitting login form")
                if not await _click_first(page, login_submit_selectors):
                    raise RuntimeError("Could not submit npm login form")

                await page.wait_for_timeout(2500)

                if await _has_any_selector(page, otp_input_selectors):
                    _playwright_log("OTP field detected, waiting for npm OTP email")
                    otp_code = wait_for_mail_otp(timeout_seconds=otp_timeout_seconds)
                    if not otp_code:
                        raise RuntimeError("Timed out waiting for npm OTP email")
                    if not await _fill_first(page, otp_input_selectors, otp_code):
                        raise RuntimeError("Could not fill npm OTP input")
                    if not await _click_first(page, otp_submit_selectors):
                        raise RuntimeError("Could not submit npm OTP form")
                    await page.wait_for_timeout(2500)

                tokens_new_url = os.environ.get(
                    "NPM_TOKENS_NEW_URL",
                    f"https://www.npmjs.com/settings/{username}/tokens/granular-access-tokens/new",
                )
                _playwright_log(f"Navigating to token creation page: {tokens_new_url}")
                await page.goto(
                    tokens_new_url,
                    wait_until="domcontentloaded",
                    timeout=navigation_timeout_ms,
                )
                await page.wait_for_timeout(1500)

                if not await _has_any_selector(page, token_name_selectors):
                    challenge_detected, challenge_reason = await _detect_bot_challenge(
                        page
                    )
                    if challenge_detected:
                        screenshot_path = await _capture_debug_screenshot(
                            page, "challenge-token-create"
                        )
                        if screenshot_path:
                            _playwright_log(
                                f"Saved challenge screenshot: {screenshot_path}"
                            )
                        raise RuntimeError(
                            "npm token page appears to be blocked by a bot/challenge "
                            f"({challenge_reason})"
                        )
                    tokens_url = os.environ.get(
                        "NPM_TOKENS_URL",
                        f"https://www.npmjs.com/settings/{username}/tokens",
                    )
                    _playwright_log(
                        "Token form missing, falling back to tokens list page"
                    )
                    await page.goto(
                        tokens_url,
                        wait_until="domcontentloaded",
                        timeout=navigation_timeout_ms,
                    )
                    await page.wait_for_timeout(1500)
                    if not await _click_first(
                        page, new_token_selectors, timeout_ms=2500
                    ):
                        raise RuntimeError("Could not open npm new token form")
                    await page.wait_for_timeout(1200)

                if not await _fill_first(
                    page, token_name_selectors, token_name, timeout_ms=2500
                ):
                    raise RuntimeError("Could not set npm token name")
                _playwright_log("Token name set")

                if not await _check_first(
                    page, bypass_2fa_checkbox_selectors, timeout_ms=2500
                ):
                    raise RuntimeError("Could not tick bypass-2FA checkbox")
                _playwright_log("Bypass 2FA checkbox selected")

                if not await _select_dropdown_option(
                    page,
                    permission_dropdown_trigger_selectors,
                    read_write_permission_selectors,
                    expected_text="Read and write",
                    timeout_ms=2500,
                ):
                    screenshot_path = await _capture_debug_screenshot(
                        page, "permissions-selection-failed"
                    )
                    if screenshot_path:
                        _playwright_log(
                            f"Saved permissions failure screenshot: {screenshot_path}"
                        )
                    raise RuntimeError("Could not select 'Read and write' permission")
                _playwright_log("'Read and write' permission selected")

                await page.wait_for_timeout(600)
                if not (
                    await _check_first(
                        page, all_packages_radio_selectors, timeout_ms=2500
                    )
                    or await _click_first(
                        page, all_packages_radio_selectors, timeout_ms=2500
                    )
                ):
                    raise RuntimeError("Could not select 'All packages'")
                _playwright_log("'All packages' selected")

                for selector in token_expiration_selectors:
                    select = page.locator(selector).first
                    try:
                        if await select.count() == 0:
                            continue
                        try:
                            await select.select_option(label="90 days", timeout=2000)
                        except Exception:
                            for option_value in ["90", "90d", "P90D"]:
                                try:
                                    await select.select_option(
                                        value=option_value, timeout=1000
                                    )
                                    break
                                except Exception:
                                    continue
                        break
                    except Exception:
                        continue

                await _fill_first(
                    page,
                    expiration_date_input_selectors,
                    expires_on,
                    timeout_ms=1500,
                )

                if not await _click_first(
                    page, token_generate_selectors, timeout_ms=3000
                ):
                    raise RuntimeError("Could not submit npm token generation form")
                _playwright_log("Submitted token generation form")

                await page.wait_for_timeout(3500)

                generated_token = await _extract_token_from_page(page)
                if not generated_token:
                    screenshot_path = await _capture_debug_screenshot(
                        page, "token-extraction-failed"
                    )
                    if screenshot_path:
                        _playwright_log(
                            f"Saved token extraction screenshot: {screenshot_path}"
                        )
                    raise RuntimeError(
                        "Token was generated but could not be extracted from page"
                    )

                _playwright_log("Token extracted successfully")
                return generated_token
            finally:
                await context.close()
                await browser.close()


def generate_npm_token(
    username: Optional[str] = None,
    password: Optional[str] = None,
    expiration_days: int = NPM_TOKEN_EXPIRATION_DAYS,
) -> Optional[str]:
    """
    Generate a new npm token through Playwright browser automation.

    This flow supports npm's email-based OTP path by polling a configured IMAP mailbox.
    """
    npm_username = (username or os.environ.get("NPM_USER") or "").strip()
    npm_password = (password or os.environ.get("NPM_PASSWORD") or "").strip()

    if not npm_username or not npm_password:
        print("NPM_USER and NPM_PASSWORD are required to regenerate npm token")
        return None

    try:
        return asyncio.run(
            _generate_npm_token_with_playwright_async(
                npm_username,
                npm_password,
                expiration_days,
            )
        )
    except Exception as exc:
        print(f"Error generating npm token with Playwright: {exc}")
        return None


def get_or_generate_token() -> Optional[str]:
    """Get a valid npm token from Kubernetes cache, or regenerate and re-cache it."""

    cache = KubernetesSecretTokenCache()
    env_token = os.environ.get("NPM_TOKEN", "").strip()

    if cache.is_available():
        cached_token = cache.get_valid_token()
        if cached_token:
            return cached_token

        generated_token = generate_npm_token(expiration_days=NPM_TOKEN_EXPIRATION_DAYS)
        if generated_token:
            now = _utc_now()
            cache.store_token(
                generated_token,
                created_at=now,
                expires_at=now + timedelta(days=NPM_TOKEN_EXPIRATION_DAYS),
            )
            return generated_token

        if env_token:
            now = _utc_now()
            cache.store_token(
                env_token,
                created_at=now,
                expires_at=now + timedelta(days=NPM_TOKEN_EXPIRATION_DAYS),
            )
            print(
                "Using NPM_TOKEN from environment as fallback and refreshing cache metadata"
            )
            return env_token

        print("No valid npm token in Kubernetes secret and regeneration failed")
        return None

    if env_token:
        return env_token

    generated_token = generate_npm_token(expiration_days=NPM_TOKEN_EXPIRATION_DAYS)
    if generated_token:
        return generated_token

    print("No npm token available (NPM_TOKEN missing and generation failed)")
    return None


def dry_run_npm_token(force_regenerate: bool = False) -> bool:
    """
    Dry-run helper for npm token cache behavior.

    It validates cache state, optionally forces regeneration, and prints outcomes.
    """
    cache = KubernetesSecretTokenCache()
    print("NPM token dry-run")
    print(f"  Secret cache: {cache.secret_name} (namespace={cache.namespace})")
    print(f"  Kubernetes cache available: {'yes' if cache.is_available() else 'no'}")

    initial_info = cache.get_token_info() if cache.is_available() else None
    if initial_info:
        print(f"  Cached token: {_mask_token(str(initial_info.get('token', '')))}")
        print(f"  Cached created_at: {initial_info.get('created_at') or 'unset'}")
        print(f"  Cached expires_at: {initial_info.get('expires_at') or 'unset'}")
        print(
            "  Cached token valid: "
            f"{'yes' if bool(initial_info.get('is_valid')) else 'no'}"
        )
    else:
        print("  No token currently stored in cache secret")

    token: Optional[str] = None

    if force_regenerate:
        print("  Forcing regeneration flow...")
        token = generate_npm_token(expiration_days=NPM_TOKEN_EXPIRATION_DAYS)
        if not token:
            token = os.environ.get("NPM_TOKEN", "").strip()
            if token:
                print("  Regeneration failed, falling back to NPM_TOKEN env var")
            else:
                print("  Regeneration failed and no NPM_TOKEN fallback available")
                return False

        if cache.is_available():
            now = _utc_now()
            if cache.store_token(
                token,
                created_at=now,
                expires_at=now + timedelta(days=NPM_TOKEN_EXPIRATION_DAYS),
            ):
                print("  Cache secret updated")
            else:
                print("  Failed to update cache secret")
                return False
    else:
        print("  Running standard get_or_generate flow...")
        token = get_or_generate_token()
        if not token:
            print("  get_or_generate_token returned no token")
            return False

    print(f"  Effective token: {_mask_token(token)}")

    final_info = cache.get_token_info() if cache.is_available() else None
    if final_info:
        print(f"  Final cache created_at: {final_info.get('created_at') or 'unset'}")
        print(f"  Final cache expires_at: {final_info.get('expires_at') or 'unset'}")
        print(
            "  Final cache valid: "
            f"{'yes' if bool(final_info.get('is_valid')) else 'no'}"
        )

    token_for_yaml = ""
    created_at_for_yaml = ""
    expires_at_for_yaml = ""
    if final_info and final_info.get("token"):
        token_for_yaml = str(final_info.get("token") or "")
        created_at_for_yaml = str(final_info.get("created_at") or "")
        expires_at_for_yaml = str(final_info.get("expires_at") or "")

    if not token_for_yaml and token:
        now = _utc_now()
        token_for_yaml = token
        created_at_for_yaml = _to_iso8601(now)
        expires_at_for_yaml = _to_iso8601(
            now + timedelta(days=NPM_TOKEN_EXPIRATION_DAYS)
        )

    if token_for_yaml:
        yaml_manifest = _render_secret_yaml(
            secret_name=cache.secret_name,
            namespace=cache.namespace,
            token=token_for_yaml,
            created_at=created_at_for_yaml,
            expires_at=expires_at_for_yaml,
        )
        print("  Secret YAML (create manually if needed):")
        print("-----BEGIN-NPM-TOKEN-SECRET-YAML-----")
        print(yaml_manifest)
        print("-----END-NPM-TOKEN-SECRET-YAML-----")
    else:
        print("  Secret YAML could not be generated (no token value available)")

    print("  Dry-run completed successfully")
    return True
