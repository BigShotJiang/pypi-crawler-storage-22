"""NPM package build and publish utilities."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from sideloader.adapters.npm.token_generator import get_or_generate_token


NPM_REGISTRY = os.environ.get("NPM_REGISTRY", "https://registry.npmjs.org/")


def _ensure_npm_available() -> bool:
    if shutil.which("npm"):
        return True
    print("npm CLI is not installed in this runtime image (missing `npm` binary)")
    return False


def package_build(
    directory: Path,
    package_name: str,
    data_file: str,
    package_version: str,
    package_tag: str,
) -> bool:
    """
    Create an npm package structure in the specified directory.

    Args:
        directory: Directory containing the data file
        package_name: Existing npm package name to publish into
        data_file: Name of the data file to include
        package_version: Exact semver version to publish
        package_tag: Dist-tag used to fetch this version later

    Returns:
        True if successful, False otherwise
    """
    try:
        package_json = {
            "name": package_name,
            "version": package_version,
            "description": f"Sideloaded payload ({package_tag})",
            "main": "index.js",
            "files": [data_file, "index.js"],
            "author": "Null Void",
            "license": "ISC",
        }

        package_json_path = directory / "package.json"
        with open(package_json_path, "w", encoding="utf-8") as file_handle:
            json.dump(package_json, file_handle, indent=2)
            file_handle.write("\n")

        index_js_path = directory / "index.js"
        with open(index_js_path, "w", encoding="utf-8") as file_handle:
            file_handle.write(f'module.exports = {{ dataFile: "{data_file}" }};\n')

        return True
    except Exception as exc:
        print(f"Error creating npm package structure: {exc}")
        return False


def _write_npmrc(directory: Path, npm_token: str) -> Path:
    npmrc_path = directory / ".npmrc"
    registry_url = NPM_REGISTRY.rstrip("/")
    if "://" in registry_url:
        registry_host = registry_url.split("://", 1)[1].rstrip("/")
    else:
        registry_host = registry_url.rstrip("/")

    with open(npmrc_path, "w", encoding="utf-8") as file_handle:
        file_handle.write(f"registry={registry_url}/\n")
        file_handle.write(f"//{registry_host}/:_authToken={npm_token}\n")
        file_handle.write("always-auth=true\n")

    return npmrc_path


def npm_publish(directory: Path, dist_tag: str) -> bool:
    """
    Publish a package to npm with a dedicated dist-tag.

    Args:
        directory: Directory containing the package.json
        dist_tag: Dist-tag to attach to this publish

    Returns:
        True if successful, False otherwise
    """
    try:
        if not _ensure_npm_available():
            return False

        npm_token = get_or_generate_token()
        if not npm_token:
            print("No npm token available, publish aborted")
            return False

        _write_npmrc(directory, npm_token)

        result = subprocess.run(
            ["npm", "publish", "--access=public", "--tag", dist_tag],
            cwd=str(directory),
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            stderr_output = result.stderr.strip() if result.stderr else ""
            stdout_output = result.stdout.strip() if result.stdout else ""
            details = stderr_output or stdout_output or "unknown error"
            print(f"npm publish failed: {details}")
            return False

        return True
    except Exception as exc:
        print(f"Error publishing to npm: {exc}")
        return False
