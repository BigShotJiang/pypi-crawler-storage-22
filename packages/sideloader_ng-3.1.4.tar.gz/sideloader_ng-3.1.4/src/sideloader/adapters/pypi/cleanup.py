"""
PyPI package cleanup via browser automation with Playwright.
Reusable functions for deleting sideload packages from PyPI.
"""

import asyncio
import os
import random

import pyotp
from playwright.async_api import async_playwright, Page


PYPI_USER = os.environ.get("PYPI_USER", "")
PYPI_PASSWORD = os.environ.get("PYPI_PASSWORD", "")
PYPI_TOTP = os.environ.get("PYPI_TOTP", "")

__all__ = [
    "pypi_login",
    "delete_pypi_project",
    "delete_pypi_packages",
    "delete_pypi_packages_sync",
    "PYPI_USER",
    "PYPI_PASSWORD",
    "PYPI_TOTP",
]


async def _human_like_mouse_movement(page: Page):
    """Simulate human-like mouse movements across the page"""
    viewport_size = page.viewport_size
    width = viewport_size.get("width", 1280) if viewport_size else 1280
    height = viewport_size.get("height", 720) if viewport_size else 720

    for _ in range(random.randint(3, 6)):
        x = random.randint(50, width - 50)
        y = random.randint(50, height - 50)
        await page.mouse.move(x, y)
        await asyncio.sleep(random.uniform(0.15, 0.4))


async def pypi_login(page: Page):
    """Log in to PyPI. Handles TOTP if PYPI_TOTP is set."""
    print("🔐 Logging in to PyPI...")
    await page.goto("https://pypi.org/account/login/")

    await page.fill("#username", PYPI_USER)
    await asyncio.sleep(random.uniform(0.2, 0.4))
    await page.fill("#password", PYPI_PASSWORD)
    await asyncio.sleep(random.uniform(0.3, 0.6))

    await page.click('input[type="submit"]')
    await asyncio.sleep(2)

    current_url = page.url
    if "/account/two-factor/" in current_url and PYPI_TOTP:
        print("  🔐 Generating TOTP code...")
        await asyncio.sleep(random.uniform(1.5, 2.5))
        await _human_like_mouse_movement(page)

        totp = pyotp.TOTP(PYPI_TOTP)
        code = totp.now()

        totp_input = await page.query_selector(
            'input[name="totp_value"]'
        ) or await page.query_selector('input[type="text"]')

        if totp_input:
            await totp_input.click()
            await asyncio.sleep(random.uniform(0.4, 0.8))
            for i, char in enumerate(code):
                await totp_input.type(char, delay=random.randint(100, 250))
                await asyncio.sleep(random.uniform(0.1, 0.25))
                if i % 2 == 0:
                    await page.mouse.move(
                        random.randint(200, 600), random.randint(200, 500)
                    )

            await asyncio.sleep(random.uniform(0.8, 1.5))
            await _human_like_mouse_movement(page)

            submit_button = await page.query_selector(
                'button[type="submit"]'
            ) or await page.query_selector('input[type="submit"]')
            if submit_button:
                await submit_button.click()
                await asyncio.sleep(4)

    print("  ✅ Login completed!")


async def delete_pypi_project(page: Page, package_name: str) -> bool:
    """Delete a single project from PyPI using browser automation."""
    try:
        print(f"  🗑️  Deleting {package_name}...")
        settings_url = f"https://pypi.org/manage/project/{package_name}/settings/"
        await page.goto(settings_url)

        title = await page.title()
        if "404" in title or "Not Found" in title:
            print(f"    ⚠️  Project {package_name} not found on PyPI")
            return False

        await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await asyncio.sleep(0.5)

        # Extract exact project name from the page
        exact_project_name = await page.evaluate(
            """() => {
            const labels = Array.from(document.querySelectorAll('label'));
            for (const label of labels) {
                const text = label.textContent;
                if (text && text.includes('confirm by typing the project name')) {
                    const match = text.match(/\\(([^)]+)\\)/);
                    if (match) return match[1];
                }
            }
            const path = window.location.pathname;
            const urlMatch = path.match(/\\/manage\\/project\\/([^\\/]+)/);
            return urlMatch ? decodeURIComponent(urlMatch[1]) : null;
        }"""
        )

        if not exact_project_name:
            exact_project_name = package_name

        # Check all confirmation checkboxes
        checkboxes = await page.query_selector_all('input[type="checkbox"]')
        for checkbox in checkboxes:
            await checkbox.check()

        # Type project name in confirmation field
        confirm_input = await page.query_selector('input[name="confirm_project_name"]')
        if not confirm_input:
            print(f"    ⚠️  Could not find confirmation input for {package_name}")
            return False

        await confirm_input.clear()
        await asyncio.sleep(random.uniform(0.2, 0.5))
        await _human_like_mouse_movement(page)

        for char in exact_project_name:
            await confirm_input.type(char, delay=random.randint(80, 200))
            await asyncio.sleep(random.uniform(0.05, 0.15))

        await asyncio.sleep(random.uniform(1.0, 2.0))
        await _human_like_mouse_movement(page)

        # Click delete button
        delete_link = await page.query_selector('[data-delete-confirm-target="button"]')
        if not delete_link:
            print(f"    ⚠️  Could not find delete button")
            return False

        is_disabled = await delete_link.evaluate(
            '(el) => el.classList.contains("button--disabled") || el.hasAttribute("disabled")'
        )
        if is_disabled:
            print(f"    ⚠️  Delete button is still disabled")
            return False

        box = await delete_link.bounding_box()
        if box:
            target_x = box["x"] + random.uniform(10, box["width"] - 10)
            target_y = box["y"] + random.uniform(10, box["height"] - 10)
            await page.mouse.move(target_x, target_y)
            await asyncio.sleep(random.uniform(0.2, 0.5))

        await delete_link.click()
        await asyncio.sleep(random.uniform(0.5, 1.0))
        await page.wait_for_load_state("networkidle")

        print(f"    ✅ Deleted {package_name} from PyPI")
        return True

    except Exception as e:
        print(f"    ❌ Error deleting {package_name}: {e}")
        return False


async def delete_pypi_packages(package_names: list[str]) -> tuple[int, int]:
    """
    Delete a list of packages from PyPI.

    Returns:
        Tuple of (deleted_count, error_count)
    """
    if not PYPI_USER or not PYPI_PASSWORD:
        print("  ⚠️  PYPI_USER / PYPI_PASSWORD not set, skipping PyPI cleanup")
        return 0, 0

    deleted = 0
    errors = 0

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        try:
            await pypi_login(page)

            for package_name in package_names:
                if await delete_pypi_project(page, package_name):
                    deleted += 1
                else:
                    errors += 1
                # Small delay between deletions
                await asyncio.sleep(random.uniform(1.0, 3.0))
        finally:
            await browser.close()

    return deleted, errors


def delete_pypi_packages_sync(package_names: list[str]) -> tuple[int, int]:
    """Synchronous wrapper for delete_pypi_packages."""
    return asyncio.run(delete_pypi_packages(package_names))
