"""PyPI package build and upload utilities."""

import os
import subprocess
from pathlib import Path


PYPI_TOKEN = os.environ.get("PYPI_TOKEN", "")


def package_build(directory: Path) -> bool:
    """Build a Python wheel package in the specified directory."""
    result = subprocess.run(
        ["python3", "-m", "build", "--wheel"], cwd=str(directory), check=True
    )
    return result.returncode == 0


def twine_upload(directory: Path) -> bool:
    """Upload a package to PyPI using twine."""
    result = subprocess.run(
        [
            "twine",
            "upload",
            "dist/*",
            "-u",
            "__token__",
            "-p",
            PYPI_TOKEN,
        ],
        cwd=str(directory),
        check=True,
    )
    return result.returncode == 0
