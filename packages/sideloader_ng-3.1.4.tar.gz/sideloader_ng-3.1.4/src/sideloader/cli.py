#!/usr/bin/env python3
"""
Sideload CLI Client
A beautiful command-line interface for downloading files via the Sideload service.
"""

import os
import sys
import time
import subprocess
import tempfile
import argparse
from pathlib import Path
from typing import List, Dict
from urllib.parse import quote

from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
)
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.align import Align
from rich.rule import Rule

from sideloader.adapters.jsonbin import JSONBinConnector, SideloadBinManager
from sideloader.adapters.hookdeck import HookdeckClient

console = Console()


class SideloadClient:
    def __init__(
        self,
        jsonbin_token: str,
        collection_id: str,
        verify_ssl: bool = True,
        key_type: str = "master",
        hookdeck_source_id: str | None = None,
        hookdeck_api_key: str | None = None,
        hookdeck_verify_ssl: bool = True,
    ):
        self.collection_id = collection_id
        self.connector = JSONBinConnector(
            jsonbin_token, verify_ssl=verify_ssl, key_type=key_type
        )
        self.manager = SideloadBinManager(self.connector)
        self.hookdeck_client = HookdeckClient(
            source_id=hookdeck_source_id,
            api_key=hookdeck_api_key,
            verify_ssl=hookdeck_verify_ssl,
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connector.close()

    def notify_hookdeck(self, bin_id: str, event_type: str = "start"):
        """Send an event to Hookdeck via the Publish API to trigger server-side processing"""
        self.hookdeck_client.notify(bin_id, event_type)

    def create_request(self, url: str) -> str:
        """Create a new sideload request and return the bin ID"""
        with console.status("[bold green]Creating sideload request..."):
            bin_id = self.manager.create_sideload_request(url, self.collection_id)

        console.print(f"✅ Created sideload request: [bold cyan]{bin_id}[/bold cyan]")
        self.notify_hookdeck(bin_id)
        return bin_id

    def monitor_request(self, bin_id: str) -> Dict:
        """Monitor the sideload request progress"""

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
            transient=True,
        ) as progress:
            download_task = progress.add_task("Monitoring request...", total=100)

            while True:
                try:
                    data = self.manager.get_sideload_data(bin_id)

                    status = data.get("status", "UNKNOWN")
                    current_progress = data.get("progress", 0)

                    if status == "DOWNLOADING":
                        progress.update(
                            download_task,
                            description=f"📥 Downloading... ({current_progress}%)",
                            completed=current_progress,
                        )
                    elif status == "BUILDING":
                        progress.update(
                            download_task,
                            description="🔨 Building packages...",
                            completed=90,
                        )
                    elif status == "UPLOADING":
                        current_part = data.get("current_part", 1)
                        total_parts = data.get("total_parts", 1)
                        progress.update(
                            download_task,
                            description=f"📤 Uploading part {current_part}/{total_parts}...",
                            completed=95,
                        )
                    elif status == "UPLOADED":
                        progress.update(
                            download_task,
                            description="✅ Upload complete!",
                            completed=100,
                        )
                        break
                    elif status in ["FAILED", "REJECTED"]:
                        reason = data.get("reason", "Unknown error")
                        console.print(f"❌ Request failed: {reason}", style="bold red")
                        return data

                    time.sleep(2)

                except KeyboardInterrupt:
                    console.print("\n⚠️  Monitoring interrupted by user", style="yellow")
                    console.print(
                        f"💡 To resume this download, run: [bold cyan]sideload download --resume {bin_id}[/bold cyan]"
                    )
                    break
                except Exception as e:
                    console.print(f"❌ Error monitoring request: {e}", style="red")
                    break

        # Get final data
        return self.manager.get_sideload_data(bin_id)

    def download_packages(
        self,
        package_names: List[str],
        output_dir: Path,
        debug: bool = False,
        storage_backend: str = "pypi",
        fallback_package_names: List[str] | None = None,
    ) -> List[Path]:
        """Download all packages to a temporary directory"""
        if storage_backend == "npm":
            return self.download_npm_packages(
                package_names,
                output_dir,
                debug,
                fallback_package_names=fallback_package_names,
            )
        else:
            return self.download_pypi_packages(package_names, output_dir, debug)
    
    def download_npm_packages(
        self,
        package_names: List[str],
        output_dir: Path,
        debug: bool = False,
        fallback_package_names: List[str] | None = None,
    ) -> List[Path]:
        """Download npm packages to a directory"""
        downloaded_files = []
        npm_registry = os.environ.get("NPM_REGISTRY", "").strip()
        registry_base = (npm_registry or "https://registry.npmjs.org").rstrip("/")
        try:
            max_retries = max(1, int(os.environ.get("NPM_PACK_RETRIES", "8")))
        except ValueError:
            max_retries = 8
        try:
            retry_delay_seconds = max(
                0.2, float(os.environ.get("NPM_PACK_RETRY_DELAY_SECONDS", "2"))
            )
        except ValueError:
            retry_delay_seconds = 2.0

        def build_tarball_url(package_spec: str) -> str | None:
            if "@" not in package_spec:
                return None
            if package_spec.startswith("@"):
                split_index = package_spec.rfind("@")
                if split_index <= 0:
                    return None
                package_name_only = package_spec[:split_index]
                package_version = package_spec[split_index + 1 :]
            else:
                package_name_only, package_version = package_spec.rsplit("@", 1)

            if not package_name_only or not package_version:
                return None

            tarball_base_name = package_name_only.rsplit("/", 1)[-1]
            encoded_package_name = quote(package_name_only, safe="@/")
            encoded_tarball_name = quote(
                f"{tarball_base_name}-{package_version}.tgz", safe=""
            )
            return (
                f"{registry_base}/{encoded_package_name}/-/{encoded_tarball_name}"
            )

        def should_retry_pack(result: subprocess.CompletedProcess) -> bool:
            output = f"{result.stderr or ''}\n{result.stdout or ''}".lower()
            retry_markers = (
                "notarget",
                "no matching version found",
                "e404",
                "404 not found",
            )
            return any(marker in output for marker in retry_markers)

        if debug:
            console.print(f"[dim]NPM package names to download: {package_names}[/dim]")
            if fallback_package_names:
                console.print(
                    f"[dim]NPM fallback package refs: {fallback_package_names}[/dim]"
                )

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
            disable=debug,
        ) as progress:
            download_task = progress.add_task(
                "Downloading NPM packages...", total=len(package_names)
            )

            for i, package_name in enumerate(package_names):
                progress.update(
                    download_task,
                    description=f"📦 Downloading {package_name}...",
                    completed=i,
                )

                # Download using npm pack
                try:
                    def run_npm_pack(spec: str) -> subprocess.CompletedProcess:
                        cmd = [
                            "npm",
                            "pack",
                            spec,
                            "--pack-destination",
                            str(output_dir),
                            "--prefer-online",
                        ]
                        if npm_registry:
                            cmd.extend(["--registry", npm_registry])

                        if debug:
                            console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")

                        return subprocess.run(
                            cmd,
                            capture_output=True,
                            text=True,
                            cwd=str(output_dir),
                        )

                    def run_npm_pack_with_retries(
                        spec: str, retry_label: str
                    ) -> subprocess.CompletedProcess:
                        result: subprocess.CompletedProcess | None = None
                        for attempt in range(1, max_retries + 1):
                            result = run_npm_pack(spec)
                            if result.returncode == 0:
                                return result

                            if not should_retry_pack(result) or attempt == max_retries:
                                return result

                            console.print(
                                "[yellow]⚠ npm metadata not ready for "
                                f"{retry_label}, retrying in "
                                f"{retry_delay_seconds:g}s "
                                f"({attempt}/{max_retries})[/yellow]"
                            )
                            time.sleep(retry_delay_seconds)

                        return result or run_npm_pack(spec)

                    result: subprocess.CompletedProcess | None = (
                        run_npm_pack_with_retries(package_name, package_name)
                    )
                    fallback_spec = None
                    if fallback_package_names and i < len(fallback_package_names):
                        fallback_spec = fallback_package_names[i]

                    if result is None or result.returncode != 0:
                        if fallback_spec and fallback_spec != package_name:
                            console.print(
                                f"[yellow]⚠ Tag download failed for {package_name}, "
                                f"retrying with version ref {fallback_spec}[/yellow]"
                            )
                            result = run_npm_pack_with_retries(
                                fallback_spec, fallback_spec
                            )

                    if result is None or result.returncode != 0:
                        if fallback_spec:
                            tarball_url = build_tarball_url(fallback_spec)
                            if tarball_url:
                                console.print(
                                    "[yellow]⚠ Version lookup still unavailable, "
                                    f"retrying direct tarball URL for "
                                    f"{fallback_spec}[/yellow]"
                                )
                                result = run_npm_pack_with_retries(
                                    tarball_url, f"tarball:{fallback_spec}"
                                )

                    if result is None or result.returncode != 0:
                        console.print(
                            f"❌ Failed to download {package_name}", style="red"
                        )
                        if result.stderr:
                            stderr_lines = result.stderr.strip().split("\n")
                            for line in stderr_lines[-3:]:
                                console.print(f"   [dim]{line}[/dim]")
                        continue

                    # Find the downloaded tgz file
                    # npm pack creates files like: package-name-1.0.0.tgz
                    tgz_files = list(output_dir.glob("*.tgz"))
                    # Get the most recently created file
                    if tgz_files:
                        latest_tgz = max(tgz_files, key=lambda f: f.stat().st_mtime)
                        downloaded_files.append(latest_tgz)
                        if debug:
                            console.print(
                                f"[green]✓ Downloaded: {latest_tgz.name}[/green]"
                            )
                    else:
                        console.print(
                            f"[yellow]⚠ No tgz file found for {package_name}[/yellow]"
                        )

                except subprocess.CalledProcessError as e:
                    error_msg = (
                        e.stderr if hasattr(e, "stderr") and e.stderr else str(e)
                    )
                    console.print(
                        f"❌ Failed to download {package_name}: {error_msg}",
                        style="red",
                    )
                    continue

            progress.update(
                download_task,
                description="✅ Download complete!",
                completed=len(package_names),
            )

        return downloaded_files

    def download_pypi_packages(
        self, package_names: List[str], output_dir: Path, debug: bool = False
    ) -> List[Path]:
        """Download all packages to a temporary directory"""
        downloaded_files = []

        if debug:
            console.print(f"[dim]Package names to download: {package_names}[/dim]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
            disable=debug,  # Disable progress bar in debug mode
        ) as progress:
            download_task = progress.add_task(
                "Downloading packages...", total=len(package_names)
            )

            for i, package_name in enumerate(package_names):
                progress.update(
                    download_task,
                    description=f"📦 Downloading {package_name}...",
                    completed=i,
                )

                # Download using pip to temporary directory
                try:
                    cmd = [
                        sys.executable,
                        "-m",
                        "pip",
                        "download",
                        "--no-deps",
                        "--dest",
                        str(output_dir),
                        package_name,
                    ]

                    if debug:
                        console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")

                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                    )

                    if result.returncode != 0:
                        console.print(
                            f"❌ Failed to download {package_name}", style="red"
                        )
                        if result.stderr:
                            # Show last few lines of stderr for context
                            stderr_lines = result.stderr.strip().split("\n")
                            for line in stderr_lines[-3:]:
                                console.print(f"   [dim]{line}[/dim]")
                        continue

                    # Find the downloaded wheel file
                    # Pip normalizes package names: lowercase, underscores collapsed, hyphens become underscores
                    def normalize_package_name(name: str) -> str:
                        """Normalize package name to match pip's wheel naming convention"""
                        import re

                        # Replace runs of underscores/hyphens/dots with single underscore, then lowercase
                        return re.sub(r"[-_.]+", "_", name).lower()

                    normalized_name = normalize_package_name(package_name)
                    wheel_files = [
                        f
                        for f in output_dir.glob("*.whl")
                        if normalize_package_name(f.name.split("-")[0])
                        == normalized_name
                    ]
                    if wheel_files:
                        downloaded_files.append(wheel_files[0])
                        if debug:
                            console.print(
                                f"[green]✓ Downloaded: {wheel_files[0].name}[/green]"
                            )
                    else:
                        console.print(
                            f"[yellow]⚠ No wheel file found for {package_name}[/yellow]"
                        )
                        if debug:
                            all_wheels = list(output_dir.glob("*.whl"))
                            console.print(
                                f"[dim]Normalized package name: {normalized_name}[/dim]"
                            )
                            console.print(
                                f"[dim]Available wheels in dir: {[w.name for w in all_wheels]}[/dim]"
                            )

                except subprocess.CalledProcessError as e:
                    error_msg = (
                        e.stderr if hasattr(e, "stderr") and e.stderr else str(e)
                    )
                    console.print(
                        f"❌ Failed to download {package_name}: {error_msg}",
                        style="red",
                    )
                    continue

            progress.update(
                download_task,
                description="✅ Download complete!",
                completed=len(package_names),
            )

        return downloaded_files

    def extract_and_reassemble(
        self,
        wheel_files: List[Path],
        package_names: List[str],
        original_filename: str,
        output_path: Path,
        debug: bool = False,
        work_dir: Path = None,
        storage_backend: str = "pypi",
    ):
        """Extract parts from package files and reassemble the original file"""
        if storage_backend == "npm":
            return self.extract_and_reassemble_npm(
                wheel_files, package_names, original_filename, output_path, debug, work_dir
            )
        else:
            return self.extract_and_reassemble_pypi(
                wheel_files, package_names, original_filename, output_path, debug, work_dir
            )
    
    def extract_and_reassemble_npm(
        self,
        tgz_files: List[Path],
        package_names: List[str],
        original_filename: str,
        output_path: Path,
        debug: bool = False,
        work_dir: Path | None = None,
    ):
        """Extract parts from npm tgz files and reassemble the original file"""
        use_temp = work_dir is None
        if use_temp:
            temp_dir_obj = tempfile.TemporaryDirectory()
            temp_path = Path(temp_dir_obj.name)
        else:
            temp_dir_obj = None
            temp_path = work_dir
            temp_path.mkdir(parents=True, exist_ok=True)

        try:
            part_files = []

            if not use_temp:
                console.print(f"[yellow]⚠️  Using work directory: {temp_path}[/yellow]")

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                console=console,
                disable=debug,
            ) as progress:
                extract_task = progress.add_task(
                    "Extracting npm packages...", total=len(tgz_files)
                )

                # Extract each tgz file
                for i, (tgz_file, package_name) in enumerate(
                    zip(tgz_files, package_names)
                ):
                    progress.update(
                        extract_task,
                        description=f"📂 Extracting {tgz_file.name}...",
                        completed=i,
                    )

                    if debug:
                        console.print(
                            f"\n[cyan]Extracting package {i + 1}/{len(tgz_files)}: {package_name}[/cyan]"
                        )

                    # Extract tgz file
                    import tarfile

                    extract_dir = temp_path / f"extract_{i}"
                    extract_dir.mkdir(exist_ok=True)

                    with tarfile.open(tgz_file, "r:gz") as tar:
                        if debug:
                            console.print(f"\n[dim]Contents of {tgz_file.name}:[/dim]")
                            for name in sorted(tar.getnames()):
                                console.print(f"[dim]  {name}[/dim]")
                        tar.extractall(extract_dir)

                    # npm packages extract to a 'package' directory
                    package_dir = extract_dir / "package"
                    if package_dir.exists():
                        # Find the data file (the part file has the same name as the last component of package_name)
                        # Find files that are not package.json or index.js
                        data_files = [
                            f for f in package_dir.iterdir()
                            if f.is_file() and f.name not in ["package.json", "index.js", ".npmrc"]
                        ]
                        
                        if data_files:
                            part_file_path = data_files[0]  # Should be only one data file
                            part_files.append(part_file_path)
                            if debug:
                                console.print(
                                    f"[green]✓ Found part file: {part_file_path.name} (size: {part_file_path.stat().st_size:,} bytes)[/green]"
                                )
                        else:
                            if debug:
                                console.print(
                                    f"[yellow]⚠ No data file found in package {package_name}[/yellow]"
                                )
                    else:
                        if debug:
                            console.print(
                                f"[yellow]⚠ No package directory found in {tgz_file.name}[/yellow]"
                            )

                progress.update(
                    extract_task,
                    description="✅ Extraction complete!",
                    completed=len(tgz_files),
                )

            # Reassemble the original file
            if part_files:
                console.print(
                    f"📝 Reassembling {len(part_files)} part(s) into [cyan]{original_filename}[/cyan]..."
                )

                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TaskProgressColumn(),
                    console=console,
                    disable=debug,
                ) as progress:
                    reassemble_task = progress.add_task(
                        "Reassembling file...", total=len(part_files)
                    )

                    with open(output_path, "wb") as output_file:
                        for i, part_file in enumerate(part_files):
                            progress.update(
                                reassemble_task,
                                description=f"✍️  Writing part {i + 1}/{len(part_files)}...",
                                completed=i,
                            )

                            with open(part_file, "rb") as pf:
                                output_file.write(pf.read())

                    progress.update(
                        reassemble_task,
                        description="✅ Reassembly complete!",
                        completed=len(part_files),
                    )
        finally:
            # Clean up temporary directory if we created one
            if use_temp and temp_dir_obj:
                temp_dir_obj.cleanup()
    
    def extract_and_reassemble_pypi(
        self,
        wheel_files: List[Path],
        package_names: List[str],
        original_filename: str,
        output_path: Path,
        debug: bool = False,
        work_dir: Path = None,
    ):
        """Extract parts from wheel files and reassemble the original file"""
        # Use provided work directory or create a temporary one
        use_temp = work_dir is None
        if use_temp:
            temp_dir_obj = tempfile.TemporaryDirectory()
            temp_path = Path(temp_dir_obj.name)
        else:
            temp_dir_obj = None
            temp_path = work_dir
            temp_path.mkdir(parents=True, exist_ok=True)

        try:
            part_files = []

            if not use_temp:
                console.print(f"[yellow]⚠️  Using work directory: {temp_path}[/yellow]")
                console.print(
                    f"[yellow]   Files will be kept after extraction for debugging[/yellow]"
                )

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                console=console,
                disable=debug,  # Disable progress bar in debug mode
            ) as progress:
                extract_task = progress.add_task(
                    "Extracting packages...", total=len(wheel_files)
                )

                # Extract each wheel file
                for i, (wheel_file, package_name) in enumerate(
                    zip(wheel_files, package_names)
                ):
                    progress.update(
                        extract_task,
                        description=f"📂 Extracting {wheel_file.name}...",
                        completed=i,
                    )

                    if debug:
                        console.print(
                            f"\n[cyan]Extracting package {i + 1}/{len(wheel_files)}: {package_name}[/cyan]"
                        )

                    # Extract wheel file (it's just a zip)
                    import zipfile

                    with zipfile.ZipFile(wheel_file, "r") as zip_ref:
                        if debug:
                            console.print(
                                f"\n[dim]Contents of {wheel_file.name}:[/dim]"
                            )
                            for name in sorted(zip_ref.namelist()):
                                console.print(f"[dim]  {name}[/dim]")
                        zip_ref.extractall(temp_path)

                    # Find the part file using the normalized package name
                    # Pattern: pkgname-version.data/data/share/pkgname/pkgname
                    # Need to find the .data directory that starts with normalized package_name
                    import re

                    def normalize_package_name(name: str) -> str:
                        """Normalize package name to match pip's wheel naming convention"""
                        return re.sub(r"[-_.]+", "_", name).lower()

                    normalized_name = normalize_package_name(package_name)
                    data_dir = None
                    actual_package_name = None

                    for d in temp_path.iterdir():
                        if d.is_dir() and d.name.endswith(".data"):
                            # Extract package name from directory (before -version)
                            dir_pkg_name = d.name.split("-")[0]
                            if normalize_package_name(dir_pkg_name) == normalized_name:
                                data_dir = d
                                actual_package_name = dir_pkg_name
                                break

                    if data_dir and actual_package_name:
                        # The share directory uses the original package name (with __ etc)
                        # Try both the actual_package_name (from .data dir) and the original package_name
                        share_dir = data_dir / "data" / "share"
                        part_file_path = None

                        # First try: use actual_package_name from wheel (normalized)
                        candidate = (
                            share_dir / actual_package_name / actual_package_name
                        )
                        if candidate.is_file():
                            part_file_path = candidate
                        else:
                            # Second try: use original package_name (with __)
                            candidate = share_dir / package_name / package_name
                            if candidate.is_file():
                                part_file_path = candidate
                            else:
                                # Third try: search for any subdirectory in share
                                if share_dir.exists():
                                    for subdir in share_dir.iterdir():
                                        if subdir.is_dir():
                                            inner_file = subdir / subdir.name
                                            if inner_file.is_file():
                                                part_file_path = inner_file
                                                break

                        if debug:
                            console.print(
                                f"[dim]Looking for part file in: {share_dir}[/dim]"
                            )
                            if share_dir.exists():
                                console.print(
                                    f"[dim]Share dir contents: {[x.name for x in share_dir.iterdir()]}[/dim]"
                                )

                        if part_file_path and part_file_path.is_file():
                            part_files.append(part_file_path)
                            if debug:
                                console.print(
                                    f"[green]✓ Found part file: {part_file_path.name} (size: {part_file_path.stat().st_size:,} bytes)[/green]"
                                )
                        else:
                            if debug:
                                console.print(
                                    f"[yellow]⚠ Part file not found at expected path[/yellow]"
                                )
                    else:
                        if debug:
                            console.print(
                                f"[yellow]⚠ Could not find .data directory for {package_name}[/yellow]"
                            )
                            console.print(
                                f"[dim]Available directories: {[d.name for d in temp_path.iterdir() if d.is_dir()]}[/dim]"
                            )

                progress.update(
                    extract_task,
                    description="✅ Extraction complete!",
                    completed=len(wheel_files),
                )

            # Sort part files to ensure correct order
            part_files.sort(key=lambda x: x.name)

            if len(part_files) == 1 and part_files[0].name == original_filename:
                # Single file, just copy it
                console.print("📄 Single file detected, copying...")
                import shutil

                shutil.copy2(part_files[0], output_path)
            else:
                # Multiple parts, concatenate them
                console.print(f"🔗 Reassembling {len(part_files)} parts...")

                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TaskProgressColumn(),
                    console=console,
                    disable=debug,  # Disable progress bar in debug mode
                ) as progress:
                    reassemble_task = progress.add_task(
                        "Reassembling file...", total=len(part_files)
                    )

                    with open(output_path, "wb") as output_file:
                        for i, part_file in enumerate(part_files):
                            progress.update(
                                reassemble_task,
                                description=f"🔗 Assembling part {i + 1}/{len(part_files)}...",
                                completed=i,
                            )

                            if debug:
                                console.print(
                                    f"[dim]Reading part {i + 1}/{len(part_files)}: {part_file.name} ({part_file.stat().st_size:,} bytes)[/dim]"
                                )

                            with open(part_file, "rb") as part:
                                output_file.write(part.read())

                    progress.update(
                        reassemble_task,
                        description="✅ Reassembly complete!",
                        completed=len(part_files),
                    )
        finally:
            # Clean up temporary directory if we created one
            if use_temp and temp_dir_obj:
                temp_dir_obj.cleanup()


def display_header():
    """Display the application header"""
    header = Text("🚀 SIDELOAD", style="bold magenta")
    subtitle = Text("Download large files via PyPI/npm packages", style="dim")

    panel = Panel(
        Align.center(f"{header}\n{subtitle}"), border_style="magenta", padding=(1, 2)
    )
    console.print(panel)


def display_summary(data: Dict):
    """Display a summary of the completed request"""
    table = Table(title="📊 Download Summary", style="cyan")
    table.add_column("Property", style="bold")
    table.add_column("Value")

    table.add_row("Original Filename", data.get("filename", "Unknown"))
    table.add_row("File Size", f"{data.get('file_size', 0):,} bytes")
    table.add_row("Total Packages", str(data.get("total_packages", 0)))
    table.add_row("Status", f"✅ {data.get('status', 'Unknown')}")

    console.print(table)


def list_resumable_downloads(connector: JSONBinConnector, collection_id: str):
    """List all resumable downloads from the collection"""
    table = Table(title="📋 Resumable Downloads", style="cyan")
    table.add_column("Request ID", style="bold cyan")
    table.add_column("Status", style="yellow")
    table.add_column("Filename", style="white")
    table.add_column("Progress", style="green")
    table.add_column("Created", style="dim")

    # Resumable statuses (in-progress or completed but not yet downloaded)
    resumable_statuses = {"CREATED", "DOWNLOADING", "BUILDING", "UPLOADING", "UPLOADED"}

    found_count = 0
    last_bin_id = None

    with console.status("[bold green]Fetching downloads..."):
        while True:
            try:
                bins = connector.get_collection_bins(collection_id, last_bin_id)
                if not bins:
                    break

                for bin_data in bins:
                    bin_id = bin_data["record"]
                    last_bin_id = bin_id

                    try:
                        data = connector.get_bin(bin_id)
                        status = data.get("status", "UNKNOWN")

                        if status in resumable_statuses:
                            found_count += 1
                            filename = data.get("filename", data.get("url", "Unknown"))
                            # Truncate long filenames
                            if len(filename) > 40:
                                filename = filename[:37] + "..."

                            progress = data.get("progress", 0)
                            progress_str = (
                                f"{progress}%" if status == "DOWNLOADING" else "-"
                            )

                            # Format created time
                            created_at = data.get("created_at", 0)
                            if created_at:
                                from datetime import datetime

                                created_str = datetime.fromtimestamp(
                                    created_at
                                ).strftime("%Y-%m-%d %H:%M")
                            else:
                                created_str = "Unknown"

                            # Status with emoji
                            status_display = {
                                "CREATED": "⏳ CREATED",
                                "DOWNLOADING": "📥 DOWNLOADING",
                                "BUILDING": "🔨 BUILDING",
                                "UPLOADING": "📤 UPLOADING",
                                "UPLOADED": "✅ UPLOADED",
                            }.get(status, status)

                            table.add_row(
                                bin_id,
                                status_display,
                                filename,
                                progress_str,
                                created_str,
                            )
                    except Exception:
                        continue

            except Exception as e:
                console.print(f"[red]Error fetching bins: {e}[/red]")
                break

    if found_count > 0:
        console.print(table)
        console.print(
            f"\n💡 To resume a download: [bold cyan]sideload download --resume <REQUEST_ID>[/bold cyan]"
        )
    else:
        console.print("[yellow]No resumable downloads found.[/yellow]")


def cli_main():
    parser = argparse.ArgumentParser(
        description="Sideload CLI - Download large files via PyPI packages",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  sideload download https://example.com/largefile.zip
  sideload download https://example.com/file.zip --output ./downloads/
  sideload download --resume abc123xyz  # Resume an interrupted download
  sideload list                          # List resumable downloads
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # List command
    list_parser = subparsers.add_parser("list", help="List resumable downloads")
    list_parser.add_argument("--collection", help="JSONBin collection ID")
    list_parser.add_argument("--token", help="JSONBin API token")
    list_parser.add_argument(
        "--no-verify-ssl",
        action="store_true",
        help="Disable SSL certificate verification for JSONBin API",
    )
    list_parser.add_argument(
        "--jsonbin-key-type",
        choices=["master", "access"],
        default=None,
        help="JSONBin key type to use (default: from JSONBIN_KEY_TYPE env or 'master')",
    )

    # Download command
    download_parser = subparsers.add_parser(
        "download", help="Download a file via sideload"
    )
    download_parser.add_argument(
        "url",
        nargs="?",
        help="URL of the file to download (not required if --resume is used)",
    )
    download_parser.add_argument(
        "--resume",
        "-r",
        metavar="REQUEST_ID",
        help="Resume an interrupted download by providing the request ID",
    )
    download_parser.add_argument(
        "--output",
        "-o",
        type=Path,
        default=Path.cwd(),
        help="Output directory (default: current directory)",
    )
    download_parser.add_argument("--collection", help="JSONBin collection ID")
    download_parser.add_argument("--token", help="JSONBin API token")
    download_parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    download_parser.add_argument(
        "--work-dir",
        type=Path,
        help="Working directory for extraction (for debugging, defaults to temp directory)",
    )
    download_parser.add_argument(
        "--no-verify-ssl",
        action="store_true",
        help="Disable SSL certificate verification for JSONBin API",
    )
    download_parser.add_argument(
        "--jsonbin-key-type",
        choices=["master", "access"],
        default=None,
        help="JSONBin key type to use (default: from JSONBIN_KEY_TYPE env or 'master')",
    )
    download_parser.add_argument(
        "--hookdeck-source-id",
        type=str,
        default=None,
        help="Hookdeck source ID for the Publish API (default: from HOOKDECK_SOURCE_ID env)",
    )
    download_parser.add_argument(
        "--hookdeck-api-key",
        type=str,
        default=None,
        help="Hookdeck API key for the Publish API (default: from HOOKDECK_API_KEY env)",
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    display_header()

    if args.command == "list":
        # Get credentials
        jsonbin_token = args.token or os.environ.get("JSONBIN_TOKEN")
        collection_id = args.collection or os.environ.get("SIDELOAD_COLLECTION_ID")

        # Get SSL verification setting
        verify_ssl = not args.no_verify_ssl
        if not args.no_verify_ssl:
            env_verify = os.environ.get("JSONBIN_VERIFY_SSL", "true").lower()
            verify_ssl = env_verify in ("true", "1", "yes")

        # Get key type
        key_type = (
            args.jsonbin_key_type
            or os.environ.get("JSONBIN_KEY_TYPE", "master").lower()
        )

        if not jsonbin_token:
            console.print(
                "❌ JSONBin token required. Set JSONBIN_TOKEN environment variable or use --token",
                style="red",
            )
            return

        if not collection_id:
            console.print(
                "❌ Collection ID required. Set SIDELOAD_COLLECTION_ID environment variable or use --collection",
                style="red",
            )
            return

        connector = JSONBinConnector(
            jsonbin_token, verify_ssl=verify_ssl, key_type=key_type
        )
        try:
            list_resumable_downloads(connector, collection_id)
        finally:
            connector.close()

    elif args.command == "download":
        # Get credentials
        jsonbin_token = args.token or os.environ.get("JSONBIN_TOKEN")
        collection_id = args.collection or os.environ.get("SIDELOAD_COLLECTION_ID")

        # Get SSL verification setting (CLI flag overrides env var)
        verify_ssl = not args.no_verify_ssl
        if args.no_verify_ssl:
            # If CLI flag is set, disable SSL verification
            verify_ssl = False
        else:
            # Otherwise check environment variable (default to True)
            env_verify = os.environ.get("JSONBIN_VERIFY_SSL", "true").lower()
            verify_ssl = env_verify in ("true", "1", "yes")

        # Get key type (CLI arg > env var > default)
        key_type = (
            args.jsonbin_key_type
            or os.environ.get("JSONBIN_KEY_TYPE", "master").lower()
        )

        if not jsonbin_token:
            console.print(
                "❌ JSONBin token required. Set JSONBIN_TOKEN environment variable or use --token",
                style="red",
            )
            return

        if not collection_id:
            console.print(
                "❌ Collection ID required. Set SIDELOAD_COLLECTION_ID environment variable or use --collection",
                style="red",
            )
            return

        # Ensure output directory exists
        args.output.mkdir(parents=True, exist_ok=True)

        # Show debug flags if enabled
        if args.debug:
            console.print("\n[bold cyan]Debug Mode Enabled[/bold cyan]")
            if args.resume:
                console.print(f"  [dim]Resume Request ID:[/dim] {args.resume}")
            else:
                console.print(f"  [dim]URL:[/dim] {args.url}")
            console.print(f"  [dim]Output:[/dim] {args.output}")
            console.print(
                f"  [dim]Work Directory:[/dim] {args.work_dir or 'temp (auto-cleanup)'}"
            )
            console.print(f"  [dim]Collection ID:[/dim] {collection_id}")
            console.print(f"  [dim]SSL Verification:[/dim] {verify_ssl}")
            console.print(f"  [dim]JSONBin Key Type:[/dim] {key_type}")
            console.print()

        # Validate that either URL or --resume is provided
        if not args.url and not args.resume:
            console.print(
                "❌ Either a URL or --resume REQUEST_ID is required",
                style="red",
            )
            return

        if args.url and args.resume:
            console.print(
                "❌ Cannot specify both URL and --resume at the same time",
                style="red",
            )
            return

        # Get hookdeck config
        hookdeck_source_id = getattr(
            args, "hookdeck_source_id", None
        ) or os.environ.get("HOOKDECK_SOURCE_ID")
        hookdeck_api_key = getattr(args, "hookdeck_api_key", None) or os.environ.get(
            "HOOKDECK_API_KEY"
        )
        hookdeck_verify_ssl = os.environ.get("HOOKDECK_VERIFY_SSL", "true").lower() in (
            "true", "1", "yes"
        )

        try:
            with SideloadClient(
                jsonbin_token,
                collection_id,
                verify_ssl,
                key_type,
                hookdeck_source_id,
                hookdeck_api_key,
                hookdeck_verify_ssl,
            ) as client:
                if args.resume:
                    # Resume an existing request
                    bin_id = args.resume
                    console.print(
                        f"🔄 Resuming request: [bold cyan]{bin_id}[/bold cyan]"
                    )

                    # Check if request exists and get its current status
                    try:
                        data = client.manager.get_sideload_data(bin_id)
                        status = data.get("status", "UNKNOWN")
                        console.print(
                            f"📋 Current status: [bold yellow]{status}[/bold yellow]"
                        )

                        if status == "UPLOADED":
                            console.print(
                                "✅ Request already completed, proceeding to download packages..."
                            )
                        elif status in ["FAILED", "REJECTED"]:
                            reason = data.get(
                                "reason", data.get("details", "Unknown error")
                            )
                            console.print(
                                f"❌ Request failed: {reason}", style="bold red"
                            )
                            return
                        else:
                            # Continue monitoring if not yet complete
                            console.print(Rule("📡 Monitoring Progress"))
                            data = client.monitor_request(bin_id)
                    except Exception as e:
                        console.print(
                            f"❌ Failed to retrieve request {bin_id}: {e}", style="red"
                        )
                        return
                else:
                    # Create a new request
                    console.print(
                        f"🌐 Requesting download for: [bold blue]{args.url}[/bold blue]"
                    )
                    bin_id = client.create_request(args.url)

                    # Monitor the request
                    console.print(Rule("📡 Monitoring Progress"))
                    data = client.monitor_request(bin_id)

                if data.get("status") != "UPLOADED":
                    console.print(
                        "❌ Request did not complete successfully", style="red"
                    )
                    return

                # Display summary
                display_summary(data)

                # Download packages
                package_names = data.get("packages_names", [])
                fallback_package_names = data.get("packages_cleanup_names", [])
                if len(fallback_package_names) != len(package_names):
                    fallback_package_names = None
                if not package_names:
                    console.print("❌ No packages found in the response", style="red")
                    return

                console.print(Rule("📦 Downloading Packages"))

                # Use work_dir for downloads if provided, otherwise use temp directory
                use_work_dir = args.work_dir is not None
                if use_work_dir:
                    download_dir = args.work_dir / "wheels"
                    download_dir.mkdir(parents=True, exist_ok=True)
                    console.print(
                        f"[yellow]📥 Downloading packages to: {download_dir}[/yellow]"
                    )

                    storage_backend = data.get("storage_backend", "pypi")
                    wheel_files = client.download_packages(
                        package_names,
                        download_dir,
                        args.debug,
                        storage_backend,
                        fallback_package_names=fallback_package_names,
                    )

                    if not wheel_files:
                        console.print(
                            "❌ No packages were downloaded successfully", style="red"
                        )
                        return

                    # Extract and reassemble
                    console.print(Rule("🔧 Reassembling File"))
                    original_filename = data.get("filename", "downloaded_file")
                    output_file = args.output / original_filename

                    client.extract_and_reassemble(
                        wheel_files,
                        package_names,
                        original_filename,
                        output_file,
                        args.debug,
                        args.work_dir,
                        storage_backend,
                    )

                    # Success!
                    console.print(Rule("✨ Complete"))
                    console.print(
                        f"🎉 File successfully downloaded to: [bold green]{output_file}[/bold green]"
                    )
                    console.print(
                        f"📊 File size: [cyan]{output_file.stat().st_size:,} bytes[/cyan]"
                    )
                    client.notify_hookdeck(bin_id, "clean")
                else:
                    # Use temporary directory for downloads
                    with tempfile.TemporaryDirectory() as temp_dir:
                        temp_path = Path(temp_dir)
                        storage_backend = data.get("storage_backend", "pypi")
                        wheel_files = client.download_packages(
                            package_names,
                            temp_path,
                            args.debug,
                            storage_backend,
                            fallback_package_names=fallback_package_names,
                        )

                        if not wheel_files:
                            console.print(
                                "❌ No packages were downloaded successfully",
                                style="red",
                            )
                            return

                        # Extract and reassemble
                        console.print(Rule("🔧 Reassembling File"))
                        original_filename = data.get("filename", "downloaded_file")
                        output_file = args.output / original_filename

                        client.extract_and_reassemble(
                            wheel_files,
                            package_names,
                            original_filename,
                            output_file,
                            args.debug,
                            args.work_dir,
                            storage_backend,
                        )

                        # Success!
                        console.print(Rule("✨ Complete"))
                        console.print(
                            f"🎉 File successfully downloaded to: [bold green]{output_file}[/bold green]"
                        )
                        console.print(
                            f"📊 File size: [cyan]{output_file.stat().st_size:,} bytes[/cyan]"
                        )
                        client.notify_hookdeck(bin_id, "clean")

        except KeyboardInterrupt:
            console.print("\n⚠️  Download interrupted by user", style="yellow")
        except Exception as e:
            console.print(f"❌ Error: {e}", style="bold red")
            raise


if __name__ == "__main__":
    cli_main()
