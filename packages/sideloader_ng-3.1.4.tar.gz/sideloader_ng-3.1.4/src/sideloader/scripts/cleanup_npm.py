#!/usr/bin/env python3
"""
Standalone script to clean up npm packages.
Usage: python cleanup_npm.py package-spec1 package-spec2 package-spec3...
"""

import sys
from sideloader.adapters.npm import npm_unpublish_packages_sync


def main():
    if len(sys.argv) < 2:
        print("Usage: python cleanup_npm.py <package_spec1> [package_spec2] ...")
        print("\nExample:")
        print(
            "  python cleanup_npm.py sideloader-base-pkg@1.1700000000.123 "
            "sideloader-base-pkg@1.1700000000.124"
        )
        sys.exit(1)

    package_names = sys.argv[1:]

    print(f"🧹 Cleaning up {len(package_names)} npm package(s)...")
    print("-" * 60)

    deleted, errors = npm_unpublish_packages_sync(package_names)

    print("-" * 60)
    print(f"✅ Cleanup complete: {deleted} deleted, {errors} errors")

    if errors > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
