import os
import hashlib
import re
import shutil
from pathlib import Path
import tempfile
import threading
import time

import requests

from sideloader.adapters.jsonbin import JSONBinConnector
from sideloader.adapters.pypi import package_build as pypi_package_build, twine_upload
from sideloader.adapters.npm import package_build as npm_package_build, npm_publish

JSONBIN_TOKEN = os.environ.get("JSONBIN_TOKEN", "")
MAX_PACKAGE_SIZE = 92 * 1024 * 1024  # 95 MB

# Storage backend: "pypi" or "npm"
STORAGE_BACKEND = os.environ.get("STORAGE_BACKEND", "pypi").lower()
NPM_BASE_PACKAGE = os.environ.get("NPM_BASE_PACKAGE", "sideloader-base-package")

LAST_BINS: dict[str, str | None] = {}

PYPROJECT_TEMPLATE = """
[build-system]
requires = ["setuptools"]
build-backend = "setuptools.build_meta"

[project]
name = "{package_name}"
version = "1.0.0"
description = "Sideloaded package"
requires-python = ">=3.8"
authors = [
  {{name = "Null Void" }}
]

[tool.setuptools.data-files]
"share/{package_name}" = ["{package_name}"]
"""

jsonbin_connector = JSONBinConnector(JSONBIN_TOKEN) if JSONBIN_TOKEN else None


def _require_jsonbin_connector() -> JSONBinConnector:
    if jsonbin_connector is None:
        raise RuntimeError(
            "JSONBIN_TOKEN environment variable is required for this operation"
        )
    return jsonbin_connector


def build_and_upload_pypi(part_path: Path, package_name: str) -> bool:
    """Build and upload a PyPI package."""
    with open(
        part_path.parent / "pyproject.toml",
        "w",
        encoding="utf-8",
    ) as pyproject_file:
        pyproject_file.write(PYPROJECT_TEMPLATE.format(package_name=package_name))

    if not pypi_package_build(part_path.parent):
        return False

    if not twine_upload(part_path.parent):
        return False

    return True


def _slugify_npm_tag_component(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return normalized[:64] or "artifact"


def _build_npm_dist_tag(
    filename_root: str,
    bin_id: str,
    part_idx: int,
    total_parts: int,
) -> str:
    suffix = f"-p{part_idx}" if total_parts > 1 else ""
    tag = f"sideload-{_slugify_npm_tag_component(filename_root)}-{bin_id[:7]}{suffix}"
    return tag[:214]


def _build_npm_version(bin_id: str, part_idx: int) -> str:
    timestamp_seconds = int(time.time())
    digest = hashlib.sha1(
        f"{bin_id}:{part_idx}:{timestamp_seconds}".encode("utf-8")
    ).hexdigest()
    patch = int(digest[:8], 16)
    return f"1.{timestamp_seconds}.{patch}"


def build_and_upload_npm(
    part_path: Path,
    package_name: str,
    package_version: str,
    package_tag: str,
) -> bool:
    """Build and upload an NPM package."""
    data_file = part_path.name

    if not npm_package_build(
        part_path.parent,
        package_name,
        data_file,
        package_version,
        package_tag,
    ):
        return False

    if not npm_publish(part_path.parent, package_tag):
        return False

    return True


def npm_test_upload_file(file_path: Path, requested_tag: str | None = None) -> bool:
    """Upload a local file as a one-part npm test artifact."""
    if not file_path.exists() or not file_path.is_file():
        print(f"❌ File does not exist: {file_path}")
        return False

    filename_root = file_path.stem or "artifact"
    synthetic_id = hashlib.sha1(
        f"{file_path}:{time.time()}".encode("utf-8")
    ).hexdigest()
    package_tag = (
        _slugify_npm_tag_component(requested_tag)
        if requested_tag
        else _build_npm_dist_tag(filename_root, synthetic_id, 0, 1)
    )
    package_version = _build_npm_version(synthetic_id, 0)

    with tempfile.TemporaryDirectory() as temp_dir:
        staging_dir = Path(temp_dir) / "npm-test"
        staging_dir.mkdir(parents=True, exist_ok=True)
        staged_file = staging_dir / file_path.name
        shutil.copy2(file_path, staged_file)

        print(f"📦 Publishing npm test artifact from: {file_path}")
        print(f"  Package: {NPM_BASE_PACKAGE}")
        print(f"  Tag: {package_tag}")
        print(f"  Version: {package_version}")

        success = build_and_upload_npm(
            part_path=staged_file,
            package_name=NPM_BASE_PACKAGE,
            package_version=package_version,
            package_tag=package_tag,
        )
        if not success:
            print("❌ npm test upload failed")
            return False

    download_ref = f"{NPM_BASE_PACKAGE}@{package_tag}"
    cleanup_ref = f"{NPM_BASE_PACKAGE}@{package_version}"

    print("✅ npm test upload succeeded")
    print(f"  Download ref: {download_ref}")
    print(f"  Cleanup ref: {cleanup_ref}")
    print("  Unpublish command:")
    print(f"  uv run sideloader-server --npm-test-unpublish {cleanup_ref}")
    return True


def npm_test_unpublish(package_spec: str) -> bool:
    """Unpublish a specific npm package spec (typically package@version)."""
    from sideloader.adapters.npm import npm_unpublish_package

    print(f"🗑️  Unpublishing npm test artifact: {package_spec}")
    success = npm_unpublish_package(package_spec)
    if success:
        print("✅ npm test unpublish succeeded")
    else:
        print("❌ npm test unpublish failed")
    return success


def download_file(bin_id: str, url: str):
    try:
        # Send a HTTP request to the server.
        response = requests.get(url, stream=True)
    except Exception as e:
        _require_jsonbin_connector().update_bin(
            bin_id,
            {
                "status": "REJECTED",
                "details": f"Failed to download file: [{e.__class__.__name__}]: {e}",
            },
        )
        return
    if not response.ok:
        _require_jsonbin_connector().update_bin(
            bin_id,
            {
                "status": "REJECTED",
                "details": f"URL returned code {response.status_code}: {response.reason}",
            },
        )
        return
    # Total size in bytes.
    total_size = int(response.headers.get("content-length", 1))
    try:
        content_disposition = response.headers.get("Content-Disposition", "")
        filename = None

        # Try to extract filename from Content-Disposition header
        # Format can be: attachment; filename="file.ext"; filename*=utf-8''encoded%20name.ext
        if content_disposition:
            import re
            from urllib.parse import unquote

            # First try filename*= (RFC 5987 encoded, preferred)
            match = re.search(
                r"filename\*=(?:utf-8''|UTF-8'')([^;]+)", content_disposition
            )
            if match:
                filename = unquote(match.group(1).strip())
            else:
                # Fall back to filename= (may be quoted)
                match = re.search(
                    r'filename=(?:"([^"]+)"|([^;\s]+))', content_disposition
                )
                if match:
                    filename = match.group(1) or match.group(2)
                    filename = filename.strip('"').strip()

        if not filename:
            raise ValueError("No filename found in Content-Disposition")
    except Exception:
        filename = response.url.removesuffix("/").split("/")[-1]
        # URL decode and clean up the filename
        from urllib.parse import unquote

        filename = unquote(filename)

    # Initialize variables to track progress.
    downloaded = 0
    chunk_size = 1024 * 1024  # Size of each chunk in bytes.
    last_progress = 0
    filename_root = filename.split(".")[0]
    package_name = f"sideload_{filename_root}_bin_{bin_id}"
    # replace all non-alphanumeric characters with an underscore
    package_name = "".join(c if c.isalnum() else "_" for c in package_name)
    parts: list[Path] = []
    pypi_package_names: list[str] = []
    npm_download_refs: list[str] = []
    npm_cleanup_refs: list[str] = []

    def make_part_name():
        return f"{package_name}_p{len(parts)}"

    def make_new_part():
        part_name = make_part_name()
        part_directory = Path(temp_dir) / package_name / part_name
        part_directory.mkdir(parents=True, exist_ok=False)
        part_path = part_directory / part_name
        parts.append(part_path)
        return open(part_path, "wb")

    # Open a local file for writing in binary mode.
    with tempfile.TemporaryDirectory() as temp_dir:
        # temp_dir = "./dumptmp3"  # only for debugging
        os.mkdir(os.path.join(temp_dir, package_name))
        _require_jsonbin_connector().update_bin(
            bin_id,
            {"status": "DOWNLOADING", "progress": 0},
        )
        current_part_fp = make_new_part()
        try:
            current_chunk_size = 0
            for data in response.iter_content(chunk_size=chunk_size):
                if current_chunk_size + len(data) > MAX_PACKAGE_SIZE:
                    current_part_fp.close()
                    current_part_fp = make_new_part()
                    current_chunk_size = 0
                current_part_fp.write(data)
                downloaded += len(data)
                current_chunk_size += len(data)
                if total_size < downloaded:
                    total_size = downloaded
                    progress = 99
                else:
                    progress = int((downloaded / total_size) * 100)
                if progress != last_progress:
                    _require_jsonbin_connector().update_bin(
                        bin_id, {"progress": progress}
                    )
                    last_progress = progress
        finally:
            current_part_fp.close()
        _require_jsonbin_connector().update_bin(
            bin_id, {"progress": 100, "status": "DOWNLOADED"}
        )
        for part_idx, path_part in enumerate(parts):
            _require_jsonbin_connector().update_bin(
                bin_id,
                {
                    "status": "BUILDING",
                    "details": f"Building package part {part_idx + 1}/{len(parts)}.",
                },
            )

            part_package_name = path_part.name

            # Choose backend and build/upload
            if STORAGE_BACKEND == "npm":
                package_tag = _build_npm_dist_tag(
                    filename_root,
                    bin_id,
                    part_idx,
                    len(parts),
                )
                package_version = _build_npm_version(bin_id, part_idx)
                success = build_and_upload_npm(
                    path_part,
                    NPM_BASE_PACKAGE,
                    package_version,
                    package_tag,
                )
                backend_name = "NPM"
                if success:
                    npm_download_refs.append(f"{NPM_BASE_PACKAGE}@{package_tag}")
                    npm_cleanup_refs.append(f"{NPM_BASE_PACKAGE}@{package_version}")
            else:  # default to pypi
                success = build_and_upload_pypi(path_part, part_package_name)
                backend_name = "PyPI"
                if success:
                    pypi_package_names.append(part_package_name)

            if not success:
                _require_jsonbin_connector().update_bin(
                    bin_id,
                    {
                        "status": "FAILED",
                        "details": f"Failed to build/upload {backend_name} package part {part_idx + 1}/{len(parts)}.",
                    },
                )
                return

            _require_jsonbin_connector().update_bin(
                bin_id,
                {
                    "status": "UPLOADING",
                    "details": f"Uploaded {backend_name} package part {part_idx + 1}/{len(parts)}.",
                },
            )
        if STORAGE_BACKEND == "npm":
            package_names = npm_download_refs
            cleanup_names = npm_cleanup_refs
        else:
            package_names = pypi_package_names
            cleanup_names = pypi_package_names

        _require_jsonbin_connector().update_bin(
            bin_id,
            {
                "status": "UPLOADED",
                "packages_names": package_names,
                "packages_cleanup_names": cleanup_names,
                "filename": filename,
                "file_size": total_size,
                "total_packages": len(parts),
                "storage_backend": STORAGE_BACKEND,
                "npm_base_package": NPM_BASE_PACKAGE
                if STORAGE_BACKEND == "npm"
                else None,
            },
        )


def process_bin(bin_id: str):
    url = f"https://api.jsonbin.io/v3/b/{bin_id}"
    bin_data = requests.get(url, headers={"X-Master-Key": JSONBIN_TOKEN}).json()
    bin_record = bin_data["record"]
    if bin_record["status"] == "CREATED":
        print("Processing bin:", bin_id)
        download_file(bin_id, bin_record["url"])
    elif bin_record["status"] != "UPLOADED":
        _require_jsonbin_connector().update_bin(
            bin_id, {"status": "FAILED", "details": "Server interruption"}
        )
    else:
        print("Bin already processed:", bin_id)


def watch_collection(collection_id: str):
    print("Watching collection:", collection_id)
    while True:
        collection_data = _require_jsonbin_connector().get_collection_bins(
            collection_id, LAST_BINS.get(collection_id)
        )
        last_bin: str | None = None
        for bin_data in collection_data:
            bin_id = bin_data["record"]
            process_bin(bin_id)
            last_bin = bin_id
        if last_bin is not None:
            LAST_BINS[collection_id] = last_bin
        time.sleep(3)


# Statuses that indicate a bin can be cleaned up
CLEANUP_STATUSES = {"UPLOADED", "FAILED", "REJECTED"}
# Max age for bins in CREATED status (considered dead/stale) - 24 hours
MAX_CREATED_AGE_SECONDS = 24 * 60 * 60


def cleanup_collection(collection_id: str) -> tuple[int, int]:
    """
    Clean up finished and dead bins from a collection.
    Handles pagination to process ALL bins.

    Returns:
        Tuple of (deleted_count, error_count)
    """
    deleted = 0
    errors = 0
    current_time = time.time()
    last_bin_id: str | None = None

    try:
        while True:
            # Get bins in the collection (paginated)
            collection_data = _require_jsonbin_connector().get_collection_bins(
                collection_id, last_bin_id
            )

            if not collection_data:
                break  # No more bins

            for bin_data in collection_data:
                bin_id = bin_data["record"]
                last_bin_id = bin_id  # Track for pagination

                try:
                    bin_record = _require_jsonbin_connector().get_bin(bin_id)
                    status = bin_record.get("status", "UNKNOWN")
                    created_at = bin_record.get("created_at", 0)

                    should_delete = False
                    reason = ""

                    # Delete finished/failed bins
                    if status in CLEANUP_STATUSES:
                        should_delete = True
                        reason = f"status={status}"
                    # Delete stale CREATED bins (stuck/dead requests)
                    elif status == "CREATED" and created_at > 0:
                        age = current_time - created_at
                        if age > MAX_CREATED_AGE_SECONDS:
                            should_delete = True
                            reason = f"stale CREATED (age={age / 3600:.1f}h)"

                    if should_delete:
                        print(f"  Deleting bin {bin_id}: {reason}")
                        _require_jsonbin_connector().delete_bin(bin_id)
                        deleted += 1

                except Exception as e:
                    print(f"  Error processing bin {bin_id}: {e}")
                    errors += 1

    except Exception as e:
        print(f"  Error fetching collection bins: {e}")
        errors += 1

    return deleted, errors


def cleanup_all_collections():
    """Clean up all sideload collections on startup."""
    print("🧹 Cleaning up old bins...")
    total_deleted = 0
    total_errors = 0

    collections = _require_jsonbin_connector().get_collections()
    for collection in collections:
        if collection["collectionMeta"]["name"].startswith("sideload_"):
            collection_id = collection["record"]
            collection_name = collection["collectionMeta"]["name"]
            print(f"  Cleaning collection: {collection_name} ({collection_id})")

            deleted, errors = cleanup_collection(collection_id)
            total_deleted += deleted
            total_errors += errors

    print(f"✅ Cleanup complete: {total_deleted} bins deleted, {total_errors} errors")
    return total_deleted, total_errors


def clean_request(bin_id: str):
    """Clean up a completed request: delete packages (PyPI or NPM) and the JSONBin bin."""
    try:
        bin_data = _require_jsonbin_connector().get_bin(bin_id)
        status = bin_data.get("status", "UNKNOWN")
        print(f"  Bin {bin_id} status: {status}")

        if status not in CLEANUP_STATUSES:
            print(f"  ⚠️  Bin {bin_id} has status {status}, skipping cleanup")
            return

        # Get storage backend used for this request
        storage_backend = bin_data.get("storage_backend", "pypi").lower()

        # Delete packages if they exist
        package_names = bin_data.get("packages_names", [])
        if package_names:
            cleanup_package_names = package_names
            if storage_backend == "npm":
                cleanup_package_names = (
                    bin_data.get("packages_cleanup_names") or package_names
                )

            print(
                "  🗑️  Deleting "
                f"{len(cleanup_package_names)} {storage_backend.upper()} package(s)..."
            )

            if storage_backend == "npm":
                from sideloader.adapters.npm import npm_unpublish_packages_sync

                deleted, errors = npm_unpublish_packages_sync(cleanup_package_names)
            else:  # default to pypi
                from sideloader.adapters.pypi import delete_pypi_packages_sync

                deleted, errors = delete_pypi_packages_sync(cleanup_package_names)

            print(
                f"  📦 {storage_backend.upper()} cleanup: {deleted} deleted, {errors} errors"
            )
        else:
            print(f"  ℹ️  No packages to clean from {storage_backend.upper()}")

        # Delete the JSONBin bin
        _require_jsonbin_connector().delete_bin(bin_id)
        print(f"  ✅ Deleted bin {bin_id}")

    except Exception as e:
        print(f"  ❌ Error cleaning request {bin_id}: {e}")


def server_main():
    import argparse

    parser = argparse.ArgumentParser(description="Sideload server")
    parser.add_argument(
        "--request-id",
        type=str,
        default=None,
        help="Process a single request by JSONBin ID and exit",
    )
    parser.add_argument(
        "--clean-request-id",
        type=str,
        default=None,
        help="Clean up a completed request by JSONBin ID and exit",
    )
    parser.add_argument(
        "--dry-run-npm-token",
        action="store_true",
        help="Validate npm token cache/regeneration flow and exit",
    )
    parser.add_argument(
        "--force-regenerate-npm-token",
        action="store_true",
        help="Force npm token regeneration during --dry-run-npm-token",
    )
    parser.add_argument(
        "--npm-test-upload-file",
        type=str,
        default=None,
        help="Upload a local file to npm using NPM_BASE_PACKAGE and print refs",
    )
    parser.add_argument(
        "--npm-test-tag",
        type=str,
        default=None,
        help="Optional dist-tag for --npm-test-upload-file",
    )
    parser.add_argument(
        "--npm-test-unpublish",
        type=str,
        default=None,
        help="Unpublish an npm package spec, typically package@version",
    )
    args = parser.parse_args()

    if args.force_regenerate_npm_token and not args.dry_run_npm_token:
        parser.error("--force-regenerate-npm-token requires --dry-run-npm-token")
    if args.npm_test_tag and not args.npm_test_upload_file:
        parser.error("--npm-test-tag requires --npm-test-upload-file")

    selected_modes = sum(
        bool(value)
        for value in [
            args.request_id,
            args.clean_request_id,
            args.dry_run_npm_token,
            args.npm_test_upload_file,
            args.npm_test_unpublish,
        ]
    )
    if selected_modes > 1:
        parser.error(
            "Use only one mode at a time: "
            "--request-id, --clean-request-id, --dry-run-npm-token, "
            "--npm-test-upload-file, or --npm-test-unpublish"
        )

    if args.dry_run_npm_token:
        from sideloader.adapters.npm import dry_run_npm_token

        print("🔎 Running npm token dry-run")
        ok = dry_run_npm_token(force_regenerate=args.force_regenerate_npm_token)
        if not ok:
            print("❌ NPM token dry-run failed")
            raise SystemExit(1)
        print("✅ NPM token dry-run finished")
        return

    if args.npm_test_upload_file:
        file_path = Path(args.npm_test_upload_file).expanduser().resolve()
        if not npm_test_upload_file(file_path, requested_tag=args.npm_test_tag):
            raise SystemExit(1)
        return

    if args.npm_test_unpublish:
        if not npm_test_unpublish(args.npm_test_unpublish):
            raise SystemExit(1)
        return

    if args.clean_request_id:
        # Clean mode: delete the bin and exit
        print(f"🧹 Cleaning request: {args.clean_request_id}")
        clean_request(args.clean_request_id)
        print(f"✅ Finished cleaning request: {args.clean_request_id}")
        return

    if args.request_id:
        # Single-request mode: process one request and exit
        print(f"🎯 Processing single request: {args.request_id}")
        process_bin(args.request_id)
        print(f"✅ Finished processing request: {args.request_id}")
        return

    # Polling mode: clean up and watch all collections
    cleanup_all_collections()

    print("🚀 Starting sideload server...")
    collections = _require_jsonbin_connector().get_collections()
    for collection in collections:
        if collection["collectionMeta"]["name"].startswith("sideload_"):
            collection_id = collection["record"]
            collection_name = collection["collectionMeta"]["name"]
            print(f"  Watching collection: {collection_name} ({collection_id})")
            threading.Thread(target=watch_collection, args=(collection_id,)).start()


if __name__ == "__main__":
    server_main()
