"""Built-in SQL query templates shipped with siftd.

These queries can be copied into `~/.config/siftd/queries/` via:

    siftd copy query <name>
"""

