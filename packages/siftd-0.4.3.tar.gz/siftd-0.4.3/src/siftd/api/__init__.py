"""Public library API for siftd.

This module provides programmatic access to siftd functionality.
CLI commands are thin wrappers over these functions.
"""

from siftd.api.adapters import (
    AdapterInfo,
    list_adapters,
    list_builtin_adapters,
)
from siftd.api.conversations import (
    ConversationDetail,
    ConversationSummary,
    Exchange,
    NarrativeBlock,
    QueryError,
    QueryFile,
    QueryResult,
    ToolCallDetail,
    ToolCallSummary,
    Turn,
    get_conversation,
    get_recent_conversation_ids,
    list_conversations,
    list_query_files,
    resolve_entity_id,
    run_query_file,
)
from siftd.api.database import (
    create_database,
    open_database,
)
from siftd.api.doctor import (
    CheckInfo,
    Finding,
    list_checks,
    run_checks,
)
from siftd.api.export import (
    ExportedConversation,
    ExportOptions,
    export_conversations,
    format_exchanges,
    format_export,
    format_json,
    format_prompts,
)
from siftd.api.file_refs import (
    FileRef,
    fetch_file_refs,
)
from siftd.api.peek import (
    PeekExchange,
    SessionDetail,
    SessionInfo,
    find_session_file,
    list_active_sessions,
    read_session_detail,
    tail_session,
)
from siftd.api.resources import (
    CopyError,
    copy_adapter,
    copy_query,
    list_builtin_queries,
)
from siftd.api.stats import (
    DatabaseStats,
    HarnessInfo,
    TableCounts,
    ToolStats,
    WorkspaceStats,
    get_stats,
    list_workspaces,
)
from siftd.api.tags import (
    DERIVATIVE_TAG,
    TagInfo,
    apply_tag,
    delete_tag,
    get_or_create_tag,
    list_tags,
    remove_tag,
    rename_tag,
)
from siftd.api.tools import (
    TagUsage,
    WorkspaceTagUsage,
    get_tool_tag_summary,
    get_tool_tags_by_workspace,
)

# Search symbols are lazy-imported to avoid pulling numpy into non-search commands.
# Access via siftd.api.SearchResult etc. triggers __getattr__ below.
_LAZY_SEARCH_NAMES = {
    "ConversationScore",
    "IndexCompatError",
    "SearchResult",
    "build_index",
    "first_mention",
    "hybrid_search",
}


def __getattr__(name: str):
    if name in _LAZY_SEARCH_NAMES:
        from siftd.api import search as _search_mod

        val = getattr(_search_mod, name)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # adapters
    "AdapterInfo",
    "list_adapters",
    "list_builtin_adapters",
    # database
    "create_database",
    "open_database",
    # tags
    "DERIVATIVE_TAG",
    "TagInfo",
    "apply_tag",
    "delete_tag",
    "get_or_create_tag",
    "list_tags",
    "remove_tag",
    "rename_tag",
    # doctor
    "CheckInfo",
    "Finding",
    "list_checks",
    "run_checks",
    # peek
    "PeekExchange",
    "SessionDetail",
    "SessionInfo",
    "find_session_file",
    "list_active_sessions",
    "read_session_detail",
    "tail_session",
    # conversations
    "ConversationSummary",
    "ConversationDetail",
    "Exchange",
    "NarrativeBlock",
    "ToolCallDetail",
    "ToolCallSummary",
    "Turn",
    "get_recent_conversation_ids",
    "list_conversations",
    "get_conversation",
    "resolve_entity_id",
    # query files
    "QueryFile",
    "QueryResult",
    "QueryError",
    "list_query_files",
    "run_query_file",
    # file refs
    "FileRef",
    "fetch_file_refs",
    # resources
    "CopyError",
    "copy_adapter",
    "copy_query",
    "list_builtin_queries",
    # search
    "SearchResult",
    "ConversationScore",
    "IndexCompatError",
    "hybrid_search",
    "first_mention",
    "build_index",
    # stats
    "DatabaseStats",
    "TableCounts",
    "HarnessInfo",
    "WorkspaceStats",
    "ToolStats",
    "get_stats",
    "list_workspaces",
    # tools
    "TagUsage",
    "WorkspaceTagUsage",
    "get_tool_tag_summary",
    "get_tool_tags_by_workspace",
    # export
    "ExportedConversation",
    "ExportOptions",
    "export_conversations",
    "format_export",
    "format_exchanges",
    "format_json",
    "format_prompts",
]
