"""CLI handler for 'siftd search' — unified search over conversations.

Supports three modes:
- Hybrid (default with embeddings): FTS5 recall + semantic reranking
- FTS5-only (--fts or fallback): keyword search without embeddings
- Semantic-only (--semantic): pure embeddings without FTS5 recall
"""

import argparse
import sys
from pathlib import Path
from typing import cast

from siftd.cli_common import resolve_db
from siftd.paths import embeddings_db_path


def _apply_search_config(args) -> None:
    """Apply config defaults to args if no formatter flag is explicitly set."""
    from siftd.config import get_search_defaults

    # Check if any formatter-related flag was explicitly set
    formatter_flags = ["format", "json", "verbose", "full", "thread", "context", "conversations"]
    has_explicit_formatter = any(
        getattr(args, flag, None) not in (None, False)
        for flag in formatter_flags
    )

    if has_explicit_formatter:
        return

    # Apply config defaults
    defaults = get_search_defaults()
    for key, value in defaults.items():
        if getattr(args, key, None) is None:
            setattr(args, key, value)


def _print_empty_json_results(args, query: str, db: Path) -> None:
    """Emit empty JSON results for --json output modes."""
    from siftd.api import open_database
    from siftd.output import FormatterContext
    from siftd.output.formatters import JsonFormatter

    conn = open_database(db, read_only=True)
    try:
        ctx = FormatterContext(query=query, results=[], conn=conn, args=args)
        JsonFormatter().format(ctx)
    finally:
        conn.close()


def cmd_search(args) -> int:
    """Unified search over conversations — auto-selects FTS5 or semantic based on availability."""
    from siftd.api import open_database
    from siftd.api.search import open_embeddings_db, search_similar
    from siftd.embeddings import embeddings_available

    # Apply config defaults before processing
    _apply_search_config(args)

    db = resolve_db(args)
    embed_db = Path(args.embed_db) if args.embed_db else embeddings_db_path()

    if not db.exists():
        print(f"Database not found: {db}")
        print("Run 'siftd ingest' to create it.")
        return 1

    # Index or rebuild mode — requires embeddings
    if args.index or args.rebuild:
        if not embeddings_available():
            print("Semantic search requires the [embed] extra.", file=sys.stderr)
            print()
            print("Install with:")
            print("  siftd install embed")
            return 1
        return _search_build_index(db, embed_db, rebuild=args.rebuild, backend_name=args.backend, verbose=True)

    # Search mode — need a query
    query = " ".join(args.query) if args.query else ""
    if not query:
        print("Usage: siftd search <query>")
        print("       siftd search --index     (build/update index)")
        print("       siftd search --rebuild   (rebuild index from scratch)")
        return 1

    # --refs with --json is not supported (refs dump would break JSON validity)
    if args.json and args.refs:
        print("Error: --refs is not supported with --json", file=sys.stderr)
        return 1

    # --thread with --json: warn and ignore (JSON formatter doesn't use thread grouping)
    if args.json and args.thread:
        print("Note: --thread is ignored with --json output", file=sys.stderr)

    # Determine search mode: FTS5-only, semantic-only, or hybrid
    use_fts = getattr(args, "fts", False)
    use_semantic = getattr(args, "semantic", False)

    # Mutual exclusivity check
    if use_fts and use_semantic:
        print("Error: --fts and --semantic are mutually exclusive", file=sys.stderr)
        return 1

    # --fts mode: pure FTS5, no embeddings required
    if use_fts:
        return _search_fts_only(args, db, query)

    # Check embeddings availability for auto-selection
    has_embeddings = embeddings_available() and embed_db.exists()

    # --semantic mode: force embeddings-only (no FTS5 recall), error if unavailable
    if use_semantic:
        if not embeddings_available():
            print("Semantic search requires the [embed] extra.", file=sys.stderr)
            print()
            print("Install with:")
            print("  siftd install embed")
            return 1
        if not embed_db.exists():
            print("No embeddings index found.")
            print("Run 'siftd search --index' to build it.")
            return 1
        # Force embeddings-only mode (skip FTS5 recall)
        args.embeddings_only = True

    # Auto-selection: fall back to FTS5 if embeddings not fully available
    if not has_embeddings and not use_semantic:
        # Distinguish between "deps not installed" and "index missing"
        if embeddings_available() and not embed_db.exists():
            print("[FTS5 mode - embeddings index not built: siftd search --index]", file=sys.stderr)
        else:
            print("[FTS5 mode - for semantic search: siftd install embed]", file=sys.stderr)
        return _search_fts_only(args, db, query)

    # Resolve backend for query embedding
    from siftd.embeddings import get_backend
    try:
        backend = get_backend(preferred=args.backend, verbose=True)
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    # Compose filters: get candidate conversation IDs from main DB
    from siftd.api import DERIVATIVE_TAG
    from siftd.cli_common import parse_date
    from siftd.search import filter_conversations, get_active_conversation_ids

    exclude_tags = list(getattr(args, "no_tag", None) or [])
    if not args.include_derivative:
        exclude_tags.append(DERIVATIVE_TAG)

    candidate_ids = filter_conversations(
        db,
        workspace=args.workspace,
        model=args.model,
        since=parse_date(args.since),
        before=parse_date(args.before),
        tags=getattr(args, "tag", None),
        all_tags=getattr(args, "all_tags", None),
        exclude_tags=exclude_tags or None,
    )

    # Exclude conversations from active sessions (unless opted out)
    exclude_active_ids = set()
    if not args.no_exclude_active:
        exclude_active_ids = get_active_conversation_ids(db)
        if exclude_active_ids:
            if candidate_ids is not None:
                candidate_ids = candidate_ids - exclude_active_ids
            else:
                conn_tmp = open_database(db, read_only=True)
                all_ids = {
                    row["id"]
                    for row in conn_tmp.execute("SELECT id FROM conversations").fetchall()
                }
                conn_tmp.close()
                candidate_ids = all_ids - exclude_active_ids

    # Hybrid recall: FTS5 narrows candidates, embeddings rerank
    fts5_ids: set[str] | None = None
    fts5_mode: str | None = None
    if not args.embeddings_only:
        from siftd.api.search import fts5_recall_conversations

        main_conn = open_database(db, read_only=True)
        fts5_ids, fts5_mode = fts5_recall_conversations(main_conn, query, limit=args.recall)
        main_conn.close()

        if fts5_ids:
            if candidate_ids is not None:
                intersected = fts5_ids & candidate_ids
                candidate_ids = intersected if intersected else candidate_ids
            else:
                candidate_ids = fts5_ids
        elif fts5_mode == "none":
            print("FTS5 found no matches, falling back to pure embeddings.", file=sys.stderr)

    if candidate_ids is not None and not candidate_ids:
        if args.json:
            _print_empty_json_results(args, query, db)
        else:
            print("No conversations match the given filters.")
        return 0

    # Embed query and search
    use_mmr = not args.no_diversity
    query_embedding = backend.embed_one(query)
    embed_conn = open_embeddings_db(embed_db, read_only=True)

    # Validate index compatibility before search
    from siftd.api.search import IndexCompatError, validate_index_compat
    from siftd.embeddings import SCHEMA_VERSION

    try:
        validate_index_compat(
            embed_conn,
            backend_name=backend.name,
            backend_model=backend.model,
            backend_dimension=backend.dimension,
            current_schema_version=SCHEMA_VERSION,
        )
    except IndexCompatError as e:
        embed_conn.close()
        print(f"Error: {e}", file=sys.stderr)
        return 1

    # Widen initial search for modes that aggregate or filter post-hoc
    search_limit = args.limit
    if args.thread:
        search_limit = max(args.limit, 40)
    elif args.first or args.conversations:
        search_limit = max(args.limit * 10, 100)
    # Widen further for MMR to have candidates to diversify from
    if use_mmr:
        search_limit = max(search_limit * 3, search_limit)
    try:
        results: list[dict] = search_similar(
            embed_conn,
            query_embedding,
            limit=search_limit,
            conversation_ids=candidate_ids,
            include_embeddings=use_mmr,
        )
    except ValueError as e:
        embed_conn.close()
        print(f"Error: {e}", file=sys.stderr)
        return 1
    embed_conn.close()

    if not results:
        if args.json:
            _print_empty_json_results(args, query, db)
        else:
            print(f"No results for: {query}")
        return 0

    # Update breakdown with FTS5 recall info
    from siftd.search import ScoreBreakdown
    for r in results:
        if "breakdown" in r and isinstance(r["breakdown"], ScoreBreakdown):
            breakdown = r["breakdown"]
            if fts5_ids:
                breakdown.fts5_matched = r["conversation_id"] in fts5_ids
                breakdown.fts5_mode = fts5_mode if breakdown.fts5_matched else None
            else:
                breakdown.fts5_matched = False
                breakdown.fts5_mode = None

    # Apply temporal weighting if requested (before MMR so it affects reranking)
    if args.recency and results:
        from siftd.api.search import apply_temporal_weight, fetch_conversation_timestamps

        conv_ids_for_ts = list({r["conversation_id"] for r in results})
        ts_conn = open_database(db, read_only=True)
        timestamps = fetch_conversation_timestamps(ts_conn, conv_ids_for_ts)
        ts_conn.close()
        results = apply_temporal_weight(
            results,
            timestamps,
            half_life_days=args.recency_half_life,
            max_boost=args.recency_max_boost,
        )

    # Apply MMR diversity reranking
    if use_mmr and results:
        from siftd.search import mmr_rerank
        mmr_limit = args.limit
        if args.thread:
            mmr_limit = max(args.limit, 40)
        elif args.first or args.conversations:
            mmr_limit = max(args.limit * 10, 100)
        results = mmr_rerank(
            results,
            query_embedding,
            lambda_=args.lambda_,
            limit=mmr_limit,
        )

    # Apply threshold filter if specified
    if args.threshold is not None:
        results = [r for r in results if r["score"] >= args.threshold]
        if not results:
            if args.json:
                _print_empty_json_results(args, query, db)
            else:
                print(f"No results above threshold {args.threshold} for: {query}")
            return 0

    # Post-processing: --first (earliest match above threshold)
    if args.first:
        from siftd.api import first_mention
        effective_threshold = args.threshold if args.threshold is not None else 0.65
        earliest = first_mention(results, threshold=effective_threshold, db_path=db)
        if not earliest:
            if args.json:
                _print_empty_json_results(args, query, db)
            else:
                print(f"No results above relevance threshold for: {query}")
            return 0
        results = [cast(dict, earliest)]

    # Trim to requested limit after post-processing
    # Skip for modes that manage their own candidate pools:
    # - --conversations: aggregates per conversation, handles own limit
    # - --thread: widened pool for grouping, formatter handles presentation
    if not args.conversations and not args.thread:
        results = results[:args.limit]

    # Enrich results with metadata from main DB
    main_conn = open_database(db, read_only=True)

    # Enrich results with file refs (skip for --conversations mode)
    if not args.conversations:
        from siftd.api import fetch_file_refs
        all_source_ids = []
        for r in results:
            all_source_ids.extend(r.get("source_ids") or [])
        if all_source_ids:
            refs_by_prompt = fetch_file_refs(main_conn, all_source_ids)
            for r in results:
                r_refs = []
                for sid in (r.get("source_ids") or []):
                    r_refs.extend(refs_by_prompt.get(sid, []))
                r["file_refs"] = r_refs

    # Privacy warning for full content display
    if args.full or args.refs:
        print("Note: Showing full content which may contain sensitive information.", file=sys.stderr)

    # Select and run formatter
    from siftd.output import FormatterContext, print_refs_content, select_formatter
    try:
        formatter = select_formatter(args)
    except ValueError as e:
        main_conn.close()
        print(f"Error: {e}", file=sys.stderr)
        return 1

    try:
        # Warn if --by-time is used with a mode that ignores it
        if args.by_time:
            from siftd.output.formatters import (
                ConversationFormatter,
                JsonFormatter,
                ThreadFormatter,
            )
            if isinstance(formatter, (ConversationFormatter, ThreadFormatter, JsonFormatter)):
                mode = "conversation" if isinstance(formatter, ConversationFormatter) else \
                       "thread" if isinstance(formatter, ThreadFormatter) else "json"
                print(f"Note: --by-time has no effect in {mode} mode", file=sys.stderr)

        ctx = FormatterContext(query=query, results=results, conn=main_conn, args=args)
        formatter.format(ctx)

        # --refs content dump (post-processor, not part of formatter)
        if args.refs and not args.conversations:
            all_refs = []
            for r in results:
                all_refs.extend(r.get("file_refs") or [])
            filter_basenames = None
            if isinstance(args.refs, str):
                filter_basenames = [b.strip() for b in args.refs.split(",") if b.strip()]
            print_refs_content(all_refs, filter_basenames)

        # Tagging hint (skip for JSON output)
        if not args.json and results:
            first_id = results[0]["conversation_id"][:12]
            print(f"Tip: Tag useful results for future retrieval: siftd tag {first_id} research:<topic>", file=sys.stderr)
    finally:
        main_conn.close()

    return 0


def _search_fts_only(args, db: Path, query: str) -> int:
    """FTS5-only search mode — keyword search without embeddings."""
    import sqlite3

    from siftd.api import DERIVATIVE_TAG, open_database
    from siftd.api.search import fts5_search_content
    from siftd.cli_common import parse_date
    from siftd.search import filter_conversations, get_active_conversation_ids

    # Warn about flags that are ignored in FTS5-only mode
    unsupported_flags = []
    if args.thread:
        unsupported_flags.append("--thread")
    if args.context:
        unsupported_flags.append("--context")
    if args.full:
        unsupported_flags.append("--full")
    if args.verbose:
        unsupported_flags.append("--verbose/-v")
    if args.conversations:
        unsupported_flags.append("--conversations")
    if args.first:
        unsupported_flags.append("--first")
    if args.refs:
        unsupported_flags.append("--refs")
    if args.by_time:
        unsupported_flags.append("--by-time")
    if args.format:
        unsupported_flags.append("--format")

    if unsupported_flags:
        flags_str = ", ".join(unsupported_flags)
        print(f"WARNING: {flags_str} ignored in FTS5 mode (requires embeddings)", file=sys.stderr)

    # Compose filters
    exclude_tags = list(getattr(args, "no_tag", None) or [])
    if not args.include_derivative:
        exclude_tags.append(DERIVATIVE_TAG)

    candidate_ids = filter_conversations(
        db,
        workspace=args.workspace,
        model=args.model,
        since=parse_date(args.since),
        before=parse_date(args.before),
        tags=getattr(args, "tag", None),
        all_tags=getattr(args, "all_tags", None),
        exclude_tags=exclude_tags or None,
    )

    # Exclude active sessions
    exclude_active_ids = set()
    if not args.no_exclude_active:
        exclude_active_ids = get_active_conversation_ids(db)
        if exclude_active_ids:
            if candidate_ids is not None:
                candidate_ids = candidate_ids - exclude_active_ids
            else:
                conn_tmp = open_database(db, read_only=True)
                all_ids = {
                    row["id"]
                    for row in conn_tmp.execute("SELECT id FROM conversations").fetchall()
                }
                conn_tmp.close()
                candidate_ids = all_ids - exclude_active_ids

    # Run FTS5 search
    conn = open_database(db, read_only=True)
    try:
        try:
            raw_results = fts5_search_content(conn, query, limit=args.limit * 5)  # Overfetch for filtering
        except sqlite3.OperationalError as e:
            err_msg = str(e).lower()
            if "no such table" in err_msg and "fts" in err_msg:
                print("FTS index not found. Run 'siftd ingest' first.", file=sys.stderr)
            elif "fts5" in err_msg or "syntax" in err_msg:
                print(f"Invalid search query: {e}", file=sys.stderr)
                print("Tip: Check your search query for syntax errors.", file=sys.stderr)
            else:
                print(f"Database error: {e}", file=sys.stderr)
            return 1

        # Filter by candidate conversation IDs if filters were applied
        if candidate_ids is not None:
            raw_results = [r for r in raw_results if r["conversation_id"] in candidate_ids]

        # Limit results
        raw_results = raw_results[:args.limit]

        if not raw_results:
            if args.json:
                import json

                out = {
                    "query": query,
                    "mode": "fts5",
                    "results": [],
                }
                if unsupported_flags:
                    out["warnings"] = [
                        f"{flag} ignored in FTS5 mode (requires embeddings)"
                        for flag in unsupported_flags
                    ]
                print(json.dumps(out, indent=2))
                return 0
            print(f"No results for: {query}")
            return 0

        # Transform to common result format for formatters
        results = []
        for r in raw_results:
            results.append({
                "conversation_id": r["conversation_id"],
                "score": abs(r["rank"]),  # FTS5 rank is negative (lower = better)
                "text": r["snippet"],
                "side": r["side"],
                # Minimal fields needed for display
                "source_ids": [],
                "file_refs": [],
            })

        # JSON output
        if args.json:
            import json
            out = {
                "query": query,
                "mode": "fts5",
                "results": [
                    {
                        "conversation_id": r["conversation_id"],
                        "score": r["score"],
                        "snippet": r["text"],
                        "side": r["side"],
                    }
                    for r in results
                ],
            }
            if unsupported_flags:
                out["warnings"] = [
                    f"{flag} ignored in FTS5 mode (requires embeddings)"
                    for flag in unsupported_flags
                ]
            print(json.dumps(out, indent=2))
            return 0

        # Default text output — one result per line with snippet
        for r in results:
            cid = r["conversation_id"][:12]
            snippet = r["text"].replace("\n", " ")[:80]
            print(f"{cid}  {snippet}")

        # Tagging hint
        if results:
            first_id = results[0]["conversation_id"][:12]
            print(f"Tip: Tag useful results: siftd tag {first_id} research:<topic>", file=sys.stderr)

        return 0
    finally:
        conn.close()


def _search_build_index(db: Path, embed_db: Path, *, rebuild: bool, backend_name: str | None, verbose: bool) -> int:
    """Build or incrementally update the embeddings index."""
    from siftd.api import build_index
    from siftd.embeddings.indexer import IncrementalCompatError

    try:
        result = build_index(
            db_path=db,
            embed_db_path=embed_db,
            rebuild=rebuild,
            backend=backend_name,
            verbose=verbose,
        )
    except FileNotFoundError as e:
        print(str(e))
        print("Run 'siftd ingest' to create it.")
        return 1
    except IncrementalCompatError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if result["chunks_added"] == 0 and verbose:
        print(f"Index is up to date. ({result['total_chunks']} chunks)")

    return 0


def build_search_parser(subparsers) -> None:
    """Add the 'search' subparser to the CLI."""
    p_search = subparsers.add_parser(
        "search",
        help="Search conversations (auto-selects FTS5 or semantic based on what's installed)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Unified search: auto-selects the best available search mechanism.
- With embeddings installed: hybrid search (FTS5 recall + semantic reranking)
- Without embeddings: FTS5 keyword search (install embeddings: siftd install embed)

examples:
  # search (auto-selects best available mode)
  siftd search "error handling"                        # hybrid or FTS5 (auto)
  siftd search -w myproject "auth flow"                # filter by workspace
  siftd search --since 2024-06 "testing"               # filter by date

  # explicit mode selection
  siftd search --fts "error handling"                  # force FTS5 keyword search
  siftd search --semantic "auth flow"                  # force semantic search

  # refine
  siftd search "design decision" --thread              # narrative: top conversations expanded
  siftd search "why we chose X" --context 2            # ±2 surrounding exchanges
  siftd search "event sourcing" --conversations        # rank whole conversations, not chunks
  siftd search "when first discussed Y" --first        # earliest match above threshold
  siftd search --threshold 0.7 "architecture"          # only high-relevance results

  # inspect
  siftd search -v "chunking"                           # full chunk text
  siftd search --full "chunking"                       # complete prompt+response exchange
  siftd search --refs "authelia"                       # file references + content
  siftd search --refs HANDOFF.md "setup"               # filter refs to specific file

  # filter by tags
  siftd search -l research:auth "auth flow"            # search within tagged conversations
  siftd search -l research: -l useful: "pattern"       # OR — any research: or useful: tag
  siftd search --all-tags important --all-tags reviewed "design"  # AND — must have both
  siftd search -l research: --no-tag archived "auth"   # combine OR + NOT

  # save useful results for future retrieval
  siftd tag 01HX... research:auth                   # bookmark a conversation
  siftd tag --last research:architecture            # tag most recent conversation
  siftd query -l research:auth                      # retrieve tagged conversations

  # tuning
  siftd search --embeddings-only "chunking"            # skip FTS5, pure embeddings
  siftd search --recall 200 "error"                    # widen FTS5 candidate pool
  siftd search --by-time "chunking"                     # sort by time instead of score

  # diversity vs relevance (MMR reranking)
  siftd search --no-diversity "chunking"               # pure relevance order (deterministic)
  siftd search --lambda 0.5 "design"                   # more diverse results (less redundancy)
  siftd search --json "auth" | jq '.results[0].breakdown'  # score component breakdown""",
    )

    # Positional argument
    p_search.add_argument("query", nargs="*", help="Natural language search query")

    # Filtering options (most commonly used)
    filter_group = p_search.add_argument_group("filtering")
    filter_group.add_argument("-w", "--workspace", metavar="SUBSTR", help="Filter by workspace path substring")
    filter_group.add_argument("-m", "--model", metavar="NAME", help="Filter by model name")
    from siftd.cli_common import parse_date

    filter_group.add_argument("--since", metavar="DATE", type=parse_date, help="Conversations started after this date (YYYY-MM-DD, 7d, 1w, yesterday, today)")
    filter_group.add_argument("--before", metavar="DATE", type=parse_date, help="Conversations started before this date (YYYY-MM-DD, 7d, 1w, yesterday, today)")
    filter_group.add_argument("-l", "--tag", action="append", metavar="NAME", help="Filter by tag (repeatable, OR logic)")
    filter_group.add_argument("--all-tags", action="append", metavar="NAME", help="Require all specified tags (AND logic)")
    filter_group.add_argument("--no-tag", action="append", metavar="NAME", help="Exclude conversations with this tag (NOT logic)")

    # Output options
    output_group = p_search.add_argument_group("output")
    output_group.add_argument("-n", "--limit", type=int, default=10, help="Max results (default: 10)")
    output_group.add_argument("-v", "--verbose", action="store_true", help="Show full chunk text")
    output_group.add_argument("--full", action="store_true", help="Show complete prompt+response exchange")
    output_group.add_argument("--context", type=int, metavar="N", help="Show ±N exchanges around match")
    output_group.add_argument("--thread", action="store_true", help="Narrative thread: top conversations expanded, rest as shortlist")
    output_group.add_argument("--by-time", action="store_true", help="Sort results by time instead of score")
    output_group.add_argument("--json", action="store_true", help="Output as structured JSON")
    output_group.add_argument("--format", metavar="NAME", help="Use named formatter (built-in or drop-in plugin)")

    # Result modes
    mode_group = p_search.add_argument_group("result modes")
    mode_group.add_argument("--conversations", action="store_true", help="Aggregate scores per conversation, return ranked conversations")
    mode_group.add_argument("--first", action="store_true", help="Return chronologically earliest match above threshold")
    mode_group.add_argument("--refs", nargs="?", const=True, metavar="FILES", help="Show file references; optionally filter by comma-separated basenames")

    # Search mode selection
    mode_selection = p_search.add_argument_group("search mode")
    mode_selection.add_argument("--fts", action="store_true", help="Force FTS5 keyword search (no embeddings)")
    mode_selection.add_argument("--semantic", action="store_true", help="Force semantic search (requires embeddings)")

    # Search tuning
    tuning_group = p_search.add_argument_group("search tuning")
    tuning_group.add_argument("--embeddings-only", action="store_true", help="Skip FTS5 recall, use pure embeddings")
    tuning_group.add_argument("--recall", type=int, default=80, metavar="N", help="FTS5 conversation recall limit (default: 80)")
    tuning_group.add_argument("--threshold", type=float, metavar="SCORE", help="Filter results below this score (e.g., 0.7)")

    # Diversity (MMR reranking)
    diversity_group = p_search.add_argument_group("diversity")
    diversity_group.add_argument("--no-diversity", action="store_true", help="Disable MMR reranking for deterministic pure relevance order")
    diversity_group.add_argument("--lambda", type=float, default=0.7, dest="lambda_", metavar="FLOAT", help="MMR lambda: 1.0=relevance, 0.0=diversity (default: 0.7)")

    # Recency boost
    recency_group = p_search.add_argument_group("recency")
    recency_group.add_argument("--recency", action="store_true", help="Boost recent results (exponential decay, mild 15%% boost)")
    recency_group.add_argument("--recency-half-life", type=float, default=30.0, metavar="DAYS", help="Days until recency boost decays to half (default: 30)")
    recency_group.add_argument("--recency-max-boost", type=float, default=1.15, metavar="MULT", help="Max boost multiplier for today's results (default: 1.15)")

    # Scope options
    scope_group = p_search.add_argument_group("scope")
    scope_group.add_argument("--no-exclude-active", action="store_true", help="Include results from active sessions (excluded by default)")
    scope_group.add_argument("--include-derivative", action="store_true", help="Include derivative conversations (siftd search/query results)")

    # Index management
    index_group = p_search.add_argument_group("index management")
    index_group.add_argument("--index", action="store_true", help="Build/update embeddings index")
    index_group.add_argument("--rebuild", action="store_true", help="Rebuild embeddings index from scratch")
    index_group.add_argument("--backend", metavar="NAME", help="Embedding backend (ollama, fastembed)")
    index_group.add_argument("--embed-db", metavar="PATH", help="Alternate embeddings database path")

    p_search.set_defaults(func=cmd_search)
