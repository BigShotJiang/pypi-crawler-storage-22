"""Tests for SigAid protocol."""
