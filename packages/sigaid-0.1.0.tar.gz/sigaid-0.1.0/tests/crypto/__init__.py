"""Crypto module tests."""
