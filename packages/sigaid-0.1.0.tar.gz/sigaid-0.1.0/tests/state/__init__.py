"""State module tests."""
