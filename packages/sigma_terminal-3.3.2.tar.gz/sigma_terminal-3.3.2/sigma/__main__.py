"""Sigma entry point for `python -m sigma`."""

from sigma.cli import main

if __name__ == "__main__":
    main()
