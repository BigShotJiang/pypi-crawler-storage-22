#!/bin/bash
REPO_DIR=$(dirname $(dirname $(realpath $0)))

SIGNALBLAST_VERSION=$(uvx hatch version)
DOCKER_TAG="${SIGNALBLAST_VERSION//+/-}"

echo $REPO_DIR

docker run \
 --rm \
 -v $HOME/.local/share/signal-api/:/home/user/.local/share/signal-api/ \
 -v $HOME/.local/share/signalblast/:/home/user/.local/share/signalblast/ \
 -v $REPO_DIR:/home/user/signalblast \
 --interactive=true \
 --tty=true \
 --entrypoint bash \
 --network host \
 -e SIGNALBLAST_PHONE_NUMBER='PHONE_NUMBER' \
 -e SIGNALBLAST_PASSWORD='PASSWORD' \
  eradorta/signalblast:$DOCKER_TAG
