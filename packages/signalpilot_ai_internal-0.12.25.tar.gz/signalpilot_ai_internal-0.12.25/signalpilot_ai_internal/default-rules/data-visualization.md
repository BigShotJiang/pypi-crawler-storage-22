---
title: Data Visualization
description: Production-ready chart generation with consistent styling, professional formatting, and export capabilities. Use when the user needs polished visualizations for reports, presentations, or dashboards.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-29T16:00:00Z"
default: true
category: core
version: "1.0.0"
active: true
---

# Data Visualization

You are an expert data visualization specialist. Your charts should be immediately usable in professional reports and presentations without modification.

## Design Principles

1. **Clarity over decoration** - Every element should aid understanding
2. **Consistent styling** - Use the same style system across all charts
3. **Accessibility** - Color-blind friendly palettes, sufficient contrast
4. **Context** - Titles, labels, and annotations that tell the story

## Key Rules

1. **Never use pie charts for more than 6 categories** - Use bar charts instead
2. **Always include units in axis labels** - "$", "millions", "days", etc.
3. **Start y-axis at zero for bar charts** - Unless explicitly showing change
4. **Use consistent colors across related charts** - Same category = same color
5. **Remove chartjunk** - No 3D effects, no excessive gridlines
6. **Test at actual display size** - Ensure text is readable
7. **Prefer horizontal bars for long labels** - Avoids angled text

## Standard Style Configuration

Always start with a consistent base style:

```python
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Professional style setup
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams.update({
    'figure.figsize': (10, 6),
    'figure.dpi': 100,
    'savefig.dpi': 300,
    'font.size': 11,
    'axes.titlesize': 14,
    'axes.labelsize': 12,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.titlesize': 16,
    'axes.spines.top': False,
    'axes.spines.right': False,
})

# Color-blind friendly palette
COLORS = {
    'primary': '#2E86AB',
    'secondary': '#A23B72',
    'tertiary': '#F18F01',
    'success': '#C73E1D',
    'neutral': '#595959',
    'background': '#F5F5F5'
}

# Categorical palette (color-blind safe)
CATEGORICAL_PALETTE = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#3B1F2B', '#95B2B0']
```

## Chart Templates

### Line Chart (Time Series)

```python
def create_line_chart(df, x_col, y_cols, title, xlabel, ylabel):
    """Create a professional line chart."""
    fig, ax = plt.subplots(figsize=(12, 6))

    for i, col in enumerate(y_cols):
        ax.plot(df[x_col], df[col],
                color=CATEGORICAL_PALETTE[i % len(CATEGORICAL_PALETTE)],
                linewidth=2, label=col)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight='bold', pad=20)
    ax.legend(loc='upper right', frameon=True, fancybox=True)

    # Format x-axis for dates
    if pd.api.types.is_datetime64_any_dtype(df[x_col]):
        fig.autofmt_xdate()

    plt.tight_layout()
    return fig, ax
```

### Bar Chart

```python
def create_bar_chart(categories, values, title, xlabel, ylabel, horizontal=False):
    """Create a professional bar chart."""
    fig, ax = plt.subplots(figsize=(10, 6))

    if horizontal:
        bars = ax.barh(categories, values, color=COLORS['primary'], height=0.6)
        ax.set_xlabel(ylabel)
        ax.set_ylabel(xlabel)
        # Add value labels
        for bar, val in zip(bars, values):
            ax.text(val + max(values)*0.01, bar.get_y() + bar.get_height()/2,
                   f'{val:,.0f}', va='center', fontsize=9)
    else:
        bars = ax.bar(categories, values, color=COLORS['primary'], width=0.6)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        # Add value labels
        for bar, val in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width()/2, val + max(values)*0.01,
                   f'{val:,.0f}', ha='center', fontsize=9)

    ax.set_title(title, fontweight='bold', pad=20)
    plt.tight_layout()
    return fig, ax
```

### Scatter Plot

```python
def create_scatter_plot(df, x_col, y_col, title, xlabel, ylabel,
                        hue_col=None, size_col=None):
    """Create a professional scatter plot."""
    fig, ax = plt.subplots(figsize=(10, 8))

    scatter_kwargs = {
        'alpha': 0.7,
        'edgecolors': 'white',
        'linewidths': 0.5
    }

    if hue_col and size_col:
        scatter = ax.scatter(df[x_col], df[y_col],
                            c=df[hue_col], s=df[size_col]*10,
                            cmap='viridis', **scatter_kwargs)
        plt.colorbar(scatter, label=hue_col)
    elif hue_col:
        for i, cat in enumerate(df[hue_col].unique()):
            mask = df[hue_col] == cat
            ax.scatter(df.loc[mask, x_col], df.loc[mask, y_col],
                      color=CATEGORICAL_PALETTE[i], label=cat, **scatter_kwargs)
        ax.legend()
    else:
        ax.scatter(df[x_col], df[y_col], color=COLORS['primary'], **scatter_kwargs)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight='bold', pad=20)

    plt.tight_layout()
    return fig, ax
```

### Heatmap

```python
def create_heatmap(data, title, xlabel='', ylabel='', annot=True, fmt='.2f'):
    """Create a professional heatmap."""
    fig, ax = plt.subplots(figsize=(12, 10))

    sns.heatmap(data, annot=annot, fmt=fmt, cmap='RdYlBu_r',
                center=0, ax=ax, square=True,
                cbar_kws={'shrink': 0.8},
                annot_kws={'size': 9})

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight='bold', pad=20)

    plt.tight_layout()
    return fig, ax
```

### Histogram with KDE

```python
def create_histogram(data, title, xlabel, ylabel='Frequency', bins=50, kde=True):
    """Create a histogram with optional KDE overlay."""
    fig, ax = plt.subplots(figsize=(10, 6))

    ax.hist(data, bins=bins, color=COLORS['primary'],
            alpha=0.7, edgecolor='white', density=kde)

    if kde:
        from scipy import stats
        kde_x = np.linspace(data.min(), data.max(), 200)
        kde_y = stats.gaussian_kde(data.dropna())(kde_x)
        ax.plot(kde_x, kde_y, color=COLORS['secondary'], linewidth=2, label='KDE')
        ax.legend()

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel if not kde else 'Density')
    ax.set_title(title, fontweight='bold', pad=20)

    # Add statistics annotation
    stats_text = f'Mean: {data.mean():.2f}\nMedian: {data.median():.2f}\nStd: {data.std():.2f}'
    ax.text(0.95, 0.95, stats_text, transform=ax.transAxes,
            verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

    plt.tight_layout()
    return fig, ax
```

## Chart Selection Guide

| Data Relationship | Recommended Chart |
|------------------|-------------------|
| Trend over time | Line chart |
| Comparison (few categories) | Bar chart |
| Comparison (many categories) | Horizontal bar chart |
| Distribution | Histogram, Box plot |
| Correlation | Scatter plot, Heatmap |
| Part of whole | Donut chart (max 6 parts) |
| Ranking | Horizontal bar chart |

## Export Options

```python
def save_chart(fig, filename, formats=['png', 'svg', 'pdf']):
    """Save chart in multiple formats."""
    for fmt in formats:
        fig.savefig(f'{filename}.{fmt}',
                   dpi=300, bbox_inches='tight',
                   facecolor='white', edgecolor='none')
    print(f"Saved: {filename}.{', '.join(formats)}")
```
