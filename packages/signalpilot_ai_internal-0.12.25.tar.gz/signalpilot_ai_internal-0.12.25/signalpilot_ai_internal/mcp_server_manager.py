"""
MCP Server Manager.

Handles automatic startup and management of MCP servers (like dbt-mcp) when SignalPilot AI starts.
"""
import atexit
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

from signalpilot_ai_internal.db_config.storage import get_mcp_env_vars

logger = logging.getLogger(__name__)


class MCPServerManager:
    """Manages MCP server processes."""

    def __init__(self):
        self._processes: Dict[str, subprocess.Popen] = {}
        self._server_configs: Dict[str, Dict] = {}

        atexit.register(self.stop_all_servers)

    def add_server_config(
        self,
        name: str,
        command: List[str],
        cwd: Optional[str] = None,
        env: Optional[Dict[str, str]] = None,
        transport: str = "stdio"
    ):
        """Add an MCP server configuration.

        Args:
            name: Server identifier
            command: Command to start the server (as list)
            cwd: Working directory for the server process (default: None)
            env: Environment variables for the server (default: None)
            transport: MCP transport type (default: "stdio")
        """
        self._server_configs[name] = {
            'name': name,
            'command': command,
            'cwd': cwd,
            'env': env or {},
            'transport': transport
        }
        logger.info(f"Added MCP server config: {name}")
    
    def start_server(self, name: str) -> bool:
        """Start a specific MCP server.

        Args:
            name: Server identifier

        Returns:
            True if server started successfully, False otherwise
        """
        config = self._server_configs.get(name)
        if not config:
            logger.error(f"No configuration found for server: {name}")
            return False

        if name in self._processes:
            if self._processes[name].poll() is None:
                logger.info(f"MCP server '{name}' is already running")
                return True
            del self._processes[name]

        try:
            logger.info(f"Starting MCP server '{name}' with command: {' '.join(config['command'])}")
            use_pipes = config['transport'] != 'http'
            process = self._create_process(config, use_pipes)
            self._processes[name] = process
            logger.info(f"MCP server '{name}' started with PID: {process.pid}")
            return True
        except Exception as e:
            logger.error(f"Failed to start MCP server '{name}': {e}")
            return False

    def _create_process(self, config: Dict, use_pipes: bool) -> subprocess.Popen:
        """Create subprocess with appropriate pipe configuration.

        Args:
            config: Server configuration dict
            use_pipes: True for stdio transport (needs pipes), False for HTTP

        Returns:
            Started subprocess
        """
        env = os.environ.copy()
        env.update(config['env'])
        env['MCP_TRANSPORT'] = config['transport']

        if use_pipes:
            return subprocess.Popen(
                config['command'],
                cwd=config['cwd'],
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.PIPE,
                bufsize=0
            )
        return subprocess.Popen(
            config['command'],
            cwd=config['cwd'],
            env=env,
            stdout=None,
            stderr=None,
            stdin=subprocess.DEVNULL
        )
    
    def start_all_servers(self) -> Dict[str, bool]:
        """Start all configured MCP servers.

        Returns:
            Dictionary mapping server names to start success status
        """
        return {name: self.start_server(name) for name in self._server_configs}
    
    def stop_server(self, name: str) -> bool:
        """Stop a specific MCP server.

        Args:
            name: Server identifier

        Returns:
            True if server stopped successfully, False otherwise
        """
        if name not in self._processes:
            logger.warning(f"MCP server '{name}' is not running")
            return False

        try:
            process = self._processes[name]
            process.terminate()

            try:
                process.wait(timeout=5)
                logger.info(f"MCP server '{name}' terminated gracefully")
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                logger.warning(f"MCP server '{name}' was force killed")

            del self._processes[name]
            return True
        except Exception as e:
            logger.error(f"Failed to stop MCP server '{name}': {e}")
            return False

    def stop_all_servers(self):
        """Stop all running MCP servers."""
        for name in list(self._processes.keys()):
            self.stop_server(name)

    def get_server_status(self, name: str) -> Optional[str]:
        """Get the status of a specific server.

        Args:
            name: Server identifier

        Returns:
            'running', 'stopped', or None if not configured
        """
        if name not in self._server_configs:
            return None

        if name not in self._processes:
            return 'stopped'

        return 'running' if self._processes[name].poll() is None else 'stopped'

    def get_all_server_status(self) -> Dict[str, Optional[str]]:
        """Get status of all configured servers.

        Returns:
            Dictionary mapping server names to their status
        """
        return {name: self.get_server_status(name) for name in self._server_configs}
    
    def get_server_logs(self, name: str) -> Dict[str, str]:
        """Get recent stdout/stderr logs from a server.

        Args:
            name: Server identifier

        Returns:
            Dictionary with 'stdout' and 'stderr' keys containing log output
        """
        if name not in self._processes:
            return {"stdout": "", "stderr": "", "error": "Server not running"}

        process = self._processes[name]
        logs = {"stdout": "", "stderr": ""}

        try:
            import select

            logs["stdout"] = self._read_stream(process.stdout, select)
            logs["stderr"] = self._read_stream(process.stderr, select)
        except Exception as e:
            logs["error"] = f"Error reading logs: {e}"

        return logs

    def _read_stream(self, stream, select_module) -> str:
        """Read from a stream non-blocking.

        Args:
            stream: File stream to read from
            select_module: The select module for Unix systems

        Returns:
            String content or error message
        """
        if not stream:
            return ""

        if hasattr(select_module, 'select'):
            if select_module.select([stream], [], [], 0)[0]:
                return stream.read(4096).decode('utf-8', errors='ignore')
            return ""

        try:
            return stream.read(4096).decode('utf-8', errors='ignore')
        except Exception:
            return "(Unable to read - pipe may be blocking)"


# Global instance
_mcp_server_manager: Optional[MCPServerManager] = None


def get_mcp_server_manager() -> MCPServerManager:
    """Get the global MCP server manager instance"""
    global _mcp_server_manager
    if _mcp_server_manager is None:
        _mcp_server_manager = MCPServerManager()
    return _mcp_server_manager


def configure_default_servers(workspace_dir: str):
    """Configure default MCP servers for SignalPilot AI.

    Parameters
    ----------
    workspace_dir : str
        Jupyter workspace root directory (server_app.root_dir).
    """
    manager = get_mcp_server_manager()
    signalpilot_ai_internal_dir = Path(__file__).parent

    # Configure signalpilot MCP server (HTTP transport)
    mcp_server_dir = signalpilot_ai_internal_dir.parent / "mcp_server"
    if mcp_server_dir.exists():
        db_env_vars = get_mcp_env_vars()

        env = {
            **db_env_vars,
            "ROOT_DIR": workspace_dir,
        }

        manager.add_server_config(
            name="signalpilot-mcp",
            command=["uv", "run", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", "8235"],
            cwd=str(mcp_server_dir),
            env=env,
            transport="http"
        )
        logger.info(f"Configured signalpilot-mcp server at {mcp_server_dir}")
        # Note: signalpilot client config is now a built-in server in mcp_service/constants.py
    else:
        logger.warning(f"mcp_server directory not found at {mcp_server_dir}")

    # Configure dbt-mcp server
    dbt_mcp_dir = signalpilot_ai_internal_dir / "dbt-mcp"

    if dbt_mcp_dir.exists():
        # Use the Python executable that's running this process
        python_executable = sys.executable

        # Command to run dbt-mcp using the main module
        dbt_mcp_command = [
            python_executable,
            "-m",
            "dbt_mcp.main"
        ]

        manager.add_server_config(
            name="dbt-mcp",
            command=dbt_mcp_command,
            cwd=str(dbt_mcp_dir),
            env={},
            transport="stdio"
        )
        logger.info(f"Configured dbt-mcp server at {dbt_mcp_dir}")
    else:
        logger.warning(f"dbt-mcp directory not found at {dbt_mcp_dir}")


def autostart_mcp_servers(workspace_dir: str):
    """Automatically start all configured MCP servers.

    Parameters
    ----------
    workspace_dir : str
        Jupyter workspace root directory (server_app.root_dir).
    """
    configure_default_servers(workspace_dir)
    manager = get_mcp_server_manager()
    results = manager.start_all_servers()
    
    for name, success in results.items():
        if success:
            logger.info(f"✓ MCP server '{name}' started successfully")
        else:
            logger.error(f"✗ MCP server '{name}' failed to start")
    
    return results
