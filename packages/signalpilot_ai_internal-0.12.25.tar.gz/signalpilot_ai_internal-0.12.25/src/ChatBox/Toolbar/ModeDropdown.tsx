/**
 * ModeDropdown - Unified mode selector with auto-run toggle
 *
 * Combines Executive Mode and Auto Run into a single dropdown:
 * - MODE section: Audit Mode / Executive Mode
 * - EXECUTION section: Auto Run toggle
 *
 * Mode switching logic:
 * - Executive Mode: sets autoRun=true (user can still toggle off)
 * - Audit Mode: sets autoRun=false
 */

import * as React from 'react';
// @ts-ignore - createPortal types may not be available in all environments
import { createPortal } from 'react-dom';
import { useState, useRef, useEffect, useCallback } from 'react';
import { useSettingsStore } from '@/stores/settingsStore';

// ═══════════════════════════════════════════════════════════════
// SVG ICONS
// ═══════════════════════════════════════════════════════════════

const ChevronIcon = ({ open }: { open: boolean }) => (
  <svg
    width="12"
    height="12"
    viewBox="0 0 12 12"
    fill="none"
    style={{
      transition: 'transform 0.2s ease',
      transform: open ? 'rotate(180deg)' : 'rotate(0deg)'
    }}
  >
    <path
      d="M3 4.5L6 7.5L9 4.5"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const AuditIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <rect
      x="1.5"
      y="3"
      width="13"
      height="10"
      rx="1.5"
      stroke="currentColor"
      strokeWidth="1.3"
    />
    <path
      d="M4.5 6.5L6.5 8.5L4.5 10.5"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M8 10.5h3.5"
      stroke="currentColor"
      strokeWidth="1.3"
      strokeLinecap="round"
    />
  </svg>
);

const ExecutiveIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <rect
      x="1.5"
      y="2"
      width="13"
      height="4"
      rx="1.2"
      stroke="currentColor"
      strokeWidth="1.3"
    />
    <rect
      x="1.5"
      y="8"
      width="6"
      height="6"
      rx="1.2"
      stroke="currentColor"
      strokeWidth="1.3"
    />
    <rect
      x="9.5"
      y="8"
      width="5"
      height="6"
      rx="1.2"
      stroke="currentColor"
      strokeWidth="1.3"
    />
  </svg>
);

const CheckIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path
      d="M3.5 7.5L5.5 9.5L10.5 4.5"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const AutoRunIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path
      d="M7 1v2M7 11v2M1 7h2M11 7h2M2.76 2.76l1.41 1.41M9.83 9.83l1.41 1.41M11.24 2.76l-1.41 1.41M4.17 9.83l-1.41 1.41"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
    />
    <circle cx="7" cy="7" r="2.25" stroke="currentColor" strokeWidth="1.2" />
  </svg>
);

// ═══════════════════════════════════════════════════════════════
// TOGGLE COMPONENT
// ═══════════════════════════════════════════════════════════════

interface ToggleProps {
  checked: boolean;
  onChange: (value: boolean) => void;
}

const Toggle = ({ checked, onChange }: ToggleProps) => (
  <button
    className="sage-mode-dropdown-toggle"
    onClick={() => onChange(!checked)}
    data-checked={checked}
    type="button"
    aria-checked={checked}
    role="switch"
  >
    <div className="sage-mode-dropdown-toggle-knob" />
  </button>
);

// ═══════════════════════════════════════════════════════════════
// MODE CONFIG
// ═══════════════════════════════════════════════════════════════

type ModeKey = 'audit' | 'executive';

interface ModeConfig {
  key: ModeKey;
  label: string;
  desc: string;
  icon: JSX.Element;
  color: string;
}

const MODES: ModeConfig[] = [
  {
    key: 'audit',
    label: 'Audit Mode',
    desc: 'Full code visibility & manual control',
    icon: <AuditIcon />,
    color: '#a78bfa'
  },
  {
    key: 'executive',
    label: 'Executive Mode',
    desc: 'Streamlined — less code, auto-run on',
    icon: <ExecutiveIcon />,
    color: '#ec4899'
  }
];

// ═══════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════

export function ModeDropdown(): JSX.Element {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [panelPos, setPanelPos] = useState({ top: 0, left: 0 });

  // Store state (all persisted in settingsStore via localStorage)
  const autoRun = useSettingsStore(state => state.autoRun);
  const setAutoRun = useSettingsStore(state => state.setAutoRun);
  const executiveMode = useSettingsStore(state => state.executiveMode);
  const setExecutiveMode = useSettingsStore(state => state.setExecutiveMode);

  const currentMode: ModeKey = executiveMode ? 'executive' : 'audit';
  const currentConfig = MODES.find(m => m.key === currentMode)!;

  // Calculate panel position from trigger button rect
  const updatePosition = useCallback(() => {
    if (!triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    const panelWidth = 280;
    let left = rect.right - panelWidth;
    if (left < 8) left = 8;
    setPanelPos({ top: rect.bottom + 6, left });
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    if (!open) return;

    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        triggerRef.current?.contains(target) ||
        panelRef.current?.contains(target)
      ) {
        return;
      }
      setOpen(false);
    };

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [open]);

  // Update position when opened or on scroll/resize
  useEffect(() => {
    if (!open) return;
    updatePosition();

    window.addEventListener('resize', updatePosition);
    window.addEventListener('scroll', updatePosition, true);
    return () => {
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition, true);
    };
  }, [open, updatePosition]);

  const handleToggle = useCallback(() => {
    setOpen(prev => !prev);
  }, []);

  const handleModeChange = useCallback(
    (modeKey: ModeKey) => {
      if (modeKey === 'executive') {
        setExecutiveMode(true);
        setAutoRun(true);
      } else {
        setExecutiveMode(false);
        setAutoRun(false);
      }
    },
    [setExecutiveMode, setAutoRun]
  );

  const handleAutoRunChange = useCallback(
    (value: boolean) => {
      setAutoRun(value);
    },
    [setAutoRun]
  );

  const panelContent = open
    ? createPortal(
        <div
          ref={panelRef}
          className="sage-mode-dropdown-panel"
          style={{
            position: 'fixed',
            top: panelPos.top,
            left: panelPos.left,
            zIndex: 10000
          }}
        >
          {/* Mode Section Header */}
          <div className="sage-mode-dropdown-section-header">Mode</div>

          {/* Mode Options */}
          {MODES.map(m => {
            const active = currentMode === m.key;
            return (
              <button
                key={m.key}
                className="sage-mode-dropdown-item"
                onClick={() => handleModeChange(m.key)}
                data-active={active}
                style={
                  {
                    '--mode-color': m.color
                  } as React.CSSProperties
                }
                type="button"
              >
                <span className="sage-mode-dropdown-item-icon">{m.icon}</span>
                <div className="sage-mode-dropdown-item-content">
                  <div className="sage-mode-dropdown-item-label">{m.label}</div>
                  <div className="sage-mode-dropdown-item-desc">{m.desc}</div>
                </div>
                {active && (
                  <span className="sage-mode-dropdown-item-check">
                    <CheckIcon />
                  </span>
                )}
              </button>
            );
          })}

          {/* Divider */}
          <div className="sage-mode-dropdown-divider" />

          {/* Execution Section Header */}
          <div className="sage-mode-dropdown-section-header">Execution</div>

          {/* Auto Run Toggle */}
          <div className="sage-mode-dropdown-autorun">
            <span className="sage-mode-dropdown-autorun-icon">
              <AutoRunIcon />
            </span>
            <div className="sage-mode-dropdown-autorun-content">
              <div className="sage-mode-dropdown-autorun-label">Auto Run</div>
              <div className="sage-mode-dropdown-autorun-desc">
                Auto-approve code generations
              </div>
            </div>
            <Toggle checked={autoRun} onChange={handleAutoRunChange} />
          </div>
        </div>,
        document.body
      )
    : null;

  return (
    <div className="sage-mode-dropdown" data-mode={currentMode}>
      {/* Trigger Button */}
      <button
        ref={triggerRef}
        className="sage-mode-dropdown-trigger"
        onClick={handleToggle}
        type="button"
        data-open={open}
        style={{ color: currentConfig.color }}
      >
        <span className="sage-mode-dropdown-trigger-icon">
          {currentConfig.icon}
        </span>
        {currentConfig.label}
        <ChevronIcon open={open} />
      </button>

      {/* Dropdown Panel - portaled to document.body */}
      {panelContent}
    </div>
  );
}
