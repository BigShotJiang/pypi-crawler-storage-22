@echo off
echo === Cleaning all build artifacts ===
call jlpm run clean:all
if %errorlevel% neq 0 exit /b %errorlevel%

echo === Building extension ===
call jlpm run build
if %errorlevel% neq 0 exit /b %errorlevel%

echo === Build complete ===
exit
