"""Databricks database configuration."""
