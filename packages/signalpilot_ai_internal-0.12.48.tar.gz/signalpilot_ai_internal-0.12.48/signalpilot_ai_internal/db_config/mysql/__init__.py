"""MySQL database configuration."""
