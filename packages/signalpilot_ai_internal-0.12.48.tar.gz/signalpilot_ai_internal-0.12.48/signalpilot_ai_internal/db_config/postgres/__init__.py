"""PostgreSQL database configuration."""
