"""Snowflake database configuration."""
