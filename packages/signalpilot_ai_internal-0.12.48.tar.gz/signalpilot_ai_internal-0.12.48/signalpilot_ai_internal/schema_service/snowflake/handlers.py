"""Snowflake schema service handlers."""

import json
import re
from typing import Any, Dict, List, Optional

import tornado.web
from jupyter_server.base.handlers import APIHandler

from signalpilot_ai_internal.schema_service.base.config import ConfigLoader
from signalpilot_ai_internal.schema_service.base.handlers import BaseQueryHandler
from signalpilot_ai_internal.schema_service.base.package_manager import PackageManager
from signalpilot_ai_internal.schema_service.snowflake.extractor import SnowflakeSchemaExtractor
from signalpilot_ai_internal.schema_service.snowflake.warehouse import WarehouseManager


def _get_snowflake_config(provided: Optional[Dict] = None) -> Optional[Dict]:
    """Get Snowflake configuration from request or environment."""
    if provided:
        return provided
    return ConfigLoader.get_config_by_type("snowflake")


def _get_connection_params(config: Dict) -> Dict[str, Any]:
    """Build Snowflake connection parameters from configuration."""
    connection_url = config.get("connectionUrl", "")
    if not connection_url:
        raise ValueError("connectionUrl is required for Snowflake")

    url_match = re.match(r"https?://([^/]+)", connection_url)
    if not url_match:
        raise ValueError(f"Invalid Snowflake connectionUrl format: {connection_url}")

    account = url_match.group(1).replace(".snowflakecomputing.com", "")

    conn_params = {
        "account": account,
        "user": config["username"],
        "password": config["password"],
    }

    if config.get("warehouse"):
        conn_params["warehouse"] = config["warehouse"]
    if config.get("database"):
        conn_params["database"] = config["database"]
    if config.get("role"):
        conn_params["role"] = config["role"]

    return conn_params


def _get_connector():
    """Get Snowflake connector module."""
    PackageManager.ensure_installed("snowflake")
    import snowflake.connector
    return snowflake.connector


class SnowflakeSchemaHandler(APIHandler):
    """Handler for Snowflake schema operations."""

    @tornado.web.authenticated
    def post(self):
        """Get Snowflake database schema information."""
        try:
            try:
                body = json.loads(self.request.body.decode("utf-8"))
            except json.JSONDecodeError:
                body = {}

            config = _get_snowflake_config(body.get("config"))
            if not config:
                self.set_status(400)
                self.finish(json.dumps({
                    "error": "No Snowflake configuration provided and none found in environment"
                }))
                return

            try:
                connector = _get_connector()
            except ImportError as e:
                self.set_status(500)
                self.finish(json.dumps({"error": str(e)}))
                return

            try:
                conn_params = _get_connection_params(config)
                max_workers = int(body.get("max_workers", 5))

                specified_database = config.get("database")
                specified_warehouse = config.get("warehouse")

                connection = connector.connect(**conn_params, client_session_keep_alive=False)
                try:
                    cursor = connection.cursor(connector.DictCursor)

                    # Ensure warehouse
                    if specified_warehouse:
                        warehouse = specified_warehouse
                        cursor.execute(f'USE WAREHOUSE "{warehouse}"')
                    else:
                        warehouse = WarehouseManager.ensure_warehouse(cursor, None)
                        cursor.execute(f'USE WAREHOUSE "{warehouse}"')

                    cursor.close()

                    # Extract schema
                    extractor = SnowflakeSchemaExtractor(connector, connection)
                    databases = [specified_database] if specified_database else None
                    catalog = extractor.build_catalog(warehouse, databases, max_workers)

                    self.finish(json.dumps(catalog, indent=2))
                finally:
                    connection.close()

            except Exception as e:
                self.set_status(500)
                self.finish(json.dumps({"error": f"Error connecting to Snowflake: {str(e)}"}))

        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": "Internal server error", "message": str(e)}))


class SnowflakeQueryHandler(BaseQueryHandler):
    """Handler for Snowflake query execution."""

    db_type = "snowflake"

    def _get_config(self, body: Dict) -> Optional[Dict]:
        """Get Snowflake config from request or environment."""
        config = _get_snowflake_config(body.get("config"))
        if config and body.get("database"):
            config = dict(config)  # Copy to avoid mutating original
            config["database"] = body["database"]
        return config

    def execute_query(self, config: Dict, query: str) -> List[Dict[str, Any]]:
        """Execute query on Snowflake."""
        connector = _get_connector()
        conn_params = _get_connection_params(config)

        if not conn_params.get("warehouse"):
            raise ValueError("A warehouse is required to execute queries.")

        connection = connector.connect(**conn_params)
        cursor = connection.cursor()
        try:
            cursor.execute(query)
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = cursor.fetchall()
            return [{columns[i]: row[i] for i in range(len(columns))} for row in rows]
        finally:
            cursor.close()
            connection.close()
