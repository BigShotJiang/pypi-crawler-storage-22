from zipfile import ZipFile

from .paratext_project_text_updater_base import ParatextProjectTextUpdaterBase
from .zip_paratext_project_file_handler import ZipParatextProjectFileHandler
from .zip_paratext_project_settings_parser import ZipParatextProjectSettingsParser


class ZipParatextProjectTextUpdater(ParatextProjectTextUpdaterBase):
    def __init__(self, archive: ZipFile) -> None:
        super().__init__(ZipParatextProjectFileHandler(archive), ZipParatextProjectSettingsParser(archive).parse())
