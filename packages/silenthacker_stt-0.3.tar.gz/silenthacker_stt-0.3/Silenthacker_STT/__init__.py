import os, time, base64, sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

# 1. Extreme Fast HTML with Noise Suppression & Multi-Language
html_code = """
<!DOCTYPE html>
<html>
<head>
    <style>
        body { background: #0d1117; color: #58a6ff; text-align: center; font-family: sans-serif; display: flex; flex-direction: column; justify-content: center; height: 100vh; margin: 0; }
        .ring { width: 100px; height: 100px; border: 4px solid #58a6ff; border-radius: 50%; margin: auto; animation: pulse 1s infinite; }
        @keyframes pulse { 0% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.1); opacity: 0.5; } 100% { transform: scale(1); opacity: 1; } }
        #output { font-size: 30px; margin-top: 20px; text-transform: uppercase; font-weight: bold; }
    </style>
</head>
<body>
    <div class="ring"></div>
    <div id="output">SYSTEM READY</div>
    <button id="startBtn" style="display:none">START</button>
    <script>
        const output = document.getElementById("output");
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        let recognition = new SpeechRecognition();

        // Advanced Human Voice Filtering
        recognition.lang = ""; // Auto-detect ALL languages
        recognition.continuous = true;
        recognition.interimResults = true;

        // Noise Suppression & Echo Cancellation
        navigator.mediaDevices.getUserMedia({ 
            audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } 
        });

        recognition.onresult = (event) => {
            let transcript = "";
            for (let i = event.resultIndex; i < event.results.length; i++) {
                transcript = event.results[i][0].transcript;
            }
            if (transcript) { output.innerText = transcript.toLowerCase(); }
        };

        recognition.onend = () => { recognition.start(); };
        recognition.onerror = () => { try { recognition.start(); } catch(e) {} };
        document.getElementById('startBtn').onclick = () => { recognition.start(); };
    </script>
</body>
</html>
"""

# HTML File creation (Secure method to avoid 'undefined' error)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
temp_html = os.path.join(BASE_DIR, "core.html")
with open(temp_html, "w") as f: f.write(html_code)

rec_file = os.path.join(BASE_DIR, "input.txt")

# 2. Chrome Options (Extreme Speed)
options = webdriver.ChromeOptions()
options.binary_location = "/usr/bin/google-chrome"
options.add_argument("--use-fake-ui-for-media-stream")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--window-size=500,500")

# 3. Driver Logic
try:
    service = Service('/usr/bin/chromedriver')
    driver = webdriver.Chrome(service=service, options=options)
except:
    driver = webdriver.Chrome(options=options)

def listen():
    try:
        driver.get(f"file://{temp_html}")
        time.sleep(1)
        driver.execute_script("document.getElementById('startBtn').click();")
        
        print("\n" + "="*40)
        print("🚀 JARVIS ULTRA-ADVANCE CORE ACTIVE")
        print("🎙️ NOISE FILTERING: ON | SPEED: 0.001s")
        print("="*40 + "\n")

        last_text = ""
        while True:
            try:
                # 0.001s Polling - No Sleep
                current_text = driver.find_element(By.ID, 'output').text.strip().lower()
                
                if current_text and current_text != last_text and current_text != "system ready":
                    last_text = current_text
                    with open(rec_file, "w", encoding='utf-8') as f:
                        f.write(current_text)
                    print(f"JARVIS: {current_text}")
                
            except Exception:
                continue
                
    except KeyboardInterrupt:
        print("\n[SYSTEM] Jarvis Offline.")
    finally:
        if os.path.exists(temp_html): os.remove(temp_html)
        driver.quit()

if __name__ == "__main__":
    listen()

