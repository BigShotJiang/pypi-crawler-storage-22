from setuptools import setup, find_packages

setup(
    name='Silenthacker_STT',
    version='0.3',
    author='Lovely hacker',
    author_email='silenthacker036@gmail.com',
    description='this is speech to text package created by lovely hacker',
    packages=find_packages(),
    install_requires=[
        'selenium',
        'webdriver_manager'
    ]
)
