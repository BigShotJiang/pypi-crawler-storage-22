from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_twap_order_dto_market_type import CreateTwapOrderDtoMarketType
from ..models.create_twap_order_dto_order_intent import CreateTwapOrderDtoOrderIntent
from ..models.create_twap_order_dto_order_side import CreateTwapOrderDtoOrderSide
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateTwapOrderDto")


@_attrs_define
class CreateTwapOrderDto:
    """
    Attributes:
        lots (float):  Default: 6.0.
        asset_id (str):  Default: 'BTC'.
        amount (str):  Default: '6'.
        price_lower_bound (Union[None, str]):  Default: '0.01'.
        price_upper_bound (Union[None, str]):  Default: '2000000'.
        start_time (float):  Default: 2000000000.0.
        end_time (float):  Default: 2000001000.0.
        order_side (CreateTwapOrderDtoOrderSide): Order side - buy or sell
        market_type (CreateTwapOrderDtoMarketType): Market type - spot or perpetual
        wallet_id (Union[Unset, str]):
        slippage (Union[Unset, str]): Slippage tolerance Default: '0.001'.
        order_intent (Union[Unset, CreateTwapOrderDtoOrderIntent]): Order intent - open or close position (required for
            perp orders)
    """

    order_side: CreateTwapOrderDtoOrderSide
    market_type: CreateTwapOrderDtoMarketType
    lots: float = 6.0
    asset_id: str = "BTC"
    amount: str = "6"
    price_lower_bound: Union[None, str] = "0.01"
    price_upper_bound: Union[None, str] = "2000000"
    start_time: float = 2000000000.0
    end_time: float = 2000001000.0
    wallet_id: Union[Unset, str] = UNSET
    slippage: Union[Unset, str] = "0.001"
    order_intent: Union[Unset, CreateTwapOrderDtoOrderIntent] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        lots = self.lots

        asset_id = self.asset_id

        amount = self.amount

        price_lower_bound: Union[None, str]
        price_lower_bound = self.price_lower_bound

        price_upper_bound: Union[None, str]
        price_upper_bound = self.price_upper_bound

        start_time = self.start_time

        end_time = self.end_time

        order_side = self.order_side.value

        market_type = self.market_type.value

        wallet_id = self.wallet_id

        slippage = self.slippage

        order_intent: Union[Unset, str] = UNSET
        if not isinstance(self.order_intent, Unset):
            order_intent = self.order_intent.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "lots": lots,
                "assetId": asset_id,
                "amount": amount,
                "priceLowerBound": price_lower_bound,
                "priceUpperBound": price_upper_bound,
                "startTime": start_time,
                "endTime": end_time,
                "order_side": order_side,
                "market_type": market_type,
            }
        )
        if wallet_id is not UNSET:
            field_dict["walletId"] = wallet_id
        if slippage is not UNSET:
            field_dict["slippage"] = slippage
        if order_intent is not UNSET:
            field_dict["order_intent"] = order_intent

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        lots = d.pop("lots")

        asset_id = d.pop("assetId")

        amount = d.pop("amount")

        def _parse_price_lower_bound(data: object) -> Union[None, str]:
            if data is None:
                return data
            return cast(Union[None, str], data)

        price_lower_bound = _parse_price_lower_bound(d.pop("priceLowerBound"))

        def _parse_price_upper_bound(data: object) -> Union[None, str]:
            if data is None:
                return data
            return cast(Union[None, str], data)

        price_upper_bound = _parse_price_upper_bound(d.pop("priceUpperBound"))

        start_time = d.pop("startTime")

        end_time = d.pop("endTime")

        order_side = CreateTwapOrderDtoOrderSide(d.pop("order_side"))

        market_type = CreateTwapOrderDtoMarketType(d.pop("market_type"))

        wallet_id = d.pop("walletId", UNSET)

        slippage = d.pop("slippage", UNSET)

        _order_intent = d.pop("order_intent", UNSET)
        order_intent: Union[Unset, CreateTwapOrderDtoOrderIntent]
        if isinstance(_order_intent, Unset):
            order_intent = UNSET
        else:
            order_intent = CreateTwapOrderDtoOrderIntent(_order_intent)

        create_twap_order_dto = cls(
            lots=lots,
            asset_id=asset_id,
            amount=amount,
            price_lower_bound=price_lower_bound,
            price_upper_bound=price_upper_bound,
            start_time=start_time,
            end_time=end_time,
            order_side=order_side,
            market_type=market_type,
            wallet_id=wallet_id,
            slippage=slippage,
            order_intent=order_intent,
        )

        create_twap_order_dto.additional_properties = d
        return create_twap_order_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
