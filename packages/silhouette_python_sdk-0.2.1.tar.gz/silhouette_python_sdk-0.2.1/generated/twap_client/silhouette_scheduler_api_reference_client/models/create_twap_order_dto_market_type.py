from enum import Enum


class CreateTwapOrderDtoMarketType(str, Enum):
    PERP = "perp"
    SPOT = "spot"

    def __str__(self) -> str:
        return str(self.value)
