from enum import Enum


class CreateTwapOrderDtoOrderIntent(str, Enum):
    CLOSE = "close"
    OPEN = "open"

    def __str__(self) -> str:
        return str(self.value)
