from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="RegisterApiKeyDto")


@_attrs_define
class RegisterApiKeyDto:
    """
    Attributes:
        hyperliquid_api_key (str):
        wallet_address (str):
    """

    hyperliquid_api_key: str
    wallet_address: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        hyperliquid_api_key = self.hyperliquid_api_key

        wallet_address = self.wallet_address

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hyperliquidApiKey": hyperliquid_api_key,
                "walletAddress": wallet_address,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        hyperliquid_api_key = d.pop("hyperliquidApiKey")

        wallet_address = d.pop("walletAddress")

        register_api_key_dto = cls(
            hyperliquid_api_key=hyperliquid_api_key,
            wallet_address=wallet_address,
        )

        register_api_key_dto.additional_properties = d
        return register_api_key_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
