"""Silhouette API client for enclave integration."""

from silhouette.api.client import SilhouetteApiClient, SilhouetteApiError

__all__ = ["SilhouetteApiClient", "SilhouetteApiError"]
