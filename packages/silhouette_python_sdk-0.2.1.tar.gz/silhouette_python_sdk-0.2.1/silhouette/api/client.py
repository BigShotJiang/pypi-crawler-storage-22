"""Silhouette API client for integrating with the enclave API."""

import json
from collections.abc import Callable
from functools import wraps
from typing import Any

import requests

from silhouette.api.auth import AuthConfig, AuthManager
from silhouette.api.generated import (
    BatchGetDelegatedOrdersRequest,
    BatchGetDelegatedOrdersResponse,
    CancelOrderRequest,
    CancelOrderResponse,
    CreateOrderRequest,
    CreateOrderResponse,
    GetBalancesResponse,
    GetDelegatedOrderRequest,
    GetDelegatedOrderResponse,
    GetHealthFeaturesResponse,
    GetHealthInfoResponse,
    GetHealthReadyResponse,
    GetHealthResponse,
    GetHistoryRequest,
    GetHistoryResponse,
    GetUserOrdersRequest,
    GetUserOrdersResponse,
    GetUserWithdrawalsRequest,
    GetUserWithdrawalsResponse,
    GetWithdrawalStatusRequest,
    GetWithdrawalStatusResponse,
    InitiateWithdrawalRequest,
    InitiateWithdrawalResponse,
    ListDelegatedOrdersRequest,
    ListDelegatedOrdersResponse,
)


def parse_response(model_class: type[Any]) -> Callable[..., Callable[..., dict[str, Any]]]:
    """Decorator that parses API responses using a Pydantic model and returns a clean dict.

    This decorator:
    1. Validates the response using the specified Pydantic model
    2. Converts the model to a dict with camelCase keys (by_alias=True)
    3. Removes the redundant 'operation' field from the response
    4. Returns a clean dict that clients can use without importing generated models

    Args:
        model_class: The Pydantic model class to use for validation

    Returns:
        A decorator function that wraps API operation methods
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., dict[str, Any]]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> dict[str, Any]:
            response: Any = func(*args, **kwargs)
            result = model_class.from_dict(response)
            if result is None:
                raise ValueError(f"Failed to parse {model_class.__name__} from API response")
            result_dict: dict[str, Any] = result.to_dict()
            result_dict.pop("operation", None)  # Remove redundant operation field
            return result_dict

        return wrapper

    return decorator


def build_request(model_class: type[Any], **kwargs: Any) -> dict[str, Any]:
    """Build and serialize a request model with snake_case params converted to camelCase."""
    request = model_class(**kwargs)
    return request.model_dump(by_alias=True, exclude_none=True)  # type: ignore[no-any-return]


class SilhouetteApiError(Exception):
    """Custom exception for Silhouette API errors."""

    def __init__(self, code: str, message: str, status: int | None):
        super().__init__(f"API Error [{code}]: {message} (HTTP {status})")
        self.code = code
        self.message = message
        self.status = status


class HealthOperations:
    """Health endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(GetHealthResponse)
    def get_health(self) -> dict[str, Any]:
        """Get basic health check information.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - status: str (e.g., "healthy")
        """
        return self._client._request_operation("getHealth")

    @parse_response(GetHealthFeaturesResponse)
    def get_features(self) -> dict[str, Any]:
        """Get health features discovery information.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - features: dict (enabled feature flags)
        """
        return self._client._request_operation("getHealthFeatures")

    @parse_response(GetHealthInfoResponse)
    def get_info(self) -> dict[str, Any]:
        """Get detailed system info (debug mode only).

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - info: dict (system information)
        """
        return self._client._request_operation("getHealthInfo")

    @parse_response(GetHealthReadyResponse)
    def get_ready(self) -> dict[str, Any]:
        """Get health readiness check.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - ready: bool
        """
        return self._client._request_operation("getHealthReady")


class HistoryOperations:
    """History endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(GetHistoryResponse)
    def get_history(
        self,
        session_id: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Get transaction history with optional filtering parameters.

        Args:
            session_id: Optional session ID to filter by
            limit: Optional maximum number of records to return

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - history: list[dict] (transaction history records)
        """
        params = build_request(GetHistoryRequest, operation="getHistory", session_id=session_id, limit=limit)
        return self._client._request_operation("getHistory", params)

    def get_session(self) -> dict[str, Any]:
        """Get current session information.

        Note: Returns the raw API response without Pydantic validation.
        Unlike other methods, the response includes the 'operation' field.

        Returns:
            dict with keys:
                - operation: str ('getSession')
                - responseMetadata: dict (timestamp and requestId)
                - session: dict (session details)
        """
        return self._client._request_operation("getSession")


class TestOperations:
    """Test endpoint operations for the enclave API."""

    __test__ = False

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    def get_test_balance(self, address: str) -> dict[str, Any]:
        """Get test balances for a given address."""
        return self._client._request_operation("getTestBalance", {"address": address})

    def spoof_deposit(self, user_address: str, token_symbol: str, amount: str) -> dict[str, Any]:
        """Spoof a deposit for a user."""
        params = {
            "userAddress": user_address,
            "tokenSymbol": token_symbol,
            "amount": amount,
        }
        return self._client._request_operation("spoofDeposit", params)

    def spoof_withdrawal(self, user_address: str, token_symbol: str, amount: str) -> dict[str, Any]:
        """Simulates a withdrawal for a user."""
        params = {
            "userAddress": user_address,
            "tokenSymbol": token_symbol,
            "amount": amount,
        }
        return self._client._request_operation("spoofWithdrawal", params)


class UserOperations:
    """Authenticated user endpoint operations for the enclave API."""

    __test__ = False

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(GetBalancesResponse)
    def get_balances(self) -> dict[str, Any]:
        """Get user balances.

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - balances: list[dict] (token balances with 'available', 'locked', 'total', etc.)
        """
        return self._client._request_operation("getBalances")

    def get_balance(self, token_symbol: str) -> int:
        """
        Get the available balance for a specific token from the Silhouette enclave.

        This safely handles cases where the user or token is not found, returning 0
        instead of raising an error.

        Args:
            token_symbol: The symbol of the token (e.g., "USDC")

        Returns:
            The available balance as an integer in Silhouette's fixed-point format.

        Raises:
            SilhouetteApiError: For unexpected API errors (not USER_NOT_FOUND)
        """
        try:
            balances_response = self.get_balances()
            if balances_response.get("balances"):
                balance_info = next(
                    (b for b in balances_response["balances"] if b.get("token") == token_symbol),
                    None,
                )
                if balance_info and balance_info.get("available"):
                    return int(balance_info["available"])
        except SilhouetteApiError as e:
            if e.code == "USER_NOT_FOUND":
                return 0  # User doesn't exist yet, so balance is 0
            raise  # Re-raise other unexpected API errors
        return 0

    def get_balance_float(self, token_symbol: str) -> float:
        """
        Get the available balance for a specific token as a float.

        This uses the `availableFloat` field from the API, returning 0.0 if the
        user or token is not found.

        Args:
            token_symbol: The symbol of the token (e.g., "USDC")

        Returns:
            The available balance as a float.

        Raises:
            SilhouetteApiError: For unexpected API errors (not USER_NOT_FOUND)
        """
        try:
            balances_response = self.get_balances()
            if balances_response.get("balances"):
                balance_info = next(
                    (b for b in balances_response["balances"] if b.get("token") == token_symbol),
                    None,
                )
                if balance_info and balance_info.get("availableFloat"):
                    return float(balance_info["availableFloat"])
            return 0.0
        except SilhouetteApiError as e:
            if e.code == "USER_NOT_FOUND":
                return 0.0  # User doesn't exist yet, so balance is 0
            raise  # Re-raise other unexpected API errors

    @parse_response(InitiateWithdrawalResponse)
    def initiate_withdrawal(self, token_symbol: str, amount: str) -> dict[str, Any]:
        """Initiate a withdrawal for the authenticated user.

        Args:
            token_symbol: The symbol of the token (e.g., "USDC")
            amount: The amount to withdraw

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - message: str (success message)
                - withdrawalId: str (unique identifier for the withdrawal)
        """
        params = build_request(
            InitiateWithdrawalRequest, operation="initiateWithdrawal", token_symbol=token_symbol, amount=amount
        )
        return self._client._request_operation("initiateWithdrawal", params)

    @parse_response(GetWithdrawalStatusResponse)
    def get_withdrawal_status(self, withdrawal_id: str) -> dict[str, Any]:
        """Get the status of a specific withdrawal by ID."""
        params = build_request(GetWithdrawalStatusRequest, operation="getWithdrawalStatus", withdrawal_id=withdrawal_id)
        return self._client._request_operation("getWithdrawalStatus", params)

    @parse_response(GetUserWithdrawalsResponse)
    def get_user_withdrawals(self) -> dict[str, Any]:
        """Get all withdrawals for the authenticated user."""
        params = build_request(GetUserWithdrawalsRequest, operation="getUserWithdrawals")
        return self._client._request_operation("getUserWithdrawals", params)


class OrderOperations:
    """Authenticated order endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(CreateOrderResponse)
    def create_order(
        self,
        side: str,
        order_type: str,
        base_token: str,
        quote_token: str,
        amount: str,
        price: str | None = None,
    ) -> dict[str, Any]:
        """Create a new order.

        Args:
            side: Order side ("buy" or "sell")
            order_type: Order type (e.g., "limit", "market")
            base_token: Base token symbol (e.g., "HYPE")
            quote_token: Quote token symbol (e.g., "USDC")
            amount: Order amount
            price: Optional price for limit orders

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - orderId: str (unique identifier for the order)
                - message: str (success message)
        """
        params = build_request(
            CreateOrderRequest,
            operation="createOrder",
            side=side,
            order_type=order_type,
            base_token=base_token,
            quote_token=quote_token,
            amount=amount,
            price=price,
        )
        return self._client._request_operation("createOrder", params)

    @parse_response(CancelOrderResponse)
    def cancel_order(self, order_id: str) -> dict[str, Any]:
        """Cancel an existing order.

        Args:
            order_id: The ID of the order to cancel

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - message: str (success message)
        """
        params = build_request(CancelOrderRequest, operation="cancelOrder", order_id=order_id)
        return self._client._request_operation("cancelOrder", params)

    @parse_response(GetUserOrdersResponse)
    def get_user_orders(self, status: str | None = None) -> dict[str, Any]:
        """Get all orders for the authenticated user.

        Args:
            status: Optional status filter (e.g., "open", "filled", "cancelled")

        Returns:
            dict with keys:
                - responseMetadata: dict (timestamp and requestId)
                - orders: list[dict] (order records)
        """
        params = build_request(GetUserOrdersRequest, operation="getUserOrders", status=status)
        return self._client._request_operation("getUserOrders", params)


class DelegatedOrderOperations:
    """Authenticated delegated order endpoint operations for the enclave API."""

    def __init__(self, client: "SilhouetteApiClient"):
        self._client = client

    @parse_response(ListDelegatedOrdersResponse)
    def list_delegated_orders(
        self,
        status: str | None = None,
        created_after: int | None = None,
        created_before: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """List delegated orders with filters and pagination.

        Args:
            status: Filter by order status (e.g., "open", "filled", "cancelled")
            created_after: Filter orders created after this timestamp (ms)
            created_before: Filter orders created before this timestamp (ms)
            limit: Maximum number of orders to return (1-100)
            cursor: Pagination cursor for next page

        Returns:
            dict with keys:
                - orders: list[dict] (order records)
                - pagination: dict (hasMore, nextCursor)
                - responseMetadata: dict (timestamp)
        """
        params = build_request(
            ListDelegatedOrdersRequest,
            operation="listDelegatedOrders",
            status=status,
            created_after=created_after,
            created_before=created_before,
            limit=limit,
            cursor=cursor,
        )
        return self._client._request_operation("listDelegatedOrders", params)

    @parse_response(GetDelegatedOrderResponse)
    def get_delegated_order(self, order_id: str) -> dict[str, Any]:
        """Get a single delegated order by ID.

        Args:
            order_id: The unique identifier of the order

        Returns:
            dict with keys:
                - order: dict (order details)
                - responseMetadata: dict (timestamp)
        """
        params = build_request(
            GetDelegatedOrderRequest,
            operation="getDelegatedOrder",
            order_id=order_id,
        )
        return self._client._request_operation("getDelegatedOrder", params)

    @parse_response(BatchGetDelegatedOrdersResponse)
    def batch_get_delegated_orders(self, order_ids: list[str]) -> dict[str, Any]:
        """Batch get multiple delegated orders by IDs (max 100).

        Args:
            order_ids: List of order IDs to retrieve

        Returns:
            dict with keys:
                - orders: list[dict] (found orders)
                - notFound: list[str] (IDs that weren't found)
                - responseMetadata: dict (timestamp)
        """
        params = build_request(
            BatchGetDelegatedOrdersRequest,
            operation="batchGetDelegatedOrders",
            order_ids=order_ids,
        )
        return self._client._request_operation("batchGetDelegatedOrders", params)


class SilhouetteApiClient:
    """
    Silhouette API client for interacting with the enclave API.

    Provides access to health and history operations through a simple,
    synchronous interface that follows Hyperliquid SDK patterns.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8081",
        timeout: float = 30.0,
        private_key: str | None = None,
        keystore_path: str | None = None,
        auto_auth: bool = True,
        max_login_retries: int = 3,
        login_retry_base_delay: float = 1.0,
        login_retry_max_delay: float = 10.0,
        verify_ssl: bool = True,
        chain_id: int = 1,
    ):
        """
        Initialize the Silhouette API client.

        Args:
            base_url: Base URL for the enclave API
            timeout: Request timeout in seconds
            private_key: Private key for auto-authentication (hex string with or without 0x prefix)
            keystore_path: Path to encrypted keystore file (alternative to private_key)
            auto_auth: Enable automatic authentication and token refresh on 401
            max_login_retries: Maximum login retry attempts on failure
            login_retry_base_delay: Base delay for exponential backoff (seconds)
            login_retry_max_delay: Maximum delay for exponential backoff (seconds)
            verify_ssl: Enable SSL certificate verification (defaults to True for production)
            chain_id: Chain ID for SIWE authentication (1 for mainnet, 421614 for Arbitrum Sepolia)
        """
        self.base_url = base_url
        self.timeout = timeout
        self.verify_ssl = verify_ssl

        # Initialize auth manager
        auth_config = AuthConfig(
            auto_auth=auto_auth,
            max_login_retries=max_login_retries,
            login_retry_base_delay=login_retry_base_delay,
            login_retry_max_delay=login_retry_max_delay,
            chain_id=chain_id,
        )
        self._auth = AuthManager(
            client=self,
            config=auth_config,
            private_key=private_key,
            keystore_path=keystore_path,
        )

        # Backwards compatibility: expose _jwt_token property
        self._jwt_token: str | None = None

        # Initialize operation groups
        self.health = HealthOperations(self)
        self.history = HistoryOperations(self)
        self.test = TestOperations(self)
        self.user = UserOperations(self)
        self.order = OrderOperations(self)
        self.delegated_order = DelegatedOrderOperations(self)

    @property
    def wallet(self):
        """Get the wallet used for authentication."""
        return self._auth.wallet

    def login(self, message: str, signature: str) -> str:
        """
        Authenticate with the enclave using a SIWE message and signature.

        Args:
            message: The SIWE message.
            signature: The signature of the message.

        Returns:
            The JWT token string.
        """
        token = self._raw_login(message, signature)
        self._auth.set_token(token)
        self._jwt_token = token  # Backwards compatibility
        return token

    def _raw_login(self, message: str, signature: str) -> str:
        """
        Perform raw login API call without updating auth state.

        This is used internally by AuthManager to avoid circular dependencies.

        Args:
            message: The SIWE message.
            signature: The signature of the message.

        Returns:
            The JWT token string.

        Raises:
            SilhouetteApiError: If login fails
        """
        params = {"message": message, "signature": signature}
        # Use _raw_request to bypass auth logic
        response = self._raw_request("login", params, token=None)
        token_value = response.get("token")
        if not isinstance(token_value, str) or not token_value:
            raise SilhouetteApiError("LOGIN_FAILED", "No token in response", None)
        return token_value

    def _request_operation(
        self, operation: str, params: dict[str, Any] | None = None, token: str | None = None
    ) -> dict[str, Any]:
        """
        Make a request to the enclave API with the envelope pattern.

        This method handles automatic authentication and 401 retry logic.

        Args:
            operation: The operation name to execute
            params: Optional parameters for the operation
            token: Optional JWT token to use for this specific request

        Returns:
            Response data with responseMetadata excluded

        Raises:
            requests.Timeout: On request timeout
            requests.ConnectionError: On connection failure
            SilhouetteApiError: On API error responses (JSON with code/error)
            ValueError: On malformed or non-JSON responses
        """
        # Operations that don't require authentication
        unauthenticated_ops = {
            "login",
            "getHealth",
            "getHealthFeatures",
            "getHealthInfo",
            "getHealthReady",
        }

        requires_auth = operation not in unauthenticated_ops

        # Auto-login if needed and no explicit token provided
        if requires_auth and token is None:
            # Check for existing token (backwards compatibility)
            token = self._auth.get_token() or self._jwt_token
            if token is None:
                # No token exists, try to auto-authenticate
                self._auth.ensure_authenticated()
                token = self._auth.get_token()

        # Make the request
        try:
            return self._raw_request(operation, params, token)
        except SilhouetteApiError as e:
            # Handle 401 by attempting re-login and retry
            if e.status == 401 and requires_auth:
                if self._auth.handle_auth_error(e.status):
                    # Login succeeded, retry with new token
                    token = self._auth.get_token()
                    return self._raw_request(operation, params, token)
            # Re-raise if not 401 or if login failed
            raise

    def _raw_request(
        self, operation: str, params: dict[str, Any] | None = None, token: str | None = None
    ) -> dict[str, Any]:
        """
        Make a raw HTTP request to the enclave API without auth logic.

        Args:
            operation: The operation name to execute
            params: Optional parameters for the operation
            token: Optional JWT token to use for this request

        Returns:
            Response data with responseMetadata excluded

        Raises:
            requests.Timeout: On request timeout
            requests.ConnectionError: On connection failure
            SilhouetteApiError: On API error responses (JSON with code/error)
            ValueError: On malformed or non-JSON responses
        """
        # Build request payload with envelope pattern
        payload = {"operation": operation}
        if params:
            payload.update(params)

        url = f"{self.base_url}/v0"
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        # Make the HTTP request
        response = requests.post(url, json=payload, headers=headers, timeout=self.timeout, verify=self.verify_ssl)

        # Parse JSON response (best-effort)
        try:
            response_data = response.json()
        except json.JSONDecodeError as e:
            # If HTTP error with non-JSON body, surface concise status
            if not response.ok:
                raise ValueError(f"HTTP {response.status_code} error with non-JSON response") from e
            raise ValueError("Failed to parse response JSON") from e

        # Handle error responses
        if not response.ok:
            error_msg = response_data.get("error", f"HTTP {response.status_code}")
            error_code = response_data.get("code", "UNKNOWN_ERROR")
            raise SilhouetteApiError(error_code, error_msg, response.status_code)

        # Return full response for Pydantic validation
        return dict(response_data)
