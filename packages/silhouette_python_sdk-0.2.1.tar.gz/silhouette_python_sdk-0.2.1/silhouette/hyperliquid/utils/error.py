"""Re-export of official hyperliquid.utils.error for convenience."""

# Re-export everything from the official module
from hyperliquid.utils.error import *  # noqa: F403, F401
