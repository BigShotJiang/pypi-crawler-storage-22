# Silhouette TWAP Platform - Usage Guide

## Table of Contents

1. [Platform Overview](#platform-overview)
2. [Getting Started](#getting-started)
3. [Platform Features](#platform-features)
4. [Common Use Cases](#common-use-cases)
5. [How the Platform Works](#how-the-platform-works)
6. [Key Handling and Authentication](#key-handling-and-authentication)

---

## Platform Overview

Silhouette TWAP (Time-Weighted Average Price) is an algorithmic trading platform designed to execute large trading orders on the Hyperliquid exchange over extended time periods. The platform intelligently splits large orders into smaller, randomized lots distributed across time to minimize market impact while ensuring reliable execution.

### Key Benefits

- **Minimized Market Impact**: Large orders are broken down into smaller pieces spread over time
- **Anti-Detection**: Randomized timing and sizing prevent pattern recognition
- **Automated Execution**: Hands-off execution once an order is placed
- **Price Protection**: Configurable price bounds prevent unwanted executions
- **Secure**: API keys encrypted at rest, only decrypted during execution

---

## Getting Started

### Prerequisites

1. **Hyperliquid Account**
   - Create an account on Hyperliquid
   - Generate an API key
   - Register the API key as an "agent" for your wallet

2. **Python SDK**
   - Install the Silhouette Python SDK

### Installation

```bash
pip install silhouette-sdk
```

### Basic Usage

The `AuthenticatedTwapClient` handles all authentication automatically - no manual setup required:

```python
from silhouette.twap.authenticated_client import AuthenticatedTwapClient
from datetime import datetime, timedelta
import time

# Initialize the client (registration happens automatically)
client = AuthenticatedTwapClient(
    base_url="https://scheduler.silhouette.com",
    hyperliquid_api_key="0x...",  # Your Hyperliquid API key
    wallet_address="0x..."         # Your wallet address
)

# Create a TWAP order
start_time = datetime.now()
end_time = start_time + timedelta(hours=2)

order = client.create_twap_order({
    "asset_id": "BTC",
    "amount": "1.0",                  # Total amount to execute
    "lots": 10,                       # Number of sub-orders
    "order_side": "buy",              # "buy" or "sell"
    "market_type": "spot",            # "spot" or "perp"
    "start_time": int(start_time.timestamp()),
    "end_time": int(end_time.timestamp()),
    "price_upper_bound": "50000",     # Optional: max price
    "price_lower_bound": "45000",     # Optional: min price
    "slippage": "0.001"               # Optional: slippage tolerance (default 0.001)
})

print(f"Order created: {order['id']}")
print(f"Status: {order['status']}")

# Monitor order status
order_data = order
while order_data['status'] == "active":
    time.sleep(60)  # Check every minute
    order_data = client.get_order(order['id'])
    print(f"Progress: {order_data['executedAmount']} / {order_data['totalAmount']}")
```

### Available Methods

```python
# Create a TWAP order
order = client.create_twap_order(order_data)

# Get order details
order = client.get_order(order_id)

# Cancel an order
result = client.cancel_order(order_id)

# Pause an active order
result = client.pause_order(order_id)

# Resume a paused order
result = client.resume_order(order_id)

# Get all orders for your wallet
orders = client.get_orders_by_user()

# Get your wallet address
wallet_address = client.get_wallet_address()

# Check if client is ready
is_ready = client.is_ready()
```

---

## Platform Features

### TWAP Order Execution

Execute large orders over time with intelligent splitting and randomization.

**Required Parameters:**
- `asset_id`: Trading pair (e.g., "BTC", "ETH")
- `amount`: Total quantity to execute (as string)
- `lots`: Number of sub-orders to split into
- `order_side`: "buy" or "sell"
- `market_type`: "spot" or "perp"
- `start_time`: Unix timestamp (seconds)
- `end_time`: Unix timestamp (seconds)

**Optional Parameters:**
- `price_upper_bound`: Maximum price for buys (string)
- `price_lower_bound`: Minimum price for buys (string)
- `slippage`: Slippage tolerance (default "0.001", i.e., 0.1%)
- `order_intent`: Required for perp orders - "open" or "close"

### Price Bounds Protection

Protect your orders with upper and/or lower price limits.

```python
order = client.create_twap_order({
    "asset_id": "BTC",
    "amount": "10.0",
    "lots": 20,
    "order_side": "buy",
    "market_type": "spot",
    "start_time": int(start_time.timestamp()),
    "end_time": int(end_time.timestamp()),
    "price_upper_bound": "52000",  # Don't buy above $52,000
    "price_lower_bound": "48000"   # Don't buy below $48,000
})
```

- Price bounds are validated before each lot execution
- Orders automatically pause if bounds are breached
- Orders resume when price returns to acceptable range

### Randomized Execution

The platform automatically randomizes:
- **Timing**: ±20% variance in execution intervals
- **Size**: ±15% variance in individual lot sizes

This prevents market makers from detecting your order patterns.

### Perpetual Futures Support

For perpetual futures orders, you must specify `order_intent`:

```python
# Open a new position
order = client.create_twap_order({
    "asset_id": "BTC",
    "amount": "10.0",
    "lots": 15,
    "order_side": "buy",
    "market_type": "perp",
    "order_intent": "open",  # Required for perp: "open" or "close"
    "start_time": int(start_time.timestamp()),
    "end_time": int(end_time.timestamp())
})
```

### Order Management

**Order States:**
- `pending`: Order created, waiting to start
- `active`: Order executing lots over time
- `paused`: Price bounds breached or manually paused
- `completed`: All lots executed successfully
- `cancelled`: Order cancelled by user
- `failed`: Critical error occurred

**Monitoring:**
```python
# Get order status
order = client.get_order(order_id)
print(f"Status: {order['status']}")
print(f"Executed: {order['executedAmount']} / {order['totalAmount']}")

# List all your orders
orders = client.get_orders_by_user()
```

---

## Common Use Cases

### Use Case 1: Large Order Execution

Execute a large order without moving the market.

```python
from silhouette.twap.authenticated_client import AuthenticatedTwapClient
from datetime import datetime, timedelta

client = AuthenticatedTwapClient(
    base_url="https://scheduler.silhouette.com",
    hyperliquid_api_key="0x...",
    wallet_address="0x..."
)

start = datetime.now()
end = start + timedelta(hours=6)

order = client.create_twap_order({
    "asset_id": "BTC",
    "amount": "100.0",
    "lots": 50,  # ~2 BTC per lot
    "order_side": "buy",
    "market_type": "spot",
    "start_time": int(start.timestamp()),
    "end_time": int(end.timestamp()),
    "price_upper_bound": "52000"
})
```

### Use Case 2: Dollar Cost Averaging (DCA)

Accumulate an asset over time with price protection.

```python
start = datetime.now()
end = start + timedelta(hours=24)

order = client.create_twap_order({
    "asset_id": "ETH",
    "amount": "50.0",
    "lots": 20,  # 20 purchases over 24 hours
    "order_side": "buy",
    "market_type": "spot",
    "start_time": int(start.timestamp()),
    "end_time": int(end.timestamp()),
    "price_upper_bound": "3000",
    "price_lower_bound": "2500"
})
```

### Use Case 3: Exit Strategy

Sell a large position gradually to minimize impact.

```python
start = datetime.now()
end = start + timedelta(hours=4)

order = client.create_twap_order({
    "asset_id": "BTC",
    "amount": "50.0",
    "lots": 30,
    "order_side": "sell",
    "market_type": "spot",
    "start_time": int(start.timestamp()),
    "end_time": int(end.timestamp()),
    "price_lower_bound": "48000"  # Don't sell below $48k
})
```

### Use Case 4: Perpetual Position Entry

Open a large perpetual position gradually.

```python
start = datetime.now()
end = start + timedelta(hours=3)

order = client.create_twap_order({
    "asset_id": "BTC",
    "amount": "25.0",
    "lots": 15,
    "order_side": "buy",
    "market_type": "perp",
    "order_intent": "open",
    "start_time": int(start.timestamp()),
    "end_time": int(end.timestamp()),
    "price_upper_bound": "51000"
})
```

---

## How the Platform Works

### Architecture Overview

The Silhouette TWAP platform uses a **split services architecture**:

1. **Scheduler Service (TypeScript/NestJS)**
   - Handles order planning and TWAP computation
   - Manages user authentication
   - Splits orders into randomized lots
   - Creates execution tasks

2. **Executor Service (Python/FastAPI)**
   - Consumes tasks from the queue
   - Validates price bounds before execution
   - Executes trades on Hyperliquid
   - Reports results back

Both services communicate through **Upstash Redis** for task queuing and state storage.

### Order Execution Flow

```
User → Scheduler → Redis → Executor → Hyperliquid
```

1. User creates a TWAP order via the SDK
2. Scheduler validates the order and computes execution plan
3. Scheduler creates execution tasks with randomized timing
4. Tasks are queued in Redis
5. Executor consumes tasks at scheduled times
6. Executor validates price bounds and executes trades
7. Results are reported back and stored

### TWAP Algorithm

When you create a TWAP order:

1. **Order Splitting**: Total amount divided into multiple lots
   - ±15% size variation per lot to avoid patterns
   - Example: 10 BTC / 20 lots → ~0.43-0.57 BTC per lot

2. **Time Distribution**: Executions spread across duration
   - ±20% timing variance in execution intervals
   - Example: 2-hour order → executions at 4.8min, 12.2min, 17.4min

3. **Price Validation**: Price bounds checked before each execution
   - Real-time market price validation
   - Order pauses if bounds are breached

4. **Execution Tracking**: Each lot execution is tracked individually
   - Complete audit trail
   - Status updates in real-time

---

## Key Handling and Authentication

### Authentication Process

The `AuthenticatedTwapClient` handles all authentication automatically:

```python
client = AuthenticatedTwapClient(
    base_url="https://scheduler.silhouette.com",
    hyperliquid_api_key="0x...",
    wallet_address="0x..."
)
```

**What happens during initialization:**

1. Health check - Verifies scheduler service is available
2. Registration check - Checks if your wallet is registered
3. Auto-registration - Registers your API key if needed
4. JWT generation - Creates authentication token
5. Ready to use - Client is immediately available

**Automatic token refresh:**
- If a request receives 401 (Unauthorized), the client automatically refreshes the token
- The failed request is automatically retried
- All happens transparently

### Security Architecture

**Key Components:**

1. **Hyperliquid API Key**
   - Used for authentication and trade execution
   - Must be registered as an "agent" for your wallet
   - Cannot withdraw funds
   - Sent over the wire only once during registration
   - Encrypted at rest in storage
   - Only decrypted at lot execution time by the executor service

2. **JWT Tokens**
   - Client-signed using your Hyperliquid API key
   - Algorithm: ES256K (ECDSA with secp256k1)
   - Short-lived (1 hour max)
   - Automatically refreshed

### Key Rotation

To rotate your API key, simply create a new client instance:

```python
client = AuthenticatedTwapClient(
    base_url="https://scheduler.silhouette.com",
    hyperliquid_api_key="0x...",  # New API key
    wallet_address="0x..."         # Same wallet address
)
```

The client automatically detects registration and updates your key.

### Security Best Practices

1. **Keep API Keys Secure**
   - Store in environment variables or secrets manager
   - Never commit to version control
   - Use different keys for testnet and mainnet

2. **Key Permissions**
   - Silhouette only uses your API key for signing trades
   - Cannot withdraw funds or access other operations
   - Revoke immediately if compromised

3. **System Protections**
   - Anti-enumeration protection prevents key discovery
   - Constant-time validation operations
   - Generic error messages for security

---

## Additional Resources

You can interact with the scheduler server directly via API. The OpenAPI-compliant API documentation and architecture breakdown can be found at:

**https://silhouette-scheduler.fly.dev**

---

*Last Updated: 2025*
