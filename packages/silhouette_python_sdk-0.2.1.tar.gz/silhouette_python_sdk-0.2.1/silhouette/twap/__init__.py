"""
Silhouette TWAP (Time-Weighted Average Price) Client

This module contains the TWAP client that integrates generated client code
from OpenAPI specifications with the Silhouette SDK architecture.
"""

from .authenticated_client import AuthenticatedTwapClient, AuthenticationError
from .client import AuthenticationExpiredError, TwapClient, TwapClientError
from .interfaces import TwapClientInterface

__all__ = [
    "TwapClientInterface",
    "TwapClient",
    "TwapClientError",
    "AuthenticationExpiredError",
    "AuthenticatedTwapClient",
    "AuthenticationError",
]
