"""JWT authentication module for Silhouette SDK.

This module provides client-signed JWT authentication using Hyperliquid API keys
for secure access to Silhouette services.
"""

from .exceptions import (
    AuthenticationFailedError,
    ConfigurationError,
    CryptographicError,
    InvalidHyperliquidKeyError,
    JWTSigningError,
    PayloadValidationError,
    SilhouetteAuthError,
    TokenValidationError,
)
from .jwt_service import JWTSigningService
from .jwt_signer import JWTSigner
from .utils import (
    create_agent_account_from_key,
    validate_hyperliquid_key_format,
    validate_wallet_address_format,
    validate_wallet_credentials,
)

__all__ = [
    "SilhouetteAuthError",
    "InvalidHyperliquidKeyError",
    "JWTSigningError",
    "AuthenticationFailedError",
    "ConfigurationError",
    "TokenValidationError",
    "CryptographicError",
    "PayloadValidationError",
    "JWTSigningService",
    "JWTSigner",
    "validate_wallet_credentials",
    "validate_hyperliquid_key_format",
    "validate_wallet_address_format",
    "create_agent_account_from_key",
]
