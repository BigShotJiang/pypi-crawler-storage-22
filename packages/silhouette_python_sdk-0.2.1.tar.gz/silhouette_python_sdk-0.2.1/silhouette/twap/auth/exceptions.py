"""Exception classes for JWT authentication in Silhouette SDK."""


class SilhouetteAuthError(Exception):
    """Base exception for all Silhouette authentication errors.

    This is the parent class for all authentication-related exceptions
    in the Silhouette SDK. It provides a common base for error handling
    and allows catching all authentication errors with a single except clause.
    """

    def __init__(self, message: str, details: str | None = None) -> None:
        """Initialize the authentication error.

        Args:
            message: The main error message
            details: Optional additional details about the error
        """
        super().__init__(message)
        self.message = message
        self.details = details

    def __str__(self) -> str:
        """Return a string representation of the error."""
        if self.details is not None and self.details.strip():
            return f"{self.message}: {self.details}"
        return self.message


class InvalidHyperliquidKeyError(SilhouetteAuthError):
    """Raised when a Hyperliquid API key is invalid or malformed.

    This exception is raised when:
    - The API key format is incorrect
    - The API key cannot be used for cryptographic operations
    - The API key fails validation checks
    """

    def __init__(self, message: str = "Invalid Hyperliquid API key", details: str | None = None) -> None:
        """Initialize the invalid key error.

        Args:
            message: The error message (defaults to standard message)
            details: Optional additional details about the validation failure
        """
        super().__init__(message, details)


class JWTSigningError(SilhouetteAuthError):
    """Raised when JWT token creation or signing fails.

    This exception is raised when:
    - ECDSA signing operations fail
    - JWT payload creation fails
    - Cryptographic operations encounter errors
    """

    def __init__(self, message: str = "Failed to create or sign JWT token", details: str | None = None) -> None:
        """Initialize the JWT signing error.

        Args:
            message: The error message (defaults to standard message)
            details: Optional additional details about the signing failure
        """
        super().__init__(message, details)


class AuthenticationFailedError(SilhouetteAuthError):
    """Raised when server rejects JWT authentication.

    This exception is raised when:
    - The server rejects the JWT token
    - Authentication credentials are invalid
    - Authorization fails for API requests
    """

    def __init__(self, message: str = "Server rejected JWT authentication", details: str | None = None) -> None:
        """Initialize the authentication failed error.

        Args:
            message: The error message (defaults to standard message)
            details: Optional additional details about the authentication failure
        """
        super().__init__(message, details)


class ConfigurationError(SilhouetteAuthError):
    """Raised when SDK configuration is missing or invalid.

    This exception is raised when:
    - Required configuration parameters are missing
    - Configuration values are invalid
    - SDK setup is incomplete
    """

    def __init__(self, message: str = "Missing or invalid SDK configuration", details: str | None = None) -> None:
        """Initialize the configuration error.

        Args:
            message: The error message (defaults to standard message)
            details: Optional additional details about the configuration issue
        """
        super().__init__(message, details)


class TokenValidationError(JWTSigningError):
    """Raised when JWT token validation fails.

    This exception is raised when:
    - JWT token structure is invalid
    - Required claims are missing or malformed
    - Token format does not meet requirements
    """

    def __init__(self, message: str = "JWT token validation failed", details: str | None = None) -> None:
        """Initialize the token validation error.

        Args:
            message: The error message (defaults to standard message)
            details: Optional additional details about the validation failure
        """
        super().__init__(message, details)


class CryptographicError(JWTSigningError):
    """Raised when cryptographic operations fail.

    This exception is raised when:
    - ECDSA signing operations encounter errors
    - Private key operations fail
    - Cryptographic library errors occur
    """

    def __init__(self, message: str = "Cryptographic operation failed", details: str | None = None) -> None:
        """Initialize the cryptographic error.

        Args:
            message: The error message (defaults to standard message)
            details: Optional additional details about the cryptographic failure
        """
        super().__init__(message, details)


class PayloadValidationError(JWTSigningError):
    """Raised when JWT payload validation fails.

    This exception is raised when:
    - JWT payload structure is invalid
    - Payload claims have incorrect types or values
    - Payload cannot be serialized to JSON
    """

    def __init__(self, message: str = "JWT payload validation failed", details: str | None = None) -> None:
        """Initialize the payload validation error.

        Args:
            message: The error message (defaults to standard message)
            details: Optional additional details about the payload validation failure
        """
        super().__init__(message, details)
