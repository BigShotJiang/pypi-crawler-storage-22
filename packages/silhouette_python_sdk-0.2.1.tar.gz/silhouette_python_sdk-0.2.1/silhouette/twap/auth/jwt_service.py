"""JWT signing service for managing JWT tokens and authentication.

This module provides the high-level JWT signing service that manages token
creation, expiration, and formatting for HTTP Authorization headers.
"""

import time
from typing import Any

import jwt

from .exceptions import ConfigurationError, JWTSigningError, TokenValidationError
from .jwt_signer import JWTSigner
from .utils import validate_wallet_credentials


class JWTSigningService:
    """Service for creating and managing JWT tokens using Hyperliquid API keys.

    This service provides a high-level interface for JWT token management,
    including creation, expiration checking, and authorization header formatting.
    """

    def __init__(self, hyperliquid_api_key: str, wallet_address: str) -> None:
        """Initialize the JWT signing service.

        Args:
            hyperliquid_api_key: The Hyperliquid API key for JWT signing
            wallet_address: The wallet address that this API key acts on behalf of

        Raises:
            ConfigurationError: If the API key is missing or invalid
            JWTSigningError: If the API key or wallet address is invalid
        """
        if not hyperliquid_api_key or not hyperliquid_api_key.strip():
            raise ConfigurationError("Hyperliquid API key is required")

        if not wallet_address or not wallet_address.strip():
            raise ConfigurationError("Wallet address is required")

        # Validate the API key and wallet address
        self._wallet_address = validate_wallet_credentials(hyperliquid_api_key, wallet_address)
        self._api_key = hyperliquid_api_key

        # Initialize the JWT signer
        try:
            self._signer = JWTSigner(hyperliquid_api_key)
        except Exception as e:
            raise JWTSigningError("Failed to initialize JWT signer", details=str(e)) from e

    def create_jwt(self, expires_in: int = 3600) -> str:
        """Create a new JWT token with specified expiration.

        Args:
            expires_in: Token expiration time in seconds (default: 1 hour, max: 1 hour)

        Returns:
            The signed JWT token as a string

        Raises:
            JWTSigningError: If token creation fails
            ConfigurationError: If expires_in is invalid
        """
        if type(expires_in) is not int:
            raise ConfigurationError("Invalid expiration time", details="expires_in must be a positive integer")

        if expires_in <= 0:
            raise ConfigurationError("Invalid expiration time", details="expires_in must be a positive integer")

        # Enforce maximum 1 hour expiration as per requirements
        if expires_in > 3600:
            raise ConfigurationError(
                "Invalid expiration time", details="Maximum expiration time is 1 hour (3600 seconds)"
            )

        try:
            current_time = int(time.time())
            expiration_time = current_time + expires_in

            # Create JWT payload with required claims
            payload = {
                "sub": self._wallet_address,  # Subject: wallet address as user ID
                "iat": current_time,  # Issued at timestamp
                "exp": expiration_time,  # Expiration timestamp
                "iss": "silhouette-sdk",  # Issuer identifier
            }

            # Sign the JWT using the signer
            token = self._signer.sign_jwt(payload)
            return token

        except Exception as e:
            if isinstance(e, (ConfigurationError, JWTSigningError)):
                raise
            raise JWTSigningError("Failed to create JWT token", details=str(e)) from e

    def get_wallet_address(self) -> str:
        """Get the wallet address that this service acts on behalf of.

        Returns:
            The wallet address as a hex string
        """
        return self._wallet_address

    def get_jwt_expiry(self, token: str) -> int:
        """Get the expiry timestamp from a JWT token.

        Args:
            token: The JWT token to extract expiry from

        Returns:
            The expiry timestamp as an integer (seconds since epoch)

        Raises:
            TokenValidationError: If the token is malformed or missing expiry claim
        """
        try:
            # Decode without verification to extract the expiry
            # We don't need to verify signature here, just read the claim
            decoded = jwt.decode(token, options={"verify_signature": False})

            if "exp" not in decoded:
                raise TokenValidationError(
                    "JWT token missing expiry claim", details="Token does not contain an 'exp' claim"
                )

            return int(decoded["exp"])

        except jwt.DecodeError as e:
            raise TokenValidationError("Invalid JWT token", details=f"Failed to decode token: {str(e)}") from e
        except (KeyError, ValueError, TypeError) as e:
            raise TokenValidationError("Invalid JWT token format", details=str(e)) from e

    def is_jwt_expired(self, token: str, buffer_seconds: int = 60) -> bool:
        """Check if a JWT token is expired or close to expiry.

        Args:
            token: The JWT token to check
            buffer_seconds: Number of seconds before actual expiry to consider token expired
                          (default: 60 seconds). This provides a safety buffer for token refresh.

        Returns:
            True if the token is expired or within the buffer window, False otherwise

        Raises:
            TokenValidationError: If the token is malformed or missing expiry claim
        """
        try:
            expiry = self.get_jwt_expiry(token)
            current_time = int(time.time())

            # Consider token expired if it's within the buffer window
            return current_time >= (expiry - buffer_seconds)

        except TokenValidationError:
            # Re-raise validation errors
            raise

    def is_token_expired(self, token: str) -> bool:
        """Check if a JWT token is expired.

        Args:
            token: The JWT token to check

        Returns:
            True if the token is expired, False otherwise

        Raises:
            JWTSigningError: If the token is malformed or cannot be decoded
        """
        if not token or not isinstance(token, str):
            raise JWTSigningError("Invalid token format", details="Token must be a non-empty string")

        try:
            # First validate the token structure
            if not self._validate_token_structure(token):
                raise TokenValidationError("Invalid token structure", details="Token does not have valid JWT format")

            # Decode the token without verification to check expiration
            # We only need to check the payload, not verify the signature
            decoded = jwt.decode(token, options={"verify_signature": False})

            # Validate required claims
            self._validate_token_claims(decoded)

            # Compare expiration time with current time
            current_time = int(time.time())
            expiration_time = int(decoded["exp"])

            return current_time >= expiration_time

        except jwt.DecodeError as e:
            raise JWTSigningError("Failed to decode JWT token", details=str(e)) from e
        except Exception as e:
            if isinstance(e, (JWTSigningError, TokenValidationError)):
                raise
            raise JWTSigningError("Failed to check token expiration", details=str(e)) from e

    def get_auth_headers(self, token: str | None = None) -> dict[str, str]:
        """Get HTTP Authorization headers with JWT token.

        Args:
            token: Optional JWT token. If None, creates a new token.

        Returns:
            Dictionary with Authorization header

        Raises:
            JWTSigningError: If token creation fails
        """
        try:
            # If no token provided, create a new one
            if token is None:
                token = self.create_jwt()
            else:
                # If token provided, check if it's expired and create new one if needed
                try:
                    if self.is_token_expired(token):
                        token = self.create_jwt()
                except JWTSigningError:
                    # If token is invalid/malformed, create a new one
                    token = self.create_jwt()

            # Format the Authorization header
            return {"Authorization": f"Bearer {token}"}

        except Exception as e:
            if isinstance(e, (ConfigurationError, JWTSigningError, TokenValidationError)):
                raise
            raise JWTSigningError("Failed to create authorization headers", details=str(e)) from e

    def _validate_token_structure(self, token: str) -> bool:
        """Validate the basic structure of a JWT token.

        Args:
            token: The JWT token string to validate

        Returns:
            True if the token structure is valid, False otherwise
        """
        if not isinstance(token, str) or not token.strip():
            return False

        # JWT should have exactly 3 parts separated by dots
        parts = token.split(".")
        if len(parts) != 3:
            return False

        header, payload, signature = parts

        # Each part should be non-empty
        if not all(part.strip() for part in parts):
            return False

        # Each part should be valid base64url (we'll try to decode)
        try:
            import base64

            for part in [header, payload]:
                # Add padding if needed for base64 decoding
                pad_len = (-len(part)) % 4
                padded = part + ("=" * pad_len)
                base64.urlsafe_b64decode(padded)

            # Signature should also be valid base64url
            sig_pad_len = (-len(signature)) % 4
            padded_sig = signature + ("=" * sig_pad_len)
            base64.urlsafe_b64decode(padded_sig)
        except Exception:
            return False

        return True

    def _validate_token_claims(self, decoded_payload: dict[str, Any]) -> None:
        """Validate that a JWT payload contains all required claims.

        Args:
            decoded_payload: The decoded JWT payload dictionary

        Raises:
            JWTSigningError: If required claims are missing or invalid
        """
        if not isinstance(decoded_payload, dict):
            raise JWTSigningError("Invalid token payload", details="Token payload must be a dictionary")

        # Check for required claims
        required_claims = ["sub", "iat", "exp", "iss"]
        missing_claims = [claim for claim in required_claims if claim not in decoded_payload]

        if missing_claims:
            raise TokenValidationError(
                "Invalid token claims", details=f"Token missing required claims: {', '.join(missing_claims)}"
            )

        # Validate claim types and values
        try:
            # Subject should be a string (wallet address)
            if not isinstance(decoded_payload["sub"], str) or not decoded_payload["sub"].strip():
                raise TokenValidationError(
                    "Invalid token claims", details="Subject (sub) claim must be a non-empty string"
                )

            # Issued at should be a valid timestamp
            iat = decoded_payload["iat"]
            if not isinstance(iat, (int, float)) or iat <= 0:
                raise TokenValidationError(
                    "Invalid token claims", details="Issued at (iat) claim must be a positive timestamp"
                )

            # Expiration should be a valid timestamp
            exp = decoded_payload["exp"]
            if not isinstance(exp, (int, float)) or exp <= 0:
                raise TokenValidationError(
                    "Invalid token claims", details="Expiration (exp) claim must be a positive timestamp"
                )

            # Expiration should be after issued at
            if exp <= iat:
                raise TokenValidationError("Invalid token claims", details="Expiration time must be after issued time")

            # Issuer should be our expected value
            if decoded_payload["iss"] != "silhouette-sdk":
                raise TokenValidationError(
                    "Invalid token claims", details="Issuer (iss) claim must be 'silhouette-sdk'"
                )

        except Exception as e:
            if isinstance(e, (JWTSigningError, TokenValidationError)):
                raise
            raise TokenValidationError("Failed to validate token claims", details=str(e)) from e
