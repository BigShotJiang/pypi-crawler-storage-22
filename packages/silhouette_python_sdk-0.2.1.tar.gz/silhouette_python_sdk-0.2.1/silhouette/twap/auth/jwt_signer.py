"""Low-level JWT signing implementation using ECDSA with ES256K algorithm.

This module provides the core JWT signing functionality using Hyperliquid API keys
and the secp256k1 elliptic curve for ECDSA signatures.
"""

import base64
import json
from typing import Any

import jwt
from cryptography.hazmat.primitives.asymmetric import ec

from .exceptions import CryptographicError, JWTSigningError, PayloadValidationError
from .utils import create_agent_account_from_key, validate_hyperliquid_key_format


class JWTSigner:
    """Low-level JWT signer using ECDSA with ES256K algorithm.

    This class handles the cryptographic operations for creating and signing
    JWT tokens using Hyperliquid API keys with the secp256k1 curve.
    """

    def __init__(self, hyperliquid_api_key: str) -> None:
        """Initialize the JWT signer with a Hyperliquid API key.

        Args:
            hyperliquid_api_key: The Hyperliquid API key for signing operations

        Raises:
            JWTSigningError: If the API key is invalid or cannot be used for signing
        """
        if not validate_hyperliquid_key_format(hyperliquid_api_key):
            raise JWTSigningError(
                "Invalid Hyperliquid API key format", details="API key must be a 64-character hexadecimal string"
            )

        try:
            self._account = create_agent_account_from_key(hyperliquid_api_key)
            # Convert the eth_account key to a cryptography EC private key for ES256K
            private_key_bytes = self._account.key
            self._private_key = ec.derive_private_key(
                int.from_bytes(private_key_bytes, byteorder="big"),
                ec.SECP256K1(),
            )
        except Exception as e:
            raise JWTSigningError("Failed to initialize JWT signer", details=str(e)) from e

    def sign_jwt(self, payload: dict[str, Any]) -> str:
        """Sign a JWT payload using ES256K algorithm.

        Args:
            payload: The JWT payload dictionary to sign

        Returns:
            The signed JWT token as a string

        Raises:
            JWTSigningError: If signing fails or payload is invalid
        """
        if not isinstance(payload, dict):
            raise JWTSigningError("Invalid JWT payload", details="Payload must be a dictionary")

        if not payload:
            raise JWTSigningError("Invalid JWT payload", details="Payload cannot be empty")

        # Validate payload structure
        try:
            self._validate_payload_structure(payload)
        except PayloadValidationError:
            raise
        except Exception as e:
            raise PayloadValidationError("Failed to validate JWT payload", details=str(e)) from e

        try:
            # Create JWT token using ES256K algorithm
            # PyJWT doesn't support ES256K directly, so we need to use the cryptography library
            token = jwt.encode(payload, self._private_key, algorithm="ES256K", headers={"typ": "JWT", "alg": "ES256K"})

            # Validate the created token structure
            if not self._validate_jwt_structure(token):
                raise JWTSigningError(
                    "Failed to create valid JWT token", details="Generated token has invalid structure"
                )

            return token

        except Exception as e:
            if isinstance(e, JWTSigningError):
                raise
            # Handle specific cryptographic errors
            if "cryptography" in str(type(e)).lower() or "ecdsa" in str(e).lower():
                raise CryptographicError("Cryptographic signing operation failed", details=str(e)) from e
            raise JWTSigningError("Failed to sign JWT token", details=str(e)) from e

    def _get_wallet_address(self) -> str:
        """Get wallet address using the Hyperliquid SDK.

        Returns:
            The wallet address as a hex string

        Raises:
            JWTSigningError: If wallet address retrieval fails
        """
        # TODO: Implement in task 2
        raise NotImplementedError("Wallet address retrieval will be implemented in task 2")

    def _validate_jwt_structure(self, token: str) -> bool:
        """Validate the structure and format of a JWT token.

        Args:
            token: The JWT token string to validate

        Returns:
            True if the token structure is valid, False otherwise
        """
        if not isinstance(token, str):
            return False  # type: ignore[unreachable]

        # JWT should have exactly 3 parts separated by dots
        parts = token.split(".")
        if len(parts) != 3:
            return False

        header, payload, signature = parts

        # Each part should be valid base64url
        for part in [header, payload]:
            try:
                # Add padding if needed for base64 decoding
                missing = (-len(part)) % 4
                padded = part + "=" * missing
                base64.urlsafe_b64decode(padded)
            except Exception:
                return False

        # Validate header structure
        try:
            missing = (-len(header)) % 4
            header_data = json.loads(base64.urlsafe_b64decode(header + "=" * missing))
            if not isinstance(header_data, dict):
                return False
            if header_data.get("typ") != "JWT":
                return False
            if header_data.get("alg") != "ES256K":
                return False
        except Exception:
            return False

        # Validate payload structure
        try:
            missing = (-len(payload)) % 4
            payload_data = json.loads(base64.urlsafe_b64decode(payload + "=" * missing))
            if not isinstance(payload_data, dict):
                return False
        except Exception:
            return False

        # Signature should be valid base64url (we don't verify the signature here, just format)
        try:
            missing = (-len(signature)) % 4
            padded_sig = signature + "=" * missing
            base64.urlsafe_b64decode(padded_sig)
        except Exception:
            return False

        return True

    def _validate_payload_structure(self, payload: dict[str, Any]) -> None:
        """Validate the structure of a JWT payload before signing.

        Args:
            payload: The JWT payload dictionary to validate

        Raises:
            JWTSigningError: If the payload structure is invalid
        """
        # Check for JSON serializable values
        try:
            json.dumps(payload)
        except (TypeError, ValueError) as e:
            raise PayloadValidationError(
                "Invalid JWT payload", details=f"Payload must be JSON serializable: {str(e)}"
            ) from e

        # Check for reserved claim names and validate their types
        if "iat" in payload:
            if not isinstance(payload["iat"], (int, float)) or payload["iat"] <= 0:
                raise PayloadValidationError(
                    "Invalid JWT payload", details="Issued at (iat) claim must be a positive number"
                )

        if "exp" in payload:
            if not isinstance(payload["exp"], (int, float)) or payload["exp"] <= 0:
                raise PayloadValidationError(
                    "Invalid JWT payload", details="Expiration (exp) claim must be a positive number"
                )

        if "sub" in payload:
            if not isinstance(payload["sub"], str) or not payload["sub"].strip():
                raise PayloadValidationError(
                    "Invalid JWT payload", details="Subject (sub) claim must be a non-empty string"
                )

        if "iss" in payload:
            if not isinstance(payload["iss"], str) or not payload["iss"].strip():
                raise PayloadValidationError(
                    "Invalid JWT payload", details="Issuer (iss) claim must be a non-empty string"
                )

        # Validate expiration is after issued time if both are present
        if "iat" in payload and "exp" in payload:
            if payload["exp"] <= payload["iat"]:
                raise PayloadValidationError("Invalid JWT payload", details="Expiration time must be after issued time")
