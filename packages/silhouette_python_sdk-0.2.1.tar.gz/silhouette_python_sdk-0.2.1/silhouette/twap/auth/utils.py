"""Utility functions for JWT authentication and wallet operations.

This module provides utility functions for wallet address derivation,
API key validation, and other authentication-related operations.
"""

import re

from eth_account import Account
from eth_account.signers.local import LocalAccount

from .exceptions import InvalidHyperliquidKeyError


def validate_wallet_credentials(hyperliquid_api_key: str, wallet_address: str) -> str:
    """Validate Hyperliquid API key and wallet address credentials.

    This function validates that both the Hyperliquid API key (agent key) and wallet address
    are properly formatted. It does not derive the wallet address from the API key, but rather
    validates that both credentials are in the correct format for use with Hyperliquid.

    Args:
        hyperliquid_api_key: The Hyperliquid agent key (64-character hex string, with or without 0x prefix)
        wallet_address: The wallet address that this agent key is authorized to act on behalf of

    Returns:
        The validated wallet address as a hex string (e.g., "0x1234...")

    Raises:
        InvalidHyperliquidKeyError: If the API key format is invalid or wallet address is malformed
    """
    if not validate_hyperliquid_key_format(hyperliquid_api_key):
        raise InvalidHyperliquidKeyError(
            "Invalid Hyperliquid API key format", details="API key must be a 64-character hexadecimal string"
        )

    if not validate_wallet_address_format(wallet_address):
        raise InvalidHyperliquidKeyError(
            "Invalid wallet address format",
            details="Wallet address must be a valid Ethereum address (0x followed by 40 hex characters)",
        )

    return wallet_address


def validate_hyperliquid_key_format(api_key: str | None) -> bool:
    """Validate the format of a Hyperliquid API key (agent key).

    Hyperliquid API keys are expected to be 64-character hexadecimal strings
    representing 32-byte agent keys, with or without the "0x" prefix.

    Args:
        api_key: The API key to validate

    Returns:
        True if the format is valid, False otherwise
    """
    if not isinstance(api_key, str):
        return False

    # Remove 0x prefix if present
    key_without_prefix = api_key[2:] if api_key.startswith("0x") else api_key

    # Check if it's exactly 64 characters and all hexadecimal
    if len(key_without_prefix) != 64:
        return False

    # Check if all characters are valid hexadecimal
    hex_pattern = re.compile(r"^[0-9a-fA-F]+$")
    return bool(hex_pattern.match(key_without_prefix))


def validate_wallet_address_format(address: str | None) -> bool:
    """Validate the format of an Ethereum wallet address.

    Args:
        address: The wallet address to validate

    Returns:
        True if the format is valid, False otherwise
    """
    if not isinstance(address, str):
        return False

    # Must start with 0x and be exactly 42 characters total
    if not address.startswith("0x") or len(address) != 42:
        return False

    # Check if all characters after 0x are valid hexadecimal
    hex_part = address[2:]
    hex_pattern = re.compile(r"^[0-9a-fA-F]+$")
    return bool(hex_pattern.match(hex_part))


def create_agent_account_from_key(hyperliquid_api_key: str) -> LocalAccount:
    """Create an eth_account LocalAccount from a Hyperliquid agent key.

    This creates a LocalAccount that can be used for signing operations with the agent key.
    Note that this account represents the agent key, not the wallet it acts on behalf of.

    Args:
        hyperliquid_api_key: The Hyperliquid agent key

    Returns:
        A LocalAccount instance for signing with the agent key

    Raises:
        InvalidHyperliquidKeyError: If the API key is invalid or malformed
    """
    if not validate_hyperliquid_key_format(hyperliquid_api_key):
        raise InvalidHyperliquidKeyError(
            "Invalid Hyperliquid API key format", details="API key must be a 64-character hexadecimal string"
        )

    try:
        # Ensure the key has 0x prefix for eth_account
        agent_key = hyperliquid_api_key
        if not agent_key.startswith("0x"):
            agent_key = "0x" + agent_key

        account: LocalAccount = Account.from_key(agent_key)
        return account

    except Exception as e:
        raise InvalidHyperliquidKeyError("Failed to create agent account from API key", details=str(e)) from e
