"""Authenticated TWAP client with automatic authentication lifecycle management.

This module provides a high-level TWAP client that automatically handles:
- Health check on initialization
- JWT token generation and refresh
- User registration check and auto-registration
- Automatic JWT refresh on 401 responses
"""

import logging
from functools import wraps
from typing import Any

from .auth.exceptions import ConfigurationError, JWTSigningError
from .auth.jwt_service import JWTSigningService
from .client import AuthenticationExpiredError, TwapClient, TwapClientError

logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
    """Exception raised when authentication flow fails."""

    def __init__(self, message: str, details: str | None = None) -> None:
        """Initialize the authentication error.

        Args:
            message: The main error message
            details: Optional additional details about the error
        """
        super().__init__(message)
        self.message = message
        self.details = details

    def __str__(self) -> str:
        """Return a string representation of the error."""
        if self.details is not None and self.details.strip():
            return f"{self.message}: {self.details}"
        return self.message


def handle_401_retry(method):
    """Decorator to handle 401 responses by refreshing JWT and retrying once.

    Args:
        method: The method to wrap

    Returns:
        Wrapped method that handles 401 responses
    """

    @wraps(method)
    def wrapper(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except AuthenticationExpiredError:
            logger.info("Authentication expired, refreshing JWT token")

            # Refresh the JWT token
            try:
                self._refresh_jwt()
            except Exception as refresh_error:
                raise AuthenticationError("Failed to refresh JWT token", details=str(refresh_error)) from refresh_error

            # Retry the operation once
            try:
                return method(self, *args, **kwargs)
            except AuthenticationExpiredError as err:
                raise AuthenticationError(
                    "Authentication failed after token refresh",
                    details="The operation failed with 401 even after refreshing the JWT token",
                ) from err

    return wrapper


class AuthenticatedTwapClient:
    """High-level TWAP client with automatic authentication management.

    This client automatically handles:
    - Health check on initialization
    - JWT token generation
    - User registration check and auto-registration
    - JWT token refresh on 401 responses

    All authentication is handled transparently, allowing users to focus
    on their trading logic.
    """

    def __init__(self, base_url: str, hyperliquid_api_key: str, wallet_address: str) -> None:
        """Initialize the authenticated TWAP client.

        This will automatically:
        1. Perform a health check
        2. Generate an initial JWT token
        3. Check if the user is registered
        4. Register the user if needed

        Args:
            base_url: The base URL for the TWAP API
            hyperliquid_api_key: The Hyperliquid API key for signing
            wallet_address: The wallet address

        Raises:
            AuthenticationError: If initialization or authentication fails
            ConfigurationError: If credentials are invalid
        """
        self._base_url = base_url
        self._hyperliquid_api_key = hyperliquid_api_key
        self._wallet_address = wallet_address
        self._is_ready = False

        try:
            # Initialize JWT service
            self._jwt_service = JWTSigningService(hyperliquid_api_key, wallet_address)

            # Initialize underlying TWAP client with generated client
            try:
                # Try to import the generated client for e2e tests
                from generated.twap_client.silhouette_scheduler_api_reference_client.client import (
                    Client as GeneratedClient,
                )

                generated_client = GeneratedClient(base_url=base_url)
            except ImportError as err:
                # If generated client is not available, raise an error
                raise AuthenticationError(
                    "Generated client is required for e2e tests",
                    details="Please run 'make generate-twap-client' to generate the required client files.",
                ) from err

            self._twap_client = TwapClient(
                base_url=base_url,
                jwt_service=self._jwt_service,
                generated_client=generated_client,
                wallet_address=wallet_address,
            )

            # Run the startup flow
            self._startup_flow()

            self._is_ready = True
            logger.info("Authenticated TWAP client initialized successfully")

        except (JWTSigningError, ConfigurationError) as e:
            raise AuthenticationError("Failed to initialize authentication", details=str(e)) from e

    def _startup_flow(self) -> None:
        """Execute the startup authentication flow.

        Steps:
        1. Health check
        2. Verify registration status
        3. Register if needed

        Raises:
            AuthenticationError: If any step fails
        """
        logger.info("Starting authentication flow")

        # Step 1: Health check
        try:
            health = self._twap_client.get_health_check()
            logger.debug("Health check passed: %s", health)
        except TwapClientError as e:
            raise AuthenticationError("Health check failed", details=str(e)) from e

        # Step 2: Check registration status
        try:
            verification = self._twap_client.verify({})
            is_registered = verification.get("verified", False)
            logger.debug("Registration status: %s", "registered" if is_registered else "not registered")
        except TwapClientError as e:
            raise AuthenticationError("Failed to verify registration status", details=str(e)) from e

        # Step 3: Register if needed
        if not is_registered:
            try:
                logger.info("User not registered, registering now")
                registration = self._twap_client.register(self._hyperliquid_api_key, self._wallet_address)
                logger.info("Registration successful: %s", registration.get("message", ""))
            except TwapClientError as e:
                raise AuthenticationError("Registration failed", details=str(e)) from e
        else:
            logger.info("User already registered, skipping registration")

    def _refresh_jwt(self) -> None:
        """Refresh the JWT token by generating a new one.

        This updates the internal JWT service state with a fresh token.

        Raises:
            JWTSigningError: If JWT generation fails
        """
        logger.info("Refreshing JWT token")

        # Generate a new JWT token
        # The JWT service will automatically use the new token for subsequent requests
        self._jwt_service.create_jwt(expires_in=3600)
        logger.debug("New JWT token generated")

    def is_ready(self) -> bool:
        """Check if the client is ready to use.

        Returns:
            True if the client has completed initialization and is ready
        """
        return self._is_ready

    @handle_401_retry
    def create_twap_order(self, order_data: dict[str, Any]) -> dict[str, Any]:
        """Create a TWAP order with automatic 401 handling.

        Args:
            order_data: The order data dictionary

        Returns:
            The created order response

        Raises:
            TwapClientError: If order creation fails
            AuthenticationError: If authentication fails after retry
        """
        return self._twap_client.create_twap_order(order_data)

    @handle_401_retry
    def get_order(self, order_id: str) -> dict[str, Any]:
        """Get order details with automatic 401 handling.

        Args:
            order_id: The order ID to retrieve

        Returns:
            The order details

        Raises:
            TwapClientError: If order retrieval fails
            AuthenticationError: If authentication fails after retry
        """
        return self._twap_client.get_order(order_id)

    @handle_401_retry
    def cancel_order(self, order_id: str) -> dict[str, Any]:
        """Cancel an order with automatic 401 handling.

        Args:
            order_id: The order ID to cancel

        Returns:
            The cancellation response

        Raises:
            TwapClientError: If order cancellation fails
            AuthenticationError: If authentication fails after retry
        """
        return self._twap_client.cancel_order(order_id)

    @handle_401_retry
    def pause_order(self, order_id: str) -> dict[str, Any]:
        """Pause an order with automatic 401 handling.

        Args:
            order_id: The order ID to pause

        Returns:
            The pause response

        Raises:
            TwapClientError: If order pause fails
            AuthenticationError: If authentication fails after retry
        """
        return self._twap_client.pause_order(order_id)

    @handle_401_retry
    def resume_order(self, order_id: str) -> dict[str, Any]:
        """Resume a paused order with automatic 401 handling.

        Args:
            order_id: The order ID to resume

        Returns:
            The resume response

        Raises:
            TwapClientError: If order resume fails
            AuthenticationError: If authentication fails after retry
        """
        return self._twap_client.resume_order(order_id)

    @handle_401_retry
    def get_orders_by_user(self) -> list[dict[str, Any]]:
        """Get all orders for the authenticated user with automatic 401 handling.

        Returns:
            The list of orders

        Raises:
            TwapClientError: If order retrieval fails
            AuthenticationError: If authentication fails after retry
        """
        return self._twap_client.get_orders_by_user()

    def get_wallet_address(self) -> str:
        """Get the wallet address for this client.

        Returns:
            The wallet address
        """
        return self._wallet_address

    def get_health_check(self) -> dict[str, Any]:
        """Get the health status of the TWAP scheduler.

        Returns:
            Health check response from the scheduler

        Raises:
            TwapClientError: If health check fails
        """
        return self._twap_client.get_health_check()
