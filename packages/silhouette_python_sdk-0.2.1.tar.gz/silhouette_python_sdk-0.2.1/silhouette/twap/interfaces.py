"""
Interfaces for TWAP client integration.

This module defines the minimal interfaces needed for integrating
generated TWAP client code with the Silhouette SDK.
"""

from abc import ABC, abstractmethod
from typing import Any

from generated.twap_client.silhouette_scheduler_api_reference_client.models.create_twap_order_dto import (
    CreateTwapOrderDto,
)


class TwapClientInterface(ABC):
    """
    Interface for TWAP client implementations.

    This interface defines the contract that TWAP clients must follow
    to be compatible with the Silhouette SDK.
    """

    @abstractmethod
    def create_twap_order(self, order_data: CreateTwapOrderDto) -> dict[str, Any]:
        """Create a TWAP order.

        Args:
            order_data: The order data containing all required fields including
                       order_side, market_type, order_intent (for perp), and slippage
        """
        pass

    @abstractmethod
    def get_order(self, order_id: str) -> dict[str, Any]:
        """Get order details by ID."""
        pass

    @abstractmethod
    def cancel_order(self, order_id: str) -> dict[str, Any]:
        """Cancel an order by order ID."""
        pass

    @abstractmethod
    def pause_order(self, order_id: str) -> dict[str, Any]:
        """Pause an order."""
        pass

    @abstractmethod
    def resume_order(self, order_id: str) -> dict[str, Any]:
        """Resume an order."""
        pass

    @abstractmethod
    def get_orders_by_user(self) -> list[dict[str, Any]]:
        """Get orders for a specific user."""
        pass

    @abstractmethod
    def register(self, hyperliquid_api_key: str, wallet_address: str) -> dict[str, Any]:
        """Register API key with the scheduler service."""
        pass

    @abstractmethod
    def verify(self, verification_data: dict[str, Any]) -> dict[str, Any]:
        """Verify authentication with the scheduler service."""
        pass

    @abstractmethod
    def get_task_status(self, task_id: str) -> dict[str, Any]:
        """Get task status by task ID."""
        pass

    @abstractmethod
    def get_health_check(self) -> dict[str, Any]:
        """Get health check status from the scheduler service."""
        pass
