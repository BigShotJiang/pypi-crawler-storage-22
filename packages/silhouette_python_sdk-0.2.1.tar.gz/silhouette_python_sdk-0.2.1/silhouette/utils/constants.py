"""Silhouette API URL constants."""

# Silhouette API URLs
SILHOUETTE_API_MAINNET_URL = "https://api.silhouette.exchange"
SILHOUETTE_API_TESTNET_URL = "https://api.silhouette.exchange"

# Silhouette TWAP Scheduler URLs
SILHOUETTE_TWAP_MAINNET_URL = "https://twap.silhouette.exchange"
SILHOUETTE_TWAP_TESTNET_URL = "https://twap.silhouette.exchange"
