# Version number following semver standard.
version = '0.53.1'
