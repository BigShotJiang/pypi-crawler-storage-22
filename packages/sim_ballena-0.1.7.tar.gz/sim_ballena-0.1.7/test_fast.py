import numpy as np
import matplotlib.pyplot as plt
import sim_ballena as ballena

neu = ballena.Lif().v_reset(-56).v_thres(-57)
print( neu )