#pragma once
#include <stator/xml.hpp>
#include <memory>

namespace simcem {
  using std::shared_ptr;
  using std::make_shared;
  using std::dynamic_pointer_cast;
  using namespace stator::xml;
}
