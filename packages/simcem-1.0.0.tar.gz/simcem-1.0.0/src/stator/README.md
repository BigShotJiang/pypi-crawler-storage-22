Stator is a C++11 math library which uses template metaprogramming to
build a Computer Algebra System.

Aside from the math, it has some tools for application in
event-driven dynamics/ray-tracing/collision-detection.

For full details, see the Documentation:

https://toastedcrumpets.github.io/stator