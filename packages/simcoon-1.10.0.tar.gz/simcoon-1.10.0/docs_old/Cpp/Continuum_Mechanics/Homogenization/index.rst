Homogenization
==============

.. toctree::

    eshelby.rst
