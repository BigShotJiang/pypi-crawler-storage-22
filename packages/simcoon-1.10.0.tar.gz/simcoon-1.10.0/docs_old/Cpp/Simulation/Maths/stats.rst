The Statistics Library
======================
