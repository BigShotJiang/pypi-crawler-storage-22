"""Simforge client for provider-based API calls."""

from simforge.client import (
    AllowedEnvVars,
    CurrentSpan,
    CurrentTrace,
    Simforge,
    SimforgeFunction,
    SpanType,
    flush_traces,
    get_current_span,
    get_current_trace,
)
from simforge.replay import ReplayItem, ReplayResult

# Only export SimforgeTracingProcessor if openai-agents is available
try:
    from simforge.tracing import (
        SimforgeOpenAITracingProcessor as SimforgeTracingProcessor,
    )

    __all__ = [
        "Simforge",
        "SimforgeFunction",
        "CurrentSpan",
        "CurrentTrace",
        "SpanType",
        "AllowedEnvVars",
        "SimforgeTracingProcessor",
        "ReplayItem",
        "ReplayResult",
        "flush_traces",
        "get_current_span",
        "get_current_trace",
    ]
except ImportError:
    # openai-agents not installed, skip tracing processor export
    __all__ = [
        "Simforge",
        "SimforgeFunction",
        "CurrentSpan",
        "CurrentTrace",
        "SpanType",
        "AllowedEnvVars",
        "ReplayItem",
        "ReplayResult",
        "flush_traces",
        "get_current_span",
        "get_current_trace",
    ]
