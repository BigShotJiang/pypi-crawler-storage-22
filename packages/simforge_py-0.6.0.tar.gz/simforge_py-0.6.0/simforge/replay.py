"""Replay historical traces through a function and create a test run."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Callable, TypedDict

from simforge.http import flush_traces
from simforge.serialize import deserialize_value

if TYPE_CHECKING:
    from simforge.client import Simforge

logger = logging.getLogger(__name__)


class ReplayItem(TypedDict):
    """A single item from a replay execution."""

    input: list[Any]
    result: Any
    original_output: Any
    error: str | None


class ReplayResult(TypedDict):
    """Result from a replay execution."""

    items: list[ReplayItem]
    test_run_id: str
    test_run_url: str


def _find_simforge_wrapper(fn: Callable) -> Callable | None:
    """Walk the __wrapped__ chain to find the innermost simforge-decorated function.

    Handles nested decorators (e.g. @retry(@cache(@span(fn)))) by traversing
    through each layer's __wrapped__ attribute until it finds one with
    _simforge_wrapped=True.
    """
    current = fn
    seen: set[int] = set()
    while current is not None:
        if id(current) in seen:
            break
        seen.add(id(current))
        if getattr(current, "_simforge_wrapped", False):
            return current
        current = getattr(current, "__wrapped__", None)
    return None


def replay(
    client: Simforge,
    fn: Callable,
    *,
    limit: int = 5,
    trace_ids: list[str] | None = None,
) -> ReplayResult:
    """Replay historical traces through a function and create a test run.

    Fetches the last N traces for the given trace function key, re-runs each
    through the provided function (wrapped with span decorator for tracing),
    and returns comparison data.

    The function is called through its full decorator chain (e.g. @retry,
    @cache) — replay injects test_run_id via context rather than re-wrapping.

    Args:
        client: The Simforge client instance
        fn: The function to replay (must be decorated with @span)
        limit: Maximum number of traces to replay
        trace_ids: Optional list of trace IDs to filter which traces are replayed

    Returns:
        ReplayResult with items (input, result, original_output, error),
        test_run_id, and test_run_url
    """
    wrapper = _find_simforge_wrapper(fn)
    if wrapper is None:
        raise ValueError(
            f"Function {getattr(fn, '__name__', repr(fn))} must be decorated with @span before calling replay."
        )

    trace_function_key = getattr(wrapper, "_simforge_trace_function_key")

    replay_data = client.http_client.start_replay(trace_function_key, limit, trace_ids=trace_ids)
    test_run_id = replay_data["testRunId"]
    test_run_url = replay_data["testRunUrl"]
    server_items = replay_data["items"]

    result_items: list[ReplayItem] = []

    for server_item in server_items:
        span = client.http_client.get_external_span(server_item["externalSpanId"])
        item_data = _extract_span_data(span)

        replay_item, _had_error = _execute_item(
            item_data, fn, test_run_id
        )
        result_items.append(replay_item)

    flush_traces()

    try:
        client.http_client.complete_replay(test_run_id)
    except Exception as e:
        logger.error(f"Failed to complete replay: {e}")

    return ReplayResult(
        items=result_items,
        test_run_id=test_run_id,
        test_run_url=f"{client.service_url}{test_run_url}",
    )


def _extract_span_data(span: dict[str, Any]) -> dict[str, Any]:
    """Extract input/output data and span options from an external span's rawData."""
    raw_data = span.get("rawData") or {}
    span_data = raw_data.get("span_data") or {}

    return {
        "input": span_data.get("input"),
        "output": span_data.get("output"),
        "inputSerialized": span_data.get("input_serialized"),
        "outputSerialized": span_data.get("output_serialized"),
    }


def _execute_item(
    item: dict[str, Any],
    fn: Callable,
    test_run_id: str,
) -> tuple[ReplayItem, bool]:
    """Execute a single replay item: deserialize inputs, call fn with replay context.

    Sets the replay context so the existing @span decorator picks up
    test_run_id, then calls fn through its full decorator chain.

    Returns:
        Tuple of (ReplayItem, had_error)
    """
    args, kwargs = _deserialize_inputs(item)

    fn_result = None
    fn_error = None

    from simforge.client import _replay_context

    token = _replay_context.set({"test_run_id": test_run_id})
    try:
        if asyncio.iscoroutinefunction(fn):
            fn_result = asyncio.run(fn(*args, **kwargs))
        else:
            fn_result = fn(*args, **kwargs)
    except Exception as e:
        fn_error = str(e)
    finally:
        _replay_context.reset(token)

    replay_item = ReplayItem(
        input=args,
        result=fn_result,
        original_output=item.get("output"),
        error=fn_error,
    )
    return replay_item, fn_error is not None


def _deserialize_inputs(item: dict[str, Any]) -> tuple[list[Any], dict[str, Any]]:
    """Deserialize inputs from a replay item into (args, kwargs)."""
    input_serialized = item.get("inputSerialized")
    raw_input = item.get("input")

    if (
        input_serialized
        and isinstance(input_serialized, dict)
        and "meta" in input_serialized
    ):
        deserialized = deserialize_value(input_serialized)
        if isinstance(deserialized, dict):
            return deserialized.get("args", []), deserialized.get("kwargs", {})
        return [deserialized] if deserialized is not None else [], {}

    if isinstance(raw_input, list):
        return raw_input, {}
    if isinstance(raw_input, dict):
        return [], raw_input
    return [raw_input] if raw_input is not None else [], {}
