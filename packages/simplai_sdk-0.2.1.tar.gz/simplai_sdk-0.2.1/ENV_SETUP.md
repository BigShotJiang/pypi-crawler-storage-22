# Environment Configuration Setup

This guide explains how to set up environment variables for the Simplai Python SDK.

## Quick Start

1. **Copy the example file:**
   ```bash
   cp .env.example .env
   ```

2. **Edit `.env` with your values:**
   ```env
   API_KEY=your-pim-sid-api-key-here
   AGENT_ID=agent-6912e47d72fe386f5281c242
   SIMPAI_BASE_URL=https://edge-service-preprod.simplai.ai
   ```

3. **Install python-dotenv (if not already installed):**
   ```bash
   pip install python-dotenv
   ```

4. **Run the test scripts:**
   ```bash
   python tests/test_agent_chat.py
   ```

## Environment Variables

### Required

- **`API_KEY`**: Your PIM-SID API key for authentication

### Optional

- **`BASE_URL`**: Base URL for the Simplai API (default: `https://edge-service-preprod.simplai.ai`)
- **`AGENT_ID`**: Default agent ID to use in tests
- **`MESSAGE`**: Default message to send in tests
- **`CONVERSATION_ID`**: Existing conversation ID for continuing conversations
- **`PROJECT_ID`**: Project ID for the API requests
- **`TENANT_ID`**: Tenant ID (default: `1`)
- **`USER_ID`**: User ID for the API requests

## File Locations

- **`.env.example`**: Template file with example values (safe to commit)
- **`.env`**: Your actual configuration (gitignored, do NOT commit)

## Security Notes

⚠️ **Important:**
- Never commit your `.env` file to version control
- The `.env` file is automatically gitignored
- Keep your API keys secure and never share them publicly
- Use different API keys for different environments (dev, staging, prod)

## Loading Order

The SDK automatically loads API keys and configuration in this priority order:

1. **User-provided parameter** (e.g., `SimplAI(api_key="...")`)
2. **Environment variable** (e.g., `export API_KEY=...`)
3. **`.env` file** (automatically loaded if `python-dotenv` is installed)
4. **Default values** (for base_url only)

For API keys, if none of the above are found, the SDK will raise a clear error message.

## Example .env File

```env
# API Configuration
API_KEY=ccd97fb6-f105-4a82-9e6a-bc6a27734d5f
SIMPAI_BASE_URL=https://edge-service-preprod.simplai.ai

# Agent Configuration
AGENT_ID=agent-6912e47d72fe386f5281c242

# Test Message
MESSAGE=Hello! Can you help me?

# Project Configuration
PROJECT_ID=407
TENANT_ID=1
USER_ID=4
```

## Troubleshooting

### "API key is required" Error
The SDK will show this error if it cannot find an API key. To fix:

1. **Provide API key explicitly:**
   ```python
   simplai = SimplAI(api_key="your-api-key")
   ```

2. **Set environment variable:**
   ```bash
   export API_KEY=your-api-key
   ```

3. **Use `.env` file:**
   - Create a `.env` file in the `python-sdk` directory
   - Add `API_KEY=your-api-key` to the file
   - Ensure `python-dotenv` is installed: `pip install python-dotenv`

### Environment variables not loading
- Verify the `.env` file path is correct (should be in `python-sdk/` directory)
- Check for typos in variable names
- Ensure there are no spaces around the `=` sign
- Make sure `python-dotenv` is installed if using `.env` files
- The SDK will automatically search for `.env` files in common locations

### Using environment variables directly
If you prefer not to use `.env` files, you can set environment variables directly:

```bash
export API_KEY=your-api-key
export AGENT_ID=agent-123
python tests/test_agent_chat.py
```

Or inline:
```bash
API_KEY=your-api-key python tests/test_agent_chat.py
```

