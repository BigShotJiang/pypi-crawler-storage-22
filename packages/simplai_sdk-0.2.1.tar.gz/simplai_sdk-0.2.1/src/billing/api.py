from .schema import BillingResponse

from typing import Any, Dict, List
import httpx

from exceptions import APIException


from constants import BILLING_BASE_URL as BASE_URL


async def get_billing_detail_api(
    trace_id: str,
    api_key: str,
) -> Dict[str, Any]:
    """
    Get the billing detail for a given trace ID.
    """
    url = f"{BASE_URL}/{trace_id}/detail"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }


    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                url,
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()

            if(response.status_code == 204):
                raise APIException(message="No Content", status_code=204)

                
            data = response.json()
            
            result = data.get("result", {})

            return BillingResponse(
                totalConsumption=result.get("totalConsumption", 0),
                appName=result.get("appName", ""),
                appType=result.get("appType", ""),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")