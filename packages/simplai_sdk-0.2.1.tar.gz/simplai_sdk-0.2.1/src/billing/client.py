from .api import get_billing_detail_api
from typing import Dict, Any


async def get_billing_detail(
    trace_id: str,
    api_key: str,
) -> Dict[str, Any]:
    billing_detail = await get_billing_detail_api(trace_id, api_key)
    return {
        "totalConsumption": billing_detail.totalConsumption,
        "appName": billing_detail.appName,
        "appType": billing_detail.appType,
    }