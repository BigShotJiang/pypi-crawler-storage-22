"""Pydantic schemas for bulk workflow execution API requests and responses."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field



class BillingResponse(BaseModel):
    """Response schema from bulk run API."""
    totalConsumption: float = Field(..., description="The total consumption of the app")
    appName: str = Field(..., description="The name of the app")
    appType: str = Field(..., description="The type of the app")

    class Config:
        populate_by_name = True
