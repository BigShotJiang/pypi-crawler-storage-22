"""Centralized constants for the SimplAI Python SDK.

This module contains all shared constants including base URLs, API paths,
and default configuration values used across the SDK.
"""

from __future__ import annotations

import os
from pathlib import Path

# Load .env file before reading environment variables
def _load_env_file() -> None:
    """Attempt to load .env file from common locations."""
    try:
        from dotenv import load_dotenv  # type: ignore[import]
    except ImportError:
        return

    # Try to find .env file in common locations
    current_dir = Path.cwd()
    possible_env_paths = [
        current_dir / ".env",
        current_dir.parent / ".env",  # python-sdk/.env
        Path(__file__).parent.parent.parent / ".env",  # python-sdk/.env from src/constants/__init__.py
    ]

    for env_path in possible_env_paths:
        if env_path.exists():
            load_dotenv(dotenv_path=env_path, override=False)
            break
    else:
        # Fallback: try loading from current directory
        load_dotenv(override=False)

# Load .env file
_load_env_file()

# ============================================================================
# Base URLs
# ============================================================================

# Get base URL from environment variable or use default
DEFAULT_BASE_URL = os.getenv("SIMPAI_BASE_URL")

# Service-specific base URLs
WORKFLOW_BASE_URL = f"{DEFAULT_BASE_URL}/interact/api/v2/tool"
BILLING_BASE_URL = f"{DEFAULT_BASE_URL}/billing/api/v1/bill"

#Billing base URL
BILLING_BASE_URL = f"{DEFAULT_BASE_URL}/billing/api/v1/bill"


# ============================================================================
# Agent API Paths
# ============================================================================

AGENT_CONVERSATION_PATH = "/interact/api/ve1/intract/conversation"
AGENT_STREAM_PATH = "/interact/api/v1/intract/data/{key}/stream"
AGENT_CONVERSATION_FETCH_PATH = "/interact/api/ve1/intract/conversation/fetch"  # SSE format
AGENT_CONVERSATION_FETCH_DETAILS_PATH = "/interact/api/ve1/intract/conversation/fetchDetails"  # JSON format

# ============================================================================
# Trace API Paths
# ============================================================================

# Request-level trace endpoints (RAG traces)
TRACE_V1_BASE_PATH = "/api/v1/trace"
TRACE_V1_FETCH_PATH = "/api/v1/trace"
TRACE_V1_DETAILS_PATH = "/api/v1/trace/details"
TRACE_V1_EVALUATE_PATH = "/api/v1/trace/evaluate"

# Tree-based trace endpoints
TRACE_V2_BASE_PATH = "/api/v2/trace"
TRACE_V2_FETCH_PATH = "/api/v2/trace"
TRACE_V2_AGGREGATE_OUTPUT_PATH = "/api/v2/trace/aggregate-output"
TRACE_V2_TREE_PATH = "/evaluation/api/v2/trace/tree"
TRACE_V2_DETAILS_PATH = "/evaluation/api/v2/trace/details"
TRACE_V2_DOWNLOAD_PATH = "/evaluation/api/v2/trace/download"

# Metrics endpoints
METRICS_V1_BASE_PATH = "/api/v1/metrics"
METRICS_V1_AGENT_PATH = "/api/v1/metrics/agent"
METRICS_V1_TOOL_PATH = "/api/v1/metrics/tool"

# ============================================================================
# Workflow Execution Constants
# ============================================================================

TERMINAL_STATES = {"COMPLETED", "FAILED", "CANCELLED"}
