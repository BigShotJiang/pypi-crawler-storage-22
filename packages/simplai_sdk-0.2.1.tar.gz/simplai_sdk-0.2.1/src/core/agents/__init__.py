"""Backwards-compatibility shim for earlier imports.

The implementation has been split into smaller modules for readability:

- constants: low-level URLs and defaults
- models:   AgentStatus / AgentResult / AgentExecutionError
- client:   AgentClient HTTP and polling logic
- api:      High-level helpers (agent_chat, agent_chat_stream, etc.)
"""

from .execution import (
    DEFAULT_BASE_URL,
    AgentClient,
    AgentExecutionError,
    AgentMessage,
    AgentResult,
    AgentStatus,
    AgentStreamChunk,
    agent_chat,
    agent_chat_async,
    agent_chat_stream,
    agent_chat_stream_async,
    get_agent_message_status,
    get_agent_message_status_async,
)

__all__ = [
    "DEFAULT_BASE_URL",
    "AgentStatus",
    "AgentResult",
    "AgentMessage",
    "AgentStreamChunk",
    "AgentExecutionError",
    "AgentClient",
    "agent_chat",
    "agent_chat_async",
    "agent_chat_stream",
    "agent_chat_stream_async",
    "get_agent_message_status",
    "get_agent_message_status_async",
]

