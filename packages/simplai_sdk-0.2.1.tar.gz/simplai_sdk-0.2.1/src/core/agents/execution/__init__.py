"""Simplai Agent SDK
==============

High-level Python SDK for chatting with Simplai agents.

Main entrypoints:

- agent_chat(...)                    # synchronous helper (polls until completion)
- agent_chat_async(...)             # async helper
- agent_chat_stream(...)             # streaming with callback (sync)
- agent_chat_stream_async(...)      # streaming with callback (async)
- get_agent_message_status(...)     # one-off status check (sync)
- get_agent_message_status_async(...) # one-off status check (async)
"""

from ..models import (
    AgentExecutionError,
    AgentMessage,
    AgentResult,
    AgentStatus,
    AgentStreamChunk,
)
from .api import (
    agent_chat,
    agent_chat_async,
    agent_chat_stream,
    agent_chat_stream_async,
    get_agent_message_status,
    get_agent_message_status_async,
)
from .client import AgentClient
from constants import DEFAULT_BASE_URL

__all__ = [
    "AgentClient",
    "AgentStatus",
    "AgentResult",
    "AgentMessage",
    "AgentStreamChunk",
    "AgentExecutionError",
    "DEFAULT_BASE_URL",
    "agent_chat",
    "agent_chat_async",
    "agent_chat_stream",
    "agent_chat_stream_async",
    "get_agent_message_status",
    "get_agent_message_status_async",
]

