from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from utils.config import get_api_key, get_base_url

from ..models import AgentMessage, AgentResult, AgentStreamChunk
from .client import AgentClient
from constants import DEFAULT_BASE_URL


def agent_chat(
    agent_id: str,
    message: str,
    *,
    api_key: str,
    chat_history: Optional[List[AgentMessage]] = None,
    conversation_id: Optional[str] = None,
    version_id: Optional[str] = None,
    state_override: Optional[Dict[str, Any]] = None,
    mode: str = "sync",
    timeout: Optional[float] = None,
    poll_interval: float = 2.0,
    base_url: str = DEFAULT_BASE_URL,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
    seller_id: Optional[str] = None,
    client_id: Optional[str] = None,
    seller_profile_id: Optional[str] = None,
) -> AgentResult | Dict[str, Any]:
    """Unified helper for agent chat (synchronous wrapper).

    Args:
        agent_id: ID of the agent to chat with.
        message: User message to send to the agent.
        api_key: PIM-SID API key.
        chat_history: Optional list of previous messages in the conversation.
        conversation_id: Optional existing conversation ID to continue.
        version_id: Optional agent version ID (defaults to "latest").
        state_override: Optional state override dictionary.
        mode: "sync" to poll until completion, "async" to return immediately.
        timeout: Optional timeout (seconds) for sync mode.
        poll_interval: Polling interval (seconds) for sync mode.
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for the conversation.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.
        seller_id: Optional seller ID (X-SELLER-ID header).
        client_id: Optional client ID (X-CLIENT-ID header).
        seller_profile_id: Optional seller profile ID (X-SELLER-PROFILE-ID header).

    Returns:
        If mode == "sync": AgentResult.
        If mode == "async": Response dict with conversation_id and message_id.
    """
    client = AgentClient(
        api_key=api_key,
        base_url=base_url,
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
        seller_id=seller_id,
        client_id=client_id,
        seller_profile_id=seller_profile_id,
    )

    mode_normalized = mode.lower()
    if mode_normalized == "async":
        response = client.chat_once(
            agent_id, message, chat_history, conversation_id, version_id, state_override
        )
        return response
    if mode_normalized == "sync":
        return client.chat_and_wait(
            agent_id,
            message,
            chat_history,
            conversation_id,
            version_id,
            state_override,
            poll_interval=poll_interval,
            timeout=timeout,
        )

    raise ValueError("mode must be either 'sync' or 'async'")


async def agent_chat_async(
    agent_id: str,
    message: str,
    *,
    api_key: str,
    chat_history: Optional[List[AgentMessage]] = None,
    conversation_id: Optional[str] = None,
    version_id: Optional[str] = None,
    state_override: Optional[Dict[str, Any]] = None,
    mode: str = "sync",
    timeout: Optional[float] = None,
    poll_interval: float = 2.0,
    base_url: str = DEFAULT_BASE_URL,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
    seller_id: Optional[str] = None,
    client_id: Optional[str] = None,
    seller_profile_id: Optional[str] = None,
) -> AgentResult | Dict[str, Any]:
    """Async variant of agent_chat."""
    client = AgentClient(
        api_key=api_key,
        base_url=base_url,
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
        seller_id=seller_id,
        client_id=client_id,
        seller_profile_id=seller_profile_id,
    )

    mode_normalized = mode.lower()
    if mode_normalized == "async":
        response = await client.achat_once(
            agent_id, message, chat_history, conversation_id, version_id, state_override
        )
        return response
    if mode_normalized == "sync":
        return await client.achat_and_wait(
            agent_id,
            message,
            chat_history,
            conversation_id,
            version_id,
            state_override,
            poll_interval=poll_interval,
            timeout=timeout,
        )

    raise ValueError("mode must be either 'sync' or 'async'")


def agent_chat_stream(
    agent_id: str,
    message: str,
    *,
    api_key: str,
    chat_history: Optional[List[AgentMessage]] = None,
    conversation_id: Optional[str] = None,
    version_id: Optional[str] = None,
    state_override: Optional[Dict[str, Any]] = None,
    on_chunk: Optional[Callable[[AgentStreamChunk], None]] = None,
    base_url: str = DEFAULT_BASE_URL,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
    seller_id: Optional[str] = None,
    client_id: Optional[str] = None,
    seller_profile_id: Optional[str] = None,
) -> AgentResult:
    """Stream agent chat response with callback for each chunk (synchronous).

    Args:
        agent_id: ID of the agent to chat with.
        message: User message to send to the agent.
        api_key: PIM-SID API key.
        chat_history: Optional list of previous messages in the conversation.
        conversation_id: Optional existing conversation ID to continue.
        version_id: Optional agent version ID.
        on_chunk: Optional callback function called for each streamed chunk.
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for the conversation.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        AgentResult with the complete response.
    """
    client = AgentClient(
        api_key=api_key,
        base_url=base_url,
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
        seller_id=seller_id,
        client_id=client_id,
        seller_profile_id=seller_profile_id,
    )

    return client.stream_chat(
        agent_id,
        message,
        chat_history,
        conversation_id,
        version_id,
        state_override,
        on_chunk=on_chunk,
    )


async def agent_chat_stream_async(
    agent_id: str,
    message: str,
    *,
    api_key: Optional[str] = None,
    chat_history: Optional[List[AgentMessage]] = None,
    conversation_id: Optional[str] = None,
    version_id: Optional[str] = None,
    state_override: Optional[Dict[str, Any]] = None,
    on_chunk: Optional[Callable[[AgentStreamChunk], None]] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
    seller_id: Optional[str] = None,
    client_id: Optional[str] = None,
    seller_profile_id: Optional[str] = None,
) -> AgentResult:
    """Async variant of agent_chat_stream."""
    client = AgentClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
        seller_id=seller_id,
        client_id=client_id,
        seller_profile_id=seller_profile_id,
    )

    return await client.astream_chat(
        agent_id,
        message,
        chat_history,
        conversation_id,
        version_id,
        state_override,
        on_chunk=on_chunk,
    )


def get_agent_message_status(
    conversation_id: str,
    message_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> Dict[str, Any]:
    """One-off helper to fetch status for a given message (synchronous)."""
    client = AgentClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    response, _, _ = client.fetch_message_once(conversation_id, message_id)
    return response


async def get_agent_message_status_async(
    conversation_id: str,
    message_id: str,
    *,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Async variant of get_agent_message_status."""
    client = AgentClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    response, _, _ = await client.afetch_message_once(conversation_id, message_id)
    return response

