from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional


class AgentStatus(str, Enum):
    """Known agent response status values returned by the Simplai agent API.
    
    The API returns messageStatus as an integer:
    - 0 or None = PENDING/PROCESSING
    - 1 = PROCESSING
    - 2 = COMPLETED
    - Other values = FAILED/ERROR
    """

    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    TIMEOUT = "TIMEOUT"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_raw(cls, value: Any) -> "AgentStatus":
        """Convert a raw status value from the API into an AgentStatus.
        
        Handles both integer messageStatus and string status values.
        """
        # Handle integer messageStatus (0, 1, 2, etc.)
        if isinstance(value, int):
            if value == 0:
                return cls.PROCESSING  # 0 typically means processing
            elif value == 1:
                return cls.PROCESSING
            elif value == 2:
                return cls.COMPLETED
            else:
                return cls.FAILED
        
        # Handle None/empty
        if value is None:
            return cls.PROCESSING
        
        # Handle string values
        if isinstance(value, str):
            upper = value.upper()
            for member in cls:
                if member.value == upper:
                    return member
        
        return cls.UNKNOWN


@dataclass
class AgentMessage:
    """Represents a message in agent conversation."""

    role: str  # "user" or "assistant"
    content: str
    message_id: Optional[str] = None


@dataclass
class AgentResult:
    """Final result of an agent conversation."""

    conversation_id: str
    message_id: str
    status: AgentStatus
    response: str
    payload: Dict[str, Any]  # Full response from API
    trace_id: Optional[str] = None  # Trace ID for tracing (from response)
    node_id: Optional[str] = None  # Node ID for tracing (from response)

    @property
    def succeeded(self) -> bool:
        """True if the agent conversation completed successfully."""
        return self.status == AgentStatus.COMPLETED


@dataclass
class AgentStreamChunk:
    """Represents a chunk in streaming agent response."""

    content: str
    conversation_id: Optional[str] = None
    message_id: Optional[str] = None
    is_complete: bool = False
    metadata: Optional[Dict[str, Any]] = None
    trace_id: Optional[str] = None  # Trace ID from first chunk (for request-level traces)
    node_id: Optional[str] = None  # Node ID from first chunk (for tree-based traces)
    tree_id: Optional[str] = None  # Tree ID from first chunk (for tree-based traces)


class AgentExecutionError(Exception):
    """Raised when an agent conversation fails, times out, or cannot be executed."""

