"""Low-level HTTP API layer for bulk workflow execution."""

from typing import Any, Dict, List
import httpx

from .schema import (
    BulkRunRequest,
    BulkRunResponse,
    InputFieldMapping,
    BulkRunStatusResponse,
    BulkRunCancelResponse,
)
from exceptions import APIException


from constants import WORKFLOW_BASE_URL as BASE_URL



async def trigger_bulk_run_api(
    workflow_id: str,
    file_link: str,
    batch_size: int,
    input_mapping: List[Dict[str, str]],
    api_key: str,
) -> BulkRunResponse:
    """
    Trigger a bulk workflow run via the REST API.
    
    Args:
        workflow_id: The workflow ID to execute
        file_link: URL/link to the input file
        batch_size: Number of records to process per batch
        input_mapping: List of dictionaries mapping app_input_field to file_input_field
                      Example: [{"app_input_field": "num_1", "file_input_field": "A"}]
        api_key: API key for authentication
        
    Returns:
        BulkRunResponse with execution_id and status
        
    Raises:
        APIException: If the API request fails
    """
    url = f"{BASE_URL}/bulk/run"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }
    
    # Convert input_mapping to InputFieldMapping objects
    input_fields_mapping = [
        InputFieldMapping(
            app_input_field=mapping["app_input_field"],
            file_input_field=mapping["file_input_field"]
        )
        for mapping in input_mapping
    ]
    
    request_body = BulkRunRequest(
        file_url=file_link,
        tool_id=workflow_id,
        batch_size=batch_size,
        input_fields_mapping=input_fields_mapping,
    )
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                url,
                headers=headers,
                json=request_body.model_dump(),
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            
            return BulkRunResponse(
                execution_id=data.get("execution_id", ""),
                status=data.get("status", ""),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")


async def get_bulk_run_status_api(
    bulk_run_id: str,
    api_key: str,
) -> BulkRunStatusResponse:
    """
    Get the bulk run status by bulk run ID.
    """
    # NOTE: Endpoint path uses singular 'run' (not 'runs'), e.g.:
    # /bulk/run/{execution_id}/status
    url = f"{BASE_URL}/bulk/run/{bulk_run_id}/status"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                url,
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()

            data = response.json()

            return BulkRunStatusResponse(
                execution_id=data.get("execution_id", ""),
                status=data.get("status", ""),
                batch_completed=data.get("batch_completed", 0),
                total_batches=data.get("total_batches", 0),
                trace_id=data.get("trace_id"),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")


async def cancel_bulk_run_api(
    bulk_run_id: str,
    api_key: str,
) -> BulkRunCancelResponse:
    """
    Cancel a bulk run via the REST API.
    """
    url = f"{BASE_URL}/bulk/execution/{bulk_run_id}/cancel"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }

    async with httpx.AsyncClient() as client:
        try:
            response = await client.put(
                url,
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()

            return BulkRunCancelResponse(
                execution_id=data.get("execution_id", ""),
                status=data.get("status", ""),
                trace_id=data.get("trace_id"),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")


async def download_bulk_run_result_api(
    bulk_run_id: str,
    api_key: str,
) -> str:
    """
    Download the bulk run result as raw CSV text.
    """
    url = f"{BASE_URL}/bulk/run/{bulk_run_id}/download"
    headers = {
        "Accept": "text/csv",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                url,
                headers=headers,
                timeout=60.0,
            )
            response.raise_for_status()
            # The API returns raw CSV (text/csv)
            return response.text
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")