"""Public SDK interface for bulk workflow execution."""

from typing import Dict, List

from .api import trigger_bulk_run_api
from .api import get_bulk_run_status_api
from .api import cancel_bulk_run_api
from .api import download_bulk_run_result_api


async def trigger_bulk_run(
    workflow_id: str,
    file_link: str,
    batch_size: int,
    input_mapping: List[Dict[str, str]],
    api_key: str,
) -> Dict[str, str]:
    """
    Trigger a bulk run of workflows.
    
    Args:
        workflow_id: The workflow ID to execute
        file_link: URL/link to the input file containing the data
        batch_size: Number of records to process per batch
        input_mapping: List of dictionaries mapping workflow input fields to file columns.
                      Each dictionary should have:
                      - "app_input_field": The workflow input field name
                      - "file_input_field": The file column/field name
                      Example: [
                          {"app_input_field": "num_1", "file_input_field": "A"},
                          {"app_input_field": "num_2", "file_input_field": "B"}
                      ]
        api_key: API key for authentication
        
    Returns:
        Dictionary with bulk_run_id and status:
        {
            "bulk_run_id": str,
            "status": str
        }
    """
    response = await trigger_bulk_run_api(
        workflow_id=workflow_id,
        file_link=file_link,
        batch_size=batch_size,
        input_mapping=input_mapping,
        api_key=api_key,
    )
    
    return {
        "bulk_run_id": response.execution_id,
        "status": response.status,
    }


async def get_bulk_run_status(
    bulk_run_id: str,
    api_key: str,
) -> Dict[str, str]:
    """
    Get the bulk run result by bulk run ID.
    
    Args:
        bulk_run_id: The bulk run ID to check
        api_key: API key for authentication
    """
    response = await get_bulk_run_status_api(
        bulk_run_id=bulk_run_id,
        api_key=api_key,
    )
    
    return {
        "bulk_run_id": response.execution_id,
        "status": response.status,
        "batch_completed": response.batch_completed,
        "total_batches": response.total_batches,
        "trace_id": response.trace_id,
    }


async def cancel_bulk_run(
    bulk_run_id: str,
    api_key: str,
) -> Dict[str, str]:
    """
    Cancel a bulk run by bulk run ID.
    """
    response = await cancel_bulk_run_api(
        bulk_run_id=bulk_run_id,
        api_key=api_key,
    )

    result: Dict[str, str] = {
        "bulk_run_id": response.execution_id,
        "status": response.status,
    }

    if response.trace_id:
        result["trace_id"] = response.trace_id

    return result


async def download_bulk_run_result(
    bulk_run_id: str,
    api_key: str,
) -> str:
    """
    Download the bulk run result as CSV text for the given bulk_run_id.
    """
    return await download_bulk_run_result_api(
        bulk_run_id=bulk_run_id,
        api_key=api_key,
    )

