"""Pydantic schemas for bulk workflow execution API requests and responses."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class InputFieldMapping(BaseModel):
    """Schema for input field mapping."""
    app_input_field: str = Field(..., description="The workflow input field name")
    file_input_field: str = Field(..., description="The file column/field name")


class BulkRunRequest(BaseModel):
    """Request schema for triggering a bulk workflow run."""
    file_url: str = Field(..., description="URL/link to the input file")
    tool_id: str = Field(..., description="The workflow ID")
    batch_size: int = Field(..., description="Number of records to process per batch")
    input_fields_mapping: List[InputFieldMapping] = Field(
        ..., 
        description="Mapping between workflow input fields and file columns"
    )


class BulkRunResponse(BaseModel):
    """Response schema from bulk run API."""
    execution_id: str = Field(..., alias="execution_id", description="The bulk run execution ID")
    status: str = Field(..., description="Execution status (e.g., ACCEPTED)")

    class Config:
        populate_by_name = True

class BulkRunStatusRequest(BaseModel):
    """Request schema for getting the bulk run status."""
    execution_id: str = Field(..., description="The bulk run ID")

    class Config:
        populate_by_name = True

class BulkRunStatusResponse(BaseModel):
    """Response schema from bulk run client."""
    execution_id: str = Field(..., alias="execution_id", description="The bulk run execution ID")
    status: str = Field(..., description="Execution status (e.g., ACCEPTED, COMPLETED, FAILED, CANCELLED)")
    batch_completed: int = Field(..., description="Number of completed batches")
    total_batches: int = Field(..., description="Total number of batches")
    trace_id: Optional[str] = Field(None, description="Trace identifier for the bulk run")

    class Config:
        populate_by_name = True


class BulkRunCancelResponse(BaseModel):
    """Response schema from bulk run cancel API."""
    execution_id: str = Field(..., alias="execution_id", description="The bulk run execution ID")
    status: str = Field(..., description="Execution status after cancel (e.g., CANCELLED)")
    trace_id: Optional[str] = Field(None, description="Trace identifier for the bulk run")

    class Config:
        populate_by_name = True
