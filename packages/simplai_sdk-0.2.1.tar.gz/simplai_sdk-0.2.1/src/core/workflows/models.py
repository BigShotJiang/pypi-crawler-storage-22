from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict


class ExecutionStatus(str, Enum):
    """Known execution status values returned by the Simplai workflow API."""

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    CANCELED = "CANCELED"
    TIMEOUT = "TIMEOUT"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_raw(cls, value: Any) -> "ExecutionStatus":
        """Convert a raw status value from the API into an ExecutionStatus."""
        if not isinstance(value, str):
            return cls.UNKNOWN
        upper = value.upper()
        for member in cls:
            if member.value == upper:
                return member
        return cls.UNKNOWN


@dataclass
class WorkflowResult:
    """Final result of a workflow execution in synchronous mode."""

    execution_id: str
    status: ExecutionStatus
    payload: Dict[str, Any]

    @property
    def succeeded(self) -> bool:
        """True if the workflow completed successfully."""
        return self.status == ExecutionStatus.SUCCEEDED


class WorkflowExecutionError(Exception):
    """Raised when a workflow fails, times out, or cannot be executed."""



