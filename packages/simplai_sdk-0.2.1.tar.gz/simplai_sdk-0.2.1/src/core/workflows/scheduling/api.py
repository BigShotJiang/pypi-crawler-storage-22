"""Low-level HTTP API layer for scheduled workflow execution."""

from math import log
from typing import Any, Dict, List, Optional, Union
import httpx

from exceptions import APIException

from .schema import (
    ScheduleRunRequest,
    ScheduleRunResponse,
    ScheduleRunResult,
    ScheduleCancelRequest,
    ScheduleCancelResponse,
    BulkInputFieldMapping,
    ManualInputFieldMapping,
)


from constants import WORKFLOW_BASE_URL as BASE_URL


async def schedule_run_api(
    workflow_id: str,
    scheduled_run_type: str,
    cron_expression: str,
    time_zone: str,
    input_mapping: List[Dict[str, str]],
    api_key: str,
    file_url: Optional[str] = None,
    batch_size: Optional[int] = None,
) -> ScheduleRunResponse:
    """
    Schedule a workflow run via the REST API (supports both BULK and MANUAL types).
    
    Args:
        workflow_id: The workflow ID to execute
        scheduled_run_type: Type of scheduled run - 'BULK' or 'MANUAL'
        cron_expression: Cron expression for scheduling (e.g., "47 22 11 2 1 ?")
        time_zone: Time zone for the schedule (e.g., "Asia/Kolkata")
        input_mapping: List of dictionaries with input field mappings.
                      For BULK: [{"app_input_field": "x", "file_input_field": "A"}]
                      For MANUAL: [{"app_input_field": "x", "value": "y"}]
        api_key: API key for authentication
        file_url: URL/link to the input file (required for BULK, ignored for MANUAL)
        batch_size: Number of records to process per batch (required for BULK, optional for MANUAL)
        
    Returns:
        ScheduleRunResponse with execution_id and status
        
    Raises:
        APIException: If the API request fails
        ValueError: If required fields are missing for the scheduled_run_type
    """
    # Validate required fields based on scheduled_run_type
    scheduled_run_type_upper = scheduled_run_type.upper()
    if scheduled_run_type_upper not in ["BULK", "MANUAL"]:
        raise ValueError(f"scheduled_run_type must be 'BULK' or 'MANUAL', got '{scheduled_run_type}'")
    
    if scheduled_run_type_upper == "BULK":
        if not file_url:
            raise ValueError("file_url is required when scheduled_run_type is 'BULK'")

    
    # Build the request body
    request_data: Dict[str, Any] = {
        "tool_id": workflow_id,
        "scheduled_run_type": scheduled_run_type_upper,
        "cron_expression": cron_expression,
        "time_zone": time_zone,
        "input_fields_mapping": input_mapping,
        "batch_size": batch_size,
    }
    
    # Add BULK-specific / shared fields if applicable
    if scheduled_run_type_upper == "BULK":
        request_data["file_url"] = file_url

    # batch_size can be used for both BULK and MANUAL if provided

    print(f"request_data : {request_data}")
    
    url = f"{BASE_URL}/schedule/run"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                url,
                headers=headers,
                json=request_data,
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            
            # Parse nested result object if present
            result_obj = None
            if "result" in data and data["result"]:
                result_data = data["result"]
                result_obj = ScheduleRunResult(
                    unique_id=result_data.get("unique_id", ""),
                    job_master_id=result_data.get("job_master_id", ""),
                )
            
            return ScheduleRunResponse(
                app_id=data.get("app_id", ""),
                status=data.get("status", ""),
                execution_mode=data.get("execution_mode"),
                result=result_obj,
                trace_id=data.get("trace_id"),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")


async def cancel_schedule_run_api(
    job_master_id: Union[int, str],
    unique_id: str,
    api_key: str,
) -> ScheduleCancelResponse:
    """
    Cancel a scheduled run via the REST API.
    
    Args:
        job_master_id: Job master identifier (can be int or str)
        unique_id: Unique identifier for the scheduled run
        api_key: API key for authentication
        
    Returns:
        ScheduleCancelResponse with status and trace_id
        
    Raises:
        APIException: If the API request fails
    """
    url = f"{BASE_URL}/schedule/cancel"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }
    
    request_data = {
        "job_master_id": job_master_id,
        "unique_id": unique_id,
    }
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.put(
                url,
                headers=headers,
                json=request_data,
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            
            return ScheduleCancelResponse(
                status=data.get("status", ""),
                trace_id=data.get("trace_id"),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")

