"""Public SDK interface for scheduled workflow execution."""

from typing import Dict, List, Optional, Union

from .api import schedule_run_api, cancel_schedule_run_api


async def schedule_run(
    workflow_id: str,
    scheduled_run_type: str,
    cron_expression: str,
    time_zone: str,
    input_mapping: List[Dict[str, str]],
    api_key: str,
    file_url: Optional[str] = None,
    batch_size: Optional[int] = None,
) -> Dict[str, str]:
    """
    Schedule a workflow run (supports both BULK and MANUAL types).
    
    Args:
        workflow_id: The workflow ID to execute
        scheduled_run_type: Type of scheduled run - 'BULK' or 'MANUAL'
        cron_expression: Cron expression for scheduling (e.g., "47 22 11 2 1 ?")
        time_zone: Time zone for the schedule (e.g., "Asia/Kolkata")
        input_mapping: List of dictionaries with input field mappings.
                      For BULK: [{"app_input_field": "number_1", "file_input_field": "A"}]
                      For MANUAL: [{"app_input_field": "interview_id", "value": "0148eee6-a867-4c7a-8d42-f039a5ef6adf"}]
        api_key: API key for authentication
        file_url: URL/link to the input file (required for BULK, ignored for MANUAL)
        batch_size: Number of records to process per batch (required for BULK, optional for MANUAL)
        
    Returns:
        Dictionary with unique_id, job_master_id, trace_id, and status:
        {
            "unique_id": str,
            "job_master_id": str,
            "trace_id": str,
            "status": str
        }
        
    Example - BULK scheduled run:
        await schedule_run(
            workflow_id="695cafaffa8b738fc69146aa",
            scheduled_run_type="BULK",
            cron_expression="47 22 11 2 1 ?",
            time_zone="Asia/Kolkata",
            input_mapping=[
                {"app_input_field": "number_1", "file_input_field": "A"},
                {"app_input_field": "number_2", "file_input_field": "B"}
            ],
            api_key="your_api_key",
            file_url="s3://media-simplai/2025-10-03T16:04:23.490089839-bulk_test.csv",
            batch_size=1,
        )
        
    Example - MANUAL scheduled run:
        await schedule_run(
            workflow_id="6915a7785ac679cd4de1d4d5",
            scheduled_run_type="MANUAL",
            cron_expression="47 22 11 2 1 *",
            time_zone="Asia/Kolkata",
            input_mapping=[
                {"app_input_field": "interview_id", "value": "0148eee6-a867-4c7a-8d42-f039a5ef6adf"}
            ],
            api_key="your_api_key",
        )
    """
    response = await schedule_run_api(
        workflow_id=workflow_id,
        scheduled_run_type=scheduled_run_type,
        cron_expression=cron_expression,
        time_zone=time_zone,
        input_mapping=input_mapping,
        api_key=api_key,
        file_url=file_url,
        batch_size=batch_size,
    )
    
    result: Dict[str, str] = {
        "status": response.status,
    }
    
    if response.result:
        result["unique_id"] = response.result.unique_id
        result["job_master_id"] = response.result.job_master_id
    
    if response.trace_id:
        result["trace_id"] = response.trace_id
    
    return result


async def cancel_schedule_run(
    job_master_id: Union[int, str],
    unique_id: str,
    api_key: str,
) -> Dict[str, str]:
    """
    Cancel a scheduled run by job_master_id and unique_id.
    
    Args:
        job_master_id: Job master identifier (can be int or str)
        unique_id: Unique identifier for the scheduled run
        api_key: API key for authentication
        
    Returns:
        Dictionary with status and trace_id:
        {
            "status": str,
            "trace_id": str
        }
    """
    response = await cancel_schedule_run_api(
        job_master_id=job_master_id,
        unique_id=unique_id,
        api_key=api_key,
    )
    
    result: Dict[str, str] = {
        "status": response.status,
    }
    
    if response.trace_id:
        result["trace_id"] = response.trace_id
    
    return result

