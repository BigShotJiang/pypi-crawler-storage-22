"""Pydantic schemas for scheduled workflow execution API requests and responses."""

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field


class BulkInputFieldMapping(BaseModel):
    """Schema for bulk input field mapping (file-based)."""
    app_input_field: str = Field(..., description="The workflow input field name")
    file_input_field: str = Field(..., description="The file column/field name")


class ManualInputFieldMapping(BaseModel):
    """Schema for manual input field mapping (value-based)."""
    app_input_field: str = Field(..., description="The workflow input field name")
    value: str = Field(..., description="The static value for the input field")


class ScheduleRunRequest(BaseModel):
    """Request schema for scheduling a workflow run (supports both BULK and MANUAL)."""
    tool_id: str = Field(..., description="The workflow ID")
    scheduled_run_type: str = Field(..., description="Type of scheduled run: 'BULK' or 'MANUAL'")
    cron_expression: str = Field(..., description="Cron expression for scheduling")
    time_zone: str = Field(..., description="Time zone for the schedule (e.g., 'Asia/Kolkata')")
    
    # BULK-specific fields (optional, required when scheduled_run_type is 'BULK')
    file_url: Optional[str] = Field(None, description="URL/link to the input file (required for BULK)")
    batch_size: Optional[int] = Field(None, description="Number of records to process per batch (required for BULK)")
    
    # Input field mappings - can be either bulk or manual format
    input_fields_mapping: List[Dict[str, str]] = Field(
        ..., 
        description="List of input field mappings. For BULK: [{'app_input_field': 'x', 'file_input_field': 'A'}]. For MANUAL: [{'app_input_field': 'x', 'value': 'y'}]"
    )

    class Config:
        populate_by_name = True


class ScheduleRunResult(BaseModel):
    """Nested result object in schedule run response."""
    unique_id: str = Field(..., description="Unique identifier for the scheduled run")
    job_master_id: str = Field(..., description="Job master identifier")


class ScheduleRunResponse(BaseModel):
    """Response schema from schedule run API."""
    app_id: str = Field(..., alias="app_id", description="The workflow/app ID")
    status: str = Field(..., description="Execution status (e.g., ACCEPTED)")
    execution_mode: Optional[str] = Field(None, description="Execution mode (e.g., ASYNC)")
    result: Optional[ScheduleRunResult] = Field(None, description="Result object with unique_id and job_master_id")
    trace_id: Optional[str] = Field(None, description="Trace identifier for the scheduled run")

    class Config:
        populate_by_name = True


class ScheduleCancelRequest(BaseModel):
    """Request schema for canceling a scheduled run."""
    job_master_id: Union[int, str] = Field(..., description="Job master identifier")
    unique_id: str = Field(..., description="Unique identifier for the scheduled run")

    class Config:
        populate_by_name = True


class ScheduleCancelResponse(BaseModel):
    """Response schema from schedule cancel API."""
    status: str = Field(..., description="Cancellation status (e.g., CANCELLED)")
    trace_id: Optional[str] = Field(None, description="Trace identifier for the cancelled run")

    class Config:
        populate_by_name = True

