"""Low-level HTTP API layer for workflow execution."""

import json
from typing import Any, Dict, Optional
import httpx

from .schema import (
    ExecuteWorkflowRequest,
    ExecuteWorkflowResponse,
    ExecutionStatusResponse,
    CancelExecutionResponse,
)
from exceptions import APIException


from constants import WORKFLOW_BASE_URL as BASE_URL

async def execute_workflow_api(
    workflow_id: str,
    inputs: Dict[str, Any],
    api_key: str,
) -> ExecuteWorkflowResponse:
    """
    Execute a workflow via the REST API.
    
    Args:
        workflow_id: The workflow ID to execute
        inputs: Input parameters for the workflow
        api_key: API key for authentication
        
    Returns:
        ExecuteWorkflowResponse with execution_id and status
        
    Raises:
        APIException: If the API request fails
    """
    url = f"{BASE_URL}/execute"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }
    
    request_body = ExecuteWorkflowRequest(
        app_id=workflow_id,
        inputs=inputs,
    )


    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                url,
                headers=headers,
                json=request_body.model_dump(),
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            
            return ExecuteWorkflowResponse(
                execution_id=data.get("execution_id", ""),
                status=data.get("status", ""),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")


async def get_execution_status_api(
    execution_id: str,
    api_key: str,
) -> ExecutionStatusResponse:
    """
    Get the execution status and result via the REST API.
    
    Args:
        execution_id: The execution ID to check
        api_key: API key for authentication
        
    Returns:
        ExecutionStatusResponse with executionId, traceId, status, and parsed result
        
    Raises:
        APIException: If the API request fails
    """
    url = f"{BASE_URL}/executions/{execution_id}/status"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                url,
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            
            # Extract and parse result from raw_response.api_response.result
            raw_response = data.get("raw_response", {})
            api_response = raw_response.get("api_response") if raw_response else None
            
            return ExecutionStatusResponse(
                executionId=data.get("executionId", ""),
                traceId=data.get("traceId"),
                status=data.get("status", ""),
                api_response=api_response,
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")


async def cancel_execution_api(
    execution_id: str,
    api_key: str,
) -> CancelExecutionResponse:
    """
    Cancel an execution via the REST API.
    
    Args:
        execution_id: The execution ID to cancel
        api_key: API key for authentication
        
    Returns:
        CancelExecutionResponse with execution_id and status
        
    Raises:
        APIException: If the API request fails
    """
    url = f"{BASE_URL}/executions/{execution_id}/cancel"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "PIM-SID": api_key,
    }
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                url,
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
            
            return CancelExecutionResponse(
                execution_id=data.get("execution_id", ""),
                status=data.get("status", ""),
            )
        except httpx.HTTPStatusError as e:
            raise APIException(
                f"API request failed with status {e.response.status_code}: {e.response.text}",
                status_code=e.response.status_code,
            )
        except httpx.RequestError as e:
            raise APIException(f"Request failed: {str(e)}")

