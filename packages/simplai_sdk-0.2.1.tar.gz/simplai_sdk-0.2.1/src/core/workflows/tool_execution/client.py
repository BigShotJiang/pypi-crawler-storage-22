"""Public SDK interface for workflow execution."""

import asyncio
import time
from typing import Any, Dict, Optional

from constants import TERMINAL_STATES

from .api import execute_workflow_api, get_execution_status_api, cancel_execution_api
from exceptions import TimeoutException



async def execute_workflow(
    workflow_id: str,
    inputs: Dict[str, Any],
    api_key: str,
) -> Dict[str, str]:
    """
    Execute a workflow and return the execution ID.
    
    Args:
        workflow_id: The workflow ID to execute
        inputs: Input parameters for the workflow
        api_key: API key for authentication
        
    Returns:
        Dictionary with execution_id and status:
        {
            "execution_id": str,
            "status": str
        }
    """
    response = await execute_workflow_api(
        workflow_id=workflow_id,
        inputs=inputs,
        api_key=api_key,
    )
    
    return {
        "execution_id": response.execution_id,
        "status": response.status,
    }


async def get_tool_result(
    execution_id: str,
    api_key: str,
) -> Dict[str, Any]:
    """
    Get the execution result by execution ID.
    
    Args:
        execution_id: The execution ID to check
        api_key: API key for authentication
        
    Returns:
        Dictionary with executionId, traceId, status, and result:
        {
            "executionId": str,
            "traceId": str (optional),
            "status": str,
            "result": Any (parsed JSON if possible)
        }
    """
    response = await get_execution_status_api(
        execution_id=execution_id,
        api_key=api_key,
    )
    
    result = {
        "executionId": response.executionId,
        "status": response.status,
    }
    
    if response.traceId:
        result["traceId"] = response.traceId
    
    if response.api_response is not None:
        result["api_response"] = response.api_response
    
    return result


async def execute_and_wait_workflow(
    workflow_id: str,
    inputs: Dict[str, Any],
    api_key: str,
    timeout: float = 60.0,
    poll_interval: float = 2.0,
) -> Dict[str, Any]:
    """
    Execute a workflow and wait for completion with polling.
    
    Args:
        workflow_id: The workflow ID to execute
        inputs: Input parameters for the workflow
        api_key: API key for authentication
        timeout: Maximum time to wait in seconds (default: 60.0)
        poll_interval: Time between polls in seconds (default: 2.0)
        
    Returns:
        Dictionary with executionId, traceId, status, and result:
        {
            "executionId": str,
            "traceId": str (optional),
            "status": str,
            "result": Any (parsed JSON if possible)
        }
        
    Raises:
        TimeoutException: If the execution doesn't complete within the timeout
    """
    # Step 1: Execute the workflow
    execution_info = await execute_workflow(
        workflow_id=workflow_id,
        inputs=inputs,
        api_key=api_key,
    )
    
    execution_id = execution_info["execution_id"]
    start_time = time.time()
    
    # Step 2: Poll for completion
    while True:
        elapsed_time = time.time() - start_time
        
        # Check timeout
        if elapsed_time >= timeout:
            raise TimeoutException(
                f"Workflow execution timed out after {timeout} seconds. "
                f"Execution ID: {execution_id}"
            )
        
        # Get execution status
        result = await get_tool_result(
            execution_id=execution_id,
            api_key=api_key,
        )
        
        status = result.get("status", "").upper()
        
        # Check if we've reached a terminal state
        if status in TERMINAL_STATES:
            return result
        
        # If still pending, wait before next poll
        if status == "PENDING":
            # Calculate remaining time and sleep for poll_interval or remaining time, whichever is smaller
            remaining_time = timeout - elapsed_time
            sleep_time = min(poll_interval, remaining_time)
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)
            else:
                # No time left, will timeout on next iteration
                continue
        
        # For any other non-terminal state, continue polling
        remaining_time = timeout - elapsed_time
        sleep_time = min(poll_interval, remaining_time)
        if sleep_time > 0:
            await asyncio.sleep(sleep_time)
        else:
            # No time left, will timeout on next iteration
            continue


async def cancel_execution(
    execution_id: str,
    api_key: str,
) -> Dict[str, str]:
    """
    Cancel an execution by execution ID.
    
    Args:
        execution_id: The execution ID to cancel
        api_key: API key for authentication
        
    Returns:
        Dictionary with execution_id and status:
        {
            "execution_id": str,
            "status": str
        }
    """
    response = await cancel_execution_api(
        execution_id=execution_id,
        api_key=api_key,
    )
    
    return {
        "execution_id": response.execution_id,
        "status": response.status,
    }

