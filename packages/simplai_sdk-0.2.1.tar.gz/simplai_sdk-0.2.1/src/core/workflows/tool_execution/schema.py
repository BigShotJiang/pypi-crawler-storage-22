"""Pydantic schemas for workflow execution API requests and responses."""

from typing import Any, Dict, Optional
from pydantic import BaseModel, Field


class ExecuteWorkflowRequest(BaseModel):
    """Request schema for executing a workflow."""
    app_id: str = Field(..., description="The workflow ID")
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Input parameters for the workflow")


class ExecuteWorkflowResponse(BaseModel):
    """Response schema from execute workflow API."""
    execution_id: str = Field(..., alias="execution_id")
    status: str = Field(..., description="Execution status (e.g., PENDING)")

    class Config:
        populate_by_name = True


class ExecutionStatusResponse(BaseModel):
    """Response schema from get execution status API."""
    executionId: str = Field(..., description="The execution ID")
    traceId: Optional[str] = Field(None, description="The trace ID")
    status: str = Field(..., description="Execution status (e.g., COMPLETED, FAILED, CANCELLED, PENDING)")
    api_response: Optional[Dict[str, Any]] = Field(None, description="Raw response from the API")

    class Config:
        populate_by_name = True


class CancelExecutionResponse(BaseModel):
    """Response schema from cancel execution API."""
    execution_id: str = Field(..., alias="execution_id", description="The execution ID")
    status: str = Field(..., description="Execution status (e.g., COMPLETE)")

    class Config:
        populate_by_name = True

