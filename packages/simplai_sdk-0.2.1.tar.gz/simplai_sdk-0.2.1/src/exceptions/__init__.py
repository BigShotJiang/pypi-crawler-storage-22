"""Custom exceptions for the SimplAI Python SDK."""

from typing import Optional


class SimplAIException(Exception):
    """Base exception for all SimplAI SDK exceptions."""
    pass


class TimeoutException(SimplAIException):
    """Raised when a workflow execution times out."""
    pass


class APIException(SimplAIException):
    """Raised when an API request fails."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code

