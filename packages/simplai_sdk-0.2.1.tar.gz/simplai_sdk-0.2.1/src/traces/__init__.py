"""Traces module for SimplAI SDK."""
