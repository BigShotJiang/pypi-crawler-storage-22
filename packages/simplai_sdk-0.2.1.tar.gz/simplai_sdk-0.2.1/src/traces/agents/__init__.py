"""Simplai Tracing APIs for agents.

This module provides APIs for fetching and analyzing traces from agent conversations.
"""

from .api import (
    fetch_traces,
    get_trace_details,
    fetch_trace_nodes,
    get_aggregate_output,
    get_trace_tree,
    get_trace_node_details,
    download_traces,
    get_agent_metrics,
    get_tool_metrics,
)
from .client import TraceClient
from .models import (
    EvalMetrics,
    FetchTraceFilters,
    MetricsRequestDto,
    PageableResponse,
    RagTrace,
    TraceData,
    TraceError,
    TraceFilters,
    TraceNode,
    ChildInfo,
)

__all__ = [
    # API functions
    "fetch_traces",
    "get_trace_details",
    "fetch_trace_nodes",
    "get_aggregate_output",
    "get_trace_tree",
    "get_trace_node_details",
    "download_traces",
    "get_agent_metrics",
    "get_tool_metrics",
    # Client
    "TraceClient",
    # Models
    "EvalMetrics",
    "FetchTraceFilters",
    "MetricsRequestDto",
    "PageableResponse",
    "RagTrace",
    "TraceData",
    "TraceError",
    "TraceFilters",
    "TraceNode",
    "ChildInfo",
]
