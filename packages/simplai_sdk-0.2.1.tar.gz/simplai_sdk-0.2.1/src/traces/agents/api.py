from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from utils.config import get_api_key, get_base_url

from .client import TraceClient
from constants import DEFAULT_BASE_URL
from .models import (
    FetchTraceFilters,
    MetricsRequestDto,
    PageableResponse,
    RagTrace,
    TraceError,
    TraceFilters,
    TraceNode,
)


def fetch_traces(
    *,
    api_key: Optional[str] = None,
    filters: Optional[FetchTraceFilters] = None,
    page: int = 0,
    size: int = 20,
    sort: str = "id",
    direction: str = "DESC",
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> PageableResponse:
    """Fetch paginated request-level traces (RAG traces).

    Args:
        api_key: PIM-SID API key.
        filters: Optional filters for querying traces.
        page: Page number (0-indexed).
        size: Page size.
        sort: Sort field.
        direction: Sort direction (ASC or DESC).
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        PageableResponse containing paginated RagTrace objects.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.fetch_traces(filters=filters, page=page, size=size, sort=sort, direction=direction)


def get_trace_details(
    *,
    api_key: Optional[str] = None,
    trace_id: Optional[str] = None,
    request_id: Optional[str] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> RagTrace:
    """Get details of a specific request-level trace.

    Args:
        api_key: PIM-SID API key.
        trace_id: Trace ID (optional, but either trace_id or request_id required).
        request_id: Request ID (optional, but either trace_id or request_id required).
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        RagTrace object with full details.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.get_trace_details(trace_id=trace_id, request_id=request_id)


def fetch_trace_nodes(
    *,
    api_key: Optional[str] = None,
    filters: Optional[TraceFilters] = None,
    page: int = 0,
    size: int = 20,
    sort: str = "id",
    direction: str = "DESC",
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> PageableResponse:
    """Fetch paginated tree-based trace nodes (root traces).

    Args:
        api_key: PIM-SID API key.
        filters: Optional filters for querying traces.
        page: Page number (0-indexed).
        size: Page size.
        sort: Sort field.
        direction: Sort direction (ASC or DESC).
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        PageableResponse containing paginated TraceNode objects.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.fetch_trace_nodes(filters=filters, page=page, size=size, sort=sort, direction=direction)


def get_aggregate_output(
    *,
    api_key: Optional[str] = None,
    filters: Optional[TraceFilters] = None,
    page: int = 0,
    size: int = 20,
    sort: str = "id",
    direction: str = "DESC",
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Get aggregate output traces (summary view).

    Args:
        api_key: PIM-SID API key.
        filters: Optional filters for querying traces.
        page: Page number (0-indexed).
        size: Page size.
        sort: Sort field.
        direction: Sort direction (ASC or DESC).
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        Dictionary containing aggregate trace data.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.get_aggregate_output(filters=filters, page=page, size=size, sort=sort, direction=direction)


def get_trace_tree(
    *,
    api_key: Optional[str] = None,
    tree_id: str,
    node_id: str,
    max_depth: Optional[int] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
    seller_id: Optional[str] = None,
    client_id: Optional[str] = None,
    seller_profile_id: Optional[str] = None,
    raw_response: bool = False,
) -> Union[TraceNode, Dict[str, Any]]:
    """Get a trace sub-tree starting from a specific node.

    Args:
        api_key: PIM-SID API key.
        tree_id: Tree ID of the trace.
        node_id: Node ID to start the tree from.
        max_depth: Maximum depth to traverse (optional).
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.
        seller_id: Optional seller ID.
        client_id: Optional client ID.
        seller_profile_id: Optional seller profile ID.
        raw_response: If True, return raw JSON response instead of parsed TraceNode.

    Returns:
        TraceNode representing the root of the sub-tree, or raw JSON dict if raw_response=True.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
        seller_id=seller_id,
        client_id=client_id,
        seller_profile_id=seller_profile_id,
    )
    return client.get_trace_tree(tree_id=tree_id, node_id=node_id, max_depth=max_depth, raw_response=raw_response)


def get_trace_node_details(
    *,
    api_key: Optional[str] = None,
    tree_id: str,
    node_id: str,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> TraceNode:
    """Get details of a specific trace node.

    Args:
        api_key: PIM-SID API key.
        tree_id: Tree ID of the trace.
        node_id: Node ID to get details for.
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        TraceNode object with full details.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.get_trace_node_details(tree_id=tree_id, node_id=node_id)


def download_traces(
    *,
    api_key: Optional[str] = None,
    filters: Optional[TraceFilters] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> bytes:
    """Download traces as CSV.

    Args:
        api_key: PIM-SID API key.
        filters: Optional filters for querying traces.
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        Bytes containing CSV file content.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.download_traces(filters=filters)


def get_agent_metrics(
    *,
    api_key: Optional[str] = None,
    metrics_request: Optional[MetricsRequestDto] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Get agent-level metrics from traces.

    Args:
        api_key: PIM-SID API key.
        metrics_request: Optional metrics request with filters.
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        Dictionary containing aggregated agent metrics.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.get_agent_metrics(metrics_request=metrics_request)


def get_tool_metrics(
    *,
    api_key: Optional[str] = None,
    metrics_request: Optional[MetricsRequestDto] = None,
    base_url: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: str = "1",
    project_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Get tool-level metrics from traces.

    Args:
        api_key: PIM-SID API key.
        metrics_request: Optional metrics request with filters.
        base_url: Override the default base URL if needed.
        user_id: Optional user ID for trace operations.
        tenant_id: Tenant ID (defaults to "1").
        project_id: Optional project ID.

    Returns:
        Dictionary containing aggregated tool metrics.
    """
    client = TraceClient(
        api_key=get_api_key(api_key),
        base_url=get_base_url(base_url),
        user_id=user_id,
        tenant_id=tenant_id,
        project_id=project_id,
    )
    return client.get_tool_metrics(metrics_request=metrics_request)

