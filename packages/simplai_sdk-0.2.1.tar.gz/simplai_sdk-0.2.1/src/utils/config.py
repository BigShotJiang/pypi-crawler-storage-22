"""Configuration utilities for loading API keys and base URLs.

This module provides utilities to load configuration values with the following priority:
1. User-provided parameter
2. Environment variable
3. .env file (if python-dotenv is available)
4. Default value (for base_url) or error (for api_key)
"""

import os
from pathlib import Path
from typing import Optional


def _load_env_file() -> None:
    """Attempt to load .env file from common locations."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        # python-dotenv not installed, skip loading .env
        return

    # Try to find .env file in common locations
    current_dir = Path.cwd()
    possible_env_paths = [
        current_dir / ".env",
        current_dir.parent / ".env",  # python-sdk/.env
        Path(__file__).parent.parent.parent / ".env",  # python-sdk/.env from src/utils
    ]

    for env_path in possible_env_paths:
        if env_path.exists():
            load_dotenv(dotenv_path=env_path, override=False)
            break
    else:
        # Fallback: try loading from current directory
        load_dotenv(override=False)


def get_api_key(api_key: Optional[str] = None) -> str:
    """
    Get API key with fallback priority:
    1. User-provided api_key parameter
    2. API_KEY from environment variable
    3. API_KEY from .env file
    4. Raise error if not found

    Args:
        api_key: Optional API key provided by user

    Returns:
        API key string

    Raises:
        ValueError: If API key is not found in any source
    """
    # First priority: user-provided API key
    if api_key:
        return api_key

    # Second priority: check environment variable (may already be set)
    env_api_key = os.getenv("SIMPAI_API_KEY")
    if env_api_key:
        return env_api_key

    # Third priority: try to load from .env file
    _load_env_file()

    # Check environment variable again after loading .env
    env_api_key = os.getenv("SIMPAI_API_KEY")
    if env_api_key:
        return env_api_key

    # Fourth priority: raise error
    raise ValueError(
        "API key is required. Provide it using one of the following methods:\n"
        "  1. As a parameter: SimplAI(api_key='your-key')\n"
        "  2. As environment variable: export API_KEY=your-key\n"
        "  3. In a .env file: API_KEY=your-key"
    )


def get_base_url(base_url: Optional[str] = None) -> str:
    """
    Get base URL with fallback priority:
    1. User-provided base_url parameter
    2. BASE_URL from environment variable
    3. BASE_URL from .env file
    4. Default base URL constant

    Args:
        base_url: Optional base URL provided by user

    Returns:
        Base URL string
    """
    # First priority: user-provided base URL
    if base_url:
        return base_url.rstrip("/")

    # Second priority: check environment variable (may already be set)
    env_base_url = os.getenv("SIMPAI_BASE_URL")
    if env_base_url:
        return env_base_url.rstrip("/")

    # Third priority: try to load from .env file
    _load_env_file()

    # Check environment variable again after loading .env
    env_base_url = os.getenv("SIMPAI_BASE_URL")
    if env_base_url:
        return env_base_url.rstrip("/")

    # Fourth priority: default base URL
    from constants import DEFAULT_BASE_URL

    return DEFAULT_BASE_URL
