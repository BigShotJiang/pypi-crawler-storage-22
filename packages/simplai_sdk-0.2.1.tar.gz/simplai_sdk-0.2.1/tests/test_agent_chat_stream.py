#!/usr/bin/env python3
"""Simple example script for streaming agent chat using SimplAI."""

import asyncio
import os
import sys
from pathlib import Path

# Add src directory to path to import SDK
script_dir = os.path.dirname(os.path.abspath(__file__))
python_sdk_dir = os.path.abspath(os.path.join(script_dir, ".."))
src_dir = os.path.join(python_sdk_dir, "src")
sys.path.insert(0, src_dir)

# Load environment variables from .env file if it exists
try:
    from dotenv import load_dotenv

    env_path = Path(__file__).parent.parent.parent.parent / ".env"
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
        print(f"Loaded environment variables from: {env_path}")
    else:
        load_dotenv()
except ImportError:
    # python-dotenv not installed, skip loading .env
    pass

from core.agents import agent_chat_stream_async, AgentStreamChunk, AgentExecutionError  # type: ignore[import]


def on_chunk(chunk: AgentStreamChunk) -> None:
    """Callback function called for each streamed chunk."""
    print(chunk.content, end="", flush=True)


async def main() -> None:
    """Example usage of SimplAI for a single streaming agent chat."""
    print("=" * 60)
    print("SimplAI - Streaming Agent Chat Example")
    print("=" * 60)
    
    agent_id = os.getenv("AGENT_ID", "agent-6912e47d72fe386f5281c242")
    api_key = os.getenv("API_KEY", "")
    message = os.getenv("MESSAGE", "")
    base_url = os.getenv("BASE_URL", "https://edge-service-preprod.simplai.ai")
    
    if not api_key:
        print("ERROR: API_KEY environment variable is required")
        print("Usage: API_KEY=your-key AGENT_ID=agent-id MESSAGE='Hi' python test_agent_chat_stream.py")
        return

    if not message:
        print("ERROR: MESSAGE environment variable is required")
        return
    
    try:
        print(f"\nAgent ID: {agent_id}")
        print(f"Message: {message}")
        print(f"Base URL: {base_url}")
        print("\nStarting stream...\n")
        print("Agent Response (streaming):")
        print("-" * 60)
        
        # Get optional parameters from environment
        user_id = os.getenv("USER_ID")
        tenant_id = os.getenv("TENANT_ID", "1")
        project_id = os.getenv("PROJECT_ID")
        seller_id = os.getenv("SELLER_ID")
        client_id = os.getenv("CLIENT_ID")
        seller_profile_id = os.getenv("SELLER_PROFILE_ID")
        device_id = os.getenv("DEVICE_ID", "preprod-simplai")
        
        # Call agent_chat_stream_async with all optional parameters (like the non-streaming test)
        result = await agent_chat_stream_async(
            agent_id=agent_id,
            message=message,
            api_key=api_key,
            on_chunk=on_chunk,
            base_url=base_url,
            user_id=user_id,
            tenant_id=tenant_id,
            project_id=int(project_id) if project_id else None,
            seller_id=seller_id,
            client_id=client_id,
            seller_profile_id=seller_profile_id,
            device_id=device_id,
        )
        
        print("\n" + "-" * 60)
        print("Stream Completed")
        print("=" * 60)
        print(f"Conversation ID: {result.conversation_id}")
        print(f"Message ID: {result.message_id}")
        print(f"Status: {result.status.value}")
        print("\nFull Response:")
        print("-" * 60)
        print(result.response)
        print("-" * 60)
        print(f"\nSuccess: {result.succeeded}")
    except AgentExecutionError as e:
        print(f"\nERROR: Agent execution failed: {e}")
    except KeyboardInterrupt:
        print("\nStream interrupted by user")
    except Exception as e:
        print(f"\nERROR: Unexpected error: {e}")
        import traceback

        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
