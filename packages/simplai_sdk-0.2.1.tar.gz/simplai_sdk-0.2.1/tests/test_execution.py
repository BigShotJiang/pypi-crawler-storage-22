"""Simple example script to test the SDK with real API calls.

Usage:
    python test_execution.py
"""

import os
import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
src_dir = project_root / "src"
sys.path.insert(0, str(src_dir))

import asyncio
from simplai import SimplAI  # type: ignore[import]


async def test_execute_workflow(simplai: SimplAI, workflow_id: str, inputs: dict):
    """Test executing a workflow (async, returns immediately)."""
    print("\n1. Testing execute_workflow()...")
    print("=" * 50)
    
    try:
        execution_info = await simplai.execute_workflow(
            workflow_id=workflow_id,
            inputs=inputs,
        )
        print(f"   Execution ID: {execution_info.get('execution_id')}")
        print(f"   Status: {execution_info.get('status')}")
        return execution_info
    except Exception as e:
        print(f"   Error: {e}")
        raise


async def test_execute_and_wait_workflow(simplai: SimplAI, workflow_id: str, inputs: dict, timeout: float = 60.0, poll_interval: float = 2.0):
    """Test executing a workflow and waiting for completion."""
    print("\nTesting execute_and_wait_workflow()...")
    print("=" * 50)
    
    try:
        result = await simplai.execute_and_wait_workflow(
            workflow_id=workflow_id,
            inputs=inputs,
            timeout=timeout,
            poll_interval=poll_interval,
        )
        print(f"   Execution ID: {result.get('executionId')}")
        print(f"   Status: {result.get('status')}")
        if 'traceId' in result:
            print(f"   Trace ID: {result['traceId']}")
        if 'result' in result:
            print(f"   Result: {result['api_response']}")
        return result
    except Exception as e:
        print(f"   Error: {e}")
        raise


async def test_get_tool_result(simplai: SimplAI, execution_id: str):
    """Test getting the result of an execution."""
    print("\n2. Testing get_tool_result()...")
    print("=" * 50)
    
    try:
        result = await simplai.get_tool_result(execution_id=execution_id)
        print(f"   Execution ID: {result.get('executionId')}")
        print(f"   Status: {result.get('status')}")
        if 'result' in result:
            print(f"   Result: {result['api_response']}")
        return result
    except Exception as e:
        print(f"   Error: {e}")
        raise


async def test_cancel_execution(simplai: SimplAI, execution_id: str):
    """Test cancelling an execution."""
    print("\n3. Testing cancel_execution()...")
    print("=" * 50)
    
    try:
        result = await simplai.cancel_execution(execution_id=execution_id)
        print(f"   Execution ID: {result.get('execution_id')}")
        print(f"   Status: {result.get('status')}")
        return result
    except Exception as e:
        print(f"   Error: {e}")
        raise


async def main():
    """Example usage of the SDK."""
    # Replace with your actual values
    workflow_id = "68d126b243be12ff54307579"
    inputs = {"number_1": 1, "number_2": 2}

    simplai = SimplAI(api_key="")

    print("Testing SDK...")
    print("=" * 50)
    
    try:
        # Test 1: Execute and wait for workflow completion
        execution_result = await test_execute_and_wait_workflow(
            simplai=simplai,
            workflow_id=workflow_id,
            inputs=inputs,
            timeout=60.0,
            poll_interval=2.0,
        )
        
        # Test 2: Get result separately (using a specific execution ID)
        await test_get_tool_result(
            simplai=simplai,
            execution_id=""
        )
        
    except Exception as e:
        print(f"\nError: {e}")
    
    print("\n" + "=" * 50)
    print("Testing complete!")


if __name__ == "__main__":
    asyncio.run(main())
