#!/usr/bin/env python3
"""Simple example script for tracing using SimplAI."""

import asyncio
import os
import sys
from pathlib import Path

# Add src directory to path to import SDK
script_dir = os.path.dirname(os.path.abspath(__file__))
python_sdk_dir = os.path.abspath(os.path.join(script_dir, ".."))
src_dir = os.path.join(python_sdk_dir, "src")
sys.path.insert(0, src_dir)

# Load environment variables from .env file if it exists
# Skip if API_KEY is already set (e.g., from command line)
if not os.getenv("API_KEY"):
    try:
        from dotenv import load_dotenv

        env_path = Path(__file__).parent.parent.parent.parent / ".env"
        if env_path.exists():
            load_dotenv(dotenv_path=env_path)
            print(f"Loaded environment variables from: {env_path}")
        else:
            load_dotenv()
    except ImportError:
        # python-dotenv not installed, skip loading .env
        pass

from simplai import SimplAI, get_trace_tree  # type: ignore[import]
from core.agents import AgentStreamChunk  # type: ignore[import]


async def main() -> None:
    """Example usage of SimplAI for tracing."""
    print("=" * 60)
    print("SimplAI - Trace Tree Example")
    print("=" * 60)
    
    api_key = os.getenv("API_KEY", "")
    trace_id = os.getenv("TRACE_ID", "")
    tree_id = os.getenv("TREE_ID", "")
    node_id = os.getenv("NODE_ID", "")
    agent_id = os.getenv("AGENT_ID", "")
    message = os.getenv("MESSAGE", "Hello! Can you help me?")
    base_url = os.getenv("BASE_URL", "https://edge-service-preprod.simplai.ai")
    
    if not api_key:
        print("ERROR: API_KEY environment variable is required")
        print("Usage: API_KEY=your-key [AGENT_ID=agent-id] [TRACE_ID=trace-id or TREE_ID=tree-id] [NODE_ID=node-id] python test_traces.py")
        return
    
    # Use tree_id if trace_id is not provided
    if not trace_id and tree_id:
        trace_id = tree_id
    
    # If agent_id is provided but trace_id/node_id are not, get them from agent chat
    if agent_id and (not trace_id or not node_id):
        print(f"\nAgent ID provided: {agent_id}")
        print("Trace ID and Node ID not provided - fetching from agent chat...\n")
        
        simplai = SimplAI(api_key=api_key)
        
        try:
            print(f"Message: {message}")
            print("\nSending agent chat request...\n")
            
            # Get agent chat response (which includes trace_id and node_id)
            result = await simplai.agent_chat(
                agent_id=agent_id,
                message=message,
            )
            
            print("=" * 60)
            print("Agent Response Received")
            print("=" * 60)
            print(f"Conversation ID: {result.conversation_id}")
            print(f"Message ID: {result.message_id}")
            print(f"Status: {result.status.value}")
            print(f"\nAgent Response:")
            print("-" * 60)
            print(result.response)
            print("-" * 60)
            
            # Extract trace_id and node_id from AgentResult
            if result.trace_id and result.node_id:
                trace_id = result.trace_id
                node_id = result.node_id
                print(f"\nTrace ID from response: {trace_id}")
                print(f"Node ID from response: {node_id}")
            else:
                print("\nWARNING: Could not extract trace_id and node_id from agent response")
                print("  The response may not have contained trace information")
                print("  Please provide TRACE_ID and NODE_ID manually")
                return
        except Exception as e:
            print(f"\nERROR: Failed to get trace info from agent chat: {e}")
            print("  Please provide TRACE_ID and NODE_ID manually")
            return
    
    # If still no trace_id/tree_id or node_id, show error
    if (not trace_id and not tree_id) or not node_id:
        print("ERROR: (TRACE_ID or TREE_ID) and NODE_ID are required")
        print("  Option 1: Provide AGENT_ID and MESSAGE to automatically get trace info from stream")
        print("  Option 2: Provide TRACE_ID (or TREE_ID) and NODE_ID directly")
        print("\nExample:")
        print("  AGENT_ID=agent-123 MESSAGE='Hello' python test_traces.py")
        print("  OR")
        print("  TRACE_ID=your-trace-id NODE_ID=your-node-id python test_traces.py")
        print("  OR")
        print("  TREE_ID=your-tree-id NODE_ID=your-node-id python test_traces.py")
        return
    
    try:
        print(f"\nTrace ID: {trace_id or tree_id}")
        print(f"Tree ID: {tree_id or trace_id}")
        print(f"Node ID: {node_id}")
        print(f"Base URL: {base_url}")
        print("\nFetching trace tree...")
        print(f"  Using tree_id: {tree_id or trace_id}")
        print(f"  Using node_id: {node_id}\n")
        
        # Get optional parameters from environment
        user_id = os.getenv("USER_ID")
        tenant_id = os.getenv("TENANT_ID", "1")
        project_id = os.getenv("PROJECT_ID")
        seller_id = os.getenv("SELLER_ID")
        client_id = os.getenv("CLIENT_ID")
        seller_profile_id = os.getenv("SELLER_PROFILE_ID")
        device_id = os.getenv("DEVICE_ID", "preprod-simplai")
        max_depth = os.getenv("MAX_DEPTH")
        
        # Get trace tree - use raw_response=True to get the raw JSON
        final_tree_id = trace_id or tree_id
        tree = get_trace_tree(
            api_key=api_key,
            tree_id=final_tree_id,
            node_id=node_id,
            max_depth=int(max_depth) if max_depth else None,
            user_id=user_id,
            tenant_id=tenant_id,
            project_id=int(project_id) if project_id else None,
            seller_id=seller_id,
            client_id=client_id,
            seller_profile_id=seller_profile_id,
            device_id=device_id,
            raw_response=True,  # Return raw JSON response
        )
        
        print("=" * 60)
        print("Raw Trace Tree Response")
        print("=" * 60)
        import json
        print(json.dumps(tree, indent=2))

        print("=" * 60)
        print("Trace tree retrieved successfully!")
        
    except Exception as e:
        print(f"\nERROR: Failed to get trace tree: {e}")
        import traceback
        traceback.print_exc()


async def example_with_stream() -> None:
    """Example showing how to get trace_id and node_id from a streaming agent response."""
    print("\n" + "=" * 60)
    print("Example: Getting Trace ID from Streaming Agent Response")
    print("=" * 60)
    
    api_key = os.getenv("API_KEY", "")
    agent_id = os.getenv("AGENT_ID", "agent-6912e47d72fe386f5281c242")
    message = os.getenv("MESSAGE", "Hello! Can you help me?")
    
    if not api_key:
        print("ERROR: API_KEY environment variable is required")
        return
    
    try:
        simplai = SimplAI(api_key=api_key)
        
        def on_chunk(chunk: AgentStreamChunk) -> None:
            """Callback to print streamed content."""
            print(chunk.content, end="", flush=True)
        
        print(f"\nAgent ID: {agent_id}")
        print(f"Message: {message}")
        print("\nStarting stream...\n")
        print("Agent Response (streaming):")
        print("-" * 60)
        
        # Stream the agent response
        result = await simplai.agent_chat_stream(
            agent_id=agent_id,
            message=message,
            on_chunk=on_chunk,
        )
        
        print("\n" + "-" * 60)
        print("Stream Completed")
        print("=" * 60)
        print(f"Conversation ID: {result.conversation_id}")
        print(f"Message ID: {result.message_id}")
        print(f"Status: {result.status.value}")
        
        # Use trace_id and node_id from AgentResult
        if result.trace_id and result.node_id:
            print(f"\nTrace ID from response: {result.trace_id}")
            print(f"Node ID from response: {result.node_id}")
            
            print("\nFetching trace tree...\n")
            
            # Get trace tree using the IDs from the response
            tree = get_trace_tree(
                api_key=api_key,
                tree_id=result.trace_id,
                node_id=result.node_id,
            )
            
            print("=" * 60)
            print("Trace Tree Retrieved")
            print("=" * 60)
            print(f"Node ID: {tree.node_id}")
            print(f"Tree ID: {tree.tree_id}")
            print(f"Name: {tree.name}")
            print(f"Entity Type: {tree.entity_type}")
            print(f"Status: {tree.status}")
            print(f"Has Children: {tree.has_children}")
            if tree.children:
                print(f"Children Count: {len(tree.children)}")
        else:
            print("\nWARNING: Could not extract trace_id and node_id from agent response")
            print("  The response may not have contained trace information")
        
    except Exception as e:
        print(f"\nERROR: Failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # Check if we should run the stream example
    if os.getenv("USE_STREAM", "").lower() in ("1", "true", "yes"):
        asyncio.run(example_with_stream())
    else:
        asyncio.run(main())
