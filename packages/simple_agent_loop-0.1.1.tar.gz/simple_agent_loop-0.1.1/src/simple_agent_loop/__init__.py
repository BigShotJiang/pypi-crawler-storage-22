from datetime import datetime, timezone
import copy
import json
import concurrent.futures


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def init_session(system_prompt, user_prompt):
    return {
        "messages": [
            {"role": "system", "content": system_prompt, "ts": now()},
            {"role": "user", "content": user_prompt, "ts": now()},
        ]
    }


def extend_session(session, message):
    session["messages"].append(message)


def send(session, user_message):
    extend_session(session, {"role": "user", "content": user_message, "ts": now()})


def fork_session(session):
    return copy.deepcopy(session)


def response(session):
    for msg in reversed(session["messages"]):
        if msg.get("role") == "assistant":
            return msg
    return None


def to_api_messages(messages):
    """Convert generic messages to Anthropic API format.

    Groups consecutive thinking/assistant/tool_call into a single assistant message,
    and consecutive tool_results into a single user message.
    """
    api_messages = []
    assistant_blocks = []
    tool_result_blocks = []

    def flush_assistant():
        nonlocal assistant_blocks
        if assistant_blocks:
            api_messages.append({"role": "assistant", "content": assistant_blocks})
            assistant_blocks = []

    def flush_tool_results():
        nonlocal tool_result_blocks
        if tool_result_blocks:
            api_messages.append({"role": "user", "content": tool_result_blocks})
            tool_result_blocks = []

    for msg in messages:
        role = msg.get("role")
        msg_type = msg.get("type")

        if role == "system":
            continue

        elif role == "user":
            flush_assistant()
            flush_tool_results()
            api_messages.append({"role": "user", "content": msg["content"]})

        elif role == "assistant":
            flush_tool_results()
            assistant_blocks.append({"type": "text", "text": msg["content"]})

        elif msg_type == "thinking":
            flush_tool_results()
            block = {"type": "thinking", "thinking": msg["content"]}
            if "signature" in msg:
                block["signature"] = msg["signature"]
            assistant_blocks.append(block)

        elif msg_type == "tool_call":
            flush_tool_results()
            assistant_blocks.append({
                "type": "tool_use",
                "id": msg["id"],
                "name": msg["name"],
                "input": msg["input"],
            })

        elif msg_type == "tool_result":
            flush_assistant()
            output = msg["output"]
            tool_result_blocks.append({
                "type": "tool_result",
                "tool_use_id": msg["id"],
                "content": output if isinstance(output, str) else json.dumps(output),
            })

    flush_assistant()
    flush_tool_results()
    return api_messages


def parse_response(api_response):
    """Parse Anthropic API response dict into generic messages."""
    messages = []
    ts = now()

    for block in api_response.get("content", []):
        block_type = block["type"]

        if block_type == "thinking":
            msg = {"type": "thinking", "content": block["thinking"], "ts": ts}
            if "signature" in block:
                msg["signature"] = block["signature"]
            messages.append(msg)

        elif block_type == "text":
            if block["text"]:
                messages.append({"role": "assistant", "content": block["text"], "ts": ts})

        elif block_type == "tool_use":
            messages.append({
                "type": "tool_call",
                "name": block["name"],
                "id": block["id"],
                "input": block["input"],
            })

    return messages


def execute_tool_calls(tool_calls, tool_handlers):
    """Execute tool calls in parallel via ThreadPoolExecutor. Errors are caught and returned as results."""
    results = []

    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_to_tc = {}
        for tc in tool_calls:
            handler = tool_handlers.get(tc["name"])
            if handler is None:
                results.append({
                    "type": "tool_result",
                    "id": tc["id"],
                    "output": f"Error: unknown tool '{tc['name']}'",
                })
                continue
            future = executor.submit(handler, **tc["input"])
            future_to_tc[future] = tc

        for future in concurrent.futures.as_completed(future_to_tc):
            tc = future_to_tc[future]
            try:
                output = future.result()
                results.append({
                    "type": "tool_result",
                    "id": tc["id"],
                    "output": output,
                })
            except Exception as e:
                results.append({
                    "type": "tool_result",
                    "id": tc["id"],
                    "output": f"Error: {e}",
                })

    return results


def log(message, name=None):
    ts = message.get("ts", now())
    agent = name or "agent"

    role = message.get("role", "")
    msg_type = message.get("type", "")
    label = role or msg_type

    if msg_type == "thinking":
        content = message.get("content", "")
    elif msg_type == "tool_call":
        content = f"{message['name']}({json.dumps(message['input'])})"
    elif msg_type == "tool_result":
        output = message.get("output", "")
        content = output if isinstance(output, str) else json.dumps(output)
    else:
        content = message.get("content", "")

    content = content.replace("\n", " ").strip()
    line = f"{ts} {agent} {label} {content}"
    if len(line) > 120:
        line = line[:117] + "..."
    print(line)


def compact_session(session):
    """Compact old thinking and tool_call messages to save context window space.

    Only compacts messages where the model has responded (assistant role)
    at least twice since that message. Keeps the first 120 chars of content.
    """
    messages = session["messages"]
    assistant_count = 0
    for i in range(len(messages) - 1, -1, -1):
        msg = messages[i]
        if msg.get("role") == "assistant":
            assistant_count += 1
        if assistant_count >= 2 and not msg.get("compacted"):
            msg_type = msg.get("type")
            if msg_type == "thinking":
                content = msg["content"]
                if len(content) > 120:
                    msg["content"] = content[:120] + "..."
                    msg["compacted"] = True
            elif msg_type == "tool_call":
                input_str = json.dumps(msg["input"])
                if len(input_str) > 120:
                    msg["input"] = {"_compacted": input_str[:120] + "..."}
                    msg["compacted"] = True


def readme():
    return r"""
# simple_agent_loop

A minimal agent loop for tool-using language models. ~250 lines. Handles
message format conversion, parallel tool execution, session compaction,
and subagent composition.

## Setup

```python
import anthropic
import json
import simple_agent_loop as sal

client = anthropic.Anthropic()  # uses ANTHROPIC_API_KEY env var

def invoke_model(tools, session):
    kwargs = dict(
        model="claude-sonnet-4-5",
        max_tokens=16000,
        messages=session["messages"],
    )
    if "system" in session:
        kwargs["system"] = session["system"]
    if tools:
        kwargs["tools"] = tools
    return client.messages.create(**kwargs).to_dict()
```

## Hello World

No tools, single turn -- the model just responds:

```python
session = init_session(
    system_prompt="You are a helpful assistant.",
    user_prompt="Say hello in three languages.",
)
result = agent_loop(invoke_model, [], session, max_iterations=1)
print(response(result)["content"])
```

## Tool-Using Agent

Define tools as Anthropic tool schemas and provide handler functions. The
handler receives tool input as keyword arguments and returns a string.

```python
import requests

tools = [
    {
        "name": "get_weather",
        "description": "Get the current weather for a city.",
        "input_schema": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    }
]

def get_weather(city):
    resp = requests.get(f"https://wttr.in/{city}?format=j1")
    data = resp.json()["current_condition"][0]
    return json.dumps({
        "city": city,
        "temp_c": data["temp_C"],
        "description": data["weatherDesc"][0]["value"],
    })

session = init_session(
    system_prompt="You answer weather questions. Use the get_weather tool.",
    user_prompt="What's the weather in Tokyo and Paris?",
)
result = agent_loop(
    invoke_model, tools, session,
    tool_handlers={"get_weather": get_weather},
)
print(response(result)["content"])
```

The model will call get_weather twice (in parallel), see the results, and
respond with a summary. The loop runs until the model responds without
making any tool calls.

## Subagents

A subagent is a tool handler that runs its own agent loop. The outer agent
calls it like any tool and gets back a string result.

### Example: Text Compressor (compressor.py)

A coordinator agent iteratively compresses text using two subagents:
a shortener and a quality judge.

```python
# Subagent: compresses text
def shorten(text):
    session = init_session(
        system_prompt="Rewrite the text to half its length. Output ONLY the result.",
        user_prompt=text,
    )
    result = agent_loop(invoke_model, [], session, name="shortener", max_iterations=1)
    shortened = response(result)["content"]
    ratio = len(shortened) / len(text)
    return json.dumps({"compression_ratio": round(ratio, 3), "shortened_text": shortened})

# Subagent: judges compression quality
def judge(original, shortened):
    session = init_session(
        system_prompt=(
            "Compare original and shortened text. Return ONLY JSON: "
            '{"verdict": "acceptable", "reason": "..."} or '
            '{"verdict": "too_lossy", "reason": "..."}'
        ),
        user_prompt=f"ORIGINAL:\n{original}\n\nSHORTENED:\n{shortened}",
    )
    result = agent_loop(invoke_model, [], session, name="judge", max_iterations=1)
    return response(result)["content"]
```

The coordinator has tools for `shorten` and `judge`, and its system prompt
tells it to loop: shorten, judge, stop if too_lossy or diminishing returns,
otherwise shorten again. Each subagent is a one-shot agent loop
(max_iterations=1) with no tools of its own.

### Example: Transform Rule Derivation (derive_transform.py)

A more complex example with four subagents and a coordinator. Given a
source text and target text, it derives general transformation rules and
specific info that together reproduce the target from the source.

```python
# Subagent: applies rules + specific info to source text
def edit(text, rules, specific_info):
    session = init_session(
        system_prompt="Apply the rules to the text using the specific info. Output ONLY the result.",
        user_prompt=f"SOURCE TEXT:\n{text}\n\nRULES:\n{rules}\n\nSPECIFIC INFO:\n{specific_info}",
    )
    result = agent_loop(invoke_model, [], session, name="editor", max_iterations=1)
    return response(result)["content"]

# Subagent: scores how close the output is to the target
def judge_similarity(editor_output, target):
    session = init_session(
        system_prompt='Compare texts. Return JSON: {"score": 0-100, "differences": "..."}',
        user_prompt=f"EDITOR OUTPUT:\n{editor_output}\n\nTARGET:\n{target}",
    )
    result = agent_loop(invoke_model, [], session, name="similarity-judge", max_iterations=1)
    return response(result)["content"]

# Subagent: checks rules are abstract (no specific content leaked in)
def judge_generality(rules):
    ...

# Subagent: checks specific_info is a flat fact list
def judge_specific_info(specific_info):
    ...
```

The coordinator calls `edit`, then calls all three judges in parallel,
refines based on scores, and repeats until all judges score above 90.
Tool calls within a single model response execute in parallel automatically.

## API Reference

### Session Management

- `init_session(system_prompt, user_prompt)` - Create a new session
- `extend_session(session, message)` - Append a message to the session
- `send(session, user_message)` - Add a user message to the session
- `fork_session(session)` - Deep copy a session for branching
- `response(session)` - Get the last assistant message, or None

### Agent Loop

- `agent_loop(invoke_model, tools, session, tool_handlers=None, name=None, max_iterations=None)`
  - `invoke_model(tools, session)` - Function that calls the model API
  - `tools` - List of Anthropic tool schemas ([] for no tools)
  - `session` - Session dict from init_session
  - `tool_handlers` - Dict mapping tool names to handler functions
  - `name` - Agent name for log output
  - `max_iterations` - Max model calls before stopping (None = unlimited)
  - Returns the session with all messages appended

### Message Format

Messages use a generic format independent of any API:

    {"role": "system", "content": "..."}
    {"role": "user", "content": "..."}
    {"role": "assistant", "content": "..."}
    {"type": "thinking", "content": "..."}
    {"type": "tool_call", "name": "...", "id": "...", "input": {...}}
    {"type": "tool_result", "id": "...", "output": "..."}

Conversion to/from Anthropic API format is handled by to_api_messages()
and parse_response().
"""


def agent_loop(invoke_model, tools, session, tool_handlers=None, name=None, max_iterations=None):
    if tool_handlers is None:
        tool_handlers = {}

    iteration = 0
    while max_iterations is None or iteration < max_iterations:
        iteration += 1

        system_prompts = [m["content"] for m in session["messages"] if m.get("role") == "system"]
        api_session = {"messages": to_api_messages(session["messages"])}
        if system_prompts:
            api_session["system"] = system_prompts[0]
        api_response = invoke_model(tools, api_session)

        messages = parse_response(api_response)
        for msg in messages:
            extend_session(session, msg)
            log(msg, name)

        compact_session(session)

        tool_calls = [m for m in messages if m.get("type") == "tool_call"]
        if not tool_calls:
            break

        results = execute_tool_calls(tool_calls, tool_handlers)
        for result in results:
            extend_session(session, result)
            log(result, name)

    return session
