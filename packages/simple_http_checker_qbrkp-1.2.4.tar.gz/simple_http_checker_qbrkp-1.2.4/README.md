# python_devops
This repo contains code CI/CD implementation
