# simple-math

A minimal Python package that provides two functions: `add` and `hello`.
