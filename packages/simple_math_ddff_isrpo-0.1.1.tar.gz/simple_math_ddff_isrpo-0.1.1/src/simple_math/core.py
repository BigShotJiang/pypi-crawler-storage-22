def add(a, b):
    return a + b

def hello(name):
    return f"hello,{name}!"
