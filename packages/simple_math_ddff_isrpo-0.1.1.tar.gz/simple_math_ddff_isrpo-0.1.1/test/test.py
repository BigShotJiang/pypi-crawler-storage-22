#!/usr/bin/env python3
from simple_math import hello

print(hello("world"))
