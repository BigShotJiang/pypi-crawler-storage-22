# Simple Python package

Template repository for publication of simple Python package to PyPI.
