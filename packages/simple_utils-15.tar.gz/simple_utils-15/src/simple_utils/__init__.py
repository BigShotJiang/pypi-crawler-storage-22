"""
simple-utils: A collection of simple Python utilities.
"""

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.0.0"

