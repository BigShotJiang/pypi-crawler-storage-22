"""Storage utilities for simple-utils."""

from .object_storage import ObjectStorage

__all__ = ["ObjectStorage"]
