# Python Client Development Guide

## Adding New Services

Follow this pattern when implementing new Augur API service endpoints.

### 1. Create Service Directory Structure

```
src/augur_api/services/{service_name}/
    __init__.py      # Export client and schemas
    client.py        # Service client and resource classes
    schemas.py       # Pydantic models for request/response
```

### 2. Schema Pattern (schemas.py)

**CRITICAL:** Always import `CamelCaseModel` from core - never define your own!

```python
"""Schemas for the {ServiceName} service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel


# Request params use BaseModel (snake_case for Python convenience)
class ListParams(BaseModel):
    """Parameters for listing resources."""
    limit: int | None = None
    offset: int | None = None
    # Add service-specific params...


# Response models use CamelCaseModel (handles API camelCase automatically)
class Resource(CamelCaseModel):
    """Resource entity returned by API."""
    resource_uid: int        # API returns: resourceUid
    resource_name: str       # API returns: resourceName
    optional_field: str | None = None
```

### 3. camelCase Handling

The Augur API returns camelCase field names, Python convention uses snake_case.

**How it works:**
- `CamelCaseModel` uses Pydantic's `alias_generator=to_camel`
- Field `resource_uid` automatically maps to JSON `resourceUid`
- `populate_by_name=True` allows both names to work
- **No explicit `Field(alias=...)` needed!** The alias_generator handles it.

**Rule:** Response models MUST inherit from `CamelCaseModel`.
Request params can use `BaseModel` since they're converted to query strings.

### 4. Client Pattern (client.py)

**Use BaseResource to eliminate boilerplate:**

```python
"""Service client for {service_name}."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import List as ListType
else:
    ListType = list

from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource
from augur_api.services.{service_name}.schemas import (
    ListParams,
    Resource,
)


class ResourceResource(BaseResource):
    """Resource for /{resource} endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        super().__init__(http, "/resource")  # Base path

    def list(self, params: ListParams | None = None) -> BaseResponse[ListType[Resource]]:
        """List resources."""
        response = self._get(params=params)  # Uses inherited helper
        return BaseResponse[ListType[Resource]].model_validate(response)

    def get(self, uid: int) -> BaseResponse[Resource]:
        """Get resource by UID."""
        response = self._get(f"/{uid}")  # Path suffix appended to base
        return BaseResponse[Resource].model_validate(response)

    def create(self, data: CreateData) -> BaseResponse[Resource]:
        """Create a resource."""
        response = self._post(data=data)  # POST to base path
        return BaseResponse[Resource].model_validate(response)

    def update(self, uid: int, data: UpdateData) -> BaseResponse[Resource]:
        """Update a resource."""
        response = self._put(f"/{uid}", data=data)
        return BaseResponse[Resource].model_validate(response)

    def delete(self, uid: int) -> BaseResponse[None]:
        """Delete a resource."""
        response = self._delete(f"/{uid}")
        return BaseResponse[None].model_validate(response)


class ServiceClient(BaseServiceClient):
    """Client for {ServiceName} service."""

    def __init__(self, http_client: HTTPClient) -> None:
        super().__init__(http_client)
        self._resource: ResourceResource | None = None

    @property
    def resource(self) -> ResourceResource:
        """Access resource endpoints."""
        if self._resource is None:
            self._resource = ResourceResource(self._http)
        return self._resource
```

### 5. BaseResource Helper Methods

`BaseResource` provides these helpers to reduce boilerplate:

| Method | Purpose |
|--------|---------|
| `_get(path, params)` | GET request, appends path to base |
| `_post(path, data, params)` | POST request |
| `_put(path, data, params)` | PUT request |
| `_delete(path, params)` | DELETE request |
| `_to_params(params)` | Convert Pydantic model to dict |

**Before (without BaseResource):**
```python
def list(self, params):
    query_params = params.model_dump(exclude_none=True) if params else None
    response = self._http.get("/resource", params=query_params)
    return BaseResponse[list[Resource]].model_validate(response)
```

**After (with BaseResource):**
```python
def list(self, params):
    response = self._get(params=params)
    return BaseResponse[ListType[Resource]].model_validate(response)
```

### 6. Export Pattern (__init__.py)

```python
"""Service exports."""

from augur_api.services.{service_name}.client import ServiceClient
from augur_api.services.{service_name}.schemas import (
    ListParams,
    Resource,
)

__all__ = [
    "ServiceClient",
    "ListParams",
    "Resource",
]
```

### 7. Register in Main Client

Add to `src/augur_api/client.py`:

```python
from augur_api.services.{service_name} import ServiceClient

class AugurAPI:
    def __init__(self, ...):
        self._service_name: ServiceClient | None = None

    @property
    def service_name(self) -> ServiceClient:
        if self._service_name is None:
            http = HTTPClient("{service-name}", self.config)
            self._service_name = ServiceClient(http)
        return self._service_name
```

### 8. Testing

Create `tests/services/test_{service_name}.py`:

```python
"""Tests for {ServiceName} service."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI


class TestSchemas:
    """Test schema validation."""

    def test_resource_model(self) -> None:
        """Should parse camelCase response."""
        from augur_api.services.{service_name} import Resource

        # Use camelCase like real API
        data = {"resourceUid": 1, "resourceName": "Test"}
        resource = Resource.model_validate(data)

        # Access via snake_case
        assert resource.resource_uid == 1
        assert resource.resource_name == "Test"


class TestClient:
    """Test client methods."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        return AugurAPI(token="test", site_id="test")

    def test_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        httpx_mock.add_response(
            url="https://{service-name}.augur-api.com/resource",
            json={
                "count": 1,
                "data": [{"resourceUid": 1, "resourceName": "Test"}],
                "message": "Success",
                "options": [],
                "params": [],
                "status": 200,
                "total": 1,
                "totalResults": 1,  # camelCase!
            },
        )
        result = api.service_name.resource.list()
        assert result.count == 1
```

## Quality Gates

Run before every commit:

```bash
cd packages/python
uv run ruff check src tests      # Linting
uv run mypy src                  # Type checking
uv run pytest tests              # Tests + 100% coverage
```

## Live Testing

With credentials in `.protected/augur_info.json`:

```python
from tests.conftest import live_test

@live_test
def test_live_endpoint(live_api):
    """Test against real API."""
    result = live_api.service_name.resource.list()
    assert result.status == 200
```

Or set `SKIP_LIVE_TESTS=true` to skip live tests.

## Key Reminders

1. **Never define `CamelCaseModel` in service schemas** - Always import from `core.schemas`
2. **Use `ListType` instead of `list`** in resource classes to avoid shadowing
3. **Response mocks must use camelCase** - Match real API behavior
4. **100% test coverage required** - No exceptions
5. **Inherit from `BaseResource`** - Eliminates HTTP boilerplate
