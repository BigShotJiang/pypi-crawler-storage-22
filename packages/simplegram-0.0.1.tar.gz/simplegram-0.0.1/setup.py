import setuptools

with open("README.md", "r", encoding = "utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name = "simplegram",
    version = "0.0.1",
    author = "Diyorbek Jumanov",
    author_email = "djumanovdev@gmail.com",
    description = "A simple python telegram bot library.",
    long_description = long_description,
    long_description_content_type = "text/markdown",
    url = "https://github.com/nt-sn04/simplegram",
    project_urls = {
        "Bug Tracker": "https://github.com/nt-sn04/simplegram",
    },
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir = {"": "simplegram"},
    packages = setuptools.find_packages(where="simplegram"),
    python_requires = ">=3.10"
)
