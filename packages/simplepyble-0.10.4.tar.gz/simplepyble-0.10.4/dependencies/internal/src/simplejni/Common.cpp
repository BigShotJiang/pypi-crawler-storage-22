#include "simplejni/Common.hpp"

namespace SimpleJNI {
} // namespace SimpleJNI