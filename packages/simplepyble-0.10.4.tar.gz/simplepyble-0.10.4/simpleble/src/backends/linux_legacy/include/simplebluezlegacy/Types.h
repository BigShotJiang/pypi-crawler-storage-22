#pragma once

#include "kvn/kvn_bytearray.h"

namespace SimpleBluezLegacy {

using ByteArray = kvn::bytearray;

}
