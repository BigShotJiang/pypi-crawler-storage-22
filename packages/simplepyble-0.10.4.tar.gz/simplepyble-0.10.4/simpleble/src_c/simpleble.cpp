#include <simpleble_c/simpleble.h>

#include <cstdlib>

void simpleble_free(void* handle) { free(handle); }