#pragma once

#include "kvn/kvn_bytearray.h"

namespace SimpleBluez {

using ByteArray = kvn::bytearray;

}
