from dataclasses import dataclass
from ..common import BaseCategory, BaseModel, vStr, ApiRetSData, api_method, smart_model

class Cwdm(BaseCategory):
    """CWDM"""

    @smart_model
    class Get(BaseModel):
        id: int
        node_id: int
        description: vStr
        date_add: vStr
        is_planned: bool
        inventory_id: int
        name: vStr
        location: vStr

    @api_method(Get)
    def get(self, *, id: int | str = None, node_id: int | str = None) -> ApiRetSData[Get]:
        """Список CWDM

            Обязательные параметры:
                нет
            Дополнительные параметры:
                id - id объектов (можно через запятую)
                node_id - id объектов размещения (можно через запятую)
        """
        ...
