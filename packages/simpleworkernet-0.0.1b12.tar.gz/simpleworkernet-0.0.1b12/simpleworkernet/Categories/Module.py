from typing import List, Literal, overload
from ..common import BaseCategory, BaseModel, vStr, vFlag, ApiRetResult, ApiRetSData, api_method, smart_model

class Module(BaseCategory):
    """Внешние запросы от модулей"""

    @smart_model
    class Get_api_information(BaseModel):
        version: vStr
        date: vStr

    @api_method(Get_api_information)
    def get_api_information(self) -> ApiRetSData[Get_api_information]:
        """Используемая версия API"""
        ...

    @api_method()
    def get_city_district_list(self): 
        """Адреса. Районы в населённых пунктах"""
        ...

    @smart_model
    class Get_city_list(BaseModel):
        id: int
        name: vStr

    @api_method(Get_city_list)
    def get_city_list(self) -> ApiRetSData[Get_city_list]: 
        """Адреса. Населённые пункты"""
        ...

    @smart_model
    class Get_connect_list(BaseModel):
        @smart_model
        class Item(BaseModel):
            type: vStr
            id: int
            direction: int
            interface: int
        customer: List[Item]
        switch: List[Item]
        other: List[Item]

    @api_method()
    def get_connect_list(self, *, object_type: Literal['customer','switch','other'] = None, object_id: int | str = None): 
        """Коммутация объектов (абонентов/оборудования) между собой"""
        ...

    @api_method()
    def get_device_list(self, *, device_type: Literal['switch','radio','other'] = None): 
        """Оборудование. Список устройств"""
        ...

    @api_method()
    def get_device_model(self, *, device_type: Literal['switch','radio','other'] = None): 
        """Оборудование. Модели устройств"""
        ...

    @api_method()
    def get_device_type(self): 
        """Оборудование. Типы устройств"""
        ...

    @api_method()
    def get_house_list(self): 
        """Адреса. Дома"""
        ...

    @api_method()
    def get_services_list(self): 
        """Услуги/дополнительные услуги"""
        ...
    
    @api_method()
    def get_street_list(self): 
        """Адреса. Улицы"""
        ...
    
    @api_method()
    def get_supported_change_user_data_list(self): 
        """Поддерживаемые методы для изменения данных абонента через API"""
        ...

    @api_method()
    def get_supported_change_user_state(self, *, customer_id: int = None): 
        """Поддерживаемые статусы для изменения статуса работы абонента через API"""
        ...

    @api_method()
    def get_supported_change_user_tariff(self, *, customer_id: int = None): 
        """Поддерживаемые тарифные планы для изменения тарифа у абонента через API"""
        ...

    @api_method()
    def get_supported_method_list(self): 
        """Поддерживаемые методы API"""
        ...

    @api_method()
    def get_system_information(self): 
        """Системная информация"""
        ...

    @api_method()
    def get_tariff_list(self): 
        """Тарифные планы. Стандартные тарифы"""
        ...
    
    @api_method()
    def get_user_additional_data_type_list(self): 
        """Типы дополнительных полей по абонентам"""
        ...
    
    @api_method()
    def get_user_group_list(self): 
        """Группы абонентов"""
        ...

    @api_method()
    def get_user_history(self, *, customer_id: int): 
        """История по абоненту"""
        ...

    @api_method()
    def get_user_list(self, *, customer_id: int = None): 
        """Абоненты/клиенты"""
        ...

    @api_method()
    def get_user_messages(self): 
        """Сообщения абонентов"""
        ...

    @api_method()
    def get_user_state_list(self): 
        """Типы статусов абонентов (конфигуратор статусов)"""
        ...

    @api_method()
    def get_user_tags(self): 
        """Метки для абонентов"""
        ...
