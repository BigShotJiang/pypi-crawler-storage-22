import types, json, pickle, gzip, re, os, html, inspect
from typing import TypeVar, Generic, List, Iterable, Generator, Iterator, Dict, Any, Union, Literal, Type, Optional, Callable, get_type_hints, get_origin, get_args, dataclass_transform
from dataclasses import dataclass, fields, is_dataclass
from urllib.parse import unquote_plus
from functools import wraps
from enum import IntFlag, StrEnum
from pathlib import Path

@dataclass_transform()
def smart_model(cls=None, **kwargs):
    params = {"init": False, "repr": False}
    params.update(kwargs)
    if cls is None:
        return lambda c: dataclass(c, **params)
    return dataclass(cls, **params)

class BaseModel:...

T = TypeVar('T',bound=BaseModel)

SKEY_NAME = 'extern_skey'

type ApiRetResult = bool | None
type ApiRetSData[T] = SmartData[T] | T | List[T] | None
type ApiRet = ApiRetSData | ApiRetResult

class WorkerNetException(BaseException):
    def __init__(self, message: str, code: Optional[int] = None):
        super().__init__(f"{message}{f" response.status_code={code}" if code else ''}")
        self.message = message
        self.code = code

class vStr(str):
    def __new__(cls, value):
        return super().__new__(cls, unquote_plus(string = html.unescape(str(value)), encoding = "utf-8"))

class vFlag(IntFlag):
    v1 = 1
    v0 = 0

additional_field = lambda x: f"additional_field_{x}"

class BaseCategory:
    _is_ret_origin = False
    def __init__(self, api: Any):
        self._api = api
        self._category = self.__class__.__name__.lower()
        self._is_ret_origin = False
    @staticmethod
    def _return_original_response(is_ret_origin: bool = True):
        BaseCategory._is_ret_origin = is_ret_origin

class BaseData(BaseModel): pass


def collapse_list(lst: Any, mode: Literal['auto', 'aggressive', 'preserve'] = 'auto', depth: int = 0) -> Any:
    """
    Универсальная функция схлопывания списков.
    
    Режимы:
    - 'auto': автоматическое определение по типам элементов
    - 'aggressive': полное схлопывание матрешек, распаковка всех вложенных списков
    - 'preserve': сохранение структуры, только обработка элементов без схлопывания
    
    ВАЖНО: В любом режиме, если в списке 1 элемент и он - список - разворачиваем
    """
    if not isinstance(lst, list):
        return lst
    
    if len(lst) == 0:
        return lst
    
    # --- НОВОЕ: БЕЗУСЛОВНОЕ РАЗВОРАЧИВАНИЕ ОДИНОЧНЫХ ВЛОЖЕННЫХ СПИСКОВ ---
    # Это правило применяется ВСЕГДА, независимо от режима
    while len(lst) == 1 and isinstance(lst[0], list):
        lst = lst[0]
        if len(lst) == 0:
            break
    # --- КОНЕЦ НОВОГО ПРАВИЛА ---
    
    # Режим PRESERVE - только обрабатываем элементы, не схлопываем
    if mode == 'preserve':
        result = []
        for item in lst:
            if isinstance(item, list):
                result.append(collapse_list(item, 'preserve', depth + 1))
            else:
                result.append(item)
        return result
    
    # Режим AGGRESSIVE - полное схлопывание матрешек
    if mode == 'aggressive':
        # Схлопываем матрешки на текущем уровне (теперь это дублируется с новым правилом,
        # но оставляем для обратной совместимости)
        while len(lst) == 1 and isinstance(lst[0], list):
            lst = lst[0]
        
        # Обрабатываем элементы
        result = []
        for item in lst:
            if isinstance(item, list):
                item = collapse_list(item, 'aggressive', depth + 1)
                if isinstance(item, list):
                    result.extend(item)
                else:
                    result.append(item)
            else:
                result.append(item)
        
        # Финальная проверка
        while len(result) == 1 and isinstance(result[0], list):
            result = result[0]
        
        return result
    
    # Режим AUTO - определяем по типам элементов
    if mode == 'auto':
        # Проверяем, все ли элементы - простые типы
        all_primitives = True
        for item in lst:
            if item is None:
                continue
            if not isinstance(item, (int, float, str, bool)):
                all_primitives = False
                break
        
        if all_primitives:
            return collapse_list(lst, 'preserve', depth + 1)
        else:
            return collapse_list(lst, 'aggressive', depth + 1)
    
    return lst

class BaseModel:
    # extern_skey: str = ''
    
    def __init__(self, *args, **kwargs):

        hints = get_type_hints(self.__class__)

        def is_base_model_type(t):
            try:
                return isinstance(t, type) and issubclass(t, BaseModel)
            except: return False

        def deep_cast(target_t, val):

            if target_t is Any or target_t is type(None) or val is None:
                return val
            origin = get_origin(target_t)
            args = get_args(target_t)
            
            # 1. Обработка Union (Optional)
            if origin is Union or (hasattr(types, "UnionType") and isinstance(target_t, types.UnionType)):
                for t in args:
                    if t is type(None): continue
                    try: return deep_cast(t, val)
                    except: continue
                return val

            # 2. Обработка СПИСКОВ (List/list)
            if origin is list or target_t is list or target_t is List:
                inner_t = args[0] if args else Any
                
                if isinstance(val, list):
                    # Если внутри списка лежат структуры (словари/списки), обрабатываем элементы рекурсивно
                    if len(val) > 0 and isinstance(val[0], (dict, list)):
                        result = [deep_cast(inner_t, x) for x in val]
                    else:
                        # Проверка на вложенность:
                        try:
                            # Если inner_t — это класс который может принять список целиком
                            if is_dataclass(inner_t) or is_base_model_type(inner_t):
                                # Если создание объекта из всего списка прошло успешно - возвращаем [Obj]
                                return [deep_cast(inner_t, val)]
                        except:
                            pass
                        
                        # Стандартный путь: просто возвращаем список, прогнав элементы через deep_cast
                        result = [deep_cast(inner_t, x) for x in val]
                    
                    # Постобработка: схлопывание матрешек в получившемся списке
                    return collapse_list(result)
                
                # Если на вход пришло НЕ список, оборачиваем в список (согласно List в аннотации)
                return [deep_cast(inner_t, val)]

            # 3. Обработка ТИПОВ (Классы, Датаклассы)
            if isinstance(target_t, type):
                if isinstance(val, dict):
                    # Если наследник BaseModel - передаем словарь как один аргумент
                    if is_base_model_type(target_t):
                        result = target_t(**val)
                        # Постобработка для вложенных BaseModel объектов
                        return self._postprocess_model(result)
                    # Если обычный датакласс - распаковываем
                    if is_dataclass(target_t):
                        result = target_t(**val)
                        return result
                
                if isinstance(val, list):
                    try: 
                        # Пытаемся создать объект из списка напрямую (напр. Point([1,2]))
                        result = target_t(val)
                        # Постобработка для вложенных BaseModel объектов
                        if is_base_model_type(target_t):
                            return self._postprocess_model(result)
                        return result
                    except: 
                        # Если не вышло - считаем, что это список таких объектов
                        result = [deep_cast(target_t, x) for x in val]
                        # Постобработка
                        return collapse_list(result)

            # 4. Базовое приведение
            try:
                if isinstance(val, target_t): return val
                return target_t(val) if val is not None else val
            except:
                return val

        for name, value in kwargs.items():
            if name in hints:
                setattr(self, name, deep_cast(hints[name], value))
            else:
                setattr(self, name, value)
        
        # Постобработка всего объекта после инициализации
        self._postprocess_object()

    def _postprocess_object(self):
        """Постобработка объекта"""
        if not hasattr(self, '__dict__'):
            return
        for key, value in self.__dict__.items():
            if key.startswith('_'):
                continue
            setattr(self, key, self._postprocess_value(value))

    def _postprocess_value(self, value):
        """Рекурсивная постобработка значения"""
        if isinstance(value, list):
            # Обрабатываем список
            result = []
            for item in value:
                result.append(self._postprocess_value(item))
            # Схлопываем матрешки в получившемся списке
            return collapse_list(result)
        elif isinstance(value, dict):
            # Обрабатываем словарь
            return {k: self._postprocess_value(v) for k, v in value.items()}
        elif isinstance(value, BaseModel):
            # Для BaseModel вызываем его постобработку
            value._postprocess_object()
            return value
        else:
            return value

    def _postprocess_model(self, model):
        """Постобработка модели BaseModel"""
        if model is None:
            return None
        model._postprocess_object()
        return model
    
    def to_dict(self, clear_skey=True) -> dict:
        def _ser(obj):
            if isinstance(obj, BaseModel): return obj.to_dict(clear_skey)
            if isinstance(obj, list): return [_ser(x) for x in obj]
            if isinstance(obj, dict): return {k: _ser(v) for k, v in obj.items()}
            return obj
        return {k: _ser(v) for k, v in self.__dict__.items() if not (clear_skey and k == SKEY_NAME)}

    def __getitem__(self, key):
        if isinstance(key,int):
            return self[key]
        return getattr(self, key)

    def __repr__(self):
        attrs = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items() if k != SKEY_NAME)
        return f"{self.__class__.__name__}({attrs})"

setattr(BaseModel,SKEY_NAME,'')

class Operator(StrEnum):
    """Операторы сравнения"""
    EQ = '=='
    """Равно: =="""
    NE = '!='
    """Не равно: !="""
    GT = '>'
    """Больше: >"""
    LT = '<'
    """Меньше: <"""
    GTE = '>='
    """Больше или равно: >="""
    LTE = '<='
    """Меньше или равно: <="""
    LIKE = 'LIKE'
    """Частичное совпадение"""
    IN = 'IN'
    """Вхождение в список"""
    BETWEEN = 'BETWEEN'
    """проверка диапазона [min, max], включая значения min,max - в любом порядке"""
    REGEX = 'REGEX'
    """поиск по регулярному выражению"""

class Where:
    """Поиск по условиям"""

    def __init__(self, key: str, value: Any, op: Operator = Operator.EQ):
        self.key, self.value, self.op = key, value, op

    def check(self, item: Any) -> bool:
        # Извлекаем значение (атрибут или ключ словаря)
        target = getattr(item, self.key, item.get(self.key) if isinstance(item, dict) else None)

        # Вспомогательная функция для сравнения с приведением типов
        def compare(v1, v2, op_override=None):
            operation = op_override or self.op
            try:
                if operation == Operator.EQ: return v1 == v2
                if operation == Operator.NE: return v1 != v2
                if operation == Operator.GT: return v1 > v2
                if operation == Operator.LT: return v1 < v2
                if operation == Operator.GTE: return v1 >= v2
                if operation == Operator.LTE: return v1 <= v2
                return False
            except TypeError:
                try: 
                    # Пробуем привести v2 к типу v1 и повторить
                    return compare(v1, type(v1)(v2), op_override=operation)
                except: return False

        match self.op:
            case Operator.LIKE: 
                return str(self.value).lower() in str(target).lower()
            case Operator.IN: 
                return target in self.value
            case Operator.REGEX: 
                return bool(re.search(str(self.value), str(target)))
            case Operator.BETWEEN:
                if not isinstance(self.value, (list, tuple)) or len(self.value) != 2:
                    return False
                # Возвращаем True, если target >= v_min И target <= v_max
                return compare(target, min(map(float, self.value)), Operator.GTE) and compare(target, max(map(float, self.value)), Operator.LTE)
            case _: 
                return compare(target, self.value)

class SmartData(Generic[T]):
    """
    Универсальный контейнер для интеллектуальной обработки и типизации сложных JSON-структур.
    
    АЛГОРИТМ РАБОТЫ:
    ------------------------------------------------------------------------
    1. ГЛОБАЛЬНАЯ ПРЕДОБРАБОТКА (_global_preprocess):
       - Полностью распаковывает ВСЕ матрешки [[[x]]] -> [x]
       - Останавливается, когда встречает список с несколькими элементами
    
    2. ГОРИЗОНТАЛЬНОЕ СХЛОПЫВАНИЕ (_extract_valid_dicts):
       - Ищет ВСЕ словари с валидными ключами (имена переменных Python)
       - Схлопывает словари с невалидными ключами в плоские списки
       - Формирует _items - плоский список кандидатов для кастинга
    
    3. ВЕРТИКАЛЬНАЯ ОБРАБОТКА (_process_dict_fields / _process_list_field):
       - Обрабатывает каждое поле каждого словаря в _items
       - Для полей-списков: распаковывает матрешки, анализирует типы
       - Для полей-словарей: рекурсивно углубляется
    
    4. ПРИВЕДЕНИЕ К ТИПУ (_cast_to_target_type):
       - Пытается преобразовать все элементы к target_type
       - Достаточно одного общего поля для преобразования
       - Если не получается - оставляет как есть
    """

    def __init__(self, data: Any, target_type: type[T] = Any):
        """
        Инициализация SmartData.
        
        Args:
            data: Входные данные (любого типа)
            target_type: Целевой тип для преобразования элементов
        """
        self._target_type = target_type
        self._items: List[T] = []
        self._cache = {}
        self._processed_ids = set()
        self._max_depth = 100

        if data is None:
            return

        try:
            # ЭТАП 1: Глобальная предобработка - распаковка всех матрешек
            data = self._global_preprocess(data)
            
            # ЭТАП 2: Подготовка входных данных (кортежи -> списки и т.д.)
            prepared = self._prepare_input(data)
            
            # ЭТАП 3: Горизонтальное схлопывание - извлекаем все словари с валидными ключами
            self._items = self._extract_valid_dicts(prepared, [])
            
            # ЭТАП 4: Вертикальная обработка - обрабатываем поля каждого словаря
            for i, item in enumerate(self._items):
                if isinstance(item, dict):
                    self._items[i] = self._process_dict_fields(item, [])
            
            # ЭТАП 5: Приведение к целевому типу
            if target_type is not None and target_type is not Any:
                self._cast_to_target_type()
            else:
                self._determine_target_type()
                
        except Exception as e:
            print(f"Error in SmartData init: {e}")
            import traceback
            traceback.print_exc()
            self._items = self._emergency_flatten(data)

    # ------------------------------------------------------------------------
    # ЭТАП 1: ГЛОБАЛЬНАЯ ПРЕДОБРАБОТКА - РАСПАКОВКА МАТРЕШЕК
    # ------------------------------------------------------------------------

    def _global_preprocess(self, data: Any) -> Any:
        """
        Глобальная предобработка данных.
        ПОЛНОСТЬЮ распаковывает ВСЕ матрешки, пока не встретит список с несколькими элементами.
        
        Правило: пока список содержит ровно 1 элемент и этот элемент - список,
                заменяем внешний список на внутренний.
        
        Примеры:
        [[[x]]] -> [x]
        [[[x], [[y], [z]]]] -> [[x], [[y], [z]]]
        [[[[x], [y]], [z]]] -> [[[x], [y]], [z]]
        
        Args:
            data: Входные данные
            
        Returns:
            Данные с полностью распакованными матрешками
        """
        if isinstance(data, list):
            # Полная распаковка матрешек на текущем уровне
            while len(data) == 1 and isinstance(data[0], list):
                data = data[0]
            
            # Рекурсивная обработка каждого элемента
            result = []
            for item in data:
                result.append(self._global_preprocess(item))
            return result
        
        elif isinstance(data, dict):
            result = {}
            for k, v in data.items():
                result[k] = self._global_preprocess(v)
            return result
        
        else:
            return data

    # ------------------------------------------------------------------------
    # ЭТАП 2: ПОДГОТОВКА ВХОДНЫХ ДАННЫХ
    # ------------------------------------------------------------------------

    def _prepare_input(self, data: Any) -> Any:
        """
        Подготавливает входные данные к обработке.
        
        Преобразования:
        - Кортежи -> списки
        - SmartData -> список элементов
        - Пользовательские объекты -> словарь атрибутов
        
        Args:
            data: Входные данные
            
        Returns:
            Подготовленные данные
        """
        if isinstance(data, tuple):
            return list(data)
        if isinstance(data, SmartData):
            return data.to_list()
        if hasattr(data, '__dict__') and not isinstance(data, (BaseModel, dict)):
            return {k: v for k, v in data.__dict__.items() if not k.startswith('_')}
        return data

    # ------------------------------------------------------------------------
    # ЭТАП 3: ГОРИЗОНТАЛЬНОЕ СХЛОПЫВАНИЕ - ПОИСК СЛОВАРЕЙ С ВАЛИДНЫМИ КЛЮЧАМИ
    # ------------------------------------------------------------------------

    def _extract_valid_dicts(self, data: Any, path: List[tuple]) -> List[dict]:
        """
        ГОРИЗОНТАЛЬНОЕ СХЛОПЫВАНИЕ.
        Рекурсивно обходит структуру и извлекает ВСЕ словари с валидными ключами.
        
        Правила:
        1. Словари с валидными ключами -> кандидаты в _items
        2. Словари с невалидными ключами и ВСЕМИ значениями-словарями -> схлопнуть в список
        3. Списки -> рекурсивно обойти
        4. Остальное -> игнорировать
        
        Args:
            data: Текущие данные
            path: Текущий путь для построения extern_skey
            
        Returns:
            Плоский список словарей с валидными ключами
        """
        result = []

        # 1. ОБРАБОТКА СПИСКОВ
        if isinstance(data, list):
            for idx, item in enumerate(data):
                new_path = path + [('idx', str(idx))]
                result.extend(self._extract_valid_dicts(item, new_path))
            return result

        # 2. ОБРАБОТКА СЛОВАРЕЙ
        if isinstance(data, dict):
            str_keys = [str(k) for k in data.keys()]
            all_keys_valid = all(self._is_valid_field_name(k) for k in str_keys)
            
            # 2.1 СЛОВАРЬ С ВАЛИДНЫМИ КЛЮЧАМИ - КАНДИДАТ!
            if all_keys_valid:
                dict_copy = data.copy()
                skey = self._build_extern_skey(path)
                if skey:
                    dict_copy[SKEY_NAME] = skey
                result.append(dict_copy)
                return result
            
            # 2.2 ВСЕ ЗНАЧЕНИЯ - СЛОВАРИ -> СХЛОПЫВАЕМ В ПЛОСКИЙ СПИСОК!
            all_values_are_dicts = all(isinstance(v, dict) for v in data.values())
            
            if all_values_are_dicts:
                sorted_items = self._sort_dict_items(data)
                for key, value in sorted_items:
                    key_str = str(key)
                    key_type = 'field' if self._is_valid_field_name(key_str) else 'col'
                    new_path = path + [(key_type, key_str)]
                    
                    dicts = self._extract_valid_dicts(value, new_path)
                    result.extend(dicts)  # ВСЕГДА В ОДИН ПЛОСКИЙ СПИСОК!
                return result
            
            # 2.3 ЕСТЬ НЕ-СЛОВАРИ - просто обходим значения
            for key, value in data.items():
                key_str = str(key)
                key_type = 'field' if self._is_valid_field_name(key_str) else 'col'
                new_path = path + [(key_type, key_str)]
                result.extend(self._extract_valid_dicts(value, new_path))
            return result

        return result

    # ------------------------------------------------------------------------
    # ЭТАП 4: ВЕРТИКАЛЬНАЯ ОБРАБОТКА - ОБРАБОТКА ПОЛЕЙ СЛОВАРЕЙ
    # ------------------------------------------------------------------------

    def _process_dict_fields(self, data: dict, path: List[tuple]) -> dict:
        """
        ВЕРТИКАЛЬНАЯ ОБРАБОТКА ПОЛЕЙ СЛОВАРЯ.
        Рекурсивно обрабатывает каждое поле словаря.
        
        Args:
            data: Словарь для обработки
            path: Текущий путь для extern_skey
            
        Returns:
            Обработанный словарь
        """
        result = data.copy()
        
        for key, value in result.items():
            if key == SKEY_NAME:
                continue
            
            key_str = str(key)
            key_type = 'field' if self._is_valid_field_name(key_str) else 'col'
            new_path = path + [(key_type, key_str)]
            
            # 1. ПОЛЕ - СЛОВАРЬ
            if isinstance(value, dict):
                if any(self._is_valid_field_name(str(k)) for k in value.keys()):
                    # Уже валидный словарь
                    result[key] = self._process_dict_fields(value, new_path)
                else:
                    # Невалидный - ищем валидные внутри
                    valid_dicts = self._extract_valid_dicts(value, new_path)
                    if valid_dicts:
                        if len(valid_dicts) == 1:
                            result[key] = self._process_dict_fields(valid_dicts[0], new_path)
                        else:
                            result[key] = [
                                self._process_dict_fields(vd, new_path + [('idx', str(i))])
                                for i, vd in enumerate(valid_dicts)
                            ]
                    else:
                        result[key] = self._process_dict_fields(value, new_path)
            
            # 2. ПОЛЕ - СПИСОК
            elif isinstance(value, list):
                result[key] = self._process_list_field(value, new_path)
            
            # 3. ПРОСТЫЕ ТИПЫ - ничего не делаем
            else:
                pass
        
        return result

    def _process_list_field(self, data: list, path: List[tuple]) -> list:
        """
        ВЕРТИКАЛЬНАЯ ОБРАБОТКА ПОЛЯ-СПИСКА.
        
        АЛГОРИТМ:
        1. Распаковываем матрешки до конца
        2. Анализируем типы элементов на текущем уровне
        3. В зависимости от типов применяем соответствующую обработку
        
        Правила обработки:
        - Все элементы - простые типы -> вернуть как есть
        - Все элементы - словари -> обработать каждый словарь
        - Все элементы - списки:
          * Если внутри только простые типы -> обработать каждый подсписок отдельно
          * Если внутри есть словари -> распрямить в плоский список
        - Смешанные типы -> обработать каждый элемент индивидуально
        
        Args:
            data: Список для обработки
            path: Текущий путь для extern_skey
            
        Returns:
            Обработанный список
        """
        # ШАГ 1: Полная распаковка матрешек
        while len(data) == 1 and isinstance(data[0], list):
            data = data[0]
        
        # ШАГ 2: Анализ типов элементов на текущем уровне
        all_primitives = True
        all_dicts = True
        all_lists = True
        
        for item in data:
            if not self._is_primitive(item):
                all_primitives = False
            if not isinstance(item, dict):
                all_dicts = False
            if not isinstance(item, list):
                all_lists = False
        
        # ШАГ 3: Все элементы - простые типы
        if all_primitives:
            return data
        
        # ШАГ 4: Все элементы - словари
        if all_dicts:
            result = []
            for idx, item in enumerate(data):
                new_path = path + [('idx', str(idx))]
                
                if any(self._is_valid_field_name(str(k)) for k in item.keys()):
                    # Валидный словарь
                    result.append(self._process_dict_fields(item, new_path))
                else:
                    # Невалидный - ищем валидные внутри
                    valid_dicts = self._extract_valid_dicts(item, new_path)
                    if valid_dicts:
                        if len(valid_dicts) == 1:
                            result.append(self._process_dict_fields(valid_dicts[0], new_path))
                        else:
                            for j, vd in enumerate(valid_dicts):
                                vd_path = new_path + [('idx', str(j))]
                                result.append(self._process_dict_fields(vd, vd_path))
                    else:
                        result.append(self._process_dict_fields(item, new_path))
            return result
        
        # ШАГ 5: Все элементы - списки
        if all_lists:
            # Проверяем, что внутри этих списков
            inner_all_primitives = True
            for sublist in data:
                for item in sublist:
                    if not self._is_primitive(item):
                        inner_all_primitives = False
                        break
                if not inner_all_primitives:
                    break
            
            if inner_all_primitives:
                # Внутри только простые типы - обрабатываем каждый подсписок отдельно
                result = []
                for idx, sublist in enumerate(data):
                    new_path = path + [('idx', str(idx))]
                    result.append(self._process_list_field(sublist, new_path))
                return result
            else:
                # Внутри есть словари - распрямляем в плоский список
                result = []
                for sublist in data:
                    processed = self._process_list_field(sublist, path)
                    if isinstance(processed, list):
                        result.extend(processed)
                    else:
                        result.append(processed)
                return result
        
        # ШАГ 6: Смешанный случай - обрабатываем каждый элемент индивидуально
        result = []
        for idx, item in enumerate(data):
            new_path = path + [('idx', str(idx))]
            
            if isinstance(item, dict):
                if any(self._is_valid_field_name(str(k)) for k in item.keys()):
                    result.append(self._process_dict_fields(item, new_path))
                else:
                    valid_dicts = self._extract_valid_dicts(item, new_path)
                    if valid_dicts:
                        if len(valid_dicts) == 1:
                            result.append(self._process_dict_fields(valid_dicts[0], new_path))
                        else:
                            for vd in valid_dicts:
                                result.append(self._process_dict_fields(vd, new_path))
                    else:
                        result.append(self._process_dict_fields(item, new_path))
            
            elif isinstance(item, list):
                sub_result = self._process_list_field(item, new_path)
                if isinstance(sub_result, list):
                    result.extend(sub_result)
                else:
                    result.append(sub_result)
            
            else:
                result.append(item)
        
        return result

    # ------------------------------------------------------------------------
    # ЭТАП 5: ПРИВЕДЕНИЕ К ЦЕЛЕВОМУ ТИПУ
    # ------------------------------------------------------------------------

    def _cast_to_target_type(self):
        """
        Приводит ВСЕ элементы _items к target_type.
        Преобразование происходит только если ВСЕ элементы можно преобразовать.
        Достаточно одного общего поля для определения возможности преобразования.
        """
        if not self._items or self._target_type is Any:
            return
        
        # Проверяем, может элементы уже нужного типа?
        all_already_casted = all(isinstance(item, self._target_type) for item in self._items)
        if all_already_casted:
            return
        
        new_items = []
        castable = True
        
        for item in self._items:
            if isinstance(item, self._target_type):
                new_items.append(item)
                continue
            
            if isinstance(item, dict):
                obj = self._create_object(item, self._target_type)
                if obj is not None:
                    new_items.append(obj)
                else:
                    castable = False
                    break
            else:
                castable = False
                break
        
        if castable:
            self._items = new_items

    def _create_object(self, data: dict, target_type: type) -> Optional[T]:
        """
        Создает объект target_type из словаря.
        
        Args:
            data: Словарь с данными
            target_type: Целевой тип
            
        Returns:
            Объект target_type или None, если создание невозможно
        """
        if not isinstance(data, dict):
            return None
        
        if not self._is_target_dict(data, target_type):
            return None
        
        try:
            skey = data.pop(SKEY_NAME, None)
            obj = target_type(**data)
            if skey is not None:
                setattr(obj, SKEY_NAME, skey)
            return obj
        except Exception as e:
            print(f"Error creating object {target_type.__name__}: {e}")
            return None

    def _is_target_dict(self, data: dict, target_type: type) -> bool:
        """
        Проверяет, можно ли создать объект target_type из словаря.
        Достаточно наличия ХОТЯ БЫ ОДНОГО общего поля.
        
        Args:
            data: Словарь для проверки
            target_type: Целевой тип
            
        Returns:
            True если словарь подходит для создания объекта
        """
        if not isinstance(data, dict) or not isinstance(target_type, type):
            return False
        
        target_fields = set(self._get_model_fields(target_type))
        if not target_fields:
            return False
        
        data_keys = set(data.keys())
        if SKEY_NAME in data_keys:
            data_keys.remove(SKEY_NAME)
        
        return bool(target_fields.intersection(data_keys))

    def _get_model_fields(self, model_type: type) -> List[str]:
        """
        Получает список полей модели.
        
        Args:
            model_type: Тип модели
            
        Returns:
            Список имен полей
        """
        if model_type in self._cache:
            return self._cache[model_type]
        
        fields_list = []
        try:
            if hasattr(model_type, '__annotations__'):
                fields_list = list(model_type.__annotations__.keys())
            elif is_dataclass(model_type):
                fields_list = [f.name for f in fields(model_type)]
            elif hasattr(model_type, '__base__') and model_type.__base__ == BaseModel:
                fields_list = [k for k in model_type.__dict__.keys()
                               if not k.startswith('_') and k != SKEY_NAME]
        except Exception:
            pass
        
        self._cache[model_type] = fields_list
        return fields_list

    def _determine_target_type(self):
        """
        Определяет результирующий тип элементов _items.
        Если все элементы одного типа - устанавливаем этот тип.
        Иначе оставляем Any.
        """
        if not self._items:
            return
        
        types = set(type(item) for item in self._items)
        
        if len(types) == 1:
            item_type = next(iter(types))
            if issubclass(item_type, BaseModel):
                self._target_type = item_type
        else:
            self._target_type = Any

    # ------------------------------------------------------------------------
    # ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    # ------------------------------------------------------------------------

    def _is_valid_field_name(self, name: str) -> bool:
        """
        Проверяет, является ли имя валидным идентификатором Python.
        
        Args:
            name: Имя для проверки
            
        Returns:
            True если имя может быть именем переменной Python
        """
        if not name or not isinstance(name, str):
            return False
        return bool(re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name))

    def _is_primitive(self, value: Any) -> bool:
        """
        Проверяет, является ли значение простым типом.
        
        Args:
            value: Значение для проверки
            
        Returns:
            True для None, int, float, str, bool
        """
        return value is None or isinstance(value, (int, float, str, bool))

    def _sort_dict_items(self, data: dict) -> List[tuple]:
        """
        Сортирует элементы словаря: сначала числовые ключи, затем строковые.
        
        Args:
            data: Словарь для сортировки
            
        Returns:
            Отсортированный список пар (ключ, значение)
        """
        items = list(data.items())
        numeric = []
        other = []
        
        for key, val in items:
            s = str(key)
            if s.isdigit():
                numeric.append((int(s), key, val))
            else:
                other.append((s, key, val))
        
        numeric.sort(key=lambda x: x[0])
        other.sort(key=lambda x: x[0])
        
        result = []
        for _, k, v in numeric:
            result.append((k, v))
        for _, k, v in other:
            result.append((k, v))
        
        return result

    def _build_extern_skey(self, path: List[tuple]) -> str:
        """
        Строит строку extern_skey из пути.
        
        Args:
            path: Список кортежей (тип, значение)
            
        Returns:
            Строка вида "col:1/field:name/idx:0"
        """
        if not path:
            return ''
        
        parts = []
        for typ, val in path:
            if typ in ('col', 'idx', 'field'):
                parts.append(f"{typ}:{val}")
        
        return '/'.join(parts)

    def _emergency_flatten(self, data: Any) -> List[Any]:
        """
        Аварийное преобразование в плоский список (только для ошибок).
        
        Args:
            data: Данные для преобразования
            
        Returns:
            Плоский список
        """
        result = []
        
        def _extract(obj):
            if obj is None:
                return
            if isinstance(obj, (list, tuple)):
                for item in obj:
                    _extract(item)
            elif isinstance(obj, dict):
                if any(self._is_valid_field_name(str(k)) for k in obj.keys()):
                    result.append(obj)
                for value in obj.values():
                    if isinstance(value, (list, tuple, dict)):
                        _extract(value)
            else:
                result.append(obj)
        
        _extract(data)
        return result

    # ------------------------------------------------------------------------
    # FLATTEN - ПРЕОБРАЗОВАНИЕ В ПЛОСКИЙ СПИСОК
    # ------------------------------------------------------------------------

    def flatten(self) -> 'SmartData[Any]':
        """
        Преобразует структуру в плоский список словарей с валидными ключами.
        Используется для отладки и специальных случаев.
        
        Returns:
            Новый SmartData с плоским списком
        """
        flattened = []
        
        def _extract(obj):
            if isinstance(obj, (list, tuple, SmartData)):
                for item in obj:
                    _extract(item)
            elif isinstance(obj, dict):
                if any(self._is_valid_field_name(str(k)) for k in obj.keys()):
                    flattened.append(obj)
                for value in obj.values():
                    if isinstance(value, (list, tuple, dict, SmartData)):
                        _extract(value)
            elif isinstance(obj, BaseModel):
                flattened.append(obj)
                for value in obj.__dict__.values():
                    if isinstance(value, (list, tuple, dict, SmartData, BaseModel)):
                        _extract(value)
            else:
                flattened.append(obj)
        
        for item in self._items:
            _extract(item)
        
        new = self._derived(flattened)
        new._target_type = Any
        return new

    # ------------------------------------------------------------------------
    # FLUENT INTERFACE - МЕТОДЫ ДЛЯ ЦЕПОЧЕК ВЫЗОВОВ
    # ------------------------------------------------------------------------

    def _derived(self, items: List[T]) -> 'SmartData[T]':
        """
        Создаёт новый экземпляр с теми же настройками.
        
        Args:
            items: Новый список элементов
            
        Returns:
            Новый SmartData
        """
        new = self.__class__.__new__(self.__class__)
        new._target_type = self._target_type
        new._items = items
        new._cache = {}
        new._processed_ids = set()
        new._max_depth = self._max_depth
        return new

    def filter(self, *conditions: Where, join: Literal['AND', 'OR'] = 'AND') -> 'SmartData[T]':
        """
        Фильтрует объекты по условиям Where.
        
        Args:
            *conditions: Условия фильтрации
            join: 'AND' или 'OR'
            
        Returns:
            Новый SmartData с отфильтрованными элементами
        """
        filtered = [item for item in self._items
                    if (join == 'AND' and all(c.check(item) for c in conditions)) or
                       (join == 'OR' and any(c.check(item) for c in conditions))]
        return self._derived(filtered)

    def where(self, key: Any, value: Any = None, op: Operator = Operator.EQ, is_partial: bool = None) -> 'SmartData[T]':
        """
        Фильтрует объекты по простому условию.
        
        Args:
            key: Ключ для поиска
            value: Значение для сравнения
            op: Оператор сравнения
            is_partial: Частичное совпадение для строк
            
        Returns:
            Новый SmartData с отфильтрованными элементами
        """
        if is_partial is None:
            is_partial = (op == Operator.LIKE)
        
        condition = Where(key, value, op)
        filtered = [item for item in self._items if condition.check(item)]
        return self._derived(filtered)

    def sort(self, key: Callable[[T], Any] = None, reverse: bool = False) -> 'SmartData[T]':
        """
        Сортирует объекты.
        
        Args:
            key: Функция для получения ключа сортировки
            reverse: Обратный порядок
            
        Returns:
            Новый SmartData с отсортированными элементами
        """
        return self._derived(sorted(self._items, key=key, reverse=reverse))

    def limit(self, count: int) -> 'SmartData[T]':
        """
        Ограничивает количество объектов.
        
        Args:
            count: Максимальное количество
            
        Returns:
            Новый SmartData с первыми count элементами
        """
        return self._derived(self._items[:count])

    def skip(self, count: int) -> 'SmartData[T]':
        """
        Пропускает указанное количество объектов.
        
        Args:
            count: Количество пропускаемых элементов
            
        Returns:
            Новый SmartData без первых count элементов
        """
        return self._derived(self._items[count:])

    def map(self, func: Callable[[T], Any]) -> List[Any]:
        """
        Применяет функцию к каждому объекту.
        
        Args:
            func: Функция для применения
            
        Returns:
            Список результатов
        """
        return [func(item) for item in self._items]

    def group_by(self, key_func: Callable[[T], Any]) -> Dict[Any, 'SmartData[T]']:
        """
        Группирует объекты по ключу.
        
        Args:
            key_func: Функция для получения ключа группы
            
        Returns:
            Словарь: ключ -> SmartData с элементами группы
        """
        groups = {}
        for item in self._items:
            key = key_func(item)
            if key not in groups:
                groups[key] = self._derived([])
            groups[key]._items.append(item)
        return groups

    def unique(self, key_func: Callable[[T], Any] = None) -> 'SmartData[T]':
        """
        Возвращает уникальные объекты.
        
        Args:
            key_func: Функция для получения ключа уникальности
            
        Returns:
            Новый SmartData с уникальными элементами
        """
        seen = set()
        unique_items = []
        for item in self._items:
            key = key_func(item) if key_func else item
            if key not in seen:
                seen.add(key)
                unique_items.append(item)
        return self._derived(unique_items)

    # ------------------------------------------------------------------------
    # МЕТОДЫ ПОИСКА
    # ------------------------------------------------------------------------

    def _all_objects(self, data: Any) -> Generator[Any, None, None]:
        """
        Генератор для рекурсивного обхода всех объектов в структуре.
        
        Args:
            data: Данные для обхода
            
        Yields:
            Все объекты в структуре
        """
        seen = set()

        def _recursive_walk(obj):
            obj_id = id(obj)
            if obj_id in seen:
                return
            seen.add(obj_id)

            if obj is None:
                return

            yield obj

            if isinstance(obj, BaseModel):
                for value in obj.__dict__.values():
                    if value is not None:
                        yield from _recursive_walk(value)
            elif isinstance(obj, dict):
                for value in obj.values():
                    if value is not None:
                        yield from _recursive_walk(value)
            elif isinstance(obj, (list, tuple, set)):
                for item in obj:
                    if item is not None:
                        yield from _recursive_walk(item)

        yield from _recursive_walk(data)

    def find_all(self, key: Any = None, value: Any = None, is_partial: bool = False) -> List[T]:
        """
        Ищет объекты по ключу и значению.
        
        Args:
            key: Ключ или список ключей
            value: Значение или список значений
            is_partial: Частичное совпадение для строк
            
        Returns:
            Список найденных объектов
        """
        results = []
        seen = set()

        keys, values = self._normalize_query_params(key, value)

        for item in self._items:
            for obj in self._all_objects(item):
                obj_id = id(obj)
                if obj_id in seen:
                    continue
                if self._match_complex_query(obj, keys, values, is_partial):
                    results.append(item)
                    seen.add(obj_id)
                    break

        return results

    def exists(self, key: Any = None, value: Any = None, is_partial: bool = False) -> bool:
        """
        Проверяет существование объекта с указанными критериями.
        
        Args:
            key: Ключ или список ключей
            value: Значение или список значений
            is_partial: Частичное совпадение для строк
            
        Returns:
            True если хотя бы один объект найден
        """
        if key is None and value is None:
            return len(self._items) > 0

        try:
            keys, values = self._normalize_query_params(key, value)
        except ValueError:
            return False

        for item in self._items:
            for obj in self._all_objects(item):
                if self._match_complex_query(obj, keys, values, is_partial):
                    return True

        return False

    def _normalize_query_params(self, key: Any, value: Any) -> tuple:
        """
        Нормализует параметры запроса в единый формат (списки).
        
        Args:
            key: Ключ или список ключей
            value: Значение или список значений
            
        Returns:
            Кортеж (список_ключей, список_значений)
        """
        if key is None and value is None:
            return None, None

        if isinstance(key, list) and isinstance(value, list):
            if len(key) != len(value):
                raise ValueError(f"Length of keys ({len(key)}) must match length of values ({len(value)})")
            return key, value

        if isinstance(key, list):
            return key, [value] * len(key)

        if isinstance(value, list):
            return [key] * len(value), value

        return [key], [value]

    def _get_object_key_value_pairs(self, obj: Any) -> List[tuple]:
        """
        Извлекает все пары ключ-значение из объекта.
        
        Args:
            obj: Объект для анализа
            
        Returns:
            Список пар (ключ, значение)
        """
        pairs = []

        if isinstance(obj, BaseModel):
            for attr_name in dir(obj):
                if not attr_name.startswith('_') and attr_name != SKEY_NAME:
                    try:
                        attr_value = getattr(obj, attr_name)
                        pairs.append((attr_name, attr_value))
                    except Exception:
                        continue

            if hasattr(obj, '__dict__'):
                for attr_name, attr_value in obj.__dict__.items():
                    if not attr_name.startswith('_') and attr_name != SKEY_NAME:
                        if (attr_name, attr_value) not in pairs:
                            pairs.append((attr_name, attr_value))

        elif isinstance(obj, dict):
            for dict_key, dict_value in obj.items():
                if dict_key != SKEY_NAME:
                    pairs.append((dict_key, dict_value))
        else:
            try:
                if hasattr(obj, '__dict__'):
                    for attr_name, attr_value in obj.__dict__.items():
                        if not attr_name.startswith('_'):
                            pairs.append((attr_name, attr_value))
            except Exception:
                pass

        return pairs

    def _match_complex_query(self, obj: Any, keys: Optional[List], values: Optional[List], is_partial: bool) -> bool:
        """
        Проверяет соответствие объекта сложному запросу.
        
        Args:
            obj: Объект для проверки
            keys: Список ключей
            values: Список значений
            is_partial: Частичное совпадение
            
        Returns:
            True если объект соответствует запросу
        """
        if keys is None and values is None:
            return True

        obj_pairs = self._get_object_key_value_pairs(obj)

        if not obj_pairs:
            return keys is None and values is None

        for key, value in zip(keys, values):
            matched = False

            for obj_key, obj_value in obj_pairs:
                if key is not None and obj_key != key:
                    continue

                if value is None:
                    if obj_value is None:
                        matched = True
                        break
                elif is_partial and isinstance(value, str) and isinstance(obj_value, str):
                    if value.lower() in obj_value.lower():
                        matched = True
                        break
                elif obj_value == value:
                    matched = True
                    break

            if not matched:
                return False

        return True

    # ------------------------------------------------------------------------
    # СТАТИСТИЧЕСКИЕ МЕТОДЫ
    # ------------------------------------------------------------------------

    def count(self) -> int:
        """Возвращает количество элементов."""
        return len(self._items)

    def first(self) -> Union[T, None]:
        """Возвращает первый элемент или None."""
        return self._items[0] if self._items else None

    def last(self) -> Union[T, None]:
        """Возвращает последний элемент или None."""
        return self._items[-1] if self._items else None

    def min(self, key_func: Callable[[T], Any] = None) -> Union[T, Any, None]:
        """
        Возвращает минимальный элемент или значение.
        
        Args:
            key_func: Функция для получения сравниваемого значения
            
        Returns:
            Минимальный элемент или None
        """
        if not self._items:
            return None
        if key_func:
            return min(self._items, key=key_func)
        return min(self._items)

    def max(self, key_func: Callable[[T], Any] = None) -> Union[T, Any, None]:
        """
        Возвращает максимальный элемент или значение.
        
        Args:
            key_func: Функция для получения сравниваемого значения
            
        Returns:
            Максимальный элемент или None
        """
        if not self._items:
            return None
        if key_func:
            return max(self._items, key=key_func)
        return max(self._items)

    def sum(self, key_func: Callable[[T], Any]) -> Any:
        """
        Суммирует значения, полученные от key_func для каждого элемента.
        
        Args:
            key_func: Функция для получения суммируемого значения
            
        Returns:
            Сумма значений
        """
        return sum(key_func(item) for item in self._items)

    def avg(self, key_func: Callable[[T], Any]) -> float:
        """
        Вычисляет среднее арифметическое значений.
        
        Args:
            key_func: Функция для получения значения
            
        Returns:
            Среднее значение
        """
        return sum(key_func(item) for item in self._items) / len(self._items) if self._items else 0.0

    # ------------------------------------------------------------------------
    # МАССОВЫЕ ОПЕРАЦИИ
    # ------------------------------------------------------------------------

    def __setattr__(self, name: str, value: Any) -> None:
        """
        Перехватывает установку атрибутов для массового обновления.
        Если имя не служебное - устанавливает атрибут всем элементам.
        """
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            for item in self._items:
                if isinstance(item, BaseModel):
                    setattr(item, name, value)
                elif isinstance(item, dict):
                    item[name] = value

    def update_all(self, **kwargs) -> 'SmartData[T]':
        """
        Обновляет все объекты указанными значениями.
        
        Args:
            **kwargs: Пары ключ-значение для обновления
            
        Returns:
            Тот же объект (для цепочек вызовов)
        """
        for item in self._items:
            if isinstance(item, BaseModel):
                for key, val in kwargs.items():
                    setattr(item, key, val)
            elif isinstance(item, dict):
                item.update(kwargs)
        return self

    # ------------------------------------------------------------------------
    # СЕРИАЛИЗАЦИЯ
    # ------------------------------------------------------------------------

    def to_list(self) -> List[T]:
        """
        Возвращает плоский список элементов.
        
        Returns:
            Копия списка _items
        """
        return self._items.copy()

    def to_dict(self, clear_skey: bool = True) -> dict:
        """
        Преобразует в словарь, восстанавливая исходную структуру по extern_skey.
        
        Args:
            clear_skey: Удалить extern_skey из результата
            
        Returns:
            Словарь с восстановленной структурой
        """
        result = {}

        # Группируем элементы по skey
        items_by_skey = {}
        for item in self._items:
            if isinstance(item, BaseModel):
                skey = getattr(item, SKEY_NAME, "")
            elif isinstance(item, dict):
                skey = item.get(SKEY_NAME, "")
            else:
                continue
            
            if skey:
                items_by_skey[skey] = item

        # Восстанавливаем по skey (сортировка для правильной вложенности)
        for skey in sorted(items_by_skey.keys(), key=lambda x: (x.count('/'), x)):
            item = items_by_skey[skey]
            self._restore_by_skey(result, item, skey, clear_skey)

        return result

    def _restore_by_skey(self, result: dict, item: Any, skey: str, clear_skey: bool):
        """
        Восстанавливает элемент по extern_skey.
        
        Args:
            result: Результирующий словарь
            item: Элемент для восстановления
            skey: Путь для восстановления
            clear_skey: Удалить skey из результата
        """
        parts = skey.split('/')
        current = result

        for i, part in enumerate(parts):
            if ':' not in part:
                continue

            key_type, key_value = part.split(':', 1)
            is_last = i == len(parts) - 1

            if key_type in ("col", "idx", "field"):
                if key_value not in current:
                    current[key_value] = {} if not is_last else None

                if is_last:
                    item_dict = self._item_to_dict(item, clear_skey)
                    current[key_value] = item_dict
                else:
                    current = current[key_value]

    def _item_to_dict(self, item: Any, clear_skey: bool) -> Any:
        """
        Преобразует элемент в словарь рекурсивно.
        
        Args:
            item: Элемент для преобразования
            clear_skey: Удалить skey из результата
            
        Returns:
            Словарное представление элемента
        """
        if isinstance(item, BaseModel):
            return item.to_dict(clear_skey)
        elif isinstance(item, dict):
            result = {}
            for k, v in item.items():
                if clear_skey and k == SKEY_NAME:
                    continue
                result[k] = self._item_to_dict(v, clear_skey)
            return result
        elif isinstance(item, list):
            return [self._item_to_dict(x, clear_skey) for x in item]
        else:
            return item

    def to_file(self, filename: str, format: Literal['json', 'pkl', 'gz'] = None, clear_skey: bool = False) -> None:
        """
        Сохраняет данные в файл.
        
        Args:
            filename: Имя файла
            format: Формат ('json', 'pkl', 'gz')
            clear_skey: Удалить extern_skey
        """
        if format is None:
            if filename.endswith('.json'):
                format = 'json'
            elif filename.endswith('.pkl'):
                format = 'pkl'
            elif filename.endswith('.gz'):
                format = 'gz'
            else:
                format = 'json'

        Path(filename).parent.mkdir(parents=True, exist_ok=True)

        if format == 'json':
            data = self.to_dict(clear_skey)
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        elif format == 'pkl':
            with open(filename, 'wb') as f:
                pickle.dump(self, f)
        elif format == 'gz':
            with gzip.open(filename, 'wb') as f:
                pickle.dump(self, f)
        else:
            raise ValueError(f"Unsupported format: {format}")

    @classmethod
    def from_file(cls, filename: str, target_type: type[T] = Any) -> 'SmartData[T]':
        """
        Загружает данные из файла.
        
        Args:
            filename: Имя файла
            target_type: Целевой тип
            
        Returns:
            Загруженный SmartData
        """
        if not os.path.exists(filename):
            raise FileNotFoundError(f"File not found: {filename}")

        if filename.endswith('.json'):
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
        elif filename.endswith('.pkl'):
            with open(filename, 'rb') as f:
                return pickle.load(f)
        elif filename.endswith('.gz'):
            with gzip.open(filename, 'rb') as f:
                return pickle.load(f)
        else:
            raise ValueError(f"Unsupported file format: {filename}")

        return cls(data, target_type)

    # ------------------------------------------------------------------------
    # МАГИЧЕСКИЕ МЕТОДЫ
    # ------------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index) -> Union[T, List[T]]:
        if isinstance(index, slice):
            return self._derived(self._items[index])
        return self._items[index]

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    def __contains__(self, item: T) -> bool:
        return item in self._items

    def __add__(self, other: 'SmartData[T]') -> 'SmartData[T]':
        if not isinstance(other, SmartData):
            raise TypeError(f"Cannot add SmartData and {type(other).__name__}")
        return self._derived(self._items + other._items)

    def __iadd__(self, other: 'SmartData[T]') -> 'SmartData[T]':
        if not isinstance(other, SmartData):
            raise TypeError(f"Cannot add SmartData and {type(other).__name__}")
        self._items.extend(other._items)
        return self

    def __bool__(self) -> bool:
        return bool(self._items)

    def __repr__(self) -> str:
        type_name = self._target_type.__name__ if hasattr(self._target_type, '__name__') else str(self._target_type)
        preview = []
        for i, item in enumerate(self._items[:3]):
            if isinstance(item, BaseModel):
                preview.append(f"{type(item).__name__}(...)")
            elif isinstance(item, dict):
                keys = list(item.keys())[:2]
                preview.append(f"{{{', '.join(keys)}{', ...' if len(item) > 2 else ''}}}")
            else:
                preview.append(repr(item)[:30])
        if len(self._items) > 3:
            preview.append(f"... (+{len(self._items) - 3})")
        return f"SmartData[{type_name}](count={len(self._items)}, items=[{', '.join(preview)}])"

    # def __repr__(self) -> str:
    #     return f"SmartData[{self._target_type}](count={len(self._items)}, items={self._items})"


def api_method(model: Type[T] = Any) -> ApiRet:
    """--- Декоратор для методов API ---"""

    def decorator(func: Callable):
        @wraps(func)
        def wrapper(self, *args, **kwargs):

            prepared_kwargs = func(self, *args, **kwargs)
            final_params = prepared_kwargs if isinstance(prepared_kwargs, dict) else kwargs

            try:
                api_action = getattr(getattr(self._api, self._category), func.__name__)
            except AttributeError as e:
                raise WorkerNetException(f'Ошибка API запроса: {e}')

            try:
                response = api_action(**final_params)
                if model is Any or self._is_ret_origin: return response
            except WorkerNetException as e:
                if model is Any: raise e
                return None

            if isinstance(response, list) or self._category == 'module': return SmartData(response,model)
            if not isinstance(response, dict): return response

            result = response['result'] == 'OK' if response.get('result', None) else None

            try: data = response.get(next(key for key in response if str(key).lower() not in ('result','error')), None)
            except: data = None

            return SmartData(data, model) if data is not None else result

        return wrapper
    return decorator



@smart_model
class GeoPoint(BaseModel):
    """Географические координаты"""

    lat: float
    lon: float

    def __init__(self, *args, **kwargs):
        # Если передан один позиционный аргумент (список или кортеж)
        if len(args) == 1 and isinstance(args[0], (list, tuple)):
            lat, lon = args[0]
            super().__init__(lat=lat,lon=lon)
        # Если переданы стандартные именованные аргументы или позиционные (lat, lon)
        else:
            super().__init__(*args, **kwargs)

    def __str__(self):
        return f"{self.lat},{self.lon}"
