## simpleworkernet
Высокопроизводительный Python клиент для REST API системы WorkerNet с интеллектуальной системой трансформации и типизации сложных JSON структур.

## 🌟 Особенности

### 🚀 SmartData Framework
SmartData — это специализированный SDK-компонент для обработки API-ответов сервера WorkerNet. Он превращает сырые, динамически типизированные JSON-данные сервера в строго типизированные объекты Python с поддержкой глубокого поиска и автоматической трансформации коллекций.

- Автоматическое приведение типов согласно аннотациям Python
- Сохранение метаданных о пути извлечения данных
- Глубокий поиск по любым уровням вложенности
- Fluent-интерфейс для фильтрации, сортировки и агрегации
- Поддержка экспорта/импорта (JSON, Pickle, Gzip)

### 🔧 BaseModel Engine
**BaseModel** - мощная система рекурсивного кастинга типов:
- Автоматическое преобразование данных в типизированные объекты
- Поддержка Union, Optional, List, вложенных моделей
- Постобработка и схлопывание избыточных структур
- Сериализация/десериализация с сохранением типов

## 📦 Установка
```bash
pip install simpleworkernet

```

## 🎨 Пример

```python
from simpleworkernet import WorkerNetClient, Where, Operator

wn = WorkerNetClient(host='my_wokernet_host', apikey='my_secret_apikey')

# Получаем каталог кабелей
catalog_cables = wn.Fiber.catalog_cables_get()
# Для получения оригинального ответа от сервера: категория - lower
# catalog_cables = wn.fiber.catalog_cables_get()

# Составление условий запроса:
cond = Where('cable_line_type_id',5), Where('fiber_count',[4,16],Operator.BETWEEN), Where('model','ОКА',Operator.LIKE)

# Cписок объектов Fiber.Catalog_cables_get
filtered_cables = catalog_cables.find_query(*cond)

```

## ✒️ Автор
 - [Андрей Литвинов](https://t.me/busy4beaver)