from dataclasses import dataclass
from ..common import BaseCategory, BaseModel, BaseItem, vStr, ApiRetResult, ApiRetSData, api_method, smart_model

class Advertising(BaseCategory):
    """Рекламные кампании"""

    @api_method(bool)
    def add_customer(self, *, advert_id: int, customer_id: int) -> ApiRetResult: 
        """Добавление рекламной кампании абоненту

            Обязательные параметры:
                advert_id - id рекламной кампании
                customer_id - id абонента
        """
        ...

    @smart_model
    class Get(BaseItem):
        date_start: vStr
        date_finish: vStr

    @api_method(Get)
    def get(self, *, id: int | str =None) -> ApiRetSData[Get]: 
        """Список рекламных кампаний

            Обязательные параметры:
                нет
            Дополнительные параметры:
                id - id кампаний (можно через запятую)
        """
        ...
    
    @api_method(bool)
    def remove_customer(self, *, advert_id, customer_id) -> ApiRetResult: 
        """Исключение абонента из рекламной кампании

            Обязательные параметры:
                advert_id - id рекламной кампании
                customer_id - id абонента
        """
        ...
