from dataclasses import dataclass
from ..common import BaseCategory, BaseItem, ApiRetSData, api_method, smart_model

class Billing(BaseCategory):
    """Биллинги"""

    @api_method(BaseItem)
    def get(self) -> ApiRetSData[BaseItem]:
        """Информация о биллингах

            Обязательные параметры:
                нет
        """
        ...
    
    # @api_method(None)
    # def refresh_date_update(self, *, id: int) -> ApiRet:
    #     """Обновление даты синхронизации данных с биллингом

    #         Обязательные параметры:
    #             id - ID биллинга
    #     """
    #     ...

