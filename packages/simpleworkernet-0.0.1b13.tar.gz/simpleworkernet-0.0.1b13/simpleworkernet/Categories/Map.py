from typing import List
from ..common import BaseCategory, BaseModel, BaseItem, GeoPoint, vStr, ApiRetResult, ApiRetSData, api_method, smart_model

class Map(BaseCategory):
    """Действие с картами покрытия"""

    @api_method(str)
    def add_label(self, *, lat: float, lon: float, text: str) -> ApiRetSData[str]:
        """Добавление надписи

            Обязательные параметры:
                lat - широта
                lon - долгота
                text - текст надписи
        """
        ...

    @api_method(str)
    def add_poly(self, *, coord: str, name: str, color: str = None) -> ApiRetSData[str]:
        """Добавление полигона

            Обязательные параметры:
                coord - координаты (через запятую)
                name - наименование
            Необязательные параметры:
                color - HTML-цвет полигона
        """
        ...
    
    @smart_model
    class Check_entry_point_in_polygon(BaseItem):
        color: vStr
        coordinates: List[GeoPoint]
        coordinates_center: GeoPoint

    @api_method(Check_entry_point_in_polygon)
    def check_entry_point_in_polygon(self, *, lat: float, lon: float) -> ApiRetSData[Check_entry_point_in_polygon]:
        """Список полигонов в которые входит точка

            Обязательные параметры:
                lat - широта точки
                lon - долгота точки
        """
        ...

    @api_method(bool)
    def edit_label(self, *, id: str, lat: float = None, lon: float = None, text: str = None) -> ApiRetResult:
        """Изменение надписи

            Обязательные параметры:
                id - id объекта
            Необязательные параметры:
                lat - широта
                lon - долгота
                text - текст надписи
        """
        ...

    @api_method(bool)
    def edit_poly(self, *, id: str, coord: str = None, name: str = None, color: str = None) -> ApiRetResult:
        """Изменение полигона

            Обязательные параметры:
                id - id объекта
            Необязательные параметры:
                coord - координаты (через запятую)
                name - наименование
                color - HTML-цвет полигона
        """
        ...
    
    @smart_model
    class Get(BaseItem):
        @smart_model
        class Center(BaseModel):
            lat: float
            lon: float
            zoom: int
        center: Center

    @api_method(Get)
    def get(self, *, id: int | str = None) -> ApiRetSData[Get]:
        """Список объектов

            Необязательные параметры:
                id - перечень ID объектов (через запятую)
        """
        ...

    @smart_model
    class Get_poly(BaseItem):
        color: vStr
        coordinates: List[GeoPoint]
        coordinates_center: GeoPoint

    @api_method(Get_poly)
    def get_poly(self, *, id: str = None) -> ApiRetSData[Get_poly]:
        """Список полигонов

            Необязательные параметры:
                id - перечень ID объектов (через запятую)
        """
        ...

    @api_method()
    def map_object_facilities_inside(self, *, id: str) -> dict[str, List[int]]:
        """Получение списка объектов, что находятся внутри объекта на карте (например внутри полигона)

            Обязательные параметры:
                id - id объекта
        """
        ...
    
    @api_method(bool)
    def map_object_mark_add(self, *, id: str, mark_id: int) -> ApiRetResult:
        """Добавление метки на объекте на карте

            Обязательные параметры:
                id - id объекта
                mark_id - id метки
        """
        ...
    
    @api_method(bool)
    def map_object_mark_delete(self, *, id: str, mark_id: int) -> ApiRetResult:
        """Удаление метки с объекта на карте

            Обязательные параметры:
                id - id объекта
                mark_id - id метки
        """
        ...
