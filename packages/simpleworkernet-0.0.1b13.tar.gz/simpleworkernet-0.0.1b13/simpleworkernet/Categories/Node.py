from typing import List, Dict, Any, Literal
from enum import IntEnum
from ..common import BaseCategory, BaseModel, BaseItem, vStr, vFlag, ApiRetSData, ApiRetResult, api_method, smart_model, additional_data

class Node(BaseCategory):
    """Объекты инфраструктуры (узлы связи, муфты, опоры, колодцы)"""

    class In_type_id(IntEnum):
        """ID типов объектов инфраструктуры"""
        splice_closure = 1
        """муфта"""
        pole = 2
        """опора"""
        manhole = 3
        """колодец"""
        node = 4
        """узел связи"""

    @api_method(int)
    def add(self, *, 
            type: int | In_type_id, 
            city_id: int = None, 
            custom_icon_id: int = None, 
            comment: str = None, 
            date_add: str = None, 
            entrance: int = None, 
            house_id: int = None, 
            inventory_number: str = None, 
            is_planned: vFlag = None, 
            level: str = None, 
            level_id: int = None, 
            location: str = None, 
            node_parent_id: int = None, 
            number: str = None, 
            owner_id: int = None, 
            coordinates: str = None) -> ApiRetSData[int]:
        """Описание: Добавление объекта

            Обязательные параметры:
                type - Тип объекта
            Дополнительные параметры:
                city_id - ID населенного пункта размещения объекта
                custom_icon_id - ID индивидуального значка на карте
                comment - заметки
                date_add - дата добавления
                entrance - номер подъезда
                house_id - ID дома размещения объекта
                inventory_number - инв.номер объекта
                is_planned - Флаг - объект только запланирован
                level - номер этажа
                level_id - ID этажа/уровня (из структуры здания)
                location - размещение объекта (текстовое)
                node_parent_id - ID родительского объекта
                number - номер объекта
                owner_id - ID собственника
                coordinates - координаты в текстовом виде через запятую (пример: 47.839628,35.140553)
        """
        ...

    @api_method(bool)
    def add_mark(self, *, node_id: int, mark_id: int) -> ApiRetResult:
        """Добавление метки

            Обязательные параметры:
                node_id - id объекта
                mark_id - id метки
        """
        ...

    @api_method()
    def change_custom_icon(self, *, id: int, custom_icon_id: int):
        """Изменение собственного значка на карте

            Обязательные параметры:
                id - id объекта
                custom_icon_id - id значка
        """
        ...

    @api_method()
    def delete(self, *, id: int):
        """Удаление сооружения связи

            Обязательные параметры:
                id - id объекта
        """
        ...

    @api_method()
    def delete_mark(self, *, node_id: int, mark_id: int):
        """Снятие метки

            Обязательные параметры:
                node_id - id объекта
                mark_id - id метки
        """
        ...
    
    @api_method()
    def edit(self, *, 
             id: int, 
             city_id: int = None, 
             custom_icon_id: int = None, 
             comment: str = None, 
             coordinates: str = None, 
             date_add: str = None, 
             entrance: int = None, 
             house_id: int = None, 
             inventory_number: str = None, 
             is_planned: vFlag = None, 
             level: str = None, 
             level_id: int = None, 
             location: str = None, 
             node_parent_id: int = None, 
             number: str = None, 
             owner_id: int = None):
        """Редактирование объекта

            Обязательные параметры:
                id - ID объекта
            Необязательные параметры:
                city_id - ID населенного пункта размещения объекта
                custom_icon_id - ID индивидуального значка на карте
                comment - заметки
                coordinates - координаты в текстовом виде через запятую (пример: 47.839628,35.140553)
                date_add - дата добавления
                entrance - номер подъезда
                house_id - ID дома размещения объекта
                inventory_number - инв.номер объекта
                is_planned - Флаг - объект только запланирован
                level - номер этажа
                level_id - ID этажа/уровня (из структуры здания)
                location - размещение объекта (текстовое)
                node_parent_id - ID родительского объекта
                number - номер объекта
                owner_id - ID собственника
        """
        ...

    @api_method()
    def get(self, *, address_id: int = None, entrance_number: int = None, id: int | str = None, mark_id: int = None, object_type: int | In_type_id = None, parent_id: int = None):
        """Список объектов

            Обязательные параметры:
                нет
            Необязательные параметры:
                address_id - id адресной единицы (можно через запятую)
                entrance_number - номер подъезда
                id - id объектов (можно через запятую)
                mark_id - id метки
                object_type - тип объекта
                parent_id - id родительского объекта (можно через запятую)
        """
        ...
        
    @api_method(BaseItem)
    def get_icon_list(self, *, id: int | str = None) -> ApiRetSData[BaseItem]:
        """Список собственных значков для объектов

            Необязательные параметры:
                id - перечень ID объектов (через запятую)
        """
        ...
    
    @api_method()
    def get_id(self, *, data_type: Literal['comment', 'number'] | str, data_value: str, is_entry: vFlag = None, type_id: int | In_type_id):
        """Получение ID объекта по входящим данным

            Обязательные параметры:
                data_type - тип данных, которые проверяем (возможные значения: comment, number, additional_dataX (вместо X - id дополнительного поля))
                data_value - значение
            Необязательные параметры:
                is_entry - флаг - проверять ли в т.ч. совпадение по части вхождения в строку
                type_id - тип объекта
        """
        ...

    @api_method
    def get_id_by_coord(self, *, lat: float, lon: float, type: int | In_type_id = None, range: int = None):
        """Получение ID ближайшего объекта по указанным координатам

            Обязательные параметры:
                lat - широта
                lon - долгота
            Необязательные параметры:
                type - тип объекта
                range - радиус в метрах, в пределах которого отобразить объекты
        """
        ...

    @api_method()
    def get_redevelopment_scheme(self, *, id: int):
        """Список схем перепланировки для сооружения связи

            Обязательные параметры:
                id - id сооружения связи
        """
        ...

    @api_method()
    def get_relation_customers(self, *, id: int):
        """Получение информации о зависимых абонентах

            Обязательные параметры:
                id - id сооружения связи
        """
        ...

    @api_method()
    def get_scheme(self, *, id: int):
        """Получение схемы коммутации

            Обязательные параметры:
                id - id сооружения связи
        """
        ...

    @api_method()
    def get_type_list(self):
        """Получение список типов сооружения связи"""
        ...