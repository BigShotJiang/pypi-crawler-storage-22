import requests
from urllib.parse import unquote_plus
from .Categories import *

class WorkerNetException(BaseException):
    def __init__(self, message: str, code: int = None):
        super().__init__(f"{message}{f" response.status_code={code}" if code else ''}")

class WorkerNetClient:
    """API Клиент WorkerNet"""

    max_len_url = 2048

    def __init__(
        self, 
        host: str, 
        apikey: str, 
        protocol: Literal['http','https'] = 'https', 
        port: int = 443, 
        apiscr: str = 'api.php', 
        session: requests.Session = None
    ):
        self._url = f'{protocol}://{host}:{port}/{apiscr}'
        self._apikey = apikey
        self._session = session

        self.Address = Address(self)
        """Действие с адресами"""
        self.Attach = Attach(self)
        """Действие с прикрепляемыми файлами"""
        self.Additional_data = Additional_data(self)
        """Действие с дополнительными полями/данными"""
        self.Advertising = Advertising(self)
        """Рекламные кампании"""
        self.Billing = Billing(self)
        """Биллинги"""
        self.Cable_route = Cable_route(self)
        """Кабельные трассы и каналы"""
        self.Call = Call(self)
        """Звонки"""
        self.Commutation = Commutation(self)
        """Коммутация объектов"""
        self.Cross = Cross(self)
        """ODF/Кроссы"""
        self.Customer = Customer(self)
        """Действия с абонентами"""
        self.Cwdm = Cwdm(self)
        """CWDM"""
        self.Device = Device(self)
        """Оборудование"""
        self.Employee = Employee(self)
        """Сотрудники"""
        self.Fiber = Fiber(self)
        """Кабельные линии"""
        self.Gps = Gps(self)
        """GPS трекеры"""
        self.Inventory = Inventory(self)
        """Действия с ТМЦ и складом"""
        self.Key = Key(self)
        """Ключи"""
        self.Map = Map(self)
        """Действие с картами покрытия"""
        self.Module = Module(self)
        """Внешние запросы от модулей"""
        self.Node = Node(self)
        """Объекты инфраструктуры (узлы связи, муфты, опоры, колодцы)"""

    def _exec(self, action, **kwargs) -> dict | Any:
        def encode_str(data):
            """Особая обработка слеша"""
            if isinstance(data, dict):
                return {k: encode_str(v) for k, v in data.items()}
            elif isinstance(data, list):
                return [encode_str(v) for v in data]
            elif isinstance(data, tuple):
                return tuple(encode_str(v) for v in data)
            elif isinstance(data, str):
                return data.replace('/','&#047;').replace('\\','&#092;')
            return data

        params = {'key': self._apikey,
                  'cat': self.category,
                  'action': action}
        
        if self.category == 'module': params["request"] = params.pop("action")

        params = params | encode_str(kwargs)

        close_after_request = self.session()

        prepared = requests.Request(method='GET',url=self._url, params=params).prepare()

        try:
            if len(prepared.url) > WorkerNetClient.max_len_url:
                response = self._session.post(self._url, params=params)
            else: 
                response = self._session.send(prepared)
        except Exception as e:
            raise WorkerNetException(f"Ошибка при отправке запроса: {e}")

        if close_after_request: self.closeSession()

        try:
            content = response.json()
        except:
            content = response.content

        if response.status_code != 200:
            raise WorkerNetException(f"{content.get("error", None) or content.get("Error", "Неизвестная ошибка")} | URL<{unquote_plus(response.url.replace(self._apikey,"SECRET_API_KEY"))}>", response.status_code)

        return content

    def is_online(self, timeout = 5) -> bool:
        try:
            requests.get(self._url, timeout=timeout)
            return True
        except requests.RequestException:
            return False

    def session(self) -> bool:
        if not self._session:
            self._session = requests.Session()
            return True
        return False
    
    def closeSession(self):
        if self._session:
            self._session.close()
            self._session = None

    def __getattr__(self, cat):
        self.category = cat
        class WorkerNetDynamicCategory:
            def __init__(self, api, cat):
                self.api:WorkerNetClient = api
                self.api.category = cat
            def __getattr__(self, action):
                def _action(**kwargs):
                    clean_kwargs = {k: v for k, v in kwargs.items() if v is not None}
                    return self.api._exec(action, **clean_kwargs)
                return _action
        return WorkerNetDynamicCategory(self, cat)
    
    def __enter__(self):
        self.session()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.closeSession()

    def __del__(self):
        self.closeSession()
    
    def __repr__(self):
        return f"WorkerNetClient(URL={self._url}, session={str(self._session)})"
