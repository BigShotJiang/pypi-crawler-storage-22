from dataclasses import dataclass
from ..common import BaseCategory, BaseModel, ApiRetSData, api_method, smart_model

class Billing(BaseCategory):
    """Биллинги"""

    @smart_model
    class Get(BaseModel):
        id:int
        name:str
    
    @api_method(Get)
    def get(self) -> ApiRetSData[Get]:
        """Информация о биллингах

            Обязательные параметры:
                нет
        """
        ...
    
    # @api_method(None)
    # def refresh_date_update(self, *, id: int) -> ApiRet:
    #     """Обновление даты синхронизации данных с биллингом

    #         Обязательные параметры:
    #             id - ID биллинга
    #     """
    #     ...

