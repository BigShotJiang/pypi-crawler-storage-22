import types, json, pickle, gzip, re, os, html, inspect
from typing import TypeVar, Generic, List, Iterable, Generator, Iterator, Dict, Any, Union, Literal, Type, Optional, Callable, get_type_hints, get_origin, get_args, dataclass_transform
from dataclasses import dataclass, fields, is_dataclass
from urllib.parse import unquote_plus
from functools import wraps
from enum import IntFlag, StrEnum
from pathlib import Path

SKEY_NAME = 'extern_skey'

@dataclass_transform()
def smart_model(cls=None, **kwargs):
    params = {"init": False, "repr": False}
    params.update(kwargs)
    if cls is None:
        return lambda c: dataclass(c, **params)
    return dataclass(cls, **params)

class SmartData:...
class BaseModel:...

T = TypeVar('T',bound=BaseModel)

type ApiRetId = int | str | None
type ApiRetResult = bool | None
type ApiRetSData[T] = SmartData[T] | T | List[T] | None
type ApiRet = ApiRetSData[T] | T | List[T] | bool | int | Dict | None

class WorkerNetException(BaseException):
    def __init__(self, message: str, code: Optional[int] = None):
        super().__init__(f"{message}{f" response.status_code={code}" if code else ''}")
        self.message = message
        self.code = code

class vStr(str):
    def __new__(cls, value):
        return super().__new__(cls, unquote_plus(string = html.unescape(str(value)), encoding = "utf-8"))

class vFlag(IntFlag):
    v1 = 1
    v0 = 0

additional_field = lambda x: f"additional_field_{x}"

class BaseCategory:
    _is_ret_origin = False
    def __init__(self, api: Any):
        self._api = api
        self._category = self.__class__.__name__.lower()
        self._is_ret_origin = False
    @staticmethod
    def return_original_response(is_ret_origin: bool = True):
        BaseCategory._is_ret_origin = is_ret_origin

class BaseModel:
    extern_skey: str = ''
    
    def __init__(self, *args, **kwargs):

        hints = get_type_hints(self.__class__)

        def is_base_model_type(t):
            try:
                return isinstance(t, type) and issubclass(t, BaseModel)
            except: return False

        def deep_cast(target_t, val):
            if target_t is Any or target_t is type(None) or val is None:
                return val
            
            origin = get_origin(target_t)
            args = get_args(target_t)

            # 1. Обработка Union (Optional)
            if origin is Union or (hasattr(types, "UnionType") and isinstance(target_t, types.UnionType)):
                for t in args:
                    if t is type(None): continue
                    try: return deep_cast(t, val)
                    except: continue
                return val

            # 2. Обработка СПИСКОВ (List/list)
            if origin is list or target_t is list or target_t is List:
                inner_t = args[0] if args else Any
                
                if isinstance(val, list):
                    # Если внутри списка лежат структуры (словари/списки), обрабатываем элементы рекурсивно
                    if len(val) > 0 and isinstance(val[0], (dict, list)):
                        result = [deep_cast(inner_t, x) for x in val]
                    else:
                        # ПРОВЕРКА НА МАТРЁШКУ:
                        try:
                            # Если inner_t — это класс (напр. GeoPoint), который может принять список целиком
                            if is_dataclass(inner_t) or is_base_model_type(inner_t):
                                # Если создание объекта из всего списка прошло успешно - возвращаем [Obj]
                                return [deep_cast(inner_t, val)]
                        except:
                            pass
                        
                        # Стандартный путь: просто возвращаем список, прогнав элементы через deep_cast
                        result = [deep_cast(inner_t, x) for x in val]
                    
                    # Постобработка: схлопывание матрешек в получившемся списке
                    result = self._collapse_list(result)
                    return result
                
                # Если на вход пришло НЕ список, оборачиваем в список (согласно List в аннотации)
                return [deep_cast(inner_t, val)]

            # 3. Обработка ТИПОВ (Классы, Датаклассы)
            if isinstance(target_t, type):
                if isinstance(val, dict):
                    # Если наследник BaseModel - передаем словарь как один аргумент
                    if is_base_model_type(target_t):
                        result = target_t(**val)
                        # Постобработка для вложенных BaseModel объектов
                        return self._postprocess_model(result)
                    # Если обычный датакласс - распаковываем
                    if is_dataclass(target_t):
                        result = target_t(**val)
                        return result
                
                if isinstance(val, list):
                    try: 
                        # Пытаемся создать объект из списка напрямую (напр. Point([1,2]))
                        result = target_t(val)
                        # Постобработка для вложенных BaseModel объектов
                        if is_base_model_type(target_t):
                            return self._postprocess_model(result)
                        return result
                    except: 
                        # Если не вышло - считаем, что это список таких объектов
                        result = [deep_cast(target_t, x) for x in val]
                        # Постобработка: схлопывание матрешек
                        result = self._collapse_list(result)
                        return result

            # 4. Базовое приведение
            try:
                if isinstance(val, target_t): return val
                return target_t(val)
            except:
                return val

        for name, value in kwargs.items():
            if name in hints:
                setattr(self, name, deep_cast(hints[name], value))
            else:
                setattr(self, name, value)
        
        # Постобработка всего объекта после инициализации
        self._postprocess_object()

    def _postprocess_object(self):
        """Постобработка объекта: рекурсивное схлопывание матрешек"""
        if not hasattr(self, '__dict__'):
            return
        
        for key, value in self.__dict__.items():
            if key.startswith('_'):
                continue
            setattr(self, key, self._postprocess_value(value))

    def _postprocess_value(self, value):
        """Рекурсивная постобработка значения"""
        if isinstance(value, list):
            # Обрабатываем список
            result = []
            for item in value:
                result.append(self._postprocess_value(item))
            # Схлопываем матрешки в получившемся списке
            return self._collapse_list(result)
        elif isinstance(value, dict):
            # Обрабатываем словарь
            return {k: self._postprocess_value(v) for k, v in value.items()}
        elif isinstance(value, BaseModel):
            # Для BaseModel вызываем его постобработку
            value._postprocess_object()
            return value
        else:
            return value

    def _collapse_list(self, lst):
        """
        Рекурсивно схлопывает матрешки списков.
        Правило: если список содержит ровно один элемент и этот элемент - список,
        то заменяем исходный список на этот элемент.
        """
        if not isinstance(lst, list):
            return lst
        
        # Если список пустой, возвращаем как есть
        if len(lst) == 0:
            return lst
        
        # Рекурсивно обрабатываем все элементы списка
        processed = []
        for item in lst:
            processed.append(self._collapse_list(item))
        
        # Схлопываем если: список из 1 элемента И этот элемент - список
        while len(processed) == 1 and isinstance(processed[0], list):
            processed = processed[0]
            # Рекурсивно обрабатываем схлопнутый список
            processed = [self._collapse_list(item) for item in processed]
        
        return processed

    def _postprocess_model(self, model):
        """Постобработка модели BaseModel"""
        if model is None:
            return None
        model._postprocess_object()
        return model
    
    def to_dict(self, clear_skey=True) -> dict:
        def _ser(obj):
            if isinstance(obj, BaseModel): return obj.to_dict(clear_skey)
            if isinstance(obj, list): return [_ser(x) for x in obj]
            if isinstance(obj, dict): return {k: _ser(v) for k, v in obj.items()}
            return obj
        return {k: _ser(v) for k, v in self.__dict__.items() if not (clear_skey and k == SKEY_NAME)}

    def __getitem__(self, key):
        return getattr(self, key)

    def __repr__(self):
        attrs = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items() if k != SKEY_NAME)
        return f"{self.__class__.__name__}({attrs})"



class Operator(StrEnum):
    """Операторы сравнения"""
    EQ = '=='
    """Равно: =="""
    NE = '!='
    """Не равно: !="""
    GT = '>'
    """Больше: >"""
    LT = '<'
    """Меньше: <"""
    GTE = '>='
    """Больше или равно: >="""
    LTE = '<='
    """Меньше или равно: <="""
    LIKE = 'LIKE'
    """Частичное совпадение"""
    IN = 'IN'
    """Вхождение в список"""
    BETWEEN = 'BETWEEN'
    """проверка диапазона [min, max], включая значения min,max - в любом порядке"""
    REGEX = 'REGEX'
    """поиск по регулярному выражению"""

class Where:
    """Поиск по условиям"""

    def __init__(self, key: str, value: Any, op: Operator = Operator.EQ):
        self.key, self.value, self.op = key, value, op

    def check(self, item: Any) -> bool:
        # Извлекаем значение (атрибут или ключ словаря)
        target = getattr(item, self.key, item.get(self.key) if isinstance(item, dict) else None)

        # Вспомогательная функция для сравнения с приведением типов
        def compare(v1, v2, op_override=None):
            operation = op_override or self.op
            try:
                if operation == Operator.EQ: return v1 == v2
                if operation == Operator.NE: return v1 != v2
                if operation == Operator.GT: return v1 > v2
                if operation == Operator.LT: return v1 < v2
                if operation == Operator.GTE: return v1 >= v2
                if operation == Operator.LTE: return v1 <= v2
                return False
            except TypeError:
                try: 
                    # Пробуем привести v2 к типу v1 и повторить
                    return compare(v1, type(v1)(v2), op_override=operation)
                except: return False

        match self.op:
            case Operator.LIKE: 
                return str(self.value).lower() in str(target).lower()
            case Operator.IN: 
                return target in self.value
            case Operator.REGEX: 
                return bool(re.search(str(self.value), str(target)))
            case Operator.BETWEEN:
                if not isinstance(self.value, (list, tuple)) or len(self.value) != 2:
                    return False
                # Возвращаем True, если target >= v_min И target <= v_max
                return compare(target, min(map(float, self.value)), Operator.GTE) and compare(target, max(map(float, self.value)), Operator.LTE)
            case _: 
                return compare(target, self.value)


class SmartData(Generic[T]):
    """
    Универсальный контейнер для интеллектуальной обработки и типизации сложных JSON-структур.
    """
    
    def __init__(self, data: Any, target_type: type[T] = Any):
        self._target_type = target_type
        self._items: List[T] = []
        
        if data is not None:
  
            # Предварительная обработка данных
            processed_data = self._preprocess_data(data)

            # Определяем поля целевой модели
            self._model_fields = self._get_model_fields(target_type) if target_type != Any else None

            # Извлекаем объекты
            self._extract_objects(processed_data, [])
    
    def _preprocess_data(self, data: Any) -> Any:
        """Предварительная обработка данных"""
        if isinstance(data, dict):
            # ОСОБАЯ ОБРАБОТКА: если все ключи - числа (как строки), преобразуем в список
            if data and all(isinstance(k, str) and k.isdigit() for k in data.keys()):
                # Сортируем по ключам как числам и создаем список значений
                sorted_items = sorted(data.items(), key=lambda x: int(x[0]))
                return [self._preprocess_data(value) for _, value in sorted_items]
            
            # Стандартная обработка
            result = {}
            for key, value in data.items():
                result[key] = self._preprocess_data(value)
            return result
        
        elif isinstance(data, list):
            # Схлопываем матрешки
            if len(data) == 1 and isinstance(data[0], list):
                return self._preprocess_data(data[0])
            
            processed_items = []
            for item in data:
                processed = self._preprocess_data(item)
                # Если обработанный элемент список из одного элемента, берем его
                if isinstance(processed, list) and len(processed) == 1:
                    processed_items.append(processed[0])
                else:
                    processed_items.append(processed)
            
            return processed_items
        
        else:
            return data
    
    def _extract_objects(self, data: Any, path: List[tuple]) -> None:
        """Извлекает объекты target_type из данных"""
        
        # Если target_type == Any, добавляем сам data как элемент
        if self._target_type is Any:
            if data is not None:
                obj = self._add_extern_skey(data, path)
                self._add_item(obj, path)
            return
        
        # Если data уже является экземпляром target_type
        if isinstance(data, self._target_type):
            obj = self._add_extern_skey(data, path)
            self._add_item(obj, path)
            return
        
        # Если это словарь, проверяем, можно ли создать объект из него
        if isinstance(data, dict):
            # ПРОСТАЯ ЛОГИКА: если словарь содержит поля target_type, создаем объект
            should_create = False
            
            if self._model_fields:
                # Проверяем пересечение ключей словаря с полями модели
                dict_keys = set(data.keys())
                model_fields_set = set(self._model_fields)
                
                if dict_keys & model_fields_set:  # Есть общие ключи
                    should_create = True
            else:
                # Для Any создаем из любого непустого словаря
                should_create = len(data) > 0
            
            if should_create:
                try:
                    obj = self._create_object(data, path)
                    if obj is not None:
                        self._add_item(obj, path)
                        # Не идем глубже после создания объекта
                        return
                except Exception as e:
                    pass
            
            # Рекурсивно ищем в значениях
            for key, value in data.items():
                if value is None:
                    continue
                
                key_type = self._get_key_type(key)
                new_path = path + [(key_type, str(key))]
                self._extract_objects(value, new_path)
                
        elif isinstance(data, list):
            # Если список пустой или содержит None, пропускаем
            if not data:
                return
            
            # Обрабатываем каждый элемент списка
            for idx, item in enumerate(data):
                if item is None:
                    continue
                
                new_path = path + [('idx', str(idx))]
                self._extract_objects(item, new_path)
    
    def _create_object(self, data: Any, path: List[tuple]) -> Any:
        """Создает объект из данных"""
        
        if self._target_type is Any:
            return self._add_extern_skey(data, path)
        
        # Для моделей BaseModel
        if isinstance(self._target_type, type):
            # Подготавливаем данные с extern_skey
            prepared = {}
            skey = self._build_extern_skey(path)
            
            if isinstance(data, dict):
                prepared = data.copy()
                prepared[SKEY_NAME] = skey
            else:
                prepared = {SKEY_NAME: skey}
            
            try:
                # Здесь BaseModel.__init__ будет рекурсивно обрабатывать вложенные структуры
                return self._target_type(**prepared)
            except:
                # Возвращаем данные как есть с extern_skey
                return self._add_extern_skey(data, path)
        
        return data
    
    def _is_valid_field_name(self, name: str) -> bool:
        """Проверяет, является ли имя валидным именем поля"""
        if not name or not isinstance(name, str):
            return False
        return re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name) is not None
    
    
    def _can_create_object_from_dict(self, data: dict, path: List[tuple]) -> bool:
        """Проверяет, можно ли создать объект target_type из словаря"""
        
        if self._target_type is Any:
            return isinstance(data, dict) and len(data) > 0
        
        # Для моделей BaseModel проверяем наличие полей модели в данных
        if isinstance(self._target_type, type) and (
            hasattr(self._target_type, '__base__') and self._target_type.__base__ == BaseModel
        ) or is_dataclass(self._target_type):
            # Если у нас есть поля модели, проверяем их наличие в данных
            if self._model_fields:
                # Проверяем, есть ли хотя бы одно поле модели в данных
                for field in self._model_fields:
                    if field in data:
                        return True
                return False
            # Если полей модели нет (Any или неопределенный тип), создаем из любого словаря
            return True
        
        return False
    

    
    def _get_model_fields(self, model_type: type) -> List[str]:
        """Получает поля целевой модели"""
        if hasattr(model_type, '__annotations__'):
            return list(model_type.__annotations__.keys())
        elif is_dataclass(model_type):
            return [f.name for f in fields(model_type)]
        else:
            return []
    

    

    

    
    def _get_key_type(self, key: Any) -> str:
        """Определяет тип ключа для построения пути"""
        
        key_str = str(key)
        
        # Числовые ключи - коллекции
        if key_str.isdigit() or (key_str.startswith('-') and key_str[1:].isdigit()):
            return "col"
        
        # Невалидные имена полей
        if not self._is_valid_field_name(key_str):
            return "col"
        
        return "field"
    
    def _is_valid_field_name(self, name: str) -> bool:
        """Проверяет, является ли имя валидным именем поля"""
        if not name or not isinstance(name, str):
            return False
        return re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name) is not None
    
    def _add_extern_skey(self, data: Any, path: List[tuple]) -> Any:
        """Добавляет extern_skey к данным"""
        
        skey = self._build_extern_skey(path)
        if not skey:
            return data
        
        if isinstance(data, dict):
            result = data.copy()
            result[SKEY_NAME] = skey
            return result
        
        elif isinstance(data, BaseModel):
            if not hasattr(data, SKEY_NAME) or not getattr(data, SKEY_NAME):
                setattr(data, SKEY_NAME, skey)
            return data
        
        else:
            return data
    
    def _build_extern_skey(self, path: List[tuple]) -> str:
        """Строит строку extern_skey из пути"""
        if not path:
            return ""
        return "/".join(f"{k_type}:{k_value}" for k_type, k_value in path)
    
    def _add_item(self, item: Any, path: List[tuple]) -> None:
        """Добавляет элемент в _items"""
        self._items.append(item)
    
    # ============== ГЛУБОКИЙ ПОИСК ==============
    
    def _all_objects(self, data: Any) -> Generator[Any, None, None]:
        """Генератор для рекурсивного обхода всех объектов"""
        
        if isinstance(data, BaseModel):
            yield data
            for value in data.__dict__.values():
                if value is not None:
                    yield from self._all_objects(value)
                    
        elif isinstance(data, dict):
            for value in data.values():
                if value is not None:
                    yield from self._all_objects(value)
                    
        elif isinstance(data, list):
            for item in data:
                if item is not None:
                    yield from self._all_objects(item)
        
        elif data is not None:
            yield data

    def _match_object(self, obj: Any, key: Any, value: Any, is_partial: bool) -> bool:
        """Проверяет, соответствует ли объект критерию поиска с поддержкой списков ключей/значений"""
        
        # Вариант 1: ключ не указан - проверяем все ключи
        if key is None:
            return self._match_any_key(obj, value, is_partial)
        
        # Вариант 2: список ключей и одно значение - любой ключ из списка
        if isinstance(key, list) and not isinstance(value, list):
            return self._match_any_keys_with_value(obj, key, value, is_partial)
        
        # Вариант 3: один ключ и список значений - ключ должен совпасть с любым значением
        if not isinstance(key, list) and isinstance(value, list):
            return self._match_key_with_any_values(obj, key, value, is_partial)
        
        # Вариант 4: список ключей и список значений - попарное сравнение
        if isinstance(key, list) and isinstance(value, list):
            return self._match_keys_with_values(obj, key, value, is_partial)
        
        # Вариант 5: обычный поиск (один ключ, одно значение)
        return self._match_single_key_value(obj, key, value, is_partial)

    def _match_any_key(self, obj: Any, value: Any, is_partial: bool) -> bool:
        """Проверяет все ключи объекта на соответствие значению"""
        
        # Получаем все ключи объекта
        keys = self._get_object_keys(obj)
        
        # Если значение None - ищем ключи со значением None
        if value is None:
            for k in keys:
                target = self._get_value_from_object(obj, k)
                if target is None:
                    return True
            return False
        
        # Иначе ищем значение в любом ключе
        for k in keys:
            target = self._get_value_from_object(obj, k)
            if self._compare_values(target, value, is_partial):
                return True
        
        return False

    def _match_any_keys_with_value(self, obj: Any, keys: List[str], value: Any, is_partial: bool) -> bool:
        """Проверяет любой ключ из списка на соответствие значению"""
        
        if value is None:
            # Ищем любой ключ из списка со значением None
            for k in keys:
                target = self._get_value_from_object(obj, k)
                if target is None:
                    return True
            return False
        
        # Ищем значение в любом ключе из списка
        for k in keys:
            target = self._get_value_from_object(obj, k)
            if self._compare_values(target, value, is_partial):
                return True
        
        return False

    def _match_key_with_any_values(self, obj: Any, key: str, values: List[Any], is_partial: bool) -> bool:
        """Проверяет ключ на совпадение с любым значением из списка"""
        
        target = self._get_value_from_object(obj, key)
        
        if target is None:
            # Проверяем, есть ли None в списке значений
            return None in values
        
        # Для строкового поиска с is_partial
        if is_partial and isinstance(target, str):
            for val in values:
                if val is not None and isinstance(val, str) and val.lower() in target.lower():
                    return True
            return False
        
        # Обычное сравнение
        return target in values

    def _match_keys_with_values(self, obj: Any, keys: List[str], values: List[Any], is_partial: bool) -> bool:
        """Попарное сравнение ключей и значений"""
        
        if len(keys) != len(values):
            raise ValueError(f"Количество ключей ({len(keys)}) должно совпадать с количеством значений ({len(values)})")
        
        for k, v in zip(keys, values):
            target = self._get_value_from_object(obj, k)
            
            if v is None:
                if target is not None:
                    return False
            elif not self._compare_values(target, v, is_partial):
                return False
        
        return True

    def _match_single_key_value(self, obj: Any, key: str, value: Any, is_partial: bool) -> bool:
        """Проверяет одиночный ключ и значение"""
        
        target = self._get_value_from_object(obj, key)
        
        if value is None:
            return target is None
        
        if is_partial and isinstance(value, str) and isinstance(target, str):
            return value.lower() in target.lower()
        
        return target == value

    def _compare_values(self, target: Any, value: Any, is_partial: bool) -> bool:
        """Сравнивает значения с учетом типа и флага is_partial"""
        
        if target is None or value is None:
            return target == value
        
        if is_partial and isinstance(value, str) and isinstance(target, str):
            return value.lower() in target.lower()
        
        return target == value

    def _get_object_keys(self, obj: Any) -> List[str]:
        """Получает все ключи объекта"""
        
        if isinstance(obj, BaseModel):
            # Получаем все публичные атрибуты (не начинающиеся с _)
            return [k for k in obj.__dict__.keys() if not k.startswith('_')]
        elif isinstance(obj, dict):
            return list(obj.keys())
        else:
            return []

    def _get_value_from_object(self, obj: Any, key: str) -> Any:
        """Извлекает значение по ключу из объекта"""
        
        if isinstance(obj, (BaseModel, dict)):
            return obj.get(key) if isinstance(obj, dict) else getattr(obj, key, None)
        return None

    def find_all(self, key: Any = None, value: Any = None, is_partial: bool = False) -> List[T]:
        """Ищет объекты по ключу и значению с поддержкой списков"""
        
        results = []
        seen = set()
        
        for item in self._items:
            for obj in self._all_objects(item):
                obj_id = id(obj)
                if obj_id in seen:
                    continue
                
                if self._match_object(obj, key, value, is_partial):
                    results.append(item)
                    seen.add(obj_id)
                    break
        
        return results
    
    def find_query(self, *conditions: Where, join: Literal['AND', 'OR'] = 'AND') -> List[T]:
        """Фильтрует объекты по набору условий Where"""
        
        results = []
        for item in self._items:
            if join == 'AND':
                if all(condition.check(item) for condition in conditions):
                    results.append(item)
            else:
                if any(condition.check(item) for condition in conditions):
                    results.append(item)
        
        return results
    
    def find_extern(self, col: str = None, idx: str = None, val: str = None) -> List[T]:
        """Ищет объекты по метаданным пути в extern_skey"""
        
        results = []
        for item in self._items:
            skey = None
            if isinstance(item, BaseModel):
                skey = getattr(item, SKEY_NAME, "")
            elif isinstance(item, dict):
                skey = item.get(SKEY_NAME, "")
            
            if not skey:
                continue
            
            parts = skey.split('/')
            matches = True
            
            if col is not None:
                col_found = any(part.startswith(f"col:{col}") for part in parts)
                matches = matches and col_found
            
            if idx is not None:
                idx_found = any(part.startswith(f"idx:{idx}") for part in parts)
                matches = matches and idx_found
            
            if val is not None:
                val_found = any(part.startswith(f"field:{val}") for part in parts)
                matches = matches and val_found
            
            if matches:
                results.append(item)
        
        return results
    
    def where(self, key: str, value: Any, op: Operator = Operator.EQ) -> 'SmartData[T]':
        """Создает новый SmartData с отфильтрованными элементами"""
        return self.filter(Where(key, value, op))
    
    def first(self) -> Union[T, None]:
        """Возвращает первый элемент или None если список пуст"""
        return self._items[0] if self._items else None
    
    def last(self) -> Union[T, None]:
        """Возвращает последний элемент или None если список пуст"""
        return self._items[-1] if self._items else None
    
    # ============== ЭКСПОРТ И ИМПОРТ ==============
    
    def to_dict(self, clear_skey: bool = True) -> dict:
        """Преобразует в словарь, восстанавливая исходную структуру"""
        
        result = {}
        for item in self._items:
            skey = ""
            if isinstance(item, BaseModel):
                skey = getattr(item, SKEY_NAME, "")
            elif isinstance(item, dict):
                skey = item.get(SKEY_NAME, "")
            
            if skey:
                self._restore_by_skey(result, item, skey, clear_skey)
            else:
                if isinstance(item, BaseModel):
                    result.update(item.to_dict(clear_skey))
                elif isinstance(item, dict):
                    result.update(item)
        
        return result
    
    def _restore_by_skey(self, result: dict, item: Any, skey: str, clear_skey: bool):
        """Восстанавливает структуру по extern_skey"""
        
        parts = skey.split('/')
        current = result
        
        for i, part in enumerate(parts):
            if ':' not in part:
                continue
                
            key_type, key_value = part.split(':', 1)
            is_last = i == len(parts) - 1
            
            if key_type in ("col", "idx"):
                if key_value not in current:
                    current[key_value] = {} if not is_last else None
                
                if is_last:
                    current[key_value] = self._item_to_dict(item, clear_skey)
                else:
                    current = current[key_value]
            else:
                if is_last:
                    current[key_value] = self._item_to_dict(item, clear_skey)
                else:
                    if key_value not in current:
                        current[key_value] = {}
                    current = current[key_value]
    
    def _item_to_dict(self, item: Any, clear_skey: bool) -> Any:
        """Преобразует элемент в словарь"""
        
        if isinstance(item, BaseModel):
            return item.to_dict(clear_skey)
        elif isinstance(item, dict):
            result = {}
            for k, v in item.items():
                if clear_skey and k == SKEY_NAME:
                    continue
                result[k] = self._item_to_dict(v, clear_skey)
            return result
        elif isinstance(item, list):
            return [self._item_to_dict(x, clear_skey) for x in item]
        else:
            return item
    
    def to_list(self) -> List[T]:
        """Возвращает все объекты в виде списка"""
        return self._items.copy()
    
    def to_file(self, filename: str, format: Literal['json','pkl','gz'] = None, clear_skey: bool = False) -> None:
        """Сохраняет данные в файл"""
        
        if format is None:
            if filename.endswith('.json'):
                format = 'json'
            elif filename.endswith('.pkl'):
                format = 'pkl'
            elif filename.endswith('.gz'):
                format = 'gz'
            else:
                format = 'json'
        
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        
        if format == 'json':
            data = self.to_dict(clear_skey)
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        
        elif format == 'pkl':
            with open(filename, 'wb') as f:
                pickle.dump(self, f)
        
        elif format == 'gz':
            with gzip.open(filename, 'wb') as f:
                pickle.dump(self, f)
        
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    @classmethod
    def from_file(cls, filename: str, target_type: type[T] = Any) -> 'SmartData[T]':
        """Загружает данные из файла"""
        
        if not os.path.exists(filename):
            raise FileNotFoundError(f"File not found: {filename}")
        
        if filename.endswith('.json'):
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
        
        elif filename.endswith('.pkl'):
            with open(filename, 'rb') as f:
                return pickle.load(f)
        
        elif filename.endswith('.gz'):
            with gzip.open(filename, 'rb') as f:
                return pickle.load(f)
        
        else:
            raise ValueError(f"Unsupported file format: {filename}")
        
        return cls(data, target_type)
    
    # ============== FLUENT INTERFACE ==============
    
    def filter(self, *conditions: Where, join: Literal['AND', 'OR'] = 'AND') -> 'SmartData[T]':
        """Фильтрует объекты по условиям"""
        
        filtered_items = []
        for item in self._items:
            if join == 'AND':
                if all(condition.check(item) for condition in conditions):
                    filtered_items.append(item)
            else:
                if any(condition.check(item) for condition in conditions):
                    filtered_items.append(item)
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = self._target_type
        new_sd._items = filtered_items
        
        return new_sd
    
    def sort(self, key: Callable[[T], Any] = None, reverse: bool = False) -> 'SmartData[T]':
        """Сортирует объекты"""
        
        sorted_items = sorted(self._items, key=key, reverse=reverse)
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = self._target_type
        new_sd._items = sorted_items
        
        return new_sd
    
    def limit(self, count: int) -> 'SmartData[T]':
        """Ограничивает количество объектов"""
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = self._target_type
        new_sd._items = self._items[:count]
        
        return new_sd
    
    def skip(self, count: int) -> 'SmartData[T]':
        """Пропускает указанное количество объектов"""
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = self._target_type
        new_sd._items = self._items[count:]
        
        return new_sd
    
    def map(self, func: Callable[[T], Any]) -> List[Any]:
        """Применяет функцию к каждому объекту"""
        return [func(item) for item in self._items]
    
    def group_by(self, key_func: Callable[[T], Any]) -> Dict[Any, 'SmartData[T]']:
        """Группирует объекты по ключу"""
        
        groups = {}
        for item in self._items:
            key = key_func(item)
            if key not in groups:
                new_sd = self.__class__.__new__(self.__class__)
                new_sd._target_type = self._target_type
                new_sd._items = []
                groups[key] = new_sd
            groups[key]._items.append(item)
        
        return groups
    
    def unique(self, key_func: Callable[[T], Any] = None) -> 'SmartData[T]':
        """Возвращает уникальные объекты"""
        
        seen = set()
        unique_items = []
        
        for item in self._items:
            key = key_func(item) if key_func else item
            if key not in seen:
                seen.add(key)
                unique_items.append(item)
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = self._target_type
        new_sd._items = unique_items
        
        return new_sd
    
    # ============== СТАТИСТИЧЕСКИЕ МЕТОДЫ ==============
    
    def count(self) -> int:
        """Возвращает количество объектов"""
        return len(self._items)
    
    def min(self, key_func: Callable[[T], Any] = None) -> Union[T, Any, None]:
        """Возвращает минимальный объект или значение"""
        if not self._items:
            return None
        
        if key_func:
            return min(self._items, key=key_func)
        return min(self._items)
    
    def max(self, key_func: Callable[[T], Any] = None) -> Union[T, Any, None]:
        """Возвращает максимальный объект или значение"""
        if not self._items:
            return None
        
        if key_func:
            return max(self._items, key=key_func)
        return max(self._items)
    
    def sum(self, key_func: Callable[[T], Any]) -> Any:
        """Суммирует значения"""
        return sum(key_func(item) for item in self._items)
    
    def avg(self, key_func: Callable[[T], Any]) -> float:
        """Вычисляет среднее значение"""
        if not self._items:
            return 0.0
        return sum(key_func(item) for item in self._items) / len(self._items)
    
    # ============== МАССОВЫЕ ОПЕРАЦИИ ==============
    
    def __setattr__(self, name: str, value: Any) -> None:
        """Перехватывает установку атрибутов для массового обновления"""
        
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            for item in self._items:
                if isinstance(item, BaseModel):
                    setattr(item, name, value)
                elif isinstance(item, dict):
                    item[name] = value
    
    def update_all(self, **kwargs) -> 'SmartData[T]':
        """Обновляет все объекты указанными значениями"""
        for item in self._items:
            if isinstance(item, BaseModel):
                for key, value in kwargs.items():
                    setattr(item, key, value)
            elif isinstance(item, dict):
                item.update(kwargs)
        return self
    
    # ============== МАГИЧЕСКИЕ МЕТОДЫ ==============
    
    def __len__(self) -> int:
        return len(self._items)
    
    def __getitem__(self, index) -> Union[T, List[T]]:
        if isinstance(index, slice):
            new_sd = self.__class__.__new__(self.__class__)
            new_sd._target_type = self._target_type
            new_sd._items = self._items[index]
            return new_sd
        return self._items[index]
    
    def __getattr__(self, name: str) -> List[Any]:
        """
        Динамически извлекает значения указанного атрибута из всех объектов в _items.
        
        Позволяет обращаться к атрибутам объектов в SmartData как к атрибутам самого SmartData.
        Например: smart_data.name вернет список всех значений атрибута 'name' из объектов.
        
        Args:
            name: Имя атрибута для извлечения
            
        Returns:
            List[Any]: Список значений атрибута из всех объектов
            
        Raises:
            AttributeError: Если ни у одного объекта нет указанного атрибута
        """
        if name.startswith('_'):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
        
        values = []
        
        for item in self._items:
            # Для объектов BaseModel
            if isinstance(item, BaseModel):
                if hasattr(item, name):
                    values.append(getattr(item, name))
                else:
                    # Проверяем, есть ли атрибут в __dict__
                    if hasattr(item, '__dict__') and name in item.__dict__:
                        values.append(item.__dict__[name])
                    else:
                        values.append(None)
            
            # Для словарей
            elif isinstance(item, dict):
                values.append(item.get(name))
            
            # Для других типов объектов
            else:
                try:
                    values.append(getattr(item, name))
                except AttributeError:
                    values.append(None)
        
        # Проверяем, есть ли хотя бы одно не-None значение
        if all(v is None for v in values):
            raise AttributeError(
                f"'{self.__class__.__name__}' object and its items have no attribute '{name}'"
            )
        
        return values
    
    def __iter__(self) -> Iterator[T]:
        return iter(self._items)
    
    def __contains__(self, item: T) -> bool:
        return item in self._items
    
    def __add__(self, other: 'SmartData[T]') -> 'SmartData[T]':
        """Объединяет два SmartData"""
        
        if not isinstance(other, SmartData):
            raise TypeError(f"Cannot add SmartData and {type(other).__name__}")
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = self._target_type
        new_sd._items = self._items + other._items
        
        return new_sd
    
    def __iadd__(self, other: 'SmartData[T]') -> 'SmartData[T]':
        """Добавляет элементы в текущий SmartData"""
        if not isinstance(other, SmartData):
            raise TypeError(f"Cannot add SmartData and {type(other).__name__}")
        
        self._items.extend(other._items)
        return self
    
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SmartData):
            return False
        return self._items == other._items and self._target_type == other._target_type
    
    def __bool__(self) -> bool:
        return bool(self._items)
    
    def __repr__(self) -> str:
        type_name = self._target_type.__name__ if hasattr(self._target_type, '__name__') else str(self._target_type)
        
        items_repr = []
        for item in self._items[:3]:
            if isinstance(item, BaseModel):
                attrs = []
                if hasattr(item, '__dict__'):
                    for field_name, value in item.__dict__.items():
                        if field_name == SKEY_NAME:
                            continue
                        if isinstance(value, (list, dict)) and value:
                            attrs.append(f"{field_name}=<{type(value).__name__} len={len(value)}>")
                        elif isinstance(value, BaseModel):
                            attrs.append(f"{field_name}={type(value).__name__}()")
                        elif value is not None:
                            value_str = repr(value)
                            attrs.append(f"{field_name}={value_str[:30]}{'...' if len(value_str) > 30 else ''}")
                        else:
                            attrs.append(f"{field_name}=None")
                
                items_repr.append(f"{type(item).__name__}({', '.join(attrs)})")
            else:
                item_str = str(item)
                items_repr.append(item_str[:50] + '...' if len(item_str) > 50 else item_str)
        
        if len(self._items) > 3:
            items_repr.append(f"... (+{len(self._items) - 3} more)")
        
        return f"SmartData[{type_name}](count={len(self._items)}, items=[{', '.join(items_repr)}])"

    # def __repr__(self) -> str:
    #     return f"SmartData[{self._target_type}](count={len(self._items)}, items={self._items})"
    
    def __str__(self) -> str:
        type_name = self._target_type.__name__ if hasattr(self._target_type, '__name__') else str(self._target_type)
        return f"SmartData[{type_name}] with {len(self._items)} items"
    
    # ============== ДОПОЛНИТЕЛЬНЫЕ МЕТОДЫ ==============
    
    def pluck(self, key: str) -> List[Any]:
        """Извлекает значения по ключу из всех объектов"""
        result = []
        for item in self._items:
            if isinstance(item, (BaseModel, dict)):
                value = item.get(key) if isinstance(item, dict) else getattr(item, key, None)
                result.append(value)
        return result

    def exists(self, key: Any = None, value: Any = None) -> bool:
        """Проверяет, существует ли объект с указанным ключом и значением с поддержкой списков"""
        
        for item in self._items:
            for obj in self._all_objects(item):
                if self._match_object(obj, key, value, is_partial=False):
                    return True
        
        return False
    
    def chunk(self, size: int) -> List['SmartData[T]']:
        """Разбивает на части указанного размера"""
        result = []
        for i in range(0, len(self._items), size):
            chunk_items = self._items[i:i + size]
            new_sd = self.__class__.__new__(self.__class__)
            new_sd._target_type = self._target_type
            new_sd._items = chunk_items
            result.append(new_sd)
        return result
    
    def sample(self, n: int = 1) -> 'SmartData[T]':
        """Возвращает случайную выборку объектов"""
        import random
        sampled = random.sample(self._items, min(n, len(self._items)))
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = self._target_type
        new_sd._items = sampled
        
        return new_sd
    
    def flatten(self) -> 'SmartData[Any]':
        """Выравнивает вложенные структуры в один плоский список"""
        flattened = []
        
        def _flatten(item):
            if isinstance(item, (list, SmartData)):
                for subitem in item:
                    _flatten(subitem)
            else:
                flattened.append(item)
        
        for item in self._items:
            _flatten(item)
        
        new_sd = self.__class__.__new__(self.__class__)
        new_sd._target_type = Any
        new_sd._items = flattened
        
        return new_sd



def api_method(model: Type[T] = Any) -> ApiRet:
    """--- Декоратор для методов API ---"""

    def decorator(func: Callable):
        @wraps(func)
        def wrapper(self, *args, **kwargs):

            prepared_kwargs = func(self, *args, **kwargs)
            final_params = prepared_kwargs if isinstance(prepared_kwargs, dict) else kwargs

            try:
                api_action = getattr(getattr(self._api, self._category), func.__name__)
            except AttributeError as e:
                raise WorkerNetException(f'Ошибка API запроса: {e}')

            try:
                response = api_action(**final_params)
                if model is Any or self._is_ret_origin: return response
            except WorkerNetException as e:
                if model is Any: raise e
                return None

            if isinstance(response, list): return SmartData(response)
            if not isinstance(response, dict): return response

            result = response.get('result',None) == 'OK' if response.get('result',None) else None
            id = response.get('id',None) or response.get('Id',None)
            data = response.get('data', None)

            if data is None: 
                data = response.get('Data', None)
            if issubclass(model,bool): 
                return result
            if issubclass(model,(int,str,)): 
                if response.get('ip', None): return response['ip']
                # return data if data is not None else id

            return SmartData(data, model) if data is not None else id or result

        return wrapper
    return decorator



@smart_model
class GeoPoint(BaseModel):
    """Географические координаты"""

    lon: float
    lat: float

    def __init__(self, *args, **kwargs):
        # Если передан один позиционный аргумент (список или кортеж)
        if len(args) == 1 and isinstance(args[0], (list, tuple)):
            lon, lat = args[0]
            super().__init__(lon=lon, lat=lat)
        # Если переданы стандартные именованные аргументы или позиционные (lon, lat)
        else:
            super().__init__(*args, **kwargs)
    def __str__(self):
        return f"{self.lon},{self.lat}"
