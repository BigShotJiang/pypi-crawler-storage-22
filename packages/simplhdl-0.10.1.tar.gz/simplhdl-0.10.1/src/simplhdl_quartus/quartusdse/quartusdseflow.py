import logging
import shutil
from argparse import Namespace
from pathlib import Path

from simplhdl import Project
from simplhdl.plugin import FlowTools, ImplementationFlow
from simplhdl.utils import sh

from ..quartusflow import QuartusFlow
from ..resources.templates import quartus as templates

logger = logging.getLogger(__name__)


class QuartusDseFlow(ImplementationFlow):
    @classmethod
    def parse_args(self, subparsers) -> None:
        parser = subparsers.add_parser("quartus-dse", help="Quartus Design Space Explore Flow")
        parser.add_argument("--gui", action="store_true", help="Open project in Quartus GUI")
        parser.add_argument(
            "--dse-args",
            default="",
            action="store",
            metavar="ARGS",
            help="Extra arguments for Quartus Design Space Explore command",
        )
        parser.add_argument(
            "--dse-file",
            action="store",
            metavar="FILE",
            help="The .dse configuration file to be used for this project",
        )
        parser.add_argument(
            "--num-seeds",
            action="store",
            help="Number of seeds to sweep as part of the exploration space. "
            + "DSE auto-generates seed values when this is provided",
        )

    def __init__(self, name, args: Namespace, project: Project, builddir: Path):
        super().__init__(name, args, project, builddir)
        self.templates = templates
        self.tools.add(FlowTools.QUARTUS)

    def run(self) -> None:
        quartus = QuartusFlow("quartus", None, self.project, self.builddir)
        quartus.validate()
        quartus.configure()
        quartus.generate()
        self.execute()

    def execute(self):
        name = self.project.name
        if self.args.gui:
            sh(["quartus_dsew", name], cwd=self.builddir)
            return
        args = self.args.dse_args
        if self.args.num_seeds:
            args += f" --num-seeds {self.args.num_seeds}"
        if self.args.dse_file:
            args += f" --use-dse-file {self.args.dse_file}"
        command = f"quartus_dse {args} {name}".split()
        sh(command, cwd=self.builddir, output=True)

    def is_tool_setup(self) -> None:
        exit: bool = False
        if shutil.which("quartus_sh") is None:
            logger.error("quartus_sh: not found in PATH")
            exit = True
        if shutil.which("quartus") is None:
            logger.error("quartus: not found in PATH")
            exit = True
        if exit:
            raise FileNotFoundError("Quartus is not setup correctly")
