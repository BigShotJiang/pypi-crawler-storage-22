"""
Factory
=======

Contains functions which select class types based on Simvue configuration
"""
