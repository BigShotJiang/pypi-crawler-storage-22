#
# Copyright (C) Spacinov SAS
# Distributed under the 2-clause BSD license
#

import datetime
import typing
import unittest
import zoneinfo

from sipmessage import (
    URI,
    Address,
    AuthChallenge,
    AuthCredentials,
    AuthParameters,
    CSeq,
    MediaType,
    Message,
    Parameters,
    Request,
    Response,
    Via,
)
from sipmessage.message import Headers

ADDRESS = Address(uri=URI(scheme="sip", host="example.com"))
AUTHENTICATE = AuthChallenge(
    "Digest",
    parameters=AuthParameters(
        realm="atlanta.com",
        domain="sip:boxesbybob.com",
        qop="auth",
        nonce="f84f1cec41e6cbe5aea9c8e88d359",
        opaque="",
        stale="FALSE",
        algorithm="MD5",
    ),
)
AUTHORIZATION = AuthCredentials(
    "Digest",
    parameters=AuthParameters(
        username="Alice",
        realm="atlanta.com",
        nonce="84a4cc6f3082121f32b42a2187831a9e",
        response="7587245234b3434cc3412213e5f113a5432",
    ),
)
CSEQ = CSeq(sequence=1, method="OPTIONS")
VIA = Via(
    transport="WSS",
    host="mYn6S3lQaKjo.invalid",
    parameters=Parameters(branch="z9hG4bKgD24yaj"),
)

T = typing.TypeVar("T", bytes, str)


def dummy_message() -> Request:
    return Request("OPTIONS", URI(scheme="sip", host="example.com"))


def lf2crlf(x: T) -> T:
    if isinstance(x, bytes):
        return x.replace(b"\n", b"\r\n")
    else:
        return x.replace("\n", "\r\n")


class HeadersTest(unittest.TestCase):
    def test_add(self) -> None:
        headers = Headers()

        headers.add(
            "Via", "SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1"
        )
        self.assertEqual(
            str(headers),
            lf2crlf("""Via: SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1

"""),
        )
        self.assertEqual(headers.keys(), ["Via"])

        headers.add(
            "Via",
            "SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bKnashds8;received=192.0.2.1",
        )
        self.assertEqual(
            str(headers),
            lf2crlf("""Via: SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1
Via: SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bKnashds8;received=192.0.2.1

"""),
        )

        headers.add("From", "<sip:alice@atlanta.com>")
        self.assertEqual(
            str(headers),
            lf2crlf("""Via: SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1
Via: SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bKnashds8;received=192.0.2.1
From: <sip:alice@atlanta.com>

"""),
        )
        self.assertEqual(headers.keys(), ["Via", "From"])

    def test_set(self) -> None:
        headers = Headers()

        headers.set("To", "Bob <sip:bob@biloxi.com>")
        self.assertEqual(
            str(headers),
            lf2crlf("""To: Bob <sip:bob@biloxi.com>

"""),
        )
        self.assertEqual(headers.keys(), ["To"])

        headers.set("To", "Alice <sip:alice@biloxi.com>")
        self.assertEqual(
            str(headers),
            lf2crlf("""To: Alice <sip:alice@biloxi.com>

"""),
        )

    def test_setlist(self) -> None:
        headers = Headers()

        headers.setlist(
            "Via",
            ["SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1"],
        )
        self.assertEqual(
            str(headers),
            lf2crlf("""Via: SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1

"""),
        )
        self.assertEqual(headers.keys(), ["Via"])

        headers.setlist(
            "Via",
            [
                "SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1",
                "SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bKnashds8;received=192.0.2.1",
            ],
        )
        self.assertEqual(
            str(headers),
            lf2crlf("""Via: SIP/2.0/UDP bigbox3.site3.atlanta.com;branch=z9hG4bK77ef4c2312983.1
Via: SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bKnashds8;received=192.0.2.1

"""),
        )
        self.assertEqual(headers.keys(), ["Via"])


class MessageTest(unittest.TestCase):
    maxDiff = None

    REQUEST_COMPACT_BYTES = lf2crlf(
        b"""REGISTER sip:atlanta.com SIP/2.0
v: SIP/2.0/WSS mYn6S3lQaKjo.invalid;branch=z9hG4bKgD24yaj
Max-Forwards: 70
t: <sip:alice@atlanta.com>
f: <sip:alice@atlanta.com>;tag=69piINLbAb
i: t87Br1RHAoBz2FsrKKk6hV
CSeq: 1 REGISTER
m: <sip:Mk9sZp5Z@mYn6S3lQaKjo.invalid;transport=ws>;expires=300
User-Agent: Tester/0.1.0
l: 0

"""
    )
    REQUEST_FULL_BYTES = lf2crlf(
        b"""REGISTER sip:atlanta.com SIP/2.0
Via: SIP/2.0/WSS mYn6S3lQaKjo.invalid;branch=z9hG4bKgD24yaj
Max-Forwards: 70
To: <sip:alice@atlanta.com>
From: <sip:alice@atlanta.com>;tag=69piINLbAb
Call-ID: t87Br1RHAoBz2FsrKKk6hV
CSeq: 1 REGISTER
Contact: <sip:Mk9sZp5Z@mYn6S3lQaKjo.invalid;transport=ws>;expires=300
User-Agent: Tester/0.1.0
Content-Length: 0

"""
    )

    def assertMessageHeaders(self, request: Message, values: list[str]) -> None:
        self.assertEqual(str(request.headers).split("\r\n")[:-2], values)

    def _test_request(self, message_bytes: bytes) -> None:
        message = Message.parse(message_bytes)
        assert isinstance(message, Request)

        self.assertEqual(message.method, "REGISTER")
        self.assertEqual(message.uri, URI(scheme="sip", host="atlanta.com"))
        self.assertEqual(message.body, b"")

        # Check headers.
        self.assertEqual(message.call_id, "t87Br1RHAoBz2FsrKKk6hV")
        self.assertEqual(message.content_type, None)
        self.assertEqual(message.content_length, 0)
        self.assertEqual(message.cseq, CSeq(sequence=1, method="REGISTER"))
        self.assertEqual(
            message.contact,
            [
                Address(
                    uri=URI(
                        scheme="sip",
                        host="mYn6S3lQaKjo.invalid",
                        user="Mk9sZp5Z",
                        parameters=Parameters(transport="ws"),
                    ),
                    parameters=Parameters(expires="300"),
                )
            ],
        )
        self.assertEqual(
            message.from_address,
            Address(
                uri=URI(scheme="sip", host="atlanta.com", user="alice"),
                parameters=Parameters(tag="69piINLbAb"),
            ),
        )
        self.assertEqual(message.max_forwards, 70)
        self.assertEqual(
            message.to_address,
            Address(uri=URI(scheme="sip", host="atlanta.com", user="alice")),
        )
        self.assertEqual(message.proxy_authenticate, None)
        self.assertEqual(message.user_agent, "Tester/0.1.0")
        self.assertEqual(
            message.via,
            [
                Via(
                    transport="WSS",
                    host="mYn6S3lQaKjo.invalid",
                    parameters=Parameters(branch="z9hG4bKgD24yaj"),
                )
            ],
        )
        self.assertEqual(message.www_authenticate, None)

        self.assertEqual(bytes(message), self.REQUEST_FULL_BYTES)

    def test_request_compact_form(self) -> None:
        self._test_request(self.REQUEST_COMPACT_BYTES)

    def test_request_full_form(self) -> None:
        self._test_request(self.REQUEST_FULL_BYTES)

    def test_response(self) -> None:
        message_bytes = lf2crlf(
            b"""SIP/2.0 200 OK
Via: SIP/2.0/WSS K1IXduq1pcuX.invalid;branch=z9hG4bKAVaf5Tk;received=80.200.136.90;rport=54087
From: <sip:alice@atlanta.com>;tag=8hZmsuF0Kb
To: <sip:alice@atlanta.com>;tag=Bg8X3vvKyrmKH
Call-ID: t87Br1RHAoBz2FsrKKk6hV
CSeq: 1 REGISTER
Date: Thu, 01 Feb 2018 11:29:53 GMT
User-Agent: FreeSWITCH-mod_sofia/1.6.20-37-987c9b9~64bit
Allow: INVITE, ACK, BYE, CANCEL, OPTIONS, MESSAGE, INFO, UPDATE, REGISTER, REFER, NOTIFY, PUBLISH, SUBSCRIBE
Supported: timer, path, replaces
Content-Length: 0

"""
        )

        message = Message.parse(message_bytes)
        assert isinstance(message, Response)

        self.assertEqual(message.code, 200)
        self.assertEqual(message.phrase, "OK")
        self.assertEqual(message.body, b"")

        self.assertEqual(bytes(message), message_bytes)

    def test_header_accept(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.accept, None)

        # Add the header.
        request.accept = [
            MediaType(mime_type="application/sdp", parameters=Parameters(level="1")),
            MediaType(mime_type="application/x-private"),
            MediaType(mime_type="text/html"),
        ]
        self.assertEqual(
            request.accept,
            [
                MediaType(
                    mime_type="application/sdp", parameters=Parameters(level="1")
                ),
                MediaType(mime_type="application/x-private"),
                MediaType(mime_type="text/html"),
            ],
        )
        self.assertMessageHeaders(
            request,
            [
                "Accept: application/sdp;level=1",
                "Accept: application/x-private",
                "Accept: text/html",
            ],
        )

        # Clear the header.
        request.accept = []
        self.assertEqual(request.accept, [])
        self.assertMessageHeaders(request, ["Accept: "])

        # Remove the header.
        request.accept = None
        self.assertEqual(request.accept, None)
        self.assertMessageHeaders(request, [])

    def test_header_authorization(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.authorization)

        # Add the header.
        request.authorization = AUTHORIZATION
        self.assertEqual(request.authorization, AUTHORIZATION)
        self.assertMessageHeaders(
            request,
            [
                'Authorization: Digest username="Alice", realm="atlanta.com", '
                'nonce="84a4cc6f3082121f32b42a2187831a9e", '
                'response="7587245234b3434cc3412213e5f113a5432"'
            ],
        )

        # Remove the header.
        request.authorization = None
        self.assertIsNone(request.authorization)
        self.assertMessageHeaders(request, [])

    def test_header_call_id(self) -> None:
        request = dummy_message()

        # Check the initial value.
        with self.assertRaises(KeyError):
            request.call_id

        # Add the header.
        request.call_id = "abc"
        self.assertEqual(request.call_id, "abc")
        self.assertMessageHeaders(request, ["Call-ID: abc"])

    def test_header_contact(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.contact, [])

        # Add the header.
        request.contact = [ADDRESS]
        self.assertEqual(request.contact, [ADDRESS])
        self.assertMessageHeaders(request, ["Contact: <sip:example.com>"])

        # Remove the header.
        request.contact = []
        self.assertEqual(request.contact, [])
        self.assertMessageHeaders(request, [])

    def test_header_content_language(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.content_language)

        # Add the header.
        request.content_language = "fr"
        self.assertEqual(request.content_language, "fr")
        self.assertMessageHeaders(request, ["Content-Language: fr"])

        # Remove the header.
        request.content_language = None
        self.assertIsNone(request.content_language)
        self.assertMessageHeaders(request, [])

    def test_header_content_length(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.content_length)

        # Add the header.
        request.content_length = 10
        self.assertEqual(request.content_length, 10)
        self.assertMessageHeaders(request, ["Content-Length: 10"])

        # Remove the header.
        request.content_length = None
        self.assertIsNone(request.content_length)
        self.assertMessageHeaders(request, [])

    def test_header_content_type(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.content_type)

        # Add the header.
        request.content_type = MediaType(mime_type="application/sdp")
        self.assertEqual(request.content_type, MediaType(mime_type="application/sdp"))
        self.assertMessageHeaders(request, ["Content-Type: application/sdp"])

        # Remove the header.
        request.content_type = None
        self.assertIsNone(request.content_type)
        self.assertMessageHeaders(request, [])

    def test_header_cseq(self) -> None:
        request = dummy_message()

        # Check the initial value.
        with self.assertRaises(KeyError):
            request.cseq

        # Add the header.
        request.cseq = CSEQ
        self.assertEqual(request.cseq, CSEQ)
        self.assertMessageHeaders(request, ["CSeq: 1 OPTIONS"])

    def test_header_date(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.date)

        # Set the header.
        request.date = datetime.datetime(
            2010, 11, 14, 0, 29, tzinfo=zoneinfo.ZoneInfo("Europe/Paris")
        )
        self.assertEqual(
            request.date,
            datetime.datetime(2010, 11, 13, 23, 29, tzinfo=datetime.timezone.utc),
        )
        self.assertMessageHeaders(request, ["Date: Sat, 13 Nov 2010 23:29:00 GMT"])

        # Remove the header.
        request.date = None
        self.assertIsNone(request.date)
        self.assertMessageHeaders(request, [])

    def test_header_expires(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.expires)

        # Add the header.
        request.expires = 5
        self.assertEqual(request.expires, 5)
        self.assertMessageHeaders(request, ["Expires: 5"])

        # Remove the header.
        request.expires = None
        self.assertIsNone(request.expires)
        self.assertMessageHeaders(request, [])

    def test_header_from_address(self) -> None:
        request = dummy_message()

        # Check the initial value.
        with self.assertRaises(KeyError):
            request.from_address

        # Add the header.
        request.from_address = ADDRESS
        self.assertEqual(request.from_address, ADDRESS)
        self.assertMessageHeaders(request, ["From: <sip:example.com>"])

    def test_header_in_reply_to(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.in_reply_to, [])

        # Add the header.
        request.in_reply_to = ["70710@saturn.bell-tel.com", "17320@saturn.bell-tel.com"]
        self.assertEqual(
            request.in_reply_to,
            ["70710@saturn.bell-tel.com", "17320@saturn.bell-tel.com"],
        )
        self.assertMessageHeaders(
            request,
            ["In-Reply-To: 70710@saturn.bell-tel.com, 17320@saturn.bell-tel.com"],
        )

        # Remove the header.
        request.in_reply_to = []
        self.assertEqual(request.in_reply_to, [])
        self.assertMessageHeaders(request, [])

    def test_header_max_forwards(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.max_forwards)

        # Add the header.
        request.max_forwards = 1
        self.assertEqual(request.max_forwards, 1)
        self.assertMessageHeaders(request, ["Max-Forwards: 1"])

        # Remove the header.
        request.max_forwards = None
        self.assertIsNone(request.max_forwards)
        self.assertMessageHeaders(request, [])

    def test_header_min_expires(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.min_expires)

        # Add the header.
        request.min_expires = 60
        self.assertEqual(request.min_expires, 60)
        self.assertMessageHeaders(request, ["Min-Expires: 60"])

        # Remove the header.
        request.min_expires = None
        self.assertIsNone(request.min_expires)
        self.assertMessageHeaders(request, [])

    def test_header_proxy_authenticate(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.proxy_authenticate)

        # Add the header.
        request.proxy_authenticate = AUTHENTICATE
        self.assertEqual(request.proxy_authenticate, AUTHENTICATE)
        self.assertMessageHeaders(
            request,
            [
                'Proxy-Authenticate: Digest realm="atlanta.com", domain="sip:boxesbybob.com", '
                'qop="auth", nonce="f84f1cec41e6cbe5aea9c8e88d359", opaque="", stale=FALSE, '
                "algorithm=MD5"
            ],
        )

        # Remove the header.
        request.proxy_authenticate = None
        self.assertIsNone(request.proxy_authenticate)
        self.assertMessageHeaders(request, [])

    def test_header_proxy_authorization(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.proxy_authorization)

        # Add the header.
        request.proxy_authorization = AUTHORIZATION
        self.assertEqual(request.proxy_authorization, AUTHORIZATION)
        self.assertMessageHeaders(
            request,
            [
                'Proxy-Authorization: Digest username="Alice", realm="atlanta.com", '
                'nonce="84a4cc6f3082121f32b42a2187831a9e", '
                'response="7587245234b3434cc3412213e5f113a5432"'
            ],
        )

        # Remove the header.
        request.proxy_authorization = None
        self.assertIsNone(request.proxy_authorization)
        self.assertMessageHeaders(request, [])

    def test_header_proxy_require(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.proxy_require, [])

        # Add the header.
        request.proxy_require = ["foo"]
        self.assertEqual(request.proxy_require, ["foo"])
        self.assertMessageHeaders(request, ["Proxy-Require: foo"])

        # Remove the header.
        request.proxy_require = []
        self.assertEqual(request.proxy_require, [])
        self.assertMessageHeaders(request, [])

    def test_header_record_route(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.record_route, [])

        # Add the header.
        request.record_route = [ADDRESS]
        self.assertEqual(request.record_route, [ADDRESS])
        self.assertMessageHeaders(request, ["Record-Route: <sip:example.com>"])

        # Remove the header.
        request.record_route = []
        self.assertEqual(request.record_route, [])
        self.assertMessageHeaders(request, [])

    def test_header_require(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.require, [])

        # Add the header.
        request.require = ["foo"]
        self.assertEqual(request.require, ["foo"])
        self.assertMessageHeaders(request, ["Require: foo"])

        # Remove the header.
        request.require = []
        self.assertEqual(request.require, [])
        self.assertMessageHeaders(request, [])

    def test_header_route(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.route, [])

        # Add the header.
        request.route = [ADDRESS]
        self.assertEqual(request.route, [ADDRESS])
        self.assertMessageHeaders(request, ["Route: <sip:example.com>"])

        # Remove the header.
        request.route = []
        self.assertEqual(request.route, [])
        self.assertMessageHeaders(request, [])

    def test_header_server(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.server)

        # Add the header.
        request.server = "HomeServer v2"
        self.assertEqual(request.server, "HomeServer v2")
        self.assertMessageHeaders(request, ["Server: HomeServer v2"])

        # Remove the header.
        request.server = None
        self.assertIsNone(request.server)
        self.assertMessageHeaders(request, [])

    def test_header_subject(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.subject)

        # Add the header.
        request.subject = "Need more boxes"
        self.assertEqual(request.subject, "Need more boxes")
        self.assertMessageHeaders(request, ["Subject: Need more boxes"])

        # Remove the header.
        request.subject = None
        self.assertIsNone(request.subject)
        self.assertMessageHeaders(request, [])

    def test_header_supported(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.supported, [])

        # Add the header.
        request.supported = ["replaces", "timer"]
        self.assertEqual(request.supported, ["replaces", "timer"])
        self.assertMessageHeaders(request, ["Supported: replaces, timer"])

        # Remove the header.
        request.supported = []
        self.assertEqual(request.supported, [])
        self.assertMessageHeaders(request, [])

        # Check parsing of an empty header.
        request.headers.set("Supported", "")
        self.assertEqual(request.supported, [])
        self.assertMessageHeaders(request, ["Supported: "])

    def test_header_to_address(self) -> None:
        request = dummy_message()

        # Check the initial value.
        with self.assertRaises(KeyError):
            request.to_address

        # Add the header.
        request.to_address = ADDRESS
        self.assertEqual(request.to_address, ADDRESS)
        self.assertMessageHeaders(request, ["To: <sip:example.com>"])

    def test_header_unsupported(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.unsupported, [])

        # Add the header.
        request.unsupported = ["foo"]
        self.assertEqual(request.unsupported, ["foo"])
        self.assertMessageHeaders(request, ["Unsupported: foo"])

        # Remove the header.
        request.unsupported = []
        self.assertEqual(request.unsupported, [])
        self.assertMessageHeaders(request, [])

    def test_header_user_agent(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.user_agent)

        # Add the header.
        request.user_agent = "Tester/0.1.0"
        self.assertEqual(request.user_agent, "Tester/0.1.0")
        self.assertMessageHeaders(request, ["User-Agent: Tester/0.1.0"])

        # Remove the header.
        request.user_agent = None
        self.assertIsNone(request.user_agent)
        self.assertMessageHeaders(request, [])

    def test_header_via(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertEqual(request.via, [])

        # Add the header.
        request.via = [VIA]
        self.assertEqual(request.via, [VIA])
        self.assertMessageHeaders(
            request, ["Via: SIP/2.0/WSS mYn6S3lQaKjo.invalid;branch=z9hG4bKgD24yaj"]
        )

        # Remove the header.
        request.via = []
        self.assertEqual(request.via, [])
        self.assertMessageHeaders(request, [])

    def test_header_www_authenticate(self) -> None:
        request = dummy_message()

        # Check the initial value.
        self.assertIsNone(request.www_authenticate)

        # Add the header.
        request.www_authenticate = AUTHENTICATE
        self.assertEqual(request.www_authenticate, AUTHENTICATE)
        self.assertMessageHeaders(
            request,
            [
                'WWW-Authenticate: Digest realm="atlanta.com", domain="sip:boxesbybob.com", '
                'qop="auth", nonce="f84f1cec41e6cbe5aea9c8e88d359", opaque="", stale=FALSE, '
                "algorithm=MD5"
            ],
        )

        # Remove the header.
        request.www_authenticate = None
        self.assertIsNone(request.www_authenticate)
        self.assertMessageHeaders(request, [])

    def test_not_bytes(self) -> None:
        with self.assertRaises(ValueError) as cm:
            Message.parse("SIP/2.0 200 OK")  # type: ignore
        self.assertEqual(str(cm.exception), "SIP message must be passed as bytes")

    def test_too_few_lines(self) -> None:
        with self.assertRaises(ValueError) as cm:
            Message.parse(b"SIP/2.0 200 OK")
        self.assertEqual(str(cm.exception), "SIP message has too few lines")

    def test_neither_request_nor_response(self) -> None:
        with self.assertRaises(ValueError) as cm:
            Message.parse(b"SIP/3.0\r\n\r\n")
        self.assertEqual(
            str(cm.exception), "SIP message is neither request nor response"
        )
