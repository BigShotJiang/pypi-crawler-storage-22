"""Site Audit Agent - CLI tool for automated website audits."""

__version__ = "0.5.0"
