from __future__ import annotations

from setuptools import setup


try:
    from wheel.bdist_wheel import bdist_wheel as _bdist_wheel

    class bdist_wheel(_bdist_wheel):
        def finalize_options(self) -> None:
            super().finalize_options()
            self.root_is_pure = False
            if hasattr(self, "root_is_purelib"):
                self.root_is_purelib = False

        def get_tag(self) -> tuple[str, str, str]:
            _, _, plat = super().get_tag()
            # py3-none-<platform>: works with any Python 3, no ABI, platform-specific
            return "py3", "none", plat

except Exception:  # wheel not available
    bdist_wheel = None  # type: ignore[assignment]


setup(cmdclass={"bdist_wheel": bdist_wheel} if bdist_wheel else {})
