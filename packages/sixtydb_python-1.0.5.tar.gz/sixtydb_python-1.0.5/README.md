# 60db

Official 60db SDK for Python

## Installation

```bash
pip install 60db
```

## Quick Start

```python
from sixtydb import SixtyDBClient

client = SixtyDBClient('your-api-key')

# Text to Speech
audio = client.text_to_speech(
    'Hello, world!',
    voice_id='default-voice',
    speed=1.0  # 0.5 to 2.0 (default 1.0)
)

# Save audio
with open('output.mp3', 'wb') as f:
    f.write(audio)

# Get all voices
voices = client.get_voices()
```

## API Methods

### Text-to-Speech
- `text_to_speech(text, voice_id=None, **params)` - Convert text to speech

### Speech-to-Text
- `speech_to_text(audio_file, language=None)` - Transcribe audio
- `get_languages()` - Get supported languages

### Voices
- `get_voices()` - List all voices
- `get_voice(voice_id)` - Get specific voice

## Examples

### Streaming TTS

```python
def handle_chunk(chunk):
    print(f"Received {len(chunk)} bytes")

client.text_to_speech_stream(
    "This is streaming audio",
    on_chunk=handle_chunk,
    on_complete=lambda: print("Done!"),
    voice_id='default-voice'
)
```

### Speech to Text

```python
with open('audio.mp3', 'rb') as f:
    result = client.speech_to_text(f, language='en')
    print(result['text'])
```

## License

MIT
