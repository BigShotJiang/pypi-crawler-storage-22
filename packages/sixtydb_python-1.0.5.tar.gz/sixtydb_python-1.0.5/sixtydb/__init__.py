"""
60db Python SDK
Official Python client for the 60db API
"""

from .client import SixtyDBClient

__version__ = "1.0.0"
__all__ = ["SixtyDBClient"]
