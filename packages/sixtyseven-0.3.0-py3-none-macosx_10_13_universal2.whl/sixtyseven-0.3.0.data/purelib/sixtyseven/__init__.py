"""
Sixtyseven - ML Experiment Tracking SDK

A Python SDK for tracking machine learning experiments with Sixtyseven.

Example usage:
    from sixtyseven import Run

    with Run(project="my-team/image-classifier") as run:
        run.log_config({"learning_rate": 0.001})

        for epoch in range(100):
            loss = train()
            run.log_metrics({"loss": loss}, step=epoch)
"""

from sixtyseven.config import configure
from sixtyseven.exceptions import (
    APIError,
    AuthenticationError,
    ServerError,
    SixtySevenError,
    ValidationError,
)
from sixtyseven.run import Run

__version__ = "0.1.0"
__all__ = [
    "Run",
    "configure",
    "SixtySevenError",
    "AuthenticationError",
    "APIError",
    "ValidationError",
    "ServerError",
]
