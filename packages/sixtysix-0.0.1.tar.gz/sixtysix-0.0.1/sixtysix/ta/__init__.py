"""
Technical Analysis Module

Organized by category:
- crossovers: crossover, crossunder, crossed
- indicators: rma, sma, ema, atr, rsi, dmi, adx, macd
- pivots: detect_pivots, detect_pivot_lows, detect_pivot_highs, pivothigh, pivotlow
- helpers: HasBarIndex protocol, TradingHelpers class
"""

from .crossovers import crossover, crossunder, crossed
from .indicators import rma, sma, ema, atr, rsi, dmi, adx, macd
from .pivots import detect_pivots, detect_pivot_lows, detect_pivot_highs, pivothigh, pivotlow
from .helpers import HasBarIndex, TradingHelpers

__all__ = [
    'crossover', 'crossunder', 'crossed',
    'rma', 'sma', 'ema', 'atr', 'rsi', 'dmi', 'adx', 'macd',
    'detect_pivots', 'detect_pivot_lows', 'detect_pivot_highs', 'pivothigh', 'pivotlow',
    'HasBarIndex', 'TradingHelpers',
]
