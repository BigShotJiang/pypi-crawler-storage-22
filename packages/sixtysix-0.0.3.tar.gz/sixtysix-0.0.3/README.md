# SixtySix

Framework for building trading strategies and technical indicators.

## Installation

```bash
pip install sixtysix
```

## Quick Start — Strategy

```python
from sixtysix import strategy, computed, param, Line

@strategy(name='sma_crossover', display_name='SMA Crossover')
class SMACrossover:
    fast = param.number(default=20, min=5, max=100)
    slow = param.number(default=50, min=10, max=200)

    @computed
    def fast_sma(self, df):
        return df['close'].rolling(self.fast).mean()

    @computed
    def slow_sma(self, df):
        return df['close'].rolling(self.slow).mean()

    def plot(self, df):
        return [
            Line(y=self.fast_sma(df), color='#3b82f6'),
            Line(y=self.slow_sma(df), color='#f97316'),
        ]

    def on_bar(self, df):
        if self.ta.crossover(self.fast_sma(df), self.slow_sma(df)):
            return self.buy()
```

## Quick Start — Indicator

```python
from sixtysix import indicator, param, Line

@indicator(name='sma', display_name='SMA', type='overlay')
class SMA:
    period = param.number(default=20, min=1, max=500)
    color = param.color(default='#2962ff')

    def plot(self, df):
        sma = df['close'].rolling(self.period).mean()
        return [Line(y=sma, color=self.color, line_width=2)]
```
