import sys

print(''.join(sys.argv))
