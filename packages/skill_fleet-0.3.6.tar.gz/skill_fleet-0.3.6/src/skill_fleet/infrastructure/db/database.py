"""
Skills-Fleet Database Connection.

Database connection and session management for the skills fleet database.
"""

import os
from collections.abc import AsyncGenerator
from collections.abc import Generator as SyncGenerator
from contextlib import contextmanager

from sqlalchemy import CheckConstraint, create_engine, text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import Session, sessionmaker

from .models import Base


def _with_postgres_driver(url: str, driver: str, *, override: bool = False) -> str:
    """Ensure Postgres URLs include a DBAPI driver when appropriate."""
    if url.startswith("postgresql+"):
        if not override:
            return url
        _, rest = url.split("://", 1)
        return f"postgresql+{driver}://{rest}"
    if url.startswith("postgresql://"):
        return f"postgresql+{driver}://{url[len('postgresql://') :]}"
    if url.startswith("postgres://"):
        return f"postgresql+{driver}://{url[len('postgres://') :]}"
    return url


# Database URL from environment
# In production: DATABASE_URL is required
# In development/test: falls back to SQLite for convenience
RAW_DATABASE_URL = os.getenv("DATABASE_URL")
_ENV = os.getenv("SKILL_FLEET_ENV", "production")

if not RAW_DATABASE_URL:
    if _ENV in ("development", "test", "testing"):
        # Use SQLite for development/testing if no DATABASE_URL is provided
        RAW_DATABASE_URL = "sqlite:///./skill_fleet_dev.db"
    else:
        raise ValueError(
            "DATABASE_URL environment variable is required in production. "
            "Set it to a PostgreSQL connection string, e.g.: "
            "postgresql://user:pass@host/dbname?sslmode=require"
        )

# Use psycopg (v3) for sync engine when driver isn't specified.
# SQLite URLs pass through unchanged.
DATABASE_URL = _with_postgres_driver(RAW_DATABASE_URL, "psycopg")

# Async database URL (derive from DATABASE_URL unless explicitly set).
# For SQLite, use aiosqlite driver for async support.
ASYNC_DATABASE_URL = os.getenv("ASYNC_DATABASE_URL")
if not ASYNC_DATABASE_URL:
    if RAW_DATABASE_URL.startswith("sqlite"):
        # SQLite async uses aiosqlite driver
        ASYNC_DATABASE_URL = RAW_DATABASE_URL.replace("sqlite:", "sqlite+aiosqlite:")
    else:
        ASYNC_DATABASE_URL = _with_postgres_driver(RAW_DATABASE_URL, "asyncpg", override=True)

# Check if we're using SQLite (different engine configuration)
_IS_SQLITE = DATABASE_URL.startswith("sqlite")

# Synchronous engine
# SQLite doesn't support connection pooling like PostgreSQL
connect_args = {"check_same_thread": False} if _IS_SQLITE else {}
if not _IS_SQLITE:
    connect_args.update(
        {
            "connect_timeout": 10,
            "options": "-c idle_in_transaction_session_timeout=60000",  # 60s timeout
        }
    )

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=bool(not _IS_SQLITE),
    pool_size=20 if not _IS_SQLITE else 0,  # Increased from 10
    max_overflow=30 if not _IS_SQLITE else 0,  # Increased from 20
    pool_recycle=300 if not _IS_SQLITE else -1,  # Recycle connections every 5 min
    pool_timeout=30,  # Wait up to 30s for connection
    echo=os.getenv("SQL_ECHO", "false").lower() == "true",
    connect_args=connect_args,
)

# Synchronous session factory
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

# Async engine
# SQLite async doesn't support connection pooling
async_engine = create_async_engine(
    ASYNC_DATABASE_URL,
    pool_pre_ping=bool(not _IS_SQLITE),
    pool_size=10 if not _IS_SQLITE else 0,
    max_overflow=20 if not _IS_SQLITE else 0,
    pool_recycle=300 if not _IS_SQLITE else -1,  # Recycle connections every 5 min
    echo=os.getenv("SQL_ECHO", "false").lower() == "true",
)

# Async session factory
AsyncSessionLocal = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


def get_db() -> SyncGenerator[Session, None, None]:
    """
    Get a database session for dependency injection.

    Usage:
        @app.get("/skills")
        def read_skills(db: Session = Depends(get_db)):
            return db.query(Skill).all()
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def get_db_context() -> SyncGenerator[Session, None, None]:
    """
    Context manager for database sessions.

    Usage:
        with get_db_context() as db:
            skills = db.query(Skill).all()
    """
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


async def get_async_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Get an async database session for dependency injection.

    Usage:
        @app.get("/skills")
        async def read_skills(db: AsyncSession = Depends(get_async_db)):
            result = await db.execute(select(Skill))
            return result.scalars().all()
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


@contextmanager
def get_db_context_manager() -> SyncGenerator[Session, None, None]:
    """
    Alias for get_db_context() for backward compatibility.

    .. deprecated:: 2026.02
        Use :func:`get_db_context` directly. Will be removed in 2026.04.
    """
    import warnings

    warnings.warn(
        "get_db_context_manager() is deprecated; use get_db_context() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    with get_db_context() as db:
        yield db


def init_db() -> None:
    """
    Initialize the database by creating all tables.

    This should only be used for development. In production,
    use Alembic migrations instead.
    """
    if _IS_SQLITE:
        for table in Base.metadata.tables.values():
            regex_constraints = [
                constraint
                for constraint in table.constraints
                if isinstance(constraint, CheckConstraint) and "~" in str(constraint.sqltext)
            ]
            for constraint in regex_constraints:
                table.constraints.remove(constraint)

    # Ensure uuid-ossp extension exists (Postgres only)
    if not _IS_SQLITE:
        with engine.connect() as conn:
            conn.execute(text('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"'))
            conn.commit()

    Base.metadata.create_all(bind=engine)


def drop_db() -> None:
    """
    Drop all database tables.

    WARNING: This will delete all data!
    """
    # Drop dependent views/materialized views first
    with engine.connect() as conn:
        conn.execute(text("DROP MATERIALIZED VIEW IF EXISTS skill_statistics CASCADE"))
        conn.execute(text("DROP VIEW IF EXISTS popular_skills_view CASCADE"))
        conn.execute(text("DROP VIEW IF EXISTS skills_attention_view CASCADE"))
        conn.execute(text("DROP VIEW IF EXISTS active_skills_view CASCADE"))
        conn.execute(text("DROP VIEW IF EXISTS draft_skills_view CASCADE"))

        # Manually drop all known tables in dependency order with CASCADE
        tables_to_drop = [
            "optimization_jobs",
            "usage_events",
            "skill_test_coverage",
            "validation_checks",
            "validation_reports",
            "tdd_workflow_state",
            "deep_understanding_state",
            "hitl_interactions",
            "jobs",
            "skill_allowed_tools",
            "skill_files",
            "tag_stats",
            "skill_tags",
            "skill_keywords",
            "skill_references",
            "dependency_closure",
            "skill_dependencies",
            "capabilities",
            "facet_definitions",
            "skill_facets",
            "skill_aliases",
            "skill_categories",
            "taxonomy_closure",
            "taxonomy_categories",
            "skills",
        ]

        for table in tables_to_drop:
            conn.execute(text(f"DROP TABLE IF EXISTS {table} CASCADE"))

        # Drop types
        types_to_drop = [
            "skill_status_enum",
            "skill_type_enum",
            "skill_weight_enum",
            "load_priority_enum",
            "skill_style_enum",
            "dependency_type_enum",
            "job_status_enum",
            "hitl_type_enum",
            "validation_status_enum",
            "severity_enum",
            "file_type_enum",
        ]

        for type_name in types_to_drop:
            conn.execute(text(f"DROP TYPE IF EXISTS {type_name} CASCADE"))

        conn.commit()

    Base.metadata.drop_all(bind=engine)


async def init_async_db() -> None:
    """
    Initialize the async database by creating all tables.

    This should only be used for development. In production,
    use Alembic migrations instead.
    """
    async with async_engine.begin() as conn:
        await conn.execute(text('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"'))
        await conn.run_sync(Base.metadata.create_all)


async def drop_async_db() -> None:
    """
    Drop all async database tables.

    WARNING: This will delete all data!
    """
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


def close_db() -> None:
    """Close the database connection."""
    engine.dispose()


async def close_async_db() -> None:
    """Close the async database connection."""
    await async_engine.dispose()
