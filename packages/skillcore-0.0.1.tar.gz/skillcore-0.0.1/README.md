# skillcore

Core skill engine and runtime. Part of the skillmd ecosystem.

Part of the [skillmd](https://skillmd.sh) ecosystem.
