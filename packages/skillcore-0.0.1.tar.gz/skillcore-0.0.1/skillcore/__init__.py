"""Core skill engine and runtime. Part of the skillmd ecosystem."""
__version__ = '0.0.1'
