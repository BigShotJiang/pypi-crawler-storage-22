# skillmd

The SKILL.md package manager — install, discover and publish agent skills.

Part of the [skillmd](https://skillmd.sh) ecosystem.
