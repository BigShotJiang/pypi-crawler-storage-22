"""The SKILL.md package manager — install, discover and publish agent skills."""
__version__ = '0.0.1'
