class SkillValidationError(ValueError):
    """Raised when a skill definition fails validation."""

