def run(payload: str = "ok") -> str:
    return "finance/convert_currency executed"
