def run(payload: str = "ok") -> str:
    return "finance/get_exchange_rates executed"
