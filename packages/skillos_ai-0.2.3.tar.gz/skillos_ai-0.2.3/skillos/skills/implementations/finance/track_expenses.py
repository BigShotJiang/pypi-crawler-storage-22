def run(payload: str = "ok") -> str:
    return "finance/track_expenses executed"
