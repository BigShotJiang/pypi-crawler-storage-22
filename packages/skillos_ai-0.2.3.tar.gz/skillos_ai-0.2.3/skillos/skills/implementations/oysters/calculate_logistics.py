def run(payload: str = "ok") -> str:
    return "oysters/calculate_logistics executed"
