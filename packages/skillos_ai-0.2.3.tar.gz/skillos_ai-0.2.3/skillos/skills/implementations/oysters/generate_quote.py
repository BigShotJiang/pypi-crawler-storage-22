def run(payload: str = "ok") -> str:
    return "oysters/generate_quote executed"
