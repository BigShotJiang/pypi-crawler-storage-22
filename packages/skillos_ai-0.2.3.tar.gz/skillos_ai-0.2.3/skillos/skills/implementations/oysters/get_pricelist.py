def run(payload: str = "ok") -> str:
    return "oysters/get_pricelist executed"
