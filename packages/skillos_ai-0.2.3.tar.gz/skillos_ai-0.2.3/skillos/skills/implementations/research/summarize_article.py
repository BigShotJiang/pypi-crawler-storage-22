def run(payload: str = "ok") -> str:
    return "research/summarize_article executed"
