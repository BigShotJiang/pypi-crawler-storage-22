def run(payload: str = "ok") -> str:
    return "research/web_search executed"
