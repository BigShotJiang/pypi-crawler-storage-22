def run(payload: str = "ok") -> str:
    return "travel/build_itinerary executed"
