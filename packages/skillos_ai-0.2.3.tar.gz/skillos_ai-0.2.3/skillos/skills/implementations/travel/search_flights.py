def run(payload: str = "ok") -> str:
    return "travel/search_flights executed"
