def run(payload: str = "ok") -> str:
    return "travel/search_hotels executed"
