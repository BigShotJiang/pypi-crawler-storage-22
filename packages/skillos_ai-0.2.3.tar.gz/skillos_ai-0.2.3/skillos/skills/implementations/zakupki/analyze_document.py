def run(payload: str = "ok") -> str:
    return "zakupki/analyze_document executed"
