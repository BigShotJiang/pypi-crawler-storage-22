def run(payload: str = "ok") -> str:
    return "zakupki/check_requirements executed"
