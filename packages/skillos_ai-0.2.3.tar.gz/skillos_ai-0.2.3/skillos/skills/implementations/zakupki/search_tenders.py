def run(payload: str = "ok") -> str:
    return "zakupki/search_tenders executed"
