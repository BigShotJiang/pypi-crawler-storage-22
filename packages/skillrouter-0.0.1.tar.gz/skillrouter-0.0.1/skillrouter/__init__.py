"""SkillRouter - Universal skill router for AI agents."""
__version__ = "0.0.1"
