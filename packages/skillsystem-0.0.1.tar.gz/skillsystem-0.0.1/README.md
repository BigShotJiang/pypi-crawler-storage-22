# skillsystem

Skill system framework. Part of the skillmd ecosystem.

Part of the [skillmd](https://skillmd.sh) ecosystem.
