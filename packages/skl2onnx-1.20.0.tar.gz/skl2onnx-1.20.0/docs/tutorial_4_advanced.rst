..  SPDX-License-Identifier: Apache-2.0


Advanced scenarios
==================

Unexpected discrepencies may appear. This a list of examples
with issues and resolved issues.

.. toctree::
    :maxdepth: 1

    auto_tutorial/plot_ngrams
    auto_tutorial/plot_usparse_xgboost
    auto_tutorial/plot_woe_transformer
    auto_tutorial/plot_output_onnx_single_probability
