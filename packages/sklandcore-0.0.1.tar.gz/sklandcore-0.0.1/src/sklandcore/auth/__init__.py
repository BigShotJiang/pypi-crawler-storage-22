from .hypergryph import HypergryphAuth
from .skland import SklandAuth

__all__ = ["HypergryphAuth", "SklandAuth"]
