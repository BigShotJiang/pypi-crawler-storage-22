from .core import s,ClusterKMeans,figsize
__version__ = "0.2.0"
__all__ = ['s']

s(1)