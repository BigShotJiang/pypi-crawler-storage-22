import pyperclip

SNIPPETS = {
    1: "import numpy as np",
    2: "import pandas as pd",
    3: "import matplotlib.pyplot as plt",
    4: "from sklearn.cluster import KMeans",
    5: "from sklearn.decomposition import PCA",
    6: "from sklearn.metrics import silhouette_score",
    7: "from sklearn.cluster import AgglomerativeClustering",
    8: "from sklearn.cluster import SpectralClustering",
    9: "from scipy.cluster.hierarchy import dendrogram, linkage",
    10: "import seaborn as sns",
    11: "warnings.filterwarnings('ignore')",
    12: "X = np.random.randn(100, 2)",
    13: "kmeans = KMeans(n_clusters=3, random_state=42)",
    14: "labels = kmeans.fit_predict(X)",
    15: "pca = PCA(n_components=2)",
    16: "plt.figure(figsize=(10, 7))",
    17: "df = pd.read_csv('data.csv')",
    18: "from sklearn.metrics import calinski_harabasz_score",
    19: "import scipy.cluster.hierarchy as shc",
    20: "np.random.seed(42)"
}

def s(id: int = 1) -> bool:

    text = SNIPPETS.get(id, SNIPPETS[1])
    pyperclip.copy(text)
def ClusterKMeans(id: int = 1) -> bool:

    text = SNIPPETS.get(id, SNIPPETS[1])
    pyperclip.copy(text)

def figsize(id: int = 1, id2: int = 1,) -> bool:
    text = SNIPPETS.get(id, SNIPPETS[1])
    pyperclip.copy(text)
