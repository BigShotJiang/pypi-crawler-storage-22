from .core import s,ClusterKMeans,figsize,x
__version__ = "0.6.0"
__all__ = ['s','ClusterKMeans', 'figsize','x']

s(1)