from certifi import where
from attrs import define, field
from ssl import SSLContext, create_default_context

from skoll.utils import get_config_var


__all__ = ["SSLContextConfig", "SpiceDBConfig", "PostgresConfig", "NATSConfig"]


@define(frozen=True, kw_only=True)
class SSLContextConfig:

    default: SSLContext = field(factory=lambda: create_default_context(cafile=where()))


@define(frozen=True, kw_only=True)
class SpiceDBConfig:

    uri: str | None = field(factory=get_config_var(["SPICEDB_URI", "/run/secrets/spicedb_uri.txt"]))
    token: str | None = field(factory=get_config_var(["SPICEDB_TOKEN", "/run/secrets/spicedb_token.txt"]))


@define(frozen=True, kw_only=True)
class PostgresConfig:

    dsn: str | None = field(factory=get_config_var(["PG_DB_DSN", "/run/secrets/pg_db_dsn.txt"]))


@define(frozen=True, kw_only=True)
class NATSConfig:

    urls: str | None = field(factory=get_config_var(["NATS_URLS", "/run/secrets/nats_urls.txt"]))
    seed: str | None = field(factory=get_config_var(["NATS_SEED", "/run/secrets/nats_seed.txt"]))
