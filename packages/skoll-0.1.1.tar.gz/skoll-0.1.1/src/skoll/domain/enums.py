from .base import Enum

__all__ = ["SortDirection", "BaseStatus"]


class SortDirection(Enum):

    ASCENDING = "ASC"
    DESCENDING = "DESC"


class BaseStatus(Enum):

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    DELETED = "DELETED"
    ARCHIVED = "ARCHIVED"
