from skrift.lib.template import Template

__all__ = ["Template"]
