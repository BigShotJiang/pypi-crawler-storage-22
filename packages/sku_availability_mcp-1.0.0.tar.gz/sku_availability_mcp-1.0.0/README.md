# SKU Availability MCP Server

A Model Context Protocol (MCP) server that provides real-time inventory availability queries from Confluent Cloud ksqlDB.

## Features

- 🔍 Real-time SKU availability queries
- ☁️ Integration with Confluent Cloud ksqlDB
- ⚡ FastMCP-based server implementation
- 🎯 Filter by SKU and/or branch
- 🔌 Easy integration with watsonx Orchestrate

## Installation

```bash
pip install sku-availability-mcp
```

## Configuration

Set the following environment variables:

```bash
export KSQLDB_API_KEY="your-api-key"
export KSQLDB_API_SECRET="your-api-secret"
export KSQLDB_ENDPOINT="https://your-ksqldb-endpoint.confluent.cloud:443"
```

Or create a `.env` file:

```env
KSQLDB_API_KEY=your-api-key
KSQLDB_API_SECRET=your-api-secret
KSQLDB_ENDPOINT=https://your-ksqldb-endpoint.confluent.cloud:443
```

## Usage

### Run as a module

```bash
python -m sku_availability_mcp
```

### Run as a command

```bash
sku-availability-mcp
```

### Use with watsonx Orchestrate

Add the toolkit using the orchestrate CLI:

```bash
orchestrate toolkits add \
  --kind mcp \
  --name "sku-availability-toolkit" \
  --description "Real-time inventory availability from Confluent Cloud" \
  --language python \
  --package "sku-availability-mcp" \
  --tools "*"
```

## Available Tools

### get_sku_availability

Query real-time inventory availability for SKUs across branches.

**Parameters:**
- `sku` (optional): SKU filter (e.g., 'LAPTOP-DELL-XPS-15')
- `branch` (optional): Branch filter (e.g., 'DubaiMall', 'MallOfEgypt')

**Returns:**
JSON object with availability records containing:
- `sku`: Product SKU
- `branch`: Store branch name
- `available_quantity`: Current available quantity

**Example:**

```python
# Get all inventory
get_sku_availability()

# Get specific SKU
get_sku_availability(sku="LAPTOP-DELL-XPS-15")

# Get inventory for specific branch
get_sku_availability(branch="DubaiMall")

# Get specific SKU at specific branch
get_sku_availability(sku="LAPTOP-DELL-XPS-15", branch="DubaiMall")
```

## Architecture

This MCP server connects to Confluent Cloud ksqlDB to query the `INVENTORY_AVAILABILITY` table, which aggregates real-time inventory transactions from Kafka topics.

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues and questions, please open an issue on GitHub.