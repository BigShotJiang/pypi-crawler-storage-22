from setuptools import setup, find_packages
import os

# Read the README file for long description
long_description = """
# SKU Availability MCP Server

A Model Context Protocol (MCP) server that provides real-time inventory availability 
queries from Confluent Cloud ksqlDB.

## Features

- Real-time SKU availability queries
- Integration with Confluent Cloud ksqlDB
- FastMCP-based server implementation
- Filter by SKU and/or branch

## Installation

```bash
pip install sku-availability-mcp
```

## Usage

Run as a module:
```bash
python -m sku_availability_mcp
```

## Configuration

Set the following environment variables:
- `KSQLDB_API_KEY`: Your ksqlDB API key
- `KSQLDB_API_SECRET`: Your ksqlDB API secret
- `KSQLDB_ENDPOINT`: Your ksqlDB endpoint URL

## License

MIT License
"""

setup(
    name="sku-availability-mcp",
    version="1.0.0",
    author="Bob AI Assistant",
    author_email="bob@example.com",
    description="MCP server for real-time SKU availability queries via Confluent Cloud ksqlDB",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/sku-availability-mcp",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "fastmcp>=2.14.4",
        "requests>=2.32.0",
        "python-dotenv>=1.0.0",
    ],
    entry_points={
        "console_scripts": [
            "sku-availability-mcp=sku_availability_mcp.server:main",
        ],
    },
    keywords="mcp model-context-protocol confluent kafka ksqldb inventory",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/sku-availability-mcp/issues",
        "Source": "https://github.com/yourusername/sku-availability-mcp",
    },
)

# Made with Bob
