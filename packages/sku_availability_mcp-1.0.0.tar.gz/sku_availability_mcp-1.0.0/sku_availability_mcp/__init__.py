"""
SKU Availability MCP Server
Real-time inventory availability queries via Confluent Cloud ksqlDB
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .server import mcp, get_sku_availability

__all__ = ["mcp", "get_sku_availability"]

# Made with Bob
