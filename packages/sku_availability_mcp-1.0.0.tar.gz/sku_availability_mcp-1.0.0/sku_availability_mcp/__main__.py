"""
Entry point for running the SKU Availability MCP server as a module
"""

from .server import mcp

if __name__ == "__main__":
    mcp.run()

# Made with Bob
