"""Mithril cloud adaptor."""
