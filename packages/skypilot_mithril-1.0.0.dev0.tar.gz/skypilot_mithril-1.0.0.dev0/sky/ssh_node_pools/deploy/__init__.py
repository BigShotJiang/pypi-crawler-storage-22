"""Module for Deploying SSH Node Pools"""
from sky.ssh_node_pools.deploy.deploy import run

__all__ = ['run']
