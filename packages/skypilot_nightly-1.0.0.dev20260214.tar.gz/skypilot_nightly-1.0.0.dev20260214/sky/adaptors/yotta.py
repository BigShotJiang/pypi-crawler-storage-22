"""Yotta cloud adaptor."""
