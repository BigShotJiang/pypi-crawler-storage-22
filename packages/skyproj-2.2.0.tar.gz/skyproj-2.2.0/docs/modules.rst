skyproj modules
===============

.. toctree::
    :maxdepth: 4

skyproj
-------
.. automodule:: skyproj.skyproj
    :members:
    :inherited-members:
    :show-inheritance:

Skyproj
-------
.. automodule:: skyproj.Skyproj
    :members:
    :inherited-members:
    :show-inheritance:

Survey
------
.. automodule:: skyproj.survey
    :members:
    :inherited-members:
    :show-inheritance:

SkyAxes
-------
.. automodule:: skyproj.SkyAxes
    :members:
    :inherited-members:
    :show-inheritance:

SkyCRS
------
.. automodule:: skyproj.SkyCRS
    :members:
    :inherited-members:
    :show-inheritance:
