Quickstart
==========

Multiple tutorial `jupyter notebooks <http://jupyter-notebook.readthedocs.io/en/latest/>`_ are available here:

* `Base class tutorial <https://github.com/LSSTDESC/skyproj/blob/main/tutorial/tutorial_baseclass.ipynb>`_
* `HealSparse tutorial <https://github.com/LSSTDESC/skyproj/blob/main/tutorial/tutorial_healsparse.ipynb>`_
* `Survey tutorial <https://github.com/LSSTDESC/skyproj/blob/main/tutorial/tutorial_surveys.ipynb>`_
