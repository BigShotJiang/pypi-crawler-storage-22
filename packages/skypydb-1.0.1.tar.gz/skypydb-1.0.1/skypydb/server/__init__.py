"""
Server module for Skypydb.
"""
