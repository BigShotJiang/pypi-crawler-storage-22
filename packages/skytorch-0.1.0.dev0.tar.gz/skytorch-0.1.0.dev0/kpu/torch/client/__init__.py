"""
KPU PyTorch gRPC client.
"""
