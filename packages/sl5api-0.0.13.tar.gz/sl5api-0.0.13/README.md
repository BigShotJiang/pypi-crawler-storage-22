# SimpLight SCADA v5 gRPC API

Use this package to work with SimpLight SCADA v5. The package implements a scripting API that is available in system scripts in Lua language.
