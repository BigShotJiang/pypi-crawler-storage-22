from typing import Any
from .pb import sl5_api_pb2

AlarmStatus = sl5_api_pb2.AlarmStatus

class Tag:
  tag_id: int
  name: str
  value: Any
  quality: int
  high_scale: float
  low_scale: float
  lo_lo_alarm: float
  lo_alarm: float
  hi_alarm: float
  hi_hi_alarm: float
  alarm_status: AlarmStatus

  def __init__(self):
    pass