#!/bin/bash

set -e 

# Собрать пакеты
py -m build

# Запушить собранные пакеты
py -m twine upload dist/*