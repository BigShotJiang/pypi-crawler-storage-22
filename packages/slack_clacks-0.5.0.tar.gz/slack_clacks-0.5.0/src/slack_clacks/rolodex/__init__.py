"""
Rolodex: Local cache for user and channel metadata.
"""
