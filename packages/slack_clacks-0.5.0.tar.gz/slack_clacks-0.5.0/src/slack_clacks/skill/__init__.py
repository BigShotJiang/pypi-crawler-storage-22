"""
Skill: Agent Skills integration for clacks.
"""
