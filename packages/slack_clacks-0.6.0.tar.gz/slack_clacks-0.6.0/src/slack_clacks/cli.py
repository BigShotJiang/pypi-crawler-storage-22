import argparse
from importlib.metadata import version

from slack_clacks.auth.cli import generate_cli as generate_auth_cli
from slack_clacks.configuration.cli import generate_cli as generate_config_cli
from slack_clacks.listen.cli import generate_listen_parser
from slack_clacks.messaging.cli import (
    generate_delete_parser,
    generate_react_parser,
    generate_read_parser,
    generate_recent_parser,
    generate_send_parser,
)
from slack_clacks.rolodex.cli import generate_cli as generate_rolodex_cli
from slack_clacks.skill.cli import generate_cli as generate_skill_cli


def generate_cli() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="clacks: the default mode of degenerate communication."
    )
    parser.add_argument(
        "--version",
        action="version",
        version=version("slack-clacks"),
    )
    parser.set_defaults(func=lambda _: parser.print_help())
    subparsers = parser.add_subparsers()

    config_parser = generate_config_cli()
    subparsers.add_parser(
        "config",
        parents=[config_parser],
        add_help=False,
        help=config_parser.description,
    )

    auth_parser = generate_auth_cli()
    subparsers.add_parser(
        "auth", parents=[auth_parser], add_help=False, help=auth_parser.description
    )

    rolodex_parser = generate_rolodex_cli()
    subparsers.add_parser(
        "rolodex",
        parents=[rolodex_parser],
        add_help=False,
        help=rolodex_parser.description,
    )

    send_parser = generate_send_parser()
    subparsers.add_parser(
        "send",
        parents=[send_parser],
        add_help=False,
        help=send_parser.description,
    )

    read_parser = generate_read_parser()
    subparsers.add_parser(
        "read",
        parents=[read_parser],
        add_help=False,
        help=read_parser.description,
    )

    recent_parser = generate_recent_parser()
    subparsers.add_parser(
        "recent",
        parents=[recent_parser],
        add_help=False,
        help=recent_parser.description,
    )

    react_parser = generate_react_parser()
    subparsers.add_parser(
        "react",
        parents=[react_parser],
        add_help=False,
        help=react_parser.description,
    )

    delete_parser = generate_delete_parser()
    subparsers.add_parser(
        "delete",
        parents=[delete_parser],
        add_help=False,
        help=delete_parser.description,
    )

    skill_parser = generate_skill_cli()
    subparsers.add_parser(
        "skill",
        parents=[skill_parser],
        add_help=False,
        help=skill_parser.description,
    )

    listen_parser = generate_listen_parser()
    subparsers.add_parser(
        "listen",
        parents=[listen_parser],
        add_help=False,
        help=listen_parser.description,
    )

    return parser
