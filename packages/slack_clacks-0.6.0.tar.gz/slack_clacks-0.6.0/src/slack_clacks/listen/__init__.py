"""
Slack channel listening operations.
"""
