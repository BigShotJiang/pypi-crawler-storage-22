"""Task lifecycle management."""
