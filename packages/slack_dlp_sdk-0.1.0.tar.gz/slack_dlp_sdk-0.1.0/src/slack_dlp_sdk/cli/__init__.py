"""CLI module for Slack DLP SDK."""

from .cli_client import main

__all__ = ["main"]
