"""Reverse mode autodiff library and NLP solver DSL"""

from ._sleipnir import *

__version__ = "0.3.4"
