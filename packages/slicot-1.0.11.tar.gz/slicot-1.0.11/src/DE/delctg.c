/*
 * SPDX-License-Identifier: BSD-3-Clause
 * Copyright (c) 1996-2025, The SLICOT Team (original Fortran77 code)
 * Copyright (c) 2025, slicot.c contributors (C11 translation)
 */

#include "slicot.h"

int delctg(const f64* alphar, const f64* alphai, const f64* beta)
{
    (void)alphar;
    (void)alphai;
    (void)beta;
    return 1;
}
