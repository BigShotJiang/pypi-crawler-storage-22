"""
SlideDeck AI: Co-create PowerPoint presentations with AI.
"""
from ._version import __version__  # type: ignore
