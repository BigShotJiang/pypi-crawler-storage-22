"""Core module - configuration, secrets, HTTP client, and error handling."""
