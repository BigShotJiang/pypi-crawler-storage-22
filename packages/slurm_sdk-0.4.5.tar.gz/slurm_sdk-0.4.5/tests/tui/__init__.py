"""Tests for TUI components."""
