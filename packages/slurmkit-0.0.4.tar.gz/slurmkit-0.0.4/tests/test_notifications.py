"""Tests for slurmkit.notifications module."""

from argparse import Namespace
from pathlib import Path
import smtplib

import yaml

from slurmkit.collections import CollectionManager
from slurmkit.config import Config
from slurmkit.notification_formatters import (
    render_default_chat,
    render_default_email_body,
    render_default_email_subject,
)
from slurmkit.notifications import (
    DeliveryResult,
    EVENT_COLLECTION_COMPLETED,
    EVENT_JOB_COMPLETED,
    EVENT_JOB_FAILED,
    EVENT_TEST,
    NotificationService,
    SCHEMA_VERSION,
)


def _make_config(tmp_path: Path, data: dict) -> Config:
    """Create config file and return Config instance."""
    config_dir = tmp_path / ".slurm-kit"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(data, f)
    return Config(project_root=tmp_path)


def test_route_defaults_event_subscription(tmp_path):
    """Routes without events default to job_failed."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {"name": "default_route", "type": "webhook", "url": "https://example.test/hook"}
                ]
            }
        },
    )
    service = NotificationService(config=config)

    failed = service.resolve_routes(event=EVENT_JOB_FAILED)
    completed = service.resolve_routes(event=EVENT_JOB_COMPLETED)

    assert len(failed.routes) == 1
    assert len(completed.routes) == 0


def test_env_interpolation_success(tmp_path, monkeypatch):
    """Route URL and headers support ${ENV_VAR} interpolation."""
    monkeypatch.setenv("TEST_NOTIFY_URL", "https://hooks.example.test/abc")
    monkeypatch.setenv("TEST_NOTIFY_TOKEN", "secret-token")

    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "env_route",
                        "type": "webhook",
                        "url": "${TEST_NOTIFY_URL}",
                        "headers": {"Authorization": "Bearer ${TEST_NOTIFY_TOKEN}"},
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)

    assert resolution.errors == []
    assert len(resolution.routes) == 1
    route = resolution.routes[0]
    assert route.url == "https://hooks.example.test/abc"
    assert route.headers["Authorization"] == "Bearer secret-token"


def test_env_interpolation_missing_var_is_route_error(tmp_path, monkeypatch):
    """Missing env vars should become route-level errors."""
    monkeypatch.delenv("MISSING_NOTIFY_URL", raising=False)
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {"name": "bad_route", "type": "webhook", "url": "${MISSING_NOTIFY_URL}"}
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)

    assert len(resolution.routes) == 0
    assert len(resolution.errors) == 1
    assert "Missing environment variable" in resolution.errors[0]


def test_route_filtering_and_unknown_route_error(tmp_path):
    """Route filtering should select requested routes and flag unknown names."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {"name": "a", "type": "webhook", "url": "https://example.test/a"},
                    {"name": "b", "type": "webhook", "url": "https://example.test/b"},
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(
        event=EVENT_JOB_FAILED,
        route_names=["b", "missing"],
    )

    assert [route.name for route in resolution.routes] == ["b"]
    assert len(resolution.errors) == 1
    assert "Unknown notification route 'missing'" in resolution.errors[0]


def test_route_filtering_ignores_unselected_route_parse_errors(tmp_path, monkeypatch):
    """Filtering to specific routes should not parse unrelated routes."""
    monkeypatch.delenv("MISSING_NOTIFY_URL", raising=False)
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {"name": "broken", "type": "webhook", "url": "${MISSING_NOTIFY_URL}"},
                    {"name": "ok", "type": "webhook", "url": "https://example.test/ok"},
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(
        event=EVENT_JOB_FAILED,
        route_names=["ok"],
    )

    assert [route.name for route in resolution.routes] == ["ok"]
    assert resolution.errors == []


def test_route_retry_timeout_backoff_fallbacks(tmp_path):
    """Routes should inherit retry/timeout values from defaults."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "defaults": {
                    "events": [EVENT_JOB_FAILED],
                    "timeout_seconds": 7,
                    "max_attempts": 4,
                    "backoff_seconds": 0.25,
                },
                "routes": [
                    {"name": "inherits", "type": "webhook", "url": "https://example.test/hook"}
                ],
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    route = resolution.routes[0]

    assert route.timeout_seconds == 7
    assert route.max_attempts == 4
    assert route.backoff_seconds == 0.25


def test_build_payload_collection_match_and_failure_tail(tmp_path):
    """A matching collection should enrich payload and include failure tail."""
    output_path = tmp_path / "job.out"
    output_path.write_text("line1\nline2\nline3\n")

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "routes": [
                    {"name": "hook", "type": "webhook", "url": "https://example.test/hook"}
                ]
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp1")
    collection.add_job(job_name="train", job_id="123", output_path=output_path, state="FAILED")
    manager.save(collection)

    service = NotificationService(config=config)
    payload, warnings = service.build_job_payload(
        job_id="123",
        exit_code=1,
        event=EVENT_JOB_FAILED,
        tail_lines=2,
    )

    assert warnings == []
    assert payload["schema_version"] == SCHEMA_VERSION
    assert payload["context_source"] == "collection_match"
    assert payload["collection"]["name"] == "exp1"
    assert payload["job"]["job_name"] == "train"
    assert payload["job"]["output_tail"] == "line2\nline3"
    assert payload["ai_status"] == "disabled"
    assert payload["ai_summary"] is None


def test_build_payload_no_match_is_env_only(tmp_path):
    """Missing collection match should still produce a valid env-only payload."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {"name": "hook", "type": "webhook", "url": "https://example.test/hook"}
                ]
            }
        },
    )
    service = NotificationService(config=config)
    payload, warnings = service.build_job_payload(
        job_id="999",
        exit_code=1,
        event=EVENT_JOB_FAILED,
    )

    assert payload["context_source"] == "env_only"
    assert payload["collection"] is None
    assert warnings == []


def test_build_payload_ambiguous_match_warns_and_uses_env_only(tmp_path):
    """Ambiguous job IDs across collections should not pick one arbitrarily."""
    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "routes": [
                    {"name": "hook", "type": "webhook", "url": "https://example.test/hook"}
                ]
            },
        },
    )
    manager = CollectionManager(config=config)
    c1 = manager.create("exp1")
    c1.add_job(job_name="job_a", job_id="321")
    manager.save(c1)
    c2 = manager.create("exp2")
    c2.add_job(job_name="job_b", job_id="321")
    manager.save(c2)

    service = NotificationService(config=config)
    payload, warnings = service.build_job_payload(
        job_id="321",
        exit_code=1,
        event=EVENT_JOB_FAILED,
    )

    assert payload["context_source"] == "ambiguous_match"
    assert payload["collection"] is None
    assert len(warnings) == 1
    assert "multiple collections" in warnings[0]


def test_output_tail_only_for_failed_event(tmp_path):
    """Output tail should not be attached for successful completion events."""
    output_path = tmp_path / "job.out"
    output_path.write_text("hello\nworld\n")

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "routes": [
                    {"name": "hook", "type": "webhook", "url": "https://example.test/hook"}
                ]
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.add_job(job_name="job", job_id="777", output_path=output_path, state="COMPLETED")
    manager.save(collection)

    service = NotificationService(config=config)
    payload, _ = service.build_job_payload(
        job_id="777",
        exit_code=0,
        event=EVENT_JOB_COMPLETED,
    )
    assert payload["job"]["output_tail"] is None


def test_job_ai_callback_disabled_by_default(tmp_path):
    """Job AI callback should default to disabled when not configured."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {"name": "hook", "type": "webhook", "url": "https://example.test/hook"}
                ]
            }
        },
    )
    service = NotificationService(config=config)
    payload, _ = service.build_job_payload(
        job_id="777",
        exit_code=0,
        event=EVENT_JOB_COMPLETED,
    )
    ai_summary, ai_status, warning = service.run_job_ai_callback(payload)

    assert ai_summary is None
    assert ai_status == "disabled"
    assert warning is None


def test_job_ai_callback_enrichment_updates_payload(tmp_path, monkeypatch):
    """Enabled job AI callback should produce available summary for payload enrichment."""
    module_path = tmp_path / "job_ai_module.py"
    module_path.write_text(
        "def summarize(payload):\n"
        "    return f\"Job AI summary for {payload['job']['job_id']}\"\n"
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "job": {
                    "ai": {
                        "enabled": True,
                        "callback": "job_ai_module:summarize",
                    }
                },
                "routes": [
                    {"name": "hook", "type": "webhook", "url": "https://example.test/hook"}
                ],
            }
        },
    )
    service = NotificationService(config=config)
    payload, _ = service.build_job_payload(
        job_id="777",
        exit_code=1,
        event=EVENT_JOB_FAILED,
    )
    ai_summary, ai_status, warning = service.run_job_ai_callback(payload)
    payload["ai_status"] = ai_status
    payload["ai_summary"] = ai_summary

    assert warning is None
    assert payload["ai_status"] == "available"
    assert payload["ai_summary"] == "Job AI summary for 777"


def test_dispatch_applies_global_formatter_callback_for_chat_and_email(tmp_path, monkeypatch):
    """Global formatter callback should apply to both chat and email route rendering."""
    module_path = tmp_path / "formatter_cb_global.py"
    module_path.write_text(
        "def render(payload):\n"
        "    name = payload.get('meta', {}).get('route_name', 'unknown')\n"
        "    return {\n"
        "        'chat': f'chat-{name}',\n"
        "        'email_subject': f'subject-{name}',\n"
        "        'email_body': f'body-{name}',\n"
        "    }\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "formatter": {"callback": "formatter_cb_global:render"},
                "routes": [
                    {"name": "team_slack", "type": "slack", "url": "https://example.test/slack"},
                    {
                        "name": "team_email",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                    },
                ],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    captured = {"json": {}, "email": {}}

    def fake_send_json(route, payload, dry_run=False):
        captured["json"][route.name] = payload
        return DeliveryResult(route_name=route.name, route_type=route.route_type, success=True, attempts=0, dry_run=True)

    def fake_send_email(route, payload, subject=None, body=None, dry_run=False):
        captured["email"][route.name] = {"subject": subject, "body": body}
        return DeliveryResult(route_name=route.name, route_type=route.route_type, success=True, attempts=0, dry_run=True)

    monkeypatch.setattr(service, "_send_json", fake_send_json)
    monkeypatch.setattr(service, "_send_email", fake_send_email)

    results = service.dispatch(payload=payload, routes=routes, dry_run=True)

    assert all(result.success for result in results)
    assert all(result.warning is None for result in results)
    assert captured["json"]["team_slack"]["text"] == "chat-team_slack"
    assert captured["email"]["team_email"]["subject"] == "subject-team_email"
    assert captured["email"]["team_email"]["body"] == "body-team_email"


def test_route_formatter_callback_overrides_global_callback(tmp_path, monkeypatch):
    """Route-level formatter callback should take precedence over global callback."""
    module_path = tmp_path / "formatter_cb_override.py"
    module_path.write_text(
        "def global_render(_payload):\n"
        "    return {'chat': 'global-chat'}\n"
        "def route_render(_payload):\n"
        "    return {'chat': 'route-chat'}\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "formatter": {"callback": "formatter_cb_override:global_render"},
                "routes": [
                    {
                        "name": "team_slack",
                        "type": "slack",
                        "url": "https://example.test/slack",
                        "formatter_callback": "formatter_cb_override:route_render",
                    }
                ],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    captured = {}

    def fake_send_json(route, payload, dry_run=False):
        captured[route.name] = payload
        return DeliveryResult(route_name=route.name, route_type=route.route_type, success=True, attempts=0, dry_run=True)

    monkeypatch.setattr(service, "_send_json", fake_send_json)

    results = service.dispatch(payload=payload, routes=routes, dry_run=True)
    assert results[0].warning is None
    assert captured["team_slack"]["text"] == "route-chat"


def test_route_formatter_callback_null_disables_global_callback(tmp_path, monkeypatch):
    """Route-level null formatter_callback should disable a configured global callback."""
    module_path = tmp_path / "formatter_cb_null.py"
    module_path.write_text(
        "def global_render(_payload):\n"
        "    return {'chat': 'global-chat'}\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "formatter": {"callback": "formatter_cb_null:global_render"},
                "routes": [
                    {
                        "name": "team_slack",
                        "type": "slack",
                        "url": "https://example.test/slack",
                        "formatter_callback": None,
                    }
                ],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    captured = {}

    def fake_send_json(route, payload, dry_run=False):
        captured[route.name] = payload
        return DeliveryResult(route_name=route.name, route_type=route.route_type, success=True, attempts=0, dry_run=True)

    monkeypatch.setattr(service, "_send_json", fake_send_json)

    results = service.dispatch(payload=payload, routes=routes, dry_run=True)
    assert results[0].warning is None
    assert captured["team_slack"]["text"].startswith("SLURMKIT: Test notification")


def test_formatter_callback_failure_falls_back_with_warning(tmp_path, monkeypatch):
    """Formatter callback failures should not block delivery and should fall back safely."""
    module_path = tmp_path / "formatter_cb_fail.py"
    module_path.write_text(
        "def broken(_payload):\n"
        "    raise RuntimeError('boom')\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "formatter": {"callback": "formatter_cb_fail:broken"},
                "routes": [{"name": "team_slack", "type": "slack", "url": "https://example.test/slack"}],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    captured = {}

    def fake_send_json(route, payload, dry_run=False):
        captured[route.name] = payload
        return DeliveryResult(route_name=route.name, route_type=route.route_type, success=True, attempts=0, dry_run=True)

    monkeypatch.setattr(service, "_send_json", fake_send_json)

    results = service.dispatch(payload=payload, routes=routes, dry_run=True)
    assert "failed" in (results[0].warning or "")
    assert captured["team_slack"]["text"] == render_default_chat(service._route_payload(routes[0], payload))


def test_formatter_callback_invalid_output_falls_back_with_warning(tmp_path, monkeypatch):
    """Invalid formatter callback fields should be ignored with warnings and safe fallback."""
    module_path = tmp_path / "formatter_cb_invalid.py"
    module_path.write_text(
        "def invalid(_payload):\n"
        "    return {'chat': 123, 'unknown_field': 'x'}\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "formatter": {"callback": "formatter_cb_invalid:invalid"},
                "routes": [{"name": "team_slack", "type": "slack", "url": "https://example.test/slack"}],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    captured = {}

    def fake_send_json(route, payload, dry_run=False):
        captured[route.name] = payload
        return DeliveryResult(route_name=route.name, route_type=route.route_type, success=True, attempts=0, dry_run=True)

    monkeypatch.setattr(service, "_send_json", fake_send_json)

    results = service.dispatch(payload=payload, routes=routes, dry_run=True)
    assert "unsupported keys" in (results[0].warning or "")
    assert "fields must be strings" in (results[0].warning or "")
    assert captured["team_slack"]["text"] == render_default_chat(service._route_payload(routes[0], payload))


def test_webhook_route_ignores_formatter_callback(tmp_path, monkeypatch):
    """Webhook route payload should remain canonical and skip formatter callback execution."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "formatter": {"callback": "missing.module:fn"},
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    captured = {}

    def fake_send_json(route, payload, dry_run=False):
        captured[route.name] = payload
        return DeliveryResult(route_name=route.name, route_type=route.route_type, success=True, attempts=0, dry_run=True)

    monkeypatch.setattr(service, "_send_json", fake_send_json)

    results = service.dispatch(payload=payload, routes=routes, dry_run=True)
    assert results[0].warning is None
    assert captured["hook"]["event"] == EVENT_TEST
    assert captured["hook"]["meta"]["route_name"] == "hook"
    assert captured["hook"]["meta"]["route_type"] == "webhook"


def test_resolve_routes_warns_on_invalid_global_formatter_callback_type(tmp_path):
    """Global formatter callback type errors should be surfaced as route warnings."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "formatter": {"callback": 123},
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)

    assert resolution.errors == []
    assert len(resolution.routes) == 1
    assert len(resolution.warnings) == 1
    assert "notifications.formatter.callback" in resolution.warnings[0]
    assert resolution.routes[0].formatter_callback is None


def test_resolve_routes_warns_on_invalid_route_formatter_callback_type(tmp_path):
    """Invalid route formatter_callback type should warn and continue with fallback formatter."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "hook",
                        "type": "webhook",
                        "url": "https://example.test/hook",
                        "formatter_callback": 123,
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)

    assert resolution.errors == []
    assert len(resolution.routes) == 1
    assert len(resolution.warnings) == 1
    assert "formatter_callback" in resolution.warnings[0]
    assert resolution.routes[0].formatter_callback is None


def test_default_email_formatter_helpers(tmp_path):
    """Default email subject/body helpers should match fallback formatter output."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            }
        },
    )
    service = NotificationService(config=config)
    payload = service.build_test_payload()

    assert render_default_email_subject(payload) == "SLURMKIT: test_notification"
    assert render_default_email_body(payload).startswith("SLURMKIT: Test notification")


def test_dispatch_retries_then_succeeds(tmp_path, monkeypatch):
    """HTTP 5xx should be retried until success within max_attempts."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "defaults": {"max_attempts": 3, "backoff_seconds": 0.01},
                "routes": [
                    {"name": "hook", "type": "webhook", "url": "https://example.test/hook"}
                ],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()

    class _Response:
        def __init__(self, status_code):
            self.status_code = status_code
            self.text = ""

    calls = {"count": 0}

    def fake_post(*_args, **_kwargs):
        calls["count"] += 1
        if calls["count"] == 1:
            return _Response(500)
        return _Response(200)

    import slurmkit.notifications as notifications_module

    monkeypatch.setattr(notifications_module, "requests", Namespace(post=fake_post))
    monkeypatch.setattr(notifications_module.time, "sleep", lambda *_args, **_kwargs: None)

    results = service.dispatch(payload=payload, routes=routes, dry_run=False)
    assert len(results) == 1
    assert results[0].success is True
    assert results[0].attempts == 2


def test_partial_success_evaluation_strict_vs_non_strict(tmp_path, monkeypatch):
    """Strict mode should fail on partial route failures."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "defaults": {"max_attempts": 1},
                "routes": [
                    {"name": "ok", "type": "webhook", "url": "https://example.test/ok"},
                    {"name": "bad", "type": "webhook", "url": "https://example.test/bad"},
                ],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()

    class _Response:
        def __init__(self, status_code):
            self.status_code = status_code
            self.text = ""

    def fake_post(url, **_kwargs):
        if url.endswith("/ok"):
            return _Response(200)
        return _Response(500)

    import slurmkit.notifications as notifications_module

    monkeypatch.setattr(notifications_module, "requests", Namespace(post=fake_post))
    monkeypatch.setattr(notifications_module.time, "sleep", lambda *_args, **_kwargs: None)

    results = service.dispatch(payload=payload, routes=routes, dry_run=False)

    assert sum(1 for r in results if r.success) == 1
    assert service.evaluate_delivery(results, strict=False) == 0
    assert service.evaluate_delivery(results, strict=True) == 1


def test_email_route_parses_recipients_and_defaults(tmp_path):
    """Email route should parse recipients and apply SMTP defaults."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com, ml@example.com, ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)

    assert resolution.errors == []
    assert len(resolution.routes) == 1
    route = resolution.routes[0]
    assert route.route_type == "email"
    assert route.email_to == ["ops@example.com", "ml@example.com"]
    assert route.email_from == "noreply@example.com"
    assert route.smtp_host == "smtp.example.com"
    assert route.smtp_port == 587
    assert route.smtp_starttls is True
    assert route.smtp_ssl is False


def test_email_route_accepts_list_recipients(tmp_path):
    """Email route should accept recipient list format."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": ["ops@example.com", "ml@example.com"],
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    assert resolution.errors == []
    assert resolution.routes[0].email_to == ["ops@example.com", "ml@example.com"]


def test_email_route_missing_required_fields(tmp_path):
    """Email route requires to/from/smtp_host fields."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {"name": "m1", "type": "email", "from": "x@example.com", "smtp_host": "smtp.example.com"},
                    {"name": "m2", "type": "email", "to": ["x@example.com"], "smtp_host": "smtp.example.com"},
                    {"name": "m3", "type": "email", "to": ["x@example.com"], "from": "x@example.com"},
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    assert len(resolution.routes) == 0
    assert len(resolution.errors) == 3
    joined = "\n".join(resolution.errors)
    assert "required field 'to'" in joined
    assert "required field 'from'" in joined
    assert "required field 'smtp_host'" in joined


def test_email_route_invalid_tls_ssl_combination(tmp_path):
    """STARTTLS and SMTP SSL cannot both be enabled."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                        "smtp_starttls": True,
                        "smtp_ssl": True,
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    assert len(resolution.routes) == 0
    assert len(resolution.errors) == 1
    assert "cannot enable both smtp_starttls and smtp_ssl" in resolution.errors[0]


def test_email_route_invalid_auth_pair(tmp_path):
    """Username/password auth must be configured together."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                        "smtp_username": "user-only",
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    assert len(resolution.routes) == 0
    assert len(resolution.errors) == 1
    assert "smtp_username and smtp_password together" in resolution.errors[0]


def test_email_route_rejects_url_and_headers(tmp_path):
    """Email routes should not define webhook fields."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                        "url": "https://example.com/hook",
                    },
                    {
                        "name": "mail2",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                        "headers": {"X-Test": "1"},
                    },
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    assert len(resolution.routes) == 0
    assert len(resolution.errors) == 2
    assert "must not define field 'url'" in resolution.errors[0]
    assert "must not define field 'headers'" in resolution.errors[1]


def test_email_route_env_interpolation_success(tmp_path, monkeypatch):
    """Email fields support environment variable interpolation."""
    monkeypatch.setenv("MAIL_TO", "ops@example.com,ml@example.com")
    monkeypatch.setenv("MAIL_FROM", "noreply@example.com")
    monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
    monkeypatch.setenv("SMTP_PORT", "1025")
    monkeypatch.setenv("SMTP_STARTTLS", "false")
    monkeypatch.setenv("SMTP_SSL", "true")
    monkeypatch.setenv("SMTP_USER", "demo-user")
    monkeypatch.setenv("SMTP_PASS", "demo-pass")
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "${MAIL_TO}",
                        "from": "${MAIL_FROM}",
                        "smtp_host": "${SMTP_HOST}",
                        "smtp_port": "${SMTP_PORT}",
                        "smtp_starttls": "${SMTP_STARTTLS}",
                        "smtp_ssl": "${SMTP_SSL}",
                        "smtp_username": "${SMTP_USER}",
                        "smtp_password": "${SMTP_PASS}",
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    assert resolution.errors == []
    route = resolution.routes[0]
    assert route.email_to == ["ops@example.com", "ml@example.com"]
    assert route.email_from == "noreply@example.com"
    assert route.smtp_host == "smtp.example.com"
    assert route.smtp_port == 1025
    assert route.smtp_starttls is False
    assert route.smtp_ssl is True
    assert route.smtp_username == "demo-user"
    assert route.smtp_password == "demo-pass"


def test_email_route_env_interpolation_missing_var(tmp_path, monkeypatch):
    """Missing env interpolation in email fields should produce route error."""
    monkeypatch.delenv("MISSING_SMTP_HOST", raising=False)
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "${MISSING_SMTP_HOST}",
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED)
    assert len(resolution.routes) == 0
    assert len(resolution.errors) == 1
    assert "Missing environment variable" in resolution.errors[0]


def test_email_dispatch_dry_run_skips_smtp(tmp_path, monkeypatch):
    """Dry-run email dispatch should not call SMTP."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()

    class _FailSMTP:
        def __init__(self, *_args, **_kwargs):
            raise AssertionError("SMTP should not be called in dry-run mode")

    import slurmkit.notifications as notifications_module

    monkeypatch.setattr(notifications_module.smtplib, "SMTP", _FailSMTP)

    results = service.dispatch(payload=payload, routes=routes, dry_run=True)
    assert len(results) == 1
    assert results[0].success is True
    assert results[0].dry_run is True
    assert results[0].attempts == 0


def test_email_dispatch_smtp_success(tmp_path, monkeypatch):
    """Email dispatch should send through SMTP and mark success."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                        "smtp_username": "user",
                        "smtp_password": "pass",
                        "smtp_starttls": True,
                    }
                ]
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    calls = {"starttls": 0, "login": 0, "send": 0}

    class _SMTP:
        def __init__(self, *_args, **_kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

        def ehlo(self):
            return None

        def starttls(self):
            calls["starttls"] += 1

        def login(self, *_args):
            calls["login"] += 1

        def send_message(self, *_args):
            calls["send"] += 1

    import slurmkit.notifications as notifications_module

    monkeypatch.setattr(notifications_module.smtplib, "SMTP", _SMTP)
    monkeypatch.setattr(notifications_module.time, "sleep", lambda *_args, **_kwargs: None)

    results = service.dispatch(payload=payload, routes=routes, dry_run=False)
    assert len(results) == 1
    assert results[0].success is True
    assert results[0].attempts == 1
    assert calls["starttls"] == 1
    assert calls["login"] == 1
    assert calls["send"] == 1


def test_email_dispatch_retries_then_succeeds(tmp_path, monkeypatch):
    """Transient email send failures should retry and eventually succeed."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "defaults": {"max_attempts": 3, "backoff_seconds": 0.01},
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                    }
                ],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()
    calls = {"send": 0}

    class _SMTP:
        def __init__(self, *_args, **_kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

        def ehlo(self):
            return None

        def starttls(self):
            return None

        def send_message(self, *_args):
            calls["send"] += 1
            if calls["send"] == 1:
                raise OSError("temporary network issue")

    import slurmkit.notifications as notifications_module

    monkeypatch.setattr(notifications_module.smtplib, "SMTP", _SMTP)
    monkeypatch.setattr(notifications_module.time, "sleep", lambda *_args, **_kwargs: None)

    results = service.dispatch(payload=payload, routes=routes, dry_run=False)
    assert len(results) == 1
    assert results[0].success is True
    assert results[0].attempts == 2


def test_email_dispatch_permanent_failure(tmp_path, monkeypatch):
    """Permanent SMTP failures should return failed DeliveryResult after retries."""
    config = _make_config(
        tmp_path,
        {
            "notifications": {
                "defaults": {"max_attempts": 2, "backoff_seconds": 0.01},
                "routes": [
                    {
                        "name": "mail",
                        "type": "email",
                        "to": "ops@example.com",
                        "from": "noreply@example.com",
                        "smtp_host": "smtp.example.com",
                    }
                ],
            }
        },
    )
    service = NotificationService(config=config)
    routes = service.resolve_routes(event=None).routes
    payload = service.build_test_payload()

    class _SMTP:
        def __init__(self, *_args, **_kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

        def ehlo(self):
            return None

        def starttls(self):
            return None

        def send_message(self, *_args):
            raise smtplib.SMTPException("permanent failure")

    import slurmkit.notifications as notifications_module

    monkeypatch.setattr(notifications_module.smtplib, "SMTP", _SMTP)
    monkeypatch.setattr(notifications_module.time, "sleep", lambda *_args, **_kwargs: None)

    results = service.dispatch(payload=payload, routes=routes, dry_run=False)
    assert len(results) == 1
    assert results[0].success is False
    assert results[0].attempts == 2
    assert "permanent failure" in (results[0].error or "")


def test_build_payload_uses_spec_override_output_tail_lines(tmp_path):
    """Collection spec notifications defaults should override global output tail lines."""
    output_path = tmp_path / "job.out"
    output_path.write_text("line1\nline2\nline3\n", encoding="utf-8")

    spec_path = tmp_path / "specs" / "exp_spec.yaml"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text(
        "notifications:\n"
        "  defaults:\n"
        "    output_tail_lines: 1\n",
        encoding="utf-8",
    )

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "defaults": {"output_tail_lines": 3},
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.meta["generation"] = {"spec_path": "specs/exp_spec.yaml"}
    collection.add_job(job_name="train", job_id="123", output_path=output_path, state="FAILED")
    manager.save(collection)

    service = NotificationService(config=config)
    payload, warnings = service.build_job_payload(
        job_id="123",
        exit_code=1,
        event=EVENT_JOB_FAILED,
        collection_name="exp",
    )

    assert warnings == []
    assert payload["job"]["output_tail"] == "line3"


def test_resolve_routes_uses_spec_routes_replacement(tmp_path):
    """Spec routes should replace global routes for matched collections."""
    spec_path = tmp_path / "specs" / "exp_spec.yaml"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text(
        "notifications:\n"
        "  routes:\n"
        "    - name: spec_route\n"
        "      type: webhook\n"
        "      url: https://example.test/spec\n",
        encoding="utf-8",
    )

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "routes": [{"name": "global_route", "type": "webhook", "url": "https://example.test/global"}],
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.meta["generation"] = {"spec_path": "specs/exp_spec.yaml"}
    manager.save(collection)

    service = NotificationService(config=config)
    resolution = service.resolve_routes(event=EVENT_JOB_FAILED, collection_name="exp")

    assert resolution.errors == []
    assert [route.name for route in resolution.routes] == ["spec_route"]


def test_job_ai_callback_uses_spec_override(tmp_path, monkeypatch):
    """Job AI callback should resolve from collection spec notifications override."""
    module_path = tmp_path / "spec_ai_module.py"
    module_path.write_text(
        "def summarize(payload):\n"
        "    return f\"spec-ai-{payload['job']['job_id']}\"\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    spec_path = tmp_path / "specs" / "exp_spec.yaml"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text(
        "notifications:\n"
        "  job:\n"
        "    ai:\n"
        "      enabled: true\n"
        "      callback: spec_ai_module:summarize\n",
        encoding="utf-8",
    )

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "job": {"ai": {"enabled": True, "callback": "missing.module:fn"}},
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.meta["generation"] = {"spec_path": "specs/exp_spec.yaml"}
    collection.add_job(job_name="train", job_id="123", state="FAILED")
    manager.save(collection)

    service = NotificationService(config=config)
    payload, warnings = service.build_job_payload(
        job_id="123",
        exit_code=1,
        event=EVENT_JOB_FAILED,
        collection_name="exp",
    )
    assert warnings == []

    ai_summary, ai_status, warning = service.run_job_ai_callback(payload)
    assert warning is None
    assert ai_status == "available"
    assert ai_summary == "spec-ai-123"


def test_missing_spec_warns_and_falls_back_to_global_notifications(tmp_path):
    """Missing spec path should warn and continue using global notifications."""
    output_path = tmp_path / "job.out"
    output_path.write_text("line1\nline2\nline3\n", encoding="utf-8")

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "defaults": {"output_tail_lines": 2},
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.meta["generation"] = {"spec_path": "specs/missing.yaml"}
    collection.add_job(job_name="train", job_id="123", output_path=output_path, state="FAILED")
    manager.save(collection)

    service = NotificationService(config=config)
    payload, warnings = service.build_job_payload(
        job_id="123",
        exit_code=1,
        event=EVENT_JOB_FAILED,
        collection_name="exp",
    )

    assert payload["job"]["output_tail"] == "line2\nline3"
    assert len(warnings) == 1
    assert "Spec file not found" in warnings[0]


def test_invalid_spec_warns_and_falls_back_to_global_notifications(tmp_path):
    """Unreadable spec YAML should warn and fallback to global notifications."""
    spec_path = tmp_path / "specs" / "bad_spec.yaml"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text("notifications:\n  defaults: [\n", encoding="utf-8")

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.meta["generation"] = {"spec_path": "specs/bad_spec.yaml"}
    collection.add_job(job_name="train", job_id="123", state="FAILED")
    manager.save(collection)

    service = NotificationService(config=config)
    _payload, warnings = service.build_job_payload(
        job_id="123",
        exit_code=1,
        event=EVENT_JOB_FAILED,
        collection_name="exp",
    )

    assert len(warnings) == 1
    assert "Failed to read spec file" in warnings[0]


def test_non_mapping_notifications_in_spec_warns_and_falls_back(tmp_path):
    """Non-mapping notifications block should warn and fallback to global notifications."""
    spec_path = tmp_path / "specs" / "bad_notifications.yaml"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text("notifications:\n  - not\n  - mapping\n", encoding="utf-8")

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.meta["generation"] = {"spec_path": "specs/bad_notifications.yaml"}
    collection.add_job(job_name="train", job_id="123", state="FAILED")
    manager.save(collection)

    service = NotificationService(config=config)
    _payload, warnings = service.build_job_payload(
        job_id="123",
        exit_code=1,
        event=EVENT_JOB_FAILED,
        collection_name="exp",
    )

    assert len(warnings) == 1
    assert "notifications block" in warnings[0]


def test_spec_without_notifications_silently_uses_global(tmp_path):
    """Spec files without notifications should fallback silently to global config."""
    spec_path = tmp_path / "specs" / "plain_spec.yaml"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text("name: exp\n", encoding="utf-8")

    config = _make_config(
        tmp_path,
        {
            "collections_dir": ".job-collections/",
            "notifications": {
                "routes": [{"name": "hook", "type": "webhook", "url": "https://example.test/hook"}],
            },
        },
    )
    manager = CollectionManager(config=config)
    collection = manager.create("exp")
    collection.meta["generation"] = {"spec_path": "specs/plain_spec.yaml"}
    collection.add_job(job_name="train", job_id="123", state="FAILED")
    manager.save(collection)

    service = NotificationService(config=config)
    _payload, warnings = service.build_job_payload(
        job_id="123",
        exit_code=1,
        event=EVENT_JOB_FAILED,
        collection_name="exp",
    )

    assert warnings == []
