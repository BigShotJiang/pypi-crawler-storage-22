"""Entry point for running the MCP server via python -m small.mcp."""

from .server import run_server

if __name__ == "__main__":
    run_server()
