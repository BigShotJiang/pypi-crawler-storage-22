# Утилиты для работы с админскими событиями

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

import pytz

from ..handlers.handlers import get_global_var

logger = logging.getLogger(__name__)

# Московская временная зона
MOSCOW_TZ = pytz.timezone("Europe/Moscow")


# ========== Утилиты для редактирования событий ==========

def parse_json_data(data):
    """Парсит JSON данные (строку или словарь)"""
    if not data:
        return {}
    if isinstance(data, str):
        try:
            return json.loads(data)
        except Exception:
            return {}
    return data or {}


def format_executed_time(executed_at: str) -> str:
    """Форматирует время выполнения события для отображения"""
    if not executed_at:
        return "Дата неизвестна"
    try:
        utc_time = datetime.fromisoformat(executed_at.replace("Z", "+00:00"))
        moscow_time = utc_time.astimezone(MOSCOW_TZ)
        return moscow_time.strftime('%d.%m.%Y в %H:%M') + " МСК"
    except Exception:
        return "Дата неизвестна"


def check_edit_availability(executed_at: str) -> tuple[bool, timedelta | None]:
    """Проверяет возможность редактирования события (48 часов)"""
    if not executed_at:
        return False, None
    
    try:
        event_time = datetime.fromisoformat(executed_at.replace("Z", "+00:00"))
        if event_time.tzinfo is None:
            event_time = event_time.replace(tzinfo=timezone.utc)
        
        now = datetime.now(timezone.utc)
        time_diff = now - event_time
        can_edit = time_diff < timedelta(hours=48)
        
        if can_edit:
            time_remaining = timedelta(hours=48) - time_diff
            return True, time_remaining
        return False, None
    except Exception:
        return False, None


def format_time_remaining(time_remaining: timedelta) -> str:
    """Форматирует оставшееся время в человекочитаемом формате"""
    total_seconds = int(time_remaining.total_seconds())
    days = total_seconds // 86400
    hours = (total_seconds % 86400) // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    
    time_parts = []
    if days > 0:
        time_parts.append(f"{days} дн.")
    if hours > 0:
        time_parts.append(f"{hours} ч.")
    if minutes > 0:
        time_parts.append(f"{minutes} мин.")
    if seconds > 0 and len(time_parts) == 0:
        time_parts.append(f"{seconds} сек.")
    
    return " ".join(time_parts) if time_parts else "0 сек."


def get_message_from_data(result_data, event_data) -> str:
    """Получает сообщение из result_data (приоритет) или event_data"""
    parsed_result = parse_json_data(result_data)
    message = parsed_result.get("message", "")
    
    if not message:
        parsed_event = parse_json_data(event_data)
        message = parsed_event.get("message", "")
    
    return message


async def delete_user_messages(message_ids: dict) -> tuple[int, int]:
    """Удаляет сообщения у пользователей. Возвращает (успешно, ошибок)"""
    bot = get_global_var("bot")
    if not bot:
        logger.error("❌ Бот не найден для удаления сообщений")
        return 0, 0
    
    deleted_count = 0
    failed_count = 0
    
    for chat_id_str, message_id_list in message_ids.items():
        for msg_id in message_id_list:
            try:
                chat_id = int(chat_id_str)
                await bot.delete_message(chat_id=chat_id, message_id=msg_id)
                deleted_count += 1
            except Exception as e:
                logger.error(f"Ошибка удаления сообщения {msg_id} для пользователя {chat_id_str}: {e}")
                failed_count += 1
    
    return deleted_count, failed_count


async def edit_user_messages(message_ids: dict, new_message: str, message_type: str) -> tuple[int, int]:
    """Редактирует сообщения у пользователей. Возвращает (успешно, ошибок)"""
    from telegramify_markdown import standardize
    
    bot = get_global_var("bot")
    if not bot:
        logger.error("❌ Бот не найден для редактирования сообщений")
        return 0, 0
    
    standardized_message = standardize(new_message)
    edited_count = 0
    failed_count = 0
    
    for chat_id_str, message_id_list in message_ids.items():
        if not message_id_list:
            continue
        
        try:
            chat_id = int(chat_id_str)
            first_message_id = message_id_list[0]
            
            if message_type != "text":
                await bot.edit_message_caption(
                    chat_id=chat_id,
                    message_id=first_message_id,
                    caption=standardized_message,
                    parse_mode="MarkdownV2",
                )
            else:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=first_message_id,
                    text=standardized_message,
                    parse_mode="MarkdownV2",
                )
            edited_count += 1
        except Exception as e:
            logger.error(f"Ошибка редактирования сообщения для пользователя {chat_id_str}: {e}")
            failed_count += 1
    
    return edited_count, failed_count


def update_event_message_data(event_id: str, new_message: str) -> str:
    """Обновляет сообщение в event_data и result_data"""
    supabase_client = get_global_var("supabase_client")
    if not supabase_client:
        logger.error("❌ Supabase клиент не найден для обновления сообщения")
        return ""
    
    # Строим запрос с учетом bot_id
    query = (
        supabase_client.client.table("scheduled_events")
        .select("event_data, result_data")
        .eq("id", event_id)
    )
    
    # Фильтруем по bot_id только если он указан
    if supabase_client.bot_id:
        query = query.eq("bot_id", supabase_client.bot_id)
    
    result = query.execute()
    
    if not result.data:
        return ""
    
    event_data = parse_json_data(result.data[0].get("event_data"))
    result_data = parse_json_data(result.data[0].get("result_data"))
    
    old_message = result_data.get("message", "") or event_data.get("message", "")
    
    event_data["message"] = new_message
    result_data["message"] = new_message
    
    # Строим запрос обновления с учетом bot_id
    update_query = (
        supabase_client.client.table("scheduled_events")
        .update({
            "event_data": json.dumps(event_data, ensure_ascii=False),
            "result_data": json.dumps(result_data, ensure_ascii=False)
        })
        .eq("id", event_id)
    )
    
    # Фильтруем по bot_id только если он указан
    if supabase_client.bot_id:
        update_query = update_query.eq("bot_id", supabase_client.bot_id)
    
    update_query.execute()
    
    return old_message


# ========== Константы ==========

# Лимиты Telegram API
MAX_TEXT_MESSAGE_LENGTH = 4096
MAX_CAPTION_LENGTH = 1024
EDIT_TIME_LIMIT_HOURS = 48
RECENT_EVENTS_COUNT = 5

# Тестовый пользователь
TEST_USERNAME = "test_user"


# ========== Утилиты для создания событий ==========

def create_segments_keyboard(segments: list):
    """Создает клавиатуру с сегментами (по 2 в ряд). Возвращает список списков для InlineKeyboardMarkup"""
    from aiogram.types import InlineKeyboardButton
    
    keyboard = []
    keyboard.append([InlineKeyboardButton(text="📢 Отправить всем", callback_data="segment:all")])
    
    if segments:
        for i in range(0, len(segments), 2):
            row = [InlineKeyboardButton(text=f"👥 {segments[i]}", callback_data=f"segment:{segments[i]}")]
            if i + 1 < len(segments):
                row.append(InlineKeyboardButton(text=f"👥 {segments[i+1]}", callback_data=f"segment:{segments[i+1]}"))
            keyboard.append(row)
    
    return keyboard


def filter_users_for_mailing(users: list, admin_manager, supabase_client) -> list:
    """Фильтрует пользователей для рассылки (убирает админов, тестовых, других ботов)"""
    # Фильтруем админов
    users = [user for user in users if not admin_manager.is_admin(user["telegram_id"])]
    
    # Фильтруем тестовых пользователей
    users = [user for user in users if user.get("username") != TEST_USERNAME]
    
    # Фильтруем по bot_id (только пользователи текущего бота)
    current_bot_id = supabase_client.bot_id
    if current_bot_id:
        users = [user for user in users if user.get("bot_id") == current_bot_id]
    
    return users


def format_time_display(is_immediate: bool, event_date: Optional[str] = None, event_time: Optional[str] = None) -> str:
    """Форматирует время для отображения"""
    if is_immediate:
        return "Прямо сейчас 🔥"
    
    if event_date and event_time:
        naive_datetime = datetime.strptime(f"{event_date} {event_time}", "%Y-%m-%d %H:%M")
        moscow_datetime = MOSCOW_TZ.localize(naive_datetime)
        return f"{moscow_datetime.strftime('%d.%m.%Y %H:%M')} (МСК)"
    
    return "Время не указано"


def get_message_type_limits(message_type: str) -> tuple[int, str, str]:
    """Возвращает лимиты и описания для типа сообщения"""
    if message_type == "text":
        return MAX_TEXT_MESSAGE_LENGTH, "текстового сообщения", "текстовое сообщение"
    elif message_type == "photo":
        return MAX_CAPTION_LENGTH, "подписи к фото", "подпись к фото"
    elif message_type == "video":
        return MAX_CAPTION_LENGTH, "подписи к видео", "подпись к видео"
    elif message_type == "document":
        return MAX_CAPTION_LENGTH, "подписи к документу", "подпись к документу"
    elif message_type == "media_group":
        return MAX_CAPTION_LENGTH, "подписи к группе медиа", "подпись к группе медиа (фото/видео)"
    else:
        return MAX_TEXT_MESSAGE_LENGTH, "сообщения", "сообщение"


def create_action_keyboard(can_edit: bool):
    """Создает клавиатуру с действиями для редактирования события"""
    from aiogram.types import InlineKeyboardButton
    
    keyboard_buttons = []
    if can_edit:
        keyboard_buttons.append([
            InlineKeyboardButton(text="✏️ Отредактировать сообщение", callback_data="edit_action:message")
        ])
    keyboard_buttons.append([
        InlineKeyboardButton(text="🗑️ Удалить событие", callback_data="edit_action:delete")
    ])
    keyboard_buttons.append([
        InlineKeyboardButton(text="❌ Отмена", callback_data="edit_action:cancel")
    ])
    return keyboard_buttons


def create_action_message_text(event_name: str, can_edit: bool, time_remaining=None) -> str:
    """Создает текст сообщения с действиями для редактирования"""
    message_text = f"✅ **Событие найдено:** `{event_name}`\n\n"
    
    if can_edit and time_remaining:
        time_str = format_time_remaining(time_remaining)
        message_text += (
            "💡 **Редактирование доступно**\n"
            f"⏰ Осталось времени: **{time_str}**\n"
            "_Сообщение можно изменить только в течение 48 часов с момента отправки_\n\n"
        )
    elif not can_edit:
        message_text += "⚠️ _Редактирование недоступно (событие старше 48 часов)_\n\n"
    
    message_text += "Выберите действие:"
    return message_text


# ========== Утилиты для работы с файлами ==========

async def download_and_save_file(
    bot, file_id: str, file_name: str, file_type: str, stage: str, has_caption: bool = False, order: Optional[int] = None, group_id: Optional[str] = None
) -> dict:
    """
    Скачивает и сохраняет файл. Возвращает словарь с информацией о файле.
    
    Args:
        bot: Экземпляр бота
        file_id: ID файла в Telegram
        file_name: Имя файла
        file_type: Тип файла (photo, video, document)
        stage: Стадия (with_message, after_message)
        has_caption: Есть ли подпись
        order: Порядок в альбоме (для with_message)
    
    Returns:
        dict: Информация о файле для сохранения в state
    """
    import os
    from datetime import datetime
    
    TEMP_DIR = "temp_event_files"
    
    # Скачиваем файл
    file = await bot.get_file(file_id)
    file_path = os.path.join(TEMP_DIR, file_name)
    await bot.download_file(file.file_path, file_path)
    
    file_info = {
        "type": file_type,
        "file_path": file_path,
        "name": file_name,
        "stage": stage,
    }
    
    if stage == "with_message":
        file_info["has_caption"] = has_caption
    
    # Сохраняем order для обоих стадий (with_message и after_message)
    if order is not None and order > 0:
        file_info["order"] = order
    
    # Сохраняем group_id для группировки медиа-групп
    if group_id:
        file_info["group_id"] = group_id
    
    return file_info


def generate_file_name(file_type: str, file_id: Optional[str] = None, file_name: Optional[str] = None, index: Optional[int] = None) -> str:
    """Генерирует имя файла в зависимости от типа"""
    from datetime import datetime
    
    if file_type == "photo":
        if index:
            return f"photo_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{index}.jpg"
        return f"photo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
    elif file_type == "video":
        return file_name or f"{file_id}.mp4"
    elif file_type == "document":
        return file_name or f"{file_id}"
    elif file_type == "audio":
        return file_name or f"{file_id}.ogg"
    return file_name or f"{file_id}"


def create_continue_keyboard():
    """Создает клавиатуру с кнопкой 'Продолжить без файлов'"""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="➡️ Продолжить без файлов", callback_data="files:skip"
                )
            ]
        ]
    )


def create_files_done_keyboard():
    """Создает клавиатуру с кнопкой 'Завершить добавление файлов'"""
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Завершить добавление файлов", callback_data="files:done"
                )
            ]
        ]
    )


def get_additional_files_message() -> str:
    """Возвращает текст сообщения о дополнительных файлах"""
    return (
        "✅ **Сообщение сохранено!**\n\n"
        "📎 **Дополнительные файлы**\n\n"
        "Теперь вы можете отправить:\n"
        "📄 PDF документы\n"
        "📁 Файлы любых форматов\n"
        "🎵 Аудио файлы\n"
        "🎥 Дополнительные видео\n"
        "🖼 Дополнительные фото\n\n"
        "💡 _Можно отправить несколько файлов по очереди_\n\n"
        "Или нажмите кнопку, если дополнительных файлов нет:"
    )


def extract_message_id(sent_message) -> Optional[int]:
    """Извлекает message_id из отправленного сообщения"""
    if sent_message and hasattr(sent_message, 'message_id'):
        return sent_message.message_id
    return None


def extract_message_ids_from_group(messages) -> list:
    """Извлекает message_id из группы сообщений (media_group)"""
    message_ids = []
    if messages:
        for msg in messages:
            msg_id = extract_message_id(msg)
            if msg_id:
                message_ids.append(msg_id)
    return message_ids


def truncate_text(text: str, max_length: int = 2000, suffix: str = "...") -> str:
    """Обрезает текст до указанной длины с добавлением суффикса"""
    if not text:
        return ""
    if len(text) <= max_length:
        return text
    truncated = text[:max_length - len(suffix)]
    return truncated + suffix + f"\n\n_⚠️ Текст обрезан (показано {max_length} из {len(text)} символов)_"


def get_max_order_for_stage(files: list, stage: str) -> int:
    """Получает максимальный order для указанной стадии"""
    existing_files = [f for f in files if f.get("stage") == stage]
    return max([f.get("order", 0) for f in existing_files], default=0)


def generate_group_id() -> str:
    """Генерирует уникальный ID для медиа-группы"""
    import uuid
    return f"group_{uuid.uuid4().hex[:8]}"


async def save_media_group_files(
    bot, messages: list, files: list, stage: str, max_order: int, group_id: str
) -> list:
    """
    Сохраняет файлы из медиа-группы.
    
    Args:
        bot: Экземпляр бота
        messages: Список сообщений из медиа-группы
        files: Текущий список файлов
        stage: Стадия сохранения (with_message, after_message)
        max_order: Максимальный порядок для этой стадии
        group_id: ID группы для этих файлов
    
    Returns:
        list: Обновленный список файлов
    """
    import logging
    
    logger = logging.getLogger(__name__)
    
    # Используем функции из того же модуля (без импорта, чтобы избежать циклических зависимостей)
    for i, message in enumerate(messages, 1):
        try:
            order = max_order + i
            file_info = None
            
            if message.photo:
                photo = message.photo[-1]
                file_name = generate_file_name("photo", index=i)
                file_info = await download_and_save_file(
                    bot, photo.file_id, file_name, "photo", stage, False, order, group_id
                )
                logger.info(f"Фото сохранено: {file_info['file_path']} (stage={stage}, order={order}, group_id={group_id})")
            
            elif message.video:
                file_name = generate_file_name("video", message.video.file_id, message.video.file_name, index=i)
                file_info = await download_and_save_file(
                    bot, message.video.file_id, file_name, "video", stage, False, order, group_id
                )
                logger.info(f"Видео сохранено: {file_info['file_path']} (stage={stage}, order={order}, group_id={group_id})")
            
            if file_info:
                files.append(file_info)
        
        except Exception as e:
            logger.error(f"❌ Ошибка загрузки файла {i} из медиа-группы: {e}")
            continue
    
    return files


def group_files_by_group_id(files: list) -> tuple[dict, list]:
    """
    Группирует файлы по group_id.
    
    Args:
        files: Список файлов
    
    Returns:
        tuple: (словарь групп {group_id: [files]}, список одиночных файлов)
    """
    groups = {}
    standalone_files = []
    
    for file_info in files:
        group_id = file_info.get("group_id")
        if group_id and file_info["type"] in ("photo", "video"):
            if group_id not in groups:
                groups[group_id] = []
            groups[group_id].append(file_info)
        else:
            standalone_files.append(file_info)
    
    return groups, standalone_files


def create_media_group_from_files(group_files: list):
    """
    Создает список InputMedia из файлов для отправки как media_group.
    
    Args:
        group_files: Список файлов одной группы
    
    Returns:
        list: Список InputMedia объектов
    """
    from aiogram.types import FSInputFile, InputMediaPhoto, InputMediaVideo
    import logging
    
    logger = logging.getLogger(__name__)
    media_group = []
    
    for file_info in group_files:
        try:
            if file_info["type"] == "photo":
                media = InputMediaPhoto(media=FSInputFile(file_info["file_path"]))
                media_group.append(media)
            elif file_info["type"] == "video":
                media = InputMediaVideo(media=FSInputFile(file_info["file_path"]))
                media_group.append(media)
        except Exception as e:
            logger.error(f"❌ Ошибка создания медиа для файла {file_info.get('name')}: {e}")
            continue
    
    return media_group


async def send_media_group_with_fallback(
    bot, chat_id: int, media_group: list, group_files: list,
    extract_message_id_func, extract_message_ids_from_group_func
) -> list:
    """
    Отправляет медиа-группу с fallback на отправку по одному при ошибке.
    
    Args:
        bot: Экземпляр бота
        chat_id: ID чата
        media_group: Список InputMedia объектов
        group_files: Исходные файлы для fallback
        extract_message_id_func: Функция извлечения message_id
        extract_message_ids_from_group_func: Функция извлечения message_ids из группы
    
    Returns:
        list: Список message_id отправленных сообщений
    """
    import logging
    from aiogram.types import FSInputFile
    
    logger = logging.getLogger(__name__)
    message_ids = []
    
    if not media_group:
        return message_ids
    
    try:
        messages = await bot.send_media_group(chat_id=chat_id, media=media_group)
        message_ids.extend(extract_message_ids_from_group_func(messages))
    except Exception as e:
        logger.error(f"❌ Ошибка отправки медиа-группы: {e}")
        # Fallback: отправляем по одному
        for file_info in group_files:
            try:
                if file_info["type"] == "photo":
                    sent_message = await bot.send_photo(chat_id=chat_id, photo=FSInputFile(file_info["file_path"]))
                elif file_info["type"] == "video":
                    sent_message = await bot.send_video(chat_id=chat_id, video=FSInputFile(file_info["file_path"]))
                msg_id = extract_message_id_func(sent_message)
                if msg_id:
                    message_ids.append(msg_id)
            except Exception as e2:
                logger.error(f"❌ Ошибка отправки отдельного файла из группы: {e2}")
    
    return message_ids


async def send_single_file(
    bot, chat_id: int, file_info: dict, extract_message_id_func
) -> int | None:
    """
    Отправляет одиночный файл.
    
    Args:
        bot: Экземпляр бота
        chat_id: ID чата
        file_info: Информация о файле
        extract_message_id_func: Функция извлечения message_id
    
    Returns:
        int | None: message_id или None при ошибке
    """
    import logging
    from aiogram.types import FSInputFile
    
    logger = logging.getLogger(__name__)
    
    try:
        sent_message = None
        if file_info["type"] == "document":
            sent_message = await bot.send_document(chat_id=chat_id, document=FSInputFile(file_info["file_path"]))
        elif file_info["type"] == "photo":
            sent_message = await bot.send_photo(chat_id=chat_id, photo=FSInputFile(file_info["file_path"]))
        elif file_info["type"] == "video":
            sent_message = await bot.send_video(chat_id=chat_id, video=FSInputFile(file_info["file_path"]))
        
        return extract_message_id_func(sent_message)
    except Exception as e:
        logger.error(f"❌ Ошибка отправки файла {file_info.get('name')}: {e}")
        return None


async def send_additional_files_grouped(bot, files_after: list, chat_id: int, extract_message_id_func, extract_message_ids_from_group_func) -> list:
    """
    Отправляет дополнительные файлы с группировкой медиа-групп.
    
    Args:
        bot: Экземпляр бота
        files_after: Список файлов с stage="after_message"
        chat_id: ID чата для отправки
        extract_message_id_func: Функция для извлечения message_id из одного сообщения
        extract_message_ids_from_group_func: Функция для извлечения message_ids из media_group
    
    Returns:
        list: Список message_id всех отправленных сообщений
    """
    message_ids = []
    sorted_files = sorted(files_after, key=lambda x: x.get("order", 0))
    
    # Группируем файлы по group_id
    groups, standalone_files = group_files_by_group_id(sorted_files)
    
    # Отправляем медиа-группы
    for group_id, group_files in groups.items():
        # Сортируем файлы в группе по order
        group_files = sorted(group_files, key=lambda x: x.get("order", 0))
        
        if len(group_files) == 1:
            # Если в группе один файл, отправляем как обычный
            standalone_files.append(group_files[0])
        else:
            # Создаем media_group и отправляем
            media_group = create_media_group_from_files(group_files)
            group_message_ids = await send_media_group_with_fallback(
                bot, chat_id, media_group, group_files,
                extract_message_id_func, extract_message_ids_from_group_func
            )
            message_ids.extend(group_message_ids)
    
    # Отправляем одиночные файлы
    for file_info in standalone_files:
        msg_id = await send_single_file(bot, chat_id, file_info, extract_message_id_func)
        if msg_id:
            message_ids.append(msg_id)
    
    return message_ids



