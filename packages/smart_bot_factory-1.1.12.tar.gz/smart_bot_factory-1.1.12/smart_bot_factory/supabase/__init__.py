"""
Supabase клиент с автоматической загрузкой настроек из .env
"""

from .client import SupabaseClient

__all__ = ["SupabaseClient"]
