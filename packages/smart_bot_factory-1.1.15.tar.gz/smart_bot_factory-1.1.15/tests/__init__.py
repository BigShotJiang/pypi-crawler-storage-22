"""Тесты для библиотеки smart_bot_factory"""
