"""Тесты для модуля file_router"""
