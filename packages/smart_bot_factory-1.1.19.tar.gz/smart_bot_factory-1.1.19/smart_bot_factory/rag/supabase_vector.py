from __future__ import annotations

import uuid
import warnings
import asyncio
from collections import OrderedDict
from itertools import repeat
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
    Type,
    Union,
)

import numpy as np
from langchain_community.vectorstores.utils import maximal_marginal_relevance
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore

if TYPE_CHECKING:
    import supabase


class SupabaseVectorStore(VectorStore):
    """`Supabase Postgres` vector store."""

    def __init__(
        self,
        client: supabase.client.Client,
        embedding: Embeddings,
        table_name: str,
        chunk_size: int = 500,
        query_name: Union[str, None] = None,
        keyword_query_name: Union[str, None] = None,  # НОВОЕ: для полнотекстового поиска
    ) -> None:
        """Initialize with supabase client."""
        try:
            import supabase  # noqa: F401
        except ImportError:
            raise ImportError("Could not import supabase python package. " "Please install it with `pip install supabase`.")

        self._client = client
        self._embedding: Embeddings = embedding
        self.table_name = table_name or "documents"
        self.query_name = query_name or "match_documents"
        # В базе данных функция полнотекстового поиска называется match_{table_name}
        self.keyword_query_name = keyword_query_name or "match_documents"
        self.chunk_size = chunk_size or 500

    @property
    def embeddings(self) -> Embeddings:
        return self._embedding

    # ========== ГИБРИДНЫЙ ПОИСК ==========
    
    def hybrid_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        score: float = 0.0,
        full_text_weight: float = 1.0,
        semantic_weight: float = 1.0,
        rrf_k: int = 50,
        **kwargs: Any,
    ) -> List[Document]:
        """Гибридный поиск, объединяющий векторный и полнотекстовый поиск."""
        results = asyncio.run(self._ahybrid_search(
            query, k, filter, full_text_weight, semantic_weight, rrf_k, **kwargs
        ))
        # Фильтруем по score если указан
        if score > 0.0:
            # Получаем результаты со скорами для фильтрации
            results_with_scores = asyncio.run(self._ahybrid_search_with_scores(
                query, k * 2, filter, full_text_weight, semantic_weight, rrf_k, **kwargs
            ))
            filtered_results = [(doc, doc_score) for doc, doc_score in results_with_scores if doc_score >= score]
            return [doc for doc, _ in filtered_results[:k]]
        return results

    async def _ahybrid_search(
        self,
        query: str,
        k: int,
        filter: Optional[Dict[str, Any]],
        full_text_weight: float,
        semantic_weight: float,
        rrf_k: int,
        **kwargs: Any,
    ) -> List[Document]:
        """Асинхронная реализация гибридного поиска."""
        
        # Параллельное выполнение двух типов поиска
        semantic_future = self._semantic_search_async(query, k, filter)
        keyword_future = self._keyword_search_async(query, k, filter)
        semantic_results, keyword_results = await asyncio.gather(
            semantic_future, keyword_future
        )

        # Преобразование результатов в словари для объединения
        semantic_dict = {
            str(r["id"]): {"rank": idx + 1, "doc": r}
            for idx, r in enumerate(semantic_results)
        }
        keyword_dict = {
            str(r["id"]): {"rank": idx + 1, "doc": r}
            for idx, r in enumerate(keyword_results)
        }

        # Объединение всех уникальных ID
        all_ids = set(semantic_dict.keys()) | set(keyword_dict.keys())
        scored_results = []

        # Расчет финального скора по формуле Reciprocal Ranked Fusion (RRF)
        for doc_id in all_ids:
            semantic_rank = semantic_dict.get(doc_id, {}).get("rank")
            keyword_rank = keyword_dict.get(doc_id, {}).get("rank")

            # Расчет скора для каждого метода
            semantic_score = (
                semantic_weight / (rrf_k + semantic_rank) if semantic_rank else 0.0
            )
            keyword_score = (
                full_text_weight / (rrf_k + keyword_rank) if keyword_rank else 0.0
            )

            total_score = semantic_score + keyword_score

            # Получение документа из любого источника
            doc_source = semantic_dict.get(doc_id) or keyword_dict.get(doc_id)
            if doc_source and total_score > 0:
                doc_data = doc_source["doc"]
                scored_results.append({
                    "score": total_score,
                    "document": Document(
                        page_content=doc_data.get("content", ""),
                        metadata=doc_data.get("metadata", {})
                    )
                })

        # Сортировка по убыванию скора и возврат документов
        scored_results.sort(key=lambda x: x["score"], reverse=True)
        # Возвращаем топ-k результатов
        return [r["document"] for r in scored_results[:k]]

    async def ahybrid_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        score: float = 0.0,
        full_text_weight: float = 1.0,
        semantic_weight: float = 1.0,
        rrf_k: int = 50,
        **kwargs: Any,
    ) -> List[Document]:
        """Асинхронный гибридный поиск, объединяющий векторный и полнотекстовый поиск."""
        results = await self._ahybrid_search(
            query, k, filter, full_text_weight, semantic_weight, rrf_k, **kwargs
        )
        # Фильтруем по score если указан
        if score > 0.0:
            # Получаем результаты со скорами для фильтрации
            results_with_scores = await self._ahybrid_search_with_scores(
                query, k * 2, filter, full_text_weight, semantic_weight, rrf_k, **kwargs
            )
            filtered_results = [(doc, doc_score) for doc, doc_score in results_with_scores if doc_score >= score]
            return [doc for doc, _ in filtered_results[:k]]
        return results

    async def ahybrid_search_with_relevance_scores(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        score: float = 0.0,
        full_text_weight: float = 1.0,
        semantic_weight: float = 1.0,
        rrf_k: int = 50,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """Асинхронный гибридный поиск с возвратом скора релевантности."""
        docs_scores = await self._ahybrid_search_with_scores(
            query, k * 2 if score > 0.0 else k, filter, full_text_weight, semantic_weight, rrf_k, **kwargs
        )
        # Фильтруем по score если указан
        if score > 0.0:
            docs_scores = [(doc, doc_score) for doc, doc_score in docs_scores if doc_score >= score]
            return docs_scores[:k]
        return docs_scores

    async def _semantic_search_async(
        self, query: str, limit: int, filter: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Векторный (семантический) поиск по эмбеддингам (асинхронный)."""
        # Генерация эмбеддинга для запроса
        query_embedding = await self._embedding.aembed_query(query)

        # Подготовка аргументов
        match_args = {"query_embedding": query_embedding, "match_count": limit}
        if filter:
            match_args["filter"] = filter

        # Вызов функции в БД через RPC
        response = self._client.rpc(self.query_name, match_args).execute()

        return response.data if response.data else []

    async def _keyword_search_async(
        self, query: str, limit: int, filter: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Полнотекстовый поиск по ключевым словам (асинхронный)."""
        # Подготовка аргументов в правильном порядке, как в функции БД:
        # match_vectorstore(query_text TEXT, match_count INT, filter JSONB)
        # Используем OrderedDict для гарантии порядка параметров
        match_args = OrderedDict([
            ("query_text", query),
            ("match_count", limit),
            ("filter", filter if filter else {})
        ])

        # Вызов функции в БД через RPC
        response = self._client.rpc(self.keyword_query_name, match_args).execute()

        return response.data if response.data else []

    def hybrid_search_with_relevance_scores(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        score: float = 0.0,
        full_text_weight: float = 1.0,
        semantic_weight: float = 1.0,
        rrf_k: int = 50,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """Гибридный поиск с возвратом скора релевантности."""
        docs_scores = asyncio.run(self._ahybrid_search_with_scores(
            query, k * 2 if score > 0.0 else k, filter, full_text_weight, semantic_weight, rrf_k, **kwargs
        ))
        # Фильтруем по score если указан
        if score > 0.0:
            docs_scores = [(doc, doc_score) for doc, doc_score in docs_scores if doc_score >= score]
            return docs_scores[:k]
        return docs_scores

    async def _ahybrid_search_with_scores(
        self,
        query: str,
        k: int,
        filter: Optional[Dict[str, Any]],
        full_text_weight: float,
        semantic_weight: float,
        rrf_k: int,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """Асинхронная реализация с возвратом скора."""
        # Параллельное выполнение двух типов поиска
        semantic_future = self._semantic_search_async(query, k, filter)
        keyword_future = self._keyword_search_async(query, k, filter)
        semantic_results, keyword_results = await asyncio.gather(
            semantic_future, keyword_future
        )

        # Преобразование результатов в словари для объединения
        semantic_dict = {
            str(r["id"]): {"rank": idx + 1, "doc": r}
            for idx, r in enumerate(semantic_results)
        }
        keyword_dict = {
            str(r["id"]): {"rank": idx + 1, "doc": r}
            for idx, r in enumerate(keyword_results)
        }

        # Объединение всех уникальных ID
        all_ids = set(semantic_dict.keys()) | set(keyword_dict.keys())
        scored_results = []

        # Расчет финального скора по формуле RRF
        for doc_id in all_ids:
            semantic_rank = semantic_dict.get(doc_id, {}).get("rank")
            keyword_rank = keyword_dict.get(doc_id, {}).get("rank")

            semantic_score = (
                semantic_weight / (rrf_k + semantic_rank) if semantic_rank else 0.0
            )
            keyword_score = (
                full_text_weight / (rrf_k + keyword_rank) if keyword_rank else 0.0
            )

            total_score = semantic_score + keyword_score

            doc_source = semantic_dict.get(doc_id) or keyword_dict.get(doc_id)
            if doc_source and total_score > 0:
                doc_data = doc_source["doc"]
                scored_results.append({
                    "score": total_score,
                    "document": Document(
                        page_content=doc_data.get("content", ""),
                        metadata=doc_data.get("metadata", {})
                    )
                })

        # Сортировка по убыванию скора
        scored_results.sort(key=lambda x: x["score"], reverse=True)
        
        # Возвращаем топ-k результатов с их скорами
        top_results = scored_results[:k]
        return [(r["document"], r["score"]) for r in top_results]

    # ========== СУЩЕСТВУЮЩИЕ МЕТОДЫ (без изменений) ==========

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[Any, Any]]] = None,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> List[str]:
        ids = ids or [str(uuid.uuid4()) for _ in texts]
        docs = self._texts_to_documents(texts, metadatas)

        vectors = self._embedding.embed_documents(list(texts))
        return self.add_vectors(vectors, docs, ids)

    @classmethod
    def from_texts(
        cls: Type["SupabaseVectorStore"],
        texts: List[str],
        embedding: Embeddings,
        metadatas: Optional[List[dict]] = None,
        client: Optional[supabase.client.Client] = None,
        table_name: Optional[str] = "documents",
        query_name: Union[str, None] = "match_documents",
        keyword_query_name: Union[str, None] = None,  # НОВОЕ
        chunk_size: int = 500,
        ids: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> "SupabaseVectorStore":
        """Return VectorStore initialized from texts and embeddings."""

        if not client:
            raise ValueError("Supabase client is required.")

        if not table_name:
            raise ValueError("Supabase document table_name is required.")

        embeddings = embedding.embed_documents(texts)
        ids = [str(uuid.uuid4()) for _ in texts]
        docs = cls._texts_to_documents(texts, metadatas)
        cls._add_vectors(client, table_name, embeddings, docs, ids, chunk_size, **kwargs)

        return cls(
            client=client,
            embedding=embedding,
            table_name=table_name,
            query_name=query_name,
            keyword_query_name=keyword_query_name,  # НОВОЕ
            chunk_size=chunk_size,
        )

    def add_vectors(
        self,
        vectors: List[List[float]],
        documents: List[Document],
        ids: List[str],
    ) -> List[str]:
        return self._add_vectors(self._client, self.table_name, vectors, documents, ids, self.chunk_size)

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        vector = self._embedding.embed_query(query)
        return self.similarity_search_by_vector(vector, k=k, filter=filter, **kwargs)

    def similarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        result = self.similarity_search_by_vector_with_relevance_scores(embedding, k=k, filter=filter, **kwargs)

        documents = [doc for doc, _ in result]

        return documents

    def similarity_search_with_relevance_scores(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        vector = self._embedding.embed_query(query)
        return self.similarity_search_by_vector_with_relevance_scores(vector, k=k, filter=filter, **kwargs)

    def match_args(self, query: List[float], filter: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        ret: Dict[str, Any] = dict(query_embedding=query)
        if filter:
            ret["filter"] = filter
        return ret

    def similarity_search_by_vector_with_relevance_scores(
        self,
        query: List[float],
        k: int,
        filter: Optional[Dict[str, Any]] = None,
        postgrest_filter: Optional[str] = None,
        score_threshold: Optional[float] = None,
    ) -> List[Tuple[Document, float]]:
        """Поиск документов по вектору с возможностью фильтрации и порога релевантности."""

        # Преобразуем MongoDB-style filter в PostgreSQL IN выражения
        if filter:
            for key, value in filter.items():
                if isinstance(value, dict) and "$in" in value:
                    in_values = value["$in"]
                    values_str = ",".join(f"'{str(v)}'" for v in in_values)
                    new_filter = f"metadata->>{key} IN ({values_str})"

                    if postgrest_filter:
                        postgrest_filter = f"({postgrest_filter}) AND ({new_filter})"
                    else:
                        postgrest_filter = new_filter

        # Подготовка аргументов для RPC
        match_documents_params = self.match_args(query, filter)
        query_builder = self._client.rpc(self.query_name, match_documents_params)

        # Применяем фильтр и лимит
        if postgrest_filter:
            query_builder = query_builder.filter(postgrest_filter)

        query_builder = query_builder.limit(k)

        # Выполнение запроса
        res = query_builder.execute()

        # Формируем результат в виде списка кортежей (Document, similarity)
        match_result = [
            (Document(metadata=search.get("metadata", {}), page_content=search.get("content", "")), search.get("similarity", 0.0))
            for search in res.data
            if search.get("content")
        ]

        # Фильтруем по порогу релевантности
        if score_threshold is not None:
            match_result = [(doc, similarity) for doc, similarity in match_result if similarity >= score_threshold]
            if not match_result:
                warnings.warn(f"No relevant docs were retrieved using the relevance score threshold {score_threshold}")

        return match_result

    def similarity_search_by_vector_returning_embeddings(
        self,
        query: List[float],
        k: int,
        filter: Optional[Dict[str, Any]] = None,
        postgrest_filter: Optional[str] = None,
    ) -> List[Tuple[Document, float, np.ndarray]]:
        match_documents_params = self.match_args(query, filter)
        query_builder = self._client.rpc(self.query_name, match_documents_params)

        if postgrest_filter:
            query_builder.params = query_builder.params.set("and", f"({postgrest_filter})")

        query_builder.params = query_builder.params.set("limit", k)

        res = query_builder.execute()

        match_result = [
            (
                Document(
                    metadata=search.get("metadata", {}),
                    page_content=search.get("content", ""),
                ),
                search.get("similarity", 0.0),
                # Supabase returns a vector type as its string represation (!).
                # This is a hack to convert the string to numpy array.
                np.fromstring(search.get("embedding", "").strip("[]"), np.float32, sep=","),
            )
            for search in res.data
            if search.get("content")
        ]

        return match_result

    @staticmethod
    def _texts_to_documents(
        texts: Iterable[str],
        metadatas: Optional[Iterable[Dict[Any, Any]]] = None,
    ) -> List[Document]:
        """Return list of Documents from list of texts and metadatas."""
        if metadatas is None:
            metadatas = repeat({})

        docs = [Document(page_content=text, metadata=metadata) for text, metadata in zip(texts, metadatas)]

        return docs

    @staticmethod
    def _add_vectors(
        client: supabase.client.Client,
        table_name: str,
        vectors: List[List[float]],
        documents: List[Document],
        ids: List[str],
        chunk_size: int,
        **kwargs: Any,
    ) -> List[str]:
        """Add vectors to Supabase table."""

        rows: List[Dict[str, Any]] = [
            {
                "id": ids[idx],
                "content": documents[idx].page_content,
                "embedding": embedding,
                "metadata": documents[idx].metadata,
                **kwargs,
            }
            for idx, embedding in enumerate(vectors)
        ]
        id_list: List[str] = []
        for i in range(0, len(rows), chunk_size):
            chunk = rows[i : i + chunk_size]

            result = client.from_(table_name).upsert(chunk).execute()

            if len(result.data) == 0:
                raise Exception("Error inserting: No rows added")

            # VectorStore.add_vectors returns ids as strings
            ids = [str(i.get("id")) for i in result.data if i.get("id")]

            id_list.extend(ids)

        return id_list

    def max_marginal_relevance_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        **kwargs: Any,
    ) -> List[Document]:
        """Return docs selected using the maximal marginal relevance."""
        result = self.similarity_search_by_vector_returning_embeddings(embedding, fetch_k)

        matched_documents = [doc_tuple[0] for doc_tuple in result]
        matched_embeddings = [doc_tuple[2] for doc_tuple in result]

        mmr_selected = maximal_marginal_relevance(
            np.array([embedding], dtype=np.float32),
            matched_embeddings,
            k=k,
            lambda_mult=lambda_mult,
        )

        filtered_documents = [matched_documents[i] for i in mmr_selected]

        return filtered_documents

    def max_marginal_relevance_search(
        self,
        query: str,
        k: int = 4,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        **kwargs: Any,
    ) -> List[Document]:
        """Return docs selected using the maximal marginal relevance."""
        embedding = self._embedding.embed_query(query)
        docs = self.max_marginal_relevance_search_by_vector(embedding, k, fetch_k, lambda_mult=lambda_mult)
        return docs

    def delete(self, ids: Optional[List[str]] = None, **kwargs: Any) -> None:
        """Delete by vector IDs."""

        if ids is None:
            raise ValueError("No ids provided to delete.")

        rows: List[Dict[str, Any]] = [
            {
                "id": id,
            }
            for id in ids
        ]

        # TODO: Check if this can be done in bulk
        for row in rows:
            self._client.from_(self.table_name).delete().eq("id", row["id"]).execute()