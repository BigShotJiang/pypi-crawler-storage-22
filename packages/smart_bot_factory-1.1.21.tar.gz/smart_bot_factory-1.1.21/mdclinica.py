from smart_bot_factory.creation import BotBuilder
from rag_tools import rag_router

bot_builder = BotBuilder("mdclinica")
bot_builder.register_routers(rag_router)