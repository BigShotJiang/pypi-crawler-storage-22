import asyncio
import logging
import os
from collections import OrderedDict
from pathlib import Path
from typing import Any, List, Optional, Tuple, Dict

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from project_root_finder import root
from supabase import Client, create_client

from .supabase_vector import SupabaseVectorStore

logger = logging.getLogger(__name__)


class VectorStore(SupabaseVectorStore):
    """Векторное хранилище с автоматической загрузкой настроек бота и поддержкой гибридного поиска."""

    def __init__(
        self, 
        bot_id: str, 
        table_name: str = "vectorstore", 
        query_name: Optional[str] = None,
        keyword_query_name: Optional[str] = None,  # НОВОЕ: для полнотекстового поиска
        hybrid_query_name: Optional[str] = None     # НОВОЕ: для гибридного поиска
    ) -> None:
        self.bot_id = bot_id
        self.table_name = table_name

        # Если query_name не указан, используем стандартное имя функции
        if not query_name:
            query_name = f"match_{table_name}"
        self.query_name = query_name

        # Если keyword_query_name не указан, используем стандартное имя
        # ВАЖНО:
        # - `match_{table_name}` (например, match_vectorstore) — векторная функция (query_embedding, filter)
        # - полнотекстовая функция у тебя называется `match_documents` (query_text, match_count, filter)
        if not keyword_query_name:
            keyword_query_name = "match_documents"
        self.keyword_query_name = keyword_query_name

        # Если hybrid_query_name не указан, используем стандартное имя
        if not hybrid_query_name:
            hybrid_query_name = f"hybrid_match_{table_name}"
        self.hybrid_query_name = hybrid_query_name

        self.supabase_client: Optional[Client] = None
        self.url: Optional[str] = None
        self.key: Optional[str] = None
        self.openai_api_key: Optional[str] = None

        self._load_env_config()
        
        # Проверяем, что все необходимые переменные загружены
        if not self.url or not self.key:
            raise ValueError("SUPABASE_URL и SUPABASE_KEY должны быть установлены")
        if not self.openai_api_key:
            raise ValueError("OPENAI_API_KEY должен быть установлен")
        
        self.supabase_client = create_client(self.url, self.key)

        embedding_model = "text-embedding-3-small"
        embedding = OpenAIEmbeddings(openai_api_key=self.openai_api_key, model=embedding_model)
        self.embedding = embedding

        # Передаем все параметры в родительский класс
        super().__init__(
            client=self.supabase_client, 
            embedding=embedding, 
            table_name=table_name, 
            query_name=query_name,
            keyword_query_name=keyword_query_name  # Передаем новый параметр
        )

    # ======================================================================
    # Методы загрузки ENV (оставлены для доступа к настройкам из .env)
    # ======================================================================
    def _load_env_config(self) -> None:
        """Загружает конфигурацию из .env файла."""
        try:
            env_path = self._find_env_file()

            if not env_path or not env_path.exists():
                raise FileNotFoundError(f".env файл не найден: {env_path}")

            load_dotenv(env_path)

            self.url = os.getenv("SUPABASE_URL")
            self.key = os.getenv("SUPABASE_KEY")
            self.openai_api_key = os.getenv("OPENAI_API_KEY")

            missing_vars = []
            if not self.url:
                missing_vars.append("SUPABASE_URL")
            if not self.key:
                missing_vars.append("SUPABASE_KEY")
            if not self.openai_api_key:
                missing_vars.append("OPENAI_API_KEY")

            if missing_vars:
                raise ValueError(f"Отсутствуют обязательные переменные в .env: {', '.join(missing_vars)}")

            logger.info("✅ Настройки Supabase загружены из %s", env_path)

        except Exception as exc:
            logger.error("❌ Ошибка загрузки конфигурации Supabase: %s", exc)
            raise

    def _find_env_file(self) -> Optional[Path]:
        """Автоматически находит .env файл для указанного бота."""
        bot_env_path = root / "bots" / self.bot_id / ".env"

        if bot_env_path.exists():
            logger.info("🔍 Найден .env файл для бота %s: %s", self.bot_id, bot_env_path)
            return bot_env_path

        logger.error("❌ .env файл не найден для бота %s", self.bot_id)
        logger.error("   Искали в: %s", bot_env_path)
        return None

    def _check_table_and_function(self) -> None:
        """
        Проверяет наличие таблицы и функций при инициализации класса.
        """
        # Проверяем наличие таблицы
        if not self.supabase_client:
            logger.error("❌ Supabase клиент не инициализирован")
            return
            
        try:
            self.supabase_client.table(self.table_name).select("id").limit(1).execute()
            logger.info("✅ Таблица '%s' найдена в Supabase", self.table_name)
        except Exception as table_error:
            logger.error("❌ Таблица '%s' не найдена: %s", self.table_name, table_error)

        # Проверяем векторную функцию поиска
        try:
            super().similarity_search(query="test", k=1)
            logger.info("✅ Функция '%s' найдена в Supabase", self.query_name)
        except Exception as function_error:
            logger.error("❌ Функция '%s' не найдена: %s", self.query_name, function_error)

        # Проверяем полнотекстовую функцию поиска
        try:
            self._test_keyword_function()
            logger.info("✅ Функция '%s' найдена в Supabase", self.keyword_query_name)
        except Exception as function_error:
            logger.error("❌ Функция '%s' не найдена: %s", self.keyword_query_name, function_error)

        # Проверяем гибридную функцию поиска (опционально)
        try:
            self._test_hybrid_function()
            logger.info("✅ Функция '%s' найдена в Supabase", self.hybrid_query_name)
        except Exception as function_error:
            logger.warning("⚠️  Функция гибридного поиска '%s' не найдена: %s", 
                          self.hybrid_query_name, function_error)
            logger.info("ℹ️  Гибридный поиск будет эмулироваться на стороне Python")

    def _test_keyword_function(self) -> None:
        """Тестирует функцию полнотекстового поиска."""
        if not self.supabase_client:
            raise ValueError("Supabase клиент не инициализирован")
        # Пробуем выполнить простой запрос к функции
        # Порядок параметров: query_text, filter
        # Используем OrderedDict для гарантии порядка параметров
        params = OrderedDict([
            ("query_text", "test"),
            ("filter", {"bot_id": self.bot_id})
        ])
        self.supabase_client.rpc(self.keyword_query_name, params).execute()

    def _test_hybrid_function(self) -> None:
        """Тестирует функцию гибридного поиска."""
        if not self.supabase_client:
            raise ValueError("Supabase клиент не инициализирован")
        # Тестовый вектор (нужно сгенерировать правильный)
        test_vector = [0.0] * 1536  # Размерность должна соответствовать вашей модели
        
        params = {
            "query_text": "test",
            "query_embedding": test_vector,
            "match_count": 1,
            "filter": {"bot_id": self.bot_id}
        }
        self.supabase_client.rpc(self.hybrid_query_name, params).execute()


    def as_retriever(self, **kwargs):
        """
        Returns a retriever for the vector store.
        """
        kwargs.setdefault("search_kwargs", {})
        search_kwargs = kwargs["search_kwargs"]
        filter_payload = search_kwargs.get("filter", {})

        # Обеспечиваем, что filter_payload - это словарь
        if not isinstance(filter_payload, dict):
            filter_payload = {}

        # Добавляем bot_id в фильтр
        filter_payload = filter_payload.copy()
        filter_payload["bot_id"] = self.bot_id

        search_kwargs["filter"] = filter_payload
        kwargs["search_kwargs"] = search_kwargs

        logger.info("JSONB фильтр для поиска: %s", filter_payload)

        return super().as_retriever(**kwargs)

    # ======================================================================
    # МЕТОДЫ ГИБРИДНОГО ПОИСКА
    # ======================================================================

    def hybrid_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[dict] = None,
        score: float = 0.0,
        full_text_weight: float = 1.0,
        semantic_weight: float = 1.0,
        rrf_k: int = 50,
        **kwargs: Any,
    ) -> List[Document]:
        """
        Гибридный поиск, объединяющий векторный и полнотекстовый поиск.

        Args:
            query: Поисковый запрос
            k: Количество результатов
            filter: Фильтр по metadata
            score: Минимальный score релевантности
            full_text_weight: Вес полнотекстового поиска
            semantic_weight: Вес семантического поиска
            rrf_k: Константа сглаживания для RRF
            **kwargs: Дополнительные аргументы

        Returns:
            Список документов
        """
        # Подготавливаем фильтр
        if filter is None:
            filter = {}
        filter = filter.copy()
        filter["bot_id"] = self.bot_id

        logger.info("Гибридный поиск: запрос='%s', k=%d, score=%.2f, вес текста=%.1f, вес семантики=%.1f", 
                   query, k, score, full_text_weight, semantic_weight)

        try:
            # Пробуем использовать SQL-функцию гибридного поиска
            results = self._hybrid_search_sql(
                query, k, filter, full_text_weight, semantic_weight, rrf_k, score, **kwargs
            )
        except Exception as sql_error:
            # Если SQL-функция не работает, используем Python-эмуляцию
            logger.warning("SQL гибридный поиск не доступен: %s. Использую Python эмуляцию.", sql_error)
            results = self._hybrid_search_python(
                query, k, filter, full_text_weight, semantic_weight, rrf_k, score, **kwargs
            )
        
        return results

    def _hybrid_search_sql(
        self,
        query: str,
        k: int,
        filter: Dict[str, Any],
        full_text_weight: float,
        semantic_weight: float,
        rrf_k: int,
        score: float = 0.0,
        **kwargs: Any,
    ) -> List[Document]:
        """
        Гибридный поиск через SQL-функцию (более эффективный).
        """
        # Если нужна фильтрация по score, используем метод со скорами
        if score > 0.0:
            results_with_scores = self.hybrid_search_with_relevance_scores(
                query=query,
                k=k,
                filter=filter,
                score=score,
                full_text_weight=full_text_weight,
                semantic_weight=semantic_weight,
                rrf_k=rrf_k,
                **kwargs
            )
            return [doc for doc, _ in results_with_scores]
        
        # Генерируем эмбеддинг для запроса
        query_embedding = self.embedding.embed_query(query)
        
        # Подготавливаем параметры
        params = {
            "query_text": query,
            "query_embedding": query_embedding,
            "match_count": k,
            "full_text_weight": full_text_weight,
            "semantic_weight": semantic_weight,
            "rrf_k": rrf_k,
            "filter": filter,
        }
        
        # Вызываем SQL-функцию
        if not self.supabase_client:
            raise ValueError("Supabase клиент не инициализирован")
        response = self.supabase_client.rpc(self.hybrid_query_name, params).execute()
        
        if not response.data:
            return []
        
        # Преобразуем результаты в документы
        documents = []
        for item in response.data:
            doc = Document(
                page_content=item.get("content", ""),
                metadata=item.get("metadata", {})
            )
            documents.append(doc)
        
        return documents[:k]

    def _hybrid_search_python(
        self,
        query: str,
        k: int,
        filter: Dict[str, Any],
        full_text_weight: float,
        semantic_weight: float,
        rrf_k: int,
        score: float = 0.0,
        **kwargs: Any,
    ) -> List[Document]:
        """
        Гибридный поиск через Python (эмуляция).
        """
        try:
            # Используем метод из родительского класса
            results = super().hybrid_search(
                query=query,
                k=k,
                filter=filter,
                score=score,
                full_text_weight=full_text_weight,
                semantic_weight=semantic_weight,
                rrf_k=rrf_k,
                **kwargs
            )
            return results
        except AttributeError:
            # Если родительский класс не имеет метода hybrid_search
            # Используем комбинацию двух поисков
            return self._hybrid_search_fallback(query, k, filter, full_text_weight, semantic_weight, rrf_k)

    def _hybrid_search_fallback(
        self,
        query: str,
        k: int,
        filter: Dict[str, Any],
        full_text_weight: float,
        semantic_weight: float,
        rrf_k: int = 50,
    ) -> List[Document]:
        """
        Резервный метод гибридного поиска, если основной не доступен.
        """
        # Выполняем оба поиска
        semantic_results = super().similarity_search_with_relevance_scores(
            query, k=k * 2, filter=filter
        )
        
        keyword_results = []
        try:
            # Пробуем полнотекстовый поиск
            keyword_results = self._keyword_search_with_scores(query, k * 2, filter)
        except Exception as e:
            logger.warning("Полнотекстовый поиск не доступен: %s", e)
        
        # Объединяем результаты
        combined = {}
        
        # Добавляем семантические результаты
        for rank, (doc, score) in enumerate(semantic_results, 1):
            doc_id = doc.metadata.get('id', str(hash(doc.page_content)))
            combined[doc_id] = {
                'doc': doc,
                'semantic_rank': rank,
                'semantic_score': score
            }
        
        # Добавляем результаты полнотекстового поиска
        for rank, (doc, score) in enumerate(keyword_results, 1):
            doc_id = doc.metadata.get('id', str(hash(doc.page_content)))
            if doc_id in combined:
                combined[doc_id]['keyword_rank'] = rank
                combined[doc_id]['keyword_score'] = score
            else:
                combined[doc_id] = {
                    'doc': doc,
                    'keyword_rank': rank,
                    'keyword_score': score
                }
        
        # Вычисляем комбинированный score
        scored_docs = []
        for doc_id, info in combined.items():
            semantic_rrf = semantic_weight / (rrf_k + info.get('semantic_rank', rrf_k + 1)) if info.get('semantic_rank') else 0
            keyword_rrf = full_text_weight / (rrf_k + info.get('keyword_rank', rrf_k + 1)) if info.get('keyword_rank') else 0
            total_score = semantic_rrf + keyword_rrf
            
            if total_score > 0:
                scored_docs.append((info['doc'], total_score))
        
        # Сортируем по score
        scored_docs.sort(key=lambda x: x[1], reverse=True)
        
        # Возвращаем только документы
        return [doc for doc, _ in scored_docs[:k]]

    def _keyword_search_with_scores(
        self, 
        query: str, 
        limit: int, 
        filter: Optional[Dict[str, Any]] = None
    ) -> List[Tuple[Document, float]]:
        """Полнотекстовый поиск с возвратом оценок."""
        # Подготовка аргументов в правильном порядке, как в функции БД:
        # match_documents(query_text TEXT, match_count INT DEFAULT 10, filter JSONB DEFAULT '{}')
        # Используем OrderedDict для гарантии порядка параметров
        match_args = OrderedDict([
            ("query_text", query),
            ("match_count", limit),
            ("filter", filter if filter else {})
        ])

        if not self.supabase_client:
            raise ValueError("Supabase клиент не инициализирован")
        response = self.supabase_client.rpc(self.keyword_query_name, match_args).execute()

        if not response.data:
            return []

        results = []
        for item in response.data:
            doc = Document(
                page_content=item.get("content", ""),
                metadata=item.get("metadata", {})
            )
            score = item.get("similarity", 0.5)
            results.append((doc, score))
        
        results.sort(key=lambda x: x[1], reverse=True)
        # Ограничиваем результаты на стороне Python, так как функция не принимает match_count
        return results[:limit]

    async def ahybrid_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[dict] = None,
        score: float = 0.0,
        full_text_weight: float = 1.0,
        semantic_weight: float = 1.0,
        rrf_k: int = 50,
        **kwargs: Any,
    ) -> List[Document]:
        """
        Асинхронный гибридный поиск.
        """
        # Используем асинхронный метод из родительского класса
        try:
            return await super().ahybrid_search(
                query=query,
                k=k,
                filter=filter,
                score=score,
                full_text_weight=full_text_weight,
                semantic_weight=semantic_weight,
                rrf_k=rrf_k,
                **kwargs
            )
        except AttributeError:
            # Если метод не доступен, вызываем синхронный метод в отдельном потоке
            return await asyncio.to_thread(
                self.hybrid_search,
                query,
                k,
                filter,
                score,
                full_text_weight,
                semantic_weight,
                rrf_k,
                **kwargs
            )

    def hybrid_search_with_relevance_scores(
        self,
        query: str,
        k: int = 4,
        filter: Optional[dict] = None,
        score: float = 0.0,
        full_text_weight: float = 1.0,
        semantic_weight: float = 1.0,
        rrf_k: int = 50,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """
        Гибридный поиск с возвратом оценок релевантности.
        """
        if filter is None:
            filter = {}
        filter = filter.copy()
        filter["bot_id"] = self.bot_id

        try:
            # Используем метод из родительского класса
            return super().hybrid_search_with_relevance_scores(
                query=query,
                k=k,
                filter=filter,
                score=score,
                full_text_weight=full_text_weight,
                semantic_weight=semantic_weight,
                rrf_k=rrf_k,
                **kwargs
            )
        except (AttributeError, NotImplementedError):
            # Если метод не доступен, используем fallback
            logger.warning("Метод hybrid_search_with_relevance_scores не доступен. Использую fallback.")
            results = self._hybrid_search_fallback_with_scores(
                query, k, filter, full_text_weight, semantic_weight, rrf_k
            )
            # Фильтруем по score если указан
            if score > 0.0:
                results = [(doc, doc_score) for doc, doc_score in results if doc_score >= score]
            return results

    def _hybrid_search_fallback_with_scores(
        self,
        query: str,
        k: int,
        filter: Dict[str, Any],
        full_text_weight: float,
        semantic_weight: float,
        rrf_k: int,
    ) -> List[Tuple[Document, float]]:
        """Резервный метод с возвратом scores."""
        # Аналогично _hybrid_search_fallback, но возвращает scores
        semantic_results = super().similarity_search_with_relevance_scores(
            query, k=k * 2, filter=filter
        )
        
        keyword_results = []
        try:
            keyword_results = self._keyword_search_with_scores(query, k * 2, filter)
        except Exception as e:
            logger.warning("Полнотекстовый поиск не доступен: %s", e)
        
        combined = {}
        
        for rank, (doc, score) in enumerate(semantic_results, 1):
            doc_id = doc.metadata.get('id', str(hash(doc.page_content)))
            combined[doc_id] = {
                'doc': doc,
                'semantic_rank': rank,
                'semantic_score': score
            }
        
        for rank, (doc, score) in enumerate(keyword_results, 1):
            doc_id = doc.metadata.get('id', str(hash(doc.page_content)))
            if doc_id in combined:
                combined[doc_id]['keyword_rank'] = rank
                combined[doc_id]['keyword_score'] = score
            else:
                combined[doc_id] = {
                    'doc': doc,
                    'keyword_rank': rank,
                    'keyword_score': score
                }
        
        scored_docs = []
        for doc_id, info in combined.items():
            semantic_rrf = semantic_weight / (rrf_k + info.get('semantic_rank', rrf_k + 1)) if info.get('semantic_rank') else 0
            keyword_rrf = full_text_weight / (rrf_k + info.get('keyword_rank', rrf_k + 1)) if info.get('keyword_rank') else 0
            total_score = semantic_rrf + keyword_rrf
            
            if total_score > 0:
                scored_docs.append((info['doc'], total_score))
        
        scored_docs.sort(key=lambda x: x[1], reverse=True)
        return scored_docs[:k]

    # ======================================================================
    # СУЩЕСТВУЮЩИЕ МЕТОДЫ (обновлены для использования гибридного поиска)
    # ======================================================================

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[dict] = None,
        score: float = 0.6,
        use_hybrid: bool = False,  # НОВЫЙ параметр
        hybrid_weights: Optional[Tuple[float, float]] = None,  # (full_text_weight, semantic_weight)
        **kwargs: Any,
    ) -> List[Document]:
        """
        Поиск похожих документов с возможностью использования гибридного поиска.

        Args:
            query: Поисковый запрос
            k: Количество результатов
            filter: Фильтр по metadata
            score: Минимальный score релевантности
            use_hybrid: Использовать гибридный поиск
            hybrid_weights: Веса для гибридного поиска (полнотекстовый, семантический)
            **kwargs: Дополнительные аргументы

        Returns:
            Список документов
        """
        if use_hybrid:
            # Используем гибридный поиск
            full_text_weight, semantic_weight = hybrid_weights or (1.0, 1.0)
            return self.hybrid_search(
                query=query,
                k=k,
                filter=filter,
                score=score,
                full_text_weight=full_text_weight,
                semantic_weight=semantic_weight,
                **kwargs
            )
        else:
            # Используем обычный поиск (существующая логика)
            if filter is None:
                filter = {}
            filter = filter.copy()
            filter["bot_id"] = self.bot_id

            logger.info("Запрос: %s, score: %.2f", query, score)

            try:
                results_with_scores = super().similarity_search_with_relevance_scores(
                    query, k=k, filter=filter
                )
                filtered_results = [(doc, doc_score) for doc, doc_score in results_with_scores if doc_score >= score]
                return [doc for doc, _ in filtered_results]
            except NotImplementedError:
                return super().similarity_search(query, k=k, filter=filter, **kwargs)
            except Exception as exc:
                logger.error("❌ Ошибка при поиске: %s", exc)
                raise

    async def asimilarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[dict] = None,
        score: float = 0.6,
        use_hybrid: bool = False,
        hybrid_weights: Optional[Tuple[float, float]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """
        Асинхронный поиск с поддержкой гибридного поиска.
        """
        if use_hybrid:
            # Асинхронный гибридный поиск
            return await self.ahybrid_search(
                query=query,
                k=k,
                filter=filter,
                score=score,
                full_text_weight=hybrid_weights[0] if hybrid_weights else 1.0,
                semantic_weight=hybrid_weights[1] if hybrid_weights else 1.0,
                **kwargs
            )
        else:
            # Существующая логика
            if filter is None:
                filter = {}
            filter = filter.copy()
            filter["bot_id"] = self.bot_id

            logger.info("Асинхронный запрос: %s, score: %.2f", query, score)

            try:
                results_with_scores = await asyncio.to_thread(
                    super().similarity_search_with_relevance_scores, 
                    query, k=k, filter=filter, **kwargs
                )
                filtered_results = [(doc, doc_score) for doc, doc_score in results_with_scores if doc_score >= score]
                return [doc for doc, _ in filtered_results]
            except NotImplementedError:
                return await super().asimilarity_search(query, k=k, filter=filter, **kwargs)
            except Exception as exc:
                logger.error("❌ Ошибка при асинхронном поиске: %s", exc)
                raise