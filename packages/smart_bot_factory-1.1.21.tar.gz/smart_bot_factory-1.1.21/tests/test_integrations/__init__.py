"""Тесты для модуля integrations"""
