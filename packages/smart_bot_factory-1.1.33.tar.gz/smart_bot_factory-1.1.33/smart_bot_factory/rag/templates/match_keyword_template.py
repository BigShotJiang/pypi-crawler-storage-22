"""
Шаблон для генерации SQL функции keyword search.
Используйте f-строку для заполнения параметров.
"""


def generate_match_keyword_sql(
    table_name: str,
    function_name: str,
) -> str:
    """
    Генерирует SQL код для создания функции keyword search.

    Args:
        table_name: Название таблицы
        function_name: Название функции (например, "kw_match_vectorstore")

    Returns:
        SQL код для создания функции
    """
    sql = f"""CREATE OR REPLACE FUNCTION {function_name}(
    query_text TEXT,
    match_count INT DEFAULT 10,
    filter JSONB DEFAULT '{{}}'::jsonb
)
RETURNS TABLE (
    id uuid,
    content TEXT,
    metadata JSONB,
    similarity FLOAT
)
LANGUAGE plpgsql
AS $function$
DECLARE
    filter_conditions TEXT := '';
    filter_key TEXT;
    filter_value JSONB;
    array_elements TEXT;
BEGIN
    -- Проверяем, есть ли фильтры
    IF filter IS NOT NULL AND filter != '{{}}'::jsonb THEN
        FOR filter_key, filter_value IN SELECT * FROM jsonb_each(filter)
        LOOP
            -- Строковые значения
            IF jsonb_typeof(filter_value) = 'string' THEN
                filter_conditions := filter_conditions || 
                    format(' AND metadata->>%L = %L', filter_key, filter_value #>> '{{}}');
            
            -- Массивы
            ELSIF jsonb_typeof(filter_value) = 'array' THEN
                SELECT string_agg(quote_literal(elem::text), ',')
                INTO array_elements
                FROM jsonb_array_elements_text(filter_value) AS elem;
                
                IF array_elements IS NOT NULL THEN
                    filter_conditions := filter_conditions || 
                        format(' AND metadata->>%L = ANY(ARRAY[%s])', filter_key, array_elements);
                END IF;

            -- Числа и boolean
            ELSIF jsonb_typeof(filter_value) IN ('number', 'boolean') THEN
                filter_conditions := filter_conditions || 
                    format(' AND metadata->>%L = %L', filter_key, filter_value #>> '{{}}');
            END IF;
        END LOOP;
    END IF;

    -- Выполняем запрос полнотекстового поиска
    RETURN QUERY EXECUTE format(
        'SELECT 
            s.id,
            s.content,
            s.metadata,
            ts_rank(
                to_tsvector(''russian'', s.content),
                websearch_to_tsquery(''russian'', $1)
            ) AS similarity
         FROM {table_name} s
         WHERE 
            to_tsvector(''russian'', s.content) @@ websearch_to_tsquery(''russian'', $1)
            %s
         ORDER BY similarity DESC
         LIMIT $2',
        filter_conditions
    ) USING query_text, match_count;
END;
$function$;
"""
    return sql
