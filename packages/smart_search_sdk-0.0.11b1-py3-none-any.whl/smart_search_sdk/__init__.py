"""
Smart Search SDK package.

This package provides a comprehensive SDK for interacting with the Smart Search API,
including authentication, search operations, and deep research capabilities.
"""

__version__ = "1.0.0"
__author__ = "GDP Labs"
__email__ = "info@gdplabs.id"
