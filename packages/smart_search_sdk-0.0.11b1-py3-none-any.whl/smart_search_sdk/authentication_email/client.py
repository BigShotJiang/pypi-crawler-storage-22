"""
Authors:
    Ardhian Heru Nugroho (ardhian.h.nugroho@gdplabs.id)

References:
    None
"""

from smart_search_sdk.client.client import BaseSmartSearchClient


class SmartSearchAuthEmailClient(BaseSmartSearchClient):
    """
    A client for interacting with the Smart Search Authentication Email API.

    Methods:
        get_authentication_emails(page: int = 1, items_per_page: int = 10) -> dict:
            Retrieves a paginated list of authentication emails.

            Args:
                page (int, optional): The page number to retrieve. Defaults to 1.
                items_per_page (int, optional): The number of items per page. Defaults to 10.

            Returns:
                dict: A dictionary containing the response data from the API.
    """

    def get_authentication_emails(
        self, page: int = 1, items_per_page: int = 10
    ) -> dict:
        """
        Retrieve a paginated list of authentication emails.

        Args:
            page (int, optional): The page number to retrieve. Defaults to 1.
            items_per_page (int, optional): The number of items per page. Defaults to 10.

        Returns:
            dict: A dictionary containing the response data from the authentication emails list endpoint.
        """

        response = self.send_get_request(
            endpoint="/authentication-emails",
            params={"page": page, "itemsPerPage": items_per_page},
        )
        return response
