# Smart Search SDK CLI Documentation

This document provides detailed usage instructions for the Smart Search SDK command-line interface (CLI).

## Installation

The Smart Search CLI is included with the Smart Search SDK package. You can use it in one of the following ways:

1. **Using Poetry (recommended for development)**:

   ```bash
   # Run commands with Poetry
   poetry run smart-search <command>

   # OR create an alias
   alias smart-search="poetry run smart-search"
   smart-search <command>
   ```

2. **Using the `smart-search` executable (WIP)**:

    ```bash
    poetry install smart-search-sdk
    ```

    ```bash
    # Run commands with the executable
    smart-search <command>
    ```

## Environment Variables

### Required Environment Variables

Before using the Smart Search CLI, you need to set up the following environment variables:

```bash
# Required environment variables
export SMARTSEARCH_BASE_URL="https://your-api-url.com"  # API endpoint URL
export SMARTSEARCH_USER_IDENTIFIER="your-user-id"     # Your API user identifier
export SMARTSEARCH_USER_SECRET="your-secret-key"      # Your API user secret
export SMARTSEARCH_TOKEN="your-token"                   # Your Smart Search token
export GL_CONNECTORS_USER_TOKEN="your-gl-token"                   # Your GL Connectors token
```

These environment variables can be set in your shell session, added to your `.bashrc`/`.zshrc` file, or stored in a `.env` file that you load before running commands.

## Commands

### `status`

Check the connection status to the Smart Search API.

```bash
smart-search status [OPTIONS]
```

**Options:**

- `--api-url` - Override the API URL for this command only

**Examples:**

```bash
# Check status using environment variables or global options
smart-search status

# Check status with a specific API URL
smart-search status --api-url http://localhost:8003
```

**Example Output (Success):**

```
╭──────────────────────── 🚀 Connection Status ────────────────────────╮
│ ✅ Connected to Smart Search API                                    │
│ 🔗 API URL: http://localhost:8003                                   │
╰──────────────────────────────────────────────────────────────────────╯

┏━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ Service       ┃ Status        ┃
┡━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ Search API    │ ✅ Connected  │
└───────────────┴───────────────┘
```

### `search key-points`

Perform a search using the Smart Search service.

```bash
smart-search search key-points [OPTIONS]
```

**Options:**

- `--query` - Search query string (required, will prompt if not provided)
- `--search-profiles` - Search profiles to use (required, will prompt if not provided)
  Available options: general, github, google_mail, google_drive, google_calendar
- `--size` - Maximum number of results to return (default: 5)
- `--view` - Output format (default: table, options: table, json)
- All global options are also available

**Examples:**

```bash
# Basic search
smart-search search key-points --query "jakarta hari ini" --search-profiles general --size 3

# Multiple search profiles (comma-separated)
smart-search search key-points --query "jakarta hari ini" --search-profiles "general,github" --size 3
```

**Interactive Mode:**
If you run the command without options, it will prompt you for required inputs:

```bash
smart-search search key-points
```

You'll see the following prompts:

```
Enter query: <your-query>
Enter search profile
Available options are: general, github, google_mail, google_drive, google_calendar
For multiple profile, separate with commas: <search-profiles>
Enter size (default is 5) [5]: <size>
Enter view type (default is table) [table]: <view>
```

---

## Web Search Commands

The `web` command group provides access to web search and scraping functionality.

### `web search`

Search the web for documents or pages relevant to a query. Returns either snippets or keypoints.

```bash
smart-search web search [OPTIONS]
```

**Options:**

- `--query` - Search query string (required, will prompt if not provided)
- `--result-type` - Type of results: `snippets` or `keypoints` (default: snippets)
- `--size` - Maximum number of results to return (1-50, default: 5)
- `--view` - Output format (default: table, options: table, json)

**Examples:**

```bash
# Search for snippets
smart-search web search --query "Python tutorials" --result-type snippets --size 5

# Search for keypoints
smart-search web search --query "machine learning" --result-type keypoints --size 3

# JSON output
smart-search web search --query "Python" --view json
```

**Interactive Mode:**

```bash
smart-search web search
```

Prompts:
```
Enter query: <your-query>
Enter result type (snippets or keypoints): snippets
Enter size (default is 5) [5]: 5
Enter view type (table or json) [table]: table
```

---

### `web urls`

Search the web and return only URLs (like a search engine).

```bash
smart-search web urls [OPTIONS]
```

**Options:**

- `--query` - Search query string (required, will prompt if not provided)
- `--size` - Maximum number of URLs to return (1-50, default: 5)
- `--view` - Output format (default: table, options: table, json)

**Examples:**

```bash
# Get URLs for a query
smart-search web urls --query "Python documentation" --size 10

# JSON output
smart-search web urls --query "Python" --view json
```

---

### `web fetch`

Fetch a single web page by URL and return its content and metadata.

```bash
smart-search web fetch [OPTIONS]
```

**Options:**

- `--url` - URL of the web page to fetch (required, will prompt if not provided)
- `--return-html` - Include full HTML content in response (flag, default: False)
- `--view` - Output format (default: json, options: json, markdown)

**Examples:**

```bash
# Fetch a page (JSON output by default)
smart-search web fetch --url "https://docs.python.org/3/tutorial/"

# Fetch with HTML content
smart-search web fetch --url "https://example.com" --return-html

# Markdown view
smart-search web fetch --url "https://example.com" --view markdown
```

---

### `web snippets`

Extract relevant text snippets from a web page for a given query.

```bash
smart-search web snippets [OPTIONS]
```

**Options:**

- `--query` - Query to search for within the page (required, will prompt if not provided)
- `--url` - URL of the web page to extract from (required, will prompt if not provided)
- `--size` - Maximum number of snippets to return (1-50, default: 5)
- `--style` - Snippet style: `paragraph` or `sentence` (default: paragraph)
- `--view` - Output format (default: table, options: table, json)

**Examples:**

```bash
# Extract paragraph snippets
smart-search web snippets --query "list comprehension" --url "https://docs.python.org/3/tutorial/" --size 3

# Extract sentence snippets
smart-search web snippets --query "decorators" --url "https://realpython.com/primer-on-python-decorators/" --style sentence --size 5

# JSON output
smart-search web snippets --query "python" --url "https://python.org" --view json
```

---

### `web keypoints`

Extract concise key points from a web page for a given query.

```bash
smart-search web keypoints [OPTIONS]
```

**Options:**

- `--query` - Query to search for (required, will prompt if not provided)
- `--url` - URL of the web page to extract from (required, will prompt if not provided)
- `--size` - Maximum number of keypoints to return (1-50, default: 5)
- `--view` - Output format (default: table, options: table, json)

**Examples:**

```bash
# Extract key points
smart-search web keypoints --query "Python features" --url "https://www.python.org/about/" --size 5

# JSON output
smart-search web keypoints --query "AI ethics" --url "https://example.com/ai-article" --view json
```

---

## Connector Commands

The `connector` command group provides integration with third-party services like GitHub, Google Drive, Google Calendar, and Gmail through the GL Connectors connector system.

### `connector connect`

Initiate integration with a third-party connector. This command connects to a specified app and may return a setup URL if OAuth authentication is required.

```bash
smart-search connector connect [OPTIONS]
```

**Options:**

- `--app-name` - App name (required, will prompt if not provided)
  - Available options: `github`, `google_mail`, `google_calendar`, `google_drive`, `chief_retrieval`
- `--gl-token` - Optional GL Connectors token (if not provided, uses default credentials)
- `--callback-url` - OAuth callback URL (optional, defaults to Smart Search's URL)
- `--view` - Output format (default: pretty, options: pretty, json)

**Examples:**

```bash
# Connect to GitHub
smart-search connector connect --app-name github

# Connect to Google Calendar with custom GL Connectors token
smart-search connector connect --app-name google_calendar --gl-token "your-gl-token"

# Connect with custom callback URL
smart-search connector connect --app-name github --callback-url "https://your-app.com/callback"

# JSON output
smart-search connector connect --app-name google_drive --view json
```

**Interactive Mode:**

```bash
smart-search connector connect
```

Prompts:
```
Enter app name: github
Enter GL Connectors token (press Enter to skip):
Enter callback URL (press Enter for default): https://search-api.gdplabs.id/health-check
```

**Output (Success):**

```
╭──────────────────────── ✅ Connected ────────────────────────╮
│ ✓ Successfully connected to GitHub                          │
╰──────────────────────────────────────────────────────────────╯
```

**Output (Setup Required):**

```
╭──────────────────────── ⚠️  Setup Required ──────────────────────╮
│ ⚠ Please visit the following URL to set up the GL Connectors          │
│ integration for GitHub: https://github.com/login/oauth/...   │
│                                                               │
│ Setup URL: https://github.com/login/oauth/authorize?...      │
╰──────────────────────────────────────────────────────────────────╯

Please visit: https://github.com/login/oauth/authorize?...
```

---

### `connector disconnect`

Remove integration with a third-party connector. This command disconnects from a specified app and removes the integration.

```bash
smart-search connector disconnect [OPTIONS]
```

**Options:**

- `--app-name` - App name (required, will prompt if not provided)
  - Available options: `github`, `google_mail`, `google_calendar`, `google_drive`, `chief_retrieval`
- `--gl-token` - Optional GL Connectors token (if not provided, uses default credentials)
- `--view` - Output format (default: pretty, options: pretty, json)

**Examples:**

```bash
# Disconnect from GitHub
smart-search connector disconnect --app-name github

# Disconnect from Google Drive with custom GL Connectors token
smart-search connector disconnect --app-name google_drive --gl-token "your-gl-token"

# JSON output
smart-search connector disconnect --app-name google_mail --view json
```

**Output (Success):**

```
╭──────────────────────── ✅ Disconnected ────────────────────────╮
│ ✓ Successfully disconnected from GitHub                        │
╰─────────────────────────────────────────────────────────────────╯
```

---

### `connector search`

Search a connector for the specified app using natural language queries. This command searches the connected third-party service and returns relevant results.

```bash
smart-search connector search [OPTIONS]
```

**Options:**

- `--query` - Natural language search query (required, will prompt if not provided)
- `--app-name` - App name (required, will prompt if not provided)
  - Available options: `github`, `google_mail`, `google_calendar`, `google_drive`, `chief_retrieval`
- `--gl-token` - Optional GL Connectors token (if not provided, uses default credentials)
- `--view` - Output format (default: table, options: table, json)

**Examples:**

```bash
# Search GitHub for issues
smart-search connector search --query "open issues about authentication" --app-name github

# Search Google Calendar for meetings
smart-search connector search --query "meetings with Alice next week" --app-name google_calendar

# Search Google Drive for documents
smart-search connector search --query "Q2 financial reports" --app-name google_drive --size 10

# Search Gmail with custom GL Connectors token
smart-search connector search --query "emails from Bob about contract" --app-name google_mail --gl-token "your-token"

# JSON output
smart-search connector search --query "repositories about AI" --app-name github --view json
```

**Interactive Mode:**

```bash
smart-search connector search
```

Prompts:
```
Enter query: open issues about authentication
Enter app name: github
Enter GL Connectors token (press Enter to skip):
Enter view type (table or json) [table]: table
```

**Output (Table View):**

```
┏━━━━┳━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┓
┃ No ┃ Title             ┃ Content Preview     ┃ Source            ┃ Score  ┃
┡━━━━╇━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━╇━━━━━━━━┩
│ 1  │ Authentication... │ We need to fix...   │ github.com/org... │ 0.92   │
│ 2  │ Login issues      │ Users reporting...  │ github.com/org... │ 0.87   │
└────┴───────────────────┴─────────────────────┴───────────────────┴────────┘
✓ Found 2 results.
```

**Supported Connectors:**

- **github**: Search GitHub repositories, issues, pull requests
- **google_mail**: Search Gmail messages
- **google_calendar**: Search calendar events and meetings
- **google_drive**: Search Google Drive documents
- **chief_retrieval**: Search Chief knowledge base

---

## Output Formats

The Smart Search CLI supports the following output formats:

1. **Table**: Displays search results in a formatted table with colors (default for search commands)
2. **Pretty**: Displays formatted panels and rich output (default for connector connect/disconnect)
3. **JSON**: Raw JSON output for programmatic processing
4. **Markdown**: Displays content in markdown format (available for web fetch)

Specify the format using the `--view` option:

```bash
# Table view (default for most search commands)
smart-search search key-points --query "your query" --search-profiles general --view table

# Pretty view (default for connector commands)
smart-search connector connect --app-name github --view pretty

# JSON view for machine processing
smart-search search key-points --query "your query" --search-profiles general --view json

# Markdown view for web content
smart-search web fetch --url "https://example.com" --view markdown
```

## Troubleshooting

If you encounter issues with the CLI:

1. Check your network connection to the API server
2. Verify that your API URL is correct
3. Make sure the Smart Search service is running
4. Check for any error messages in the output
5. For credentials issues, reach out to the Smart Search Team
