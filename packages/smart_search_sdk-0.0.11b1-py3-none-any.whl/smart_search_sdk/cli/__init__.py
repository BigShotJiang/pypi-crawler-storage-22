"""CLI package for Smart Search SDK.

Authors:
    Generated from template
"""

from .main import main

__all__ = ["main"]
