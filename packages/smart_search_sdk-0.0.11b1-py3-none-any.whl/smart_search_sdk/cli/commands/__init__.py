"""CLI commands package."""

from . import search

__all__ = ["search"]
