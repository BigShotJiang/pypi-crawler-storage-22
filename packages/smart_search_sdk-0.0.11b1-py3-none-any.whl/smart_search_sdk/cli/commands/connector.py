"""Connector command implementation for Smart Search SDK.

Authors:
    Michael Hans (michael.hans@gdplabs.id)

References:
    [1] https://github.com/GDP-ADMIN/glaip-sdk/tree/main/python/glaip-sdk/glaip_sdk/cli
"""

import asyncio
import sys
import click
import os
import json
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from smart_search_sdk.cli.utils import health_check
from smart_search_sdk.connector.client import ConnectorClient
from smart_search_sdk.connector.models import (
    ConnectorRequest,
    ConnectorConnectRequest,
    AppName,
)
from smart_search_sdk.connector.models.schema import ConnectorResponse
from smart_search_sdk.shared.utils.helper import (
    convert_dict_to_object_based_response,
    parse_bool,
    normalize_connector_token,
)
from smart_search_sdk.shared.utils.stream import handle_cli_response

DEFAULT_CREDENTIALS_TEXT = "Using default credentials"


@click.group(name="connector")
def connector_group():
    """Connector commands for Smart Search SDK."""
    pass


@connector_group.command(name="connect")
@click.option(
    "--app-name",
    required=True,
    type=click.Choice([app.value for app in AppName], case_sensitive=False),
    help="App name (e.g., github, google_mail, google_calendar, google_drive, chief_retrieval)",
    prompt="Enter app name",
)
@click.option(
    "--gl-token",
    required=False,
    help="GL Connectors token (optional, preferred)",
    prompt="Enter GL Connectors token (press Enter to skip)",
    default="",
)
@click.option(
    "--bosa-token",
    required=False,
    help="BOSA token (optional, deprecated - use --gl-token instead)",
    default="",
)
@click.option(
    "--callback-url",
    required=False,
    help="OAuth callback URL (optional, defaults to Smart Search's URL)",
    prompt="Enter callback URL (press Enter for default)",
    default="https://search-api.gdplabs.id/health-check",
)
@click.option(
    "--view",
    default="pretty",
    help="View type: pretty or json (default is pretty)",
)
@click.pass_context
def connect_connector_command(ctx, app_name, gl_token, bosa_token, callback_url, view):
    """
    Initiate integration with a third-party connector.

    This command connects to a specified app (e.g., GitHub, Google Drive) and may return
    a setup URL if OAuth authentication is required.

    Example:

    smart-search connector connect --app-name github --gl-token "1234567890"
    smart-search connector connect --app-name github --bosa-token "1234567890"  # deprecated
    """
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        console = Console()

        api_url = ctx.obj.get("api_url") or os.getenv("SMARTSEARCH_BASE_URL")
        gl_token = normalize_connector_token(gl_token=gl_token, bosa_token=bosa_token)

        client = ConnectorClient(base_url=api_url)

        # Format token display (Python 3.11 compatible)
        gl_token_display = (
            f"{gl_token[:6]}...{gl_token[-6:]}"
            if gl_token
            else DEFAULT_CREDENTIALS_TEXT
        )

        console.print(
            Panel(
                f"[bold blue]🔗 Connecting to connector...[/bold blue]\n"
                f"App name: {app_name}\n"
                f"GL Connectors token: {gl_token_display}\n"
                f"Callback URL: {callback_url}",
                title="Connector Connect",
                border_style="blue",
            )
        )

        request = ConnectorConnectRequest(callback_url=callback_url)

        async def execute():
            await client.authenticate()
            return await handle_cli_response(
                client.connect_connector,
                request,
                False,
                console,
                app_name=app_name,
                gl_token=gl_token,
            )

        try:
            response = asyncio.run(execute())
        except Exception as exec_error:
            console.print(
                Panel(
                    f"[bold red]❌ Error occurred during connection[/bold red]\n"
                    f"Details: {str(exec_error)}",
                    title="Error",
                    border_style="red",
                )
            )
            sys.exit(1)

        if view == "json":
            console.print(json.dumps(response, indent=4))
        else:
            # Display formatted response (default pretty view)
            status = response.get("status", "unknown")
            message = response.get("message", "")
            setup_url = response.get("setup_url")

            if status == "connected":
                console.print(
                    Panel(
                        f"[bold green]✓ {message}[/bold green]",
                        title="✅ Connected",
                        border_style="green",
                    )
                )
            elif status == "setup_required":
                console.print(
                    Panel(
                        f"[bold yellow]⚠ {message}[/bold yellow]\n\n"
                        f"Setup URL: {setup_url}",
                        title="⚠️  Setup Required",
                        border_style="yellow",
                    )
                )
                if setup_url:
                    console.print(f"\n[cyan]Please visit:[/cyan] {setup_url}")
            else:
                console.print(json.dumps(response, indent=4))

    except Exception as e:
        console = Console()
        console.print(
            Panel(
                f"[bold red]❌ Error occurred during connector connection[/bold red]\n"
                f"Details: {str(e)}",
                title="Error",
                border_style="red",
            )
        )
        sys.exit(1)


@connector_group.command(name="disconnect")
@click.option(
    "--app-name",
    required=True,
    type=click.Choice([app.value for app in AppName], case_sensitive=False),
    help="App name (e.g., github, google_mail, google_calendar, google_drive, chief_retrieval)",
    prompt="Enter app name",
)
@click.option(
    "--gl-token",
    required=False,
    help="GL Connectors token (optional, preferred)",
    prompt="Enter GL Connectors token (press Enter to skip)",
    default="",
)
@click.option(
    "--bosa-token",
    required=False,
    help="BOSA token (optional, deprecated - use --gl-token instead)",
    default="",
)
@click.option(
    "--view",
    default="pretty",
    help="View type: pretty or json (default is pretty)",
)
@click.pass_context
def disconnect_connector_command(ctx, app_name, gl_token, bosa_token, view):
    """
    Remove integration with a third-party connector.

    This command disconnects from a specified app and removes the integration.

    Example:

    smart-search connector disconnect --app-name github --gl-token "1234567890"
    smart-search connector disconnect --app-name github --bosa-token "1234567890"  # deprecated
    """
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        console = Console()

        api_url = ctx.obj.get("api_url") or os.getenv("SMARTSEARCH_BASE_URL")
        gl_token = normalize_connector_token(gl_token=gl_token, bosa_token=bosa_token)

        client = ConnectorClient(base_url=api_url)

        # Format token display (Python 3.11 compatible)
        gl_token_display = (
            f"{gl_token[:6]}...{gl_token[-6:]}"
            if gl_token
            else DEFAULT_CREDENTIALS_TEXT
        )

        console.print(
            Panel(
                f"[bold blue]🔌 Disconnecting from connector...[/bold blue]\n"
                f"App name: {app_name}\n"
                f"GL Connectors token: {gl_token_display}",
                title="Connector Disconnect",
                border_style="blue",
            )
        )

        async def execute():
            await client.authenticate()
            return await handle_cli_response(
                client.disconnect_connector,
                None,
                False,
                console,
                app_name=app_name,
                gl_token=gl_token,
            )

        try:
            response = asyncio.run(execute())
        except Exception as exec_error:
            console.print(
                Panel(
                    f"[bold red]❌ Error occurred during disconnection[/bold red]\n"
                    f"Details: {str(exec_error)}",
                    title="Error",
                    border_style="red",
                )
            )
            sys.exit(1)

        if view == "json":
            console.print(json.dumps(response, indent=4))
        else:
            # Display formatted response (default pretty view)
            status = response.get("status", "unknown")
            message = response.get("message", "")

            if status == "disconnected":
                console.print(
                    Panel(
                        f"[bold green]✓ {message}[/bold green]",
                        title="✅ Disconnected",
                        border_style="green",
                    )
                )
            else:
                console.print(json.dumps(response, indent=4))

    except Exception as e:
        console = Console()
        console.print(
            Panel(
                f"[bold red]❌ Error occurred during connector disconnection[/bold red]\n"
                f"Details: {str(e)}",
                title="Error",
                border_style="red",
            )
        )
        sys.exit(1)


@connector_group.command(name="search")
@click.option(
    "--query",
    required=True,
    help="Natural language search query",
    prompt="Enter query",
)
@click.option(
    "--app-name",
    required=True,
    type=click.Choice([app.value for app in AppName], case_sensitive=False),
    help="App name (e.g., github, google_mail, google_calendar, google_drive, chief_retrieval)",
    prompt="Enter app name",
)
@click.option(
    "--gl-token",
    required=False,
    help="GL Connectors token (optional, preferred)",
    prompt="Enter GL Connectors token (press Enter to skip)",
    default="",
)
@click.option(
    "--bosa-token",
    required=False,
    help="BOSA token (optional, deprecated - use --gl-token instead)",
    default="",
)
@click.option(
    "--view",
    default="table",
    help="View type: table or json (default is table)",
    prompt="Enter view type (table or json)",
)
@click.option(
    "--stream",
    default="false",
    help="Stream the response (default is false)",
    prompt="Enter stream (default is false)",
)
@click.pass_context
def search_connector_command(ctx, query, app_name, gl_token, bosa_token, view, stream):
    """
    Search a connector for the specified app using natural language.

    This command searches the connected third-party service (GitHub, Google Drive, etc.)
    and returns relevant results.

    Examples:

    smart-search connector search --query "open issues about auth" --app-name github

    smart-search connector search --query "meetings with Alice next week" --app-name google_calendar

    smart-search connector search --query "documents about Q2 financials" --app-name google_drive
    """
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        console = Console()

        view = view if view in ["table", "json"] else "table"
        api_url = ctx.obj.get("api_url") or os.getenv("SMARTSEARCH_BASE_URL")
        gl_token = normalize_connector_token(gl_token=gl_token, bosa_token=bosa_token)

        client = ConnectorClient(base_url=api_url)

        # Format token display (Python 3.11 compatible)
        gl_token_display = (
            f"{gl_token[:6]}...{gl_token[-6:]}"
            if gl_token
            else DEFAULT_CREDENTIALS_TEXT
        )

        console.print(
            Panel(
                f"[bold blue]🔍 Searching connector...[/bold blue]\n"
                f"Query: {query}\n"
                f"App name: {app_name}\n"
                f"GL Connectors token: {gl_token_display}\n"
                f"View: {view}",
                title="Connector Search",
                border_style="blue",
            )
        )

        request = ConnectorRequest(query=query)

        async def execute():
            await client.authenticate()
            return await handle_cli_response(
                client.search_connector,
                request,
                parse_bool(stream),
                console,
                app_name=app_name,
                gl_token=gl_token,
            )

        try:
            response = asyncio.run(execute())
        except Exception as exec_error:
            console.print(
                Panel(
                    f"[bold red]❌ Error occurred during search[/bold red]\n"
                    f"Details: {str(exec_error)}",
                    title="Error",
                    border_style="red",
                )
            )
            sys.exit(1)

        response["data"] = convert_dict_to_object_based_response(
            response.get("data", []), ConnectorResponse
        )

        if view == "json":
            console.print(json.dumps(response, indent=4))
            return
        elif view == "table":
            if "data" in response and response["data"]:
                table = Table(
                    title=f"🔍 Connector Search Results for '{query}' ({app_name})"
                )
                table.add_column("No", style="cyan", no_wrap=True, width=4)
                table.add_column("Title", style="white", width=30)
                table.add_column("Content Preview", style="yellow", width=50)
                table.add_column("Source", style="green", width=30)
                table.add_column("Score", style="magenta", width=8)

                for idx, result in enumerate(response.get("data", [])):
                    content = result.content
                    if len(content) > 100:
                        content = content[:97] + "..."

                    metadata = result.metadata
                    title = metadata.title
                    if len(title) > 30:
                        title = title[:27] + "..."

                    source = metadata.source
                    if len(source) > 30:
                        source = source[:27] + "..."

                    score = result.confidence_score
                    score_str = f"{score:.2f}" if score is not None else "N/A"

                    table.add_row(
                        str(idx + 1),
                        title,
                        content,
                        source,
                        score_str,
                    )

                console.print(table)
                console.print(
                    f"[green]✓[/green] Found {len(response.get('data', []))} results."
                )
            else:
                console.print(
                    Panel(
                        "[yellow]No results found.[/yellow]",
                        title="Search Results",
                        border_style="yellow",
                    )
                )

    except Exception as e:
        console = Console()
        console.print(
            Panel(
                f"[bold red]❌ Error occurred during connector search[/bold red]\n"
                f"Details: {str(e)}",
                title="Error",
                border_style="red",
            )
        )
        sys.exit(1)
