"""Search command implementation for Smart Search SDK.

Authors:
    Glenn S. Santoso (glenn.s.santoso@gdplabs.id)

References:
    [1] https://github.com/GDP-ADMIN/glaip-sdk/tree/main/python/glaip-sdk/glaip_sdk/cli
"""

import asyncio
import sys
import click
import os
import json
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from smart_search_sdk.cli.utils import health_check
from smart_search_sdk.search.client import (
    SmartSearchSearchClient,
    SmartSearchKeyPointsRequest,
)


@click.group(name="search")
def search_group():
    """Search commands for Smart Search SDK."""
    pass


@search_group.command(name="key-points")
@click.option(
    "--query", required=True, help="Search query string", prompt="Enter query"
)
@click.option(
    "--search-profiles",
    required=True,
    help="Search profiles to use, available options are:\ngeneral, github, google_mail, google_drive, google_calendar (default is general).\nSeparate by commas",
    default="general",
    prompt="Enter search profile\nAvailable options are: general, github, google_mail, google_drive, google_calendar\nFor multiple profile, separate with commas",
)
@click.option(
    "--size",
    default=5,
    help="Maximum number of results to return, default is 5 if you don't specify any",
    prompt="Enter size (default is 5)",
)
@click.option(
    "--view",
    default="table",
    help="View type, available options are: table, json",
    prompt="Enter view type (default is table)\navailable options are: table, json\n",
)
@click.pass_context
def search_command(ctx, query, search_profiles, size, view):
    """
    Perform a search using Smart Search service.

    query is the search query string.\n

    Example:\n

    smart-search search key-points --query "jakarta hari ini" --search-profiles general --size 3\n\n

    If you wish to use multiple search profiles, you can use the --search-profiles option multiple times:\n

    smart-search search key-points --query "jakarta hari ini" --search-profiles general --search-profiles github --size 3

    If you run the command plain, it will trigger the prompt:\n

    smart-search search key-points\n\n
    Enter query: <your-query>\n
    Enter search profile\nAvailable options are: general, github, google_mail, google_drive, google_calendar\nFor multiple profile, separate with commas: <search-profiles>\n
    Enter size (default is 5) [5]: <size>
    """
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        console = Console()

        view = view if view in ["table", "json"] else "table"

        size = size if isinstance(size, int) else 5

        api_url = ctx.obj.get("api_url") or os.getenv("SMARTSEARCH_BASE_URL")
        search_profiles = [item.strip() for item in search_profiles.split(",")]

        for profile in search_profiles:
            if profile not in [
                "general",
                "github",
                "google_mail",
                "google_drive",
                "google_calendar",
            ]:
                console.print(
                    Panel(
                        f"[bold red]❌ Invalid search profile: {profile}[/bold red]\n"
                        f"Available options are: general, github, google_mail, google_drive, google_calendar",
                        title="Error",
                        border_style="red",
                    )
                )
                search_profiles.remove(profile)

        if not search_profiles:
            search_profiles = ["general"]

        # TODO: add cache manager
        client = SmartSearchSearchClient(base_url=api_url)

        console.print(
            Panel(
                f"[bold blue]🔍 Searching...[/bold blue]\n"
                f"Search profiles: {', '.join(search_profiles)}\n"
                f"Query: {query}\n"
                f"Size: {size}\n"
                f"View: {view}",
                title="Smart Search",
                border_style="blue",
            )
        )

        try:
            asyncio.run(client.authenticate())
        except Exception as e:
            console.print(
                Panel(
                    f"[bold red]❌ Error occurred during authentication[/bold red]\n"
                    f"Details: {str(e)}",
                    title="Error",
                    border_style="red",
                )
            )
            sys.exit(1)

        request = SmartSearchKeyPointsRequest(
            query=query,
            search_profile_names=search_profiles,
            size=size,
        )

        response = client.search(request)

        if view == "json":
            console.print(json.dumps(response, indent=4))
            return
        elif view == "table":
            if "data" in response and response["data"]:
                table = Table(title=f"🔍 Search Results for '{query}'")
                table.add_column("No", style="cyan", no_wrap=True)
                table.add_column("URL", style="green")
                table.add_column("Title", style="white")

                for idx, result in enumerate(response.get("data", [])):
                    table.add_row(
                        str(idx + 1),
                        result.get("metadata", {}).get("source", ""),
                        result.get("metadata", {}).get("title", ""),
                    )

                console.print(table)
                console.print(
                    f"[green]✓[/green] Found {len(response.get('data', []))} result."
                )
            else:
                console.print(
                    Panel(
                        "[yellow]No results found.[/yellow]",
                        title="Search Results",
                        border_style="yellow",
                    )
                )

    except Exception as e:
        console = Console()
        console.print(
            Panel(
                f"[bold red]❌ Error occurred during search[/bold red]\n"
                f"Details: {str(e)}",
                title="Error",
                border_style="red",
            )
        )
