"""Utils implementation for Smart Search SDK.

Authors:
    Glenn S. Santoso (glenn.s.santoso@gdplabs.id)

References:
    [1] https://github.com/GDP-ADMIN/glaip-sdk/tree/main/python/glaip-sdk/glaip_sdk/cli
"""

import click
from rich.console import Console
from rich.panel import Panel


@click.group(name="set")
def set_group():
    """Set commands for Smart Search SDK."""
    pass


@set_group.command(name="api-url")
@click.argument("api_url", envvar="SMARTSEARCH_BASE_URL")
@click.pass_context
def set_api_url(ctx, api_url):
    """Set the API URL for Smart Search SDK."""
    ctx.obj["api_url"] = api_url
    console = Console()
    console.print(
        Panel(
            f"[bold blue]API URL set to: {api_url}[/bold blue]",
            title="Smart Search",
            border_style="blue",
        )
    )


@set_group.command(name="api-user-identifier")
@click.argument("api_user_identifier", envvar="SMARTSEARCH_USER_IDENTIFIER")
@click.pass_context
def set_api_user_identifier(ctx, api_user_identifier):
    """Set the API user identifier for Smart Search SDK."""
    ctx.obj["api_user_identifier"] = api_user_identifier

    console = Console()
    console.print(
        Panel(
            f"[bold blue]API user identifier set to: {api_user_identifier}[/bold blue]",
            title="Smart Search",
            border_style="blue",
        )
    )


@set_group.command(name="api-user-secret")
@click.argument("api_user_secret", envvar="SMARTSEARCH_USER_SECRET")
@click.pass_context
def set_api_user_secret(ctx, api_user_secret):
    """Set the API user secret for Smart Search SDK."""
    ctx.obj["api_user_secret"] = api_user_secret
    console = Console()
    console.print(
        Panel(
            f"[bold blue]API user secret set to: {api_user_secret[:4]}...{api_user_secret[-4:]}[/bold blue]",
            title="Smart Search",
            border_style="blue",
        )
    )
