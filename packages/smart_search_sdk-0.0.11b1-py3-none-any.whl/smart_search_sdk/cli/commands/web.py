"""Web command implementation for Smart Search SDK.

Authors:
    Glenn S. Santoso (glenn.s.santoso@gdplabs.id)

References:
    [1] https://github.com/GDP-ADMIN/glaip-sdk/tree/main/python/glaip-sdk/glaip_sdk/cli
"""

from json.decoder import JSONDecodeError
import asyncio
import sys
from typing import Any, AsyncGenerator, Callable, Iterable, Sequence
import click
import os
import json
from pydantic import BaseModel
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.markdown import Markdown
from smart_search_sdk.config.constants import EventType

from smart_search_sdk.cli.utils import health_check
from smart_search_sdk.shared.utils.helper import (
    convert_dict_to_object_based_response,
    parse_bool,
    parse_comma_separated_sites,
)
from smart_search_sdk.shared.utils.table_renderer import render_raw_data_table
from smart_search_sdk.shared.utils.stream import handle_cli_response
from smart_search_sdk.web.client import WebSearchClient
from smart_search_sdk.web.models import (
    GetWebSearchUrlsRequest,
    GetWebPageRequest,
    GetWebPageSnippetsRequest,
    GetWebPageKeypointsRequest,
    GetWebPageResponse,
    GetWebSearchMapRequest,
    GetWebSearchMapResponse,
    GetWebSearchResultsResponse,
    GetWebSearchResultsRequest,
    GetWebSearchUrlsResponse,
    GetWebPageSnippetsResponse,
    GetWebPageKeypointsResponse,
    WebSearchEngine,
)
from smart_search_sdk.config.constants import SmartSearchEmitDataValue


def create_cli_executor(
    client: WebSearchClient,
    method: Callable,
    request: BaseModel,
    stream: bool,
    console: Console,
):
    """Create an async executor function for CLI commands.

    This helper reduces code duplication by wrapping the common pattern of:
    1. Authenticating the client
    2. Handling the CLI response through the method call

    Args:
        client: The WebSearchClient instance
        method: The client method to call
        request: The request object to pass to the method
        stream: Whether to stream the response
        console: The console instance for output

    Returns:
        An async function that executes the authentication and method call
    """

    async def execute():
        await client.authenticate()
        return await handle_cli_response(method, request, stream, console)

    return execute


def _get_api_url(ctx) -> str | None:
    ctx_obj = getattr(ctx, "obj", None) or {}
    return ctx_obj.get("api_url") or os.getenv("SMARTSEARCH_BASE_URL")


def _normalize_choice(value: str, allowed: Sequence[str], default: str) -> str:
    return value if value in allowed else default


def _coerce_bounded_int(
    value: Any,
    default: int,
    min_value: int,
    max_value: int,
) -> int:
    if isinstance(value, int):
        parsed = value
    elif isinstance(value, str) and value.isdigit():
        parsed = int(value)
    else:
        parsed = default
    return max(min_value, min(max_value, parsed))


def _print_error_panel(console: Console, message: str, title: str = "Error") -> None:
    console.print(
        Panel(
            message,
            title=title,
            border_style="red",
        )
    )


def _exit_with_error(console: Console, message: str, title: str = "Error") -> None:
    _print_error_panel(console, message, title=title)
    sys.exit(1)


def _run_executor_or_exit(console: Console, execute: Callable[[], Any]) -> dict:
    try:
        return asyncio.run(execute())
    except Exception as auth_error:
        _exit_with_error(
            console,
            f"[bold red]❌ Error occurred[/bold red]\nDetails: {str(auth_error)}",
            title="Error",
        )


def _serialize_iterable_for_json(data: Any) -> Any:
    if not hasattr(data, "__iter__") or isinstance(data, (str, dict)):
        return data
    return [
        item.model_dump(mode="json", exclude_none=True)
        if hasattr(item, "model_dump")
        else item
        for item in data
    ]


def _serialize_model_for_json(data: Any, *, exclude_none: bool = True) -> Any:
    if hasattr(data, "model_dump"):
        if exclude_none:
            return data.model_dump(mode="json", exclude_none=True)
        return data.model_dump(mode="json")
    return data


def _print_json(console: Console, response: dict, default: Any = None) -> None:
    if default is None:
        console.print(json.dumps(response, indent=4))
    else:
        console.print(json.dumps(response, indent=4, default=default))


def _try_parse_json_schema(
    console: Console,
    json_schema_value: str,
    *,
    none_sentinel: str = "None",
    invalid_is_fatal: bool,
    warn_on_none_sentinel: bool = False,
) -> dict | None:
    if json_schema_value == none_sentinel:
        if warn_on_none_sentinel:
            _print_error_panel(
                console,
                "[bold yellow]❌ Invalid JSON schema[/bold yellow]",
                title="Error",
            )
        return None

    try:
        return json.loads(json_schema_value)
    except JSONDecodeError as e:
        if invalid_is_fatal:
            _exit_with_error(
                console,
                f"[bold red]❌ Invalid JSON schema provided[/bold red]\nDetails: {str(e)}",
                title="Invalid JSON Schema",
            )
        _print_error_panel(
            console,
            "[bold yellow]❌ Invalid JSON schema[/bold yellow]",
            title="Error",
        )
        return None


def _truncate(text: str, limit: int) -> str:
    return text[:limit] + "..." if len(text) > limit else text


def _render_no_results_panel(console: Console, message: str, title: str) -> None:
    console.print(Panel(message, title=title, border_style="yellow"))


def _render_search_results_table(
    console: Console,
    query: str,
    results: Iterable[Any],
) -> None:
    table = Table(title=f"🔍 Web Search Results for '{query}'")
    table.add_column("No", style="cyan", no_wrap=True)
    table.add_column("URL", style="green")
    table.add_column("Title", style="white")
    table.add_column("Content Preview", style="yellow")

    results_list = list(results)
    for idx, result in enumerate(results_list):
        content = _truncate(result.content, 100)
        table.add_row(
            str(idx + 1),
            result.metadata.source,
            result.metadata.title,
            content,
        )

    console.print(table)
    console.print(f"[green]✓[/green] Found {len(results_list)} results.")


def _render_excerpt_table(
    console: Console,
    title: str,
    rows: Iterable[Any],
    *,
    content_column_label: str,
    found_label: str,
) -> None:
    table = Table(title=title)
    table.add_column("No", style="cyan", no_wrap=True)
    table.add_column(content_column_label, style="white")
    table.add_column("Score", style="green")

    rows_list = list(rows)
    for idx, result in enumerate(rows_list):
        table.add_row(str(idx + 1), result.content, str(result.confidence_score))

    console.print(table)
    console.print(f"[green]✓[/green] Found {len(rows_list)} {found_label}.")


@click.group(name="web")
def web_group():
    """Web search commands for Smart Search SDK."""
    pass


@web_group.command(name="search")
@click.option(
    "--query", required=True, help="Search query string", prompt="Enter query"
)
@click.option(
    "--site",
    default="None",
    help="Optional URL(s) to limit search results to specific site(s) or domain(s). Separate multiple sites with commas.",
    prompt="Enter site(s) (optional, comma-separated for multiple)",
)
@click.option(
    "--result-type",
    default="snippets",
    help="Result type: snippets or keypoints (default is snippets)",
    prompt="Enter result type (snippets or keypoints or summary)",
)
@click.option(
    "--search-mode",
    default=WebSearchEngine.AUTO.value,
    help=f"Search mode to use ({WebSearchEngine.AUTO}, {WebSearchEngine.FIRECRAWL}, {WebSearchEngine.PERPLEXITY}). Defaults to {WebSearchEngine.AUTO} which uses the default search mode.",
    prompt=f"Enter search mode ({WebSearchEngine.AUTO}, {WebSearchEngine.FIRECRAWL}, {WebSearchEngine.PERPLEXITY})",
)
@click.option(
    "--size",
    default=5,
    help="Maximum number of results to return (1-50), default is 5",
    prompt="Enter size (default is 5)",
)
@click.option(
    "--stream",
    default="false",
    help="Stream the response (default is false)",
    prompt="Enter stream (default is false)",
)
@click.option(
    "--view",
    default="table",
    help="View type: table or json (default is table)",
    prompt="Enter view type (table or json)",
)
@click.pass_context
def search_web_command(ctx, query, site, result_type, search_mode, size, stream, view):
    """
    Search the web for documents or pages relevant to the input query.

    Returns either snippets or keypoints based on the result_type parameter.

    Example:

    smart-search web search --query "Python tutorials" --result-type snippets --search-mode auto --size 5

    If you run the command plain, it will trigger the prompt:

    smart-search web search
    """
    console = Console()
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        view = _normalize_choice(view, ["table", "json"], "table")
        site = parse_comma_separated_sites(site)
        result_type = _normalize_choice(
            result_type, ["snippets", "keypoints", "summary"], "snippets"
        )
        size = _coerce_bounded_int(size, 5, 1, 50)

        api_url = _get_api_url(ctx)
        client = WebSearchClient(base_url=api_url)

        console.print(
            Panel(
                f"[bold blue]🔍 Searching the web...[/bold blue]\n"
                f"Query: {query}\n"
                f"Result type: {result_type}\n"
                f"Size: {size}\n"
                f"Site: {site or 'None'}\n"
                f"View: {view}",
                title="Web Search",
                border_style="blue",
            )
        )

        request = GetWebSearchResultsRequest(
            query=query,
            result_type=result_type,
            size=size,
            search_mode=search_mode,
            site=site,
        )

        execute = create_cli_executor(
            client, client.search_web, request, parse_bool(stream), console
        )
        response = _run_executor_or_exit(console, execute)

        response["data"] = convert_dict_to_object_based_response(
            response.get("data", []), GetWebSearchResultsResponse
        )

        if view == "json":
            response["data"] = _serialize_iterable_for_json(response["data"])
            _print_json(console, response)
            return

        if "data" in response and response["data"]:
            _render_search_results_table(console, query, response.get("data", []))
            return

        _render_no_results_panel(
            console,
            "[yellow]No results found.[/yellow]",
            title="Search Results",
        )
    except Exception as e:
        _exit_with_error(
            console,
            f"[bold red]❌ Error occurred during web search[/bold red]\nDetails: {str(e)}",
            title="Error",
        )


@web_group.command(name="map")
@click.option(
    "--base-url",
    required=True,
    help="Base URL to map",
    prompt="Enter base URL",
)
@click.option(
    "--page",
    default=1,
    help="Page number to return (default is 1). Can be skipped if --return-all-map is true.",
    prompt="Enter page number (default is 1)",
)
@click.option(
    "--size",
    default=20,
    help="Maximum number of URLs to return, default is 20. Can be skipped if --return-all-map is true.",
    prompt="Enter size (default is 20)",
)
@click.option(
    "--include-subdomains",
    default="false",
    help="Include subdomains in the map (default is false)",
    prompt="Include subdomains? (true/false)",
)
@click.option(
    "--query",
    default="None",
    help="Optional query for filtering URLs by keywords",
    prompt="Enter optional query (press Enter to skip)",
)
@click.option(
    "--return-all-map",
    default="false",
    help="Return all mapped links (default is false)",
    prompt="Return all mapped links? (true/false)",
)
@click.option(
    "--stream",
    default="false",
    help="Enable streaming response (default is false)",
    prompt="Enable streaming? (true/false)",
)
@click.option(
    "--view",
    default="table",
    help="View type: table or json (default is table)",
    prompt="Enter view type (table or json)",
)
@click.pass_context
def map_command(
    ctx, base_url, page, size, include_subdomains, query, return_all_map, stream, view
):
    """
    Map and discover URLs from a website.

    Example:

    smart-search web map --base-url "https://firecrawl.dev" --size 10 --include-subdomains true
    """
    try:
        if query == "None":
            query = None

        return_all_map = (
            parse_bool(return_all_map)
            if isinstance(return_all_map, str)
            else return_all_map
        )

        include_subdomains = (
            parse_bool(include_subdomains)
            if isinstance(include_subdomains, str)
            else include_subdomains
        )
        stream = parse_bool(stream) if isinstance(stream, str) else stream

        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        console = Console()

        view = view if view in ["table", "json"] else "table"
        size = int(size) if isinstance(size, (int, str)) and str(size).isdigit() else 20
        size = max(1, size)

        api_url = ctx.obj.get("api_url") or os.getenv("SMARTSEARCH_BASE_URL")

        client = WebSearchClient(base_url=api_url)

        query_message = "None" if query is None else query

        console.print(
            Panel(
                f"[bold blue]🗺️  Mapping website...[/bold blue]\n"
                f"Base URL: {base_url}\n"
                f"Size: {size}\n"
                f"Include Subdomains: {include_subdomains}\n"
                f"Query: {query_message}\n"
                f"View: {view}",
                title="Web Map",
                border_style="blue",
            )
        )

        request = GetWebSearchMapRequest(
            base_url=base_url,
            page=page,
            size=size,
            include_subdomains=include_subdomains,
            query=query,
            return_all_map=return_all_map,
        )

        execute = create_cli_executor(
            client, client.search_web_map, request, stream, console
        )

        try:
            response = asyncio.run(execute())
        except Exception as e:
            console.print(f"[red]Error executing web map: {e}[/red]")
            sys.exit(1)

        response["data"] = convert_dict_to_object_based_response(
            response.get("data", []), GetWebSearchMapResponse
        )

        if view == "json":
            # map_command data is already a model with .model_dump()
            if hasattr(response["data"], "model_dump"):
                response["data"] = response["data"].model_dump(
                    mode="json", exclude_none=True
                )
            console.print(json.dumps(response, indent=4, default=str))
        else:
            if "data" in response and response["data"] and len(response["data"]) > 0:
                table = Table(
                    title="Web Map Results",
                    show_header=True,
                    header_style="bold magenta",
                )
                table.add_column("#", style="cyan", width=6)
                table.add_column("URL", style="green")
                table.add_column("Title", style="blue")
                table.add_column("Description", style="white")

                for idx, result in enumerate(response["data"]):
                    table.add_row(
                        str(idx + 1),
                        str(result.url) or "N/A",
                        result.title or "N/A",
                        result.description or "N/A",
                    )

                console.print(table)
                console.print(
                    f"[green]✓[/green] Found {len(response.get('data', []))} URLs."
                )
            else:
                console.print(
                    Panel(
                        "[yellow]No URLs found.[/yellow]",
                        title="Web Map Results",
                        border_style="yellow",
                    )
                )

    except Exception as e:
        console = Console()
        console.print(
            Panel(
                f"[bold red]❌ Error occurred during web mapping[/bold red]\n"
                f"Details: {str(e)}",
                title="Error",
                border_style="red",
            )
        )
        sys.exit(1)


@web_group.command(name="urls")
@click.option(
    "--query", required=True, help="Search query string", prompt="Enter query"
)
@click.option(
    "--site",
    default="None",
    help="Optional URL(s) to limit search results to specific site(s) or domain(s). Separate multiple sites with commas.",
    prompt="Enter site(s) (optional, comma-separated for multiple)",
)
@click.option(
    "--size",
    default=5,
    help="Maximum number of URLs to return (1-50), default is 5",
    prompt="Enter size (default is 5)",
)
@click.option(
    "--search-mode",
    default=WebSearchEngine.AUTO.value,
    help=f"Search mode to use ({WebSearchEngine.AUTO.value}, {WebSearchEngine.FIRECRAWL.value}, {WebSearchEngine.PERPLEXITY.value}). Defaults to {WebSearchEngine.AUTO.value} which uses the default search mode.",
    prompt=f"Enter search mode ({WebSearchEngine.AUTO.value}, {WebSearchEngine.FIRECRAWL.value}, {WebSearchEngine.PERPLEXITY.value})",
)
@click.option(
    "--stream",
    default="false",
    help="Stream the response (default is false)",
    prompt="Enter stream (default is false)",
)
@click.option(
    "--view",
    default="table",
    help="View type: table or json (default is table)",
    prompt="Enter view type (table or json)",
)
@click.pass_context
def search_urls_command(
    ctx,
    query,
    site,
    size,
    search_mode,
    stream,
    view,
):
    """
    Search the web for pages and return their URLs.

    This command behaves like a search engine (e.g., Google), returning a list of URLs.

    Example:

    smart-search web urls --query "Python documentation" --size 10 --search-mode auto --stream "true" --view "json"
    """
    try:
        # Convert "None" string or empty string to None for optional site parameter
        site = parse_comma_separated_sites(site)
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        console = Console()

        view = view if view in ["table", "json"] else "table"
        size = int(size) if isinstance(size, (int, str)) and str(size).isdigit() else 5
        size = max(1, min(50, size))

        api_url = (ctx.obj.get("api_url") if ctx.obj else None) or os.getenv(
            "SMARTSEARCH_BASE_URL"
        )

        client = WebSearchClient(base_url=api_url)

        console.print(
            Panel(
                f"[bold blue]🔍 Searching for URLs...[/bold blue]\n"
                f"Query: {query}\n"
                f"Size: {size}\n"
                f"View: {view}\n"
                f"Site: {site or 'None'}",
                title="Web URL Search",
                border_style="blue",
            )
        )

        request = GetWebSearchUrlsRequest(
            query=query, size=size, site=site, search_mode=search_mode
        )

        execute = create_cli_executor(
            client, client.search_web_urls, request, parse_bool(stream), console
        )

        try:
            response = asyncio.run(execute())

        except Exception as auth_error:
            console.print(
                Panel(
                    f"[bold red]❌ Error occurred[/bold red]\n"
                    f"Details: {str(auth_error)}",
                    title="Error",
                    border_style="red",
                )
            )
            sys.exit(1)

        response["data"] = convert_dict_to_object_based_response(
            response.get("data", []), GetWebSearchUrlsResponse
        )

        if view == "json":
            # Convert list of URLs/strings to JSON-serializable format
            if hasattr(response["data"], "__iter__") and not isinstance(
                response["data"], (str, dict)
            ):
                response["data"] = [str(item) for item in response["data"]]
            console.print(json.dumps(response, indent=4))
            return
        elif view == "table":
            if "data" in response and response["data"]:
                table = Table(title=f"🔗 URLs for '{query}'")
                table.add_column("No", style="cyan", no_wrap=True)
                table.add_column("URL", style="green")

                for idx, url in enumerate(response.get("data", [])):
                    table.add_row(str(idx + 1), str(url))

                console.print(table)
                console.print(
                    f"[green]✓[/green] Found {len(response.get('data', []))} URLs."
                )
            else:
                console.print(
                    Panel(
                        "[yellow]No URLs found.[/yellow]",
                        title="URL Results",
                        border_style="yellow",
                    )
                )

    except Exception as e:
        console = Console()
        console.print(
            Panel(
                f"[bold red]❌ Error occurred during URL search[/bold red]\n"
                f"Details: {str(e)}",
                title="Error",
                border_style="red",
            )
        )
        sys.exit(1)


@web_group.command(name="fetch")
@click.option(
    "--url", required=True, help="URL of the web page to fetch", prompt="Enter URL"
)
@click.option(
    "--return-html",
    is_flag=True,
    default="false",
    help="Return full HTML content (default is false)",
)
@click.option(
    "--json-schema",
    default="None",
    help="Enter JSON schema string, or 'None' to skip (default is None)",
    prompt="Enter JSON schema (or 'None' to skip)",
)
@click.option(
    "--search-mode",
    default="auto",
    help="Search mode: auto, balance, self_host (default is auto)",
    prompt="Enter search mode (auto, balance, self_host)",
    type=click.Choice(["auto", "balance", "self_host"]),
)
@click.option(
    "--stream",
    default="false",
    help="Stream the response (default is false)",
    prompt="Enter stream (default is false)",
)
@click.option(
    "--view",
    default="json",
    help="View type: json, markdown (default is json)",
    prompt="Enter view type (json or markdown)",
)
@click.pass_context
def fetch_page_command(ctx, url, return_html, json_schema, search_mode, stream, view):
    """
    Fetch a single web page by URL and return its content and metadata.

    Example:

    smart-search web fetch --url "https://docs.python.org/3/tutorial/" --return-html
    """
    console = Console()
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        view = _normalize_choice(view, ["markdown", "json"], "json")
        api_url = _get_api_url(ctx)

        parsed_schema = _try_parse_json_schema(
            console,
            json_schema,
            invalid_is_fatal=False,
            warn_on_none_sentinel=True,
        )

        client = WebSearchClient(base_url=api_url)

        console.print(
            Panel(
                f"[bold blue]📄 Fetching web page...[/bold blue]\n"
                f"URL: {url}\n"
                f"Return HTML: {return_html}\n"
                f"View: {view}",
                title="Fetch Web Page",
                border_style="blue",
            )
        )

        request = GetWebPageRequest(
            source=url,
            json_schema=parsed_schema,
            return_html=return_html,
            search_mode=search_mode,
        )

        execute = create_cli_executor(
            client, client.fetch_web_page, request, parse_bool(stream), console
        )
        response = _run_executor_or_exit(console, execute)

        response["data"] = convert_dict_to_object_based_response(
            response,
            GetWebPageResponse,
            return_model_only=True,
        )

        if response["data"] is None:
            _exit_with_error(
                console,
                "[bold red]❌ Page not found[/bold red]",
                title="Error",
            )

        console.print(
            Panel(
                f"[bold green]✓ Page fetched successfully[/bold green]\n"
                f"Title: {response['data'].metadata.title or 'N/A'}\n"
                f"Description: {response['data'].metadata.description or 'N/A'}\n"
                f"Language: {response['data'].metadata.language or 'N/A'}\n"
                f"Status: {response['data'].metadata.status_code or 'N/A'}",
                title="Page Metadata",
                border_style="green",
            )
        )

        if view == "json":
            response["data"] = _serialize_model_for_json(
                response["data"],
                exclude_none=False,
            )
            _print_json(console, response)
            return

        if response["data"].markdown:
            console.print("\n[bold]Page Content (Markdown):[/bold]\n")
            md = Markdown(response["data"].markdown[:2000])
            console.print(md)
            if len(response["data"].markdown) > 2000:
                console.print("\n[dim]... (content truncated)[/dim]")

        if response["data"].json:
            console.print("\n[bold]Page Content for schema response (JSON):[/bold]\n")
            json_str = json.dumps(response["data"].json, indent=4)
            console.print(json_str[:2000])
            if len(json_str) > 2000:
                console.print("\n[dim]... (content truncated)[/dim]")
    except Exception as e:
        _exit_with_error(
            console,
            f"[bold red]❌ Error occurred while fetching page[/bold red]\nDetails: {str(e)}",
            title="Error",
        )


@web_group.command(name="snippets")
@click.option(
    "--query",
    required=True,
    help="Query to search within the page",
    prompt="Enter query",
)
@click.option(
    "--url",
    required=True,
    help="URL of the web page to extract from",
    prompt="Enter URL",
)
@click.option(
    "--size",
    default=5,
    help="Maximum number of snippets to return (1-50), default is 5",
    prompt="Enter size (default is 5)",
)
@click.option(
    "--json-schema",
    default="None",
    help="Optional JSON schema for custom extraction",
)
@click.option(
    "--style",
    default="paragraph",
    help="Snippet style: paragraph or sentence (default is paragraph)",
    prompt="Enter snippet style (paragraph or sentence)",
)
@click.option(
    "--search-mode",
    default="auto",
    help="Search mode: auto, balance, self_host (default is auto)",
    prompt="Enter search mode (auto, balance, self_host)",
    type=click.Choice(["auto", "balance", "self_host"]),
)
@click.option(
    "--stream",
    default="false",
    help="Stream the response (default is false)",
    prompt="Enter stream (default is false)",
)
@click.option(
    "--view",
    default="table",
    help="View type: table or json (default is table)",
    prompt="Enter view type (table or json)",
)
@click.pass_context
def snippets_command(ctx, query, url, size, json_schema, style, search_mode, stream, view):
    """
    Extract relevant text snippets from a web page for a given query.

    Example:

    smart-search web snippets --query "list comprehension" --url "https://docs.python.org/3/tutorial/" --size 3
    """
    console = Console()
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        view = _normalize_choice(view, ["table", "json"], "table")
        style = _normalize_choice(style, ["paragraph", "sentence"], "paragraph")

        parsed_schema = _try_parse_json_schema(
            console,
            json_schema,
            invalid_is_fatal=True,
        )

        size = _coerce_bounded_int(size, 5, 1, 50)
        api_url = _get_api_url(ctx)
        client = WebSearchClient(base_url=api_url)

        console.print(
            Panel(
                f"[bold blue]📝 Extracting snippets...[/bold blue]\n"
                f"Query: {query}\n"
                f"URL: {url}\n"
                f"Size: {size}\n"
                f"JSON Schema: {parsed_schema}\n"
                f"Style: {style}\n"
                f"View: {view}",
                title="Web Page Snippets",
                border_style="blue",
            )
        )

        request = GetWebPageSnippetsRequest(
            query=query,
            source=url,
            size=size,
            json_schema=parsed_schema,
            snippet_style=style,
            search_mode=search_mode,
        )

        execute = create_cli_executor(
            client, client.get_web_page_snippets, request, parse_bool(stream), console
        )
        response = _run_executor_or_exit(console, execute)

        if not parsed_schema:
            response["data"] = convert_dict_to_object_based_response(
                response.get("data", []), GetWebPageSnippetsResponse
            )
        else:
            response["data"], response["raw_data"] = convert_dict_to_object_based_response(
                response.get("data", []),
                GetWebPageSnippetsResponse,
                return_fields=("data", "raw_data"),
                raw_data=response.get("raw_data", []),
            )

        if view == "json":
            response["data"] = (
                _serialize_iterable_for_json(response["data"])
                if not parsed_schema
                else _serialize_model_for_json(response["data"])
            )
            _print_json(console, response)
            return

        if "data" in response and response["data"]:
            _render_excerpt_table(
                console,
                f"📝 Snippets for '{query}' from {url}",
                response.get("data", []),
                content_column_label="Content",
                found_label="snippets",
            )
        else:
            _render_no_results_panel(
                console,
                "[yellow]No snippets found.[/yellow]",
                title="Snippet Results",
            )

        if response.get("raw_data"):
            render_raw_data_table(response.get("raw_data"), console)
    except Exception as e:
        _exit_with_error(
            console,
            f"[bold red]❌ Error occurred while extracting snippets[/bold red]\nDetails: {str(e)}",
            title="Error",
        )


@web_group.command(name="keypoints")
@click.option(
    "--query", required=True, help="Query to search for", prompt="Enter query"
)
@click.option(
    "--url",
    required=True,
    help="URL of the web page to extract from",
    prompt="Enter URL",
)
@click.option(
    "--size",
    default=5,
    help="Maximum number of keypoints to return (1-50), default is 5",
    prompt="Enter size (default is 5)",
)
@click.option(
    "--json-schema",
    default="None",
    help="Optional JSON schema for custom extraction",
)
@click.option(
    "--search-mode",
    default="auto",
    help="Search mode to use (auto, balance, self_host), default is auto",
    prompt="Enter search mode (auto, balance, self_host)",
    type=click.Choice(["auto", "balance", "self_host"]),
)
@click.option(
    "--stream",
    default="false",
    help="Stream the response (default is false)",
    prompt="Enter stream (default is false)",
)
@click.option(
    "--view",
    default="table",
    help="View type: table or json (default is table)",
    prompt="Enter view type (table or json)",
)
@click.pass_context
def keypoints_command(ctx, query, url, size, json_schema, search_mode, stream, view):
    """
    Extract concise key points from a web page.

    Example:

    smart-search web keypoints --query "Python features" --url "https://www.python.org/about/" --size 5
    """
    console = Console()
    try:
        health_check(os.getenv("SMARTSEARCH_BASE_URL"))

        view = _normalize_choice(view, ["table", "json"], "table")
        size = _coerce_bounded_int(size, 5, 1, 50)

        parsed_schema = _try_parse_json_schema(
            console,
            json_schema,
            invalid_is_fatal=True,
        )

        api_url = _get_api_url(ctx)
        client = WebSearchClient(base_url=api_url)

        console.print(
            Panel(
                f"[bold blue]🔑 Extracting key points...[/bold blue]\n"
                f"Query: {query}\n"
                f"URL: {url}\n"
                f"JSON Schema: {parsed_schema}\n"
                f"Size: {size}\n"
                f"View: {view}",
                title="Web Page Key Points",
                border_style="blue",
            )
        )

        request = GetWebPageKeypointsRequest(
            query=query,
            source=url,
            size=size,
            json_schema=parsed_schema,
            search_mode=search_mode,
        )

        execute = create_cli_executor(
            client, client.get_web_page_keypoints, request, parse_bool(stream), console
        )
        response = _run_executor_or_exit(console, execute)

        if not parsed_schema:
            response["data"] = convert_dict_to_object_based_response(
                response.get("data", []), GetWebPageKeypointsResponse
            )
        else:
            response["data"], response["raw_data"] = convert_dict_to_object_based_response(
                response.get("data", []),
                GetWebPageKeypointsResponse,
                return_fields=("data", "raw_data"),
                raw_data=response.get("raw_data", []),
            )

        if view == "json":
            response["data"] = (
                _serialize_iterable_for_json(response["data"])
                if not parsed_schema
                else _serialize_model_for_json(response["data"])
            )
            _print_json(console, response)
            return

        if "data" in response and response["data"]:
            _render_excerpt_table(
                console,
                f"🔑 Key Points for '{query}' from {url}",
                response.get("data", []),
                content_column_label="Key Point",
                found_label="key points",
            )
        else:
            _render_no_results_panel(
                console,
                "[yellow]No key points found.[/yellow]",
                title="Key Point Results",
            )

        if response.get("raw_data"):
            render_raw_data_table(response.get("raw_data"), console)
    except Exception as e:
        _exit_with_error(
            console,
            f"[bold red]❌ Error occurred while extracting key points[/bold red]\nDetails: {str(e)}",
            title="Error",
        )


def _parse_bool(value: str) -> bool:
    return value.lower() in ["true", "1", "t", "y", "yes"]


async def _handle_streaming_response(
    client_method: Callable, request: BaseModel, stream_enabled: bool, console: Console
) -> dict[str, any]:
    """
    Helper function to handle both streaming and non-streaming responses.

    Args:
        client_method: The async client method to call
        request: The request object
        stream_enabled: Whether streaming is enabled
        console: Rich console for output

    Returns:
        dict: Complete response (aggregated if streaming, direct if not)
    """
    if stream_enabled:
        console.print("[cyan]📡 Streaming enabled - receiving chunks...[/cyan]\n")
        response = {}
        chunk_count = 0

        # Get the async generator
        stream: AsyncGenerator[BaseModel, None] = await client_method(
            request, stream=True
        )

        # Consume the stream
        async for chunk in stream:
            chunk_count += 1
            if chunk.type and chunk.type == EventType.RESPONSE:
                response["data"] = chunk.value
            elif chunk.value.data_type == SmartSearchEmitDataValue.ACTIVITY:
                console.print(
                    Panel(
                        f"{json.dumps(chunk.value.data_value.model_dump(), indent=4)}",
                        title="Received chunk",
                        border_style="blue",
                    )
                )

        console.print(
            f"\n[green]✓ Streaming complete - received {chunk_count} chunks[/green]\n"
        )

        return response

    return await client_method(request, stream=False)
