"""Main CLI entry point for Smart Search SDK.

Authors:
    Glenn S. Santoso (glenn.s.santoso@gdplabs.id)

References:
    [1] https://github.com/GDP-ADMIN/glaip-sdk/tree/main/python/glaip-sdk/glaip_sdk/cli
"""

import sys
import os
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

import click

from smart_search_sdk.cli.commands.search import search_group
from smart_search_sdk.cli.commands.utils import set_group
from smart_search_sdk.cli.commands.web import web_group
from smart_search_sdk.cli.commands.connector import connector_group
from smart_search_sdk.cli.utils import health_check
from smart_search_sdk.search.client import SmartSearchSearchClient

from dotenv import load_dotenv
from smart_search_sdk.connector.models.schema import GL_CONNECTORS_DEFAULT_CALLBACK_URL
from smart_search_sdk.shared.utils.helper import get_connector_token

try:
    load_dotenv()
except Exception:
    pass


@click.group()
@click.version_option(version="0.1.0", prog_name="smart-search")
@click.pass_context
def main(ctx):
    """Smart Search SDK Command Line Interface.

    A comprehensive CLI for interacting with Smart Search services.
    """
    # Create an empty object to share between commands
    ctx.ensure_object(dict)

    # Skip auth check for help commands or version command
    if ctx.invoked_subcommand in [
        None,
        "set",
        "--help",
        "-h",
        "--version",
        "-v",
        "init",
    ]:
        return

    if (
        not os.getenv("SMARTSEARCH_USER_IDENTIFIER")
        or not os.getenv("SMARTSEARCH_USER_SECRET")
        or not os.getenv("SMARTSEARCH_BASE_URL")
    ):
        console = Console()

        def _get_missing_env_warnings():
            warnings = ""
            error_message_dict = {
                "SMARTSEARCH_USER_IDENTIFIER": "  - [bold]export SMARTSEARCH_USER_IDENTIFIER=YOUR_ID[/bold]\n",
                "SMARTSEARCH_USER_SECRET": "  - [bold]export SMARTSEARCH_USER_SECRET=YOUR_SECRET[/bold]\n",
                "SMARTSEARCH_BASE_URL": "  - [bold]export SMARTSEARCH_BASE_URL=YOUR_BASE_API_URL[/bold]\n",
                "SMARTSEARCH_TOKEN": "  - [bold]export SMARTSEARCH_TOKEN=YOUR_TOKEN[/bold]\n",
                "GL_CONNECTORS_USER_TOKEN": "  - [bold]export GL_CONNECTORS_USER_TOKEN=YOUR_GL_CONNECTORS_USER_TOKEN[/bold]\n",
                "GL_CONNECTORS_DEFAULT_CALLBACK_URL": "  - [bold]export GL_CONNECTORS_DEFAULT_CALLBACK_URL=YOUR_CALLBACK_URL[/bold]\n\n",
            }
            for env_key, env_value in error_message_dict.items():
                if not os.getenv(env_key):
                    warnings += env_value
                    continue
                warnings += "\n"
            return warnings

        console.print(
            Panel(
                "[bold yellow]⚠️ Authentication credentials not found[/bold yellow]\n\n"
                "Before using Smart Search commands, please set your missing credentials:\n"
                f"{_get_missing_env_warnings()}"
                "Or better yet, create an .env file that hosts these variables:\n"
                "[bold]SMARTSEARCH_BASE_URL=YOUR_BASE_API_URL[/bold]\n"
                "[bold]SMARTSEARCH_USER_IDENTIFIER=YOUR_ID[/bold]\n"
                "[bold]SMARTSEARCH_USER_SECRET=YOUR_SECRET[/bold]\n"
                "[bold]SMARTSEARCH_TOKEN=YOUR_TOKEN[/bold]\n"
                "[bold]GL_CONNECTORS_USER_TOKEN=YOUR_GL_CONNECTORS_USER_TOKEN[/bold]\n"
                "[bold]GL_CONNECTORS_DEFAULT_CALLBACK_URL=YOUR_CALLBACK_URL[/bold]\n"
                "[bold yellow]⚠️ Please reach out to Smart Search Team for assistance regarding credentials[/bold yellow]",
                title="Authentication Required",
                border_style="yellow",
            )
        )
        sys.exit(1)


# Add command groups
main.add_command(search_group)
main.add_command(set_group)
main.add_command(web_group)
main.add_command(connector_group)


@main.command()
@click.option("--api-url", help="Smart Search API URL")
@click.pass_context
def status(ctx, api_url):
    """Show connection status and basic info."""
    config = {}
    try:
        console = Console()

        # Load config from context
        context_config = ctx.obj or {}

        # Load environment variables (low priority)
        import os

        env_config = {}
        env_var_map = {
            "SMARTSEARCH_BASE_URL": ("api_url", None),
            "SMARTSEARCH_USER_IDENTIFIER": ("user_identifier", None),
            "SMARTSEARCH_USER_SECRET": ("user_secret", None),
            "SMARTSEARCH_TOKEN": ("token", None),
            "GL_CONNECTORS_DEFAULT_CALLBACK_URL": (
                "gl_connectors_default_callback_url",
                GL_CONNECTORS_DEFAULT_CALLBACK_URL,
            ),
        }
        for env_var, (config_key, default) in env_var_map.items():
            value = os.getenv(env_var, default)
            if value is not None:
                env_config[config_key] = value

        # Get connector token with backward compatibility (GL_CONNECTORS_USER_TOKEN or BOSA_TOKEN)
        connector_token = get_connector_token()
        if connector_token:
            env_config["gl_token"] = connector_token

        # Filter out None values from context config to avoid overriding other configs
        filtered_context = {k: v for k, v in context_config.items() if v is not None}

        # Command-specific parameters (highest priority)
        cmd_config = {}
        if api_url:
            cmd_config["api_url"] = api_url

        # Merge configs: env (low) -> context (mid) -> CLI args (high)
        config = {**env_config, **filtered_context, **cmd_config}

        if not config.get("api_url"):
            console.print(
                Panel(
                    "[bold red]❌ Configuration incomplete[/bold red]\n\n"
                    f"🔍 Current config:\n"
                    f"   • API URL: {config.get('api_url', 'Not set')}\n"
                    f"💡 To fix this:\n"
                    f"   • Set SMARTSEARCH_BASE_URL environment variables\n"
                    f"   • Or provide --api-url arguments",
                    title="❌ Configuration Error",
                    border_style="red",
                )
            )
            sys.exit(1)

        health_check(config["api_url"])

        # Try to create client
        client = SmartSearchSearchClient(
            base_url=config["api_url"],
        )

        # Test connection with a simple API call
        try:
            # Just verify connection works by checking API status
            # We'll create a status table
            table = Table(title="🔗 Smart Search Status")
            table.add_column("Service", style="cyan", width=15)
            table.add_column("Status", style="green", width=15)

            table.add_row("Search API", "✅ Connected")

            console.print(
                Panel(
                    f"[bold green]✅ Connected to Smart Search API[/bold green]\n"
                    f"🔗 API URL: {env_config['api_url']}\n"
                    f"🔗 GL Connectors Token: {env_config['gl_token'][:5]}...{env_config['gl_token'][-5:]}\n"
                    f"🔗 User Identifier: {env_config['user_identifier']}\n"
                    f"🔗 User Secret: {env_config['user_secret'][:13]}...{env_config['user_secret'][-5:]}\n"
                    f"🔗 Token: {env_config['token'][:5]}...{env_config['token'][-5:]}\n",
                    title="🚀 Connection Status",
                    border_style="green",
                )
            )

            console.print(table)

        except Exception as e:
            console.print(
                Panel(
                    f"[bold yellow]⚠️  Connection established but API call failed[/bold yellow]\n"
                    f"🔗 API URL: {client.base_url}\n"
                    f"❌ Error: {e}\n\n"
                    f"💡 This usually means:\n"
                    f"   • Network connectivity issues\n"
                    f"   • API permissions problems\n"
                    f"   • Backend service issues",
                    title="⚠️  Connection Problem",
                    border_style="yellow",
                )
            )

    except Exception as e:
        console.print(
            Panel(
                f"[bold red]❌ Connection failed[/bold red]\n\n"
                f"🔍 Error: {e}\n\n"
                f"💡 Troubleshooting steps:\n"
                f"   • Check your API URL\n"
                f"   • Verify your environment variables\n"
                f"   • Check network connectivity to {config.get('api_url', 'your API')}",
                title="❌ Connection Error",
                border_style="red",
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
