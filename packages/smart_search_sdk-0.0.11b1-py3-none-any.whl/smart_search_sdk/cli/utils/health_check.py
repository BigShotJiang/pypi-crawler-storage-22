import sys
import requests
from rich.console import Console
from rich.panel import Panel

console = Console()


def health_check(api_url):
    if not api_url:
        console.print(
            Panel(
                "[bold red]❌ Missing API URL[/bold red]\n\n"
                "💡 Troubleshooting steps:\n"
                "   • Set SMARTSEARCH_BASE_URL environment variable\n"
                "   • Or provide --api-url parameter",
                title="❌ Configuration Error",
                border_style="red",
            )
        )
        sys.exit(1)

    try:
        response = requests.get(f"{api_url}/health-check", timeout=2)
        response.raise_for_status()
        return True
    except Exception:
        console.print(
            Panel(
                "[bold red]❌ Connection failed[/bold red]\n\n"
                f"💡 Troubleshooting steps:\n"
                f"   • Check your API URL: {api_url}\n"
                f"   • Verify your environment variables\n"
                f"   • Check network connectivity",
                title="❌ Connection Error",
                border_style="red",
            )
        )
        sys.exit(1)
