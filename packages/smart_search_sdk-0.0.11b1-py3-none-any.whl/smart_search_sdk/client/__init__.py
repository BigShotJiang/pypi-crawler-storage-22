"""
Client module for Smart Search SDK.

This module provides the base client classes for interacting with the Smart Search API.
"""

from .client import BaseSmartSearchClient

__all__ = ["BaseSmartSearchClient"]
