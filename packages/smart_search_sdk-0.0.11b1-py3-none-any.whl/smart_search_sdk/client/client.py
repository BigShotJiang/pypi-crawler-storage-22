"""
This module provides a base client for interacting with the SmartSearch API. It includes functionality for authentication
and sending HTTP requests.

Classes:
    BaseSmartSearchClient:
        An abstract base class for interacting with the SmartSearch API. It provides methods for authentication
        and sending HTTP requests.

            base_url (str): The base URL for the SmartSearch API.

Dependencies:
    - abc: Provides the ABC class for defining abstract base classes.
    - os: Provides access to environment variables and file system operations.
    - typing: Provides type hints for function arguments and return values.
    - httpx: Used for sending async HTTP requests to the SmartSearch API.
    - websockets: Used for WebSocket connections.

Environment Variables:
    - SMARTSEARCH_BASE_URL: The base URL for the SmartSearch API.
    - SMARTSEARCH_TOKEN: The authentication token for the SmartSearch API.
    - SMARTSEARCH_USER_IDENTIFIER: The user identifier for authentication.
    - SMARTSEARCH_USER_SECRET: The user secret for authentication.

Authors:
    Ardhian Heru Nugroho (ardhian.h.nugroho@gdplabs.id)
    Glenn Santoso (glenn.s.santoso@gdplabs.id)

References:
    None
"""

import logging
import asyncio
from abc import ABC
import functools
from http import HTTPStatus
import json
import os
import time
from typing import Any, AsyncGenerator
import warnings
from smart_search_sdk.config.constants import EventType, TimeoutEnum
from pydantic import BaseModel
from smart_search_sdk.shared.models.model import (
    StreamChunkDataYield,
    StreamYieldResponse,
)
import websockets

import httpx

STATUS_DONE = "done"
logger = logging.getLogger(__name__)


def deprecated(func):
    """
    A decorator to mark functions as deprecated.
    This decorator emits a `DeprecationWarning` when the decorated function is called,
    indicating that the function is deprecated and will be removed in a future version.

    Args:
        func (Callable): The function to be marked as deprecated.

    Returns:
        Callable: A wrapper function that emits the warning and calls the original function.

    Example:
        @deprecated
        def old_function():
            pass
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        """
        A wrapper function that issues a deprecation warning when the decorated function is called.
        This function is used to mark other functions as deprecated. It will display a warning message
        indicating that the function is deprecated and will be removed in a future version.

        Args:
            *args: Positional arguments passed to the decorated function.
            **kwargs: Keyword arguments passed to the decorated function.

        Returns:
            The result of calling the decorated function with the provided arguments.

        Raises:
            DeprecationWarning: Warns that the decorated function is deprecated.
        """

        warnings.warn(
            f"{func.__name__} is deprecated and will be removed in a future version.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        return func(*args, **kwargs)

    return wrapper


class BaseSmartSearchClient(ABC):
    """
    BaseSmartSearchClient is an abstract base class for interacting with the SmartSearch API.
    It provides async methods for authentication and sending HTTP requests using httpx.

    Attributes:
        base_url (str): The base URL for the SmartSearch API.
        token (str): The authentication token for the SmartSearch API.
        client (httpx.AsyncClient): The async HTTP client instance.

    Methods:
        __init__(base_url: str = ""):
            Initializes the SmartSearch client with the specified base URL.
        async authenticate(token: str = None, user_identifier: str = None, user_secret: str = None):
            Authenticates the client by retrieving or generating an authentication token.
        async send_get_request(endpoint: str, params: dict = None) -> dict:
            Sends an async GET request to the specified API endpoint.
        async send_post_request(endpoint: str, data: dict = None) -> dict:
            Sends an async POST request to the specified API endpoint.
        async send_stream_request(endpoint: str, payload: dict = None) -> AsyncGenerator[dict, None]:
            Sends an async POST request with streaming support (SSE).
        async close():
            Closes the HTTP client connection.
    """

    base_url: str = ""
    token: str = ""
    client: httpx.AsyncClient = None

    def __init__(
        self,
        base_url: str = "",
        timeout: float = 300,
    ):
        """
        Initializes the client with a base URL.

        Args:
            base_url (str, optional): The base URL for the Smart Search API. Defaults to an empty string.
            If not provided, it will attempt to use the environment variable `SMARTSEARCH_BASE_URL`.
        """
        base_url_str = (base_url or os.getenv("SMARTSEARCH_BASE_URL", "")).rstrip("/")
        self.base_url = (
            base_url_str  # Keep for backward compatibility and WebSocket URLs
        )
        self.client = httpx.AsyncClient(base_url=base_url_str, timeout=timeout)

    async def close(self):
        """Close the HTTP client connection."""
        if self.client:
            await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    async def authenticate(
        self, token: str = None, user_identifier: str = None, user_secret: str = None
    ):
        """
        Authenticate the client by validating or generating a token.
        This method attempts to authenticate the client using the provided token,
        user identifier, and user secret. If no token is provided, it retrieves
        the token from the environment variables.

        Args:
            token (str, optional): The authentication token. Defaults to None.
            user_identifier (str, optional): The user identifier for authentication.
                Defaults to None. If not provided, it is retrieved from the
                "SMARTSEARCH_USER_IDENTIFIER" environment variable.
            user_secret (str, optional): The user secret for authentication.
                Defaults to None. If not provided, it is retrieved from the
                "SMARTSEARCH_USER_SECRET" environment variable.

        Returns:
            None
        """

        # Priority 1: If explicit token is provided, use it
        if token:
            self.token = token.rstrip("/")
        else:
            # Priority 2: Get credentials from parameters or environment
            user_identifier = user_identifier or os.getenv(
                "SMARTSEARCH_USER_IDENTIFIER", ""
            )
            user_secret = user_secret or os.getenv("SMARTSEARCH_USER_SECRET", "")

            # If credentials are available, generate token from credentials
            if user_identifier and user_secret:
                token_response = await self.send_post_request(
                    endpoint="token",
                    data={"identifier": user_identifier, "secret": user_secret},
                )
                self.token = token_response.get("token", "")
            else:
                # Priority 3: Use environment token as fallback
                self.token = os.getenv("SMARTSEARCH_TOKEN", "").rstrip("/")

    async def send_get_request(
        self, endpoint: str, params: dict = None, timeout: int = 7200
    ) -> dict:
        """
        Sends a GET request to the specified endpoint with the provided parameters.

        Args:
            endpoint (str): The API endpoint to send the request to.
            params (dict, optional): A dictionary of query parameters to include in the request.
            timeout (int, optional): The maximum time (in seconds) to wait for a response. Defaults to 7200 seconds.

        Returns:
            dict: The JSON response from the API.

        Raises:
            HTTPError: If the API request fails with an HTTP error.
        """
        headers = {
            "Authorization": f"Bearer {self.token}" if self.token else "",
            "Content-Type": "application/json",
        }
        response = await self.client.get(
            endpoint.lstrip("/"), headers=headers, params=params or {}, timeout=timeout
        )
        response.raise_for_status()
        return response.json()

    def _prepare_form_data(self, data: dict) -> dict:
        """Prepare data for form submission by serializing dict/list fields to JSON strings.

        This method handles the conversion of complex Python data types (dicts and lists)
        to JSON strings for proper Form data encoding. This is necessary because Form data
        (application/x-www-form-urlencoded) expects all values to be strings.

        Args:
            data: Dictionary of form fields

        Returns:
            Dictionary with complex types serialized to JSON strings
        """
        prepared = {}
        for key, value in data.items():
            if value is None:
                continue
            elif isinstance(value, dict):
                prepared[key] = json.dumps(value)
            else:
                prepared[key] = value
        return prepared

    async def send_post_request(
        self,
        endpoint: str,
        data: dict = None,
        timeout: int = 7200,
        headers: dict = None,
    ) -> dict:
        """
        Sends a POST request to the specified endpoint with the provided JSON body.

        Args:
            endpoint (str): The API endpoint to send the request to.
            data (dict, optional): A dictionary to include in the request body as form data.
            timeout (int, optional): The maximum time (in seconds) to wait for a response. Defaults to 7200 seconds.
            headers (dict, optional): Additional headers to include in the request.

        Returns:
            dict: The JSON response from the API.

        Raises:
            HTTPError: If the API request fails with an HTTP error.
        """
        request_headers = {
            "Authorization": f"Bearer {self.token}" if self.token else "",
            "Content-Type": "application/x-www-form-urlencoded",
            **(headers or {}),
        }
        prepared_data = self._prepare_form_data(data or {})
        response = await self.client.post(
            endpoint.lstrip("/"),
            headers=request_headers,
            data=prepared_data,
            timeout=timeout,
        )
        response.raise_for_status()
        return response.json()

    async def send_ws_request(
        self,
        endpoint: str,
        stream_output: Any,
        payload: dict = None,
        total_timeout: int = 7200,
        response_timeout: int = 1000,
    ):  # pragma: no cover
        """
        Sends a WebSocket request to a specified endpoint and streams the response.

        Args:
            endpoint (str): The WebSocket endpoint to connect to.
            stream_output (Any): An asynchronous stream-like object to send responses to.
            payload (dict, optional): The payload to send as a JSON object. Defaults to None.
            total_timeout (int, optional): The maximum time (in seconds) to keep the WebSocket connection open. Defaults to 30.
            response_timeout (int, optional): The maximum time (in seconds) to wait for a single response. Defaults to 10.

        Raises:
            asyncio.TimeoutError: If the total timeout or response timeout is exceeded.
            websockets.exceptions.ConnectionClosedOK: If the WebSocket connection is closed normally.
            Exception: For any other errors encountered during communication.

        Returns:
            dict: The parsed JSON response if the "status" field equals `STATUS_DONE`.
            None: If the WebSocket connection is closed without a `STATUS_DONE` response.
        """

        url = f"{self.base_url.replace('http', 'ws')}/{endpoint.lstrip('/')}"
        headers = {
            "Authorization": f"Bearer {self.token}" if self.token else "",
        }
        async with websockets.connect(
            url, additional_headers=headers, ping_interval=None
        ) as websocket:
            if payload:
                await websocket.send(json.dumps(payload))
            start_time = time.monotonic()
            while True:
                if (time.monotonic() - start_time) >= total_timeout:
                    raise asyncio.TimeoutError("Total WebSocket timeout exceeded")

                try:
                    response = await asyncio.wait_for(
                        websocket.recv(), timeout=response_timeout
                    )
                    await stream_output.send(response)

                    try:
                        parsed = json.loads(response)
                        if parsed.get("status") == STATUS_DONE:
                            return parsed
                    except json.JSONDecodeError:
                        pass

                except asyncio.TimeoutError:
                    raise asyncio.TimeoutError("Response wait timeout exceeded")

                except websockets.exceptions.ConnectionClosedOK:
                    return

                except Exception:
                    return

    async def send_get_with_sst_request(
        self, endpoint: str, params: dict = None, timeout: int = 7200
    ) -> dict:
        """
        Sends a GET request to the specified endpoint with an SST token included in the query parameters.

        Args:
            endpoint (str): The API endpoint to send the GET request to.
            params (dict, optional): Dictionary of query parameters to include in the request. Defaults to None.
            timeout (int, optional): Timeout for the request in seconds. Defaults to 7200.

        Returns:
            dict: The JSON response from the server.

        Raises:
            HTTPError: If the HTTP request returned an unsuccessful status code.
        """
        headers = {
            "Content-Type": "application/json",
        }
        if params is None:
            params = {}
        params["sst"] = self.token if self.token else ""
        response = await self.client.get(
            endpoint.lstrip("/"), headers=headers, params=params, timeout=timeout
        )
        response.raise_for_status()
        return response.json()

    def _parse_stream_chunk(self, chunk_text: str) -> dict | None:
        """Parse a stream chunk into JSON.

        Args:
            chunk_text: Raw chunk text to parse

        Returns:
            Parsed JSON dict or None if parsing fails
        """
        try:
            clean_text = (
                chunk_text.removeprefix("data:")
                if chunk_text.startswith("data:")
                else chunk_text
            )

            if "value" not in clean_text:
                return None

            return json.loads(clean_text)
        except json.JSONDecodeError:
            return None

    def _parse_nested_json_value(self, raw_json: dict) -> dict:
        """Parse nested JSON value if it's a string.

        Args:
            raw_json: Raw JSON dict that may contain nested JSON string

        Returns:
            JSON dict with parsed nested value
        """
        if isinstance(raw_json.get("value"), str):
            try:
                raw_json["value"] = json.loads(raw_json["value"])
            except json.JSONDecodeError:
                pass  # Keep original value if parsing fails
        return raw_json

    def _create_data_response(self, raw_json: dict) -> StreamYieldResponse:
        """Create StreamYieldResponse for DATA event type.

        Args:
            raw_json: Parsed JSON dict

        Returns:
            StreamYieldResponse with StreamChunkDataYield value
        """
        return StreamYieldResponse[StreamChunkDataYield](**raw_json)

    def _create_response_type(
        self, raw_json: dict, model: type[BaseModel]
    ) -> StreamYieldResponse:
        """Create StreamYieldResponse for RESPONSE event type.

        Args:
            raw_json: Parsed JSON dict
            model: Pydantic model type for the response

        Returns:
            StreamYieldResponse with wrapped value
        """
        value = self._extract_response_value_with_model(raw_json, model)

        return StreamYieldResponse[model](
            level=raw_json.get("level"),
            type=raw_json.get("type"),
            timestamp=raw_json.get("timestamp"),
            metadata=raw_json.get("metadata", {}),
            value=value,
        )

    def _extract_response_value_with_model(
        self, raw_json: dict, model: type[BaseModel]
    ) -> dict[str, any]:
        """
        Extract and transform the value from a RESPONSE event based on the model structure.

        Args:
            raw_json: Parsed JSON dict from the stream
            model: Pydantic model type for the response

        Returns:
            Transformed value suitable for the model
        """
        raw_value = raw_json["value"]

        model_fields = model.model_fields if hasattr(model, "model_fields") else {}
        has_data_field = "data" in model_fields

        if has_data_field and isinstance(raw_value, list):
            return {"data": raw_value}
        return raw_value

    def _process_stream_event(
        self, raw_json: dict, model: type[BaseModel]
    ) -> StreamYieldResponse | dict:
        """Process stream event based on event type.

        Args:
            raw_json: Parsed JSON dict
            model: Optional Pydantic model type for RESPONSE events

        Returns:
            Appropriate response object based on event type
        """
        event_type = raw_json.get("type")

        if event_type == EventType.DATA:
            return self._create_data_response(raw_json)
        elif event_type == EventType.RESPONSE and model:
            return self._create_response_type(raw_json, model)
        return raw_json

    async def send_stream_request(
        self,
        endpoint: str,
        model: type[BaseModel],
        payload: dict[str, Any],
        headers: dict[str, Any] = {},
        timeout: float = TimeoutEnum.SIMPLE_PROCESS_TIMEOUT.value,
    ) -> AsyncGenerator[StreamYieldResponse | dict, None]:
        """
        Sends a POST request with text/event-stream support and yields parsed events.

        Args:
            endpoint (str): The API endpoint to send the request to.
            data (dict, optional): A dictionary to include in the request body. Defaults to None.
            model (type[BaseModel], optional): Pydantic model type for RESPONSE events. Defaults to None.
            timeout (float, optional): The maximum time (in seconds) to wait for a response. Defaults to 30 seconds.

        Yields:
            BaseModel: Parsed event data from the stream.

        Raises:
            Exception: If the API request fails with an HTTP error.
        """
        headers = {
            "Accept": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Authorization": f"Bearer {self.token}" if self.token else "",
            **headers,
        }
        prepared_data = self._prepare_form_data(payload or {})

        async with httpx.AsyncClient(base_url=self.base_url, timeout=timeout) as client:
            async with client.stream(
                "POST",
                endpoint.lstrip("/"),
                data=prepared_data,
                headers=headers,
                timeout=timeout,
            ) as response:
                if response.status_code != HTTPStatus.OK:
                    error_text = await response.aread()
                    raise Exception(
                        f"Error: {response.status_code} - {error_text.decode('utf-8')}"
                    )

                buffer = ""  # Add buffer for incomplete chunks

                async for chunk in response.aiter_bytes():
                    if not chunk:
                        continue

                    try:
                        buffer += chunk.decode("utf-8")
                    except UnicodeDecodeError:
                        continue

                    # Process all complete events in buffer
                    while "\n\n" in buffer:
                        event_text, buffer = buffer.split("\n\n", 1)

                        raw_json = self._parse_stream_chunk(event_text)
                        if not raw_json:
                            logger.debug(f"Skipping incomplete event: {event_text}")
                            continue

                        try:
                            raw_json = self._parse_nested_json_value(raw_json)
                            processed_event = self._process_stream_event(
                                raw_json, model
                            )
                            yield processed_event

                        except KeyError as e:
                            logger.warning(f"KeyError processing stream event: {e}")
                            continue
                        except Exception as e:
                            logger.warning(
                                f"Unexpected error processing stream event: {e}"
                            )
                            continue

                # Process any remaining data in buffer
                stripped_buffer = buffer.strip()
                raw_json = self._parse_stream_chunk(stripped_buffer)
                if raw_json:
                    try:
                        raw_json = self._parse_nested_json_value(raw_json)
                        processed_event = self._process_stream_event(raw_json, model)
                        yield processed_event
                    except Exception as e:
                        logger.warning(f"Error processing final buffer: {e}")
