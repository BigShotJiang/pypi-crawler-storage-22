from smart_search_sdk.deep_research.enum import ResearchType
from enum import Enum, StrEnum

VERSION_0_1_0 = "0.1.0"
DEFAULT_VERSION = VERSION_0_1_0

DEEP_RESEARCH_ENDPOINTS = {
    VERSION_0_1_0: {
        ResearchType.POST_SONAR: "/sonar/research",
        ResearchType.WS_SONAR: "/sonar/research",
        ResearchType.POST_ASSAFELOVIC: "/assafelovic/research",
        ResearchType.WS_ASSAFELOVIC: "/assafelovic/generate_report",
        ResearchType.POST_ASSAFELOVIC_EVENT_STREAM: "/assafelovic/generate_report",
    }
}


class SmartSearchEmitDataValue(StrEnum):
    ACTIVITY = "activity"


class EventType(StrEnum):
    """Defines event types for the event emitter module."""

    ACTIVITY = "activity"
    CODE = "code"
    DATA = "data"
    REFERENCE = "reference"
    RESPONSE = "response"
    STATUS = "status"
    THINKING = "thinking"


class TimeoutEnum(Enum):
    COMPLEX_PROCESS_TIMEOUT: float = 300
    SIMPLE_PROCESS_TIMEOUT: float = 30
