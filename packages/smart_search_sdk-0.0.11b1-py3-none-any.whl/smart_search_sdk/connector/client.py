"""
Authors:
    Michael Hans (michael.hans@gdplabs.id)

References:
    None
"""

from typing import AsyncGenerator
from smart_search_sdk.client.client import BaseSmartSearchClient
from smart_search_sdk.config.constants import TimeoutEnum
from smart_search_sdk.connector.models import (
    ConnectorRequest,
    ConnectorConnectRequest,
    AppName,
)
from smart_search_sdk.connector.models.schema import ConnectorResponse
from smart_search_sdk.shared.models.model import StreamYieldResponse
from smart_search_sdk.shared.utils.helper import (
    build_connector_headers,
)


class ConnectorClient(BaseSmartSearchClient):
    """
    A client for interacting with the Connector service.

    This client provides methods to connect, disconnect and search connectors.

    Methods:
        connect_connector(app_name: AppName, gl_token: str | None = None, request: ConnectorConnectRequest, *, bosa_token: str | None = None) -> dict:
            Initiate integration with a third-party connector for the specified app.

        disconnect_connector(app_name: AppName, gl_token: str | None = None, *, bosa_token: str | None = None) -> dict:
            Remove integration with a third-party connector for the specified app.

        search_connector(app_name: AppName, gl_token: str | None = None, request: ConnectorRequest, stream: bool = False, *, bosa_token: str | None = None) -> dict:
            Searches a connector for the specified app.
    """

    async def connect_connector(
        self,
        app_name: AppName,
        gl_token: str | None = None,
        request: ConnectorConnectRequest | None = None,
        *,
        bosa_token: str | None = None,
    ) -> dict:
        """
        Initiate integration with a third-party connector for the specified app.

        This endpoint authenticates the user and delegates the connection process to the service layer.
        If integration is required, a setup URL may be returned.

        Credential Logic:
        - If 'gl-token' header is provided → Service uses GLCHAT_GL_CONNECTORS_API_KEY + provided token
        - If no 'gl-token' header → Service uses Smart Search's internal GL Connectors credentials

        Args:
            app_name (AgentType): The name of the app to connect to (e.g., github, gdrive).
            gl_token: Optional GL Connectors token (new naming, preferred).
            bosa_token: Optional BOSA token (old naming, for backward compatibility).
            request: Connection request containing callback URL (as form data).

        Returns:
            ConnectorMessageResponse: Information about the integration status or setup instructions.
        """
        # Normalize token with backward compatibility (prefer gl_token over bosa_token)
        # Don't check environment variables - use what's provided directly
        token = gl_token if gl_token else bosa_token
        headers = build_connector_headers(token)
        response = await self.send_post_request(
            endpoint=f"/v2/connector/{app_name}/connect",
            headers=headers,
            data=request.model_dump(mode="json"),
        )
        return response

    async def disconnect_connector(
        self,
        app_name: AppName,
        gl_token: str | None = None,
        *,
        bosa_token: str | None = None,
    ) -> dict:
        """
        Remove integration with a third-party connector for the specified app.

        This endpoint authenticates the user and delegates the disconnection process to the service layer.

        Credential Logic:
        - If 'gl-token' header is provided → Service uses GLCHAT_GL_CONNECTORS_API_KEY + provided token
        - If no 'gl-token' header → Service uses Smart Search's internal GL Connectors credentials

        Args:
            app_name (AppName): The name of the app to disconnect from (e.g., github, gdrive).
            gl_token: Optional GL Connectors token (new naming, preferred).
            bosa_token: Optional BOSA token (old naming, for backward compatibility).

        Returns:
            dict: Confirmation of disconnection or relevant status message.
        """
        # Normalize token with backward compatibility (prefer gl_token over bosa_token)
        # Don't check environment variables - use what's provided directly
        token = gl_token if gl_token else bosa_token
        headers = build_connector_headers(token)
        response = await self.send_post_request(
            endpoint=f"/v2/connector/{app_name}/disconnect",
            headers=headers,
        )
        return response

    async def search_connector(
        self,
        app_name: AppName,
        gl_token: str | None = None,
        request: ConnectorRequest | None = None,
        stream: bool = False,
        timeout: float = TimeoutEnum.SIMPLE_PROCESS_TIMEOUT.value,
        *,
        bosa_token: str | None = None,
    ) -> dict | AsyncGenerator[StreamYieldResponse | dict, None]:
        """
        Searches a connector for the specified app.

        This endpoint authenticates the user and delegates the search process to the service layer.

        Credential Logic:
        - If 'gl-token' header is provided → Service uses GLCHAT_GL_CONNECTORS_API_KEY + provided token
        - If no 'gl-token' header → Service uses Smart Search's internal GL Connectors credentials

        Args:
            app_name (AppName): The name of the app to search (e.g., github, gdrive).
            gl_token: Optional GL Connectors token (new naming, preferred).
            bosa_token: Optional BOSA token (old naming, for backward compatibility).
            request: Search request containing the natural language query (as form data).

        Returns:
            dict: The search results.
        """
        # Normalize token with backward compatibility (prefer gl_token over bosa_token)
        # Don't check environment variables - use what's provided directly
        token = gl_token if gl_token else bosa_token
        headers = build_connector_headers(token)
        payload = request.model_dump(mode="json")
        if stream:
            payload["stream"] = stream
            return self.send_stream_request(
                endpoint=f"/v2/connector/{app_name}/search",
                headers=headers,
                model=ConnectorResponse,
                payload=payload,
                timeout=timeout,
            )
        else:
            response: dict = await self.send_post_request(
                endpoint=f"/v2/connector/{app_name}/search",
                headers=headers,
                data=payload,
            )
            return response
