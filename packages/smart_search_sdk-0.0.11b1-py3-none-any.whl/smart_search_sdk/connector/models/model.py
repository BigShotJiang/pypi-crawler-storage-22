"""
Module: model

Description:
    Defines models for connector operations.

Author:
    Michael Hans (michael.hans@gdplabs.id)
"""

from enum import StrEnum


class AppName(StrEnum):
    """
    Enumeration of available app names.

    Defines the supported app names that can be used with the Connector service.
    Each value corresponds to a specific app name.
    """

    GITHUB = "github"
    GOOGLE_MAIL = "google_mail"
    GOOGLE_CALENDAR = "google_calendar"
    GOOGLE_DRIVE = "google_drive"
    CHIEF_RETRIEVAL = "chief_retrieval"
