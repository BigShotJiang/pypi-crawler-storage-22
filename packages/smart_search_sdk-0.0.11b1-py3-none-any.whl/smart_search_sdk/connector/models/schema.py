"""
Module: schema

Description:
    Defines request and response models for connector tools that retrieve items from third-party services
    (e.g., GitHub, Google Drive, Google Calendar, Gmail) using natural language queries.

Classes:
    - ConnectorRequest: Request model for connector queries.
    - ConnectorResponse: Response model containing retrieved chunks.
    - ConnectorConnectRequest: Request model for connector connect operations.
    - ConnectorMessageResponse: Response model for connector operations (connect/disconnect).

Author:
    Michael Hans (michael.hans@gdplabs.id)
"""

from pydantic import BaseModel, Field
from smart_search_sdk.shared.models import ChunkCollectionResponse
from typing import Literal
from pydantic import ConfigDict

GL_CONNECTORS_DEFAULT_CALLBACK_URL = "https://search-api.gdplabs.id/health-check"


class ConnectorRequest(BaseModel):
    """
    Generic connector request for retrieving items from a third-party service using a natural language query.

    This model is used for all GL Connectors connector tools (GitHub, Google Drive, Google Calendar, Gmail, etc.).
    """

    query: str = Field(
        ...,
        description=("A natural language query describing what you want to find."),
        examples=[
            "Find open issues about authentication",
            "List PRs fixing bug #123",
            "Show repositories about machine learning",
            "Find documents about Q2 financials",
            "Find meetings with Alice next week",
            "Find emails from Bob about the contract",
        ],
    )


class ConnectorResponse(ChunkCollectionResponse):
    """
    A list of chunks from a connector retrieval query, containing items such as issues, pull requests, documents, events, or emails.

    The returned data depends on the connector and the query.
    """


class ConnectorConnectRequest(BaseModel):
    """
    Request model for connector connect operations.

    This model defines the structure of the request payload for connecting to a connector.
    It supports both JSON and form-data input.

    Attributes:
        callback_url (str): OAuth callback URL where user will be redirected after authentication.
                           Defaults to GL_CONNECTORS_DEFAULT_CALLBACK_URL from environment.
    """

    callback_url: str = GL_CONNECTORS_DEFAULT_CALLBACK_URL


class ConnectorMessageResponse(BaseModel):
    """
    Response model for connector operations (connect/disconnect).
    """

    message: str = Field(..., description="Status message for the operation")
    setup_url: str | None = Field(
        None, description="Setup URL if integration setup is required"
    )
    status: Literal["connected", "disconnected", "setup_required"] = Field(
        ..., description="Current status of the connector"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "message": "Successfully connected to GitHub",
                    "setup_url": None,
                    "status": "connected",
                },
                {
                    "message": "Please visit the following URL to set up the GL Connectors integration for GitHub: https://github.com/login/oauth/authorize?client_id=...",
                    "setup_url": "https://github.com/login/oauth/authorize?client_id=...",
                    "status": "setup_required",
                },
                {
                    "message": "Successfully disconnected from GitHub",
                    "setup_url": None,
                    "status": "disconnected",
                },
            ]
        }
    )
