"""
Client module for performing deep research requests using various methods.

This module defines input models and a client class for handling different types of deep research
requests, including POST and WebSocket-based methods for "Sonar" and "Assafelovic" research types.

Classes:
    PostSonarInput (BaseModel): Input model for POST Sonar research requests.
    WSSonarInput (BaseModel): Input model for WebSocket Sonar research requests.
    PostAssafelovicInput (BaseModel): Input model for POST Assafelovic research requests.
    WSAssafelovicInput (BaseModel): Input model for WebSocket Assafelovic research requests.
    SmartSearchDeepResearchClient (BaseSmartSearchClient): Client for performing deep research.

Functions:
    SmartSearchDeepResearchClient.deep_research(input_data: dict) -> dict:
        Perform deep research based on the input data, dispatching to the appropriate
        research method (POST or WebSocket) and returning the response.

Authors:
    Ardhian Heru Nugroho (ardhian.h.nugroho@gdplabs.id)
    Vilia Susanti (vilia.susanti@gdplabs.id)

References:
    None
"""

from pydantic import BaseModel, TypeAdapter
from typing import Any, ClassVar, Literal, Union
from urllib.parse import urlencode


from smart_search_sdk.config.constants import (
    DEEP_RESEARCH_ENDPOINTS,
    DEFAULT_VERSION,
)
from smart_search_sdk.client.client import BaseSmartSearchClient
from smart_search_sdk.deep_research.enum import ResearchType


class BaseResearchInput(BaseModel):
    """Base class for research input models."""

    query: str


class PostSonarInput(BaseResearchInput):
    """Input model for POST Sonar research type."""

    type: Literal[ResearchType.POST_SONAR]


class WSSonarInput(BaseResearchInput):
    """Input model for WebSocket Sonar research type."""

    type: Literal[ResearchType.WS_SONAR]
    websocket: Any


class BaseAssafelovicInput(BaseResearchInput):
    """Base class for Assafelovic research input models."""

    TYPE_FIELD: ClassVar[str] = "type"

    smart_llm: str | None = "openai:gpt-4o-mini"
    strategic_llm: str | None = "openai:gpt-4o-mini"
    smart_token_limit: int | None = 4000
    strategic_token_limit: int | None = 4000
    report_type: str | None = None
    tone: str | None = None


class PostAssafelovicInput(BaseAssafelovicInput):
    """Input model for POST Assafelovic research type."""

    type: Literal[ResearchType.POST_ASSAFELOVIC]


class WSAssafelovicInput(BaseAssafelovicInput):
    """Input model for WebSocket Assafelovic research type."""

    type: Literal[ResearchType.WS_ASSAFELOVIC]
    websocket: Any


class PostAssafelovicEventStreamInput(BaseAssafelovicInput):
    """Input model for POST Assafelovic event stream research type."""

    type: Literal[ResearchType.POST_ASSAFELOVIC_EVENT_STREAM]


ResearchInput = Union[
    PostSonarInput,
    WSSonarInput,
    PostAssafelovicInput,
    WSAssafelovicInput,
    PostAssafelovicEventStreamInput,
]

adapter = TypeAdapter(ResearchInput)


class SmartSearchDeepResearchClient(BaseSmartSearchClient):
    """Client for performing deep research operations.

    This client supports multiple research types including Sonar and Assafelovic
    implementations, with both synchronous and asynchronous (WebSocket) interfaces.
    """

    endpoints: ClassVar[dict[ResearchType, str]]

    def __init__(
        self,
        base_url: str = "",
        version: str = DEFAULT_VERSION,
    ):
        """Initialize the SmartSearchDeepResearchClient.
        Args:
            base_url: Base URL for the deep research service.
            version: Version of the deep research API to use.
        """
        super().__init__(base_url=base_url)
        if not version:
            version = DEFAULT_VERSION
        self.endpoints = DEEP_RESEARCH_ENDPOINTS.get(version, {})
        if not self.endpoints:
            raise ValueError(f"Unsupported version: {version}")

    def _build_assafelovic_payload(self, input_data: dict) -> dict:
        """Build the payload for the Assafelovic research type.

        Args:
            input_data: Dictionary containing research parameters and type.
        """
        return input_data

    async def deep_research(self, input_data: dict) -> dict:
        """Perform deep research based on the provided input data.

        Args:
            input_data: Dictionary containing research parameters and type.

        Returns:
            dict: Research results.

        Raises:
            ValueError: If the research type is not supported.
        """
        parsed = adapter.validate_python(input_data)

        match parsed:
            case PostSonarInput():
                return await self.send_post_request(
                    endpoint=self.endpoints[ResearchType.POST_SONAR],
                    data={"query": parsed.query},
                )

            case WSSonarInput():
                query_params = {"query": parsed.query}
                url = (
                    f"{self.endpoints[ResearchType.WS_SONAR]}?{urlencode(query_params)}"
                )
                return await self.send_ws_request(
                    endpoint=url,
                    stream_output=parsed.websocket,
                )

            case PostAssafelovicInput():
                payload = parsed.model_dump(exclude_none=True)
                return await self.send_post_request(
                    endpoint=self.endpoints[ResearchType.POST_ASSAFELOVIC],
                    data=payload,
                )

            case WSAssafelovicInput():
                query_params = {"query": parsed.query}
                url = f"{self.endpoints[ResearchType.WS_ASSAFELOVIC]}?{urlencode(query_params)}"
                return await self.send_ws_request(
                    endpoint=url,
                    stream_output=parsed.websocket,
                )

            case PostAssafelovicEventStreamInput():
                payload = parsed.model_dump(exclude_none=True)
                payload.pop(BaseAssafelovicInput.TYPE_FIELD, None)
                return await self.send_post_request(
                    endpoint=self.endpoints[ResearchType.POST_ASSAFELOVIC_EVENT_STREAM],
                    data=payload,
                )

            case _:
                raise ValueError(f"Unsupported research type: {parsed.type}")
