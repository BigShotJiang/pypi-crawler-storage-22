from enum import Enum


class ResearchType(Enum):
    """Enum for different types of research requests."""

    POST_ASSAFELOVIC = "post_assafelovic"
    WS_ASSAFELOVIC = "ws_assafelovic"
    POST_SONAR = "post_sonar"
    WS_SONAR = "ws_sonar"
    POST_ASSAFELOVIC_EVENT_STREAM = "post_assafelovic_event_stream"
