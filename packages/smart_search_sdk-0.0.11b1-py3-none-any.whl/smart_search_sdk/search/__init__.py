"""
Search module for Smart Search SDK.

This module provides search functionality for the Smart Search API.
"""

from .client import SmartSearchSearchClient, SmartSearchKeyPointsRequest

__all__ = ["SmartSearchSearchClient", "SmartSearchKeyPointsRequest"]
