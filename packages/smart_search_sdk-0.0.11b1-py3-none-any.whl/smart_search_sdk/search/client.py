"""
Authors:
    Ardhian Heru Nugroho (ardhian.h.nugroho@gdplabs.id)
    Glenn S. Santoso (glenn.s.santoso@gdplabs.id)

References:
    None
"""

from pydantic import BaseModel
from typing import List

from smart_search_sdk.client.client import BaseSmartSearchClient
from smart_search_sdk.shared.utils.helper import (
    get_connector_token,
    build_connector_headers,
)


class SmartSearchKeyPointsRequest(BaseModel):
    """Request model for smart search key points resource."""

    query: str
    search_profile_names: List[str]
    size: int = 5


class SmartSearchSearchClient(BaseSmartSearchClient):
    """
    A client for interacting with the Smart Search service.

    Methods:
        search(search_profile_names: str, query: str, size: int = 20, params: dict = {}) -> dict:
            Perform a search operation using the Smart Search service.

            Args:
                search_profile_names (str): The profile names identifying the search source.
                query (str): The search query string.
                size (int, optional): The maximum number of results to return. Defaults to 20.
                params (dict, optional): Additional parameters for the search request. Defaults to an empty dictionary.

            Returns:
                dict: The response from the Smart Search service containing the search results.
    """

    async def search(self, request: SmartSearchKeyPointsRequest) -> dict:
        """
        Perform a search operation using the specified profile names and query.

        Args:
            search_profile_names (str): The profile names identifying the search source.
            query (str): The search query string.
            size (int, optional): The maximum number of results to return. Defaults to 20.
            params (dict, optional): Additional parameters for the search operation. Defaults to an empty dictionary.

        Returns:
            dict: The response from the search operation, typically containing search results and metadata.
        """

        # Get token with backward compatibility (GL_CONNECTORS_USER_TOKEN or BOSA_TOKEN)
        token = get_connector_token()
        headers = build_connector_headers(token)

        response = await self.send_post_request(
            endpoint="/v1/search/key-points",
            data=request.model_dump(),
            headers=headers,
        )
        return response

    async def deep_search(self, query: str) -> dict:
        """
        Performs a deep search using the provided query string.
        Sends a GET request to the "/search" endpoint with the specified query parameter,
        and returns the response as a dictionary.

        Args:
            query (str): The search query string.

        Returns:
            dict: The response from the search endpoint.
        """
        response = await self.send_get_with_sst_request(
            endpoint="/search",
            params={"query": query},
        )
        return response
