from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field
from typing import TypeVar, Generic

T = TypeVar("T")


class StreamYieldResponse(BaseModel, Generic[T]):
    value: T = Field(..., description="Value")
    level: str = Field(..., description="Level")
    type: str = Field(..., description="Type")
    timestamp: datetime = Field(..., description="Timestamp")
    metadata: dict = Field(..., description="Metadata")

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "value": "item1",
                    "level": "info",
                    "type": "chunk",
                    "timestamp": "2024-01-01T10:00:00Z",
                    "metadata": {},
                }
            ]
        }
    )


class DataValueChunk(BaseModel):
    message: str | None = Field(None, description="Message")
    url: str | None = Field(None, description="URL")
    query: str | None = Field(None, description="Query")
    type: str = Field(..., description="Type")

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "message": "item1",
                    "url": "https://example.com/article1",
                    "query": "item2",
                    "type": "chunk",
                }
            ]
        }
    )


class StreamChunkDataYield(BaseModel):
    id: str
    data_type: str
    data_value: DataValueChunk

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "id": "chunk-001",
                    "data_type": "chunk",
                    "data_value": {
                        "message": "item1",
                        "url": "https://example.com/article1",
                        "query": "item2",
                        "type": "chunk",
                    },
                }
            ]
        }
    )
