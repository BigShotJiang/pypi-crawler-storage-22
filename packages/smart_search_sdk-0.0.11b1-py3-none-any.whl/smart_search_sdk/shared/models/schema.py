"""
Module: schema

Description:
    Defines shared models used across multiple tools.

Classes:
    - ChunkMetadata:
        Metadata of a chunk.
    - Chunk:
        A chunk.

Author:
    Glenn Steven Santoso (glenn.s.santoso@gdplabs.id)

References:
    None
"""

from datetime import datetime
from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field, AnyHttpUrl

# Generic type for collection items
T = TypeVar("T")

CHUNK_METADATA_EXAMPLE = {
    "source": "https://example.com/returns",
    "source_type": "web",
    "title": "Return Policy",
    "file_id": None,
    "created_at": "2024-01-01T10:00:00Z",
    "updated_at": "2024-01-01T10:00:00Z",
}

CHUNK_EXAMPLE = {
    "id": "chunk-001",
    "content": "This is a snippet from the search results explaining the refund window.",
    "metadata": CHUNK_METADATA_EXAMPLE,
    "confidence_score": 0.88,
}


# ---------------------------
# Shared Models (used in multiple tools)
# ---------------------------
class ChunkMetadata(BaseModel):
    """
    Metadata of a chunk.
    """

    source: str | None = Field(None, description="Source URL or identifier")
    source_type: str | None = Field(
        None, description="Type of source (web, internal, etc.)"
    )
    title: str | None = Field(None, description="Title of the content")
    file_id: str | None = Field(None, description="File identifier if applicable")
    created_at: datetime | None = Field(None, description="Creation timestamp")
    updated_at: datetime | None = Field(None, description="Last update timestamp")

    model_config = ConfigDict(json_schema_extra={"examples": [CHUNK_METADATA_EXAMPLE]})


class Chunk(BaseModel):
    """
    A chunk.
    """

    id: str = Field(..., description="Chunk identifier")
    content: str = Field(description="Text fragments, can be snippets / key points")
    metadata: ChunkMetadata = Field(..., description="Metadata of the chunk")
    confidence_score: float | None = Field(
        None, ge=0.0, le=1.0, description="Relevance score in [0,1]"
    )

    model_config = ConfigDict(json_schema_extra={"examples": [CHUNK_EXAMPLE]})


# ---------------------------
# Generic Collection Response Models
# ---------------------------
class CollectionResponse(BaseModel, Generic[T]):
    """
    Generic collection response model for any type of data.

    This eliminates the need for repetitive list[Type] patterns
    and provides a consistent structure across all collection endpoints.
    """

    data: list[T] = Field(..., description="Collection of items")

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "data": [],
                }
            ]
        }
    )


# ---------------------------
# Specific Collection Response Models
# ---------------------------
class ChunkCollectionResponse(CollectionResponse[Chunk]):
    """
    Collection response specifically for Chunk items.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "data": [CHUNK_EXAMPLE],
                }
            ]
        }
    )


class StringCollectionResponse(CollectionResponse[str]):
    """
    Collection response specifically for string items (suggestions, shingles, etc.).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "data": ["item1", "item2", "item3"],
                }
            ]
        }
    )


class UrlCollectionResponse(CollectionResponse[AnyHttpUrl]):
    """
    Collection response specifically for URL items from web search.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "data": [
                        "https://example.com/article1",
                        "https://example.com/guide",
                        "https://example.com/tutorial",
                    ],
                }
            ]
        }
    )
