import os
from pydantic import BaseModel
from typing import TypeVar

T = TypeVar("T")


def convert_dict_to_object_based_response(
    response: list | BaseModel | dict,
    model: type[T],
    return_fields: tuple[str, ...] = ("data",),
    return_model_only: bool = False,
    **kwargs,
) -> T | tuple[T, ...]:
    """
    Convert a dict/list response to an object-based response model.

    Args:
        response: The response data (list, dict, or BaseModel)
        model: The model class to convert to
        return_fields: Tuple of field names to return from the model.
                      Defaults to ("data",) for backward compatibility.
        **kwargs: Additional keyword arguments to pass to the model constructor

    Returns:
        If return_fields has a single element, returns that field's value.
        If return_fields has multiple elements, returns a tuple of field values.

    Examples:
        # Single field (backward compatible)
        data = convert_dict_to_object_based_response(response, Model)

        # Multiple fields
        data, raw_data = convert_dict_to_object_based_response(
            response, Model,
            return_fields=("data", "raw_data"),
            raw_data=raw_data_value
        )
    """
    # Indicates that the current response is already an object-based model
    if isinstance(response, model):
        model_instance = response
    elif isinstance(response, dict):
        model_instance = model(**response, **kwargs)
    else:
        model_instance = model(data=response, **kwargs)

    if return_model_only:
        return model_instance

    # Extract the requested fields
    result = []
    for field in return_fields:
        if hasattr(model_instance, field):
            result.append(getattr(model_instance, field))
        else:
            result.append(None)

    # Return single value or tuple based on number of fields
    if len(return_fields) == 1:
        return result[0]
    return tuple(result)


def parse_bool(value: str) -> bool:
    return value.lower() in ["true", "1", "t", "y", "yes"]


def parse_comma_separated_sites(site: str | None) -> list[str] | None:
    """
    Parse comma-separated site strings into a list or None.

    Handles the following cases:
    - "None" string or empty string -> None
    - Comma-separated values -> list of stripped strings
    - Empty list after parsing (only commas/whitespace) -> None

    Args:
        site: Comma-separated string of sites or None

    Returns:
        List of site strings or None

    Examples:
        >>> parse_comma_separated_sites("https://python.org, https://docs.python.org")
        ['https://python.org', 'https://docs.python.org']
        >>> parse_comma_separated_sites("None")
        None
        >>> parse_comma_separated_sites("  ,  ,  ")
        None
    """
    if site == "None" or not site:
        return None

    parsed_sites = [s.strip() for s in site.split(",") if s.strip()]

    # Convert empty list to None for consistency
    if not parsed_sites:
        return None

    return parsed_sites


def get_connector_token() -> str | None:
    """
    Get connector token from environment variables with backward compatibility.

    Checks for GL_CONNECTORS_USER_TOKEN first (new naming), then falls back to
    BOSA_TOKEN (old naming) for backward compatibility.

    Returns:
        Token string if found, None otherwise
    """
    return os.getenv("GL_CONNECTORS_USER_TOKEN") or os.getenv("BOSA_TOKEN")


def normalize_connector_token(
    gl_token: str | None = None, bosa_token: str | None = None
) -> str | None:
    """
    Normalize connector token parameter with backward compatibility.

    Accepts both gl_token and bosa_token parameters, preferring gl_token.
    If neither is provided, falls back to environment variables.

    Args:
        gl_token: GL Connectors token (new naming, preferred)
        bosa_token: BOSA token (old naming, for backward compatibility)

    Returns:
        Token string if found, None otherwise
    """
    # Prefer gl_token over bosa_token
    if gl_token:
        return gl_token
    if bosa_token:
        return bosa_token
    # Fall back to environment variables
    return get_connector_token()


def build_connector_headers(token: str | None) -> dict[str, str] | None:
    """
    Build connector headers.

    Creates headers with GL-Token (new naming). The header name uses the new
    convention, but token retrieval supports backward compatibility through
    normalize_connector_token().

    Args:
        token: The connector token

    Returns:
        Dictionary with GL-Token header if token is provided, None otherwise
    """
    if not token:
        return None

    return {"GL-Token": token}
