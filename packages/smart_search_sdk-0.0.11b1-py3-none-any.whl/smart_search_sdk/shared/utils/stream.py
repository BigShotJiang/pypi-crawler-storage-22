import json
from typing import AsyncGenerator, Callable

from pydantic import BaseModel
from rich.console import Console
from rich.panel import Panel

from smart_search_sdk.config.constants import EventType, SmartSearchEmitDataValue


async def handle_cli_response(
    client_method: Callable,
    request: BaseModel | None,
    stream_enabled: bool,
    console: Console,
    **kwargs,
) -> dict[str, any]:
    """
    Helper function to handle both streaming and non-streaming responses.

    Args:
        client_method: The async client method to call
        request: The request object (optional, some methods don't need it)
        stream_enabled: Whether streaming is enabled
        console: Rich console for output
        **kwargs: Additional keyword arguments to pass to the client method

    Returns:
        dict: Complete response (aggregated if streaming, direct if not)
    """
    if stream_enabled:
        console.print("[cyan]📡 Streaming enabled - receiving chunks...[/cyan]\n")
        response = {}
        chunk_count = 0

        # Get the async generator
        # Only pass request if it's provided
        call_kwargs = {"stream": True, **kwargs}
        if request is not None:
            call_kwargs["request"] = request

        stream: AsyncGenerator[BaseModel, None] = await client_method(**call_kwargs)

        # Consume the stream
        async for chunk in stream:
            chunk_count += 1
            if chunk.type and chunk.type == EventType.RESPONSE:
                response["data"] = chunk.value
            elif chunk.value.data_type == SmartSearchEmitDataValue.ACTIVITY:
                console.print(
                    Panel(
                        f"{json.dumps(chunk.value.data_value.model_dump(), indent=4)}",
                        title="Received chunk",
                        border_style="blue",
                    )
                )

        console.print(
            f"\n[green]✓ Streaming complete - received {chunk_count} chunks[/green]\n"
        )

        return response

    # For non-streaming, only pass request and stream if provided/needed
    # Some methods (like disconnect_connector) don't accept request parameter
    call_kwargs = {**kwargs}
    if request is not None:
        call_kwargs["request"] = request

    return await client_method(**call_kwargs)
