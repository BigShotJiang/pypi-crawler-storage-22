"""
Utility functions for rendering tables in CLI output.

This module provides reusable table rendering functionality for displaying
structured data in the command-line interface.

Functions:
    render_raw_data_table: Renders flexible tables for custom schema extraction results

Author:
    Glenn Steven Santoso (glenn.s.santoso@gdplabs.id)

References:
    None
"""

import json
from rich.console import Console
from rich.table import Table


def render_raw_data_table(
    raw_data: list | dict,
    console: Console,
) -> None:
    """
    Render flexible table(s) for raw_data from custom schema extraction.

    This function handles various data structures returned from custom JSON schema
    extraction, including single dictionaries, lists of dictionaries, and nested
    structures. It automatically formats values based on their type (lists, dicts,
    or simple values).

    Args:
        raw_data: The raw extracted data. Can be:
            - A single dictionary
            - A list of dictionaries
            - A list of mixed types
        console: Rich Console instance for output

    Example:
        >>> from rich.console import Console
        >>> console = Console()
        >>> raw_data = [{"name": "John", "skills": ["Python", "Go"]}]
        >>> render_raw_data_table(raw_data, console)
    """
    console.print("\n[bold]📊 Extracted Data (Custom Schema):[/bold]\n")

    # Handle raw_data which can be a list of dictionaries or a single dictionary
    raw_data_list = raw_data if isinstance(raw_data, list) else [raw_data]

    for idx, raw_item in enumerate(raw_data_list, 1):
        if isinstance(raw_item, dict):
            # Create a flexible table for each dictionary item
            table = Table(
                title=f"Extracted Item #{idx}",
                show_header=True,
                header_style="bold magenta",
            )
            table.add_column("Field", style="cyan", no_wrap=False)
            table.add_column("Value", style="white", no_wrap=False)

            for key, value in raw_item.items():
                # Format the value based on its type
                if isinstance(value, list):
                    if value and all(isinstance(v, dict) for v in value):
                        # List of dictionaries - format as JSON
                        formatted_value = json.dumps(value, indent=2)
                    else:
                        # List of simple values - join with commas
                        formatted_value = ", ".join(str(v) for v in value)
                elif isinstance(value, dict):
                    # Nested dictionary - format as JSON
                    formatted_value = json.dumps(value, indent=2)
                else:
                    # Simple value
                    formatted_value = str(value)

                table.add_row(key, formatted_value)

            console.print(table)
        else:
            # Handle non-dict items
            console.print(f"Item #{idx}: {raw_item}")

    console.print(
        f"\n[green]✓[/green] Extracted {len(raw_data_list)} item(s) using custom schema."
    )
