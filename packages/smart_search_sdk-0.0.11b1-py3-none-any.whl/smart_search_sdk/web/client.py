"""
Authors:
    Glenn S. Santoso (glenn.s.santoso@gdplabs.id)

References:
    None
"""

from typing import AsyncGenerator, Union

from smart_search_sdk.client.client import BaseSmartSearchClient
from smart_search_sdk.config.constants import TimeoutEnum
from smart_search_sdk.web.models import (
    GetWebSearchResultsRequest,
    GetWebSearchUrlsRequest,
    GetWebPageRequest,
    GetWebPageSnippetsRequest,
    GetWebPageKeypointsRequest,
)
from smart_search_sdk.web.models.schema import (
    GetWebPageResponse,
    GetWebPageSnippetsResponse,
    GetWebPageKeypointsResponse,
    GetWebSearchMapRequest,
    GetWebSearchMapResponse,
    GetWebSearchResultsResponse,
    GetWebSearchUrlsResponse,
)


class WebSearchClient(BaseSmartSearchClient):
    """
    A client for interacting with the Web Search service.

    This client provides methods to search the web, fetch web pages,
    extract snippets and keypoints from web content.

    Methods:
        search_web(request: GetWebSearchResultsRequest) -> GetWebSearchResultsResponse:
            Search the web for documents or pages relevant to the input query.

        search_web_urls(request: GetWebSearchUrlsRequest) -> GetWebSearchUrlsResponse:
            Search the web for pages relevant to the query and return their URLs.

        fetch_web_page(request: GetWebPageRequest) -> GetWebPageResponse:
            Fetch a single web page by URL and return its text, metadata, and optionally HTML content.

        get_web_page_snippets(request: GetWebPageSnippetsRequest) -> GetWebPageSnippetsResponse:
            Extract the most relevant text snippets from a web page for a given query.

        get_web_page_keypoints(request: GetWebPageKeypointsRequest) -> GetWebPageKeypointsResponse:
            Fetch a web page and extract concise key points from it.
    """

    async def search_web(
        self,
        request: GetWebSearchResultsRequest,
        stream: bool = False,
        timeout: float = TimeoutEnum.COMPLEX_PROCESS_TIMEOUT.value,
    ) -> Union[dict, AsyncGenerator[dict, None]]:
        """
        Search the web for documents or pages relevant to the input query.

        Returns either snippets or keypoints based on the result_type parameter.

        Args:
            request (GetWebSearchResultsRequest): Request containing:
                - query (str): The search query string.
                - result_type (Literal["snippets", "keypoints", "summary", "description"]): Type of results to return.
                - size (int): Maximum number of results to return (1-50).
                - timeout (float): Maximum time (in seconds) to wait for a response. Defaults to 300 seconds only for web search.
            stream (bool): If True, yields results as they arrive. If False, returns complete response.

        Returns:
            dict: A collection of chunks (snippets or keypoints) from web search results (when stream=False).
            AsyncGenerator[dict, None]: Yields individual chunks as they arrive (when stream=True).

        Example:
            # Non-streaming usage
            response = await client.search_web(request, stream=False)

            # Streaming usage
            async for chunk in await client.search_web(request, stream=True):
                print(chunk)
        """
        data = request.model_dump(mode="json", exclude_none=True)

        if stream:
            data["stream"] = stream
            return self.send_stream_request(
                endpoint="/v2/web/search",
                payload=data,
                model=GetWebSearchResultsResponse,
                timeout=timeout,
            )
        response = await self.send_post_request(
            endpoint="/v2/web/search",
            data=data,
        )
        return response

    async def search_web_map(
        self,
        request: GetWebSearchMapRequest,
        stream: bool = False,
        timeout: float = TimeoutEnum.SIMPLE_PROCESS_TIMEOUT.value,
    ) -> Union[dict, AsyncGenerator[dict, None]]:
        """
        Map a website and return its structure with URLs.

        Args:
            request (GetWebSearchMapRequest): Request containing:
                - base_url (str): The base URL of the website to map.
                - query (str, optional): Optional search query to filter URLs on the website.
                - include_subdomains (bool): Whether to include subdomains in the mapping.
                - size (int): Maximum number of URLs to return.
                - page (int): Page number for pagination.
            stream (bool): If True, yields results as they arrive. If False, returns complete response.
            timeout (float): Maximum time (in seconds) to wait for a response. Defaults to 30 seconds.

        Returns:
            dict: A collection of mapped links from the website (when stream=False).
            AsyncGenerator[dict, None]: Yields individual link chunks as they arrive (when stream=True).
        """
        data = request.model_dump(mode="json", exclude_none=True)
        if stream:
            data["stream"] = stream
            return self.send_stream_request(
                endpoint="/v2/web/search/map",
                payload=data,
                model=GetWebSearchMapResponse,
                timeout=timeout,
            )
        response = await self.send_post_request(
            endpoint="/v2/web/search/map",
            data=data,
        )
        return response

    async def search_web_urls(
        self,
        request: GetWebSearchUrlsRequest,
        stream: bool = False,
        timeout: float = TimeoutEnum.SIMPLE_PROCESS_TIMEOUT.value,
    ) -> Union[dict, AsyncGenerator[dict, None]]:
        """
        Search the web for pages relevant to the query and return their URLs.

        This method behaves like a search engine (e.g., Google), returning a list of URLs.

        Args:
            request (GetWebSearchUrlsRequest): Request containing:
                - query (str): The search query string.
                - size (int): Maximum number of URLs to return (1-50).
            stream (bool): If True, yields results as they arrive. If False, returns complete response.
            timeout (float): Maximum time (in seconds) to wait for a response. Defaults to 30 seconds.

        Returns:
            dict: A collection of URLs from web search results (when stream=False).
            AsyncGenerator[dict, None]: Yields individual URL chunks as they arrive (when stream=True).

        Example:
            # Non-streaming usage
            response = await client.search_web_urls(request, stream=False)

            # Streaming usage
            async for chunk in await client.search_web_urls(request, stream=True):
                print(chunk)
        """
        data = request.model_dump(mode="json", exclude_none=True)
        if stream:
            data["stream"] = stream
            return self.send_stream_request(
                endpoint="/v2/web/search/urls",
                payload=data,
                model=GetWebSearchUrlsResponse,
                timeout=timeout,
            )
        response = await self.send_post_request(
            endpoint="/v2/web/search/urls",
            data=data,
        )
        return response

    async def fetch_web_page(
        self,
        request: GetWebPageRequest,
        stream: bool = False,
        timeout: float = TimeoutEnum.SIMPLE_PROCESS_TIMEOUT.value,
    ) -> Union[dict, AsyncGenerator[dict, None]]:
        """
        Fetch a single web page by URL and return its text, metadata, and optionally HTML content.

        Args:
            request (GetWebPageRequest): Request containing:
                - source (AnyHttpUrl): The URL of the web page to fetch.
                - return_html (bool): Whether to return the full HTML content (default: False).
            stream (bool): If True, yields results as they arrive. If False, returns complete response.
            timeout (float): Maximum time (in seconds) to wait for a response. Defaults to 30 seconds.

        Returns:
            dict: The fetched web page with content, metadata, and optional HTML (when stream=False).
            AsyncGenerator[dict, None]: Yields page content chunks as they arrive (when stream=True).

        Example:
            # Non-streaming usage
            response = await client.fetch_web_page(request, stream=False)

            # Streaming usage
            async for chunk in await client.fetch_web_page(request, stream=True):
                print(chunk)
        """
        data = request.model_dump(mode="json", exclude_none=True)
        if stream:
            data["stream"] = stream
            return self.send_stream_request(
                endpoint="/v2/web/page",
                payload=data,
                model=GetWebPageResponse,
                timeout=timeout,
            )
        response = await self.send_post_request(
            endpoint="/v2/web/page",
            data=data,
        )
        return response

    async def get_web_page_snippets(
        self,
        request: GetWebPageSnippetsRequest,
        stream: bool = False,
        timeout: float = TimeoutEnum.COMPLEX_PROCESS_TIMEOUT.value,
    ) -> Union[dict, AsyncGenerator[dict, None]]:
        """
        Extract the most relevant text snippets from a web page for a given query.

        Returns relevant text fragments without fetching the entire page contents.

        Args:
            request (GetWebPageSnippetsRequest): Request containing:
                - query (str): The query to search for within the page.
                - source (AnyHttpUrl): The URL of the web page to extract from.
                - size (int): Maximum number of snippets to return (1-50).
                - snippet_style (Literal["paragraph", "sentence"]): Style of snippet to return.
            stream (bool): If True, yields results as they arrive. If False, returns complete response.
            timeout (float): Maximum time (in seconds) to wait for a response. Defaults to 30 seconds.

        Returns:
            dict: A collection of text snippets from the web page (when stream=False).
            AsyncGenerator[dict, None]: Yields individual snippet chunks as they arrive (when stream=True).

        Example:
            # Non-streaming usage
            response = await client.get_web_page_snippets(request, stream=False)

            # Streaming usage
            async for chunk in await client.get_web_page_snippets(request, stream=True):
                print(chunk)
        """
        data = request.model_dump(mode="json", exclude_none=True)
        if stream:
            data["stream"] = stream
            return self.send_stream_request(
                endpoint="/v2/web/page/snippets",
                payload=data,
                model=GetWebPageSnippetsResponse,
                timeout=timeout,
            )
        response = await self.send_post_request(
            endpoint="/v2/web/page/snippets",
            data=data,
        )
        return response

    async def get_web_page_keypoints(
        self,
        request: GetWebPageKeypointsRequest,
        stream: bool = False,
        timeout: float = TimeoutEnum.COMPLEX_PROCESS_TIMEOUT.value,
    ) -> Union[dict, AsyncGenerator[dict, None]]:
        """
        Fetch a web page and extract concise key points from it.

        Returns key points extracted from the web page content.

        Args:
            request (GetWebPageKeypointsRequest): Request containing:
                - query (str): The query to search for.
                - source (AnyHttpUrl): The URL of the web page to extract from.
                - size (int): Maximum number of key points to return (1-50).
            stream (bool): If True, yields results as they arrive. If False, returns complete response.

        Returns:
            dict: A collection of key points from the web page (when stream=False).
            AsyncGenerator[dict, None]: Yields individual keypoint chunks as they arrive (when stream=True).

        Example:
            # Non-streaming usage
            response = await client.get_web_page_keypoints(request, stream=False)

            # Streaming usage
            async for chunk in await client.get_web_page_keypoints(request, stream=True):
                print(chunk)
        """
        data = request.model_dump(mode="json", exclude_none=True)
        if stream:
            data["stream"] = stream
            return self.send_stream_request(
                endpoint="/v2/web/page/keypoints",
                payload=data,
                model=GetWebPageKeypointsResponse,
                timeout=timeout,
            )
        response = await self.send_post_request(
            endpoint="/v2/web/page/keypoints",
            data=data,
        )
        return response
