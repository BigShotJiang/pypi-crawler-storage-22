"""
Module: web_models.model

Description:
    Defines base models for web search and web scraping operations.

Classes:
    - Excerpt:
        Represents a piece of content with a confidence score.
    - WebPageMetadata:
        Extracted metadata for a web page.

Author:
    Glenn Steven Santoso (glenn.s.santoso@gdplabs.id)

References:
    None
"""

from enum import StrEnum
from pydantic import AnyHttpUrl, BaseModel, ConfigDict, Field

# ============================================================================
# COMMON BASE MODELS
# ============================================================================


class Excerpt(BaseModel):
    """
    Base model for keypoints representing a piece of content with a confidence score.
    """

    content: str
    confidence_score: float

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "content": "Python is a high-level, general-purpose programming language.",
                    "confidence_score": 0.95,
                },
                {
                    "content": "Python was created by Guido van Rossum and first released in 1991.",
                    "confidence_score": 0.92,
                },
            ]
        }
    )


class WebPageMetadata(BaseModel):
    """
    Extracted metadata for a web page.
    """

    title: str | None = Field(None, description="Page title")
    description: str | None = Field(None, description="Page description")
    language: str | None = Field(None, description="Page language")
    keywords: str | None = Field(None, description="Page keywords")
    status_code: int | None = Field(None, description="HTTP status code")

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "title": "Python Documentation",
                    "description": "Official documentation for the Python programming language",
                    "language": "en",
                    "keywords": "python, programming, documentation, tutorial",
                    "status_code": 200,
                },
                {
                    "title": "Getting Started with Python",
                    "description": "A beginner's guide to Python programming",
                    "language": "en-US",
                    "keywords": "python, beginners, tutorial, programming",
                    "status_code": 200,
                },
            ]
        }
    )


class MapLink(BaseModel):
    """
    A single link from the website map.
    """

    url: AnyHttpUrl = Field(..., description="URL of the mapped page")
    title: str | None = Field(None, description="Title of the page")
    description: str | None = Field(None, description="Description of the page")

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "url": "https://docs.firecrawl.dev/features/scrape",
                    "title": "Scrape | Firecrawl",
                    "description": "Turn any url into clean data",
                }
            ]
        }
    )


# ---------------------------


class SnippetStyle(StrEnum):
    PARAGRAPH = "paragraph"
    SENTENCE = "sentence"


class WebSearchEngine(StrEnum):
    """Enum for web search engine options."""

    AUTO = "auto"
    FIRECRAWL = "balance"
    PERPLEXITY = "speed"
    PARALLEL = "comprehensive"
    SELF_HOST = "self_host"
