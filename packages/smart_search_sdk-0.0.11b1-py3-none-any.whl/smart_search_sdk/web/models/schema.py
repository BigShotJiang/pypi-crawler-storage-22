"""
Module: web_models.schema

Description:
    Defines data models for web search and web scraping operations.

Classes:
    - GetWebSearchResultsRequest:
        Parameters for fetching web search results.
    - GetWebSearchResultsResponse:
        A list of snippet chunks from web search query.
    - GetWebSearchUrlsRequest:
        Parameters for retrieving URLs from web search results.
    - GetWebSearchUrlsResponse:
        A list of URLs from web search results.
    - GetWebPageRequest:
        Parameters for fetching a web page.
    - GetWebPageResponse:
        A single fetched web page.

Author:
    Glenn Steven Santoso (glenn.s.santoso@gdplabs.id)

References:
    None
"""

from datetime import datetime
from typing import Literal, Any
from smart_search_sdk.web.models.model import WebSearchEngine

from pydantic import AnyHttpUrl, BaseModel, ConfigDict, Field, field_validator

from smart_search_sdk.shared.models import (
    ChunkCollectionResponse,
    UrlCollectionResponse,
)
from smart_search_sdk.web.models.model import Excerpt, MapLink, WebPageMetadata


DEFAULT_WEB_SEARCH_SIZE: int = 5
DEFAULT_PAGINATION_WEB_SEARCH_SIZE: int = 20
DEFAULT_WEB_SEARCH_PAGE: int = 1
WEB_SEARCH_REQUEST_DESCRIPTION: str = "The query to search the web for"
WEB_SEARCH_SITE_DESCRIPTION: str = (
    "Optional URLs to limit search results to specific sites or domains"
)
WEB_SEARCH_ENGINE_DESCRIPTION: str = "Search mode to use (auto, balance, speed, comprehensive, self_host). Defaults to auto which uses the default search_mode."

SCRAPER_ENGINE_DESCRIPTION: str = (
    "The web search engine to use for fetching the web page"
)
JSON_SCHEMA_DESCRIPTION: str = "JSON schema to extract data from the web page"
SOURCE_DESCRIPTION: str = "The URL of the web page to fetch"

# ============================================================================
# WEB SEARCH GROUP
# ============================================================================


# ---------------------------
# Tool: get_web_search_results
# ---------------------------
class GetWebSearchResultsRequest(BaseModel):
    """
    Parameters for fetching web search results.
    """

    query: str
    site: list[AnyHttpUrl] | None = Field(None, description=WEB_SEARCH_SITE_DESCRIPTION)
    result_type: Literal["snippets", "keypoints", "summary", "description"] = "snippets"
    size: int = Field(DEFAULT_WEB_SEARCH_SIZE, ge=1, le=50)
    search_mode: WebSearchEngine = Field(
        WebSearchEngine.AUTO,
        description=WEB_SEARCH_ENGINE_DESCRIPTION,
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "query": "machine learning frameworks",
                    "result_type": "snippets",
                    "size": 5,
                },
                {
                    "query": "artificial intelligence ethics",
                    "result_type": "keypoints",
                    "size": 3,
                },
            ]
        }
    )

    @field_validator("site", mode="before")
    @classmethod
    def coerce_single_site_to_list(cls, v):
        if isinstance(v, str) or isinstance(v, AnyHttpUrl):
            return [v]
        return v


# ---------------------------
# Tool: get_web_search_map
# ---------------------------
class GetWebSearchMapRequest(BaseModel):
    """
    Parameters for mapping a website to get all URLs.
    """

    base_url: AnyHttpUrl = Field(..., description="The base URL of the website to map")
    query: str | None = Field(
        None,
        description="Optional search query to filter URLs on the website. Defaults to None.",
    )
    size: int = Field(
        DEFAULT_PAGINATION_WEB_SEARCH_SIZE,
        ge=1,
        description="The number of results to return",
    )
    page: int = Field(
        DEFAULT_WEB_SEARCH_PAGE,
        ge=DEFAULT_WEB_SEARCH_PAGE,
        description="The page number to return",
    )
    return_all_map: bool = Field(
        False,
        description="Whether to return all mapped links. Defaults to False.",
    )
    include_subdomains: bool = Field(
        False,
        description="Whether to include subdomains in the mapping. Defaults to False.",
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "base_url": "https://firecrawl.dev",
                    "size": 50,
                    "query": None,
                    "return_all_map": False,
                    "include_subdomains": False,
                },
                {
                    "base_url": "https://docs.python.org",
                    "size": 100,
                    "query": "tutorial",
                    "return_all_map": False,
                    "include_subdomains": True,
                },
                {
                    "base_url": "https://docs.python.org",
                    "size": 100,
                    "query": "tutorial",
                    "return_all_map": True,
                    "include_subdomains": True,
                },
            ]
        }
    )


class GetWebSearchMapResponse(BaseModel):
    """
    Response containing a list of mapped URLs from a website.
    """

    data: list[MapLink] = Field(
        ..., description="List of mapped links from the website"
    )
    total_found_links: int | None = Field(
        None, description="Total number of links found"
    )
    page: int | None = Field(None, description="Page number")
    size: int | None = Field(None, description="Number of links per page")
    total_pages: int | None = Field(None, description="Total number of pages")

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "data": [
                        {
                            "url": "https://docs.firecrawl.dev/features/scrape",
                            "title": "Scrape | Firecrawl",
                            "description": "Turn any url into clean data",
                        },
                        {
                            "url": "https://www.firecrawl.dev/playground",
                            "title": "Playground - Firecrawl",
                            "description": "Preview the API response and get the code snippets for the API",
                        },
                    ],
                    "total_found_links": None,
                    "page": None,
                    "size": None,
                    "total_pages": None,
                }
            ]
        }
    )


# ---------------------------
# Tool: get_web_search_urls
# ---------------------------
class GetWebSearchUrlsRequest(BaseModel):
    """
    Parameters for retrieving URLs from web search results.
    """

    query: str = Field(..., description=WEB_SEARCH_REQUEST_DESCRIPTION)
    site: list[AnyHttpUrl] | None = Field(None, description=WEB_SEARCH_SITE_DESCRIPTION)
    size: int = Field(
        DEFAULT_WEB_SEARCH_SIZE, ge=1, le=50, description="The number of URLs to return"
    )
    search_mode: WebSearchEngine = Field(
        WebSearchEngine.AUTO,
        description=WEB_SEARCH_ENGINE_DESCRIPTION,
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {"query": "python tutorials for beginners", "size": 5},
                {"query": "machine learning courses online", "size": 10},
            ]
        }
    )

    @field_validator("site", mode="before")
    @classmethod
    def coerce_single_site_to_list(cls, v):
        if isinstance(v, str) or isinstance(v, AnyHttpUrl):
            return [v]
        return v


class GetWebSearchUrlsResponse(UrlCollectionResponse):
    """
    A list of URLs from web search results.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [  # for query: "python tutorial" and size: 5
                {
                    "data": [
                        "https://docs.python.org/3/tutorial/",
                        "https://realpython.com/python-basics/",
                        "https://www.w3schools.com/python/",
                        "https://python.org/about/gettingstarted/",
                        "https://www.codecademy.com/learn/learn-python-3",
                    ],
                }
            ]
        }
    )


# ---------------------------
# Tool: get_web_page
# ---------------------------
class GetWebPageRequest(BaseModel):
    """
    Parameters for fetching a web page, including the target source and whether to return the full HTML content.
    """

    source: AnyHttpUrl = Field(..., description=SOURCE_DESCRIPTION)
    json_schema: dict[str, Any] | None = Field(
        None, description="Extracted JSON data matching the provided schema"
    )
    return_html: bool = Field(
        False, description="Whether to return the full HTML content of the page"
    )
    search_mode: Literal[
        WebSearchEngine.AUTO, WebSearchEngine.FIRECRAWL, WebSearchEngine.SELF_HOST
    ] = Field(
        WebSearchEngine.AUTO,
        description=f"{WEB_SEARCH_ENGINE_DESCRIPTION}. Scrape method is limited to Firecrawl only, therefore choice is narrowed down to Firecrawl based choice.",
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {"source": "https://docs.python.org/3/tutorial/", "return_html": False},
                {"source": "https://example.org/article/123", "return_html": True},
            ]
        }
    )


class GetWebPageResponse(BaseModel):
    """
    A single fetched web page.
    Returns one page with content, metadata, and optional HTML.
    """

    source: AnyHttpUrl = Field(..., description=SOURCE_DESCRIPTION)
    markdown: str | None = Field(None, description="Markdown content of the page")
    html: str | None = Field(None, description="HTML content of the page")
    metadata: WebPageMetadata = Field(..., description="Metadata of the web page")
    json: dict[str, Any] | None = Field(
        None, description="Extracted JSON data matching the provided schema"
    )
    fetched_at: datetime | None = Field(
        None, description="Timestamp when the page was fetched (ISO-8601)"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "source": "https://example.com/post/1",
                    "markdown": "# Post 1\n\nSample text",
                    "html": "<html><body><h1>Post 1</h1><p>Sample text</p></body></html>",
                    "metadata": {
                        "title": "Post 1",
                        "description": "Sample text for post 1",
                        "language": "en",
                        "keywords": "post, sample, text",
                        "status_code": 200,
                    },
                    "fetched_at": "2024-05-01T10:00:00Z",
                }
            ]
        }
    )


# # ---------------------------
# Tool: get_web_page_snippets
# ---------------------------
class GetWebPageSnippetsRequest(BaseModel):
    """
    Parameters for fetching text snippets from a web page source.
    """

    query: str = Field(..., description="The query to search the web for")
    source: AnyHttpUrl = Field(..., description=SOURCE_DESCRIPTION)
    size: int = Field(
        DEFAULT_WEB_SEARCH_SIZE,
        ge=1,
        le=50,
        description="The number of snippets to return",
    )
    search_mode: Literal[
        WebSearchEngine.AUTO, WebSearchEngine.FIRECRAWL, WebSearchEngine.SELF_HOST
    ] = Field(
        WebSearchEngine.AUTO,
        description=SCRAPER_ENGINE_DESCRIPTION,
    )
    json_schema: dict[str, Any] | None = Field(
        None,
        description=JSON_SCHEMA_DESCRIPTION,
    )
    snippet_style: Literal["paragraph", "sentence"] = Field(
        "paragraph", description="The style of snippets to return"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "query": "list comprehension",
                    "source": "https://docs.python.org/3/tutorial/datastructures.html",
                    "size": 3,
                    "json_schema": None,
                    "snippet_style": "paragraph",
                },
                {
                    "query": "python decorators",
                    "source": "https://realpython.com/primer-on-python-decorators/",
                    "size": 5,
                    "json_schema": None,
                    "snippet_style": "sentence",
                },
                {
                    "query": "python decorators",
                    "source": "https://realpython.com/primer-on-python-decorators/",
                    "size": 5,
                    "json_schema": {
                        "type": "object",
                        "properties": {
                            "example_name": {
                                "type": "string",
                                "description": "Name of the example use case",
                            },
                            "schema_models": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "model_name": {"type": "string"},
                                        "fields": {
                                            "type": "array",
                                            "items": {"type": "string"},
                                        },
                                    },
                                    "description": "Pydantic models used in the schema",
                                },
                            },
                            "data_extracted": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Types of data being extracted",
                            },
                            "key_techniques": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Key techniques demonstrated in the example",
                            },
                        },
                        "required": ["example_name", "schema_models", "data_extracted"],
                    },
                    "snippet_style": "sentence",
                },
            ]
        }
    )


class GetWebSearchResultsResponse(ChunkCollectionResponse):
    """
    A list of snippet chunks from web search query.
    """


class ExtractedDataResponse(ChunkCollectionResponse):
    """
    Response containing extracted data from Firecrawl extract API.
    Used when user provides a custom JSON schema.
    """

    raw_data: dict[str, Any] | None = Field(
        None, description="Extracted raw data matching the provided schema"
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "raw_data": {
                        "company_name": "Example Corp",
                        "description": "An example company",
                    },
                }
            ]
        }
    )


class GetWebPageSnippetsResponse(ExtractedDataResponse):
    """
    A list of snippets from a web page.
    """


# ---------------------------
# Tool: get_web_page_keypoints
# ---------------------------
class GetWebPageKeypointsRequest(BaseModel):
    """
    Parameters for fetching key points from a web search.
    """

    query: str = Field(..., description="The query to search the web for")
    source: AnyHttpUrl = Field(..., description="The URL of the web page to extract")
    json_schema: dict[str, Any] | None = Field(
        None,
        description="Optional JSON schema for custom extraction. If provided, uses Firecrawl extract API.",
    )
    size: int = Field(
        DEFAULT_WEB_SEARCH_SIZE,
        ge=1,
        le=50,
        description="The number of key points to return",
    )
    search_mode: Literal[
        WebSearchEngine.AUTO, WebSearchEngine.FIRECRAWL, WebSearchEngine.SELF_HOST
    ] = Field(
        WebSearchEngine.AUTO,
        description=SCRAPER_ENGINE_DESCRIPTION,
    )

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "query": "artificial intelligence ethics",
                    "source": "https://example.org/ai-ethics",
                    "size": 3,
                },
                {
                    "query": "climate change solutions",
                    "source": "https://example.com/climate-article",
                    "size": 5,
                },
            ]
        }
    )


class GetWebPageKeypointsResponse(ExtractedDataResponse):
    """
    A list of key points from a web page.
    """


# ============================================================================
# GENERAL RESPONSE MODELS
# ============================================================================


class KeypointResponse(BaseModel):
    """Schema for keypoint extraction responses."""

    keypoints: list[Excerpt] = Field(
        description="List of extracted key points from the text"
    )
    confidence_score: float

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "keypoints": [
                        {
                            "content": "Python supports multiple programming paradigms including object-oriented, functional, and procedural.",
                            "confidence_score": 0.95,
                        },
                        {
                            "content": "Python's design philosophy emphasizes code readability with its use of significant whitespace.",
                            "confidence_score": 0.92,
                        },
                    ],
                    "confidence_score": 0.93,
                }
            ]
        }
    )


class SnippetResponse(BaseModel):
    """Schema for snippet extraction responses."""

    snippets: list[Excerpt] = Field(
        description="List of extracted snippets from the text"
    )
    confidence_score: float

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "snippets": [
                        {
                            "content": "List comprehensions provide a concise way to create lists. Common applications are to make new lists where each element is the result of some operations applied to each member of another sequence or iterable.",
                            "confidence_score": 0.95,
                        },
                        {
                            "content": "For example, this listcomp combines the elements of two lists if they are not equal: [(x, y) for x in [1,2,3] for y in [3,1,4] if x != y]",
                            "confidence_score": 0.89,
                        },
                    ],
                    "confidence_score": 0.92,
                }
            ]
        }
    )
