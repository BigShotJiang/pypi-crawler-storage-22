from .translator import SmartTranslator

__all__ = ["SmartTranslator"]
