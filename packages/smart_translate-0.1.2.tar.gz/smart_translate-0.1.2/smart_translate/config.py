# # smart_translate/config.py

# # Default model used for translation
# MODEL_NAME = "facebook/nllb-200-distilled-600M"

# # Optional: default languages (used only if API doesn't send them)
# DEFAULT_SRC_LANG = "tha_Thai"
# DEFAULT_TGT_LANG = "eng_Latn"

# # Max token length for generation
# MAX_LENGTH = 256

MODEL_NAME = "facebook/nllb-200-distilled-600M"

