import re

def protect_words(text, keep_words):
    mapping = {}
    for i, word in enumerate(keep_words):
        placeholder = f"__KEEP_{i}__"
        mapping[placeholder] = word
        text = re.sub(rf"\b{re.escape(word)}\b", placeholder, text)
    return text, mapping

def restore_words(text, mapping):
    for placeholder, word in mapping.items():
        text = text.replace(placeholder, word)
    return text
