# smart_translate/rules.py

CUSTOM_REPLACEMENTS = {}

def apply_custom_rules(text, rules=None):
    if rules is None:
        rules = CUSTOM_REPLACEMENTS

    for key, value in rules.items():
        text = text.replace(key, value)

    return text
