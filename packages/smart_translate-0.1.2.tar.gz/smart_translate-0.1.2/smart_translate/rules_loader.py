import json
from importlib import resources


def load_custom_rules():
    with resources.files("smart_translate.rules").joinpath("custom_rules.json").open("r", encoding="utf-8") as f:
        return json.load(f)
