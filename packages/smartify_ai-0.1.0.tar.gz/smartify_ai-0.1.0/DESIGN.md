# Smartify Runtime MVP - Design Document

**Author:** Umbra  
**Date:** 2026-02-01  
**Status:** Draft

## Overview

Build a 100% local Python-based MVP runtime for the Smartify Grid specification. This runtime will orchestrate AI agents with guardrails, execute tasks in parallel, and optionally run workloads in an isolated sandbox container.

**Goals:**
- Parse and validate Grid YAML specifications
- Orchestrate agent execution following the Grid topology
- Enforce guardrails (token/time/cost limits, breakers)
- Support parallel task execution
- API and CLI interface only (no UI)

---

## Grid Specification Summary

### Root Structure
```yaml
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:       # Required - Grid identification
topology:       # Required - Node graph structure
inputs:         # Optional - Input parameters
environment:    # Optional - Variables and secrets
outputs:        # Optional - Artifacts and success criteria
agents:         # Optional - Agent definitions
tools:          # Optional - Tool configuration
guardrails:     # Optional - Limits and breaker actions
workspace:      # Optional - Execution environment
coordination:   # Optional - State management
observability:  # Optional - Logging and events
ui:             # Optional - Dashboard hints
```

### Grid States
```
draft → ready → energized → running → completed
                    ↓
              (paused | stopped | failed)
```

### Node Types

**Agent-driven (user-defined):**
- `controller` - Primary orchestrator (exactly 1 per grid)
- `relay` - Coordination/delegation node (parent: controller)
- `substation` - Task execution node (parent: relay)

**Runtime-only (not user-defined):**
- `spark` - Ephemeral helpers spawned automatically by substations

**Deterministic nodes:**
- `foreach` - Fan-out iteration over a list
- `expr` - Expression evaluation
- `aggregate` - Fan-in merge of outputs
- `approval` - Human-in-the-loop checkpoint

### Hierarchy
```
Grid
 └── Controller (1)
      └── Relay(s) (0-N)
           └── Substation(s) (0-N)
                └── Spark(s) (runtime-spawned, 0-N)
```

### Breaker Types
| Type | Monitors |
|------|----------|
| `tokens` | Input/output token usage |
| `time` | Runtime duration and task duration |
| `cost` | API cost per run and per day |
| `requests` | Requests per minute and concurrent agents |

**Breaker Status:** `ok` → `warning` (>80%) → `tripped` (>=100%)

**Trip Actions:** `notify`, `pause`, `cooldown`, `require_approval`, `stop`, `downgrade`, `block`

### Autonomy Modes
- `observe` - Read-only, no modifications
- `recommend` - Suggest changes, require approval
- `act_with_limits` - Execute within guardrails
- `full_autonomy` - Execute without restrictions

### Trigger Types
- `manual` - Started by user action
- `schedule` - Started on a cron schedule
- `webhook` - Started by HTTP webhook
- `event` - Started by system event

### Assignment Lifecycle
```
assigned → accepted → executing → completed
              ↓
          blocked → accepted (when unblocked)
```

### Inbox Items
- `assignment_delivery` - New work to process
- `signal` - Control messages (pause, resume, stop)
- `output` - Results from other nodes

---

## Architecture

### Core Components

```
┌─────────────────────────────────────────────────────────────────────┐
│                      Smartify Runtime                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │   CLI        │  │   API        │  │   Validator              │  │
│  │   Interface  │  │   Server     │  │   (Grid Spec Checker)    │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────────────────────┘  │
│         │                 │                                         │
│         └────────┬────────┘                                         │
│                  │                                                   │
│         ┌────────▼────────┐                                         │
│         │   Grid Engine   │                                         │
│         │   (Orchestrator)│                                         │
│         └────────┬────────┘                                         │
│                  │                                                   │
│    ┌─────────────┼─────────────┐                                    │
│    │             │             │                                    │
│    ▼             ▼             ▼                                    │
│ ┌──────┐   ┌──────────┐   ┌──────────┐                             │
│ │State │   │Scheduler │   │Guardrails│                             │
│ │Store │   │(DAG)     │   │Monitor   │                             │
│ └──────┘   └────┬─────┘   └──────────┘                             │
│                 │                                                   │
│         ┌───────┴───────┐                                          │
│         │               │                                          │
│         ▼               ▼                                          │
│   ┌──────────┐   ┌──────────────┐                                  │
│   │  Agent   │   │   Tool       │                                  │
│   │  Runner  │   │   Registry   │                                  │
│   └────┬─────┘   └──────────────┘                                  │
│        │                                                            │
│        ▼                                                            │
│   ┌──────────────────────────────────┐                             │
│   │     LLM Provider Adapters        │                             │
│   │  (Anthropic, OpenAI, etc.)       │                             │
│   └──────────────────────────────────┘                             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │  Sandbox        │
                    │  Container      │
                    │  (Optional)     │
                    └─────────────────┘
```

### Module Breakdown

1. **CLI Interface** (`smartify/cli/`)
   - `main.py` - Entry point, argument parsing
   - `run.py` - Run a grid from YAML file
   - `validate.py` - Validate grid spec
   - `status.py` - Check running grid status
   - `stop.py` - Stop a running grid

2. **API Server** (`smartify/api/`)
   - FastAPI-based REST API
   - Endpoints: `/grids`, `/runs`, `/status`, `/control`
   - WebSocket for real-time updates (optional for MVP)

3. **Validator** (`smartify/validator/`)
   - Schema validation (JSON Schema or Pydantic)
   - Semantic validation (topology consistency, no cycles, etc.)
   - Warning/error reporting

4. **Grid Engine** (`smartify/engine/`)
   - `grid.py` - Grid state machine
   - `orchestrator.py` - Main execution loop
   - `scheduler.py` - DAG-based task scheduling
   - `executor.py` - Node execution dispatch

5. **State Store** (`smartify/state/`)
   - In-memory store (MVP)
   - SQLite persistence (optional)
   - Grid state, node states, assignment tracking

6. **Agent Runner** (`smartify/agents/`)
   - `runner.py` - Agent execution wrapper
   - `adapters/` - LLM provider adapters (Anthropic, OpenAI)
   - `prompts/` - Built-in system prompts

7. **Guardrails** (`smartify/guardrails/`)
   - `breakers.py` - Breaker implementation
   - `monitor.py` - Token/time/cost tracking
   - `actions.py` - Trip action handlers

8. **Tools** (`smartify/tools/`)
   - `registry.py` - Tool registration
   - `builtin/` - Built-in tools (terminal, filesystem, git, browser)

9. **Workspace** (`smartify/workspace/`)
   - `local.py` - Local filesystem workspace
   - `container.py` - Docker container workspace
   - `sandbox.py` - Sandbox integration

---

## Data Models (Pydantic)

```python
# Core models
class GridSpec(BaseModel):
    apiVersion: str = "smartify.ai/v1"
    kind: str = "GridSpec"
    metadata: MetadataSpec
    topology: TopologySpec
    inputs: Optional[List[InputSpec]]
    environment: Optional[EnvironmentSpec]
    outputs: Optional[OutputsSpec]
    agents: Optional[Dict[str, AgentSpec]]
    tools: Optional[ToolsSpec]
    guardrails: Optional[GuardrailsSpec]
    workspace: Optional[WorkspaceSpec]

class NodeSpec(BaseModel):
    id: str
    kind: NodeKind  # controller, relay, substation, foreach, expr, aggregate, approval
    name: str
    description: Optional[str]
    parent: Optional[str]
    agent: Optional[str]
    capabilities: List[str] = []
    when: Optional[str]  # Expression
    parallel: bool = True
    runAfter: Optional[List[str]]
    retry: Optional[RetrySpec]
    outputSchema: Optional[dict]

class BreakerSpec(BaseModel):
    tokens: Optional[TokenLimits]
    time: Optional[TimeLimits]
    cost: Optional[CostLimits]
    requests: Optional[RequestLimits]

class BreakerActions(BaseModel):
    onTokensLimit: TripAction = TripAction.PAUSE
    onTimeLimit: TripAction = TripAction.STOP
    onCostLimit: TripAction = TripAction.PAUSE
    onRequestsLimit: TripAction = TripAction.COOLDOWN
```

---

## MVP Scope

### Phase 1: Core Infrastructure (Week 1)
- [ ] Grid YAML parsing and validation
- [ ] Pydantic models for all spec types
- [ ] CLI skeleton (validate, run)
- [ ] In-memory state store

### Phase 2: Execution Engine (Week 1-2)
- [ ] DAG-based scheduler
- [ ] Node execution dispatch
- [ ] Assignment delivery system
- [ ] Parent-child execution flow

### Phase 3: Agent Integration (Week 2)
- [ ] LLM provider adapters (start with Anthropic)
- [ ] Built-in system prompts
- [ ] Tool execution framework
- [ ] Basic tools (terminal, filesystem)

### Phase 4: Guardrails (Week 2-3)
- [ ] Token counting and limits
- [ ] Time tracking
- [ ] Breaker implementation
- [ ] Trip actions (pause, stop, notify)

### Phase 5: Polish & Testing (Week 3-4)
- [ ] API server
- [ ] Comprehensive validation
- [ ] Error handling
- [ ] Test suite
- [ ] Documentation

---

## CLI Commands

```bash
# Validate a grid spec
smartify validate grid.yaml

# Run a grid
smartify run grid.yaml --input project_name=myapp

# Check status of running grid
smartify status <run_id>

# Stop a running grid
smartify stop <run_id>

# List recent runs
smartify list

# Show grid info
smartify info grid.yaml
```

---

## API Endpoints

```
POST   /api/v1/grids              # Create/upload grid spec
GET    /api/v1/grids              # List grids
GET    /api/v1/grids/{id}         # Get grid details
DELETE /api/v1/grids/{id}         # Delete grid

POST   /api/v1/runs               # Start a grid run
GET    /api/v1/runs               # List runs
GET    /api/v1/runs/{id}          # Get run status
POST   /api/v1/runs/{id}/control  # pause, resume, stop
GET    /api/v1/runs/{id}/nodes    # List node states
GET    /api/v1/runs/{id}/logs     # Get execution logs

POST   /api/v1/validate           # Validate a grid spec
```

---

## Sandbox Integration

The runtime can optionally execute agent tasks in an isolated Docker container (similar to the sandbox we built). Configuration via `workspace` section:

```yaml
workspace:
  type: container
  config:
    image: smartify-sandbox:latest
    resources:
      cpus: 2
      memoryMb: 4096
    mounts:
      - src: ./output
        dst: /workspace/output
```

---

## Key Design Decisions

1. **Python-based** - Easier integration with ML/AI ecosystem, fast development
2. **Pydantic for validation** - Strong typing, automatic validation, serialization
3. **DAG scheduler** - Natural fit for topology with dependencies
4. **In-memory first** - Fast iteration, add persistence later
5. **Adapter pattern for LLMs** - Easy to add new providers
6. **Built-in tools** - Start minimal, expand based on need

---

## Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Scope creep | Strict MVP scope, defer features to backlog |
| LLM rate limits | Implement proper backoff, cost tracking |
| Container overhead | Make sandbox optional, default to local |
| Complex topologies | Start with simple parent-child, add edges later |

---

## Next Steps

1. Set up Python project structure
2. Implement Pydantic models for Grid spec
3. Build validator CLI command
4. Implement basic orchestrator
5. Add Anthropic adapter
6. Implement breakers
7. Build API server
8. Test with example grids
