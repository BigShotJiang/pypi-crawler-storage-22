# Smartify Runtime — Launch Plan

Plan for open-source launch: MCP integration, repo cleanup, and license/docs alignment.

---

## 1. MCP (Model Context Protocol) Integration

**Goal:** Allow grids to use tools from external MCP servers so existing MCP integrations work plug-and-play with Smartify agent swarms.

**Reference:** [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk) — official client; supports stdio, SSE, Streamable HTTP. Install: `pip install mcp` (Python ≥3.10).

### 1.1 Architecture

- **MCP as tool source:** One or more MCP servers are configured per run (or globally). The runtime connects as an MCP **client**, calls `tools/list` to discover tools, and exposes each MCP tool as a Smartify `Tool` so the existing `ToolRegistry` and orchestrator can use them.
- **Adapter pattern:** Add `McpToolAdapter` (or `McpServerBridge`) that:
  - Connects to an MCP server (stdio command, SSE URL, or Streamable HTTP URL).
  - Lists tools via MCP `tools/list`.
  - For each MCP tool, creates a wrapper that implements Smartify's `Tool` interface (`name`, `description`, `parameters` from MCP schema, `execute` → MCP `tools/call`).
- **Naming:** MCP tools can clash with builtins. Use a prefix per server (e.g. `mcp_fileread` for server label `mcp`) or a configurable prefix in grid/context so nodes can refer to `mcp_fileread` or `filesystem.read_file`.

### 1.2 Phases

#### Phase A: Dependency and MCP client wrapper (foundation)

- [x] Add optional dependency: `mcp` in `pyproject.toml` (e.g. `mcp>=1.0` in `[project.optional-dependencies]` as `mcp` or under `integrations`).
- [x] Create `src/smartify/tools/mcp/` package:
  - [x] `__init__.py` — export public API.
  - [x] `client.py` — thin wrapper around MCP Python SDK client:
    - Connect (stdio command list, or SSE/HTTP URL) from config.
    - `list_tools() -> List[McpToolDef]` (name, description, parameters schema).
    - `call_tool(name: str, arguments: dict) -> ToolResult` (async).
  - [x] Handle connection lifecycle (connect when building registry or on first use; disconnect on shutdown or run end). Prefer one client per MCP server process/URL.

#### Phase B: Smartify `Tool` adapter for MCP

- [x] In `src/smartify/tools/mcp/`, add `adapter.py`:
  - [x] Class `McpToolWrapper(Tool)`:
    - Takes an MCP client (or server session) + one MCP tool definition.
    - `name`: MCP tool name, optionally prefixed (e.g. `mcp_filesystem_read`) to avoid clashes.
    - `description`, `parameters`: from MCP tool definition (map to our JSON Schema shape if needed).
    - `execute(**kwargs)`: call MCP `tools/call` with the tool name and kwargs; map MCP result (e.g. content list or error) to `ToolResult(success=..., output=..., error=...)`.
  - [x] Add tests (unit: mock MCP client; optional integration: real MCP server in CI or behind `pytest -m mcp`).

#### Phase C: Registry integration

- [x] Add `McpRegistryBuilder` or a function `register_mcp_server(registry: ToolRegistry, config: McpServerConfig) -> None`:
  - Connect to MCP server, list tools, create `McpToolWrapper` per tool, `registry.register(wrapper)` for each.
  - Config: transport type (stdio / sse / streamable_http), command or URL, optional tool name prefix, optional allow-list of tool names.
- [x] Ensure `create_builtin_registry()` (or the factory used by the orchestrator) can accept optional MCP configs and call `register_mcp_server` for each, so builtins + MCP tools are in one registry.

#### Phase D: Grid YAML and runtime wiring

- [x] Extend grid spec (e.g. in `models/grid.py`):
  - [x] Add `McpServerSpec` (e.g. `id`, `transport: stdio | sse | streamable_http`, `command` or `url`, optional `prefix`, optional `tools: [names]`).
  - [x] In `ToolsSpec`, add `mcpServers: List[McpServerSpec]` (or under `tools.mcp`).
- [x] Validator: validate `mcpServers` entries (required fields, valid transport).
- [x] Orchestrator (or the place that builds `ToolRegistry` for a run):
  - [x] When building the registry for a run, read grid's `tools.mcpServers` (or equivalent), and for each server call `register_mcp_server(registry, server_config)`.
  - [x] If MCP is optional dependency, catch import error and raise a clear "install smartify[mcp] to use MCP servers" (or similar).
- [x] Document in README: "Using MCP servers" with a small example (one stdio server and one tool used in a grid).

#### Phase E: Docs and optional extras

- [x] README section: "Tool integrations" — builtins + MCP; link to MCP spec/sdk.
- [x] Example grid YAML that uses one MCP server (e.g. filesystem or a simple test server) so users can run it with `smartify run examples/grid-with-mcp.yaml`.
- [x] Optional: `smartify[mcp]` or `smartify[integrations]` extra in pyproject so MCP is opt-in for minimal installs.

### 1.3 Out of scope for initial launch (backlog)

- MCP resources/prompts (only tools first).
- Dynamic tool approval for MCP calls (can add later if needed).
- Caching or connection pooling across runs (keep simple: connect per run or per process).

---

## 2. Repo cleanup (pre-push)

### 2.1 Add a proper `.gitignore`

- [x] Add `.gitignore` at repo root with:
  - Python: `.venv/`, `venv/`, `env/`, `__pycache__/`, `*.py[cod]`, `*.pyo`, `.pytest_cache/`, `.mypy_cache/`, `*.egg-info/`, `dist/`, `build/`
  - Local data: `*.db`, `smartify_state.db`, `.env`, `*.local`
  - OS/IDE: `.DS_Store`, `.idea/`, `*.swp`, `*.swo`
  - Optional: `coverage.xml`, `htmlcov/` if you use coverage

### 2.2 Files to delete before pushing to Git

- [x] **`ai_healthcare_research.md`** — domain-specific research; not part of runtime.
- [x] **`AI_Healthcare_Historical_Research.md`** — same.
- [x] **`smartify_state.db`** — runtime SQLite DB; should not be committed (and is ignored via `.gitignore`).
- [x] **`.DS_Store`** — macOS metadata (and ignored).
- **Root-level E2E scripts — keep them:**  
  **`test_e2e.py`**, **`test_e2e_tools.py`**, **`test_parallel_swarm.py`** are manual smoke tests that run the **actual example YAML files** (`examples/minimal.yaml`, `file-creator.yaml`, `parallel-swarm.yaml`) with a real API. They complement `tests/test_integration_live.py` (which uses inline YAML and pytest). Use them for quick checks after changing examples: `python test_e2e.py`, `python test_e2e_tools.py`, `python test_parallel_swarm.py "topic"`.

### 2.3 Optional

- Move or trim **`GAPS.md`** (e.g. move to `docs/` or fold into README "Roadmap") so the repo reads as launch-ready.

---

## 3. License and project alignment

### 3.1 Add LICENSE file

- [x] Add **`LICENSE`** at repo root.
- [x] Use **MIT** to match `pyproject.toml` (already "MIT" and "License :: OSI Approved :: MIT License").
- [x] In LICENSE, set **Copyright (c) YEAR Smartify** (or your legal entity) and keep standard MIT text.

### 3.2 Align README and pyproject.toml

- [x] **README.md:** Change "License" section from "BSL 1.1" to **"MIT"** and add a one-line pointer: "See [LICENSE](LICENSE)."
- [x] **pyproject.toml:** Leave as-is (already MIT); no change unless you later switch to BSL 1.1 (then update both LICENSE file and both docs).

---

## Checklist summary

| Item | Status |
|------|--------|
| **LAUNCH_PLAN.md** (this file) | ✅ Done |
| **.gitignore** | ✅ Done |
| Delete healthcare research files | ✅ Done |
| Delete `smartify_state.db` / .DS_Store | ✅ Done |
| Keep root-level E2E scripts (restored) | ✅ Done |
| **LICENSE** (MIT) | ✅ Done |
| README license → MIT | ✅ Done |
| **MCP integration** | ✅ Done |

---

## MCP Integration Complete

All phases implemented:

- **Phase A**: Added optional `mcp` dependency in pyproject.toml; created `src/smartify/tools/mcp/` package with `client.py` (MCP client wrapper supporting stdio/sse/streamable_http).
- **Phase B**: Created `adapter.py` with `McpToolWrapper(Tool)` that wraps MCP tools for use in Smartify.
- **Phase C**: Created `registry.py` with `register_mcp_server()` function to register MCP server tools into a ToolRegistry.
- **Phase D**: Added `McpServerSpec` to `models/grid.py`, added `mcpServers` to `ToolsSpec`, wired orchestrator to auto-register MCP servers on `energize()`.
- **Phase E**: Updated README with MCP section, added `examples/mcp-filesystem.yaml`, added `tests/test_mcp.py` (14 tests passing).

**Tests**: 355 passing (excluding OpenAI adapter tests with pre-existing httpx version conflict from mcp package).

The repo is now ready for open-source launch with "plug and play with existing tool integrations and MCP" and multi-agent providers.
