"""Smartify - Local runtime for Grid specifications."""

__version__ = "0.1.0"
