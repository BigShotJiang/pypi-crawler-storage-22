"""LLM and tool adapters for Smartify.

Adapters implement the LLMAdapter and ToolAdapter protocols
defined in smartify.engine.orchestrator.
"""

from smartify.agents.adapters.anthropic import AnthropicAdapter
from smartify.agents.adapters.openai import OpenAIAdapter

__all__ = [
    "AnthropicAdapter",
    "OpenAIAdapter",
]
