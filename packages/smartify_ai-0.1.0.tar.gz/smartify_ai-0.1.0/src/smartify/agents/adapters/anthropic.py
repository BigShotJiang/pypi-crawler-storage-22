"""Anthropic Claude LLM adapter for Smartify.

Implements the LLMAdapter protocol using the Anthropic Python SDK.
Supports Claude 3.5 Sonnet, Claude 3 Opus, and other Claude models.
"""

import os
import logging
from typing import Any, Dict, List, Optional

from anthropic import AsyncAnthropic
from anthropic.types import Message, ContentBlock, ToolUseBlock, TextBlock


logger = logging.getLogger(__name__)


# Token pricing per million tokens (as of early 2026, check for updates)
MODEL_PRICING = {
    "claude-sonnet-4-20250514": {"input": 3.00, "output": 15.00},
    "claude-3-5-sonnet-20241022": {"input": 3.00, "output": 15.00},
    "claude-3-opus-20240229": {"input": 15.00, "output": 75.00},
    "claude-3-sonnet-20240229": {"input": 3.00, "output": 15.00},
    "claude-3-haiku-20240307": {"input": 0.25, "output": 1.25},
    # Aliases
    "claude-3-5-sonnet-latest": {"input": 3.00, "output": 15.00},
    "claude-3-opus-latest": {"input": 15.00, "output": 75.00},
}

DEFAULT_MODEL = "claude-sonnet-4-20250514"


class AnthropicAdapter:
    """Anthropic Claude LLM adapter.
    
    Implements the LLMAdapter protocol for use with Smartify's orchestrator.
    
    Example:
        adapter = AnthropicAdapter(api_key="sk-...")
        response = await adapter.complete(
            messages=[{"role": "user", "content": "Hello!"}],
            system="You are a helpful assistant."
        )
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = DEFAULT_MODEL,
        base_url: Optional[str] = None,
        timeout: float = 120.0,
    ):
        """Initialize the Anthropic adapter.
        
        Args:
            api_key: Anthropic API key. Defaults to ANTHROPIC_API_KEY env var.
            model: Default model to use for completions.
            base_url: Optional custom API base URL.
            timeout: Request timeout in seconds.
        """
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Anthropic API key required. Set ANTHROPIC_API_KEY or pass api_key."
            )
        
        self.model = model
        self.timeout = timeout
        
        self._client = AsyncAnthropic(
            api_key=self.api_key,
            base_url=base_url,
            timeout=timeout,
        )
    
    async def complete(
        self,
        messages: List[Dict[str, str]],
        system: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        model: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate a completion from Claude.
        
        Args:
            messages: List of message dicts with 'role' and 'content' keys.
            system: Optional system prompt.
            temperature: Sampling temperature (0-1).
            max_tokens: Maximum tokens to generate. Defaults to 4096.
            tools: Optional list of tool definitions for function calling.
            model: Override the default model for this request.
        
        Returns:
            Dict containing:
                - content: The assistant's response text
                - tool_calls: List of tool calls if any
                - tokens_in: Input token count
                - tokens_out: Output token count
                - cost: Estimated cost in USD
                - model: Model used
                - stop_reason: Why generation stopped
        """
        use_model = model or self.model
        max_tokens = max_tokens or 4096
        
        # Build request kwargs
        kwargs: Dict[str, Any] = {
            "model": use_model,
            "messages": self._convert_messages(messages),
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        
        if system:
            kwargs["system"] = system
        
        if tools:
            kwargs["tools"] = self._convert_tools(tools)
        
        logger.debug(f"Anthropic request: model={use_model}, messages={len(messages)}")
        
        response: Message = await self._client.messages.create(**kwargs)
        
        # Extract content
        content_text = ""
        tool_calls = []
        
        for block in response.content:
            if isinstance(block, TextBlock):
                content_text += block.text
            elif isinstance(block, ToolUseBlock):
                tool_calls.append({
                    "id": block.id,
                    "name": block.name,
                    "arguments": block.input,
                })
        
        # Calculate cost
        tokens_in = response.usage.input_tokens
        tokens_out = response.usage.output_tokens
        cost = self._calculate_cost(use_model, tokens_in, tokens_out)
        
        logger.debug(
            f"Anthropic response: tokens_in={tokens_in}, tokens_out={tokens_out}, "
            f"cost=${cost:.4f}, stop_reason={response.stop_reason}"
        )
        
        return {
            "content": content_text,
            "tool_calls": tool_calls if tool_calls else None,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": cost,
            "model": use_model,
            "stop_reason": response.stop_reason,
        }
    
    def _convert_messages(self, messages: List[Dict[str, str]]) -> List[Dict[str, Any]]:
        """Convert generic messages to Anthropic format.
        
        Handles:
        - Basic user/assistant messages
        - Tool results
        - Multi-part content
        """
        converted = []
        
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            # Anthropic uses "user" and "assistant" roles
            if role == "system":
                # System messages should be passed via system parameter
                continue
            
            anthropic_msg: Dict[str, Any] = {"role": role}
            
            # Handle tool results
            if role == "tool" or msg.get("tool_call_id"):
                anthropic_msg = {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": msg.get("tool_call_id", ""),
                            "content": content,
                        }
                    ],
                }
            else:
                anthropic_msg["content"] = content
            
            converted.append(anthropic_msg)
        
        return converted
    
    def _convert_tools(self, tools: List[Dict]) -> List[Dict[str, Any]]:
        """Convert generic tool definitions to Anthropic format.
        
        Expected input format (OpenAI-style):
        {
            "type": "function",
            "function": {
                "name": "tool_name",
                "description": "What the tool does",
                "parameters": { JSON Schema }
            }
        }
        
        Anthropic format:
        {
            "name": "tool_name",
            "description": "What the tool does",
            "input_schema": { JSON Schema }
        }
        """
        converted = []
        
        for tool in tools:
            if tool.get("type") == "function":
                func = tool.get("function", {})
                converted.append({
                    "name": func.get("name", ""),
                    "description": func.get("description", ""),
                    "input_schema": func.get("parameters", {"type": "object", "properties": {}}),
                })
            elif "name" in tool:
                # Already in Anthropic format
                converted.append(tool)
        
        return converted
    
    def _calculate_cost(self, model: str, tokens_in: int, tokens_out: int) -> float:
        """Calculate estimated cost in USD."""
        pricing = MODEL_PRICING.get(model, MODEL_PRICING[DEFAULT_MODEL])
        
        cost_in = (tokens_in / 1_000_000) * pricing["input"]
        cost_out = (tokens_out / 1_000_000) * pricing["output"]
        
        return cost_in + cost_out
    
    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.close()
    
    async def __aenter__(self) -> "AnthropicAdapter":
        return self
    
    async def __aexit__(self, *args) -> None:
        await self.close()
