"""OpenAI GPT LLM adapter for Smartify.

Implements the LLMAdapter protocol using the OpenAI Python SDK.
Supports GPT-4o, GPT-4, GPT-4 Turbo, and other OpenAI models.
"""

import os
import json
import logging
from typing import Any, Dict, List, Optional

from openai import AsyncOpenAI


logger = logging.getLogger(__name__)


# Token pricing per million tokens (as of early 2026, check for updates)
MODEL_PRICING = {
    # GPT-4o family
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-2024-11-20": {"input": 2.50, "output": 10.00},
    "gpt-4o-2024-08-06": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4o-mini-2024-07-18": {"input": 0.15, "output": 0.60},
    # GPT-4 Turbo
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-4-turbo-2024-04-09": {"input": 10.00, "output": 30.00},
    "gpt-4-turbo-preview": {"input": 10.00, "output": 30.00},
    # GPT-4
    "gpt-4": {"input": 30.00, "output": 60.00},
    "gpt-4-0613": {"input": 30.00, "output": 60.00},
    # GPT-3.5 Turbo
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "gpt-3.5-turbo-0125": {"input": 0.50, "output": 1.50},
    # o1 reasoning models
    "o1": {"input": 15.00, "output": 60.00},
    "o1-preview": {"input": 15.00, "output": 60.00},
    "o1-mini": {"input": 3.00, "output": 12.00},
}

DEFAULT_MODEL = "gpt-4o"


class OpenAIAdapter:
    """OpenAI GPT LLM adapter.
    
    Implements the LLMAdapter protocol for use with Smartify's orchestrator.
    
    Example:
        adapter = OpenAIAdapter(api_key="sk-...")
        response = await adapter.complete(
            messages=[{"role": "user", "content": "Hello!"}],
            system="You are a helpful assistant."
        )
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = DEFAULT_MODEL,
        base_url: Optional[str] = None,
        timeout: float = 120.0,
        organization: Optional[str] = None,
    ):
        """Initialize the OpenAI adapter.
        
        Args:
            api_key: OpenAI API key. Defaults to OPENAI_API_KEY env var.
            model: Default model to use for completions.
            base_url: Optional custom API base URL (for Azure, proxies, etc.).
            timeout: Request timeout in seconds.
            organization: Optional OpenAI organization ID.
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError(
                "OpenAI API key required. Set OPENAI_API_KEY or pass api_key."
            )
        
        self.model = model
        self.timeout = timeout
        
        self._client = AsyncOpenAI(
            api_key=self.api_key,
            base_url=base_url,
            timeout=timeout,
            organization=organization,
        )
    
    async def complete(
        self,
        messages: List[Dict[str, str]],
        system: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        model: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Generate a completion from GPT.
        
        Args:
            messages: List of message dicts with 'role' and 'content' keys.
            system: Optional system prompt.
            temperature: Sampling temperature (0-2 for OpenAI).
            max_tokens: Maximum tokens to generate. Defaults to 4096.
            tools: Optional list of tool definitions for function calling.
            model: Override the default model for this request.
        
        Returns:
            Dict containing:
                - content: The assistant's response text
                - tool_calls: List of tool calls if any
                - tokens_in: Input token count
                - tokens_out: Output token count
                - cost: Estimated cost in USD
                - model: Model used
                - stop_reason: Why generation stopped
        """
        use_model = model or self.model
        max_tokens = max_tokens or 4096
        
        # Build messages with system prompt prepended
        api_messages = self._convert_messages(messages, system)
        
        # Build request kwargs (max_tokens for chat completions API)
        kwargs: Dict[str, Any] = {
            "model": use_model,
            "messages": api_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        
        if tools:
            kwargs["tools"] = self._convert_tools(tools)
            kwargs["tool_choice"] = "auto"
        
        logger.debug(f"OpenAI request: model={use_model}, messages={len(api_messages)}")
        
        response = await self._client.chat.completions.create(**kwargs)
        
        # Extract content
        choice = response.choices[0]
        content_text = choice.message.content or ""
        tool_calls = []
        
        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                # Parse arguments - OpenAI returns JSON string
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {"raw": tc.function.arguments}
                
                tool_calls.append({
                    "id": tc.id,
                    "name": tc.function.name,
                    "arguments": args,
                })
        
        # Calculate cost
        tokens_in = response.usage.prompt_tokens if response.usage else 0
        tokens_out = response.usage.completion_tokens if response.usage else 0
        cost = self._calculate_cost(use_model, tokens_in, tokens_out)
        
        # Map finish_reason to consistent format
        stop_reason = self._map_stop_reason(choice.finish_reason)
        
        logger.debug(
            f"OpenAI response: tokens_in={tokens_in}, tokens_out={tokens_out}, "
            f"cost=${cost:.4f}, stop_reason={stop_reason}"
        )
        
        return {
            "content": content_text,
            "tool_calls": tool_calls if tool_calls else None,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost": cost,
            "model": use_model,
            "stop_reason": stop_reason,
        }
    
    def _convert_messages(
        self, 
        messages: List[Dict[str, str]], 
        system: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Convert generic messages to OpenAI format.
        
        OpenAI accepts system messages in the messages array.
        """
        converted = []
        
        # Prepend system message if provided
        if system:
            converted.append({"role": "system", "content": system})
        
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            # Handle tool results
            if role == "tool" or msg.get("tool_call_id"):
                converted.append({
                    "role": "tool",
                    "tool_call_id": msg.get("tool_call_id", ""),
                    "content": content,
                })
            else:
                converted.append({"role": role, "content": content})
        
        return converted
    
    def _convert_tools(self, tools: List[Dict]) -> List[Dict[str, Any]]:
        """Convert generic tool definitions to OpenAI format.
        
        OpenAI expects:
        {
            "type": "function",
            "function": {
                "name": "tool_name",
                "description": "What the tool does",
                "parameters": { JSON Schema }
            }
        }
        """
        converted = []
        
        for tool in tools:
            if tool.get("type") == "function":
                # Already in OpenAI format
                converted.append(tool)
            elif "name" in tool:
                # Convert from Anthropic-style format
                converted.append({
                    "type": "function",
                    "function": {
                        "name": tool.get("name", ""),
                        "description": tool.get("description", ""),
                        "parameters": tool.get("input_schema", tool.get("parameters", {
                            "type": "object", 
                            "properties": {}
                        })),
                    },
                })
        
        return converted
    
    def _map_stop_reason(self, finish_reason: Optional[str]) -> str:
        """Map OpenAI finish_reason to consistent stop_reason format."""
        mapping = {
            "stop": "end_turn",
            "length": "max_tokens",
            "tool_calls": "tool_use",
            "content_filter": "content_filter",
            "function_call": "tool_use",  # Legacy
        }
        return mapping.get(finish_reason or "stop", finish_reason or "end_turn")
    
    def _calculate_cost(self, model: str, tokens_in: int, tokens_out: int) -> float:
        """Calculate estimated cost in USD."""
        # Find pricing - check exact match first, then prefix match
        pricing = MODEL_PRICING.get(model)
        
        if not pricing:
            # Try prefix matching for dated model versions
            for model_key in MODEL_PRICING:
                if model.startswith(model_key):
                    pricing = MODEL_PRICING[model_key]
                    break
        
        if not pricing:
            pricing = MODEL_PRICING[DEFAULT_MODEL]
        
        cost_in = (tokens_in / 1_000_000) * pricing["input"]
        cost_out = (tokens_out / 1_000_000) * pricing["output"]
        
        return cost_in + cost_out
    
    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.close()
    
    async def __aenter__(self) -> "OpenAIAdapter":
        return self
    
    async def __aexit__(self, *args) -> None:
        await self.close()
