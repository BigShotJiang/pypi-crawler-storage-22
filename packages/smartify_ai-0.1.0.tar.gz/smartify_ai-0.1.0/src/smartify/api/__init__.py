"""Smartify HTTP API.

FastAPI-based REST API for grid management and execution.
"""

from smartify.api.server import app, run_server
from smartify.api.auth import (
    AuthConfig,
    AuthMiddleware,
    generate_api_key,
    hash_api_key,
    verify_api_key,
    get_auth_config,
)

__all__ = [
    "app",
    "run_server",
    # Auth
    "AuthConfig",
    "AuthMiddleware",
    "generate_api_key",
    "hash_api_key",
    "verify_api_key",
    "get_auth_config",
]
