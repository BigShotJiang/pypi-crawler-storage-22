"""API authentication for Smartify Runtime.

Supports multiple authentication methods:
- API Key (via header or query param)
- Bearer token (JWT, future)

Unauthenticated access is allowed only for specific endpoints like /health.
"""

import hashlib
import hmac
import logging
import os
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable, Dict, List, Optional, Set

from fastapi import Depends, HTTPException, Request, Security
from fastapi.security import APIKeyHeader, APIKeyQuery
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)


# ============================================================================
# Configuration
# ============================================================================

@dataclass
class AuthConfig:
    """Authentication configuration."""
    
    # Enable/disable auth (default: enabled if any keys configured)
    enabled: bool = True
    
    # API keys (can be set via SMARTIFY_API_KEYS env var, comma-separated)
    api_keys: Set[str] = field(default_factory=set)
    
    # Paths that don't require authentication
    public_paths: Set[str] = field(default_factory=lambda: {
        "/",
        "/health",
        "/docs",
        "/openapi.json",
        "/redoc",
    })
    
    # Path prefixes that don't require authentication
    public_prefixes: List[str] = field(default_factory=lambda: [
        "/docs",
        "/redoc",
    ])
    
    # Rate limiting (per API key)
    rate_limit_requests: int = 1000  # requests per window
    rate_limit_window_seconds: int = 3600  # 1 hour
    
    @classmethod
    def from_env(cls) -> "AuthConfig":
        """Load configuration from environment variables."""
        config = cls()
        
        # Load API keys from environment
        api_keys_str = os.environ.get("SMARTIFY_API_KEYS", "")
        if api_keys_str:
            keys = [k.strip() for k in api_keys_str.split(",") if k.strip()]
            config.api_keys = set(keys)
            logger.info(f"Loaded {len(config.api_keys)} API key(s) from environment")
        
        # Check if auth should be enabled
        auth_enabled = os.environ.get("SMARTIFY_AUTH_ENABLED", "").lower()
        if auth_enabled == "false":
            config.enabled = False
            logger.warning("Authentication disabled via SMARTIFY_AUTH_ENABLED=false")
        elif not config.api_keys:
            # No keys configured, disable auth with warning
            config.enabled = False
            logger.warning("No API keys configured - authentication disabled")
        
        # Rate limit settings
        rate_limit = os.environ.get("SMARTIFY_RATE_LIMIT")
        if rate_limit:
            try:
                config.rate_limit_requests = int(rate_limit)
            except ValueError:
                pass
        
        return config


# ============================================================================
# API Key Management
# ============================================================================

def generate_api_key(prefix: str = "sk") -> str:
    """Generate a new random API key.
    
    Format: {prefix}_{32_random_hex_chars}
    Example: sk_a1b2c3d4e5f6789012345678901234567890
    """
    random_part = secrets.token_hex(16)
    return f"{prefix}_{random_part}"


def hash_api_key(key: str) -> str:
    """Hash an API key for secure storage.
    
    Uses SHA-256 for consistent hashing.
    """
    return hashlib.sha256(key.encode()).hexdigest()


def verify_api_key(provided_key: str, stored_keys: Set[str]) -> bool:
    """Verify an API key against stored keys.
    
    Supports both plain keys and hashed keys.
    Uses constant-time comparison to prevent timing attacks.
    """
    if not provided_key:
        return False
    
    # Direct match (for plain keys in development)
    if provided_key in stored_keys:
        return True
    
    # Hash and compare (for production with hashed storage)
    hashed = hash_api_key(provided_key)
    for stored in stored_keys:
        if hmac.compare_digest(hashed, stored):
            return True
    
    return False


# ============================================================================
# Rate Limiting
# ============================================================================

@dataclass
class RateLimitEntry:
    """Track rate limit for a single key."""
    count: int = 0
    window_start: datetime = field(default_factory=datetime.now)


class RateLimiter:
    """Simple in-memory rate limiter."""
    
    def __init__(self, max_requests: int, window_seconds: int):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._entries: Dict[str, RateLimitEntry] = {}
    
    def check(self, key: str) -> tuple[bool, int]:
        """Check if request is allowed.
        
        Returns:
            (allowed, remaining_requests)
        """
        now = datetime.now()
        entry = self._entries.get(key)
        
        if entry is None:
            entry = RateLimitEntry(count=0, window_start=now)
            self._entries[key] = entry
        
        # Reset window if expired
        window_end = entry.window_start + timedelta(seconds=self.window_seconds)
        if now > window_end:
            entry.count = 0
            entry.window_start = now
        
        # Check limit
        if entry.count >= self.max_requests:
            return False, 0
        
        entry.count += 1
        remaining = self.max_requests - entry.count
        return True, remaining
    
    def get_reset_time(self, key: str) -> Optional[datetime]:
        """Get when the rate limit window resets."""
        entry = self._entries.get(key)
        if entry:
            return entry.window_start + timedelta(seconds=self.window_seconds)
        return None


# ============================================================================
# FastAPI Dependencies
# ============================================================================

# Security schemes
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)
api_key_query = APIKeyQuery(name="api_key", auto_error=False)

# Global instances (initialized on startup)
_auth_config: Optional[AuthConfig] = None
_rate_limiter: Optional[RateLimiter] = None


def get_auth_config() -> AuthConfig:
    """Get the global auth configuration."""
    global _auth_config
    if _auth_config is None:
        _auth_config = AuthConfig.from_env()
    return _auth_config


def get_rate_limiter() -> RateLimiter:
    """Get the global rate limiter."""
    global _rate_limiter
    if _rate_limiter is None:
        config = get_auth_config()
        _rate_limiter = RateLimiter(
            max_requests=config.rate_limit_requests,
            window_seconds=config.rate_limit_window_seconds,
        )
    return _rate_limiter


async def verify_api_key_dep(
    api_key_header: Optional[str] = Security(api_key_header),
    api_key_query: Optional[str] = Security(api_key_query),
) -> str:
    """FastAPI dependency to verify API key.
    
    Accepts key from either X-API-Key header or api_key query parameter.
    """
    config = get_auth_config()
    
    if not config.enabled:
        return "anonymous"
    
    # Get key from header or query
    api_key = api_key_header or api_key_query
    
    if not api_key:
        raise HTTPException(
            status_code=401,
            detail="API key required. Provide via X-API-Key header or api_key query parameter.",
            headers={"WWW-Authenticate": "ApiKey"},
        )
    
    if not verify_api_key(api_key, config.api_keys):
        raise HTTPException(
            status_code=401,
            detail="Invalid API key",
            headers={"WWW-Authenticate": "ApiKey"},
        )
    
    # Check rate limit
    limiter = get_rate_limiter()
    allowed, remaining = limiter.check(api_key)
    
    if not allowed:
        reset_time = limiter.get_reset_time(api_key)
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded",
            headers={
                "X-RateLimit-Limit": str(config.rate_limit_requests),
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Reset": reset_time.isoformat() if reset_time else "",
            },
        )
    
    return api_key


# ============================================================================
# Middleware
# ============================================================================

class AuthMiddleware(BaseHTTPMiddleware):
    """Authentication middleware for FastAPI.
    
    Checks API key for all requests except public paths.
    """
    
    async def dispatch(self, request: Request, call_next: Callable):
        config = get_auth_config()
        
        # Skip auth if disabled
        if not config.enabled:
            return await call_next(request)
        
        # Check if path is public
        path = request.url.path
        
        if path in config.public_paths:
            return await call_next(request)
        
        for prefix in config.public_prefixes:
            if path.startswith(prefix):
                return await call_next(request)
        
        # Extract API key
        api_key = request.headers.get("X-API-Key") or request.query_params.get("api_key")
        
        if not api_key:
            return JSONResponse(
                status_code=401,
                content={
                    "detail": "API key required. Provide via X-API-Key header or api_key query parameter."
                },
                headers={"WWW-Authenticate": "ApiKey"},
            )
        
        if not verify_api_key(api_key, config.api_keys):
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid API key"},
                headers={"WWW-Authenticate": "ApiKey"},
            )
        
        # Check rate limit
        limiter = get_rate_limiter()
        allowed, remaining = limiter.check(api_key)
        
        if not allowed:
            reset_time = limiter.get_reset_time(api_key)
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded"},
                headers={
                    "X-RateLimit-Limit": str(config.rate_limit_requests),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Reset": reset_time.isoformat() if reset_time else "",
                },
            )
        
        # Add rate limit headers to response
        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(config.rate_limit_requests)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        
        return response


# ============================================================================
# CLI Helpers
# ============================================================================

def print_new_api_key():
    """Generate and print a new API key (for CLI use)."""
    key = generate_api_key()
    print(f"Generated API Key: {key}")
    print(f"Add to environment: SMARTIFY_API_KEYS={key}")
    print(f"Or add hashed: {hash_api_key(key)}")
