"""CLI module for Smartify."""
