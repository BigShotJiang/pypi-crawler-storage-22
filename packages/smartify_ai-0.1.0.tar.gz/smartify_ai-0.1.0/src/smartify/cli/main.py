"""Smartify CLI - Main entry point."""

import typer
from rich.console import Console
from rich.table import Table
from pathlib import Path
from typing import Optional
import yaml

from smartify import __version__

app = typer.Typer(
    name="smartify",
    help="Local runtime for Smartify Grid specifications",
    no_args_is_help=True,
)
console = Console()


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"[bold blue]smartify[/bold blue] version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """Smartify - Local runtime for Grid specifications."""
    pass


@app.command()
def validate(
    grid_file: Path = typer.Argument(
        ...,
        help="Path to Grid YAML file",
        exists=True,
        readable=True,
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
) -> None:
    """Validate a Grid YAML specification."""
    from smartify.validator.validate import validate_grid_file
    
    console.print(f"[bold]Validating[/bold] {grid_file}")
    
    try:
        result = validate_grid_file(grid_file)
        
        if result.is_valid:
            console.print("[bold green]✓[/bold green] Grid specification is valid")
            
            if verbose and result.grid:
                console.print(f"\n[bold]Grid ID:[/bold] {result.grid.metadata.id}")
                console.print(f"[bold]Name:[/bold] {result.grid.metadata.name}")
                console.print(f"[bold]Nodes:[/bold] {len(result.grid.topology.nodes)}")
        else:
            console.print("[bold red]✗[/bold red] Validation failed")
            
            for error in result.errors:
                console.print(f"  [red]•[/red] {error}")
            
            raise typer.Exit(1)
        
        if result.warnings:
            console.print(f"\n[yellow]Warnings ({len(result.warnings)}):[/yellow]")
            for warning in result.warnings:
                console.print(f"  [yellow]•[/yellow] {warning}")
                
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)


@app.command()
def run(
    grid_file: Path = typer.Argument(
        ...,
        help="Path to Grid YAML file",
        exists=True,
        readable=True,
    ),
    input: list[str] = typer.Option(
        [],
        "--input",
        "-i",
        help="Input parameters (key=value)",
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate only, don't execute"),
    watch: bool = typer.Option(False, "--watch", "-w", help="Watch execution progress"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
) -> None:
    """Run a Grid specification."""
    import asyncio
    from smartify.engine.orchestrator import Orchestrator, ExecutionError
    
    console.print(f"[bold]Running[/bold] {grid_file}")
    
    # Parse inputs
    inputs = {}
    for inp in input:
        if "=" in inp:
            key, value = inp.split("=", 1)
            inputs[key] = value
        else:
            console.print(f"[yellow]Warning:[/yellow] Invalid input format: {inp}")
    
    if inputs:
        console.print(f"[bold]Inputs:[/bold] {inputs}")
    
    if dry_run:
        console.print("[yellow]Dry run mode - validating only[/yellow]")
        from smartify.validator.validate import validate_grid_file
        result = validate_grid_file(grid_file)
        if result.is_valid:
            console.print("[bold green]✓[/bold green] Grid is valid and ready to run")
            
            # Show execution plan
            if verbose and result.grid:
                from smartify.engine.scheduler import DAGScheduler
                scheduler = DAGScheduler(result.grid)
                scheduler.build_graph()
                console.print("\n[bold]Execution Plan:[/bold]")
                console.print(scheduler.visualize())
        else:
            console.print("[bold red]✗[/bold red] Grid validation failed")
            for error in result.errors:
                console.print(f"  [red]•[/red] {error}")
            raise typer.Exit(1)
        return
    
    async def _run():
        import os
        from smartify.agents.adapters import AnthropicAdapter
        
        orchestrator = Orchestrator()
        
        # Auto-register LLM adapter from environment
        if os.environ.get("ANTHROPIC_API_KEY"):
            adapter = AnthropicAdapter()
            orchestrator.register_llm_adapter("anthropic", adapter)
            orchestrator.register_llm_adapter("default", adapter)
            console.print("[green]✓[/green] Anthropic LLM adapter configured")
        else:
            console.print("[yellow]Warning:[/yellow] ANTHROPIC_API_KEY not set - LLM calls will fail")
        
        try:
            # Load grid
            grid_run = await orchestrator.load_grid(grid_file, inputs=inputs)
            console.print(f"[green]✓[/green] Loaded grid '{grid_run.grid.id}'")
            
            if verbose:
                console.print(f"  Nodes: {len(grid_run.grid.topology.nodes)}")
            
            # Energize
            await orchestrator.energize(grid_run)
            console.print(f"[green]✓[/green] Grid energized")
            
            # Execute
            console.print("[bold]Executing...[/bold]")
            result = await orchestrator.execute(grid_run)
            
            # Show results
            if result.get('state') == 'completed':
                console.print("\n[bold green]✓ Grid completed successfully[/bold green]")
            else:
                console.print(f"\n[bold red]✗ Grid failed: {result.get('error')}[/bold red]")
            
            if verbose:
                console.print("\n[bold]Results:[/bold]")
                import json
                console.print(json.dumps(result, indent=2, default=str))
            
            return result
            
        except ExecutionError as e:
            console.print(f"[bold red]Execution error:[/bold red] {e}")
            raise typer.Exit(1)
    
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Execution interrupted[/yellow]")
        raise typer.Exit(130)


@app.command()
def status(
    run_id: str = typer.Argument(..., help="Run ID to check"),
    db: str = typer.Option("smartify_runs.db", "--db", help="Database file path"),
) -> None:
    """Check status of a grid run."""
    from smartify.state import SQLiteStore, RunStatus
    
    store = SQLiteStore(db)
    run = store.get_run(run_id)
    
    if not run:
        console.print(f"[red]Run not found:[/red] {run_id}")
        raise typer.Exit(1)
    
    # Status color
    status_colors = {
        RunStatus.PENDING: "yellow",
        RunStatus.RUNNING: "blue",
        RunStatus.PAUSED: "yellow",
        RunStatus.COMPLETED: "green",
        RunStatus.FAILED: "red",
        RunStatus.STOPPED: "dim",
    }
    color = status_colors.get(run.status, "white")
    
    console.print(f"\n[bold]Run:[/bold] {run.run_id}")
    console.print(f"[bold]Grid:[/bold] {run.grid_name} ({run.grid_id})")
    console.print(f"[bold]Status:[/bold] [{color}]{run.status.value}[/{color}]")
    console.print(f"[bold]Created:[/bold] {run.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
    
    if run.started_at:
        console.print(f"[bold]Started:[/bold] {run.started_at.strftime('%Y-%m-%d %H:%M:%S')}")
    if run.completed_at:
        console.print(f"[bold]Completed:[/bold] {run.completed_at.strftime('%Y-%m-%d %H:%M:%S')}")
    
    console.print(f"[bold]Tokens:[/bold] {run.total_tokens:,}")
    console.print(f"[bold]Cost:[/bold] ${run.total_cost:.4f}")
    
    if run.error:
        console.print(f"[bold red]Error:[/bold red] {run.error}")
    
    # Show node outputs
    outputs = store.get_node_outputs(run_id)
    if outputs:
        console.print(f"\n[bold]Node Outputs:[/bold] {len(outputs)}")
        for out in outputs:
            status_icon = "[green]✓[/green]" if out.success else "[red]✗[/red]"
            console.print(f"  {status_icon} {out.node_id} ({out.tokens_used} tokens)")


@app.command()
def stop(
    run_id: str = typer.Argument(..., help="Run ID to stop"),
    db: str = typer.Option("smartify_runs.db", "--db", help="Database file path"),
    force: bool = typer.Option(False, "--force", "-f", help="Force stop immediately"),
) -> None:
    """Stop a running grid."""
    from smartify.state import SQLiteStore, RunStatus
    
    store = SQLiteStore(db)
    run = store.get_run(run_id)
    
    if not run:
        console.print(f"[red]Run not found:[/red] {run_id}")
        raise typer.Exit(1)
    
    if run.status not in (RunStatus.RUNNING, RunStatus.PAUSED):
        console.print(f"[yellow]Run is not active:[/yellow] {run.status.value}")
        raise typer.Exit(1)
    
    from datetime import datetime
    run.status = RunStatus.STOPPED
    run.completed_at = datetime.now()
    store.save_run(run)
    
    console.print(f"[green]✓[/green] Run stopped: {run_id}")


@app.command(name="list")
def list_runs(
    limit: int = typer.Option(10, "--limit", "-n", help="Number of runs to show"),
    status_filter: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status"),
    grid_id: Optional[str] = typer.Option(None, "--grid", "-g", help="Filter by grid ID"),
    db: str = typer.Option("smartify_runs.db", "--db", help="Database file path"),
) -> None:
    """List grid runs."""
    from smartify.state import SQLiteStore, RunStatus
    
    store = SQLiteStore(db)
    
    # Parse status filter
    status = None
    if status_filter:
        try:
            status = RunStatus(status_filter.lower())
        except ValueError:
            console.print(f"[red]Invalid status:[/red] {status_filter}")
            console.print(f"Valid: {', '.join(s.value for s in RunStatus)}")
            raise typer.Exit(1)
    
    runs = store.list_runs(status=status, grid_id=grid_id, limit=limit)
    
    if not runs:
        console.print("[dim]No runs found[/dim]")
        return
    
    # Create table
    table = Table(title="Grid Runs")
    table.add_column("Run ID", style="cyan")
    table.add_column("Grid", style="blue")
    table.add_column("Status")
    table.add_column("Tokens", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Created")
    
    for run in runs:
        status_colors = {
            RunStatus.PENDING: "yellow",
            RunStatus.RUNNING: "blue",
            RunStatus.PAUSED: "yellow",
            RunStatus.COMPLETED: "green",
            RunStatus.FAILED: "red",
            RunStatus.STOPPED: "dim",
        }
        color = status_colors.get(run.status, "white")
        
        table.add_row(
            run.run_id[:12] + "..." if len(run.run_id) > 15 else run.run_id,
            run.grid_name[:20],
            f"[{color}]{run.status.value}[/{color}]",
            f"{run.total_tokens:,}",
            f"${run.total_cost:.4f}",
            run.created_at.strftime("%m-%d %H:%M"),
        )
    
    console.print(table)


@app.command()
def serve(
    host: str = typer.Option("0.0.0.0", "--host", "-h", help="Host to bind to"),
    port: int = typer.Option(8080, "--port", "-p", help="Port to bind to"),
    reload: bool = typer.Option(False, "--reload", "-r", help="Enable auto-reload (dev mode)"),
) -> None:
    """Start the Smartify API server."""
    from smartify.api.server import run_server
    
    console.print(f"[bold]Starting Smartify API server[/bold]")
    console.print(f"  [dim]Host:[/dim] {host}")
    console.print(f"  [dim]Port:[/dim] {port}")
    console.print(f"  [dim]Docs:[/dim] http://{host}:{port}/docs")
    
    run_server(host=host, port=port, reload=reload)


@app.command()
def info(
    grid_file: Path = typer.Argument(
        ...,
        help="Path to Grid YAML file",
        exists=True,
        readable=True,
    ),
) -> None:
    """Show information about a Grid specification."""
    from smartify.validator.validate import validate_grid_file
    
    try:
        result = validate_grid_file(grid_file)
        
        if not result.is_valid or not result.grid:
            console.print("[bold red]Error:[/bold red] Invalid grid file")
            for error in result.errors:
                console.print(f"  [red]•[/red] {error}")
            raise typer.Exit(1)
        
        grid = result.grid
        
        # Grid metadata
        console.print("\n[bold blue]Grid Information[/bold blue]")
        console.print(f"  [bold]ID:[/bold] {grid.metadata.id}")
        console.print(f"  [bold]Name:[/bold] {grid.metadata.name}")
        if grid.metadata.description:
            console.print(f"  [bold]Description:[/bold] {grid.metadata.description}")
        console.print(f"  [bold]Version:[/bold] {grid.metadata.version}")
        
        # Topology
        console.print("\n[bold blue]Topology[/bold blue]")
        
        # Count node types
        node_counts = {}
        for node in grid.topology.nodes:
            kind = node.kind.value if hasattr(node.kind, 'value') else str(node.kind)
            node_counts[kind] = node_counts.get(kind, 0) + 1
        
        for kind, count in node_counts.items():
            console.print(f"  [bold]{kind}:[/bold] {count}")
        
        # Node table
        table = Table(title="Nodes")
        table.add_column("ID", style="cyan")
        table.add_column("Kind", style="green")
        table.add_column("Name")
        table.add_column("Parent", style="dim")
        
        for node in grid.topology.nodes:
            kind = node.kind.value if hasattr(node.kind, 'value') else str(node.kind)
            table.add_row(node.id, kind, node.name, node.parent or "-")
        
        console.print(table)
        
        # Inputs
        if grid.inputs:
            console.print("\n[bold blue]Inputs[/bold blue]")
            for inp in grid.inputs:
                req = "[red]*[/red]" if inp.required else ""
                default = f" (default: {inp.default})" if inp.default is not None else ""
                console.print(f"  {req}[bold]{inp.name}[/bold]: {inp.type}{default}")
        
        # Agents
        if grid.agents:
            console.print("\n[bold blue]Agents[/bold blue]")
            for name, agent in grid.agents.items():
                model = agent.modelPolicy.preferred if agent.modelPolicy else "default"
                console.print(f"  [bold]{name}:[/bold] {model}")
        
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
