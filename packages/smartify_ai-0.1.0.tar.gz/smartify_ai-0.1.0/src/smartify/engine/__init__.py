"""Smartify execution engine.

Provides grid orchestration and scheduling:
- DAGScheduler: Determines execution order based on dependencies
- Orchestrator: Core execution engine managing grid lifecycle
- SparkManager: Dynamic agent spawning for parallel workloads
"""

from smartify.engine.scheduler import DAGScheduler, NodeState, NodeExecution
from smartify.engine.orchestrator import (
    Orchestrator,
    ExecutionContext,
    GridRun,
    NodeResult,
    ExecutionError,
    GridLifecycleError,
    LLMAdapter,
    ToolAdapter,
)
from smartify.engine.spark import (
    SparkManager,
    SparkRequest,
    SparkNode,
    analyze_workload_for_sparks,
)
from smartify.engine.approval import (
    ApprovalManager,
    ApprovalRequest,
    ApprovalStatus,
    SlackNotificationChannel,
    WebhookNotificationChannel,
    get_approval_manager,
    configure_approval_manager,
)

__all__ = [
    # Scheduler
    "DAGScheduler",
    "NodeState",
    "NodeExecution",
    # Orchestrator
    "Orchestrator",
    "ExecutionContext",
    "GridRun",
    "NodeResult",
    "ExecutionError",
    "GridLifecycleError",
    # Protocols
    "LLMAdapter",
    "ToolAdapter",
    # Spark (dynamic spawning)
    "SparkManager",
    "SparkRequest",
    "SparkNode",
    "analyze_workload_for_sparks",
    # Approval (human-in-the-loop)
    "ApprovalManager",
    "ApprovalRequest",
    "ApprovalStatus",
    "SlackNotificationChannel",
    "WebhookNotificationChannel",
    "get_approval_manager",
    "configure_approval_manager",
]
