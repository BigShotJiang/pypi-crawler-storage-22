"""Spark node spawning for dynamic agent creation.

Sparks are lightweight helper agents spawned at runtime to assist
substations with parallelizable workloads. They are created dynamically
based on workload analysis and subject to spawning limits.
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from uuid import uuid4

from smartify.models.grid import (
    NodeSpec,
    NodeKind,
    DynamicSpawningSpec,
)

if TYPE_CHECKING:
    from smartify.engine.orchestrator import GridRun
    from smartify.engine.scheduler import DAGScheduler

logger = logging.getLogger(__name__)


@dataclass
class SparkRequest:
    """Request to spawn a new Spark node."""
    parent_id: str          # Substation requesting the spawn
    task: str               # Task description for the spark
    context: Dict[str, Any] = field(default_factory=dict)  # Context from parent
    priority: int = 0       # Higher = more important
    
    # Optional constraints
    tools: Optional[List[str]] = None
    max_tokens: Optional[int] = None
    timeout_seconds: Optional[int] = None


@dataclass
class SparkNode:
    """Runtime representation of a spawned Spark node."""
    id: str
    parent_id: str
    task: str
    context: Dict[str, Any]
    created_at: datetime
    
    # Runtime state
    status: str = "pending"  # pending, running, completed, failed
    output: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    tokens_used: int = 0


class SparkManager:
    """Manages dynamic Spark node spawning and execution.
    
    Usage:
        manager = SparkManager(spawning_config, scheduler)
        
        # Request a spark from a substation
        spark = await manager.spawn(SparkRequest(
            parent_id="substation-1",
            task="Analyze this file",
            context={"file": "data.csv"}
        ))
        
        # Execute all pending sparks
        results = await manager.execute_pending(run, adapter)
    """
    
    def __init__(
        self,
        config: DynamicSpawningSpec,
        scheduler: "DAGScheduler",
    ):
        self.config = config
        self.scheduler = scheduler
        
        # Track spawned sparks
        self.sparks: Dict[str, SparkNode] = {}
        self.sparks_by_parent: Dict[str, List[str]] = {}
        
        # Counters for limit enforcement
        self._total_spawned = 0
    
    @property
    def enabled(self) -> bool:
        """Check if spark spawning is enabled."""
        return self.config.enabled and self.config.enableSparks
    
    def can_spawn(self, parent_id: str) -> bool:
        """Check if a new spark can be spawned for the given parent."""
        if not self.enabled:
            return False
        
        limits = self.config.limits
        
        # Check total limit
        if len(self.sparks) >= limits.maxTotalNodes:
            logger.warning(f"Total node limit reached: {limits.maxTotalNodes}")
            return False
        
        # Check per-substation limit
        parent_sparks = self.sparks_by_parent.get(parent_id, [])
        if len(parent_sparks) >= limits.maxSparksPerSubstation:
            logger.warning(
                f"Spark limit for {parent_id} reached: {limits.maxSparksPerSubstation}"
            )
            return False
        
        return True
    
    async def spawn(self, request: SparkRequest) -> Optional[SparkNode]:
        """Spawn a new Spark node.
        
        Args:
            request: SparkRequest with task and context
            
        Returns:
            SparkNode if spawned, None if limits exceeded or disabled
        """
        if not self.can_spawn(request.parent_id):
            return None
        
        # Check if approval is required
        if self.config.requireApproval:
            logger.warning(
                f"Spark spawn requires approval (not implemented) - auto-approving"
            )
            # TODO: Implement approval flow
        
        # Create spark node
        spark_id = f"spark-{request.parent_id}-{uuid4().hex[:8]}"
        
        spark = SparkNode(
            id=spark_id,
            parent_id=request.parent_id,
            task=request.task,
            context=request.context,
            created_at=datetime.now(),
        )
        
        # Register spark
        self.sparks[spark_id] = spark
        
        if request.parent_id not in self.sparks_by_parent:
            self.sparks_by_parent[request.parent_id] = []
        self.sparks_by_parent[request.parent_id].append(spark_id)
        
        self._total_spawned += 1
        
        logger.info(
            f"Spawned spark {spark_id} for {request.parent_id}: {request.task[:50]}..."
        )
        
        return spark
    
    async def spawn_batch(
        self,
        requests: List[SparkRequest],
    ) -> List[SparkNode]:
        """Spawn multiple sparks (respects limits)."""
        spawned = []
        for request in requests:
            spark = await self.spawn(request)
            if spark:
                spawned.append(spark)
            else:
                logger.warning(
                    f"Could not spawn spark for {request.parent_id} - limits reached"
                )
                break  # Stop if we hit limits
        return spawned
    
    def get_pending_sparks(self) -> List[SparkNode]:
        """Get all sparks in pending status."""
        return [s for s in self.sparks.values() if s.status == "pending"]
    
    def get_sparks_for_parent(self, parent_id: str) -> List[SparkNode]:
        """Get all sparks spawned by a specific parent."""
        spark_ids = self.sparks_by_parent.get(parent_id, [])
        return [self.sparks[sid] for sid in spark_ids if sid in self.sparks]
    
    def mark_running(self, spark_id: str) -> None:
        """Mark a spark as running."""
        if spark_id in self.sparks:
            self.sparks[spark_id].status = "running"
    
    def mark_completed(
        self,
        spark_id: str,
        output: Dict[str, Any],
        tokens_used: int = 0,
    ) -> None:
        """Mark a spark as completed."""
        if spark_id in self.sparks:
            spark = self.sparks[spark_id]
            spark.status = "completed"
            spark.output = output
            spark.tokens_used = tokens_used
    
    def mark_failed(self, spark_id: str, error: str) -> None:
        """Mark a spark as failed."""
        if spark_id in self.sparks:
            spark = self.sparks[spark_id]
            spark.status = "failed"
            spark.error = error
    
    def get_completed_outputs(self, parent_id: str) -> List[Dict[str, Any]]:
        """Get outputs from all completed sparks for a parent."""
        outputs = []
        for spark in self.get_sparks_for_parent(parent_id):
            if spark.status == "completed" and spark.output:
                outputs.append({
                    "spark_id": spark.id,
                    "task": spark.task,
                    "output": spark.output,
                })
        return outputs
    
    def get_stats(self) -> Dict[str, Any]:
        """Get spark manager statistics."""
        by_status = {}
        for spark in self.sparks.values():
            by_status[spark.status] = by_status.get(spark.status, 0) + 1
        
        return {
            "enabled": self.enabled,
            "total_spawned": self._total_spawned,
            "active": len(self.sparks),
            "by_status": by_status,
            "limits": {
                "max_total": self.config.limits.maxTotalNodes,
                "max_per_substation": self.config.limits.maxSparksPerSubstation,
            },
        }


def analyze_workload_for_sparks(
    task: str,
    context: Dict[str, Any],
) -> List[SparkRequest]:
    """Analyze a task to determine if it can be parallelized with sparks.
    
    This is a simple heuristic-based analyzer. In production, this could
    use an LLM to intelligently decompose tasks.
    
    Returns:
        List of SparkRequests for parallel subtasks
    """
    requests = []
    
    # Check for list processing patterns
    for key, value in context.items():
        if isinstance(value, list) and len(value) > 1:
            # Potential fan-out: process each item in parallel
            for i, item in enumerate(value):
                requests.append(SparkRequest(
                    parent_id="",  # Will be set by caller
                    task=f"Process item {i+1}/{len(value)}: {task}",
                    context={key: item, "index": i, "total": len(value)},
                    priority=i,  # Process in order if needed
                ))
    
    return requests


def create_spark_node_spec(
    spark: SparkNode,
    default_agent: Optional[str] = None,
) -> NodeSpec:
    """Create a NodeSpec for a spawned Spark.
    
    This allows the spark to be tracked in the scheduler alongside
    static nodes if needed.
    
    Uses model_construct() to bypass validation since SPARK nodes
    can only be created programmatically at runtime, not in user YAML.
    """
    # Use model_construct to bypass the validator that blocks SPARK kind
    # from user-defined specs. This is intentional for runtime-created sparks.
    return NodeSpec.model_construct(
        id=spark.id,
        kind=NodeKind.SPARK,
        name=f"Spark: {spark.task[:30]}...",
        description=spark.task,
        parent=spark.parent_id,
        agent=default_agent,
        capabilities=["execute", "report"],
    )
