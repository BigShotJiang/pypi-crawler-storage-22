"""Notification system for Smartify events.

Supports webhook notifications for:
- run_completed
- run_failed
- approval_needed
- breaker_tripped
"""

from smartify.notifications.webhook import (
    WebhookNotifier,
    WebhookConfig,
    WebhookEvent,
    EventType,
)

__all__ = [
    "WebhookNotifier",
    "WebhookConfig", 
    "WebhookEvent",
    "EventType",
]
