"""Resume manager for recovering incomplete grid runs.

Handles:
1. Scanning for incomplete runs on startup
2. Reconstructing GridRun from checkpoint
3. Resuming execution from last checkpoint
4. Background worker for webhook retries
"""

import asyncio
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import yaml
import httpx

from smartify.state.checkpoint import (
    CheckpointStore,
    Checkpoint,
    CheckpointStatus,
    WebhookRetryJob,
    WebhookDeliveryStatus,
    get_checkpoint_store,
)

if TYPE_CHECKING:
    from smartify.engine.orchestrator import Orchestrator, GridRun

logger = logging.getLogger(__name__)


class ResumeManager:
    """Manages run recovery and webhook retry.
    
    Usage:
        manager = ResumeManager(orchestrator)
        
        # On startup, resume any incomplete runs
        await manager.recover_incomplete_runs()
        
        # Start background webhook retry worker
        await manager.start_webhook_worker()
    """
    
    def __init__(
        self,
        orchestrator: "Orchestrator",
        checkpoint_store: Optional[CheckpointStore] = None,
        webhook_retry_interval: float = 30.0,
        max_resume_attempts: int = 3,
    ):
        self.orchestrator = orchestrator
        self.store = checkpoint_store or get_checkpoint_store()
        self.webhook_retry_interval = webhook_retry_interval
        self.max_resume_attempts = max_resume_attempts
        
        self._webhook_worker_task: Optional[asyncio.Task] = None
        self._shutdown = False
    
    async def recover_incomplete_runs(self) -> List[str]:
        """Scan for and resume incomplete runs.
        
        Returns list of run IDs that were resumed.
        """
        resumable = self.store.get_resumable_runs()
        
        if not resumable:
            logger.info("No incomplete runs to resume")
            return []
        
        logger.info(f"Found {len(resumable)} incomplete run(s) to resume")
        
        resumed = []
        for checkpoint in resumable:
            try:
                if checkpoint.resume_count >= self.max_resume_attempts:
                    logger.warning(
                        f"Run {checkpoint.run_id} exceeded max resume attempts "
                        f"({checkpoint.resume_count}), marking as failed"
                    )
                    self.store.mark_failed(
                        checkpoint.run_id,
                        f"Exceeded max resume attempts ({self.max_resume_attempts})"
                    )
                    continue
                
                await self._resume_run(checkpoint)
                resumed.append(checkpoint.run_id)
                
            except Exception as e:
                logger.error(f"Failed to resume run {checkpoint.run_id}: {e}")
                self.store.mark_failed(checkpoint.run_id, str(e))
        
        return resumed
    
    async def _resume_run(self, checkpoint: Checkpoint) -> None:
        """Resume a single run from checkpoint."""
        logger.info(
            f"Resuming run {checkpoint.run_id} "
            f"(attempt {checkpoint.resume_count + 1}, "
            f"{len(checkpoint.completed_nodes)} nodes completed)"
        )
        
        # Increment resume count
        self.store.increment_resume_count(checkpoint.run_id)
        
        # Parse grid YAML
        grid_dict = yaml.safe_load(checkpoint.grid_yaml)
        
        # Load grid through orchestrator
        run = await self.orchestrator.load_grid(
            source=grid_dict,
            inputs=checkpoint.inputs,
        )
        
        # Restore context state
        run.context.outputs = checkpoint.outputs
        run.context.total_tokens = checkpoint.total_tokens
        run.context.total_cost = checkpoint.total_cost
        
        # Mark completed nodes in scheduler
        for node_id in checkpoint.completed_nodes:
            if node_id in run.scheduler.nodes:
                output = checkpoint.outputs.get(node_id, {})
                run.scheduler.mark_completed(node_id, output)
        
        # Mark failed nodes
        for node_id in checkpoint.failed_nodes:
            if node_id in run.scheduler.nodes:
                run.scheduler.mark_failed(node_id, "Failed in previous run")
        
        # Energize and continue execution
        await self.orchestrator.energize(run)
        
        logger.info(f"Resuming execution for run {checkpoint.run_id}")
        
        # Execute (this will continue from where we left off)
        try:
            await self.orchestrator.execute(run)
            self.store.mark_completed(checkpoint.run_id)
        except Exception as e:
            self.store.mark_failed(checkpoint.run_id, str(e))
            raise
    
    async def start_webhook_worker(self) -> None:
        """Start the background webhook retry worker."""
        if self._webhook_worker_task is not None:
            logger.warning("Webhook worker already running")
            return
        
        self._shutdown = False
        self._webhook_worker_task = asyncio.create_task(self._webhook_worker_loop())
        logger.info("Webhook retry worker started")
    
    async def stop_webhook_worker(self) -> None:
        """Stop the webhook retry worker."""
        self._shutdown = True
        
        if self._webhook_worker_task:
            self._webhook_worker_task.cancel()
            try:
                await self._webhook_worker_task
            except asyncio.CancelledError:
                pass
            self._webhook_worker_task = None
        
        logger.info("Webhook retry worker stopped")
    
    async def _webhook_worker_loop(self) -> None:
        """Background loop for retrying failed webhooks."""
        while not self._shutdown:
            try:
                await self._process_webhook_retries()
            except Exception as e:
                logger.error(f"Webhook worker error: {e}")
            
            await asyncio.sleep(self.webhook_retry_interval)
    
    async def _process_webhook_retries(self) -> int:
        """Process pending webhook retries. Returns count processed."""
        jobs = self.store.get_pending_webhook_jobs(limit=50)
        
        if not jobs:
            return 0
        
        logger.debug(f"Processing {len(jobs)} webhook retry job(s)")
        
        processed = 0
        for job in jobs:
            try:
                success = await self._deliver_webhook(job)
                
                if success:
                    self.store.mark_webhook_delivered(job.job_id)
                    logger.info(f"Webhook job {job.job_id} delivered successfully")
                else:
                    self.store.mark_webhook_failed(
                        job.job_id,
                        "Delivery failed",
                        retry_delay_seconds=60.0,
                    )
                
                processed += 1
                
            except Exception as e:
                logger.error(f"Error processing webhook job {job.job_id}: {e}")
                self.store.mark_webhook_failed(job.job_id, str(e))
        
        return processed
    
    async def _deliver_webhook(self, job: WebhookRetryJob) -> bool:
        """Attempt to deliver a webhook."""
        import hashlib
        import hmac
        import json
        
        body = json.dumps(job.payload)
        
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Smartify-Webhook/1.0",
            "X-Smartify-Event": job.event_type,
            "X-Smartify-Retry-Attempt": str(job.attempts + 1),
            **job.headers,
        }
        
        # Add signature if secret configured
        if job.secret:
            signature = hmac.new(
                job.secret.encode('utf-8'),
                body.encode('utf-8'),
                hashlib.sha256,
            ).hexdigest()
            headers["X-Smartify-Signature"] = f"sha256={signature}"
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    job.webhook_url,
                    content=body,
                    headers=headers,
                    timeout=30.0,
                )
                
                return 200 <= response.status_code < 300
                
        except Exception as e:
            logger.warning(f"Webhook delivery failed: {e}")
            return False
    
    def queue_failed_webhook(
        self,
        event_type: str,
        grid_id: str,
        webhook_url: str,
        payload: Dict[str, Any],
        headers: Dict[str, str],
        secret: Optional[str] = None,
        max_attempts: int = 3,
    ) -> None:
        """Queue a failed webhook for retry."""
        self.store.queue_webhook_retry(
            event_type=event_type,
            grid_id=grid_id,
            webhook_url=webhook_url,
            payload=payload,
            headers=headers,
            secret=secret,
            max_attempts=max_attempts,
        )
    
    def get_queue_stats(self) -> Dict[str, int]:
        """Get webhook queue statistics."""
        return self.store.get_queue_stats()
    
    async def cleanup(self, days: int = 7) -> Dict[str, int]:
        """Clean up old data."""
        webhook_deleted = self.store.cleanup_old_jobs(days=days)
        
        return {
            "webhook_jobs_deleted": webhook_deleted,
        }


# Integration helpers

def create_checkpointed_orchestrator(
    db_path: str = "smartify_state.db",
) -> tuple["Orchestrator", "ResumeManager", CheckpointStore]:
    """Create an orchestrator with checkpoint support.
    
    Returns (orchestrator, resume_manager, checkpoint_store) tuple.
    """
    from smartify.engine.orchestrator import Orchestrator
    
    store = CheckpointStore(db_path)
    orchestrator = Orchestrator()
    manager = ResumeManager(orchestrator, store)
    
    return orchestrator, manager, store
