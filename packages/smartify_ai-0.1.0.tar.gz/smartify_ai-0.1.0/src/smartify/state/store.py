"""State persistence for Smartify runs.

Provides storage backends for:
- Run state (grid + execution state)
- Node outputs
- Event logs
"""

import json
import logging
import sqlite3
from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from enum import Enum

logger = logging.getLogger(__name__)


class RunStatus(str, Enum):
    """Status of a grid run."""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


@dataclass
class RunRecord:
    """Record of a grid run."""
    run_id: str
    grid_id: str
    grid_name: str
    status: RunStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    total_tokens: int = 0
    total_cost: float = 0.0
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['status'] = self.status.value
        d['created_at'] = self.created_at.isoformat() if self.created_at else None
        d['started_at'] = self.started_at.isoformat() if self.started_at else None
        d['completed_at'] = self.completed_at.isoformat() if self.completed_at else None
        return d
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RunRecord":
        return cls(
            run_id=d['run_id'],
            grid_id=d['grid_id'],
            grid_name=d['grid_name'],
            status=RunStatus(d['status']),
            created_at=datetime.fromisoformat(d['created_at']) if d['created_at'] else datetime.now(),
            started_at=datetime.fromisoformat(d['started_at']) if d.get('started_at') else None,
            completed_at=datetime.fromisoformat(d['completed_at']) if d.get('completed_at') else None,
            total_tokens=d.get('total_tokens', 0),
            total_cost=d.get('total_cost', 0.0),
            error=d.get('error'),
            metadata=d.get('metadata'),
        )


@dataclass
class NodeOutput:
    """Output from a node execution."""
    run_id: str
    node_id: str
    success: bool
    output: Optional[Dict[str, Any]]
    error: Optional[str]
    started_at: datetime
    completed_at: datetime
    tokens_used: int = 0


class StateStore(ABC):
    """Abstract base class for state storage."""
    
    @abstractmethod
    def save_run(self, run: RunRecord) -> None:
        """Save or update a run record."""
        pass
    
    @abstractmethod
    def get_run(self, run_id: str) -> Optional[RunRecord]:
        """Get a run by ID."""
        pass
    
    @abstractmethod
    def list_runs(
        self,
        status: Optional[RunStatus] = None,
        grid_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[RunRecord]:
        """List runs with optional filters."""
        pass
    
    @abstractmethod
    def delete_run(self, run_id: str) -> bool:
        """Delete a run and its data."""
        pass
    
    @abstractmethod
    def save_node_output(self, output: NodeOutput) -> None:
        """Save node output."""
        pass
    
    @abstractmethod
    def get_node_outputs(self, run_id: str) -> List[NodeOutput]:
        """Get all node outputs for a run."""
        pass


class InMemoryStore(StateStore):
    """In-memory state store for testing and development."""
    
    def __init__(self):
        self._runs: Dict[str, RunRecord] = {}
        self._outputs: Dict[str, List[NodeOutput]] = {}
    
    def save_run(self, run: RunRecord) -> None:
        self._runs[run.run_id] = run
    
    def get_run(self, run_id: str) -> Optional[RunRecord]:
        return self._runs.get(run_id)
    
    def list_runs(
        self,
        status: Optional[RunStatus] = None,
        grid_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[RunRecord]:
        runs = list(self._runs.values())
        
        if status:
            runs = [r for r in runs if r.status == status]
        if grid_id:
            runs = [r for r in runs if r.grid_id == grid_id]
        
        # Sort by created_at descending
        runs.sort(key=lambda r: r.created_at, reverse=True)
        
        return runs[:limit]
    
    def delete_run(self, run_id: str) -> bool:
        if run_id in self._runs:
            del self._runs[run_id]
            self._outputs.pop(run_id, None)
            return True
        return False
    
    def save_node_output(self, output: NodeOutput) -> None:
        if output.run_id not in self._outputs:
            self._outputs[output.run_id] = []
        self._outputs[output.run_id].append(output)
    
    def get_node_outputs(self, run_id: str) -> List[NodeOutput]:
        return self._outputs.get(run_id, [])


class SQLiteStore(StateStore):
    """SQLite-based persistent state store."""
    
    def __init__(self, db_path: str = "smartify_runs.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self) -> None:
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS runs (
                    run_id TEXT PRIMARY KEY,
                    grid_id TEXT NOT NULL,
                    grid_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    completed_at TEXT,
                    total_tokens INTEGER DEFAULT 0,
                    total_cost REAL DEFAULT 0.0,
                    error TEXT,
                    metadata TEXT
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS node_outputs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    node_id TEXT NOT NULL,
                    success INTEGER NOT NULL,
                    output TEXT,
                    error TEXT,
                    started_at TEXT NOT NULL,
                    completed_at TEXT NOT NULL,
                    tokens_used INTEGER DEFAULT 0,
                    FOREIGN KEY (run_id) REFERENCES runs(run_id)
                )
            """)
            
            conn.execute("CREATE INDEX IF NOT EXISTS idx_runs_status ON runs(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_runs_grid ON runs(grid_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_outputs_run ON node_outputs(run_id)")
            
            conn.commit()
    
    def save_run(self, run: RunRecord) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO runs 
                (run_id, grid_id, grid_name, status, created_at, started_at, 
                 completed_at, total_tokens, total_cost, error, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                run.run_id,
                run.grid_id,
                run.grid_name,
                run.status.value,
                run.created_at.isoformat(),
                run.started_at.isoformat() if run.started_at else None,
                run.completed_at.isoformat() if run.completed_at else None,
                run.total_tokens,
                run.total_cost,
                run.error,
                json.dumps(run.metadata) if run.metadata else None,
            ))
            conn.commit()
    
    def get_run(self, run_id: str) -> Optional[RunRecord]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM runs WHERE run_id = ?", (run_id,)
            )
            row = cursor.fetchone()
            
            if not row:
                return None
            
            return RunRecord(
                run_id=row['run_id'],
                grid_id=row['grid_id'],
                grid_name=row['grid_name'],
                status=RunStatus(row['status']),
                created_at=datetime.fromisoformat(row['created_at']),
                started_at=datetime.fromisoformat(row['started_at']) if row['started_at'] else None,
                completed_at=datetime.fromisoformat(row['completed_at']) if row['completed_at'] else None,
                total_tokens=row['total_tokens'],
                total_cost=row['total_cost'],
                error=row['error'],
                metadata=json.loads(row['metadata']) if row['metadata'] else None,
            )
    
    def list_runs(
        self,
        status: Optional[RunStatus] = None,
        grid_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[RunRecord]:
        query = "SELECT * FROM runs WHERE 1=1"
        params = []
        
        if status:
            query += " AND status = ?"
            params.append(status.value)
        if grid_id:
            query += " AND grid_id = ?"
            params.append(grid_id)
        
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(query, params)
            
            runs = []
            for row in cursor:
                runs.append(RunRecord(
                    run_id=row['run_id'],
                    grid_id=row['grid_id'],
                    grid_name=row['grid_name'],
                    status=RunStatus(row['status']),
                    created_at=datetime.fromisoformat(row['created_at']),
                    started_at=datetime.fromisoformat(row['started_at']) if row['started_at'] else None,
                    completed_at=datetime.fromisoformat(row['completed_at']) if row['completed_at'] else None,
                    total_tokens=row['total_tokens'],
                    total_cost=row['total_cost'],
                    error=row['error'],
                    metadata=json.loads(row['metadata']) if row['metadata'] else None,
                ))
            
            return runs
    
    def delete_run(self, run_id: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("DELETE FROM runs WHERE run_id = ?", (run_id,))
            conn.execute("DELETE FROM node_outputs WHERE run_id = ?", (run_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    def save_node_output(self, output: NodeOutput) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO node_outputs 
                (run_id, node_id, success, output, error, started_at, completed_at, tokens_used)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                output.run_id,
                output.node_id,
                1 if output.success else 0,
                json.dumps(output.output) if output.output else None,
                output.error,
                output.started_at.isoformat(),
                output.completed_at.isoformat(),
                output.tokens_used,
            ))
            conn.commit()
    
    def get_node_outputs(self, run_id: str) -> List[NodeOutput]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM node_outputs WHERE run_id = ? ORDER BY started_at",
                (run_id,)
            )
            
            outputs = []
            for row in cursor:
                outputs.append(NodeOutput(
                    run_id=row['run_id'],
                    node_id=row['node_id'],
                    success=bool(row['success']),
                    output=json.loads(row['output']) if row['output'] else None,
                    error=row['error'],
                    started_at=datetime.fromisoformat(row['started_at']),
                    completed_at=datetime.fromisoformat(row['completed_at']),
                    tokens_used=row['tokens_used'],
                ))
            
            return outputs


# Default store factory
_default_store: Optional[StateStore] = None


def get_default_store() -> StateStore:
    """Get or create the default state store."""
    global _default_store
    if _default_store is None:
        _default_store = InMemoryStore()
    return _default_store


def set_default_store(store: StateStore) -> None:
    """Set the default state store."""
    global _default_store
    _default_store = store
