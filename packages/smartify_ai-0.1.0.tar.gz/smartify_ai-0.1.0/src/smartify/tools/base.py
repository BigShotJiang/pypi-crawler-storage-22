"""Base tool interface and registry for Smartify.

Tools are the mechanism by which LLM nodes interact with the external world.
Each tool defines:
- A unique name
- A description (for LLM understanding)
- Input schema (JSON Schema for parameters)
- An async execute method
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Type

logger = logging.getLogger(__name__)


@dataclass
class ToolResult:
    """Result from tool execution."""
    success: bool
    output: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "output": self.output,
            "error": self.error,
            **self.metadata,
        }


class Tool(ABC):
    """Base class for all Smartify tools."""
    
    # Tool metadata - override in subclasses
    name: str = "base_tool"
    description: str = "Base tool description"
    
    @property
    @abstractmethod
    def parameters(self) -> Dict[str, Any]:
        """JSON Schema for tool parameters.
        
        Example:
            {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"},
                },
                "required": ["path"]
            }
        """
        pass
    
    @abstractmethod
    async def execute(self, **kwargs) -> ToolResult:
        """Execute the tool with given parameters.
        
        Args:
            **kwargs: Parameters matching the schema
            
        Returns:
            ToolResult with success status and output/error
        """
        pass
    
    def to_openai_format(self) -> Dict[str, Any]:
        """Convert to OpenAI function calling format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            }
        }
    
    def to_anthropic_format(self) -> Dict[str, Any]:
        """Convert to Anthropic tool format."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.parameters,
        }


class ToolRegistry:
    """Registry for available tools.
    
    Manages tool registration, lookup, and execution.
    
    Example:
        registry = ToolRegistry()
        registry.register(ShellTool())
        registry.register(FileReadTool())
        
        result = await registry.execute("shell", command="ls -la")
    """
    
    def __init__(self):
        self._tools: Dict[str, Tool] = {}
    
    def register(self, tool: Tool) -> None:
        """Register a tool."""
        if tool.name in self._tools:
            logger.warning(f"Overwriting existing tool: {tool.name}")
        self._tools[tool.name] = tool
        logger.debug(f"Registered tool: {tool.name}")
    
    def register_all(self, tools: List[Tool]) -> None:
        """Register multiple tools."""
        for tool in tools:
            self.register(tool)
    
    def get(self, name: str) -> Optional[Tool]:
        """Get a tool by name."""
        return self._tools.get(name)
    
    def list_tools(self) -> List[str]:
        """List all registered tool names."""
        return list(self._tools.keys())
    
    def get_all(self) -> List[Tool]:
        """Get all registered tools."""
        return list(self._tools.values())
    
    def to_openai_format(self, names: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Get tools in OpenAI function calling format.
        
        Args:
            names: Optional list of tool names to include. If None, includes all.
        """
        tools = self._tools.values()
        if names:
            tools = [t for t in tools if t.name in names]
        return [t.to_openai_format() for t in tools]
    
    def to_anthropic_format(self, names: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Get tools in Anthropic format."""
        tools = self._tools.values()
        if names:
            tools = [t for t in tools if t.name in names]
        return [t.to_anthropic_format() for t in tools]
    
    async def execute(self, name: str, **kwargs) -> ToolResult:
        """Execute a tool by name.
        
        Args:
            name: Tool name
            **kwargs: Tool parameters
            
        Returns:
            ToolResult
            
        Raises:
            ValueError: If tool not found
        """
        tool = self._tools.get(name)
        if not tool:
            return ToolResult(
                success=False,
                error=f"Unknown tool: {name}. Available: {self.list_tools()}"
            )
        
        try:
            logger.debug(f"Executing tool {name} with args: {kwargs}")
            result = await tool.execute(**kwargs)
            logger.debug(f"Tool {name} result: success={result.success}")
            return result
        except Exception as e:
            logger.error(f"Tool {name} execution error: {e}")
            return ToolResult(
                success=False,
                error=f"Tool execution failed: {str(e)}"
            )


# Global default registry
_default_registry: Optional[ToolRegistry] = None


def get_default_registry() -> ToolRegistry:
    """Get or create the default tool registry."""
    global _default_registry
    if _default_registry is None:
        _default_registry = ToolRegistry()
    return _default_registry


def register_tool(tool: Tool) -> None:
    """Register a tool in the default registry."""
    get_default_registry().register(tool)
