"""Builtin tools for Smartify runtime."""

from typing import List, Optional

from smartify.tools.base import Tool, ToolRegistry
from smartify.tools.builtin.shell import ShellTool
from smartify.tools.builtin.file import (
    FileReadTool,
    FileWriteTool,
    FileListTool,
    FileDeleteTool,
)
from smartify.tools.builtin.http import HttpTool


__all__ = [
    "ShellTool",
    "FileReadTool",
    "FileWriteTool",
    "FileListTool",
    "FileDeleteTool",
    "HttpTool",
    "get_builtin_tools",
    "create_builtin_registry",
]


def get_builtin_tools(
    base_path: Optional[str] = None,
    enable_shell: bool = True,
    enable_file: bool = True,
    enable_http: bool = True,
) -> List[Tool]:
    """Get all builtin tools with optional configuration.
    
    Args:
        base_path: Base path for file operations (sandbox)
        enable_shell: Enable shell command tool
        enable_file: Enable file operation tools
        enable_http: Enable HTTP request tool
        
    Returns:
        List of configured Tool instances
    """
    tools = []
    
    if enable_shell:
        tools.append(ShellTool(working_dir=base_path))
    
    if enable_file:
        tools.extend([
            FileReadTool(base_path=base_path),
            FileWriteTool(base_path=base_path),
            FileListTool(base_path=base_path),
            FileDeleteTool(base_path=base_path),
        ])
    
    if enable_http:
        tools.append(HttpTool())
    
    return tools


def create_builtin_registry(
    base_path: Optional[str] = None,
    **kwargs
) -> ToolRegistry:
    """Create a ToolRegistry with all builtin tools.
    
    Args:
        base_path: Base path for file operations
        **kwargs: Passed to get_builtin_tools
        
    Returns:
        Configured ToolRegistry
    """
    registry = ToolRegistry()
    registry.register_all(get_builtin_tools(base_path=base_path, **kwargs))
    return registry
