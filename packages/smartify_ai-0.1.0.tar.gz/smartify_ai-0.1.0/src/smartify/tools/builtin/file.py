"""File operation tools."""

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from smartify.tools.base import Tool, ToolResult

logger = logging.getLogger(__name__)


class FileReadTool(Tool):
    """Read file contents."""
    
    name = "file_read"
    description = "Read the contents of a file. Returns the file content as text."
    
    def __init__(
        self,
        base_path: Optional[str] = None,
        max_size_bytes: int = 10 * 1024 * 1024,  # 10MB
    ):
        """Initialize file read tool.
        
        Args:
            base_path: If set, all paths are relative to this base
            max_size_bytes: Maximum file size to read
        """
        self.base_path = Path(base_path).resolve() if base_path else None
        self.max_size_bytes = max_size_bytes
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to read"
                },
                "encoding": {
                    "type": "string",
                    "description": "File encoding (default: utf-8)"
                },
            },
            "required": ["path"]
        }
    
    def _resolve_path(self, path: str) -> Path:
        """Resolve and validate path."""
        p = Path(path)
        if self.base_path:
            if p.is_absolute():
                return p.resolve()
            else:
                return (self.base_path / p).resolve()
        return p.resolve()
    
    def _check_path_escape(self, resolved: Path) -> bool:
        """Check if resolved path escapes base_path. Returns True if escape detected."""
        if not self.base_path:
            return False
        try:
            resolved.relative_to(self.base_path)
            return False
        except ValueError:
            return True
    
    async def execute(
        self,
        path: str,
        encoding: str = "utf-8",
        **kwargs
    ) -> ToolResult:
        """Read a file.
        
        Args:
            path: File path
            encoding: Text encoding
            
        Returns:
            ToolResult with file contents
        """
        try:
            resolved = self._resolve_path(path)
            
            # Security: check path doesn't escape base_path
            if self._check_path_escape(resolved):
                return ToolResult(
                    success=False,
                    error=f"Path escapes allowed directory: {path}"
                )
            
            if not resolved.exists():
                return ToolResult(
                    success=False,
                    error=f"File not found: {path}"
                )
            
            if not resolved.is_file():
                return ToolResult(
                    success=False,
                    error=f"Not a file: {path}"
                )
            
            # Check size
            size = resolved.stat().st_size
            if size > self.max_size_bytes:
                return ToolResult(
                    success=False,
                    error=f"File too large: {size} bytes (max: {self.max_size_bytes})"
                )
            
            content = resolved.read_text(encoding=encoding)
            
            return ToolResult(
                success=True,
                output=content,
                metadata={
                    "path": str(resolved),
                    "size": size,
                    "encoding": encoding,
                }
            )
            
        except UnicodeDecodeError as e:
            return ToolResult(
                success=False,
                error=f"Failed to decode file with encoding {encoding}: {e}"
            )
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Failed to read file: {str(e)}"
            )


class FileWriteTool(Tool):
    """Write content to a file."""
    
    name = "file_write"
    description = "Write content to a file. Creates the file if it doesn't exist, or overwrites if it does."
    
    def __init__(
        self,
        base_path: Optional[str] = None,
        create_dirs: bool = True,
    ):
        """Initialize file write tool.
        
        Args:
            base_path: If set, all paths are relative to this base
            create_dirs: Create parent directories if they don't exist
        """
        self.base_path = Path(base_path).resolve() if base_path else None
        self.create_dirs = create_dirs
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to write"
                },
                "content": {
                    "type": "string",
                    "description": "Content to write to the file"
                },
                "append": {
                    "type": "boolean",
                    "description": "Append to file instead of overwriting (default: false)"
                },
                "encoding": {
                    "type": "string",
                    "description": "File encoding (default: utf-8)"
                },
            },
            "required": ["path", "content"]
        }
    
    def _resolve_path(self, path: str) -> Path:
        """Resolve and validate path."""
        p = Path(path)
        if self.base_path:
            if p.is_absolute():
                return p.resolve()
            else:
                return (self.base_path / p).resolve()
        return p.resolve()
    
    def _check_path_escape(self, resolved: Path) -> bool:
        """Check if resolved path escapes base_path."""
        if not self.base_path:
            return False
        try:
            resolved.relative_to(self.base_path)
            return False
        except ValueError:
            return True
    
    async def execute(
        self,
        path: str,
        content: str,
        append: bool = False,
        encoding: str = "utf-8",
        **kwargs
    ) -> ToolResult:
        """Write to a file.
        
        Args:
            path: File path
            content: Content to write
            append: Append instead of overwrite
            encoding: Text encoding
            
        Returns:
            ToolResult with write status
        """
        try:
            resolved = self._resolve_path(path)
            
            # Security: check path doesn't escape base_path
            if self._check_path_escape(resolved):
                return ToolResult(
                    success=False,
                    error=f"Path escapes allowed directory: {path}"
                )
            
            # Create parent directories
            if self.create_dirs:
                resolved.parent.mkdir(parents=True, exist_ok=True)
            
            mode = "a" if append else "w"
            with open(resolved, mode, encoding=encoding) as f:
                f.write(content)
            
            size = resolved.stat().st_size
            
            return ToolResult(
                success=True,
                output={
                    "path": str(resolved),
                    "size": size,
                    "mode": "appended" if append else "written",
                },
                metadata={"path": str(resolved)}
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Failed to write file: {str(e)}"
            )


class FileListTool(Tool):
    """List files in a directory."""
    
    name = "file_list"
    description = "List files and directories in a path. Returns names and metadata."
    
    def __init__(self, base_path: Optional[str] = None):
        self.base_path = Path(base_path).resolve() if base_path else None
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path to list (default: current directory)"
                },
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern to filter files (e.g., '*.py')"
                },
                "recursive": {
                    "type": "boolean",
                    "description": "List recursively (default: false)"
                },
            },
            "required": []
        }
    
    def _resolve_path(self, path: str) -> Path:
        p = Path(path) if path else Path(".")
        if self.base_path:
            if p.is_absolute():
                return p.resolve()
            else:
                return (self.base_path / p).resolve()
        return p.resolve()
    
    async def execute(
        self,
        path: str = ".",
        pattern: Optional[str] = None,
        recursive: bool = False,
        **kwargs
    ) -> ToolResult:
        """List directory contents.
        
        Args:
            path: Directory path
            pattern: Glob pattern
            recursive: List recursively
            
        Returns:
            ToolResult with file listing
        """
        try:
            resolved = self._resolve_path(path)
            
            if not resolved.exists():
                return ToolResult(
                    success=False,
                    error=f"Path not found: {path}"
                )
            
            if not resolved.is_dir():
                return ToolResult(
                    success=False,
                    error=f"Not a directory: {path}"
                )
            
            # Get entries
            if pattern:
                if recursive:
                    entries = list(resolved.rglob(pattern))
                else:
                    entries = list(resolved.glob(pattern))
            else:
                if recursive:
                    entries = list(resolved.rglob("*"))
                else:
                    entries = list(resolved.iterdir())
            
            # Build result
            files = []
            for entry in sorted(entries):
                try:
                    stat = entry.stat()
                    files.append({
                        "name": entry.name,
                        "path": str(entry.relative_to(resolved) if not recursive else entry),
                        "type": "dir" if entry.is_dir() else "file",
                        "size": stat.st_size if entry.is_file() else None,
                    })
                except (OSError, ValueError):
                    continue
            
            return ToolResult(
                success=True,
                output={
                    "path": str(resolved),
                    "count": len(files),
                    "entries": files,
                },
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Failed to list directory: {str(e)}"
            )


class FileDeleteTool(Tool):
    """Delete a file."""
    
    name = "file_delete"
    description = "Delete a file. Use with caution."
    
    def __init__(
        self,
        base_path: Optional[str] = None,
        allow_directories: bool = False,
    ):
        self.base_path = Path(base_path).resolve() if base_path else None
        self.allow_directories = allow_directories
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to delete"
                },
            },
            "required": ["path"]
        }
    
    def _resolve_path(self, path: str) -> Path:
        p = Path(path)
        if self.base_path:
            if p.is_absolute():
                return p.resolve()
            else:
                return (self.base_path / p).resolve()
        return p.resolve()
    
    def _check_path_escape(self, resolved: Path) -> bool:
        """Check if resolved path escapes base_path."""
        if not self.base_path:
            return False
        try:
            resolved.relative_to(self.base_path)
            return False
        except ValueError:
            return True
    
    async def execute(self, path: str, **kwargs) -> ToolResult:
        """Delete a file.
        
        Args:
            path: File path to delete
            
        Returns:
            ToolResult with deletion status
        """
        try:
            resolved = self._resolve_path(path)
            
            # Security: check path doesn't escape base_path
            if self._check_path_escape(resolved):
                return ToolResult(
                    success=False,
                    error=f"Path escapes allowed directory: {path}"
                )
            
            if not resolved.exists():
                return ToolResult(
                    success=False,
                    error=f"File not found: {path}"
                )
            
            if resolved.is_dir():
                if not self.allow_directories:
                    return ToolResult(
                        success=False,
                        error="Directory deletion not allowed"
                    )
                import shutil
                shutil.rmtree(resolved)
            else:
                resolved.unlink()
            
            return ToolResult(
                success=True,
                output={"deleted": str(resolved)},
            )
            
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Failed to delete: {str(e)}"
            )
