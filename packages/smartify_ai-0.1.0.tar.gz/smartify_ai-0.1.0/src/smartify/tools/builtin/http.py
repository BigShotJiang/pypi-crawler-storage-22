"""HTTP request tool."""

import logging
from typing import Any, Dict, List, Optional

import httpx

from smartify.tools.base import Tool, ToolResult

logger = logging.getLogger(__name__)


class HttpTool(Tool):
    """Make HTTP requests.
    
    Supports GET, POST, PUT, PATCH, DELETE with JSON or form data.
    """
    
    name = "http"
    description = "Make an HTTP request to a URL. Supports GET, POST, PUT, PATCH, DELETE methods with JSON or form data."
    
    def __init__(
        self,
        timeout: float = 30.0,
        max_response_size: int = 5 * 1024 * 1024,  # 5MB
        allowed_hosts: Optional[List[str]] = None,
        blocked_hosts: Optional[List[str]] = None,
    ):
        """Initialize HTTP tool.
        
        Args:
            timeout: Request timeout in seconds
            max_response_size: Maximum response size to read
            allowed_hosts: If set, only these hosts are allowed
            blocked_hosts: Hosts to block (e.g., internal IPs)
        """
        self.timeout = timeout
        self.max_response_size = max_response_size
        self.allowed_hosts = allowed_hosts
        self.blocked_hosts = blocked_hosts or [
            "localhost",
            "127.0.0.1",
            "0.0.0.0",
            "169.254.",  # Link-local
            "10.",       # Private
            "172.16.",   # Private
            "192.168.",  # Private
        ]
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL to request"
                },
                "method": {
                    "type": "string",
                    "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"],
                    "description": "HTTP method (default: GET)"
                },
                "headers": {
                    "type": "object",
                    "description": "HTTP headers as key-value pairs"
                },
                "json": {
                    "type": "object",
                    "description": "JSON body for POST/PUT/PATCH"
                },
                "data": {
                    "type": "object",
                    "description": "Form data for POST/PUT/PATCH"
                },
                "params": {
                    "type": "object",
                    "description": "URL query parameters"
                },
            },
            "required": ["url"]
        }
    
    def _check_host(self, url: str) -> Optional[str]:
        """Check if host is allowed. Returns error message if blocked."""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            host = parsed.hostname or ""
            
            # Check blocked hosts
            for blocked in self.blocked_hosts:
                if host.startswith(blocked) or host == blocked:
                    return f"Host blocked: {host}"
            
            # Check allowed hosts
            if self.allowed_hosts:
                if host not in self.allowed_hosts:
                    return f"Host not in allowlist: {host}"
            
            return None
        except Exception as e:
            return f"Invalid URL: {e}"
    
    async def execute(
        self,
        url: str,
        method: str = "GET",
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> ToolResult:
        """Make an HTTP request.
        
        Args:
            url: Request URL
            method: HTTP method
            headers: Request headers
            json: JSON body
            data: Form data
            params: Query parameters
            
        Returns:
            ToolResult with response data
        """
        # Security check
        host_error = self._check_host(url)
        if host_error:
            return ToolResult(
                success=False,
                error=host_error
            )
        
        method = method.upper()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=json,
                    data=data,
                    params=params,
                )
                
                # Check response size
                content_length = response.headers.get("content-length")
                if content_length and int(content_length) > self.max_response_size:
                    return ToolResult(
                        success=False,
                        error=f"Response too large: {content_length} bytes"
                    )
                
                # Read response
                content = response.text
                
                # Try to parse JSON
                try:
                    json_content = response.json()
                except Exception:
                    json_content = None
                
                return ToolResult(
                    success=200 <= response.status_code < 300,
                    output={
                        "status_code": response.status_code,
                        "headers": dict(response.headers),
                        "body": json_content if json_content else content,
                        "is_json": json_content is not None,
                    },
                    error=f"HTTP {response.status_code}" if response.status_code >= 400 else None,
                    metadata={
                        "url": str(response.url),
                        "method": method,
                    }
                )
                
        except httpx.TimeoutException:
            return ToolResult(
                success=False,
                error=f"Request timed out after {self.timeout}s"
            )
        except httpx.RequestError as e:
            return ToolResult(
                success=False,
                error=f"Request failed: {str(e)}"
            )
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"HTTP request error: {str(e)}"
            )
