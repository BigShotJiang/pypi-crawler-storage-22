"""Shell command execution tool."""

import asyncio
import logging
import shlex
from typing import Any, Dict, Optional

from smartify.tools.base import Tool, ToolResult

logger = logging.getLogger(__name__)


class ShellTool(Tool):
    """Execute shell commands.
    
    Runs commands in a subprocess with configurable timeout and working directory.
    """
    
    name = "shell"
    description = "Execute a shell command and return its output. Use for running CLI tools, scripts, or system commands."
    
    def __init__(
        self,
        default_timeout: float = 60.0,
        allowed_commands: Optional[list[str]] = None,
        blocked_commands: Optional[list[str]] = None,
        working_dir: Optional[str] = None,
    ):
        """Initialize shell tool.
        
        Args:
            default_timeout: Default command timeout in seconds
            allowed_commands: If set, only these command prefixes are allowed
            blocked_commands: Commands to block (e.g., ["rm -rf", "sudo"])
            working_dir: Default working directory
        """
        self.default_timeout = default_timeout
        self.allowed_commands = allowed_commands
        self.blocked_commands = blocked_commands or ["rm -rf /", "sudo rm", ":(){ :|:& };:"]
        self.working_dir = working_dir
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute"
                },
                "timeout": {
                    "type": "number",
                    "description": f"Timeout in seconds (default: {self.default_timeout})"
                },
                "working_dir": {
                    "type": "string",
                    "description": "Working directory for the command"
                },
            },
            "required": ["command"]
        }
    
    async def execute(
        self,
        command: str,
        timeout: Optional[float] = None,
        working_dir: Optional[str] = None,
        **kwargs
    ) -> ToolResult:
        """Execute a shell command.
        
        Args:
            command: Shell command to run
            timeout: Command timeout in seconds
            working_dir: Working directory
            
        Returns:
            ToolResult with stdout/stderr
        """
        # Security checks
        for blocked in self.blocked_commands:
            if blocked in command:
                return ToolResult(
                    success=False,
                    error=f"Blocked command pattern: {blocked}"
                )
        
        if self.allowed_commands:
            cmd_prefix = command.split()[0] if command.split() else ""
            if cmd_prefix not in self.allowed_commands:
                return ToolResult(
                    success=False,
                    error=f"Command not in allowlist: {cmd_prefix}"
                )
        
        timeout = timeout or self.default_timeout
        cwd = working_dir or self.working_dir
        
        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )
            
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout
            )
            
            stdout_text = stdout.decode("utf-8", errors="replace")
            stderr_text = stderr.decode("utf-8", errors="replace")
            
            return ToolResult(
                success=process.returncode == 0,
                output={
                    "stdout": stdout_text,
                    "stderr": stderr_text,
                    "exit_code": process.returncode,
                },
                error=stderr_text if process.returncode != 0 else None,
                metadata={"command": command, "cwd": cwd}
            )
            
        except asyncio.TimeoutError:
            return ToolResult(
                success=False,
                error=f"Command timed out after {timeout}s",
                metadata={"command": command}
            )
        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Command execution failed: {str(e)}",
                metadata={"command": command}
            )
