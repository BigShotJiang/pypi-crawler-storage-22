"""MCP (Model Context Protocol) integration for Smartify.

This module provides plug-and-play integration with external MCP servers,
allowing grids to use tools from any MCP-compatible server.

Install the optional dependency:
    pip install smartify[mcp]

Example usage in a grid:
    tools:
      mcpServers:
        - id: filesystem
          transport: stdio
          command: npx
          args: ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"]
          prefix: fs
"""

from smartify.tools.mcp.client import (
    McpClient,
    McpServerConfig,
    McpTransport,
)
from smartify.tools.mcp.adapter import McpToolWrapper
from smartify.tools.mcp.registry import register_mcp_server

__all__ = [
    "McpClient",
    "McpServerConfig",
    "McpTransport",
    "McpToolWrapper",
    "register_mcp_server",
]
