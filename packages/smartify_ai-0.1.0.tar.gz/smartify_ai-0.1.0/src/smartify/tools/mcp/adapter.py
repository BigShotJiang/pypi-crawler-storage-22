"""MCP tool adapter for Smartify.

Wraps MCP tools to implement the Smartify Tool interface, allowing
MCP server tools to be used seamlessly in grid execution.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, TYPE_CHECKING

from smartify.tools.base import Tool, ToolResult

if TYPE_CHECKING:
    from smartify.tools.mcp.client import McpClient, McpToolDef

logger = logging.getLogger(__name__)


class McpToolWrapper(Tool):
    """Wraps an MCP tool to implement the Smartify Tool interface.

    This adapter allows MCP server tools to be registered in the Smartify
    ToolRegistry and used by grid nodes just like builtin tools.

    Example:
        client = McpClient(config)
        await client.connect()

        tools = await client.list_tools()
        for tool_def in tools:
            wrapper = McpToolWrapper(client, tool_def, prefix="mcp")
            registry.register(wrapper)
    """

    def __init__(
        self,
        client: "McpClient",
        tool_def: "McpToolDef",
        prefix: Optional[str] = None,
    ):
        """Initialize the MCP tool wrapper.

        Args:
            client: Connected MCP client instance
            tool_def: Tool definition from MCP server
            prefix: Optional prefix for the tool name (e.g. "mcp" -> "mcp_read_file")
        """
        self._client = client
        self._tool_def = tool_def
        self._prefix = prefix

        # Build the Smartify tool name
        if prefix:
            self._name = f"{prefix}_{tool_def.name}"
        else:
            self._name = tool_def.name

        # Store the original MCP tool name for calling
        self._mcp_tool_name = tool_def.name

    @property
    def name(self) -> str:
        """Tool name (possibly prefixed)."""
        return self._name

    @property
    def description(self) -> str:
        """Tool description from MCP server."""
        return self._tool_def.description

    @property
    def parameters(self) -> Dict[str, Any]:
        """JSON Schema for tool parameters from MCP server."""
        return self._tool_def.parameters

    @property
    def mcp_server_id(self) -> str:
        """ID of the MCP server this tool belongs to."""
        return self._client.config.id

    @property
    def mcp_tool_name(self) -> str:
        """Original tool name on the MCP server."""
        return self._mcp_tool_name

    async def execute(self, **kwargs) -> ToolResult:
        """Execute the MCP tool.

        Args:
            **kwargs: Tool arguments matching the parameter schema

        Returns:
            ToolResult with success status and output/error
        """
        if not self._client.is_connected:
            return ToolResult(
                success=False,
                error=f"MCP server '{self._client.config.id}' is not connected",
            )

        logger.debug(
            f"Executing MCP tool '{self._mcp_tool_name}' on server "
            f"'{self._client.config.id}' with args: {kwargs}"
        )

        try:
            result = await self._client.call_tool(self._mcp_tool_name, kwargs)

            return ToolResult(
                success=result["success"],
                output=result["output"],
                error=result.get("error"),
                metadata={
                    "mcp_server": self._client.config.id,
                    "mcp_tool": self._mcp_tool_name,
                },
            )

        except Exception as e:
            logger.error(
                f"MCP tool execution failed: {self._mcp_tool_name} - {e}"
            )
            return ToolResult(
                success=False,
                error=f"MCP tool execution failed: {e}",
                metadata={
                    "mcp_server": self._client.config.id,
                    "mcp_tool": self._mcp_tool_name,
                },
            )

    def to_openai_format(self) -> Dict[str, Any]:
        """Convert to OpenAI function calling format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    def to_anthropic_format(self) -> Dict[str, Any]:
        """Convert to Anthropic tool format."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.parameters,
        }

    def __repr__(self) -> str:
        return (
            f"McpToolWrapper(name={self.name!r}, "
            f"mcp_server={self._client.config.id!r}, "
            f"mcp_tool={self._mcp_tool_name!r})"
        )
