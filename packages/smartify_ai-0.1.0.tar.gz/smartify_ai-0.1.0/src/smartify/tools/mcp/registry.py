"""MCP registry integration for Smartify.

Functions for registering MCP server tools into the Smartify ToolRegistry.
"""

from __future__ import annotations

import logging
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from smartify.tools.base import ToolRegistry
    from smartify.tools.mcp.client import McpClient, McpServerConfig

logger = logging.getLogger(__name__)


async def register_mcp_server(
    registry: "ToolRegistry",
    config: "McpServerConfig",
    client: Optional["McpClient"] = None,
) -> List[str]:
    """Connect to an MCP server and register its tools in the registry.

    This function:
    1. Creates an MCP client (or uses provided one)
    2. Connects to the MCP server
    3. Lists available tools
    4. Creates McpToolWrapper for each tool
    5. Registers wrappers in the ToolRegistry

    Args:
        registry: The ToolRegistry to register tools into
        config: MCP server configuration
        client: Optional pre-created client (will connect if not connected)

    Returns:
        List of registered tool names (with prefix if configured)

    Raises:
        ImportError: If MCP SDK is not installed
        ConnectionError: If connection to MCP server fails

    Example:
        from smartify.tools import ToolRegistry
        from smartify.tools.mcp import McpServerConfig, McpTransport, register_mcp_server

        registry = ToolRegistry()

        config = McpServerConfig(
            id="filesystem",
            transport=McpTransport.STDIO,
            command="npx",
            args=["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
            prefix="fs",
        )

        tool_names = await register_mcp_server(registry, config)
        # -> ["fs_read_file", "fs_write_file", "fs_list_directory", ...]
    """
    from smartify.tools.mcp.client import McpClient
    from smartify.tools.mcp.adapter import McpToolWrapper

    # Create client if not provided
    if client is None:
        client = McpClient(config)

    # Connect if not already connected
    if not client.is_connected:
        await client.connect()

    # List tools from the server
    tool_defs = await client.list_tools()

    if not tool_defs:
        logger.warning(f"MCP server '{config.id}' has no tools")
        return []

    # Register each tool
    registered_names = []
    for tool_def in tool_defs:
        wrapper = McpToolWrapper(
            client=client,
            tool_def=tool_def,
            prefix=config.prefix,
        )
        registry.register(wrapper)
        registered_names.append(wrapper.name)

    logger.info(
        f"Registered {len(registered_names)} tools from MCP server '{config.id}': "
        f"{registered_names}"
    )

    return registered_names


async def register_mcp_servers(
    registry: "ToolRegistry",
    configs: List["McpServerConfig"],
) -> dict[str, List[str]]:
    """Register multiple MCP servers into a registry.

    Args:
        registry: The ToolRegistry to register tools into
        configs: List of MCP server configurations

    Returns:
        Dict mapping server ID to list of registered tool names

    Example:
        configs = [
            McpServerConfig(id="fs", transport=McpTransport.STDIO, ...),
            McpServerConfig(id="git", transport=McpTransport.STDIO, ...),
        ]

        results = await register_mcp_servers(registry, configs)
        # -> {"fs": ["fs_read_file", ...], "git": ["git_status", ...]}
    """
    results = {}

    for config in configs:
        try:
            tool_names = await register_mcp_server(registry, config)
            results[config.id] = tool_names
        except Exception as e:
            logger.error(f"Failed to register MCP server '{config.id}': {e}")
            results[config.id] = []

    return results
