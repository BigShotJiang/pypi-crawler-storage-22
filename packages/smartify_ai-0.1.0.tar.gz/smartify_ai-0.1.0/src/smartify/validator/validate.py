"""Grid YAML validation."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Set
import yaml
from pydantic import ValidationError

from smartify.models.grid import GridSpec, NodeKind


@dataclass
class ValidationResult:
    """Result of grid validation."""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    grid: Optional[GridSpec] = None


def validate_grid_file(path: Path) -> ValidationResult:
    """Validate a Grid YAML file."""
    errors: List[str] = []
    warnings: List[str] = []
    
    # Read file
    try:
        with open(path) as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        return ValidationResult(
            is_valid=False,
            errors=[f"YAML parse error: {e}"],
        )
    except Exception as e:
        return ValidationResult(
            is_valid=False,
            errors=[f"Failed to read file: {e}"],
        )
    
    if not data:
        return ValidationResult(
            is_valid=False,
            errors=["File is empty or contains no valid YAML"],
        )
    
    # Parse with Pydantic
    try:
        grid = GridSpec.model_validate(data)
    except ValidationError as e:
        for error in e.errors():
            loc = ".".join(str(l) for l in error["loc"])
            msg = error["msg"]
            errors.append(f"{loc}: {msg}")
        return ValidationResult(
            is_valid=False,
            errors=errors,
        )
    
    # Semantic validation
    semantic_errors, semantic_warnings = validate_semantics(grid)
    errors.extend(semantic_errors)
    warnings.extend(semantic_warnings)
    
    return ValidationResult(
        is_valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        grid=grid if len(errors) == 0 else None,
    )


def validate_semantics(grid: GridSpec) -> tuple[List[str], List[str]]:
    """Perform semantic validation on a parsed grid."""
    errors: List[str] = []
    warnings: List[str] = []
    
    nodes = grid.topology.nodes
    node_ids: Set[str] = set()
    node_map = {}
    
    # Build node map and check for duplicate IDs
    for node in nodes:
        if node.id in node_ids:
            errors.append(f"Duplicate node ID: {node.id}")
        node_ids.add(node.id)
        node_map[node.id] = node
    
    # Count controllers
    controllers = [n for n in nodes if n.kind == NodeKind.CONTROLLER]
    if len(controllers) == 0:
        errors.append("Grid must have exactly one controller node")
    elif len(controllers) > 1:
        errors.append(f"Grid must have exactly one controller node, found {len(controllers)}")
    
    # Validate parent references
    for node in nodes:
        if node.parent:
            if node.parent not in node_ids:
                errors.append(f"Node '{node.id}' references non-existent parent '{node.parent}'")
            elif node.parent == node.id:
                errors.append(f"Node '{node.id}' cannot be its own parent")
    
    # Validate controller has no parent
    for node in nodes:
        if node.kind == NodeKind.CONTROLLER and node.parent:
            errors.append(f"Controller node '{node.id}' should not have a parent")
    
    # Validate relay parents (must be controller or another relay)
    for node in nodes:
        if node.kind == NodeKind.RELAY and node.parent:
            parent = node_map.get(node.parent)
            if parent and parent.kind not in (NodeKind.CONTROLLER, NodeKind.RELAY):
                warnings.append(
                    f"Relay '{node.id}' has parent '{node.parent}' of kind '{parent.kind}', "
                    "typically relays have controller or relay parents"
                )
    
    # Validate substation parents (must be relay or controller)
    for node in nodes:
        if node.kind == NodeKind.SUBSTATION and node.parent:
            parent = node_map.get(node.parent)
            if parent and parent.kind not in (NodeKind.CONTROLLER, NodeKind.RELAY):
                warnings.append(
                    f"Substation '{node.id}' has parent '{node.parent}' of kind '{parent.kind}', "
                    "typically substations have relay or controller parents"
                )
    
    # Validate runAfter references
    for node in nodes:
        if node.runAfter:
            for dep in node.runAfter:
                if dep not in node_ids:
                    errors.append(f"Node '{node.id}' runAfter references non-existent node '{dep}'")
                if dep == node.id:
                    errors.append(f"Node '{node.id}' cannot depend on itself in runAfter")
    
    # Validate edges
    if grid.topology.edges:
        for edge in grid.topology.edges:
            from_id = edge.from_
            if from_id not in node_ids:
                errors.append(f"Edge from '{from_id}' references non-existent node")
            
            targets = edge.to if isinstance(edge.to, list) else [edge.to]
            for target in targets:
                if target not in node_ids:
                    errors.append(f"Edge to '{target}' references non-existent node")
    
    # Check for cycles (simplified check)
    # TODO: Implement full cycle detection
    
    # Validate agent references
    if grid.agents:
        agent_names = set(grid.agents.keys())
        for node in nodes:
            if node.agent and node.agent not in agent_names:
                errors.append(f"Node '{node.id}' references non-existent agent '{node.agent}'")
    
    # Validate foreach nodes have required config
    for node in nodes:
        if node.kind == NodeKind.FOREACH:
            if not node.foreach:
                errors.append(f"Foreach node '{node.id}' missing foreach configuration")
            elif not node.foreach.body.get("to"):
                errors.append(f"Foreach node '{node.id}' missing body.to target")
    
    # Validate aggregate nodes have required config
    for node in nodes:
        if node.kind == NodeKind.AGGREGATE:
            if not node.aggregate:
                errors.append(f"Aggregate node '{node.id}' missing aggregate configuration")
    
    # Warn if no guardrails defined
    if not grid.guardrails:
        warnings.append("No guardrails defined - grid will run without limits")
    
    # Warn about explicit execution mode without edges
    if grid.topology.executionMode.value == "explicit" and not grid.topology.edges:
        warnings.append(
            "executionMode is 'explicit' but no edges defined - "
            "consider using 'parent' mode or adding edges"
        )
    
    return errors, warnings


def validate_grid(data: dict) -> List[str]:
    """Validate a Grid specification dict.
    
    Returns list of error messages (empty if valid).
    """
    errors: List[str] = []
    
    if not data:
        return ["Empty grid specification"]
    
    # Pre-validation: check required top-level fields
    if "apiVersion" not in data:
        errors.append("Missing required field: apiVersion")
    if "metadata" not in data:
        errors.append("Missing required field: metadata")
    elif isinstance(data.get("metadata"), dict):
        if "id" not in data["metadata"]:
            errors.append("Missing required field: metadata.id")
    if "topology" not in data:
        errors.append("Missing required field: topology")
    elif isinstance(data.get("topology"), dict):
        if "nodes" not in data["topology"]:
            errors.append("Missing required field: topology.nodes")
    
    # If pre-validation fails, return early
    if errors:
        return errors
    
    try:
        grid = GridSpec.model_validate(data)
    except ValidationError as e:
        for error in e.errors():
            loc = ".".join(str(l) for l in error["loc"])
            msg = error["msg"]
            errors.append(f"{loc}: {msg}")
        return errors
    
    semantic_errors, _ = validate_semantics(grid)
    errors.extend(semantic_errors)
    
    return errors


def validate_yaml_string(yaml_str: str) -> ValidationResult:
    """Validate a Grid YAML string."""
    errors: List[str] = []
    warnings: List[str] = []
    
    try:
        data = yaml.safe_load(yaml_str)
    except yaml.YAMLError as e:
        return ValidationResult(
            is_valid=False,
            errors=[f"YAML parse error: {e}"],
        )
    
    if not data:
        return ValidationResult(
            is_valid=False,
            errors=["Empty or invalid YAML"],
        )
    
    try:
        grid = GridSpec.model_validate(data)
    except ValidationError as e:
        for error in e.errors():
            loc = ".".join(str(l) for l in error["loc"])
            msg = error["msg"]
            errors.append(f"{loc}: {msg}")
        return ValidationResult(
            is_valid=False,
            errors=errors,
        )
    
    semantic_errors, semantic_warnings = validate_semantics(grid)
    errors.extend(semantic_errors)
    warnings.extend(semantic_warnings)
    
    return ValidationResult(
        is_valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        grid=grid if len(errors) == 0 else None,
    )
