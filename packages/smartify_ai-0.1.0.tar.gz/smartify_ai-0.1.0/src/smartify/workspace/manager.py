"""Workspace management for isolated grid execution.

Each grid run gets its own isolated workspace directory for:
- File operations (sandboxed)
- Temporary files
- Output artifacts
"""

import logging
import shutil
import tempfile
from pathlib import Path
from typing import Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class WorkspaceManager:
    """Manages isolated workspaces for grid runs.
    
    Each run gets a unique directory under the base workspace path.
    Files created during execution are isolated to that directory.
    Cleanup happens automatically on completion (configurable).
    
    Usage:
        manager = WorkspaceManager(base_path="/tmp/smartify")
        
        # Create workspace for a run
        ws = manager.create("run-123", "my-grid")
        
        # Use workspace
        print(ws.path)  # /tmp/smartify/my-grid/run-123
        ws.write_file("output.txt", "Hello!")
        
        # Cleanup when done
        manager.cleanup("run-123")
    """
    
    def __init__(
        self,
        base_path: Optional[str] = None,
        auto_cleanup: bool = True,
        preserve_on_error: bool = True,
    ):
        """Initialize workspace manager.
        
        Args:
            base_path: Base directory for workspaces. Defaults to temp dir.
            auto_cleanup: Automatically cleanup completed runs
            preserve_on_error: Keep workspace if run failed (for debugging)
        """
        if base_path:
            self.base_path = Path(base_path)
            self.base_path.mkdir(parents=True, exist_ok=True)
        else:
            self.base_path = Path(tempfile.gettempdir()) / "smartify-workspaces"
            self.base_path.mkdir(parents=True, exist_ok=True)
        
        self.auto_cleanup = auto_cleanup
        self.preserve_on_error = preserve_on_error
        self._workspaces: dict[str, "Workspace"] = {}
        
        logger.info(f"WorkspaceManager initialized at {self.base_path}")
    
    def create(self, run_id: str, grid_id: str) -> "Workspace":
        """Create a new isolated workspace for a run.
        
        Args:
            run_id: Unique run identifier
            grid_id: Grid identifier (for organization)
            
        Returns:
            Workspace instance
        """
        # Create workspace directory: base/grid_id/run_id
        workspace_path = self.base_path / grid_id / run_id
        workspace_path.mkdir(parents=True, exist_ok=True)
        
        workspace = Workspace(
            run_id=run_id,
            grid_id=grid_id,
            path=workspace_path,
        )
        
        self._workspaces[run_id] = workspace
        logger.info(f"Created workspace for run {run_id}: {workspace_path}")
        
        return workspace
    
    def get(self, run_id: str) -> Optional["Workspace"]:
        """Get workspace for a run."""
        return self._workspaces.get(run_id)
    
    def cleanup(self, run_id: str, force: bool = False) -> bool:
        """Cleanup workspace for a run.
        
        Args:
            run_id: Run identifier
            force: Force cleanup even if preserve_on_error is set
            
        Returns:
            True if cleaned up, False if not found or preserved
        """
        workspace = self._workspaces.get(run_id)
        if not workspace:
            return False
        
        if workspace.has_error and self.preserve_on_error and not force:
            logger.info(f"Preserving workspace for failed run {run_id}")
            return False
        
        try:
            if workspace.path.exists():
                shutil.rmtree(workspace.path)
                logger.info(f"Cleaned up workspace for run {run_id}")
            
            del self._workspaces[run_id]
            return True
            
        except Exception as e:
            logger.error(f"Failed to cleanup workspace {run_id}: {e}")
            return False
    
    def list_workspaces(self) -> list[str]:
        """List all active workspace run IDs."""
        return list(self._workspaces.keys())
    
    def cleanup_all(self, force: bool = False) -> int:
        """Cleanup all workspaces.
        
        Args:
            force: Force cleanup even for failed runs
            
        Returns:
            Number of workspaces cleaned up
        """
        run_ids = list(self._workspaces.keys())
        count = 0
        for run_id in run_ids:
            if self.cleanup(run_id, force=force):
                count += 1
        return count


class Workspace:
    """An isolated workspace for a single grid run.
    
    Provides sandboxed file operations within the workspace directory.
    """
    
    def __init__(self, run_id: str, grid_id: str, path: Path):
        self.run_id = run_id
        self.grid_id = grid_id
        self.path = path
        self.created_at = datetime.now()
        self.has_error = False
        
        # Create standard subdirectories
        (self.path / "output").mkdir(exist_ok=True)
        (self.path / "temp").mkdir(exist_ok=True)
    
    @property
    def output_dir(self) -> Path:
        """Directory for output artifacts."""
        return self.path / "output"
    
    @property
    def temp_dir(self) -> Path:
        """Directory for temporary files."""
        return self.path / "temp"
    
    def resolve(self, relative_path: str) -> Path:
        """Resolve a relative path within the workspace.
        
        Raises ValueError if path escapes workspace.
        """
        resolved = (self.path / relative_path).resolve()
        
        # Security check: ensure path is within workspace
        # Note: resolve both to handle macOS /var -> /private/var symlinks
        try:
            resolved.relative_to(self.path.resolve())
        except ValueError:
            raise ValueError(f"Path escapes workspace: {relative_path}")
        
        return resolved
    
    def write_file(self, path: str, content: str, encoding: str = "utf-8") -> Path:
        """Write a file within the workspace.
        
        Args:
            path: Relative path within workspace
            content: File content
            encoding: Text encoding
            
        Returns:
            Absolute path to written file
        """
        resolved = self.resolve(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        resolved.write_text(content, encoding=encoding)
        return resolved
    
    def read_file(self, path: str, encoding: str = "utf-8") -> str:
        """Read a file from the workspace.
        
        Args:
            path: Relative path within workspace
            encoding: Text encoding
            
        Returns:
            File content
        """
        resolved = self.resolve(path)
        return resolved.read_text(encoding=encoding)
    
    def exists(self, path: str) -> bool:
        """Check if a path exists within the workspace."""
        try:
            resolved = self.resolve(path)
            return resolved.exists()
        except ValueError:
            return False
    
    def list_files(self, subdir: str = ".") -> list[Path]:
        """List files in a subdirectory."""
        resolved = self.resolve(subdir)
        if not resolved.is_dir():
            return []
        return list(resolved.iterdir())
    
    def mark_error(self) -> None:
        """Mark workspace as having an error (for preservation)."""
        self.has_error = True
    
    def cleanup_temp(self) -> None:
        """Cleanup temporary files."""
        temp_dir = self.temp_dir
        if temp_dir.exists():
            for item in temp_dir.iterdir():
                if item.is_file():
                    item.unlink()
                elif item.is_dir():
                    shutil.rmtree(item)
    
    def __repr__(self) -> str:
        return f"Workspace(run_id={self.run_id!r}, path={self.path})"
