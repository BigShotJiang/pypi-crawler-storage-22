#!/usr/bin/env python3
"""Manual E2E test: run examples/minimal.yaml with real API.

Use this for quick smoke tests against the minimal example grid.
Requires: ANTHROPIC_API_KEY

  python test_e2e.py

Or with pytest (live marker): pytest test_e2e.py -v -s
"""

import asyncio
import os
import sys

# Allow running from repo root without installing
if __name__ == "__main__" and "src" not in sys.path:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from smartify.engine.orchestrator import Orchestrator
from smartify.agents.adapters import AnthropicAdapter
from smartify.models.grid import GridState


async def main():
    print("=" * 60)
    print("Smartify Runtime E2E — examples/minimal.yaml")
    print("=" * 60)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ ANTHROPIC_API_KEY not set")
        print("   Set it with: export ANTHROPIC_API_KEY=your_key")
        return False

    print("✓ API key found")

    orchestrator = Orchestrator()
    adapter = AnthropicAdapter(api_key=api_key)
    orchestrator.register_llm_adapter("anthropic", adapter)
    orchestrator.register_llm_adapter("default", adapter)
    print("✓ Anthropic adapter registered")

    print("\n--- Loading Grid ---")
    run = await orchestrator.load_grid("examples/minimal.yaml")
    print(f"  Run ID: {run.run_id}")

    print("--- Energizing ---")
    await orchestrator.energize(run)
    print("--- Executing ---")
    result = await orchestrator.execute(run)

    print("\n--- Result ---")
    print(f"  State: {result.get('state')}")
    print(f"  Total tokens: {result.get('total_tokens')}")
    print(f"  Total cost: ${result.get('total_cost', 0):.4f}")
    if result.get("node_outputs"):
        for node_id, out in result["node_outputs"].items():
            resp = out.get("response", "")[:200]
            print(f"  {node_id}: {resp!r}...")

    await adapter.close()

    if run.state != GridState.COMPLETED:
        print("\n❌ Expected state COMPLETED")
        return False
    print("\n✅ E2E passed")
    return True


if __name__ == "__main__":
    ok = asyncio.run(main())
    sys.exit(0 if ok else 1)
