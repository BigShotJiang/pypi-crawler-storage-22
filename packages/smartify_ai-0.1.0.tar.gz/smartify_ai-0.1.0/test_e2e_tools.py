#!/usr/bin/env python3
"""Manual E2E test: run examples/file-creator.yaml (tool execution) with real API.

Use this to verify builtin tools (e.g. file_write) work end-to-end.
Requires: ANTHROPIC_API_KEY

  python test_e2e_tools.py

Runs in a temp directory so it doesn't pollute the repo.
"""

import asyncio
import os
import sys
import tempfile
from pathlib import Path

if __name__ == "__main__" and "src" not in sys.path:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from smartify.engine.orchestrator import Orchestrator
from smartify.agents.adapters import AnthropicAdapter
from smartify.tools.builtin import create_builtin_registry
from smartify.models.grid import GridState


async def main():
    print("=" * 60)
    print("Smartify Runtime E2E Tools — examples/file-creator.yaml")
    print("=" * 60)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ ANTHROPIC_API_KEY not set")
        return False

    with tempfile.TemporaryDirectory() as tmpdir:
        base_path = str(Path(tmpdir))
        registry = create_builtin_registry(base_path=base_path)
        orchestrator = Orchestrator(tool_registry=registry)
        adapter = AnthropicAdapter(api_key=api_key)
        orchestrator.register_llm_adapter("default", adapter)

        print("--- Loading file-creator grid ---")
        run = await orchestrator.load_grid("examples/file-creator.yaml")
        await orchestrator.energize(run)
        result = await orchestrator.execute(run)

        await adapter.close()

        hello_path = Path(base_path) / "hello.txt"
        if hello_path.exists():
            content = hello_path.read_text()
            print(f"  Created hello.txt: {content[:80]!r}...")
        else:
            print("  Note: hello.txt not created (model may have varied behavior)")

    if run.state != GridState.COMPLETED:
        print("\n❌ Expected state COMPLETED")
        return False
    print("\n✅ E2E tools passed")
    return True


if __name__ == "__main__":
    ok = asyncio.run(main())
    sys.exit(0 if ok else 1)
