#!/usr/bin/env python3
"""Manual E2E test: run examples/parallel-swarm.yaml (multi-agent parallel) with real API.

Heavier smoke test: controller + relay + 3 parallel researchers + aggregate + summarizer.
Requires: ANTHROPIC_API_KEY

  python test_parallel_swarm.py

Optional: pass a topic, e.g. python test_parallel_swarm.py "renewable energy"
"""

import asyncio
import os
import sys

if __name__ == "__main__" and "src" not in sys.path:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from smartify.engine.orchestrator import Orchestrator
from smartify.agents.adapters import AnthropicAdapter
from smartify.models.grid import GridState


async def main():
    topic = (sys.argv[1] if len(sys.argv) > 1 else "open source software")[:80]
    print("=" * 60)
    print("Smartify Runtime E2E — examples/parallel-swarm.yaml")
    print(f"  Topic: {topic}")
    print("=" * 60)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ ANTHROPIC_API_KEY not set")
        return False

    orchestrator = Orchestrator()
    adapter = AnthropicAdapter(api_key=api_key)
    orchestrator.register_llm_adapter("anthropic", adapter)
    orchestrator.register_llm_adapter("default", adapter)

    print("--- Loading parallel-swarm grid ---")
    run = await orchestrator.load_grid(
        "examples/parallel-swarm.yaml",
        inputs={"topic": topic, "num_perspectives": 3},
    )
    await orchestrator.energize(run)
    result = await orchestrator.execute(run)

    print("\n--- Result ---")
    print(f"  State: {result.get('state')}")
    print(f"  Total tokens: {result.get('total_tokens')}")
    print(f"  Total cost: ${result.get('total_cost', 0):.4f}")
    if result.get("node_outputs"):
        for node_id in ["controller", "researcher-1", "researcher-2", "researcher-3", "summarizer"]:
            if node_id in result["node_outputs"]:
                out = result["node_outputs"][node_id]
                resp = (out.get("response") or "")[:150]
                print(f"  {node_id}: {resp!r}...")

    await adapter.close()

    if run.state != GridState.COMPLETED:
        print("\n❌ Expected state COMPLETED")
        return False
    print("\n✅ Parallel swarm E2E passed")
    return True


if __name__ == "__main__":
    ok = asyncio.run(main())
    sys.exit(0 if ok else 1)
