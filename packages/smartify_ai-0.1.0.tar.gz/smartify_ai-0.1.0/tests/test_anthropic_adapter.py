"""Tests for the Anthropic LLM adapter."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from smartify.agents.adapters.anthropic import AnthropicAdapter, MODEL_PRICING


class TestAnthropicAdapter:
    """Test suite for AnthropicAdapter."""
    
    def test_init_requires_api_key(self):
        """Should raise if no API key provided."""
        with patch.dict("os.environ", {}, clear=True):
            with pytest.raises(ValueError, match="API key required"):
                AnthropicAdapter()
    
    def test_init_with_env_var(self):
        """Should accept API key from environment."""
        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "test-key"}):
            adapter = AnthropicAdapter()
            assert adapter.api_key == "test-key"
    
    def test_init_with_explicit_key(self):
        """Should accept explicit API key."""
        adapter = AnthropicAdapter(api_key="explicit-key")
        assert adapter.api_key == "explicit-key"
    
    def test_convert_tools_openai_format(self):
        """Should convert OpenAI-style tool definitions."""
        adapter = AnthropicAdapter(api_key="test")
        
        openai_tools = [
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "Get the weather",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "location": {"type": "string"}
                        }
                    }
                }
            }
        ]
        
        converted = adapter._convert_tools(openai_tools)
        
        assert len(converted) == 1
        assert converted[0]["name"] == "get_weather"
        assert converted[0]["description"] == "Get the weather"
        assert "input_schema" in converted[0]
    
    def test_convert_messages_basic(self):
        """Should convert basic user/assistant messages."""
        adapter = AnthropicAdapter(api_key="test")
        
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]
        
        converted = adapter._convert_messages(messages)
        
        assert len(converted) == 2
        assert converted[0]["role"] == "user"
        assert converted[1]["role"] == "assistant"
    
    def test_convert_messages_skips_system(self):
        """Should skip system messages (handled separately)."""
        adapter = AnthropicAdapter(api_key="test")
        
        messages = [
            {"role": "system", "content": "You are helpful"},
            {"role": "user", "content": "Hello"},
        ]
        
        converted = adapter._convert_messages(messages)
        
        assert len(converted) == 1
        assert converted[0]["role"] == "user"
    
    def test_calculate_cost(self):
        """Should calculate cost correctly."""
        adapter = AnthropicAdapter(api_key="test")
        
        # 1M input tokens + 1M output tokens for sonnet
        cost = adapter._calculate_cost(
            "claude-3-5-sonnet-latest",
            tokens_in=1_000_000,
            tokens_out=1_000_000,
        )
        
        # $3/M input + $15/M output = $18
        assert cost == 18.0
    
    @pytest.mark.asyncio
    async def test_complete_returns_expected_format(self):
        """Should return properly formatted response."""
        adapter = AnthropicAdapter(api_key="test")
        
        # Mock the response
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="Hello!", type="text")]
        mock_response.content[0].__class__.__name__ = "TextBlock"
        mock_response.usage.input_tokens = 10
        mock_response.usage.output_tokens = 5
        mock_response.stop_reason = "end_turn"
        
        # TextBlock check
        from anthropic.types import TextBlock
        mock_text_block = TextBlock(type="text", text="Hello!")
        mock_response.content = [mock_text_block]
        
        with patch.object(adapter._client.messages, "create", new_callable=AsyncMock) as mock_create:
            mock_create.return_value = mock_response
            
            result = await adapter.complete(
                messages=[{"role": "user", "content": "Hi"}]
            )
        
        assert "content" in result
        assert "tokens_in" in result
        assert "tokens_out" in result
        assert "cost" in result
        assert "model" in result
        assert result["content"] == "Hello!"


class TestModelPricing:
    """Test model pricing configuration."""
    
    def test_all_models_have_pricing(self):
        """All models should have input and output pricing."""
        for model, pricing in MODEL_PRICING.items():
            assert "input" in pricing, f"{model} missing input pricing"
            assert "output" in pricing, f"{model} missing output pricing"
            assert pricing["input"] > 0
            assert pricing["output"] > 0
