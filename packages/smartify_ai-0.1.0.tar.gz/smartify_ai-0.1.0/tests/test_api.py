"""Tests for the FastAPI server."""

import pytest
from fastapi.testclient import TestClient

from smartify.api.server import app, state, API_VERSION_MAJOR


# Base URL for versioned API
API_BASE = f"/{API_VERSION_MAJOR}"


@pytest.fixture
def client():
    """Create a test client."""
    # Reset state for each test
    state.runs.clear()
    state.run_tasks.clear()
    state.run_created_at.clear()
    return TestClient(app)


@pytest.fixture
def sample_grid_yaml():
    """Sample minimal grid YAML."""
    return """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  id: test-grid
  name: Test Grid
  version: "1.0"
topology:
  nodes:
    - id: controller
      kind: controller
      name: Main Controller
"""


class TestHealthEndpoints:
    """Test health and info endpoints (unversioned)."""
    
    def test_health_check(self, client):
        """Health endpoint returns healthy status."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "version" in data
        assert "api_version" in data
        # Check version header
        assert "X-API-Version" in response.headers
    
    def test_root_endpoint(self, client):
        """Root endpoint returns API info."""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Smartify Runtime API"
        assert data["api_version"] == API_VERSION_MAJOR


class TestGridManagement:
    """Test grid CRUD operations."""
    
    def test_load_grid_from_yaml(self, client, sample_grid_yaml):
        """Should load a grid from YAML content."""
        response = client.post(
            f"{API_BASE}/grids",
            json={"yaml_content": sample_grid_yaml}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["grid_id"] == "test-grid"
        assert data["name"] == "Test Grid"
        assert data["state"] == "draft"
    
    def test_load_grid_requires_content_or_path(self, client):
        """Should reject request without content or path."""
        response = client.post(f"{API_BASE}/grids", json={})
        assert response.status_code == 400
        data = response.json()
        assert data["error"] == "VALIDATION_FAILED"
        assert data["retryable"] == False
    
    def test_load_grid_rejects_both(self, client, sample_grid_yaml):
        """Should reject request with both content and path."""
        response = client.post(
            f"{API_BASE}/grids",
            json={
                "yaml_content": sample_grid_yaml,
                "file_path": "/some/path.yaml"
            }
        )
        assert response.status_code == 400
        data = response.json()
        assert data["error"] == "VALIDATION_FAILED"
    
    def test_list_grids_empty(self, client):
        """Should return empty list when no grids loaded."""
        response = client.get(f"{API_BASE}/grids")
        assert response.status_code == 200
        data = response.json()
        assert data["grids"] == []
        assert data["total"] == 0
        assert data["has_more"] == False
    
    def test_list_grids_with_loaded(self, client, sample_grid_yaml):
        """Should list loaded grids."""
        # Load a grid first
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 1
        assert len(data["grids"]) == 1
        assert data["grids"][0]["grid_id"] == "test-grid"
    
    def test_list_grids_pagination(self, client, sample_grid_yaml):
        """Should paginate grid list."""
        # Load multiple grids
        for i in range(5):
            yaml = sample_grid_yaml.replace("test-grid", f"grid-{i}")
            yaml = yaml.replace("Test Grid", f"Grid {i}")
            client.post(f"{API_BASE}/grids", json={"yaml_content": yaml})
        
        # Get first page
        response = client.get(f"{API_BASE}/grids?limit=2&offset=0")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 5
        assert len(data["grids"]) == 2
        assert data["has_more"] == True
        
        # Get second page
        response = client.get(f"{API_BASE}/grids?limit=2&offset=2")
        data = response.json()
        assert len(data["grids"]) == 2
        assert data["has_more"] == True
        
        # Get last page
        response = client.get(f"{API_BASE}/grids?limit=2&offset=4")
        data = response.json()
        assert len(data["grids"]) == 1
        assert data["has_more"] == False
    
    def test_list_grids_state_filter(self, client, sample_grid_yaml):
        """Should filter grids by state."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        # Filter by draft (should find 1)
        response = client.get(f"{API_BASE}/grids?state=draft")
        data = response.json()
        assert data["total"] == 1
        
        # Filter by running (should find 0)
        response = client.get(f"{API_BASE}/grids?state=running")
        data = response.json()
        assert data["total"] == 0
    
    def test_get_grid_status(self, client, sample_grid_yaml):
        """Should get grid status."""
        # Load a grid
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids/test-grid")
        assert response.status_code == 200
        data = response.json()
        assert data["grid_id"] == "test-grid"
        assert data["state"] == "draft"
    
    def test_get_grid_not_found(self, client):
        """Should return 404 for unknown grid."""
        response = client.get(f"{API_BASE}/grids/unknown-grid")
        assert response.status_code == 404
        data = response.json()
        assert data["error"] == "GRID_NOT_FOUND"
        assert data["retryable"] == False
    
    def test_delete_grid(self, client, sample_grid_yaml):
        """Should delete a grid."""
        # Load a grid
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        # Delete it
        response = client.delete(f"{API_BASE}/grids/test-grid")
        assert response.status_code == 200
        
        # Verify it's gone
        response = client.get(f"{API_BASE}/grids/test-grid")
        assert response.status_code == 404
    
    def test_delete_grid_not_found(self, client):
        """Should return 404 when deleting unknown grid."""
        response = client.delete(f"{API_BASE}/grids/unknown-grid")
        assert response.status_code == 404
        data = response.json()
        assert data["error"] == "GRID_NOT_FOUND"


class TestGridLifecycle:
    """Test grid lifecycle operations."""
    
    def test_energize_grid(self, client, sample_grid_yaml):
        """Should attempt to energize a grid (may fail without LLM adapter)."""
        # Load
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        # Energize - may fail if no LLM adapter configured
        response = client.post(
            f"{API_BASE}/grids/test-grid/energize",
            json={"inputs": {}}
        )
        # Accept 200 (success) or 500 (no LLM adapter) 
        assert response.status_code in (200, 500)
        if response.status_code == 200:
            data = response.json()
            assert data["state"] == "energized"
    
    def test_energize_grid_not_found(self, client):
        """Should return 404 for unknown grid."""
        response = client.post(
            f"{API_BASE}/grids/unknown-grid/energize",
            json={"inputs": {}}
        )
        assert response.status_code == 404
        data = response.json()
        assert data["error"] == "GRID_NOT_FOUND"
    
    def test_pause_grid_not_running(self, client, sample_grid_yaml):
        """Should reject pause on non-running grid."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.post(f"{API_BASE}/grids/test-grid/pause")
        assert response.status_code == 409
        data = response.json()
        assert data["error"] == "GRID_INVALID_STATE"
    
    def test_resume_grid_not_paused(self, client, sample_grid_yaml):
        """Should reject resume on non-paused grid."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.post(f"{API_BASE}/grids/test-grid/resume")
        assert response.status_code == 409
        data = response.json()
        assert data["error"] == "GRID_INVALID_STATE"
    
    def test_stop_grid_wrong_state(self, client, sample_grid_yaml):
        """Should reject stop on grid in wrong state."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        # Grid is in draft state, stop should fail
        response = client.post(f"{API_BASE}/grids/test-grid/stop")
        assert response.status_code == 409
        data = response.json()
        assert data["error"] == "GRID_INVALID_STATE"


class TestNodeInspection:
    """Test node inspection endpoints."""
    
    def test_list_nodes(self, client, sample_grid_yaml):
        """Should list nodes in a grid."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids/test-grid/nodes")
        assert response.status_code == 200
        data = response.json()
        assert "nodes" in data
        assert data["total"] == 1
        assert len(data["nodes"]) == 1
        assert data["nodes"][0]["id"] == "controller"
    
    def test_get_node_output(self, client, sample_grid_yaml):
        """Should get node details."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids/test-grid/nodes/controller")
        assert response.status_code == 200
        data = response.json()
        assert data["node_id"] == "controller"
        assert data["kind"] == "controller"
    
    def test_get_node_not_found(self, client, sample_grid_yaml):
        """Should return 404 for unknown node."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids/test-grid/nodes/unknown-node")
        assert response.status_code == 404
        data = response.json()
        assert data["error"] == "NODE_NOT_FOUND"


class TestEventsEndpoint:
    """Test event streaming endpoints."""
    
    def test_list_event_types(self, client):
        """Should list all event types."""
        response = client.get(f"{API_BASE}/events/types")
        assert response.status_code == 200
        data = response.json()
        assert "types" in data
        assert "grid.loaded" in data["types"]
        assert "node.started" in data["types"]
        assert "breaker.tripped" in data["types"]
    
    def test_get_events_empty(self, client, sample_grid_yaml):
        """Should return empty events for new grid."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids/test-grid/events")
        assert response.status_code == 200
        data = response.json()
        assert data["grid_id"] == "test-grid"
        assert data["events"] == []
        assert data["total"] == 0
        assert data["has_more"] == False
    
    def test_get_events_not_found(self, client):
        """Should return 404 for unknown grid."""
        response = client.get(f"{API_BASE}/grids/unknown/events")
        assert response.status_code == 404
        data = response.json()
        assert data["error"] == "GRID_NOT_FOUND"
    
    def test_get_events_with_limit(self, client, sample_grid_yaml):
        """Should respect limit parameter."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids/test-grid/events?limit=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data["events"]) <= 10
    
    def test_get_events_includes_progress(self, client, sample_grid_yaml):
        """Should include execution progress."""
        client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        
        response = client.get(f"{API_BASE}/grids/test-grid/events")
        assert response.status_code == 200
        data = response.json()
        assert "state" in data
        assert "progress" in data
        assert "completed_nodes" in data
        assert "total_nodes" in data


class TestErrorResponses:
    """Test error response format consistency."""
    
    def test_error_response_format(self, client):
        """All errors should have consistent format."""
        response = client.get(f"{API_BASE}/grids/nonexistent")
        assert response.status_code == 404
        data = response.json()
        
        # Required fields
        assert "error" in data
        assert "message" in data
        assert "retryable" in data
        assert "timestamp" in data
    
    def test_validation_error_includes_details(self, client):
        """Validation errors should include helpful details."""
        response = client.post(f"{API_BASE}/grids", json={})
        assert response.status_code == 400
        data = response.json()
        
        assert data["error"] == "VALIDATION_FAILED"
        assert "details" in data
        assert data["details"] is not None
    
    def test_version_header_on_all_responses(self, client, sample_grid_yaml):
        """All responses should include version header."""
        # Success response
        response = client.post(f"{API_BASE}/grids", json={"yaml_content": sample_grid_yaml})
        assert "X-API-Version" in response.headers
        
        # Error response
        response = client.get(f"{API_BASE}/grids/nonexistent")
        assert "X-API-Version" in response.headers
