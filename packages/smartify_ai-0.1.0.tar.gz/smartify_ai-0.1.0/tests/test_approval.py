"""Tests for approval flow and human-in-the-loop nodes."""

import asyncio
import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, Mock, patch

from smartify.engine.approval import (
    ApprovalStatus,
    ApprovalRequest,
    ApprovalManager,
    NotificationChannel,
    SlackNotificationChannel,
    WebhookNotificationChannel,
    get_approval_manager,
    configure_approval_manager,
    _approval_manager,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def approval_manager():
    """Fresh ApprovalManager instance."""
    return ApprovalManager(callback_base_url="http://test.local:8000")


@pytest.fixture
def approval_request():
    """Basic approval request."""
    return ApprovalRequest(
        id="apr-test123",
        grid_id="grid-1",
        node_id="approval-node",
        prompt="Do you approve this action?",
        context={"action": "deploy"},
    )


@pytest.fixture
def mock_channel():
    """Mock notification channel."""
    channel = Mock(spec=NotificationChannel)
    channel.send = AsyncMock(return_value=True)
    return channel


# ============================================================================
# ApprovalStatus Enum
# ============================================================================

class TestApprovalStatus:
    """Tests for ApprovalStatus enum."""
    
    def test_all_statuses_defined(self):
        """Test all expected statuses exist."""
        assert ApprovalStatus.PENDING == "pending"
        assert ApprovalStatus.APPROVED == "approved"
        assert ApprovalStatus.REJECTED == "rejected"
        assert ApprovalStatus.EXPIRED == "expired"
        assert ApprovalStatus.CANCELLED == "cancelled"


# ============================================================================
# ApprovalRequest Dataclass
# ============================================================================

class TestApprovalRequest:
    """Tests for ApprovalRequest dataclass."""
    
    def test_defaults(self, approval_request):
        """Test default values."""
        assert approval_request.status == ApprovalStatus.PENDING
        assert approval_request.timeout_seconds == 86400
        assert approval_request.required_approvers == 1
        assert approval_request.allowed_approvers == []
        assert approval_request.approvers == []
        assert approval_request.resolved_at is None
        assert approval_request.rejection_reason is None
    
    def test_expires_at_property(self, approval_request):
        """Test expires_at calculation."""
        expected = approval_request.created_at + timedelta(seconds=86400)
        assert abs((approval_request.expires_at - expected).total_seconds()) < 1
    
    def test_is_expired_false_when_pending(self, approval_request):
        """Test is_expired is False for fresh request."""
        assert approval_request.is_expired is False
    
    def test_is_expired_true_when_past_timeout(self):
        """Test is_expired is True when past timeout."""
        request = ApprovalRequest(
            id="apr-old",
            grid_id="grid-1",
            node_id="node-1",
            prompt="Old request",
            context={},
            timeout_seconds=1,
            created_at=datetime.now() - timedelta(seconds=10),
        )
        assert request.is_expired is True
    
    def test_is_expired_false_when_already_resolved(self):
        """Test is_expired is False when already approved."""
        request = ApprovalRequest(
            id="apr-resolved",
            grid_id="grid-1",
            node_id="node-1",
            prompt="Resolved request",
            context={},
            timeout_seconds=1,
            created_at=datetime.now() - timedelta(seconds=10),
            status=ApprovalStatus.APPROVED,
        )
        # Even though time expired, status isn't PENDING
        assert request.is_expired is False
    
    def test_approve_single_approver(self, approval_request):
        """Test approve with single required approver."""
        result = approval_request.approve("user@test.com")
        
        assert result is True
        assert approval_request.status == ApprovalStatus.APPROVED
        assert "user@test.com" in approval_request.approvers
        assert approval_request.resolved_at is not None
    
    def test_approve_multiple_approvers_required(self):
        """Test approve with multiple required approvers."""
        request = ApprovalRequest(
            id="apr-multi",
            grid_id="grid-1",
            node_id="node-1",
            prompt="Multi-approval",
            context={},
            required_approvers=2,
        )
        
        # First approval doesn't complete
        result1 = request.approve("user1@test.com")
        assert result1 is False
        assert request.status == ApprovalStatus.PENDING
        assert len(request.approvers) == 1
        
        # Second approval completes
        result2 = request.approve("user2@test.com")
        assert result2 is True
        assert request.status == ApprovalStatus.APPROVED
        assert len(request.approvers) == 2
    
    def test_approve_allowed_approvers_list(self):
        """Test approve only accepts allowed approvers."""
        request = ApprovalRequest(
            id="apr-restricted",
            grid_id="grid-1",
            node_id="node-1",
            prompt="Restricted",
            context={},
            allowed_approvers=["admin@test.com", "lead@test.com"],
        )
        
        # Not in allowed list - fails silently
        result = request.approve("random@test.com")
        assert result is False
        assert request.status == ApprovalStatus.PENDING
        assert "random@test.com" not in request.approvers
        
        # In allowed list - succeeds
        result = request.approve("admin@test.com")
        assert result is True
        assert request.status == ApprovalStatus.APPROVED
    
    def test_approve_idempotent_same_approver(self, approval_request):
        """Test approving twice as same user doesn't double-count."""
        request = ApprovalRequest(
            id="apr-idempotent",
            grid_id="grid-1",
            node_id="node-1",
            prompt="Idempotent",
            context={},
            required_approvers=2,
        )
        
        request.approve("user@test.com")
        request.approve("user@test.com")  # Same user again
        
        assert len(request.approvers) == 1
        assert request.status == ApprovalStatus.PENDING
    
    def test_approve_after_already_approved(self, approval_request):
        """Test approve returns False if already approved."""
        approval_request.approve("user@test.com")
        
        result = approval_request.approve("another@test.com")
        
        assert result is False  # Already resolved
    
    def test_reject(self, approval_request):
        """Test basic rejection."""
        approval_request.reject("user@test.com", "Not safe")
        
        assert approval_request.status == ApprovalStatus.REJECTED
        assert approval_request.rejection_reason == "Not safe"
        assert "user@test.com" in approval_request.approvers
        assert approval_request.resolved_at is not None
    
    def test_reject_without_reason(self, approval_request):
        """Test rejection without reason."""
        approval_request.reject("user@test.com")
        
        assert approval_request.status == ApprovalStatus.REJECTED
        assert approval_request.rejection_reason is None
    
    def test_reject_after_already_resolved(self, approval_request):
        """Test reject does nothing if already resolved."""
        approval_request.approve("user@test.com")
        
        approval_request.reject("another@test.com", "Too late")
        
        assert approval_request.status == ApprovalStatus.APPROVED


# ============================================================================
# ApprovalManager Initialization
# ============================================================================

class TestApprovalManagerInit:
    """Tests for ApprovalManager initialization."""
    
    def test_init_defaults(self):
        """Test default initialization."""
        manager = ApprovalManager()
        
        assert manager.requests == {}
        assert manager.channels == []
        assert manager.callback_base_url == "http://localhost:8000"
        assert manager._events == {}
    
    def test_init_custom_callback_url(self):
        """Test initialization with custom callback URL."""
        manager = ApprovalManager(callback_base_url="https://api.mysite.com")
        
        assert manager.callback_base_url == "https://api.mysite.com"
    
    def test_add_channel(self, approval_manager, mock_channel):
        """Test adding notification channel."""
        approval_manager.add_channel(mock_channel)
        
        assert len(approval_manager.channels) == 1
        assert mock_channel in approval_manager.channels


# ============================================================================
# ApprovalManager Create Request
# ============================================================================

class TestApprovalManagerCreateRequest:
    """Tests for ApprovalManager.create_request."""
    
    @pytest.mark.asyncio
    async def test_create_request_basic(self, approval_manager):
        """Test basic request creation."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Approve this?",
        )
        
        assert request.id.startswith("apr-")
        assert request.grid_id == "grid-1"
        assert request.node_id == "node-1"
        assert request.prompt == "Approve this?"
        assert request.status == ApprovalStatus.PENDING
    
    @pytest.mark.asyncio
    async def test_create_request_stored_in_manager(self, approval_manager):
        """Test request is stored in manager."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Stored?",
        )
        
        assert request.id in approval_manager.requests
        assert request.id in approval_manager._events
    
    @pytest.mark.asyncio
    async def test_create_request_with_all_options(self, approval_manager):
        """Test request creation with all options."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Full request",
            context={"env": "prod"},
            timeout_seconds=3600,
            required_approvers=2,
            allowed_approvers=["admin@test.com"],
            show_outputs={"previous_node": {"result": "data"}},
        )
        
        assert request.context == {"env": "prod"}
        assert request.timeout_seconds == 3600
        assert request.required_approvers == 2
        assert request.allowed_approvers == ["admin@test.com"]
        assert request.show_outputs == {"previous_node": {"result": "data"}}
    
    @pytest.mark.asyncio
    async def test_create_request_sends_notifications(self, approval_manager, mock_channel):
        """Test notifications are sent on create."""
        approval_manager.add_channel(mock_channel)
        
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Notify test",
        )
        
        mock_channel.send.assert_called_once()
        call_args = mock_channel.send.call_args
        assert call_args[0][0] == request
        assert f"/approvals/{request.id}" in call_args[0][1]
    
    @pytest.mark.asyncio
    async def test_create_request_notification_failure_doesnt_crash(self, approval_manager):
        """Test notification failure doesn't prevent request creation."""
        failing_channel = Mock(spec=NotificationChannel)
        failing_channel.send = AsyncMock(side_effect=Exception("Network error"))
        approval_manager.add_channel(failing_channel)
        
        # Should not raise
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Fail gracefully",
        )
        
        assert request is not None
        assert request.id in approval_manager.requests


# ============================================================================
# ApprovalManager Get/Process
# ============================================================================

class TestApprovalManagerGetProcess:
    """Tests for get/process methods."""
    
    @pytest.mark.asyncio
    async def test_get_request(self, approval_manager):
        """Test getting request by ID."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Get me",
        )
        
        retrieved = approval_manager.get_request(request.id)
        
        assert retrieved == request
    
    def test_get_request_not_found(self, approval_manager):
        """Test getting nonexistent request."""
        result = approval_manager.get_request("nonexistent-id")
        
        assert result is None
    
    @pytest.mark.asyncio
    async def test_process_approval_success(self, approval_manager):
        """Test processing approval."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Process me",
        )
        
        result = approval_manager.process_approval(request.id, "user@test.com")
        
        assert result is True
        assert request.status == ApprovalStatus.APPROVED
    
    def test_process_approval_not_found(self, approval_manager):
        """Test processing approval for nonexistent request."""
        result = approval_manager.process_approval("bad-id", "user@test.com")
        
        assert result is False
    
    @pytest.mark.asyncio
    async def test_process_approval_expired(self, approval_manager):
        """Test processing approval for expired request."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Expired",
            timeout_seconds=0,  # Immediate timeout
        )
        
        # Force expiration
        request.created_at = datetime.now() - timedelta(seconds=10)
        
        result = approval_manager.process_approval(request.id, "user@test.com")
        
        assert result is False
        assert request.status == ApprovalStatus.EXPIRED
    
    @pytest.mark.asyncio
    async def test_process_rejection(self, approval_manager):
        """Test processing rejection."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Reject me",
        )
        
        approval_manager.process_rejection(request.id, "user@test.com", "Bad idea")
        
        assert request.status == ApprovalStatus.REJECTED
        assert request.rejection_reason == "Bad idea"
    
    def test_process_rejection_not_found(self, approval_manager):
        """Test rejecting nonexistent request doesn't crash."""
        # Should not raise
        approval_manager.process_rejection("bad-id", "user@test.com")


# ============================================================================
# ApprovalManager Wait
# ============================================================================

class TestApprovalManagerWait:
    """Tests for wait_for_approval."""
    
    @pytest.mark.asyncio
    async def test_wait_already_resolved(self, approval_manager):
        """Test wait returns immediately if already resolved."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Already done",
        )
        approval_manager.process_approval(request.id, "user@test.com")
        
        result = await approval_manager.wait_for_approval(request.id)
        
        assert result.status == ApprovalStatus.APPROVED
    
    @pytest.mark.asyncio
    async def test_wait_not_found(self, approval_manager):
        """Test wait raises for nonexistent request."""
        with pytest.raises(ValueError, match="not found"):
            await approval_manager.wait_for_approval("bad-id")
    
    @pytest.mark.asyncio
    async def test_wait_approval_arrives(self, approval_manager):
        """Test wait completes when approval arrives."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Wait for me",
        )
        
        # Approve in background after small delay
        async def approve_later():
            await asyncio.sleep(0.05)
            approval_manager.process_approval(request.id, "user@test.com")
        
        asyncio.create_task(approve_later())
        
        result = await approval_manager.wait_for_approval(request.id, timeout=5)
        
        assert result.status == ApprovalStatus.APPROVED
    
    @pytest.mark.asyncio
    async def test_wait_timeout(self, approval_manager):
        """Test wait times out."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Will timeout",
        )
        
        with pytest.raises(TimeoutError, match="expired"):
            await approval_manager.wait_for_approval(request.id, timeout=0.01)
        
        assert request.status == ApprovalStatus.EXPIRED


# ============================================================================
# ApprovalManager Queries
# ============================================================================

class TestApprovalManagerQueries:
    """Tests for query methods."""
    
    @pytest.mark.asyncio
    async def test_get_pending_requests_all(self, approval_manager):
        """Test getting all pending requests."""
        req1 = await approval_manager.create_request(
            grid_id="grid-1", node_id="n1", prompt="P1"
        )
        req2 = await approval_manager.create_request(
            grid_id="grid-2", node_id="n2", prompt="P2"
        )
        
        pending = approval_manager.get_pending_requests()
        
        assert len(pending) == 2
        assert req1 in pending
        assert req2 in pending
    
    @pytest.mark.asyncio
    async def test_get_pending_requests_filtered(self, approval_manager):
        """Test getting pending requests for specific grid."""
        await approval_manager.create_request(
            grid_id="grid-1", node_id="n1", prompt="P1"
        )
        req2 = await approval_manager.create_request(
            grid_id="grid-2", node_id="n2", prompt="P2"
        )
        
        pending = approval_manager.get_pending_requests(grid_id="grid-2")
        
        assert len(pending) == 1
        assert req2 in pending
    
    @pytest.mark.asyncio
    async def test_get_pending_excludes_resolved(self, approval_manager):
        """Test pending excludes resolved requests."""
        req1 = await approval_manager.create_request(
            grid_id="grid-1", node_id="n1", prompt="P1"
        )
        req2 = await approval_manager.create_request(
            grid_id="grid-1", node_id="n2", prompt="P2"
        )
        
        approval_manager.process_approval(req1.id, "user@test.com")
        
        pending = approval_manager.get_pending_requests()
        
        assert len(pending) == 1
        assert req2 in pending
    
    @pytest.mark.asyncio
    async def test_cleanup_expired(self, approval_manager):
        """Test cleanup marks expired requests."""
        # Create with immediate expiration
        req1 = await approval_manager.create_request(
            grid_id="grid-1", node_id="n1", prompt="P1", timeout_seconds=0
        )
        req2 = await approval_manager.create_request(
            grid_id="grid-1", node_id="n2", prompt="P2", timeout_seconds=3600
        )
        
        # Force expiration on first request
        req1.created_at = datetime.now() - timedelta(seconds=10)
        
        count = approval_manager.cleanup_expired()
        
        assert count == 1
        assert req1.status == ApprovalStatus.EXPIRED
        assert req2.status == ApprovalStatus.PENDING


# ============================================================================
# SlackNotificationChannel
# ============================================================================

class TestSlackNotificationChannel:
    """Tests for Slack notification channel."""
    
    def test_init_with_webhook(self):
        """Test initialization with webhook URL."""
        channel = SlackNotificationChannel(webhook_url="https://hooks.slack.com/...")
        
        assert channel.webhook_url == "https://hooks.slack.com/..."
        assert channel.bot_token is None
    
    def test_init_with_bot_token(self):
        """Test initialization with bot token."""
        channel = SlackNotificationChannel(
            bot_token="xoxb-...",
            channel="#approvals",
        )
        
        assert channel.bot_token == "xoxb-..."
        assert channel.channel == "#approvals"
    
    @pytest.mark.asyncio
    async def test_send_no_config(self, approval_request):
        """Test send returns False when not configured."""
        channel = SlackNotificationChannel()
        
        result = await channel.send(approval_request, "http://callback")
        
        assert result is False
    
    @pytest.mark.asyncio
    async def test_send_webhook_success(self, approval_request):
        """Test successful webhook send."""
        channel = SlackNotificationChannel(webhook_url="https://hooks.slack.com/test")
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            result = await channel.send(approval_request, "http://callback")
            
            assert result is True
            mock_client.return_value.post.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_send_webhook_failure(self, approval_request):
        """Test failed webhook send."""
        channel = SlackNotificationChannel(webhook_url="https://hooks.slack.com/test")
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 500
            mock_response.text = "Server error"
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            result = await channel.send(approval_request, "http://callback")
            
            assert result is False
    
    @pytest.mark.asyncio
    async def test_send_exception_handled(self, approval_request):
        """Test exception during send is handled."""
        channel = SlackNotificationChannel(webhook_url="https://hooks.slack.com/test")
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(side_effect=Exception("Network error"))
            
            result = await channel.send(approval_request, "http://callback")
            
            assert result is False


# ============================================================================
# WebhookNotificationChannel
# ============================================================================

class TestWebhookNotificationChannel:
    """Tests for webhook notification channel."""
    
    def test_init(self):
        """Test initialization."""
        channel = WebhookNotificationChannel(
            url="https://api.example.com/approvals",
            headers={"Authorization": "Bearer token"},
        )
        
        assert channel.url == "https://api.example.com/approvals"
        assert channel.headers == {"Authorization": "Bearer token"}
    
    def test_init_default_headers(self):
        """Test initialization with default headers."""
        channel = WebhookNotificationChannel(url="https://api.example.com")
        
        assert channel.headers == {}
    
    @pytest.mark.asyncio
    async def test_send_success(self, approval_request):
        """Test successful webhook send."""
        channel = WebhookNotificationChannel(url="https://api.example.com/approvals")
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 202
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            result = await channel.send(approval_request, "http://callback")
            
            assert result is True
    
    @pytest.mark.asyncio
    async def test_send_includes_callback_url(self, approval_request):
        """Test send includes callback URL in payload."""
        channel = WebhookNotificationChannel(url="https://api.example.com/approvals")
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            await channel.send(approval_request, "http://callback/approve")
            
            call_kwargs = mock_client.return_value.post.call_args[1]
            assert call_kwargs["json"]["callback_url"] == "http://callback/approve"
    
    @pytest.mark.asyncio
    async def test_send_failure_status(self, approval_request):
        """Test send returns False on bad status."""
        channel = WebhookNotificationChannel(url="https://api.example.com/approvals")
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 400
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            result = await channel.send(approval_request, "http://callback")
            
            assert result is False


# ============================================================================
# Global Manager Functions
# ============================================================================

class TestGlobalManagerFunctions:
    """Tests for global manager functions."""
    
    def test_get_approval_manager_creates_singleton(self):
        """Test get_approval_manager creates singleton."""
        # Reset global
        import smartify.engine.approval as approval_module
        approval_module._approval_manager = None
        
        manager1 = get_approval_manager()
        manager2 = get_approval_manager()
        
        assert manager1 is manager2
    
    def test_configure_approval_manager(self):
        """Test configure_approval_manager creates new manager."""
        import smartify.engine.approval as approval_module
        approval_module._approval_manager = None
        
        manager = configure_approval_manager(
            callback_base_url="https://api.test.com",
            slack_webhook="https://hooks.slack.com/test",
        )
        
        assert manager.callback_base_url == "https://api.test.com"
        assert len(manager.channels) == 1
        assert isinstance(manager.channels[0], SlackNotificationChannel)
    
    def test_configure_with_multiple_webhooks(self):
        """Test configure with multiple webhook URLs."""
        import smartify.engine.approval as approval_module
        approval_module._approval_manager = None
        
        manager = configure_approval_manager(
            webhooks=["https://hook1.com", "https://hook2.com"],
        )
        
        assert len(manager.channels) == 2
        assert all(isinstance(c, WebhookNotificationChannel) for c in manager.channels)
    
    def test_configure_with_slack_bot_token(self):
        """Test configure with Slack bot token."""
        import smartify.engine.approval as approval_module
        approval_module._approval_manager = None
        
        manager = configure_approval_manager(
            slack_bot_token="xoxb-test-token",
            slack_channel="#approvals",
        )
        
        assert len(manager.channels) == 1
        channel = manager.channels[0]
        assert isinstance(channel, SlackNotificationChannel)
        assert channel.bot_token == "xoxb-test-token"
        assert channel.channel == "#approvals"


# ============================================================================
# Signal Complete / Events
# ============================================================================

class TestSignalComplete:
    """Tests for _signal_complete and event handling."""
    
    @pytest.mark.asyncio
    async def test_signal_sets_event(self, approval_manager):
        """Test _signal_complete sets the event."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Signal test",
        )
        
        assert not approval_manager._events[request.id].is_set()
        
        approval_manager._signal_complete(request.id)
        
        assert approval_manager._events[request.id].is_set()
    
    def test_signal_nonexistent_no_error(self, approval_manager):
        """Test signaling nonexistent request doesn't crash."""
        # Should not raise
        approval_manager._signal_complete("nonexistent-id")
    
    @pytest.mark.asyncio
    async def test_approval_signals_complete(self, approval_manager):
        """Test approval process signals completion."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Signal on approve",
        )
        
        approval_manager.process_approval(request.id, "user@test.com")
        
        assert approval_manager._events[request.id].is_set()
    
    @pytest.mark.asyncio
    async def test_rejection_signals_complete(self, approval_manager):
        """Test rejection process signals completion."""
        request = await approval_manager.create_request(
            grid_id="grid-1",
            node_id="node-1",
            prompt="Signal on reject",
        )
        
        approval_manager.process_rejection(request.id, "user@test.com")
        
        assert approval_manager._events[request.id].is_set()
