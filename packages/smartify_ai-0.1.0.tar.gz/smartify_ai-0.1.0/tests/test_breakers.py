"""Tests for the breaker/guardrails system."""

import pytest
import asyncio
from unittest.mock import AsyncMock

from smartify.guardrails import (
    BreakerManager,
    BreakerType,
    BreakerError,
)
from smartify.models.grid import (
    BreakerSpec,
    BreakerActions,
    TripAction,
    TokenLimits,
    TimeLimits,
    CostLimits,
    RequestLimits,
)


class TestBreakerManager:
    """Test BreakerManager functionality."""
    
    def test_init_with_defaults(self):
        """Should initialize with default spec."""
        manager = BreakerManager(BreakerSpec(), BreakerActions())
        assert manager.state.total_tokens == 0
        assert manager.state.total_cost == 0.0
    
    def test_record_usage(self):
        """Should track token and cost usage."""
        manager = BreakerManager(BreakerSpec(), BreakerActions())
        manager.record_usage(tokens=100, cost=0.01)
        manager.record_usage(tokens=200, cost=0.02)
        
        assert manager.state.total_tokens == 300
        assert manager.state.total_cost == 0.03
    
    def test_start_begins_timing(self):
        """Should start the execution timer."""
        manager = BreakerManager(BreakerSpec(), BreakerActions())
        assert manager.state.start_time is None
        
        manager.start()
        assert manager.state.start_time is not None
        assert manager.state.elapsed_seconds >= 0
    
    @pytest.mark.asyncio
    async def test_token_limit_trip(self):
        """Should trip when token limit exceeded."""
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=100))
        actions = BreakerActions(onTokensLimit=TripAction.NOTIFY)
        
        manager = BreakerManager(spec, actions)
        manager.start()
        manager.record_usage(tokens=150)
        
        trip = await manager.check_and_enforce()
        
        assert trip is not None
        assert trip.breaker_type == BreakerType.TOKENS
        assert trip.action == TripAction.NOTIFY
        assert "exceeded" in trip.reason.lower()
    
    @pytest.mark.asyncio
    async def test_cost_limit_trip(self):
        """Should trip when cost limit exceeded."""
        spec = BreakerSpec(cost=CostLimits(maxCostPerRun=1.0))
        actions = BreakerActions(onCostLimit=TripAction.NOTIFY)
        
        manager = BreakerManager(spec, actions)
        manager.start()
        manager.record_usage(cost=1.50)
        
        trip = await manager.check_and_enforce()
        
        assert trip is not None
        assert trip.breaker_type == BreakerType.COST
    
    @pytest.mark.asyncio
    async def test_no_trip_under_limit(self):
        """Should not trip when under limits."""
        spec = BreakerSpec(
            tokens=TokenLimits(maxTotalTokensPerRun=1000),
            cost=CostLimits(maxCostPerRun=10.0),
        )
        
        manager = BreakerManager(spec, BreakerActions())
        manager.start()
        manager.record_usage(tokens=100, cost=0.50)
        
        trip = await manager.check_and_enforce()
        assert trip is None
    
    @pytest.mark.asyncio
    async def test_stop_action_raises(self):
        """Stop action should raise BreakerError."""
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=100))
        actions = BreakerActions(onTokensLimit=TripAction.STOP)
        
        manager = BreakerManager(spec, actions)
        manager.start()
        manager.record_usage(tokens=150)
        
        with pytest.raises(BreakerError, match="stop"):
            await manager.check_and_enforce()
    
    @pytest.mark.asyncio
    async def test_block_action_raises(self):
        """Block action should raise BreakerError."""
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=100))
        actions = BreakerActions(onTokensLimit=TripAction.BLOCK)
        
        manager = BreakerManager(spec, actions)
        manager.start()
        manager.record_usage(tokens=150)
        
        with pytest.raises(BreakerError, match="blocked"):
            await manager.check_and_enforce()
    
    @pytest.mark.asyncio
    async def test_cooldown_action(self):
        """Cooldown action should wait before continuing."""
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=100))
        actions = BreakerActions(onTokensLimit=TripAction.COOLDOWN, cooldownSeconds=1)
        
        manager = BreakerManager(spec, actions)
        manager.start()
        manager.record_usage(tokens=150)
        
        import time
        start = time.time()
        trip = await manager.check_and_enforce()
        elapsed = time.time() - start
        
        assert trip is not None
        assert elapsed >= 0.9  # Should have waited ~1 second
    
    @pytest.mark.asyncio
    async def test_pause_action_sets_flag(self):
        """Pause action should set paused flag."""
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=100))
        actions = BreakerActions(onTokensLimit=TripAction.PAUSE)
        
        pause_called = False
        async def on_pause():
            nonlocal pause_called
            pause_called = True
        
        manager = BreakerManager(spec, actions, on_pause=on_pause)
        manager.start()
        manager.record_usage(tokens=150)
        
        # Run check in background (it will wait for resume)
        async def check_with_timeout():
            task = asyncio.create_task(manager.check_and_enforce())
            await asyncio.sleep(0.1)  # Let it start
            manager.resume()  # Resume it
            return await task
        
        trip = await asyncio.wait_for(check_with_timeout(), timeout=2.0)
        
        assert pause_called
        assert trip is not None
    
    @pytest.mark.asyncio
    async def test_approval_callback(self):
        """Require approval action should call callback."""
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=100))
        actions = BreakerActions(onTokensLimit=TripAction.REQUIRE_APPROVAL)
        
        async def approve(reason):
            return True
        
        manager = BreakerManager(spec, actions, on_approval_required=approve)
        manager.start()
        manager.record_usage(tokens=150)
        
        trip = await manager.check_and_enforce()
        assert trip is not None
    
    @pytest.mark.asyncio
    async def test_approval_denied_raises(self):
        """Denied approval should raise BreakerError."""
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=100))
        actions = BreakerActions(onTokensLimit=TripAction.REQUIRE_APPROVAL)
        
        async def deny(reason):
            return False
        
        manager = BreakerManager(spec, actions, on_approval_required=deny)
        manager.start()
        manager.record_usage(tokens=150)
        
        with pytest.raises(BreakerError, match="denied"):
            await manager.check_and_enforce()
    
    def test_get_summary(self):
        """Should return state summary."""
        manager = BreakerManager(BreakerSpec(), BreakerActions())
        manager.start()
        manager.record_usage(tokens=500, cost=0.25)
        
        summary = manager.get_summary()
        
        assert summary["total_tokens"] == 500
        assert summary["total_cost"] == 0.25
        assert summary["status"] == "ok"
        assert "elapsed_seconds" in summary
    
    @pytest.mark.asyncio
    async def test_request_rate_limiting(self):
        """Should track concurrent requests."""
        spec = BreakerSpec(requests=RequestLimits(maxConcurrentAgents=2))
        actions = BreakerActions(onRequestsLimit=TripAction.NOTIFY)
        
        manager = BreakerManager(spec, actions)
        manager.start()
        
        # Start 3 concurrent requests
        manager.record_request_start()
        manager.record_request_start()
        manager.record_request_start()
        
        trip = await manager.check_and_enforce()
        
        assert trip is not None
        assert trip.breaker_type == BreakerType.REQUESTS


class TestWarningThresholds:
    """Test warning threshold behavior."""
    
    @pytest.mark.asyncio
    async def test_token_warning(self):
        """Should set warning status at 80% threshold."""
        # Limit is 1000, so warning triggers at 800 (80%)
        spec = BreakerSpec(tokens=TokenLimits(maxTotalTokensPerRun=1000))
        
        manager = BreakerManager(spec, BreakerActions())
        manager.start()
        manager.record_usage(tokens=850)  # Over 80% threshold
        
        await manager.check_and_enforce()
        
        from smartify.models.grid import BreakerStatus
        assert manager.state.status == BreakerStatus.WARNING
