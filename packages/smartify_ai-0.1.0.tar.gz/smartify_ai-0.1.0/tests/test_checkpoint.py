"""Tests for checkpoint and resume functionality."""

import os
import pytest
import tempfile
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from smartify.state.checkpoint import (
    CheckpointStore,
    CheckpointStatus,
    Checkpoint,
    WebhookRetryJob,
    WebhookDeliveryStatus,
)


class TestCheckpointStore:
    """Test CheckpointStore operations."""
    
    @pytest.fixture
    def store(self, tmp_path):
        """Create a temporary checkpoint store."""
        db_path = str(tmp_path / "test_checkpoints.db")
        return CheckpointStore(db_path)
    
    def test_create_checkpoint(self, store):
        """Should create a new checkpoint."""
        checkpoint = store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="apiVersion: smartify.ai/v1\nkind: GridSpec",
            inputs={"key": "value"},
        )
        
        assert checkpoint.run_id == "run-123"
        assert checkpoint.grid_id == "grid-456"
        assert checkpoint.status == CheckpointStatus.ACTIVE
        assert checkpoint.inputs == {"key": "value"}
        assert checkpoint.completed_nodes == []
        assert checkpoint.checkpoint_id.startswith("ckpt-")
    
    def test_get_checkpoint(self, store):
        """Should retrieve checkpoint by run_id."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="test yaml",
            inputs={},
        )
        
        checkpoint = store.get_checkpoint("run-123")
        
        assert checkpoint is not None
        assert checkpoint.run_id == "run-123"
        assert checkpoint.grid_yaml == "test yaml"
    
    def test_get_nonexistent_checkpoint(self, store):
        """Should return None for nonexistent checkpoint."""
        checkpoint = store.get_checkpoint("nonexistent")
        assert checkpoint is None
    
    def test_checkpoint_node_complete(self, store):
        """Should record node completion."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={},
        )
        
        store.checkpoint_node_complete(
            run_id="run-123",
            node_id="node-1",
            output={"result": "success"},
            tokens_used=100,
            cost=0.01,
        )
        
        checkpoint = store.get_checkpoint("run-123")
        assert "node-1" in checkpoint.completed_nodes
        assert checkpoint.outputs["node-1"] == {"result": "success"}
        assert checkpoint.total_tokens == 100
        assert checkpoint.total_cost == 0.01
    
    def test_checkpoint_node_failed(self, store):
        """Should record node failure."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={},
        )
        
        store.checkpoint_node_failed(
            run_id="run-123",
            node_id="node-1",
            error="Something went wrong",
        )
        
        checkpoint = store.get_checkpoint("run-123")
        assert "node-1" in checkpoint.failed_nodes
        assert "node-1" in checkpoint.last_error
    
    def test_checkpoint_node_started(self, store):
        """Should track running nodes."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={},
        )
        
        store.checkpoint_node_started("run-123", "node-1")
        
        checkpoint = store.get_checkpoint("run-123")
        assert "node-1" in checkpoint.running_nodes
    
    def test_mark_completed(self, store):
        """Should mark checkpoint as completed."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={},
        )
        
        store.mark_completed("run-123")
        
        checkpoint = store.get_checkpoint("run-123")
        assert checkpoint.status == CheckpointStatus.COMPLETED
    
    def test_mark_failed(self, store):
        """Should mark checkpoint as failed with error."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={},
        )
        
        store.mark_failed("run-123", "Fatal error")
        
        checkpoint = store.get_checkpoint("run-123")
        assert checkpoint.status == CheckpointStatus.FAILED
        assert checkpoint.last_error == "Fatal error"
    
    def test_mark_abandoned(self, store):
        """Should mark checkpoint as abandoned."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={},
        )
        
        store.mark_abandoned("run-123")
        
        checkpoint = store.get_checkpoint("run-123")
        assert checkpoint.status == CheckpointStatus.ABANDONED
    
    def test_get_resumable_runs(self, store):
        """Should return active and abandoned runs."""
        # Create various runs
        store.create_checkpoint("run-1", "grid-1", "yaml", {})
        store.create_checkpoint("run-2", "grid-2", "yaml", {})
        store.create_checkpoint("run-3", "grid-3", "yaml", {})
        
        store.mark_completed("run-1")
        store.mark_abandoned("run-2")
        # run-3 stays active
        
        resumable = store.get_resumable_runs()
        run_ids = [r.run_id for r in resumable]
        
        assert "run-1" not in run_ids  # Completed
        assert "run-2" in run_ids  # Abandoned
        assert "run-3" in run_ids  # Active
    
    def test_increment_resume_count(self, store):
        """Should increment resume count."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={},
        )
        
        store.increment_resume_count("run-123")
        store.increment_resume_count("run-123")
        
        checkpoint = store.get_checkpoint("run-123")
        assert checkpoint.resume_count == 2
    
    def test_delete_checkpoint(self, store):
        """Should delete checkpoint."""
        store.create_checkpoint("run-123", "grid-456", "yaml", {})
        
        result = store.delete_checkpoint("run-123")
        
        assert result is True
        assert store.get_checkpoint("run-123") is None


class TestWebhookRetryQueue:
    """Test webhook retry queue operations."""
    
    @pytest.fixture
    def store(self, tmp_path):
        """Create a temporary checkpoint store."""
        db_path = str(tmp_path / "test_webhooks.db")
        return CheckpointStore(db_path)
    
    def test_queue_webhook_retry(self, store):
        """Should queue webhook for retry."""
        job = store.queue_webhook_retry(
            event_type="run_completed",
            grid_id="grid-123",
            webhook_url="https://example.com/hook",
            payload={"data": "test"},
            headers={"X-Custom": "header"},
            secret="my-secret",
            max_attempts=3,
        )
        
        assert job.job_id.startswith("whj-")
        assert job.event_type == "run_completed"
        assert job.webhook_url == "https://example.com/hook"
        assert job.status == WebhookDeliveryStatus.PENDING
        assert job.attempts == 0
    
    def test_get_pending_webhook_jobs(self, store):
        """Should return jobs ready for retry."""
        # Queue a job with past retry time
        job = store.queue_webhook_retry(
            event_type="run_completed",
            grid_id="grid-123",
            webhook_url="https://example.com/hook",
            payload={},
            headers={},
            retry_delay_seconds=0,  # Ready immediately
        )
        
        pending = store.get_pending_webhook_jobs()
        
        assert len(pending) == 1
        assert pending[0].job_id == job.job_id
    
    def test_mark_webhook_delivered(self, store):
        """Should mark webhook as delivered."""
        job = store.queue_webhook_retry(
            event_type="run_completed",
            grid_id="grid-123",
            webhook_url="https://example.com/hook",
            payload={},
            headers={},
        )
        
        store.mark_webhook_delivered(job.job_id)
        
        # Should not appear in pending
        pending = store.get_pending_webhook_jobs()
        job_ids = [j.job_id for j in pending]
        assert job.job_id not in job_ids
    
    def test_mark_webhook_failed_with_retry(self, store):
        """Should schedule retry on failure if attempts remain."""
        job = store.queue_webhook_retry(
            event_type="run_completed",
            grid_id="grid-123",
            webhook_url="https://example.com/hook",
            payload={},
            headers={},
            max_attempts=3,
        )
        
        store.mark_webhook_failed(job.job_id, "Connection refused", retry_delay_seconds=0)
        
        # Should still be pending for retry
        pending = store.get_pending_webhook_jobs()
        assert len(pending) == 1
        assert pending[0].attempts == 1
        assert pending[0].status == WebhookDeliveryStatus.RETRYING
    
    def test_mark_webhook_failed_permanently(self, store):
        """Should mark as failed after max attempts."""
        job = store.queue_webhook_retry(
            event_type="run_completed",
            grid_id="grid-123",
            webhook_url="https://example.com/hook",
            payload={},
            headers={},
            max_attempts=1,
        )
        
        store.mark_webhook_failed(job.job_id, "Error")
        
        # Should not appear in pending
        pending = store.get_pending_webhook_jobs()
        assert len(pending) == 0
    
    def test_cleanup_old_jobs(self, store):
        """Should clean up old delivered/failed jobs."""
        job = store.queue_webhook_retry(
            event_type="run_completed",
            grid_id="grid-123",
            webhook_url="https://example.com/hook",
            payload={},
            headers={},
        )
        
        store.mark_webhook_delivered(job.job_id)
        
        # Cleanup with 0 days should remove everything
        deleted = store.cleanup_old_jobs(days=0)
        
        assert deleted == 1
    
    def test_get_queue_stats(self, store):
        """Should return queue statistics."""
        # Queue multiple jobs
        job1 = store.queue_webhook_retry("run_completed", "grid-1", "url1", {}, {})
        job2 = store.queue_webhook_retry("run_failed", "grid-2", "url2", {}, {})
        
        store.mark_webhook_delivered(job1.job_id)
        
        stats = store.get_queue_stats()
        
        assert stats["delivered"] == 1
        assert stats["pending"] == 1


class TestCheckpointIntegration:
    """Integration tests for checkpoint with multiple nodes."""
    
    @pytest.fixture
    def store(self, tmp_path):
        """Create a temporary checkpoint store."""
        db_path = str(tmp_path / "test_integration.db")
        return CheckpointStore(db_path)
    
    def test_multi_node_execution(self, store):
        """Should track execution of multiple nodes."""
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="yaml",
            inputs={"project": "test"},
        )
        
        # Simulate execution
        store.checkpoint_node_started("run-123", "controller")
        store.checkpoint_node_complete("run-123", "controller", {"plan": "ok"}, 100)
        
        store.checkpoint_node_started("run-123", "relay-1")
        store.checkpoint_node_started("run-123", "relay-2")
        
        # relay-1 succeeds, relay-2 fails
        store.checkpoint_node_complete("run-123", "relay-1", {"result": "ok"}, 200)
        store.checkpoint_node_failed("run-123", "relay-2", "timeout")
        
        checkpoint = store.get_checkpoint("run-123")
        
        assert checkpoint.completed_nodes == ["controller", "relay-1"]
        assert checkpoint.failed_nodes == ["relay-2"]
        assert checkpoint.running_nodes == []  # Both finished
        assert checkpoint.total_tokens == 300
        assert len(checkpoint.outputs) == 2
    
    def test_resume_preserves_state(self, store):
        """Should preserve all state after resume."""
        # Create and partially execute
        store.create_checkpoint(
            run_id="run-123",
            grid_id="grid-456",
            grid_yaml="original: yaml",
            inputs={"key": "value"},
        )
        
        store.checkpoint_node_complete("run-123", "node-1", {"out": 1}, 100, 0.01)
        store.checkpoint_node_complete("run-123", "node-2", {"out": 2}, 150, 0.02)
        
        # Simulate crash and resume
        store.mark_abandoned("run-123")
        store.increment_resume_count("run-123")
        
        checkpoint = store.get_checkpoint("run-123")
        
        assert checkpoint.status == CheckpointStatus.ACTIVE
        assert checkpoint.resume_count == 1
        assert checkpoint.completed_nodes == ["node-1", "node-2"]
        assert checkpoint.outputs["node-1"] == {"out": 1}
        assert checkpoint.outputs["node-2"] == {"out": 2}
        assert checkpoint.total_tokens == 250
        assert checkpoint.total_cost == 0.03
        assert checkpoint.grid_yaml == "original: yaml"
        assert checkpoint.inputs == {"key": "value"}
