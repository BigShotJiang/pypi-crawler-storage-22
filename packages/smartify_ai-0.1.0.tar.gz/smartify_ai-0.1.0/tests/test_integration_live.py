"""Integration tests that hit real LLM APIs.

These tests require actual API keys and make real network calls.
Run with: pytest tests/test_integration_live.py -v -s

Set environment variables:
- ANTHROPIC_API_KEY for Anthropic tests
- OPENAI_API_KEY for OpenAI tests

Skip with: pytest -m "not live"
"""

import os
import pytest
import tempfile
from pathlib import Path

# Mark all tests in this module as "live" (requires real API)
pytestmark = pytest.mark.live


# Skip entire module if no API keys
def pytest_configure(config):
    config.addinivalue_line("markers", "live: tests that hit real APIs")


@pytest.fixture
def has_anthropic_key():
    """Check if Anthropic API key is available."""
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        pytest.skip("ANTHROPIC_API_KEY not set")
    return key


@pytest.fixture
def has_openai_key():
    """Check if OpenAI API key is available."""
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        pytest.skip("OPENAI_API_KEY not set")
    return key


@pytest.fixture
def temp_db(tmp_path):
    """Create a temporary database for tests."""
    return str(tmp_path / "test_live.db")


class TestAnthropicLive:
    """Live tests for Anthropic adapter."""
    
    @pytest.mark.asyncio
    async def test_simple_completion(self, has_anthropic_key):
        """Should complete a simple prompt."""
        from smartify.agents.adapters import AnthropicAdapter
        
        adapter = AnthropicAdapter()
        
        response = await adapter.complete(
            messages=[{"role": "user", "content": "Say 'hello' and nothing else."}],
            max_tokens=50,
        )
        
        assert response["content"] is not None
        assert "hello" in response["content"].lower()
        assert response["tokens_in"] > 0
        assert response["tokens_out"] > 0
        assert response["cost"] > 0
        assert response["stop_reason"] == "end_turn"
        
        await adapter.close()
    
    @pytest.mark.asyncio
    async def test_completion_with_system_prompt(self, has_anthropic_key):
        """Should respect system prompt."""
        from smartify.agents.adapters import AnthropicAdapter
        
        adapter = AnthropicAdapter()
        
        response = await adapter.complete(
            messages=[{"role": "user", "content": "What language do you speak?"}],
            system="You are a French speaker. Always respond in French only.",
            max_tokens=100,
        )
        
        # Should contain some French
        content = response["content"].lower()
        assert any(word in content for word in ["je", "français", "parle", "bonjour", "oui"])
        
        await adapter.close()
    
    @pytest.mark.asyncio
    async def test_tool_calling(self, has_anthropic_key):
        """Should call tools when appropriate."""
        from smartify.agents.adapters import AnthropicAdapter
        
        adapter = AnthropicAdapter()
        
        tools = [{
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get the current weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "City name"
                        }
                    },
                    "required": ["location"]
                }
            }
        }]
        
        response = await adapter.complete(
            messages=[{"role": "user", "content": "What's the weather in Tokyo?"}],
            tools=tools,
            max_tokens=200,
        )
        
        # Should have made a tool call
        assert response["tool_calls"] is not None
        assert len(response["tool_calls"]) > 0
        assert response["tool_calls"][0]["name"] == "get_weather"
        assert "tokyo" in response["tool_calls"][0]["arguments"].get("location", "").lower()
        
        await adapter.close()


class TestOpenAILive:
    """Live tests for OpenAI adapter."""
    
    @pytest.mark.asyncio
    async def test_simple_completion(self, has_openai_key):
        """Should complete a simple prompt."""
        from smartify.agents.adapters import OpenAIAdapter
        
        adapter = OpenAIAdapter()
        
        response = await adapter.complete(
            messages=[{"role": "user", "content": "Say 'hello' and nothing else."}],
            max_tokens=50,
        )
        
        assert response["content"] is not None
        assert "hello" in response["content"].lower()
        assert response["tokens_in"] > 0
        assert response["tokens_out"] > 0
        assert response["cost"] > 0
        
        await adapter.close()
    
    @pytest.mark.asyncio
    async def test_tool_calling(self, has_openai_key):
        """Should call tools when appropriate."""
        from smartify.agents.adapters import OpenAIAdapter
        
        adapter = OpenAIAdapter()
        
        tools = [{
            "type": "function",
            "function": {
                "name": "calculate",
                "description": "Perform arithmetic calculation",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {
                            "type": "string",
                            "description": "Math expression to evaluate"
                        }
                    },
                    "required": ["expression"]
                }
            }
        }]
        
        response = await adapter.complete(
            messages=[{"role": "user", "content": "What is 15 * 7?"}],
            tools=tools,
            max_tokens=200,
        )
        
        # Should have made a tool call
        assert response["tool_calls"] is not None
        assert len(response["tool_calls"]) > 0
        assert response["tool_calls"][0]["name"] == "calculate"
        
        await adapter.close()
    
    @pytest.mark.asyncio
    async def test_model_override(self, has_openai_key):
        """Should work with model override in complete()."""
        from smartify.agents.adapters import OpenAIAdapter
        import openai
        
        adapter = OpenAIAdapter()  # Uses default gpt-4o
        
        # Try gpt-4o-mini, fall back to default if not available
        try:
            response = await adapter.complete(
                messages=[{"role": "user", "content": "What is 2+2?"}],
                model="gpt-4o-mini",
                max_tokens=50,
            )
            assert response["model"] == "gpt-4o-mini"
        except openai.PermissionDeniedError:
            pytest.skip("gpt-4o-mini not available in this project")
        
        assert "4" in response["content"]
        
        await adapter.close()


class TestOrchestratorLive:
    """Live end-to-end orchestrator tests."""
    
    @pytest.fixture
    def minimal_grid_yaml(self):
        """A minimal grid for testing."""
        return """
apiVersion: smartify.ai/v1
kind: GridSpec

metadata:
  id: test-live-grid
  name: Live Test Grid

topology:
  nodes:
    - id: controller
      kind: controller
      name: Test Controller
      description: Answer the user's question briefly.
      prompt:
        template: "Answer in one sentence: What is the capital of France?"
"""
    
    @pytest.mark.asyncio
    async def test_minimal_grid_execution(self, has_anthropic_key, minimal_grid_yaml, temp_db):
        """Should execute a minimal grid end-to-end."""
        from smartify.engine.orchestrator import Orchestrator
        from smartify.agents.adapters import AnthropicAdapter
        from smartify.models.grid import GridState
        
        orchestrator = Orchestrator(enable_checkpoints=False)
        
        # Register adapter
        adapter = AnthropicAdapter()
        orchestrator.register_llm_adapter("anthropic", adapter)
        orchestrator.register_llm_adapter("default", adapter)
        
        # Load and run
        run = await orchestrator.load_grid(minimal_grid_yaml)
        await orchestrator.energize(run)
        result = await orchestrator.execute(run)
        
        # Verify
        assert run.state == GridState.COMPLETED
        assert result["state"] == "completed"
        assert result["total_tokens"] > 0
        assert result["total_cost"] > 0
        assert "controller" in result["node_outputs"]
        
        # Should mention Paris
        controller_output = result["node_outputs"]["controller"]
        assert "paris" in controller_output.get("response", "").lower()
        
        await adapter.close()
    
    @pytest.fixture
    def multi_node_grid_yaml(self):
        """A grid with multiple nodes."""
        return """
apiVersion: smartify.ai/v1
kind: GridSpec

metadata:
  id: test-multi-node
  name: Multi-Node Test

topology:
  nodes:
    - id: controller
      kind: controller
      name: Planner
      prompt:
        template: "Plan a 2-step approach to explain what Python is. Just list the steps."
    
    - id: step1
      kind: substation
      parent: controller
      name: Step 1
      prompt:
        template: "Based on the plan, explain step 1 briefly."
    
    - id: step2
      kind: substation
      parent: controller
      name: Step 2
      prompt:
        template: "Based on the plan, explain step 2 briefly."
"""
    
    @pytest.mark.asyncio
    async def test_multi_node_execution(self, has_anthropic_key, multi_node_grid_yaml, temp_db):
        """Should execute multiple nodes in sequence."""
        from smartify.engine.orchestrator import Orchestrator
        from smartify.agents.adapters import AnthropicAdapter
        from smartify.models.grid import GridState
        
        orchestrator = Orchestrator(enable_checkpoints=False)
        
        adapter = AnthropicAdapter()
        orchestrator.register_llm_adapter("default", adapter)
        
        run = await orchestrator.load_grid(multi_node_grid_yaml)
        await orchestrator.energize(run)
        result = await orchestrator.execute(run)
        
        assert run.state == GridState.COMPLETED
        assert "controller" in result["node_outputs"]
        assert "step1" in result["node_outputs"]
        assert "step2" in result["node_outputs"]
        
        # All nodes should have produced output
        for node_id in ["controller", "step1", "step2"]:
            output = result["node_outputs"][node_id]
            assert output.get("response"), f"Node {node_id} has no response"
        
        await adapter.close()
    
    @pytest.fixture
    def grid_with_tools_yaml(self):
        """A grid that uses builtin tools."""
        return """
apiVersion: smartify.ai/v1
kind: GridSpec

metadata:
  id: test-tools
  name: Tool Test Grid

topology:
  nodes:
    - id: controller
      kind: controller
      name: File Creator
      prompt:
        template: "Create a file called 'test_output.txt' with the content 'Hello from Smartify!' using the file_write tool."
      tools:
        - file_write
"""
    
    @pytest.mark.asyncio
    async def test_tool_execution(self, has_anthropic_key, grid_with_tools_yaml, tmp_path):
        """Should execute tools during grid run."""
        from smartify.engine.orchestrator import Orchestrator
        from smartify.agents.adapters import AnthropicAdapter
        from smartify.tools.builtin import create_builtin_registry
        
        # Create registry with custom base path
        registry = create_builtin_registry(base_path=str(tmp_path))
        
        orchestrator = Orchestrator(
            tool_registry=registry,
            enable_checkpoints=False,
        )
        
        adapter = AnthropicAdapter()
        orchestrator.register_llm_adapter("default", adapter)
        
        run = await orchestrator.load_grid(grid_with_tools_yaml)
        await orchestrator.energize(run)
        result = await orchestrator.execute(run)
        
        # Check if file was created
        output_file = tmp_path / "test_output.txt"
        if output_file.exists():
            content = output_file.read_text()
            assert "Hello" in content or "Smartify" in content
        
        await adapter.close()


class TestCheckpointLive:
    """Live tests for checkpoint/resume functionality."""
    
    @pytest.mark.asyncio
    async def test_checkpoint_created_during_execution(self, has_anthropic_key, temp_db):
        """Should create checkpoints during execution."""
        from smartify.engine.orchestrator import Orchestrator
        from smartify.agents.adapters import AnthropicAdapter
        from smartify.state.checkpoint import CheckpointStore
        
        store = CheckpointStore(temp_db)
        orchestrator = Orchestrator(
            checkpoint_store=store,
            enable_checkpoints=True,
        )
        
        adapter = AnthropicAdapter()
        orchestrator.register_llm_adapter("default", adapter)
        
        grid_yaml = """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  id: checkpoint-test
  name: Checkpoint Test
topology:
  nodes:
    - id: controller
      kind: controller
      name: Simple Task
      prompt:
        template: "Say hello."
"""
        
        run = await orchestrator.load_grid(grid_yaml)
        await orchestrator.energize(run)
        await orchestrator.execute(run)
        
        # Verify checkpoint was created and completed
        checkpoint = store.get_checkpoint(run.run_id)
        assert checkpoint is not None
        assert checkpoint.status.value == "completed"
        assert "controller" in checkpoint.completed_nodes
        assert checkpoint.total_tokens > 0
        
        await adapter.close()


class TestWebhookLive:
    """Live tests for webhook delivery (requires webhook.site or similar)."""
    
    @pytest.mark.asyncio
    @pytest.mark.skip(reason="Requires external webhook endpoint")
    async def test_webhook_delivery(self):
        """Should deliver webhooks to external endpoint."""
        # This test requires a webhook.site URL or similar
        # Uncomment and configure to test
        pass
