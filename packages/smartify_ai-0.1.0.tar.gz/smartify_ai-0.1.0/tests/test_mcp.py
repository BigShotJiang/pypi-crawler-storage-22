"""Tests for MCP (Model Context Protocol) integration.

Run with: pytest tests/test_mcp.py -v

Note: These tests mock the MCP SDK. For live tests with real MCP servers,
run: pytest tests/test_mcp.py -v -m mcp_live
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Any, Dict, List

# Mark tests that need MCP SDK
pytestmark = pytest.mark.skipif(
    not pytest.importorskip("mcp", reason="MCP SDK not installed"),
    reason="MCP SDK not installed"
)


class TestMcpServerConfig:
    """Tests for McpServerConfig dataclass."""

    def test_stdio_config(self):
        from smartify.tools.mcp import McpServerConfig, McpTransport

        config = McpServerConfig(
            id="test-server",
            transport=McpTransport.STDIO,
            command="python",
            args=["-m", "mcp_server"],
            prefix="test",
        )

        assert config.id == "test-server"
        assert config.transport == McpTransport.STDIO
        assert config.command == "python"
        assert config.args == ["-m", "mcp_server"]
        assert config.prefix == "test"

    def test_sse_config(self):
        from smartify.tools.mcp import McpServerConfig, McpTransport

        config = McpServerConfig(
            id="remote-server",
            transport=McpTransport.SSE,
            url="http://localhost:8000/sse",
            headers={"Authorization": "Bearer token"},
        )

        assert config.transport == McpTransport.SSE
        assert config.url == "http://localhost:8000/sse"
        assert config.headers == {"Authorization": "Bearer token"}


class TestMcpToolWrapper:
    """Tests for McpToolWrapper."""

    @pytest.fixture
    def mock_client(self):
        """Create a mock MCP client."""
        from smartify.tools.mcp import McpServerConfig, McpTransport

        client = MagicMock()
        client.config = McpServerConfig(
            id="test-server",
            transport=McpTransport.STDIO,
            command="echo",
        )
        client.is_connected = True
        return client

    @pytest.fixture
    def sample_tool_def(self):
        """Create a sample MCP tool definition."""
        from smartify.tools.mcp.client import McpToolDef

        return McpToolDef(
            name="read_file",
            description="Read contents of a file",
            parameters={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"}
                },
                "required": ["path"],
            },
        )

    def test_name_without_prefix(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        wrapper = McpToolWrapper(mock_client, sample_tool_def)
        assert wrapper.name == "read_file"
        assert wrapper.mcp_tool_name == "read_file"

    def test_name_with_prefix(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        wrapper = McpToolWrapper(mock_client, sample_tool_def, prefix="fs")
        assert wrapper.name == "fs_read_file"
        assert wrapper.mcp_tool_name == "read_file"

    def test_description_and_parameters(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        wrapper = McpToolWrapper(mock_client, sample_tool_def)
        assert wrapper.description == "Read contents of a file"
        assert wrapper.parameters["type"] == "object"
        assert "path" in wrapper.parameters["properties"]

    def test_to_openai_format(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        wrapper = McpToolWrapper(mock_client, sample_tool_def, prefix="fs")
        openai_format = wrapper.to_openai_format()

        assert openai_format["type"] == "function"
        assert openai_format["function"]["name"] == "fs_read_file"
        assert openai_format["function"]["description"] == "Read contents of a file"

    def test_to_anthropic_format(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        wrapper = McpToolWrapper(mock_client, sample_tool_def, prefix="fs")
        anthropic_format = wrapper.to_anthropic_format()

        assert anthropic_format["name"] == "fs_read_file"
        assert anthropic_format["description"] == "Read contents of a file"
        assert "input_schema" in anthropic_format

    @pytest.mark.asyncio
    async def test_execute_success(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        mock_client.call_tool = AsyncMock(
            return_value={
                "success": True,
                "output": "file contents here",
                "error": None,
            }
        )

        wrapper = McpToolWrapper(mock_client, sample_tool_def)
        result = await wrapper.execute(path="/tmp/test.txt")

        assert result.success is True
        assert result.output == "file contents here"
        assert result.error is None
        mock_client.call_tool.assert_called_once_with("read_file", {"path": "/tmp/test.txt"})

    @pytest.mark.asyncio
    async def test_execute_failure(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        mock_client.call_tool = AsyncMock(
            return_value={
                "success": False,
                "output": None,
                "error": "File not found",
            }
        )

        wrapper = McpToolWrapper(mock_client, sample_tool_def)
        result = await wrapper.execute(path="/nonexistent")

        assert result.success is False
        assert result.error == "File not found"

    @pytest.mark.asyncio
    async def test_execute_not_connected(self, mock_client, sample_tool_def):
        from smartify.tools.mcp import McpToolWrapper

        mock_client.is_connected = False

        wrapper = McpToolWrapper(mock_client, sample_tool_def)
        result = await wrapper.execute(path="/tmp/test.txt")

        assert result.success is False
        assert "not connected" in result.error.lower()


class TestRegisterMcpServer:
    """Tests for register_mcp_server function."""

    @pytest.mark.asyncio
    async def test_register_mcp_server(self):
        from smartify.tools import ToolRegistry
        from smartify.tools.mcp import McpServerConfig, McpTransport
        from smartify.tools.mcp.client import McpToolDef

        # Create a mock client
        mock_client = MagicMock()
        mock_client.config = McpServerConfig(
            id="test-server",
            transport=McpTransport.STDIO,
            command="echo",
            prefix="test",
        )
        mock_client.is_connected = True

        # Mock list_tools to return some tools
        mock_client.list_tools = AsyncMock(
            return_value=[
                McpToolDef(
                    name="tool_a",
                    description="Tool A",
                    parameters={"type": "object", "properties": {}},
                ),
                McpToolDef(
                    name="tool_b",
                    description="Tool B",
                    parameters={"type": "object", "properties": {}},
                ),
            ]
        )

        # Register
        registry = ToolRegistry()

        from smartify.tools.mcp.registry import register_mcp_server

        tool_names = await register_mcp_server(registry, mock_client.config, client=mock_client)

        assert len(tool_names) == 2
        assert "test_tool_a" in tool_names
        assert "test_tool_b" in tool_names

        # Verify tools are in registry
        assert registry.get("test_tool_a") is not None
        assert registry.get("test_tool_b") is not None


class TestMcpServerSpec:
    """Tests for McpServerSpec in grid models."""

    def test_mcp_server_spec_parsing(self):
        from smartify.models.grid import McpServerSpec

        spec = McpServerSpec(
            id="filesystem",
            transport="stdio",
            command="npx",
            args=["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
            prefix="fs",
        )

        assert spec.id == "filesystem"
        assert spec.transport == "stdio"
        assert spec.command == "npx"
        assert spec.prefix == "fs"

    def test_tools_spec_with_mcp_servers(self):
        from smartify.models.grid import ToolsSpec, McpServerSpec

        spec = ToolsSpec(
            enabled=["shell", "file_read"],
            mcpServers=[
                McpServerSpec(
                    id="fs",
                    transport="stdio",
                    command="npx",
                    args=["-y", "@modelcontextprotocol/server-filesystem"],
                ),
            ],
        )

        assert len(spec.mcpServers) == 1
        assert spec.mcpServers[0].id == "fs"

    def test_grid_spec_with_mcp(self):
        import yaml
        from smartify.models.grid import GridSpec

        grid_yaml = """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  id: mcp-test
  name: MCP Test Grid
tools:
  mcpServers:
    - id: filesystem
      transport: stdio
      command: npx
      args: ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"]
      prefix: fs
topology:
  nodes:
    - id: controller
      kind: controller
      name: Main
"""
        spec_dict = yaml.safe_load(grid_yaml)
        grid = GridSpec.model_validate(spec_dict)

        assert grid.tools is not None
        assert len(grid.tools.mcpServers) == 1
        assert grid.tools.mcpServers[0].id == "filesystem"
        assert grid.tools.mcpServers[0].prefix == "fs"
