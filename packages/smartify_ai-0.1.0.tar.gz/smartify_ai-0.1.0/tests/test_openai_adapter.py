"""Tests for OpenAI LLM adapter.

Unit tests mock AsyncOpenAI so no real HTTP client is created (avoids
openai/httpx version conflicts). The adapter uses OPENAI_API_KEY from
the environment when api_key is not passed; live tests in
test_integration_live.py use OPENAI_API_KEY for real API calls.
"""

import os
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from smartify.agents.adapters.openai import OpenAIAdapter, MODEL_PRICING, DEFAULT_MODEL


@pytest.fixture(autouse=True)
def mock_async_openai():
    """Mock AsyncOpenAI so unit tests never create a real HTTP client.

    Avoids TypeError from openai/httpx version mismatch (e.g. 'proxies'
    kwarg). Tests that need a specific client behavior replace
    adapter._client with their own mock.
    """
    with patch("smartify.agents.adapters.openai.AsyncOpenAI") as m:
        m.return_value = MagicMock()
        yield m


class TestOpenAIAdapterInit:
    """Test adapter initialization."""
    
    def test_init_with_api_key(self):
        """Should initialize with explicit API key."""
        adapter = OpenAIAdapter(api_key="sk-test-key")
        assert adapter.api_key == "sk-test-key"
        assert adapter.model == DEFAULT_MODEL
    
    def test_init_with_env_var(self, monkeypatch):
        """Should use OPENAI_API_KEY env var."""
        monkeypatch.setenv("OPENAI_API_KEY", "sk-env-key")
        adapter = OpenAIAdapter()
        assert adapter.api_key == "sk-env-key"
    
    def test_init_without_key_raises(self, monkeypatch):
        """Should raise if no API key available."""
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        with pytest.raises(ValueError, match="OpenAI API key required"):
            OpenAIAdapter()
    
    def test_init_with_custom_model(self):
        """Should allow custom model selection."""
        adapter = OpenAIAdapter(api_key="sk-test", model="gpt-4-turbo")
        assert adapter.model == "gpt-4-turbo"
    
    def test_init_with_organization(self):
        """Should pass organization to client."""
        adapter = OpenAIAdapter(api_key="sk-test", organization="org-123")
        # Organization is passed to client constructor


class TestOpenAIAdapterComplete:
    """Test completion functionality."""
    
    @pytest.fixture
    def adapter(self):
        """Create adapter with mocked client."""
        adapter = OpenAIAdapter(api_key="sk-test")
        adapter._client = AsyncMock()
        return adapter
    
    @pytest.mark.asyncio
    async def test_basic_completion(self, adapter):
        """Should handle basic completion request."""
        # Mock response
        mock_choice = MagicMock()
        mock_choice.message.content = "Hello! How can I help?"
        mock_choice.message.tool_calls = None
        mock_choice.finish_reason = "stop"
        
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        
        adapter._client.chat.completions.create = AsyncMock(return_value=mock_response)
        
        result = await adapter.complete(
            messages=[{"role": "user", "content": "Hello!"}]
        )
        
        assert result["content"] == "Hello! How can I help?"
        assert result["tokens_in"] == 10
        assert result["tokens_out"] == 5
        assert result["stop_reason"] == "end_turn"
        assert result["tool_calls"] is None
    
    @pytest.mark.asyncio
    async def test_completion_with_system_prompt(self, adapter):
        """Should prepend system message."""
        mock_choice = MagicMock()
        mock_choice.message.content = "I am a poet."
        mock_choice.message.tool_calls = None
        mock_choice.finish_reason = "stop"
        
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage.prompt_tokens = 20
        mock_response.usage.completion_tokens = 4
        
        adapter._client.chat.completions.create = AsyncMock(return_value=mock_response)
        
        await adapter.complete(
            messages=[{"role": "user", "content": "Who are you?"}],
            system="You are a poet."
        )
        
        # Verify system message was prepended
        call_kwargs = adapter._client.chat.completions.create.call_args.kwargs
        messages = call_kwargs["messages"]
        assert messages[0]["role"] == "system"
        assert messages[0]["content"] == "You are a poet."
    
    @pytest.mark.asyncio
    async def test_completion_with_tools(self, adapter):
        """Should handle tool call response."""
        mock_tool_call = MagicMock()
        mock_tool_call.id = "call_123"
        mock_tool_call.function.name = "get_weather"
        mock_tool_call.function.arguments = '{"location": "NYC"}'
        
        mock_choice = MagicMock()
        mock_choice.message.content = ""
        mock_choice.message.tool_calls = [mock_tool_call]
        mock_choice.finish_reason = "tool_calls"
        
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage.prompt_tokens = 50
        mock_response.usage.completion_tokens = 20
        
        adapter._client.chat.completions.create = AsyncMock(return_value=mock_response)
        
        tools = [{
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    }
                }
            }
        }]
        
        result = await adapter.complete(
            messages=[{"role": "user", "content": "What's the weather in NYC?"}],
            tools=tools
        )
        
        assert result["stop_reason"] == "tool_use"
        assert result["tool_calls"] is not None
        assert len(result["tool_calls"]) == 1
        assert result["tool_calls"][0]["id"] == "call_123"
        assert result["tool_calls"][0]["name"] == "get_weather"
        assert result["tool_calls"][0]["arguments"] == {"location": "NYC"}
    
    @pytest.mark.asyncio
    async def test_model_override(self, adapter):
        """Should allow per-request model override."""
        mock_choice = MagicMock()
        mock_choice.message.content = "Response"
        mock_choice.message.tool_calls = None
        mock_choice.finish_reason = "stop"
        
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage.prompt_tokens = 5
        mock_response.usage.completion_tokens = 2
        
        adapter._client.chat.completions.create = AsyncMock(return_value=mock_response)
        
        result = await adapter.complete(
            messages=[{"role": "user", "content": "Test"}],
            model="gpt-4-turbo"
        )
        
        call_kwargs = adapter._client.chat.completions.create.call_args.kwargs
        assert call_kwargs["model"] == "gpt-4-turbo"
        assert result["model"] == "gpt-4-turbo"


class TestOpenAIAdapterCostCalculation:
    """Test cost calculation."""
    
    def test_cost_for_gpt4o(self):
        """Should calculate cost for gpt-4o."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        # gpt-4o: $2.50/M input, $10/M output
        cost = adapter._calculate_cost("gpt-4o", 1000, 500)
        expected = (1000 / 1_000_000) * 2.50 + (500 / 1_000_000) * 10.00
        assert abs(cost - expected) < 0.0001
    
    def test_cost_for_gpt4o_mini(self):
        """Should calculate cost for gpt-4o-mini."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        # gpt-4o-mini: $0.15/M input, $0.60/M output
        cost = adapter._calculate_cost("gpt-4o-mini", 10000, 5000)
        expected = (10000 / 1_000_000) * 0.15 + (5000 / 1_000_000) * 0.60
        assert abs(cost - expected) < 0.0001
    
    def test_cost_for_unknown_model_uses_default(self):
        """Should use default model pricing for unknown models."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        # Unknown model should fall back to gpt-4o pricing
        cost = adapter._calculate_cost("gpt-5-future", 1000, 500)
        expected_pricing = MODEL_PRICING[DEFAULT_MODEL]
        expected = (1000 / 1_000_000) * expected_pricing["input"] + (500 / 1_000_000) * expected_pricing["output"]
        assert abs(cost - expected) < 0.0001


class TestOpenAIAdapterMessageConversion:
    """Test message format conversion."""
    
    def test_basic_messages(self):
        """Should convert basic messages."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]
        
        converted = adapter._convert_messages(messages)
        
        assert len(converted) == 2
        assert converted[0] == {"role": "user", "content": "Hello"}
        assert converted[1] == {"role": "assistant", "content": "Hi there!"}
    
    def test_system_prepended(self):
        """Should prepend system message."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        messages = [{"role": "user", "content": "Hello"}]
        converted = adapter._convert_messages(messages, system="Be helpful")
        
        assert len(converted) == 2
        assert converted[0] == {"role": "system", "content": "Be helpful"}
        assert converted[1] == {"role": "user", "content": "Hello"}
    
    def test_tool_results(self):
        """Should convert tool result messages."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        messages = [
            {"role": "tool", "tool_call_id": "call_123", "content": "72°F"}
        ]
        
        converted = adapter._convert_messages(messages)
        
        assert len(converted) == 1
        assert converted[0]["role"] == "tool"
        assert converted[0]["tool_call_id"] == "call_123"


class TestOpenAIAdapterToolConversion:
    """Test tool format conversion."""
    
    def test_openai_format_passthrough(self):
        """Should pass through OpenAI-format tools."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        tools = [{
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get weather",
                "parameters": {"type": "object", "properties": {}}
            }
        }]
        
        converted = adapter._convert_tools(tools)
        assert converted == tools
    
    def test_anthropic_format_conversion(self):
        """Should convert Anthropic-style tool definitions."""
        adapter = OpenAIAdapter(api_key="sk-test")
        
        tools = [{
            "name": "get_weather",
            "description": "Get weather for a location",
            "input_schema": {
                "type": "object",
                "properties": {
                    "location": {"type": "string"}
                }
            }
        }]
        
        converted = adapter._convert_tools(tools)
        
        assert len(converted) == 1
        assert converted[0]["type"] == "function"
        assert converted[0]["function"]["name"] == "get_weather"
        assert converted[0]["function"]["description"] == "Get weather for a location"
        assert "location" in converted[0]["function"]["parameters"]["properties"]


class TestOpenAIAdapterStopReasonMapping:
    """Test finish_reason to stop_reason mapping."""
    
    def test_stop_mapping(self):
        """Should map 'stop' to 'end_turn'."""
        adapter = OpenAIAdapter(api_key="sk-test")
        assert adapter._map_stop_reason("stop") == "end_turn"
    
    def test_length_mapping(self):
        """Should map 'length' to 'max_tokens'."""
        adapter = OpenAIAdapter(api_key="sk-test")
        assert adapter._map_stop_reason("length") == "max_tokens"
    
    def test_tool_calls_mapping(self):
        """Should map 'tool_calls' to 'tool_use'."""
        adapter = OpenAIAdapter(api_key="sk-test")
        assert adapter._map_stop_reason("tool_calls") == "tool_use"
    
    def test_none_mapping(self):
        """Should handle None gracefully."""
        adapter = OpenAIAdapter(api_key="sk-test")
        assert adapter._map_stop_reason(None) == "end_turn"


class TestOpenAIAdapterContextManager:
    """Test async context manager support."""
    
    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Should work as async context manager."""
        adapter = OpenAIAdapter(api_key="sk-test")
        adapter._client = AsyncMock()
        adapter._client.close = AsyncMock()
        
        async with adapter as a:
            assert a is adapter
        
        adapter._client.close.assert_called_once()
