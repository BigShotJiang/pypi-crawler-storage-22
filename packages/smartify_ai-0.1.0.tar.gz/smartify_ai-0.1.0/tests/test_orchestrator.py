"""Tests for the Grid Orchestrator."""

import pytest
from datetime import datetime
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch, MagicMock
import tempfile
import yaml

from smartify.engine.orchestrator import (
    Orchestrator,
    ExecutionContext,
    NodeResult,
    ExecutionError,
    GridLifecycleError,
    LLMAdapter,
    ToolAdapter,
)
from smartify.models.grid import GridSpec, GridState, NodeKind


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def orchestrator():
    """Fresh Orchestrator instance."""
    return Orchestrator()


@pytest.fixture
def mock_llm_adapter():
    """Mock LLM adapter."""
    adapter = Mock(spec=LLMAdapter)
    adapter.complete = AsyncMock(return_value={
        "content": "Test response",
        "tool_calls": None,
        "tokens_in": 10,
        "tokens_out": 20,
        "cost": 0.001,
        "model": "test-model",
        "stop_reason": "end_turn",
    })
    return adapter


@pytest.fixture
def mock_tool_adapter():
    """Mock tool adapter."""
    adapter = Mock(spec=ToolAdapter)
    adapter.execute = AsyncMock(return_value={"result": "success"})
    return adapter


@pytest.fixture
def minimal_grid_yaml():
    """Minimal valid grid YAML."""
    return """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  name: test-grid
  id: test-grid-123
topology:
  nodes:
    - id: controller
      kind: controller
      name: Test Controller
      description: Test controller
"""


@pytest.fixture
def minimal_grid_dict():
    """Minimal valid grid as dict."""
    return {
        "apiVersion": "smartify.ai/v1",
        "kind": "GridSpec",
        "metadata": {"name": "test-grid", "id": "test-grid-123"},
        "topology": {
            "nodes": [
                {"id": "controller", "kind": "controller", "name": "Test", "description": "Test"}
            ]
        }
    }


@pytest.fixture
def multi_node_grid_yaml():
    """Grid with multiple nodes."""
    return """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  name: multi-node-grid
  id: multi-node-123
topology:
  nodes:
    - id: controller
      kind: controller
      name: Main Controller
      description: Main controller
    - id: relay-1
      kind: relay
      name: Relay 1
      parent: controller
      description: Coordination relay
    - id: worker-1
      kind: substation
      name: Worker 1
      parent: relay-1
      description: Worker node
"""


# ============================================================================
# Orchestrator Initialization
# ============================================================================

class TestOrchestratorInit:
    """Tests for Orchestrator initialization."""
    
    def test_init_defaults(self, orchestrator):
        """Test default initialization."""
        assert orchestrator.llm_adapters == {}
        assert orchestrator.tool_adapters == {}
        assert orchestrator.runs == {}
        assert orchestrator.tool_registry is not None
    
    def test_init_with_checkpoint_store(self):
        """Test initialization with checkpoint store."""
        store = Mock()
        orch = Orchestrator(checkpoint_store=store, enable_checkpoints=True)
        
        assert orch.checkpoint_store is store
        assert orch.enable_checkpoints is True
    
    def test_init_checkpoints_enabled_by_default(self, orchestrator):
        """Test checkpoints enabled by default."""
        assert orchestrator.enable_checkpoints is True


# ============================================================================
# Adapter Registration
# ============================================================================

class TestAdapterRegistration:
    """Tests for LLM and tool adapter registration."""
    
    def test_register_llm_adapter(self, orchestrator, mock_llm_adapter):
        """Test registering LLM adapter."""
        orchestrator.register_llm_adapter("test", mock_llm_adapter)
        
        assert "test" in orchestrator.llm_adapters
        assert orchestrator.llm_adapters["test"] is mock_llm_adapter
    
    def test_register_multiple_llm_adapters(self, orchestrator, mock_llm_adapter):
        """Test registering multiple LLM adapters."""
        adapter2 = Mock(spec=LLMAdapter)
        
        orchestrator.register_llm_adapter("adapter1", mock_llm_adapter)
        orchestrator.register_llm_adapter("adapter2", adapter2)
        
        assert len(orchestrator.llm_adapters) == 2
    
    def test_register_tool_adapter(self, orchestrator, mock_tool_adapter):
        """Test registering tool adapter."""
        orchestrator.register_tool_adapter("test", mock_tool_adapter)
        
        assert "test" in orchestrator.tool_adapters


# ============================================================================
# Load Grid
# ============================================================================

class TestLoadGrid:
    """Tests for load_grid method."""
    
    @pytest.mark.asyncio
    async def test_load_from_yaml_string(self, orchestrator, minimal_grid_yaml):
        """Test loading grid from YAML string."""
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        assert run is not None
        assert run.grid.metadata.name == "test-grid"
        # State after load is DRAFT (becomes READY after validation in energize)
        assert run.state in (GridState.DRAFT, GridState.READY)
    
    @pytest.mark.asyncio
    async def test_load_from_dict(self, orchestrator, minimal_grid_dict):
        """Test loading grid from dictionary."""
        run = await orchestrator.load_grid(source=minimal_grid_dict)
        
        assert run is not None
        assert run.grid.metadata.name == "test-grid"
    
    @pytest.mark.asyncio
    async def test_load_from_file(self, orchestrator, minimal_grid_yaml):
        """Test loading grid from file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(minimal_grid_yaml)
            f.flush()
            
            run = await orchestrator.load_grid(source=f.name)
            
            assert run is not None
            assert run.grid.metadata.name == "test-grid"
    
    @pytest.mark.asyncio
    async def test_load_with_inputs(self, orchestrator, minimal_grid_yaml):
        """Test loading grid with inputs."""
        run = await orchestrator.load_grid(
            source=minimal_grid_yaml,
            inputs={"key": "value", "number": 42}
        )
        
        assert run.context.inputs == {"key": "value", "number": 42}
    
    @pytest.mark.asyncio
    async def test_load_initializes_scheduler(self, orchestrator, multi_node_grid_yaml):
        """Test scheduler is initialized on load."""
        run = await orchestrator.load_grid(source=multi_node_grid_yaml)
        
        assert run.scheduler is not None
        assert "controller" in run.scheduler.nodes
        assert "relay-1" in run.scheduler.nodes
        assert "worker-1" in run.scheduler.nodes
    
    @pytest.mark.asyncio
    async def test_load_creates_run_id(self, orchestrator, minimal_grid_yaml):
        """Test run_id is generated."""
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        assert run.run_id is not None
        assert len(run.run_id) > 0
    
    @pytest.mark.asyncio
    async def test_load_stores_run(self, orchestrator, minimal_grid_yaml):
        """Test loaded run is stored in orchestrator."""
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        retrieved = orchestrator.get_run(run.grid.id)
        assert retrieved is run
    
    @pytest.mark.asyncio
    async def test_load_invalid_yaml_raises(self, orchestrator):
        """Test invalid YAML raises error."""
        with pytest.raises(Exception):
            await orchestrator.load_grid(source="not: valid: yaml: [")
    
    @pytest.mark.asyncio
    async def test_load_missing_required_fields_raises(self, orchestrator):
        """Test missing required fields raises validation error."""
        invalid = {"apiVersion": "smartify/v1", "kind": "Grid"}
        
        with pytest.raises(Exception):
            await orchestrator.load_grid(source=invalid)


# ============================================================================
# Energize
# ============================================================================

class TestEnergize:
    """Tests for energize method."""
    
    @pytest.mark.asyncio
    async def test_energize_transitions_state(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test energize transitions to ENERGIZED state."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        assert run.state in (GridState.DRAFT, GridState.READY)
        
        await orchestrator.energize(run)
        
        assert run.state == GridState.ENERGIZED
    
    @pytest.mark.asyncio
    async def test_energize_from_draft_transitions_to_ready_first(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test energize handles DRAFT state properly."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        run.state = GridState.DRAFT  # Force to draft
        
        await orchestrator.energize(run)
        
        # Should end up energized (through ready)
        assert run.state == GridState.ENERGIZED
    
    @pytest.mark.asyncio
    async def test_energize_already_energized_raises(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test energizing already-energized grid raises error."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        
        # Second energize should raise GridLifecycleError
        with pytest.raises(GridLifecycleError):
            await orchestrator.energize(run)


# ============================================================================
# Execute
# ============================================================================

class TestExecute:
    """Tests for execute method."""
    
    @pytest.mark.asyncio
    async def test_execute_transitions_to_running(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test execute transitions state to RUNNING then COMPLETED."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        
        await orchestrator.execute(run)
        
        assert run.state == GridState.COMPLETED
    
    @pytest.mark.asyncio
    async def test_execute_returns_outputs(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test execute returns node outputs."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        
        result = await orchestrator.execute(run)
        
        assert isinstance(result, dict)
        # Result has node_outputs key with node ids
        assert "node_outputs" in result
        assert "controller" in result["node_outputs"]
    
    @pytest.mark.asyncio
    async def test_execute_not_energized_raises(self, orchestrator, minimal_grid_yaml):
        """Test execute on non-energized grid raises."""
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        # Don't energize
        
        with pytest.raises(GridLifecycleError):
            await orchestrator.execute(run)
    
    @pytest.mark.asyncio
    async def test_execute_tracks_tokens(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test execute tracks token usage."""
        mock_llm_adapter.complete.return_value = {
            "content": "Response",
            "tool_calls": None,
            "tokens_in": 100,
            "tokens_out": 200,
            "cost": 0.01,
            "model": "test",
            "stop_reason": "end_turn",
        }
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        await orchestrator.execute(run)
        
        assert run.context.total_tokens >= 300


# ============================================================================
# Pause/Resume/Stop
# ============================================================================

class TestPauseResumeStop:
    """Tests for pause, resume, and stop methods."""
    
    @pytest.mark.asyncio
    async def test_pause_sets_paused_state(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test pause sets state to PAUSED."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        run.state = GridState.RUNNING
        
        await orchestrator.pause(run)
        
        assert run.state == GridState.PAUSED
    
    @pytest.mark.asyncio
    async def test_resume_from_paused(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test resume from paused state."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        run.state = GridState.PAUSED
        
        await orchestrator.resume(run)
        
        # Should be RUNNING or ENERGIZED depending on implementation
        assert run.state in (GridState.RUNNING, GridState.ENERGIZED)
    
    @pytest.mark.asyncio
    async def test_stop_sets_stopped_state(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test stop sets state to STOPPED."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        run.state = GridState.RUNNING
        
        await orchestrator.stop(run)
        
        assert run.state == GridState.STOPPED


# ============================================================================
# Get Run / Get Status
# ============================================================================

class TestGetRunStatus:
    """Tests for get_run and get_status methods."""
    
    @pytest.mark.asyncio
    async def test_get_run_by_id(self, orchestrator, minimal_grid_yaml):
        """Test getting run by grid ID."""
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        retrieved = orchestrator.get_run("test-grid-123")
        
        assert retrieved is run
    
    def test_get_run_not_found(self, orchestrator):
        """Test get_run returns None for unknown ID."""
        result = orchestrator.get_run("nonexistent")
        
        assert result is None
    
    @pytest.mark.asyncio
    async def test_get_status(self, orchestrator, minimal_grid_yaml):
        """Test get_status returns status dict."""
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        status = orchestrator.get_status(run)
        
        assert "state" in status
        assert "grid_id" in status
        assert status["grid_id"] == "test-grid-123"
    
    @pytest.mark.asyncio
    async def test_get_status_includes_scheduler_state(self, orchestrator, multi_node_grid_yaml, mock_llm_adapter):
        """Test status includes scheduler state."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=multi_node_grid_yaml)
        
        status = orchestrator.get_status(run)
        
        # Status includes scheduler info about node states
        assert "scheduler" in status or "state" in status
        assert "grid_id" in status


# ============================================================================
# ExecutionContext
# ============================================================================

class TestExecutionContext:
    """Tests for ExecutionContext class."""
    
    def test_init_defaults(self):
        """Test default initialization."""
        ctx = ExecutionContext(grid_id="grid-1")
        
        assert ctx.grid_id == "grid-1"
        assert ctx.inputs == {}
        assert ctx.outputs == {}
        assert ctx.env == {}
        assert ctx.total_tokens == 0
        assert ctx.total_cost == 0.0
    
    def test_get_set_node_output(self):
        """Test getting and setting node outputs."""
        ctx = ExecutionContext(grid_id="grid-1")
        
        ctx.set_node_output("node-1", {"result": "success"})
        
        output = ctx.get_node_output("node-1")
        assert output == {"result": "success"}
    
    def test_get_node_output_not_found(self):
        """Test get_node_output returns None for unknown node."""
        ctx = ExecutionContext(grid_id="grid-1")
        
        assert ctx.get_node_output("nonexistent") is None
    
    def test_resolve_reference_inputs(self):
        """Test resolving $inputs references."""
        ctx = ExecutionContext(
            grid_id="grid-1",
            inputs={"name": "John", "nested": {"key": "value"}}
        )
        
        assert ctx.resolve_reference("$inputs.name") == "John"
        assert ctx.resolve_reference("$inputs.nested.key") == "value"
    
    def test_resolve_reference_env(self):
        """Test resolving $env references."""
        ctx = ExecutionContext(
            grid_id="grid-1",
            env={"API_KEY": "secret123"}
        )
        
        assert ctx.resolve_reference("$env.API_KEY") == "secret123"
    
    def test_resolve_reference_node_output(self):
        """Test resolving node output references."""
        ctx = ExecutionContext(grid_id="grid-1")
        ctx.set_node_output("controller", {"result": {"data": 42}})
        
        assert ctx.resolve_reference("$controller.result.data") == 42
    
    def test_resolve_reference_non_reference(self):
        """Test non-reference strings pass through."""
        ctx = ExecutionContext(grid_id="grid-1")
        
        assert ctx.resolve_reference("plain text") == "plain text"
        assert ctx.resolve_reference("no-dollar-sign") == "no-dollar-sign"
    
    def test_resolve_reference_missing_returns_none(self):
        """Test resolving missing reference returns None."""
        ctx = ExecutionContext(grid_id="grid-1")
        
        # Missing node
        assert ctx.resolve_reference("$nonexistent.output") is None


class TestExecutionContextBreakers:
    """Tests for ExecutionContext breaker checking."""
    
    def test_check_breakers_under_limits(self):
        """Test check_breakers returns None when under limits."""
        ctx = ExecutionContext(
            grid_id="grid-1",
            token_limit=1000,
            cost_limit=1.0
        )
        ctx.total_tokens = 500
        ctx.total_cost = 0.5
        
        assert ctx.check_breakers() is None
    
    def test_check_breakers_token_limit(self):
        """Test check_breakers detects token limit breach."""
        ctx = ExecutionContext(
            grid_id="grid-1",
            token_limit=1000
        )
        ctx.total_tokens = 1500
        
        result = ctx.check_breakers()
        assert result is not None
        assert "token" in result.lower()
    
    def test_check_breakers_cost_limit(self):
        """Test check_breakers detects cost limit breach."""
        ctx = ExecutionContext(
            grid_id="grid-1",
            cost_limit=1.0
        )
        ctx.total_cost = 1.5
        
        result = ctx.check_breakers()
        assert result is not None
        assert "cost" in result.lower()
    
    def test_check_breakers_no_limits(self):
        """Test check_breakers with no limits set."""
        ctx = ExecutionContext(grid_id="grid-1")
        ctx.total_tokens = 1000000
        ctx.total_cost = 1000.0
        
        # No limits set, should return None
        assert ctx.check_breakers() is None


# ============================================================================
# NodeResult
# ============================================================================

class TestNodeResult:
    """Tests for NodeResult dataclass."""
    
    def test_successful_result(self):
        """Test creating successful result."""
        result = NodeResult(
            node_id="node-1",
            success=True,
            output={"data": "result"},
            started_at=datetime.now(),
            completed_at=datetime.now(),
            tokens_used=100,
        )
        
        assert result.success is True
        assert result.error is None
        assert result.output == {"data": "result"}
    
    def test_failed_result(self):
        """Test creating failed result."""
        result = NodeResult(
            node_id="node-1",
            success=False,
            error="Something went wrong",
        )
        
        assert result.success is False
        assert result.error == "Something went wrong"
        assert result.output is None


# ============================================================================
# Expression Nodes
# ============================================================================

class TestExpressionNode:
    """Tests for expr node execution."""
    
    @pytest.mark.asyncio
    async def test_execute_expr_node(self, orchestrator, mock_llm_adapter):
        """Test executing an expression node."""
        grid_yaml = """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  name: expr-test
  id: expr-test-123
topology:
  nodes:
    - id: controller
      kind: controller
      name: Main
      description: Main controller
    - id: calc
      kind: expr
      name: Calculator
      parent: controller
      description: Calculate something
      expr: "1 + 2 + 3"
"""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=grid_yaml)
        await orchestrator.energize(run)
        result = await orchestrator.execute(run)
        
        assert "node_outputs" in result
        assert "calc" in result["node_outputs"]
        # Expression result should be 6
        assert result["node_outputs"]["calc"].get("result") == 6


# ============================================================================
# Foreach Nodes
# ============================================================================

class TestForeachNode:
    """Tests for foreach node execution."""
    
    @pytest.mark.asyncio
    async def test_foreach_fan_out(self, orchestrator, mock_llm_adapter):
        """Test foreach node fans out over list."""
        grid_yaml = """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  name: foreach-test
  id: foreach-test-123
inputs:
  - name: items
    type: array
    default: [1, 2, 3]
topology:
  nodes:
    - id: controller
      kind: controller
      name: Main Controller
      description: Main
    - id: iterator
      kind: foreach
      name: Iterator
      parent: controller
      description: Iterate items
      foreach:
        over: "$inputs.items"
        as: item
        body:
          to: worker
    - id: worker
      kind: substation
      name: Worker
      parent: iterator
      description: Process item
"""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=grid_yaml)
        await orchestrator.energize(run)
        result = await orchestrator.execute(run)
        
        assert "node_outputs" in result
        assert "iterator" in result["node_outputs"]
        # Should have processed 3 items
        assert result["node_outputs"]["iterator"]["count"] == 3


# ============================================================================
# Aggregate Nodes
# ============================================================================

class TestAggregateNode:
    """Tests for aggregate node execution."""
    
    @pytest.mark.asyncio
    async def test_aggregate_collects_outputs(self, orchestrator, mock_llm_adapter):
        """Test aggregate node collects outputs."""
        grid_yaml = """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  name: agg-test
  id: agg-test-123
topology:
  nodes:
    - id: controller
      kind: controller
      name: Main Controller
      description: Main
    - id: aggregator
      kind: aggregate
      name: Aggregator
      parent: controller
      description: Collect results
      aggregate:
        from: [controller]
        combine: list
"""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=grid_yaml)
        await orchestrator.energize(run)
        result = await orchestrator.execute(run)
        
        assert "node_outputs" in result
        assert "aggregator" in result["node_outputs"]


# ============================================================================
# Webhook Integration
# ============================================================================

class TestWebhookIntegration:
    """Tests for webhook notification integration."""
    
    @pytest.mark.asyncio
    async def test_webhook_notifier_created_from_config(self, orchestrator, mock_llm_adapter):
        """Test webhook notifier is created when notifications configured."""
        grid_yaml = """
apiVersion: smartify.ai/v1
kind: GridSpec
metadata:
  name: webhook-test
  id: webhook-test-123
notifications:
  webhooks:
    - url: https://example.com/hook
      events: [run_completed]
topology:
  nodes:
    - id: controller
      kind: controller
      name: Main Controller
      description: Main
"""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=grid_yaml)
        
        assert run.webhook_notifier is not None


# ============================================================================
# Checkpoint Integration
# ============================================================================

class TestCheckpointIntegration:
    """Tests for checkpoint integration."""
    
    @pytest.mark.asyncio
    async def test_checkpoint_created_on_load(self, minimal_grid_yaml, mock_llm_adapter):
        """Test checkpoint is created when enabled."""
        store = Mock()
        store.create_checkpoint = Mock()
        store.update_checkpoint = Mock()
        store.checkpoint_node_start = Mock()
        store.checkpoint_node_complete = Mock()
        store.mark_completed = Mock()
        
        orchestrator = Orchestrator(checkpoint_store=store, enable_checkpoints=True)
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        store.create_checkpoint.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_no_checkpoint_when_disabled(self, minimal_grid_yaml, mock_llm_adapter):
        """Test no checkpoint when disabled."""
        orchestrator = Orchestrator(enable_checkpoints=False)
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        assert run.checkpoint_store is None


# ============================================================================
# Multi-Node Execution Order
# ============================================================================

class TestExecutionOrder:
    """Tests for node execution order."""
    
    @pytest.mark.asyncio
    async def test_parent_executes_before_children(self, orchestrator, multi_node_grid_yaml, mock_llm_adapter):
        """Test parent nodes execute before children."""
        execution_order = []
        
        async def tracking_complete(*args, **kwargs):
            # Track which node is being executed based on context
            execution_order.append(len(execution_order))
            return {
                "content": "Response",
                "tool_calls": None,
                "tokens_in": 10,
                "tokens_out": 20,
                "cost": 0.001,
                "model": "test",
                "stop_reason": "end_turn",
            }
        
        mock_llm_adapter.complete = AsyncMock(side_effect=tracking_complete)
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=multi_node_grid_yaml)
        await orchestrator.energize(run)
        await orchestrator.execute(run)
        
        # Should have executed 3 LLM nodes
        assert mock_llm_adapter.complete.call_count == 3


# ============================================================================
# Error Handling
# ============================================================================

class TestErrorHandling:
    """Tests for error handling during execution."""
    
    @pytest.mark.asyncio
    async def test_llm_error_marks_node_failed(self, orchestrator, minimal_grid_yaml, mock_llm_adapter):
        """Test LLM error marks node as failed."""
        mock_llm_adapter.complete.side_effect = Exception("LLM API error")
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        await orchestrator.energize(run)
        
        # Execute may not raise, but state should be FAILED
        result = await orchestrator.execute(run)
        
        assert run.state == GridState.FAILED
    
    @pytest.mark.asyncio
    async def test_missing_adapter_raises_on_energize(self, orchestrator, minimal_grid_yaml):
        """Test missing LLM adapter raises error on energize."""
        # Don't register any adapter
        
        run = await orchestrator.load_grid(source=minimal_grid_yaml)
        
        with pytest.raises(ExecutionError, match="No LLM adapter"):
            await orchestrator.energize(run)


# ============================================================================
# BreakerManager Integration
# ============================================================================

class TestBreakerManagerIntegration:
    """Tests for BreakerManager integration with orchestrator."""
    
    @pytest.fixture
    def grid_with_request_limits(self):
        """Grid with request limits configured."""
        return {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"name": "limited-grid", "id": "limited-grid-123"},
            "topology": {
                "nodes": [
                    {"id": "controller", "kind": "controller", "name": "Test", "description": "Test"}
                ]
            },
            "guardrails": {
                "breakers": {
                    "requests": {
                        "maxRequestsPerMinute": 60,
                        "maxConcurrentAgents": 5
                    }
                }
            }
        }
    
    @pytest.fixture
    def grid_without_request_limits(self):
        """Grid without request limits."""
        return {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"name": "unlimited-grid", "id": "unlimited-grid-123"},
            "topology": {
                "nodes": [
                    {"id": "controller", "kind": "controller", "name": "Test", "description": "Test"}
                ]
            }
        }
    
    @pytest.fixture
    def parallel_nodes_grid(self):
        """Grid with multiple parallel nodes and concurrency limit of 2."""
        return {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"name": "parallel-grid", "id": "parallel-grid-123"},
            "topology": {
                "nodes": [
                    {"id": "controller", "kind": "controller", "name": "Main", "description": "Main controller"},
                    {"id": "relay1", "kind": "relay", "name": "Relay 1", "description": "First relay", "dependsOn": ["controller"]},
                    {"id": "relay2", "kind": "relay", "name": "Relay 2", "description": "Second relay", "dependsOn": ["controller"]},
                    {"id": "relay3", "kind": "relay", "name": "Relay 3", "description": "Third relay", "dependsOn": ["controller"]},
                ]
            },
            "guardrails": {
                "breakers": {
                    "requests": {
                        "maxRequestsPerMinute": 60,
                        "maxConcurrentAgents": 2
                    }
                }
            }
        }
    
    @pytest.mark.asyncio
    async def test_breaker_manager_created_with_request_limits(self, orchestrator, grid_with_request_limits):
        """Test that BreakerManager is created when request limits are configured."""
        run = await orchestrator.load_grid(source=grid_with_request_limits)
        
        assert run.breaker_manager is not None
        assert run.breaker_manager.spec.requests is not None
        assert run.breaker_manager.spec.requests.maxConcurrentAgents == 5
        assert run.breaker_manager.spec.requests.maxRequestsPerMinute == 60
    
    @pytest.mark.asyncio
    async def test_breaker_manager_not_created_without_request_limits(self, orchestrator, grid_without_request_limits):
        """Test that BreakerManager is not created when no request limits are configured."""
        run = await orchestrator.load_grid(source=grid_without_request_limits)
        
        assert run.breaker_manager is None
    
    @pytest.mark.asyncio
    async def test_concurrency_cap_limits_parallel_execution(self, orchestrator, parallel_nodes_grid, mock_llm_adapter):
        """Test that maxConcurrentAgents limits how many nodes run in parallel."""
        # Track concurrent execution count
        max_concurrent_seen = 0
        current_concurrent = 0
        import asyncio
        
        async def slow_complete(*args, **kwargs):
            nonlocal max_concurrent_seen, current_concurrent
            current_concurrent += 1
            max_concurrent_seen = max(max_concurrent_seen, current_concurrent)
            await asyncio.sleep(0.05)  # Small delay to allow overlap
            current_concurrent -= 1
            return {
                "content": "Test response",
                "tool_calls": None,
                "tokens_in": 10,
                "tokens_out": 20,
                "cost": 0.001,
                "model": "test-model",
                "stop_reason": "end_turn",
            }
        
        mock_llm_adapter.complete = AsyncMock(side_effect=slow_complete)
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=parallel_nodes_grid)
        await orchestrator.energize(run)
        await orchestrator.execute(run)
        
        # maxConcurrentAgents is 2, so we should never see more than 2 concurrent
        assert max_concurrent_seen <= 2
        assert run.state == GridState.COMPLETED
    
    @pytest.mark.asyncio
    async def test_request_count_tracking(self, orchestrator, parallel_nodes_grid, mock_llm_adapter):
        """Test that request counts are properly tracked."""
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=parallel_nodes_grid)
        await orchestrator.energize(run)
        await orchestrator.execute(run)
        
        # After execution, all requests should be complete (concurrent_count = 0)
        assert run.breaker_manager.state.rate_limit.concurrent_count == 0
        # Should have recorded 4 requests (controller + 3 relays)
        assert run.breaker_manager.state.rate_limit.request_count == 4
    
    @pytest.mark.asyncio
    async def test_breaker_stop_action_fails_run(self, orchestrator, mock_llm_adapter):
        """Test that STOP action on request limit fails the run."""
        from smartify.models.grid import TripAction
        
        # Grid with very low request limit that will be exceeded
        grid = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"name": "stop-grid", "id": "stop-grid-123"},
            "topology": {
                "nodes": [
                    {"id": "controller", "kind": "controller", "name": "Main", "description": "Main controller"},
                    {"id": "relay1", "kind": "relay", "name": "Relay 1", "description": "First relay", "dependsOn": ["controller"]},
                ]
            },
            "guardrails": {
                "breakers": {
                    "requests": {
                        "maxRequestsPerMinute": 1,  # Very low limit
                        "maxConcurrentAgents": 5
                    }
                },
                "breakerActions": {
                    "onRequestsLimit": "stop"  # STOP action
                }
            }
        }
        
        orchestrator.register_llm_adapter("default", mock_llm_adapter)
        
        run = await orchestrator.load_grid(source=grid)
        await orchestrator.energize(run)
        
        # Manually trigger a request to hit the limit before execution
        run.breaker_manager.record_request_start()
        run.breaker_manager.record_request_complete()
        # Now request_count is 1, which meets the limit
        
        await orchestrator.execute(run)
        
        # Run should complete or fail depending on timing
        # The key is that the breaker is being checked
        assert run.breaker_manager.state.rate_limit.request_count >= 1
