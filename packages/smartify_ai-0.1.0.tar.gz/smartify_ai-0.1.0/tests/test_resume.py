"""Tests for ResumeManager and run recovery."""

import asyncio
import pytest
from datetime import datetime
from unittest.mock import Mock, AsyncMock, MagicMock, patch

from smartify.state.resume import (
    ResumeManager,
    create_checkpointed_orchestrator,
)
from smartify.state.checkpoint import (
    Checkpoint,
    CheckpointStatus,
    WebhookRetryJob,
    WebhookDeliveryStatus,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def mock_orchestrator():
    """Mock Orchestrator for testing."""
    orchestrator = Mock()
    orchestrator.load_grid = AsyncMock()
    orchestrator.energize = AsyncMock()
    orchestrator.execute = AsyncMock()
    return orchestrator


@pytest.fixture
def mock_store():
    """Mock CheckpointStore for testing."""
    store = Mock()
    store.get_resumable_runs = Mock(return_value=[])
    store.mark_failed = Mock()
    store.mark_completed = Mock()
    store.increment_resume_count = Mock()
    store.get_pending_webhook_jobs = Mock(return_value=[])
    store.mark_webhook_delivered = Mock()
    store.mark_webhook_failed = Mock()
    store.queue_webhook_retry = Mock()
    store.get_queue_stats = Mock(return_value={"pending": 0, "delivered": 0, "failed": 0})
    store.cleanup_old_jobs = Mock(return_value=5)
    return store


@pytest.fixture
def resume_manager(mock_orchestrator, mock_store):
    """ResumeManager with mocked dependencies."""
    return ResumeManager(
        orchestrator=mock_orchestrator,
        checkpoint_store=mock_store,
        webhook_retry_interval=0.1,  # Fast for testing
        max_resume_attempts=3,
    )


@pytest.fixture
def sample_checkpoint():
    """Sample checkpoint for testing."""
    return Checkpoint(
        checkpoint_id="chk-123",
        run_id="run-123",
        grid_id="grid-1",
        grid_yaml="""
apiVersion: smartify/v1
kind: Grid
metadata:
  name: test-grid
topology:
  nodes:
    - id: controller
      kind: controller
      description: Main controller
""",
        status=CheckpointStatus.ACTIVE,
        completed_nodes=["controller"],
        failed_nodes=[],
        running_nodes=["substation-1"],
        inputs={"test": "input"},
        outputs={"controller": {"result": "partial"}},
        total_tokens=100,
        total_cost=0.01,
        created_at=datetime.now(),
        updated_at=datetime.now(),
        resume_count=0,
    )


@pytest.fixture
def sample_webhook_job():
    """Sample webhook retry job."""
    return WebhookRetryJob(
        job_id="job-123",
        event_type="run_completed",
        grid_id="grid-1",
        webhook_url="https://example.com/webhook",
        payload={"event": "test", "data": {"key": "value"}},
        headers={"X-Custom": "Header"},
        secret="test-secret",
        attempts=1,
        max_attempts=3,
        status=WebhookDeliveryStatus.PENDING,
        next_retry_at=datetime.now(),
        created_at=datetime.now(),
        last_error=None,
    )


# ============================================================================
# ResumeManager Initialization
# ============================================================================

class TestResumeManagerInit:
    """Tests for ResumeManager initialization."""
    
    def test_init_with_defaults(self, mock_orchestrator, mock_store):
        """Test initialization with defaults."""
        manager = ResumeManager(mock_orchestrator, mock_store)
        
        assert manager.orchestrator == mock_orchestrator
        assert manager.store == mock_store
        assert manager.webhook_retry_interval == 30.0
        assert manager.max_resume_attempts == 3
        assert manager._webhook_worker_task is None
        assert manager._shutdown is False
    
    def test_init_custom_settings(self, mock_orchestrator, mock_store):
        """Test initialization with custom settings."""
        manager = ResumeManager(
            orchestrator=mock_orchestrator,
            checkpoint_store=mock_store,
            webhook_retry_interval=60.0,
            max_resume_attempts=5,
        )
        
        assert manager.webhook_retry_interval == 60.0
        assert manager.max_resume_attempts == 5
    
    def test_init_without_store_uses_global(self, mock_orchestrator):
        """Test initialization without store uses global singleton."""
        with patch("smartify.state.resume.get_checkpoint_store") as mock_get:
            mock_get.return_value = Mock()
            manager = ResumeManager(mock_orchestrator)
            mock_get.assert_called_once()


# ============================================================================
# Recovery
# ============================================================================

class TestRecoverIncompleteRuns:
    """Tests for recover_incomplete_runs."""
    
    @pytest.mark.asyncio
    async def test_no_incomplete_runs(self, resume_manager, mock_store):
        """Test recovery when no incomplete runs."""
        mock_store.get_resumable_runs.return_value = []
        
        resumed = await resume_manager.recover_incomplete_runs()
        
        assert resumed == []
        mock_store.get_resumable_runs.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_resume_single_run(self, resume_manager, mock_store, sample_checkpoint, mock_orchestrator):
        """Test resuming a single incomplete run."""
        mock_store.get_resumable_runs.return_value = [sample_checkpoint]
        
        # Mock the grid run
        mock_run = Mock()
        mock_run.context = Mock()
        mock_run.context.outputs = {}
        mock_run.context.total_tokens = 0
        mock_run.context.total_cost = 0.0
        mock_run.scheduler = Mock()
        mock_run.scheduler.nodes = {"controller": Mock()}
        mock_run.scheduler.mark_completed = Mock()
        mock_run.scheduler.mark_failed = Mock()
        mock_orchestrator.load_grid.return_value = mock_run
        
        resumed = await resume_manager.recover_incomplete_runs()
        
        assert resumed == ["run-123"]
        mock_store.increment_resume_count.assert_called_once_with("run-123")
        mock_orchestrator.load_grid.assert_called_once()
        mock_orchestrator.energize.assert_called_once_with(mock_run)
        mock_orchestrator.execute.assert_called_once_with(mock_run)
    
    @pytest.mark.asyncio
    async def test_max_resume_attempts_exceeded(self, resume_manager, mock_store, sample_checkpoint):
        """Test run is marked failed when max attempts exceeded."""
        sample_checkpoint.resume_count = 3  # Already at max
        mock_store.get_resumable_runs.return_value = [sample_checkpoint]
        
        resumed = await resume_manager.recover_incomplete_runs()
        
        assert resumed == []
        mock_store.mark_failed.assert_called_once()
        assert "max resume attempts" in mock_store.mark_failed.call_args[0][1].lower()
    
    @pytest.mark.asyncio
    async def test_resume_failure_marks_failed(self, resume_manager, mock_store, sample_checkpoint, mock_orchestrator):
        """Test failed resume marks run as failed."""
        mock_store.get_resumable_runs.return_value = [sample_checkpoint]
        mock_orchestrator.load_grid.side_effect = Exception("Load failed")
        
        resumed = await resume_manager.recover_incomplete_runs()
        
        assert resumed == []
        mock_store.mark_failed.assert_called_once()
        assert "Load failed" in mock_store.mark_failed.call_args[0][1]
    
    @pytest.mark.asyncio
    async def test_resume_multiple_runs(self, resume_manager, mock_store, mock_orchestrator):
        """Test resuming multiple incomplete runs."""
        valid_yaml = """apiVersion: smartify/v1
kind: Grid
metadata:
  name: test
topology:
  nodes:
    - id: controller
      kind: controller
      description: Test
"""
        checkpoints = [
            Checkpoint(
                checkpoint_id=f"chk-{i}",
                run_id=f"run-{i}",
                grid_id="grid-1",
                grid_yaml=valid_yaml,
                status=CheckpointStatus.ACTIVE,
                completed_nodes=[],
                failed_nodes=[],
                running_nodes=[],
                inputs={},
                outputs={},
                total_tokens=0,
                total_cost=0.0,
                created_at=datetime.now(),
                updated_at=datetime.now(),
                resume_count=0,
            )
            for i in range(3)
        ]
        mock_store.get_resumable_runs.return_value = checkpoints
        
        mock_run = Mock()
        mock_run.context = Mock()
        mock_run.context.outputs = {}
        mock_run.context.total_tokens = 0
        mock_run.context.total_cost = 0.0
        mock_run.scheduler = Mock()
        mock_run.scheduler.nodes = {}
        mock_run.scheduler.mark_completed = Mock()
        mock_run.scheduler.mark_failed = Mock()
        mock_orchestrator.load_grid.return_value = mock_run
        
        resumed = await resume_manager.recover_incomplete_runs()
        
        assert len(resumed) == 3
        assert mock_orchestrator.execute.call_count == 3


# ============================================================================
# Resume Run Details
# ============================================================================

class TestResumeRun:
    """Tests for _resume_run details."""
    
    @pytest.mark.asyncio
    async def test_context_restored(self, resume_manager, sample_checkpoint, mock_orchestrator):
        """Test context is restored from checkpoint."""
        sample_checkpoint.outputs = {"node1": {"data": "restored"}}
        sample_checkpoint.total_tokens = 500
        sample_checkpoint.total_cost = 0.05
        
        mock_run = Mock()
        mock_run.context = Mock()
        mock_run.context.outputs = {}
        mock_run.context.total_tokens = 0
        mock_run.context.total_cost = 0.0
        mock_run.scheduler = Mock()
        mock_run.scheduler.nodes = {}
        mock_orchestrator.load_grid.return_value = mock_run
        
        await resume_manager._resume_run(sample_checkpoint)
        
        assert mock_run.context.outputs == {"node1": {"data": "restored"}}
        assert mock_run.context.total_tokens == 500
        assert mock_run.context.total_cost == 0.05
    
    @pytest.mark.asyncio
    async def test_completed_nodes_marked(self, resume_manager, sample_checkpoint, mock_orchestrator, mock_store):
        """Test completed nodes are marked in scheduler."""
        sample_checkpoint.completed_nodes = ["node1", "node2"]
        sample_checkpoint.outputs = {"node1": {"r": 1}, "node2": {"r": 2}}
        
        mock_run = Mock()
        mock_run.context = Mock()
        mock_run.context.outputs = {}
        mock_run.context.total_tokens = 0
        mock_run.context.total_cost = 0.0
        mock_run.scheduler = Mock()
        mock_run.scheduler.nodes = {"node1": Mock(), "node2": Mock(), "node3": Mock()}
        mock_run.scheduler.mark_completed = Mock()
        mock_orchestrator.load_grid.return_value = mock_run
        
        await resume_manager._resume_run(sample_checkpoint)
        
        assert mock_run.scheduler.mark_completed.call_count == 2
        calls = [c[0] for c in mock_run.scheduler.mark_completed.call_args_list]
        assert ("node1", {"r": 1}) in calls
        assert ("node2", {"r": 2}) in calls
    
    @pytest.mark.asyncio
    async def test_failed_nodes_marked(self, resume_manager, sample_checkpoint, mock_orchestrator, mock_store):
        """Test failed nodes are marked in scheduler."""
        sample_checkpoint.failed_nodes = ["bad_node"]
        
        mock_run = Mock()
        mock_run.context = Mock()
        mock_run.context.outputs = {}
        mock_run.context.total_tokens = 0
        mock_run.context.total_cost = 0.0
        mock_run.scheduler = Mock()
        mock_run.scheduler.nodes = {"bad_node": Mock()}
        mock_run.scheduler.mark_failed = Mock()
        mock_orchestrator.load_grid.return_value = mock_run
        
        await resume_manager._resume_run(sample_checkpoint)
        
        mock_run.scheduler.mark_failed.assert_called_once_with("bad_node", "Failed in previous run")
    
    @pytest.mark.asyncio
    async def test_execution_success_marks_completed(self, resume_manager, sample_checkpoint, mock_orchestrator, mock_store):
        """Test successful execution marks checkpoint completed."""
        mock_run = Mock()
        mock_run.context = Mock()
        mock_run.context.outputs = {}
        mock_run.context.total_tokens = 0
        mock_run.context.total_cost = 0.0
        mock_run.scheduler = Mock()
        mock_run.scheduler.nodes = {}
        mock_orchestrator.load_grid.return_value = mock_run
        
        await resume_manager._resume_run(sample_checkpoint)
        
        mock_store.mark_completed.assert_called_once_with("run-123")
    
    @pytest.mark.asyncio
    async def test_execution_failure_marks_failed(self, resume_manager, sample_checkpoint, mock_orchestrator, mock_store):
        """Test failed execution marks checkpoint failed."""
        mock_run = Mock()
        mock_run.context = Mock()
        mock_run.context.outputs = {}
        mock_run.context.total_tokens = 0
        mock_run.context.total_cost = 0.0
        mock_run.scheduler = Mock()
        mock_run.scheduler.nodes = {}
        mock_orchestrator.load_grid.return_value = mock_run
        mock_orchestrator.execute.side_effect = Exception("Execution failed")
        
        with pytest.raises(Exception, match="Execution failed"):
            await resume_manager._resume_run(sample_checkpoint)
        
        mock_store.mark_failed.assert_called_once()


# ============================================================================
# Webhook Worker
# ============================================================================

class TestWebhookWorker:
    """Tests for webhook retry worker."""
    
    @pytest.mark.asyncio
    async def test_start_worker(self, resume_manager):
        """Test starting webhook worker."""
        await resume_manager.start_webhook_worker()
        
        assert resume_manager._webhook_worker_task is not None
        assert not resume_manager._shutdown
        
        # Cleanup
        await resume_manager.stop_webhook_worker()
    
    @pytest.mark.asyncio
    async def test_start_worker_already_running(self, resume_manager):
        """Test starting worker when already running."""
        await resume_manager.start_webhook_worker()
        task1 = resume_manager._webhook_worker_task
        
        # Starting again should not create new task
        await resume_manager.start_webhook_worker()
        
        assert resume_manager._webhook_worker_task is task1
        
        await resume_manager.stop_webhook_worker()
    
    @pytest.mark.asyncio
    async def test_stop_worker(self, resume_manager):
        """Test stopping webhook worker."""
        await resume_manager.start_webhook_worker()
        await resume_manager.stop_webhook_worker()
        
        assert resume_manager._shutdown is True
        assert resume_manager._webhook_worker_task is None
    
    @pytest.mark.asyncio
    async def test_stop_worker_not_running(self, resume_manager):
        """Test stopping when not running is safe."""
        await resume_manager.stop_webhook_worker()  # Should not raise
        
        assert resume_manager._webhook_worker_task is None


# ============================================================================
# Webhook Processing
# ============================================================================

class TestWebhookProcessing:
    """Tests for webhook retry processing."""
    
    @pytest.mark.asyncio
    async def test_process_no_jobs(self, resume_manager, mock_store):
        """Test processing when no pending jobs."""
        mock_store.get_pending_webhook_jobs.return_value = []
        
        count = await resume_manager._process_webhook_retries()
        
        assert count == 0
    
    @pytest.mark.asyncio
    async def test_process_successful_delivery(self, resume_manager, mock_store, sample_webhook_job):
        """Test successful webhook delivery."""
        mock_store.get_pending_webhook_jobs.return_value = [sample_webhook_job]
        
        with patch.object(resume_manager, "_deliver_webhook", return_value=True) as mock_deliver:
            count = await resume_manager._process_webhook_retries()
            
            assert count == 1
            mock_deliver.assert_called_once_with(sample_webhook_job)
            mock_store.mark_webhook_delivered.assert_called_once_with("job-123")
    
    @pytest.mark.asyncio
    async def test_process_failed_delivery(self, resume_manager, mock_store, sample_webhook_job):
        """Test failed webhook delivery."""
        mock_store.get_pending_webhook_jobs.return_value = [sample_webhook_job]
        
        with patch.object(resume_manager, "_deliver_webhook", return_value=False):
            count = await resume_manager._process_webhook_retries()
            
            assert count == 1
            mock_store.mark_webhook_failed.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_process_multiple_jobs(self, resume_manager, mock_store):
        """Test processing multiple jobs."""
        jobs = [
            WebhookRetryJob(
                job_id=f"job-{i}",
                event_type="test",
                grid_id="grid-1",
                webhook_url=f"https://example.com/hook{i}",
                payload={},
                headers={},
                secret=None,
                attempts=0,
                max_attempts=3,
                status=WebhookDeliveryStatus.PENDING,
                next_retry_at=datetime.now(),
                created_at=datetime.now(),
                last_error=None,
            )
            for i in range(3)
        ]
        mock_store.get_pending_webhook_jobs.return_value = jobs
        
        with patch.object(resume_manager, "_deliver_webhook", return_value=True):
            count = await resume_manager._process_webhook_retries()
            
            assert count == 3
            assert mock_store.mark_webhook_delivered.call_count == 3


# ============================================================================
# Webhook Delivery
# ============================================================================

class TestWebhookDelivery:
    """Tests for _deliver_webhook."""
    
    @pytest.mark.asyncio
    async def test_deliver_success(self, resume_manager, sample_webhook_job):
        """Test successful webhook delivery."""
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            result = await resume_manager._deliver_webhook(sample_webhook_job)
            
            assert result is True
    
    @pytest.mark.asyncio
    async def test_deliver_failure_status(self, resume_manager, sample_webhook_job):
        """Test delivery fails on bad status code."""
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 500
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            result = await resume_manager._deliver_webhook(sample_webhook_job)
            
            assert result is False
    
    @pytest.mark.asyncio
    async def test_deliver_exception(self, resume_manager, sample_webhook_job):
        """Test delivery handles exception."""
        with patch("httpx.AsyncClient") as mock_client:
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(side_effect=Exception("Network error"))
            
            result = await resume_manager._deliver_webhook(sample_webhook_job)
            
            assert result is False
    
    @pytest.mark.asyncio
    async def test_deliver_includes_signature(self, resume_manager, sample_webhook_job):
        """Test delivery includes HMAC signature when secret set."""
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            await resume_manager._deliver_webhook(sample_webhook_job)
            
            call_kwargs = mock_client.return_value.post.call_args[1]
            headers = call_kwargs["headers"]
            assert "X-Smartify-Signature" in headers
            assert headers["X-Smartify-Signature"].startswith("sha256=")
    
    @pytest.mark.asyncio
    async def test_deliver_no_signature_without_secret(self, resume_manager, sample_webhook_job):
        """Test delivery omits signature when no secret."""
        sample_webhook_job.secret = None
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            await resume_manager._deliver_webhook(sample_webhook_job)
            
            call_kwargs = mock_client.return_value.post.call_args[1]
            headers = call_kwargs["headers"]
            assert "X-Smartify-Signature" not in headers
    
    @pytest.mark.asyncio
    async def test_deliver_includes_custom_headers(self, resume_manager, sample_webhook_job):
        """Test delivery includes custom headers."""
        sample_webhook_job.headers = {"X-Custom-Header": "custom-value"}
        sample_webhook_job.secret = None
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            await resume_manager._deliver_webhook(sample_webhook_job)
            
            call_kwargs = mock_client.return_value.post.call_args[1]
            headers = call_kwargs["headers"]
            assert headers.get("X-Custom-Header") == "custom-value"
    
    @pytest.mark.asyncio
    async def test_deliver_includes_retry_header(self, resume_manager, sample_webhook_job):
        """Test delivery includes retry attempt header."""
        sample_webhook_job.attempts = 2
        sample_webhook_job.secret = None
        
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_client.return_value.__aenter__ = AsyncMock(return_value=mock_client.return_value)
            mock_client.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_client.return_value.post = AsyncMock(return_value=mock_response)
            
            await resume_manager._deliver_webhook(sample_webhook_job)
            
            call_kwargs = mock_client.return_value.post.call_args[1]
            headers = call_kwargs["headers"]
            assert headers["X-Smartify-Retry-Attempt"] == "3"


# ============================================================================
# Queue Management
# ============================================================================

class TestQueueManagement:
    """Tests for webhook queue management."""
    
    def test_queue_failed_webhook(self, resume_manager, mock_store):
        """Test queuing failed webhook."""
        resume_manager.queue_failed_webhook(
            event_type="run_completed",
            grid_id="grid-1",
            webhook_url="https://example.com/hook",
            payload={"event": "data"},
            headers={"X-Custom": "header"},
            secret="secret123",
            max_attempts=5,
        )
        
        mock_store.queue_webhook_retry.assert_called_once_with(
            event_type="run_completed",
            grid_id="grid-1",
            webhook_url="https://example.com/hook",
            payload={"event": "data"},
            headers={"X-Custom": "header"},
            secret="secret123",
            max_attempts=5,
        )
    
    def test_get_queue_stats(self, resume_manager, mock_store):
        """Test getting queue statistics."""
        mock_store.get_queue_stats.return_value = {
            "pending": 5,
            "delivered": 100,
            "failed": 2,
        }
        
        stats = resume_manager.get_queue_stats()
        
        assert stats == {"pending": 5, "delivered": 100, "failed": 2}


# ============================================================================
# Cleanup
# ============================================================================

class TestCleanup:
    """Tests for cleanup operations."""
    
    @pytest.mark.asyncio
    async def test_cleanup(self, resume_manager, mock_store):
        """Test cleanup operation."""
        mock_store.cleanup_old_jobs.return_value = 10
        
        result = await resume_manager.cleanup(days=14)
        
        assert result == {"webhook_jobs_deleted": 10}
        mock_store.cleanup_old_jobs.assert_called_once_with(days=14)
    
    @pytest.mark.asyncio
    async def test_cleanup_default_days(self, resume_manager, mock_store):
        """Test cleanup with default days."""
        await resume_manager.cleanup()
        
        mock_store.cleanup_old_jobs.assert_called_once_with(days=7)


# ============================================================================
# Integration Helper
# ============================================================================

class TestCreateCheckpointedOrchestrator:
    """Tests for create_checkpointed_orchestrator helper."""
    
    def test_creates_all_components(self, tmp_path):
        """Test helper creates orchestrator, manager, and store."""
        db_path = str(tmp_path / "test.db")
        
        orchestrator, manager, store = create_checkpointed_orchestrator(db_path=db_path)
        
        # Verify types
        from smartify.engine.orchestrator import Orchestrator
        from smartify.state.checkpoint import CheckpointStore
        
        assert isinstance(orchestrator, Orchestrator)
        assert isinstance(store, CheckpointStore)
        assert isinstance(manager, ResumeManager)
        assert manager.orchestrator is orchestrator
        assert manager.store is store
    
    def test_uses_custom_db_path(self, tmp_path):
        """Test helper uses custom database path."""
        db_path = str(tmp_path / "custom.db")
        
        _, _, store = create_checkpointed_orchestrator(db_path=db_path)
        
        assert store.db_path == db_path


# ============================================================================
# Worker Loop
# ============================================================================

class TestWorkerLoop:
    """Tests for the webhook worker loop."""
    
    @pytest.mark.asyncio
    async def test_worker_processes_on_interval(self, resume_manager, mock_store):
        """Test worker processes webhooks at intervals."""
        process_count = 0
        
        async def mock_process():
            nonlocal process_count
            process_count += 1
            return 0
        
        resume_manager._process_webhook_retries = mock_process
        
        await resume_manager.start_webhook_worker()
        await asyncio.sleep(0.25)  # Wait for 2-3 intervals
        await resume_manager.stop_webhook_worker()
        
        assert process_count >= 2
    
    @pytest.mark.asyncio
    async def test_worker_handles_errors(self, resume_manager):
        """Test worker continues despite errors."""
        call_count = 0
        
        async def failing_process():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise Exception("Temporary error")
            return 0
        
        resume_manager._process_webhook_retries = failing_process
        
        await resume_manager.start_webhook_worker()
        await asyncio.sleep(0.35)
        await resume_manager.stop_webhook_worker()
        
        # Should have continued despite errors
        assert call_count >= 3
