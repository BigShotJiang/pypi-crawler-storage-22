"""Tests for the DAG scheduler."""

import pytest
from smartify.engine.scheduler import DAGScheduler, NodeState
from smartify.models.grid import (
    GridSpec,
    MetadataSpec,
    TopologySpec,
    NodeSpec,
    NodeKind,
    ExecutionMode,
)


def make_grid(nodes: list[NodeSpec], execution_mode: ExecutionMode = ExecutionMode.PARENT) -> GridSpec:
    """Helper to create a minimal grid for testing."""
    return GridSpec(
        metadata=MetadataSpec(id="test", name="Test Grid"),
        topology=TopologySpec(nodes=nodes, executionMode=execution_mode),
    )


class TestDAGScheduler:
    """Tests for DAGScheduler."""
    
    def test_minimal_grid(self):
        """Test scheduling a minimal grid with just a controller."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
        ])
        
        scheduler = DAGScheduler(grid)
        scheduler.build_graph()
        
        # Controller should be ready immediately (no dependencies)
        ready = scheduler.get_ready_nodes()
        assert ready == ["controller"]
        
        # Mark running and completed
        scheduler.mark_running("controller")
        assert scheduler.get_running_nodes() == ["controller"]
        
        scheduler.mark_completed("controller", {"status": "ok"})
        assert scheduler.is_complete()
        assert scheduler.is_successful()
    
    def test_parent_child_dependencies(self):
        """Test that children depend on their parent."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
            NodeSpec(id="relay", kind=NodeKind.RELAY, name="Relay", parent="controller"),
            NodeSpec(id="sub", kind=NodeKind.SUBSTATION, name="Sub", parent="relay"),
        ])
        
        scheduler = DAGScheduler(grid)
        scheduler.build_graph()
        
        # Only controller should be ready initially
        assert scheduler.get_ready_nodes() == ["controller"]
        
        # Complete controller
        scheduler.mark_running("controller")
        scheduler.mark_completed("controller")
        
        # Now relay should be ready
        assert scheduler.get_ready_nodes() == ["relay"]
        
        # Complete relay
        scheduler.mark_running("relay")
        scheduler.mark_completed("relay")
        
        # Now substation should be ready
        assert scheduler.get_ready_nodes() == ["sub"]
        
        # Complete substation
        scheduler.mark_running("sub")
        scheduler.mark_completed("sub")
        
        assert scheduler.is_complete()
        assert scheduler.is_successful()
        assert scheduler.get_execution_order() == ["controller", "relay", "sub"]
    
    def test_parallel_siblings(self):
        """Test that siblings run in parallel by default."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
            NodeSpec(id="sub1", kind=NodeKind.SUBSTATION, name="Sub 1", parent="controller"),
            NodeSpec(id="sub2", kind=NodeKind.SUBSTATION, name="Sub 2", parent="controller"),
            NodeSpec(id="sub3", kind=NodeKind.SUBSTATION, name="Sub 3", parent="controller"),
        ])
        
        scheduler = DAGScheduler(grid)
        scheduler.build_graph()
        
        # Complete controller
        scheduler.mark_running("controller")
        scheduler.mark_completed("controller")
        
        # All substations should be ready (parallel)
        ready = set(scheduler.get_ready_nodes())
        assert ready == {"sub1", "sub2", "sub3"}
    
    def test_run_after_dependency(self):
        """Test runAfter creates additional dependencies."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
            NodeSpec(id="sub1", kind=NodeKind.SUBSTATION, name="Sub 1", parent="controller"),
            NodeSpec(id="sub2", kind=NodeKind.SUBSTATION, name="Sub 2", parent="controller", runAfter=["sub1"]),
        ])
        
        scheduler = DAGScheduler(grid)
        scheduler.build_graph()
        
        # Complete controller
        scheduler.mark_running("controller")
        scheduler.mark_completed("controller")
        
        # Only sub1 should be ready (sub2 has runAfter)
        assert scheduler.get_ready_nodes() == ["sub1"]
        
        # Complete sub1
        scheduler.mark_running("sub1")
        scheduler.mark_completed("sub1")
        
        # Now sub2 should be ready
        assert scheduler.get_ready_nodes() == ["sub2"]
    
    def test_cycle_detection(self):
        """Test that cycles are detected and raise an error."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
            NodeSpec(id="a", kind=NodeKind.SUBSTATION, name="A", parent="controller", runAfter=["c"]),
            NodeSpec(id="b", kind=NodeKind.SUBSTATION, name="B", parent="controller", runAfter=["a"]),
            NodeSpec(id="c", kind=NodeKind.SUBSTATION, name="C", parent="controller", runAfter=["b"]),
        ])
        
        scheduler = DAGScheduler(grid)
        
        with pytest.raises(ValueError, match="Cycle detected"):
            scheduler.build_graph()
    
    def test_node_failure(self):
        """Test handling node failure."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
        ])
        
        scheduler = DAGScheduler(grid)
        scheduler.build_graph()
        
        scheduler.mark_running("controller")
        scheduler.mark_failed("controller", "Something went wrong")
        
        assert scheduler.is_complete()
        assert not scheduler.is_successful()
        assert scheduler.nodes["controller"].error == "Something went wrong"
    
    def test_state_summary(self):
        """Test state summary generation."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
            NodeSpec(id="relay", kind=NodeKind.RELAY, name="Relay", parent="controller"),
        ])
        
        scheduler = DAGScheduler(grid)
        scheduler.build_graph()
        
        summary = scheduler.get_state_summary()
        assert summary[NodeState.READY] == 1
        assert summary[NodeState.PENDING] == 1
        
        scheduler.mark_running("controller")
        summary = scheduler.get_state_summary()
        assert summary[NodeState.RUNNING] == 1
    
    def test_visualize(self):
        """Test visualization output."""
        grid = make_grid([
            NodeSpec(id="controller", kind=NodeKind.CONTROLLER, name="Controller"),
        ])
        
        scheduler = DAGScheduler(grid)
        scheduler.build_graph()
        
        viz = scheduler.visualize()
        assert "controller" in viz
        assert "ready" in viz


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
