"""Tests for Spark node spawning and management."""

import pytest
from datetime import datetime
from unittest.mock import Mock, AsyncMock

from smartify.engine.spark import (
    SparkManager,
    SparkNode,
    SparkRequest,
    analyze_workload_for_sparks,
    create_spark_node_spec,
)
from smartify.models.grid import (
    DynamicSpawningSpec,
    DynamicSpawningLimits,
    DynamicSpawningDefaults,
    NodeKind,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def default_config():
    """Default spawning configuration."""
    return DynamicSpawningSpec(
        enabled=True,
        enableSparks=True,
        limits=DynamicSpawningLimits(
            maxSparksPerSubstation=3,
            maxTotalNodes=10,
        ),
        defaults=DynamicSpawningDefaults(spark="default-agent"),
        requireApproval=False,
    )


@pytest.fixture
def disabled_config():
    """Configuration with sparks disabled."""
    return DynamicSpawningSpec(
        enabled=False,
        enableSparks=False,
    )


@pytest.fixture
def mock_scheduler():
    """Mock scheduler for SparkManager."""
    scheduler = Mock()
    scheduler.nodes = {}
    return scheduler


@pytest.fixture
def spark_manager(default_config, mock_scheduler):
    """SparkManager with default config."""
    return SparkManager(default_config, mock_scheduler)


@pytest.fixture
def disabled_manager(disabled_config, mock_scheduler):
    """SparkManager with sparks disabled."""
    return SparkManager(disabled_config, mock_scheduler)


# ============================================================================
# SparkManager Initialization
# ============================================================================

class TestSparkManagerInit:
    """Tests for SparkManager initialization."""
    
    def test_init_with_config(self, default_config, mock_scheduler):
        """Test initialization with config."""
        manager = SparkManager(default_config, mock_scheduler)
        
        assert manager.config == default_config
        assert manager.scheduler == mock_scheduler
        assert manager.sparks == {}
        assert manager.sparks_by_parent == {}
        assert manager._total_spawned == 0
    
    def test_enabled_property_when_enabled(self, spark_manager):
        """Test enabled property returns True when both flags set."""
        assert spark_manager.enabled is True
    
    def test_enabled_property_when_disabled(self, disabled_manager):
        """Test enabled property returns False when disabled."""
        assert disabled_manager.enabled is False
    
    def test_enabled_property_partial_disable(self, mock_scheduler):
        """Test enabled is False if only enableSparks is False."""
        config = DynamicSpawningSpec(enabled=True, enableSparks=False)
        manager = SparkManager(config, mock_scheduler)
        assert manager.enabled is False


# ============================================================================
# Spawn Limits
# ============================================================================

class TestSparkSpawnLimits:
    """Tests for spawn limit checking."""
    
    def test_can_spawn_when_empty(self, spark_manager):
        """Test can spawn when no sparks exist."""
        assert spark_manager.can_spawn("substation-1") is True
    
    def test_can_spawn_when_disabled(self, disabled_manager):
        """Test cannot spawn when disabled."""
        assert disabled_manager.can_spawn("substation-1") is False
    
    @pytest.mark.asyncio
    async def test_cannot_spawn_over_per_substation_limit(self, spark_manager):
        """Test cannot spawn over per-substation limit."""
        # Spawn 3 (the limit)
        for i in range(3):
            await spark_manager.spawn(SparkRequest(
                parent_id="substation-1",
                task=f"Task {i}",
            ))
        
        # Should hit limit
        assert spark_manager.can_spawn("substation-1") is False
        # But different parent should be fine
        assert spark_manager.can_spawn("substation-2") is True
    
    @pytest.mark.asyncio
    async def test_cannot_spawn_over_total_limit(self, default_config, mock_scheduler):
        """Test cannot spawn over total node limit."""
        # Set a low total limit
        default_config.limits.maxTotalNodes = 5
        manager = SparkManager(default_config, mock_scheduler)
        
        # Spawn 5 across different parents
        for i in range(5):
            await manager.spawn(SparkRequest(
                parent_id=f"substation-{i}",
                task=f"Task {i}",
            ))
        
        # Should hit total limit
        assert manager.can_spawn("substation-new") is False


# ============================================================================
# Spawning
# ============================================================================

class TestSparkSpawning:
    """Tests for spark spawning."""
    
    @pytest.mark.asyncio
    async def test_spawn_creates_spark(self, spark_manager):
        """Test spawn creates a new spark."""
        request = SparkRequest(
            parent_id="substation-1",
            task="Analyze data",
            context={"data": "test"},
        )
        
        spark = await spark_manager.spawn(request)
        
        assert spark is not None
        assert spark.parent_id == "substation-1"
        assert spark.task == "Analyze data"
        assert spark.context == {"data": "test"}
        assert spark.status == "pending"
        assert spark.id.startswith("spark-substation-1-")
    
    @pytest.mark.asyncio
    async def test_spawn_registers_in_manager(self, spark_manager):
        """Test spawned spark is tracked in manager."""
        spark = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1",
            task="Test task",
        ))
        
        assert spark.id in spark_manager.sparks
        assert spark.id in spark_manager.sparks_by_parent["sub-1"]
        assert spark_manager._total_spawned == 1
    
    @pytest.mark.asyncio
    async def test_spawn_returns_none_when_disabled(self, disabled_manager):
        """Test spawn returns None when disabled."""
        spark = await disabled_manager.spawn(SparkRequest(
            parent_id="sub-1",
            task="Test task",
        ))
        
        assert spark is None
    
    @pytest.mark.asyncio
    async def test_spawn_returns_none_at_limit(self, spark_manager):
        """Test spawn returns None when limit reached."""
        # Fill up substation-1
        for i in range(3):
            await spark_manager.spawn(SparkRequest(
                parent_id="substation-1",
                task=f"Task {i}",
            ))
        
        # Should fail
        spark = await spark_manager.spawn(SparkRequest(
            parent_id="substation-1",
            task="One more",
        ))
        
        assert spark is None
    
    @pytest.mark.asyncio
    async def test_spawn_with_optional_fields(self, spark_manager):
        """Test spawn with optional constraints."""
        request = SparkRequest(
            parent_id="sub-1",
            task="Complex task",
            context={"input": "data"},
            priority=5,
            tools=["shell", "file"],
            max_tokens=1000,
            timeout_seconds=30,
        )
        
        spark = await spark_manager.spawn(request)
        
        assert spark is not None
        # Optional fields on request don't transfer to SparkNode directly
        # They would be used during execution


# ============================================================================
# Batch Spawning
# ============================================================================

class TestBatchSpawning:
    """Tests for batch spark spawning."""
    
    @pytest.mark.asyncio
    async def test_spawn_batch_creates_multiple(self, spark_manager):
        """Test batch spawning creates multiple sparks."""
        requests = [
            SparkRequest(parent_id="sub-1", task=f"Task {i}")
            for i in range(3)
        ]
        
        sparks = await spark_manager.spawn_batch(requests)
        
        assert len(sparks) == 3
        assert all(s.parent_id == "sub-1" for s in sparks)
    
    @pytest.mark.asyncio
    async def test_spawn_batch_respects_limits(self, spark_manager):
        """Test batch spawning stops at limits."""
        requests = [
            SparkRequest(parent_id="sub-1", task=f"Task {i}")
            for i in range(5)  # More than limit of 3
        ]
        
        sparks = await spark_manager.spawn_batch(requests)
        
        assert len(sparks) == 3  # Stopped at limit
    
    @pytest.mark.asyncio
    async def test_spawn_batch_empty_when_disabled(self, disabled_manager):
        """Test batch returns empty when disabled."""
        requests = [SparkRequest(parent_id="sub-1", task="Task")]
        
        sparks = await disabled_manager.spawn_batch(requests)
        
        assert sparks == []


# ============================================================================
# Spark Queries
# ============================================================================

class TestSparkQueries:
    """Tests for spark query methods."""
    
    @pytest.mark.asyncio
    async def test_get_pending_sparks(self, spark_manager):
        """Test getting pending sparks."""
        # Create some sparks
        spark1 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 1"
        ))
        spark2 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 2"
        ))
        
        # Mark one as running
        spark_manager.mark_running(spark1.id)
        
        pending = spark_manager.get_pending_sparks()
        
        assert len(pending) == 1
        assert pending[0].id == spark2.id
    
    @pytest.mark.asyncio
    async def test_get_sparks_for_parent(self, spark_manager):
        """Test getting sparks for a specific parent."""
        await spark_manager.spawn(SparkRequest(parent_id="sub-1", task="Task 1"))
        await spark_manager.spawn(SparkRequest(parent_id="sub-1", task="Task 2"))
        await spark_manager.spawn(SparkRequest(parent_id="sub-2", task="Task 3"))
        
        sub1_sparks = spark_manager.get_sparks_for_parent("sub-1")
        sub2_sparks = spark_manager.get_sparks_for_parent("sub-2")
        
        assert len(sub1_sparks) == 2
        assert len(sub2_sparks) == 1
    
    @pytest.mark.asyncio
    async def test_get_sparks_for_nonexistent_parent(self, spark_manager):
        """Test getting sparks for parent with no sparks."""
        sparks = spark_manager.get_sparks_for_parent("nonexistent")
        assert sparks == []


# ============================================================================
# State Transitions
# ============================================================================

class TestSparkStateTransitions:
    """Tests for spark state transitions."""
    
    @pytest.mark.asyncio
    async def test_mark_running(self, spark_manager):
        """Test marking spark as running."""
        spark = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task"
        ))
        
        spark_manager.mark_running(spark.id)
        
        assert spark_manager.sparks[spark.id].status == "running"
    
    @pytest.mark.asyncio
    async def test_mark_completed(self, spark_manager):
        """Test marking spark as completed."""
        spark = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task"
        ))
        
        output = {"result": "success", "data": [1, 2, 3]}
        spark_manager.mark_completed(spark.id, output, tokens_used=100)
        
        stored = spark_manager.sparks[spark.id]
        assert stored.status == "completed"
        assert stored.output == output
        assert stored.tokens_used == 100
    
    @pytest.mark.asyncio
    async def test_mark_failed(self, spark_manager):
        """Test marking spark as failed."""
        spark = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task"
        ))
        
        spark_manager.mark_failed(spark.id, "Connection timeout")
        
        stored = spark_manager.sparks[spark.id]
        assert stored.status == "failed"
        assert stored.error == "Connection timeout"
    
    def test_mark_nonexistent_spark_no_error(self, spark_manager):
        """Test marking nonexistent spark doesn't raise."""
        # Should not raise
        spark_manager.mark_running("nonexistent-id")
        spark_manager.mark_completed("nonexistent-id", {})
        spark_manager.mark_failed("nonexistent-id", "error")


# ============================================================================
# Output Collection
# ============================================================================

class TestOutputCollection:
    """Tests for collecting spark outputs."""
    
    @pytest.mark.asyncio
    async def test_get_completed_outputs(self, spark_manager):
        """Test getting completed outputs for parent."""
        # Create and complete sparks
        spark1 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 1"
        ))
        spark2 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 2"
        ))
        spark3 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 3"
        ))
        
        # Complete two, fail one
        spark_manager.mark_completed(spark1.id, {"result": "A"})
        spark_manager.mark_completed(spark2.id, {"result": "B"})
        spark_manager.mark_failed(spark3.id, "Error")
        
        outputs = spark_manager.get_completed_outputs("sub-1")
        
        assert len(outputs) == 2
        assert any(o["output"]["result"] == "A" for o in outputs)
        assert any(o["output"]["result"] == "B" for o in outputs)
    
    @pytest.mark.asyncio
    async def test_get_completed_outputs_includes_metadata(self, spark_manager):
        """Test output includes spark metadata."""
        spark = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Analyze something"
        ))
        spark_manager.mark_completed(spark.id, {"data": 123})
        
        outputs = spark_manager.get_completed_outputs("sub-1")
        
        assert len(outputs) == 1
        assert outputs[0]["spark_id"] == spark.id
        assert outputs[0]["task"] == "Analyze something"
        assert outputs[0]["output"] == {"data": 123}


# ============================================================================
# Statistics
# ============================================================================

class TestSparkStatistics:
    """Tests for spark manager statistics."""
    
    def test_get_stats_empty(self, spark_manager):
        """Test stats on empty manager."""
        stats = spark_manager.get_stats()
        
        assert stats["enabled"] is True
        assert stats["total_spawned"] == 0
        assert stats["active"] == 0
        assert stats["by_status"] == {}
        assert stats["limits"]["max_total"] == 10
        assert stats["limits"]["max_per_substation"] == 3
    
    @pytest.mark.asyncio
    async def test_get_stats_with_sparks(self, spark_manager):
        """Test stats with various spark states."""
        # Create sparks with different states
        s1 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 1"
        ))
        s2 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 2"
        ))
        s3 = await spark_manager.spawn(SparkRequest(
            parent_id="sub-1", task="Task 3"
        ))
        
        spark_manager.mark_running(s1.id)
        spark_manager.mark_completed(s2.id, {"done": True})
        # s3 stays pending
        
        stats = spark_manager.get_stats()
        
        assert stats["total_spawned"] == 3
        assert stats["active"] == 3
        assert stats["by_status"]["running"] == 1
        assert stats["by_status"]["completed"] == 1
        assert stats["by_status"]["pending"] == 1


# ============================================================================
# Workload Analysis
# ============================================================================

class TestWorkloadAnalysis:
    """Tests for workload analysis helper."""
    
    def test_analyze_with_list_context(self):
        """Test analysis detects list-based fan-out opportunities."""
        context = {
            "files": ["a.txt", "b.txt", "c.txt"],
            "config": "some-config",
        }
        
        requests = analyze_workload_for_sparks("Process files", context)
        
        assert len(requests) == 3
        assert requests[0].context["files"] == "a.txt"
        assert requests[0].context["index"] == 0
        assert requests[0].context["total"] == 3
    
    def test_analyze_with_no_lists(self):
        """Test analysis returns empty when no lists in context."""
        context = {
            "single": "value",
            "config": {"nested": "object"},
        }
        
        requests = analyze_workload_for_sparks("Simple task", context)
        
        assert requests == []
    
    def test_analyze_with_single_item_list(self):
        """Test analysis ignores single-item lists."""
        context = {"items": ["only-one"]}
        
        requests = analyze_workload_for_sparks("Process", context)
        
        assert requests == []
    
    def test_analyze_preserves_priority_order(self):
        """Test requests have incrementing priorities."""
        context = {"items": ["a", "b", "c", "d"]}
        
        requests = analyze_workload_for_sparks("Process", context)
        
        priorities = [r.priority for r in requests]
        assert priorities == [0, 1, 2, 3]


# ============================================================================
# NodeSpec Creation
# ============================================================================

class TestCreateSparkNodeSpec:
    """Tests for creating NodeSpec from SparkNode."""
    
    def test_create_node_spec(self):
        """Test creating NodeSpec from SparkNode."""
        spark = SparkNode(
            id="spark-sub-1-abc123",
            parent_id="sub-1",
            task="Analyze the data file for patterns",
            context={"file": "data.csv"},
            created_at=datetime.now(),
        )
        
        spec = create_spark_node_spec(spark, default_agent="claude")
        
        assert spec.id == "spark-sub-1-abc123"
        assert spec.kind == NodeKind.SPARK
        assert spec.parent == "sub-1"
        assert spec.agent == "claude"
        assert "Analyze the data file" in spec.name
        assert spec.description == spark.task
    
    def test_create_node_spec_truncates_long_task(self):
        """Test long task names are truncated in name."""
        spark = SparkNode(
            id="spark-123",
            parent_id="sub-1",
            task="This is a very long task description that should be truncated in the name field",
            context={},
            created_at=datetime.now(),
        )
        
        spec = create_spark_node_spec(spark)
        
        assert len(spec.name) < len(spark.task) + 10  # "Spark: " + truncated
        assert "..." in spec.name
    
    def test_create_node_spec_without_agent(self):
        """Test creating spec without default agent."""
        spark = SparkNode(
            id="spark-123",
            parent_id="sub-1",
            task="Task",
            context={},
            created_at=datetime.now(),
        )
        
        spec = create_spark_node_spec(spark)
        
        assert spec.agent is None


# ============================================================================
# SparkNode Dataclass
# ============================================================================

class TestSparkNodeDataclass:
    """Tests for SparkNode dataclass."""
    
    def test_spark_node_defaults(self):
        """Test SparkNode default values."""
        spark = SparkNode(
            id="test-id",
            parent_id="parent",
            task="Do something",
            context={},
            created_at=datetime.now(),
        )
        
        assert spark.status == "pending"
        assert spark.output is None
        assert spark.error is None
        assert spark.tokens_used == 0
    
    def test_spark_node_with_all_fields(self):
        """Test SparkNode with all fields set."""
        now = datetime.now()
        spark = SparkNode(
            id="test-id",
            parent_id="parent",
            task="Do something",
            context={"key": "value"},
            created_at=now,
            status="completed",
            output={"result": "success"},
            error=None,
            tokens_used=500,
        )
        
        assert spark.status == "completed"
        assert spark.output == {"result": "success"}
        assert spark.tokens_used == 500


# ============================================================================
# SparkRequest Dataclass
# ============================================================================

class TestSparkRequestDataclass:
    """Tests for SparkRequest dataclass."""
    
    def test_spark_request_minimal(self):
        """Test SparkRequest with minimal fields."""
        request = SparkRequest(
            parent_id="sub-1",
            task="Process data",
        )
        
        assert request.parent_id == "sub-1"
        assert request.task == "Process data"
        assert request.context == {}
        assert request.priority == 0
        assert request.tools is None
        assert request.max_tokens is None
        assert request.timeout_seconds is None
    
    def test_spark_request_full(self):
        """Test SparkRequest with all fields."""
        request = SparkRequest(
            parent_id="sub-1",
            task="Complex task",
            context={"data": [1, 2, 3]},
            priority=10,
            tools=["shell", "http"],
            max_tokens=2000,
            timeout_seconds=60,
        )
        
        assert request.priority == 10
        assert request.tools == ["shell", "http"]
        assert request.max_tokens == 2000
        assert request.timeout_seconds == 60
