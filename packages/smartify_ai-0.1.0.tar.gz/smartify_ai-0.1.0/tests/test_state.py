"""Tests for state persistence."""

import pytest
import tempfile
from datetime import datetime
from pathlib import Path

from smartify.state import (
    RunStatus,
    RunRecord,
    NodeOutput,
    InMemoryStore,
    SQLiteStore,
)


class TestRunRecord:
    """Tests for RunRecord dataclass."""
    
    def test_to_dict(self):
        run = RunRecord(
            run_id="run-123",
            grid_id="grid-1",
            grid_name="Test Grid",
            status=RunStatus.RUNNING,
            created_at=datetime(2026, 2, 1, 12, 0, 0),
        )
        d = run.to_dict()
        
        assert d['run_id'] == "run-123"
        assert d['status'] == "running"
        assert d['created_at'] == "2026-02-01T12:00:00"
    
    def test_from_dict(self):
        d = {
            'run_id': "run-456",
            'grid_id': "grid-2",
            'grid_name': "Another Grid",
            'status': "completed",
            'created_at': "2026-02-01T14:00:00",
            'total_tokens': 1000,
            'total_cost': 0.05,
        }
        run = RunRecord.from_dict(d)
        
        assert run.run_id == "run-456"
        assert run.status == RunStatus.COMPLETED
        assert run.total_tokens == 1000


class TestInMemoryStore:
    """Tests for InMemoryStore."""
    
    def test_save_and_get(self):
        store = InMemoryStore()
        run = RunRecord(
            run_id="test-run",
            grid_id="grid-1",
            grid_name="Test",
            status=RunStatus.PENDING,
            created_at=datetime.now(),
        )
        
        store.save_run(run)
        retrieved = store.get_run("test-run")
        
        assert retrieved is not None
        assert retrieved.run_id == "test-run"
        assert retrieved.status == RunStatus.PENDING
    
    def test_list_runs(self):
        store = InMemoryStore()
        
        for i in range(5):
            store.save_run(RunRecord(
                run_id=f"run-{i}",
                grid_id="grid-1",
                grid_name="Test",
                status=RunStatus.COMPLETED if i % 2 == 0 else RunStatus.FAILED,
                created_at=datetime.now(),
            ))
        
        all_runs = store.list_runs()
        assert len(all_runs) == 5
        
        completed = store.list_runs(status=RunStatus.COMPLETED)
        assert len(completed) == 3
        
        failed = store.list_runs(status=RunStatus.FAILED)
        assert len(failed) == 2
    
    def test_delete_run(self):
        store = InMemoryStore()
        store.save_run(RunRecord(
            run_id="to-delete",
            grid_id="grid-1",
            grid_name="Test",
            status=RunStatus.COMPLETED,
            created_at=datetime.now(),
        ))
        
        assert store.get_run("to-delete") is not None
        assert store.delete_run("to-delete")
        assert store.get_run("to-delete") is None
    
    def test_node_outputs(self):
        store = InMemoryStore()
        
        output = NodeOutput(
            run_id="run-1",
            node_id="node-1",
            success=True,
            output={"result": "hello"},
            error=None,
            started_at=datetime.now(),
            completed_at=datetime.now(),
            tokens_used=100,
        )
        store.save_node_output(output)
        
        outputs = store.get_node_outputs("run-1")
        assert len(outputs) == 1
        assert outputs[0].node_id == "node-1"
        assert outputs[0].output == {"result": "hello"}


class TestSQLiteStore:
    """Tests for SQLiteStore."""
    
    def test_save_and_get(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteStore(f.name)
            
            run = RunRecord(
                run_id="sqlite-test",
                grid_id="grid-1",
                grid_name="Test",
                status=RunStatus.RUNNING,
                created_at=datetime.now(),
            )
            store.save_run(run)
            
            retrieved = store.get_run("sqlite-test")
            assert retrieved is not None
            assert retrieved.run_id == "sqlite-test"
    
    def test_update_run(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteStore(f.name)
            
            run = RunRecord(
                run_id="update-test",
                grid_id="grid-1",
                grid_name="Test",
                status=RunStatus.RUNNING,
                created_at=datetime.now(),
            )
            store.save_run(run)
            
            # Update status
            run.status = RunStatus.COMPLETED
            run.completed_at = datetime.now()
            run.total_tokens = 500
            store.save_run(run)
            
            retrieved = store.get_run("update-test")
            assert retrieved.status == RunStatus.COMPLETED
            assert retrieved.total_tokens == 500
    
    def test_list_with_filters(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteStore(f.name)
            
            # Create runs for different grids
            for grid_id in ["grid-a", "grid-b"]:
                for i in range(3):
                    store.save_run(RunRecord(
                        run_id=f"{grid_id}-run-{i}",
                        grid_id=grid_id,
                        grid_name=f"Grid {grid_id}",
                        status=RunStatus.COMPLETED,
                        created_at=datetime.now(),
                    ))
            
            all_runs = store.list_runs()
            assert len(all_runs) == 6
            
            grid_a_runs = store.list_runs(grid_id="grid-a")
            assert len(grid_a_runs) == 3
            assert all(r.grid_id == "grid-a" for r in grid_a_runs)
    
    def test_node_outputs_persist(self):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteStore(f.name)
            
            # Save a run first
            store.save_run(RunRecord(
                run_id="output-test",
                grid_id="grid-1",
                grid_name="Test",
                status=RunStatus.RUNNING,
                created_at=datetime.now(),
            ))
            
            # Save outputs
            for i in range(3):
                store.save_node_output(NodeOutput(
                    run_id="output-test",
                    node_id=f"node-{i}",
                    success=True,
                    output={"value": i},
                    error=None,
                    started_at=datetime.now(),
                    completed_at=datetime.now(),
                    tokens_used=100,
                ))
            
            outputs = store.get_node_outputs("output-test")
            assert len(outputs) == 3
