"""Tests for builtin tools."""

import pytest
import tempfile
import os
from pathlib import Path

from smartify.tools import Tool, ToolResult, ToolRegistry
from smartify.tools.builtin import (
    ShellTool,
    FileReadTool,
    FileWriteTool,
    FileListTool,
    FileDeleteTool,
    HttpTool,
    get_builtin_tools,
    create_builtin_registry,
)


class TestToolRegistry:
    """Tests for ToolRegistry."""
    
    def test_register_and_get(self):
        registry = ToolRegistry()
        tool = ShellTool()
        registry.register(tool)
        
        assert registry.get("shell") is tool
        assert registry.get("nonexistent") is None
    
    def test_list_tools(self):
        registry = ToolRegistry()
        registry.register(ShellTool())
        registry.register(FileReadTool())
        
        names = registry.list_tools()
        assert "shell" in names
        assert "file_read" in names
    
    def test_to_openai_format(self):
        registry = ToolRegistry()
        registry.register(ShellTool())
        
        tools = registry.to_openai_format()
        assert len(tools) == 1
        assert tools[0]["type"] == "function"
        assert tools[0]["function"]["name"] == "shell"
    
    def test_to_anthropic_format(self):
        registry = ToolRegistry()
        registry.register(ShellTool())
        
        tools = registry.to_anthropic_format()
        assert len(tools) == 1
        assert tools[0]["name"] == "shell"
        assert "input_schema" in tools[0]


class TestShellTool:
    """Tests for ShellTool."""
    
    @pytest.mark.asyncio
    async def test_echo(self):
        tool = ShellTool()
        result = await tool.execute(command="echo hello")
        
        assert result.success
        assert "hello" in result.output["stdout"]
        assert result.output["exit_code"] == 0
    
    @pytest.mark.asyncio
    async def test_failing_command(self):
        tool = ShellTool()
        result = await tool.execute(command="exit 1")
        
        assert not result.success
        assert result.output["exit_code"] == 1
    
    @pytest.mark.asyncio
    async def test_timeout(self):
        tool = ShellTool()
        result = await tool.execute(command="sleep 10", timeout=0.1)
        
        assert not result.success
        assert "timed out" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_blocked_command(self):
        tool = ShellTool()
        result = await tool.execute(command="rm -rf /")
        
        assert not result.success
        assert "blocked" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_working_dir(self):
        tool = ShellTool()
        with tempfile.TemporaryDirectory() as tmpdir:
            result = await tool.execute(command="pwd", working_dir=tmpdir)
            assert result.success
            assert tmpdir in result.output["stdout"]


class TestFileTools:
    """Tests for file operation tools."""
    
    @pytest.mark.asyncio
    async def test_write_and_read(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            write_tool = FileWriteTool(base_path=tmpdir)
            read_tool = FileReadTool(base_path=tmpdir)
            
            # Write
            result = await write_tool.execute(
                path="test.txt",
                content="Hello, World!"
            )
            assert result.success
            
            # Read
            result = await read_tool.execute(path="test.txt")
            assert result.success
            assert result.output == "Hello, World!"
    
    @pytest.mark.asyncio
    async def test_file_not_found(self):
        read_tool = FileReadTool()
        result = await read_tool.execute(path="/nonexistent/file.txt")
        
        assert not result.success
        assert "not found" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_path_escape_blocked(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            read_tool = FileReadTool(base_path=tmpdir)
            result = await read_tool.execute(path="../../../etc/passwd")
            
            assert not result.success
            assert "escapes" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_file_list(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some files
            Path(tmpdir, "file1.txt").write_text("a")
            Path(tmpdir, "file2.txt").write_text("b")
            Path(tmpdir, "subdir").mkdir()
            
            list_tool = FileListTool(base_path=tmpdir)
            result = await list_tool.execute(path=".")
            
            assert result.success
            assert result.output["count"] == 3
            names = [e["name"] for e in result.output["entries"]]
            assert "file1.txt" in names
            assert "file2.txt" in names
            assert "subdir" in names
    
    @pytest.mark.asyncio
    async def test_file_list_with_pattern(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            Path(tmpdir, "test.py").write_text("a")
            Path(tmpdir, "test.txt").write_text("b")
            
            list_tool = FileListTool(base_path=tmpdir)
            result = await list_tool.execute(path=".", pattern="*.py")
            
            assert result.success
            assert result.output["count"] == 1
            assert result.output["entries"][0]["name"] == "test.py"
    
    @pytest.mark.asyncio
    async def test_file_delete(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir, "to_delete.txt")
            test_file.write_text("delete me")
            
            delete_tool = FileDeleteTool(base_path=tmpdir)
            result = await delete_tool.execute(path="to_delete.txt")
            
            assert result.success
            assert not test_file.exists()
    
    @pytest.mark.asyncio
    async def test_file_append(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            write_tool = FileWriteTool(base_path=tmpdir)
            
            await write_tool.execute(path="log.txt", content="line1\n")
            await write_tool.execute(path="log.txt", content="line2\n", append=True)
            
            content = Path(tmpdir, "log.txt").read_text()
            assert content == "line1\nline2\n"


class TestHttpTool:
    """Tests for HttpTool."""
    
    @pytest.mark.asyncio
    async def test_blocked_localhost(self):
        tool = HttpTool()
        result = await tool.execute(url="http://localhost:8080/test")
        
        assert not result.success
        assert "blocked" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_blocked_internal_ip(self):
        tool = HttpTool()
        result = await tool.execute(url="http://192.168.1.1/test")
        
        assert not result.success
        assert "blocked" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_openai_format(self):
        tool = HttpTool()
        fmt = tool.to_openai_format()
        
        assert fmt["type"] == "function"
        assert fmt["function"]["name"] == "http"
        assert "url" in fmt["function"]["parameters"]["properties"]


class TestBuiltinHelpers:
    """Tests for builtin tool helpers."""
    
    def test_get_builtin_tools(self):
        tools = get_builtin_tools()
        names = [t.name for t in tools]
        
        assert "shell" in names
        assert "file_read" in names
        assert "file_write" in names
        assert "file_list" in names
        assert "file_delete" in names
        assert "http" in names
    
    def test_get_builtin_tools_selective(self):
        tools = get_builtin_tools(enable_shell=False, enable_http=False)
        names = [t.name for t in tools]
        
        assert "shell" not in names
        assert "http" not in names
        assert "file_read" in names
    
    def test_create_builtin_registry(self):
        registry = create_builtin_registry()
        
        assert registry.get("shell") is not None
        assert registry.get("file_read") is not None
        assert registry.get("http") is not None
