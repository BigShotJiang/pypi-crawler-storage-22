"""Tests for validator error detection."""

import pytest
import yaml

from smartify.validator.validate import validate_grid, validate_grid_file


class TestValidatorCatchesErrors:
    """Verify validator catches various spec issues."""
    
    def test_missing_api_version(self):
        """Should catch missing apiVersion."""
        spec = {
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {"nodes": [{"id": "ctrl", "kind": "controller", "name": "C"}]}
        }
        errors = validate_grid(spec)
        assert any("apiversion" in e.lower() for e in errors)
    
    def test_missing_metadata_id(self):
        """Should catch missing metadata.id."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"name": "Test", "version": "1.0.0"},
            "topology": {"nodes": [{"id": "ctrl", "kind": "controller", "name": "C"}]}
        }
        errors = validate_grid(spec)
        assert any("id" in e.lower() for e in errors)
    
    def test_missing_controller(self):
        """Should catch grid without controller."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {"nodes": [
                {"id": "sub1", "kind": "substation", "name": "S1"}
            ]}
        }
        errors = validate_grid(spec)
        assert any("controller" in e.lower() for e in errors)
    
    def test_multiple_controllers(self):
        """Should catch multiple controllers."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {"nodes": [
                {"id": "ctrl1", "kind": "controller", "name": "C1"},
                {"id": "ctrl2", "kind": "controller", "name": "C2"}
            ]}
        }
        errors = validate_grid(spec)
        assert any("controller" in e.lower() and ("one" in e.lower() or "multiple" in e.lower() or "exactly" in e.lower()) for e in errors)
    
    def test_duplicate_node_ids(self):
        """Should catch duplicate node IDs."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {"nodes": [
                {"id": "node1", "kind": "controller", "name": "C"},
                {"id": "node1", "kind": "substation", "name": "S"}
            ]}
        }
        errors = validate_grid(spec)
        assert any("duplicate" in e.lower() or "unique" in e.lower() for e in errors)
    
    def test_invalid_node_kind(self):
        """Should catch invalid node kind."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {"nodes": [
                {"id": "ctrl", "kind": "controller", "name": "C"},
                {"id": "bad", "kind": "invalid_kind", "name": "Bad"}
            ]}
        }
        errors = validate_grid(spec)
        assert len(errors) > 0  # Should have validation error
    
    def test_orphan_node_invalid_parent(self):
        """Should catch node with non-existent parent."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {"nodes": [
                {"id": "ctrl", "kind": "controller", "name": "C"},
                {"id": "sub", "kind": "substation", "name": "S", "parent": "nonexistent"}
            ]}
        }
        errors = validate_grid(spec)
        assert any("parent" in e.lower() or "nonexistent" in e.lower() for e in errors)
    
    def test_empty_nodes(self):
        """Should catch empty nodes list."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {"nodes": []}
        }
        errors = validate_grid(spec)
        assert len(errors) > 0
    
    def test_valid_minimal_grid(self):
        """Valid minimal grid should have no errors."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {
                "trigger": {"type": "manual"},
                "nodes": [{"id": "ctrl", "kind": "controller", "name": "Controller"}]
            }
        }
        errors = validate_grid(spec)
        assert len(errors) == 0, f"Unexpected errors: {errors}"
    
    def test_valid_multi_node_grid(self):
        """Valid multi-node grid should pass."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {
                "trigger": {"type": "manual"},
                "nodes": [
                    {"id": "ctrl", "kind": "controller", "name": "Controller"},
                    {"id": "relay1", "kind": "relay", "name": "R1", "parent": "ctrl"},
                    {"id": "sub1", "kind": "substation", "name": "S1", "parent": "relay1"},
                    {"id": "sub2", "kind": "substation", "name": "S2", "parent": "relay1"},
                ]
            }
        }
        errors = validate_grid(spec)
        assert len(errors) == 0, f"Unexpected errors: {errors}"
    
    def test_breaker_validation(self):
        """Breaker config should validate."""
        spec = {
            "apiVersion": "smartify.ai/v1",
            "kind": "GridSpec",
            "metadata": {"id": "test", "name": "Test", "version": "1.0.0"},
            "topology": {
                "nodes": [{"id": "ctrl", "kind": "controller", "name": "C"}]
            },
            "breakers": {
                "tokens": {"limit": 10000, "action": "stop"},
                "cost": {"limit": 1.0, "action": "pause"}
            }
        }
        errors = validate_grid(spec)
        assert len(errors) == 0, f"Unexpected errors: {errors}"
