"""Tests for webhook notification system."""

import asyncio
import json
import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from smartify.notifications.webhook import (
    WebhookNotifier,
    WebhookConfig,
    WebhookEvent,
    EventType,
    DeliveryResult,
)


class TestWebhookConfig:
    """Test WebhookConfig."""
    
    def test_default_events(self):
        """Should include all event types by default."""
        config = WebhookConfig(url="https://example.com/hook")
        assert EventType.RUN_COMPLETED in config.events
        assert EventType.RUN_FAILED in config.events
        assert EventType.BREAKER_TRIPPED in config.events
    
    def test_accepts_event(self):
        """Should filter events correctly."""
        config = WebhookConfig(
            url="https://example.com/hook",
            events=[EventType.RUN_COMPLETED, EventType.RUN_FAILED],
        )
        assert config.accepts_event(EventType.RUN_COMPLETED)
        assert config.accepts_event(EventType.RUN_FAILED)
        assert not config.accepts_event(EventType.BREAKER_TRIPPED)
    
    def test_disabled_webhook(self):
        """Should not accept events when disabled."""
        config = WebhookConfig(
            url="https://example.com/hook",
            enabled=False,
        )
        assert not config.accepts_event(EventType.RUN_COMPLETED)


class TestWebhookEvent:
    """Test WebhookEvent."""
    
    def test_to_payload(self):
        """Should convert to proper payload format."""
        event = WebhookEvent(
            id="evt-123",
            type=EventType.RUN_COMPLETED,
            grid_id="grid-456",
            timestamp=datetime(2026, 2, 1, 12, 0, 0),
            data={"outputs": {"result": "success"}},
        )
        
        payload = event.to_payload()
        
        assert payload["event_id"] == "evt-123"
        assert payload["event_type"] == "run_completed"
        assert payload["grid_id"] == "grid-456"
        assert "2026-02-01" in payload["timestamp"]
        assert payload["data"]["outputs"]["result"] == "success"


class TestWebhookNotifier:
    """Test WebhookNotifier."""
    
    def test_add_webhook(self):
        """Should add webhook configurations."""
        notifier = WebhookNotifier()
        config = WebhookConfig(url="https://example.com/hook")
        
        notifier.add_webhook(config)
        
        assert len(notifier.webhooks) == 1
        assert notifier.webhooks[0].url == "https://example.com/hook"
    
    def test_remove_webhook(self):
        """Should remove webhook by URL."""
        notifier = WebhookNotifier()
        notifier.add_webhook(WebhookConfig(url="https://example.com/hook1"))
        notifier.add_webhook(WebhookConfig(url="https://example.com/hook2"))
        
        result = notifier.remove_webhook("https://example.com/hook1")
        
        assert result is True
        assert len(notifier.webhooks) == 1
        assert notifier.webhooks[0].url == "https://example.com/hook2"
    
    def test_remove_nonexistent_webhook(self):
        """Should return False for nonexistent webhook."""
        notifier = WebhookNotifier()
        result = notifier.remove_webhook("https://example.com/nonexistent")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_notify_creates_event(self):
        """Should create event and add to history."""
        notifier = WebhookNotifier()
        
        event = await notifier.notify(
            event_type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            data={"result": "success"},
        )
        
        assert event.type == EventType.RUN_COMPLETED
        assert event.grid_id == "test-grid"
        assert event.data["result"] == "success"
        assert event in notifier.event_history
    
    @pytest.mark.asyncio
    async def test_notify_no_matching_webhooks(self):
        """Should handle no matching webhooks gracefully."""
        notifier = WebhookNotifier()
        notifier.add_webhook(WebhookConfig(
            url="https://example.com/hook",
            events=[EventType.RUN_FAILED],  # Only failed events
        ))
        
        # Send completed event - should not match
        event = await notifier.notify(
            event_type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            data={},
        )
        
        assert not event.delivered  # No matching webhooks, so not delivered
    
    @pytest.mark.asyncio
    async def test_notify_run_completed_convenience(self):
        """Test run_completed convenience method."""
        notifier = WebhookNotifier()
        
        event = await notifier.notify_run_completed(
            grid_id="test-grid",
            outputs={"result": "success"},
            duration_seconds=45.5,
            total_tokens=1000,
            total_cost=0.05,
        )
        
        assert event.type == EventType.RUN_COMPLETED
        assert event.data["outputs"] == {"result": "success"}
        assert event.data["duration_seconds"] == 45.5
        assert event.data["total_tokens"] == 1000
        assert event.data["total_cost"] == 0.05
    
    @pytest.mark.asyncio
    async def test_notify_run_failed_convenience(self):
        """Test run_failed convenience method."""
        notifier = WebhookNotifier()
        
        event = await notifier.notify_run_failed(
            grid_id="test-grid",
            error="Something went wrong",
            node_id="node-123",
            duration_seconds=10.0,
        )
        
        assert event.type == EventType.RUN_FAILED
        assert event.data["error"] == "Something went wrong"
        assert event.data["failed_node"] == "node-123"
    
    @pytest.mark.asyncio
    async def test_notify_breaker_tripped_convenience(self):
        """Test breaker_tripped convenience method."""
        notifier = WebhookNotifier()
        
        event = await notifier.notify_breaker_tripped(
            grid_id="test-grid",
            breaker_type="tokens",
            current_value=50000,
            limit=40000,
            action="stop",
        )
        
        assert event.type == EventType.BREAKER_TRIPPED
        assert event.data["breaker_type"] == "tokens"
        assert event.data["current_value"] == 50000
        assert event.data["limit"] == 40000
        assert event.data["action"] == "stop"
    
    def test_get_recent_events(self):
        """Should return recent events with filtering."""
        notifier = WebhookNotifier()
        
        # Add events directly to history
        notifier.event_history = [
            WebhookEvent(
                id="evt-1",
                type=EventType.RUN_COMPLETED,
                grid_id="grid-a",
                timestamp=datetime.now(),
                data={},
            ),
            WebhookEvent(
                id="evt-2",
                type=EventType.RUN_FAILED,
                grid_id="grid-b",
                timestamp=datetime.now(),
                data={},
            ),
            WebhookEvent(
                id="evt-3",
                type=EventType.RUN_COMPLETED,
                grid_id="grid-a",
                timestamp=datetime.now(),
                data={},
            ),
        ]
        
        # All events
        all_events = notifier.get_recent_events()
        assert len(all_events) == 3
        
        # Filter by type
        completed = notifier.get_recent_events(event_type=EventType.RUN_COMPLETED)
        assert len(completed) == 2
        
        # Filter by grid
        grid_a = notifier.get_recent_events(grid_id="grid-a")
        assert len(grid_a) == 2
        
        # Combined filter
        grid_a_completed = notifier.get_recent_events(
            event_type=EventType.RUN_COMPLETED,
            grid_id="grid-a",
        )
        assert len(grid_a_completed) == 2
    
    def test_get_failed_deliveries(self):
        """Should return events that failed to deliver."""
        notifier = WebhookNotifier()
        
        # Successful delivery
        success_event = WebhookEvent(
            id="evt-1",
            type=EventType.RUN_COMPLETED,
            grid_id="grid-a",
            timestamp=datetime.now(),
            data={},
            attempts=1,
            delivered=True,
        )
        
        # Failed delivery
        failed_event = WebhookEvent(
            id="evt-2",
            type=EventType.RUN_FAILED,
            grid_id="grid-b",
            timestamp=datetime.now(),
            data={},
            attempts=3,
            delivered=False,
            last_error="Connection refused",
        )
        
        notifier.event_history = [success_event, failed_event]
        
        failed = notifier.get_failed_deliveries()
        assert len(failed) == 1
        assert failed[0].id == "evt-2"


class TestWebhookDelivery:
    """Test webhook delivery mechanics."""
    
    def test_compute_signature(self):
        """Should compute HMAC-SHA256 signature."""
        notifier = WebhookNotifier()
        
        body = '{"test": "data"}'
        secret = "my-secret-key"
        
        signature = notifier._compute_signature(body, secret)
        
        # Signature should be hex string
        assert len(signature) == 64  # SHA256 produces 64 hex chars
        assert all(c in '0123456789abcdef' for c in signature)
    
    @pytest.mark.asyncio
    async def test_deliver_success(self):
        """Should handle successful delivery."""
        notifier = WebhookNotifier()
        
        event = WebhookEvent(
            id="evt-123",
            type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            timestamp=datetime.now(),
            data={"result": "success"},
        )
        
        config = WebhookConfig(url="https://example.com/hook")
        
        # Mock httpx
        with patch('smartify.notifications.webhook.httpx.AsyncClient') as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.text = "OK"
            
            mock_instance = AsyncMock()
            mock_instance.post = AsyncMock(return_value=mock_response)
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_instance
            
            result = await notifier._deliver(event, config)
        
        assert result.success
        assert result.status_code == 200
    
    @pytest.mark.asyncio
    async def test_deliver_failure(self):
        """Should handle failed delivery."""
        notifier = WebhookNotifier()
        
        event = WebhookEvent(
            id="evt-123",
            type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            timestamp=datetime.now(),
            data={},
        )
        
        config = WebhookConfig(url="https://example.com/hook")
        
        # Mock httpx with error response
        with patch('smartify.notifications.webhook.httpx.AsyncClient') as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 500
            mock_response.text = "Internal Server Error"
            
            mock_instance = AsyncMock()
            mock_instance.post = AsyncMock(return_value=mock_response)
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_instance
            
            result = await notifier._deliver(event, config)
        
        assert not result.success
        assert result.status_code == 500
        assert "500" in result.error
    
    @pytest.mark.asyncio
    async def test_deliver_with_signature(self):
        """Should include signature header when secret configured."""
        notifier = WebhookNotifier()
        
        event = WebhookEvent(
            id="evt-123",
            type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            timestamp=datetime.now(),
            data={},
        )
        
        config = WebhookConfig(
            url="https://example.com/hook",
            secret="my-secret",
        )
        
        with patch('smartify.notifications.webhook.httpx.AsyncClient') as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.text = "OK"
            
            mock_instance = AsyncMock()
            mock_instance.post = AsyncMock(return_value=mock_response)
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_instance
            
            await notifier._deliver(event, config)
            
            # Check that signature header was included
            call_kwargs = mock_instance.post.call_args.kwargs
            headers = call_kwargs.get("headers", {})
            assert "X-Smartify-Signature" in headers
            assert headers["X-Smartify-Signature"].startswith("sha256=")
    
    @pytest.mark.asyncio
    async def test_deliver_with_custom_headers(self):
        """Should include custom headers."""
        notifier = WebhookNotifier()
        
        event = WebhookEvent(
            id="evt-123",
            type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            timestamp=datetime.now(),
            data={},
        )
        
        config = WebhookConfig(
            url="https://example.com/hook",
            headers={"Authorization": "Bearer my-token"},
        )
        
        with patch('smartify.notifications.webhook.httpx.AsyncClient') as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.text = "OK"
            
            mock_instance = AsyncMock()
            mock_instance.post = AsyncMock(return_value=mock_response)
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_instance
            
            await notifier._deliver(event, config)
            
            call_kwargs = mock_instance.post.call_args.kwargs
            headers = call_kwargs.get("headers", {})
            assert headers.get("Authorization") == "Bearer my-token"


class TestWebhookRetry:
    """Test retry logic."""
    
    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        """Should retry on failure up to max_retries."""
        notifier = WebhookNotifier()
        
        event = WebhookEvent(
            id="evt-123",
            type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            timestamp=datetime.now(),
            data={},
        )
        
        config = WebhookConfig(
            url="https://example.com/hook",
            max_retries=2,
            retry_delay_seconds=0.01,  # Fast for testing
        )
        
        with patch('smartify.notifications.webhook.httpx.AsyncClient') as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 500
            mock_response.text = "Error"
            
            mock_instance = AsyncMock()
            mock_instance.post = AsyncMock(return_value=mock_response)
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_instance
            
            result = await notifier._deliver_with_retry(event, config)
        
        # Should have attempted 3 times (1 initial + 2 retries)
        assert event.attempts == 3
        assert not result.success
    
    @pytest.mark.asyncio
    async def test_success_on_retry(self):
        """Should succeed if retry works."""
        notifier = WebhookNotifier()
        
        event = WebhookEvent(
            id="evt-123",
            type=EventType.RUN_COMPLETED,
            grid_id="test-grid",
            timestamp=datetime.now(),
            data={},
        )
        
        config = WebhookConfig(
            url="https://example.com/hook",
            max_retries=2,
            retry_delay_seconds=0.01,
        )
        
        call_count = 0
        
        async def mock_post(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            
            mock_response = MagicMock()
            if call_count < 2:
                mock_response.status_code = 500
                mock_response.text = "Error"
            else:
                mock_response.status_code = 200
                mock_response.text = "OK"
            return mock_response
        
        with patch('smartify.notifications.webhook.httpx.AsyncClient') as mock_client:
            mock_instance = AsyncMock()
            mock_instance.post = mock_post
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_instance
            
            result = await notifier._deliver_with_retry(event, config)
        
        assert result.success
        assert event.attempts == 2  # Failed once, succeeded on second try
        assert event.delivered


class TestEventHistoryLimit:
    """Test event history size limit."""
    
    def test_history_trimmed(self):
        """Should trim history when exceeding max size."""
        notifier = WebhookNotifier()
        notifier.max_history_size = 5
        
        # Add more events than max
        for i in range(10):
            event = WebhookEvent(
                id=f"evt-{i}",
                type=EventType.RUN_COMPLETED,
                grid_id="test-grid",
                timestamp=datetime.now(),
                data={},
            )
            notifier._add_to_history(event)
        
        # Should only have last 5 events
        assert len(notifier.event_history) == 5
        assert notifier.event_history[0].id == "evt-5"
        assert notifier.event_history[-1].id == "evt-9"
