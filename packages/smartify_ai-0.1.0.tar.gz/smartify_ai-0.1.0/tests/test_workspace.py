"""Tests for workspace management."""

import pytest
import tempfile
from pathlib import Path

from smartify.workspace import WorkspaceManager, Workspace


class TestWorkspaceManager:
    """Tests for WorkspaceManager."""
    
    def test_create_workspace(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = WorkspaceManager(base_path=tmpdir)
            
            ws = manager.create("run-1", "grid-a")
            
            assert ws.run_id == "run-1"
            assert ws.grid_id == "grid-a"
            assert ws.path.exists()
            assert (ws.path / "output").exists()
            assert (ws.path / "temp").exists()
    
    def test_get_workspace(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = WorkspaceManager(base_path=tmpdir)
            
            ws = manager.create("run-1", "grid-a")
            
            retrieved = manager.get("run-1")
            assert retrieved is ws
            
            assert manager.get("nonexistent") is None
    
    def test_cleanup(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = WorkspaceManager(base_path=tmpdir)
            
            ws = manager.create("run-1", "grid-a")
            ws_path = ws.path
            
            assert ws_path.exists()
            assert manager.cleanup("run-1")
            assert not ws_path.exists()
            assert manager.get("run-1") is None
    
    def test_preserve_on_error(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = WorkspaceManager(base_path=tmpdir, preserve_on_error=True)
            
            ws = manager.create("run-1", "grid-a")
            ws.mark_error()
            ws_path = ws.path
            
            # Should not cleanup due to error
            assert not manager.cleanup("run-1")
            assert ws_path.exists()
            
            # Force cleanup should work
            assert manager.cleanup("run-1", force=True)
            assert not ws_path.exists()
    
    def test_list_workspaces(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = WorkspaceManager(base_path=tmpdir)
            
            manager.create("run-1", "grid-a")
            manager.create("run-2", "grid-a")
            manager.create("run-3", "grid-b")
            
            workspaces = manager.list_workspaces()
            assert len(workspaces) == 3
            assert "run-1" in workspaces
            assert "run-2" in workspaces
            assert "run-3" in workspaces
    
    def test_cleanup_all(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = WorkspaceManager(base_path=tmpdir)
            
            manager.create("run-1", "grid-a")
            manager.create("run-2", "grid-a")
            
            count = manager.cleanup_all()
            assert count == 2
            assert len(manager.list_workspaces()) == 0


class TestWorkspace:
    """Tests for Workspace class."""
    
    def test_write_and_read_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            ws = Workspace("run-1", "grid-a", Path(tmpdir))
            
            ws.write_file("test.txt", "Hello, World!")
            content = ws.read_file("test.txt")
            
            assert content == "Hello, World!"
    
    def test_nested_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            ws = Workspace("run-1", "grid-a", Path(tmpdir))
            
            ws.write_file("subdir/nested/file.txt", "Nested content")
            
            assert ws.exists("subdir/nested/file.txt")
            assert ws.read_file("subdir/nested/file.txt") == "Nested content"
    
    def test_path_escape_blocked(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            ws = Workspace("run-1", "grid-a", Path(tmpdir))
            
            with pytest.raises(ValueError, match="escapes"):
                ws.resolve("../../../etc/passwd")
    
    def test_list_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            ws = Workspace("run-1", "grid-a", Path(tmpdir))
            
            ws.write_file("file1.txt", "a")
            ws.write_file("file2.txt", "b")
            
            # Note: output and temp dirs are also created
            files = ws.list_files(".")
            names = [f.name for f in files]
            
            assert "file1.txt" in names
            assert "file2.txt" in names
    
    def test_output_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            ws = Workspace("run-1", "grid-a", Path(tmpdir))
            
            assert ws.output_dir.exists()
            assert ws.output_dir == ws.path / "output"
    
    def test_cleanup_temp(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            ws = Workspace("run-1", "grid-a", Path(tmpdir))
            
            # Create some temp files
            (ws.temp_dir / "temp1.txt").write_text("temp")
            (ws.temp_dir / "temp2.txt").write_text("temp")
            
            assert len(list(ws.temp_dir.iterdir())) == 2
            
            ws.cleanup_temp()
            
            assert len(list(ws.temp_dir.iterdir())) == 0
