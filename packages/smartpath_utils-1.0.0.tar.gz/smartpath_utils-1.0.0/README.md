# smartpath

smartpath provides small utilities to find the project root, resolve paths
relative to the project, search upward for files, and normalize paths.

Usage examples

```py
from smartpath import project_root, resolve, find_up, normalize, in_project
from pathlib import Path

# Find project root
root = project_root()
print(root)

# Resolve a file relative to project
cfg = resolve('pyproject.toml')
print(cfg)

# Find a file by walking upwards
env_file = find_up('.env')
print(env_file)

# Normalize a path
p = normalize('~/projects/../project')
print(p)

# Check whether a path is inside the project
print(in_project('/some/path'))
```

Environment configuration

  `project_root` (e.g. `.git,pyproject.toml,setup.cfg`). If set, it overrides
  the default marker list.

 - `project_root(start)` / `in_project(path)` in `core.py` — detects project root and checks membership.
 - `is_git_repo(start)` / `relative_to_project(path)` in `core.py` — convenience helpers to detect Git repos and express paths relative to project.
 - `resolve(relative_path, start)` in `resolver.py` — resolves relative paths against the project root (accepts absolute paths).
 - `find_up(filename, start)` and `find_files(pattern, start, recursive)` in `search.py` — find a single file walking up, and search for matching files under the project.
 - `normalize(path)` in `utils.py` — `expanduser()` + `resolve(strict=False)` for robust normalization.

Notes on design:
- Defaults use non-strict resolution so tools can operate on files that don't exist yet (generators, scaffolding).
- Markers can be customized via the `SMARTPATH_MARKERS` environment variable.
Notes

- The helpers use non-strict resolution by default so they do not raise
  errors for paths that don't exist yet (which is convenient for CLI tools
  and generators).
