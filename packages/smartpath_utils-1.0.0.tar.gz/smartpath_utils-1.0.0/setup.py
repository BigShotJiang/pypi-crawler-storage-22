from setuptools import setup, find_packages

setup(
    name="smartpath-utils",
    version="1.0.0",
    description="Small utilities for working with project-local paths",
    author="lelewithheart",
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.6',
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
