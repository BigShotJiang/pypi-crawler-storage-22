CITY = 'city'

NONE = 'none'
