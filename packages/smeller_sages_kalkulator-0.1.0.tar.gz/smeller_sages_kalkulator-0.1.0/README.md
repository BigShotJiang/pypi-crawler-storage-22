# Calculator Functions
This module provides a collection of functions for performing basic arithmetic operations, including addition, subtraction, multiplication, and division. Each function takes two numerical inputs and returns the result of the corresponding operation.
## Functions
- `add(a, b)`: Returns the sum of `a` and `b`.
- `subtract(a, b)`: Returns the difference of `a` and `b`.
- `multiply(a, b)`: Returns the product of `a` and `b`.
- `divide(a, b)`: Returns the quotient of `a` and `b`.
## Usage
To use the functions in this module, simply import the module and call the desired function with the appropriate arguments. For example:
```python
from sages_kalkulator import add, subtract, multiply, divide
result_add = add(5, 3)        # Returns 8
result_subtract = subtract(5, 3)  # Returns 2
result_multiply = multiply(5, 3)  # Returns 15
result_divide = divide(5, 3)    # Returns 1.6666666666666667
```

## Error Handling
The `divide` function includes error handling to prevent division by zero. If the second argument is zero, the function will raise a `ValueError` with an appropriate message. For example:
```python
try:
    result_divide = divide(5, 0)  # This will raise a ValueError
except ValueError as e:
    print(e)  # Output: Cannot divide by zero.
```
## Conclusion
This module provides a simple and efficient way to perform basic arithmetic operations. It can be easily extended
to include additional functions such as exponentiation, modulus, or more complex mathematical operations as needed.
