# Smart Logger 📝

**Smart Logger** is a highly customizable Python logger with colored console output, file logging, daily rotation, unique directories, and context support. Perfect for projects where structured logging and contextual information are essential.

---

## 📦 Installation

```bash
pip install smlog
```

## 🚀 Quick Start
``` bash
from logger import Logger

logger = Logger(
    name="MyApp",
    min_level="DEBUG",
    use_colors=True,
    log_to_file=True,
    log_dir="logs",
    rotate_daily=True,
    unique_dir=True,
    console=True
)

logger.debug("This is a debug message")
logger.info("Informational message", user="Nikita")
logger.warning("Warning message")
try:
    1 / 0
except Exception as e:
    logger.error("Error occurred", exc=e)

logger.bind(session_id="12345", user="Nikita")
logger.info("Message with context")
logger.unbind("session_id")  # Remove a single key
```


## ⚙️ Features

``` bash
1. Colored Console Output
- DEBUG — Blue
- INFO — Cyan
- WARNING — Yellow
- ERROR — Red
- DATE — Magenta
- MESSAGE — Cyan
Colors can be disabled using use_colors=False.

2. File Logging
Logs can be saved to a specific directory (log_dir).
Supports daily rotation (rotate_daily=True).
Unique directories can be created with unique_dir=True to avoid overwriting existing logs.

3. Custom Format
Use set_format(fmt) to customize log format:
logger.set_format("[{time}] [{level}] ({name}) {msg} | {context}")
Available fields:
- {time} — current date and time
- {level} — log level
- {name} — logger name
- {msg} — log message
- {context} — optional context
Context is only included if it exists. The | separator is automatically omitted if empty.

4. Context Management
Add context globally with bind:
logger.bind(user="Nikita", session="xyz")
logger.info("Message with context")
logger.unbind("session")  # Remove a key
logger.unbind()  # Clear all context

5. Log Levels
Supported levels: DEBUG, INFO, WARNING, ERROR.
Filter logs by min_level:

    logger = Logger(min_level="WARNING")
    logger.debug("This will not show")  # Skipped
    logger.error("This will show")
    Invalid levels will suggest the closest match:
    logger.log("INF", "Message")  # Did you mean "INFO"?

6. Format Help
Prints available fields and example usage:
logger.show_format_help()
Example output:
    ==========================
    Available parameters: ['time', 'level', 'name', 'msg', 'context']
    Example: [{time}] [{level}] ({name}) {msg}{context}
    [NOTICE] If you want to add 'context', do it as shown in the example!
    ==========================
```

## 🛠️ Logger Constructor

| **Parameter**  | **Type** | **Default** | **Description**                                  |
|:--------------:|:--------:|:-----------:|:------------------------------------------------:|
| `name`         | `str`    | `"root"`    | 🏷 Logger name                                   |
| `min_level`    | `str`    | `"DEBUG"`   | ⚡ Minimum log level                             |
| `use_colors`   | `bool`   | `True`      | 🎨 Enable colored output in console              |
| `log_to_file`  | `bool`   | `False`     | 💾 Save logs to file                             |
| `log_dir`      | `str`    | `"logs"`    | 📂 Directory for log files                       |
| `rotate_daily` | `bool`   | `False`     | 🗓 Create a new file each day                    |
| `unique_dir`   | `bool`   | `False`     | ✨ Create a unique directory if one exists       |
| `console`      | `bool`   | `True`      | 🖥 Print messages to console                     |

### 📝 Example Usage

``` bash
logger = Logger(
    name="MyApp",
    min_level="DEBUG",
    log_to_file=True,
    log_dir="my_logs",
    rotate_daily=True,
    unique_dir=True
)

logger.bind(user="Nikita", env="production")
logger.info("App started")
logger.warning("High load warning")
try:
    *here is your error*
except Exception as e:
    logger.error("Connection error", exc=e)
logger.unbind("env")
logger.debug("Debugging info", ip="127.0.0.1")

Example log file output:
    [2026-01-27 15:42:10] [INFO] (MyApp) App started | user=Nikita, env=production
    --------------------
    [2026-01-27 15:42:15] [WARNING] (MyApp) High load warning | user=Nikita, env=production
    --------------------
    [2026-01-27 15:42:20] [ERROR] (MyApp) Connection error | user=Nikita, env=production
    --------------------
```

# ✅ Features Summary
Lightweight, clean Python logger
Colored and formatted console output
Context support for dynamic logging
File logging with optional daily rotation
Unique directories to avoid overwriting logs
Full Python 3.7+ support