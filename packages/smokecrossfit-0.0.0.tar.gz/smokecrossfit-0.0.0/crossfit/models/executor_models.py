from enum import Enum


class ExecutorType(Enum):
    Local = "Local"
    Remote = "Remote"
