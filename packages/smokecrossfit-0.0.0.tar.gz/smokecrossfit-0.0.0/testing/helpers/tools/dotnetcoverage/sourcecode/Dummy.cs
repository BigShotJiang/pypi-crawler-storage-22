namespace Dummy { public class Foo { public int Bar() => 1; } }
