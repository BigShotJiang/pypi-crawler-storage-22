# Smriti — Smart Screen Session Manager

## Overview
Smriti manages GNU Screen sessions with auto-naming (hostname-dir-hash-tag-timestamp), conda/venv detection, and Claude Code integration. CLI is built on vidhi's `BaseCommand` subcommand system.

## Build System
Always use the Makefile:
```bash
make format    # autoflake + isort + black
make lint      # black --check + isort --check + autoflake --check + pyright + codespell
make test      # pytest tests/ -v
make build     # wheel + sdist
```

## Architecture
```
src/smriti/
├── cli.py          # Entry point (main), subcommand dispatch via isinstance checks
├── config.py       # SmritiCommand base + all subcommands (Create, Reattach, Kill, Claude, etc.)
├── session.py      # Screen lifecycle: create, reattach, kill, list (bash/zsh init scripts)
├── naming.py       # Session name format: <host>-<dir>-<hash>-<tag>-<YYYYMMDD-HHMMSS>
├── env_detect.py   # Conda/venv detection (local dirs → YAML → meta files)
├── claude_code.py  # Claude Code session management (cc tag)
└── utils.py        # Logging, color output, session list formatting, interactive picker
```

### Subcommand flow
`sm <subcommand> [flags]` → `parse_cli_args(SmritiCommand)` → returns typed subclass → `isinstance()` dispatch in `cli.py:main()`

### Subcommands (defined in config.py)

#### Regular Sessions
| Command | Alias | Scope | Description |
|---------|-------|-------|-------------|
| create | c | dir | Create session (default cmd). `--tag` for custom tag. |
| auto | a | global | Auto-connect to latest session globally, or create. `--target` for substring match. |
| auto-dir | ad | dir | Auto-connect to latest in current dir, or create. |
| reattach | r | global | List all sessions, interactive picker. No auto-create. |
| list | l | global | List all sessions |
| list-dir | ld | dir | List sessions in current dir |
| kill | k | dir | Kill latest session in current dir |
| kill-all | ka | dir | Kill all sessions in current dir |
| kill-latest | kl | global | Kill latest session (any dir) |

#### Claude Code Sessions
| Command | Alias | Scope | Description |
|---------|-------|-------|-------------|
| claude | cc | dir | Create new CC session. `--args`, `--config_dir` flags. |
| claude-auto | cca | global | Auto-connect to latest CC session globally, or create. |
| claude-auto-dir | ccad | dir | Auto-connect to latest CC in current dir, or create. |
| claude-reattach | ccr | global | List all CC sessions, interactive picker. No auto-create. |
| claude-list | ccl | global | List all CC sessions |
| claude-list-dir | ccld | dir | List CC sessions in current dir |
| claude-kill | cck | dir | Kill latest CC session in current dir |
| claude-kill-all | ccka | dir | Kill all CC sessions in current dir |

#### Utility
| Command | Alias | Description |
|---------|-------|-------------|
| env | e | Show detected environment |

## Coding Standards
- **Formatter**: black (line-length 100) + isort (profile=black)
- **Linting**: autoflake (unused imports), pyright (type checking), codespell
- **Type hints**: required on all public functions, use `str | None` not `Optional[str]`
- **Python target**: 3.12+
- **No** `from __future__ import annotations`

## Adding a New Subcommand
1. Define a new `@frozen_dataclass` class in `config.py` inheriting `SmritiCommand`:
   ```python
   @frozen_dataclass
   class MyCmd(SmritiCommand, name="my-cmd", alias="mc"):
       """Description"""
       my_flag: str = field("default", help="Flag description")
   ```
2. Add `isinstance(cmd, MyCmd)` branch in `cli.py:main()`
3. Import the new class in `cli.py` and `tests/test_cli.py`
4. Add test in `tests/test_cli.py` for alias resolution and flag parsing

## Testing
- Tests use `patch.object(sys, "argv", [...])` to simulate CLI input
- Session tests mock `subprocess.run` for screen commands
- Env detection tests use `tmp_path` fixtures with fake directory structures
- Run: `make test` (50+ tests, all should pass)
