# Smriti

Smart GNU Screen session manager with auto-naming, conda/venv detection, and Claude Code integration.

## Install

```bash
pip install -e .
```

Requires GNU Screen (`apt install screen` / `brew install screen`).

## Quick Start

```bash
sm                        # Create session in current dir (default)
sm c --tag dev            # Create with custom tag
sm l                      # List all sessions
sm ld                     # List sessions in current directory
sm r                      # Reattach (interactive picker, all sessions)
sm a                      # Auto-connect to latest globally (or create)
sm a --target vajra       # Auto-connect to session matching "vajra"
sm ad                     # Auto-connect to latest in current dir (or create)
sm k                      # Kill latest session in current dir
```

## Commands

### Regular Sessions

| Command | Alias | Scope | Description |
|---------|-------|-------|-------------|
| `create` | `c` | dir | Create a new session (default command) |
| `auto` | `a` | global | Auto-connect to latest session globally, or create. `--target` for substring match. |
| `auto-dir` | `ad` | dir | Auto-connect to latest in current dir, or create |
| `reattach` | `r` | global | List all sessions, interactive picker |
| `list` | `l` | global | List all sessions |
| `list-dir` | `ld` | dir | List sessions in current directory |
| `kill` | `k` | dir | Kill latest session in current directory |
| `kill-all` | `ka` | dir | Kill all sessions in current directory |
| `kill-latest` | `kl` | global | Kill latest session (any directory) |

### Claude Code Sessions

| Command | Alias | Scope | Description |
|---------|-------|-------|-------------|
| `claude` | `cc` | dir | Launch Claude Code in a session |
| `claude-auto` | `cca` | global | Auto-connect to latest CC session globally, or create |
| `claude-auto-dir` | `ccad` | dir | Auto-connect to latest CC in current dir, or create |
| `claude-reattach` | `ccr` | global | List all CC sessions, interactive picker |
| `claude-list` | `ccl` | global | List all Claude Code sessions |
| `claude-list-dir` | `ccld` | dir | List CC sessions in current directory |
| `claude-kill` | `cck` | dir | Kill latest CC session in current directory |
| `claude-kill-all` | `ccka` | dir | Kill all CC sessions in current directory |

### Utility

| Command | Alias | Description |
|---------|-------|-------------|
| `env` | `e` | Show detected environment info |

## Session Naming

Sessions follow the format: `<hostname>-<dirname>-<hash>-<tag>-<YYYYMMDD-HHMMSS>`

```
gpu01-vajra-a3f1-session-20260212-143022
gpu01-vajra-a3f1-dev-20260212-150000
gpu01-vajra-a3f1-cc-20260212-160000
```

- **hostname**: short hostname of the machine
- **dirname**: current directory basename (truncated to 30 chars)
- **hash**: 4-char SHA1 hash of the full path (disambiguates same-name dirs)
- **tag**: session purpose (`session`, `dev`, `cc`, etc.)
- **timestamp**: creation time for chronological sorting

Directory-specific commands (`ld`, `k`, `ka`) match on `<hostname>-<dirname>-<hash>-` so they only operate on sessions created from the current directory.

## Directory-Scoped Commands

Smriti tracks which directory a session was created in via the naming convention. This enables powerful directory-scoped operations:

```bash
# In ~/projects/vajra
cd ~/projects/vajra
sm c --tag dev            # Creates: gpu01-vajra-a3f1-dev-20260214-100000
sm c --tag train          # Creates: gpu01-vajra-a3f1-train-20260214-100500
sm cc                     # Creates: gpu01-vajra-a3f1-cc-20260214-101000

# In ~/projects/niti
cd ~/projects/niti
sm c                      # Creates: gpu01-niti-b7c2-session-20260214-110000

# Directory-scoped listing — only shows vajra sessions
cd ~/projects/vajra
sm ld                     # Shows: dev, train (not cc, not niti sessions)

# Directory-scoped kill
sm k                      # Kills latest vajra session (train)
sm ka                     # Kills all vajra sessions (dev + train)

# Global listing — shows everything
sm l                      # Shows all sessions across all directories
```

## Global vs Directory Scope

Commands come in global and dir-scoped variants:

- **`auto`** (`sm a`) connects to the latest session globally across all directories.
- **`auto-dir`** (`sm ad`) connects to the latest session in the current directory only.
- **`reattach`** (`sm r`) lists all sessions for interactive picking.

The same pattern applies to Claude Code commands (`cca` vs `ccad`, `ccl` vs `ccld`).

## Conda / Venv Detection

Smriti auto-detects and activates Python environments when creating sessions. Detection priority:

1. **Local directories** — checks `env/`, `.env/`, `venv/`, `.venv/`, `conda_env/`, etc. for `bin/python`
2. **YAML files** — parses `environment.yml`, `conda.yml` etc. for `name:` field
3. **Meta files** — reads `.conda_env`, `.conda-env`, `.python-version`

```bash
sm e                      # Show what environment smriti detects
sm c                      # Auto-activates detected env in the session
sm c --no_conda           # Skip env detection
```

## Claude Code Integration

Launch Claude Code in managed screen sessions with environment auto-activation:

```bash
sm cc                     # Launch Claude Code
sm cc --args "--resume"   # Pass extra args to claude
sm cc --config_dir ~/.sclaude   # Use alternate config dir
sm cca                    # Auto-connect to latest CC session globally (or create)
sm ccad                   # Auto-connect to latest CC in current dir (or create)
sm ccl                    # List all Claude Code sessions
sm ccld                   # List CC sessions in current dir
sm ccr                    # Reattach to a CC session (interactive picker)
sm cck                    # Kill latest CC session in current dir
sm ccka                   # Kill all CC sessions in current dir
```

## Global Flags

All commands accept:

| Flag | Description |
|------|-------------|
| `--no_conda` | Skip conda/venv auto-activation |
| `-V`, `--version` | Show version |
| `--help` | Show help |
