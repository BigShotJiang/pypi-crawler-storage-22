"""Setup script for smriti package.

Uses setuptools_scm to determine version from git tags.
Following the vajra pattern for version handling.
"""

import os
from datetime import datetime

from setuptools import setup
from setuptools_scm import get_version


def get_smriti_version() -> str:
    """Get version string, handling release and nightly builds for PyPI compatibility."""
    version = get_version(
        write_to="src/smriti/_version.py",
    )

    is_nightly_build = os.getenv("IS_NIGHTLY_BUILD", "false") == "true"

    if is_nightly_build:
        base = version.split(".dev")[0] if ".dev" in version else version.split("+")[0]
        version = f"{base}.dev{datetime.now().strftime('%Y%m%d%H')}"
    else:
        if ".dev" in version:
            version = version.split(".dev")[0]
        elif "+" in version:
            version = version.split("+")[0]

    return version


setup(
    version=get_smriti_version(),
)
