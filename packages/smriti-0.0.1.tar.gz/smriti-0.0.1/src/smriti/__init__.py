"""Smriti - Smart Screen Session Manager.

Sessions that remember where you were.
"""

try:
    from smriti._version import version as __version__
except ImportError:
    __version__ = "0.0.0.dev0"

__author__ = "Amey Agrawal"
__email__ = "ameyag@gatech.edu"
