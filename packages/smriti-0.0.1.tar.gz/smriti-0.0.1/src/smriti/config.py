"""Smriti configuration.

Uses Vidhi's BaseCommand for subcommand-based CLI with per-command flags.
"""

from vidhi import BaseCommand, field, frozen_dataclass

APP_NAME = "smriti"

# --- Conda/Venv Detection Paths (priority order) ---
ENV_SEARCH_DIRS = [
    "env",
    ".env",
    "venv",
    ".venv",
    "conda_env",
    ".conda_env",
    "conda",
    ".conda",
    "environment",
]

CONDA_YAML_FILES = [
    "environment.yml",
    "environment.yaml",
    "conda.yml",
    "conda.yaml",
]

ENV_META_FILES = [
    ".conda_env",
    ".conda-env",
    ".python-version",
]

# Max dirname length in session names
MAX_DIRNAME_LEN = 30

# Screen session states (as reported by `screen -ls`)
STATE_ATTACHED = "Attached"
STATE_DETACHED = "Detached"

# Default session tag when none specified
DEFAULT_TAG = "session"

# Claude Code session tag
CC_TAG = "cc"


# --- Colors ---
class Color:
    RED = "\033[0;31m"
    GREEN = "\033[0;32m"
    YELLOW = "\033[1;33m"
    BLUE = "\033[0;34m"
    CYAN = "\033[0;36m"
    MAGENTA = "\033[0;35m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    NC = "\033[0m"


# --- Subcommands ---


@frozen_dataclass
class SmritiCommand(BaseCommand):
    """Smriti — Smart Screen Session Manager"""

    no_conda: bool = field(False, help="Skip conda/venv auto-activation")


@frozen_dataclass
class Create(SmritiCommand, name="create", alias="c", default=True):
    """Create a new screen session"""

    tag: str = field("session", help="Session tag (e.g., dev, debug, train)")
    verbose: bool = field(False, help="Verbose output", name="v")


@frozen_dataclass
class Auto(SmritiCommand, name="auto", alias="a"):
    """Auto-connect to latest session globally, or create if none"""

    target: str | None = field(None, help="Session name or substring to match")


@frozen_dataclass
class AutoDir(SmritiCommand, name="auto-dir", alias="ad"):
    """Auto-connect to latest session in current directory, or create if none"""


@frozen_dataclass
class Reattach(SmritiCommand, name="reattach", alias="r"):
    """List all sessions and pick one to reattach"""


@frozen_dataclass
class ListAll(SmritiCommand, name="list", alias="l"):
    """List all sessions"""


@frozen_dataclass
class ListDir(SmritiCommand, name="list-dir", alias="ld"):
    """List sessions in current directory"""


@frozen_dataclass
class Kill(SmritiCommand, name="kill", alias="k"):
    """Kill latest session in current directory"""


@frozen_dataclass
class KillAll(SmritiCommand, name="kill-all", alias="ka"):
    """Kill all sessions in current directory"""


@frozen_dataclass
class KillLatest(SmritiCommand, name="kill-latest", alias="kl"):
    """Kill latest session (any directory)"""


@frozen_dataclass
class Claude(SmritiCommand, name="claude", alias="cc"):
    """Launch Claude Code in a session"""

    args: str | None = field(None, help="Extra args for Claude Code (quoted string)")
    config_dir: str | None = field(
        None, help="Claude Code config dir (sets CLAUDE_CONFIG_DIR, e.g. ~/.sclaude)"
    )


@frozen_dataclass
class ClaudeAuto(SmritiCommand, name="claude-auto", alias="cca"):
    """Auto-connect to latest Claude Code session globally, or create if none"""

    config_dir: str | None = field(None, help="Claude Code config dir")


@frozen_dataclass
class ClaudeAutoDir(SmritiCommand, name="claude-auto-dir", alias="ccad"):
    """Auto-connect to latest Claude Code session in current directory, or create if none"""

    config_dir: str | None = field(None, help="Claude Code config dir")


@frozen_dataclass
class ClaudeReattach(SmritiCommand, name="claude-reattach", alias="ccr"):
    """List all Claude Code sessions and pick one to reattach"""


@frozen_dataclass
class ClaudeList(SmritiCommand, name="claude-list", alias="ccl"):
    """List all Claude Code sessions"""


@frozen_dataclass
class ClaudeListDir(SmritiCommand, name="claude-list-dir", alias="ccld"):
    """List Claude Code sessions in current directory"""


@frozen_dataclass
class ClaudeKill(SmritiCommand, name="claude-kill", alias="cck"):
    """Kill latest Claude Code session in current directory"""


@frozen_dataclass
class ClaudeKillAll(SmritiCommand, name="claude-kill-all", alias="ccka"):
    """Kill all Claude Code sessions in current directory"""


@frozen_dataclass
class Env(SmritiCommand, name="env", alias="e"):
    """Show detected environment info"""
