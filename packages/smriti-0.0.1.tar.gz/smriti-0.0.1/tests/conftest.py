"""Shared test fixtures."""

import pytest


@pytest.fixture
def fake_venv(tmp_path):
    """Create a fake venv directory structure."""
    env_dir = tmp_path / "env"
    bin_dir = env_dir / "bin"
    bin_dir.mkdir(parents=True)
    (bin_dir / "python").touch()
    (bin_dir / "activate").touch()
    return tmp_path


@pytest.fixture
def fake_conda_prefix(tmp_path):
    """Create a fake local conda env directory structure."""
    env_dir = tmp_path / ".env"
    bin_dir = env_dir / "bin"
    bin_dir.mkdir(parents=True)
    (bin_dir / "python").touch()
    conda_meta = env_dir / "conda-meta"
    conda_meta.mkdir()
    (conda_meta / "history").touch()
    return tmp_path


@pytest.fixture
def fake_yaml_env(tmp_path):
    """Create a directory with environment.yml."""
    yaml_file = tmp_path / "environment.yml"
    yaml_file.write_text("name: test-env\ndependencies:\n  - python=3.11\n")
    return tmp_path


@pytest.fixture
def empty_dir(tmp_path):
    """An empty temporary directory."""
    return tmp_path
