"""Tests for env_detect module."""

from smriti.env_detect import (
    DetectedEnv,
    EnvType,
    _parse_yaml_env_name,
    detect_env,
    get_activate_command,
)


def test_detect_venv(fake_venv, monkeypatch):
    """Detect a standard venv directory."""
    monkeypatch.chdir(fake_venv)
    result = detect_env()
    assert result is not None
    assert result.env_type == EnvType.VENV
    assert result.source == "env/"


def test_detect_conda_prefix(fake_conda_prefix, monkeypatch):
    """Detect a local conda env with conda-meta/."""
    monkeypatch.chdir(fake_conda_prefix)
    result = detect_env()
    assert result is not None
    assert result.env_type == EnvType.CONDA_PREFIX
    assert result.source == ".env/"


def test_no_env(empty_dir, monkeypatch):
    """Empty directory should return None."""
    monkeypatch.chdir(empty_dir)
    result = detect_env()
    assert result is None


def test_nx_no_conda_legacy(fake_venv, monkeypatch):
    """NX_NO_CONDA=1 should skip detection."""
    monkeypatch.chdir(fake_venv)
    monkeypatch.setenv("NX_NO_CONDA", "1")
    result = detect_env()
    assert result is None


def test_venv_activate_command():
    """Venv activation should use source bin/activate."""
    env = DetectedEnv(
        env_type=EnvType.VENV,
        path_or_name="/home/user/project/env",
        source="env/",
    )
    cmd = get_activate_command(env)
    assert cmd == "source /home/user/project/env/bin/activate"


def test_conda_yaml_missing_command():
    """Missing conda env should produce a warning echo."""
    env = DetectedEnv(
        env_type=EnvType.CONDA_YAML_MISSING,
        path_or_name="myenv",
        source="environment.yml",
        yaml_file="environment.yml",
    )
    cmd = get_activate_command(env)
    assert "not installed" in cmd
    assert "environment.yml" in cmd


def test_parse_yaml_env_name(tmp_path):
    """Parse name from environment.yml."""
    yaml_file = tmp_path / "environment.yml"
    yaml_file.write_text("name: vajra-env\ndependencies:\n  - python=3.11\n")
    assert _parse_yaml_env_name(str(yaml_file)) == "vajra-env"


def test_parse_yaml_env_name_quoted(tmp_path):
    """Parse name with quotes."""
    yaml_file = tmp_path / "environment.yml"
    yaml_file.write_text("name: 'my-env'\n")
    assert _parse_yaml_env_name(str(yaml_file)) == "my-env"


def test_parse_yaml_env_name_missing(tmp_path):
    """Return None when no name field."""
    yaml_file = tmp_path / "environment.yml"
    yaml_file.write_text("dependencies:\n  - python=3.11\n")
    assert _parse_yaml_env_name(str(yaml_file)) is None


def test_parse_yaml_env_name_nonexistent():
    """Return None for nonexistent file."""
    assert _parse_yaml_env_name("/nonexistent/file.yml") is None


def test_conda_prefix_priority_over_venv(tmp_path, monkeypatch):
    """If both env/ (venv) and .env/ (conda) exist, first match wins by search order."""
    # env/ is first in ENV_SEARCH_DIRS
    env_dir = tmp_path / "env"
    bin_dir = env_dir / "bin"
    bin_dir.mkdir(parents=True)
    (bin_dir / "python").touch()
    (bin_dir / "activate").touch()

    # .env/ with conda-meta
    dot_env = tmp_path / ".env"
    dot_bin = dot_env / "bin"
    dot_bin.mkdir(parents=True)
    (dot_bin / "python").touch()
    (dot_env / "conda-meta").mkdir()
    (dot_env / "conda-meta" / "history").touch()

    monkeypatch.chdir(tmp_path)
    result = detect_env()
    assert result is not None
    # env/ is checked first, it's a venv (no conda-meta)
    assert result.env_type == EnvType.VENV
    assert result.source == "env/"
