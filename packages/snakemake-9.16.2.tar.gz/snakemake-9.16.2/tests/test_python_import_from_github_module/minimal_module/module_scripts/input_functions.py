def input_function_module(wildcards):
    return 'results/input.txt'