# snaprender

Official Python SDK for the [SnapRender](https://snap-render.com) Screenshot API.

## Install

```bash
pip install snaprender
```

## Quick Start

```python
from snaprender import SnapRender

snap = SnapRender(api_key="sk_live_...")

# Capture a screenshot
image = snap.capture("https://example.com")
with open("screenshot.png", "wb") as f:
    f.write(image)

# Capture with options
jpg = snap.capture(
    "https://example.com",
    format="jpeg",
    width=1920,
    height=1080,
    full_page=True,
    dark_mode=True,
    quality=95,
)

# Check cache status
info = snap.info("https://example.com")
print(info["cached"])  # True/False

# Get usage
usage = snap.usage()
print(f"{usage['used']}/{usage['limit']} screenshots used")
```

## Context Manager

```python
with SnapRender(api_key="sk_live_...") as snap:
    image = snap.capture("https://example.com")
```

## Error Handling

```python
from snaprender import SnapRender, SnapRenderError

snap = SnapRender(api_key="sk_live_...")

try:
    snap.capture("https://example.com")
except SnapRenderError as e:
    print(e.code)    # "QUOTA_EXCEEDED"
    print(e.status)  # 429
    print(e)         # "Monthly quota exceeded"
```

## API

### `SnapRender(api_key, base_url="https://app.snap-render.com", timeout=60.0)`

### `snap.capture(url, **options)` -> `bytes`

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `url` | str | — | URL to capture (required) |
| `format` | str | `"png"` | `"png"`, `"jpeg"`, `"webp"`, or `"pdf"` |
| `width` | int | `1280` | Viewport width |
| `height` | int | `800` | Viewport height |
| `full_page` | bool | `False` | Capture full scrollable page |
| `quality` | int | `90` | JPEG/WebP quality (1-100) |
| `delay` | int | `0` | Wait ms after page load |
| `dark_mode` | bool | `False` | Emulate dark mode |
| `block_ads` | bool | `True` | Block ad networks |
| `block_cookie_banners` | bool | `True` | Remove cookie banners |
| `device` | str | — | Device preset (e.g. `"iPhone 15"`) |
| `cache` | bool | `True` | Use cache |
| `cache_ttl` | int | `86400` | Cache TTL in seconds |

### `snap.info(url)` -> `dict`
### `snap.usage()` -> `dict`
### `snap.usage_daily(days=30)` -> `dict`
