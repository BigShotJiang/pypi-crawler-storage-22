"""SnapRender API client."""

from __future__ import annotations

from typing import Any, Optional

import httpx


class SnapRenderError(Exception):
    """Error returned by the SnapRender API."""

    def __init__(self, message: str, code: str = "UNKNOWN", status: int = 0):
        super().__init__(message)
        self.code = code
        self.status = status


class SnapRender:
    """SnapRender Screenshot API client.

    Usage::

        snap = SnapRender(api_key="sk_live_...")
        image = snap.capture("https://example.com")
        with open("screenshot.png", "wb") as f:
            f.write(image)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://app.snap-render.com",
        timeout: float = 60.0,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )

    def capture(
        self,
        url: str,
        *,
        format: str = "png",
        width: Optional[int] = None,
        height: Optional[int] = None,
        full_page: Optional[bool] = None,
        quality: Optional[int] = None,
        delay: Optional[int] = None,
        dark_mode: Optional[bool] = None,
        block_ads: Optional[bool] = None,
        block_cookie_banners: Optional[bool] = None,
        hide_selectors: Optional[str] = None,
        click_selector: Optional[str] = None,
        device: Optional[str] = None,
        user_agent: Optional[str] = None,
        cache: Optional[bool] = None,
        cache_ttl: Optional[int] = None,
    ) -> bytes:
        """Capture a screenshot and return the image bytes."""
        params: dict[str, Any] = {"url": url, "format": format}
        if width is not None:
            params["width"] = width
        if height is not None:
            params["height"] = height
        if full_page is not None:
            params["full_page"] = str(full_page).lower()
        if quality is not None:
            params["quality"] = quality
        if delay is not None:
            params["delay"] = delay
        if dark_mode is not None:
            params["dark_mode"] = str(dark_mode).lower()
        if block_ads is not None:
            params["block_ads"] = str(block_ads).lower()
        if block_cookie_banners is not None:
            params["block_cookie_banners"] = str(block_cookie_banners).lower()
        if hide_selectors is not None:
            params["hide_selectors"] = hide_selectors
        if click_selector is not None:
            params["click_selector"] = click_selector
        if device is not None:
            params["device"] = device
        if user_agent is not None:
            params["user_agent"] = user_agent
        if cache is not None:
            params["cache"] = str(cache).lower()
        if cache_ttl is not None:
            params["cache_ttl"] = cache_ttl

        resp = self._client.get("/v1/screenshot", params=params)
        if resp.status_code != 200:
            self._raise_error(resp)
        return resp.content

    def info(self, url: str, **kwargs: Any) -> dict[str, Any]:
        """Get cache info for a URL without capturing."""
        params: dict[str, Any] = {"url": url, **kwargs}
        resp = self._client.get("/v1/screenshot/info", params=params)
        if resp.status_code != 200:
            self._raise_error(resp)
        return resp.json()

    def usage(self) -> dict[str, Any]:
        """Get current month's usage."""
        resp = self._client.get("/v1/usage")
        if resp.status_code != 200:
            self._raise_error(resp)
        return resp.json()

    def usage_daily(self, days: int = 30) -> dict[str, Any]:
        """Get daily usage breakdown."""
        resp = self._client.get("/v1/usage/daily", params={"days": days})
        if resp.status_code != 200:
            self._raise_error(resp)
        return resp.json()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> SnapRender:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    @staticmethod
    def _raise_error(resp: httpx.Response) -> None:
        try:
            body = resp.json()
            err = body.get("error", {})
            raise SnapRenderError(
                err.get("message", f"HTTP {resp.status_code}"),
                err.get("code", "UNKNOWN"),
                resp.status_code,
            )
        except (ValueError, KeyError):
            raise SnapRenderError(f"HTTP {resp.status_code}", "UNKNOWN", resp.status_code)
