"""
SnapVision - A Windows-first, local-only, terminal-installed vision assistant.

Captures screen regions, performs OCR, and uses LLMs for text processing.
"""

__version__ = "0.1.0"
__author__ = "SnapVision"
