"""Manager tests."""
