# This file is generated from OpenAPI and not meant to be manually edited.
from typing import Any, Dict

from snorkelai.sdk.client_v3.ctx import SnorkelSDKContext

from ..models import (
    ActivityEventResponse,
    CreateActivityEventParams,
)


def create_activity_event_activity_events_post(
    *,
    body: CreateActivityEventParams,
) -> ActivityEventResponse:
    # Get the context
    ctx = SnorkelSDKContext.get_global()

    _kwargs: Dict[str, Any] = {
        "endpoint": "/activity-events",
    }

    _body = body.to_dict()

    _kwargs["json"] = _body

    # Call the TDM endpoint
    response = ctx.tdm_client.post(**_kwargs)

    # Parse and return the response
    def _parse_response(response: Any) -> ActivityEventResponse:
        """Parse response based on OpenAPI schema."""
        # Parse the success response
        # Parse as ActivityEventResponse
        response_201 = ActivityEventResponse.from_dict(response)

        return response_201

    return _parse_response(response)
