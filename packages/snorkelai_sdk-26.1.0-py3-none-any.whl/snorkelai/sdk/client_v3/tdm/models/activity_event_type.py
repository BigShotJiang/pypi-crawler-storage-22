import sys

if sys.version_info >= (3, 11):
    from enum import StrEnum
else:
    from backports.strenum import StrEnum


class ActivityEventType(StrEnum):
    END = "END"
    ERROR = "ERROR"
    PAUSED = "PAUSED"
    RESUMED = "RESUMED"
    START = "START"
