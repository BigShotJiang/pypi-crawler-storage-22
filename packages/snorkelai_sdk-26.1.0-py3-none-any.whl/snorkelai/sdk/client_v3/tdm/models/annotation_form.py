from typing import (
    Any,
    Dict,
    List,
    Type,
    TypeVar,
    Union,
    cast,
)

import attrs

from ..types import UNSET, Unset

T = TypeVar("T", bound="AnnotationForm")


@attrs.define
class AnnotationForm:
    """
    Attributes:
        individual_label_schemas (Union[Unset, List[int]]): List of label_schema_uids included in the annotation form
    """

    individual_label_schemas: Union[Unset, List[int]] = UNSET
    additional_properties: Dict[str, Any] = attrs.field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        individual_label_schemas: Union[Unset, List[int]] = UNSET
        if not isinstance(self.individual_label_schemas, Unset):
            individual_label_schemas = self.individual_label_schemas

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if individual_label_schemas is not UNSET:
            field_dict["individual_label_schemas"] = individual_label_schemas

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _individual_label_schemas = d.pop("individual_label_schemas", UNSET)
        individual_label_schemas = cast(
            List[int],
            UNSET if _individual_label_schemas is None else _individual_label_schemas,
        )

        obj = cls(
            individual_label_schemas=individual_label_schemas,
        )
        obj.additional_properties = d
        return obj

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
