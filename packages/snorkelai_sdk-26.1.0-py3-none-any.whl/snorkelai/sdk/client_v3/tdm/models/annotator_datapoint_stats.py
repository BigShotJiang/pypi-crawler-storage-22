from typing import (
    Any,
    Dict,
    List,
    Type,
    TypeVar,
)

import attrs

from ..models.activity_event_name import ActivityEventName

T = TypeVar("T", bound="AnnotatorDatapointStats")


@attrs.define
class AnnotatorDatapointStats:
    """Stats for a single datapoint annotated by a user.

    Attributes:
        datapoint_uid (str):
        event_name (ActivityEventName): Valid event names for activity events.

            This enum is used for API validation only. The database stores event_name
            as a VARCHAR, so adding new values here does NOT require a database migration.
        total_time_seconds (float):
        user_uid (int):
    """

    datapoint_uid: str
    event_name: ActivityEventName
    total_time_seconds: float
    user_uid: int
    additional_properties: Dict[str, Any] = attrs.field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        datapoint_uid = self.datapoint_uid
        event_name = self.event_name.value
        total_time_seconds = self.total_time_seconds
        user_uid = self.user_uid

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "datapoint_uid": datapoint_uid,
                "event_name": event_name,
                "total_time_seconds": total_time_seconds,
                "user_uid": user_uid,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        datapoint_uid = d.pop("datapoint_uid")

        event_name = ActivityEventName(d.pop("event_name"))

        total_time_seconds = d.pop("total_time_seconds")

        user_uid = d.pop("user_uid")

        obj = cls(
            datapoint_uid=datapoint_uid,
            event_name=event_name,
            total_time_seconds=total_time_seconds,
            user_uid=user_uid,
        )
        obj.additional_properties = d
        return obj

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
