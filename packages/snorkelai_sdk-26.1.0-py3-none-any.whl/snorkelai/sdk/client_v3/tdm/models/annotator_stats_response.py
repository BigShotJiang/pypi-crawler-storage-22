from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Type,
    TypeVar,
)

import attrs

if TYPE_CHECKING:
    # fmt: off
    from ..models.annotator_datapoint_stats import AnnotatorDatapointStats  # noqa: F401
    # fmt: on


T = TypeVar("T", bound="AnnotatorStatsResponse")


@attrs.define
class AnnotatorStatsResponse:
    """Response containing aggregated annotator stats for a task.

    Attributes:
        annotation_task_uid (int):
        stats (List['AnnotatorDatapointStats']):
    """

    annotation_task_uid: int
    stats: List["AnnotatorDatapointStats"]
    additional_properties: Dict[str, Any] = attrs.field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        # fmt: off
        from ..models.annotator_datapoint_stats import (
            AnnotatorDatapointStats,  # noqa: F401
        )
        # fmt: on
        annotation_task_uid = self.annotation_task_uid
        stats = []
        for stats_item_data in self.stats:
            stats_item = stats_item_data.to_dict()
            stats.append(stats_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "annotation_task_uid": annotation_task_uid,
                "stats": stats,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        # fmt: off
        from ..models.annotator_datapoint_stats import (
            AnnotatorDatapointStats,  # noqa: F401
        )
        # fmt: on
        d = src_dict.copy()
        annotation_task_uid = d.pop("annotation_task_uid")

        stats = []
        _stats = d.pop("stats")
        for stats_item_data in _stats:
            stats_item = AnnotatorDatapointStats.from_dict(stats_item_data)

            stats.append(stats_item)

        obj = cls(
            annotation_task_uid=annotation_task_uid,
            stats=stats,
        )
        obj.additional_properties = d
        return obj

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
