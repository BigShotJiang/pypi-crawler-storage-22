from typing import (
    Any,
    Dict,
    List,
    Type,
    TypeVar,
    Union,
    cast,
)

import attrs

from ..types import UNSET, Unset

T = TypeVar("T", bound="BulkCommitAnnotationTaskResponse")


@attrs.define
class BulkCommitAnnotationTaskResponse:
    """Response model for bulk commit annotation task.

    Attributes:
        committed_x_uids (List[str]): List of x_uids that were successfully committed to ground truth
        skipped_x_uids (Union[Unset, List[str]]): List of x_uids that were skipped due to validation errors
    """

    committed_x_uids: List[str]
    skipped_x_uids: Union[Unset, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attrs.field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        committed_x_uids = self.committed_x_uids

        skipped_x_uids: Union[Unset, List[str]] = UNSET
        if not isinstance(self.skipped_x_uids, Unset):
            skipped_x_uids = self.skipped_x_uids

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "committed_x_uids": committed_x_uids,
            }
        )
        if skipped_x_uids is not UNSET:
            field_dict["skipped_x_uids"] = skipped_x_uids

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        committed_x_uids = cast(List[str], d.pop("committed_x_uids"))

        _skipped_x_uids = d.pop("skipped_x_uids", UNSET)
        skipped_x_uids = cast(
            List[str], UNSET if _skipped_x_uids is None else _skipped_x_uids
        )

        obj = cls(
            committed_x_uids=committed_x_uids,
            skipped_x_uids=skipped_x_uids,
        )
        obj.additional_properties = d
        return obj

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
