import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Type,
    TypeVar,
    Union,
)

import attrs
from dateutil.parser import isoparse

from ..models.activity_event_name import ActivityEventName
from ..models.activity_event_type import ActivityEventType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    # fmt: off
    from ..models.create_activity_event_params_event_metadata import (
        CreateActivityEventParamsEventMetadata,  # noqa: F401
    )
    # fmt: on


T = TypeVar("T", bound="CreateActivityEventParams")


@attrs.define
class CreateActivityEventParams:
    """Parameters for creating an activity event.

    Attributes:
        event_name (ActivityEventName): Valid event names for activity events.

            This enum is used for API validation only. The database stores event_name
            as a VARCHAR, so adding new values here does NOT require a database migration.
        event_type (ActivityEventType): Types of activity events that can be tracked.
        workspace_uid (int):
        annotation_task_uid (Union[Unset, int]):
        dataset_uid (Union[Unset, int]):
        event_metadata (Union[Unset, CreateActivityEventParamsEventMetadata]):
        event_timestamp (Union[Unset, datetime.datetime]):
        parent_event_uid (Union[Unset, int]):
        x_uid (Union[Unset, str]):
    """

    event_name: ActivityEventName
    event_type: ActivityEventType
    workspace_uid: int
    annotation_task_uid: Union[Unset, int] = UNSET
    dataset_uid: Union[Unset, int] = UNSET
    event_metadata: Union[Unset, "CreateActivityEventParamsEventMetadata"] = UNSET
    event_timestamp: Union[Unset, datetime.datetime] = UNSET
    parent_event_uid: Union[Unset, int] = UNSET
    x_uid: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attrs.field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        # fmt: off
        from ..models.create_activity_event_params_event_metadata import (
            CreateActivityEventParamsEventMetadata,  # noqa: F401
        )
        # fmt: on
        event_name = self.event_name.value
        event_type = self.event_type.value
        workspace_uid = self.workspace_uid
        annotation_task_uid = self.annotation_task_uid
        dataset_uid = self.dataset_uid
        event_metadata: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.event_metadata, Unset):
            event_metadata = self.event_metadata.to_dict()
        event_timestamp: Union[Unset, str] = UNSET
        if not isinstance(self.event_timestamp, Unset):
            event_timestamp = self.event_timestamp.isoformat()
        parent_event_uid = self.parent_event_uid
        x_uid = self.x_uid

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_name": event_name,
                "event_type": event_type,
                "workspace_uid": workspace_uid,
            }
        )
        if annotation_task_uid is not UNSET:
            field_dict["annotation_task_uid"] = annotation_task_uid
        if dataset_uid is not UNSET:
            field_dict["dataset_uid"] = dataset_uid
        if event_metadata is not UNSET:
            field_dict["event_metadata"] = event_metadata
        if event_timestamp is not UNSET:
            field_dict["event_timestamp"] = event_timestamp
        if parent_event_uid is not UNSET:
            field_dict["parent_event_uid"] = parent_event_uid
        if x_uid is not UNSET:
            field_dict["x_uid"] = x_uid

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        # fmt: off
        from ..models.create_activity_event_params_event_metadata import (
            CreateActivityEventParamsEventMetadata,  # noqa: F401
        )
        # fmt: on
        d = src_dict.copy()
        event_name = ActivityEventName(d.pop("event_name"))

        event_type = ActivityEventType(d.pop("event_type"))

        workspace_uid = d.pop("workspace_uid")

        _annotation_task_uid = d.pop("annotation_task_uid", UNSET)
        annotation_task_uid = (
            UNSET if _annotation_task_uid is None else _annotation_task_uid
        )

        _dataset_uid = d.pop("dataset_uid", UNSET)
        dataset_uid = UNSET if _dataset_uid is None else _dataset_uid

        _event_metadata = d.pop("event_metadata", UNSET)
        _event_metadata = UNSET if _event_metadata is None else _event_metadata
        event_metadata: Union[Unset, CreateActivityEventParamsEventMetadata]
        if isinstance(_event_metadata, Unset):
            event_metadata = UNSET
        else:
            event_metadata = CreateActivityEventParamsEventMetadata.from_dict(
                _event_metadata
            )

        _event_timestamp = d.pop("event_timestamp", UNSET)
        _event_timestamp = UNSET if _event_timestamp is None else _event_timestamp
        event_timestamp: Union[Unset, datetime.datetime]
        if isinstance(_event_timestamp, Unset):
            event_timestamp = UNSET
        else:
            event_timestamp = isoparse(_event_timestamp)

        _parent_event_uid = d.pop("parent_event_uid", UNSET)
        parent_event_uid = UNSET if _parent_event_uid is None else _parent_event_uid

        _x_uid = d.pop("x_uid", UNSET)
        x_uid = UNSET if _x_uid is None else _x_uid

        obj = cls(
            event_name=event_name,
            event_type=event_type,
            workspace_uid=workspace_uid,
            annotation_task_uid=annotation_task_uid,
            dataset_uid=dataset_uid,
            event_metadata=event_metadata,
            event_timestamp=event_timestamp,
            parent_event_uid=parent_event_uid,
            x_uid=x_uid,
        )
        obj.additional_properties = d
        return obj

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
