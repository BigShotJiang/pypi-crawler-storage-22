from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Type,
    TypeVar,
    Union,
    cast,
)

import attrs

from ..types import UNSET, Unset

if TYPE_CHECKING:
    # fmt: off
    from ..models.annotation_existing_question import (
        AnnotationExistingQuestion,  # noqa: F401
    )
    from ..models.annotation_new_question import AnnotationNewQuestion  # noqa: F401
    # fmt: on


T = TypeVar("T", bound="CreateAnnotationTaskParams")


@attrs.define
class CreateAnnotationTaskParams:
    """
    Attributes:
        name (str):
        allow_auto_commit (Union[Unset, bool]):  Default: False.
        allow_reassignment (Union[Unset, bool]):  Default: False.
        description (Union[Unset, str]):
        new_annotation_form (Union[Unset, List[Union['AnnotationExistingQuestion', 'AnnotationNewQuestion']]]):
        num_required_submission (Union[Unset, int]):
        user_visibility (Union[Unset, List[int]]):
    """

    name: str
    allow_auto_commit: Union[Unset, bool] = False
    allow_reassignment: Union[Unset, bool] = False
    description: Union[Unset, str] = UNSET
    new_annotation_form: Union[
        Unset, List[Union["AnnotationExistingQuestion", "AnnotationNewQuestion"]]
    ] = UNSET
    num_required_submission: Union[Unset, int] = UNSET
    user_visibility: Union[Unset, List[int]] = UNSET
    additional_properties: Dict[str, Any] = attrs.field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        # fmt: off
        from ..models.annotation_existing_question import (
            AnnotationExistingQuestion,  # noqa: F401
        )
        from ..models.annotation_new_question import AnnotationNewQuestion  # noqa: F401
        # fmt: on
        name = self.name
        allow_auto_commit = self.allow_auto_commit
        allow_reassignment = self.allow_reassignment
        description = self.description
        new_annotation_form: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.new_annotation_form, Unset):
            new_annotation_form = []
            for new_annotation_form_item_data in self.new_annotation_form:
                new_annotation_form_item: Dict[str, Any]
                if isinstance(
                    new_annotation_form_item_data, AnnotationExistingQuestion
                ):
                    new_annotation_form_item = new_annotation_form_item_data.to_dict()
                else:
                    new_annotation_form_item = new_annotation_form_item_data.to_dict()

                new_annotation_form.append(new_annotation_form_item)

        num_required_submission = self.num_required_submission
        user_visibility: Union[Unset, List[int]] = UNSET
        if not isinstance(self.user_visibility, Unset):
            user_visibility = self.user_visibility

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if allow_auto_commit is not UNSET:
            field_dict["allow_auto_commit"] = allow_auto_commit
        if allow_reassignment is not UNSET:
            field_dict["allow_reassignment"] = allow_reassignment
        if description is not UNSET:
            field_dict["description"] = description
        if new_annotation_form is not UNSET:
            field_dict["new_annotation_form"] = new_annotation_form
        if num_required_submission is not UNSET:
            field_dict["num_required_submission"] = num_required_submission
        if user_visibility is not UNSET:
            field_dict["user_visibility"] = user_visibility

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        # fmt: off
        from ..models.annotation_existing_question import (
            AnnotationExistingQuestion,  # noqa: F401
        )
        from ..models.annotation_new_question import AnnotationNewQuestion  # noqa: F401
        # fmt: on
        d = src_dict.copy()
        name = d.pop("name")

        _allow_auto_commit = d.pop("allow_auto_commit", UNSET)
        allow_auto_commit = UNSET if _allow_auto_commit is None else _allow_auto_commit

        _allow_reassignment = d.pop("allow_reassignment", UNSET)
        allow_reassignment = (
            UNSET if _allow_reassignment is None else _allow_reassignment
        )

        _description = d.pop("description", UNSET)
        description = UNSET if _description is None else _description

        _new_annotation_form = d.pop("new_annotation_form", UNSET)
        new_annotation_form = []
        _new_annotation_form = (
            UNSET if _new_annotation_form is None else _new_annotation_form
        )
        for new_annotation_form_item_data in _new_annotation_form or []:

            def _parse_new_annotation_form_item(
                data: object,
            ) -> Union["AnnotationExistingQuestion", "AnnotationNewQuestion"]:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    new_annotation_form_item_type_0 = (
                        AnnotationExistingQuestion.from_dict(data)
                    )

                    return new_annotation_form_item_type_0
                except:  # noqa: E722
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                new_annotation_form_item_type_1 = AnnotationNewQuestion.from_dict(data)

                return new_annotation_form_item_type_1

            new_annotation_form_item = _parse_new_annotation_form_item(
                new_annotation_form_item_data
            )

            new_annotation_form.append(new_annotation_form_item)

        _num_required_submission = d.pop("num_required_submission", UNSET)
        num_required_submission = (
            UNSET if _num_required_submission is None else _num_required_submission
        )

        _user_visibility = d.pop("user_visibility", UNSET)
        user_visibility = cast(
            List[int], UNSET if _user_visibility is None else _user_visibility
        )

        obj = cls(
            name=name,
            allow_auto_commit=allow_auto_commit,
            allow_reassignment=allow_reassignment,
            description=description,
            new_annotation_form=new_annotation_form,
            num_required_submission=num_required_submission,
            user_visibility=user_visibility,
        )
        obj.additional_properties = d
        return obj

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
