# Snowcap

## Snowflake infrastructure as code

### Coming Soon!

Snowcap helps you provision, deploy, and secure resources in Snowflake. It replaces tools like Terraform, Schemachange, or Permifrost.

## Features (Coming Soon)

- **Declarative** - Define your Snowflake resources in YAML or Python
- **Comprehensive** - Support for 50+ Snowflake resource types
- **Fast** - 50-90% faster than Terraform
- **No state file** - Snowcap compares config directly to Snowflake

## Installation

```bash
pip install snowcap
```

*Note: The full package is coming soon. This is a placeholder release.*

## Links

- **GitHub**: [https://github.com/datacoves/snowcap](https://github.com/datacoves/snowcap)
- **Datacoves**: [https://datacoves.com](https://datacoves.com)

## About

Brought to you by [Datacoves](https://datacoves.com) - a managed DataOps platform for dbt and Airflow.

## License

Apache 2.0
