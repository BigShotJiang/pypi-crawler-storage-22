"""
Snowcap: Snowflake infrastructure as code

Coming Soon!

Snowcap helps you provision, deploy, and secure resources in Snowflake.
It replaces tools like Terraform, Schemachange, or Permifrost.

For more information, visit: https://github.com/datacoves/snowcap

By Datacoves - https://datacoves.com
"""

__version__ = "0.0.1"
__author__ = "Datacoves"
__email__ = "info@datacoves.com"


def main():
    """Placeholder CLI entry point."""
    print("""
    Snowcap: Snowflake infrastructure as code

    Coming Soon!

    Snowcap helps you provision, deploy, and secure resources in Snowflake.

    For updates, visit: https://github.com/datacoves/snowcap

    By Datacoves - https://datacoves.com
    """)


if __name__ == "__main__":
    main()
