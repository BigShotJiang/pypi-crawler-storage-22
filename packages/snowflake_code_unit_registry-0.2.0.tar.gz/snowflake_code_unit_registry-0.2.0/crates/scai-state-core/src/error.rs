//! Error types for the SCAI state library

use thiserror::Error;

/// Main error type for SCAI state operations.
///
/// Each variant carries a stable numeric error code (see [`Error::error_code`])
/// so that callers in every language can programmatically handle errors without
/// parsing human-readable messages.
#[derive(Error, Debug)]
pub enum Error {
    #[error("Registry not found at path: {0}")]
    RegistryNotFound(String),

    #[error("Registry already exists at path: {0}")]
    RegistryAlreadyExists(String),

    #[error("Code unit not found: {0}")]
    CodeUnitNotFound(String),

    #[error("Code unit already exists: {0}")]
    CodeUnitAlreadyExists(String),

    #[error("Invalid state transition from {from} to {to}")]
    InvalidStateTransition { from: String, to: String },

    #[error("Lock acquisition failed: {0}")]
    LockError(String),

    #[error("Validation error: {0}")]
    ValidationError(String),

    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),

    #[error("JSON error: {0}")]
    JsonError(#[from] serde_json::Error),

    #[error("Invalid path: {0}")]
    InvalidPath(String),

    #[error("Filter error: {0}")]
    FilterError(String),
}

impl Error {
    /// Stable, cross-language error code.
    ///
    /// These codes are published so that Python, C#, and any future language
    /// bindings can expose the same numeric identifiers.
    ///
    /// | Code | Variant |
    /// |------|---------|
    /// | 1001 | RegistryNotFound |
    /// | 1002 | RegistryAlreadyExists |
    /// | 1003 | CodeUnitNotFound |
    /// | 1004 | CodeUnitAlreadyExists |
    /// | 1005 | InvalidStateTransition |
    /// | 1006 | LockError |
    /// | 1007 | ValidationError |
    /// | 1008 | IoError |
    /// | 1009 | JsonError |
    /// | 1010 | InvalidPath |
    /// | 1011 | FilterError |
    pub fn error_code(&self) -> i32 {
        match self {
            Error::RegistryNotFound(_) => 1001,
            Error::RegistryAlreadyExists(_) => 1002,
            Error::CodeUnitNotFound(_) => 1003,
            Error::CodeUnitAlreadyExists(_) => 1004,
            Error::InvalidStateTransition { .. } => 1005,
            Error::LockError(_) => 1006,
            Error::ValidationError(_) => 1007,
            Error::IoError(_) => 1008,
            Error::JsonError(_) => 1009,
            Error::InvalidPath(_) => 1010,
            Error::FilterError(_) => 1011,
        }
    }
}

/// Result type alias for SCAI state operations
pub type Result<T> = std::result::Result<T, Error>;

/// Result of a batch operation (create_batch, update_batch, update_where, upsert_batch)
#[derive(Debug, Clone)]
pub struct BatchResult {
    /// IDs of successfully processed items
    pub succeeded: Vec<String>,
    /// List of (id, error_code, error_message) for failed items
    // TODO: SNOW-3037585 [State Management] Implement standardized error codes across Rust, C# and Python.
    pub failed: Vec<(String, i32, String)>,
}

impl BatchResult {
    pub fn new() -> Self {
        Self {
            succeeded: Vec::new(),
            failed: Vec::new(),
        }
    }

    pub fn success(&mut self, id: String) {
        self.succeeded.push(id);
    }

    pub fn failure(&mut self, id: String, error: &Error) {
        self.failed
            .push((id, error.error_code(), error.to_string()));
    }

    pub fn total(&self) -> usize {
        self.succeeded.len() + self.failed.len()
    }
}

impl Default for BatchResult {
    fn default() -> Self {
        Self::new()
    }
}
