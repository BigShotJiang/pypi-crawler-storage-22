//! Identity helpers for code unit ID generation
//!
//! IDs are plain UUID v4 values (32 hex characters).

use uuid::Uuid;

/// Generate a new code unit ID.
///
/// Returns a 32-character lowercase hex string (UUID v4, no dashes).
pub fn generate_id() -> String {
    Uuid::new_v4().simple().to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_id() {
        let id = generate_id();
        assert_eq!(id.len(), 32);
        assert!(id.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn test_generate_id_unique() {
        let id1 = generate_id();
        let id2 = generate_id();
        assert_ne!(id1, id2);
    }
}
