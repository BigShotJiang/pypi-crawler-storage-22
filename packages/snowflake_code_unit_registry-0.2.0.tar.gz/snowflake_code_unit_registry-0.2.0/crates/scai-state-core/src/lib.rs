//! SCAI State Core Library
//!
//! This library provides file operations for managing code unit state using
//! typed structs generated from the JSON Schema.

pub mod error;
pub mod filter;
pub mod generated;
pub mod identity;
pub mod registry;

// Re-export generated types
pub use generated::types::*;

// Re-export core types
pub use error::BatchResult;
pub use error::Error;
pub use filter::Filter;
pub use registry::CodeUnitRegistry;
pub use registry::UNKNOWN_ID;

// Re-export identity helpers
pub use identity::generate_id;
