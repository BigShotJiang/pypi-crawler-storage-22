//! Python bindings for SCAI state management
//!
//! This crate provides Python bindings using the generated Rust types
//! from the JSON schema. Data crosses the FFI boundary as native Python
//! objects (dicts/lists) using the `pythonize` crate for direct
//! serde ↔ Python conversion – no JSON string intermediary.

use pyo3::create_exception;
use pyo3::prelude::*;
use pythonize::{depythonize, pythonize};
use scai_state_core::{CodeUnit, CodeUnitRegistry as RustRegistry};

// Custom exception with error_code attribute
create_exception!(scai_state, ScaiError, pyo3::exceptions::PyException);

/// Convert a core error into a Python ScaiError with error_code.
fn to_py_error(py: Python<'_>, e: scai_state_core::Error) -> PyErr {
    let err = PyErr::new::<ScaiError, _>(e.to_string());
    if let Ok(val) = err.value(py).getattr("__class__") {
        let _ = val; // keep class ref alive
    }
    // Set error_code on the exception value
    let _ = err.value(py).setattr("error_code", e.error_code());
    err
}

/// Python wrapper for CodeUnitRegistry
#[pyclass]
pub struct CodeUnitRegistry {
    inner: RustRegistry,
}

#[pymethods]
impl CodeUnitRegistry {
    /// Initialize a new registry at the given path
    #[staticmethod]
    fn init(py: Python<'_>, path: &str) -> PyResult<Self> {
        let inner = RustRegistry::init(path).map_err(|e| to_py_error(py, e))?;
        Ok(Self { inner })
    }

    /// Open an existing registry at the given path
    #[staticmethod]
    fn open(py: Python<'_>, path: &str) -> PyResult<Self> {
        let inner = RustRegistry::open(path).map_err(|e| to_py_error(py, e))?;
        Ok(Self { inner })
    }

    // ── Create ───────────────────────────────────────────────────────────

    /// Create a new code unit on disk. Returns the ID.
    fn create(&self, py: Python<'_>, code_unit: Bound<'_, PyAny>) -> PyResult<String> {
        let mut cu: CodeUnit = depythonize(&code_unit)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        self.inner.create(&mut cu).map_err(|e| to_py_error(py, e))
    }

    /// Batch create multiple code units efficiently.
    /// Returns a dict: {"succeeded": [id, ...], "failed": [[id, code, error], ...]}
    fn create_batch(&self, py: Python<'_>, batch: Bound<'_, PyAny>) -> PyResult<PyObject> {
        let mut batch: Vec<CodeUnit> = depythonize(&batch)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let result = self
            .inner
            .create_batch(&mut batch)
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    // ── Load / List ──────────────────────────────────────────────────────

    /// Load a code unit by ID. Returns CodeUnit as a Python dict.
    /// Get a code unit by ID. Returns a Python dict.
    #[pyo3(name = "get_by_id", signature = (id, include=None))]
    fn get_by_id(
        &self,
        py: Python<'_>,
        id: &str,
        include: Option<Vec<String>>,
    ) -> PyResult<PyObject> {
        let include_refs: Option<Vec<&str>> = include
            .as_ref()
            .map(|v| v.iter().map(|s| s.as_str()).collect());
        let doc = self
            .inner
            .get_by_id(id, include_refs.as_deref())
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &doc)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    /// Find all code units, optionally filtered by a SQL WHERE expression.
    /// Returns a Python list of dicts.
    #[pyo3(name = "find_all", signature = (filter=None, include=None))]
    fn find_all(
        &self,
        py: Python<'_>,
        filter: Option<&str>,
        include: Option<Vec<String>>,
    ) -> PyResult<PyObject> {
        let include_refs: Option<Vec<&str>> = include
            .as_ref()
            .map(|v| v.iter().map(|s| s.as_str()).collect());
        let docs = self
            .inner
            .find_all(filter, include_refs.as_deref())
            .map_err(|e| to_py_error(py, e))?;
        pythonize(py, &docs)
            .map(|b| b.unbind())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    // ── Update (PATCH) ───────────────────────────────────────────────────

    /// Update specific fields in a code unit by dot-notation paths.
    fn update(&self, py: Python<'_>, id: &str, updates: Bound<'_, PyAny>) -> PyResult<()> {
        let updates_map: serde_json::Map<String, serde_json::Value> = depythonize(&updates)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let updates_vec: Vec<(&str, serde_json::Value)> = updates_map
            .iter()
            .map(|(k, v)| (k.as_str(), v.clone()))
            .collect();
        self.inner
            .update(id, &updates_vec)
            .map_err(|e| to_py_error(py, e))
    }

    /// Update all code units matching a filter with the same updates.
    fn update_where(
        &self,
        py: Python<'_>,
        filter: &str,
        updates: Bound<'_, PyAny>,
    ) -> PyResult<PyObject> {
        let updates_map: serde_json::Map<String, serde_json::Value> = depythonize(&updates)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let updates_vec: Vec<(&str, serde_json::Value)> = updates_map
            .iter()
            .map(|(k, v)| (k.as_str(), v.clone()))
            .collect();
        let result = self
            .inner
            .update_where(filter, &updates_vec)
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    /// Batch update multiple code units efficiently.
    fn update_batch(&self, py: Python<'_>, batch: Bound<'_, PyAny>) -> PyResult<PyObject> {
        let batch_raw: Vec<(String, serde_json::Map<String, serde_json::Value>)> =
            depythonize(&batch)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let batch_vec: Vec<(&str, Vec<(&str, serde_json::Value)>)> = batch_raw
            .iter()
            .map(|(id, updates_map)| {
                let updates: Vec<(&str, serde_json::Value)> = updates_map
                    .iter()
                    .map(|(k, v)| (k.as_str(), v.clone()))
                    .collect();
                (id.as_str(), updates)
            })
            .collect();
        let result = self
            .inner
            .update_batch(&batch_vec)
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    // ── Upsert (merge) ──────────────────────────────────────────────────

    /// Create-or-merge a single code unit. Returns the ID.
    fn upsert(&self, py: Python<'_>, code_unit: Bound<'_, PyAny>) -> PyResult<String> {
        let mut cu: CodeUnit = depythonize(&code_unit)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        self.inner.upsert(&mut cu).map_err(|e| to_py_error(py, e))
    }

    /// Batch upsert multiple code units.
    fn upsert_batch(&self, py: Python<'_>, batch: Bound<'_, PyAny>) -> PyResult<PyObject> {
        let mut batch: Vec<CodeUnit> = depythonize(&batch)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;
        let result = self
            .inner
            .upsert_batch(&mut batch)
            .map_err(|e| to_py_error(py, e))?;
        batch_result_to_py(py, &result)
    }

    // ── Delete ───────────────────────────────────────────────────────────

    /// Delete a code unit by ID.
    fn delete(&self, py: Python<'_>, id: &str) -> PyResult<()> {
        self.inner.delete(id).map_err(|e| to_py_error(py, e))
    }
}

/// Generate a new code unit ID (32-character UUID v4).
#[pyfunction]
fn generate_id() -> String {
    scai_state_core::generate_id()
}

/// Convert a BatchResult into a Python dict.
fn batch_result_to_py(py: Python<'_>, result: &scai_state_core::BatchResult) -> PyResult<PyObject> {
    let failed: Vec<serde_json::Value> = result
        .failed
        .iter()
        .map(|(id, code, msg)| serde_json::json!([id, code, msg]))
        .collect();
    let value = serde_json::json!({
        "succeeded": result.succeeded,
        "failed": failed
    });
    pythonize(py, &value)
        .map(|b| b.unbind())
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
}

/// Python module definition
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<CodeUnitRegistry>()?;
    m.add_function(wrap_pyfunction!(generate_id, m)?)?;
    m.add("ScaiError", m.py().get_type::<ScaiError>())?;
    Ok(())
}
