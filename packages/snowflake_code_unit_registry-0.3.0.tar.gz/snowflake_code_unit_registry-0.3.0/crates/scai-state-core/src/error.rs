//! Error types for the SCAI state library

use err_code::ErrorCode;
use thiserror::Error;

/// Main error type for SCAI state operations.
///
/// Each variant carries a stable numeric error code via the `#[error_code]`
/// attribute. These codes are the cross-language contract shared with Python,
/// C#, and any future bindings.
///
/// Call [`Error::error_code()`] to obtain the numeric value.
#[derive(Error, ErrorCode, Debug)]
#[error_code(type = "u32")]
pub enum Error {
    #[error("Registry not found at path: {0}")]
    #[error_code(1001)]
    RegistryNotFound(String),

    #[error("Registry already exists at path: {0}")]
    #[error_code(1002)]
    RegistryAlreadyExists(String),

    #[error("Code unit not found: {0}")]
    #[error_code(1003)]
    CodeUnitNotFound(String),

    #[error("Code unit already exists: {0}")]
    #[error_code(1004)]
    CodeUnitAlreadyExists(String),

    #[error("Invalid state transition from {from} to {to}")]
    #[error_code(1005)]
    InvalidStateTransition { from: String, to: String },

    #[error("Lock acquisition failed: {0}")]
    #[error_code(1006)]
    LockError(String),

    #[error("Validation error: {0}")]
    #[error_code(1007)]
    ValidationError(String),

    #[error("IO error: {0}")]
    #[error_code(1008)]
    IoError(#[from] std::io::Error),

    #[error("JSON error: {0}")]
    #[error_code(1009)]
    JsonError(#[from] serde_json::Error),

    #[error("Invalid path: {0}")]
    #[error_code(1010)]
    InvalidPath(String),

    #[error("Filter error: {0}")]
    #[error_code(1011)]
    FilterError(String),
}

impl Error {
    /// Stable i32 error code for cross-language bindings.
    ///
    /// Delegates to the auto-generated `error_code() -> u32` and casts to
    /// `i32`, which is the type expected by C# and Python consumers.
    pub fn error_code_i32(&self) -> i32 {
        self.error_code() as i32
    }
}

/// Result type alias for SCAI state operations
pub type Result<T> = std::result::Result<T, Error>;

/// A single failure inside a [`BatchResult`].
#[derive(Debug, Clone)]
pub struct BatchFailure {
    pub id: String,
    pub error_code: i32,
    pub message: String,
}

/// Result of a batch operation (create_batch, update_batch, update_where, upsert_batch)
#[derive(Debug, Clone)]
pub struct BatchResult {
    /// IDs of successfully processed items
    pub succeeded: Vec<String>,
    /// Per-item failures with error code and message
    pub failed: Vec<BatchFailure>,
}

impl BatchResult {
    pub fn new() -> Self {
        Self {
            succeeded: Vec::new(),
            failed: Vec::new(),
        }
    }

    pub fn success(&mut self, id: String) {
        self.succeeded.push(id);
    }

    pub fn failure(&mut self, id: String, error: &Error) {
        self.failed.push(BatchFailure {
            id,
            error_code: error.error_code_i32(),
            message: error.to_string(),
        });
    }

    pub fn total(&self) -> usize {
        self.succeeded.len() + self.failed.len()
    }
}

impl Default for BatchResult {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::Error;

    #[test]
    fn error_codes_are_stable() {
        assert_eq!(
            Error::RegistryNotFound("/tmp/x".into()).error_code_i32(),
            1001
        );
        assert_eq!(Error::CodeUnitNotFound("abc".into()).error_code_i32(), 1003);
        assert_eq!(Error::FilterError("bad".into()).error_code_i32(), 1011);
    }

    #[test]
    fn batch_failure_captures_code_and_message() {
        let mut result = super::BatchResult::new();
        let err = Error::CodeUnitNotFound("abc".into());
        result.failure("id1".into(), &err);

        assert_eq!(result.failed.len(), 1);
        assert_eq!(result.failed[0].id, "id1");
        assert_eq!(result.failed[0].error_code, 1003);
        assert_eq!(result.failed[0].message, "Code unit not found: abc");
    }
}
