//! Auto-generated types from JSON Schema

pub mod types;
