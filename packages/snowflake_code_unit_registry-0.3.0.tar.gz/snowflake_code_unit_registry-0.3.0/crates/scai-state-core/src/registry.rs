//! Code Unit Registry – file operations for the code unit registry
//!
//! CodeUnit files are stored flat in `./registry/{id}.json` where id is a UUID v4.

use fs2::FileExt;
use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

use serde_json::Value;

use crate::error::{BatchResult, Error, Result};
use crate::filter::Filter;
use crate::generated::types::CodeUnit;

/// ID placeholder used in batch operations when a code unit has no ID.
pub const UNKNOWN_ID: &str = "unknown";

/// Convert dot-notation path to JSON Pointer (RFC 6901)
/// e.g., "source.name" -> "/source/name"
fn to_json_pointer(dot_path: &str) -> String {
    format!("/{}", dot_path.replace('.', "/"))
}

/// Set a value at a dot-notation path, creating intermediate objects as needed.
/// Returns Err if an intermediate segment exists but is not an object.
fn set_path(root: &mut Value, path: &str, val: Value) -> Result<()> {
    let parts: Vec<&str> = path.split('.').collect();
    let mut current = root;

    for part in &parts[..parts.len() - 1] {
        if !current.is_object() {
            return Err(Error::ValidationError(format!(
                "Cannot set path '{}': intermediate value is not an object",
                path
            )));
        }
        current = current
            .as_object_mut()
            .unwrap()
            .entry(*part)
            .or_insert_with(|| Value::Object(serde_json::Map::new()));
    }

    let leaf = parts.last().unwrap();
    match current.as_object_mut() {
        Some(obj) => {
            obj.insert(leaf.to_string(), val);
            Ok(())
        }
        None => Err(Error::ValidationError(format!(
            "Cannot set path '{}': parent is not an object",
            path
        ))),
    }
}

/// Project specified fields from a JSON value into a new object.
/// Supports nested paths like "source.name".
fn project_fields(value: &Value, fields: &[&str]) -> Result<Value> {
    let mut result = Value::Object(serde_json::Map::new());

    for field in fields {
        if let Some(v) = value.pointer(&to_json_pointer(field)) {
            set_path(&mut result, field, v.clone())?;
        }
    }

    Ok(result)
}

/// Check if all fields present in `partial` match the corresponding fields in `target`.
/// For objects, recurse into nested keys. For all other types, require exact equality.
fn matches_partial(partial: &Value, target: &Value) -> bool {
    match (partial, target) {
        (Value::Object(partial_map), Value::Object(target_map)) => {
            for (key, partial_val) in partial_map {
                match target_map.get(key) {
                    Some(target_val) => {
                        if !matches_partial(partial_val, target_val) {
                            return false;
                        }
                    }
                    None => return false,
                }
            }
            true
        }
        _ => partial == target,
    }
}

/// Deep-merge `patch` into `base`.
/// For objects, recursively merge keys. For all other types, `patch` wins.
fn deep_merge(base: &mut Value, patch: &Value) {
    match (base, patch) {
        (Value::Object(base_map), Value::Object(patch_map)) => {
            for (key, patch_val) in patch_map {
                let entry = base_map.entry(key.clone()).or_insert_with(|| Value::Null);
                deep_merge(entry, patch_val);
            }
        }
        (base, patch) => {
            *base = patch.clone();
        }
    }
}

/// Platform-appropriate line ending
#[cfg(windows)]
const LINE_ENDING: &str = "\r\n";
#[cfg(not(windows))]
const LINE_ENDING: &str = "\n";

/// Lock guard that releases the lock when dropped
pub struct LockGuard {
    _file: File,
}

impl LockGuard {
    fn new(file: File) -> Self {
        Self { _file: file }
    }
}

/// A code-unit registry backed by a directory of JSON files.
pub struct CodeUnitRegistry {
    /// Root path of the registry (contains registry/)
    root: PathBuf,
}

impl CodeUnitRegistry {
    /// Initialize a new registry at the given path.
    /// Creates the registry directory structure.
    pub fn init(path: impl AsRef<Path>) -> Result<Self> {
        let root = path.as_ref().to_path_buf();
        let registry_dir = root.join("registry");

        if registry_dir.exists() {
            return Err(Error::RegistryAlreadyExists(root.display().to_string()));
        }

        fs::create_dir_all(&registry_dir)?;
        fs::create_dir_all(registry_dir.join(".locks"))?;

        // Create .gitignore for lock files
        let gitignore = registry_dir.join(".gitignore");
        let gitignore_content = format!(".locks/{}", LINE_ENDING);
        fs::write(&gitignore, gitignore_content)?;

        Ok(Self { root })
    }

    /// Open an existing registry at the given path.
    pub fn open(path: impl AsRef<Path>) -> Result<Self> {
        let root = path.as_ref().to_path_buf();
        let registry_dir = root.join("registry");

        if !registry_dir.exists() {
            return Err(Error::RegistryNotFound(root.display().to_string()));
        }

        Ok(Self { root })
    }

    /// Get the root path of the registry
    pub fn root(&self) -> &Path {
        &self.root
    }

    /// Get the registry directory path
    fn registry_dir(&self) -> PathBuf {
        self.root.join("registry")
    }

    /// Acquire an exclusive lock for write operations.
    pub fn acquire_lock(&self) -> Result<LockGuard> {
        let lock_path = self.registry_dir().join(".locks").join("registry.lock");

        if let Some(parent) = lock_path.parent() {
            fs::create_dir_all(parent)?;
        }

        let file = File::create(&lock_path)?;
        file.lock_exclusive()
            .map_err(|e| Error::LockError(e.to_string()))?;

        Ok(LockGuard::new(file))
    }

    /// Compute file path from ID.
    /// Returns `registry/{id}.json`
    fn id_to_path(&self, id: &str) -> PathBuf {
        self.registry_dir().join(format!("{}.json", id))
    }

    // ── Create ───────────────────────────────────────────────────────────

    /// Create a new code unit on disk.
    /// If code_unit.id is None, generates a new ID.
    /// Returns the ID of the created code unit.
    /// Errors if the code unit already exists.
    pub fn create(&self, code_unit: &mut CodeUnit) -> Result<String> {
        let _lock = self.acquire_lock()?;
        let id = self.create_one(code_unit)?;
        self.sync()?;
        Ok(id)
    }

    /// Batch create multiple code units efficiently.
    /// All creates are written without sync, then a single sync at the end.
    /// If a code_unit.id is None, generates a new ID for it.
    /// Skips entries that fail (e.g., duplicate IDs) and continues with the rest.
    /// Returns BatchResult with succeeded IDs and list of failures.
    pub fn create_batch(&self, batch: &mut [CodeUnit]) -> Result<BatchResult> {
        let _lock = self.acquire_lock()?;
        let mut result = BatchResult::new();
        for code_unit in batch.iter_mut() {
            match self.create_one(code_unit) {
                Ok(id) => result.success(id),
                Err(e) => {
                    let id = code_unit
                        .id
                        .clone()
                        .unwrap_or_else(|| UNKNOWN_ID.to_string());
                    result.failure(id, &e);
                }
            }
        }
        self.sync()?;
        Ok(result)
    }

    /// Create helper (no lock, no sync).
    /// If code_unit.id is None, generates a new ID and sets it.
    /// Returns the ID of the created code unit.
    fn create_one(&self, code_unit: &mut CodeUnit) -> Result<String> {
        let id = match &code_unit.id {
            Some(id) => id.clone(),
            None => {
                let new_id = crate::generate_id();
                code_unit.id = Some(new_id.clone());
                new_id
            }
        };

        let file_path = self.id_to_path(&id);

        if file_path.exists() {
            return Err(Error::CodeUnitAlreadyExists(id));
        }

        self.write_json(&file_path, code_unit, false)?;
        Ok(id)
    }

    // ── Read ─────────────────────────────────────────────────────────────

    /// Load a code unit from disk by ID.
    pub fn get_by_id(&self, id: &str, fields: Option<&[&str]>) -> Result<CodeUnit> {
        let file_path = self.id_to_path(id);

        if !file_path.exists() {
            return Err(Error::CodeUnitNotFound(id.to_string()));
        }

        let code_unit = self.read_json(&file_path)?;
        match fields {
            Some(f) => {
                let json_value = serde_json::to_value(&code_unit)?;
                let projected = project_fields(&json_value, f)?;
                Ok(serde_json::from_value(projected)?)
            }
            None => Ok(code_unit),
        }
    }

    /// List code units, optionally filtered and with field projection.
    ///
    /// If `filter` is `None`, returns all code units.
    /// If `filter` is `Some`, only returns code units matching the expression.
    /// If `fields` is `Some`, returns only the specified fields.
    pub fn find_all(&self, filter: Option<&str>, fields: Option<&[&str]>) -> Result<Vec<CodeUnit>> {
        let parsed_filter = filter.map(Filter::parse).transpose()?;
        let predicate = move |json: &Value| parsed_filter.as_ref().is_none_or(|f| f.matches(json));
        self.find_where(predicate, fields)
    }

    /// Find code units matching all non-null fields of a partial code unit.
    ///
    /// `partial` is a JSON value representing a partial code unit – only the
    /// keys present in the object are compared. For nested objects, the
    /// comparison recurses: a stored code unit matches when every key in
    /// `partial` exists in the stored document and carries the same value.
    ///
    /// If `fields` is `Some`, only the specified fields are returned
    /// (field projection).
    pub fn find_by_object(
        &self,
        partial: &Value,
        fields: Option<&[&str]>,
    ) -> Result<Vec<CodeUnit>> {
        self.find_where(|json| matches_partial(partial, json), fields)
    }

    /// Internal: find code units matching a predicate, with optional field projection.
    fn find_where<F>(&self, predicate: F, fields: Option<&[&str]>) -> Result<Vec<CodeUnit>>
    where
        F: Fn(&Value) -> bool,
    {
        let registry_dir = self.registry_dir();

        if !registry_dir.exists() {
            return Ok(Vec::new());
        }

        let mut results = Vec::new();

        for entry in fs::read_dir(&registry_dir)? {
            let path = entry?.path();
            if path.extension().is_some_and(|e| e == "json") {
                match self.read_json(&path) {
                    Ok(code_unit) => {
                        let json_value = serde_json::to_value(&code_unit)?;
                        if predicate(&json_value) {
                            let doc: CodeUnit = match fields {
                                Some(fields) => {
                                    serde_json::from_value(project_fields(&json_value, fields)?)?
                                }
                                None => code_unit,
                            };
                            results.push(doc);
                        }
                    }
                    Err(e) => eprintln!("Warning: Failed to load {:?}: {}", path, e),
                }
            }
        }

        Ok(results)
    }

    // ── Update (PATCH) ───────────────────────────────────────────────────

    /// Update specific fields in a code unit by dot-notation paths.
    /// Always syncs to disk after the update.
    pub fn update(&self, id: &str, updates: &[(&str, Value)]) -> Result<()> {
        let _lock = self.acquire_lock()?;
        self.update_one(id, updates)?;
        self.sync()
    }

    /// Update all code units matching a filter with the same updates.
    /// Skips entries that fail and continues with the rest.
    /// Returns BatchResult with succeeded IDs and list of failures.
    pub fn update_where(&self, filter: &str, updates: &[(&str, Value)]) -> Result<BatchResult> {
        let _lock = self.acquire_lock()?;
        let matches = self.find_all(Some(filter), None)?;
        let mut result = BatchResult::new();

        for code_unit in &matches {
            if let Some(id) = &code_unit.id {
                match self.update_one(id, updates) {
                    Ok(()) => result.success(id.clone()),
                    Err(e) => result.failure(id.clone(), &e),
                }
            }
        }

        self.sync()?;
        Ok(result)
    }

    /// Batch update multiple code units efficiently.
    /// All updates are written to temp files first, then renamed, with a single sync at the end.
    /// Skips entries that fail (e.g., not found) and continues with the rest.
    /// Returns BatchResult with succeeded IDs and list of failures.
    pub fn update_batch(&self, batch: &[(&str, Vec<(&str, Value)>)]) -> Result<BatchResult> {
        let _lock = self.acquire_lock()?;
        let mut result = BatchResult::new();
        for (id, updates) in batch {
            match self.update_one(id, updates) {
                Ok(()) => result.success(id.to_string()),
                Err(e) => result.failure(id.to_string(), &e),
            }
        }
        self.sync()?;
        Ok(result)
    }

    /// Apply updates to a single code unit (no lock, no sync).
    fn update_one(&self, id: &str, updates: &[(&str, Value)]) -> Result<()> {
        let file_path = self.id_to_path(id);

        if !file_path.exists() {
            return Err(Error::CodeUnitNotFound(id.to_string()));
        }

        let code_unit = self.read_json(&file_path)?;
        let mut json_value = serde_json::to_value(&code_unit)?;

        for (path, value) in updates {
            set_path(&mut json_value, path, value.clone())?;
        }

        let updated: CodeUnit = serde_json::from_value(json_value)?;
        self.write_json(&file_path, &updated, false)?;
        Ok(())
    }

    // ── Upsert (merge) ──────────────────────────────────────────────────

    /// Create-or-merge a single code unit.
    ///
    /// * If the code unit does **not** exist on disk, it is created (like `create`).
    /// * If it **does** exist, the incoming fields are deep-merged into the
    ///   existing document – fields present in `code_unit` overwrite the
    ///   corresponding fields on disk, but fields **not** present in `code_unit`
    ///   (i.e. serialised as `None` / absent) are left untouched.
    ///
    /// Returns the ID of the upserted code unit.
    pub fn upsert(&self, code_unit: &mut CodeUnit) -> Result<String> {
        let _lock = self.acquire_lock()?;
        let id = self.upsert_one(code_unit)?;
        self.sync()?;
        Ok(id)
    }

    /// Batch upsert multiple code units.
    pub fn upsert_batch(&self, batch: &mut [CodeUnit]) -> Result<BatchResult> {
        let _lock = self.acquire_lock()?;
        let mut result = BatchResult::new();
        for code_unit in batch.iter_mut() {
            match self.upsert_one(code_unit) {
                Ok(id) => result.success(id),
                Err(e) => {
                    let id = code_unit
                        .id
                        .clone()
                        .unwrap_or_else(|| UNKNOWN_ID.to_string());
                    result.failure(id, &e);
                }
            }
        }
        self.sync()?;
        Ok(result)
    }

    /// Upsert helper (no lock, no sync).
    fn upsert_one(&self, code_unit: &mut CodeUnit) -> Result<String> {
        let id = match &code_unit.id {
            Some(id) => id.clone(),
            None => {
                let new_id = crate::generate_id();
                code_unit.id = Some(new_id.clone());
                new_id
            }
        };

        let file_path = self.id_to_path(&id);

        if file_path.exists() {
            // Merge: load existing, deep-merge incoming on top
            let existing = self.read_json(&file_path)?;
            let mut base_value = serde_json::to_value(&existing)?;
            let patch_value = serde_json::to_value(&*code_unit)?;
            deep_merge(&mut base_value, &patch_value);

            let merged: CodeUnit = serde_json::from_value(base_value)?;
            self.write_json(&file_path, &merged, false)?;
        } else {
            // Create
            self.write_json(&file_path, code_unit, false)?;
        }

        Ok(id)
    }

    // ── Delete ───────────────────────────────────────────────────────────

    /// Delete a code unit by ID.
    pub fn delete(&self, id: &str) -> Result<()> {
        let _lock = self.acquire_lock()?;
        let file_path = self.id_to_path(id);

        if !file_path.exists() {
            return Err(Error::CodeUnitNotFound(id.to_string()));
        }

        fs::remove_file(&file_path)?;
        self.sync()
    }

    // ── Internal helpers ─────────────────────────────────────────────────

    /// Sync all pending writes to disk (internal use only).
    fn sync(&self) -> Result<()> {
        let registry_dir = self.registry_dir();
        if registry_dir.exists() {
            let dir = File::open(&registry_dir)?;
            dir.sync_all()?;
        }
        Ok(())
    }

    /// Read JSON from file as CodeUnit
    fn read_json(&self, path: &Path) -> Result<CodeUnit> {
        let mut file = File::open(path)?;
        let mut contents = String::new();
        file.read_to_string(&mut contents)?;
        let doc: CodeUnit = serde_json::from_str(&contents)?;
        Ok(doc)
    }

    /// Write JSON to file atomically.
    /// If `sync` is true, ensures data is flushed to disk.
    fn write_json(&self, path: &Path, doc: &CodeUnit, sync: bool) -> Result<()> {
        let json = serde_json::to_string_pretty(doc)?;
        let temp_path = path.with_extension("json.tmp");
        {
            let mut file = File::create(&temp_path)?;
            file.write_all(json.as_bytes())?;
            file.write_all(LINE_ENDING.as_bytes())?;
            if sync {
                file.sync_all()?;
            }
        }
        fs::rename(&temp_path, path)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::generated::types::{
        Kind as CodeUnitKind, ObjectType as CodeUnitObjectType, SourceMetadata, TargetMetadata,
    };
    use std::env;

    fn temp_dir() -> PathBuf {
        let dir = env::temp_dir().join(format!("scai-test-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    fn make_code_unit(id: &str, name: &str, object_type: CodeUnitObjectType) -> CodeUnit {
        CodeUnit {
            id: Some(id.to_string()),
            kind: Some(CodeUnitKind::DatabaseObject),
            object_type: Some(object_type),
            source: Some(SourceMetadata {
                database: Some("DB".to_string()),
                schema: Some("dbo".to_string()),
                name: Some(name.to_string()),
                source_id: "primary".to_string(),
            }),
            target: Some(TargetMetadata {
                database: Some("DB".to_string()),
                schema: Some("DBO".to_string()),
                name: Some(name.to_uppercase()),
            }),
            schema_version: 1,
            is_missing: false,
            extensions: Default::default(),
            code_status: None,
            dependencies: None,
            files: None,
            issues: None,
            planning: None,
            signature: None,
            in_scope: true,
        }
    }

    #[test]
    fn test_init_registry() {
        let dir = temp_dir();
        let _registry = CodeUnitRegistry::init(&dir).unwrap();
        assert!(dir.join("registry").exists());
        assert!(dir.join("registry").join(".locks").exists());

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_open_registry() {
        let dir = temp_dir();
        let _registry = CodeUnitRegistry::init(&dir).unwrap();

        let registry2 = CodeUnitRegistry::open(&dir).unwrap();
        assert_eq!(registry2.root(), dir);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_id_to_path() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let id = "abcdef12-3456-7890-abcd-ef1234567890";
        let expected = dir.join("registry").join(format!("{}.json", id));
        assert_eq!(registry.id_to_path(id), expected);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_create_batch_success() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut batch = vec![
            make_code_unit("id1", "Table1", CodeUnitObjectType::Table),
            make_code_unit("id2", "Table2", CodeUnitObjectType::Table),
            make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure),
        ];

        let result = registry.create_batch(&mut batch).unwrap();
        assert_eq!(result.succeeded.len(), 3);
        assert!(result.succeeded.contains(&"id1".to_string()));
        assert!(result.succeeded.contains(&"id2".to_string()));
        assert!(result.succeeded.contains(&"id3".to_string()));
        assert_eq!(result.failed.len(), 0);
        assert_eq!(result.total(), 3);

        // Verify all were created
        let all = registry.find_all(None, None).unwrap();
        assert_eq!(all.len(), 3);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_create_batch_partial_failure_duplicate_ids() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);

        // First create one
        registry.create(&mut cu1).unwrap();

        // Now batch create with duplicate
        let mut batch = vec![
            make_code_unit("id1", "Table1", CodeUnitObjectType::Table), // duplicate - should fail
            make_code_unit("id2", "Table2", CodeUnitObjectType::Table), // new - should succeed
        ];

        let result = registry.create_batch(&mut batch).unwrap();
        assert_eq!(result.succeeded.len(), 1);
        assert!(result.succeeded.contains(&"id2".to_string()));
        assert_eq!(result.failed.len(), 1);
        assert_eq!(result.failed[0].id, "id1");
        assert_eq!(result.failed[0].error_code, 1004); // CodeUnitAlreadyExists
        assert!(result.failed[0].message.contains("already exists"));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_update_batch_success() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();

        let batch: Vec<(&str, Vec<(&str, Value)>)> = vec![
            (
                "id1",
                vec![("source.name", Value::String("UpdatedTable1".to_string()))],
            ),
            (
                "id2",
                vec![("source.name", Value::String("UpdatedTable2".to_string()))],
            ),
        ];

        let result = registry.update_batch(&batch).unwrap();
        assert_eq!(result.succeeded.len(), 2);
        assert!(result.succeeded.contains(&"id1".to_string()));
        assert!(result.succeeded.contains(&"id2".to_string()));
        assert_eq!(result.failed.len(), 0);

        // Verify updates
        let loaded1 = registry.get_by_id("id1", None).unwrap();
        assert_eq!(loaded1.source.unwrap().name.unwrap(), "UpdatedTable1");

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_update_batch_partial_failure_not_found() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        registry.create(&mut cu1).unwrap();

        let batch: Vec<(&str, Vec<(&str, Value)>)> = vec![
            (
                "id1",
                vec![("source.name", Value::String("Updated".to_string()))],
            ),
            (
                "nonexistent",
                vec![("source.name", Value::String("X".to_string()))],
            ),
        ];

        let result = registry.update_batch(&batch).unwrap();
        assert_eq!(result.succeeded.len(), 1);
        assert!(result.succeeded.contains(&"id1".to_string()));
        assert_eq!(result.failed.len(), 1);
        assert_eq!(result.failed[0].id, "nonexistent");
        assert_eq!(result.failed[0].error_code, 1003); // CodeUnitNotFound
        assert!(result.failed[0].message.contains("not found"));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_update_where_success() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
        let mut cu3 = make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure);

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();
        registry.create(&mut cu3).unwrap();

        let updates: Vec<(&str, Value)> =
            vec![("source.database", Value::String("NEWDB".to_string()))];

        let result = registry
            .update_where("objectType = 'table'", &updates)
            .unwrap();
        assert_eq!(result.succeeded.len(), 2);
        assert!(result.succeeded.contains(&"id1".to_string()));
        assert!(result.succeeded.contains(&"id2".to_string()));
        assert_eq!(result.failed.len(), 0);

        // Verify only tables were updated
        let loaded1 = registry.get_by_id("id1", None).unwrap();
        assert_eq!(loaded1.source.unwrap().database.unwrap(), "NEWDB");

        let loaded3 = registry.get_by_id("id3", None).unwrap();
        assert_eq!(loaded3.source.unwrap().database.unwrap(), "DB"); // unchanged

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_update_where_no_matches() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        registry.create(&mut cu1).unwrap();

        let updates: Vec<(&str, Value)> =
            vec![("source.database", Value::String("NEWDB".to_string()))];

        let result = registry
            .update_where("objectType = 'view'", &updates)
            .unwrap();
        assert_eq!(result.succeeded.len(), 0);
        assert_eq!(result.failed.len(), 0);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_batch_result_default() {
        let result = BatchResult::default();
        assert_eq!(result.succeeded.len(), 0);
        assert_eq!(result.failed.len(), 0);
        assert_eq!(result.total(), 0);
    }

    #[test]
    fn test_create_generates_id_when_missing() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu = CodeUnit {
            id: None,
            kind: Some(CodeUnitKind::DatabaseObject),
            object_type: Some(CodeUnitObjectType::Table),
            source: None,
            target: None,
            schema_version: 1,
            is_missing: false,
            extensions: Default::default(),
            code_status: None,
            dependencies: None,
            files: None,
            issues: None,
            planning: None,
            signature: None,
            in_scope: true,
        };

        let id = registry.create(&mut cu).unwrap();
        assert_eq!(id.len(), 36); // UUID v4 without dashes
        assert_eq!(cu.id, Some(id.clone())); // ID was set on the code unit

        // Verify it was created
        let loaded = registry.get_by_id(&id, None).unwrap();
        assert_eq!(loaded.id, Some(id));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_create_uses_existing_id() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu = make_code_unit("my_custom_id", "Table1", CodeUnitObjectType::Table);

        let id = registry.create(&mut cu).unwrap();
        assert_eq!(id, "my_custom_id");

        // Verify it was created with the provided ID
        let loaded = registry.get_by_id("my_custom_id", None).unwrap();
        assert_eq!(loaded.id, Some("my_custom_id".to_string()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_delete_syncs() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();
        let mut cu = make_code_unit("id_del", "T", CodeUnitObjectType::Table);
        registry.create(&mut cu).unwrap();

        registry.delete("id_del").unwrap();
        assert!(!registry.id_to_path("id_del").exists());

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_upsert_creates_new() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu = make_code_unit("upsert1", "Table1", CodeUnitObjectType::Table);
        let id = registry.upsert(&mut cu).unwrap();
        assert_eq!(id, "upsert1");

        let loaded = registry.get_by_id("upsert1", None).unwrap();
        assert_eq!(
            loaded.source.as_ref().unwrap().name.as_deref(),
            Some("Table1")
        );

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_upsert_merges_existing() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        // Create initial
        let mut cu = make_code_unit("upsert2", "Table1", CodeUnitObjectType::Table);
        registry.create(&mut cu).unwrap();

        // Upsert with updated source name but no target
        let mut patch = CodeUnit {
            id: Some("upsert2".to_string()),
            source: Some(SourceMetadata {
                name: Some("UpdatedTable1".to_string()),
                database: None,
                schema: None,
                source_id: "primary".to_string(),
            }),
            schema_version: 1,
            is_missing: false,
            extensions: Default::default(),
            kind: None,
            object_type: None,
            target: None,
            code_status: None,
            dependencies: None,
            files: None,
            issues: None,
            planning: None,
            signature: None,
            in_scope: true,
        };

        let id = registry.upsert(&mut patch).unwrap();
        assert_eq!(id, "upsert2");

        let loaded = registry.get_by_id("upsert2", None).unwrap();
        // Source name should be updated
        assert_eq!(
            loaded.source.as_ref().unwrap().name.as_deref(),
            Some("UpdatedTable1")
        );
        // Target should still be present from original create
        assert!(loaded.target.is_some());
        assert_eq!(
            loaded.target.as_ref().unwrap().name.as_deref(),
            Some("TABLE1")
        );

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_upsert_generates_id_when_missing() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu = CodeUnit {
            id: None,
            kind: Some(CodeUnitKind::DatabaseObject),
            object_type: Some(CodeUnitObjectType::Table),
            source: None,
            target: None,
            schema_version: 1,
            is_missing: false,
            extensions: Default::default(),
            code_status: None,
            dependencies: None,
            files: None,
            issues: None,
            planning: None,
            signature: None,
            in_scope: true,
        };

        let id = registry.upsert(&mut cu).unwrap();
        assert_eq!(id.len(), 36); // UUID v4 with hyphens (8-4-4-4-12)
        assert_eq!(cu.id, Some(id.clone()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_upsert_batch() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        // Create one existing
        let mut existing = make_code_unit("ub1", "Table1", CodeUnitObjectType::Table);
        registry.create(&mut existing).unwrap();

        // Batch upsert: one existing (merge) + one new (create)
        let mut batch = vec![
            {
                let mut cu = make_code_unit("ub1", "UpdatedTable1", CodeUnitObjectType::Table);
                cu.target = None; // don't touch target
                cu
            },
            make_code_unit("ub2", "Table2", CodeUnitObjectType::Table),
        ];

        let result = registry.upsert_batch(&mut batch).unwrap();
        assert_eq!(result.succeeded.len(), 2);
        assert_eq!(result.failed.len(), 0);

        // ub1 should have merged source name but kept original target
        let loaded = registry.get_by_id("ub1", None).unwrap();
        assert_eq!(
            loaded.source.as_ref().unwrap().name.as_deref(),
            Some("UpdatedTable1")
        );
        assert!(loaded.target.is_some());

        // ub2 should be brand new
        let loaded2 = registry.get_by_id("ub2", None).unwrap();
        assert_eq!(
            loaded2.source.as_ref().unwrap().name.as_deref(),
            Some("Table2")
        );

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_error_codes() {
        let err = Error::RegistryNotFound("/tmp/x".to_string());
        assert_eq!(err.error_code_i32(), 1001);

        let err = Error::CodeUnitNotFound("abc".to_string());
        assert_eq!(err.error_code_i32(), 1003);

        let err = Error::FilterError("bad".to_string());
        assert_eq!(err.error_code_i32(), 1011);
    }

    // ── find_by_object tests ─────────────────────────────────────────────

    #[test]
    fn test_find_by_object_match_by_object_type() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
        let mut cu3 = make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure);

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();
        registry.create(&mut cu3).unwrap();

        // Match by objectType = table
        let partial = serde_json::json!({ "objectType": "table" });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 2);
        let ids: Vec<String> = results.iter().filter_map(|cu| cu.id.clone()).collect();
        assert!(ids.contains(&"id1".to_string()));
        assert!(ids.contains(&"id2".to_string()));

        // Match by objectType = procedure
        let partial = serde_json::json!({ "objectType": "procedure" });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id3".to_string()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_match_nested_fields() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

        // cu2 has a different schema
        cu2.source = Some(SourceMetadata {
            database: Some("DB".to_string()),
            schema: Some("sales".to_string()),
            name: Some("Table2".to_string()),
            source_id: "primary".to_string(),
        });

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();

        // Match by source.schema = "dbo"
        let partial = serde_json::json!({ "source": { "schema": "dbo" } });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id1".to_string()));

        // Match by source.schema = "sales"
        let partial = serde_json::json!({ "source": { "schema": "sales" } });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id2".to_string()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_multiple_fields() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Proc1", CodeUnitObjectType::Procedure);
        let mut cu3 = make_code_unit("id3", "Table2", CodeUnitObjectType::Table);

        // cu3 has a different schema
        cu3.source = Some(SourceMetadata {
            database: Some("DB".to_string()),
            schema: Some("sales".to_string()),
            name: Some("Table2".to_string()),
            source_id: "primary".to_string(),
        });

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();
        registry.create(&mut cu3).unwrap();

        // Match objectType = table AND source.schema = dbo
        let partial = serde_json::json!({
            "objectType": "table",
            "source": { "schema": "dbo" }
        });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id1".to_string()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_no_matches() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        registry.create(&mut cu1).unwrap();

        // Match objectType = view (no views exist)
        let partial = serde_json::json!({ "objectType": "view" });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 0);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_empty_registry() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let partial = serde_json::json!({ "objectType": "table" });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 0);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_empty_partial_matches_all() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Proc1", CodeUnitObjectType::Procedure);

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();

        // Empty partial matches all code units
        let partial = serde_json::json!({});
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 2);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_with_field_projection() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
        let mut cu3 = make_code_unit("id3", "Proc1", CodeUnitObjectType::Procedure);

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();
        registry.create(&mut cu3).unwrap();

        // Match tables, project only id and source
        let partial = serde_json::json!({ "objectType": "table" });
        let fields = vec!["id", "source"];
        let results = registry.find_by_object(&partial, Some(&fields)).unwrap();
        assert_eq!(results.len(), 2);

        // Projected results should have source but NOT target
        for cu in &results {
            assert!(cu.id.is_some());
            assert!(cu.source.is_some());
            assert!(cu.target.is_none());
            assert!(cu.kind.is_none());
            assert!(cu.object_type.is_none());
        }

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_match_by_kind() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        registry.create(&mut cu1).unwrap();

        let partial = serde_json::json!({ "kind": "databaseObject" });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);

        let partial = serde_json::json!({ "kind": "script" });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 0);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_match_by_boolean_field() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);
        cu2.is_missing = true;

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();

        // Match isMissing = true
        let partial = serde_json::json!({ "isMissing": true });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id2".to_string()));

        // Match isMissing = false
        let partial = serde_json::json!({ "isMissing": false });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id1".to_string()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_match_by_source_database_and_name() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

        cu2.source = Some(SourceMetadata {
            database: Some("OTHER_DB".to_string()),
            schema: Some("dbo".to_string()),
            name: Some("Table2".to_string()),
            source_id: "primary".to_string(),
        });

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();

        // Match by source database
        let partial = serde_json::json!({ "source": { "database": "DB" } });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id1".to_string()));

        // Match by source database AND name
        let partial = serde_json::json!({
            "source": { "database": "OTHER_DB", "name": "Table2" }
        });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id2".to_string()));

        // Match by source name that doesn't exist
        let partial = serde_json::json!({
            "source": { "database": "DB", "name": "NonExistent" }
        });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 0);

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_match_by_target() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();

        // Match by target name
        let partial = serde_json::json!({ "target": { "name": "TABLE1" } });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id1".to_string()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_find_by_object_match_by_id() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let mut cu1 = make_code_unit("id1", "Table1", CodeUnitObjectType::Table);
        let mut cu2 = make_code_unit("id2", "Table2", CodeUnitObjectType::Table);

        registry.create(&mut cu1).unwrap();
        registry.create(&mut cu2).unwrap();

        // Match by id directly
        let partial = serde_json::json!({ "id": "id1" });
        let results = registry.find_by_object(&partial, None).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].id, Some("id1".to_string()));

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_example_json_roundtrip_fidelity() {
        let dir = temp_dir();
        let registry = CodeUnitRegistry::init(&dir).unwrap();

        let example = include_str!("../examples/code-unit.example.json");
        let original: serde_json::Value = serde_json::from_str(example).unwrap();

        // Write the example through the registry, then read the file back
        // as raw JSON. This exercises the real write_json path.
        let mut code_unit: CodeUnit = serde_json::from_str(example).unwrap();
        let id = registry.create(&mut code_unit).unwrap();

        let file_path = registry.id_to_path(&id);
        let on_disk = fs::read_to_string(&file_path).unwrap();
        let roundtripped: serde_json::Value = serde_json::from_str(&on_disk).unwrap();

        assert_eq!(
            original, roundtripped,
            "Schema round-trip lost or renamed fields"
        );

        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn test_matches_partial_helper() {
        // Exact match
        assert!(matches_partial(
            &serde_json::json!({"a": 1}),
            &serde_json::json!({"a": 1, "b": 2})
        ));

        // Nested match
        assert!(matches_partial(
            &serde_json::json!({"a": {"x": 1}}),
            &serde_json::json!({"a": {"x": 1, "y": 2}, "b": 3})
        ));

        // Mismatch value
        assert!(!matches_partial(
            &serde_json::json!({"a": 1}),
            &serde_json::json!({"a": 2})
        ));

        // Missing key in target
        assert!(!matches_partial(
            &serde_json::json!({"a": 1}),
            &serde_json::json!({"b": 1})
        ));

        // Empty partial matches everything
        assert!(matches_partial(
            &serde_json::json!({}),
            &serde_json::json!({"a": 1, "b": 2})
        ));

        // Scalar vs object mismatch
        assert!(!matches_partial(
            &serde_json::json!({"a": {"x": 1}}),
            &serde_json::json!({"a": 1})
        ));

        // Array match (exact)
        assert!(matches_partial(
            &serde_json::json!({"a": [1, 2]}),
            &serde_json::json!({"a": [1, 2]})
        ));

        // Array mismatch
        assert!(!matches_partial(
            &serde_json::json!({"a": [1, 2]}),
            &serde_json::json!({"a": [1, 3]})
        ));
    }
}
