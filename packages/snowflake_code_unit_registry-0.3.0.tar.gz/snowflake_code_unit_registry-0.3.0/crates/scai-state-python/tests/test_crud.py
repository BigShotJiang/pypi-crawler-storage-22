"""CRUD lifecycle and upsert merge tests.

Validates the full create -> read -> update -> delete workflow and
the deep-merge semantics of upsert.
"""

from __future__ import annotations

import pytest

from snowflake_code_unit_registry import CodeUnitRegistry
from snowflake_code_unit_registry._native import ScaiError
from snowflake_code_unit_registry.types import (
    CodeUnit,
    Issues,
    IssuesSummary,
    Kind,
    ObjectType,
    Planning,
    SourceMetadata,
    TargetMetadata,
)


def test_crud_lifecycle(registry_dir: str):
    """Exercise init -> create -> find_all -> update -> get_by_id -> delete
    as a single end-to-end workflow."""

    registry = CodeUnitRegistry.init(registry_dir)

    # Create
    cu = CodeUnit(
        id="lifecycle-001",
        kind=Kind.databaseObject,
        objectType=ObjectType.table,
        source=SourceMetadata.model_validate(
            {"database": "DB", "schema": "dbo", "name": "Orders"}
        ),
        target=TargetMetadata.model_validate(
            {"database": "DB", "schema": "DBO", "name": "ORDERS"}
        ),
    )
    created_id = registry.create(cu)
    assert created_id == "lifecycle-001"

    # Find with filter
    results = registry.find_all(filter="objectType = 'table'")
    assert len(results) == 1
    assert results[0].id == "lifecycle-001"

    # Update
    registry.update("lifecycle-001", {"source.name": "UpdatedOrders"})

    # Verify update
    loaded = registry.get_by_id("lifecycle-001")
    assert loaded.source.name == "UpdatedOrders"

    # Delete
    registry.delete("lifecycle-001")

    # Verify delete
    with pytest.raises(ScaiError) as exc_info:
        registry.get_by_id("lifecycle-001")
    assert exc_info.value.error_code == 1003  # CodeUnitNotFound


def test_upsert_merge_semantics(registry_dir: str):
    """Verify upsert deep-merges without overwriting unrelated fields.

    The deep_merge logic overlays incoming fields onto the existing document.
    For objects it recurses; for scalars it replaces. Fields not present in
    the incoming document should be preserved."""

    registry = CodeUnitRegistry.init(registry_dir)

    # Step 1: Create the initial document with source, target, and planning.
    original = CodeUnit(
        id="upsert-001",
        kind=Kind.databaseObject,
        objectType=ObjectType.procedure,
        source=SourceMetadata.model_validate(
            {
                "sourceId": "primary",
                "database": "AdventureWorks",
                "schema": "Sales",
                "name": "usp_GetRevenue",
            }
        ),
        target=TargetMetadata.model_validate(
            {
                "database": "ADVENTUREWORKS",
                "schema": "SALES",
                "name": "USP_GET_REVENUE",
            }
        ),
        planning=Planning(wave=2, wavePosition=5, generatedBy="auto-planner-v1"),
    )
    registry.create(original)

    # Step 2: Upsert the same ID with a changed target name, updated planning
    # wave, and a new issues section.  Source is NOT changed in the payload.
    patch = CodeUnit(
        id="upsert-001",
        kind=Kind.databaseObject,
        objectType=ObjectType.procedure,
        source=SourceMetadata.model_validate(
            {
                "sourceId": "primary",
                "database": "AdventureWorks",
                "schema": "Sales",
                "name": "usp_GetRevenue",
            }
        ),
        target=TargetMetadata.model_validate(
            {
                "database": "ADVENTUREWORKS",
                "schema": "SALES",
                "name": "USP_GET_REVENUE_V2",
            }
        ),
        planning=Planning(wave=3, wavePosition=5, generatedBy="auto-planner-v1"),
        issues=Issues(
            summary=IssuesSummary(errors=0, warnings=2, info=0, blocking=False)
        ),
    )
    upserted_id = registry.upsert(patch)
    assert upserted_id == "upsert-001"

    # Step 3: Load and verify the merge result.
    loaded = registry.get_by_id("upsert-001")
    loaded_dict = loaded.model_dump(mode="json", by_alias=True)

    # Source fields should be preserved from the original.
    assert loaded_dict["source"]["schema"] == "Sales"
    assert loaded.source.database == "AdventureWorks"
    assert loaded.source.name == "usp_GetRevenue"

    # Target name should be updated by the upsert.
    assert loaded.target.name == "USP_GET_REVENUE_V2"

    # Planning should be updated by the upsert.
    assert loaded.planning.wave == 3

    # Issues should be newly added by the upsert.
    assert loaded.issues is not None
    assert loaded.issues.summary.warnings == 2
