"""Error code contract integrity tests.

Validates that ScaiError carries the correct error_code attribute
across the FFI boundary for each error variant.
"""

from __future__ import annotations

import pytest

from snowflake_code_unit_registry import CodeUnitRegistry
from snowflake_code_unit_registry._native import ScaiError


def test_error_propagation(registry_dir: str):
    """Verify ScaiError carries the correct error_code attribute across FFI."""

    # 1001: RegistryNotFound
    with pytest.raises(ScaiError) as exc_info:
        CodeUnitRegistry.open("/nonexistent/path/that/does/not/exist")
    assert exc_info.value.error_code == 1001

    # 1003: CodeUnitNotFound
    registry = CodeUnitRegistry.init(registry_dir)
    with pytest.raises(ScaiError) as exc_info:
        registry.get_by_id("nonexistent-id")
    assert exc_info.value.error_code == 1003
