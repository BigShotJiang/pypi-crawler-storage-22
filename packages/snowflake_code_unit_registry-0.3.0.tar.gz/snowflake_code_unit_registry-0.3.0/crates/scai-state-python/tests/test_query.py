"""Query and partial-match tests.

Validates find_by_object partial matching and the serialization path
unique to partial queries (exclude_unset + depythonize + matches_partial).
"""

from __future__ import annotations

from snowflake_code_unit_registry import CodeUnitRegistry
from snowflake_code_unit_registry.types import (
    CodeUnit,
    Kind,
    ObjectType,
    SourceMetadata,
    TargetMetadata,
)


def test_find_by_object_partial_match(registry_dir: str):
    """Verify find_by_object correctly uses only the set fields for matching.

    Creates 3 code units (2 tables in different schemas, 1 procedure) and
    checks that partial queries return the expected subsets."""

    registry = CodeUnitRegistry.init(registry_dir)

    table_dbo = CodeUnit(
        id="query-001",
        kind=Kind.databaseObject,
        objectType=ObjectType.table,
        source=SourceMetadata.model_validate(
            {"database": "DB", "schema": "dbo", "name": "Orders"}
        ),
        target=TargetMetadata.model_validate(
            {"database": "DB", "schema": "DBO", "name": "ORDERS"}
        ),
    )
    table_sales = CodeUnit(
        id="query-002",
        kind=Kind.databaseObject,
        objectType=ObjectType.table,
        source=SourceMetadata.model_validate(
            {"database": "DB", "schema": "Sales", "name": "Customers"}
        ),
        target=TargetMetadata.model_validate(
            {"database": "DB", "schema": "SALES", "name": "CUSTOMERS"}
        ),
    )
    proc = CodeUnit(
        id="query-003",
        kind=Kind.databaseObject,
        objectType=ObjectType.procedure,
        source=SourceMetadata.model_validate(
            {"database": "DB", "schema": "dbo", "name": "usp_Process"}
        ),
        target=TargetMetadata.model_validate(
            {"database": "DB", "schema": "DBO", "name": "USP_PROCESS"}
        ),
    )

    registry.create(table_dbo)
    registry.create(table_sales)
    registry.create(proc)

    # Match by objectType only → should return both tables.
    partial_tables = CodeUnit(objectType=ObjectType.table)
    results = registry.find_by_object(partial_tables)
    result_ids = sorted(r.id for r in results)
    assert result_ids == ["query-001", "query-002"]

    # Match by objectType + source.schema → should return only the dbo table.
    partial_dbo = CodeUnit(
        objectType=ObjectType.table,
        source=SourceMetadata.model_validate({"schema": "dbo"}),
    )
    results = registry.find_by_object(partial_dbo)
    assert len(results) == 1
    assert results[0].id == "query-001"

    # Match by objectType=procedure → should return only the procedure.
    partial_proc = CodeUnit(objectType=ObjectType.procedure)
    results = registry.find_by_object(partial_proc)
    assert len(results) == 1
    assert results[0].id == "query-003"
