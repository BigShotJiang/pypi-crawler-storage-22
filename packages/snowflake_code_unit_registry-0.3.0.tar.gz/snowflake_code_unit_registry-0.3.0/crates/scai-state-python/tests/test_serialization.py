"""FFI serialization fidelity tests.

Validates that the Python -> Rust -> disk -> Rust -> Python round-trip
preserves all fields, including aliases, enums, nested objects, and
empty containers like extensions.
"""

from __future__ import annotations

from snowflake_code_unit_registry import CodeUnitRegistry
from snowflake_code_unit_registry.types import (
    CodeStatus,
    CodeUnit,
    ColumnDef,
    ConversionStatus,
    Dependencies,
    Dependency,
    ExtractionStatus,
    FileEntry,
    Files,
    Issues,
    IssuesSummary,
    Kind,
    ObjectType,
    ParameterDef,
    Parameters,
    Planning,
    ReturnDef,
    Signature,
    SourceMetadata,
    TargetMetadata,
)


def test_roundtrip_full_document(registry_dir: str):
    """Create a CodeUnit with every major section populated, persist it,
    read it back, and verify all fields survived the
    Python -> Rust -> disk -> Rust -> Python round-trip."""

    registry = CodeUnitRegistry.init(registry_dir)

    # Use model_validate for Source/TargetMetadata because the 'schema' alias
    # conflicts with Pydantic internals when passed via constructor kwargs
    # combined with extra='allow'.  model_validate uses alias resolution and
    # works correctly.
    original = CodeUnit(
        id="roundtrip-001",
        kind=Kind.databaseObject,
        objectType=ObjectType.procedure,
        source=SourceMetadata.model_validate(
            {
                "sourceId": "primary",
                "database": "AdventureWorks",
                "schema": "Sales",
                "name": "usp_GetRevenue",
            }
        ),
        target=TargetMetadata.model_validate(
            {
                "database": "ADVENTUREWORKS",
                "schema": "SALES",
                "name": "USP_GET_REVENUE",
            }
        ),
        codeStatus=CodeStatus(
            extraction=ExtractionStatus(status="completed", extractorVersion="2.4.1"),
            conversion=ConversionStatus(status="completed", converterVersion="3.1.0"),
        ),
        files=Files(
            source=FileEntry(
                path="source/Sales/usp_GetRevenue.sql",
                checksum="db97ea0a2998433d5e51367e6d118414d6db13d98b27a788fb0e5393244f8cad",
            ),
            converted=FileEntry(
                path="converted/Sales/usp_GetRevenue.sql",
                checksum="695f088194f33ab6b670703746c00ec2457779f071e28e724cfc72137ab422d5",
            ),
        ),
        dependencies=Dependencies(
            dependsOn=[
                Dependency(
                    id="dep-001",
                    isMissing=False,
                    relationTypes=["SELECT"],
                )
            ],
            requiredBy=["dep-002"],
        ),
        planning=Planning(wave=2, wavePosition=5, generatedBy="test-harness"),
        issues=Issues(
            summary=IssuesSummary(errors=0, warnings=1, info=2, blocking=False)
        ),
        signature=Signature(
            columns=[
                ColumnDef(
                    name="Revenue",
                    type="DECIMAL(18,2)",
                    nullable=False,
                    targetName="REVENUE",
                    targetType="NUMBER(18,2)",
                )
            ],
            parameters=Parameters(
                arguments=[
                    ParameterDef(
                        name="@StartDate",
                        type="DATETIME",
                        required=True,
                        defaultValue="",
                        targetName="START_DATE",
                        targetType="TIMESTAMP_NTZ",
                    )
                ],
                returns=[
                    ReturnDef(
                        name="Revenue",
                        type="DECIMAL(18,2)",
                        targetName="REVENUE",
                        targetType="NUMBER(18,2)",
                    )
                ],
            ),
        ),
    )

    created_id = registry.create(original)
    assert created_id == "roundtrip-001"

    loaded = registry.get_by_id("roundtrip-001")

    # Identity
    assert loaded.id == original.id
    assert loaded.kind == original.kind
    assert loaded.objectType == original.objectType
    assert loaded.schemaVersion == 1
    assert loaded.isMissing is False
    assert loaded.inScope is True

    # Source / Target
    assert loaded.source.database == "AdventureWorks"
    assert loaded.source.name == "usp_GetRevenue"
    assert loaded.target.name == "USP_GET_REVENUE"

    # The 'schema' field uses a Pydantic alias (schema_ -> "schema").
    # Verify via model_dump which correctly resolves aliases across the FFI.
    loaded_dict = loaded.model_dump(mode="json", by_alias=True)
    assert loaded_dict["source"]["schema"] == "Sales"
    assert loaded_dict["target"]["schema"] == "SALES"
    assert loaded_dict["source"]["sourceId"] == "primary"

    # Files
    assert loaded.files.source.path == "source/Sales/usp_GetRevenue.sql"
    assert loaded.files.converted.checksum is not None

    # Code Status
    assert loaded.codeStatus.extraction.status.value == "completed"
    assert loaded.codeStatus.extraction.extractorVersion == "2.4.1"
    assert loaded.codeStatus.conversion.status.value == "completed"
    assert loaded.codeStatus.conversion.converterVersion == "3.1.0"

    # Dependencies
    assert len(loaded.dependencies.dependsOn) == 1
    assert loaded.dependencies.dependsOn[0].id == "dep-001"
    assert len(loaded.dependencies.requiredBy) == 1
    assert loaded.dependencies.requiredBy[0] == "dep-002"

    # Planning
    assert loaded.planning.wave == 2
    assert loaded.planning.wavePosition == 5

    # Issues
    assert loaded.issues.summary.errors == 0
    assert loaded.issues.summary.warnings == 1

    # Signature
    assert len(loaded.signature.columns) == 1
    assert loaded.signature.columns[0].name == "Revenue"
    assert len(loaded.signature.parameters.arguments) == 1
    assert loaded.signature.parameters.arguments[0].name == "@StartDate"
    assert len(loaded.signature.parameters.returns) == 1


def test_extensions_roundtrip(registry_dir: str):
    """Verify that the extensions field (empty map by default) survives the
    full round-trip.  This is a regression guard for the build.rs fix that
    strips skip_serializing_if on empty maps."""

    registry = CodeUnitRegistry.init(registry_dir)

    cu = CodeUnit(
        id="ext-001",
        kind=Kind.databaseObject,
        objectType=ObjectType.table,
        source=SourceMetadata.model_validate(
            {"database": "DB", "schema": "dbo", "name": "T1"}
        ),
        target=TargetMetadata.model_validate(
            {"database": "DB", "schema": "DBO", "name": "T1"}
        ),
    )
    registry.create(cu)

    loaded = registry.get_by_id("ext-001")
    loaded_dict = loaded.model_dump(mode="json", by_alias=True)

    # The extensions key must be present and be an empty dict, not missing/None.
    assert "extensions" in loaded_dict
    assert loaded_dict["extensions"] == {}

    # Also verify via attribute access on the Pydantic model.
    assert loaded.extensions == {}
