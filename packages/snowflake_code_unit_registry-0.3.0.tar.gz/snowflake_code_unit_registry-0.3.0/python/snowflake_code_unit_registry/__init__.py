"""Snowflake Code Unit Registry - State management library for database migrations.

This library provides file operations for managing code unit state using
typed structs generated from the JSON Schema.

Example:
    >>> from scai_state import CodeUnitRegistry, generate_id
    >>> from scai_state.types import CodeUnit, Kind, ObjectType, SourceMetadata, TargetMetadata
    >>> 
    >>> # Create code unit (ID will be auto-generated if not provided)
    >>> code_unit = CodeUnit(
    ...     kind=Kind.database_object,
    ...     object_type=ObjectType.table,
    ...     source=SourceMetadata(database="DB", schema="dbo", name="Customer"),
    ...     target=TargetMetadata(database="DB", schema="DBO", name="CUSTOMER"),
    ... )
    >>> 
    >>> # Create on disk - returns the ID
    >>> registry = CodeUnitRegistry.init("/path/to/repo")
    >>> id = registry.create(code_unit)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from snowflake_code_unit_registry._native import CodeUnitRegistry as _NativeRegistry
from snowflake_code_unit_registry._native import generate_id
from snowflake_code_unit_registry.types import CodeUnit

if TYPE_CHECKING:
    from collections.abc import Sequence

__version__ = "0.3.0"
__all__ = [
    "CodeUnitRegistry",
    "generate_id",
    "CodeUnit",
    "BatchResult",
    "BatchFailure",
    "ScaiError",
]


@dataclass
class BatchFailure:
    """A single failure inside a :class:`BatchResult`."""

    id: str
    error_code: int
    error: str


@dataclass
class BatchResult:
    """Result of a batch operation."""

    succeeded: list[str]
    failed: list[BatchFailure]

    @classmethod
    def _from_dict(cls, data: dict) -> BatchResult:
        """Construct from a dict returned by the native layer."""
        return cls(
            succeeded=data["succeeded"],
            failed=[
                BatchFailure(
                    id=f["id"],
                    error_code=f["errorCode"],
                    error=f["message"],
                )
                for f in data["failed"]
            ],
        )


class CodeUnitRegistry:
    """Code-unit registry backed by a directory of JSON files."""

    def __init__(self, inner: _NativeRegistry):
        self._inner = inner

    @classmethod
    def init(cls, repo_root: str) -> CodeUnitRegistry:
        """Initialize a new registry at the given path."""
        return cls(_NativeRegistry.init(repo_root))

    @classmethod
    def open(cls, repo_root: str) -> CodeUnitRegistry:
        """Open an existing registry at the given path."""
        return cls(_NativeRegistry.open(repo_root))

    # ── Create ────────────────────────────────────────────────────────────

    def create(self, code_unit: CodeUnit) -> str:
        """Create a new code unit on disk.

        If code_unit.id is None, generates a new ID.
        Returns the ID of the created code unit.
        Errors if the code unit already exists.
        """
        return self._inner.create(code_unit.model_dump(mode="json", by_alias=True))

    def create_batch(self, batch: Sequence[CodeUnit]) -> BatchResult:
        """Batch create multiple code units efficiently.

        If a code_unit.id is None, generates a new ID for it.
        Returns BatchResult with succeeded IDs and list of failures.
        """
        dicts = [cu.model_dump(mode="json", by_alias=True) for cu in batch]
        return BatchResult._from_dict(self._inner.create_batch(dicts))

    # ── Get / Find ────────────────────────────────────────────────────────

    def get_by_id(self, id: str, fields: Sequence[str] | None = None) -> CodeUnit:
        """Get a code unit by ID."""
        return CodeUnit.model_validate(
            self._inner.get_by_id(id, list(fields) if fields else None)
        )

    def find_all(
        self,
        filter: str | None = None,
        fields: Sequence[str] | None = None,
    ) -> list[CodeUnit]:
        """Find all code units, optionally filtered by a SQL WHERE expression."""
        items = self._inner.find_all(filter, list(fields) if fields else None)
        return [CodeUnit.model_validate(item) for item in items]

    def find_by_object(
        self,
        partial: CodeUnit,
        fields: Sequence[str] | None = None,
    ) -> list[CodeUnit]:
        """Find all code units matching the non-null fields of a partial CodeUnit.

        Only the fields explicitly set on ``partial`` are used for matching.
        For nested objects, all present keys must match recursively.
        """
        partial_dict = partial.model_dump(
            mode="json", by_alias=True, exclude_unset=True
        )
        items = self._inner.find_by_object(
            partial_dict, list(fields) if fields else None
        )
        return [CodeUnit.model_validate(item) for item in items]

    # ── Update (PATCH) ────────────────────────────────────────────────────

    def update(self, id: str, updates: dict) -> None:
        """Update specific fields in a code unit by dot-notation paths."""
        self._inner.update(id, updates)

    def update_where(self, filter: str, updates: dict) -> BatchResult:
        """Update all code units matching a filter with the same updates."""
        return BatchResult._from_dict(self._inner.update_where(filter, updates))

    def update_batch(self, batch: Sequence[tuple[str, dict]]) -> BatchResult:
        """Batch update multiple code units efficiently."""
        return BatchResult._from_dict(self._inner.update_batch(batch))

    # ── Upsert (merge) ───────────────────────────────────────────────────

    def upsert(self, code_unit: CodeUnit) -> str:
        """Create-or-merge a single code unit.

        If the code unit does not exist on disk, it is created.
        If it exists, the incoming fields are deep-merged into the existing
        document -- fields not present in ``code_unit`` are left untouched.
        Returns the ID of the upserted code unit.
        """
        return self._inner.upsert(code_unit.model_dump(mode="json", by_alias=True))

    def upsert_batch(self, batch: Sequence[CodeUnit]) -> BatchResult:
        """Batch upsert multiple code units."""
        dicts = [cu.model_dump(mode="json", by_alias=True) for cu in batch]
        return BatchResult._from_dict(self._inner.upsert_batch(dicts))

    # ── Delete ────────────────────────────────────────────────────────────

    def delete(self, id: str) -> None:
        """Delete a code unit by ID."""
        self._inner.delete(id)
