"""ODBC connection configuration module."""

from data_exchange_agent.config.sections.connections.connection_registry import (
    ConnectionRegistry,
)
from data_exchange_agent.config.sections.connections.odbc.base import (
    BaseODBCConnectionConfig,
)
from data_exchange_agent.config.sections.connections.odbc.sqlserver import (
    SQLServerConnectionConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType
from data_exchange_agent.utils.odbc_driver_utils import (
    get_best_sqlserver_driver,
    get_sqlserver_drivers,
    is_driver_available,
    validate_sqlserver_driver,
)


# Register connection types
# Note: Additional database types (PostgreSQL, Oracle, etc.) can be registered here
# when their implementations are added.
ConnectionRegistry.register(ConnectionType.SQLSERVER, SQLServerConnectionConfig)

__all__ = [
    "BaseODBCConnectionConfig",
    "SQLServerConnectionConfig",
    "get_best_sqlserver_driver",
    "get_sqlserver_drivers",
    "is_driver_available",
    "validate_sqlserver_driver",
]
