"""
Main entry point for the data exchange agent application.

This module provides the main function and command-line interface for starting
the data exchange agent server with configurable parameters.
"""

import argparse
import os
import sys

from data_exchange_agent.cli.argument_parser import create_argument_parser
from data_exchange_agent.container import create_container
from data_exchange_agent.servers.flask_app import FlaskApp
from data_exchange_agent.utils.decorators import print_error_with_message


@print_error_with_message(
    error_message="Error starting the Data Exchange Agent application."
)
def _run_server(args: argparse.Namespace) -> None:
    """
    Start the data exchange agent server.

    Args:
        args: Command line arguments

    """
    # Get config path if provided and normalize for cross-platform compatibility
    config_path = getattr(args, "config", None)
    if config_path:
        config_path = os.path.normpath(config_path)

    # Initialize the container
    _ = create_container(args, config_path=config_path)

    # Create and start the Flask app
    flask_app = FlaskApp()
    flask_app.create_app()
    flask_app.start_server()


def main() -> None:
    """
    Run the data exchange agent application.

    Supports two modes:
    - test: Verify configuration and connections
    - run (default): Start the agent server

    """
    parser = create_argument_parser()
    args = parser.parse_args()

    # Handle commands
    if args.command == "test":
        from data_exchange_agent.cli import run_connection_test

        sys.exit(run_connection_test(args))
    elif args.command == "run":
        _run_server(args)
    else:
        # Default: run server (backwards compatible)
        _run_server(args)


if __name__ == "__main__":
    main()
