"""
Snowflake stored procedure task source adapter.

This module provides the SnowflakeStoredProcedureTaskSourceAdapter class for managing
communication with Snowflake stored procedures, including task retrieval and status updates.
"""

import json

from dependency_injector.wiring import Provide, inject

from data_exchange_agent import custom_exceptions
from data_exchange_agent.config import ConfigManager
from data_exchange_agent.constants import config_keys, container_keys
from data_exchange_agent.data_sources.sf_connection import SnowflakeDataSource
from data_exchange_agent.interfaces.task_source_adapter import TaskSourceAdapter
from data_exchange_agent.tasks.task import Task


class SnowflakeStoredProcedureTaskSourceAdapter(TaskSourceAdapter):
    """
    Manages Snowflake stored procedure interactions for the Data Exchange Agent.

    This class handles communication with the Snowflake stored procedure, including:
    - Loading Snowflake stored procedure configuration
    - Retrieving tasks from the Snowflake stored procedure
    - Updating task status and details

    The Snowflake stored procedure configuration is loaded from a TOML configuration file
    and used to configure the Snowflake stored procedure.
    """

    SCHEMA = "SNOWCONVERT_AI.DATA_MIGRATION"
    AGENT_TYPE = "data-exchange-agent"
    MAX_TASKS_PER_FETCH = 1
    PULL_TASKS_SP_NAME = "PULL_TASKS"
    COMPLETE_TASK_SP_NAME = "COMPLETE_TASK"
    FAIL_TASK_SP_NAME = "FAIL_TASK"
    COMPLETED_TASK_STATUS_KEY = COMPLETE_TASK_SP_NAME  # The SP returns a scalar value, so key's result is the SP name
    FAILED_TASK_STATUS_KEY = FAIL_TASK_SP_NAME  # The SP returns a scalar value, so key's result is the SP name

    @inject
    def __init__(
        self,
        program_config: ConfigManager = Provide[container_keys.PROGRAM_CONFIG],
        snowflake_datasource: SnowflakeDataSource = Provide[container_keys.SF_DATA_SOURCE],
    ) -> None:
        """
        Initialize the SnowflakeStoredProcedureTaskSourceAdapter.

        Sets up the configuration attribute and loads the configuration from configuration.
        Registers a cleanup handler to close connections gracefully on program exit.
        """
        super().__init__()
        self._program_config = program_config

        try:
            self.agent_id = program_config[f"{config_keys.APPLICATION__AGENT_ID}"]
        except (KeyError, AttributeError) as e:
            raise custom_exceptions.ConfigurationError("Agent ID is missing or incomplete.") from e

        # Use the shared, thread-safe SnowflakeDataSource singleton.
        # Each worker thread will get its own connection via thread-local storage.
        self.snowflake_datasource = snowflake_datasource
        self.affinity: str | None = program_config.get(config_keys.APPLICATION__AFFINITY, None)

    def get_tasks(self) -> list[dict]:
        """
        Retrieve tasks from the Task Source.

        Makes a GET request to fetch tasks from the Task Source.

        Returns:
            list[dict]: List of task dictionaries from the Task Source response

        Raises:
            Exception: If the Task Source request fails

        """
        affinity = f"'{self.affinity}'" if self.affinity else "NULL"
        pull_tasks_statement = (
            f"CALL {self.SCHEMA}.{self.PULL_TASKS_SP_NAME}("
            f"'{self.agent_id}', '{self.AGENT_TYPE}', {affinity}, {self.MAX_TASKS_PER_FETCH})"
        )  # TODO(SNOW-2910666): Sanitization for this
        try:
            # Reuse a persistent connection to avoid reconnecting on every poll.
            # The connection is only (re)created if it's closed or not yet established.
            if self.snowflake_datasource.is_closed():
                self.snowflake_datasource.create_connection()

            raw_results = self.snowflake_datasource.execute_statement(pull_tasks_statement)

            tasks_list = []
            for raw_task in raw_results:
                raw_task_payload = json.loads(raw_task["PAYLOAD"])
                task_obj = Task(
                    id=raw_task["ID"],
                    engine=raw_task_payload["source_type"],
                    database=raw_task_payload["database"],
                    schema=raw_task_payload["schema"],
                    statement=raw_task_payload["statement_location_id"],
                    upload_type=raw_task_payload["target_type"],
                    upload_path=raw_task_payload["target_id"],
                    suggested_batch_size=raw_task_payload.get("suggested_batch_size"),
                    is_bulk_operation=raw_task_payload.get("is_bulk_operation", False),
                )
                tasks_list.append(task_obj.to_dict())

            return tasks_list
        except Exception as e:
            # Close the potentially broken connection so it gets recreated on the next attempt.
            self.snowflake_datasource.close_connection()
            raise Exception(f"Failed to pull tasks executing statement: {pull_tasks_statement}.") from e

    def complete_task(self, task_id: str) -> None:
        """
        Mark a task as completed.

        Args:
            task_id: The identifier of the task to mark as completed

        """
        complete_task_statement = f"CALL {self.SCHEMA}.{self.COMPLETE_TASK_SP_NAME}(" f"'{self.agent_id}', {task_id})"
        raw_result: dict | None = None
        try:
            if self.snowflake_datasource.is_closed():
                self.snowflake_datasource.create_connection()

            raw_result = next(
                iter(self.snowflake_datasource.execute_statement(complete_task_statement)),
                None,
            )
        except Exception as e:
            self.snowflake_datasource.close_connection()
            detail = f"Failed to mark task '{task_id}' as completed executing statement: {complete_task_statement}."
            raise Exception(detail) from e

        if raw_result is None or not raw_result.get(self.COMPLETED_TASK_STATUS_KEY, None):
            detail = f"Failed to mark task '{task_id}' as completed executing statement: {complete_task_statement}."
            raise Exception(detail)

    def fail_task(self, task_id: str, error_message: str | None = None) -> None:
        """
        Mark a task as failed.

        Args:
            task_id: The identifier of the task to mark as failed
            error_message: Optional error message describing the failure

        """
        actual_error_message: str = error_message.replace("'", "''") if error_message else "No error message provided."
        full_sp_name = f"{self.SCHEMA}.{self.FAIL_TASK_SP_NAME}"
        fail_task_statement = f"CALL {full_sp_name}({task_id}, '{self.agent_id}', '{actual_error_message}')"
        # TODO(SNOW-2910666): Sanitization for this

        try:
            if self.snowflake_datasource.is_closed():
                self.snowflake_datasource.create_connection()

            raw_result = next(
                iter(self.snowflake_datasource.execute_statement(fail_task_statement)),
                None,
            )
        except Exception as e:
            self.snowflake_datasource.close_connection()
            raise Exception(
                f"Failed to mark task '{task_id}' as failed executing statement: {fail_task_statement}."
            ) from e

        if raw_result is None or not raw_result.get(self.FAILED_TASK_STATUS_KEY, None):
            raise Exception(f"Failed to mark task '{task_id}' as failed executing statement: {fail_task_statement}.")
