"""Utility functions for detecting and managing ODBC drivers."""

from __future__ import annotations

from typing import Any


def _get_pyodbc() -> Any:
    """Lazily import pyodbc to avoid loading unixODBC at module import time."""
    import pyodbc

    return pyodbc


def get_all_odbc_drivers() -> list[str]:
    """
    Get a list of all available ODBC drivers on the system.

    Returns:
        list[str]: List of all ODBC driver names available on the system.
                  Returns empty list if pyodbc is not available or no drivers found.

    Example:
        >>> drivers = get_all_odbc_drivers()
        >>> print(drivers)
        ['ODBC Driver 18 for SQL Server', 'PostgreSQL Unicode', 'MySQL ODBC 8.0 Driver']

    """
    try:
        pyodbc = _get_pyodbc()
        return pyodbc.drivers()
    except (ImportError, Exception):
        return []


def get_sqlserver_drivers() -> list[str]:
    """
    Get a list of available SQL Server ODBC drivers on the system.

    Returns:
        list[str]: List of SQL Server ODBC driver names available on the system.
                  Returns empty list if no SQL Server drivers are found.

    Example:
        >>> drivers = get_sqlserver_drivers()
        >>> print(drivers)
        ['ODBC Driver 18 for SQL Server', 'ODBC Driver 17 for SQL Server']

    """
    all_drivers = get_all_odbc_drivers()
    return [driver for driver in all_drivers if "SQL Server" in driver]


def get_best_sqlserver_driver() -> str | None:
    """
    Auto-detect the best available SQL Server ODBC driver on the system.

    Searches for drivers in order of preference (newest to oldest):
    1. ODBC Driver 18 for SQL Server
    2. ODBC Driver 17 for SQL Server
    3. ODBC Driver 13 for SQL Server
    4. ODBC Driver 11 for SQL Server
    5. SQL Server Native Client 11.0
    6. SQL Server Native Client 10.0
    7. Any other driver containing "SQL Server"

    Returns:
        str | None: The name of the best available SQL Server driver,
                   or None if no SQL Server drivers are found.

    Example:
        >>> driver = get_best_sqlserver_driver()
        >>> if driver:
        ...     print(f"Using driver: {driver}")
        ... else:
        ...     print("No SQL Server drivers found")

    """
    available_drivers = get_sqlserver_drivers()

    if not available_drivers:
        return None

    # Preferred drivers in order (newest to oldest)
    preferred_drivers = [
        "ODBC Driver 18 for SQL Server",
        "ODBC Driver 17 for SQL Server",
        "ODBC Driver 13 for SQL Server",
        "ODBC Driver 11 for SQL Server",
        "SQL Server Native Client 11.0",
        "SQL Server Native Client 10.0",
    ]

    # Check for preferred drivers in order
    for preferred in preferred_drivers:
        if preferred in available_drivers:
            return preferred

    # If no preferred driver found, return the first available SQL Server driver
    return available_drivers[0]


def is_driver_available(driver_name: str) -> bool:
    """
    Check if a specific ODBC driver is available on the system.

    Args:
        driver_name: The exact name of the ODBC driver to check

    Returns:
        bool: True if the driver is available, False otherwise

    Example:
        >>> if is_driver_available("ODBC Driver 18 for SQL Server"):
        ...     print("Driver is available")
        ... else:
        ...     print("Driver not found")

    """
    return driver_name in get_all_odbc_drivers()


def validate_sqlserver_driver(driver_name: str) -> tuple[bool, str]:
    """
    Validate if a SQL Server ODBC driver is available and provide helpful feedback.

    Args:
        driver_name: The exact name of the ODBC driver to validate

    Returns:
        tuple[bool, str]: A tuple containing:
            - bool: True if driver is valid and available, False otherwise
            - str: Message describing the validation result or suggestions

    Example:
        >>> is_valid, message = validate_sqlserver_driver("ODBC Driver 18 for SQL Server")
        >>> if is_valid:
        ...     print("Driver is valid")
        ... else:
        ...     print(f"Error: {message}")

    """
    if not driver_name or not driver_name.strip():
        return False, "Driver name cannot be empty"

    available_drivers = get_all_odbc_drivers()

    if not available_drivers:
        return False, "No ODBC drivers found on system. Please install ODBC drivers."

    if driver_name in available_drivers:
        return True, f"Driver '{driver_name}' is available"

    # Driver not found - provide helpful suggestions
    sqlserver_drivers = get_sqlserver_drivers()

    if sqlserver_drivers:
        suggestions = "\n".join(f"  - {driver}" for driver in sqlserver_drivers)
        return (
            False,
            f"Driver '{driver_name}' not found.\n" f"Available SQL Server drivers:\n{suggestions}",
        )
    else:
        return (
            False,
            f"Driver '{driver_name}' not found. " f"No SQL Server ODBC drivers are installed on this system.",
        )


def print_available_drivers(filter_sqlserver: bool = False) -> None:
    """
    Print all available ODBC drivers to stdout.

    Args:
        filter_sqlserver: If True, only show SQL Server drivers. If False, show all drivers.

    Example:
        >>> print_available_drivers(filter_sqlserver=True)
        Available SQL Server ODBC Drivers:
          - ODBC Driver 18 for SQL Server
          - ODBC Driver 17 for SQL Server

    """
    if filter_sqlserver:
        drivers = get_sqlserver_drivers()
        title = "Available SQL Server ODBC Drivers:"
    else:
        drivers = get_all_odbc_drivers()
        title = "Available ODBC Drivers:"

    print(title)
    if drivers:
        for driver in drivers:
            print(f"  - {driver}")
    else:
        if filter_sqlserver:
            print("  No SQL Server ODBC drivers found")
        else:
            print("  No ODBC drivers found")
