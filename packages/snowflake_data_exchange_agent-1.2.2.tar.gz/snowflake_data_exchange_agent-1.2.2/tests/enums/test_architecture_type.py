"""
Unit tests for ArchitectureType enumeration.

This module tests the ArchitectureType enum for representing architecture types.
"""

import unittest

from data_exchange_agent.enums.architecture_type import ArchitectureType


class TestArchitectureType(unittest.TestCase):
    """Test suite for ArchitectureType enumeration."""

    def test_x64_value(self):
        """Test X64 architecture type value."""
        self.assertEqual(ArchitectureType.X64.value, "x64")

    def test_x86_value(self):
        """Test X86 architecture type value."""
        self.assertEqual(ArchitectureType.X86.value, "x86")

    def test_str_representation_x64(self):
        """Test string representation of X64."""
        self.assertEqual(str(ArchitectureType.X64), "x64")

    def test_str_representation_x86(self):
        """Test string representation of X86."""
        self.assertEqual(str(ArchitectureType.X86), "x86")

    def test_is_string_enum(self):
        """Test that ArchitectureType is a string enum."""
        self.assertIsInstance(ArchitectureType.X64, str)
        self.assertIsInstance(ArchitectureType.X86, str)

    def test_comparison_with_string(self):
        """Test that ArchitectureType can be compared with strings."""
        self.assertEqual(ArchitectureType.X64, "x64")
        self.assertEqual(ArchitectureType.X86, "x86")

    def test_enum_members(self):
        """Test that all expected enum members exist."""
        members = list(ArchitectureType)
        self.assertEqual(len(members), 2)
        self.assertIn(ArchitectureType.X64, members)
        self.assertIn(ArchitectureType.X86, members)


if __name__ == "__main__":
    unittest.main()
