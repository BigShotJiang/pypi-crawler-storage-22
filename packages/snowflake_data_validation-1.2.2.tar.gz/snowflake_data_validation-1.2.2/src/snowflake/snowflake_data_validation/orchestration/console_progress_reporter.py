from snowflake.snowflake_data_validation.utils.base_output_handler import (
    OutputHandlerBase,
    OutputMessageLevel,
)
from snowflake.snowflake_data_validation.validation.validation_database_manager import (
    ValidationDatabaseManager,
)


class ConsoleProgressReporter:
    """Handles console output reporting for validation results."""

    def __init__(self, output_handler: OutputHandlerBase) -> None:
        """Initialize the console output reporter.

        Args:
            output_handler: The output handler to use for console reporting.

        """
        self.output_handler = output_handler

    def generate_console_output_report(
        self, db_manager: ValidationDatabaseManager
    ) -> None:
        """Generate console output report DataFrame.

        Returns:
            pd.DataFrame: DataFrame containing the console output report.

        """
        (
            summary_df,
            schema_validation_summary_df,
            metrics_validation_summary_df,
            row_validation_summary_df,
        ) = db_manager.get_console_output_report_dataframe()

        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="DATA VALIDATION SUMMARY RESULTS REPORTS",
            dataframe=summary_df,
        )

        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="SCHEMA VALIDATION SUMMARY",
            dataframe=schema_validation_summary_df,
        )

        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="METRICS VALIDATION SUMMARY",
            dataframe=metrics_validation_summary_df,
        )

        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="ROW VALIDATION SUMMARY",
            dataframe=row_validation_summary_df,
        )
