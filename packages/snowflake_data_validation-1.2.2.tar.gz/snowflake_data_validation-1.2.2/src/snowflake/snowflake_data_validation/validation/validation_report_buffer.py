# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import os
import queue

import pandas as pd

from snowflake.snowflake_data_validation.utils.constants import (
    OBJECT_ID_KEY,
    VALIDATION_REPORT_CSV_NAME,
)
from snowflake.snowflake_data_validation.utils.thread_safe_singleton import (
    ThreadSafeSingleton,
)
from snowflake.snowflake_data_validation.validation.validation_database_manager import (
    ValidationDatabaseManager,
)


LOGGER = logging.getLogger(__name__)


class ValidationReportBuffer(metaclass=ThreadSafeSingleton):
    """Thread-safe singleton class for buffering validation report data before writing to file.

    This class implements the producer-consumer pattern where validation threads produce
    DataFrames and add them to a queue, and a single write operation consumes all
    queued data to write to the report file.
    """

    def __init__(self):
        """Initialize the buffer with a thread-safe queue.

        Note: This method may be called multiple times due to the metaclass implementation,
        but initialization is protected to ensure it only happens once.
        """
        if not hasattr(self, "_initialized"):
            self.data_queue = queue.Queue()
            self._initialized = True
            LOGGER.debug("ValidationReportBuffer singleton initialized")

    def add_data(self, dataframe: pd.DataFrame) -> None:
        """Add a DataFrame to the buffer queue.

        Args:
            dataframe (pd.DataFrame): The validation data to buffer

        """
        if not dataframe.empty:
            self.data_queue.put(dataframe.copy())
            LOGGER.debug("Added DataFrame with %d rows to buffer queue", len(dataframe))

    def flush_to_database(self, context, db_manager: ValidationDatabaseManager) -> str:
        """Flush all buffered validation data to the SQLite database and CSV file.

        Args:
            context: The execution context containing report path and run start time.
            db_manager: The ValidationDatabaseManager instance to use.

        Returns:
            str: The path to the database file.

        """
        db_path = db_manager.initialize_database(context)
        LOGGER.info("Flushing validation report buffer to database: %s", db_path)

        # Collect and combine all buffered data
        combined_data = self._collect_and_combine_data()
        if combined_data is None:
            return db_path

        # Write to database and CSV
        self._write_to_database(combined_data, db_manager)
        self._write_to_csv(combined_data, context)

        return db_path

    def _collect_and_combine_data(self) -> pd.DataFrame | None:
        """Collect all DataFrames from the queue and combine them.

        Returns:
            pd.DataFrame | None: Combined DataFrame, or None if no data available.

        """
        if self.data_queue.empty():
            LOGGER.debug("No data in buffer queue to write")
            return None

        # Collect all DataFrames from the queue
        dataframes = []
        while not self.data_queue.empty():
            try:
                df = self.data_queue.get_nowait()
                dataframes.append(df)
            except queue.Empty:
                break

        if not dataframes:
            LOGGER.debug("No DataFrames collected from queue")
            return None

        # Concatenate all DataFrames
        combined_data = pd.concat(dataframes, ignore_index=True)
        LOGGER.info(
            "Combined %d DataFrames with total %d rows",
            len(dataframes),
            len(combined_data),
        )

        return combined_data

    def _write_to_database(
        self, dataframe: pd.DataFrame, db_manager: ValidationDatabaseManager
    ) -> int:
        """Write the DataFrame to the SQLite database.

        Args:
            dataframe: The DataFrame containing validation results.
            db_manager: The ValidationDatabaseManager instance to use.

        Returns:
            int: Number of rows inserted.

        """
        rows_inserted = db_manager.upload_validation_report(dataframe)
        LOGGER.info(
            "Successfully wrote %d rows to validation report database",
            rows_inserted,
        )
        return rows_inserted

    def _write_to_csv(self, dataframe: pd.DataFrame, context) -> str:
        """Write the validation report DataFrame to a local CSV file.

        Args:
            dataframe: The DataFrame containing validation results.
            context: The execution context containing report path and run start time.

        Returns:
            str: The path to the written CSV file.

        """
        csv_filename = f"{context.run_start_time}_{VALIDATION_REPORT_CSV_NAME}"
        csv_path = os.path.join(context.report_path, csv_filename)

        # Ensure directory exists
        os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)

        # Add EXECUTION_ID column from context as the first column
        dataframe_with_id = dataframe.copy()
        dataframe_with_id.insert(0, "EXECUTION_ID", context.run_id)

        # Sort by OBJECT_ID before writing to CSV
        sorted_dataframe = dataframe_with_id.sort_values(
            by=OBJECT_ID_KEY, ascending=True
        )
        sorted_dataframe.to_csv(csv_path, index=False, encoding="utf-8")
        LOGGER.info(
            "Successfully wrote %d rows to validation report CSV: %s",
            len(dataframe),
            csv_path,
        )

        return csv_path

    def clear_buffer(self) -> None:
        """Clear all data from the buffer queue.

        This method can be called to clear the buffer queue, typically used
        for cleanup or when starting a fresh validation run.
        """
        while not self.data_queue.empty():
            try:
                self.data_queue.get_nowait()
            except queue.Empty:
                break
        LOGGER.info("Validation report buffer cleared")

    def get_queue_size(self) -> int:
        """Get the current size of the buffer queue.

        Returns:
            int: Number of DataFrames currently in the queue

        """
        return self.data_queue.qsize()

    def has_data(self) -> bool:
        """Check if the buffer has any data.

        Returns:
            bool: True if the buffer contains data, False otherwise

        """
        return not self.data_queue.empty()
