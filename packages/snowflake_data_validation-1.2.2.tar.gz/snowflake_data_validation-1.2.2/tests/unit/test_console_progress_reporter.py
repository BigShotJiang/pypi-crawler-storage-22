# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from unittest.mock import MagicMock
import pandas as pd

from snowflake.snowflake_data_validation.orchestration.console_progress_reporter import (
    ConsoleProgressReporter,
)
from snowflake.snowflake_data_validation.utils.base_output_handler import (
    OutputMessageLevel,
)


@pytest.fixture
def mock_output_handler():
    """Create a mock output handler."""
    return MagicMock()


@pytest.fixture
def mock_db_manager():
    """Create a mock ValidationDatabaseManager."""
    db_manager = MagicMock()
    # Return 4 sample DataFrames
    db_manager.get_console_output_report_dataframe.return_value = (
        pd.DataFrame({"OBJECT TYPE": ["TABLE"], "NUMBER OF OBJECTS VALIDATED": [5]}),
        pd.DataFrame({"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}),
        pd.DataFrame({"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}),
        pd.DataFrame({"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}),
    )
    return db_manager


class TestConsoleProgressReporter:
    """Tests for ConsoleProgressReporter class."""

    def test_init_stores_output_handler(self, mock_output_handler):
        """Test that initialization stores the output handler."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        assert reporter.output_handler == mock_output_handler

    def test_generate_console_output_report_calls_db_manager(
        self, mock_output_handler, mock_db_manager
    ):
        """Test that generate_console_output_report calls get_console_output_report_dataframe."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(db_manager=mock_db_manager)

        mock_db_manager.get_console_output_report_dataframe.assert_called_once()

    def test_generate_console_output_report_calls_handle_message_four_times(
        self, mock_output_handler, mock_db_manager
    ):
        """Test that handle_message is called four times for each report section."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(db_manager=mock_db_manager)

        assert mock_output_handler.handle_message.call_count == 4

    def test_generate_console_output_report_uses_info_level(
        self, mock_output_handler, mock_db_manager
    ):
        """Test that all handle_message calls use INFO level."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(db_manager=mock_db_manager)

        for call in mock_output_handler.handle_message.call_args_list:
            assert call.kwargs["level"] == OutputMessageLevel.INFO

    def test_generate_console_output_report_headers(
        self, mock_output_handler, mock_db_manager
    ):
        """Test that correct headers are passed to handle_message."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(db_manager=mock_db_manager)

        headers = [
            call.kwargs["header"]
            for call in mock_output_handler.handle_message.call_args_list
        ]

        assert "DATA VALIDATION SUMMARY RESULTS REPORTS" in headers
        assert "SCHEMA VALIDATION SUMMARY" in headers
        assert "METRICS VALIDATION SUMMARY" in headers
        assert "ROW VALIDATION SUMMARY" in headers

    def test_generate_console_output_report_passes_dataframes(
        self, mock_output_handler, mock_db_manager
    ):
        """Test that dataframes are passed to handle_message."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(db_manager=mock_db_manager)

        for call in mock_output_handler.handle_message.call_args_list:
            assert "dataframe" in call.kwargs
            assert isinstance(call.kwargs["dataframe"], pd.DataFrame)
