# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pandas as pd
import pytest

from snowflake.snowflake_data_validation.utils.helpers.helper_dataframe import (
    HelperDataFrame,
)
from snowflake.snowflake_data_validation.utils.constants import COLUMN_VALIDATED


@pytest.fixture
def helper():
    """Create a HelperDataFrame instance for testing."""
    return HelperDataFrame()


class TestProcessSnowflakeQueryResultToDataframe:
    """Tests for process_snowflake_query_result_to_dataframe method."""

    def test_basic_data_conversion(self, helper):
        """Test basic conversion of data rows to DataFrame."""
        data_rows = [
            {"col1": "a", "col2": 1},
            {"col1": "b", "col2": 2},
        ]

        result = helper.process_snowflake_query_result_to_dataframe(data_rows)

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert list(result.columns) == ["col1", "col2"]

    def test_data_is_sorted(self, helper):
        """Test that data is sorted by default."""
        data_rows = [
            {"col1": "b", "col2": 2},
            {"col1": "a", "col2": 1},
        ]

        result = helper.process_snowflake_query_result_to_dataframe(data_rows)

        assert result.iloc[0]["col1"] == "a"
        assert result.iloc[1]["col1"] == "b"

    def test_sort_disabled(self, helper):
        """Test that sorting can be disabled."""
        data_rows = [
            {"col1": "b", "col2": 2},
            {"col1": "a", "col2": 1},
        ]

        result = helper.process_snowflake_query_result_to_dataframe(
            data_rows, sort_and_reset_index=False
        )

        assert result.iloc[0]["col1"] == "b"
        assert result.iloc[1]["col1"] == "a"

    def test_returns_dataframe_with_correct_data(self, helper):
        """Test that the function returns a DataFrame with correct data."""
        data_rows = [{"col1": "a", "col2": 1}]

        result = helper.process_snowflake_query_result_to_dataframe(data_rows)

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert result.iloc[0]["col1"] == "a"
        assert result.iloc[0]["col2"] == 1

    def test_empty_data_returns_empty_dataframe(self, helper):
        """Test that empty data returns an empty DataFrame."""
        data_rows = []

        result = helper.process_snowflake_query_result_to_dataframe(data_rows)

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0


class TestProcessQueryResultToDataframe:
    """Tests for process_query_result_to_dataframe method."""

    def test_basic_data_conversion(self, helper):
        """Test basic conversion of column names and data rows to DataFrame."""
        columns_names = ["col1", "col2"]
        data_rows = [("a", 1), ("b", 2)]

        result = helper.process_query_result_to_dataframe(columns_names, data_rows)

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert list(result.columns) == ["COL1", "COL2"]

    def test_column_names_uppercased(self, helper):
        """Test that column names are converted to uppercase."""
        columns_names = ["lowercase", "MixedCase"]
        data_rows = [("a", "b")]

        result = helper.process_query_result_to_dataframe(columns_names, data_rows)

        assert list(result.columns) == ["LOWERCASE", "MIXEDCASE"]

    def test_data_is_sorted(self, helper):
        """Test that data is sorted by default."""
        columns_names = ["col1", "col2"]
        data_rows = [("b", 2), ("a", 1)]

        result = helper.process_query_result_to_dataframe(columns_names, data_rows)

        assert result.iloc[0]["COL1"] == "a"
        assert result.iloc[1]["COL1"] == "b"

    def test_sort_disabled(self, helper):
        """Test that sorting can be disabled."""
        columns_names = ["col1", "col2"]
        data_rows = [("b", 2), ("a", 1)]

        result = helper.process_query_result_to_dataframe(
            columns_names, data_rows, sort_and_reset_index=False
        )

        assert result.iloc[0]["COL1"] == "b"
        assert result.iloc[1]["COL1"] == "a"

    def test_column_validated_uppercased(self, helper):
        """Test that COLUMN_VALIDATED values are converted to uppercase."""
        columns_names = [COLUMN_VALIDATED, "other_col"]
        data_rows = [("lowercase_value", 1), ("mixed_Value", 2)]

        result = helper.process_query_result_to_dataframe(columns_names, data_rows)

        assert result[COLUMN_VALIDATED].iloc[0] == "LOWERCASE_VALUE"
        assert result[COLUMN_VALIDATED].iloc[1] == "MIXED_VALUE"

    def test_column_validated_uppercase_disabled(self, helper):
        """Test that COLUMN_VALIDATED uppercase can be disabled."""
        columns_names = [COLUMN_VALIDATED, "other_col"]
        data_rows = [("lowercase_value", 1)]

        result = helper.process_query_result_to_dataframe(
            columns_names, data_rows, apply_column_validated_uppercase=False
        )

        assert result[COLUMN_VALIDATED].iloc[0] == "lowercase_value"

    def test_returns_dataframe_with_correct_data(self, helper):
        """Test that the function returns a DataFrame with correct data."""
        columns_names = ["col1"]
        data_rows = [("a",)]

        result = helper.process_query_result_to_dataframe(columns_names, data_rows)

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1
        assert (
            result.iloc[0]["COL1"] == "a"
        )  # Data value preserved, only column names are uppercased

    def test_empty_data_returns_empty_dataframe(self, helper):
        """Test that empty data returns an empty DataFrame."""
        columns_names = ["col1"]
        data_rows = []

        result = helper.process_query_result_to_dataframe(columns_names, data_rows)

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
