# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

"""Unit tests for ValidationDatabaseConnectionBase."""

from unittest.mock import MagicMock

import pytest

from snowflake.snowflake_data_validation.validation.validation_database.validation_database_connection_base import (
    ValidationDatabaseConnectionBase,
)


def test_cannot_instantiate_abstract_class():
    """Test that the abstract base class cannot be instantiated directly."""
    with pytest.raises(TypeError):
        ValidationDatabaseConnectionBase(MagicMock())


def test_subclass_must_implement_abstract_methods():
    """Test that subclasses must implement all abstract methods."""

    class IncompleteConnection(ValidationDatabaseConnectionBase):
        def __init__(self, context):
            pass

    with pytest.raises(TypeError):
        IncompleteConnection(MagicMock())
