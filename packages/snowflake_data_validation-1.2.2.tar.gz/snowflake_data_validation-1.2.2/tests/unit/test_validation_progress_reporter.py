# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from unittest.mock import MagicMock
import pandas as pd

from snowflake.snowflake_data_validation.orchestration.validation_progress_reporter import (
    ValidationProgressReporter,
)
from snowflake.snowflake_data_validation.utils.constants import (
    EXECUTION_SUMMARY_REPORT_NAME,
)


@pytest.fixture
def mock_context():
    """Create a mock context with required attributes."""
    context = MagicMock()
    context.run_start_time = "20260202_120000"
    context.report_path = "/tmp/test_reports"
    return context


@pytest.fixture
def mock_db_manager():
    """Create a mock ValidationDatabaseManager."""
    db_manager = MagicMock()
    return db_manager


@pytest.fixture
def sample_execution_summary_df():
    """Create a sample DataFrame for execution summary report."""
    return pd.DataFrame(
        {
            "OBJECT_NAME": ["table1", "table2", "table3"],
            "OBJECT_TYPE": ["TABLE", "TABLE", "VIEW"],
            "OBJECT_ID": ["id1", "id2", "id3"],
            "SCHEMA_VALIDATION_STATUS": ["SUCCESS", "FAILURE", "SUCCESS"],
            "METRICS_VALIDATION_STATUS": ["SUCCESS", "SUCCESS", "N/A"],
            "ROW_VALIDATION_STATUS": ["SUCCESS", "FAILURE", "SUCCESS"],
        }
    )


def test_generate_execution_summary_report_success(
    mock_context, mock_db_manager, sample_execution_summary_df, tmp_path
):
    """Test successful generation of execution summary report."""
    # Use tmp_path for actual file writing
    mock_context.report_path = str(tmp_path)
    mock_db_manager.get_execution_summary_report_dataframe.return_value = (
        sample_execution_summary_df
    )

    reporter = ValidationProgressReporter()
    reporter.generate_execution_summary_report(mock_context, mock_db_manager)

    # Verify get_execution_summary_report_dataframe was called
    mock_db_manager.get_execution_summary_report_dataframe.assert_called_once()

    # Verify CSV file was created
    expected_filename = f"{mock_context.run_start_time}_{EXECUTION_SUMMARY_REPORT_NAME}"
    expected_path = tmp_path / expected_filename
    assert expected_path.exists()

    # Verify CSV content
    result_df = pd.read_csv(expected_path)
    assert len(result_df) == 3
    assert list(result_df.columns) == [
        "OBJECT_NAME",
        "OBJECT_TYPE",
        "OBJECT_ID",
        "SCHEMA_VALIDATION_STATUS",
        "METRICS_VALIDATION_STATUS",
        "ROW_VALIDATION_STATUS",
    ]


def test_generate_execution_summary_report_correct_method_called(
    mock_context, mock_db_manager, sample_execution_summary_df, tmp_path
):
    """Test that get_execution_summary_report_dataframe is called."""
    mock_context.report_path = str(tmp_path)
    mock_db_manager.get_execution_summary_report_dataframe.return_value = (
        sample_execution_summary_df
    )

    reporter = ValidationProgressReporter()
    reporter.generate_execution_summary_report(mock_context, mock_db_manager)

    # Verify the correct method was called
    mock_db_manager.get_execution_summary_report_dataframe.assert_called_once()


def test_generate_execution_summary_report_creates_directory(
    mock_context, mock_db_manager, sample_execution_summary_df, tmp_path
):
    """Test that report directory is created if it doesn't exist."""
    # Set report path to a non-existent subdirectory
    nested_path = tmp_path / "nested" / "reports"
    mock_context.report_path = str(nested_path)
    mock_db_manager.get_execution_summary_report_dataframe.return_value = (
        sample_execution_summary_df
    )

    reporter = ValidationProgressReporter()
    reporter.generate_execution_summary_report(mock_context, mock_db_manager)

    # Verify directory was created
    assert nested_path.exists()

    # Verify CSV file was created in the nested directory
    expected_filename = f"{mock_context.run_start_time}_{EXECUTION_SUMMARY_REPORT_NAME}"
    expected_path = nested_path / expected_filename
    assert expected_path.exists()


def test_generate_execution_summary_report_empty_dataframe(
    mock_context, mock_db_manager, tmp_path
):
    """Test generation with empty DataFrame."""
    mock_context.report_path = str(tmp_path)
    empty_df = pd.DataFrame(
        columns=[
            "OBJECT_NAME",
            "OBJECT_TYPE",
            "OBJECT_ID",
            "SCHEMA_VALIDATION_STATUS",
            "METRICS_VALIDATION_STATUS",
            "ROW_VALIDATION_STATUS",
        ]
    )
    mock_db_manager.get_execution_summary_report_dataframe.return_value = empty_df

    reporter = ValidationProgressReporter()
    reporter.generate_execution_summary_report(mock_context, mock_db_manager)

    # Verify CSV file was created even with empty data
    expected_filename = f"{mock_context.run_start_time}_{EXECUTION_SUMMARY_REPORT_NAME}"
    expected_path = tmp_path / expected_filename
    assert expected_path.exists()

    # Verify empty CSV has headers but no data rows
    result_df = pd.read_csv(expected_path)
    assert len(result_df) == 0
    assert len(result_df.columns) == 6


def test_generate_execution_summary_report_csv_encoding(
    mock_context, mock_db_manager, tmp_path
):
    """Test that CSV is written with UTF-8 encoding."""
    mock_context.report_path = str(tmp_path)
    # Create DataFrame with unicode characters
    df_with_unicode = pd.DataFrame(
        {
            "OBJECT_NAME": ["テーブル1", "таблица2", "表3"],
            "OBJECT_TYPE": ["TABLE", "TABLE", "VIEW"],
            "OBJECT_ID": ["id1", "id2", "id3"],
            "SCHEMA_VALIDATION_STATUS": ["SUCCESS", "SUCCESS", "SUCCESS"],
            "METRICS_VALIDATION_STATUS": ["SUCCESS", "SUCCESS", "SUCCESS"],
            "ROW_VALIDATION_STATUS": ["SUCCESS", "SUCCESS", "SUCCESS"],
        }
    )
    mock_db_manager.get_execution_summary_report_dataframe.return_value = (
        df_with_unicode
    )

    reporter = ValidationProgressReporter()
    reporter.generate_execution_summary_report(mock_context, mock_db_manager)

    # Verify CSV file was created
    expected_filename = f"{mock_context.run_start_time}_{EXECUTION_SUMMARY_REPORT_NAME}"
    expected_path = tmp_path / expected_filename

    # Read with UTF-8 encoding and verify content
    result_df = pd.read_csv(expected_path, encoding="utf-8")
    assert result_df["OBJECT_NAME"].tolist() == ["テーブル1", "таблица2", "表3"]


def test_generate_execution_summary_report_method_raises_error(
    mock_context, mock_db_manager
):
    """Test handling of errors from get_execution_summary_report_dataframe."""
    mock_db_manager.get_execution_summary_report_dataframe.side_effect = Exception(
        "Database error"
    )

    reporter = ValidationProgressReporter()

    with pytest.raises(Exception, match="Database error"):
        reporter.generate_execution_summary_report(mock_context, mock_db_manager)
