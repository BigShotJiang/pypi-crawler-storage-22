# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

"""Unit tests for ValidationReportBuffer."""

import os
from unittest.mock import MagicMock

import pandas as pd
import pytest

from snowflake.snowflake_data_validation.validation.validation_report_buffer import (
    ValidationReportBuffer,
)


@pytest.fixture
def mock_context(tmp_path):
    """Create a mock context."""
    context = MagicMock()
    context.report_path = str(tmp_path)
    context.run_start_time = "20260101_120000"
    context.run_id = "test-execution-id-12345"
    return context


@pytest.fixture
def mock_db_manager():
    """Create a mock database manager."""
    db_manager = MagicMock()
    db_manager.initialize_database.return_value = "/tmp/test.db"
    db_manager.upload_validation_report.return_value = 1
    return db_manager


@pytest.fixture
def buffer():
    """Create a fresh ValidationReportBuffer instance."""
    ValidationReportBuffer._instances = {}
    return ValidationReportBuffer()


@pytest.fixture
def sample_dataframe():
    """Create a sample validation dataframe."""
    return pd.DataFrame(
        {
            "VALIDATION_TYPE": ["SCHEMA VALIDATION"],
            "TABLE": ["TEST_TABLE"],
            "OBJECT_TYPE": ["TABLE"],
            "OBJECT_ID": [1],
            "COLUMN_VALIDATED": ["col1"],
            "EVALUATION_CRITERIA": ["DATA_TYPE"],
            "SOURCE_VALUE": ["VARCHAR"],
            "SNOWFLAKE_VALUE": ["VARCHAR"],
            "STATUS": ["SUCCESS"],
            "COMMENTS": [""],
        }
    )


def test_csv_includes_execution_id_column(
    buffer, mock_context, mock_db_manager, sample_dataframe
):
    """Test that the CSV file has EXECUTION_ID column."""
    buffer.add_data(sample_dataframe)
    buffer.flush_to_database(mock_context, mock_db_manager)

    csv_path = os.path.join(
        mock_context.report_path,
        f"{mock_context.run_start_time}_validation_report.csv",
    )

    df = pd.read_csv(csv_path)
    assert "EXECUTION_ID" in df.columns


def test_csv_execution_id_is_first_column(
    buffer, mock_context, mock_db_manager, sample_dataframe
):
    """Test that EXECUTION_ID is the first column in CSV."""
    buffer.add_data(sample_dataframe)
    buffer.flush_to_database(mock_context, mock_db_manager)

    csv_path = os.path.join(
        mock_context.report_path,
        f"{mock_context.run_start_time}_validation_report.csv",
    )

    df = pd.read_csv(csv_path)
    assert df.columns[0] == "EXECUTION_ID"


def test_csv_execution_id_value_from_context(
    buffer, mock_context, mock_db_manager, sample_dataframe
):
    """Test that the EXECUTION_ID value matches context.run_id."""
    buffer.add_data(sample_dataframe)
    buffer.flush_to_database(mock_context, mock_db_manager)

    csv_path = os.path.join(
        mock_context.report_path,
        f"{mock_context.run_start_time}_validation_report.csv",
    )

    df = pd.read_csv(csv_path)
    assert df["EXECUTION_ID"].iloc[0] == mock_context.run_id
