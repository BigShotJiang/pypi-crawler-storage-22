"""
Snowflake ID Generator - 分布式雪花算法ID生成器
"""

__version__ = "1.0.0"
__author__ = "AweMinds"
__email__ = "awemindsai@gmail.com"

from .generator import DefaultIdGenerator
from .options import IdGeneratorOptions
from .snowflake import SnowFlake

__all__ = [
    'DefaultIdGenerator',
    'IdGeneratorOptions',
    'SnowFlake',
    '__version__'
]
