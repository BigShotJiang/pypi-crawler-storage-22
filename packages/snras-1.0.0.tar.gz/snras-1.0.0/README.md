# SNRAS-Lib: Signal-to-Noise Ratio with Adjusted Stability

Developed by **Ahmed Sattar Jabbar**, this library provides a robust statistical metric for 
vetting exoplanet candidates in heteroscedastic light curves.

## Installation
```bash
pip install snras