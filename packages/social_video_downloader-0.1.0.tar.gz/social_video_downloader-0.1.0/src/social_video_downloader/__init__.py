"""
social_video_downloader - Download publicly available videos from social media platforms.

This package provides a simple, production-ready interface for downloading
publicly available videos from Instagram, TikTok, and Facebook.

Legal Notice:
    This tool only downloads publicly available content. Users are responsible
    for complying with the Terms of Service of each platform and applicable laws.
    Do not use this tool to download private, restricted, or copyrighted content
    without proper authorization.
"""

from .detector import URLDetector
from .core import Downloader, FilesystemHelper
from .instagram import InstagramExtractor
from .tiktok import TikTokExtractor
from .facebook import FacebookExtractor
from .exceptions import (
    SocialVideoDownloaderError,
    PlatformNotSupportedError,
    InvalidURLError,
    VideoNotFoundError,
    ExtractionFailedError,
    DownloadFailedError,
    AccessDeniedError,
)

__version__ = '1.0.0'
__author__ = 'Social Video Downloader Contributors'
__license__ = 'MIT'

__all__ = [
    'download',
    'SocialVideoDownloaderError',
    'PlatformNotSupportedError',
    'InvalidURLError',
    'VideoNotFoundError',
    'ExtractionFailedError',
    'DownloadFailedError',
    'AccessDeniedError',
]


def download(url, output_dir='.'):
    """
    Download a public video from a supported social media platform.

    Supported platforms:
        - Instagram (posts, reels, TV)
        - TikTok (videos)
        - Facebook (videos)

    Args:
        url (str): Public URL of the video to download.
        output_dir (str): Directory to save the video (default: current directory).

    Returns:
        str: Absolute path to the downloaded video file.

    Raises:
        InvalidURLError: If the URL format is invalid.
        PlatformNotSupportedError: If the URL is from an unsupported platform.
        AccessDeniedError: If the video is private or access is denied.
        ExtractionFailedError: If media URL extraction fails.
        DownloadFailedError: If the download fails.
        SocialVideoDownloaderError: For other errors.

    Example:
        >>> from social_video_downloader import download
        >>> path = download('https://www.instagram.com/p/ABC123/')
        >>> print(f"Video saved to: {path}")
    """
    platform, video_id = URLDetector.detect_platform(url)

    if platform == 'instagram':
        media_url = InstagramExtractor.extract_media_url(video_id)
    elif platform == 'tiktok':
        media_url = TikTokExtractor.extract_media_url(video_id)
    elif platform == 'facebook':
        media_url = FacebookExtractor.extract_media_url(video_id)
    else:
        raise PlatformNotSupportedError(f"Platform '{platform}' is not supported")

    filename = FilesystemHelper.generate_filename(platform, video_id)
    output_path = FilesystemHelper.get_unique_filepath(output_dir, filename)

    Downloader.download_file(media_url, output_path)

    return output_path
