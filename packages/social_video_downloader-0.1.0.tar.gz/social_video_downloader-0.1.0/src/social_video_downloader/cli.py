"""
Command-line interface for social_video_downloader.
"""

import sys
import argparse
from . import download
from .exceptions import SocialVideoDownloaderError


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog='svd',
        description='Download publicly available videos from Instagram, TikTok, and Facebook.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  svd https://www.instagram.com/p/ABC123/
  svd https://www.tiktok.com/@user/video/123456789
  svd https://www.facebook.com/watch/?v=123456789
  svd https://www.instagram.com/reel/ABC123/ -o ~/videos
        """
    )

    parser.add_argument(
        'url',
        help='URL of the public video to download'
    )

    parser.add_argument(
        '-o', '--output',
        dest='output_dir',
        default='.',
        help='Output directory for the downloaded video (default: current directory)'
    )

    parser.add_argument(
        '-v', '--version',
        action='version',
        version='%(prog)s 1.0.0'
    )

    args = parser.parse_args()

    try:
        output_path = download(args.url, output_dir=args.output_dir)
        print(f"✓ Video downloaded successfully: {output_path}")
        return 0

    except SocialVideoDownloaderError as e:
        print(f"✗ Error: {str(e)}", file=sys.stderr)
        return 1

    except KeyboardInterrupt:
        print("\n✗ Download cancelled by user", file=sys.stderr)
        return 130

    except Exception as e:
        print(f"✗ Unexpected error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
