"""
Core download logic, retry handling, and filesystem operations.
"""

import os
import time
import requests
from pathlib import Path
from urllib.parse import urlparse, unquote
from .exceptions import DownloadFailedError


class Downloader:
    """Handles HTTP requests with retry logic and streaming downloads."""

    DEFAULT_TIMEOUT = 15
    MAX_RETRIES = 3
    RETRY_BACKOFF = 2
    CHUNK_SIZE = 8192

    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }

    @staticmethod
    def fetch_url(url, timeout=DEFAULT_TIMEOUT, max_retries=MAX_RETRIES):
        """
        Fetch URL with retry logic.
        Returns response object or raises DownloadFailedError.
        """
        last_error = None

        for attempt in range(max_retries):
            try:
                response = requests.get(
                    url,
                    headers=Downloader.HEADERS,
                    timeout=timeout,
                    allow_redirects=True
                )
                response.raise_for_status()
                return response

            except requests.exceptions.Timeout:
                last_error = f"Request timeout (attempt {attempt + 1}/{max_retries})"
            except requests.exceptions.ConnectionError:
                last_error = f"Connection error (attempt {attempt + 1}/{max_retries})"
            except requests.exceptions.HTTPError as e:
                if e.response.status_code in (403, 404, 410):
                    raise DownloadFailedError(
                        f"Video not accessible (HTTP {e.response.status_code}). "
                        "It may be private, deleted, or restricted."
                    )
                last_error = f"HTTP error {e.response.status_code} (attempt {attempt + 1}/{max_retries})"
            except requests.exceptions.RequestException as e:
                last_error = f"Request failed: {str(e)} (attempt {attempt + 1}/{max_retries})"

            if attempt < max_retries - 1:
                wait_time = Downloader.RETRY_BACKOFF ** attempt
                time.sleep(wait_time)

        raise DownloadFailedError(f"Failed to fetch URL after {max_retries} attempts: {last_error}")

    @staticmethod
    def download_file(media_url, output_path):
        """
        Download file from media_url to output_path using streaming.
        Raises DownloadFailedError on failure.
        """
        try:
            response = Downloader.fetch_url(media_url)

            total_size = int(response.headers.get('content-length', 0))

            with open(output_path, 'wb') as f:
                downloaded = 0
                for chunk in response.iter_content(chunk_size=Downloader.CHUNK_SIZE):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)

            if os.path.getsize(output_path) == 0:
                raise DownloadFailedError("Downloaded file is empty")

            return output_path

        except DownloadFailedError:
            raise
        except Exception as e:
            if os.path.exists(output_path):
                os.remove(output_path)
            raise DownloadFailedError(f"Download failed: {str(e)}")


class FilesystemHelper:
    """Handles filename generation and filesystem operations."""

    INVALID_CHARS = r'[<>:"/\\|?*]'

    @staticmethod
    def sanitize_filename(filename):
        """Remove invalid characters from filename."""
        import re
        filename = re.sub(FilesystemHelper.INVALID_CHARS, '_', filename)
        filename = filename.strip('._')
        return filename or 'video'

    @staticmethod
    def generate_filename(platform, video_id, extension='mp4'):
        """Generate a sensible filename for the video."""
        filename = f"{platform}_{video_id}.{extension}"
        return FilesystemHelper.sanitize_filename(filename)

    @staticmethod
    def ensure_output_dir(output_dir):
        """Ensure output directory exists."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        return str(output_path)

    @staticmethod
    def get_unique_filepath(output_dir, filename):
        """
        Get a unique filepath, appending counter if file exists.
        Returns absolute path.
        """
        output_dir = FilesystemHelper.ensure_output_dir(output_dir)
        filepath = Path(output_dir) / filename

        if not filepath.exists():
            return str(filepath)

        name_parts = filename.rsplit('.', 1)
        base_name = name_parts[0]
        extension = name_parts[1] if len(name_parts) > 1 else ''

        counter = 1
        while True:
            new_filename = f"{base_name}_{counter}.{extension}" if extension else f"{base_name}_{counter}"
            new_filepath = Path(output_dir) / new_filename
            if not new_filepath.exists():
                return str(new_filepath)
            counter += 1
