"""
Platform detection and URL normalization.
"""

import re
from urllib.parse import urlparse
from .exceptions import InvalidURLError, PlatformNotSupportedError


class URLDetector:
    """Detects platform from URL and normalizes it."""

    INSTAGRAM_PATTERNS = [
        r'(?:https?://)?(?:www\.)?instagram\.com/(?:p|reel|tv)/([a-zA-Z0-9_-]+)',
        r'(?:https?://)?(?:www\.)?instagr\.am/(?:p|reel|tv)/([a-zA-Z0-9_-]+)',
    ]

    TIKTOK_PATTERNS = [
        r'(?:https?://)?(?:www\.)?tiktok\.com/@[\w.-]+/video/(\d+)',
        r'(?:https?://)?(?:www\.)?tiktok\.com/video/(\d+)',
        r'(?:https?://)?(?:vm|vt)\.tiktok\.com/([a-zA-Z0-9]+)',
    ]

    FACEBOOK_PATTERNS = [
        r'(?:https?://)?(?:www\.)?facebook\.com/watch.*?v=(\d+)',
        r'(?:https?://)?(?:www\.)?facebook\.com/(?:[a-zA-Z0-9_.-]+/)?videos/(\d+)',
        r'(?:https?://)?(?:www\.)?facebook\.com/(?:[a-zA-Z0-9_.-]+/)?video/(\d+)',
        r'(?:https?://)?(?:www\.)?fb\.watch/([a-zA-Z0-9]+)',
    ]

    @staticmethod
    def normalize_url(url):
        """Normalize URL to standard format."""
        if not url:
            raise InvalidURLError("URL cannot be empty")

        url = url.strip()

        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        try:
            parsed = urlparse(url)
            if not parsed.netloc:
                raise InvalidURLError(f"Invalid URL format: {url}")
        except Exception as e:
            raise InvalidURLError(f"Failed to parse URL: {str(e)}")

        return url

    @staticmethod
    def detect_platform(url):
        """
        Detect platform from URL.
        Returns: ('instagram'|'tiktok'|'facebook', extracted_id)
        """
        url = URLDetector.normalize_url(url)

        for pattern in URLDetector.INSTAGRAM_PATTERNS:
            match = re.search(pattern, url, re.IGNORECASE)
            if match:
                return 'instagram', match.group(1)

        for pattern in URLDetector.TIKTOK_PATTERNS:
            match = re.search(pattern, url, re.IGNORECASE)
            if match:
                return 'tiktok', match.group(1)

        for pattern in URLDetector.FACEBOOK_PATTERNS:
            match = re.search(pattern, url, re.IGNORECASE)
            if match:
                return 'facebook', match.group(1)

        raise PlatformNotSupportedError(
            f"URL does not match any supported platform (Instagram, TikTok, Facebook)"
        )
