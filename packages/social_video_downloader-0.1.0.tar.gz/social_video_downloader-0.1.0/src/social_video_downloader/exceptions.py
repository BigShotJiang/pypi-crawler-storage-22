"""
Custom exception types for social_video_downloader.
"""


class SocialVideoDownloaderError(Exception):
    """Base exception for all social_video_downloader errors."""
    pass


class PlatformNotSupportedError(SocialVideoDownloaderError):
    """Raised when the provided URL is from an unsupported platform."""
    pass


class InvalidURLError(SocialVideoDownloaderError):
    """Raised when the URL format is invalid or malformed."""
    pass


class VideoNotFoundError(SocialVideoDownloaderError):
    """Raised when the video cannot be found or accessed."""
    pass


class ExtractionFailedError(SocialVideoDownloaderError):
    """Raised when media URL extraction fails."""
    pass


class DownloadFailedError(SocialVideoDownloaderError):
    """Raised when the video download fails."""
    pass


class AccessDeniedError(SocialVideoDownloaderError):
    """Raised when access to the video is denied (private, deleted, etc.)."""
    pass
