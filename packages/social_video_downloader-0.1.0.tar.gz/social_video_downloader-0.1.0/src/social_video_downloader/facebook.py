"""
Facebook public video extraction logic.
Extracts direct media URLs from publicly available Facebook videos.
"""

import json
import re
from .core import Downloader
from .exceptions import ExtractionFailedError, AccessDeniedError, VideoNotFoundError


class FacebookExtractor:
    """Extracts direct video URLs from Facebook public content."""

    FACEBOOK_BASE_URL = "https://www.facebook.com"

    @staticmethod
    def extract_media_url(video_id):
        """
        Extract direct video URL from Facebook video.
        Attempts to fetch video data from public endpoints.
        """
        try:
            video_url = f"{FacebookExtractor.FACEBOOK_BASE_URL}/watch/?v={video_id}"

            response = Downloader.fetch_url(video_url)
            html_content = response.text

            media_url = FacebookExtractor._extract_from_html(html_content)
            if media_url:
                return media_url

            raise ExtractionFailedError(
                "Could not extract video URL from Facebook. "
                "The video may be private, deleted, or restricted."
            )

        except AccessDeniedError:
            raise
        except ExtractionFailedError:
            raise
        except Exception as e:
            raise ExtractionFailedError(f"Facebook extraction failed: {str(e)}")

    @staticmethod
    def _extract_from_html(html_content):
        """Extract video URL from Facebook HTML page."""
        try:
            patterns = [
                r'"src":"([^"]*\.mp4[^"]*)"',
                r'<source[^>]*src="([^"]*\.mp4[^"]*)"',
                r'"video":{"src":"([^"]+)"',
                r'"playableUrl":"([^"]+)"',
                r'<video[^>]*src="([^"]+)"',
                r'"url":"([^"]*\.mp4[^"]*)"',
            ]

            for pattern in patterns:
                matches = re.findall(pattern, html_content)
                for match in matches:
                    url = match.replace('\\/', '/')
                    if url.startswith('http') and 'mp4' in url.lower():
                        return url

            script_pattern = r'<script[^>]*type="application/json"[^>]*>({.*?})</script>'
            script_matches = re.finditer(script_pattern, html_content, re.DOTALL)
            for script_match in script_matches:
                try:
                    data = json.loads(script_match.group(1))
                    media_url = FacebookExtractor._extract_from_json(data)
                    if media_url:
                        return media_url
                except (json.JSONDecodeError, KeyError, TypeError):
                    pass

            og_video_match = re.search(r'<meta\s+property="og:video"\s+content="([^"]+)"', html_content)
            if og_video_match:
                url = og_video_match.group(1)
                if 'mp4' in url.lower():
                    return url

            return None

        except Exception:
            return None

    @staticmethod
    def _extract_from_json(data):
        """Extract video URL from Facebook JSON data."""
        try:
            def search_for_video_url(obj):
                """Recursively search for video URLs in JSON structure."""
                if isinstance(obj, dict):
                    for key, value in obj.items():
                        if key in ('src', 'url', 'playableUrl', 'video'):
                            if isinstance(value, str) and 'mp4' in value.lower():
                                return value
                        result = search_for_video_url(value)
                        if result:
                            return result
                elif isinstance(obj, list):
                    for item in obj:
                        result = search_for_video_url(item)
                        if result:
                            return result
                return None

            return search_for_video_url(data)

        except Exception:
            return None
