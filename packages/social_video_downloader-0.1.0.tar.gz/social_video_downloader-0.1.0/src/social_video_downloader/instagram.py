"""
Instagram public video extraction logic.
Extracts direct media URLs from publicly available Instagram posts and reels.
"""

import json
import re
from .core import Downloader
from .exceptions import ExtractionFailedError, AccessDeniedError, VideoNotFoundError


class InstagramExtractor:
    """Extracts direct video URLs from Instagram public content."""

    INSTAGRAM_BASE_URL = "https://www.instagram.com"

    @staticmethod
    def extract_media_url(video_id):
        """
        Extract direct video URL from Instagram post/reel.
        Attempts to fetch the public JSON data endpoint.
        """
        try:
            post_url = f"{InstagramExtractor.INSTAGRAM_BASE_URL}/p/{video_id}/"
            json_url = f"{post_url}?__a=1&__d=dis"

            response = Downloader.fetch_url(json_url)
            data = response.json()

            media_url = InstagramExtractor._extract_from_json(data)
            if media_url:
                return media_url

            html_response = Downloader.fetch_url(post_url)
            media_url = InstagramExtractor._extract_from_html(html_response.text)
            if media_url:
                return media_url

            raise ExtractionFailedError(
                "Could not extract video URL from Instagram post. "
                "The post may be private, deleted, or contain only images."
            )

        except AccessDeniedError:
            raise
        except ExtractionFailedError:
            raise
        except Exception as e:
            raise ExtractionFailedError(f"Instagram extraction failed: {str(e)}")

    @staticmethod
    def _extract_from_json(data):
        """Extract video URL from Instagram JSON response."""
        try:
            if 'graphql' in data:
                shortcode_media = data['graphql'].get('shortcode_media', {})
            else:
                shortcode_media = data.get('items', [{}])[0]

            if not shortcode_media:
                return None

            if shortcode_media.get('is_video'):
                video_url = shortcode_media.get('video_url')
                if video_url:
                    return video_url

            if 'edge_sidecar_to_children' in shortcode_media:
                edges = shortcode_media['edge_sidecar_to_children'].get('edges', [])
                for edge in edges:
                    node = edge.get('node', {})
                    if node.get('is_video'):
                        video_url = node.get('video_url')
                        if video_url:
                            return video_url

            return None

        except (KeyError, TypeError, ValueError):
            return None

    @staticmethod
    def _extract_from_html(html_content):
        """Extract video URL from Instagram HTML page."""
        try:
            patterns = [
                r'"video_url":"([^"]+)"',
                r'"src":"([^"]*video[^"]*)"',
                r'<video[^>]*src="([^"]+)"',
            ]

            for pattern in patterns:
                match = re.search(pattern, html_content)
                if match:
                    url = match.group(1)
                    if 'video' in url.lower() or url.endswith('.mp4'):
                        return url.replace('\\/', '/')

            og_video_match = re.search(r'<meta\s+property="og:video"\s+content="([^"]+)"', html_content)
            if og_video_match:
                return og_video_match.group(1)

            return None

        except Exception:
            return None
