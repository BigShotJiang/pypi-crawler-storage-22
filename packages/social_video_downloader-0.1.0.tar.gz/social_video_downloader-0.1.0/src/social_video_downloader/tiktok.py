"""
TikTok public video extraction logic.
Extracts direct media URLs from publicly available TikTok videos.
"""

import json
import re
from .core import Downloader
from .exceptions import ExtractionFailedError, AccessDeniedError, VideoNotFoundError


class TikTokExtractor:
    """Extracts direct video URLs from TikTok public content."""

    TIKTOK_BASE_URL = "https://www.tiktok.com"

    @staticmethod
    def extract_media_url(video_id):
        """
        Extract direct video URL from TikTok video.
        Attempts multiple extraction methods for reliability.
        """
        try:
            video_url = f"{TikTokExtractor.TIKTOK_BASE_URL}/@dummy/video/{video_id}"

            response = Downloader.fetch_url(video_url)
            html_content = response.text

            media_url = TikTokExtractor._extract_from_html(html_content)
            if media_url:
                return media_url

            raise ExtractionFailedError(
                "Could not extract video URL from TikTok. "
                "The video may be private, deleted, or region-restricted."
            )

        except AccessDeniedError:
            raise
        except ExtractionFailedError:
            raise
        except Exception as e:
            raise ExtractionFailedError(f"TikTok extraction failed: {str(e)}")

    @staticmethod
    def _extract_from_html(html_content):
        """Extract video URL from TikTok HTML page."""
        try:
            patterns = [
                r'"downloadAddr":"([^"]+)"',
                r'"playAddr":"([^"]+)"',
                r'"video":{"downloadAddr":"([^"]+)"',
                r'<video[^>]*src="([^"]+)"',
                r'"src":"([^"]*\.mp4[^"]*)"',
            ]

            for pattern in patterns:
                matches = re.findall(pattern, html_content)
                for match in matches:
                    url = match.replace('\\/', '/')
                    if url.startswith('http') and ('mp4' in url.lower() or 'video' in url.lower()):
                        return url

            script_pattern = r'<script[^>]*id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>({.*?})</script>'
            script_match = re.search(script_pattern, html_content, re.DOTALL)
            if script_match:
                try:
                    data = json.loads(script_match.group(1))
                    media_url = TikTokExtractor._extract_from_json(data)
                    if media_url:
                        return media_url
                except (json.JSONDecodeError, KeyError, TypeError):
                    pass

            return None

        except Exception:
            return None

    @staticmethod
    def _extract_from_json(data):
        """Extract video URL from TikTok JSON data."""
        try:
            def search_for_video_url(obj):
                """Recursively search for video URLs in JSON structure."""
                if isinstance(obj, dict):
                    for key, value in obj.items():
                        if key in ('downloadAddr', 'playAddr', 'src'):
                            if isinstance(value, str) and ('mp4' in value.lower() or 'video' in value.lower()):
                                return value
                        result = search_for_video_url(value)
                        if result:
                            return result
                elif isinstance(obj, list):
                    for item in obj:
                        result = search_for_video_url(item)
                        if result:
                            return result
                return None

            return search_for_video_url(data)

        except Exception:
            return None
