"""Configuration constants for the port scanner.

Defines all global configuration parameters, including:
- Exit codes and verbosity levels
- Network timeouts and concurrency limits
- Scanning modes and output formats
- Service port definitions and protocol flags
- Error codes and port ranges
"""
import errno

from scapy.all import conf as scapy_conf
from enum import IntEnum


scapy_conf.use_pcap = True

EXIT_SUCCESS = 0
EXIT_FAILURE = 1

class VerbosityLevel(IntEnum):
    
    MINIMUM = 0
    DEFAULT = 1
    MEDIUM = 2
    MAXIMUM = 3

    def values():
        return tuple(level.value for level in VerbosityLevel)

LOG_DIR = "/var/log/port-scanner/"


HTTP_PORTS = {80, 8080}
HTTPS_PORTS = {443, 8443}
ALL_HTTP_PORTS = HTTP_PORTS.union(HTTPS_PORTS)
HTTP_SCHEME = "http"
HTTPS_SCHEME = "https"
SSH_PORT = 22
USE_SSL = True
DONT_USE_SSL = False

IFACE = scapy_conf.iface
BASE_SOURCE_PORT = 40000
SYN_ACK_FLAG = 0x12
RESET_FLAG = 0x04
ICMP_UNREACHABLE_TYPE = 3

NO_ROUTE_TO_HOST_ERRNO = errno.EHOSTUNREACH
NETWORK_UNREACHABLE_ERRNO = errno.ENETUNREACH
ETIMEDOUT_ERRNO = errno.ETIMEDOUT

ERRORNO_LIST = [
    NO_ROUTE_TO_HOST_ERRNO,
    NETWORK_UNREACHABLE_ERRNO,
    ETIMEDOUT_ERRNO,
]

DEFAULT_TIMEOUT = 1.5
DEFAULT_READ_BYTES = 1024
DEFAULT_CONCURRENCY_FOR_SCANS = 800
DEFAULT_CONCURRENCY_FOR_BANNER_GRAB = 50
DEFAULT_RETRY_COUNT = 0

SCANNER_CLASSES = {}
TCP_SCAN = "tcp"
SYN_SCAN = "syn"
SCAN_CHOICES = (TCP_SCAN, SYN_SCAN)


DEFAULT_PORT_RANGE = range(1, 1026)
DEFAULT_PORT_SCAN_TYPE = TCP_SCAN
DEFAULT_VERBOSE_LEVEL = VerbosityLevel.DEFAULT

TEXT_FORMAT = "txt"
JSON_FORMAT = "json"
CSV_FORMAT = "csv"
FORMAT_TYPES = (TEXT_FORMAT, JSON_FORMAT, CSV_FORMAT)
OUTPUT_TO_FILE = True
OUTPUT_TO_CONSOLE = False
DEFAULT_OUTPUT_MEDIUM = (TEXT_FORMAT, OUTPUT_TO_CONSOLE)

DEFAULT_USER_AGENT = "Mozilla/1.0"
DEFAULT_SERVICE_BANNER_GRAB = False

PORT_NOT_ALLOWED = 0
MINIMUM_PORT = 1
MAXIMUM_PORT = 65535

THRESHOLD_FOR_SLOW_SCAN = 20000
SYN_SCAN_BATCH_SIZE = 2000

OPEN_PORT = "OPEN"
CLOSED_PORT = "CLOSED"
FILTERED_PORT = "FILTERED"