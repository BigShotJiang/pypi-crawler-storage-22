from __future__ import annotations

import logging
from typing import Optional

from soda_core.common.consistent_hash_builder import ConsistentHashBuilder
from soda_core.common.logging_constants import soda_logger

logger: logging.Logger = soda_logger


class DatasetIdentifier:
    def __init__(self, data_source_name: str, prefixes: list[str], dataset_name: str):
        self.data_source_name = data_source_name
        self.prefixes = prefixes
        self.dataset_name = dataset_name

    @classmethod
    def parse(cls, dataset_qualified_name: Optional[str]) -> DatasetIdentifier:
        from soda_core.common.exceptions import InvalidDatasetQualifiedNameException

        if not dataset_qualified_name:
            raise InvalidDatasetQualifiedNameException("Dataset DQN must be a valid string and cannot be None")

        parts = dataset_qualified_name.split("/")
        if len(parts) < 2:
            raise InvalidDatasetQualifiedNameException("Dataset DQN must contain at least a data source and a dataset")

        data_source_name = parts[0]
        dataset_name = parts[-1]
        prefixes = parts[1:-1] if len(parts) > 2 else []

        return cls(data_source_name, prefixes, dataset_name)

    def to_string(self) -> str:
        return "/".join([self.data_source_name] + self.prefixes + [self.dataset_name])

    def to_hash(self) -> str:
        consistent_hash_builder: ConsistentHashBuilder = ConsistentHashBuilder(hash_string_length=32)  # Use 32 chars
        consistent_hash_builder.add(self.to_string())
        return consistent_hash_builder.get_hash()

    def __repr__(self):
        return (
            f"DatasetIdentifier(data_source='{self.data_source_name}', "
            f"prefixes={self.prefixes}, dataset='{self.dataset_name}')"
        )
