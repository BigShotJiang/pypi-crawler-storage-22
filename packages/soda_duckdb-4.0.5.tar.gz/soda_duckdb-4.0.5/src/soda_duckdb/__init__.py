from soda_duckdb.common.data_sources.duckdb_data_source import (
    DuckDBDataSourceImpl as DuckDBDataSource,
)

__all__ = [
    "DuckDBDataSource",
]
