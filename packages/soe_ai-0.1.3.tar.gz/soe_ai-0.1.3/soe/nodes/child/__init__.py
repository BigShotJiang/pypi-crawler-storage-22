"""
Sub-orchestration node for executing child workflows with parent communication
"""
