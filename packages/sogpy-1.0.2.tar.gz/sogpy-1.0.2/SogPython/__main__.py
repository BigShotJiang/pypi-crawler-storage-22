"""CLI entry point for SogPython package."""

from .cli import main

if __name__ == '__main__':
    main()
