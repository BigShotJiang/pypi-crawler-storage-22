__version__ = "0.1.16"

from .model import (nitrogen_loss, phosphorus_loss, potassium_loss)

__all__ = ["nitrogen_loss","phosphorus_loss","potassium_loss",]

# Function to load your separate input file
def load_input_file(file_path="inputuser.txt"):
    """
    Load the default input file or any user-specified input file.
    
    Parameters:
    file_path : str
        Path to the input file (default is 'inputuser.txt')
    
    Returns:
    data : str
        Content of the input file
    """
    with open(file_path, "r") as f:
        data = f.read()
    return data