"""
Nutrient loss estimation based on either:
1. Soil loss
2. Percentage runoff

User must choose ONE input method.
"""


# =========================
# NITROGEN
# =========================

def nitrogen_loss(value, mode):
    """
    Calculate Nitrogen loss.
    """

    if mode == "soil":

        if 0 <= value < 5:
            nitrogen_loss_value = 2.3647 * value
        elif 5 <= value < 10:
            nitrogen_loss_value = 1.2927 * value + 0.270
        elif 10 <= value < 20:
            nitrogen_loss_value = 0.7909 * value - 0.2909
        else:
            nitrogen_loss_value = 0.8012 * value + 1.1358

        print(f"The nitrogen loss in kg ha⁻¹ based on soil loss is {nitrogen_loss_value}")

    elif mode == "runoff":

        if 0 <= value < 10:
            nitrogen_loss_value = 4.285 * value
        elif 10 <= value < 20:
            nitrogen_loss_value = 0.415 * value + 0.246
        elif 20 <= value < 30:
            nitrogen_loss_value = 0.0679 * value - 0.0175
        else:
            nitrogen_loss_value = 0.0662 * value + 0.0144

        print(f"The nitrogen loss in kg ha⁻¹ based on runoff is {nitrogen_loss_value}")

    else:
        raise ValueError("Mode must be 'soil' or 'runoff'")

    return nitrogen_loss_value


# =========================
# PHOSPHORUS
# =========================

def phosphorus_loss(value, mode):
    """
    Calculate Phosphorus loss.
    """

    if mode == "soil":

        if 0 <= value < 5:
            phosphorus_loss_value = 0.2096 * value
        elif 5 <= value < 10:
            phosphorus_loss_value = 0.0853 * value - 0.0103
        elif 10 <= value < 20:
            phosphorus_loss_value = 0.1048 * value + 0.0291
        else:
            phosphorus_loss_value = 0.0622 * value + 0.0794

        print(f"The phosphorus loss in kg ha⁻¹ based on soil loss is {phosphorus_loss_value}")

    elif mode == "runoff":

        if 0 <= value < 10:
            phosphorus_loss_value = 0.189 * value
        elif 10 <= value < 20:
            phosphorus_loss_value = 0.0478 * value + 0.018
        elif 20 <= value < 30:
            phosphorus_loss_value = 0.027 * value - 0.0066
        else:
            phosphorus_loss_value = 0.0262 * value + 0.0046

        print(f"The phosphorus loss in kg ha⁻¹ based on runoff is {phosphorus_loss_value}")

    else:
        raise ValueError("Mode must be 'soil' or 'runoff'")

    return phosphorus_loss_value


# =========================
# POTASSIUM
# =========================

def potassium_loss(value, mode):
    """
    Calculate Potassium loss.
    """

    if mode == "soil":

        if 0 <= value < 5:
            potassium_loss_value = 3.1155 * value
        elif 5 <= value < 10:
            potassium_loss_value = 1.2188 * value + 0.2178
        elif 10 <= value < 20:
            potassium_loss_value = 1.0204 * value + 2.5149
        else:
            potassium_loss_value = 0.5914 * value + 0.4662

        print(f"The potassium loss in kg ha⁻¹ based on soil loss is {potassium_loss_value}")

    elif mode == "runoff":

        if 0 <= value < 10:
            potassium_loss_value = 2.289 * value
        elif 10 <= value < 20:
            potassium_loss_value = 0.4252 * value - 0.1895
        elif 20 <= value < 30:
            potassium_loss_value = 0.4512 * value - 0.3018
        else:
            potassium_loss_value = 0.4361 * value + 0.262

        print(f"The potassium loss in kg ha⁻¹ based on runoff is {potassium_loss_value}")

    else:
        raise ValueError("Mode must be 'soil' or 'runoff'")

    return potassium_loss_value
