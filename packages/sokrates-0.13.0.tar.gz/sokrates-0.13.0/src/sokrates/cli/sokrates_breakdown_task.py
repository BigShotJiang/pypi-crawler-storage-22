#!/usr/bin/env python3
import argparse
import sys

from sokrates.workflows.refinement_workflow import RefinementWorkflow
from sokrates.cli.colors import Colors
from sokrates.file_helper import FileHelper
from sokrates.cli.output_printer import OutputPrinter
from sokrates.config import Config
from .helper import Helper

DEFAULT_MAX_TOKENS = 5000

def main():
    """Main function for the task breakdown CLI tool.
    
    This function handles command-line arguments, processes the input task,
    and executes the breakdown workflow using the RefinementWorkflow.
    
    Returns:
        None
    """
    # Set up argument parser
    parser = argparse.ArgumentParser(
            description='Breaks down a given task into sub-tasks with complexity rating. Returns a json representation of the calculated tasks.',
            formatter_class=argparse.RawDescriptionHelpFormatter
        )

    parser.add_argument(
        '--provider',
        required=False,
        type=str,
        default=None,
        help="The provider to use"
    )

    parser.add_argument(
        '--api-endpoint',
        default=None,
        help="LLM server API endpoint."
    )

    parser.add_argument(
        '--api-key',
        required=False,
        default=None,
        help='API key for authentication (many local servers don\'t require this)'
    )

    parser.add_argument(
        '--task', '-t',
        required=False,
        default=None,
        help='The full task description at hand as string'
    )

    parser.add_argument(
        '--task-file', '-tf',
        required=False,
        default=None,
        help='A filepath to a file with the task to break down'
    )
    
    parser.add_argument(
        '--model', '-m',
        default=None,
        help="The model to use for the task breakdown"
    )
    
    parser.add_argument(
        '--temperature',
        default=None,
        help="The temperature to use for the task breakdown"
    )

    parser.add_argument(
        '--output', '-o',
        help='Output filename to save the response (e.g., tasks.json)'
    )
    
    # context
    parser.add_argument(
        '--context-text', '-ct',
        default=None,
        help='Optional additional context text to prepend before the prompt'
    )
    parser.add_argument(
        '--context-files', '-cf',
        help='Optional comma separated additional context text file paths with content that should be prepended before the prompt'
    )
    parser.add_argument(
        '--context-directories', '-cd',
        default=None,
        help='Optional comma separated additional directory paths with files with content that should be prepended before the prompt'
    )
    
    parser.add_argument(
        '--max-tokens', '-mt',
        default=DEFAULT_MAX_TOKENS,
        help="Max number of output tokens to generate"
    )

    # Parse arguments
    args = parser.parse_args()
    config = Helper.load_config()
    api_endpoint = Helper.get_provider_value('api_endpoint', config, args)
    api_key = Helper.get_provider_value('api_key', config, args)
    temperature = Helper.get_provider_value('temperature', config, args, 'default_temperature')
    model = Helper.get_provider_value('model', config, args, 'default_model')

    if args.task and args.task_file:
        OutputPrinter.print_error("You cannot provide both a task-file and a task. Exiting.")
        sys.exit(1)
        
    if not args.task and not args.task_file:
        OutputPrinter.print_error("You did not provide a task via --task or --task-file. Exiting.")
        sys.exit(1)
    
    task = ""
    if args.task:
        task = args.task
        
    if args.task_file:
        task = FileHelper.read_file(args.task_file)

    Helper.print_configuration_section(config=config, args=args)
        
    # context
    context = Helper.construct_context_from_arguments(
        context_text=args.context_text,
        context_directories=args.context_directories,
        context_files=args.context_files)
    
    OutputPrinter.print_info("api-endpoint", api_endpoint)
    OutputPrinter.print_info("model", model)
    OutputPrinter.print_info("temperature", temperature)
    OutputPrinter.print_info("max-tokens", args.max_tokens)
        
    workflow = RefinementWorkflow(api_endpoint=api_endpoint, 
        api_key=api_key, model=model, 
        max_tokens=args.max_tokens, 
        temperature=temperature
    )
    result = workflow.breakdown_task(task=task, context=context)

    OutputPrinter.print_section("RESULT", Colors.BRIGHT_BLUE, "═")
    print(result)
    
    if args.output:
        OutputPrinter.print_info("Writing task list to file:", args.output, Colors.BRIGHT_MAGENTA)
        FileHelper.write_to_file(args.output, result)
    
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Process interrupted by user{Colors.RESET}")
        sys.exit(0)
    except Exception as e:
        print(f"{Colors.RED}Unexpected error: {str(e)}{Colors.RESET}")
        sys.exit(1)
