export const PLUGIN_TYPES = {
    LAYOUT: "layout",
};
