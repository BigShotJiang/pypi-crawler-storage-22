"""Tests for SolarEdge Web."""


def test_dummy() -> None:
    """Test dummy."""
    assert True
