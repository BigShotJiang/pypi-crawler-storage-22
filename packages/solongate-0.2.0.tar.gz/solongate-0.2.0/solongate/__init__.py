"""
SolonGate - Security Gateway for AI Tools and MCP Servers.

Phase 0: Threat Model & Foundations
- Trust Model: LLM is untrusted by default
- Default-Deny: All actions denied unless explicitly allowed
- Secure Defaults: New tools start in read-only mode

Phase 1: Core Runtime Enforcement
- Schema Validation Layer
- Policy Enforcement with versioning
- Scope and Capability Isolation
- MCP Server-Side Verification
- MCP Interceptor/Middleware
"""

from .trust import TrustLevel, is_valid_trust_level, assert_valid_transition
from .permissions import (
    Permission,
    PermissionSet,
    NO_PERMISSIONS,
    READ_ONLY,
    has_permission,
    has_all_permissions,
    permission_for_method,
)
from .policy import (
    PolicyEffect,
    PolicyRule,
    PolicySet,
    PolicyDecision,
    create_default_deny_policy_set,
    create_read_only_policy_set,
)
from .errors import (
    SolonGateError,
    PolicyDeniedError,
    TrustEscalationError,
    SchemaValidationError,
    RateLimitError,
    ToolNotFoundError,
    UnsafeConfigurationError,
)
from .input_guard import (
    InputGuardConfig,
    ThreatType,
    DetectedThreat,
    SanitizationResult,
    detect_path_traversal,
    detect_shell_injection,
    detect_wildcard_abuse,
    check_length_limits,
    check_entropy_limits,
    sanitize_input,
    DEFAULT_INPUT_GUARD_CONFIG,
)
from .capability_token import (
    CapabilityToken,
    TokenConfig,
    TokenVerificationResult,
    TokenIssuer,
    ServerVerifier as TokenServerVerifier,
    DEFAULT_TOKEN_TTL_SECONDS,
    TOKEN_ALGORITHM,
    MIN_SECRET_LENGTH,
)
from .client import SolonGate, SolonGateConfig

# Phase 1: Schema Validation
from .schema_validator import (
    SchemaValidationResult,
    StrictSchema,
    ToolSchema,
    ToolRegistry,
    validate_tool_input,
    get_global_registry,
    register_tool,
)

# Phase 1: Security Warnings
from .warnings import (
    SecurityWarning,
    analyze_security_warnings,
    UNSAFE_CONFIGURATION_WARNINGS,
)

# Phase 1: Rate Limiter
from .rate_limiter import (
    RateLimiter,
    RateLimitResult,
    RateLimitUsage,
)

# Phase 1: MCP Interceptor
from .mcp_interceptor import (
    InterceptorMode,
    InterceptedRequest,
    InterceptionResult,
    InterceptorConfig,
    MCPInterceptor,
    AsyncMCPInterceptor,
    protected_tool,
    async_protected_tool,
)

# Phase 1: Server Verification
from .server_verifier import (
    VerificationConfig,
    ScopeVerificationResult,
    ServerVerifier,
    create_fastapi_middleware,
    create_flask_decorator,
)

# Phase 1: Path Matching and Isolation
from .path_matcher import (
    PathConstraints,
    PathValidationResult,
    normalize_path,
    is_within_root,
    match_path_pattern,
    is_path_allowed,
    extract_path_arguments,
    validate_paths_in_request,
)

# Phase 1: Policy Store with Versioning
from .policy_store import (
    PolicyVersion,
    PolicyDiff,
    PolicyStore,
)

# Phase 1: MCP Wrapper (Easy Integration)
from .mcp_wrapper import (
    SecureServerConfig,
    SecureClientConfig,
    SecureMCPServer,
    SecureMCPClient,
    create_secure_server,
    create_secure_client,
)

# API Client (Cloud-based with API keys)
from .api_client import (
    SolonGateAPI,
    AsyncSolonGateAPI,
    APIConfig,
    APIError,
    AuthenticationError,
    ValidationResult,
    TokenResult,
    PoliciesResource,
    TokensResource,
    ToolsResource,
    AsyncPoliciesResource,
    AsyncTokensResource,
    AsyncToolsResource,
)

__version__ = "0.2.0"
__all__ = [
    # Trust
    "TrustLevel",
    "is_valid_trust_level",
    "assert_valid_transition",
    # Permissions
    "Permission",
    "PermissionSet",
    "NO_PERMISSIONS",
    "READ_ONLY",
    "has_permission",
    "has_all_permissions",
    "permission_for_method",
    # Policy
    "PolicyEffect",
    "PolicyRule",
    "PolicySet",
    "PolicyDecision",
    "create_default_deny_policy_set",
    "create_read_only_policy_set",
    # Errors
    "SolonGateError",
    "PolicyDeniedError",
    "TrustEscalationError",
    "SchemaValidationError",
    "RateLimitError",
    "ToolNotFoundError",
    "UnsafeConfigurationError",
    # Input Guard
    "InputGuardConfig",
    "ThreatType",
    "DetectedThreat",
    "SanitizationResult",
    "detect_path_traversal",
    "detect_shell_injection",
    "detect_wildcard_abuse",
    "check_length_limits",
    "check_entropy_limits",
    "sanitize_input",
    "DEFAULT_INPUT_GUARD_CONFIG",
    # Capability Token
    "CapabilityToken",
    "TokenConfig",
    "TokenVerificationResult",
    "TokenIssuer",
    "TokenServerVerifier",
    "DEFAULT_TOKEN_TTL_SECONDS",
    "TOKEN_ALGORITHM",
    "MIN_SECRET_LENGTH",
    # Client
    "SolonGate",
    "SolonGateConfig",
    # Phase 1: Schema Validation
    "SchemaValidationResult",
    "StrictSchema",
    "ToolSchema",
    "ToolRegistry",
    "validate_tool_input",
    "get_global_registry",
    "register_tool",
    # Phase 1: Security Warnings
    "SecurityWarning",
    "analyze_security_warnings",
    "UNSAFE_CONFIGURATION_WARNINGS",
    # Phase 1: Rate Limiter
    "RateLimiter",
    "RateLimitResult",
    "RateLimitUsage",
    # Phase 1: MCP Interceptor
    "InterceptorMode",
    "InterceptedRequest",
    "InterceptionResult",
    "InterceptorConfig",
    "MCPInterceptor",
    "AsyncMCPInterceptor",
    "protected_tool",
    "async_protected_tool",
    # Phase 1: Server Verification
    "VerificationConfig",
    "ScopeVerificationResult",
    "ServerVerifier",
    "create_fastapi_middleware",
    "create_flask_decorator",
    # Phase 1: Path Matching
    "PathConstraints",
    "PathValidationResult",
    "normalize_path",
    "is_within_root",
    "match_path_pattern",
    "is_path_allowed",
    "extract_path_arguments",
    "validate_paths_in_request",
    # Phase 1: Policy Store
    "PolicyVersion",
    "PolicyDiff",
    "PolicyStore",
    # Phase 1: MCP Wrapper
    "SecureServerConfig",
    "SecureClientConfig",
    "SecureMCPServer",
    "SecureMCPClient",
    "create_secure_server",
    "create_secure_client",
    # API Client
    "SolonGateAPI",
    "AsyncSolonGateAPI",
    "APIConfig",
    "APIError",
    "AuthenticationError",
    "ValidationResult",
    "TokenResult",
    "PoliciesResource",
    "TokensResource",
    "ToolsResource",
    "AsyncPoliciesResource",
    "AsyncTokensResource",
    "AsyncToolsResource",
]
