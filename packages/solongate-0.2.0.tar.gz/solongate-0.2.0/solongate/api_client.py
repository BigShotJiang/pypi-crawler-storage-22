"""
SolonGate API Client.

Provides cloud-based security management with API keys.
Similar to Stripe, OpenAI SDK patterns.

Usage:
    from solongate import SolonGateAPI

    # Initialize with API key
    api = SolonGateAPI(api_key="sg_live_xxxxxxxxxxxxxxxx")

    # Validate a tool call
    result = api.validate("file.read", {"path": "/home/user/doc.txt"})

    # Get policy from cloud
    policy = api.policies.get("default")

    # Create capability token
    token = api.tokens.create(tool="file.read", scope="read")
"""

import os
import time
import hashlib
import hmac
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal

import httpx

from .trust import TrustLevel
from .permissions import Permission
from .policy import PolicySet, PolicyEffect, PolicyDecision
from .errors import SolonGateError, PolicyDeniedError, RateLimitError


# API Constants
DEFAULT_API_URL = "https://api.solongate.com"
API_VERSION = "v1"
SDK_VERSION = "0.2.0"


class APIError(SolonGateError):
    """Error from the SolonGate API."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        request_id: str | None = None,
    ):
        super().__init__(message, code="API_ERROR")
        self.status_code = status_code
        self.request_id = request_id


class AuthenticationError(APIError):
    """API key is invalid or missing."""

    def __init__(self, message: str = "Invalid API key"):
        super().__init__(message, status_code=401)
        self.code = "AUTHENTICATION_ERROR"


@dataclass
class APIConfig:
    """Configuration for the SolonGate API client."""

    api_key: str
    api_url: str = DEFAULT_API_URL
    timeout: float = 30.0
    max_retries: int = 3
    verify_ssl: bool = True


@dataclass
class ValidationResult:
    """Result of a validation request."""

    allowed: bool
    tool: str
    decision: PolicyDecision | None = None
    token: str | None = None
    request_id: str | None = None
    latency_ms: float | None = None


@dataclass
class TokenResult:
    """Result of a token creation request."""

    token: str
    tool: str
    scope: str
    expires_at: str
    nonce: str


class PoliciesResource:
    """API resource for policy management."""

    def __init__(self, client: "SolonGateAPI"):
        self._client = client

    def get(self, policy_id: str = "default") -> PolicySet:
        """Get a policy set by ID."""
        response = self._client._request("GET", f"/policies/{policy_id}")
        return PolicySet(**response)

    def list(self) -> list[dict[str, Any]]:
        """List all policy sets."""
        response = self._client._request("GET", "/policies")
        return response.get("policies", [])

    def create(self, policy: PolicySet) -> PolicySet:
        """Create a new policy set."""
        response = self._client._request(
            "POST", "/policies", json=policy.model_dump()
        )
        return PolicySet(**response)

    def update(self, policy_id: str, policy: PolicySet) -> PolicySet:
        """Update an existing policy set."""
        response = self._client._request(
            "PUT", f"/policies/{policy_id}", json=policy.model_dump()
        )
        return PolicySet(**response)


class TokensResource:
    """API resource for token management."""

    def __init__(self, client: "SolonGateAPI"):
        self._client = client

    def create(
        self,
        tool: str,
        scope: str,
        ttl_seconds: int = 30,
    ) -> TokenResult:
        """Create a capability token."""
        response = self._client._request(
            "POST",
            "/tokens",
            json={
                "tool": tool,
                "scope": scope,
                "ttl_seconds": ttl_seconds,
            },
        )
        return TokenResult(
            token=response["token"],
            tool=response["tool"],
            scope=response["scope"],
            expires_at=response["expires_at"],
            nonce=response["nonce"],
        )

    def verify(self, token: str) -> dict[str, Any]:
        """Verify a capability token."""
        response = self._client._request(
            "POST",
            "/tokens/verify",
            json={"token": token},
        )
        return response


class ToolsResource:
    """API resource for tool management."""

    def __init__(self, client: "SolonGateAPI"):
        self._client = client

    def register(
        self,
        name: str,
        description: str,
        input_schema: dict[str, Any],
        permissions: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a tool with the gateway."""
        response = self._client._request(
            "POST",
            "/tools",
            json={
                "name": name,
                "description": description,
                "input_schema": input_schema,
                "permissions": permissions or ["READ"],
            },
        )
        return response

    def list(self) -> list[dict[str, Any]]:
        """List registered tools."""
        response = self._client._request("GET", "/tools")
        return response.get("tools", [])

    def get(self, name: str) -> dict[str, Any]:
        """Get a tool by name."""
        return self._client._request("GET", f"/tools/{name}")

    def update(self, name: str, **kwargs: Any) -> dict[str, Any]:
        """Update a tool's configuration (e.g., enabled, permissions)."""
        return self._client._request("PUT", f"/tools/{name}", json=kwargs)

    def delete(self, name: str) -> dict[str, Any]:
        """Delete / unregister a tool."""
        return self._client._request("DELETE", f"/tools/{name}")


class SolonGateAPI:
    """
    SolonGate API Client.

    Provides cloud-based security management for AI tools and MCP servers.

    Example:
        from solongate import SolonGateAPI

        # Initialize with API key
        api = SolonGateAPI(api_key="sg_live_xxxxxxxxxxxxxxxx")

        # Or use environment variable SOLONGATE_API_KEY
        api = SolonGateAPI()

        # Validate a tool call
        result = api.validate("file.read", {"path": "/home/user/doc.txt"})
        if result.allowed:
            print(f"Allowed! Token: {result.token}")
        else:
            print(f"Denied: {result.decision.reason}")

        # Manage policies
        policy = api.policies.get("default")
        api.policies.update("default", updated_policy)

        # Create tokens
        token = api.tokens.create(tool="file.read", scope="read:/home")
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """
        Initialize the SolonGate API client.

        Args:
            api_key: Your SolonGate API key (sg_live_xxx or sg_test_xxx)
                    If not provided, uses SOLONGATE_API_KEY environment variable
            api_url: API base URL (defaults to https://api.solongate.com)
            timeout: Request timeout in seconds
            max_retries: Maximum number of retries for failed requests
        """
        self._api_key = api_key or os.environ.get("SOLONGATE_API_KEY")
        if not self._api_key:
            raise AuthenticationError(
                "API key is required. Provide api_key parameter or set SOLONGATE_API_KEY environment variable."
            )

        self._validate_api_key(self._api_key)

        self._config = APIConfig(
            api_key=self._api_key,
            api_url=api_url or DEFAULT_API_URL,
            timeout=timeout,
            max_retries=max_retries,
        )

        self._client = httpx.Client(
            base_url=f"{self._config.api_url}/api/{API_VERSION}",
            timeout=timeout,
            headers={
                "X-API-Key": self._api_key,
                "Authorization": f"Bearer {self._api_key}",
                "User-Agent": f"solongate-python/{SDK_VERSION}",
                "Content-Type": "application/json",
            },
        )

        # Initialize resources
        self.policies = PoliciesResource(self)
        self.tokens = TokensResource(self)
        self.tools = ToolsResource(self)

    def _validate_api_key(self, key: str) -> None:
        """Validate API key format."""
        if not key.startswith(("sg_live_", "sg_test_")):
            raise AuthenticationError(
                "Invalid API key format. Keys should start with 'sg_live_' or 'sg_test_'"
            )

    def _request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an API request."""
        start_time = time.time()
        last_error: Exception | None = None

        for attempt in range(self._config.max_retries):
            try:
                response = self._client.request(
                    method=method,
                    url=path,
                    json=json,
                    params=params,
                )

                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 1))
                    if attempt < self._config.max_retries - 1:
                        time.sleep(retry_after)
                        continue
                    raise RateLimitError(
                        "Rate limit exceeded after retries",
                        retry_after=retry_after,
                    )

                if response.status_code == 401:
                    raise AuthenticationError("Invalid API key")

                if response.status_code >= 400:
                    error_data = response.json() if response.text else {}
                    raise APIError(
                        error_data.get("error", {}).get("message", "Unknown error"),
                        status_code=response.status_code,
                        request_id=response.headers.get("X-Request-Id"),
                    )

                return response.json()

            except httpx.TimeoutException:
                last_error = APIError("Request timed out")
            except httpx.RequestError as e:
                last_error = APIError(f"Request failed: {e}")

        raise last_error or APIError("Unknown error")

    def validate(
        self,
        tool: str,
        arguments: dict[str, Any],
        trust_level: TrustLevel = TrustLevel.VERIFIED,
        include_token: bool = True,
    ) -> ValidationResult:
        """
        Validate a tool call against policies.

        This is the main entry point for securing tool calls.

        Args:
            tool: Tool name (e.g., "file.read")
            arguments: Tool arguments
            trust_level: Trust level for this request
            include_token: Whether to include a capability token in response

        Returns:
            ValidationResult with allow/deny decision and optional token

        Example:
            result = api.validate("file.read", {"path": "/home/user/doc.txt"})
            if result.allowed:
                # Proceed with the tool call
                pass
        """
        start_time = time.time()

        response = self._request(
            "POST",
            "/validate",
            json={
                "tool": tool,
                "arguments": arguments,
                "trust_level": trust_level.value,
                "include_token": include_token,
            },
        )

        latency_ms = (time.time() - start_time) * 1000

        decision = None
        if "decision" in response:
            decision = PolicyDecision(
                effect=PolicyEffect(response["decision"]["effect"]),
                matchedRule=response["decision"].get("matched_rule"),
                reason=response["decision"]["reason"],
                evaluatedAt=response["decision"]["evaluated_at"],
            )

        return ValidationResult(
            allowed=response["allowed"],
            tool=tool,
            decision=decision,
            token=response.get("token"),
            request_id=response.get("request_id"),
            latency_ms=latency_ms,
        )

    def is_live_mode(self) -> bool:
        """Check if using live (production) API key."""
        return self._api_key.startswith("sg_live_")

    def is_test_mode(self) -> bool:
        """Check if using test (development) API key."""
        return self._api_key.startswith("sg_test_")

    def close(self) -> None:
        """Close the API client."""
        self._client.close()

    def __enter__(self) -> "SolonGateAPI":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# --- Async Version ---


class AsyncPoliciesResource:
    """Async API resource for policy management."""

    def __init__(self, client: "AsyncSolonGateAPI"):
        self._client = client

    async def get(self, policy_id: str = "default") -> PolicySet:
        """Get a policy set by ID."""
        response = await self._client._request("GET", f"/policies/{policy_id}")
        return PolicySet(**response)

    async def list(self) -> list[dict[str, Any]]:
        """List all policy sets."""
        response = await self._client._request("GET", "/policies")
        return response.get("policies", [])

    async def create(self, policy: PolicySet) -> PolicySet:
        """Create a new policy set."""
        response = await self._client._request(
            "POST", "/policies", json=policy.model_dump()
        )
        return PolicySet(**response)

    async def update(self, policy_id: str, policy: PolicySet) -> PolicySet:
        """Update an existing policy set."""
        response = await self._client._request(
            "PUT", f"/policies/{policy_id}", json=policy.model_dump()
        )
        return PolicySet(**response)


class AsyncTokensResource:
    """Async API resource for token management."""

    def __init__(self, client: "AsyncSolonGateAPI"):
        self._client = client

    async def create(
        self,
        tool: str,
        scope: str,
        ttl_seconds: int = 30,
    ) -> TokenResult:
        """Create a capability token."""
        response = await self._client._request(
            "POST",
            "/tokens",
            json={
                "tool": tool,
                "scope": scope,
                "ttl_seconds": ttl_seconds,
            },
        )
        return TokenResult(
            token=response["token"],
            tool=response["tool"],
            scope=response["scope"],
            expires_at=response["expires_at"],
            nonce=response["nonce"],
        )

    async def verify(self, token: str) -> dict[str, Any]:
        """Verify a capability token."""
        response = await self._client._request(
            "POST",
            "/tokens/verify",
            json={"token": token},
        )
        return response


class AsyncToolsResource:
    """Async API resource for tool management."""

    def __init__(self, client: "AsyncSolonGateAPI"):
        self._client = client

    async def register(
        self,
        name: str,
        description: str,
        input_schema: dict[str, Any],
        permissions: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a tool with the gateway."""
        response = await self._client._request(
            "POST",
            "/tools",
            json={
                "name": name,
                "description": description,
                "input_schema": input_schema,
                "permissions": permissions or ["READ"],
            },
        )
        return response

    async def list(self) -> list[dict[str, Any]]:
        """List registered tools."""
        response = await self._client._request("GET", "/tools")
        return response.get("tools", [])

    async def get(self, name: str) -> dict[str, Any]:
        """Get a tool by name."""
        return await self._client._request("GET", f"/tools/{name}")

    async def update(self, name: str, **kwargs: Any) -> dict[str, Any]:
        """Update a tool's configuration (e.g., enabled, permissions)."""
        return await self._client._request("PUT", f"/tools/{name}", json=kwargs)

    async def delete(self, name: str) -> dict[str, Any]:
        """Delete / unregister a tool."""
        return await self._client._request("DELETE", f"/tools/{name}")


class AsyncSolonGateAPI:
    """
    Async version of the SolonGate API client.

    Example:
        from solongate import AsyncSolonGateAPI

        async with AsyncSolonGateAPI(api_key="sg_live_xxx") as api:
            result = await api.validate("file.read", {"path": "/home/user/doc.txt"})
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        self._api_key = api_key or os.environ.get("SOLONGATE_API_KEY")
        if not self._api_key:
            raise AuthenticationError(
                "API key is required. Provide api_key parameter or set SOLONGATE_API_KEY environment variable."
            )

        if not self._api_key.startswith(("sg_live_", "sg_test_")):
            raise AuthenticationError(
                "Invalid API key format. Keys should start with 'sg_live_' or 'sg_test_'"
            )

        self._config = APIConfig(
            api_key=self._api_key,
            api_url=api_url or DEFAULT_API_URL,
            timeout=timeout,
            max_retries=max_retries,
        )

        self._client = httpx.AsyncClient(
            base_url=f"{self._config.api_url}/api/{API_VERSION}",
            timeout=timeout,
            headers={
                "X-API-Key": self._api_key,
                "Authorization": f"Bearer {self._api_key}",
                "User-Agent": f"solongate-python/{SDK_VERSION}",
                "Content-Type": "application/json",
            },
        )

        # Initialize resources
        self.policies = AsyncPoliciesResource(self)
        self.tokens = AsyncTokensResource(self)
        self.tools = AsyncToolsResource(self)

    async def _request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an async API request."""
        import asyncio

        last_error: Exception | None = None

        for attempt in range(self._config.max_retries):
            try:
                response = await self._client.request(
                    method=method,
                    url=path,
                    json=json,
                    params=params,
                )

                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 1))
                    if attempt < self._config.max_retries - 1:
                        await asyncio.sleep(retry_after)
                        continue
                    raise RateLimitError(
                        "Rate limit exceeded after retries",
                        retry_after=retry_after,
                    )

                if response.status_code == 401:
                    raise AuthenticationError("Invalid API key")

                if response.status_code >= 400:
                    error_data = response.json() if response.text else {}
                    raise APIError(
                        error_data.get("error", {}).get("message", "Unknown error"),
                        status_code=response.status_code,
                    )

                return response.json()

            except httpx.TimeoutException:
                last_error = APIError("Request timed out")
            except httpx.RequestError as e:
                last_error = APIError(f"Request failed: {e}")

        raise last_error or APIError("Unknown error")

    async def validate(
        self,
        tool: str,
        arguments: dict[str, Any],
        trust_level: TrustLevel = TrustLevel.VERIFIED,
        include_token: bool = True,
    ) -> ValidationResult:
        """Async validate a tool call."""
        start_time = time.time()

        response = await self._request(
            "POST",
            "/validate",
            json={
                "tool": tool,
                "arguments": arguments,
                "trust_level": trust_level.value,
                "include_token": include_token,
            },
        )

        latency_ms = (time.time() - start_time) * 1000

        decision = None
        if "decision" in response:
            decision = PolicyDecision(
                effect=PolicyEffect(response["decision"]["effect"]),
                matchedRule=response["decision"].get("matched_rule"),
                reason=response["decision"]["reason"],
                evaluatedAt=response["decision"]["evaluated_at"],
            )

        return ValidationResult(
            allowed=response["allowed"],
            tool=tool,
            decision=decision,
            token=response.get("token"),
            request_id=response.get("request_id"),
            latency_ms=latency_ms,
        )

    def is_live_mode(self) -> bool:
        """Check if using live (production) API key."""
        return self._api_key.startswith("sg_live_")

    def is_test_mode(self) -> bool:
        """Check if using test (development) API key."""
        return self._api_key.startswith("sg_test_")

    async def close(self) -> None:
        """Close the async client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncSolonGateAPI":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
