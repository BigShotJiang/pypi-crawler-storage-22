"""
Capability Token system for SolonGate.

Provides signed, short-lived, single-use tokens for tool execution.
Prevents replay and TOCTOU attacks.
"""

import secrets
import time
from dataclasses import dataclass
from typing import Literal

import jwt

# Constants
DEFAULT_TOKEN_TTL_SECONDS = 30
TOKEN_ALGORITHM: Literal["HS256"] = "HS256"
MIN_SECRET_LENGTH = 32


@dataclass
class TokenConfig:
    """Configuration for token issuance."""

    secret: str
    ttl_seconds: int = DEFAULT_TOKEN_TTL_SECONDS
    algorithm: str = TOKEN_ALGORITHM
    issuer: str = "solongate"


@dataclass
class CapabilityToken:
    """A signed capability token."""

    token: str
    tool: str
    scope: str
    nonce: str
    issued_at: int
    expires_at: int


@dataclass
class TokenVerificationResult:
    """Result of token verification."""

    valid: bool
    error: str | None = None
    tool: str | None = None
    scope: str | None = None
    nonce: str | None = None


class TokenIssuer:
    """Issues signed capability tokens."""

    def __init__(self, config: TokenConfig):
        if len(config.secret) < MIN_SECRET_LENGTH:
            raise ValueError(f"Secret must be at least {MIN_SECRET_LENGTH} characters")
        self._config = config
        self._used_nonces: set[str] = set()

    def issue(self, tool: str, scope: str) -> CapabilityToken:
        """
        Issue a new capability token.

        Args:
            tool: The tool name this token authorizes
            scope: The scope/permissions for this token

        Returns:
            A signed CapabilityToken
        """
        now = int(time.time())
        nonce = secrets.token_urlsafe(16)
        expires_at = now + self._config.ttl_seconds

        payload = {
            "tool": tool,
            "scope": scope,
            "nonce": nonce,
            "iat": now,
            "exp": expires_at,
            "iss": self._config.issuer,
        }

        token = jwt.encode(payload, self._config.secret, algorithm=self._config.algorithm)

        return CapabilityToken(
            token=token,
            tool=tool,
            scope=scope,
            nonce=nonce,
            issued_at=now,
            expires_at=expires_at,
        )

    def verify(self, token: str) -> TokenVerificationResult:
        """
        Verify a capability token.

        Checks:
        - Signature validity
        - Expiration
        - Nonce (single-use)

        Args:
            token: The JWT token string

        Returns:
            TokenVerificationResult with validity status
        """
        try:
            payload = jwt.decode(
                token,
                self._config.secret,
                algorithms=[self._config.algorithm],
                issuer=self._config.issuer,
            )
        except jwt.ExpiredSignatureError:
            return TokenVerificationResult(valid=False, error="Token expired")
        except jwt.InvalidTokenError as e:
            return TokenVerificationResult(valid=False, error=f"Invalid token: {e}")

        nonce = payload.get("nonce")
        if not nonce:
            return TokenVerificationResult(valid=False, error="Missing nonce")

        # Check for replay
        if nonce in self._used_nonces:
            return TokenVerificationResult(valid=False, error="Token already used (replay detected)")

        # Mark nonce as used
        self._used_nonces.add(nonce)

        # Clean up old nonces (simple GC)
        if len(self._used_nonces) > 10000:
            self._used_nonces.clear()

        return TokenVerificationResult(
            valid=True,
            tool=payload.get("tool"),
            scope=payload.get("scope"),
            nonce=nonce,
        )


class ServerVerifier:
    """Verifies incoming requests from gateway."""

    def __init__(self, gateway_secret: str):
        if len(gateway_secret) < MIN_SECRET_LENGTH:
            raise ValueError(f"Gateway secret must be at least {MIN_SECRET_LENGTH} characters")
        self._secret = gateway_secret

    def verify_signature(self, token: str, expected_tool: str | None = None) -> TokenVerificationResult:
        """
        Verify a gateway signature.

        Args:
            token: The signed token from gateway
            expected_tool: Optional expected tool name

        Returns:
            TokenVerificationResult
        """
        try:
            payload = jwt.decode(token, self._secret, algorithms=[TOKEN_ALGORITHM])
        except jwt.InvalidTokenError as e:
            return TokenVerificationResult(valid=False, error=f"Invalid signature: {e}")

        tool = payload.get("tool")
        if expected_tool and tool != expected_tool:
            return TokenVerificationResult(
                valid=False, error=f"Tool mismatch: expected {expected_tool}, got {tool}"
            )

        return TokenVerificationResult(
            valid=True,
            tool=tool,
            scope=payload.get("scope"),
            nonce=payload.get("nonce"),
        )
