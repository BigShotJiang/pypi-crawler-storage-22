"""
SolonGate Client - Main entry point for the Python SDK.

Usage:
    from solongate import SolonGate

    gate = SolonGate(api_key="sg_live_xxx")

    # Validate a tool call
    result = gate.validate("file.read", {"path": "/etc/passwd"})

    # Create a capability token
    token = gate.create_capability_token("file.read", "read")

    # Sanitize input
    sanitized = gate.sanitize(user_input)
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

from .trust import TrustLevel
from .permissions import Permission, PermissionSet, NO_PERMISSIONS, permission_for_method
from .policy import (
    PolicySet,
    PolicyDecision,
    PolicyEffect,
    create_default_deny_policy_set,
)
from .input_guard import (
    InputGuardConfig,
    SanitizationResult,
    sanitize_input,
    DEFAULT_INPUT_GUARD_CONFIG,
)
from .capability_token import TokenIssuer, TokenConfig, CapabilityToken
from .errors import PolicyDeniedError, SchemaValidationError, RateLimitError


@dataclass
class SolonGateConfig:
    """Configuration for SolonGate client."""

    api_key: str | None = None
    api_url: str = "https://api.solongate.com"
    policy_set: PolicySet | None = None
    token_secret: str | None = None
    token_ttl_seconds: int = 30
    input_guard_config: InputGuardConfig = field(default_factory=lambda: DEFAULT_INPUT_GUARD_CONFIG)
    rate_limit_per_tool: int = 100
    global_rate_limit_per_minute: int = 1000
    validate_schemas: bool = True
    verbose_errors: bool = False
    enable_logging: bool = True


class SolonGate:
    """
    SolonGate - Security Gateway for AI Tools and MCP Servers.

    Core Principles (Phase 0):
    - Trust Model: LLM is untrusted by default
    - Default-Deny: All actions denied unless explicitly allowed
    - Secure Defaults: New tools start in read-only mode

    Example:
        gate = SolonGate(api_key="sg_live_xxx")

        # Check if action is allowed
        decision = gate.evaluate("file.read", Permission.READ)

        # Sanitize untrusted input
        result = gate.sanitize(user_input)

        # Create signed capability token
        token = gate.create_capability_token("file.read", "read:/home/user")
    """

    def __init__(
        self,
        api_key: str | None = None,
        config: SolonGateConfig | None = None,
        **kwargs: Any,
    ):
        """
        Initialize SolonGate client.

        Args:
            api_key: API key for SolonGate cloud service
            config: Full configuration object
            **kwargs: Additional config options
        """
        if config:
            self._config = config
        else:
            self._config = SolonGateConfig(api_key=api_key, **kwargs)

        # Initialize policy set (default-deny if not provided)
        self._policy_set = self._config.policy_set or create_default_deny_policy_set()

        # Initialize token issuer if secret is provided
        self._token_issuer: TokenIssuer | None = None
        if self._config.token_secret:
            self._token_issuer = TokenIssuer(
                TokenConfig(
                    secret=self._config.token_secret,
                    ttl_seconds=self._config.token_ttl_seconds,
                )
            )

        # Rate limiting state
        self._tool_call_counts: dict[str, list[float]] = {}
        self._global_call_times: list[float] = []

    def evaluate(
        self,
        tool: str,
        permission: Permission,
        trust_level: TrustLevel = TrustLevel.UNTRUSTED,
    ) -> PolicyDecision:
        """
        Evaluate a tool action against the current policy set.

        Args:
            tool: Tool name
            permission: Required permission
            trust_level: Current trust level of the request

        Returns:
            PolicyDecision with ALLOW or DENY effect
        """
        now = datetime.utcnow().isoformat() + "Z"

        # Evaluate rules in priority order
        for rule in sorted(self._policy_set.rules, key=lambda r: r.priority):
            if not rule.enabled:
                continue

            # Check tool pattern match
            if not self._matches_pattern(tool, rule.tool_pattern):
                continue

            # Check permission match
            if rule.permission != permission:
                continue

            # Check trust level
            if not self._meets_trust_level(trust_level, rule.minimum_trust_level):
                continue

            return PolicyDecision(
                effect=rule.effect,
                matchedRule=rule,
                reason=f"Matched rule: {rule.id}",
                evaluatedAt=now,
            )

        # Default deny (no matching rule)
        return PolicyDecision(
            effect=PolicyEffect.DENY,
            matchedRule=None,
            reason="No matching policy rule (default deny)",
            evaluatedAt=now,
        )

    def validate(
        self,
        tool: str,
        params: dict[str, Any],
        method: str = "tools/call",
    ) -> PolicyDecision:
        """
        Validate a complete tool call.

        Runs through:
        1. Input sanitization
        2. Policy evaluation
        3. Rate limiting

        Args:
            tool: Tool name
            params: Tool parameters
            method: MCP method name

        Returns:
            PolicyDecision

        Raises:
            PolicyDeniedError: If policy denies the action
            SchemaValidationError: If input fails validation
            RateLimitError: If rate limit exceeded
        """
        # 1. Sanitize inputs
        for key, value in params.items():
            result = self.sanitize(value, field_name=key)
            if not result.safe:
                threats = ", ".join(t.message for t in result.threats)
                raise SchemaValidationError(f"Input validation failed: {threats}")

        # 2. Check rate limits
        self._check_rate_limit(tool)

        # 3. Evaluate policy
        permission = permission_for_method(method)
        decision = self.evaluate(tool, permission, TrustLevel.VERIFIED)

        if decision.effect == PolicyEffect.DENY:
            raise PolicyDeniedError(
                f"Policy denied: {decision.reason}",
                tool=tool,
                reason=decision.reason,
            )

        return decision

    def sanitize(
        self,
        value: Any,
        field_name: str | None = None,
    ) -> SanitizationResult:
        """
        Sanitize an input value.

        Args:
            value: Value to sanitize
            field_name: Optional field name for error messages

        Returns:
            SanitizationResult with safety status
        """
        return sanitize_input(value, self._config.input_guard_config, field_name)

    def create_capability_token(self, tool: str, scope: str) -> CapabilityToken:
        """
        Create a signed capability token for tool execution.

        Args:
            tool: Tool name
            scope: Permission scope

        Returns:
            Signed CapabilityToken

        Raises:
            ValueError: If token issuer not configured
        """
        if not self._token_issuer:
            raise ValueError("Token issuer not configured. Provide token_secret in config.")
        return self._token_issuer.issue(tool, scope)

    def load_policy(self, policy_set: PolicySet) -> None:
        """Load a new policy set."""
        self._policy_set = policy_set

    def get_policy(self) -> PolicySet:
        """Get the current policy set."""
        return self._policy_set

    def _matches_pattern(self, tool: str, pattern: str) -> bool:
        """Check if tool matches a pattern (supports * wildcard)."""
        if pattern == "*":
            return True
        if pattern.endswith("*"):
            return tool.startswith(pattern[:-1])
        if pattern.startswith("*"):
            return tool.endswith(pattern[1:])
        return tool == pattern

    def _meets_trust_level(self, current: TrustLevel, required: TrustLevel) -> bool:
        """Check if current trust level meets or exceeds required."""
        levels = [TrustLevel.UNTRUSTED, TrustLevel.VERIFIED, TrustLevel.TRUSTED]
        return levels.index(current) >= levels.index(required)

    def _check_rate_limit(self, tool: str) -> None:
        """Check and enforce rate limits."""
        import time

        now = time.time()
        window = 60  # 1 minute

        # Clean old entries
        self._global_call_times = [t for t in self._global_call_times if now - t < window]

        # Global rate limit
        if len(self._global_call_times) >= self._config.global_rate_limit_per_minute:
            raise RateLimitError(
                "Global rate limit exceeded",
                limit=self._config.global_rate_limit_per_minute,
                window_seconds=window,
            )

        # Per-tool rate limit
        if tool not in self._tool_call_counts:
            self._tool_call_counts[tool] = []
        self._tool_call_counts[tool] = [
            t for t in self._tool_call_counts[tool] if now - t < window
        ]

        if len(self._tool_call_counts[tool]) >= self._config.rate_limit_per_tool:
            raise RateLimitError(
                f"Rate limit exceeded for tool: {tool}",
                limit=self._config.rate_limit_per_tool,
                window_seconds=window,
            )

        # Record this call
        self._global_call_times.append(now)
        self._tool_call_counts[tool].append(now)
