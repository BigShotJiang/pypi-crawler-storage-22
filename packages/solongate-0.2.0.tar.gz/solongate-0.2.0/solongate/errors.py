"""
SolonGate custom exceptions.

All security-related errors inherit from SolonGateError.
"""


class SolonGateError(Exception):
    """Base exception for all SolonGate errors."""

    def __init__(self, message: str, code: str | None = None):
        super().__init__(message)
        self.message = message
        self.code = code or "SOLONGATE_ERROR"


class PolicyDeniedError(SolonGateError):
    """Raised when a policy denies an action."""

    def __init__(self, message: str, tool: str | None = None, reason: str | None = None):
        super().__init__(message, code="POLICY_DENIED")
        self.tool = tool
        self.reason = reason


class TrustEscalationError(SolonGateError):
    """Raised when an invalid trust level escalation is attempted."""

    def __init__(self, message: str):
        super().__init__(message, code="TRUST_ESCALATION")


class SchemaValidationError(SolonGateError):
    """Raised when input fails schema validation."""

    def __init__(self, message: str, errors: list[dict] | None = None):
        super().__init__(message, code="SCHEMA_VALIDATION")
        self.errors = errors or []


class RateLimitError(SolonGateError):
    """Raised when rate limit is exceeded."""

    def __init__(
        self,
        message: str,
        limit: int | None = None,
        window_seconds: int | None = None,
        retry_after: int | None = None,
    ):
        super().__init__(message, code="RATE_LIMIT")
        self.limit = limit
        self.window_seconds = window_seconds
        self.retry_after = retry_after


class ToolNotFoundError(SolonGateError):
    """Raised when a requested tool is not found."""

    def __init__(self, message: str, tool: str | None = None):
        super().__init__(message, code="TOOL_NOT_FOUND")
        self.tool = tool


class UnsafeConfigurationError(SolonGateError):
    """Raised when an unsafe configuration is detected."""

    def __init__(self, message: str, config_key: str | None = None):
        super().__init__(message, code="UNSAFE_CONFIG")
        self.config_key = config_key
