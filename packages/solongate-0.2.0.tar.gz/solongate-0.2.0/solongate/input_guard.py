"""
Input Guard and Sanitization for SolonGate.

Protects against:
- Path traversal attacks
- Shell injection
- Wildcard abuse
- Length and entropy limits
"""

import math
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ThreatType(str, Enum):
    """Types of detected threats."""

    PATH_TRAVERSAL = "PATH_TRAVERSAL"
    SHELL_INJECTION = "SHELL_INJECTION"
    WILDCARD_ABUSE = "WILDCARD_ABUSE"
    LENGTH_EXCEEDED = "LENGTH_EXCEEDED"
    HIGH_ENTROPY = "HIGH_ENTROPY"


@dataclass
class DetectedThreat:
    """A detected security threat."""

    threat_type: ThreatType
    message: str
    value: str | None = None
    field: str | None = None


@dataclass
class SanitizationResult:
    """Result of input sanitization."""

    safe: bool
    threats: list[DetectedThreat] = field(default_factory=list)
    sanitized_value: Any = None


@dataclass
class InputGuardConfig:
    """Configuration for input guard."""

    max_string_length: int = 10000
    max_path_length: int = 4096
    max_entropy: float = 4.5
    block_path_traversal: bool = True
    block_shell_chars: bool = True
    block_wildcards: bool = True


DEFAULT_INPUT_GUARD_CONFIG = InputGuardConfig()


# Dangerous shell characters
SHELL_CHARS = set(";|&$`\\!<>(){}[]'\"\n\r")

# Path traversal patterns
PATH_TRAVERSAL_PATTERNS = [
    r"\.\./",
    r"\.\.\\",
    r"/\.\.",
    r"\\\.\.",
    r"^/etc/",
    r"^/proc/",
    r"^/sys/",
    r"^/dev/",
    r"^~",
]


def calculate_entropy(s: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not s:
        return 0.0

    freq = {}
    for char in s:
        freq[char] = freq.get(char, 0) + 1

    length = len(s)
    entropy = 0.0
    for count in freq.values():
        p = count / length
        entropy -= p * math.log2(p)

    return entropy


def detect_path_traversal(value: str, field_name: str | None = None) -> DetectedThreat | None:
    """Detect path traversal attempts."""
    for pattern in PATH_TRAVERSAL_PATTERNS:
        if re.search(pattern, value, re.IGNORECASE):
            return DetectedThreat(
                threat_type=ThreatType.PATH_TRAVERSAL,
                message=f"Path traversal pattern detected: {pattern}",
                value=value[:100],
                field=field_name,
            )
    return None


def detect_shell_injection(value: str, field_name: str | None = None) -> DetectedThreat | None:
    """Detect shell injection attempts."""
    found_chars = [c for c in value if c in SHELL_CHARS]
    if found_chars:
        return DetectedThreat(
            threat_type=ThreatType.SHELL_INJECTION,
            message=f"Shell metacharacters detected: {', '.join(repr(c) for c in set(found_chars))}",
            value=value[:100],
            field=field_name,
        )
    return None


def detect_wildcard_abuse(value: str, field_name: str | None = None) -> DetectedThreat | None:
    """Detect wildcard abuse patterns."""
    # Multiple consecutive wildcards
    if "**" in value or "??" in value:
        return DetectedThreat(
            threat_type=ThreatType.WILDCARD_ABUSE,
            message="Multiple consecutive wildcards detected",
            value=value[:100],
            field=field_name,
        )

    # Too many wildcards
    wildcard_count = value.count("*") + value.count("?")
    if wildcard_count > 3:
        return DetectedThreat(
            threat_type=ThreatType.WILDCARD_ABUSE,
            message=f"Too many wildcards ({wildcard_count})",
            value=value[:100],
            field=field_name,
        )

    return None


def check_length_limits(
    value: str,
    config: InputGuardConfig,
    field_name: str | None = None,
    is_path: bool = False,
) -> DetectedThreat | None:
    """Check string length limits."""
    max_len = config.max_path_length if is_path else config.max_string_length
    if len(value) > max_len:
        return DetectedThreat(
            threat_type=ThreatType.LENGTH_EXCEEDED,
            message=f"String length ({len(value)}) exceeds limit ({max_len})",
            value=value[:100],
            field=field_name,
        )
    return None


def check_entropy_limits(
    value: str,
    config: InputGuardConfig,
    field_name: str | None = None,
) -> DetectedThreat | None:
    """Check string entropy limits (detects encoded/obfuscated payloads)."""
    if len(value) < 20:  # Skip short strings
        return None

    entropy = calculate_entropy(value)
    if entropy > config.max_entropy:
        return DetectedThreat(
            threat_type=ThreatType.HIGH_ENTROPY,
            message=f"High entropy ({entropy:.2f}) suggests encoded/obfuscated content",
            value=value[:100],
            field=field_name,
        )
    return None


def sanitize_input(
    value: Any,
    config: InputGuardConfig | None = None,
    field_name: str | None = None,
) -> SanitizationResult:
    """
    Sanitize an input value against all configured checks.

    Args:
        value: The value to sanitize
        config: Configuration for the input guard
        field_name: Optional field name for error messages

    Returns:
        SanitizationResult with safety status and any detected threats
    """
    if config is None:
        config = DEFAULT_INPUT_GUARD_CONFIG

    threats: list[DetectedThreat] = []

    # Only check strings
    if not isinstance(value, str):
        return SanitizationResult(safe=True, threats=[], sanitized_value=value)

    # Length check
    length_threat = check_length_limits(value, config, field_name)
    if length_threat:
        threats.append(length_threat)

    # Path traversal
    if config.block_path_traversal:
        path_threat = detect_path_traversal(value, field_name)
        if path_threat:
            threats.append(path_threat)

    # Shell injection
    if config.block_shell_chars:
        shell_threat = detect_shell_injection(value, field_name)
        if shell_threat:
            threats.append(shell_threat)

    # Wildcard abuse
    if config.block_wildcards:
        wildcard_threat = detect_wildcard_abuse(value, field_name)
        if wildcard_threat:
            threats.append(wildcard_threat)

    # Entropy check
    entropy_threat = check_entropy_limits(value, config, field_name)
    if entropy_threat:
        threats.append(entropy_threat)

    return SanitizationResult(
        safe=len(threats) == 0,
        threats=threats,
        sanitized_value=value if len(threats) == 0 else None,
    )
