"""
MCP Interceptor for SolonGate.

Intercepts MCP protocol calls and enforces security policies.
Full 9-step pipeline matching TypeScript implementation:

1. Rate limit check (per-tool)
2. Global rate limit check
3. Input guard (sanitization)
4. Schema validation
5. Policy evaluation
6. Issue capability token
7. Sign request (ServerVerifier)
8. Record rate limit usage
9. Audit log

This is the main integration point between SolonGate and MCP servers.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Awaitable

from .client import SolonGate, SolonGateConfig
from .trust import TrustLevel
from .permissions import Permission, permission_for_method
from .policy import PolicyDecision, PolicyEffect
from .schema_validator import (
    ToolRegistry,
    SchemaValidationResult,
    get_global_registry,
)
from .input_guard import sanitize_input, SanitizationResult
from .capability_token import CapabilityToken
from .rate_limiter import RateLimiter
from .errors import (
    PolicyDeniedError,
    SchemaValidationError,
    RateLimitError,
    ToolNotFoundError,
)


class InterceptorMode(str, Enum):
    """Operating mode for the interceptor."""

    ENFORCE = "ENFORCE"  # Block requests that fail validation
    AUDIT = "AUDIT"  # Log but allow requests (for migration)
    PASSTHROUGH = "PASSTHROUGH"  # Disabled (development only)


@dataclass
class InterceptedRequest:
    """Represents an intercepted MCP request."""

    method: str
    tool: str
    params: dict[str, Any]
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")
    request_id: str | None = None


@dataclass
class InterceptionResult:
    """Result of intercepting a request."""

    allowed: bool
    request: InterceptedRequest
    decision: PolicyDecision | None = None
    validation: SchemaValidationResult | None = None
    sanitization: SanitizationResult | None = None
    token: CapabilityToken | None = None
    error: str | None = None
    audit_log: dict[str, Any] = field(default_factory=dict)


@dataclass
class InterceptorConfig:
    """Configuration for the MCP interceptor."""

    mode: InterceptorMode = InterceptorMode.ENFORCE
    validate_schemas: bool = True
    sanitize_inputs: bool = True
    require_capability_token: bool = True
    log_requests: bool = True
    log_decisions: bool = True
    rate_limiter: RateLimiter | None = None
    rate_limit_per_tool: int | None = None
    global_rate_limit_per_minute: int | None = None


class MCPInterceptor:
    """
    Intercepts MCP protocol calls and enforces SolonGate security policies.

    Usage:
        gate = SolonGate(config=SolonGateConfig(...))
        interceptor = MCPInterceptor(gate)

        # Intercept a tool call
        result = interceptor.intercept("tools/call", "file.read", {"path": "/etc/passwd"})
        if result.allowed:
            # Proceed with the call using result.token
            pass
        else:
            # Handle denial
            print(f"Denied: {result.error}")
    """

    def __init__(
        self,
        gate: SolonGate,
        config: InterceptorConfig | None = None,
        registry: ToolRegistry | None = None,
    ):
        """
        Initialize the MCP interceptor.

        Args:
            gate: SolonGate instance for policy evaluation
            config: Interceptor configuration
            registry: Tool registry for schema validation (uses global if not provided)
        """
        self._gate = gate
        self._config = config or InterceptorConfig()
        self._registry = registry or get_global_registry()
        self._audit_log: list[dict[str, Any]] = []

    def intercept(
        self,
        method: str,
        tool: str,
        params: dict[str, Any],
        trust_level: TrustLevel = TrustLevel.UNTRUSTED,
        request_id: str | None = None,
    ) -> InterceptionResult:
        """
        Intercept and validate an MCP request.

        Full 9-step pipeline:
        1. Rate limit check (per-tool)
        2. Global rate limit check
        3. Input sanitization
        4. Schema validation
        5. Policy evaluation
        6. Issue capability token
        7. Sign request (ServerVerifier) — reserved
        8. Record rate limit usage
        9. Audit log

        Args:
            method: MCP method (e.g., "tools/call")
            tool: Tool name
            params: Tool parameters
            trust_level: Current trust level of the request
            request_id: Optional request ID for tracking

        Returns:
            InterceptionResult with validation status and capability token
        """
        request = InterceptedRequest(
            method=method,
            tool=tool,
            params=params,
            request_id=request_id,
        )

        audit_entry: dict[str, Any] = {
            "timestamp": request.timestamp,
            "method": method,
            "tool": tool,
            "request_id": request_id,
            "trust_level": trust_level.value,
        }

        # Passthrough mode - skip all checks
        if self._config.mode == InterceptorMode.PASSTHROUGH:
            audit_entry["decision"] = "PASSTHROUGH"
            self._log_audit(audit_entry)
            return InterceptionResult(
                allowed=True,
                request=request,
                audit_log=audit_entry,
            )

        try:
            # --- Step 1: Per-tool rate limit check ---
            rate_limiter = self._config.rate_limiter
            if rate_limiter and self._config.rate_limit_per_tool:
                check = rate_limiter.check_limit(tool, self._config.rate_limit_per_tool)
                if not check.allowed:
                    audit_entry["decision"] = "DENIED"
                    audit_entry["reason"] = "rate_limit_per_tool"
                    self._log_audit(audit_entry)
                    return InterceptionResult(
                        allowed=False,
                        request=request,
                        error=f'Rate limit exceeded for tool "{tool}"',
                        audit_log=audit_entry,
                    )

            # --- Step 2: Global rate limit check ---
            if rate_limiter and self._config.global_rate_limit_per_minute:
                check = rate_limiter.check_global_limit(self._config.global_rate_limit_per_minute)
                if not check.allowed:
                    audit_entry["decision"] = "DENIED"
                    audit_entry["reason"] = "global_rate_limit"
                    self._log_audit(audit_entry)
                    return InterceptionResult(
                        allowed=False,
                        request=request,
                        error="Global rate limit exceeded",
                        audit_log=audit_entry,
                    )

            # --- Step 3: Input sanitization (if enabled) ---
            sanitization_result: SanitizationResult | None = None
            if self._config.sanitize_inputs:
                threats_found = []
                for key, value in params.items():
                    result = sanitize_input(value, field_name=key)
                    if not result.safe:
                        threats_found.extend(result.threats)

                if threats_found:
                    sanitization_result = SanitizationResult(
                        safe=False,
                        threats=threats_found,
                    )
                    error = f"Input sanitization failed: {', '.join(t.message for t in threats_found)}"
                    audit_entry["sanitization"] = "FAILED"
                    audit_entry["threats"] = [t.threat_type.value for t in threats_found]

                    if self._config.mode == InterceptorMode.ENFORCE:
                        audit_entry["decision"] = "DENIED"
                        self._log_audit(audit_entry)
                        return InterceptionResult(
                            allowed=False,
                            request=request,
                            sanitization=sanitization_result,
                            error=error,
                            audit_log=audit_entry,
                        )
                else:
                    audit_entry["sanitization"] = "PASSED"
                    sanitization_result = SanitizationResult(safe=True)

            # --- Step 4: Schema validation (if enabled and tool is registered) ---
            validation_result: SchemaValidationResult | None = None
            if self._config.validate_schemas and self._registry.has_tool(tool):
                validation_result = self._registry.validate_input(tool, params)
                if not validation_result.valid:
                    error = f"Schema validation failed: {', '.join(validation_result.errors)}"
                    audit_entry["validation"] = "FAILED"
                    audit_entry["validation_errors"] = validation_result.errors

                    if self._config.mode == InterceptorMode.ENFORCE:
                        audit_entry["decision"] = "DENIED"
                        self._log_audit(audit_entry)
                        return InterceptionResult(
                            allowed=False,
                            request=request,
                            validation=validation_result,
                            error=error,
                            audit_log=audit_entry,
                        )
                else:
                    audit_entry["validation"] = "PASSED"

            # --- Step 5: Policy evaluation ---
            permission = permission_for_method(method)
            decision = self._gate.evaluate(tool, permission, trust_level)
            audit_entry["policy_decision"] = decision.effect.value
            audit_entry["matched_rule"] = decision.matched_rule.id if decision.matched_rule else None

            if decision.effect == PolicyEffect.DENY:
                error = f"Policy denied: {decision.reason}"

                if self._config.mode == InterceptorMode.ENFORCE:
                    audit_entry["decision"] = "DENIED"
                    self._log_audit(audit_entry)
                    return InterceptionResult(
                        allowed=False,
                        request=request,
                        decision=decision,
                        validation=validation_result,
                        sanitization=sanitization_result,
                        error=error,
                        audit_log=audit_entry,
                    )

            # --- Step 6: Generate capability token (if configured) ---
            token: CapabilityToken | None = None
            if self._config.require_capability_token:
                try:
                    scope = f"{permission.value}:{tool}"
                    token = self._gate.create_capability_token(tool, scope)
                    audit_entry["token_issued"] = True
                except ValueError:
                    # Token issuer not configured
                    audit_entry["token_issued"] = False

            # --- Step 7: Sign request (reserved for ServerVerifier integration) ---
            # When a ServerVerifier is configured on the gateway, the token
            # and request params would be signed here before forwarding to
            # the upstream MCP server.

            # --- Step 8: Record rate limit usage ---
            if rate_limiter:
                rate_limiter.record_call(tool)

            # --- Step 9: Audit log ---
            audit_entry["decision"] = "ALLOWED"
            self._log_audit(audit_entry)

            return InterceptionResult(
                allowed=True,
                request=request,
                decision=decision,
                validation=validation_result,
                sanitization=sanitization_result,
                token=token,
                audit_log=audit_entry,
            )

        except Exception as e:
            audit_entry["decision"] = "ERROR"
            audit_entry["error"] = str(e)
            self._log_audit(audit_entry)

            if self._config.mode == InterceptorMode.ENFORCE:
                return InterceptionResult(
                    allowed=False,
                    request=request,
                    error=f"Interception error: {e}",
                    audit_log=audit_entry,
                )
            else:
                # In AUDIT mode, allow even on errors
                return InterceptionResult(
                    allowed=True,
                    request=request,
                    error=f"Interception error (audit mode): {e}",
                    audit_log=audit_entry,
                )

    def _log_audit(self, entry: dict[str, Any]) -> None:
        """Log an audit entry."""
        if self._config.log_decisions:
            self._audit_log.append(entry)

    def get_audit_log(self) -> list[dict[str, Any]]:
        """Get the audit log."""
        return self._audit_log.copy()

    def clear_audit_log(self) -> None:
        """Clear the audit log."""
        self._audit_log.clear()


# --- Async Support ---


class AsyncMCPInterceptor:
    """
    Async version of MCP interceptor for use with async MCP servers.
    """

    def __init__(
        self,
        gate: SolonGate,
        config: InterceptorConfig | None = None,
        registry: ToolRegistry | None = None,
    ):
        self._sync_interceptor = MCPInterceptor(gate, config, registry)

    async def intercept(
        self,
        method: str,
        tool: str,
        params: dict[str, Any],
        trust_level: TrustLevel = TrustLevel.UNTRUSTED,
        request_id: str | None = None,
    ) -> InterceptionResult:
        """Async intercept - delegates to sync implementation."""
        # The actual interception logic is CPU-bound, not I/O-bound
        # So we can safely call the sync version
        return self._sync_interceptor.intercept(
            method, tool, params, trust_level, request_id
        )

    def get_audit_log(self) -> list[dict[str, Any]]:
        return self._sync_interceptor.get_audit_log()

    def clear_audit_log(self) -> None:
        self._sync_interceptor.clear_audit_log()


# --- Decorator for MCP tool handlers ---


def protected_tool(
    interceptor: MCPInterceptor,
    tool_name: str,
    trust_level: TrustLevel = TrustLevel.UNTRUSTED,
):
    """
    Decorator to protect an MCP tool handler with SolonGate validation.

    Usage:
        @protected_tool(interceptor, "file.read")
        def handle_file_read(params: dict) -> dict:
            # Handler code
            return {"content": "..."}
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(params: dict[str, Any], *args: Any, **kwargs: Any) -> Any:
            result = interceptor.intercept(
                method="tools/call",
                tool=tool_name,
                params=params,
                trust_level=trust_level,
            )

            if not result.allowed:
                raise PolicyDeniedError(
                    result.error or "Access denied",
                    tool=tool_name,
                    reason=result.error,
                )

            return func(params, *args, **kwargs)

        return wrapper

    return decorator


def async_protected_tool(
    interceptor: AsyncMCPInterceptor,
    tool_name: str,
    trust_level: TrustLevel = TrustLevel.UNTRUSTED,
):
    """
    Async decorator to protect an MCP tool handler with SolonGate validation.

    Usage:
        @async_protected_tool(interceptor, "file.read")
        async def handle_file_read(params: dict) -> dict:
            # Handler code
            return {"content": "..."}
    """

    def decorator(func: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        async def wrapper(params: dict[str, Any], *args: Any, **kwargs: Any) -> Any:
            result = await interceptor.intercept(
                method="tools/call",
                tool=tool_name,
                params=params,
                trust_level=trust_level,
            )

            if not result.allowed:
                raise PolicyDeniedError(
                    result.error or "Access denied",
                    tool=tool_name,
                    reason=result.error,
                )

            return await func(params, *args, **kwargs)

        return wrapper

    return decorator
