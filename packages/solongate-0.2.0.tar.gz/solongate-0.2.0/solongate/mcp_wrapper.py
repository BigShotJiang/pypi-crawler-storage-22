"""
MCP SDK Wrapper for SolonGate.

Provides drop-in security wrapper for MCP servers and clients.
Works with the official MCP Python SDK.

Usage (Server):
    from mcp.server import Server
    from solongate.mcp_wrapper import SecureMCPServer

    # Wrap your MCP server
    server = Server("my-server")
    secure_server = SecureMCPServer(server, gateway_secret="your-secret...")

    # Register tools as normal - they're automatically protected
    @secure_server.tool()
    def read_file(path: str) -> str:
        return open(path).read()

Usage (Client):
    from mcp import ClientSession
    from solongate.mcp_wrapper import SecureMCPClient

    secure_client = SecureMCPClient(session, token_secret="your-secret...")
    result = await secure_client.call_tool("read_file", {"path": "/home/user/doc.txt"})
"""

from dataclasses import dataclass
from typing import Any, Callable, Awaitable, TypeVar
from functools import wraps

from .client import SolonGate, SolonGateConfig
from .trust import TrustLevel
from .permissions import Permission
from .policy import PolicySet, create_default_deny_policy_set, create_read_only_policy_set
from .mcp_interceptor import MCPInterceptor, InterceptorConfig, InterceptorMode
from .server_verifier import ServerVerifier, VerificationConfig
from .capability_token import TokenIssuer, TokenConfig
from .schema_validator import ToolRegistry, StrictSchema
from .path_matcher import PathConstraints, is_path_allowed
from .errors import PolicyDeniedError, SchemaValidationError

T = TypeVar("T")


@dataclass
class SecureServerConfig:
    """Configuration for secure MCP server."""

    gateway_secret: str
    policy_set: PolicySet | None = None
    path_constraints: PathConstraints | None = None
    enforce_tokens: bool = True
    audit_logging: bool = True


@dataclass
class SecureClientConfig:
    """Configuration for secure MCP client."""

    token_secret: str
    policy_set: PolicySet | None = None
    mode: InterceptorMode = InterceptorMode.ENFORCE
    rate_limit_per_tool: int = 100
    global_rate_limit: int = 1000


class SecureMCPServer:
    """
    Security wrapper for MCP servers.

    Wraps an existing MCP server and adds:
    - Token verification for incoming requests
    - Path-level access control
    - Audit logging
    - Automatic tool protection

    Example:
        from mcp.server import Server
        from solongate.mcp_wrapper import SecureMCPServer, SecureServerConfig

        server = Server("my-server")
        config = SecureServerConfig(gateway_secret="your-32-char-secret...")

        secure = SecureMCPServer(server, config)

        @secure.tool()
        async def read_file(path: str) -> str:
            # Automatically protected - token verified, path checked
            return open(path).read()
    """

    def __init__(self, mcp_server: Any, config: SecureServerConfig):
        self._server = mcp_server
        self._config = config
        self._verifier = ServerVerifier(
            VerificationConfig(gateway_secret=config.gateway_secret)
        )
        self._registry = ToolRegistry()
        self._audit_log: list[dict[str, Any]] = []

    def tool(
        self,
        name: str | None = None,
        description: str | None = None,
        schema: type[StrictSchema] | None = None,
    ) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
        """
        Decorator to register a protected tool.

        Args:
            name: Tool name (defaults to function name)
            description: Tool description
            schema: Optional Pydantic schema for input validation
        """

        def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
            tool_name = name or func.__name__
            tool_desc = description or func.__doc__ or ""

            # Register schema if provided
            if schema:
                self._registry.register(tool_name, tool_desc, schema)

            @wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> T:
                # Extract token from context (implementation depends on MCP SDK)
                token = kwargs.pop("_solongate_token", None)

                # Verify token if enforcement is enabled
                if self._config.enforce_tokens:
                    if not token:
                        self._log_audit(tool_name, "DENIED", "Missing token")
                        raise PolicyDeniedError(
                            "Missing capability token",
                            tool=tool_name,
                            reason="No token provided",
                        )

                    result = self._verifier.verify_request(token, expected_tool=tool_name)
                    if not result.valid:
                        self._log_audit(tool_name, "DENIED", result.error)
                        raise PolicyDeniedError(
                            f"Token verification failed: {result.error}",
                            tool=tool_name,
                            reason=result.error,
                        )

                # Check path constraints if configured
                if self._config.path_constraints:
                    path_args = self._extract_paths(kwargs)
                    for path in path_args:
                        if not is_path_allowed(path, self._config.path_constraints):
                            self._log_audit(tool_name, "DENIED", f"Path not allowed: {path}")
                            raise PolicyDeniedError(
                                f"Path access denied: {path}",
                                tool=tool_name,
                                reason="Path not in allowed scope",
                            )

                # Validate schema if registered
                if self._registry.has_tool(tool_name):
                    validation = self._registry.validate_input(tool_name, kwargs)
                    if not validation.valid:
                        self._log_audit(tool_name, "DENIED", f"Schema validation: {validation.errors}")
                        raise SchemaValidationError(
                            f"Input validation failed: {validation.errors}"
                        )

                # Execute the tool
                self._log_audit(tool_name, "ALLOWED", "Execution permitted")
                return await func(*args, **kwargs)

            # Register with underlying MCP server
            if hasattr(self._server, "tool"):
                # MCP SDK style registration
                return self._server.tool(name=tool_name, description=tool_desc)(wrapper)

            return wrapper

        return decorator

    def _extract_paths(self, kwargs: dict[str, Any]) -> list[str]:
        """Extract path-like arguments from kwargs."""
        paths = []
        for value in kwargs.values():
            if isinstance(value, str) and ("/" in value or "\\" in value):
                paths.append(value)
        return paths

    def _log_audit(self, tool: str, decision: str, reason: str) -> None:
        """Log an audit entry."""
        if self._config.audit_logging:
            from datetime import datetime, timezone

            self._audit_log.append({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "tool": tool,
                "decision": decision,
                "reason": reason,
            })

    def get_audit_log(self) -> list[dict[str, Any]]:
        """Get the audit log."""
        return self._audit_log.copy()


class SecureMCPClient:
    """
    Security wrapper for MCP clients.

    Wraps MCP client calls with:
    - Policy evaluation before calls
    - Input sanitization
    - Automatic token injection
    - Rate limiting

    Example:
        from mcp import ClientSession
        from solongate.mcp_wrapper import SecureMCPClient, SecureClientConfig

        async with ClientSession(...) as session:
            config = SecureClientConfig(token_secret="your-32-char-secret...")
            client = SecureMCPClient(session, config)

            # Calls are automatically secured
            result = await client.call_tool("read_file", {"path": "/home/user/doc.txt"})
    """

    def __init__(self, mcp_session: Any, config: SecureClientConfig):
        self._session = mcp_session
        self._config = config

        gate_config = SolonGateConfig(
            policy_set=config.policy_set or create_read_only_policy_set("*"),
            token_secret=config.token_secret,
            rate_limit_per_tool=config.rate_limit_per_tool,
            global_rate_limit_per_minute=config.global_rate_limit,
        )
        self._gate = SolonGate(config=gate_config)

        self._interceptor = MCPInterceptor(
            self._gate,
            InterceptorConfig(mode=config.mode),
        )

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        trust_level: TrustLevel = TrustLevel.VERIFIED,
    ) -> Any:
        """
        Call an MCP tool with security enforcement.

        Args:
            name: Tool name
            arguments: Tool arguments
            trust_level: Trust level for this request

        Returns:
            Tool result

        Raises:
            PolicyDeniedError: If policy denies the call
            SchemaValidationError: If input validation fails
            RateLimitError: If rate limit exceeded
        """
        args = arguments or {}

        # Run through security pipeline
        result = self._interceptor.intercept(
            method="tools/call",
            tool=name,
            params=args,
            trust_level=trust_level,
        )

        if not result.allowed:
            raise PolicyDeniedError(
                result.error or "Access denied",
                tool=name,
                reason=result.error,
            )

        # Inject token into request if available
        call_args = args.copy()
        if result.token:
            call_args["_solongate_token"] = result.token.token

        # Call the actual MCP tool
        if hasattr(self._session, "call_tool"):
            return await self._session.call_tool(name, call_args)
        else:
            raise NotImplementedError("MCP session does not support call_tool")

    async def list_tools(self) -> Any:
        """List available tools from the MCP server."""
        if hasattr(self._session, "list_tools"):
            return await self._session.list_tools()
        raise NotImplementedError("MCP session does not support list_tools")

    async def read_resource(self, uri: str) -> Any:
        """Read a resource with security checks."""
        # Intercept as a read operation
        result = self._interceptor.intercept(
            method="resources/read",
            tool="resource",
            params={"uri": uri},
            trust_level=TrustLevel.VERIFIED,
        )

        if not result.allowed:
            raise PolicyDeniedError(
                result.error or "Access denied",
                tool="resource",
                reason=result.error,
            )

        if hasattr(self._session, "read_resource"):
            return await self._session.read_resource(uri)
        raise NotImplementedError("MCP session does not support read_resource")

    def get_audit_log(self) -> list[dict[str, Any]]:
        """Get the interceptor's audit log."""
        return self._interceptor.get_audit_log()


# --- Convenience functions ---


def create_secure_server(
    mcp_server: Any,
    gateway_secret: str,
    allowed_paths: list[str] | None = None,
    denied_paths: list[str] | None = None,
    root_directory: str | None = None,
) -> SecureMCPServer:
    """
    Create a secure MCP server with common defaults.

    Args:
        mcp_server: The underlying MCP server
        gateway_secret: Secret for token verification (min 32 chars)
        allowed_paths: Glob patterns for allowed paths
        denied_paths: Glob patterns for denied paths
        root_directory: Root directory for sandboxing

    Returns:
        SecureMCPServer instance
    """
    path_constraints = None
    if allowed_paths or denied_paths or root_directory:
        path_constraints = PathConstraints(
            root_directory=root_directory,
            allowed=allowed_paths,
            denied=denied_paths,
        )

    config = SecureServerConfig(
        gateway_secret=gateway_secret,
        path_constraints=path_constraints,
    )

    return SecureMCPServer(mcp_server, config)


def create_secure_client(
    mcp_session: Any,
    token_secret: str,
    policy_set: PolicySet | None = None,
    mode: InterceptorMode = InterceptorMode.ENFORCE,
) -> SecureMCPClient:
    """
    Create a secure MCP client with common defaults.

    Args:
        mcp_session: The underlying MCP session
        token_secret: Secret for token signing (min 32 chars)
        policy_set: Policy set to enforce (defaults to read-only)
        mode: Enforcement mode (ENFORCE, AUDIT, or PASSTHROUGH)

    Returns:
        SecureMCPClient instance
    """
    config = SecureClientConfig(
        token_secret=token_secret,
        policy_set=policy_set,
        mode=mode,
    )

    return SecureMCPClient(mcp_session, config)
