"""
Path Matching and Isolation for SolonGate.

Provides path-level access control:
- Glob-style pattern matching (*, **)
- Root directory sandboxing
- Allow/deny list evaluation
- Path normalization

Does NOT use regex to prevent ReDoS attacks.
"""

from dataclasses import dataclass


@dataclass
class PathConstraints:
    """Constraints for path-based access control."""

    root_directory: str | None = None
    allowed: list[str] | None = None
    denied: list[str] | None = None


def normalize_path(path: str) -> str:
    """
    Normalizes a file path for consistent matching.
    Resolves . and .. segments, normalizes separators.
    """
    # Normalize separators to forward slash
    normalized = path.replace("\\", "/")

    # Remove trailing slash (except for root)
    if len(normalized) > 1 and normalized.endswith("/"):
        normalized = normalized[:-1]

    # Resolve . and .. segments
    parts = normalized.split("/")
    resolved: list[str] = []

    for part in parts:
        if part == "." or part == "":
            if not resolved:
                resolved.append("")
            continue
        if part == "..":
            if len(resolved) > 1:
                resolved.pop()
            continue
        resolved.append(part)

    return "/".join(resolved) or "/"


def is_within_root(path: str, root: str) -> bool:
    """
    Checks if a path is within a root directory (sandbox boundary).
    Prevents escaping via .., symlinks, etc.

    Args:
        path: The path to check
        root: The root directory boundary

    Returns:
        True if path is within root, False otherwise
    """
    normalized_path = normalize_path(path)
    normalized_root = normalize_path(root)

    # Path must start with root
    if normalized_path == normalized_root:
        return True
    return normalized_path.startswith(normalized_root + "/")


def match_path_pattern(path: str, pattern: str) -> bool:
    """
    Glob-style path pattern matching.

    Supports:
    - * matches any single path segment (not /)
    - ** matches any number of path segments
    - Exact match

    Does NOT support regex (ReDoS prevention).

    Args:
        path: The path to match
        pattern: The glob pattern

    Returns:
        True if path matches pattern
    """
    normalized_path = normalize_path(path)
    normalized_pattern = normalize_path(pattern)

    if normalized_pattern == "*":
        return True
    if normalized_pattern == normalized_path:
        return True

    pattern_parts = normalized_pattern.split("/")
    path_parts = normalized_path.split("/")

    return _match_parts(path_parts, 0, pattern_parts, 0)


def _match_parts(
    path_parts: list[str],
    pi: int,
    pattern_parts: list[str],
    qi: int,
) -> bool:
    """Recursive helper for path matching."""
    while pi < len(path_parts) and qi < len(pattern_parts):
        pattern = pattern_parts[qi]

        if pattern == "**":
            # ** can match zero or more path segments
            if qi == len(pattern_parts) - 1:
                return True

            # Try matching ** against 0, 1, 2, ... path segments
            for i in range(pi, len(path_parts) + 1):
                if _match_parts(path_parts, i, pattern_parts, qi + 1):
                    return True
            return False

        if pattern == "*":
            # * matches exactly one path segment
            pi += 1
            qi += 1
            continue

        if pattern != path_parts[pi]:
            return False

        pi += 1
        qi += 1

    # Skip trailing ** patterns
    while qi < len(pattern_parts) and pattern_parts[qi] == "**":
        qi += 1

    return pi == len(path_parts) and qi == len(pattern_parts)


def is_path_allowed(path: str, constraints: PathConstraints) -> bool:
    """
    Checks if a path is allowed by the given constraints.

    Evaluation order:
    1. If root_directory is set, path must be within it
    2. If denied list exists, path must NOT match any denied pattern
    3. If allowed list exists, path must match at least one allowed pattern
    4. If neither list exists, path is allowed (constraints are optional)

    Args:
        path: The path to check
        constraints: The path constraints to evaluate against

    Returns:
        True if path is allowed, False otherwise
    """
    # 1. Root directory check (sandbox)
    if constraints.root_directory:
        if not is_within_root(path, constraints.root_directory):
            return False

    # 2. Denied list - any match means denied
    if constraints.denied:
        for pattern in constraints.denied:
            if match_path_pattern(path, pattern):
                return False

    # 3. Allowed list - must match at least one
    if constraints.allowed:
        matches_allowed = False
        for pattern in constraints.allowed:
            if match_path_pattern(path, pattern):
                matches_allowed = True
                break
        if not matches_allowed:
            return False

    return True


def extract_path_arguments(args: dict[str, object]) -> list[str]:
    """
    Extracts path-like arguments from tool call arguments.
    Heuristic: any string argument containing / or \\ is treated as a path.

    Args:
        args: Tool call arguments

    Returns:
        List of path-like strings found in arguments
    """
    paths: list[str] = []

    for value in args.values():
        if isinstance(value, str) and ("/" in value or "\\" in value):
            paths.append(value)

    return paths


@dataclass
class PathValidationResult:
    """Result of path validation."""

    allowed: bool
    denied_paths: list[str] | None = None
    reason: str | None = None


def validate_paths_in_request(
    args: dict[str, object],
    constraints: PathConstraints,
) -> PathValidationResult:
    """
    Validates all path-like arguments against constraints.

    Args:
        args: Tool call arguments
        constraints: Path constraints to enforce

    Returns:
        PathValidationResult with validation status
    """
    paths = extract_path_arguments(args)

    if not paths:
        return PathValidationResult(allowed=True)

    denied_paths: list[str] = []
    for path in paths:
        if not is_path_allowed(path, constraints):
            denied_paths.append(path)

    if denied_paths:
        return PathValidationResult(
            allowed=False,
            denied_paths=denied_paths,
            reason=f"Paths not allowed: {', '.join(denied_paths)}",
        )

    return PathValidationResult(allowed=True)
