"""
Permission types for SolonGate.

Permission types are ALWAYS evaluated independently.
Having READ does NOT imply WRITE or EXECUTE.
"""

from enum import Enum
from typing import FrozenSet


class Permission(str, Enum):
    """
    Permission types in SolonGate.

    READ: Read data from a tool/resource
    WRITE: Write/modify data
    EXECUTE: Execute actions/commands
    """

    READ = "READ"
    WRITE = "WRITE"
    EXECUTE = "EXECUTE"


# Type alias for immutable permission sets
PermissionSet = FrozenSet[Permission]


def create_permission_set(*permissions: Permission) -> PermissionSet:
    """Creates an immutable permission set from permissions."""
    return frozenset(permissions)


# Empty permission set - the default for all new tools (default-deny)
NO_PERMISSIONS: PermissionSet = frozenset()

# Read-only permission set - the maximum default for new tools
READ_ONLY: PermissionSet = frozenset({Permission.READ})


def has_permission(permissions: PermissionSet, required: Permission) -> bool:
    """Check if a permission set contains a specific permission."""
    return required in permissions


def has_all_permissions(permissions: PermissionSet, required: list[Permission]) -> bool:
    """Check if a permission set contains all required permissions."""
    return all(p in permissions for p in required)


def permission_for_method(method: str) -> Permission:
    """
    Maps MCP protocol methods to SolonGate permission types.

    Args:
        method: The MCP method name (e.g., 'tools/call', 'resources/read')

    Returns:
        The required permission for the method.
    """
    if method.startswith("resources/") or method.startswith("prompts/") or method == "tools/list":
        return Permission.READ

    if method == "tools/call":
        return Permission.EXECUTE

    # Default to EXECUTE for unknown methods (most restrictive)
    return Permission.EXECUTE
