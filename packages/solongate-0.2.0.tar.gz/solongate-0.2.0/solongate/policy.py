"""
Policy definitions for SolonGate.

Policies are:
- Declarative, non-Turing-complete
- Allow-list based permissions
- No loops, dynamic evaluation, or regex-heavy logic
- Versioned and immutable
"""

from datetime import datetime
from enum import Enum
from typing import Literal
from pydantic import BaseModel, Field

from .trust import TrustLevel
from .permissions import Permission


class PolicyEffect(str, Enum):
    """Effect of a policy rule."""

    ALLOW = "ALLOW"
    DENY = "DENY"


class PolicyRule(BaseModel):
    """
    A single policy rule.

    Rules are evaluated in priority order (lower = higher priority).
    First matching rule wins.
    """

    id: str
    description: str
    effect: PolicyEffect
    priority: int = Field(ge=0, le=100000)
    tool_pattern: str = Field(alias="toolPattern")
    permission: Permission
    minimum_trust_level: TrustLevel = Field(alias="minimumTrustLevel")
    enabled: bool = True
    path_patterns: list[str] | None = Field(default=None, alias="pathPatterns")
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")

    class Config:
        populate_by_name = True


class PolicySet(BaseModel):
    """
    A versioned, immutable set of policy rules.
    """

    id: str
    name: str
    description: str
    version: int = Field(ge=1)
    rules: list[PolicyRule]
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")

    class Config:
        populate_by_name = True


class PolicyDecision(BaseModel):
    """Result of a policy evaluation."""

    effect: PolicyEffect
    matched_rule: PolicyRule | None = Field(default=None, alias="matchedRule")
    reason: str
    evaluated_at: str = Field(alias="evaluatedAt")

    class Config:
        populate_by_name = True


def create_default_deny_policy_set() -> PolicySet:
    """
    Creates the default "deny all" policy set.
    This is the starting policy for any new SolonGate deployment.
    """
    now = datetime.utcnow().isoformat() + "Z"

    return PolicySet(
        id="default-deny",
        name="Default Deny All",
        description="Denies all tool executions. Add explicit ALLOW rules to grant access.",
        version=1,
        rules=[
            PolicyRule(
                id="deny-all-execute",
                description="Explicitly deny all tool executions",
                effect=PolicyEffect.DENY,
                priority=10000,
                toolPattern="*",
                permission=Permission.EXECUTE,
                minimumTrustLevel=TrustLevel.UNTRUSTED,
                enabled=True,
                createdAt=now,
                updatedAt=now,
            ),
            PolicyRule(
                id="deny-all-write",
                description="Explicitly deny all write operations",
                effect=PolicyEffect.DENY,
                priority=10000,
                toolPattern="*",
                permission=Permission.WRITE,
                minimumTrustLevel=TrustLevel.UNTRUSTED,
                enabled=True,
                createdAt=now,
                updatedAt=now,
            ),
            PolicyRule(
                id="deny-all-read",
                description="Explicitly deny all read operations",
                effect=PolicyEffect.DENY,
                priority=10000,
                toolPattern="*",
                permission=Permission.READ,
                minimumTrustLevel=TrustLevel.UNTRUSTED,
                enabled=True,
                createdAt=now,
                updatedAt=now,
            ),
        ],
        createdAt=now,
        updatedAt=now,
    )


def create_read_only_policy_set(tool_pattern: str) -> PolicySet:
    """
    Creates a read-only policy set for a specific tool pattern.
    Allows reads for VERIFIED requests only.
    """
    now = datetime.utcnow().isoformat() + "Z"

    return PolicySet(
        id=f"read-only-{tool_pattern}",
        name=f"Read-Only: {tool_pattern}",
        description=f'Allows read access to tools matching "{tool_pattern}". Denies write and execute.',
        version=1,
        rules=[
            PolicyRule(
                id=f"allow-read-{tool_pattern}",
                description=f"Allow read access to {tool_pattern}",
                effect=PolicyEffect.ALLOW,
                priority=100,
                toolPattern=tool_pattern,
                permission=Permission.READ,
                minimumTrustLevel=TrustLevel.VERIFIED,
                enabled=True,
                createdAt=now,
                updatedAt=now,
            ),
        ],
        createdAt=now,
        updatedAt=now,
    )
