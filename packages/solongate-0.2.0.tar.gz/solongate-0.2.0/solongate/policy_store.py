"""
Policy Store with Versioning for SolonGate.

Provides versioned, immutable policy management:
- Immutable versions: once saved, a version cannot be modified
- Hash chain: each version includes SHA256 of the policy content
- Full history: no version is ever deleted
- Rollback support: create new version from historical version
"""

import hashlib
import json
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from .policy import PolicySet, PolicyRule


@dataclass(frozen=True)
class PolicyVersion:
    """
    A versioned snapshot of a policy set.
    Immutable once created - modifications create new versions.
    """

    version: int
    policy_set: PolicySet
    hash: str
    reason: str
    created_by: str
    created_at: str


@dataclass
class PolicyDiff:
    """Diff between two policy versions."""

    added: list[PolicyRule] = field(default_factory=list)
    removed: list[PolicyRule] = field(default_factory=list)
    modified: list[tuple[PolicyRule, PolicyRule]] = field(default_factory=list)


class PolicyStore:
    """
    In-memory versioned policy store.
    Stores complete history of policy changes with cryptographic hashes.

    Security properties:
    - Immutable versions: once saved, a version cannot be modified
    - Hash chain: each version includes SHA256 of the policy content
    - Full history: no version is ever deleted
    """

    def __init__(self) -> None:
        self._versions: dict[str, list[PolicyVersion]] = {}

    def save_version(
        self,
        policy_set: PolicySet,
        reason: str,
        created_by: str,
    ) -> PolicyVersion:
        """
        Saves a new version of a policy set.
        The version number auto-increments.

        Args:
            policy_set: The policy set to save
            reason: Reason for this version (audit trail)
            created_by: Who created this version

        Returns:
            The created PolicyVersion
        """
        policy_id = policy_set.id
        history = self._versions.get(policy_id, [])

        latest_version = history[-1].version if history else 0

        # Create frozen copy of policy set
        frozen_policy = deepcopy(policy_set)

        version = PolicyVersion(
            version=latest_version + 1,
            policy_set=frozen_policy,
            hash=self.compute_hash(policy_set),
            reason=reason,
            created_by=created_by,
            created_at=datetime.utcnow().isoformat() + "Z",
        )

        new_history = history + [version]
        self._versions[policy_id] = new_history

        return version

    def get_version(self, policy_id: str, version: int) -> PolicyVersion | None:
        """Gets a specific version of a policy set."""
        history = self._versions.get(policy_id)
        if not history:
            return None

        for v in history:
            if v.version == version:
                return v
        return None

    def get_latest(self, policy_id: str) -> PolicyVersion | None:
        """Gets the latest version of a policy set."""
        history = self._versions.get(policy_id)
        if not history:
            return None
        return history[-1]

    def get_history(self, policy_id: str) -> list[PolicyVersion]:
        """Gets the full version history of a policy set."""
        return self._versions.get(policy_id, []).copy()

    def rollback(self, policy_id: str, to_version: int) -> PolicyVersion:
        """
        Rolls back to a previous version by creating a new version
        with the same content as the target version.

        Args:
            policy_id: The policy set ID
            to_version: The version number to rollback to

        Returns:
            The new PolicyVersion (a copy of the target)

        Raises:
            ValueError: If target version not found
        """
        target = self.get_version(policy_id, to_version)
        if not target:
            raise ValueError(f"Version {to_version} not found for policy '{policy_id}'")

        return self.save_version(
            target.policy_set,
            f"Rollback to version {to_version}",
            "system",
        )

    def diff(self, v1: PolicyVersion, v2: PolicyVersion) -> PolicyDiff:
        """
        Computes a diff between two policy versions.

        Args:
            v1: The older version
            v2: The newer version

        Returns:
            PolicyDiff with added, removed, and modified rules
        """
        old_rules_map = {r.id: r for r in v1.policy_set.rules}
        new_rules_map = {r.id: r for r in v2.policy_set.rules}

        added: list[PolicyRule] = []
        removed: list[PolicyRule] = []
        modified: list[tuple[PolicyRule, PolicyRule]] = []

        # Find added and modified rules
        for rule_id, new_rule in new_rules_map.items():
            old_rule = old_rules_map.get(rule_id)
            if not old_rule:
                added.append(new_rule)
            elif old_rule.model_dump() != new_rule.model_dump():
                modified.append((old_rule, new_rule))

        # Find removed rules
        for rule_id, old_rule in old_rules_map.items():
            if rule_id not in new_rules_map:
                removed.append(old_rule)

        return PolicyDiff(added=added, removed=removed, modified=modified)

    def compute_hash(self, policy_set: PolicySet) -> str:
        """
        Computes SHA256 hash of a policy set for integrity verification.

        Args:
            policy_set: The policy set to hash

        Returns:
            Hex-encoded SHA256 hash
        """
        serialized = json.dumps(policy_set.model_dump(), sort_keys=True)
        return hashlib.sha256(serialized.encode()).hexdigest()

    def verify_integrity(self, version: PolicyVersion) -> bool:
        """
        Verifies the integrity of a policy version by recomputing its hash.

        Args:
            version: The version to verify

        Returns:
            True if hash matches, False otherwise
        """
        computed = self.compute_hash(version.policy_set)
        return computed == version.hash
