"""
Sliding Window Rate Limiter for SolonGate.

Tracks per-tool and global call rates using an in-memory sliding window.
Mirrors the TypeScript implementation in packages/sdk-ts/src/rate-limiter.ts.

Features:
- Separate check() and record() for pre/post execution control
- Per-tool and global rate limiting
- Configurable window size
- Usage inspection and reset methods
"""

import time
from dataclasses import dataclass, field

# Default window size: 60 seconds (1 minute)
RATE_LIMIT_WINDOW_SECONDS = 60

# Maximum entries per tool before cleanup
RATE_LIMIT_MAX_ENTRIES = 10_000


@dataclass(frozen=True)
class RateLimitResult:
    """Result of a rate limit check."""

    allowed: bool
    remaining: int
    reset_at: float


@dataclass(frozen=True)
class RateLimitUsage:
    """Current usage stats for a tool."""

    count: int
    window_start: float


class RateLimiter:
    """
    Sliding window rate limiter for tool calls.

    Tracks per-tool and global call rates using an in-memory sliding window.

    Usage:
        limiter = RateLimiter(window_seconds=60)

        # Before executing a tool
        check = limiter.check_limit("file.read", limit_per_window=100)
        if not check.allowed:
            raise RateLimitError("Rate limit exceeded")

        # Execute the tool...

        # After successful execution
        limiter.record_call("file.read")
    """

    def __init__(self, window_seconds: float | None = None):
        """
        Initialize the rate limiter.

        Args:
            window_seconds: Size of the sliding window in seconds (default: 60)
        """
        self._window_seconds = window_seconds or RATE_LIMIT_WINDOW_SECONDS
        self._records: dict[str, list[float]] = {}
        self._global_records: list[float] = []

    def check_limit(self, tool_name: str, limit_per_window: int) -> RateLimitResult:
        """
        Check if a tool call is within the rate limit.

        Does NOT record the call - use record_call() after successful execution.

        Args:
            tool_name: Name of the tool
            limit_per_window: Maximum calls allowed in the window

        Returns:
            RateLimitResult with allowed status and remaining calls
        """
        now = time.time()
        window_start = now - self._window_seconds

        records = self._get_active_records(tool_name, window_start)
        count = len(records)
        allowed = count < limit_per_window
        remaining = max(0, limit_per_window - count)
        reset_at = records[0] + self._window_seconds if records else now + self._window_seconds

        return RateLimitResult(allowed=allowed, remaining=remaining, reset_at=reset_at)

    def check_global_limit(self, limit_per_window: int) -> RateLimitResult:
        """
        Check the global rate limit across all tools.

        Args:
            limit_per_window: Maximum total calls allowed in the window

        Returns:
            RateLimitResult with allowed status and remaining calls
        """
        now = time.time()
        window_start = now - self._window_seconds

        self._global_records = [t for t in self._global_records if t > window_start]
        count = len(self._global_records)
        allowed = count < limit_per_window
        remaining = max(0, limit_per_window - count)
        reset_at = (
            self._global_records[0] + self._window_seconds
            if self._global_records
            else now + self._window_seconds
        )

        return RateLimitResult(allowed=allowed, remaining=remaining, reset_at=reset_at)

    def record_call(self, tool_name: str) -> None:
        """
        Record a tool call for rate limiting.

        Call this after successful execution.

        Args:
            tool_name: Name of the tool that was executed
        """
        now = time.time()

        # Per-tool tracking
        if tool_name not in self._records:
            self._records[tool_name] = []
        self._records[tool_name].append(now)

        # Cleanup if too many entries
        if len(self._records[tool_name]) > RATE_LIMIT_MAX_ENTRIES:
            window_start = now - self._window_seconds
            self._records[tool_name] = [
                t for t in self._records[tool_name] if t > window_start
            ]

        # Global tracking
        self._global_records.append(now)
        if len(self._global_records) > RATE_LIMIT_MAX_ENTRIES:
            window_start = now - self._window_seconds
            self._global_records = [t for t in self._global_records if t > window_start]

    def get_usage(self, tool_name: str) -> RateLimitUsage:
        """
        Get usage stats for a tool.

        Args:
            tool_name: Name of the tool

        Returns:
            RateLimitUsage with current count and window start
        """
        now = time.time()
        window_start = now - self._window_seconds
        records = self._get_active_records(tool_name, window_start)
        return RateLimitUsage(count=len(records), window_start=window_start)

    def reset_tool(self, tool_name: str) -> None:
        """Reset rate tracking for a specific tool."""
        self._records.pop(tool_name, None)

    def reset_all(self) -> None:
        """Reset all rate tracking."""
        self._records.clear()
        self._global_records.clear()

    def _get_active_records(self, tool_name: str, window_start: float) -> list[float]:
        """Get records within the active window, cleaning up expired entries."""
        records = self._records.get(tool_name, [])
        active = [t for t in records if t > window_start]

        # Update stored records to remove expired entries
        if len(active) != len(records):
            self._records[tool_name] = active

        return active
