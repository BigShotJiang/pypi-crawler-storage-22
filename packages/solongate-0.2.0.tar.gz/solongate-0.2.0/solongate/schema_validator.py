"""
Schema Validation Layer for SolonGate.

Provides strict JSON schema enforcement:
- Unknown fields REJECTED
- Type mismatches REJECTED
- Required fields ENFORCED
- Depth limits ENFORCED
- Size limits ENFORCED

Schema acts as the first hard boundary against malformed or injected inputs.
"""

import json
from dataclasses import dataclass, field
from typing import Any, TypeVar, Generic

from pydantic import BaseModel, ConfigDict, ValidationError

# Constants
MAX_ARGUMENT_DEPTH = 10
MAX_ARGUMENTS_SIZE_BYTES = 1_048_576  # 1MB
MAX_TOOL_NAME_LENGTH = 256


@dataclass
class SchemaValidationResult:
    """Result of schema validation."""

    valid: bool
    errors: list[str] = field(default_factory=list)
    sanitized: dict[str, Any] | None = None


class StrictSchema(BaseModel):
    """
    Base class for strict schemas that reject unknown fields.
    All tool input schemas should inherit from this.
    """

    model_config = ConfigDict(
        extra="forbid",  # Reject unknown fields
        strict=True,  # Strict type checking
        validate_default=True,
    )


def validate_tool_input(
    schema_class: type[BaseModel],
    input_data: Any,
    max_depth: int = MAX_ARGUMENT_DEPTH,
    max_size_bytes: int = MAX_ARGUMENTS_SIZE_BYTES,
) -> SchemaValidationResult:
    """
    Validates tool input against a Pydantic schema with strict security enforcement.

    - Unknown fields are REJECTED
    - Type mismatches are REJECTED
    - Required fields are ENFORCED
    - Recursive depth is limited
    - Argument size is limited

    Args:
        schema_class: Pydantic model class to validate against
        input_data: The input data to validate
        max_depth: Maximum allowed nesting depth
        max_size_bytes: Maximum allowed size in bytes

    Returns:
        SchemaValidationResult with validation status and errors
    """
    errors: list[str] = []

    # 1. Size check - prevent oversized payloads
    size_error = _check_input_size(input_data, max_size_bytes)
    if size_error:
        return SchemaValidationResult(valid=False, errors=[size_error])

    # 2. Depth check - prevent deeply nested structures
    depth_error = _check_input_depth(input_data, max_depth)
    if depth_error:
        return SchemaValidationResult(valid=False, errors=[depth_error])

    # 3. Schema validation using Pydantic
    try:
        validated = schema_class.model_validate(input_data)
        return SchemaValidationResult(
            valid=True,
            errors=[],
            sanitized=validated.model_dump(),
        )
    except ValidationError as e:
        for error in e.errors():
            path = ".".join(str(p) for p in error["loc"]) or "root"
            errors.append(f"{path}: {error['msg']}")
        return SchemaValidationResult(valid=False, errors=errors)


def _check_input_size(input_data: Any, max_bytes: int) -> str | None:
    """Check if input size exceeds the maximum allowed bytes."""
    try:
        serialized = json.dumps(input_data)
    except (TypeError, ValueError):
        return "Input cannot be serialized to JSON"

    size_bytes = len(serialized.encode("utf-8"))
    if size_bytes > max_bytes:
        return f"Input size {size_bytes} bytes exceeds maximum {max_bytes} bytes"
    return None


def _check_input_depth(input_data: Any, max_depth: int) -> str | None:
    """Check if input exceeds maximum nesting depth."""
    depth = _measure_depth(input_data, 0)
    if depth > max_depth:
        return f"Input depth {depth} exceeds maximum {max_depth}"
    return None


def _measure_depth(value: Any, current_depth: int) -> int:
    """Measure the nesting depth of a value."""
    if current_depth > MAX_ARGUMENT_DEPTH + 1:
        return current_depth  # Early exit to prevent stack overflow

    if value is None or not isinstance(value, (dict, list)):
        return current_depth

    if isinstance(value, list):
        max_child_depth = current_depth + 1
        for item in value:
            child_depth = _measure_depth(item, current_depth + 1)
            if child_depth > max_child_depth:
                max_child_depth = child_depth
        return max_child_depth

    if isinstance(value, dict):
        max_child_depth = current_depth + 1
        for v in value.values():
            child_depth = _measure_depth(v, current_depth + 1)
            if child_depth > max_child_depth:
                max_child_depth = child_depth
        return max_child_depth

    return current_depth


# --- Tool Schema Registry ---


@dataclass
class ToolSchema:
    """Schema definition for a tool."""

    name: str
    description: str
    input_schema: type[BaseModel]
    output_schema: type[BaseModel] | None = None


class ToolRegistry:
    """
    Registry for tool schemas.

    Provides centralized schema management for validation.
    """

    def __init__(self) -> None:
        self._schemas: dict[str, ToolSchema] = {}

    def register(
        self,
        name: str,
        description: str,
        input_schema: type[BaseModel],
        output_schema: type[BaseModel] | None = None,
    ) -> None:
        """
        Register a tool schema.

        Args:
            name: Tool name (must be unique)
            description: Tool description
            input_schema: Pydantic model for input validation
            output_schema: Optional Pydantic model for output validation
        """
        if len(name) > MAX_TOOL_NAME_LENGTH:
            raise ValueError(f"Tool name exceeds maximum length of {MAX_TOOL_NAME_LENGTH}")

        self._schemas[name] = ToolSchema(
            name=name,
            description=description,
            input_schema=input_schema,
            output_schema=output_schema,
        )

    def get(self, name: str) -> ToolSchema | None:
        """Get a tool schema by name."""
        return self._schemas.get(name)

    def validate_input(self, name: str, input_data: Any) -> SchemaValidationResult:
        """
        Validate input for a registered tool.

        Args:
            name: Tool name
            input_data: Input data to validate

        Returns:
            SchemaValidationResult

        Raises:
            ValueError: If tool is not registered
        """
        schema = self._schemas.get(name)
        if not schema:
            raise ValueError(f"Tool '{name}' is not registered")

        return validate_tool_input(schema.input_schema, input_data)

    def list_tools(self) -> list[str]:
        """List all registered tool names."""
        return list(self._schemas.keys())

    def has_tool(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._schemas


# Global registry instance
_global_registry = ToolRegistry()


def get_global_registry() -> ToolRegistry:
    """Get the global tool registry."""
    return _global_registry


def register_tool(
    name: str,
    description: str,
    input_schema: type[BaseModel],
    output_schema: type[BaseModel] | None = None,
) -> None:
    """Register a tool in the global registry."""
    _global_registry.register(name, description, input_schema, output_schema)
