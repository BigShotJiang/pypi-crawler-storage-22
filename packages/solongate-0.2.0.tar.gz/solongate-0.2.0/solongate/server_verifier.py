"""
Server-Side Verification for SolonGate.

MCP servers use this module to verify incoming requests:
- Signature validation (JWT)
- Expiry enforcement
- Scope re-validation
- Nonce/replay protection

Requests without valid gateway signature are REJECTED.
"""

import time
from dataclasses import dataclass, field
from typing import Any

import jwt

from .capability_token import (
    TOKEN_ALGORITHM,
    MIN_SECRET_LENGTH,
    TokenVerificationResult,
)
from .permissions import Permission


@dataclass
class VerificationConfig:
    """Configuration for server-side verification."""

    gateway_secret: str
    enforce_expiry: bool = True
    enforce_scope: bool = True
    enforce_nonce: bool = True
    max_clock_skew_seconds: int = 30


@dataclass
class ScopeVerificationResult:
    """Result of scope verification."""

    valid: bool
    error: str | None = None
    tool: str | None = None
    permission: Permission | None = None
    path: str | None = None


class ServerVerifier:
    """
    Verifies incoming requests from the SolonGate gateway.

    MCP servers should use this to validate that requests are properly
    authorized and haven't been tampered with.

    Usage:
        verifier = ServerVerifier(VerificationConfig(
            gateway_secret="your-32-char-secret-key..."
        ))

        # On each request
        result = verifier.verify_request(token, expected_tool="file.read")
        if not result.valid:
            return error_response(result.error)
    """

    def __init__(self, config: VerificationConfig):
        if len(config.gateway_secret) < MIN_SECRET_LENGTH:
            raise ValueError(f"Gateway secret must be at least {MIN_SECRET_LENGTH} characters")
        self._config = config
        self._used_nonces: set[str] = set()
        self._nonce_timestamps: dict[str, float] = {}

    def verify_request(
        self,
        token: str,
        expected_tool: str | None = None,
        expected_scope: str | None = None,
    ) -> TokenVerificationResult:
        """
        Verify an incoming request token.

        Checks:
        1. Signature validity (HMAC-SHA256)
        2. Expiration (with clock skew tolerance)
        3. Nonce (single-use, replay protection)
        4. Tool match (if expected_tool provided)
        5. Scope match (if expected_scope provided)

        Args:
            token: The JWT token from the gateway
            expected_tool: Optional expected tool name
            expected_scope: Optional expected scope string

        Returns:
            TokenVerificationResult with validity status
        """
        # 1. Decode and verify signature
        try:
            payload = jwt.decode(
                token,
                self._config.gateway_secret,
                algorithms=[TOKEN_ALGORITHM],
                options={
                    "require": ["exp", "iat", "tool", "scope", "nonce"],
                    "verify_exp": self._config.enforce_expiry,
                },
                leeway=self._config.max_clock_skew_seconds,
            )
        except jwt.ExpiredSignatureError:
            return TokenVerificationResult(valid=False, error="Token expired")
        except jwt.InvalidTokenError as e:
            return TokenVerificationResult(valid=False, error=f"Invalid token: {e}")

        # 2. Extract claims
        tool = payload.get("tool")
        scope = payload.get("scope")
        nonce = payload.get("nonce")

        # 3. Nonce verification (replay protection)
        if self._config.enforce_nonce:
            if not nonce:
                return TokenVerificationResult(valid=False, error="Missing nonce")

            if nonce in self._used_nonces:
                return TokenVerificationResult(
                    valid=False, error="Token already used (replay detected)"
                )

            # Mark nonce as used
            self._used_nonces.add(nonce)
            self._nonce_timestamps[nonce] = time.time()

            # Cleanup old nonces (older than 5 minutes)
            self._cleanup_old_nonces()

        # 4. Tool verification
        if expected_tool and tool != expected_tool:
            return TokenVerificationResult(
                valid=False,
                error=f"Tool mismatch: expected {expected_tool}, got {tool}",
            )

        # 5. Scope verification
        if self._config.enforce_scope and expected_scope:
            if scope != expected_scope:
                return TokenVerificationResult(
                    valid=False,
                    error=f"Scope mismatch: expected {expected_scope}, got {scope}",
                )

        return TokenVerificationResult(
            valid=True,
            tool=tool,
            scope=scope,
            nonce=nonce,
        )

    def verify_scope(
        self,
        scope: str,
        requested_tool: str,
        requested_permission: Permission,
        requested_path: str | None = None,
    ) -> ScopeVerificationResult:
        """
        Verify that a scope string authorizes a specific action.

        Scope format: "PERMISSION:tool[:path]"
        Examples:
            - "READ:file.read" - allows read on file.read
            - "WRITE:file.write:/home/user" - allows write on file.write under /home/user
            - "EXECUTE:*" - allows execute on any tool (dangerous!)

        Args:
            scope: The scope string from the token
            requested_tool: The tool being invoked
            requested_permission: The permission required
            requested_path: Optional path being accessed

        Returns:
            ScopeVerificationResult
        """
        try:
            parts = scope.split(":", 2)
            if len(parts) < 2:
                return ScopeVerificationResult(
                    valid=False, error=f"Invalid scope format: {scope}"
                )

            scope_permission_str = parts[0]
            scope_tool = parts[1]
            scope_path = parts[2] if len(parts) > 2 else None

            # Parse permission
            try:
                scope_permission = Permission(scope_permission_str)
            except ValueError:
                return ScopeVerificationResult(
                    valid=False, error=f"Invalid permission in scope: {scope_permission_str}"
                )

            # Check permission
            if scope_permission != requested_permission:
                return ScopeVerificationResult(
                    valid=False,
                    error=f"Permission mismatch: scope has {scope_permission.value}, requested {requested_permission.value}",
                )

            # Check tool (supports wildcard *)
            if scope_tool != "*" and scope_tool != requested_tool:
                # Check prefix match (e.g., "file.*" matches "file.read")
                if scope_tool.endswith("*"):
                    prefix = scope_tool[:-1]
                    if not requested_tool.startswith(prefix):
                        return ScopeVerificationResult(
                            valid=False,
                            error=f"Tool not covered by scope: {requested_tool}",
                        )
                else:
                    return ScopeVerificationResult(
                        valid=False,
                        error=f"Tool mismatch: scope has {scope_tool}, requested {requested_tool}",
                    )

            # Check path (if scope has path restriction)
            if scope_path and requested_path:
                if not requested_path.startswith(scope_path):
                    return ScopeVerificationResult(
                        valid=False,
                        error=f"Path not covered by scope: {requested_path} not under {scope_path}",
                    )

            return ScopeVerificationResult(
                valid=True,
                tool=scope_tool,
                permission=scope_permission,
                path=scope_path,
            )

        except Exception as e:
            return ScopeVerificationResult(
                valid=False, error=f"Scope verification error: {e}"
            )

    def _cleanup_old_nonces(self) -> None:
        """Remove nonces older than 5 minutes."""
        now = time.time()
        cutoff = now - 300  # 5 minutes

        expired = [
            nonce
            for nonce, timestamp in self._nonce_timestamps.items()
            if timestamp < cutoff
        ]

        for nonce in expired:
            self._used_nonces.discard(nonce)
            del self._nonce_timestamps[nonce]

        # Also cap total nonces to prevent memory issues
        if len(self._used_nonces) > 10000:
            # Remove oldest half
            sorted_nonces = sorted(
                self._nonce_timestamps.items(), key=lambda x: x[1]
            )
            to_remove = sorted_nonces[: len(sorted_nonces) // 2]
            for nonce, _ in to_remove:
                self._used_nonces.discard(nonce)
                del self._nonce_timestamps[nonce]


# --- Middleware for common frameworks ---


def create_fastapi_middleware(verifier: ServerVerifier):
    """
    Create a FastAPI middleware for request verification.

    Usage:
        from fastapi import FastAPI, Request
        from solongate import ServerVerifier, VerificationConfig, create_fastapi_middleware

        verifier = ServerVerifier(VerificationConfig(gateway_secret="..."))
        app = FastAPI()

        @app.middleware("http")
        async def verify_gateway(request: Request, call_next):
            return await create_fastapi_middleware(verifier)(request, call_next)
    """

    async def middleware(request: Any, call_next: Any) -> Any:
        # Get token from header
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            from fastapi.responses import JSONResponse

            return JSONResponse(
                status_code=401,
                content={"error": "Missing or invalid Authorization header"},
            )

        token = auth_header[7:]  # Remove "Bearer " prefix

        # Get expected tool from path or header
        expected_tool = request.headers.get("X-SolonGate-Tool")

        # Verify
        result = verifier.verify_request(token, expected_tool=expected_tool)
        if not result.valid:
            from fastapi.responses import JSONResponse

            return JSONResponse(
                status_code=403,
                content={"error": result.error},
            )

        # Add verification result to request state
        request.state.solongate_verification = result

        return await call_next(request)

    return middleware


def create_flask_decorator(verifier: ServerVerifier):
    """
    Create a Flask decorator for route protection.

    Usage:
        from flask import Flask
        from solongate import ServerVerifier, VerificationConfig, create_flask_decorator

        verifier = ServerVerifier(VerificationConfig(gateway_secret="..."))
        require_gateway = create_flask_decorator(verifier)

        app = Flask(__name__)

        @app.route("/api/tool")
        @require_gateway(expected_tool="my.tool")
        def handle_tool():
            return {"result": "success"}
    """
    from functools import wraps

    def decorator(expected_tool: str | None = None):
        def route_decorator(f: Any) -> Any:
            @wraps(f)
            def decorated_function(*args: Any, **kwargs: Any) -> Any:
                from flask import request, jsonify, g

                auth_header = request.headers.get("Authorization", "")
                if not auth_header.startswith("Bearer "):
                    return jsonify({"error": "Missing or invalid Authorization header"}), 401

                token = auth_header[7:]
                result = verifier.verify_request(token, expected_tool=expected_tool)

                if not result.valid:
                    return jsonify({"error": result.error}), 403

                g.solongate_verification = result
                return f(*args, **kwargs)

            return decorated_function

        return route_decorator

    return decorator
