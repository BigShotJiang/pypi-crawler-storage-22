"""
Trust Model for SolonGate.

Core threat model principle: LLMs are UNTRUSTED by default.
Trust is never assumed - it must be explicitly granted and is
always scoped to specific capabilities.

Trust Levels:
- UNTRUSTED: Default for all LLM-originated requests. No permissions.
- VERIFIED: Passed schema validation and policy evaluation. May execute within granted scope.
- TRUSTED: System-internal only. NEVER assignable to LLM-originated requests.
"""

from enum import Enum
from typing import Any

from .errors import TrustEscalationError


class TrustLevel(str, Enum):
    """
    Trust levels in the SolonGate security model.

    UNTRUSTED: Default for all LLM-originated requests. No permissions.
    VERIFIED: Passed schema validation and policy evaluation.
    TRUSTED: System-internal only. NEVER assignable to LLM requests.
    """

    UNTRUSTED = "UNTRUSTED"
    VERIFIED = "VERIFIED"
    TRUSTED = "TRUSTED"


def is_valid_trust_level(value: Any) -> bool:
    """
    Validates that a value is a legitimate TrustLevel.
    Prevents type confusion attacks where a string bypasses checks.
    """
    if isinstance(value, TrustLevel):
        return True
    if isinstance(value, str):
        try:
            TrustLevel(value)
            return True
        except ValueError:
            return False
    return False


def assert_valid_transition(from_level: TrustLevel, to_level: TrustLevel) -> None:
    """
    Asserts that a trust level transition is valid.

    UNTRUSTED -> VERIFIED (via policy evaluation) is the only escalation path.
    TRUSTED is never reachable from external requests.

    Raises:
        TrustEscalationError: If the transition is invalid.
    """
    # TRUSTED is never reachable from any request
    if to_level == TrustLevel.TRUSTED:
        raise TrustEscalationError(
            "Cannot escalate to TRUSTED level. TRUSTED is reserved for system-internal operations."
        )

    # Downgrade is always allowed (fail-safe)
    if from_level == TrustLevel.VERIFIED and to_level == TrustLevel.UNTRUSTED:
        return

    # Normal escalation via policy evaluation
    if from_level == TrustLevel.UNTRUSTED and to_level == TrustLevel.VERIFIED:
        return

    # No-op
    if from_level == to_level:
        return

    raise TrustEscalationError(f"Invalid trust transition from {from_level.value} to {to_level.value}")
