"""
Security Warnings Analysis for SolonGate.

Analyzes policy configurations and flags unsafe patterns:
- WILDCARD_ALLOW: wildcard ALLOW rules bypass default-deny
- ALLOW_UNTRUSTED: ALLOW rules targeting UNTRUSTED requests
- ALLOW_EXECUTE: EXECUTE permissions without careful scoping
- DISABLED_VALIDATION: schema validation disabled

Mirrors the TypeScript implementation in packages/policy-engine/src/warnings.ts.
"""

from dataclasses import dataclass
from typing import Literal

from .policy import PolicySet, PolicyRule


# Warning messages matching TypeScript UNSAFE_CONFIGURATION_WARNINGS
UNSAFE_CONFIGURATION_WARNINGS = {
    "WILDCARD_ALLOW": (
        "Wildcard ALLOW rules grant permission to ALL tools. "
        "This bypasses the default-deny model."
    ),
    "TRUSTED_LEVEL_EXTERNAL": (
        "Setting trust level to TRUSTED for external requests "
        "bypasses all security checks."
    ),
    "WRITE_WITHOUT_READ": (
        "Granting WRITE without READ is unusual and may indicate "
        "a misconfiguration."
    ),
    "EXECUTE_WITHOUT_REVIEW": (
        "EXECUTE permission allows tools to perform arbitrary actions. "
        "Review carefully."
    ),
    "RATE_LIMIT_ZERO": (
        "A rate limit of 0 means unlimited calls. "
        "This removes protection against runaway loops."
    ),
    "DISABLED_VALIDATION": (
        "Disabling schema validation removes input sanitization protections."
    ),
}


@dataclass(frozen=True)
class SecurityWarning:
    """A security warning about a policy configuration."""

    level: Literal["WARNING", "CRITICAL"]
    code: str
    message: str
    rule_id: str | None = None
    recommendation: str = ""


def analyze_security_warnings(policy_set: PolicySet) -> list[SecurityWarning]:
    """
    Analyze a policy set and return security warnings.

    Pure function - does not modify the policy set.

    Args:
        policy_set: The policy set to analyze

    Returns:
        List of SecurityWarning objects describing unsafe patterns
    """
    warnings: list[SecurityWarning] = []

    # Per-rule warnings
    for rule in policy_set.rules:
        warnings.extend(_analyze_rule_warnings(rule))

    # Policy-level warnings: wildcard ALLOW
    allow_rules = [
        r for r in policy_set.rules
        if r.effect.value == "ALLOW" and r.enabled
    ]
    wildcard_allows = [r for r in allow_rules if r.tool_pattern == "*"]

    if wildcard_allows:
        warnings.append(SecurityWarning(
            level="CRITICAL",
            code="WILDCARD_ALLOW",
            message=UNSAFE_CONFIGURATION_WARNINGS["WILDCARD_ALLOW"],
            recommendation="Replace wildcard ALLOW rules with specific tool patterns.",
        ))

    return warnings


def _analyze_rule_warnings(rule: PolicyRule) -> list[SecurityWarning]:
    """Analyze a single rule for warnings."""
    warnings: list[SecurityWarning] = []

    # CRITICAL: ALLOW rules with UNTRUSTED trust level
    if rule.effect.value == "ALLOW" and rule.minimum_trust_level == "UNTRUSTED":
        warnings.append(SecurityWarning(
            level="CRITICAL",
            code="ALLOW_UNTRUSTED",
            message=(
                f'Rule "{rule.id}" allows execution for UNTRUSTED requests. '
                "Unverified LLM requests can execute tools."
            ),
            rule_id=rule.id,
            recommendation="Set minimumTrustLevel to VERIFIED or higher for ALLOW rules.",
        ))

    # WARNING: ALLOW rules with EXECUTE permission
    if rule.effect.value == "ALLOW" and rule.permission == "EXECUTE":
        warnings.append(SecurityWarning(
            level="WARNING",
            code="ALLOW_EXECUTE",
            message=UNSAFE_CONFIGURATION_WARNINGS["EXECUTE_WITHOUT_REVIEW"],
            rule_id=rule.id,
            recommendation="Ensure EXECUTE permissions are intentional and scoped to specific tools.",
        ))

    return warnings
