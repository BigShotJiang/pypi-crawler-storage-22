"""
OR-Tools Example: simple_sat_program.py

This is a solvOR implementation of the Google OR-Tools example.
Original: https://github.com/google/or-tools/blob/stable/ortools/sat/samples/simple_sat_program.py

solvOR provides pure Python solvers for learning and prototyping.
For production-scale problems, consider using Google OR-Tools which
offers compiled C++ solvers with significantly better performance.

Comparison:
- solvOR: Pure Python, readable, educational, no dependencies
- OR-Tools: C++ backend, production-ready, 10-100x faster
"""

#!/usr/bin/env python3
# Copyright 2010-2025 Google LLC
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START program]
"""Simple solve."""
# [START import]
from solvor import Model, Status

# [END import]


def simple_sat_program():
    """Minimal CP-SAT example to showcase calling the solver."""
    # Creates the model.
    # [START model]
    model = Model()
    # [END model]

    # Creates the variables.
    # [START variables]
    num_vals = 3
    x = model.int_var(0, num_vals - 1, "x")
    y = model.int_var(0, num_vals - 1, "y")
    z = model.int_var(0, num_vals - 1, "z")
    # [END variables]

    # Creates the constraints.
    # [START constraints]
    model.add(x != y)
    # [END constraints]

    # Creates a solver and solves the model.
    # [START solve]
    result = model.solve()
    # [END solve]

    # [START print_solution]
    if result.status == Status.OPTIMAL:
        print(f"x = {result.solution['x']}")
        print(f"y = {result.solution['y']}")
        print(f"z = {result.solution['z']}")
    else:
        print("No solution found.")
    # [END print_solution]


simple_sat_program()
# [END program]
