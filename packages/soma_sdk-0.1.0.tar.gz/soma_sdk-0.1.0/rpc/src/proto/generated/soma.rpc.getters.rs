mod _getter_impls {
    #![allow(clippy::useless_conversion)]
    use super::*;
    impl BalanceChange {
        pub const fn const_default() -> Self {
            Self {
                address: None,
                amount: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: BalanceChange = BalanceChange::const_default();
            &DEFAULT
        }
        pub fn with_address(mut self, field: String) -> Self {
            self.address = Some(field.into());
            self
        }
        pub fn with_amount(mut self, field: String) -> Self {
            self.amount = Some(field.into());
            self
        }
    }
    impl Checkpoint {
        pub const fn const_default() -> Self {
            Self {
                sequence_number: None,
                digest: None,
                summary: None,
                signature: None,
                contents: None,
                transactions: Vec::new(),
                objects: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Checkpoint = Checkpoint::const_default();
            &DEFAULT
        }
        pub fn with_sequence_number(mut self, field: u64) -> Self {
            self.sequence_number = Some(field.into());
            self
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
        pub fn summary(&self) -> &CheckpointSummary {
            self.summary
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| CheckpointSummary::default_instance() as _)
        }
        pub fn summary_opt(&self) -> Option<&CheckpointSummary> {
            self.summary.as_ref().map(|field| field as _)
        }
        pub fn summary_opt_mut(&mut self) -> Option<&mut CheckpointSummary> {
            self.summary.as_mut().map(|field| field as _)
        }
        pub fn summary_mut(&mut self) -> &mut CheckpointSummary {
            self.summary.get_or_insert_default()
        }
        pub fn with_summary(mut self, field: CheckpointSummary) -> Self {
            self.summary = Some(field.into());
            self
        }
        pub fn signature(&self) -> &ValidatorAggregatedSignature {
            self.signature
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ValidatorAggregatedSignature::default_instance() as _)
        }
        pub fn signature_opt(&self) -> Option<&ValidatorAggregatedSignature> {
            self.signature.as_ref().map(|field| field as _)
        }
        pub fn signature_opt_mut(
            &mut self,
        ) -> Option<&mut ValidatorAggregatedSignature> {
            self.signature.as_mut().map(|field| field as _)
        }
        pub fn signature_mut(&mut self) -> &mut ValidatorAggregatedSignature {
            self.signature.get_or_insert_default()
        }
        pub fn with_signature(mut self, field: ValidatorAggregatedSignature) -> Self {
            self.signature = Some(field.into());
            self
        }
        pub fn contents(&self) -> &CheckpointContents {
            self.contents
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| CheckpointContents::default_instance() as _)
        }
        pub fn contents_opt(&self) -> Option<&CheckpointContents> {
            self.contents.as_ref().map(|field| field as _)
        }
        pub fn contents_opt_mut(&mut self) -> Option<&mut CheckpointContents> {
            self.contents.as_mut().map(|field| field as _)
        }
        pub fn contents_mut(&mut self) -> &mut CheckpointContents {
            self.contents.get_or_insert_default()
        }
        pub fn with_contents(mut self, field: CheckpointContents) -> Self {
            self.contents = Some(field.into());
            self
        }
        pub fn transactions(&self) -> &[ExecutedTransaction] {
            &self.transactions
        }
        pub fn transactions_mut(&mut self) -> &mut Vec<ExecutedTransaction> {
            &mut self.transactions
        }
        pub fn with_transactions(mut self, field: Vec<ExecutedTransaction>) -> Self {
            self.transactions = field;
            self
        }
        pub fn objects(&self) -> &ObjectSet {
            self.objects
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectSet::default_instance() as _)
        }
        pub fn objects_opt(&self) -> Option<&ObjectSet> {
            self.objects.as_ref().map(|field| field as _)
        }
        pub fn objects_opt_mut(&mut self) -> Option<&mut ObjectSet> {
            self.objects.as_mut().map(|field| field as _)
        }
        pub fn objects_mut(&mut self) -> &mut ObjectSet {
            self.objects.get_or_insert_default()
        }
        pub fn with_objects(mut self, field: ObjectSet) -> Self {
            self.objects = Some(field.into());
            self
        }
    }
    impl CheckpointContents {
        pub const fn const_default() -> Self {
            Self {
                digest: None,
                version: None,
                transactions: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: CheckpointContents = CheckpointContents::const_default();
            &DEFAULT
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
        pub fn with_version(mut self, field: i32) -> Self {
            self.version = Some(field.into());
            self
        }
        pub fn transactions(&self) -> &[CheckpointedTransactionInfo] {
            &self.transactions
        }
        pub fn transactions_mut(&mut self) -> &mut Vec<CheckpointedTransactionInfo> {
            &mut self.transactions
        }
        pub fn with_transactions(
            mut self,
            field: Vec<CheckpointedTransactionInfo>,
        ) -> Self {
            self.transactions = field;
            self
        }
    }
    impl CheckpointedTransactionInfo {
        pub const fn const_default() -> Self {
            Self {
                transaction: None,
                effects: None,
                signatures: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: CheckpointedTransactionInfo = CheckpointedTransactionInfo::const_default();
            &DEFAULT
        }
        pub fn with_transaction(mut self, field: String) -> Self {
            self.transaction = Some(field.into());
            self
        }
        pub fn with_effects(mut self, field: String) -> Self {
            self.effects = Some(field.into());
            self
        }
        pub fn signatures(&self) -> &[UserSignature] {
            &self.signatures
        }
        pub fn signatures_mut(&mut self) -> &mut Vec<UserSignature> {
            &mut self.signatures
        }
        pub fn with_signatures(mut self, field: Vec<UserSignature>) -> Self {
            self.signatures = field;
            self
        }
    }
    impl CheckpointSummary {
        pub const fn const_default() -> Self {
            Self {
                digest: None,
                epoch: None,
                sequence_number: None,
                total_network_transactions: None,
                content_digest: None,
                previous_digest: None,
                epoch_rolling_transaction_fees: None,
                timestamp: None,
                commitments: Vec::new(),
                end_of_epoch_data: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: CheckpointSummary = CheckpointSummary::const_default();
            &DEFAULT
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn with_sequence_number(mut self, field: u64) -> Self {
            self.sequence_number = Some(field.into());
            self
        }
        pub fn with_total_network_transactions(mut self, field: u64) -> Self {
            self.total_network_transactions = Some(field.into());
            self
        }
        pub fn with_content_digest(mut self, field: String) -> Self {
            self.content_digest = Some(field.into());
            self
        }
        pub fn with_previous_digest(mut self, field: String) -> Self {
            self.previous_digest = Some(field.into());
            self
        }
        pub fn epoch_rolling_transaction_fees(&self) -> &TransactionFee {
            self.epoch_rolling_transaction_fees
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| TransactionFee::default_instance() as _)
        }
        pub fn epoch_rolling_transaction_fees_opt(&self) -> Option<&TransactionFee> {
            self.epoch_rolling_transaction_fees.as_ref().map(|field| field as _)
        }
        pub fn epoch_rolling_transaction_fees_opt_mut(
            &mut self,
        ) -> Option<&mut TransactionFee> {
            self.epoch_rolling_transaction_fees.as_mut().map(|field| field as _)
        }
        pub fn epoch_rolling_transaction_fees_mut(&mut self) -> &mut TransactionFee {
            self.epoch_rolling_transaction_fees.get_or_insert_default()
        }
        pub fn with_epoch_rolling_transaction_fees(
            mut self,
            field: TransactionFee,
        ) -> Self {
            self.epoch_rolling_transaction_fees = Some(field.into());
            self
        }
        pub fn commitments(&self) -> &[CheckpointCommitment] {
            &self.commitments
        }
        pub fn commitments_mut(&mut self) -> &mut Vec<CheckpointCommitment> {
            &mut self.commitments
        }
        pub fn with_commitments(mut self, field: Vec<CheckpointCommitment>) -> Self {
            self.commitments = field;
            self
        }
        pub fn end_of_epoch_data(&self) -> &EndOfEpochData {
            self.end_of_epoch_data
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| EndOfEpochData::default_instance() as _)
        }
        pub fn end_of_epoch_data_opt(&self) -> Option<&EndOfEpochData> {
            self.end_of_epoch_data.as_ref().map(|field| field as _)
        }
        pub fn end_of_epoch_data_opt_mut(&mut self) -> Option<&mut EndOfEpochData> {
            self.end_of_epoch_data.as_mut().map(|field| field as _)
        }
        pub fn end_of_epoch_data_mut(&mut self) -> &mut EndOfEpochData {
            self.end_of_epoch_data.get_or_insert_default()
        }
        pub fn with_end_of_epoch_data(mut self, field: EndOfEpochData) -> Self {
            self.end_of_epoch_data = Some(field.into());
            self
        }
    }
    impl EndOfEpochData {
        pub const fn const_default() -> Self {
            Self {
                next_epoch_validator_committee: None,
                next_epoch_protocol_version: None,
                epoch_commitments: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: EndOfEpochData = EndOfEpochData::const_default();
            &DEFAULT
        }
        pub fn next_epoch_validator_committee(&self) -> &ValidatorCommittee {
            self.next_epoch_validator_committee
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ValidatorCommittee::default_instance() as _)
        }
        pub fn next_epoch_validator_committee_opt(&self) -> Option<&ValidatorCommittee> {
            self.next_epoch_validator_committee.as_ref().map(|field| field as _)
        }
        pub fn next_epoch_validator_committee_opt_mut(
            &mut self,
        ) -> Option<&mut ValidatorCommittee> {
            self.next_epoch_validator_committee.as_mut().map(|field| field as _)
        }
        pub fn next_epoch_validator_committee_mut(&mut self) -> &mut ValidatorCommittee {
            self.next_epoch_validator_committee.get_or_insert_default()
        }
        pub fn with_next_epoch_validator_committee(
            mut self,
            field: ValidatorCommittee,
        ) -> Self {
            self.next_epoch_validator_committee = Some(field.into());
            self
        }
        pub fn with_next_epoch_protocol_version(mut self, field: u64) -> Self {
            self.next_epoch_protocol_version = Some(field.into());
            self
        }
        pub fn epoch_commitments(&self) -> &[CheckpointCommitment] {
            &self.epoch_commitments
        }
        pub fn epoch_commitments_mut(&mut self) -> &mut Vec<CheckpointCommitment> {
            &mut self.epoch_commitments
        }
        pub fn with_epoch_commitments(
            mut self,
            field: Vec<CheckpointCommitment>,
        ) -> Self {
            self.epoch_commitments = field;
            self
        }
    }
    impl CheckpointCommitment {
        pub const fn const_default() -> Self {
            Self { kind: None, digest: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: CheckpointCommitment = CheckpointCommitment::const_default();
            &DEFAULT
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
    }
    impl TransactionEffects {
        pub const fn const_default() -> Self {
            Self {
                status: None,
                epoch: None,
                fee: None,
                transaction_digest: None,
                gas_object_index: None,
                dependencies: Vec::new(),
                lamport_version: None,
                changed_objects: Vec::new(),
                unchanged_shared_objects: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: TransactionEffects = TransactionEffects::const_default();
            &DEFAULT
        }
        pub fn status(&self) -> &ExecutionStatus {
            self.status
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ExecutionStatus::default_instance() as _)
        }
        pub fn status_opt(&self) -> Option<&ExecutionStatus> {
            self.status.as_ref().map(|field| field as _)
        }
        pub fn status_opt_mut(&mut self) -> Option<&mut ExecutionStatus> {
            self.status.as_mut().map(|field| field as _)
        }
        pub fn status_mut(&mut self) -> &mut ExecutionStatus {
            self.status.get_or_insert_default()
        }
        pub fn with_status(mut self, field: ExecutionStatus) -> Self {
            self.status = Some(field.into());
            self
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn fee(&self) -> &TransactionFee {
            self.fee
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| TransactionFee::default_instance() as _)
        }
        pub fn fee_opt(&self) -> Option<&TransactionFee> {
            self.fee.as_ref().map(|field| field as _)
        }
        pub fn fee_opt_mut(&mut self) -> Option<&mut TransactionFee> {
            self.fee.as_mut().map(|field| field as _)
        }
        pub fn fee_mut(&mut self) -> &mut TransactionFee {
            self.fee.get_or_insert_default()
        }
        pub fn with_fee(mut self, field: TransactionFee) -> Self {
            self.fee = Some(field.into());
            self
        }
        pub fn with_transaction_digest(mut self, field: String) -> Self {
            self.transaction_digest = Some(field.into());
            self
        }
        pub fn with_gas_object_index(mut self, field: u32) -> Self {
            self.gas_object_index = Some(field.into());
            self
        }
        pub fn dependencies(&self) -> &[String] {
            &self.dependencies
        }
        pub fn dependencies_mut(&mut self) -> &mut Vec<String> {
            &mut self.dependencies
        }
        pub fn with_dependencies(mut self, field: Vec<String>) -> Self {
            self.dependencies = field;
            self
        }
        pub fn with_lamport_version(mut self, field: u64) -> Self {
            self.lamport_version = Some(field.into());
            self
        }
        pub fn changed_objects(&self) -> &[ChangedObject] {
            &self.changed_objects
        }
        pub fn changed_objects_mut(&mut self) -> &mut Vec<ChangedObject> {
            &mut self.changed_objects
        }
        pub fn with_changed_objects(mut self, field: Vec<ChangedObject>) -> Self {
            self.changed_objects = field;
            self
        }
        pub fn unchanged_shared_objects(&self) -> &[UnchangedSharedObject] {
            &self.unchanged_shared_objects
        }
        pub fn unchanged_shared_objects_mut(
            &mut self,
        ) -> &mut Vec<UnchangedSharedObject> {
            &mut self.unchanged_shared_objects
        }
        pub fn with_unchanged_shared_objects(
            mut self,
            field: Vec<UnchangedSharedObject>,
        ) -> Self {
            self.unchanged_shared_objects = field;
            self
        }
    }
    impl ChangedObject {
        pub const fn const_default() -> Self {
            Self {
                object_id: None,
                input_state: None,
                input_version: None,
                input_digest: None,
                input_owner: None,
                output_state: None,
                output_version: None,
                output_digest: None,
                output_owner: None,
                id_operation: None,
                object_type: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ChangedObject = ChangedObject::const_default();
            &DEFAULT
        }
        pub fn with_object_id(mut self, field: String) -> Self {
            self.object_id = Some(field.into());
            self
        }
        pub fn with_input_version(mut self, field: u64) -> Self {
            self.input_version = Some(field.into());
            self
        }
        pub fn with_input_digest(mut self, field: String) -> Self {
            self.input_digest = Some(field.into());
            self
        }
        pub fn input_owner(&self) -> &Owner {
            self.input_owner
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Owner::default_instance() as _)
        }
        pub fn input_owner_opt(&self) -> Option<&Owner> {
            self.input_owner.as_ref().map(|field| field as _)
        }
        pub fn input_owner_opt_mut(&mut self) -> Option<&mut Owner> {
            self.input_owner.as_mut().map(|field| field as _)
        }
        pub fn input_owner_mut(&mut self) -> &mut Owner {
            self.input_owner.get_or_insert_default()
        }
        pub fn with_input_owner(mut self, field: Owner) -> Self {
            self.input_owner = Some(field.into());
            self
        }
        pub fn with_output_version(mut self, field: u64) -> Self {
            self.output_version = Some(field.into());
            self
        }
        pub fn with_output_digest(mut self, field: String) -> Self {
            self.output_digest = Some(field.into());
            self
        }
        pub fn output_owner(&self) -> &Owner {
            self.output_owner
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Owner::default_instance() as _)
        }
        pub fn output_owner_opt(&self) -> Option<&Owner> {
            self.output_owner.as_ref().map(|field| field as _)
        }
        pub fn output_owner_opt_mut(&mut self) -> Option<&mut Owner> {
            self.output_owner.as_mut().map(|field| field as _)
        }
        pub fn output_owner_mut(&mut self) -> &mut Owner {
            self.output_owner.get_or_insert_default()
        }
        pub fn with_output_owner(mut self, field: Owner) -> Self {
            self.output_owner = Some(field.into());
            self
        }
        pub fn with_object_type(mut self, field: String) -> Self {
            self.object_type = Some(field.into());
            self
        }
    }
    impl UnchangedSharedObject {
        pub const fn const_default() -> Self {
            Self {
                kind: None,
                object_id: None,
                version: None,
                digest: None,
                object_type: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: UnchangedSharedObject = UnchangedSharedObject::const_default();
            &DEFAULT
        }
        pub fn with_object_id(mut self, field: String) -> Self {
            self.object_id = Some(field.into());
            self
        }
        pub fn with_version(mut self, field: u64) -> Self {
            self.version = Some(field.into());
            self
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
        pub fn with_object_type(mut self, field: String) -> Self {
            self.object_type = Some(field.into());
            self
        }
    }
    impl Epoch {
        pub const fn const_default() -> Self {
            Self {
                epoch: None,
                committee: None,
                system_state: None,
                first_checkpoint: None,
                last_checkpoint: None,
                start: None,
                end: None,
                protocol_config: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Epoch = Epoch::const_default();
            &DEFAULT
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn committee(&self) -> &ValidatorCommittee {
            self.committee
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ValidatorCommittee::default_instance() as _)
        }
        pub fn committee_opt(&self) -> Option<&ValidatorCommittee> {
            self.committee.as_ref().map(|field| field as _)
        }
        pub fn committee_opt_mut(&mut self) -> Option<&mut ValidatorCommittee> {
            self.committee.as_mut().map(|field| field as _)
        }
        pub fn committee_mut(&mut self) -> &mut ValidatorCommittee {
            self.committee.get_or_insert_default()
        }
        pub fn with_committee(mut self, field: ValidatorCommittee) -> Self {
            self.committee = Some(field.into());
            self
        }
        pub fn system_state(&self) -> &SystemState {
            self.system_state
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| SystemState::default_instance() as _)
        }
        pub fn system_state_opt(&self) -> Option<&SystemState> {
            self.system_state.as_ref().map(|field| field as _)
        }
        pub fn system_state_opt_mut(&mut self) -> Option<&mut SystemState> {
            self.system_state.as_mut().map(|field| field as _)
        }
        pub fn system_state_mut(&mut self) -> &mut SystemState {
            self.system_state.get_or_insert_default()
        }
        pub fn with_system_state(mut self, field: SystemState) -> Self {
            self.system_state = Some(field.into());
            self
        }
        pub fn with_first_checkpoint(mut self, field: u64) -> Self {
            self.first_checkpoint = Some(field.into());
            self
        }
        pub fn with_last_checkpoint(mut self, field: u64) -> Self {
            self.last_checkpoint = Some(field.into());
            self
        }
        pub fn protocol_config(&self) -> &ProtocolConfig {
            self.protocol_config
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ProtocolConfig::default_instance() as _)
        }
        pub fn protocol_config_opt(&self) -> Option<&ProtocolConfig> {
            self.protocol_config.as_ref().map(|field| field as _)
        }
        pub fn protocol_config_opt_mut(&mut self) -> Option<&mut ProtocolConfig> {
            self.protocol_config.as_mut().map(|field| field as _)
        }
        pub fn protocol_config_mut(&mut self) -> &mut ProtocolConfig {
            self.protocol_config.get_or_insert_default()
        }
        pub fn with_protocol_config(mut self, field: ProtocolConfig) -> Self {
            self.protocol_config = Some(field.into());
            self
        }
    }
    impl ExecutedTransaction {
        pub const fn const_default() -> Self {
            Self {
                digest: None,
                transaction: None,
                signatures: Vec::new(),
                effects: None,
                checkpoint: None,
                timestamp: None,
                balance_changes: Vec::new(),
                objects: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ExecutedTransaction = ExecutedTransaction::const_default();
            &DEFAULT
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
        pub fn transaction(&self) -> &Transaction {
            self.transaction
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Transaction::default_instance() as _)
        }
        pub fn transaction_opt(&self) -> Option<&Transaction> {
            self.transaction.as_ref().map(|field| field as _)
        }
        pub fn transaction_opt_mut(&mut self) -> Option<&mut Transaction> {
            self.transaction.as_mut().map(|field| field as _)
        }
        pub fn transaction_mut(&mut self) -> &mut Transaction {
            self.transaction.get_or_insert_default()
        }
        pub fn with_transaction(mut self, field: Transaction) -> Self {
            self.transaction = Some(field.into());
            self
        }
        pub fn signatures(&self) -> &[UserSignature] {
            &self.signatures
        }
        pub fn signatures_mut(&mut self) -> &mut Vec<UserSignature> {
            &mut self.signatures
        }
        pub fn with_signatures(mut self, field: Vec<UserSignature>) -> Self {
            self.signatures = field;
            self
        }
        pub fn effects(&self) -> &TransactionEffects {
            self.effects
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| TransactionEffects::default_instance() as _)
        }
        pub fn effects_opt(&self) -> Option<&TransactionEffects> {
            self.effects.as_ref().map(|field| field as _)
        }
        pub fn effects_opt_mut(&mut self) -> Option<&mut TransactionEffects> {
            self.effects.as_mut().map(|field| field as _)
        }
        pub fn effects_mut(&mut self) -> &mut TransactionEffects {
            self.effects.get_or_insert_default()
        }
        pub fn with_effects(mut self, field: TransactionEffects) -> Self {
            self.effects = Some(field.into());
            self
        }
        pub fn with_checkpoint(mut self, field: u64) -> Self {
            self.checkpoint = Some(field.into());
            self
        }
        pub fn balance_changes(&self) -> &[BalanceChange] {
            &self.balance_changes
        }
        pub fn balance_changes_mut(&mut self) -> &mut Vec<BalanceChange> {
            &mut self.balance_changes
        }
        pub fn with_balance_changes(mut self, field: Vec<BalanceChange>) -> Self {
            self.balance_changes = field;
            self
        }
        pub fn objects(&self) -> &ObjectSet {
            self.objects
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectSet::default_instance() as _)
        }
        pub fn objects_opt(&self) -> Option<&ObjectSet> {
            self.objects.as_ref().map(|field| field as _)
        }
        pub fn objects_opt_mut(&mut self) -> Option<&mut ObjectSet> {
            self.objects.as_mut().map(|field| field as _)
        }
        pub fn objects_mut(&mut self) -> &mut ObjectSet {
            self.objects.get_or_insert_default()
        }
        pub fn with_objects(mut self, field: ObjectSet) -> Self {
            self.objects = Some(field.into());
            self
        }
    }
    impl ExecutionStatus {
        pub const fn const_default() -> Self {
            Self { success: None, error: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ExecutionStatus = ExecutionStatus::const_default();
            &DEFAULT
        }
        pub fn with_success(mut self, field: bool) -> Self {
            self.success = Some(field.into());
            self
        }
        pub fn error(&self) -> &ExecutionError {
            self.error
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ExecutionError::default_instance() as _)
        }
        pub fn error_opt(&self) -> Option<&ExecutionError> {
            self.error.as_ref().map(|field| field as _)
        }
        pub fn error_opt_mut(&mut self) -> Option<&mut ExecutionError> {
            self.error.as_mut().map(|field| field as _)
        }
        pub fn error_mut(&mut self) -> &mut ExecutionError {
            self.error.get_or_insert_default()
        }
        pub fn with_error(mut self, field: ExecutionError) -> Self {
            self.error = Some(field.into());
            self
        }
    }
    impl ExecutionError {
        pub const fn const_default() -> Self {
            Self {
                description: None,
                kind: None,
                error_details: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ExecutionError = ExecutionError::const_default();
            &DEFAULT
        }
        pub fn with_description(mut self, field: String) -> Self {
            self.description = Some(field.into());
            self
        }
        pub fn object_id(&self) -> &str {
            if let Some(execution_error::ErrorDetails::ObjectId(field)) = &self
                .error_details
            {
                field as _
            } else {
                ""
            }
        }
        pub fn object_id_opt(&self) -> Option<&str> {
            if let Some(execution_error::ErrorDetails::ObjectId(field)) = &self
                .error_details
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn object_id_opt_mut(&mut self) -> Option<&mut String> {
            if let Some(execution_error::ErrorDetails::ObjectId(field)) = &mut self
                .error_details
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn object_id_mut(&mut self) -> &mut String {
            if self.object_id_opt_mut().is_none() {
                self.error_details = Some(
                    execution_error::ErrorDetails::ObjectId(String::default()),
                );
            }
            self.object_id_opt_mut().unwrap()
        }
        pub fn with_object_id(mut self, field: String) -> Self {
            self.error_details = Some(
                execution_error::ErrorDetails::ObjectId(field.into()),
            );
            self
        }
        pub fn other_error(&self) -> &str {
            if let Some(execution_error::ErrorDetails::OtherError(field)) = &self
                .error_details
            {
                field as _
            } else {
                ""
            }
        }
        pub fn other_error_opt(&self) -> Option<&str> {
            if let Some(execution_error::ErrorDetails::OtherError(field)) = &self
                .error_details
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn other_error_opt_mut(&mut self) -> Option<&mut String> {
            if let Some(execution_error::ErrorDetails::OtherError(field)) = &mut self
                .error_details
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn other_error_mut(&mut self) -> &mut String {
            if self.other_error_opt_mut().is_none() {
                self.error_details = Some(
                    execution_error::ErrorDetails::OtherError(String::default()),
                );
            }
            self.other_error_opt_mut().unwrap()
        }
        pub fn with_other_error(mut self, field: String) -> Self {
            self.error_details = Some(
                execution_error::ErrorDetails::OtherError(field.into()),
            );
            self
        }
    }
    impl GetServiceInfoRequest {
        pub const fn const_default() -> Self {
            Self {}
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetServiceInfoRequest = GetServiceInfoRequest::const_default();
            &DEFAULT
        }
    }
    impl GetServiceInfoResponse {
        pub const fn const_default() -> Self {
            Self {
                chain_id: None,
                chain: None,
                epoch: None,
                checkpoint_height: None,
                timestamp: None,
                lowest_available_checkpoint: None,
                lowest_available_checkpoint_objects: None,
                server: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetServiceInfoResponse = GetServiceInfoResponse::const_default();
            &DEFAULT
        }
        pub fn with_chain_id(mut self, field: String) -> Self {
            self.chain_id = Some(field.into());
            self
        }
        pub fn with_chain(mut self, field: String) -> Self {
            self.chain = Some(field.into());
            self
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn with_checkpoint_height(mut self, field: u64) -> Self {
            self.checkpoint_height = Some(field.into());
            self
        }
        pub fn with_lowest_available_checkpoint(mut self, field: u64) -> Self {
            self.lowest_available_checkpoint = Some(field.into());
            self
        }
        pub fn with_lowest_available_checkpoint_objects(mut self, field: u64) -> Self {
            self.lowest_available_checkpoint_objects = Some(field.into());
            self
        }
        pub fn with_server(mut self, field: String) -> Self {
            self.server = Some(field.into());
            self
        }
    }
    impl GetObjectRequest {
        pub const fn const_default() -> Self {
            Self {
                object_id: None,
                version: None,
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetObjectRequest = GetObjectRequest::const_default();
            &DEFAULT
        }
        pub fn with_object_id(mut self, field: String) -> Self {
            self.object_id = Some(field.into());
            self
        }
        pub fn with_version(mut self, field: u64) -> Self {
            self.version = Some(field.into());
            self
        }
    }
    impl GetObjectResponse {
        pub const fn const_default() -> Self {
            Self { object: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetObjectResponse = GetObjectResponse::const_default();
            &DEFAULT
        }
        pub fn object(&self) -> &Object {
            self.object
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Object::default_instance() as _)
        }
        pub fn object_opt(&self) -> Option<&Object> {
            self.object.as_ref().map(|field| field as _)
        }
        pub fn object_opt_mut(&mut self) -> Option<&mut Object> {
            self.object.as_mut().map(|field| field as _)
        }
        pub fn object_mut(&mut self) -> &mut Object {
            self.object.get_or_insert_default()
        }
        pub fn with_object(mut self, field: Object) -> Self {
            self.object = Some(field.into());
            self
        }
    }
    impl BatchGetObjectsRequest {
        pub const fn const_default() -> Self {
            Self {
                requests: Vec::new(),
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: BatchGetObjectsRequest = BatchGetObjectsRequest::const_default();
            &DEFAULT
        }
        pub fn requests(&self) -> &[GetObjectRequest] {
            &self.requests
        }
        pub fn requests_mut(&mut self) -> &mut Vec<GetObjectRequest> {
            &mut self.requests
        }
        pub fn with_requests(mut self, field: Vec<GetObjectRequest>) -> Self {
            self.requests = field;
            self
        }
    }
    impl BatchGetObjectsResponse {
        pub const fn const_default() -> Self {
            Self { objects: Vec::new() }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: BatchGetObjectsResponse = BatchGetObjectsResponse::const_default();
            &DEFAULT
        }
        pub fn objects(&self) -> &[GetObjectResult] {
            &self.objects
        }
        pub fn objects_mut(&mut self) -> &mut Vec<GetObjectResult> {
            &mut self.objects
        }
        pub fn with_objects(mut self, field: Vec<GetObjectResult>) -> Self {
            self.objects = field;
            self
        }
    }
    impl GetObjectResult {
        pub const fn const_default() -> Self {
            Self { result: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetObjectResult = GetObjectResult::const_default();
            &DEFAULT
        }
        pub fn object(&self) -> &Object {
            if let Some(get_object_result::Result::Object(field)) = &self.result {
                field as _
            } else {
                Object::default_instance() as _
            }
        }
        pub fn object_opt(&self) -> Option<&Object> {
            if let Some(get_object_result::Result::Object(field)) = &self.result {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn object_opt_mut(&mut self) -> Option<&mut Object> {
            if let Some(get_object_result::Result::Object(field)) = &mut self.result {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn object_mut(&mut self) -> &mut Object {
            if self.object_opt_mut().is_none() {
                self.result = Some(get_object_result::Result::Object(Object::default()));
            }
            self.object_opt_mut().unwrap()
        }
        pub fn with_object(mut self, field: Object) -> Self {
            self.result = Some(get_object_result::Result::Object(field.into()));
            self
        }
    }
    impl GetTransactionRequest {
        pub const fn const_default() -> Self {
            Self {
                digest: None,
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetTransactionRequest = GetTransactionRequest::const_default();
            &DEFAULT
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
    }
    impl GetTransactionResponse {
        pub const fn const_default() -> Self {
            Self { transaction: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetTransactionResponse = GetTransactionResponse::const_default();
            &DEFAULT
        }
        pub fn transaction(&self) -> &ExecutedTransaction {
            self.transaction
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ExecutedTransaction::default_instance() as _)
        }
        pub fn transaction_opt(&self) -> Option<&ExecutedTransaction> {
            self.transaction.as_ref().map(|field| field as _)
        }
        pub fn transaction_opt_mut(&mut self) -> Option<&mut ExecutedTransaction> {
            self.transaction.as_mut().map(|field| field as _)
        }
        pub fn transaction_mut(&mut self) -> &mut ExecutedTransaction {
            self.transaction.get_or_insert_default()
        }
        pub fn with_transaction(mut self, field: ExecutedTransaction) -> Self {
            self.transaction = Some(field.into());
            self
        }
    }
    impl BatchGetTransactionsRequest {
        pub const fn const_default() -> Self {
            Self {
                digests: Vec::new(),
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: BatchGetTransactionsRequest = BatchGetTransactionsRequest::const_default();
            &DEFAULT
        }
        pub fn digests(&self) -> &[String] {
            &self.digests
        }
        pub fn digests_mut(&mut self) -> &mut Vec<String> {
            &mut self.digests
        }
        pub fn with_digests(mut self, field: Vec<String>) -> Self {
            self.digests = field;
            self
        }
    }
    impl BatchGetTransactionsResponse {
        pub const fn const_default() -> Self {
            Self { transactions: Vec::new() }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: BatchGetTransactionsResponse = BatchGetTransactionsResponse::const_default();
            &DEFAULT
        }
        pub fn transactions(&self) -> &[GetTransactionResult] {
            &self.transactions
        }
        pub fn transactions_mut(&mut self) -> &mut Vec<GetTransactionResult> {
            &mut self.transactions
        }
        pub fn with_transactions(mut self, field: Vec<GetTransactionResult>) -> Self {
            self.transactions = field;
            self
        }
    }
    impl GetTransactionResult {
        pub const fn const_default() -> Self {
            Self { result: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetTransactionResult = GetTransactionResult::const_default();
            &DEFAULT
        }
        pub fn transaction(&self) -> &ExecutedTransaction {
            if let Some(get_transaction_result::Result::Transaction(field)) = &self
                .result
            {
                field as _
            } else {
                ExecutedTransaction::default_instance() as _
            }
        }
        pub fn transaction_opt(&self) -> Option<&ExecutedTransaction> {
            if let Some(get_transaction_result::Result::Transaction(field)) = &self
                .result
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn transaction_opt_mut(&mut self) -> Option<&mut ExecutedTransaction> {
            if let Some(get_transaction_result::Result::Transaction(field)) = &mut self
                .result
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn transaction_mut(&mut self) -> &mut ExecutedTransaction {
            if self.transaction_opt_mut().is_none() {
                self.result = Some(
                    get_transaction_result::Result::Transaction(
                        ExecutedTransaction::default(),
                    ),
                );
            }
            self.transaction_opt_mut().unwrap()
        }
        pub fn with_transaction(mut self, field: ExecutedTransaction) -> Self {
            self.result = Some(
                get_transaction_result::Result::Transaction(field.into()),
            );
            self
        }
    }
    impl GetCheckpointRequest {
        pub const fn const_default() -> Self {
            Self {
                read_mask: None,
                checkpoint_id: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetCheckpointRequest = GetCheckpointRequest::const_default();
            &DEFAULT
        }
        pub fn sequence_number(&self) -> u64 {
            if let Some(get_checkpoint_request::CheckpointId::SequenceNumber(field)) = &self
                .checkpoint_id
            {
                *field
            } else {
                0u64
            }
        }
        pub fn sequence_number_opt(&self) -> Option<u64> {
            if let Some(get_checkpoint_request::CheckpointId::SequenceNumber(field)) = &self
                .checkpoint_id
            {
                Some(*field)
            } else {
                None
            }
        }
        pub fn sequence_number_opt_mut(&mut self) -> Option<&mut u64> {
            if let Some(get_checkpoint_request::CheckpointId::SequenceNumber(field)) = &mut self
                .checkpoint_id
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn sequence_number_mut(&mut self) -> &mut u64 {
            if self.sequence_number_opt_mut().is_none() {
                self.checkpoint_id = Some(
                    get_checkpoint_request::CheckpointId::SequenceNumber(u64::default()),
                );
            }
            self.sequence_number_opt_mut().unwrap()
        }
        pub fn with_sequence_number(mut self, field: u64) -> Self {
            self.checkpoint_id = Some(
                get_checkpoint_request::CheckpointId::SequenceNumber(field.into()),
            );
            self
        }
        pub fn digest(&self) -> &str {
            if let Some(get_checkpoint_request::CheckpointId::Digest(field)) = &self
                .checkpoint_id
            {
                field as _
            } else {
                ""
            }
        }
        pub fn digest_opt(&self) -> Option<&str> {
            if let Some(get_checkpoint_request::CheckpointId::Digest(field)) = &self
                .checkpoint_id
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn digest_opt_mut(&mut self) -> Option<&mut String> {
            if let Some(get_checkpoint_request::CheckpointId::Digest(field)) = &mut self
                .checkpoint_id
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn digest_mut(&mut self) -> &mut String {
            if self.digest_opt_mut().is_none() {
                self.checkpoint_id = Some(
                    get_checkpoint_request::CheckpointId::Digest(String::default()),
                );
            }
            self.digest_opt_mut().unwrap()
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.checkpoint_id = Some(
                get_checkpoint_request::CheckpointId::Digest(field.into()),
            );
            self
        }
    }
    impl GetCheckpointResponse {
        pub const fn const_default() -> Self {
            Self { checkpoint: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetCheckpointResponse = GetCheckpointResponse::const_default();
            &DEFAULT
        }
        pub fn checkpoint(&self) -> &Checkpoint {
            self.checkpoint
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Checkpoint::default_instance() as _)
        }
        pub fn checkpoint_opt(&self) -> Option<&Checkpoint> {
            self.checkpoint.as_ref().map(|field| field as _)
        }
        pub fn checkpoint_opt_mut(&mut self) -> Option<&mut Checkpoint> {
            self.checkpoint.as_mut().map(|field| field as _)
        }
        pub fn checkpoint_mut(&mut self) -> &mut Checkpoint {
            self.checkpoint.get_or_insert_default()
        }
        pub fn with_checkpoint(mut self, field: Checkpoint) -> Self {
            self.checkpoint = Some(field.into());
            self
        }
    }
    impl GetEpochRequest {
        pub const fn const_default() -> Self {
            Self {
                epoch: None,
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetEpochRequest = GetEpochRequest::const_default();
            &DEFAULT
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
    }
    impl GetEpochResponse {
        pub const fn const_default() -> Self {
            Self { epoch: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetEpochResponse = GetEpochResponse::const_default();
            &DEFAULT
        }
        pub fn epoch(&self) -> &Epoch {
            self.epoch
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Epoch::default_instance() as _)
        }
        pub fn epoch_opt(&self) -> Option<&Epoch> {
            self.epoch.as_ref().map(|field| field as _)
        }
        pub fn epoch_opt_mut(&mut self) -> Option<&mut Epoch> {
            self.epoch.as_mut().map(|field| field as _)
        }
        pub fn epoch_mut(&mut self) -> &mut Epoch {
            self.epoch.get_or_insert_default()
        }
        pub fn with_epoch(mut self, field: Epoch) -> Self {
            self.epoch = Some(field.into());
            self
        }
    }
    impl Object {
        pub const fn const_default() -> Self {
            Self {
                object_id: None,
                version: None,
                digest: None,
                owner: None,
                object_type: None,
                contents: None,
                previous_transaction: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Object = Object::const_default();
            &DEFAULT
        }
        pub fn with_object_id(mut self, field: String) -> Self {
            self.object_id = Some(field.into());
            self
        }
        pub fn with_version(mut self, field: u64) -> Self {
            self.version = Some(field.into());
            self
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
        pub fn owner(&self) -> &Owner {
            self.owner
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Owner::default_instance() as _)
        }
        pub fn owner_opt(&self) -> Option<&Owner> {
            self.owner.as_ref().map(|field| field as _)
        }
        pub fn owner_opt_mut(&mut self) -> Option<&mut Owner> {
            self.owner.as_mut().map(|field| field as _)
        }
        pub fn owner_mut(&mut self) -> &mut Owner {
            self.owner.get_or_insert_default()
        }
        pub fn with_owner(mut self, field: Owner) -> Self {
            self.owner = Some(field.into());
            self
        }
        pub fn with_object_type(mut self, field: String) -> Self {
            self.object_type = Some(field.into());
            self
        }
        pub fn with_contents(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.contents = Some(field.into());
            self
        }
        pub fn with_previous_transaction(mut self, field: String) -> Self {
            self.previous_transaction = Some(field.into());
            self
        }
    }
    impl ObjectSet {
        pub const fn const_default() -> Self {
            Self { objects: Vec::new() }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ObjectSet = ObjectSet::const_default();
            &DEFAULT
        }
        pub fn objects(&self) -> &[Object] {
            &self.objects
        }
        pub fn objects_mut(&mut self) -> &mut Vec<Object> {
            &mut self.objects
        }
        pub fn with_objects(mut self, field: Vec<Object>) -> Self {
            self.objects = field;
            self
        }
    }
    impl ObjectReference {
        pub const fn const_default() -> Self {
            Self {
                object_id: None,
                version: None,
                digest: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ObjectReference = ObjectReference::const_default();
            &DEFAULT
        }
        pub fn with_object_id(mut self, field: String) -> Self {
            self.object_id = Some(field.into());
            self
        }
        pub fn with_version(mut self, field: u64) -> Self {
            self.version = Some(field.into());
            self
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
    }
    impl Owner {
        pub const fn const_default() -> Self {
            Self {
                kind: None,
                address: None,
                version: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Owner = Owner::const_default();
            &DEFAULT
        }
        pub fn with_address(mut self, field: String) -> Self {
            self.address = Some(field.into());
            self
        }
        pub fn with_version(mut self, field: u64) -> Self {
            self.version = Some(field.into());
            self
        }
    }
    impl ProtocolConfig {
        pub const fn const_default() -> Self {
            Self {
                protocol_version: None,
                feature_flags: std::collections::BTreeMap::new(),
                attributes: std::collections::BTreeMap::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ProtocolConfig = ProtocolConfig::const_default();
            &DEFAULT
        }
        pub fn with_protocol_version(mut self, field: u64) -> Self {
            self.protocol_version = Some(field.into());
            self
        }
    }
    impl UserSignature {
        pub const fn const_default() -> Self {
            Self {
                scheme: None,
                signature: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: UserSignature = UserSignature::const_default();
            &DEFAULT
        }
        pub fn simple(&self) -> &SimpleSignature {
            if let Some(user_signature::Signature::Simple(field)) = &self.signature {
                field as _
            } else {
                SimpleSignature::default_instance() as _
            }
        }
        pub fn simple_opt(&self) -> Option<&SimpleSignature> {
            if let Some(user_signature::Signature::Simple(field)) = &self.signature {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn simple_opt_mut(&mut self) -> Option<&mut SimpleSignature> {
            if let Some(user_signature::Signature::Simple(field)) = &mut self.signature {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn simple_mut(&mut self) -> &mut SimpleSignature {
            if self.simple_opt_mut().is_none() {
                self.signature = Some(
                    user_signature::Signature::Simple(SimpleSignature::default()),
                );
            }
            self.simple_opt_mut().unwrap()
        }
        pub fn with_simple(mut self, field: SimpleSignature) -> Self {
            self.signature = Some(user_signature::Signature::Simple(field.into()));
            self
        }
        pub fn multisig(&self) -> &MultisigAggregatedSignature {
            if let Some(user_signature::Signature::Multisig(field)) = &self.signature {
                field as _
            } else {
                MultisigAggregatedSignature::default_instance() as _
            }
        }
        pub fn multisig_opt(&self) -> Option<&MultisigAggregatedSignature> {
            if let Some(user_signature::Signature::Multisig(field)) = &self.signature {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn multisig_opt_mut(&mut self) -> Option<&mut MultisigAggregatedSignature> {
            if let Some(user_signature::Signature::Multisig(field)) = &mut self.signature
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn multisig_mut(&mut self) -> &mut MultisigAggregatedSignature {
            if self.multisig_opt_mut().is_none() {
                self.signature = Some(
                    user_signature::Signature::Multisig(
                        MultisigAggregatedSignature::default(),
                    ),
                );
            }
            self.multisig_opt_mut().unwrap()
        }
        pub fn with_multisig(mut self, field: MultisigAggregatedSignature) -> Self {
            self.signature = Some(user_signature::Signature::Multisig(field.into()));
            self
        }
    }
    impl SimpleSignature {
        pub const fn const_default() -> Self {
            Self {
                scheme: None,
                signature: None,
                public_key: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SimpleSignature = SimpleSignature::const_default();
            &DEFAULT
        }
        pub fn with_signature(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.signature = Some(field.into());
            self
        }
        pub fn with_public_key(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.public_key = Some(field.into());
            self
        }
    }
    impl MultisigMemberPublicKey {
        pub const fn const_default() -> Self {
            Self {
                scheme: None,
                public_key: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: MultisigMemberPublicKey = MultisigMemberPublicKey::const_default();
            &DEFAULT
        }
        pub fn with_public_key(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.public_key = Some(field.into());
            self
        }
    }
    impl MultisigMember {
        pub const fn const_default() -> Self {
            Self {
                public_key: None,
                weight: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: MultisigMember = MultisigMember::const_default();
            &DEFAULT
        }
        pub fn public_key(&self) -> &MultisigMemberPublicKey {
            self.public_key
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| MultisigMemberPublicKey::default_instance() as _)
        }
        pub fn public_key_opt(&self) -> Option<&MultisigMemberPublicKey> {
            self.public_key.as_ref().map(|field| field as _)
        }
        pub fn public_key_opt_mut(&mut self) -> Option<&mut MultisigMemberPublicKey> {
            self.public_key.as_mut().map(|field| field as _)
        }
        pub fn public_key_mut(&mut self) -> &mut MultisigMemberPublicKey {
            self.public_key.get_or_insert_default()
        }
        pub fn with_public_key(mut self, field: MultisigMemberPublicKey) -> Self {
            self.public_key = Some(field.into());
            self
        }
        pub fn with_weight(mut self, field: u32) -> Self {
            self.weight = Some(field.into());
            self
        }
    }
    impl MultisigCommittee {
        pub const fn const_default() -> Self {
            Self {
                members: Vec::new(),
                threshold: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: MultisigCommittee = MultisigCommittee::const_default();
            &DEFAULT
        }
        pub fn members(&self) -> &[MultisigMember] {
            &self.members
        }
        pub fn members_mut(&mut self) -> &mut Vec<MultisigMember> {
            &mut self.members
        }
        pub fn with_members(mut self, field: Vec<MultisigMember>) -> Self {
            self.members = field;
            self
        }
        pub fn with_threshold(mut self, field: u32) -> Self {
            self.threshold = Some(field.into());
            self
        }
    }
    impl MultisigAggregatedSignature {
        pub const fn const_default() -> Self {
            Self {
                signatures: Vec::new(),
                bitmap: None,
                committee: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: MultisigAggregatedSignature = MultisigAggregatedSignature::const_default();
            &DEFAULT
        }
        pub fn signatures(&self) -> &[MultisigMemberSignature] {
            &self.signatures
        }
        pub fn signatures_mut(&mut self) -> &mut Vec<MultisigMemberSignature> {
            &mut self.signatures
        }
        pub fn with_signatures(mut self, field: Vec<MultisigMemberSignature>) -> Self {
            self.signatures = field;
            self
        }
        pub fn with_bitmap(mut self, field: u32) -> Self {
            self.bitmap = Some(field.into());
            self
        }
        pub fn committee(&self) -> &MultisigCommittee {
            self.committee
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| MultisigCommittee::default_instance() as _)
        }
        pub fn committee_opt(&self) -> Option<&MultisigCommittee> {
            self.committee.as_ref().map(|field| field as _)
        }
        pub fn committee_opt_mut(&mut self) -> Option<&mut MultisigCommittee> {
            self.committee.as_mut().map(|field| field as _)
        }
        pub fn committee_mut(&mut self) -> &mut MultisigCommittee {
            self.committee.get_or_insert_default()
        }
        pub fn with_committee(mut self, field: MultisigCommittee) -> Self {
            self.committee = Some(field.into());
            self
        }
    }
    impl MultisigMemberSignature {
        pub const fn const_default() -> Self {
            Self {
                scheme: None,
                signature: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: MultisigMemberSignature = MultisigMemberSignature::const_default();
            &DEFAULT
        }
        pub fn with_signature(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.signature = Some(field.into());
            self
        }
    }
    impl ValidatorCommittee {
        pub const fn const_default() -> Self {
            Self {
                epoch: None,
                members: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ValidatorCommittee = ValidatorCommittee::const_default();
            &DEFAULT
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn members(&self) -> &[ValidatorCommitteeMember] {
            &self.members
        }
        pub fn members_mut(&mut self) -> &mut Vec<ValidatorCommitteeMember> {
            &mut self.members
        }
        pub fn with_members(mut self, field: Vec<ValidatorCommitteeMember>) -> Self {
            self.members = field;
            self
        }
    }
    impl ValidatorCommitteeMember {
        pub const fn const_default() -> Self {
            Self {
                authority_key: None,
                weight: None,
                network_metadata: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ValidatorCommitteeMember = ValidatorCommitteeMember::const_default();
            &DEFAULT
        }
        pub fn with_authority_key(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.authority_key = Some(field.into());
            self
        }
        pub fn with_weight(mut self, field: u64) -> Self {
            self.weight = Some(field.into());
            self
        }
        pub fn network_metadata(&self) -> &ValidatorNetworkMetadata {
            self.network_metadata
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ValidatorNetworkMetadata::default_instance() as _)
        }
        pub fn network_metadata_opt(&self) -> Option<&ValidatorNetworkMetadata> {
            self.network_metadata.as_ref().map(|field| field as _)
        }
        pub fn network_metadata_opt_mut(
            &mut self,
        ) -> Option<&mut ValidatorNetworkMetadata> {
            self.network_metadata.as_mut().map(|field| field as _)
        }
        pub fn network_metadata_mut(&mut self) -> &mut ValidatorNetworkMetadata {
            self.network_metadata.get_or_insert_default()
        }
        pub fn with_network_metadata(mut self, field: ValidatorNetworkMetadata) -> Self {
            self.network_metadata = Some(field.into());
            self
        }
    }
    impl ValidatorNetworkMetadata {
        pub const fn const_default() -> Self {
            Self {
                consensus_address: None,
                hostname: None,
                protocol_key: None,
                network_key: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ValidatorNetworkMetadata = ValidatorNetworkMetadata::const_default();
            &DEFAULT
        }
        pub fn with_consensus_address(mut self, field: String) -> Self {
            self.consensus_address = Some(field.into());
            self
        }
        pub fn with_hostname(mut self, field: String) -> Self {
            self.hostname = Some(field.into());
            self
        }
        pub fn with_protocol_key(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.protocol_key = Some(field.into());
            self
        }
        pub fn with_network_key(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.network_key = Some(field.into());
            self
        }
    }
    impl ValidatorAggregatedSignature {
        pub const fn const_default() -> Self {
            Self {
                epoch: None,
                signature: None,
                bitmap: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ValidatorAggregatedSignature = ValidatorAggregatedSignature::const_default();
            &DEFAULT
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn with_signature(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.signature = Some(field.into());
            self
        }
        pub fn bitmap(&self) -> &[u32] {
            &self.bitmap
        }
        pub fn bitmap_mut(&mut self) -> &mut Vec<u32> {
            &mut self.bitmap
        }
        pub fn with_bitmap(mut self, field: Vec<u32>) -> Self {
            self.bitmap = field;
            self
        }
    }
    impl GetBalanceRequest {
        pub const fn const_default() -> Self {
            Self { owner: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetBalanceRequest = GetBalanceRequest::const_default();
            &DEFAULT
        }
        pub fn with_owner(mut self, field: String) -> Self {
            self.owner = Some(field.into());
            self
        }
    }
    impl GetBalanceResponse {
        pub const fn const_default() -> Self {
            Self { balance: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetBalanceResponse = GetBalanceResponse::const_default();
            &DEFAULT
        }
        pub fn with_balance(mut self, field: u64) -> Self {
            self.balance = Some(field.into());
            self
        }
    }
    impl ListOwnedObjectsRequest {
        pub const fn const_default() -> Self {
            Self {
                owner: None,
                page_size: None,
                page_token: None,
                read_mask: None,
                object_type: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ListOwnedObjectsRequest = ListOwnedObjectsRequest::const_default();
            &DEFAULT
        }
        pub fn with_owner(mut self, field: String) -> Self {
            self.owner = Some(field.into());
            self
        }
        pub fn with_page_size(mut self, field: u32) -> Self {
            self.page_size = Some(field.into());
            self
        }
        pub fn with_page_token(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.page_token = Some(field.into());
            self
        }
        pub fn with_object_type(mut self, field: String) -> Self {
            self.object_type = Some(field.into());
            self
        }
    }
    impl ListOwnedObjectsResponse {
        pub const fn const_default() -> Self {
            Self {
                objects: Vec::new(),
                next_page_token: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ListOwnedObjectsResponse = ListOwnedObjectsResponse::const_default();
            &DEFAULT
        }
        pub fn objects(&self) -> &[Object] {
            &self.objects
        }
        pub fn objects_mut(&mut self) -> &mut Vec<Object> {
            &mut self.objects
        }
        pub fn with_objects(mut self, field: Vec<Object>) -> Self {
            self.objects = field;
            self
        }
        pub fn with_next_page_token(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.next_page_token = Some(field.into());
            self
        }
    }
    impl GetTargetRequest {
        pub const fn const_default() -> Self {
            Self {
                target_id: None,
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetTargetRequest = GetTargetRequest::const_default();
            &DEFAULT
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
    }
    impl GetTargetResponse {
        pub const fn const_default() -> Self {
            Self { target: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetTargetResponse = GetTargetResponse::const_default();
            &DEFAULT
        }
        pub fn target(&self) -> &Target {
            self.target
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Target::default_instance() as _)
        }
        pub fn target_opt(&self) -> Option<&Target> {
            self.target.as_ref().map(|field| field as _)
        }
        pub fn target_opt_mut(&mut self) -> Option<&mut Target> {
            self.target.as_mut().map(|field| field as _)
        }
        pub fn target_mut(&mut self) -> &mut Target {
            self.target.get_or_insert_default()
        }
        pub fn with_target(mut self, field: Target) -> Self {
            self.target = Some(field.into());
            self
        }
    }
    impl ListTargetsRequest {
        pub const fn const_default() -> Self {
            Self {
                status_filter: None,
                epoch_filter: None,
                page_size: None,
                page_token: None,
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ListTargetsRequest = ListTargetsRequest::const_default();
            &DEFAULT
        }
        pub fn with_status_filter(mut self, field: String) -> Self {
            self.status_filter = Some(field.into());
            self
        }
        pub fn with_epoch_filter(mut self, field: u64) -> Self {
            self.epoch_filter = Some(field.into());
            self
        }
        pub fn with_page_size(mut self, field: u32) -> Self {
            self.page_size = Some(field.into());
            self
        }
        pub fn with_page_token(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.page_token = Some(field.into());
            self
        }
    }
    impl ListTargetsResponse {
        pub const fn const_default() -> Self {
            Self {
                targets: Vec::new(),
                next_page_token: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ListTargetsResponse = ListTargetsResponse::const_default();
            &DEFAULT
        }
        pub fn targets(&self) -> &[Target] {
            &self.targets
        }
        pub fn targets_mut(&mut self) -> &mut Vec<Target> {
            &mut self.targets
        }
        pub fn with_targets(mut self, field: Vec<Target>) -> Self {
            self.targets = field;
            self
        }
        pub fn with_next_page_token(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.next_page_token = Some(field.into());
            self
        }
    }
    impl GetChallengeRequest {
        pub const fn const_default() -> Self {
            Self {
                challenge_id: None,
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetChallengeRequest = GetChallengeRequest::const_default();
            &DEFAULT
        }
        pub fn with_challenge_id(mut self, field: String) -> Self {
            self.challenge_id = Some(field.into());
            self
        }
    }
    impl GetChallengeResponse {
        pub const fn const_default() -> Self {
            Self { challenge: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GetChallengeResponse = GetChallengeResponse::const_default();
            &DEFAULT
        }
        pub fn challenge(&self) -> &Challenge {
            self.challenge
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Challenge::default_instance() as _)
        }
        pub fn challenge_opt(&self) -> Option<&Challenge> {
            self.challenge.as_ref().map(|field| field as _)
        }
        pub fn challenge_opt_mut(&mut self) -> Option<&mut Challenge> {
            self.challenge.as_mut().map(|field| field as _)
        }
        pub fn challenge_mut(&mut self) -> &mut Challenge {
            self.challenge.get_or_insert_default()
        }
        pub fn with_challenge(mut self, field: Challenge) -> Self {
            self.challenge = Some(field.into());
            self
        }
    }
    impl ListChallengesRequest {
        pub const fn const_default() -> Self {
            Self {
                target_id: None,
                status_filter: None,
                epoch_filter: None,
                page_size: None,
                page_token: None,
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ListChallengesRequest = ListChallengesRequest::const_default();
            &DEFAULT
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
        pub fn with_status_filter(mut self, field: String) -> Self {
            self.status_filter = Some(field.into());
            self
        }
        pub fn with_epoch_filter(mut self, field: u64) -> Self {
            self.epoch_filter = Some(field.into());
            self
        }
        pub fn with_page_size(mut self, field: u32) -> Self {
            self.page_size = Some(field.into());
            self
        }
        pub fn with_page_token(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.page_token = Some(field.into());
            self
        }
    }
    impl ListChallengesResponse {
        pub const fn const_default() -> Self {
            Self {
                challenges: Vec::new(),
                next_page_token: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ListChallengesResponse = ListChallengesResponse::const_default();
            &DEFAULT
        }
        pub fn challenges(&self) -> &[Challenge] {
            &self.challenges
        }
        pub fn challenges_mut(&mut self) -> &mut Vec<Challenge> {
            &mut self.challenges
        }
        pub fn with_challenges(mut self, field: Vec<Challenge>) -> Self {
            self.challenges = field;
            self
        }
        pub fn with_next_page_token(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.next_page_token = Some(field.into());
            self
        }
    }
    impl SubscribeCheckpointsRequest {
        pub const fn const_default() -> Self {
            Self { read_mask: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SubscribeCheckpointsRequest = SubscribeCheckpointsRequest::const_default();
            &DEFAULT
        }
    }
    impl SubscribeCheckpointsResponse {
        pub const fn const_default() -> Self {
            Self {
                cursor: None,
                checkpoint: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SubscribeCheckpointsResponse = SubscribeCheckpointsResponse::const_default();
            &DEFAULT
        }
        pub fn with_cursor(mut self, field: u64) -> Self {
            self.cursor = Some(field.into());
            self
        }
        pub fn checkpoint(&self) -> &Checkpoint {
            self.checkpoint
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Checkpoint::default_instance() as _)
        }
        pub fn checkpoint_opt(&self) -> Option<&Checkpoint> {
            self.checkpoint.as_ref().map(|field| field as _)
        }
        pub fn checkpoint_opt_mut(&mut self) -> Option<&mut Checkpoint> {
            self.checkpoint.as_mut().map(|field| field as _)
        }
        pub fn checkpoint_mut(&mut self) -> &mut Checkpoint {
            self.checkpoint.get_or_insert_default()
        }
        pub fn with_checkpoint(mut self, field: Checkpoint) -> Self {
            self.checkpoint = Some(field.into());
            self
        }
    }
    impl SystemState {
        pub const fn const_default() -> Self {
            Self {
                epoch: None,
                epoch_start_timestamp_ms: None,
                protocol_version: None,
                parameters: None,
                validators: None,
                validator_report_records: std::collections::BTreeMap::new(),
                emission_pool: None,
                target_state: None,
                model_registry: None,
                submission_report_records: std::collections::BTreeMap::new(),
                safe_mode: None,
                safe_mode_accumulated_fees: None,
                safe_mode_accumulated_emissions: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SystemState = SystemState::const_default();
            &DEFAULT
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn with_epoch_start_timestamp_ms(mut self, field: u64) -> Self {
            self.epoch_start_timestamp_ms = Some(field.into());
            self
        }
        pub fn with_protocol_version(mut self, field: u64) -> Self {
            self.protocol_version = Some(field.into());
            self
        }
        pub fn parameters(&self) -> &SystemParameters {
            self.parameters
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| SystemParameters::default_instance() as _)
        }
        pub fn parameters_opt(&self) -> Option<&SystemParameters> {
            self.parameters.as_ref().map(|field| field as _)
        }
        pub fn parameters_opt_mut(&mut self) -> Option<&mut SystemParameters> {
            self.parameters.as_mut().map(|field| field as _)
        }
        pub fn parameters_mut(&mut self) -> &mut SystemParameters {
            self.parameters.get_or_insert_default()
        }
        pub fn with_parameters(mut self, field: SystemParameters) -> Self {
            self.parameters = Some(field.into());
            self
        }
        pub fn validators(&self) -> &ValidatorSet {
            self.validators
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ValidatorSet::default_instance() as _)
        }
        pub fn validators_opt(&self) -> Option<&ValidatorSet> {
            self.validators.as_ref().map(|field| field as _)
        }
        pub fn validators_opt_mut(&mut self) -> Option<&mut ValidatorSet> {
            self.validators.as_mut().map(|field| field as _)
        }
        pub fn validators_mut(&mut self) -> &mut ValidatorSet {
            self.validators.get_or_insert_default()
        }
        pub fn with_validators(mut self, field: ValidatorSet) -> Self {
            self.validators = Some(field.into());
            self
        }
        pub fn emission_pool(&self) -> &EmissionPool {
            self.emission_pool
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| EmissionPool::default_instance() as _)
        }
        pub fn emission_pool_opt(&self) -> Option<&EmissionPool> {
            self.emission_pool.as_ref().map(|field| field as _)
        }
        pub fn emission_pool_opt_mut(&mut self) -> Option<&mut EmissionPool> {
            self.emission_pool.as_mut().map(|field| field as _)
        }
        pub fn emission_pool_mut(&mut self) -> &mut EmissionPool {
            self.emission_pool.get_or_insert_default()
        }
        pub fn with_emission_pool(mut self, field: EmissionPool) -> Self {
            self.emission_pool = Some(field.into());
            self
        }
        pub fn target_state(&self) -> &TargetState {
            self.target_state
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| TargetState::default_instance() as _)
        }
        pub fn target_state_opt(&self) -> Option<&TargetState> {
            self.target_state.as_ref().map(|field| field as _)
        }
        pub fn target_state_opt_mut(&mut self) -> Option<&mut TargetState> {
            self.target_state.as_mut().map(|field| field as _)
        }
        pub fn target_state_mut(&mut self) -> &mut TargetState {
            self.target_state.get_or_insert_default()
        }
        pub fn with_target_state(mut self, field: TargetState) -> Self {
            self.target_state = Some(field.into());
            self
        }
        pub fn model_registry(&self) -> &ModelRegistry {
            self.model_registry
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ModelRegistry::default_instance() as _)
        }
        pub fn model_registry_opt(&self) -> Option<&ModelRegistry> {
            self.model_registry.as_ref().map(|field| field as _)
        }
        pub fn model_registry_opt_mut(&mut self) -> Option<&mut ModelRegistry> {
            self.model_registry.as_mut().map(|field| field as _)
        }
        pub fn model_registry_mut(&mut self) -> &mut ModelRegistry {
            self.model_registry.get_or_insert_default()
        }
        pub fn with_model_registry(mut self, field: ModelRegistry) -> Self {
            self.model_registry = Some(field.into());
            self
        }
        pub fn with_safe_mode(mut self, field: bool) -> Self {
            self.safe_mode = Some(field.into());
            self
        }
        pub fn with_safe_mode_accumulated_fees(mut self, field: u64) -> Self {
            self.safe_mode_accumulated_fees = Some(field.into());
            self
        }
        pub fn with_safe_mode_accumulated_emissions(mut self, field: u64) -> Self {
            self.safe_mode_accumulated_emissions = Some(field.into());
            self
        }
    }
    impl ReporterSet {
        pub const fn const_default() -> Self {
            Self { reporters: Vec::new() }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ReporterSet = ReporterSet::const_default();
            &DEFAULT
        }
        pub fn reporters(&self) -> &[String] {
            &self.reporters
        }
        pub fn reporters_mut(&mut self) -> &mut Vec<String> {
            &mut self.reporters
        }
        pub fn with_reporters(mut self, field: Vec<String>) -> Self {
            self.reporters = field;
            self
        }
    }
    impl SystemParameters {
        pub const fn const_default() -> Self {
            Self {
                epoch_duration_ms: None,
                validator_reward_allocation_bps: None,
                model_min_stake: None,
                model_architecture_version: None,
                model_reveal_slash_rate_bps: None,
                model_tally_slash_rate_bps: None,
                target_epoch_fee_collection: None,
                base_fee: None,
                write_object_fee: None,
                value_fee_bps: None,
                min_value_fee_bps: None,
                max_value_fee_bps: None,
                fee_adjustment_rate_bps: None,
                target_models_per_target: None,
                target_embedding_dim: None,
                target_initial_distance_threshold: None,
                target_reward_allocation_bps: None,
                target_hit_rate_target_bps: None,
                target_hit_rate_ema_decay_bps: None,
                target_difficulty_adjustment_rate_bps: None,
                target_max_distance_threshold: None,
                target_min_distance_threshold: None,
                target_initial_targets_per_epoch: None,
                target_miner_reward_share_bps: None,
                target_model_reward_share_bps: None,
                target_claimer_incentive_bps: None,
                submission_bond_per_byte: None,
                challenger_bond_per_byte: None,
                max_submission_data_size: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SystemParameters = SystemParameters::const_default();
            &DEFAULT
        }
        pub fn with_epoch_duration_ms(mut self, field: u64) -> Self {
            self.epoch_duration_ms = Some(field.into());
            self
        }
        pub fn with_validator_reward_allocation_bps(mut self, field: u64) -> Self {
            self.validator_reward_allocation_bps = Some(field.into());
            self
        }
        pub fn with_model_min_stake(mut self, field: u64) -> Self {
            self.model_min_stake = Some(field.into());
            self
        }
        pub fn with_model_architecture_version(mut self, field: u64) -> Self {
            self.model_architecture_version = Some(field.into());
            self
        }
        pub fn with_model_reveal_slash_rate_bps(mut self, field: u64) -> Self {
            self.model_reveal_slash_rate_bps = Some(field.into());
            self
        }
        pub fn with_model_tally_slash_rate_bps(mut self, field: u64) -> Self {
            self.model_tally_slash_rate_bps = Some(field.into());
            self
        }
        pub fn with_target_epoch_fee_collection(mut self, field: u64) -> Self {
            self.target_epoch_fee_collection = Some(field.into());
            self
        }
        pub fn with_base_fee(mut self, field: u64) -> Self {
            self.base_fee = Some(field.into());
            self
        }
        pub fn with_write_object_fee(mut self, field: u64) -> Self {
            self.write_object_fee = Some(field.into());
            self
        }
        pub fn with_value_fee_bps(mut self, field: u64) -> Self {
            self.value_fee_bps = Some(field.into());
            self
        }
        pub fn with_min_value_fee_bps(mut self, field: u64) -> Self {
            self.min_value_fee_bps = Some(field.into());
            self
        }
        pub fn with_max_value_fee_bps(mut self, field: u64) -> Self {
            self.max_value_fee_bps = Some(field.into());
            self
        }
        pub fn with_fee_adjustment_rate_bps(mut self, field: u64) -> Self {
            self.fee_adjustment_rate_bps = Some(field.into());
            self
        }
        pub fn with_target_models_per_target(mut self, field: u64) -> Self {
            self.target_models_per_target = Some(field.into());
            self
        }
        pub fn with_target_embedding_dim(mut self, field: u64) -> Self {
            self.target_embedding_dim = Some(field.into());
            self
        }
        pub fn with_target_initial_distance_threshold(mut self, field: f32) -> Self {
            self.target_initial_distance_threshold = Some(field.into());
            self
        }
        pub fn with_target_reward_allocation_bps(mut self, field: u64) -> Self {
            self.target_reward_allocation_bps = Some(field.into());
            self
        }
        pub fn with_target_hit_rate_target_bps(mut self, field: u64) -> Self {
            self.target_hit_rate_target_bps = Some(field.into());
            self
        }
        pub fn with_target_hit_rate_ema_decay_bps(mut self, field: u64) -> Self {
            self.target_hit_rate_ema_decay_bps = Some(field.into());
            self
        }
        pub fn with_target_difficulty_adjustment_rate_bps(mut self, field: u64) -> Self {
            self.target_difficulty_adjustment_rate_bps = Some(field.into());
            self
        }
        pub fn with_target_max_distance_threshold(mut self, field: f32) -> Self {
            self.target_max_distance_threshold = Some(field.into());
            self
        }
        pub fn with_target_min_distance_threshold(mut self, field: f32) -> Self {
            self.target_min_distance_threshold = Some(field.into());
            self
        }
        pub fn with_target_initial_targets_per_epoch(mut self, field: u64) -> Self {
            self.target_initial_targets_per_epoch = Some(field.into());
            self
        }
        pub fn with_target_miner_reward_share_bps(mut self, field: u64) -> Self {
            self.target_miner_reward_share_bps = Some(field.into());
            self
        }
        pub fn with_target_model_reward_share_bps(mut self, field: u64) -> Self {
            self.target_model_reward_share_bps = Some(field.into());
            self
        }
        pub fn with_target_claimer_incentive_bps(mut self, field: u64) -> Self {
            self.target_claimer_incentive_bps = Some(field.into());
            self
        }
        pub fn with_submission_bond_per_byte(mut self, field: u64) -> Self {
            self.submission_bond_per_byte = Some(field.into());
            self
        }
        pub fn with_challenger_bond_per_byte(mut self, field: u64) -> Self {
            self.challenger_bond_per_byte = Some(field.into());
            self
        }
        pub fn with_max_submission_data_size(mut self, field: u64) -> Self {
            self.max_submission_data_size = Some(field.into());
            self
        }
    }
    impl EmissionPool {
        pub const fn const_default() -> Self {
            Self {
                balance: None,
                emission_per_epoch: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: EmissionPool = EmissionPool::const_default();
            &DEFAULT
        }
        pub fn with_balance(mut self, field: u64) -> Self {
            self.balance = Some(field.into());
            self
        }
        pub fn with_emission_per_epoch(mut self, field: u64) -> Self {
            self.emission_per_epoch = Some(field.into());
            self
        }
    }
    impl ValidatorSet {
        pub const fn const_default() -> Self {
            Self {
                total_stake: None,
                validators: Vec::new(),
                pending_validators: Vec::new(),
                pending_removals: Vec::new(),
                staking_pool_mappings: std::collections::BTreeMap::new(),
                inactive_validators: std::collections::BTreeMap::new(),
                at_risk_validators: std::collections::BTreeMap::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ValidatorSet = ValidatorSet::const_default();
            &DEFAULT
        }
        pub fn with_total_stake(mut self, field: u64) -> Self {
            self.total_stake = Some(field.into());
            self
        }
        pub fn validators(&self) -> &[Validator] {
            &self.validators
        }
        pub fn validators_mut(&mut self) -> &mut Vec<Validator> {
            &mut self.validators
        }
        pub fn with_validators(mut self, field: Vec<Validator>) -> Self {
            self.validators = field;
            self
        }
        pub fn pending_validators(&self) -> &[Validator] {
            &self.pending_validators
        }
        pub fn pending_validators_mut(&mut self) -> &mut Vec<Validator> {
            &mut self.pending_validators
        }
        pub fn with_pending_validators(mut self, field: Vec<Validator>) -> Self {
            self.pending_validators = field;
            self
        }
        pub fn pending_removals(&self) -> &[u32] {
            &self.pending_removals
        }
        pub fn pending_removals_mut(&mut self) -> &mut Vec<u32> {
            &mut self.pending_removals
        }
        pub fn with_pending_removals(mut self, field: Vec<u32>) -> Self {
            self.pending_removals = field;
            self
        }
    }
    impl Validator {
        pub const fn const_default() -> Self {
            Self {
                soma_address: None,
                protocol_pubkey: None,
                network_pubkey: None,
                worker_pubkey: None,
                net_address: None,
                p2p_address: None,
                primary_address: None,
                proxy_address: None,
                voting_power: None,
                commission_rate: None,
                next_epoch_stake: None,
                next_epoch_commission_rate: None,
                staking_pool: None,
                next_epoch_protocol_pubkey: None,
                next_epoch_network_pubkey: None,
                next_epoch_worker_pubkey: None,
                next_epoch_net_address: None,
                next_epoch_p2p_address: None,
                next_epoch_primary_address: None,
                next_epoch_proxy_address: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Validator = Validator::const_default();
            &DEFAULT
        }
        pub fn with_soma_address(mut self, field: String) -> Self {
            self.soma_address = Some(field.into());
            self
        }
        pub fn with_protocol_pubkey(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.protocol_pubkey = Some(field.into());
            self
        }
        pub fn with_network_pubkey(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.network_pubkey = Some(field.into());
            self
        }
        pub fn with_worker_pubkey(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.worker_pubkey = Some(field.into());
            self
        }
        pub fn with_net_address(mut self, field: String) -> Self {
            self.net_address = Some(field.into());
            self
        }
        pub fn with_p2p_address(mut self, field: String) -> Self {
            self.p2p_address = Some(field.into());
            self
        }
        pub fn with_primary_address(mut self, field: String) -> Self {
            self.primary_address = Some(field.into());
            self
        }
        pub fn with_proxy_address(mut self, field: String) -> Self {
            self.proxy_address = Some(field.into());
            self
        }
        pub fn with_voting_power(mut self, field: u64) -> Self {
            self.voting_power = Some(field.into());
            self
        }
        pub fn with_commission_rate(mut self, field: u64) -> Self {
            self.commission_rate = Some(field.into());
            self
        }
        pub fn with_next_epoch_stake(mut self, field: u64) -> Self {
            self.next_epoch_stake = Some(field.into());
            self
        }
        pub fn with_next_epoch_commission_rate(mut self, field: u64) -> Self {
            self.next_epoch_commission_rate = Some(field.into());
            self
        }
        pub fn staking_pool(&self) -> &StakingPool {
            self.staking_pool
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| StakingPool::default_instance() as _)
        }
        pub fn staking_pool_opt(&self) -> Option<&StakingPool> {
            self.staking_pool.as_ref().map(|field| field as _)
        }
        pub fn staking_pool_opt_mut(&mut self) -> Option<&mut StakingPool> {
            self.staking_pool.as_mut().map(|field| field as _)
        }
        pub fn staking_pool_mut(&mut self) -> &mut StakingPool {
            self.staking_pool.get_or_insert_default()
        }
        pub fn with_staking_pool(mut self, field: StakingPool) -> Self {
            self.staking_pool = Some(field.into());
            self
        }
        pub fn with_next_epoch_protocol_pubkey(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_protocol_pubkey = Some(field.into());
            self
        }
        pub fn with_next_epoch_network_pubkey(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_network_pubkey = Some(field.into());
            self
        }
        pub fn with_next_epoch_worker_pubkey(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_worker_pubkey = Some(field.into());
            self
        }
        pub fn with_next_epoch_net_address(mut self, field: String) -> Self {
            self.next_epoch_net_address = Some(field.into());
            self
        }
        pub fn with_next_epoch_p2p_address(mut self, field: String) -> Self {
            self.next_epoch_p2p_address = Some(field.into());
            self
        }
        pub fn with_next_epoch_primary_address(mut self, field: String) -> Self {
            self.next_epoch_primary_address = Some(field.into());
            self
        }
        pub fn with_next_epoch_proxy_address(mut self, field: String) -> Self {
            self.next_epoch_proxy_address = Some(field.into());
            self
        }
    }
    impl StakingPool {
        pub const fn const_default() -> Self {
            Self {
                id: None,
                activation_epoch: None,
                deactivation_epoch: None,
                soma_balance: None,
                rewards_pool: None,
                pool_token_balance: None,
                exchange_rates: std::collections::BTreeMap::new(),
                pending_stake: None,
                pending_total_soma_withdraw: None,
                pending_pool_token_withdraw: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: StakingPool = StakingPool::const_default();
            &DEFAULT
        }
        pub fn with_id(mut self, field: String) -> Self {
            self.id = Some(field.into());
            self
        }
        pub fn with_activation_epoch(mut self, field: u64) -> Self {
            self.activation_epoch = Some(field.into());
            self
        }
        pub fn with_deactivation_epoch(mut self, field: u64) -> Self {
            self.deactivation_epoch = Some(field.into());
            self
        }
        pub fn with_soma_balance(mut self, field: u64) -> Self {
            self.soma_balance = Some(field.into());
            self
        }
        pub fn with_rewards_pool(mut self, field: u64) -> Self {
            self.rewards_pool = Some(field.into());
            self
        }
        pub fn with_pool_token_balance(mut self, field: u64) -> Self {
            self.pool_token_balance = Some(field.into());
            self
        }
        pub fn with_pending_stake(mut self, field: u64) -> Self {
            self.pending_stake = Some(field.into());
            self
        }
        pub fn with_pending_total_soma_withdraw(mut self, field: u64) -> Self {
            self.pending_total_soma_withdraw = Some(field.into());
            self
        }
        pub fn with_pending_pool_token_withdraw(mut self, field: u64) -> Self {
            self.pending_pool_token_withdraw = Some(field.into());
            self
        }
    }
    impl PoolTokenExchangeRate {
        pub const fn const_default() -> Self {
            Self {
                soma_amount: None,
                pool_token_amount: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: PoolTokenExchangeRate = PoolTokenExchangeRate::const_default();
            &DEFAULT
        }
        pub fn with_soma_amount(mut self, field: u64) -> Self {
            self.soma_amount = Some(field.into());
            self
        }
        pub fn with_pool_token_amount(mut self, field: u64) -> Self {
            self.pool_token_amount = Some(field.into());
            self
        }
    }
    impl Model {
        pub const fn const_default() -> Self {
            Self {
                owner: None,
                architecture_version: None,
                weights_url_commitment: None,
                weights_commitment: None,
                commit_epoch: None,
                weights_manifest: None,
                embedding: Vec::new(),
                staking_pool: None,
                commission_rate: None,
                next_epoch_commission_rate: None,
                pending_update: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Model = Model::const_default();
            &DEFAULT
        }
        pub fn with_owner(mut self, field: String) -> Self {
            self.owner = Some(field.into());
            self
        }
        pub fn with_architecture_version(mut self, field: u64) -> Self {
            self.architecture_version = Some(field.into());
            self
        }
        pub fn with_weights_url_commitment(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.weights_url_commitment = Some(field.into());
            self
        }
        pub fn with_weights_commitment(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.weights_commitment = Some(field.into());
            self
        }
        pub fn with_commit_epoch(mut self, field: u64) -> Self {
            self.commit_epoch = Some(field.into());
            self
        }
        pub fn weights_manifest(&self) -> &ModelWeightsManifest {
            self.weights_manifest
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ModelWeightsManifest::default_instance() as _)
        }
        pub fn weights_manifest_opt(&self) -> Option<&ModelWeightsManifest> {
            self.weights_manifest.as_ref().map(|field| field as _)
        }
        pub fn weights_manifest_opt_mut(&mut self) -> Option<&mut ModelWeightsManifest> {
            self.weights_manifest.as_mut().map(|field| field as _)
        }
        pub fn weights_manifest_mut(&mut self) -> &mut ModelWeightsManifest {
            self.weights_manifest.get_or_insert_default()
        }
        pub fn with_weights_manifest(mut self, field: ModelWeightsManifest) -> Self {
            self.weights_manifest = Some(field.into());
            self
        }
        pub fn embedding(&self) -> &[f32] {
            &self.embedding
        }
        pub fn embedding_mut(&mut self) -> &mut Vec<f32> {
            &mut self.embedding
        }
        pub fn with_embedding(mut self, field: Vec<f32>) -> Self {
            self.embedding = field;
            self
        }
        pub fn staking_pool(&self) -> &StakingPool {
            self.staking_pool
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| StakingPool::default_instance() as _)
        }
        pub fn staking_pool_opt(&self) -> Option<&StakingPool> {
            self.staking_pool.as_ref().map(|field| field as _)
        }
        pub fn staking_pool_opt_mut(&mut self) -> Option<&mut StakingPool> {
            self.staking_pool.as_mut().map(|field| field as _)
        }
        pub fn staking_pool_mut(&mut self) -> &mut StakingPool {
            self.staking_pool.get_or_insert_default()
        }
        pub fn with_staking_pool(mut self, field: StakingPool) -> Self {
            self.staking_pool = Some(field.into());
            self
        }
        pub fn with_commission_rate(mut self, field: u64) -> Self {
            self.commission_rate = Some(field.into());
            self
        }
        pub fn with_next_epoch_commission_rate(mut self, field: u64) -> Self {
            self.next_epoch_commission_rate = Some(field.into());
            self
        }
        pub fn pending_update(&self) -> &PendingModelUpdate {
            self.pending_update
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| PendingModelUpdate::default_instance() as _)
        }
        pub fn pending_update_opt(&self) -> Option<&PendingModelUpdate> {
            self.pending_update.as_ref().map(|field| field as _)
        }
        pub fn pending_update_opt_mut(&mut self) -> Option<&mut PendingModelUpdate> {
            self.pending_update.as_mut().map(|field| field as _)
        }
        pub fn pending_update_mut(&mut self) -> &mut PendingModelUpdate {
            self.pending_update.get_or_insert_default()
        }
        pub fn with_pending_update(mut self, field: PendingModelUpdate) -> Self {
            self.pending_update = Some(field.into());
            self
        }
    }
    impl ModelRegistry {
        pub const fn const_default() -> Self {
            Self {
                active_models: std::collections::BTreeMap::new(),
                pending_models: std::collections::BTreeMap::new(),
                staking_pool_mappings: std::collections::BTreeMap::new(),
                inactive_models: std::collections::BTreeMap::new(),
                total_model_stake: None,
                model_report_records: std::collections::BTreeMap::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ModelRegistry = ModelRegistry::const_default();
            &DEFAULT
        }
        pub fn with_total_model_stake(mut self, field: u64) -> Self {
            self.total_model_stake = Some(field.into());
            self
        }
    }
    impl TargetState {
        pub const fn const_default() -> Self {
            Self {
                distance_threshold: None,
                targets_generated_this_epoch: None,
                hits_this_epoch: None,
                hit_rate_ema_bps: None,
                reward_per_target: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: TargetState = TargetState::const_default();
            &DEFAULT
        }
        pub fn with_distance_threshold(mut self, field: f32) -> Self {
            self.distance_threshold = Some(field.into());
            self
        }
        pub fn with_targets_generated_this_epoch(mut self, field: u64) -> Self {
            self.targets_generated_this_epoch = Some(field.into());
            self
        }
        pub fn with_hits_this_epoch(mut self, field: u64) -> Self {
            self.hits_this_epoch = Some(field.into());
            self
        }
        pub fn with_hit_rate_ema_bps(mut self, field: u64) -> Self {
            self.hit_rate_ema_bps = Some(field.into());
            self
        }
        pub fn with_reward_per_target(mut self, field: u64) -> Self {
            self.reward_per_target = Some(field.into());
            self
        }
    }
    impl Target {
        pub const fn const_default() -> Self {
            Self {
                id: None,
                embedding: Vec::new(),
                model_ids: Vec::new(),
                distance_threshold: None,
                reward_pool: None,
                generation_epoch: None,
                status: None,
                fill_epoch: None,
                miner: None,
                winning_model_id: None,
                winning_model_owner: None,
                bond_amount: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Target = Target::const_default();
            &DEFAULT
        }
        pub fn with_id(mut self, field: String) -> Self {
            self.id = Some(field.into());
            self
        }
        pub fn embedding(&self) -> &[f32] {
            &self.embedding
        }
        pub fn embedding_mut(&mut self) -> &mut Vec<f32> {
            &mut self.embedding
        }
        pub fn with_embedding(mut self, field: Vec<f32>) -> Self {
            self.embedding = field;
            self
        }
        pub fn model_ids(&self) -> &[String] {
            &self.model_ids
        }
        pub fn model_ids_mut(&mut self) -> &mut Vec<String> {
            &mut self.model_ids
        }
        pub fn with_model_ids(mut self, field: Vec<String>) -> Self {
            self.model_ids = field;
            self
        }
        pub fn with_distance_threshold(mut self, field: f32) -> Self {
            self.distance_threshold = Some(field.into());
            self
        }
        pub fn with_reward_pool(mut self, field: u64) -> Self {
            self.reward_pool = Some(field.into());
            self
        }
        pub fn with_generation_epoch(mut self, field: u64) -> Self {
            self.generation_epoch = Some(field.into());
            self
        }
        pub fn with_status(mut self, field: String) -> Self {
            self.status = Some(field.into());
            self
        }
        pub fn with_fill_epoch(mut self, field: u64) -> Self {
            self.fill_epoch = Some(field.into());
            self
        }
        pub fn with_miner(mut self, field: String) -> Self {
            self.miner = Some(field.into());
            self
        }
        pub fn with_winning_model_id(mut self, field: String) -> Self {
            self.winning_model_id = Some(field.into());
            self
        }
        pub fn with_winning_model_owner(mut self, field: String) -> Self {
            self.winning_model_owner = Some(field.into());
            self
        }
        pub fn with_bond_amount(mut self, field: u64) -> Self {
            self.bond_amount = Some(field.into());
            self
        }
    }
    impl Submission {
        pub const fn const_default() -> Self {
            Self {
                miner: None,
                data_commitment: None,
                data_manifest: None,
                model_id: None,
                embedding: Vec::new(),
                distance_score: None,
                bond_amount: None,
                submit_epoch: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Submission = Submission::const_default();
            &DEFAULT
        }
        pub fn with_miner(mut self, field: String) -> Self {
            self.miner = Some(field.into());
            self
        }
        pub fn with_data_commitment(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.data_commitment = Some(field.into());
            self
        }
        pub fn data_manifest(&self) -> &SubmissionManifest {
            self.data_manifest
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| SubmissionManifest::default_instance() as _)
        }
        pub fn data_manifest_opt(&self) -> Option<&SubmissionManifest> {
            self.data_manifest.as_ref().map(|field| field as _)
        }
        pub fn data_manifest_opt_mut(&mut self) -> Option<&mut SubmissionManifest> {
            self.data_manifest.as_mut().map(|field| field as _)
        }
        pub fn data_manifest_mut(&mut self) -> &mut SubmissionManifest {
            self.data_manifest.get_or_insert_default()
        }
        pub fn with_data_manifest(mut self, field: SubmissionManifest) -> Self {
            self.data_manifest = Some(field.into());
            self
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn embedding(&self) -> &[f32] {
            &self.embedding
        }
        pub fn embedding_mut(&mut self) -> &mut Vec<f32> {
            &mut self.embedding
        }
        pub fn with_embedding(mut self, field: Vec<f32>) -> Self {
            self.embedding = field;
            self
        }
        pub fn with_distance_score(mut self, field: f32) -> Self {
            self.distance_score = Some(field.into());
            self
        }
        pub fn with_bond_amount(mut self, field: u64) -> Self {
            self.bond_amount = Some(field.into());
            self
        }
        pub fn with_submit_epoch(mut self, field: u64) -> Self {
            self.submit_epoch = Some(field.into());
            self
        }
    }
    impl Challenge {
        pub const fn const_default() -> Self {
            Self {
                id: None,
                target_id: None,
                challenger: None,
                challenger_bond: None,
                challenge_epoch: None,
                status: None,
                verdict: None,
                win_reason: None,
                distance_threshold: None,
                winning_distance_score: None,
                winning_model_id: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Challenge = Challenge::const_default();
            &DEFAULT
        }
        pub fn with_id(mut self, field: String) -> Self {
            self.id = Some(field.into());
            self
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
        pub fn with_challenger(mut self, field: String) -> Self {
            self.challenger = Some(field.into());
            self
        }
        pub fn with_challenger_bond(mut self, field: u64) -> Self {
            self.challenger_bond = Some(field.into());
            self
        }
        pub fn with_challenge_epoch(mut self, field: u64) -> Self {
            self.challenge_epoch = Some(field.into());
            self
        }
        pub fn with_status(mut self, field: String) -> Self {
            self.status = Some(field.into());
            self
        }
        pub fn with_verdict(mut self, field: String) -> Self {
            self.verdict = Some(field.into());
            self
        }
        pub fn with_win_reason(mut self, field: String) -> Self {
            self.win_reason = Some(field.into());
            self
        }
        pub fn with_distance_threshold(mut self, field: f32) -> Self {
            self.distance_threshold = Some(field.into());
            self
        }
        pub fn with_winning_distance_score(mut self, field: f32) -> Self {
            self.winning_distance_score = Some(field.into());
            self
        }
        pub fn with_winning_model_id(mut self, field: String) -> Self {
            self.winning_model_id = Some(field.into());
            self
        }
    }
    impl Transaction {
        pub const fn const_default() -> Self {
            Self {
                digest: None,
                kind: None,
                sender: None,
                gas_payment: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Transaction = Transaction::const_default();
            &DEFAULT
        }
        pub fn with_digest(mut self, field: String) -> Self {
            self.digest = Some(field.into());
            self
        }
        pub fn kind(&self) -> &TransactionKind {
            self.kind
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| TransactionKind::default_instance() as _)
        }
        pub fn kind_opt(&self) -> Option<&TransactionKind> {
            self.kind.as_ref().map(|field| field as _)
        }
        pub fn kind_opt_mut(&mut self) -> Option<&mut TransactionKind> {
            self.kind.as_mut().map(|field| field as _)
        }
        pub fn kind_mut(&mut self) -> &mut TransactionKind {
            self.kind.get_or_insert_default()
        }
        pub fn with_kind(mut self, field: TransactionKind) -> Self {
            self.kind = Some(field.into());
            self
        }
        pub fn with_sender(mut self, field: String) -> Self {
            self.sender = Some(field.into());
            self
        }
        pub fn gas_payment(&self) -> &[ObjectReference] {
            &self.gas_payment
        }
        pub fn gas_payment_mut(&mut self) -> &mut Vec<ObjectReference> {
            &mut self.gas_payment
        }
        pub fn with_gas_payment(mut self, field: Vec<ObjectReference>) -> Self {
            self.gas_payment = field;
            self
        }
    }
    impl TransactionKind {
        pub const fn const_default() -> Self {
            Self { kind: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: TransactionKind = TransactionKind::const_default();
            &DEFAULT
        }
        pub fn genesis(&self) -> &GenesisTransaction {
            if let Some(transaction_kind::Kind::Genesis(field)) = &self.kind {
                field as _
            } else {
                GenesisTransaction::default_instance() as _
            }
        }
        pub fn genesis_opt(&self) -> Option<&GenesisTransaction> {
            if let Some(transaction_kind::Kind::Genesis(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn genesis_opt_mut(&mut self) -> Option<&mut GenesisTransaction> {
            if let Some(transaction_kind::Kind::Genesis(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn genesis_mut(&mut self) -> &mut GenesisTransaction {
            if self.genesis_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::Genesis(GenesisTransaction::default()),
                );
            }
            self.genesis_opt_mut().unwrap()
        }
        pub fn with_genesis(mut self, field: GenesisTransaction) -> Self {
            self.kind = Some(transaction_kind::Kind::Genesis(field.into()));
            self
        }
        pub fn consensus_commit_prologue(&self) -> &ConsensusCommitPrologue {
            if let Some(transaction_kind::Kind::ConsensusCommitPrologue(field)) = &self
                .kind
            {
                field as _
            } else {
                ConsensusCommitPrologue::default_instance() as _
            }
        }
        pub fn consensus_commit_prologue_opt(&self) -> Option<&ConsensusCommitPrologue> {
            if let Some(transaction_kind::Kind::ConsensusCommitPrologue(field)) = &self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn consensus_commit_prologue_opt_mut(
            &mut self,
        ) -> Option<&mut ConsensusCommitPrologue> {
            if let Some(transaction_kind::Kind::ConsensusCommitPrologue(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn consensus_commit_prologue_mut(&mut self) -> &mut ConsensusCommitPrologue {
            if self.consensus_commit_prologue_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ConsensusCommitPrologue(
                        ConsensusCommitPrologue::default(),
                    ),
                );
            }
            self.consensus_commit_prologue_opt_mut().unwrap()
        }
        pub fn with_consensus_commit_prologue(
            mut self,
            field: ConsensusCommitPrologue,
        ) -> Self {
            self.kind = Some(
                transaction_kind::Kind::ConsensusCommitPrologue(field.into()),
            );
            self
        }
        pub fn change_epoch(&self) -> &ChangeEpoch {
            if let Some(transaction_kind::Kind::ChangeEpoch(field)) = &self.kind {
                field as _
            } else {
                ChangeEpoch::default_instance() as _
            }
        }
        pub fn change_epoch_opt(&self) -> Option<&ChangeEpoch> {
            if let Some(transaction_kind::Kind::ChangeEpoch(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn change_epoch_opt_mut(&mut self) -> Option<&mut ChangeEpoch> {
            if let Some(transaction_kind::Kind::ChangeEpoch(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn change_epoch_mut(&mut self) -> &mut ChangeEpoch {
            if self.change_epoch_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ChangeEpoch(ChangeEpoch::default()),
                );
            }
            self.change_epoch_opt_mut().unwrap()
        }
        pub fn with_change_epoch(mut self, field: ChangeEpoch) -> Self {
            self.kind = Some(transaction_kind::Kind::ChangeEpoch(field.into()));
            self
        }
        pub fn add_validator(&self) -> &AddValidator {
            if let Some(transaction_kind::Kind::AddValidator(field)) = &self.kind {
                field as _
            } else {
                AddValidator::default_instance() as _
            }
        }
        pub fn add_validator_opt(&self) -> Option<&AddValidator> {
            if let Some(transaction_kind::Kind::AddValidator(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn add_validator_opt_mut(&mut self) -> Option<&mut AddValidator> {
            if let Some(transaction_kind::Kind::AddValidator(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn add_validator_mut(&mut self) -> &mut AddValidator {
            if self.add_validator_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::AddValidator(AddValidator::default()),
                );
            }
            self.add_validator_opt_mut().unwrap()
        }
        pub fn with_add_validator(mut self, field: AddValidator) -> Self {
            self.kind = Some(transaction_kind::Kind::AddValidator(field.into()));
            self
        }
        pub fn remove_validator(&self) -> &RemoveValidator {
            if let Some(transaction_kind::Kind::RemoveValidator(field)) = &self.kind {
                field as _
            } else {
                RemoveValidator::default_instance() as _
            }
        }
        pub fn remove_validator_opt(&self) -> Option<&RemoveValidator> {
            if let Some(transaction_kind::Kind::RemoveValidator(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn remove_validator_opt_mut(&mut self) -> Option<&mut RemoveValidator> {
            if let Some(transaction_kind::Kind::RemoveValidator(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn remove_validator_mut(&mut self) -> &mut RemoveValidator {
            if self.remove_validator_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::RemoveValidator(RemoveValidator::default()),
                );
            }
            self.remove_validator_opt_mut().unwrap()
        }
        pub fn with_remove_validator(mut self, field: RemoveValidator) -> Self {
            self.kind = Some(transaction_kind::Kind::RemoveValidator(field.into()));
            self
        }
        pub fn report_validator(&self) -> &ReportValidator {
            if let Some(transaction_kind::Kind::ReportValidator(field)) = &self.kind {
                field as _
            } else {
                ReportValidator::default_instance() as _
            }
        }
        pub fn report_validator_opt(&self) -> Option<&ReportValidator> {
            if let Some(transaction_kind::Kind::ReportValidator(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_validator_opt_mut(&mut self) -> Option<&mut ReportValidator> {
            if let Some(transaction_kind::Kind::ReportValidator(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_validator_mut(&mut self) -> &mut ReportValidator {
            if self.report_validator_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ReportValidator(ReportValidator::default()),
                );
            }
            self.report_validator_opt_mut().unwrap()
        }
        pub fn with_report_validator(mut self, field: ReportValidator) -> Self {
            self.kind = Some(transaction_kind::Kind::ReportValidator(field.into()));
            self
        }
        pub fn undo_report_validator(&self) -> &UndoReportValidator {
            if let Some(transaction_kind::Kind::UndoReportValidator(field)) = &self.kind
            {
                field as _
            } else {
                UndoReportValidator::default_instance() as _
            }
        }
        pub fn undo_report_validator_opt(&self) -> Option<&UndoReportValidator> {
            if let Some(transaction_kind::Kind::UndoReportValidator(field)) = &self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_validator_opt_mut(
            &mut self,
        ) -> Option<&mut UndoReportValidator> {
            if let Some(transaction_kind::Kind::UndoReportValidator(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_validator_mut(&mut self) -> &mut UndoReportValidator {
            if self.undo_report_validator_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::UndoReportValidator(
                        UndoReportValidator::default(),
                    ),
                );
            }
            self.undo_report_validator_opt_mut().unwrap()
        }
        pub fn with_undo_report_validator(mut self, field: UndoReportValidator) -> Self {
            self.kind = Some(transaction_kind::Kind::UndoReportValidator(field.into()));
            self
        }
        pub fn update_validator_metadata(&self) -> &UpdateValidatorMetadata {
            if let Some(transaction_kind::Kind::UpdateValidatorMetadata(field)) = &self
                .kind
            {
                field as _
            } else {
                UpdateValidatorMetadata::default_instance() as _
            }
        }
        pub fn update_validator_metadata_opt(&self) -> Option<&UpdateValidatorMetadata> {
            if let Some(transaction_kind::Kind::UpdateValidatorMetadata(field)) = &self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn update_validator_metadata_opt_mut(
            &mut self,
        ) -> Option<&mut UpdateValidatorMetadata> {
            if let Some(transaction_kind::Kind::UpdateValidatorMetadata(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn update_validator_metadata_mut(&mut self) -> &mut UpdateValidatorMetadata {
            if self.update_validator_metadata_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::UpdateValidatorMetadata(
                        UpdateValidatorMetadata::default(),
                    ),
                );
            }
            self.update_validator_metadata_opt_mut().unwrap()
        }
        pub fn with_update_validator_metadata(
            mut self,
            field: UpdateValidatorMetadata,
        ) -> Self {
            self.kind = Some(
                transaction_kind::Kind::UpdateValidatorMetadata(field.into()),
            );
            self
        }
        pub fn set_commission_rate(&self) -> &SetCommissionRate {
            if let Some(transaction_kind::Kind::SetCommissionRate(field)) = &self.kind {
                field as _
            } else {
                SetCommissionRate::default_instance() as _
            }
        }
        pub fn set_commission_rate_opt(&self) -> Option<&SetCommissionRate> {
            if let Some(transaction_kind::Kind::SetCommissionRate(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn set_commission_rate_opt_mut(&mut self) -> Option<&mut SetCommissionRate> {
            if let Some(transaction_kind::Kind::SetCommissionRate(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn set_commission_rate_mut(&mut self) -> &mut SetCommissionRate {
            if self.set_commission_rate_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::SetCommissionRate(
                        SetCommissionRate::default(),
                    ),
                );
            }
            self.set_commission_rate_opt_mut().unwrap()
        }
        pub fn with_set_commission_rate(mut self, field: SetCommissionRate) -> Self {
            self.kind = Some(transaction_kind::Kind::SetCommissionRate(field.into()));
            self
        }
        pub fn transfer_coin(&self) -> &TransferCoin {
            if let Some(transaction_kind::Kind::TransferCoin(field)) = &self.kind {
                field as _
            } else {
                TransferCoin::default_instance() as _
            }
        }
        pub fn transfer_coin_opt(&self) -> Option<&TransferCoin> {
            if let Some(transaction_kind::Kind::TransferCoin(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn transfer_coin_opt_mut(&mut self) -> Option<&mut TransferCoin> {
            if let Some(transaction_kind::Kind::TransferCoin(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn transfer_coin_mut(&mut self) -> &mut TransferCoin {
            if self.transfer_coin_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::TransferCoin(TransferCoin::default()),
                );
            }
            self.transfer_coin_opt_mut().unwrap()
        }
        pub fn with_transfer_coin(mut self, field: TransferCoin) -> Self {
            self.kind = Some(transaction_kind::Kind::TransferCoin(field.into()));
            self
        }
        pub fn pay_coins(&self) -> &PayCoins {
            if let Some(transaction_kind::Kind::PayCoins(field)) = &self.kind {
                field as _
            } else {
                PayCoins::default_instance() as _
            }
        }
        pub fn pay_coins_opt(&self) -> Option<&PayCoins> {
            if let Some(transaction_kind::Kind::PayCoins(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn pay_coins_opt_mut(&mut self) -> Option<&mut PayCoins> {
            if let Some(transaction_kind::Kind::PayCoins(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn pay_coins_mut(&mut self) -> &mut PayCoins {
            if self.pay_coins_opt_mut().is_none() {
                self.kind = Some(transaction_kind::Kind::PayCoins(PayCoins::default()));
            }
            self.pay_coins_opt_mut().unwrap()
        }
        pub fn with_pay_coins(mut self, field: PayCoins) -> Self {
            self.kind = Some(transaction_kind::Kind::PayCoins(field.into()));
            self
        }
        pub fn transfer_objects(&self) -> &TransferObjects {
            if let Some(transaction_kind::Kind::TransferObjects(field)) = &self.kind {
                field as _
            } else {
                TransferObjects::default_instance() as _
            }
        }
        pub fn transfer_objects_opt(&self) -> Option<&TransferObjects> {
            if let Some(transaction_kind::Kind::TransferObjects(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn transfer_objects_opt_mut(&mut self) -> Option<&mut TransferObjects> {
            if let Some(transaction_kind::Kind::TransferObjects(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn transfer_objects_mut(&mut self) -> &mut TransferObjects {
            if self.transfer_objects_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::TransferObjects(TransferObjects::default()),
                );
            }
            self.transfer_objects_opt_mut().unwrap()
        }
        pub fn with_transfer_objects(mut self, field: TransferObjects) -> Self {
            self.kind = Some(transaction_kind::Kind::TransferObjects(field.into()));
            self
        }
        pub fn add_stake(&self) -> &AddStake {
            if let Some(transaction_kind::Kind::AddStake(field)) = &self.kind {
                field as _
            } else {
                AddStake::default_instance() as _
            }
        }
        pub fn add_stake_opt(&self) -> Option<&AddStake> {
            if let Some(transaction_kind::Kind::AddStake(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn add_stake_opt_mut(&mut self) -> Option<&mut AddStake> {
            if let Some(transaction_kind::Kind::AddStake(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn add_stake_mut(&mut self) -> &mut AddStake {
            if self.add_stake_opt_mut().is_none() {
                self.kind = Some(transaction_kind::Kind::AddStake(AddStake::default()));
            }
            self.add_stake_opt_mut().unwrap()
        }
        pub fn with_add_stake(mut self, field: AddStake) -> Self {
            self.kind = Some(transaction_kind::Kind::AddStake(field.into()));
            self
        }
        pub fn withdraw_stake(&self) -> &WithdrawStake {
            if let Some(transaction_kind::Kind::WithdrawStake(field)) = &self.kind {
                field as _
            } else {
                WithdrawStake::default_instance() as _
            }
        }
        pub fn withdraw_stake_opt(&self) -> Option<&WithdrawStake> {
            if let Some(transaction_kind::Kind::WithdrawStake(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn withdraw_stake_opt_mut(&mut self) -> Option<&mut WithdrawStake> {
            if let Some(transaction_kind::Kind::WithdrawStake(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn withdraw_stake_mut(&mut self) -> &mut WithdrawStake {
            if self.withdraw_stake_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::WithdrawStake(WithdrawStake::default()),
                );
            }
            self.withdraw_stake_opt_mut().unwrap()
        }
        pub fn with_withdraw_stake(mut self, field: WithdrawStake) -> Self {
            self.kind = Some(transaction_kind::Kind::WithdrawStake(field.into()));
            self
        }
        pub fn commit_model(&self) -> &CommitModel {
            if let Some(transaction_kind::Kind::CommitModel(field)) = &self.kind {
                field as _
            } else {
                CommitModel::default_instance() as _
            }
        }
        pub fn commit_model_opt(&self) -> Option<&CommitModel> {
            if let Some(transaction_kind::Kind::CommitModel(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn commit_model_opt_mut(&mut self) -> Option<&mut CommitModel> {
            if let Some(transaction_kind::Kind::CommitModel(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn commit_model_mut(&mut self) -> &mut CommitModel {
            if self.commit_model_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::CommitModel(CommitModel::default()),
                );
            }
            self.commit_model_opt_mut().unwrap()
        }
        pub fn with_commit_model(mut self, field: CommitModel) -> Self {
            self.kind = Some(transaction_kind::Kind::CommitModel(field.into()));
            self
        }
        pub fn reveal_model(&self) -> &RevealModel {
            if let Some(transaction_kind::Kind::RevealModel(field)) = &self.kind {
                field as _
            } else {
                RevealModel::default_instance() as _
            }
        }
        pub fn reveal_model_opt(&self) -> Option<&RevealModel> {
            if let Some(transaction_kind::Kind::RevealModel(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn reveal_model_opt_mut(&mut self) -> Option<&mut RevealModel> {
            if let Some(transaction_kind::Kind::RevealModel(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn reveal_model_mut(&mut self) -> &mut RevealModel {
            if self.reveal_model_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::RevealModel(RevealModel::default()),
                );
            }
            self.reveal_model_opt_mut().unwrap()
        }
        pub fn with_reveal_model(mut self, field: RevealModel) -> Self {
            self.kind = Some(transaction_kind::Kind::RevealModel(field.into()));
            self
        }
        pub fn commit_model_update(&self) -> &CommitModelUpdate {
            if let Some(transaction_kind::Kind::CommitModelUpdate(field)) = &self.kind {
                field as _
            } else {
                CommitModelUpdate::default_instance() as _
            }
        }
        pub fn commit_model_update_opt(&self) -> Option<&CommitModelUpdate> {
            if let Some(transaction_kind::Kind::CommitModelUpdate(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn commit_model_update_opt_mut(&mut self) -> Option<&mut CommitModelUpdate> {
            if let Some(transaction_kind::Kind::CommitModelUpdate(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn commit_model_update_mut(&mut self) -> &mut CommitModelUpdate {
            if self.commit_model_update_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::CommitModelUpdate(
                        CommitModelUpdate::default(),
                    ),
                );
            }
            self.commit_model_update_opt_mut().unwrap()
        }
        pub fn with_commit_model_update(mut self, field: CommitModelUpdate) -> Self {
            self.kind = Some(transaction_kind::Kind::CommitModelUpdate(field.into()));
            self
        }
        pub fn reveal_model_update(&self) -> &RevealModelUpdate {
            if let Some(transaction_kind::Kind::RevealModelUpdate(field)) = &self.kind {
                field as _
            } else {
                RevealModelUpdate::default_instance() as _
            }
        }
        pub fn reveal_model_update_opt(&self) -> Option<&RevealModelUpdate> {
            if let Some(transaction_kind::Kind::RevealModelUpdate(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn reveal_model_update_opt_mut(&mut self) -> Option<&mut RevealModelUpdate> {
            if let Some(transaction_kind::Kind::RevealModelUpdate(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn reveal_model_update_mut(&mut self) -> &mut RevealModelUpdate {
            if self.reveal_model_update_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::RevealModelUpdate(
                        RevealModelUpdate::default(),
                    ),
                );
            }
            self.reveal_model_update_opt_mut().unwrap()
        }
        pub fn with_reveal_model_update(mut self, field: RevealModelUpdate) -> Self {
            self.kind = Some(transaction_kind::Kind::RevealModelUpdate(field.into()));
            self
        }
        pub fn add_stake_to_model(&self) -> &AddStakeToModel {
            if let Some(transaction_kind::Kind::AddStakeToModel(field)) = &self.kind {
                field as _
            } else {
                AddStakeToModel::default_instance() as _
            }
        }
        pub fn add_stake_to_model_opt(&self) -> Option<&AddStakeToModel> {
            if let Some(transaction_kind::Kind::AddStakeToModel(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn add_stake_to_model_opt_mut(&mut self) -> Option<&mut AddStakeToModel> {
            if let Some(transaction_kind::Kind::AddStakeToModel(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn add_stake_to_model_mut(&mut self) -> &mut AddStakeToModel {
            if self.add_stake_to_model_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::AddStakeToModel(AddStakeToModel::default()),
                );
            }
            self.add_stake_to_model_opt_mut().unwrap()
        }
        pub fn with_add_stake_to_model(mut self, field: AddStakeToModel) -> Self {
            self.kind = Some(transaction_kind::Kind::AddStakeToModel(field.into()));
            self
        }
        pub fn set_model_commission_rate(&self) -> &SetModelCommissionRate {
            if let Some(transaction_kind::Kind::SetModelCommissionRate(field)) = &self
                .kind
            {
                field as _
            } else {
                SetModelCommissionRate::default_instance() as _
            }
        }
        pub fn set_model_commission_rate_opt(&self) -> Option<&SetModelCommissionRate> {
            if let Some(transaction_kind::Kind::SetModelCommissionRate(field)) = &self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn set_model_commission_rate_opt_mut(
            &mut self,
        ) -> Option<&mut SetModelCommissionRate> {
            if let Some(transaction_kind::Kind::SetModelCommissionRate(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn set_model_commission_rate_mut(&mut self) -> &mut SetModelCommissionRate {
            if self.set_model_commission_rate_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::SetModelCommissionRate(
                        SetModelCommissionRate::default(),
                    ),
                );
            }
            self.set_model_commission_rate_opt_mut().unwrap()
        }
        pub fn with_set_model_commission_rate(
            mut self,
            field: SetModelCommissionRate,
        ) -> Self {
            self.kind = Some(
                transaction_kind::Kind::SetModelCommissionRate(field.into()),
            );
            self
        }
        pub fn deactivate_model(&self) -> &DeactivateModel {
            if let Some(transaction_kind::Kind::DeactivateModel(field)) = &self.kind {
                field as _
            } else {
                DeactivateModel::default_instance() as _
            }
        }
        pub fn deactivate_model_opt(&self) -> Option<&DeactivateModel> {
            if let Some(transaction_kind::Kind::DeactivateModel(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn deactivate_model_opt_mut(&mut self) -> Option<&mut DeactivateModel> {
            if let Some(transaction_kind::Kind::DeactivateModel(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn deactivate_model_mut(&mut self) -> &mut DeactivateModel {
            if self.deactivate_model_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::DeactivateModel(DeactivateModel::default()),
                );
            }
            self.deactivate_model_opt_mut().unwrap()
        }
        pub fn with_deactivate_model(mut self, field: DeactivateModel) -> Self {
            self.kind = Some(transaction_kind::Kind::DeactivateModel(field.into()));
            self
        }
        pub fn report_model(&self) -> &ReportModel {
            if let Some(transaction_kind::Kind::ReportModel(field)) = &self.kind {
                field as _
            } else {
                ReportModel::default_instance() as _
            }
        }
        pub fn report_model_opt(&self) -> Option<&ReportModel> {
            if let Some(transaction_kind::Kind::ReportModel(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_model_opt_mut(&mut self) -> Option<&mut ReportModel> {
            if let Some(transaction_kind::Kind::ReportModel(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_model_mut(&mut self) -> &mut ReportModel {
            if self.report_model_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ReportModel(ReportModel::default()),
                );
            }
            self.report_model_opt_mut().unwrap()
        }
        pub fn with_report_model(mut self, field: ReportModel) -> Self {
            self.kind = Some(transaction_kind::Kind::ReportModel(field.into()));
            self
        }
        pub fn undo_report_model(&self) -> &UndoReportModel {
            if let Some(transaction_kind::Kind::UndoReportModel(field)) = &self.kind {
                field as _
            } else {
                UndoReportModel::default_instance() as _
            }
        }
        pub fn undo_report_model_opt(&self) -> Option<&UndoReportModel> {
            if let Some(transaction_kind::Kind::UndoReportModel(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_model_opt_mut(&mut self) -> Option<&mut UndoReportModel> {
            if let Some(transaction_kind::Kind::UndoReportModel(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_model_mut(&mut self) -> &mut UndoReportModel {
            if self.undo_report_model_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::UndoReportModel(UndoReportModel::default()),
                );
            }
            self.undo_report_model_opt_mut().unwrap()
        }
        pub fn with_undo_report_model(mut self, field: UndoReportModel) -> Self {
            self.kind = Some(transaction_kind::Kind::UndoReportModel(field.into()));
            self
        }
        pub fn submit_data(&self) -> &SubmitData {
            if let Some(transaction_kind::Kind::SubmitData(field)) = &self.kind {
                field as _
            } else {
                SubmitData::default_instance() as _
            }
        }
        pub fn submit_data_opt(&self) -> Option<&SubmitData> {
            if let Some(transaction_kind::Kind::SubmitData(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn submit_data_opt_mut(&mut self) -> Option<&mut SubmitData> {
            if let Some(transaction_kind::Kind::SubmitData(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn submit_data_mut(&mut self) -> &mut SubmitData {
            if self.submit_data_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::SubmitData(SubmitData::default()),
                );
            }
            self.submit_data_opt_mut().unwrap()
        }
        pub fn with_submit_data(mut self, field: SubmitData) -> Self {
            self.kind = Some(transaction_kind::Kind::SubmitData(field.into()));
            self
        }
        pub fn claim_rewards(&self) -> &ClaimRewards {
            if let Some(transaction_kind::Kind::ClaimRewards(field)) = &self.kind {
                field as _
            } else {
                ClaimRewards::default_instance() as _
            }
        }
        pub fn claim_rewards_opt(&self) -> Option<&ClaimRewards> {
            if let Some(transaction_kind::Kind::ClaimRewards(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn claim_rewards_opt_mut(&mut self) -> Option<&mut ClaimRewards> {
            if let Some(transaction_kind::Kind::ClaimRewards(field)) = &mut self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn claim_rewards_mut(&mut self) -> &mut ClaimRewards {
            if self.claim_rewards_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ClaimRewards(ClaimRewards::default()),
                );
            }
            self.claim_rewards_opt_mut().unwrap()
        }
        pub fn with_claim_rewards(mut self, field: ClaimRewards) -> Self {
            self.kind = Some(transaction_kind::Kind::ClaimRewards(field.into()));
            self
        }
        pub fn report_submission(&self) -> &ReportSubmission {
            if let Some(transaction_kind::Kind::ReportSubmission(field)) = &self.kind {
                field as _
            } else {
                ReportSubmission::default_instance() as _
            }
        }
        pub fn report_submission_opt(&self) -> Option<&ReportSubmission> {
            if let Some(transaction_kind::Kind::ReportSubmission(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_submission_opt_mut(&mut self) -> Option<&mut ReportSubmission> {
            if let Some(transaction_kind::Kind::ReportSubmission(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_submission_mut(&mut self) -> &mut ReportSubmission {
            if self.report_submission_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ReportSubmission(ReportSubmission::default()),
                );
            }
            self.report_submission_opt_mut().unwrap()
        }
        pub fn with_report_submission(mut self, field: ReportSubmission) -> Self {
            self.kind = Some(transaction_kind::Kind::ReportSubmission(field.into()));
            self
        }
        pub fn undo_report_submission(&self) -> &UndoReportSubmission {
            if let Some(transaction_kind::Kind::UndoReportSubmission(field)) = &self.kind
            {
                field as _
            } else {
                UndoReportSubmission::default_instance() as _
            }
        }
        pub fn undo_report_submission_opt(&self) -> Option<&UndoReportSubmission> {
            if let Some(transaction_kind::Kind::UndoReportSubmission(field)) = &self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_submission_opt_mut(
            &mut self,
        ) -> Option<&mut UndoReportSubmission> {
            if let Some(transaction_kind::Kind::UndoReportSubmission(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_submission_mut(&mut self) -> &mut UndoReportSubmission {
            if self.undo_report_submission_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::UndoReportSubmission(
                        UndoReportSubmission::default(),
                    ),
                );
            }
            self.undo_report_submission_opt_mut().unwrap()
        }
        pub fn with_undo_report_submission(
            mut self,
            field: UndoReportSubmission,
        ) -> Self {
            self.kind = Some(transaction_kind::Kind::UndoReportSubmission(field.into()));
            self
        }
        pub fn initiate_challenge(&self) -> &InitiateChallenge {
            if let Some(transaction_kind::Kind::InitiateChallenge(field)) = &self.kind {
                field as _
            } else {
                InitiateChallenge::default_instance() as _
            }
        }
        pub fn initiate_challenge_opt(&self) -> Option<&InitiateChallenge> {
            if let Some(transaction_kind::Kind::InitiateChallenge(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn initiate_challenge_opt_mut(&mut self) -> Option<&mut InitiateChallenge> {
            if let Some(transaction_kind::Kind::InitiateChallenge(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn initiate_challenge_mut(&mut self) -> &mut InitiateChallenge {
            if self.initiate_challenge_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::InitiateChallenge(
                        InitiateChallenge::default(),
                    ),
                );
            }
            self.initiate_challenge_opt_mut().unwrap()
        }
        pub fn with_initiate_challenge(mut self, field: InitiateChallenge) -> Self {
            self.kind = Some(transaction_kind::Kind::InitiateChallenge(field.into()));
            self
        }
        pub fn report_challenge(&self) -> &ReportChallenge {
            if let Some(transaction_kind::Kind::ReportChallenge(field)) = &self.kind {
                field as _
            } else {
                ReportChallenge::default_instance() as _
            }
        }
        pub fn report_challenge_opt(&self) -> Option<&ReportChallenge> {
            if let Some(transaction_kind::Kind::ReportChallenge(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_challenge_opt_mut(&mut self) -> Option<&mut ReportChallenge> {
            if let Some(transaction_kind::Kind::ReportChallenge(field)) = &mut self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn report_challenge_mut(&mut self) -> &mut ReportChallenge {
            if self.report_challenge_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ReportChallenge(ReportChallenge::default()),
                );
            }
            self.report_challenge_opt_mut().unwrap()
        }
        pub fn with_report_challenge(mut self, field: ReportChallenge) -> Self {
            self.kind = Some(transaction_kind::Kind::ReportChallenge(field.into()));
            self
        }
        pub fn undo_report_challenge(&self) -> &UndoReportChallenge {
            if let Some(transaction_kind::Kind::UndoReportChallenge(field)) = &self.kind
            {
                field as _
            } else {
                UndoReportChallenge::default_instance() as _
            }
        }
        pub fn undo_report_challenge_opt(&self) -> Option<&UndoReportChallenge> {
            if let Some(transaction_kind::Kind::UndoReportChallenge(field)) = &self.kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_challenge_opt_mut(
            &mut self,
        ) -> Option<&mut UndoReportChallenge> {
            if let Some(transaction_kind::Kind::UndoReportChallenge(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn undo_report_challenge_mut(&mut self) -> &mut UndoReportChallenge {
            if self.undo_report_challenge_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::UndoReportChallenge(
                        UndoReportChallenge::default(),
                    ),
                );
            }
            self.undo_report_challenge_opt_mut().unwrap()
        }
        pub fn with_undo_report_challenge(mut self, field: UndoReportChallenge) -> Self {
            self.kind = Some(transaction_kind::Kind::UndoReportChallenge(field.into()));
            self
        }
        pub fn claim_challenge_bond(&self) -> &ClaimChallengeBond {
            if let Some(transaction_kind::Kind::ClaimChallengeBond(field)) = &self.kind {
                field as _
            } else {
                ClaimChallengeBond::default_instance() as _
            }
        }
        pub fn claim_challenge_bond_opt(&self) -> Option<&ClaimChallengeBond> {
            if let Some(transaction_kind::Kind::ClaimChallengeBond(field)) = &self.kind {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn claim_challenge_bond_opt_mut(
            &mut self,
        ) -> Option<&mut ClaimChallengeBond> {
            if let Some(transaction_kind::Kind::ClaimChallengeBond(field)) = &mut self
                .kind
            {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn claim_challenge_bond_mut(&mut self) -> &mut ClaimChallengeBond {
            if self.claim_challenge_bond_opt_mut().is_none() {
                self.kind = Some(
                    transaction_kind::Kind::ClaimChallengeBond(
                        ClaimChallengeBond::default(),
                    ),
                );
            }
            self.claim_challenge_bond_opt_mut().unwrap()
        }
        pub fn with_claim_challenge_bond(mut self, field: ClaimChallengeBond) -> Self {
            self.kind = Some(transaction_kind::Kind::ClaimChallengeBond(field.into()));
            self
        }
    }
    impl AddValidator {
        pub const fn const_default() -> Self {
            Self {
                pubkey_bytes: None,
                network_pubkey_bytes: None,
                worker_pubkey_bytes: None,
                net_address: None,
                p2p_address: None,
                primary_address: None,
                proxy_address: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: AddValidator = AddValidator::const_default();
            &DEFAULT
        }
        pub fn with_pubkey_bytes(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.pubkey_bytes = Some(field.into());
            self
        }
        pub fn with_network_pubkey_bytes(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.network_pubkey_bytes = Some(field.into());
            self
        }
        pub fn with_worker_pubkey_bytes(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.worker_pubkey_bytes = Some(field.into());
            self
        }
        pub fn with_net_address(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.net_address = Some(field.into());
            self
        }
        pub fn with_p2p_address(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.p2p_address = Some(field.into());
            self
        }
        pub fn with_primary_address(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.primary_address = Some(field.into());
            self
        }
        pub fn with_proxy_address(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.proxy_address = Some(field.into());
            self
        }
    }
    impl RemoveValidator {
        pub const fn const_default() -> Self {
            Self { pubkey_bytes: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: RemoveValidator = RemoveValidator::const_default();
            &DEFAULT
        }
        pub fn with_pubkey_bytes(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.pubkey_bytes = Some(field.into());
            self
        }
    }
    impl ReportValidator {
        pub const fn const_default() -> Self {
            Self { reportee: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ReportValidator = ReportValidator::const_default();
            &DEFAULT
        }
        pub fn with_reportee(mut self, field: String) -> Self {
            self.reportee = Some(field.into());
            self
        }
    }
    impl UndoReportValidator {
        pub const fn const_default() -> Self {
            Self { reportee: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: UndoReportValidator = UndoReportValidator::const_default();
            &DEFAULT
        }
        pub fn with_reportee(mut self, field: String) -> Self {
            self.reportee = Some(field.into());
            self
        }
    }
    impl UpdateValidatorMetadata {
        pub const fn const_default() -> Self {
            Self {
                next_epoch_network_address: None,
                next_epoch_p2p_address: None,
                next_epoch_primary_address: None,
                next_epoch_proxy_address: None,
                next_epoch_protocol_pubkey: None,
                next_epoch_worker_pubkey: None,
                next_epoch_network_pubkey: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: UpdateValidatorMetadata = UpdateValidatorMetadata::const_default();
            &DEFAULT
        }
        pub fn with_next_epoch_network_address(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_network_address = Some(field.into());
            self
        }
        pub fn with_next_epoch_p2p_address(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_p2p_address = Some(field.into());
            self
        }
        pub fn with_next_epoch_primary_address(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_primary_address = Some(field.into());
            self
        }
        pub fn with_next_epoch_proxy_address(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_proxy_address = Some(field.into());
            self
        }
        pub fn with_next_epoch_protocol_pubkey(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_protocol_pubkey = Some(field.into());
            self
        }
        pub fn with_next_epoch_worker_pubkey(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_worker_pubkey = Some(field.into());
            self
        }
        pub fn with_next_epoch_network_pubkey(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.next_epoch_network_pubkey = Some(field.into());
            self
        }
    }
    impl SetCommissionRate {
        pub const fn const_default() -> Self {
            Self { new_rate: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SetCommissionRate = SetCommissionRate::const_default();
            &DEFAULT
        }
        pub fn with_new_rate(mut self, field: u64) -> Self {
            self.new_rate = Some(field.into());
            self
        }
    }
    impl TransferCoin {
        pub const fn const_default() -> Self {
            Self {
                coin: None,
                amount: None,
                recipient: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: TransferCoin = TransferCoin::const_default();
            &DEFAULT
        }
        pub fn coin(&self) -> &ObjectReference {
            self.coin
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectReference::default_instance() as _)
        }
        pub fn coin_opt(&self) -> Option<&ObjectReference> {
            self.coin.as_ref().map(|field| field as _)
        }
        pub fn coin_opt_mut(&mut self) -> Option<&mut ObjectReference> {
            self.coin.as_mut().map(|field| field as _)
        }
        pub fn coin_mut(&mut self) -> &mut ObjectReference {
            self.coin.get_or_insert_default()
        }
        pub fn with_coin(mut self, field: ObjectReference) -> Self {
            self.coin = Some(field.into());
            self
        }
        pub fn with_amount(mut self, field: u64) -> Self {
            self.amount = Some(field.into());
            self
        }
        pub fn with_recipient(mut self, field: String) -> Self {
            self.recipient = Some(field.into());
            self
        }
    }
    impl PayCoins {
        pub const fn const_default() -> Self {
            Self {
                coins: Vec::new(),
                amounts: Vec::new(),
                recipients: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: PayCoins = PayCoins::const_default();
            &DEFAULT
        }
        pub fn coins(&self) -> &[ObjectReference] {
            &self.coins
        }
        pub fn coins_mut(&mut self) -> &mut Vec<ObjectReference> {
            &mut self.coins
        }
        pub fn with_coins(mut self, field: Vec<ObjectReference>) -> Self {
            self.coins = field;
            self
        }
        pub fn amounts(&self) -> &[u64] {
            &self.amounts
        }
        pub fn amounts_mut(&mut self) -> &mut Vec<u64> {
            &mut self.amounts
        }
        pub fn with_amounts(mut self, field: Vec<u64>) -> Self {
            self.amounts = field;
            self
        }
        pub fn recipients(&self) -> &[String] {
            &self.recipients
        }
        pub fn recipients_mut(&mut self) -> &mut Vec<String> {
            &mut self.recipients
        }
        pub fn with_recipients(mut self, field: Vec<String>) -> Self {
            self.recipients = field;
            self
        }
    }
    impl TransferObjects {
        pub const fn const_default() -> Self {
            Self {
                objects: Vec::new(),
                recipient: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: TransferObjects = TransferObjects::const_default();
            &DEFAULT
        }
        pub fn objects(&self) -> &[ObjectReference] {
            &self.objects
        }
        pub fn objects_mut(&mut self) -> &mut Vec<ObjectReference> {
            &mut self.objects
        }
        pub fn with_objects(mut self, field: Vec<ObjectReference>) -> Self {
            self.objects = field;
            self
        }
        pub fn with_recipient(mut self, field: String) -> Self {
            self.recipient = Some(field.into());
            self
        }
    }
    impl AddStake {
        pub const fn const_default() -> Self {
            Self {
                address: None,
                coin_ref: None,
                amount: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: AddStake = AddStake::const_default();
            &DEFAULT
        }
        pub fn with_address(mut self, field: String) -> Self {
            self.address = Some(field.into());
            self
        }
        pub fn coin_ref(&self) -> &ObjectReference {
            self.coin_ref
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectReference::default_instance() as _)
        }
        pub fn coin_ref_opt(&self) -> Option<&ObjectReference> {
            self.coin_ref.as_ref().map(|field| field as _)
        }
        pub fn coin_ref_opt_mut(&mut self) -> Option<&mut ObjectReference> {
            self.coin_ref.as_mut().map(|field| field as _)
        }
        pub fn coin_ref_mut(&mut self) -> &mut ObjectReference {
            self.coin_ref.get_or_insert_default()
        }
        pub fn with_coin_ref(mut self, field: ObjectReference) -> Self {
            self.coin_ref = Some(field.into());
            self
        }
        pub fn with_amount(mut self, field: u64) -> Self {
            self.amount = Some(field.into());
            self
        }
    }
    impl WithdrawStake {
        pub const fn const_default() -> Self {
            Self { staked_soma: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: WithdrawStake = WithdrawStake::const_default();
            &DEFAULT
        }
        pub fn staked_soma(&self) -> &ObjectReference {
            self.staked_soma
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectReference::default_instance() as _)
        }
        pub fn staked_soma_opt(&self) -> Option<&ObjectReference> {
            self.staked_soma.as_ref().map(|field| field as _)
        }
        pub fn staked_soma_opt_mut(&mut self) -> Option<&mut ObjectReference> {
            self.staked_soma.as_mut().map(|field| field as _)
        }
        pub fn staked_soma_mut(&mut self) -> &mut ObjectReference {
            self.staked_soma.get_or_insert_default()
        }
        pub fn with_staked_soma(mut self, field: ObjectReference) -> Self {
            self.staked_soma = Some(field.into());
            self
        }
    }
    impl Metadata {
        pub const fn const_default() -> Self {
            Self { version: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Metadata = Metadata::const_default();
            &DEFAULT
        }
        pub fn v1(&self) -> &MetadataV1 {
            if let Some(metadata::Version::V1(field)) = &self.version {
                field as _
            } else {
                MetadataV1::default_instance() as _
            }
        }
        pub fn v1_opt(&self) -> Option<&MetadataV1> {
            if let Some(metadata::Version::V1(field)) = &self.version {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn v1_opt_mut(&mut self) -> Option<&mut MetadataV1> {
            if let Some(metadata::Version::V1(field)) = &mut self.version {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn v1_mut(&mut self) -> &mut MetadataV1 {
            if self.v1_opt_mut().is_none() {
                self.version = Some(metadata::Version::V1(MetadataV1::default()));
            }
            self.v1_opt_mut().unwrap()
        }
        pub fn with_v1(mut self, field: MetadataV1) -> Self {
            self.version = Some(metadata::Version::V1(field.into()));
            self
        }
    }
    impl MetadataV1 {
        pub const fn const_default() -> Self {
            Self { checksum: None, size: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: MetadataV1 = MetadataV1::const_default();
            &DEFAULT
        }
        pub fn with_checksum(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.checksum = Some(field.into());
            self
        }
        pub fn with_size(mut self, field: u64) -> Self {
            self.size = Some(field.into());
            self
        }
    }
    impl Manifest {
        pub const fn const_default() -> Self {
            Self { version: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: Manifest = Manifest::const_default();
            &DEFAULT
        }
        pub fn v1(&self) -> &ManifestV1 {
            if let Some(manifest::Version::V1(field)) = &self.version {
                field as _
            } else {
                ManifestV1::default_instance() as _
            }
        }
        pub fn v1_opt(&self) -> Option<&ManifestV1> {
            if let Some(manifest::Version::V1(field)) = &self.version {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn v1_opt_mut(&mut self) -> Option<&mut ManifestV1> {
            if let Some(manifest::Version::V1(field)) = &mut self.version {
                Some(field as _)
            } else {
                None
            }
        }
        pub fn v1_mut(&mut self) -> &mut ManifestV1 {
            if self.v1_opt_mut().is_none() {
                self.version = Some(manifest::Version::V1(ManifestV1::default()));
            }
            self.v1_opt_mut().unwrap()
        }
        pub fn with_v1(mut self, field: ManifestV1) -> Self {
            self.version = Some(manifest::Version::V1(field.into()));
            self
        }
    }
    impl ManifestV1 {
        pub const fn const_default() -> Self {
            Self { url: None, metadata: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ManifestV1 = ManifestV1::const_default();
            &DEFAULT
        }
        pub fn with_url(mut self, field: String) -> Self {
            self.url = Some(field.into());
            self
        }
        pub fn metadata(&self) -> &Metadata {
            self.metadata
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Metadata::default_instance() as _)
        }
        pub fn metadata_opt(&self) -> Option<&Metadata> {
            self.metadata.as_ref().map(|field| field as _)
        }
        pub fn metadata_opt_mut(&mut self) -> Option<&mut Metadata> {
            self.metadata.as_mut().map(|field| field as _)
        }
        pub fn metadata_mut(&mut self) -> &mut Metadata {
            self.metadata.get_or_insert_default()
        }
        pub fn with_metadata(mut self, field: Metadata) -> Self {
            self.metadata = Some(field.into());
            self
        }
    }
    impl ModelWeightsManifest {
        pub const fn const_default() -> Self {
            Self {
                manifest: None,
                decryption_key: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ModelWeightsManifest = ModelWeightsManifest::const_default();
            &DEFAULT
        }
        pub fn manifest(&self) -> &Manifest {
            self.manifest
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Manifest::default_instance() as _)
        }
        pub fn manifest_opt(&self) -> Option<&Manifest> {
            self.manifest.as_ref().map(|field| field as _)
        }
        pub fn manifest_opt_mut(&mut self) -> Option<&mut Manifest> {
            self.manifest.as_mut().map(|field| field as _)
        }
        pub fn manifest_mut(&mut self) -> &mut Manifest {
            self.manifest.get_or_insert_default()
        }
        pub fn with_manifest(mut self, field: Manifest) -> Self {
            self.manifest = Some(field.into());
            self
        }
        pub fn with_decryption_key(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.decryption_key = Some(field.into());
            self
        }
    }
    impl PendingModelUpdate {
        pub const fn const_default() -> Self {
            Self {
                weights_url_commitment: None,
                weights_commitment: None,
                commit_epoch: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: PendingModelUpdate = PendingModelUpdate::const_default();
            &DEFAULT
        }
        pub fn with_weights_url_commitment(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.weights_url_commitment = Some(field.into());
            self
        }
        pub fn with_weights_commitment(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.weights_commitment = Some(field.into());
            self
        }
        pub fn with_commit_epoch(mut self, field: u64) -> Self {
            self.commit_epoch = Some(field.into());
            self
        }
    }
    impl CommitModel {
        pub const fn const_default() -> Self {
            Self {
                model_id: None,
                weights_url_commitment: None,
                weights_commitment: None,
                architecture_version: None,
                stake_amount: None,
                commission_rate: None,
                staking_pool_id: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: CommitModel = CommitModel::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn with_weights_url_commitment(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.weights_url_commitment = Some(field.into());
            self
        }
        pub fn with_weights_commitment(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.weights_commitment = Some(field.into());
            self
        }
        pub fn with_architecture_version(mut self, field: u64) -> Self {
            self.architecture_version = Some(field.into());
            self
        }
        pub fn with_stake_amount(mut self, field: u64) -> Self {
            self.stake_amount = Some(field.into());
            self
        }
        pub fn with_commission_rate(mut self, field: u64) -> Self {
            self.commission_rate = Some(field.into());
            self
        }
        pub fn with_staking_pool_id(mut self, field: String) -> Self {
            self.staking_pool_id = Some(field.into());
            self
        }
    }
    impl RevealModel {
        pub const fn const_default() -> Self {
            Self {
                model_id: None,
                weights_manifest: None,
                embedding: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: RevealModel = RevealModel::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn weights_manifest(&self) -> &ModelWeightsManifest {
            self.weights_manifest
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ModelWeightsManifest::default_instance() as _)
        }
        pub fn weights_manifest_opt(&self) -> Option<&ModelWeightsManifest> {
            self.weights_manifest.as_ref().map(|field| field as _)
        }
        pub fn weights_manifest_opt_mut(&mut self) -> Option<&mut ModelWeightsManifest> {
            self.weights_manifest.as_mut().map(|field| field as _)
        }
        pub fn weights_manifest_mut(&mut self) -> &mut ModelWeightsManifest {
            self.weights_manifest.get_or_insert_default()
        }
        pub fn with_weights_manifest(mut self, field: ModelWeightsManifest) -> Self {
            self.weights_manifest = Some(field.into());
            self
        }
        pub fn embedding(&self) -> &[f32] {
            &self.embedding
        }
        pub fn embedding_mut(&mut self) -> &mut Vec<f32> {
            &mut self.embedding
        }
        pub fn with_embedding(mut self, field: Vec<f32>) -> Self {
            self.embedding = field;
            self
        }
    }
    impl CommitModelUpdate {
        pub const fn const_default() -> Self {
            Self {
                model_id: None,
                weights_url_commitment: None,
                weights_commitment: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: CommitModelUpdate = CommitModelUpdate::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn with_weights_url_commitment(
            mut self,
            field: ::prost::bytes::Bytes,
        ) -> Self {
            self.weights_url_commitment = Some(field.into());
            self
        }
        pub fn with_weights_commitment(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.weights_commitment = Some(field.into());
            self
        }
    }
    impl RevealModelUpdate {
        pub const fn const_default() -> Self {
            Self {
                model_id: None,
                weights_manifest: None,
                embedding: Vec::new(),
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: RevealModelUpdate = RevealModelUpdate::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn weights_manifest(&self) -> &ModelWeightsManifest {
            self.weights_manifest
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ModelWeightsManifest::default_instance() as _)
        }
        pub fn weights_manifest_opt(&self) -> Option<&ModelWeightsManifest> {
            self.weights_manifest.as_ref().map(|field| field as _)
        }
        pub fn weights_manifest_opt_mut(&mut self) -> Option<&mut ModelWeightsManifest> {
            self.weights_manifest.as_mut().map(|field| field as _)
        }
        pub fn weights_manifest_mut(&mut self) -> &mut ModelWeightsManifest {
            self.weights_manifest.get_or_insert_default()
        }
        pub fn with_weights_manifest(mut self, field: ModelWeightsManifest) -> Self {
            self.weights_manifest = Some(field.into());
            self
        }
        pub fn embedding(&self) -> &[f32] {
            &self.embedding
        }
        pub fn embedding_mut(&mut self) -> &mut Vec<f32> {
            &mut self.embedding
        }
        pub fn with_embedding(mut self, field: Vec<f32>) -> Self {
            self.embedding = field;
            self
        }
    }
    impl AddStakeToModel {
        pub const fn const_default() -> Self {
            Self {
                model_id: None,
                coin_ref: None,
                amount: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: AddStakeToModel = AddStakeToModel::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn coin_ref(&self) -> &ObjectReference {
            self.coin_ref
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectReference::default_instance() as _)
        }
        pub fn coin_ref_opt(&self) -> Option<&ObjectReference> {
            self.coin_ref.as_ref().map(|field| field as _)
        }
        pub fn coin_ref_opt_mut(&mut self) -> Option<&mut ObjectReference> {
            self.coin_ref.as_mut().map(|field| field as _)
        }
        pub fn coin_ref_mut(&mut self) -> &mut ObjectReference {
            self.coin_ref.get_or_insert_default()
        }
        pub fn with_coin_ref(mut self, field: ObjectReference) -> Self {
            self.coin_ref = Some(field.into());
            self
        }
        pub fn with_amount(mut self, field: u64) -> Self {
            self.amount = Some(field.into());
            self
        }
    }
    impl SetModelCommissionRate {
        pub const fn const_default() -> Self {
            Self {
                model_id: None,
                new_rate: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SetModelCommissionRate = SetModelCommissionRate::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn with_new_rate(mut self, field: u64) -> Self {
            self.new_rate = Some(field.into());
            self
        }
    }
    impl DeactivateModel {
        pub const fn const_default() -> Self {
            Self { model_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: DeactivateModel = DeactivateModel::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
    }
    impl ReportModel {
        pub const fn const_default() -> Self {
            Self { model_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ReportModel = ReportModel::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
    }
    impl UndoReportModel {
        pub const fn const_default() -> Self {
            Self { model_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: UndoReportModel = UndoReportModel::const_default();
            &DEFAULT
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
    }
    impl ReportSubmission {
        pub const fn const_default() -> Self {
            Self {
                target_id: None,
                challenger: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ReportSubmission = ReportSubmission::const_default();
            &DEFAULT
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
        pub fn with_challenger(mut self, field: String) -> Self {
            self.challenger = Some(field.into());
            self
        }
    }
    impl UndoReportSubmission {
        pub const fn const_default() -> Self {
            Self { target_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: UndoReportSubmission = UndoReportSubmission::const_default();
            &DEFAULT
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
    }
    impl ChangeEpoch {
        pub const fn const_default() -> Self {
            Self {
                epoch: None,
                epoch_start_timestamp: None,
                protocol_version: None,
                fees: None,
                epoch_randomness: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ChangeEpoch = ChangeEpoch::const_default();
            &DEFAULT
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn with_protocol_version(mut self, field: u64) -> Self {
            self.protocol_version = Some(field.into());
            self
        }
        pub fn with_fees(mut self, field: u64) -> Self {
            self.fees = Some(field.into());
            self
        }
        pub fn with_epoch_randomness(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.epoch_randomness = Some(field.into());
            self
        }
    }
    impl GenesisTransaction {
        pub const fn const_default() -> Self {
            Self { objects: Vec::new() }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: GenesisTransaction = GenesisTransaction::const_default();
            &DEFAULT
        }
        pub fn objects(&self) -> &[Object] {
            &self.objects
        }
        pub fn objects_mut(&mut self) -> &mut Vec<Object> {
            &mut self.objects
        }
        pub fn with_objects(mut self, field: Vec<Object>) -> Self {
            self.objects = field;
            self
        }
    }
    impl ConsensusCommitPrologue {
        pub const fn const_default() -> Self {
            Self {
                epoch: None,
                round: None,
                sub_dag_index: None,
                commit_timestamp: None,
                consensus_commit_digest: None,
                additional_state_digest: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ConsensusCommitPrologue = ConsensusCommitPrologue::const_default();
            &DEFAULT
        }
        pub fn with_epoch(mut self, field: u64) -> Self {
            self.epoch = Some(field.into());
            self
        }
        pub fn with_round(mut self, field: u64) -> Self {
            self.round = Some(field.into());
            self
        }
        pub fn with_sub_dag_index(mut self, field: u64) -> Self {
            self.sub_dag_index = Some(field.into());
            self
        }
        pub fn with_consensus_commit_digest(mut self, field: String) -> Self {
            self.consensus_commit_digest = Some(field.into());
            self
        }
        pub fn with_additional_state_digest(mut self, field: String) -> Self {
            self.additional_state_digest = Some(field.into());
            self
        }
    }
    impl SubmitData {
        pub const fn const_default() -> Self {
            Self {
                target_id: None,
                data_commitment: None,
                data_manifest: None,
                model_id: None,
                embedding: Vec::new(),
                distance_score: None,
                bond_coin: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SubmitData = SubmitData::const_default();
            &DEFAULT
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
        pub fn with_data_commitment(mut self, field: ::prost::bytes::Bytes) -> Self {
            self.data_commitment = Some(field.into());
            self
        }
        pub fn data_manifest(&self) -> &SubmissionManifest {
            self.data_manifest
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| SubmissionManifest::default_instance() as _)
        }
        pub fn data_manifest_opt(&self) -> Option<&SubmissionManifest> {
            self.data_manifest.as_ref().map(|field| field as _)
        }
        pub fn data_manifest_opt_mut(&mut self) -> Option<&mut SubmissionManifest> {
            self.data_manifest.as_mut().map(|field| field as _)
        }
        pub fn data_manifest_mut(&mut self) -> &mut SubmissionManifest {
            self.data_manifest.get_or_insert_default()
        }
        pub fn with_data_manifest(mut self, field: SubmissionManifest) -> Self {
            self.data_manifest = Some(field.into());
            self
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn embedding(&self) -> &[f32] {
            &self.embedding
        }
        pub fn embedding_mut(&mut self) -> &mut Vec<f32> {
            &mut self.embedding
        }
        pub fn with_embedding(mut self, field: Vec<f32>) -> Self {
            self.embedding = field;
            self
        }
        pub fn with_distance_score(mut self, field: f32) -> Self {
            self.distance_score = Some(field.into());
            self
        }
        pub fn bond_coin(&self) -> &ObjectReference {
            self.bond_coin
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectReference::default_instance() as _)
        }
        pub fn bond_coin_opt(&self) -> Option<&ObjectReference> {
            self.bond_coin.as_ref().map(|field| field as _)
        }
        pub fn bond_coin_opt_mut(&mut self) -> Option<&mut ObjectReference> {
            self.bond_coin.as_mut().map(|field| field as _)
        }
        pub fn bond_coin_mut(&mut self) -> &mut ObjectReference {
            self.bond_coin.get_or_insert_default()
        }
        pub fn with_bond_coin(mut self, field: ObjectReference) -> Self {
            self.bond_coin = Some(field.into());
            self
        }
    }
    impl ClaimRewards {
        pub const fn const_default() -> Self {
            Self { target_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ClaimRewards = ClaimRewards::const_default();
            &DEFAULT
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
    }
    impl SubmissionManifest {
        pub const fn const_default() -> Self {
            Self { manifest: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SubmissionManifest = SubmissionManifest::const_default();
            &DEFAULT
        }
        pub fn manifest(&self) -> &Manifest {
            self.manifest
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Manifest::default_instance() as _)
        }
        pub fn manifest_opt(&self) -> Option<&Manifest> {
            self.manifest.as_ref().map(|field| field as _)
        }
        pub fn manifest_opt_mut(&mut self) -> Option<&mut Manifest> {
            self.manifest.as_mut().map(|field| field as _)
        }
        pub fn manifest_mut(&mut self) -> &mut Manifest {
            self.manifest.get_or_insert_default()
        }
        pub fn with_manifest(mut self, field: Manifest) -> Self {
            self.manifest = Some(field.into());
            self
        }
    }
    impl InitiateChallenge {
        pub const fn const_default() -> Self {
            Self {
                target_id: None,
                challenge_type: None,
                model_id: None,
                bond_coin: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: InitiateChallenge = InitiateChallenge::const_default();
            &DEFAULT
        }
        pub fn with_target_id(mut self, field: String) -> Self {
            self.target_id = Some(field.into());
            self
        }
        pub fn with_challenge_type(mut self, field: String) -> Self {
            self.challenge_type = Some(field.into());
            self
        }
        pub fn with_model_id(mut self, field: String) -> Self {
            self.model_id = Some(field.into());
            self
        }
        pub fn bond_coin(&self) -> &ObjectReference {
            self.bond_coin
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ObjectReference::default_instance() as _)
        }
        pub fn bond_coin_opt(&self) -> Option<&ObjectReference> {
            self.bond_coin.as_ref().map(|field| field as _)
        }
        pub fn bond_coin_opt_mut(&mut self) -> Option<&mut ObjectReference> {
            self.bond_coin.as_mut().map(|field| field as _)
        }
        pub fn bond_coin_mut(&mut self) -> &mut ObjectReference {
            self.bond_coin.get_or_insert_default()
        }
        pub fn with_bond_coin(mut self, field: ObjectReference) -> Self {
            self.bond_coin = Some(field.into());
            self
        }
    }
    impl ReportChallenge {
        pub const fn const_default() -> Self {
            Self { challenge_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ReportChallenge = ReportChallenge::const_default();
            &DEFAULT
        }
        pub fn with_challenge_id(mut self, field: String) -> Self {
            self.challenge_id = Some(field.into());
            self
        }
    }
    impl UndoReportChallenge {
        pub const fn const_default() -> Self {
            Self { challenge_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: UndoReportChallenge = UndoReportChallenge::const_default();
            &DEFAULT
        }
        pub fn with_challenge_id(mut self, field: String) -> Self {
            self.challenge_id = Some(field.into());
            self
        }
    }
    impl ClaimChallengeBond {
        pub const fn const_default() -> Self {
            Self { challenge_id: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ClaimChallengeBond = ClaimChallengeBond::const_default();
            &DEFAULT
        }
        pub fn with_challenge_id(mut self, field: String) -> Self {
            self.challenge_id = Some(field.into());
            self
        }
    }
    impl ExecuteTransactionRequest {
        pub const fn const_default() -> Self {
            Self {
                transaction: None,
                signatures: Vec::new(),
                read_mask: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ExecuteTransactionRequest = ExecuteTransactionRequest::const_default();
            &DEFAULT
        }
        pub fn transaction(&self) -> &Transaction {
            self.transaction
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Transaction::default_instance() as _)
        }
        pub fn transaction_opt(&self) -> Option<&Transaction> {
            self.transaction.as_ref().map(|field| field as _)
        }
        pub fn transaction_opt_mut(&mut self) -> Option<&mut Transaction> {
            self.transaction.as_mut().map(|field| field as _)
        }
        pub fn transaction_mut(&mut self) -> &mut Transaction {
            self.transaction.get_or_insert_default()
        }
        pub fn with_transaction(mut self, field: Transaction) -> Self {
            self.transaction = Some(field.into());
            self
        }
        pub fn signatures(&self) -> &[UserSignature] {
            &self.signatures
        }
        pub fn signatures_mut(&mut self) -> &mut Vec<UserSignature> {
            &mut self.signatures
        }
        pub fn with_signatures(mut self, field: Vec<UserSignature>) -> Self {
            self.signatures = field;
            self
        }
    }
    impl ExecuteTransactionResponse {
        pub const fn const_default() -> Self {
            Self { transaction: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: ExecuteTransactionResponse = ExecuteTransactionResponse::const_default();
            &DEFAULT
        }
        pub fn transaction(&self) -> &ExecutedTransaction {
            self.transaction
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ExecutedTransaction::default_instance() as _)
        }
        pub fn transaction_opt(&self) -> Option<&ExecutedTransaction> {
            self.transaction.as_ref().map(|field| field as _)
        }
        pub fn transaction_opt_mut(&mut self) -> Option<&mut ExecutedTransaction> {
            self.transaction.as_mut().map(|field| field as _)
        }
        pub fn transaction_mut(&mut self) -> &mut ExecutedTransaction {
            self.transaction.get_or_insert_default()
        }
        pub fn with_transaction(mut self, field: ExecutedTransaction) -> Self {
            self.transaction = Some(field.into());
            self
        }
    }
    impl SimulateTransactionRequest {
        pub const fn const_default() -> Self {
            Self {
                transaction: None,
                read_mask: None,
                checks: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SimulateTransactionRequest = SimulateTransactionRequest::const_default();
            &DEFAULT
        }
        pub fn transaction(&self) -> &Transaction {
            self.transaction
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| Transaction::default_instance() as _)
        }
        pub fn transaction_opt(&self) -> Option<&Transaction> {
            self.transaction.as_ref().map(|field| field as _)
        }
        pub fn transaction_opt_mut(&mut self) -> Option<&mut Transaction> {
            self.transaction.as_mut().map(|field| field as _)
        }
        pub fn transaction_mut(&mut self) -> &mut Transaction {
            self.transaction.get_or_insert_default()
        }
        pub fn with_transaction(mut self, field: Transaction) -> Self {
            self.transaction = Some(field.into());
            self
        }
    }
    impl SimulateTransactionResponse {
        pub const fn const_default() -> Self {
            Self { transaction: None }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: SimulateTransactionResponse = SimulateTransactionResponse::const_default();
            &DEFAULT
        }
        pub fn transaction(&self) -> &ExecutedTransaction {
            self.transaction
                .as_ref()
                .map(|field| field as _)
                .unwrap_or_else(|| ExecutedTransaction::default_instance() as _)
        }
        pub fn transaction_opt(&self) -> Option<&ExecutedTransaction> {
            self.transaction.as_ref().map(|field| field as _)
        }
        pub fn transaction_opt_mut(&mut self) -> Option<&mut ExecutedTransaction> {
            self.transaction.as_mut().map(|field| field as _)
        }
        pub fn transaction_mut(&mut self) -> &mut ExecutedTransaction {
            self.transaction.get_or_insert_default()
        }
        pub fn with_transaction(mut self, field: ExecutedTransaction) -> Self {
            self.transaction = Some(field.into());
            self
        }
    }
    impl TransactionFee {
        pub const fn const_default() -> Self {
            Self {
                base_fee: None,
                operation_fee: None,
                value_fee: None,
                total_fee: None,
            }
        }
        #[doc(hidden)]
        pub fn default_instance() -> &'static Self {
            static DEFAULT: TransactionFee = TransactionFee::const_default();
            &DEFAULT
        }
        pub fn with_base_fee(mut self, field: u64) -> Self {
            self.base_fee = Some(field.into());
            self
        }
        pub fn with_operation_fee(mut self, field: u64) -> Self {
            self.operation_fee = Some(field.into());
            self
        }
        pub fn with_value_fee(mut self, field: u64) -> Self {
            self.value_fee = Some(field.into());
            self
        }
        pub fn with_total_fee(mut self, field: u64) -> Self {
            self.total_fee = Some(field.into());
            self
        }
    }
}
