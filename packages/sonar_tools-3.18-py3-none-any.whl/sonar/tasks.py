#
# sonar-tools
# Copyright (C) 2022-2026 Olivier Korach
# mailto:olivier.korach AT gmail DOT com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#

"""Abstraction of the SonarQube background task concept"""

from __future__ import annotations
from typing import Optional, Any, Union, TYPE_CHECKING

from datetime import datetime
import time
import json
import re

from sonar.sqobject import SqObject
import sonar.logging as log
from sonar import exceptions
import sonar.utilities as sutil
from sonar.audit.rules import get_rule, RuleId
from sonar.audit.problem import Problem
from sonar.config import get_scanners_versions
from sonar.util import cache
from sonar.util import misc as util
from sonar.api.manager import ApiOperation as Oper

from sonar import projects
from sonar import applications
from sonar import portfolios

if TYPE_CHECKING:
    from sonar.platform import Platform
    from sonar.util.types import ApiPayload, ConfigSettings
    from sonar.projects import Project
    from sonar.applications import Application
    from sonar.portfolios import Portfolio
    from sonar.branches import Branch
    from sonar.pull_requests import PullRequest
    from sonar.app_branches import ApplicationBranch

    ConcernedObject = Union[Project, Branch, PullRequest, Application, ApplicationBranch, Portfolio]

SUCCESS = "SUCCESS"
PENDING = "PENDING"
IN_PROGRESS = "IN_PROGRESS"
FAILED = "FAILED"
CANCELED = "CANCELED"

TIMEOUT = "TIMEOUT"

STATUSES = (SUCCESS, PENDING, IN_PROGRESS, FAILED, CANCELED)

# Project import background task errors
NO_ERROR = "NO_ERROR"
ZIP_MISSING = "ZIP_MISSING"
ZIP_CORRUPTED = "ZIP_CORRUPTED"
ZIP_DOESNT_MATCH = "ZIP_DOES_NOT_MATCH_PROJECT"
CANT_UNZIP = "CANNOT_UNZIP"
INCOMPATIBLE_SQ = "INCOMPATIBLE_SQ_VERSION"
INCOMPATIBLE_PLUGINS = "INCOMPATIBLE_PLUGINS"
IMPORT_ERRORS = (ZIP_MISSING, ZIP_CORRUPTED, ZIP_DOESNT_MATCH, CANT_UNZIP, INCOMPATIBLE_SQ, INCOMPATIBLE_PLUGINS)

SCANNER_VERSIONS = get_scanners_versions()


class Task(SqObject):
    """
    Abstraction of the SonarQube "background task" concept
    """

    CACHE = cache.Cache()

    def __init__(self, endpoint: Platform, data: ApiPayload) -> None:
        """Constructor"""
        super().__init__(endpoint, data)
        self.key = data["id"]
        self.concerned_object: Optional[ConcernedObject]
        self.component_key: Optional[str]
        self._context: Optional[dict[str, str]] = None
        self._error: Optional[dict[str, str]] = None
        self.__class__.CACHE.put(self)
        self.reload(data)

    def __str__(self) -> str:
        """Returns the string representation of the background task"""
        return f"background task '{self.key}'"

    @classmethod
    def get_object(cls, endpoint: Platform, task_id: str, use_cache: bool = True) -> Task:
        """Returns a background task object from its id"""
        o: Optional[Task] = cls.CACHE.get(endpoint.local_url, task_id)
        if use_cache and o:
            return o
        additional_fields = "scannerContext,warnings"
        if not endpoint.is_sonarcloud():
            additional_fields += ",stacktrace"
        api, _, params, ret = endpoint.api.get_details(cls, Oper.GET, id=task_id, additionalFields=additional_fields)
        data = json.loads(endpoint.get(api, params=params).text)[ret]
        return o.reload(data) if o else cls.load(endpoint, json.loads(endpoint.get(api, params=params).text)[ret])

    @staticmethod
    def hash_payload(data: ApiPayload) -> tuple[Any, ...]:
        """Returns the hash items for a given object search payload"""
        return (data["id"],)

    def hash_object(self) -> tuple[Any, ...]:
        """Returns the hash elements for a given object"""
        return (self.key,)

    @classmethod
    def search(cls, endpoint: Platform, **search_params: Any) -> list[Task]:
        """Searches background tasks

        :param Platform endpoint: Reference to the SonarQube platform
        :param search_params: Search filters (see api/ce/activity parameters)
        :return: The list of found background tasks
        :rtype: list[Task]
        """
        api, _, params, ret = endpoint.api.get_details(cls, Oper.SEARCH, **search_params)
        dataset = json.loads(endpoint.get(api, params=params).text)
        return [cls.load(endpoint, data=t) for t in dataset[ret]]

    @classmethod
    def search_last(cls, endpoint: Platform, component: str, **search_params: Any) -> Optional[Task]:
        """Searches for last background task of a component"""
        branch = search_params.pop("branch", None)
        search_params = search_params | {"onlyCurrents": branch is None, "component": component}
        bg_tasks = Task.search(endpoint=endpoint, **search_params)
        if branch:
            bg_tasks = [t for t in bg_tasks if t.sq_json.get("branch", "") == branch]
        bg = next(iter(bg_tasks), None)
        if bg is None:
            log.debug("No background task found for component key '%s'%s", component, f" branch '{branch}'" if branch else "")
        return bg

    def refresh(self) -> Task:
        """Refreshes a local cache Task from the SonarQube"""
        return self.__class__.get_object(self.endpoint, self.key, use_cache=False)

    def url(self) -> str:
        """Returns the SonarQube permalink URL to the background task"""
        u = f"{self.base_url(local=False)}/project/background_tasks"
        if self.component_key:
            u += f"?id={self.component_key}"
        return u

    def reload(self, data: ApiPayload) -> Task:
        """Reloads a Task with and API Payload"""
        super().reload(data)
        self.component_key = data.get("componentKey")
        if self.component_key:
            qualifier = data.get("componentQualifier")
            if qualifier == "TRK":
                self.concerned_object = projects.Project.get_object(self.endpoint, self.component_key)
            elif qualifier == "APP":
                self.concerned_object = applications.Application.get_object(self.endpoint, self.component_key)
            elif qualifier == "VW":
                self.concerned_object = portfolios.Portfolio.get_object(self.endpoint, self.component_key)
            else:
                log.error("Unknown task component qualifier %s", qualifier)
        return self

    def submit_date(self) -> Optional[datetime]:
        """Returns the background task submission date"""
        return sutil.string_to_datetime(self.sq_json.get("submittedAt"))

    def start_date(self) -> Optional[datetime]:
        """Returns the background task start date, or None if not started yet"""
        return sutil.string_to_datetime(self.sq_json.get("startedAt"))

    def end_date(self) -> Optional[datetime]:
        """Returns the background task end date or None if not ended yet"""
        return sutil.string_to_datetime(self.sq_json.get("endedAt"))

    def project(self) -> Project:
        """Returns the project of the background task"""
        return self.concerned_object

    def id(self) -> str:
        """Return the background task id"""
        return self.key

    def __json_field(self, field: str) -> str:
        """Returns a background task scanner context field"""
        if field not in self.sq_json:
            self.refresh()
        return self.sq_json.get(field, None)

    def type(self) -> str:
        """Returns the background task type"""
        return self.__json_field("type")

    def status(self) -> str:
        """Returns the background task status"""
        return self.__json_field("status")

    def component(self) -> Optional[str]:
        """Returns the background task component key or None"""
        return self.__json_field("componentKey")

    def execution_time(self) -> int:
        """Returns the background task execution time in millisec"""
        return int(self.__json_field("executionTimeMs"))

    def submitter(self) -> str:
        """Returns the background task submitter"""
        return self.sq_json.get("submitterLogin", "anonymous")

    def has_scanner_context(self) -> bool:
        """Returns whether the background task has a scanner context"""
        return self.__json_field("hasScannerContext") or False

    def warnings(self) -> list[str]:
        """Returns the background task warnings, if any"""
        return self.__json_field("warnings")

    def warning_count(self) -> int:
        """Returns the number of warnings in the background task"""
        return self.__json_field("warningCount")

    def wait_for_completion(self, timeout: int = 180) -> str:
        """Waits for a background task to complete

        :param timeout: Timeout to wait in seconds, defaults to 180
        :type timeout: int, optional
        :return: the background task status
        :rtype: str
        """
        wait_time = 0
        sleep_time = 0.5
        status = self.__json_field("status")
        while status not in (SUCCESS, FAILED, CANCELED, TIMEOUT):
            log.debug("%s is '%s', sleeping %5.1fs", self, status, sleep_time)
            time.sleep(sleep_time)
            wait_time += sleep_time
            sleep_time *= 2
            self.refresh()
            log.debug("Data = %s", self.sq_json)
            status = self.__json_field("status")
            if wait_time >= timeout and status not in (SUCCESS, FAILED, CANCELED):
                status = TIMEOUT
        return status

    def scanner_context(self) -> Optional[dict[str, str]]:
        """Returns the background task scanner context"""
        if not (context_line := self.__json_field("scannerContext")):
            return None
        context = {}
        for line in [line for line in context_line.split("\n  - ") if line.startswith("sonar")]:
            (prop, val) = line.split("=", 1)
            context[prop] = val
        return context

    def scanner(self) -> str:
        """Returns the project type (MAVEN, GRADLE, DOTNET, OTHER, UNKNOWN)"""
        if not (ctxt := self.scanner_context()):
            return "UNKNOWN"
        return ctxt.get("sonar.scanner.app", "UNKNOWN").upper().replace("SCANNER", "").replace("MSBUILD", "DOTNET").replace("NPM", "CLI")

    def error_details(self) -> tuple[Optional[str], Optional[str]]:
        """
        :return: The background task error details
        :rtype: tuple (errorMsg (str), stackTrace (str))
        """
        return (self.__json_field("errorMessage"), self.__json_field("errorStackTrace"))

    def error_message(self) -> Optional[str]:
        """Return the background task error message"""
        return self.__json_field("errorMessage")

    def short_error(self) -> str:
        """Returns a short error message for the background task"""
        if self.endpoint.is_sonarcloud():
            raise exceptions.UnsupportedOperation("No stacktrace info on SonarQube Cloud")
        details = self.error_details()[1]
        if not details:
            return NO_ERROR
        errmsg = details.split("\n")[0]
        short_err = errmsg
        if "Dump file does not exist" in errmsg:
            # Actually this error should happen before the background task is created
            # so it should never happen once the object exists
            short_err = ZIP_MISSING
        elif "Missing metadata file" in errmsg:
            short_err = ZIP_CORRUPTED
        elif "Project key in dump file" in errmsg and "does not match" in errmsg:
            short_err = ZIP_DOESNT_MATCH
        elif "Can not unzip file" in errmsg:
            short_err = CANT_UNZIP
        elif re.match(r"Project dump was generated with .* but .* is required", errmsg):
            short_err = INCOMPATIBLE_SQ
        elif "Project dump can't be imported as installed plugins in the target SonarQube instance are not compatible with the dump" in errmsg:
            short_err = INCOMPATIBLE_PLUGINS
        log.error("%s import error %s", str(self), errmsg)
        return short_err

    def __audit_exclusions(self, exclusion_pattern: str, susp_exclusions: str, susp_exceptions: str) -> list[Problem]:
        """Audits a task exclusion patterns are returns found problems"""
        problems = []
        for susp in susp_exclusions:
            if not re.search(rf"{susp}", exclusion_pattern):
                continue
            is_exception = False
            for exception in susp_exceptions:
                if re.search(rf"{exception}", exclusion_pattern):
                    log.debug("Exclusion %s matches exception %s, no audit problem will be raised", exclusion_pattern, exception)
                    is_exception = True
                    break
            if not is_exception:
                rule = get_rule(RuleId.PROJ_SUSPICIOUS_EXCLUSION)
                problems.append(Problem(rule, self.concerned_object, str(self.concerned_object), exclusion_pattern))
                break  # Report only on the 1st suspicious match
        return problems

    def __audit_disabled_scm(self, audit_settings: ConfigSettings, scan_context: dict[str, str]) -> list[Problem]:
        """Audits a bg task for eventual SCM disabled and reports the problem if found"""
        if not audit_settings.get("audit.project.scm.disabled", True):
            log.info("Auditing disabled SCM integration is turned off, skipping...")
            return []

        if scan_context.get("sonar.scm.disabled", "false") == "false":
            return []
        return [Problem(get_rule(RuleId.PROJ_SCM_DISABLED), self, str(self.concerned_object))]

    def __audit_warnings(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits for warning in background tasks and reports found problems"""
        if not audit_settings.get("audit.projects.analysisWarnings", True):
            log.info("Project analysis warnings auditing disabled, skipping...")
            return []
        pbs = []
        warnings = self.warnings()
        warnings_left = []
        for w in warnings:
            if w.find("SCM provider autodetection failed") >= 0:
                pbs.append(Problem(get_rule(RuleId.PROJ_SCM_UNDETECTED), self.concerned_object, str(self.concerned_object)))
            else:
                warnings_left.append(w)
        if len(warnings_left) > 0:
            rule = get_rule(RuleId.PROJ_ANALYSIS_WARNING)
            pbs.append(Problem(rule, self, str(self.concerned_object), " --- ".join(warnings_left)))
        return pbs

    def __audit_failed_task(self, audit_settings: ConfigSettings) -> list[Problem]:
        if not audit_settings.get("audit.projects.failedTasks", True):
            log.debug("Project failed background tasks auditing disabled, skipping...")
            return []
        if self.sq_json["status"] != "FAILED":
            log.debug("Last bg task of %s has status %s...", str(self.concerned_object), self.sq_json["status"])
            return []
        return [Problem(get_rule(RuleId.BG_TASK_FAILED), self, str(self.concerned_object))]

    def __audit_scanner_version(self, audit_settings: ConfigSettings) -> list[Problem]:
        if not self.has_scanner_context():
            return []
        context = self.scanner_context()
        scanner_type = context.get("sonar.scanner.app", None)
        scanner_version = context.get("sonar.scanner.appVersion", None)
        proj = self.concerned_object
        log.debug("Scanner type = %s, Scanner version = %s", scanner_type, scanner_version)
        if not scanner_version:
            log.warning(
                "%s has been scanned with scanner '%s' with no version, skipping check scanner version obsolescence",
                str(proj),
                scanner_type,
            )
            return []
        if scanner_type not in SCANNER_VERSIONS:
            log.warning(
                "%s has been scanned with scanner '%s' which is not inventoried, skipping check on scanner obsolescence",
                str(proj),
                scanner_type,
            )
            return []

        if scanner_type == "Ant":
            return [Problem(get_rule(RuleId.ANT_SCANNER_DEPRECATED), proj, str(proj))]

        problems = []
        if scanner_type in ("ScannerGradle", "ScannerMaven"):
            scanner_version = scanner_version.split("/")[0].replace("-SNAPSHOT", "")
        scanner_version = [int(n) for n in scanner_version.split(".")]
        if len(scanner_version) == 2:
            scanner_version.append(0)
        scanner_version = tuple(scanner_version[0:3])
        str_version = sutil.version_to_string(scanner_version)
        versions_list = SCANNER_VERSIONS[scanner_type].keys()
        log.debug("versions = %s", str(versions_list))
        try:
            release_date = SCANNER_VERSIONS[scanner_type][str_version]
        except KeyError:
            log.warning(
                "Scanner '%s' version '%s' is not referenced in sonar-tools. "
                "Scanner obsolescence check skipped. "
                "Please report to author at https://github.com/okorach/sonar-tools/issues",
                scanner_type,
                str_version,
            )
            return []

        tuple_version_list = [tuple(int(n) for n in v.split(".")) for v in versions_list]
        tuple_version_list.sort(reverse=True)
        delta_days = (datetime.today() - release_date).days
        index = tuple_version_list.index(scanner_version)

        log.debug("Auditing Scanner for .NET v9.2.x")
        if scanner_type == "ScannerMSBuild" and scanner_version[0:2] == (9, 2):
            problems.append(Problem(get_rule(RuleId.VULNERABLE_DOTNET_SCANNER), proj, str(proj), str_version))

        log.debug("Scanner used is %d versions old", index)
        if delta_days > audit_settings.get("audit.projects.scannerMaxAge", 730):
            rule = get_rule(RuleId.OBSOLETE_SCANNER) if index >= 3 else get_rule(RuleId.NOT_LATEST_SCANNER)
            release_date = sutil.date_to_string(release_date, with_time=False)
            problems.append(Problem(rule, proj, str(proj), scanner_type, str_version, release_date))

        return problems

    def audit(self, audit_settings: ConfigSettings) -> list[Problem]:
        """Audits a background task and returns the list of found problems"""
        if not audit_settings.get("audit.projects.exclusions", True):
            log.debug("Project exclusions auditing disabled, skipping...")
            return []
        log.debug("Auditing %s", str(self))
        problems = []
        if self.has_scanner_context():
            if audit_settings.get("audit.projects.exclusions", True):
                context = self.scanner_context()
                susp_exclusions = util.csv_to_list(audit_settings.get("audit.projects.suspiciousExclusionsPatterns", ""))
                susp_exceptions = util.csv_to_list(audit_settings.get("audit.projects.suspiciousExclusionsExceptions", ""))
                for prop in ("sonar.exclusions", "sonar.global.exclusions"):
                    if context.get(prop, None) is None:
                        continue
                    for excl in util.csv_to_list(context[prop]):
                        log.debug("Pattern = '%s'", excl)
                        problems += self.__audit_exclusions(excl, susp_exclusions, susp_exceptions)
            problems += self.__audit_disabled_scm(audit_settings, context)
        elif type(self.concerned_object).__name__ == "Project":
            log.debug("Last background task of %s has no scanner context, can't audit it", str(self.concerned_object))

        problems += self.__audit_warnings(audit_settings)
        problems += self.__audit_failed_task(audit_settings)
        problems += self.__audit_scanner_version(audit_settings)

        return problems
