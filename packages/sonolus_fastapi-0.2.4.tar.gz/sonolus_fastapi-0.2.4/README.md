# Sonolus-FastAPI

このプロジェクトはまだ開発途中です。

This project is still under development.

## Install

```bash
pip insatll sonolus-fastapi
```

## Usage


こちらをお読みください。

Please read this.


`https://sonolus-fastapi.pim4n-net.com`

## Example

[example.py](./example.py)
[example2.py](./example2.py)