from pydantic import BaseModel

class ServerSubmitItemCommunityActionRequest(BaseModel):
    values: str