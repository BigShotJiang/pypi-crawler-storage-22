from abc import ABC, abstractmethod
from typing import Any, Dict, List
from langgraph.graph.state import CompiledStateGraph
from agno.agent import Agent as AgnoAgent
from pydantic import BaseModel
from pydantic_ai.agent import Agent as PydanticAIAgent
from crewai.agent import Agent as CrewAIAgent
from ..utils.logger import logger
import json
import ast


class AgentAdapter(ABC):
    
    @abstractmethod
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        pass


class LangGraphAgentAdapter(AgentAdapter):
    
    def __init__(self, agent: CompiledStateGraph):
        self.agent = agent
    
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        logger.info("Invoking LangGraphAgentAdapter agent with messages")
        response = self.agent.invoke({"messages": messages})
        
        if structured_response := response.get('structured_response'):
            return structured_response.model_dump()
        
        if not response or "messages" not in response:
            raise ValueError("Agent response missing 'messages'")
        
        response_messages = response.get("messages")
        if not response_messages:
            raise ValueError("Agent response 'messages' list is empty")
        
        return response_messages[-1].content


class CrewAIAgentAdapter(AgentAdapter):

    def __init__(self, agent: CrewAIAgent, output_schema: BaseModel):
        self.agent = agent
        self.output_schema = output_schema

    def _convert_to_dict(self, response: Any) -> Dict[str, Any]:
        """
        Convert response to dict using 3 strategies:
        1. Check if already a dict
        2. Try json.loads()
        3. Try ast.literal_eval()
        """

        # Strategy 1: Already a dict
        if isinstance(response, dict):
            logger.info("Response is already a dict")
            return response

        # Convert to string for parsing
        response_str_raw = str(response)

        response_str = response_str_raw[response_str_raw.find("{"): response_str_raw.rfind("}")+1]

        # Strategy 2: Try json.loads()
        try:
            parsed = json.loads(response_str)
            logger.info("Successfully parsed with json.loads()")
            return parsed
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logger.error(f"json.loads() failed: {e}")

        # Strategy 3: Try ast.literal_eval()
        try:
            parsed = ast.literal_eval(response_str)
            if isinstance(parsed, dict):
                logger.info("Successfully parsed with ast.literal_eval()")
                return parsed
        except (ValueError, SyntaxError, TypeError) as e:
            logger.error(f"ast.literal_eval() failed: {e}")

        # All parsing failed - return as string
        logger.error("All parsing strategies failed, returning raw response")
        return response_str

    def invoke(self, messages: List[Dict[str, str]]) -> Any:
        try:
            logger.info("Invoking CrewAIAgentAdapter agent with messages")
            result = self.agent.kickoff(messages, response_format=self.output_schema)

            if structured_response := getattr(result, 'pydantic', None):
                logger.info("Got pydantic structured response")
                return structured_response.model_dump()

            agent_response = getattr(result, 'raw', None)
            if agent_response is None:
                agent_response = str(result)

            logger.info(f"Processing raw response type: {type(agent_response)}")

            if not self.output_schema:
                logger.info("No output schema provided, returning raw response")
                return agent_response

            return self._convert_to_dict(agent_response)

        except Exception as e:
            raise RuntimeError(f"CrewAI agent invocation failed: {e}")


class AgnoAgentAdapter(AgentAdapter):
    
    def __init__(self, agent: AgnoAgent):
        self.agent = agent
    
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        try:
            logger.info("Invoking AgnoAgentAdapter agent with messages")
            response = self.agent.run(messages)
            agent_response = response.content if hasattr(response, 'content') else str(response)
            
            return agent_response
        except Exception as e:
            raise RuntimeError(f"Agno agent invocation failed: {e}")


class PydanticAIAgentAdapter(AgentAdapter):
    
    def __init__(self, agent: PydanticAIAgent):
        self.agent = agent
    
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        try:
            logger.info("Invoking LangGraph agent with messages")
            result = self.agent.run_sync(messages)
            agent_response = result.output if hasattr(result, 'output') else str(result)
            
            return agent_response
        except Exception as e:
            raise RuntimeError(f"Pydantic-AI agent invocation failed: {e}")
