import pytest
import json
from unittest.mock import MagicMock
from jinja2 import Environment
from soprano_sdk.nodes.collect_input import CollectInputStrategy, _get_agent_response
from soprano_sdk.core.constants import WorkflowKeys

class TestCollectInputStrategyRefactor:
    @pytest.fixture
    def strategy(self):
        step_config = {
            "field": "test_field",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        return CollectInputStrategy(step_config, engine_context)

    def test_get_agent_response_success(self, strategy):
        agent = MagicMock()
        conversation = [{"role": "user", "content": "hello"}]

        mock_response = "response content"
        agent.invoke.return_value = mock_response

        response = _get_agent_response(agent, conversation)

        assert response == "response content"
        assert conversation[-1]["role"] == "assistant"
        assert conversation[-1]["content"] == "response content"

    def test_handle_max_attempts_default_message(self):
        """Test that default error message is used when on_max_attempts_reached is not provided"""
        step_config = {
            "id": "collect_customer_name",
            "field": "customer_name",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"

        strategy = CollectInputStrategy(step_config, engine_context)
        state = {}

        result = strategy._handle_max_attempts(state)

        assert result[WorkflowKeys.STATUS] == "collect_customer_name_max_attempts"
        assert "customer_name" in result[WorkflowKeys.MESSAGES][0]
        assert "customer service" in result[WorkflowKeys.MESSAGES][0].lower()

    def test_handle_max_attempts_custom_message(self):
        """Test that custom error message is used when on_max_attempts_reached is provided"""
        custom_message = "Custom error: Too many attempts. Please call 1-800-SUPPORT."
        step_config = {
            "id": "collect_customer_name",
            "field": "customer_name",
            "agent": {"name": "test_agent"},
            "on_max_attempts_reached": custom_message
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"

        strategy = CollectInputStrategy(step_config, engine_context)
        state = {}

        result = strategy._handle_max_attempts(state)

        assert result[WorkflowKeys.STATUS] == "collect_customer_name_max_attempts"
        assert result[WorkflowKeys.MESSAGES][0] == custom_message
        assert "1-800-SUPPORT" in result[WorkflowKeys.MESSAGES][0]

    def test_generate_prompt_with_structured_output_no_initial_message(self):
        """Test that bot_response is extracted from structured output when no initial_message is provided"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "captured_name", "type": "boolean", "description": "Name captured", "required": True}
                    ]
                }
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)

        strategy = CollectInputStrategy(step_config, engine_context)

        # Mock agent that returns structured output
        agent = MagicMock()
        structured_response = json.dumps({
            "bot_response": "Hello! Please provide your name.",
            "captured_name": False
        })
        agent.invoke.return_value = structured_response

        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        assert prompt == "Hello! Please provide your name."
        assert len(conversation) == 1
        assert conversation[0]["role"] == "assistant"
        assert conversation[0]["content"] == "Hello! Please provide your name."

    def test_generate_prompt_with_structured_output_empty_bot_response(self):
        """Test that None is returned when bot_response is empty in structured output"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "captured_name", "type": "boolean", "description": "Name captured", "required": True}
                    ]
                }
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)

        strategy = CollectInputStrategy(step_config, engine_context)

        # Mock agent that returns structured output with empty bot_response
        agent = MagicMock()
        structured_response = json.dumps({
            "bot_response": "",
            "captured_name": False
        })
        agent.invoke.return_value = structured_response

        conversation = []
        state = {}

        # Empty bot_response should return None (which causes execute() to skip interrupt)
        prompt = strategy._generate_prompt(agent, conversation, state)

        assert prompt is None
        assert len(conversation) == 0  # Nothing added to conversation

    def test_generate_prompt_without_structured_output_no_initial_message(self):
        """Test that regular agent response is used when structured output is disabled"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "structured_output": {
                    "enabled": False
                }
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)

        strategy = CollectInputStrategy(step_config, engine_context)

        # Mock agent that returns plain text
        agent = MagicMock()
        agent.invoke.return_value = "Hello! What's your name?"

        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        assert prompt == "Hello! What's your name?"
        assert len(conversation) == 1
        assert conversation[0]["role"] == "assistant"
        assert conversation[0]["content"] == "Hello! What's your name?"

    def test_context_value_applied_from_engine_context(self):
        """Test that context values are applied from engine context"""
        step_config = {
            "id": "collect_customer_id",
            "field": "customer_id",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        # Mock context value (from initial_context)
        engine_context.get_context_value.return_value = "CTX_12345"

        strategy = CollectInputStrategy(step_config, engine_context)

        # Simulate state
        state = {}

        span = MagicMock()

        # Call _apply_context_value
        strategy._apply_context_value(state, span)

        # Verify the context value WAS applied
        assert state["customer_id"] == "CTX_12345"
        # Verify the context.value_used event was logged
        span.add_event.assert_called_once()
        event_call = span.add_event.call_args
        assert event_call[0][0] == "context.value_used"
        assert event_call[0][1]["field"] == "customer_id"
        assert event_call[0][1]["value"] == "CTX_12345"
