"""
Unit test for initial_context override bug.

Bug: When a collector node has interrupted and is waiting for user input,
if the caller passes initial_context with the same field, it overrides
the user's input instead of respecting it.

This test currently FAILS (documents the bug).
After fixing the bug, this test should PASS.
"""

import pytest
from unittest.mock import MagicMock, patch
from soprano_sdk.tools import WorkflowTool
from soprano_sdk.core.constants import WorkflowKeys


class TestInitialContextOverrideBug:
    """
    Test that initial_context should NOT override user input
    when a field is actively being collected.
    """

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_initial_context_should_not_override_user_input_during_collection(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """
        Test that initial_context does NOT override user input for actively collecting field.

        Scenario:
        1. Node "get_name" has interrupted, asking "What's your name?"
        2. User provides "John" via user_message
        3. Caller also passes initial_context={"name": "Alice", "age": 30}
        4. Expected: "name" should be "John" (from user), not "Alice" (from context)
        5. Expected: "age" should be 30 (from context, not collected yet)

        Current behavior (BUG):
        - Both "name" and "age" are passed to engine.update_context
        - _apply_context_value overwrites state["name"] = "Alice"
        - User input "John" is lost

        Expected behavior (AFTER FIX):
        - Only "age" should be passed to engine.update_context
        - "name" should be filtered out (actively collecting)
        - User input "John" is preserved
        """
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Simulate state when "get_name" node has interrupted
        mock_state = MagicMock()
        mock_state.next = ["get_name"]  # Node is waiting for input
        mock_state.values = {
            WorkflowKeys.NODE_EXECUTION_ORDER: [],  # Node hasn't completed yet
            WorkflowKeys.STATUS: "get_name_collecting",  # Actively collecting
            "_active_input_field": "name",  # Field being collected
            "name": None  # Field not collected yet
        }
        mock_graph.get_state.return_value = mock_state

        # Mock collector_node_field_map (maps node_id -> field)
        mock_engine.collector_node_field_map = {
            "get_name": "name",
            "get_age": "age"
        }

        # Mock result
        mock_result = {"outcome": "success"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = "Success"

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute - resuming with user input "John" but initial_context has "Alice"
        workflow.execute(
            thread_id="test-thread",
            user_message="John",  # User's input
            initial_context={"name": "Alice", "age": 30}  # Context trying to override
        )

        # ASSERTION: Verify that "name" was filtered out from context update
        mock_engine.update_context.assert_called_once()
        called_context = mock_engine.update_context.call_args[0][0]

        # The actively collecting field "name" should NOT be in the context
        assert "name" not in called_context, (
            f"Bug: 'name' should be filtered out because it's actively being collected. "
            f"Got context: {called_context}"
        )

        # The uncollected field "age" SHOULD be in the context
        assert "age" in called_context, (
            f"Expected: 'age' should be in context for pre-population. "
            f"Got context: {called_context}"
        )
        assert called_context["age"] == 30


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
