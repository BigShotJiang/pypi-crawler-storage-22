from abc import ABC, abstractmethod
from typing import Any, Dict, List
from langgraph.graph.state import CompiledStateGraph
from agno.agent import Agent as AgnoAgent
from pydantic import BaseModel
from pydantic_ai.agent import Agent as PydanticAIAgent
from crewai.agent import Agent as CrewAIAgent
from ..utils.logger import logger
from ..utils.tracing import tracer
import json
import ast
import traceback


class AgentAdapter(ABC):
    
    @abstractmethod
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        pass


class LangGraphAgentAdapter(AgentAdapter):
    
    def __init__(self, agent: CompiledStateGraph):
        self.agent = agent
    
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        logger.info("Invoking LangGraphAgentAdapter agent with messages")
        response = self.agent.invoke({"messages": messages})
        
        if structured_response := response.get('structured_response'):
            return structured_response.model_dump()
        
        if not response or "messages" not in response:
            raise ValueError("Agent response missing 'messages'")
        
        response_messages = response.get("messages")
        if not response_messages:
            raise ValueError("Agent response 'messages' list is empty")
        
        return response_messages[-1].content


class CrewAIAgentAdapter(AgentAdapter):

    def __init__(self, agent: CrewAIAgent, output_schema: BaseModel):
        self.agent = agent
        self.output_schema = output_schema

    def _llm_parse_fallback(self, response_str: str) -> Dict[str, Any] | None:
        """
        Use the agent's LLM to parse a malformed response into the expected schema.

        Args:
            response_str: The raw response string that failed to parse

        Returns:
            Parsed dictionary or None if parsing fails
        """
        with tracer.start_as_current_span(
            "llm.parse_fallback",
            attributes={
                "llm.purpose": "parse_malformed_response",
                "response.length": len(response_str),
                "schema.name": self.output_schema.__name__ if self.output_schema else "none"
            }
        ) as span:
            try:
                # Get schema fields and descriptions
                schema_fields = self.output_schema.model_json_schema()

                # Build parsing prompt
                parsing_prompt = f"""You are a data extraction assistant. Extract structured data from the following response text.

Required output format (JSON):
{json.dumps(schema_fields, indent=2)}

Response text to parse:
{response_str}

Instructions:
1. Extract ONLY the fields specified in the output format
2. Return valid JSON matching the schema exactly
3. If a field is not found in the response, use appropriate default
4. Do not include any explanatory text, only return the JSON

Return the extracted JSON now:"""

                span.set_attribute("prompt.length", len(parsing_prompt))

                # Call the agent's LLM
                llm_response = self.agent.llm.call(messages=[{"role": "user", "content": parsing_prompt}])

                # Extract content from LLM response
                if hasattr(llm_response, 'content'):
                    parsed_content = llm_response.content
                elif isinstance(llm_response, dict) and 'content' in llm_response:
                    parsed_content = llm_response['content']
                else:
                    parsed_content = str(llm_response)

                span.set_attribute("llm.response.length", len(parsed_content))

                # Try to parse the LLM's response
                # Remove markdown code blocks if present
                parsed_content = parsed_content.strip()
                if parsed_content.startswith('```'):
                    # Remove ```json or ``` at start and ``` at end
                    lines = parsed_content.split('\n')
                    parsed_content = '\n'.join(lines[1:-1])
                    span.set_attribute("llm.response.had_code_blocks", True)

                # Parse JSON
                parsed_dict = json.loads(parsed_content)
                span.set_attribute("parsing.json_parse", "success")

                # Validate against schema
                if self.output_schema:
                    validated = self.output_schema.model_validate(parsed_dict)
                    span.set_attribute("parsing.validation", "success")
                    span.set_attribute("result.fields", len(validated.model_dump()))
                    return validated.model_dump()

                return parsed_dict

            except Exception as e:
                span.set_attribute("error", True)
                span.set_attribute("error.type", type(e).__name__)
                span.set_attribute("error.message", str(e))
                span.add_event("exception", {
                    "exception.type": type(e).__name__,
                    "exception.message": str(e),
                    "exception.stacktrace": traceback.format_exc()
                })
                logger.error(f"LLM parse fallback error: {e}")
                logger.error(f"Traceback:\n{traceback.format_exc()}")
                return None

    def _convert_to_dict(self, response: Any) -> Dict[str, Any]:
        """
        Convert response to dict using 3 strategies:
        1. Check if already a dict
        2. Try json.loads()
        3. Try ast.literal_eval()
        """

        # Strategy 1: Already a dict
        if isinstance(response, dict):
            logger.info("Response is already a dict")
            return response

        # Convert to string for parsing
        response_str_raw = str(response)
        response_str = response_str_raw[response_str_raw.find("{"): response_str_raw.rfind("}")+1]

        # Strategy 2: Try json.loads()
        try:
            parsed = json.loads(response_str)
            logger.info("Successfully parsed with json.loads()")
            return parsed
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logger.error(f"json.loads() failed: {e}")

        # Strategy 3: Try ast.literal_eval()
        try:
            parsed = ast.literal_eval(response_str)
            if isinstance(parsed, dict):
                logger.info("Successfully parsed with ast.literal_eval()")
                return parsed
        except (ValueError, SyntaxError, TypeError) as e:
            logger.error(f"ast.literal_eval() failed: {e}")

        # All parsing failed - return as string
        logger.error("All parsing strategies failed, returning raw response")
        return response_str

    def invoke(self, messages: List[Dict[str, str]]) -> Any:
        try:
            logger.info("Invoking CrewAIAgentAdapter agent with messages")
            result = self.agent.kickoff(messages, response_format=self.output_schema)

            if structured_response := getattr(result, 'pydantic', None):
                logger.info("Got pydantic structured response")
                return structured_response.model_dump()

            agent_response = getattr(result, 'raw', None)
            if agent_response is None:
                agent_response = str(result)

            logger.info(f"Processing raw response type: {type(agent_response)}")

            if not self.output_schema:
                logger.info("No output schema provided, returning raw response")
                return agent_response

            # Parse the response
            parsed_dict = self._convert_to_dict(agent_response)

            # Validate if we have a schema
            if self.output_schema and isinstance(parsed_dict, dict):
                try:
                    validated = self.output_schema.model_validate(parsed_dict)
                    logger.info("Validation passed")
                    return validated.model_dump()
                except Exception as validation_error:
                    logger.error(f"Validation failed: {validation_error}")
                    # Try LLM fallback
                    if hasattr(self.agent, 'llm'):
                        logger.info("Attempting LLM fallback")
                        if fallback_result := self._llm_parse_fallback(str(agent_response)):
                            logger.info("LLM fallback succeeded")
                            return fallback_result
                    raise RuntimeError(f"Validation failed and LLM fallback unsuccessful: {validation_error}")

            return parsed_dict

        except Exception as e:
            raise RuntimeError(f"CrewAI agent invocation failed: {e}")


class AgnoAgentAdapter(AgentAdapter):
    
    def __init__(self, agent: AgnoAgent):
        self.agent = agent
    
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        try:
            logger.info("Invoking AgnoAgentAdapter agent with messages")
            response = self.agent.run(messages)
            agent_response = response.content if hasattr(response, 'content') else str(response)
            
            return agent_response
        except Exception as e:
            raise RuntimeError(f"Agno agent invocation failed: {e}")


class PydanticAIAgentAdapter(AgentAdapter):
    
    def __init__(self, agent: PydanticAIAgent):
        self.agent = agent
    
    def invoke(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        try:
            logger.info("Invoking LangGraph agent with messages")
            result = self.agent.run_sync(messages)
            agent_response = result.output if hasattr(result, 'output') else str(result)
            
            return agent_response
        except Exception as e:
            raise RuntimeError(f"Pydantic-AI agent invocation failed: {e}")
