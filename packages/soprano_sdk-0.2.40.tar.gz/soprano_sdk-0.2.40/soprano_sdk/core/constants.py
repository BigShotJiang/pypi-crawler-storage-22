from enum import Enum
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class WorkflowKeys:
    STEP_ID = '_step_id'
    STATUS = '_status'
    OUTCOME_ID = '_outcome_id'
    MESSAGES = '_messages'
    CONVERSATIONS = '_conversations'
    STATE_HISTORY = '_state_history'
    COLLECTOR_NODES = '_collector_nodes'
    ATTEMPT_COUNTS = '_attempt_counts'
    NODE_EXECUTION_ORDER = '_node_execution_order'
    NODE_FIELD_MAP = '_node_field_map'
    COMPUTED_FIELDS = '_computed_fields'
    VALIDATION_ERRORS = '_validation_errors'
    ERROR = 'error'
    TARGET_LANGUAGE = '_target_language'
    TARGET_SCRIPT = '_target_script'


class ActionType(Enum):
    COLLECT_INPUT_WITH_AGENT = 'collect_input_with_agent'
    CALL_FUNCTION = 'call_function'
    CALL_ASYNC_FUNCTION = 'call_async_function'
    FOLLOW_UP = 'follow_up'
    MFA = 'mfa'


class InterruptType:
    """Interrupt type markers for workflow pauses"""
    USER_INPUT = '__WORKFLOW_INTERRUPT__'
    ASYNC = '__ASYNC_INTERRUPT__'
    OUT_OF_SCOPE = '__OUT_OF_SCOPE_INTERRUPT__'


class OutcomePrefix:
    """Outcome type markers for workflow completion"""
    REDIRECT = '__REDIRECT__'


class DataType(Enum):
    TEXT = 'text'
    NUMBER = 'number'
    DOUBLE = 'double'
    BOOLEAN = 'boolean'
    LIST = 'list'
    DICT = 'dict'
    ANY = "any"


class OutcomeType(Enum):
    SUCCESS = 'success'
    FAILURE = 'failure'
    REDIRECT = 'redirect'


class StatusPattern:
    COLLECTING = '{step_id}_collecting'
    MAX_ATTEMPTS = '{step_id}_max_attempts'
    NEXT_STEP = '{step_id}_{next_step}'
    SUCCESS = '{step_id}_success'
    FAILED = '{step_id}_failed'
    INTENT_CHANGE = '{step_id}_{target_node}'


class TransitionPattern:
    CAPTURED = '{field}_CAPTURED:'
    FAILED = '{field}_FAILED:'
    INTENT_CHANGE = 'INTENT_CHANGE:'


class ResponseMarkers:
    OPTIONS_DATA = 'OPTIONS_DATA:'


DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_MODEL = 'gpt-4o-mini'
DEFAULT_TIMEOUT = 300

MAX_ATTEMPTS_MESSAGE = "I'm having trouble understanding your {field}. Please contact customer service for assistance."
WORKFLOW_COMPLETE_MESSAGE = "Workflow completed."

# Humanization defaults
DEFAULT_HUMANIZATION_ENABLED = False
DEFAULT_HUMANIZATION_SYSTEM_PROMPT = """You transform template-based messages into natural, conversational responses.

Rules:
1. Rewrite the reference message naturally while maintaining ALL factual information
2. Use conversation history for context and tone matching
3. Be warm, professional, and helpful
4. Keep responses concise but complete

CRITICAL: Return ONLY the humanized message itself. Do NOT include:
- Preambles like "Here's..." or "Sure, here's..."
- Explanations of what you did
- Meta-commentary about the transformation
- Phrases like "more condensed version" or "rewritten message"
- Placeholders like "[insert X]", "[placeholder]", or "[your message here]"

Just provide the actual humanized message and nothing else. All content must be final, not placeholders."""

HUMANIZATION_OPTIONS_GUIDANCE = """
INTELLIGENT OPTIONS HANDLING:

When you have options for the user to choose from:
1. First provide the brief introductory message, which must NOT include the options themselves
2. If options are already provided in the reference message: preserve them exactly in your options field
3. If NO options provided but message asks yes/no question: set options=["Yes", "No"], is_selectable=true
4. If NO options provided but message offers discrete choices: extract them as options array, is_selectable=true
5. If message has no choices: set options=null, is_selectable=null

Your humanized message must ONLY contain the introductory text. Do NOT list the options in the message text.
The UI will automatically display options as buttons/list items.

Examples:
- "Would you like to proceed?" → message: "Would you like to proceed?", options: ["Yes", "No"], is_selectable: true
- "Please select from: iPhone, Samsung, MacBook" → message: "Please choose your product:", options: ["iPhone", "Samsung", "MacBook"], is_selectable: true
- "What is your name?" → message: "What is your name?", options: null, is_selectable: null
"""


class HumanizationKeys:
    """Keys for humanization agent configuration"""
    ENABLED = 'enabled'
    MODEL = 'model'
    BASE_URL = 'base_url'
    INSTRUCTIONS = 'instructions'


# Localization defaults
DEFAULT_LOCALIZATION_INSTRUCTIONS = """LANGUAGE REQUIREMENT:
You MUST respond in {language} using {script} script.
- All your responses must be in {language}
- Use the {script} writing system
- Maintain the same meaning and tone as you would in English
- Do not mix languages unless quoting the user
"""


class LocalizationKeys:
    """Keys for localization configuration"""
    LANGUAGE = 'language'
    SCRIPT = 'script'
    INSTRUCTIONS = 'instructions'


class MFAConfig(BaseSettings):
    """
    Configuration for MFA REST API endpoints.

    Values can be provided during initialization or will be automatically
    loaded from environment variables with the same name (uppercase).

    Example:
        # Load from environment variables
        config = MFAConfig()

        # Or provide specific values
        config = MFAConfig(
            generate_token_base_url="https://api.example.com",
            generate_token_path="/v1/mfa/generate"
        )
    """
    generate_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the generate token endpoint"
    )
    generate_token_path: Optional[str] = Field(
        default=None,
        description="Path for the generate token endpoint"
    )
    validate_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the validate token endpoint"
    )
    validate_token_path: Optional[str] = Field(
        default=None,
        description="Path for the validate token endpoint"
    )
    authorize_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the authorize token endpoint"
    )
    authorize_token_path: Optional[str] = Field(
        default=None,
        description="Path for the authorize token endpoint"
    )
    resend_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the resend token endpoint"
    )
    resend_token_path: Optional[str] = Field(
        default=None,
        description="Path for the resend token endpoint"
    )
    api_timeout: int = Field(
        default=30,
        description="API request timeout in seconds"
    )
    initial_message: Optional[str] = Field(
        default=None,
        description="Initial message to display when MFA authentication is required"
    )
    mfa_validation_error_message: str = Field(
        default="Invalid OTP entered",
        description="Message to display when MFA validation fails"
    )
    max_attempts_message: str = Field(
        default="Maximum authentication attempts reached. Please try again later.",
        description="Message to display when max MFA attempts are reached"
    )

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra='ignore'
    )
