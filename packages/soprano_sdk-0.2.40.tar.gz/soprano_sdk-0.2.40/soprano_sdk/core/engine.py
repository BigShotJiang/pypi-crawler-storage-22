from typing import Optional, Dict, Any, Tuple, List

import yaml
from jinja2 import Environment
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.constants import START
from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledStateGraph
from pydantic import BaseModel, Field

from .constants import (
    WorkflowKeys,
    MFAConfig,
    DEFAULT_HUMANIZATION_ENABLED,
    DEFAULT_HUMANIZATION_SYSTEM_PROMPT,
    HUMANIZATION_OPTIONS_GUIDANCE,
    HumanizationKeys,
    DEFAULT_LOCALIZATION_INSTRUCTIONS,
    LocalizationKeys,
    OutcomePrefix
)
from .models import MessagePayload
from ..agents.factory import get_model
from .state import create_state_model
from ..nodes.factory import NodeFactory
from ..routing.router import WorkflowRouter
from ..utils.function import FunctionRepository
from ..utils.logger import logger
from ..utils.tool import ToolRepository
from ..utils.tracing import trace_agent_invocation
from ..validation import validate_workflow


class HumanizedResponse(BaseModel):
    """Structured output for humanized messages."""
    message: str = Field(
        description="The humanized message without any preambles, explanations, or meta-commentary"
    )
    options: Optional[List[str]] = Field(
        default=None,
        description="List of selectable options for the user (if provided in reference message)"
    )
    is_selectable: Optional[bool] = Field(
        default=None,
        description="Whether user must select from options (true) or can also type freely (false)"
    )


class WorkflowEngine:

    def __init__(self, yaml_path: str, configs: dict, mfa_config: Optional[MFAConfig] = None):
        self.yaml_path = yaml_path
        self.configs = configs or {}
        logger.info(f"Loading workflow from: {yaml_path}")

        try:
            with open(yaml_path, 'r') as f:
                self.config = yaml.safe_load(f)

            logger.info("Validating workflow configuration")
            validate_workflow(self.config, mfa_config=mfa_config or MFAConfig())

            self.workflow_name = self.config['name']
            self.workflow_description = self.config['description']
            self.workflow_version = self.config['version']
            self.mfa_validator_steps: set[str] = set()
            self.steps: list = self.load_steps()
            self.step_map = {step['id']: step for step in self.steps}
            self.mfa_config = (mfa_config or MFAConfig())
            self.data_fields = self.load_data()
            self.outcomes = self.load_outcomes()
            self.metadata = self.config.get('metadata', {})
            self.failure_message: Optional[str] = self.config.get('failure_message')

            self.StateType = create_state_model(self.data_fields)

            self.outcome_map = {outcome['id']: outcome for outcome in self.outcomes}

            self.function_repository = FunctionRepository()
            self.tool_repository = None
            if tool_config := self.config.get("tool_config"):
                self.tool_repository = ToolRepository(tool_config)

            self.context_store = {}
            self.collect_input_fields = self._get_collect_input_fields()

            logger.info(
                f"Workflow loaded: {self.workflow_name} v{self.workflow_version} "
                f"({len(self.steps)} steps, {len(self.outcomes)} outcomes, "
                f"{len(self.collector_node_field_map)} collector nodes)"
            )

        except Exception as e:
            raise e

    def get_config_value(self, key, default_value: Optional[Any]=None):
        if value := self.configs.get(key) :
            return value

        if value := self.config.get(key) :
            return value

        return default_value

    def _get_collect_input_fields(self) -> set:
        fields = set()
        for step in self.steps:
            if step.get('action') == 'collect_input_with_agent':
                if field := step.get('field'):
                    fields.add(field)
                if field_list := step.get('fields'):
                    fields.update(field_list)
        return fields

    def update_context(self, context: Dict[str, Any]):
        self.context_store.update(context)
        logger.info(f"Context updated: {context}")

    def remove_context_field(self, field_name: str):
        if field_name in self.context_store:
            del self.context_store[field_name]
            logger.info(f"Removed context field: {field_name}")
    
    def get_context_value(self, field_name: str):
        value = self.context_store.get(field_name, None)
        if value is not None:
            logger.info(f"Retrieved context value for '{field_name}': {value}")
        return value

    def build_graph(self, checkpointer=None):
        logger.info("Building workflow graph")

        try:
            builder = StateGraph(self.StateType)

            collector_nodes = []

            logger.info("Adding nodes to graph")
            for step in self.steps:
                step_id = step['id']
                action = step['action']

                if action == 'collect_input_with_agent':
                    collector_nodes.append(step_id)

                node_fn = NodeFactory.create(step, engine_context=self)
                builder.add_node(step_id, node_fn)

                logger.info(f"Added node: {step_id} (action: {action})")

            first_step_id = self.steps[0]['id']
            builder.add_edge(START, first_step_id)
            logger.info(f"Set entry point: {first_step_id}")

            logger.info("Adding routing edges")
            for step in self.steps:
                step_id = step['id']

                router = WorkflowRouter(step, self.step_map, self.outcome_map)
                route_fn = router.create_route_function()
                routing_map = router.get_routing_map(collector_nodes)

                builder.add_conditional_edges(step_id, route_fn, routing_map)

                logger.info(
                    f"Added routing for {step_id}: {len(routing_map)} destinations"
                )

            if checkpointer is None:
                checkpointer = InMemorySaver()
                logger.info("Using InMemorySaver for state persistence")
            else:
                logger.info(f"Using custom checkpointer: {type(checkpointer).__name__}")

            graph = builder.compile(checkpointer=checkpointer)

            logger.info("Workflow graph built successfully")
            return graph

        except Exception as e:
            raise RuntimeError(f"Failed to build workflow graph: {e}")

    def _aggregate_conversation_history(self, state: Dict[str, Any]) -> List[Dict[str, str]]:
        """Aggregate all conversations from collector nodes in execution order."""
        conversations = state.get(WorkflowKeys.CONVERSATIONS, {})
        node_order = state.get(WorkflowKeys.NODE_EXECUTION_ORDER, [])
        node_field_map = state.get(WorkflowKeys.NODE_FIELD_MAP, {})

        aggregated = []
        for node_id in node_order:
            field = node_field_map.get(node_id)
            if field:
                conv_key = f"{field}_conversation"
                if conv_messages := conversations.get(conv_key):
                    aggregated.extend(conv_messages)

        return aggregated

    def _get_humanization_config(self) -> Dict[str, Any]:
        """Get humanization agent configuration from workflow config."""
        return self.config.get('humanization_agent', {})

    def _should_humanize_outcome(self, outcome: Dict[str, Any]) -> bool:
        """Determine if an outcome should be humanized."""
        # Check workflow-level setting (default: enabled)
        workflow_humanization = self._get_humanization_config()
        workflow_enabled = workflow_humanization.get(
            HumanizationKeys.ENABLED,
            DEFAULT_HUMANIZATION_ENABLED
        )

        if not workflow_enabled:
            return False

        # Check per-outcome setting (default: True, inherit from workflow)
        return outcome.get('humanize', True)

    def _get_humanization_model_config(self) -> Optional[Dict[str, Any]]:
        """Get model config for humanization, with overrides applied."""
        model_config = self.get_config_value('model_config')
        if not model_config:
            return None

        humanization_config = self._get_humanization_config()
        model_config = model_config.copy()  # Don't mutate original

        # Apply overrides from humanization_agent config
        if model := humanization_config.get(HumanizationKeys.MODEL):
            model_config['model_name'] = model
        if base_url := humanization_config.get(HumanizationKeys.BASE_URL):
            model_config['base_url'] = base_url

        return model_config

    def _get_localization_config(self) -> Dict[str, Any]:
        """Get localization configuration from workflow config."""
        return self.config.get('localization', {})

    def get_localization_instructions(self, state: Dict[str, Any]) -> str:
        """Get localization instructions based on state (per-turn) or YAML defaults.

        Args:
            state: Current workflow state containing per-turn language/script values

        Returns:
            Localization instructions string to prepend to agent prompts, or empty string if no localization
        """
        # First check state for per-turn values
        language = state.get(WorkflowKeys.TARGET_LANGUAGE)
        script = state.get(WorkflowKeys.TARGET_SCRIPT)

        # Fall back to YAML defaults if not in state
        yaml_config = self._get_localization_config()
        if not language:
            language = yaml_config.get(LocalizationKeys.LANGUAGE)
        if not script:
            script = yaml_config.get(LocalizationKeys.SCRIPT)

        custom_instructions = yaml_config.get(LocalizationKeys.INSTRUCTIONS)

        if not language and not script:
            if custom_instructions:
                return custom_instructions
            return ""


        localization_prompt = DEFAULT_LOCALIZATION_INSTRUCTIONS.format(
            language=language or "the target language",
            script=script or "the appropriate script"
        )  

        if custom_instructions:
            localization_prompt += custom_instructions.format(
                language=language or "the target language",
                script=script or "the appropriate script"
            )

        return localization_prompt

    def _humanize_message(
        self,
        reference_message: str,
        state: Dict[str, Any],
        options: Optional[List[str]] = None,
        is_selectable: Optional[bool] = None
    ) -> MessagePayload:
        """Use LLM to humanize the reference message using conversation context.

        Returns:
            MessagePayload containing the humanized message with optional options
        """
        try:
            model_config = self._get_humanization_model_config()
            if not model_config:
                logger.warning("No model_config found, skipping humanization")
                return MessagePayload(reference_message, options, is_selectable or False)

            humanization_config = self._get_humanization_config()

            # Build system prompt (without reference message)
            custom_instructions = humanization_config.get(HumanizationKeys.INSTRUCTIONS)
            if custom_instructions:
                system_prompt = custom_instructions
            else:
                system_prompt = DEFAULT_HUMANIZATION_SYSTEM_PROMPT

            # Always append OPTIONS guidance (works with both default and custom prompts)
            system_prompt += HUMANIZATION_OPTIONS_GUIDANCE

            # Inject localization instructions if specified
            localization_instructions = self.get_localization_instructions(state)
            if localization_instructions:
                system_prompt = f"{localization_instructions}\n\n{system_prompt}"

            # Aggregate conversation history
            conversation_history = self._aggregate_conversation_history(state)

            # Create LLM with structured output for humanization
            llm = get_model(
                config=model_config,
                output_schema=HumanizedResponse
            )

            user_query = f"Humanize this message based on the prior context:\n\n```\n{reference_message}\n```"

            # Add options information if provided
            if options is not None:
                user_query += f"\n\nSelectable options: {options}"
                user_query += f"\nMust select from options: {is_selectable}"
                user_query += "\n\nReturn these options and is_selectable values in your structured response."

            messages = [{"role": "system", "content": system_prompt}]
            if conversation_history:
                messages.extend(conversation_history)
            messages.append({"role": "user", "content": user_query})

            # Trace humanization LLM call with structured output
            with trace_agent_invocation(
                agent_name="HumanizationAgent",
                model=model_config.get('model_name', 'unknown'),
                structured_output=True
            ) as span:
                humanized_response: HumanizedResponse = llm.invoke(messages)

                # Log structured output details
                if span and span.is_recording():
                    span.set_attribute("humanization.input_length", len(reference_message))
                    span.set_attribute("humanization.structured_output", True)
                    span.add_event("structured_output.received", {
                        "has_message": hasattr(humanized_response, 'message')
                    })

                humanized_message = humanized_response.message
                # Extract options from response, fallback to input if not provided
                humanized_options = humanized_response.options if humanized_response.options is not None else options
                humanized_is_selectable = humanized_response.is_selectable if humanized_response.is_selectable is not None else is_selectable

                # Log extracted message
                if span and span.is_recording():
                    span.set_attribute("humanization.output_length", len(humanized_message) if humanized_message else 0)
                    span.set_attribute("humanization.success", bool(humanized_message and humanized_message.strip()))
                    span.set_attribute("humanization.has_options", humanized_options is not None)

            # Validate we got a meaningful response
            if not humanized_message or humanized_message.strip() == '':
                logger.warning("Humanization returned empty response, using original message")
                return MessagePayload(reference_message, options, is_selectable or False)

            logger.info(f"Message humanized successfully: {humanized_message[:100]}...")
            return MessagePayload(humanized_message, humanized_options, humanized_is_selectable or False)

        except Exception as e:
            logger.warning(f"Humanization failed, using original message: {e}")
            return MessagePayload(reference_message, options, is_selectable or False)

    def get_outcome_message(self, state: Dict[str, Any], thread_id: str, workflow_name: str = None) -> MessagePayload:
        """Get outcome message with options support.

        Returns:
            MessagePayload containing the outcome message with optional options
        """
        outcome_id = state.get(WorkflowKeys.OUTCOME_ID)
        step_id = state.get(WorkflowKeys.STEP_ID)

        outcome = self.outcome_map.get(outcome_id)
        if outcome and 'message' in outcome:
            outcome_type = outcome.get('type')
            message = outcome['message']
            template_loader = self.get_config_value("template_loader", Environment())
            rendered_message = template_loader.from_string(message).render(state)

            # Apply humanization if enabled for this outcome
            message = MessagePayload(rendered_message)
            if self._should_humanize_outcome(outcome):
                result = self._humanize_message(rendered_message, state)
                message.message = result.message
                message.options = result.options
                message.is_selectable = result.is_selectable

            # Handle redirect outcome type
            if outcome_type == 'redirect':
                redirect_to = outcome.get('redirect_to', '')
                rendered_redirect_to = template_loader.from_string(redirect_to).render(state)

                # Return redirect format: __REDIRECT__|thread_id|workflow_name|redirect_to|message
                logger.info(f"Redirect outcome in step {step_id} to {rendered_redirect_to}")
                message.message = f"{OutcomePrefix.REDIRECT}|{thread_id}|{workflow_name}|{rendered_redirect_to}|{message.message}"

            logger.info(f"Outcome message generated in step {step_id}: {(message.message, message.options, message.is_selectable)}")
            return message

        if error := state.get("error"):
            logger.info(f"Outcome error found in step {step_id}: {error}")
            # Apply humanization to error message if enabled at workflow level
            humanization_config = self._get_humanization_config()
            if humanization_config.get(HumanizationKeys.ENABLED, DEFAULT_HUMANIZATION_ENABLED):
                return self._humanize_message(error, state)
            return MessagePayload(f"{error}")

        if message := state.get(WorkflowKeys.MESSAGES):
            logger.info(f"Outcome message found in step {step_id}: {message}")
            return MessagePayload(f"{message}")

        logger.error(f"No outcome message found in step {step_id}")
        return MessagePayload("{'error': 'Unable to complete the request'}")

    def get_step_info(self, step_id: str) -> Optional[Dict[str, Any]]:
        return self.step_map.get(step_id)

    def get_outcome_info(self, outcome_id: str) -> Optional[Dict[str, Any]]:
        return self.outcome_map.get(outcome_id)

    def list_steps(self) -> list:
        return [step['id'] for step in self.steps]

    def list_outcomes(self) -> list:
        return [outcome['id'] for outcome in self.outcomes]

    def get_workflow_info(self) -> Dict[str, Any]:
        return {
            'name': self.workflow_name,
            'description': self.workflow_description,
            'version': self.workflow_version,
            'steps': len(self.steps),
            'outcomes': len(self.outcomes),
            'data_fields': [f['name'] for f in self.data_fields],
            'metadata': self.metadata
        }

    def build_field_details(self, state: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Build a snapshot of the current collector node's fields with values and validation errors.

        Returns a list of dicts for the fields belonging to the active collector node:
            [{"name": "email", "value": "bad@", "error": "Invalid email format"}, ...]

        For fields that failed validation, the value is the one that failed (not None).
        """
        current_fields = self._get_current_node_fields(state)
        if current_fields is None:
            return []

        data_field_map = {f['name']: f for f in self.data_fields}
        validation_errors = state.get(WorkflowKeys.VALIDATION_ERRORS, {})
        field_details = []
        for name in current_fields:
            field_def = data_field_map.get(name)
            if not field_def:
                continue
            entry = {
                "name": name,
            }
            if name in validation_errors:
                entry["value"] = validation_errors[name]["value"]
                entry["error"] = validation_errors[name]["error"]
            else:
                entry["value"] = state.get(name)
            field_details.append(entry)
        return field_details

    def _get_current_node_fields(self, state: Dict[str, Any]) -> Optional[List[str]]:
        """Determine which fields belong to the currently active collector node."""
        status = state.get(WorkflowKeys.STATUS, "")
        for node_id, fields in self.collector_node_field_map.items():
            if status.startswith(f"{node_id}_"):
                if isinstance(fields, list):
                    return fields
                return [fields]
        return None

    def get_tool_policy(self) -> str:
        tool_config = self.config.get('tool_config')
        if not tool_config:
            raise ValueError("Tool config is not provided in the YAML")
        return tool_config.get('usage_policy')


    def load_steps(self):
        self.collector_node_field_map: Dict[str, str] = {}  # Map of node_id -> field

        # Build collector node -> field(s) map
        for step in self.config['steps']:
            if step.get('action') == 'collect_input_with_agent':
                node_id = step.get('id')
                if field := step.get('field'):
                    self.collector_node_field_map[node_id] = field
                elif fields := step.get('fields'):
                    self.collector_node_field_map[node_id] = fields  # Store as list


        return self.config['steps']

    def load_data(self):
        data: list = self.config['data']
        return data

    def load_outcomes(self):
        outcomes: list = self.config['outcomes']
        # MFA cancellation is handled by on_cancel redirect in MFA step config
        return outcomes


def load_workflow(yaml_path: str, checkpointer=None, config=None, mfa_config: Optional[MFAConfig] = None) -> Tuple[CompiledStateGraph, WorkflowEngine]:
    """
    Load a workflow from YAML configuration.

    This is the main entry point for using the framework.

    Args:
        yaml_path: Path to the workflow YAML file
        checkpointer: Optional checkpointer for state persistence.
                     Defaults to InMemorySaver() if not provided.
                     Example: MongoDBSaver for production persistence.
        config: Optional configuration dictionary
        mfa_config: Optional MFA configuration. If not provided, will load from environment variables.

    Returns:
        Tuple of (compiled_graph, engine) where:
        - compiled_graph: LangGraph ready for execution
        - engine: WorkflowEngine instance for introspection

    Example:
        ```python
        # Load with environment variables
        graph, engine = load_workflow("workflow.yaml")

        # Or provide MFA configuration explicitly
        from soprano_sdk.core.constants import MFAConfig
        mfa_config = MFAConfig(
            generate_token_base_url="https://api.example.com",
            generate_token_path="/v1/mfa/generate"
        )
        graph, engine = load_workflow("workflow.yaml", mfa_config=mfa_config)

        result = graph.invoke({}, config={"configurable": {"thread_id": "123"}})
        message = engine.get_outcome_message(result)
        ```
    """
    engine = WorkflowEngine(yaml_path, configs=config, mfa_config=mfa_config)
    graph = engine.build_graph(checkpointer=checkpointer)
    return graph, engine
