"""Tests for the agent factory module."""

import pytest
from unittest.mock import MagicMock, patch
from soprano_sdk.agents.factory import (
    AgentFactory,
    AgentAdapter,
    LangGraphAgentCreator,
    LangGraphAgentAdapter,
    CrewAIAgentCreator,
    CrewAIAgentAdapter,
    AgnoAgentCreator,
    AgnoAgentAdapter,
    PydanticAIAgentCreator,
    get_model,
)


class TestAgentFactory:
    """Test suite for AgentFactory."""
    
    def test_get_creator_langgraph(self):
        """Test that factory returns LangGraph creator for 'langgraph'."""
        creator = AgentFactory.get_creator("langgraph")
        assert isinstance(creator, LangGraphAgentCreator)
    
    def test_get_creator_langgraph_case_insensitive(self):
        """Test that framework names are case-insensitive."""
        creator = AgentFactory.get_creator("LangGraph")
        assert isinstance(creator, LangGraphAgentCreator)
    
    def test_get_creator_crewai(self):
        """Test that factory returns CrewAI creator for 'crewai'."""
        creator = AgentFactory.get_creator("crewai")
        assert isinstance(creator, CrewAIAgentCreator)
    
    def test_get_creator_agno(self):
        """Test that factory returns Agno creator for 'agno'."""
        creator = AgentFactory.get_creator("agno")
        assert isinstance(creator, AgnoAgentCreator)
    
    def test_get_creator_pydantic_ai(self):
        """Test that factory returns Pydantic-AI creator for 'pydantic-ai'."""
        creator = AgentFactory.get_creator("pydantic-ai")
        assert isinstance(creator, PydanticAIAgentCreator)
    
    def test_get_creator_invalid_framework(self):
        """Test that factory raises ValueError for invalid framework."""
        with pytest.raises(ValueError) as exc_info:
            AgentFactory.get_creator("invalid_framework")
        
        assert "Unsupported agent framework" in str(exc_info.value)
        assert "invalid_framework" in str(exc_info.value)
        assert "langgraph" in str(exc_info.value)  # Should list supported frameworks
    
    def test_create_agent_langgraph_returns_adapter(self):
        """Test that factory returns an adapter when creating LangGraph agent."""
        adapter = AgentFactory.create_agent(
            framework="langgraph",
            name="TestAgent",
            model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
            tools=[],
            system_prompt="Test prompt",
            structured_output_model=None
        )
        
        # Should return an adapter, not raw agent
        assert isinstance(adapter, AgentAdapter)
        assert isinstance(adapter, LangGraphAgentAdapter)
        assert hasattr(adapter, 'invoke')


class TestLangGraphAgentAdapter:
    """Test suite for LangGraphAgentAdapter."""
    
    def test_adapter_has_invoke_method(self):
        """Test that adapter has invoke method."""
        creator = LangGraphAgentCreator()        
        adapter = creator.create_agent(
            name="TestAgent",
            model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
            tools=[],
            system_prompt="Test prompt"
        )
        
        assert isinstance(adapter, LangGraphAgentAdapter)
        assert hasattr(adapter, 'invoke')
        assert callable(adapter.invoke)
    
    def test_adapter_invoke_returns_standardized_format(self):
        """Test that adapter invoke returns standardized response format."""
        # Create a mock agent
        mock_agent = MagicMock()
        mock_message = MagicMock()
        mock_message.content = "Test response"
        mock_agent.invoke.return_value = {"messages": [mock_message]}
        
        adapter = LangGraphAgentAdapter(mock_agent)
        
        result = adapter.invoke([{"role": "user", "content": "Hello"}])
        
        # Check standardized format
        # Check standardized format
        assert isinstance(result, str)
        assert result == "Test response"
    
    def test_adapter_invoke_raises_on_missing_messages(self):
        """Test that adapter raises ValueError when response missing messages."""
        mock_agent = MagicMock()
        mock_agent.invoke.return_value = {}
        
        adapter = LangGraphAgentAdapter(mock_agent)
        
        with pytest.raises(ValueError, match="Agent response missing 'messages'"):
            adapter.invoke([{"role": "user", "content": "Hello"}])


class TestPlaceholderAgentAdapters:
    """Test suite for placeholder agent adapters (CrewAI, Agno, Pydantic-AI)."""
    
    def test_crewai_adapter_raises_import_error(self):
        """Test that CrewAI creator raises ImportError if crewai not installed."""
        creator = CrewAIAgentCreator()        
        # Should raise ImportError if crewai package is not installed
        try:
            adapter = creator.create_agent(
                name="TestAgent",
                model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
                tools=[],
                system_prompt="Test"
            )
            # If we get here, crewai is installed - test the adapter
            assert isinstance(adapter, CrewAIAgentAdapter)
        except ImportError as e:
            assert "crewai" in str(e).lower()
    
    def test_agno_adapter_raises_import_error(self):
        """Test that Agno creator raises ImportError if agno not installed."""
        creator = AgnoAgentCreator()
        # Should raise ImportError if agno package is not installed
        try:
            adapter = creator.create_agent(
                name="TestAgent",
                model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
                tools=[],
                system_prompt="Test",
            )
            # If we get here, agno is installed - test the adapter
            assert isinstance(adapter, AgnoAgentAdapter)
        except ImportError as e:
            assert "agno" in str(e).lower()


class TestGetModelBedrock:
    """Test suite for Bedrock provider support via LiteLLM."""

    def test_bedrock_no_api_key_required(self):
        """Test that bedrock provider does not require an API key."""
        with patch("langchain_community.chat_models.ChatLiteLLM") as mock_cls:
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
            }
            get_model(config)
            mock_cls.assert_called_once_with(
                model="bedrock/converse/anthropic.claude-3-sonnet-20240229-v1:0"
            )

    def test_bedrock_model_string_format(self):
        """Test that bedrock model string is formatted as bedrock/{model_name}."""
        with patch("langchain_community.chat_models.ChatLiteLLM") as mock_cls:
            config = {
                "model_name": "anthropic.claude-3-haiku-20240307-v1:0",
                "provider": "bedrock",
            }
            get_model(config)
            call_kwargs = mock_cls.call_args[1]
            assert call_kwargs["model"] == "bedrock/converse/anthropic.claude-3-haiku-20240307-v1:0"

    def test_openai_still_uses_chatopenai(self):
        """Test that openai provider continues to use ChatOpenAI."""
        from langchain_openai import ChatOpenAI
        config = {"model_name": "gpt-4o-mini", "provider": "openai", "api_key": "sk-test"}
        model = get_model(config)
        assert isinstance(model, ChatOpenAI)

    def test_ollama_still_uses_chatopenai(self):
        """Test that ollama provider continues to use ChatOpenAI."""
        from langchain_openai import ChatOpenAI
        config = {"model_name": "llama3.2", "provider": "ollama"}
        model = get_model(config)
        assert isinstance(model, ChatOpenAI)

    def test_agno_with_bedrock_raises_error(self):
        """Test that agno framework with bedrock raises a clear error."""
        config = {
            "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
            "provider": "bedrock",
        }
        with pytest.raises(ValueError, match="not supported with the 'agno' framework"):
            get_model(config, framework="agno")

    def test_bedrock_with_structured_output(self):
        """Test that structured output works with bedrock/litellm path."""
        from pydantic import BaseModel, Field

        class TestOutput(BaseModel):
            answer: str = Field(description="test")

        with patch("langchain_community.chat_models.ChatLiteLLM") as mock_cls:
            mock_llm = MagicMock()
            mock_cls.return_value = mock_llm
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
            }
            get_model(config, output_schema=TestOutput)
            mock_llm.with_structured_output.assert_called_once_with(TestOutput)

    def test_bedrock_with_tools(self):
        """Test that tool binding works with bedrock/litellm path."""
        with patch("langchain_community.chat_models.ChatLiteLLM") as mock_cls:
            mock_llm = MagicMock()
            mock_cls.return_value = mock_llm
            tools = [MagicMock()]
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
            }
            get_model(config, tools=tools)
            mock_llm.bind_tools.assert_called_once_with(tools)

    def test_bedrock_with_base_url(self):
        """Test that base_url is passed as api_base to ChatLiteLLM."""
        with patch("langchain_community.chat_models.ChatLiteLLM") as mock_cls:
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
                "base_url": "https://custom-endpoint.example.com",
            }
            get_model(config)
            call_kwargs = mock_cls.call_args[1]
            assert call_kwargs["api_base"] == "https://custom-endpoint.example.com"
    