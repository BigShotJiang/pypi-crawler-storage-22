/**
 * Utility functions for memory operations.
 */

/**
 * Read bytes from memory at the specified address.
 *
 * @param {NativePointer} address - The memory address to read from.
 * @param {number} size - Number of bytes to read.
 * @returns {ArrayBuffer | null} ArrayBuffer containing the read data, or null on failure.
 */
export function readMemoryBytes(address: NativePointer, size: number): ArrayBuffer | null {
  return address.readByteArray(size);
}

/**
 * Read a C string from memory at the specified address.
 *
 * @param {NativePointer} address - The memory address to read from.
 * @returns {string | null} The read string or null if reading failed.
 */
export function readCString(address: NativePointer): string | null {
  try {
    return address.readCString();
  } catch (error) {
    console.error(
      `Failed to read C string at ${address}: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
    return null;
  }
}
