"""soSaver - a tool for dumping .so files from Android applications using Frida."""

__version__ = "1.0.1"

from sosaver.device.connector import DeviceConnector
from sosaver.dumper.module_dumper import ModuleDumper
from sosaver.frida.script_manager import script_manager
from sosaver.fs.file_manager import FileManager
from sosaver.utils.logging import LogLevel, logger

__all__ = [
    "ModuleDumper",
    "DeviceConnector",
    "FileManager",
    "logger",
    "LogLevel",
    "script_manager"
]
