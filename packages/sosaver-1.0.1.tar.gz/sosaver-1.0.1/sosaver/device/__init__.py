"""
Package for working with Android devices via Frida.

Provides classes and functions for connecting to devices
and Android processes.
"""

from sosaver.device.connector import DeviceConnector

__all__ = ['DeviceConnector']
