"""
Package for dumping libraries from Android process memory.

Provides components for extracting and saving .so libraries
from Android application memory.
"""

# Architectural decision: avoiding imports in __init__.py to prevent
# circular dependencies between package modules.
#
# Main components of this package:
# - ModuleDumper: extracts libraries from memory
# - MessageHandler: processes messages from Frida agent
# - ModuleDumpManager: coordinates the library dumping process
#
# Recommended way to import components:
# from sosaver.dumper.module_dumper import ModuleDumper
# from sosaver.dumper.message_handler import MessageHandler
# from sosaver.dumper.manager import ModuleDumpManager
