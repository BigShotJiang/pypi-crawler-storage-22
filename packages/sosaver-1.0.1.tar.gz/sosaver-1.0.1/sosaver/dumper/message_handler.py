"""
Module for handling messages from the Frida script.

Provides the MessageHandler class that processes various types
of messages from the JavaScript script and performs appropriate actions.
"""

from typing import Any, Dict, Optional, Protocol

from sosaver.utils.logging import LogContext, logger


# Protocol for DumpManager instead of direct import
class DumpManagerProtocol(Protocol):
    """Protocol for the dump manager."""
    active_dumps: Dict[str, Dict[str, Any]]

    def start_module_dump(self, module_name: str, base_address: str, module_size: int, is_partial: bool = False) -> str:
        """Start dumping a module and create its file.

        Args:
            module_name: Name of the module to dump.
            base_address: Base memory address of the module.
            module_size: Total size of the module in bytes.
            is_partial: Whether this is a partial dump due to memory access restrictions.

        Returns:
            Path to the created file.
        """
        ...

    def write_module_chunk(self, module_name: str, data: bytes, offset: int, chunk_size: int) -> None:
        """Write a chunk of data to a module dump file.

        Args:
            module_name: Name of the module being dumped.
            data: Binary data chunk to write.
            offset: Offset position in the file to write at.
            chunk_size: Size of the data chunk in bytes.
        """
        ...

    def complete_module_dump(self, module_name: str) -> str:
        """Mark a module dump as complete and finalize the file.

        Args:
            module_name: Name of the module to complete.

        Returns:
            Path to the completed dump file.
        """
        ...


class MessageHandler:
    """
    Handler for messages from the Frida script.

    Responsible for interpreting messages of various types
    from the JavaScript script and performing appropriate actions.
    """

    # Message types from the Frida script
    MSG_TYPE_MODULE_INFO = "module_info"
    MSG_TYPE_MODULE_CHUNK = "module_chunk"
    MSG_TYPE_MODULE_ERROR = "module_error"
    MSG_TYPE_MODULE_COMPLETE = "module_complete"
    MSG_TYPE_GENERAL_ERROR = "error"
    MSG_TYPE_INFO = "send"

    # Message payload keys
    KEY_MODULE = "module"
    KEY_BASE = "base"
    KEY_SIZE = "size"
    KEY_PATH = "path"
    KEY_OFFSET = "offset"
    KEY_CHUNK_SIZE = "chunk_size"
    KEY_ERROR = "error"
    KEY_DESCRIPTION = "description"
    KEY_STACK = "stack"
    KEY_IS_PARTIAL = "is_partial"

    def __init__(self, dump_manager: Optional[DumpManagerProtocol] = None):
        """
        Initialize the message handler.

        Args:
            dump_manager: The dump manager for saving dumped libraries.
        """
        self.dump_manager = dump_manager

    def set_dump_manager(self, dump_manager: DumpManagerProtocol) -> None:
        """
        Set the dump manager.

        Args:
            dump_manager: The dump manager for saving dumped libraries.
        """
        self.dump_manager = dump_manager

    def handle_message(self, message: Dict[str, Any], data: Optional[bytes]) -> None:
        """
        Handle a message from the Frida script.

        Args:
            message: The message from the script.
            data: Binary data, if any.
        """
        msg_type = message.get("payload", {}).get("type", "")
        payload = message.get("payload", {})

        try:
            if msg_type == self.MSG_TYPE_MODULE_INFO:
                self._handle_module_info(payload)
            elif msg_type == self.MSG_TYPE_MODULE_CHUNK:
                if data:
                    self._handle_module_chunk(payload, data)
                else:
                    module_name = payload.get(self.KEY_MODULE, "unknown")
                    logger.warning("Received chunk without data for module",
                                 context=LogContext(logger.COMPONENT_MODULE, module_name))
            elif msg_type == self.MSG_TYPE_MODULE_ERROR:
                self._handle_module_error(payload)
            elif msg_type == self.MSG_TYPE_MODULE_COMPLETE:
                self._handle_module_complete(payload)
            elif msg_type == self.MSG_TYPE_GENERAL_ERROR:
                self._handle_general_error(payload)
            elif msg_type == self.MSG_TYPE_INFO or message.get("type") == "send":
                self._handle_info_message(payload)
            else:
                # Handle old message format for backward compatibility
                if isinstance(payload, dict) and self.KEY_MODULE in payload and data:
                    logger.warning("Received message in old format",
                                  context=LogContext(logger.COMPONENT_FRIDA))
                elif isinstance(payload, str):
                    logger.frida(payload)
                else:
                    logger.debug(f"Unknown message type '{msg_type}': {message}",
                               context=LogContext(logger.COMPONENT_FRIDA))
        except Exception as e:
            logger.error(f"Error handling message: {e}",
                        context=LogContext(logger.COMPONENT_FRIDA))
            logger.debug(f"Message: {message}",
                       context=LogContext(logger.COMPONENT_FRIDA))
            if data:
                logger.debug(f"Data size: {len(data)} bytes",
                           context=LogContext(logger.COMPONENT_FRIDA))

    def _handle_module_info(self, payload: Dict[str, Any]) -> None:
        """
        Handle module information before dumping starts.

        Args:
            payload: Module information.
        """
        try:
            # Get module data
            module_name = payload.get(self.KEY_MODULE, "")
            base_address = payload.get(self.KEY_BASE, "0x0")
            module_size = payload.get(self.KEY_SIZE, 0)
            module_path = payload.get(self.KEY_PATH, "")
            is_partial = payload.get(self.KEY_IS_PARTIAL, False)

            if not module_name:
                logger.error("Received module information without name",
                            context=LogContext(logger.COMPONENT_FRIDA))
                return

            # Create context for this module
            module_context = LogContext(logger.COMPONENT_MODULE, module_name)

            logger.info(
                f"Starting module dump (size: {module_size} bytes, address: {base_address})",
                context=module_context
            )

            if module_path:
                logger.debug(f"Module path: {module_path}", context=module_context)

            if is_partial:
                logger.warning(
                    "Module will be dumped partially (memory access restriction)",
                    context=module_context
                )

            # Start writing module
            if self.dump_manager is None:
                logger.error("Dump manager not set", context=module_context)
                return

            save_path = self.dump_manager.start_module_dump(module_name, base_address, module_size, is_partial)
            logger.info(f"Module will be saved to '{save_path}'", context=module_context)

        except Exception as e:
            module_name_str = module_name if isinstance(module_name, str) else "unknown"
            if module_name_str:
                logger.error(f"Error handling module information: {e}",
                            context=LogContext(logger.COMPONENT_MODULE, module_name_str))
            else:
                logger.error(f"Error handling module information: {e}",
                            context=LogContext(logger.COMPONENT_FRIDA))

    def _handle_module_chunk(self, payload: Dict[str, Any], data: bytes) -> None:
        """
        Handle a part of the module data.

        Args:
            payload: Information about the part.
            data: Part data.
        """
        try:
            # Get part data
            module_name = payload.get(self.KEY_MODULE, "")
            offset = payload.get(self.KEY_OFFSET, 0)
            chunk_size = payload.get(self.KEY_CHUNK_SIZE, 0)

            if not module_name:
                logger.error("Received module part without name",
                            context=LogContext(logger.COMPONENT_FRIDA))
                return

            # Write module part
            if self.dump_manager is None:
                logger.error("Dump manager not set",
                            context=LogContext(logger.COMPONENT_MODULE, module_name))
                return

            self.dump_manager.write_module_chunk(module_name, data, offset, chunk_size)

        except Exception as e:
            module_name_str = module_name if isinstance(module_name, str) else "unknown"
            if module_name_str:
                logger.error(f"Error handling module part: {e}",
                            context=LogContext(logger.COMPONENT_MODULE, module_name_str))
            else:
                logger.error(f"Error handling module part: {e}",
                            context=LogContext(logger.COMPONENT_FRIDA))

    def _handle_module_error(self, payload: Dict[str, Any]) -> None:
        """
        Handle a module dumping error.

        Args:
            payload: Error information.
        """
        module_name = payload.get(self.KEY_MODULE, "unknown")
        error = payload.get(self.KEY_ERROR, "unknown error")
        description = payload.get(self.KEY_DESCRIPTION, "")
        stack = payload.get(self.KEY_STACK, "")

        module_context = LogContext(logger.COMPONENT_MODULE, module_name)

        logger.error(f"Error dumping module: {error}.", context=module_context)

        if description:
            logger.error(f"Description: {description}.", context=module_context)

        if stack:
            logger.debug(f"Stack trace: {stack}.", context=module_context)

        # Handle specific memory access error
        if "memory access error" in error.lower() or "memory access violation" in error.lower():
            logger.warning(
                "Memory access error. Module may be protected from reading.",
                context=module_context
            )

        # Try to complete module dump
        try:
            if self.dump_manager is None:
                logger.debug("Dump manager not set", context=module_context)
                return

            if module_name in self.dump_manager.active_dumps:
                self.dump_manager.complete_module_dump(module_name)
        except Exception as e:
            logger.debug(f"Failed to complete module dump: {e}.", context=module_context)

    def _handle_module_complete(self, payload: Dict[str, Any]) -> None:
        """
        Handle module dumping completion.

        Args:
            payload: Completion information.
        """
        module_name = payload.get(self.KEY_MODULE, "unknown")
        module_context = LogContext(logger.COMPONENT_MODULE, module_name)

        try:
            # Complete module dump
            if self.dump_manager is None:
                logger.error("Dump manager not set", context=module_context)
                return

            self.dump_manager.complete_module_dump(module_name)

        except Exception as e:
            logger.error(f"Error completing module dump: {e}.", context=module_context)

    def _handle_general_error(self, payload: Dict[str, Any]) -> None:
        """
        Handle a general script error.

        Args:
            payload: Error information.
        """
        error = payload.get(self.KEY_ERROR, "unknown error")
        description = payload.get(self.KEY_DESCRIPTION, "")
        stack = payload.get(self.KEY_STACK, "")

        logger.error(f"General script error: {error}.",
                    context=LogContext(logger.COMPONENT_FRIDA))

        if description:
            logger.error(f"Description: {description}.",
                        context=LogContext(logger.COMPONENT_FRIDA))

        if stack:
            logger.debug(f"Stack trace: {stack}.",
                        context=LogContext(logger.COMPONENT_FRIDA))

    def _handle_info_message(self, payload: Dict[str, Any]) -> None:
        """
        Handle an informational message from the script.

        Args:
            payload: Message content.
        """
        if isinstance(payload, str):
            logger.frida(payload)
        elif isinstance(payload, dict) and "message" in payload:
            logger.frida(payload["message"])
        else:
            logger.debug(f"Informational message: {payload}.",
                       context=LogContext(logger.COMPONENT_FRIDA))
