"""
Package for working with Frida scripting functionality.

Provides components for loading, managing and executing
Frida scripts for library extraction.

"""
