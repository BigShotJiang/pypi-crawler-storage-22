"""
Package containing JavaScript scripts for Frida agent.

This package includes the JavaScript code that will be injected
into the target Android application to extract native libraries.
"""
