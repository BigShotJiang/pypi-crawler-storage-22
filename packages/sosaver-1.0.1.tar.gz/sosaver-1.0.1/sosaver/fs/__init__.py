"""
Package for working with the file system.

Provides components for managing files and paths
when saving dumped libraries.
"""

from sosaver.fs.file_manager import FileManager
from sosaver.fs.path_generator import PathGenerator

__all__ = ['FileManager', 'PathGenerator']
