"""
Module for working with the file system.

Provides an interface for working with the file system,
including path generation and module dump management.

"""

import glob
import os
from typing import Any, Dict, List, Optional, Protocol

from sosaver.fs.path_generator import PathGenerator
from sosaver.utils.logging import LogContext, logger


# Define a protocol for DumpManager to avoid circular imports
class DumpManagerProtocol(Protocol):
    """Protocol for the dump manager."""
    active_dumps: Dict[str, Dict[str, Any]]

    def start_module_dump(self, module_name: str, base_address: str, module_size: int, is_partial: bool = False) -> str:
        """Start dumping a module and create its file.

        Args:
            module_name: Name of the module to dump.
            base_address: Base memory address of the module.
            module_size: Total size of the module in bytes.
            is_partial: Whether this is a partial dump due to memory access restrictions.

        Returns:
            Path to the created file.
        """
        ...

    def write_module_chunk(self, module_name: str, data: bytes, offset: int, chunk_size: int) -> None:
        """Write a chunk of data to a module dump file.

        Args:
            module_name: Name of the module being dumped.
            data: Binary data chunk to write.
            offset: Offset position in the file to write at.
            chunk_size: Size of the data chunk in bytes.
        """
        ...

    def complete_module_dump(self, module_name: str) -> str:
        """Mark a module dump as complete and finalize the file.

        Args:
            module_name: Name of the module to complete.

        Returns:
            Path to the completed dump file.
        """
        ...

    def cleanup_active_dumps(self, log_incomplete: bool = False) -> None:
        """Clean up any incomplete module dumps.

        Args:
            log_incomplete: Whether to log incomplete dumps before cleanup.
        """
        ...


class FileManager:
    """
    File system manager.

    Provides a unified interface for file operations,
    including organizing output directories and managing module dumps.
    """

    def __init__(self, output_folder: str = "dumped_so", dump_manager: Optional[DumpManagerProtocol] = None):
        """
        Initialize the file system manager.

        Args:
            output_folder: Directory for saving dumped libraries.
            dump_manager: Module dump manager (if None, will be set later).
        """
        self.output_folder = os.path.abspath(output_folder)
        self.path_generator = PathGenerator(output_folder)
        self.dump_manager = dump_manager

        # If dump_manager is not provided, it must be set later
        # via set_dump_manager before using dump-related methods

    def set_dump_manager(self, dump_manager: DumpManagerProtocol) -> None:
        """
        Set the dump manager.

        Args:
            dump_manager: Module dump manager.
        """
        self.dump_manager = dump_manager

    @property
    def active_dumps(self) -> Dict[str, Dict[str, Any]]:
        """Active module dumps."""
        if self.dump_manager is None:
            return {}
        return self.dump_manager.active_dumps

    # Methods for managing module dumps

    def start_module_dump(self, module_name: str, base_address: str, module_size: int, is_partial: bool = False) -> str:
        """
        Start recording a module dump.

        Args:
            module_name: Module name.
            base_address: Base address of the module.
            module_size: Module size in bytes.
            is_partial: Is the dump partial.

        Returns:
            Path to the file where the dump will be recorded.
        """
        if self.dump_manager is None:
            raise ValueError("Dump manager is not set. Use set_dump_manager()")
        return self.dump_manager.start_module_dump(module_name, base_address, module_size, is_partial)

    def write_module_chunk(self, module_name: str, data: bytes, offset: int, chunk_size: int) -> None:
        """
        Write a part of the module data.

        Args:
            module_name: Module name.
            data: Data to write.
            offset: Offset from the beginning of the file.
            chunk_size: Size of the data part.
        """
        if self.dump_manager is None:
            raise ValueError("Dump manager is not set. Use set_dump_manager()")
        self.dump_manager.write_module_chunk(module_name, data, offset, chunk_size)

    def complete_module_dump(self, module_name: str) -> str:
        """
        Complete the recording of a module dump.

        Args:
            module_name: Module name.

        Returns:
            Path to the saved file.
        """
        if self.dump_manager is None:
            raise ValueError("Dump manager is not set. Use set_dump_manager()")
        return self.dump_manager.complete_module_dump(module_name)

    def cleanup_active_dumps(self, log_incomplete: bool = False) -> None:
        """
        Close all active dump files.

        Args:
            log_incomplete: Log incomplete dumps.
        """
        if self.dump_manager is None:
            return
        self.dump_manager.cleanup_active_dumps(log_incomplete)

    # Methods for analyzing results

    def get_dumped_files(self) -> List[str]:
        """
        Get a list of all dumped files.

        Returns:
            List of file paths.
        """
        if not os.path.exists(self.output_folder):
            return []

        # Find all .bin files in the output directory
        bin_files = glob.glob(os.path.join(self.output_folder, "*.bin"))
        return sorted(bin_files)

    def get_dump_stats(self) -> Dict[str, Any]:
        """
        Get statistics on dumped files.

        Returns:
            Dictionary with statistics.
        """
        try:
            if not os.path.exists(self.output_folder):
                logger.warning(
                    f"Failed to get statistics: directory {self.output_folder} does not exist",
                    context=LogContext(logger.COMPONENT_FILE)
                )
                return {
                    "dumped_modules_count": 0,
                    "files_count": 0,
                    "total_size_mb": 0
                }

            dumped_files = self.get_dumped_files()

            # Calculate the total size
            total_size = sum(os.path.getsize(file) for file in dumped_files)

            # Calculate the number of modules (by unique names without address)
            unique_modules = set()
            for file_path in dumped_files:
                file_name = os.path.basename(file_path)
                # Find the index of the first underscore after the file name
                underscores = [i for i, c in enumerate(file_name) if c == '_']
                if underscores:
                    # Take the name before the first underscore
                    module_name = file_name[:underscores[0]]
                    unique_modules.add(module_name)

            return {
                "dumped_modules_count": len(unique_modules),
                "files_count": len(dumped_files),
                "total_size_mb": round(total_size / (1024 * 1024), 2)
            }

        except Exception as e:
            logger.error(
                f"Error getting statistics: {e}",
                context=LogContext(logger.COMPONENT_FILE)
            )
            return {
                "error": str(e),
                "dumped_modules_count": 0,
                "files_count": 0,
                "total_size_mb": 0
            }
