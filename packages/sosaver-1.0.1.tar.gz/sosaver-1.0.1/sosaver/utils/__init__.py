"""Utilities for soSaver.

This package contains various utility classes and functions used throughout soSaver,
including custom exceptions, logging, and helper functions.

"""
