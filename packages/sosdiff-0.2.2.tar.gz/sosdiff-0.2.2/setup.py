import os
import setuptools


def read(fname):
    return open(
        os.path.join(os.path.dirname(__file__), fname), encoding="utf-8"
        ).read()


setuptools.setup(
    name='sosdiff',
    version='v0.2.2',
    setup_requires=[],
    scripts=[
        'sosdiff/bin/__init__.py'],
    entry_points={
        'console_scripts': [
            'sosdiff=sosdiff.bin:main'
            ],
        },
    packages=setuptools.find_packages(),
    package_data={
        'sosdiff.html.css': ['*'],
        'sosdiff.html.js': ['*'],
        'sosdiff.templates': ['*'],
    },
    license='GPLv3',
    author='Pablo Fernández Rodríguez',
    url='https://github.com/pafernanr/sosdiff',
    keywords='sos sosreport',
    description="Compare two sosreports and show the differences.",
    long_description_content_type='text/markdown',
    long_description=read("README.md"),
    classifiers=[
        'Intended Audience :: Information Technology',
        'Intended Audience :: System Administrators',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
    ],
    )
