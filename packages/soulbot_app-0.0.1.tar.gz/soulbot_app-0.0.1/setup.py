from setuptools import setup, find_packages

setup(
    name="soulbot-app",
    version="0.0.1",
    description="Hello World",
    long_description="Hello World",
    long_description_content_type="text/markdown",
    author="",
    author_email="",
    url="",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
