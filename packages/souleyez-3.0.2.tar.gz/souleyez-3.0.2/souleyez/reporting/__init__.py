"""SoulEyez reporting module."""

from .generator import ReportGenerator

__all__ = ["ReportGenerator"]
