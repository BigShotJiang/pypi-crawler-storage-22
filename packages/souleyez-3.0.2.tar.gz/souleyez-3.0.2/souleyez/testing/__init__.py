"""
souleyez.testing - Credential and service testing modules
"""
