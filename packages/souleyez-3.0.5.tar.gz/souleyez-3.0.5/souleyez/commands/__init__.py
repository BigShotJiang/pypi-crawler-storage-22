"""Commands package for SoulEyez."""
