# soundgen
soundgen it's a library written on Python for generate sounds.

## How it works?
It's creating sounds with math help.

## Dependencies
- numpy
- hatchling (if you build your version of soundgen library)

## Installation
pip install soundgen - and begin!