from soundgen import sound_down

sound_down("test.wav", 1000, 100, 1.0)