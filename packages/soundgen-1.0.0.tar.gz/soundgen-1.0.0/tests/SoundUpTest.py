from soundgen import sound_up

sound_up("test.wav", 100, 1000, 1.0)