"""
soundhub_utils Constants

Project constants that should never change during runtime.

License: BSD 3-Clause
"""

# Supported audio file formats
SUPPORTED_AUDIO_FORMATS = {'.flac', '.wav', '.mp3', '.m4a', '.ogg'}