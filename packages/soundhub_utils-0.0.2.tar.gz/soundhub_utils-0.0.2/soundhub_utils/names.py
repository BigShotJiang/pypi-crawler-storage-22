"""
FIX ME: names.py used to manage soundhub_utils names and path conventions
"""
from typing import Optional
import re


def filename(
        name: str,
        directory: Optional[str] = None,
        start_byte: Optional[int] = None,
        end_byte: Optional[int] = None,
        start_time: int = None,
        end_time: Optional[int] = None,
        duration: Optional[int] = None,
        segment: Optional[int] = None,
        segment_prefix: str = 'n',
        ext: str = None,
        src_ext: Optional[str] = None) -> str:
    """
    FIX ME
    """
    if ext:
        ext = re.sub(r'^\.', '', ext)
        if src_ext:
            src_ext = re.sub(r'^\.', '', src_ext)
        else:
            src_ext = ext
        name = re.sub(f'\\.{src_ext}$', '', name)
    if segment is not None:
        name = f'{name}.{segment_prefix}{segment}'
    if start_time or end_time or duration:
        if start_time is None:
            start_time = 0
        name = f'{name}.{start_time}'
        if (end_time is None) and duration:
            end_time = start_time + duration
        if end_time:
            name = f'{name}-{end_time}'
    elif start_byte is None:
        if end_byte:
            name = f'{name}.end_byte_{end_byte}'
    else:
        if end_byte:
            name = f'{name}.bytes_{start_byte}-{end_byte}'
        else:
            name = f'{name}.start_byte_{end_byte}'
    if ext:
        name = f'{name}.{ext}'
    if directory:
        name = f'{directory}/{name}'
    return name
