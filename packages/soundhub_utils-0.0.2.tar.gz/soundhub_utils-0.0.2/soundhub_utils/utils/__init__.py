"""
Utility Functions Module  

Generic utility functions and format-specific utilities

License: BSD 3-Clause
"""