from setuptools import setup

setup(
    name="sovereign-memory",
    version="0.0.1",
    description="Sovereign Memory SDK for AI Agents — Coming soon",
    author="SIX — Sovereign Inference Exchange",
    author_email="support@six-sov.com",
    url="https://memory.six-sov.com",
    python_requires=">=3.8",
    py_modules=["sovereign_memory"],
)
