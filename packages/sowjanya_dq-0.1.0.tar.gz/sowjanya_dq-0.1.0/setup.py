from setuptools import setup, find_packages

setup(
    name="sowjanya_dq",
    version="0.1.0",
    description="A Data Quality Framework with Reporting",
    author="Sowjanya",
    packages=find_packages(),
    install_requires=[
        "pandas"  # This ensures the user has pandas installed
    ]
)