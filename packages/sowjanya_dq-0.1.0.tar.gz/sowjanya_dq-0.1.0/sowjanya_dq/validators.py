import pandas as pd

class NullChecker:
    """Checks for missing (null) values in a column."""
    def __init__(self, df):
        self.df = df

    def run(self, column):
        null_count = self.df[column].isnull().sum()
        status = "FAIL" if null_count > 0 else "PASS"
        return {
            "check_type": "Completeness",
            "column": column,
            "status": status,
            "details": f"{null_count} missing values found"
        }

class DuplicateChecker:
    """Checks for duplicate values in a column."""
    def __init__(self, df):
        self.df = df

    def run(self, column):
        # subset=[column] checks for duplicates in that specific column only
        dupe_count = self.df.duplicated(subset=[column]).sum()
        status = "FAIL" if dupe_count > 0 else "PASS"
        return {
            "check_type": "Uniqueness",
            "column": column,
            "status": status,
            "details": f"{dupe_count} duplicates found"
        }

class RangeChecker:
    """Checks if numerical values fall within a specific range."""
    def __init__(self, df):
        self.df = df

    def run(self, column, min_val, max_val):
        # We find rows that are NOT (~) between min and max
        outliers = self.df[~self.df[column].between(min_val, max_val)]
        count = len(outliers)
        status = "FAIL" if count > 0 else "PASS"
        return {
            "check_type": "Validity",
            "column": column,
            "status": status,
            "details": f"{count} values outside range {min_val}-{max_val}"
        }

class DQReport:
    """Collects results from all checks and exports them."""
    def __init__(self):
        self.results = []

    def log(self, result):
        """Adds a result dictionary to the list."""
        self.results.append(result)

    def to_csv(self, filename="dq_report.csv"):
        """Saves the collected results to a CSV file."""
        if not self.results:
            print("Warning: No checks were logged.")
            return
        
        report_df = pd.DataFrame(self.results)
        report_df.to_csv(filename, index=False)
        print(f"✅ Report successfully generated: {filename}")