import requests
import base64

class ScrapingPros:
    """
    Class to interact with the Scraping Pros API.

    Args:
        api_token: authentication token for the API.

    Example:
        >>> client = ScrapingPros('token123')
    """
    def __init__(self, token):
        self.token = token


    def scrape_site(self, data):
        """
        Method to scrape a site.
        
        Args:
            data: A dictionary with the instructions to scrape the website. Documentation in:
                https://gitlab.com/7Puentes/scraping-pros-api/-/blob/master/docs/sync/scrape.md?ref_type=heads
        
        Screenshots: 
            If a screenshot where to be requested, the user needs a "screenshots" folder in their 
            project so the screenshots are saved inside of said folder.
        """
        
        response = requests.post(
        "http://mascherano.7puentes.com:8000/v1/sync/scrape", #change this latter to production API
        json=data,
        headers={"Authorization": f"Bearer {self.token}"}
        )
        parsed_responsed = response.json()
        page_name = data["url"].replace("https://", "").replace("/", "").replace(".", "_")
        if parsed_responsed.get("screenshot"):
            jpgtxt = base64.decodebytes(parsed_responsed["screenshot"].encode("utf-8"))
            with open(f"screenshots/{page_name}.jpg", "wb") as f:
                f.write(jpgtxt)

        return parsed_responsed
    

    # def metrics(self, dates : str = '', metric : str = ''):
    #     """
    #     Method to get the metrics from the API.
        
    #     Args:
    #         dates: a range of dates to get the metrics from. The format of the range is:
    #             YYYY-MM-DD:YYYY-MM-DD
    #         metric: a string that represents a specific metric you want to see. Accepted values are:
    #             [url, proxy, api_codes, page_codes, exe_time, scrape_type]

    #     Return: 
    #         A JSON response with the metrics.
    #     """

    #     response = requests.get(
    #     "http://mascherano.7puentes.com:8000/v1/sync/metrics", #change this latter to production API
    #     params={"date":dates,"metric":metric},
    #     headers={"Authorization": f"Bearer {self.token}"}
    #     )
    #     parsed_responsed = response.json()

    #     return parsed_responsed