# Space Data Standards (Python)

High-performance FlatBuffers schemas for space data exchange.

## Installation

```bash
pip install spacedatastandards
```

## Usage

```python
import flatbuffers
from spacedatastandards.OMM import OMM

# Create a builder
builder = flatbuffers.Builder(1024)

# Build your message...
```

## Documentation

- [Website](https://spacedatastandards.org)
- [GitBook](https://digitalarsenal-io-inc.gitbook.io/spacedatastandards.org/)
- [GitHub](https://github.com/DigitalArsenal/spacedatastandards.org)
