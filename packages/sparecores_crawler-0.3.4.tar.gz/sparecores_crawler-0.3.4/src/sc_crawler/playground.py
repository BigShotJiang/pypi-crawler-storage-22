# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
import os
import sys
import json

from typing import List

from alibabacloud_bssopenapi20171214.client import Client as BssOpenApi20171214Client
from alibabacloud_credentials.client import Client as CredentialClient
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_bssopenapi20171214 import models as bss_open_api_20171214_models
from alibabacloud_tea_util import models as util_models
from alibabacloud_tea_util.client import Client as UtilClient


class Sample:
    def __init__(self):
        pass

    @staticmethod
    def create_client() -> BssOpenApi20171214Client:
        """
        Initialize the Client with the credentials
        @return: Client
        @throws Exception
        """
        # It is recommended to use the default credential. For more credentials, please refer to: https://www.alibabacloud.com/help/en/alibaba-cloud-sdk-262060/latest/configure-credentials-378659.
        credential = CredentialClient()
        config = open_api_models.Config(
            credential=credential
        )
        # See https://api.alibabacloud.com/product/BssOpenApi.
        config.endpoint = f'business.ap-southeast-1.aliyuncs.com'
        return BssOpenApi20171214Client(config)

    @staticmethod
    def main(
        args: List[str],
    ) -> None:
        client = Sample.create_client()
        module_list_0 = bss_open_api_20171214_models.GetPayAsYouGoPriceRequestModuleList(
            module_code='InstanceType',
            price_type='Hour',
            config='InstanceType:ecs.t5-lc1m1.small'
        )
        get_pay_as_you_go_price_request = bss_open_api_20171214_models.GetPayAsYouGoPriceRequest(
            product_code='ecs',
            subscription_type='PayAsYouGo',
            module_list=[
                module_list_0
            ]
        )
        runtime = util_models.RuntimeOptions()
        try:
            resp = client.get_pay_as_you_go_price_with_options(get_pay_as_you_go_price_request, runtime)
            print(json.dumps(resp, default=str, indent=2))
        except Exception as error:
            # Only a printing example. Please be careful about exception handling and do not ignore exceptions directly in engineering projects.
            # print error message
            print(error.message)
            # Please click on the link below for diagnosis.
            print(error.data.get("Recommend"))

    @staticmethod
    async def main_async(
        args: List[str],
    ) -> None:
        client = Sample.create_client()
        module_list_0 = bss_open_api_20171214_models.GetPayAsYouGoPriceRequestModuleList(
            module_code='InstanceType',
            price_type='Hour',
            config='InstanceType:ecs.t5-lc1m1.small'
        )
        get_pay_as_you_go_price_request = bss_open_api_20171214_models.GetPayAsYouGoPriceRequest(
            product_code='ecs',
            subscription_type='PayAsYouGo',
            module_list=[
                module_list_0
            ]
        )
        runtime = util_models.RuntimeOptions()
        try:
            resp = await client.get_pay_as_you_go_price_with_options_async(get_pay_as_you_go_price_request, runtime)
            print(json.dumps(resp, default=str, indent=2))
        except Exception as error:
            # Only a printing example. Please be careful about exception handling and do not ignore exceptions directly in engineering projects.
            # print error message
            print(error.message)
            # Please click on the link below for diagnosis.
            print(error.data.get("Recommend"))


if __name__ == '__main__':
    Sample.main(sys.argv[1:])
