"""sparktype - Generate static types from OpenAPI specifications."""

__version__ = "0.1.1"
