"""Processing modules for different media types."""
