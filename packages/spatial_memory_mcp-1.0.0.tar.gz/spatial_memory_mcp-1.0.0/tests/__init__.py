"""Tests for Spatial Memory MCP Server."""
