"""Integration tests for Spatial Memory MCP Server."""
