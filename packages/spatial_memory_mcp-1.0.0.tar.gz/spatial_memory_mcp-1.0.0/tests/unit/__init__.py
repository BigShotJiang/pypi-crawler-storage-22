"""Unit tests for Spatial Memory MCP Server."""
