# Implementation Plan for PROPOSED_CHANGES.md

**Generated:** 2026-02-01
**Based on:** Agent analysis of server.py, database.py, embeddings.py, export_import.py, rate_limiter.py

---

## Phase 1: Quick Wins (< 1 hour each)

These are minimal-effort, high-impact changes that can be done immediately.

### 1.1 Add expires_at BTREE Index
**File:** `spatial_memory/core/database.py`
**Line:** ~1050 (btree_columns list)
**Change:** Add `"expires_at"` to btree_columns list

```python
btree_columns = [
    "id",
    "created_at",
    "updated_at",
    "last_accessed",
    "importance",
    "access_count",
    "expires_at",  # ADD THIS
]
```

**Impact:** Faster TTL cleanup queries

---

### 1.2 Add prefilter=True to Namespace Filter
**File:** `spatial_memory/core/database.py`
**Method:** `vector_search()` (~line 2230)
**Change:** Add prefilter parameter

```python
# Before
search = search.where(f"namespace = '{safe_ns}'")

# After
search = search.where(f"namespace = '{safe_ns}'", prefilter=True)
```

**Impact:** Faster vector search when filtering by namespace

---

### 1.3 Remove Deprecated TOCTOU-Vulnerable Methods
**File:** `spatial_memory/services/export_import.py`
**Lines to DELETE:** 827-961 (approximately 130 lines)
**Methods to remove:**
- `_parse_parquet()`
- `_parse_json()`
- `_parse_csv()`

**Verification:** Run `grep -r "_parse_parquet\|_parse_json\|_parse_csv" spatial_memory/` to ensure no usage before deletion.

**Impact:** Removes security risk from deprecated code

---

### 1.4 Export RateLimiter from core module
**File:** `spatial_memory/core/__init__.py`
**Change:** Add RateLimiter to exports

```python
from spatial_memory.core.rate_limiter import RateLimiter

__all__ = [
    # ... existing exports ...
    "RateLimiter",
]
```

**Impact:** Prepares for rate limiting integration

---

## Phase 2: Error Response Refactoring (2-3 hours)

### 2.1 Create Error Response Helper

**File:** `spatial_memory/server.py`
**Location:** After imports, before TOOLS constant (~line 60)

```python
# Error type to response name mapping
ERROR_MAPPINGS: dict[type[Exception], str] = {
    MemoryNotFoundError: "MemoryNotFound",
    ValidationError: "ValidationError",
    DecayError: "DecayError",
    ReinforcementError: "ReinforcementError",
    ExtractionError: "ExtractionError",
    ConsolidationError: "ConsolidationError",
    ExportError: "ExportError",
    MemoryImportError: "ImportError",
    PathSecurityError: "PathSecurityError",
    FileSizeLimitError: "FileSizeLimitError",
    ImportRecordLimitError: "ImportRecordLimitError",
    NamespaceNotFoundError: "NamespaceNotFound",
    NamespaceOperationError: "NamespaceOperationError",
    SpatialMemoryError: "SpatialMemoryError",
}

def _create_error_response(error: Exception, error_id: str | None = None) -> list[TextContent]:
    """Create standardized error response for tool handlers."""
    error_type = ERROR_MAPPINGS.get(type(error), "UnknownError")
    response = {
        "error": error_type,
        "message": str(error),
        "isError": True,
    }
    if error_id:
        response["error_id"] = error_id
    return [TextContent(type="text", text=json.dumps(response))]
```

**Then refactor `call_tool()` method (lines 893-1009):**

```python
async def call_tool(self, name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await self._handle_tool(name, arguments)
        return [TextContent(type="text", text=json.dumps(result, default=str))]
    except tuple(ERROR_MAPPINGS.keys()) as e:
        return _create_error_response(e)
    except Exception as e:
        error_id = str(uuid.uuid4())[:8]
        logger.error(f"Unexpected error [{error_id}] in {name}: {e}", exc_info=True)
        return _create_error_response(e, error_id)
```

**Impact:** Reduces 110+ lines of repetitive exception handling to ~15 lines

---

## Phase 3: Rate Limiting Integration (1-2 hours)

### 3.1 Add Rate Limiter to Server

**File:** `spatial_memory/server.py`

**Step 1: Import** (add to imports section)
```python
from spatial_memory.core.rate_limiter import RateLimiter
```

**Step 2: Initialize in __init__** (after line 882)
```python
# Rate limiting
self._rate_limiter = RateLimiter(
    rate=self._settings.embedding_rate_limit,
    capacity=int(self._settings.embedding_rate_limit * 2)
)
```

**Step 3: Apply in call_tool** (at start of method)
```python
async def call_tool(self, name: str, arguments: dict) -> list[TextContent]:
    # Apply rate limiting
    if not self._rate_limiter.wait(timeout=30.0):
        return [TextContent(
            type="text",
            text=json.dumps({
                "error": "RateLimitExceeded",
                "message": "Too many requests. Please wait and try again.",
                "isError": True,
            })
        )]

    # ... rest of method
```

**Impact:** Prevents resource exhaustion attacks

---

## Phase 4: Move TOOLS to Separate Module (1 hour)

### 4.1 Create Tools Module

**Create directory structure:**
```
spatial_memory/
├── server.py
└── tools/
    ├── __init__.py
    └── definitions.py
```

**File:** `spatial_memory/tools/__init__.py`
```python
from spatial_memory.tools.definitions import TOOLS

__all__ = ["TOOLS"]
```

**File:** `spatial_memory/tools/definitions.py`
```python
"""MCP Tool definitions for Spatial Memory Server."""

from mcp.types import Tool

TOOLS: list[Tool] = [
    # Move lines 66-727 from server.py here
    ...
]
```

**Update server.py:**
```python
from spatial_memory.tools import TOOLS
```

**Impact:** Improves code organization, server.py reduced by 661 lines

---

## Phase 5: Dispatch Pattern Refactor (4-6 hours)

### 5.1 Create Handler Registry

**File:** `spatial_memory/server.py`

**Step 1: Create handler methods** (extract from _handle_tool_impl)

Each tool gets its own async method:
```python
async def _handle_remember(self, arguments: dict) -> dict:
    result = await self._memory_service.remember(
        content=arguments["content"],
        namespace=arguments.get("namespace", "default"),
        importance=arguments.get("importance", 0.5),
        tags=arguments.get("tags"),
        metadata=arguments.get("metadata"),
    )
    return asdict(result)

async def _handle_recall(self, arguments: dict) -> dict:
    results = await self._memory_service.recall(
        query=arguments["query"],
        limit=arguments.get("limit", 5),
        namespace=arguments.get("namespace"),
        min_similarity=arguments.get("min_similarity", 0.0),
    )
    return {
        "memories": [
            {
                "id": r.id,
                "content": r.content,
                "similarity": r.similarity,
                # ... rest of fields
            }
            for r in results
        ]
    }

# ... 20+ more handlers
```

**Step 2: Create registry in __init__**
```python
def __init__(self, ...):
    # ... existing initialization ...

    # Tool handler registry
    self._tool_handlers: dict[str, Callable[[dict], Awaitable[dict]]] = {
        "remember": self._handle_remember,
        "remember_batch": self._handle_remember_batch,
        "recall": self._handle_recall,
        "nearby": self._handle_nearby,
        "forget": self._handle_forget,
        "forget_batch": self._handle_forget_batch,
        "health": self._handle_health,
        "journey": self._handle_journey,
        "wander": self._handle_wander,
        "regions": self._handle_regions,
        "visualize": self._handle_visualize,
        "decay": self._handle_decay,
        "reinforce": self._handle_reinforce,
        "extract": self._handle_extract,
        "consolidate": self._handle_consolidate,
        "stats": self._handle_stats,
        "namespaces": self._handle_namespaces,
        "delete_namespace": self._handle_delete_namespace,
        "rename_namespace": self._handle_rename_namespace,
        "export_memories": self._handle_export_memories,
        "import_memories": self._handle_import_memories,
        "hybrid_recall": self._handle_hybrid_recall,
    }
```

**Step 3: Replace _handle_tool_impl**
```python
async def _handle_tool_impl(self, name: str, arguments: dict) -> dict:
    handler = self._tool_handlers.get(name)
    if handler is None:
        raise ValidationError(f"Unknown tool: {name}")
    return await handler(arguments)
```

**Impact:**
- Cyclomatic complexity: 22 → 2
- Each handler testable independently
- Easy to add/modify tools

---

## Phase 6: Performance Optimizations (3-4 hours)

### 6.1 Fix N+1 Query in update_access_batch

**File:** `spatial_memory/core/database.py`
**Method:** `update_access_batch()` (lines 2062-2130)

```python
@with_process_lock
@with_write_lock
def update_access_batch(self, memory_ids: list[str]) -> int:
    if not memory_ids:
        return 0

    now = utc_now()

    # Validate and sanitize all IDs first
    validated_ids = []
    for memory_id in memory_ids:
        try:
            validated_id = _validate_uuid(memory_id)
            validated_ids.append(_sanitize_string(validated_id))
        except Exception:
            continue

    if not validated_ids:
        return 0

    # BATCH FETCH: Single query for all records
    id_list = ", ".join(f"'{mid}'" for mid in validated_ids)
    all_records = self.table.search().where(f"id IN ({id_list})").to_list()

    if not all_records:
        return 0

    # Prepare updates
    records_to_update = []
    for record in all_records:
        record["last_accessed"] = now
        record["access_count"] = record["access_count"] + 1

        # Ensure proper serialization
        if isinstance(record.get("metadata"), dict):
            record["metadata"] = json.dumps(record["metadata"])
        if isinstance(record.get("vector"), np.ndarray):
            record["vector"] = record["vector"].tolist()

        records_to_update.append(record)

    # Atomic batch upsert
    (
        self.table.merge_insert("id")
        .when_matched_update_all()
        .when_not_matched_insert_all()
        .execute(records_to_update)
    )

    return len(records_to_update)
```

**Impact:** 10-50x faster for batch access updates

---

### 6.2 Add Embedding Cache

**File:** `spatial_memory/core/embeddings.py`

```python
import hashlib
from collections import OrderedDict

class EmbeddingService:
    def __init__(self, ...):
        # ... existing init ...

        # Embedding cache (LRU with max size)
        self._embed_cache: OrderedDict[str, np.ndarray] = OrderedDict()
        self._cache_max_size = 1000
        self._cache_lock = threading.Lock()

    def _get_cache_key(self, text: str) -> str:
        """Generate cache key from text content."""
        return hashlib.md5(text.encode()).hexdigest()

    def embed(self, text: str) -> np.ndarray:
        """Embed text with caching."""
        cache_key = self._get_cache_key(text)

        # Check cache (thread-safe)
        with self._cache_lock:
            if cache_key in self._embed_cache:
                # Move to end (most recently used)
                self._embed_cache.move_to_end(cache_key)
                return self._embed_cache[cache_key].copy()

        # Generate embedding
        if self.use_openai:
            result = self._embed_openai([text])[0]
        else:
            result = self._embed_local([text])[0]

        # Cache result (thread-safe)
        with self._cache_lock:
            # LRU eviction
            while len(self._embed_cache) >= self._cache_max_size:
                self._embed_cache.popitem(last=False)

            self._embed_cache[cache_key] = result.copy()

        return result

    def clear_cache(self) -> int:
        """Clear embedding cache. Returns number of entries cleared."""
        with self._cache_lock:
            count = len(self._embed_cache)
            self._embed_cache.clear()
            return count
```

**Impact:** 50%+ savings in consolidation/deduplication scenarios

---

### 6.3 Streaming Parquet Export

**File:** `spatial_memory/services/export_import.py`

```python
def _export_parquet(
    self,
    path: Path,
    batches: Iterator[list[dict[str, Any]]],
    include_vectors: bool,
) -> int:
    """Export to Parquet using streaming writer."""
    import pyarrow.parquet as pq

    schema = self._create_parquet_schema(include_vectors)
    count = 0
    writer = None

    try:
        for batch in batches:
            if not batch:
                continue

            # Process batch records
            processed_records = []
            for record in batch:
                processed = self._prepare_record_for_export(record, include_vectors)
                if "metadata" in processed and isinstance(processed["metadata"], dict):
                    processed["metadata"] = json.dumps(processed["metadata"])
                processed_records.append(processed)

            # Create Arrow table from batch
            table = pa.Table.from_pylist(processed_records, schema=schema)

            # Initialize writer on first batch (gets schema from data)
            if writer is None:
                writer = pq.ParquetWriter(
                    path,
                    schema=table.schema,
                    compression=self._config.parquet_compression
                )

            # Write batch to file
            writer.write_table(table)
            count += len(processed_records)

        # Handle empty export
        if writer is None:
            # Write empty file with schema
            empty_table = pa.Table.from_pydict(
                {f.name: [] for f in schema},
                schema=schema
            )
            pq.write_table(empty_table, path, compression=self._config.parquet_compression)

    finally:
        if writer is not None:
            writer.close()

    return count

def _create_parquet_schema(self, include_vectors: bool) -> pa.Schema:
    """Create Arrow schema for Parquet export."""
    fields = [
        pa.field("id", pa.string()),
        pa.field("content", pa.string()),
        pa.field("namespace", pa.string()),
        pa.field("tags", pa.list_(pa.string())),
        pa.field("importance", pa.float32()),
        pa.field("source", pa.string()),
        pa.field("metadata", pa.string()),
        pa.field("created_at", pa.timestamp("us")),
        pa.field("updated_at", pa.timestamp("us")),
        pa.field("last_accessed", pa.timestamp("us")),
        pa.field("access_count", pa.int32()),
    ]

    if include_vectors:
        fields.append(pa.field("vector", pa.list_(pa.float32())))

    return pa.schema(fields)
```

**Impact:** Enables export of datasets larger than RAM

---

## Phase 7: Add Vector Projection (1-2 hours)

### 7.1 Exclude Vector Column When Not Needed

**File:** `spatial_memory/core/database.py`
**Method:** `vector_search()` and related methods

```python
def vector_search(
    self,
    query_vector: np.ndarray,
    limit: int = 10,
    namespace: str | None = None,
    min_similarity: float = 0.0,
    include_vector: bool = False,  # NEW PARAMETER
) -> list[dict[str, Any]]:
    # ... existing code ...

    # Add projection to exclude vector if not needed
    if not include_vector:
        search = search.select([
            "id", "content", "namespace", "metadata",
            "created_at", "updated_at", "last_accessed",
            "importance", "tags", "source", "access_count"
        ])

    # ... rest of method
```

**Update callers that need vectors:**
- `_get_vectors_for_journey()` - needs vectors
- `nearby()` - needs vectors
- Regular `recall` - doesn't need vectors

**Impact:** Reduced memory usage and faster queries

---

## Implementation Order (Recommended)

| Phase | Effort | Risk | Dependencies |
|-------|--------|------|--------------|
| Phase 1: Quick Wins | 1-2 hours | Very Low | None |
| Phase 2: Error Refactor | 2-3 hours | Low | None |
| Phase 3: Rate Limiting | 1-2 hours | Low | Phase 1.4 |
| Phase 4: Move TOOLS | 1 hour | Very Low | None |
| Phase 5: Dispatch Pattern | 4-6 hours | Medium | Phase 2, 4 |
| Phase 6: Performance | 3-4 hours | Medium | None |
| Phase 7: Vector Projection | 1-2 hours | Low | None |

**Total Estimated Effort:** 13-20 hours

---

## Verification Checklist

After each phase:
- [ ] Run unit tests: `pytest tests/unit/ -v`
- [ ] Run integration tests: `pytest tests/integration/ -v`
- [ ] Check for type errors: `mypy spatial_memory/`
- [ ] Check for lint issues: `ruff check spatial_memory/`

Final verification:
- [ ] All 1,184+ tests pass
- [ ] No new type errors
- [ ] Performance benchmarks show improvement
- [ ] Memory profiling confirms streaming export works

---

## Files Modified Summary

| File | Phases | Changes |
|------|--------|---------|
| `spatial_memory/core/database.py` | 1, 6, 7 | Indexes, N+1 fix, prefilter, projection |
| `spatial_memory/core/embeddings.py` | 6 | Embedding cache |
| `spatial_memory/server.py` | 2, 3, 4, 5 | Error helper, rate limiting, dispatch pattern |
| `spatial_memory/services/export_import.py` | 1, 6 | Remove deprecated, streaming export |
| `spatial_memory/core/__init__.py` | 1 | Export RateLimiter |
| `spatial_memory/tools/` | 4 | New module for TOOLS constant |
