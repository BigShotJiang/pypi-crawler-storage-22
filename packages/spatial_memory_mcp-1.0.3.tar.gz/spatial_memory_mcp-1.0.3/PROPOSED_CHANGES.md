# Proposed Changes for spatial-memory-mcp

**Review Date:** 2026-02-01
**Reviewers:** 5 Specialized Agents (Code Quality, Performance, Security, Technical Debt, Database)
**Overall Health:** Good (Technical Debt Score: 3/10)

---

## Executive Summary

Comprehensive review identified **25+ actionable items** across 5 categories. The codebase demonstrates strong engineering practices with Clean Architecture, 1,137 tests, and enterprise-grade features. Key areas for improvement: code organization, performance optimization, and security hardening.

---

## Priority 1: High (Should Fix Soon)

### 1.1 Code Cleanup

#### Refactor server.py (1,600+ lines)

**Problem:** The `_handle_tool_impl` method is 567 lines with repetitive if/elif chains.

**Location:** `spatial_memory/server.py:1028-1578`

**Solution:** Implement dispatch pattern:

```python
# Before: 567-line if/elif chain
async def _handle_tool_impl(self, name: str, arguments: dict) -> dict:
    if name == "remember":
        # 30 lines of handling
    elif name == "recall":
        # 30 lines of handling
    # ... 20+ more tools

# After: Clean dispatch
class SpatialMemoryServer:
    def __init__(self, ...):
        self._tool_handlers = {
            "remember": self._handle_remember,
            "recall": self._handle_recall,
            # ... register all handlers
        }

    async def _handle_tool_impl(self, name: str, arguments: dict) -> dict:
        handler = self._tool_handlers.get(name)
        if handler is None:
            raise ValidationError(f"Unknown tool: {name}")
        return await handler(arguments)

    async def _handle_remember(self, args: dict) -> dict:
        # Single tool handling
        ...
```

**Effort:** Medium (4-6 hours)
**Impact:** High - Maintainability, testability

---

#### Extract Error Response Helper

**Problem:** 12+ identical exception handling blocks in `call_tool`.

**Location:** `spatial_memory/server.py:899-1009`

**Solution:**

```python
# Before: Repeated 12+ times
except MemoryNotFoundError as e:
    return [TextContent(
        type="text",
        text=json.dumps({"error": "MemoryNotFound", "message": str(e), "isError": True}),
    )]

# After: Single helper
ERROR_MAPPINGS = {
    MemoryNotFoundError: "MemoryNotFound",
    ValidationError: "ValidationError",
    DecayError: "DecayError",
    # ... all mappings
}

def _create_error_response(self, error: Exception) -> list[TextContent]:
    error_name = ERROR_MAPPINGS.get(type(error), "UnknownError")
    return [TextContent(
        type="text",
        text=json.dumps({"error": error_name, "message": str(error), "isError": True}),
    )]
```

**Effort:** Low (1-2 hours)
**Impact:** Medium - Code quality, DRY principle

---

#### Move TOOLS Constant to Separate Module

**Problem:** 661-line `TOOLS` constant clutters server.py.

**Location:** `spatial_memory/server.py:66-727`

**Solution:**
```
spatial_memory/
├── server.py              # Main server logic
└── tools/
    ├── __init__.py
    └── definitions.py     # TOOLS constant moved here
```

**Effort:** Low (1 hour)
**Impact:** Low - Code organization

---

### 1.2 Performance Optimizations

#### Fix N+1 Query in update_access_batch

**Problem:** Fetches each record individually in a loop.

**Location:** `spatial_memory/core/database.py:1870-1920`

**Solution:**

```python
# Before: N+1 queries
for memory_id in memory_ids:
    results = self.table.search().where(f"id = '{safe_id}'").limit(1).to_list()
    # Process individually

# After: Single batch query
id_list = ", ".join(f"'{_sanitize_string(mid)}'" for mid in memory_ids)
all_records = self.table.search().where(f"id IN ({id_list})").to_list()
records_by_id = {r["id"]: r for r in all_records}
# Process all at once, single merge_insert
```

**Effort:** Medium (2-3 hours)
**Impact:** High - 10-50x faster for batch access updates

---

#### Add Embedding Cache

**Problem:** Same content embedded multiple times (common in consolidation).

**Location:** `spatial_memory/core/embeddings.py`

**Solution:**

```python
from functools import lru_cache
import hashlib

class EmbeddingService:
    def __init__(self, ...):
        self._embed_cache: dict[str, np.ndarray] = {}
        self._cache_max_size = 1000

    def embed(self, text: str) -> np.ndarray:
        # Hash-based cache lookup
        content_hash = hashlib.md5(text.encode()).hexdigest()

        if content_hash in self._embed_cache:
            return self._embed_cache[content_hash].copy()

        # Generate embedding
        if self.use_openai:
            result = self._embed_openai([text])[0]
        else:
            result = self._embed_local([text])[0]

        # Cache with LRU eviction
        if len(self._embed_cache) >= self._cache_max_size:
            # Remove oldest entry
            oldest = next(iter(self._embed_cache))
            del self._embed_cache[oldest]

        self._embed_cache[content_hash] = result
        return result.copy()
```

**Effort:** Medium (2-3 hours)
**Impact:** High - 50%+ savings in consolidation/deduplication

---

#### Implement Namespace Cache in get_namespaces()

**Problem:** Cache exists but `get_namespaces()` doesn't use it.

**Location:** `spatial_memory/core/database.py`

**Solution:**

```python
def get_namespaces(self) -> list[str]:
    now = time.time()

    # Fast path: check cache without lock
    if (
        self._cached_namespaces is not None
        and (now - self._namespace_cache_time) < self._NAMESPACE_CACHE_TTL
    ):
        return list(self._cached_namespaces)

    # Fetch fresh data
    results = self.table.search().select(["namespace"]).to_list()
    namespaces = sorted(set(r["namespace"] for r in results))

    # Update cache with lock
    with self._namespace_cache_lock:
        self._cached_namespaces = set(namespaces)
        self._namespace_cache_time = now

    return namespaces
```

**Effort:** Low (1 hour)
**Impact:** High - Eliminates repeated namespace queries

---

#### Use Streaming Parquet Export

**Problem:** Loads all records into memory before writing.

**Location:** `spatial_memory/services/export_import.py:507-570`

**Solution:**

```python
import pyarrow.parquet as pq

def _export_parquet(self, path: Path, namespace: str | None, ...) -> int:
    batches = self._repo.get_all_for_export(namespace=namespace)

    # Get schema from first batch
    first_batch = next(batches, None)
    if first_batch is None:
        return 0

    schema = self._create_arrow_schema()
    count = 0

    # Stream to Parquet writer
    with pq.ParquetWriter(path, schema, compression='zstd') as writer:
        # Write first batch
        table = pa.Table.from_pylist([self._process_record(r) for r in first_batch])
        writer.write_table(table)
        count += len(first_batch)

        # Write remaining batches
        for batch in batches:
            table = pa.Table.from_pylist([self._process_record(r) for r in batch])
            writer.write_table(table)
            count += len(batch)

    return count
```

**Effort:** Medium (3-4 hours)
**Impact:** High - Enables export of datasets larger than RAM

---

### 1.3 Database Optimizations

#### Add expires_at BTREE Index

**Problem:** TTL cleanup does full table scan.

**Location:** `spatial_memory/core/database.py:843-903`

**Solution:**

```python
def create_scalar_indexes(self) -> None:
    btree_columns = [
        "id",
        "created_at",
        "updated_at",
        "last_accessed",
        "importance",
        "access_count",
        "expires_at",  # ADD THIS LINE
    ]
    # ... rest of method
```

**Effort:** Minimal (1 line change)
**Impact:** Medium - Faster TTL cleanup

---

#### Use Prefilter for Namespace in Vector Search

**Problem:** Postfilter after ANN search fetches unnecessary vectors.

**Location:** `spatial_memory/core/database.py:2059`

**Solution:**

```python
# Before
search = search.where(f"namespace = '{safe_ns}'")

# After: Use prefilter for selective namespaces
search = search.where(f"namespace = '{safe_ns}'", prefilter=True)
```

**Effort:** Minimal (add parameter)
**Impact:** High - Significantly faster for selective filters

---

#### Add Projection to Exclude Vector Column

**Problem:** Fetches 384-float vector even when not needed.

**Location:** `spatial_memory/core/database.py:2063`

**Solution:**

```python
def vector_search(
    self,
    query_vector: np.ndarray,
    ...,
    include_vector: bool = False,  # New parameter
) -> list[dict[str, Any]]:
    # ...

    if not include_vector:
        search = search.select([
            "id", "content", "namespace", "metadata",
            "created_at", "updated_at", "importance", "tags"
        ])
```

**Effort:** Low (1-2 hours)
**Impact:** Medium - Reduced memory usage

---

### 1.4 Security Fixes

#### Apply Rate Limiting to Tool Handlers

**Problem:** RateLimiter exists but not applied.

**Location:** `spatial_memory/server.py`

**Solution:**

```python
from spatial_memory.core.rate_limiter import RateLimiter

class SpatialMemoryServer:
    def __init__(self, ...):
        self._rate_limiter = RateLimiter(
            requests_per_second=self._settings.embedding_rate_limit
        )

    async def _handle_tool(self, name: str, arguments: dict) -> list[TextContent]:
        # Apply rate limiting
        await self._rate_limiter.acquire()

        try:
            result = await self._handle_tool_impl(name, arguments)
            return [TextContent(type="text", text=json.dumps(result, default=str))]
        except Exception as e:
            return self._create_error_response(e)
```

**Effort:** Low (1-2 hours)
**Impact:** High - Prevents resource exhaustion

---

#### Remove Deprecated TOCTOU-Vulnerable Methods

**Problem:** Old methods could be accidentally used.

**Location:** `spatial_memory/services/export_import.py:827-961`

**Action:** Delete the following methods:
- `_parse_parquet()` (lines 827-867)
- `_parse_json()` (lines 869-909)
- `_parse_csv()` (lines 911-961)

**Effort:** Minimal (delete ~130 lines)
**Impact:** Medium - Removes security risk

---

## Priority 2: Medium (Next Release)

### 2.1 Code Quality

| Item | Location | Effort |
|------|----------|--------|
| ~~Replace `datetime.utcnow()`~~ | ~~lifecycle.py:221~~ | ~~Low~~ | **DONE** |
| Address `# type: ignore` comments | server.py:760, embeddings.py:148,275 | Low |
| Consolidate JSON metadata to use `helpers.py` | database.py, export_import.py (11 locations) | Medium |
| Split database.py into focused modules | database.py (2,825 lines) | High |

### 2.2 Performance

| Item | Location | Impact |
|------|----------|--------|
| Use `pyarrow.compute.value_counts()` for namespace counting | database.py:1570-1616 | Medium |
| Add module-level thread pool for batch_vector_search | database.py:2199-2270 | Medium |
| Use `orjson` for faster JSON serialization | Multiple files | Medium |
| Batch duplicate checking in imports | export_import.py:1062-1103 | Medium |

### 2.3 Database

| Item | Location | Impact |
|------|----------|--------|
| Lower vector index threshold (10K → 5K) | config.py:117-119 | Medium |
| Add auto-compaction after large batch inserts | database.py | Medium |
| Batch delete operations into chunks of 500 | database.py:1852-1853 | Medium |

---

## Priority 3: Low (Backlog)

- Remove `_SettingsProxy` class, encourage `get_settings()` usage
- Add `atexit` handler for connection cleanup
- Reduce default connection pool size (10 → 3-5)
- Improve test cleanup exception handling
- Document security configuration best practices more prominently

---

## Quick Wins Checklist

- [ ] Add `expires_at` to BTREE indexes (1 line)
- [ ] Add `.select()` projection to exclude vector (2 lines)
- [ ] Register `atexit` handler for connection cleanup (3 lines)
- [ ] Remove deprecated `_parse_*` methods (delete ~130 lines)
- [ ] Add `prefilter=True` to namespace filters (1 parameter)

---

## Files to Modify

| File | Changes | Priority |
|------|---------|----------|
| `spatial_memory/server.py` | Dispatch pattern, error helper, rate limiting | High |
| `spatial_memory/core/database.py` | N+1 fix, indexes, prefilter, projection | High |
| `spatial_memory/core/embeddings.py` | Embedding cache | High |
| `spatial_memory/services/export_import.py` | Streaming export, remove deprecated | High |
| `spatial_memory/config.py` | Lower thresholds | Medium |
| `spatial_memory/services/lifecycle.py` | datetime fix | Medium |

---

## Verification Plan

After implementing changes:

1. **Run full test suite:** `pytest tests/ -v`
2. **Run concurrent write test:** `pytest tests/integration/test_concurrent_writes.py -v`
3. **Verify no regressions:** All 1,137 tests should pass
4. **Performance benchmark:** Compare before/after for key operations
5. **Memory profiling:** Verify export doesn't exceed expected memory

---

## Appendix: Positive Findings (No Changes Needed)

The following areas are well-implemented:

- **Clean Architecture** - Proper separation of ports, adapters, services, core
- **Thread Safety** - RLock for writes, proper connection pooling
- **SQL Injection Prevention** - Comprehensive pattern matching
- **TOCTOU Protection** - Safe file operations (new methods)
- **Test Coverage** - 1,137 tests with excellent edge case coverage
- **ONNX Backend** - 2.75x faster embedding inference
- **Error Hierarchy** - 20+ specific exception types
- **Stale Connection Recovery** - Auto-reconnect mechanism
