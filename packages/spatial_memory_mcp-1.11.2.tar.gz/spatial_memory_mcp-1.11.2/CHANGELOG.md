# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Medium severity architectural improvements (MED-ARCH-001 through MED-ARCH-004)
- Migration system (MED-DB-005)

## [1.10.1] - 2026-02-09

### Fixed
- **Tilde expansion in memory_path**: Added `field_validator` to `Settings.memory_path` so `~` is expanded to the user's home directory.
- **Queue writer default path**: `get_queue_dir()` now uses project-relative `.spatial-memory` default (matching server config) instead of `~/.spatial-memory`, and expands `~` when `SPATIAL_MEMORY_MEMORY_PATH` is set.

### Changed
- **README.md**: Condensed and restructured with plugin-first quick start, cognitive offloading docs, multi-client setup, and streamlined tool/config reference.
- **CHANGELOG.md**: Backfilled historical release entries (v1.0.0 through v1.5.4).

## [1.10.0] - 2026-02-09

### Added
- **Cognitive offloading hook scripts**: Automatic memory capture via Claude Code hooks. PostToolUse captures decisions/errors during tool use, PreCompact and Stop capture transcript text at session boundaries.
- **Multi-client support**: Strategy pattern for 5 AI coding clients (Claude Code, Cursor, Windsurf, Antigravity, VS Code Copilot) with 3-tier architecture.
- **Plugin packaging**: Zero-config Claude Code plugin with hooks and MCP server config.
- **`setup_hooks` MCP tool and CLI**: Generates client-specific hook configuration (`python -m spatial_memory setup-hooks --client <name>`).
- **SessionStart hook**: Recall nudge at session start (installed via settings, not plugin — see Known Issues).
- **Cursor adapter**: Translates Cursor hook format to Claude Code format for cross-client compatibility.
- **Queue-based memory pipeline**: Maildir-style atomic queue for hook-to-server memory delivery.

### Changed
- **Signal detection**: Pattern-based classification into 3 tiers (decisions/errors, patterns/config, no signal).
- **Secret redaction**: Single-pass `subn()` for passwords, API keys, tokens, private keys with fail-open behavior.
- **Lazy module loading**: PostToolUse hook loads sibling modules only for non-skipped tools.

### Fixed
- **Redaction double-pass**: Replaced `findall()` + `sub()` with single-pass `subn()` (H-1).
- **Password-in-URL pattern**: Preserves URL structure using capturing groups (H-2).
- **Pipeline type safety**: Added `WriteQueueFileProtocol` for strict callable typing (M-5).
- **Response type docstring**: Corrected handler count 22 to 23 (M-9).

### Known Issues
- **Windows**: Plugin SessionStart hooks freeze terminal input in Claude Code v2.1.37. Workaround: install SessionStart via `.claude/settings.json` using `setup-hooks` CLI.

## [1.9.3] - 2026-02-05

### Changed
- **Tiered auto-save instructions**: Rewrote MCP server instructions with a 3-tier memory save system. Tier 1 (decisions, fixes, errors, architecture) auto-saves with a `> Memorized:` notification. Tier 2 (patterns, preferences, config, workarounds) asks first. Tier 3 (trivial/duplicate/speculative) never saves. Includes dedup guidance to check `recall` before saving.

## [1.9.2] - 2026-02-02

### Fixed
- **Clamped similarity values to valid range**: `SpatialService._process_batch_results()` now clamps similarity scores to [0.0, 1.0] range to ensure values are always within expected bounds, preventing potential issues with out-of-range similarity scores from vector search results.

## [1.9.1] - 2026-02-02

### Fixed
- **Removed undeclared pandas dependency**: `batch_vector_search_native` in `db_search.py` was using `to_pandas()` which required pandas (not declared in dependencies). Refactored to use Arrow operations (`to_arrow().to_pylist()`) consistent with the rest of the codebase.
  - Fixes "No module named 'pandas'" error when using `journey` tool
  - Improves performance by avoiding DataFrame conversion overhead
  - Reduces dependency footprint (pandas is ~50MB)

## [1.9.0] - 2026-02-02

### Breaking Changes
- **Stricter Namespace Validation**: Namespaces now follow DNS label conventions
  - Must start with a letter (a-z, A-Z)
  - Can only contain letters, numbers, dashes, and underscores
  - Maximum 63 characters (was 256)
  - **Dots no longer allowed** - use underscores instead (e.g., `ns_v1` not `ns.v1`)
  - **Numeric start no longer allowed** - must start with letter

### Added
- **Getting Started Tutorial**: New `docs/GETTING_STARTED.md` with step-by-step guide
- **Dependency Lock File**: `requirements.lock` with 79 pinned packages for reproducible builds
- **PyPI Metadata**: Added Documentation, Changelog, and Bug Tracker URLs to pyproject.toml

### Changed
- **Consolidated Namespace Validation**: Single canonical pattern across all modules
  - `validation.py` now exports `NAMESPACE_PATTERN` used by `import_security.py`
  - Consistent error messages with clear format requirements
- **mypy Configuration**: Replaced outdated `stubs/` directory with module overrides
  - External libraries (lancedb, pyarrow, hdbscan, etc.) now use `ignore_missing_imports`
  - All 49 source files pass strict mypy checks

### Fixed
- Resolved mypy configuration issue where deleted `stubs/` directory was still referenced

## [1.8.0] - 2026-02-02

### Added
- **Unified Decay System**: Auto-decay and manual decay now use the same algorithm
  - New `SPATIAL_MEMORY_AUTO_DECAY_FUNCTION` config option to choose decay function
  - Supported functions: `exponential` (default), `linear`, `step`
  - Consistent behavior regardless of code path (auto-decay vs manual `decay` tool)
  - Adaptive half-life based on access count and importance
- New `decay_function` field in `AutoDecayConfig` model

### Changed
- `DecayManager` now uses `calculate_decay_factor()` from `lifecycle_ops.py` instead of a separate implementation
- Auto-decay effective half-life now considers both access count (1.5× per access) and importance factor (1 + importance)

### Fixed
- **Type Safety**: Resolved all mypy errors in main source code (49 source files)
  - Added proper type annotations for numpy operations returning `Any`
  - Fixed protocol type assignments in factory.py
  - Added `__all__` exports to service modules
  - Fixed type narrowing issues with optional database connections
- **Code Quality**: Resolved all ruff linting errors in test files (45 issues)
  - Fixed import ordering (E402) by moving `pytestmark` after imports
  - Removed unused variable assignments (F841)
  - Fixed lines exceeding 100 characters (E501)

### Documentation
- Updated `docs/CONFIGURATION.md` with `SPATIAL_MEMORY_AUTO_DECAY_FUNCTION` option
- Updated `.env.example` with decay function configuration examples

## [1.7.0] - 2026-02-02

### Added
- **Auto-Decay Feature**: Automatic time-based importance decay during recall operations
  - Memories automatically lose importance over time if not accessed (exponential decay)
  - `effective_importance` field added to `recall` and `hybrid_recall` responses
  - Results re-ranked by `similarity × effective_importance` to favor recent memories
  - Background persistence thread batches and saves decay updates to database
  - Configurable via environment variables:
    - `SPATIAL_MEMORY_AUTO_DECAY_ENABLED` (default: true)
    - `SPATIAL_MEMORY_AUTO_DECAY_PERSIST_ENABLED` (default: true)
    - `SPATIAL_MEMORY_AUTO_DECAY_PERSIST_BATCH_SIZE` (default: 100)
    - `SPATIAL_MEMORY_AUTO_DECAY_PERSIST_FLUSH_INTERVAL_SECONDS` (default: 5.0)
    - `SPATIAL_MEMORY_AUTO_DECAY_MIN_CHANGE_THRESHOLD` (default: 0.01)
    - `SPATIAL_MEMORY_AUTO_DECAY_MAX_QUEUE_SIZE` (default: 10000)
  - Access count slows decay: frequently accessed memories stay relevant longer
  - Minimum importance floor prevents memories from decaying to zero
- Configuration documentation (`docs/CONFIGURATION.md`)
  - Complete reference for all environment variables
  - Examples for `.mcp.json`, Claude Desktop, and `.env` files
  - Auto-decay configuration guide
- Test script for verifying auto-decay (`scripts/test_auto_decay.py`)

### Changed
- `MemoryResultDict` and `HybridMemoryDict` response types now include optional `effective_importance` field
- `MemoryResult` and `HybridMemoryMatch` models now include `last_accessed` and `access_count` fields

## [1.6.2] - 2026-02-02

### Added
- Technical highlights documentation (`docs/TECHNICAL_HIGHLIGHTS.md`) with Mermaid diagrams
  - Cognitive memory model vs traditional storage
  - SLERP algorithm for journey tool
  - Temperature-based random walks for wander tool
  - HDBSCAN clustering for regions tool
  - UMAP projection for visualize tool
  - ONNX Runtime optimization
  - scipy integration for efficient similarity calculations

### Fixed
- Fixed 46 ruff linting errors across codebase
  - Import sorting and formatting
  - Lines exceeding 100 characters
  - Unused variables and imports
  - Import ordering issues

## [1.6.1] - 2026-02-02

### Added
- `spatial-memory instructions` CLI command to view the MCP instructions injected into Claude's context

### Changed
- Updated CLAUDE.md to be contributor documentation (removed stale claude-memory references)

## [1.6.0] - 2026-02-02

### Fixed

#### Critical Issues
- **CRIT-001**: Fixed consolidation data loss window - implemented add-before-delete pattern with pending status marker
- **CRIT-002**: Fixed journey N+1 query pattern - plumbed `include_vector` parameter through search pipeline

#### High Severity Issues
- **HIGH-001**: Fixed sequential DB calls in wander (resolved via CRIT-002)
- **HIGH-002**: Fixed O(n²) similarity calculation in visualize - replaced with `scipy.spatial.distance.cdist` vectorized operation
- **HIGH-003**: Fixed inefficient batch search - implemented native LanceDB batch search
- **HIGH-004**: Fixed duplicate embedding generation in extract - batch embed upfront with `embed_batch()`
- **HIGH-005**: Fixed sequential updates in decay - added `update_batch()` method
- **HIGH-006**: Fixed sequential fetches in reinforce - added `get_batch()` method
- **HIGH-007**: Fixed non-atomic batch insert - added `PartialBatchInsertError` with rollback capability
- **HIGH-008**: Fixed rename_namespace lacking rollback - track renamed IDs with `_rollback_namespace_rename()`
- **HIGH-009**: Fixed consolidation loading entire namespace - added streaming `_consolidate_chunked()`
- **HIGH-010**: Fixed file lock on NFS/SMB - added detection and startup warning

#### Medium Severity Issues
- **MED-SEC-002**: Fixed memory exhaustion in JSON/CSV export - implemented streaming export
- **MED-CQ-001**: Fixed `forget_batch` returning incorrect IDs
- **MED-CQ-002**: Added missing `backend` to `EmbeddingServiceProtocol`
- **MED-CQ-003**: Fixed rate limiter token consumption issue
- **MED-CQ-004**: Fixed embedding cache leak in batch operations
- **MED-DB-001**: Added missing index to idempotency table
- **MED-DB-003**: Fixed `get_namespace_stats()` loading all records
- **MED-DB-004**: Added vector dimension validation at insert

#### Low Severity Issues
- **LOW-001**: Made embedding cache size configurable (was hardcoded 1000)
- **LOW-002**: Standardized datetime handling in lifecycle.py
- **LOW-003**: Extracted magic numbers in retry logic to constants
- **LOW-004**: Added Literal type validation for `index_type`
- **LOW-006**: Fixed `validate_namespace` docstring mismatch
- **LOW-007**: Normalized mock embedding vectors in conftest.py
- **LOW-008**: Documented content validation security approach
- **LOW-009**: Added metadata depth validation
- **LOW-010**: Sanitized paths in error messages
- **LOW-011**: Added proactive connection health check
- **LOW-012**: Fixed `close()` to remove from connection pool
- **LOW-013**: Implemented auto-compaction scheduling
- **LOW-014**: Cached stop words set (was recreated per call)
- **LOW-015**: Improved cache key hashing

### Added
- `get_batch()` method for bulk memory retrieval
- `update_batch()` method returning `(success_count, failed_ids)` tuple
- Native LanceDB batch vector search
- `PartialBatchInsertError` exception with `succeeded_ids` for recovery
- `atomic=True` parameter to `insert_batch()` with rollback capability
- Streaming consolidation with configurable `consolidate_chunk_size`
- NFS/SMB filesystem detection in `core/filesystem.py`
- Config option `acknowledge_network_filesystem_risk` to suppress warnings

### Changed
- Refactored `database.py` into separate manager modules for maintainability
- Improved type safety across async operations

### Closed (By Design)
- **MED-SEC-001**: No namespace-level authorization - single-developer local use is intended
- **MED-DB-002**: `get_namespaces()` loads all values - TTL caching is sufficient
- **LOW-005**: Duplicate local imports - intentional circular import avoidance

## [1.5.4] - 2026-02-01

### Fixed

#### Critical Issues
- **CRIT-001**: Fixed consolidation data loss window — implemented add-before-delete pattern with pending status marker to preserve originals if delete fails
- **CRIT-002**: Fixed journey N+1 query pattern — plumbed `include_vector` parameter through search pipeline, eliminating 30+ extra DB calls for a 10-step journey

#### High Severity Issues
- **HIGH-001**: Fixed wander sequential DB calls (resolved via CRIT-002 `include_vector` pattern)
- **HIGH-010**: Added NFS/SMB filesystem detection with `acknowledge_network_filesystem_risk` config option and startup warning

### Added
- `core/filesystem.py` with network filesystem detection utilities
- Retry logic with exponential backoff in `_ensure_table()`

## [1.5.3] - 2026-02-01

### Added
- **MCP server instructions**: Auto-injected behavioral guidelines for AI clients via `_get_server_instructions()`
- **Request tracing**: `request_id` and `_agent_id` tracking on all 22 tool calls
- **Response caching**: LRU cache for read-only operations (`recall`, `nearby`, `hybrid_recall`, `regions`)
- **Per-agent rate limiting**: Configurable per-agent and global rate limits with token bucket algorithm
- **Circuit breaker pattern**: Resilient external service calls with automatic fallback and recovery

## [1.0.3] - 2026-02-01

### Added
- Version field (`__version__`) in health endpoint response
- Synced `__init__.py` version with `pyproject.toml`

## [1.0.2] - 2026-02-01

### Added
- **Cross-process filelock**: `ProcessLockManager` with reentrant file locking for multi-process safety
- **Handler registry pattern**: Refactored `server.py` with dispatch registry for 22 tool handlers
- **Embedding cache**: Thread-safe LRU eviction cache for repeated embedding lookups
- **Streaming Parquet export**: PyArrow `ParquetWriter` for memory-efficient exports
- **RateLimiter integration**: Token bucket algorithm for API resource protection
- `expires_at` BTREE index for faster TTL queries
- `prefilter=True` on namespace filter for faster vector search

### Changed
- Moved `TOOLS` constant to `spatial_memory/tools/` module

### Fixed
- N+1 query in `update_access_batch` — replaced with batch IN clause
- Removed deprecated TOCTOU-vulnerable parse methods

## [1.0.0] - 2026-01-31

### Added

#### Phase 2: Core Operations
- MCP server with 6 core tools: `remember`, `remember_batch`, `recall`, `nearby`, `forget`, `forget_batch`
- Clean Architecture with ports/adapters pattern and dependency injection
- `MemoryService` business logic layer with `LanceDBRepository` adapter
- 25 unit tests + 15 integration tests

#### Phase 3: Enterprise Features & Observability
- Thread-safe `ConnectionPool` with LRU eviction and max size limits
- TTL support with `expires_at` field and `cleanup_expired_memories()`
- Snapshot management: create, restore, list snapshots
- Dynamic search parameter tuning with HNSW index support alongside IVF-PQ
- Health check infrastructure (liveness/readiness probes)
- Optional Prometheus metrics with graceful degradation
- Secure structured logging with API key masking
- Graceful shutdown with signal handlers (SIGTERM/SIGINT)

#### Phase 4A: Critical Fixes & Technical Debt
- Dynamic retry with `_with_retry()` instance method (replaces static decorator)
- Atomic updates via LanceDB `merge_insert` (eliminates race conditions)
- Centralized `validation.py`: UUID, namespace, content, importance, tags, metadata validation
- SQL injection prevention with `sanitize_string()`
- Helper module for serialization/deserialization utilities

#### Phase 4B: Spatial Operations
- `journey`: SLERP interpolation between memories for semantic path discovery
- `wander`: Temperature-based random walk for neighborhood exploration
- `regions`: HDBSCAN clustering for semantic memory regions
- `visualize`: UMAP projection for 2D/3D visualization (JSON/Mermaid/SVG output)
- Core algorithms in `spatial_ops.py`: normalize, slerp, softmax_with_temperature

#### Lifecycle Phase
- `decay`: Time/access-based importance decay (exponential, linear, step functions)
- `reinforce`: Importance boosting (additive, multiplicative, set_value)
- `extract`: Auto-extract memories from text with confidence scoring and deduplication
- `consolidate`: Merge duplicate memories using Union-Find algorithm (4 strategies)

#### Phase 5: Utilities & Admin
- `stats`, `namespaces`, `export_memories`, `import_memories`, `hybrid_recall` tools
- File security validators for export/import path validation
- Streaming export/import for large datasets

#### Infrastructure
- ONNX Runtime as default embedding backend (2.75x faster: 1,218 vs 443 texts/sec)
- Cross-platform installation verification
- 24 code review findings fixed (security, error handling, test coverage)

### Fixed
- Journey response size reduced from 84KB to ~3KB (removed position vectors from output)
- Wander empty query validation (uses generic query for random start)
- Journey float precision errors (cosine distance clamping)
- Decay timezone handling (naive UTC datetime normalization)
- Rename namespace infinite loop when old == new
- Hybrid search score column handling (`_score`, `_relevance_score`)

## [0.1.0] - 2026-01-20

### Added

#### Configuration System
- Pydantic-based settings with environment variable support
- Dependency injection pattern for testability
- Full configuration validation with bounds checking
- Support for `.env` files

#### Database Layer
- LanceDB integration for vector storage
- SQL injection prevention with pattern detection
- UUID validation for memory IDs
- Namespace format validation
- Atomic updates with rollback support

#### Embedding Service
- Local embedding support via sentence-transformers
- OpenAI API embedding support
- Dual-backend architecture with automatic routing
- Model: `all-MiniLM-L6-v2` (384 dimensions) as default

#### Data Models
- `Memory` - Core memory representation
- `MemoryResult` - Search result with similarity score
- `Filter` / `FilterGroup` - Query filtering system
- `ClusterInfo` - Cluster metadata for regions
- `JourneyStep` - Step in journey interpolation
- `VisualizationData` - Visualization output format

#### Error Handling
- Custom exception hierarchy
- `SpatialMemoryError` base class
- Specific errors: `MemoryNotFoundError`, `NamespaceNotFoundError`, `EmbeddingError`, `StorageError`, `ValidationError`, `ConfigurationError`, `ClusteringError`, `VisualizationError`

#### Testing
- 71 unit tests covering all Phase 1 components
- Pytest fixtures for isolated testing
- Mock embedding service for fast tests

#### Documentation
- README with project overview and roadmap
- Architecture diagrams (Mermaid)
- Security documentation
- Contributing guidelines
- Configuration reference (`.env.example`)

### Security
- Input validation on all user-provided data
- SQL injection prevention
- Namespace isolation
- Sanitized error messages
