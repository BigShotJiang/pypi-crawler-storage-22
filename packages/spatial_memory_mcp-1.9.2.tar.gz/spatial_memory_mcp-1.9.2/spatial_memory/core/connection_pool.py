"""Thread-safe LRU connection pool for LanceDB."""

from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from typing import TYPE_CHECKING, Any

import lancedb

if TYPE_CHECKING:
    from lancedb import DBConnection

logger = logging.getLogger(__name__)


class ConnectionPool:
    """Thread-safe LRU connection pool for LanceDB connections.

    This class encapsulates connection management with:
    - LRU eviction when at max capacity
    - Thread-safe access with locking
    - Connection reuse for same URIs

    Example:
        pool = ConnectionPool(max_size=10)
        conn = pool.get_or_create("/path/to/db")
        # ... use connection
        pool.close_all()  # cleanup
    """

    def __init__(self, max_size: int = 10) -> None:
        """Initialize the connection pool.

        Args:
            max_size: Maximum number of connections to cache.
        """
        if max_size < 1:
            raise ValueError("max_size must be >= 1")
        self._connections: OrderedDict[str, DBConnection] = OrderedDict()
        self._lock = threading.Lock()
        self._max_size = max_size

    @property
    def max_size(self) -> int:
        """Get the maximum pool size."""
        return self._max_size

    @max_size.setter
    def max_size(self, value: int) -> None:
        """Set the maximum pool size."""
        if value < 1:
            raise ValueError("max_size must be >= 1")
        with self._lock:
            self._max_size = value
            # Evict if now over capacity
            while len(self._connections) > self._max_size:
                self._evict_oldest()

    def get_or_create(
        self,
        uri: str,
        read_consistency_interval_ms: int = 0,
        validate_health: bool = True,
        **kwargs: Any,
    ) -> DBConnection:
        """Get existing connection or create new one.

        Args:
            uri: Database URI/path.
            read_consistency_interval_ms: Read consistency interval.
            validate_health: Whether to validate cached connection health (default: True).
            **kwargs: Additional args for lancedb.connect().

        Returns:
            Database connection.
        """
        with self._lock:
            # Check if exists
            if uri in self._connections:
                conn = self._connections[uri]

                # Optionally validate health of cached connection
                if validate_health and not self._validate_connection(conn, uri):
                    # Connection is stale, remove and create new
                    logger.info(f"Stale connection detected for {uri}, recreating")
                    self._connections.pop(uri)
                    try:
                        conn.close()
                    except Exception:
                        pass
                else:
                    # Connection is healthy, move to end (most recently used)
                    self._connections.move_to_end(uri)
                    return conn

            # Evict oldest if at capacity
            while len(self._connections) >= self._max_size:
                self._evict_oldest()

            # Create new connection
            from datetime import timedelta
            conn_kwargs = dict(kwargs)
            if read_consistency_interval_ms > 0:
                conn_kwargs["read_consistency_interval"] = timedelta(
                    milliseconds=read_consistency_interval_ms
                )

            conn = lancedb.connect(uri, **conn_kwargs)
            self._connections[uri] = conn
            logger.debug(f"Created new connection for {uri} (pool size: {len(self._connections)})")
            return conn

    def _validate_connection(self, conn: DBConnection, uri: str) -> bool:
        """Validate that a cached connection is still healthy.

        Performs a lightweight operation to verify the connection
        is still usable.

        Args:
            conn: The connection to validate.
            uri: URI for logging purposes.

        Returns:
            True if connection is healthy, False if stale.
        """
        try:
            # List tables is a lightweight operation that validates connection
            conn.table_names()
            return True
        except Exception as e:
            if self.is_stale_connection_error(e):
                logger.debug(f"Connection health check failed for {uri}: {e}")
                return False
            # Other errors might be transient, consider healthy
            return True

    def _evict_oldest(self) -> None:
        """Evict the oldest (least recently used) connection."""
        if self._connections:
            uri, conn = self._connections.popitem(last=False)
            try:
                conn.close()
            except Exception as e:
                logger.debug(f"Error closing evicted connection {uri}: {e}")
            logger.debug(f"Evicted connection for {uri}")

    def close_all(self) -> None:
        """Close all connections in the pool."""
        with self._lock:
            for uri, conn in list(self._connections.items()):
                try:
                    conn.close()
                except Exception as e:
                    logger.debug(f"Error closing connection {uri}: {e}")
            self._connections.clear()
            logger.info("Closed all pooled connections")

    def stats(self) -> dict[str, Any]:
        """Get pool statistics."""
        with self._lock:
            return {
                "size": len(self._connections),
                "max_size": self._max_size,
                "uris": list(self._connections.keys()),
            }

    def __len__(self) -> int:
        """Return number of connections in pool."""
        with self._lock:
            return len(self._connections)

    def invalidate(self, uri: str) -> bool:
        """Invalidate and remove a specific connection from the pool.

        Use this when a connection is detected as stale (e.g., database
        was deleted/recreated, or metadata references missing files).

        Args:
            uri: Database URI/path to invalidate.

        Returns:
            True if connection was found and removed, False otherwise.
        """
        with self._lock:
            if uri in self._connections:
                conn = self._connections.pop(uri)
                try:
                    conn.close()
                except Exception as e:
                    logger.debug(f"Error closing invalidated connection {uri}: {e}")
                logger.info(f"Invalidated stale connection for {uri}")
                return True
            return False

    @staticmethod
    def is_stale_connection_error(error: Exception) -> bool:
        """Check if an error indicates a stale/corrupted connection.

        These errors occur when:
        - Database was deleted and recreated while connection cached
        - Database metadata references files that no longer exist
        - Version mismatch from external modifications

        Args:
            error: The exception to check.

        Returns:
            True if the error indicates a stale connection.
        """
        error_str = str(error).lower()
        stale_patterns = (
            "_deletions/",  # Missing deletion files
            "not found:",  # General missing file errors
            "no such file",  # File system errors
            "version mismatch",  # Stale version references
            "manifest",  # Corrupted manifest references
        )
        return any(pattern in error_str for pattern in stale_patterns)
