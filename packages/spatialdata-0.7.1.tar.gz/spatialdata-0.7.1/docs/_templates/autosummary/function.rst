:github_url: {{ fullname }}

{{ fullname | escape | underline}}

.. autofunction:: {{ fullname }}
