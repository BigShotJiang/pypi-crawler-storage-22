# SpatialData object

```{eval-rst}
.. currentmodule:: spatialdata

.. autoclass:: SpatialData
```
