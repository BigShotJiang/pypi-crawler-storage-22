# Datasets

Convenience small datasets

```{eval-rst}
.. currentmodule:: spatialdata.datasets

.. autofunction:: blobs
.. autofunction:: blobs_annotating_element
.. autofunction:: raccoon
```
