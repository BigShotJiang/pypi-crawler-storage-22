# Testing utilities

```{eval-rst}
.. currentmodule:: spatialdata.testing

.. autofunction:: assert_spatial_data_objects_are_identical
.. autofunction:: assert_elements_are_identical
.. autofunction:: assert_elements_dict_are_identical
```
