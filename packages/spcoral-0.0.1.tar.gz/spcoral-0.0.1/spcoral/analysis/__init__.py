from .correlation import pearson, bivariate_moran, bivariate_local_moran
from .mapping import mapping_slides
from .spatial_domain import cluster