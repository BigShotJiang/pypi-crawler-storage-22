from .model import regist_model, integrate_model, integrate_model_block
from .regist import registration, registration_by_downsampling