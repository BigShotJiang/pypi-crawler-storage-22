#  SPDX-License-Identifier: BSD-3-Clause
#  Copyright (C) 2017 Intel Corporation.
#  Copyright (C) 2025 Dell Inc, or its subsidiaries.
#  All rights reserved.
