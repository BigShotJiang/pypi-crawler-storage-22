# Example Specification

## Overview
This is an example specification file. Replace with your actual specs.

## Related Issue
- [ISSUE-001](../issues/001-example.md)

## Requirements

### Core Features
- **EXAMPLE-001**: The system should do something useful
- **EXAMPLE-002**: The system should handle errors gracefully
- **EXAMPLE-003** [manual]: Code follows project naming conventions
