"""Contract property modules for CrossHair analysis."""

__all__ = ["crosshair_props"]
