import '@jupyterlab/console';
import '@jupyterlab/fileeditor';
import '@jupyterlab/logconsole';
import '@jupyterlite/apputils';
import 'mock-socket';
