"""Top-level package for TARDIS-Spectrum-Filtering."""

__author__ = """Clyde Watson"""
__email__ = "clyde.n.watson@gmail.com"
__version__ = "0.0.1"
