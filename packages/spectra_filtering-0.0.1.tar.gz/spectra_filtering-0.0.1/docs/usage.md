# Usage

To use TARDIS-Spectrum-Filtering in a project:

```
import TARDIS_Spectrum_Filtering
```
