#!/usr/bin/env python

"""Tests for `TARDIS_Spectrum_Filtering` package."""


import unittest

from TARDIS_Spectrum_Filtering import TARDIS_Spectrum_Filtering


class TestTardis_spectrum_filtering(unittest.TestCase):
    """Tests for `TARDIS_Spectrum_Filtering` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
