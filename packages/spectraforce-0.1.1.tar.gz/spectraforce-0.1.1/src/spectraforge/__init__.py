"""SpectraForge: a modern desktop workstation for Earth observation segmentation."""

__all__ = ["__version__"]

__version__ = "0.1.0"
