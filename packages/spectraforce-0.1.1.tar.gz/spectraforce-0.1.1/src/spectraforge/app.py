from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path


def _ensure_mpl_cache() -> None:
    if os.environ.get("MPLCONFIGDIR"):
        return
    cache_dir = Path(tempfile.gettempdir()) / "spectraforge_mpl"
    cache_dir.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(cache_dir)


def main() -> None:
    _ensure_mpl_cache()
    from PySide6 import QtWidgets

    from .ui.main_window import MainWindow

    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("SpectraForge")
    app.setOrganizationName("SpectraForge")

    window = MainWindow()
    window.show()
    sys.exit(app.exec())
