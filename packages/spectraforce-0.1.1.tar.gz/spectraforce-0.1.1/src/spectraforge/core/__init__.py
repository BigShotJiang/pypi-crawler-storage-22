"""Core processing modules for SpectraForge."""
