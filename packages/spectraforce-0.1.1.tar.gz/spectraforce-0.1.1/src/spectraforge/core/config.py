from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


CONFIG_DIR = Path.home() / ".spectraforge"
CONFIG_PATH = CONFIG_DIR / "config.json"


@dataclass
class AppConfig:
    copernicus_key: str = ""
    copernicus_secret: str = ""
    planetscope_key: str = ""
    download_dir: str = str(Path.home() / "spectraforge_downloads")
    custom_indices: list[str] = field(default_factory=list)


def load_config() -> AppConfig:
    if not CONFIG_PATH.exists():
        return AppConfig()
    data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    return AppConfig(**data)


def save_config(config: AppConfig) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config.__dict__, indent=2), encoding="utf-8")
