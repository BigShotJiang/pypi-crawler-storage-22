from .spectreq import *

__doc__ = spectreq.__doc__
if hasattr(spectreq, "__all__"):
    __all__ = spectreq.__all__