# MOVED to specsoloist

The `specular-ai` package has been renamed to **`specsoloist`**.

Please install the new package:

```bash
pip install specsoloist
```

This package exists only to transitively install `specsoloist` for backward compatibility.
