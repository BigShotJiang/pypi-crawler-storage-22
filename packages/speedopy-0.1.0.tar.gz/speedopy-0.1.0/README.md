# speedopy

Zero-dependency performance measurement decorators for Python.

Just import a decorator, slap it on your function, and instantly see metrics printed to the console. No config, no setup, no external packages.

## Install

```bash
pip install speedopy
```

## Decorators

| Decorator | What It Measures |
|---|---|
| `cpu_time` | CPU processing time (excludes I/O) |
| `real_time` | Wall-clock time |
| `memory_usage` | Peak memory allocated (auto-formats B/KB/MB) |
| `thread_time` | CPU time for the current thread only |
| `call_count` | Number of times a function has been called |
| `function_profile` | Full cProfile report (top 10 calls) |
| `io_time` | I/O wait time (real - cpu) |
| `gc_stats` | Garbage collections triggered |
| `object_count` | Net new Python objects created |

## Usage

```python
from speedopy import cpu_time, memory_usage, io_time

@cpu_time
@memory_usage
@io_time
def process_data():
    data = [i ** 2 for i in range(1_000_000)]
    return sum(data)

process_data()
```

Output:
```
[io_time] process_data -> real: 0.182345s, cpu: 0.171875s, io_wait: 0.010470s
[memory_usage] process_data -> current: 472 B, peak: 8.06 MB
[cpu_time] process_data -> 0.183291s
```

## Stack Multiple Decorators

```python
from speedopy import cpu_time, memory_usage, call_count

@call_count
@cpu_time
@memory_usage
def my_func():
    return sum(range(500_000))

my_func()  # [call_count] my_func -> called 1 time(s)
my_func()  # [call_count] my_func -> called 2 time(s)
```

## Requirements

- Python 3.8+
- No external dependencies

## License

MIT
