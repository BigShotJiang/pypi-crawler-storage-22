"""
speedopy — A collection of zero-dependency performance measurement decorators.

Usage:
    from speedopy import cpu_time, real_time, memory_usage

    @cpu_time
    def my_function():
        ...
"""

__version__ = "0.1.0"

from .decorators import (
    cpu_time,
    real_time,
    memory_usage,
    thread_time,
    call_count,
    function_profile,
    io_time,
    gc_stats,
    object_count,
)

__all__ = [
    "cpu_time",
    "real_time",
    "memory_usage",
    "thread_time",
    "call_count",
    "function_profile",
    "io_time",
    "gc_stats",
    "object_count",
]
