import time
import tracemalloc
import cProfile
import pstats
import io
import gc
from functools import wraps


# ─────────────────────────────────────────────
# 1. CPU Time
# ─────────────────────────────────────────────
def cpu_time(func):
    """Measures CPU processing time (excludes I/O wait, sleep, etc.)."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.process_time_ns()
        result = func(*args, **kwargs)
        elapsed_ns = time.process_time_ns() - start
        elapsed = elapsed_ns / 1_000_000_000
        print(f"[cpu_time] {func.__name__} -> {elapsed:.6f}s")
        return result
    return wrapper


# ─────────────────────────────────────────────
# 2. Real (Wall-Clock) Time
# ─────────────────────────────────────────────
def real_time(func):
    """Measures wall-clock (real) time including I/O, sleep, etc."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        print(f"[real_time] {func.__name__} -> {elapsed:.6f}s")
        return result
    return wrapper


# ─────────────────────────────────────────────
# 3. Memory Usage
# ─────────────────────────────────────────────
def memory_usage(func):
    """Measures peak memory allocated during function execution."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        tracemalloc.start()
        result = func(*args, **kwargs)
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        # Auto-format to the most readable unit
        if peak < 1024:
            peak_str = f"{peak} B"
        elif peak < 1024 ** 2:
            peak_str = f"{peak / 1024:.2f} KB"
        else:
            peak_str = f"{peak / (1024 ** 2):.2f} MB"

        if current < 1024:
            curr_str = f"{current} B"
        elif current < 1024 ** 2:
            curr_str = f"{current / 1024:.2f} KB"
        else:
            curr_str = f"{current / (1024 ** 2):.2f} MB"

        print(f"[memory_usage] {func.__name__} -> current: {curr_str}, peak: {peak_str}")
        return result
    return wrapper


# ─────────────────────────────────────────────
# 4. Thread Time
# ─────────────────────────────────────────────
def thread_time(func):
    """Measures CPU time consumed by the current thread only."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.thread_time_ns()
        result = func(*args, **kwargs)
        elapsed_ns = time.thread_time_ns() - start
        elapsed = elapsed_ns / 1_000_000_000
        print(f"[thread_time] {func.__name__} -> {elapsed:.6f}s")
        return result
    return wrapper


# ─────────────────────────────────────────────
# 5. Call Count
# ─────────────────────────────────────────────
def call_count(func):
    """Tracks and displays how many times a function has been called."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        wrapper.calls += 1
        result = func(*args, **kwargs)
        print(f"[call_count] {func.__name__} -> called {wrapper.calls} time(s)")
        return result
    wrapper.calls = 0
    return wrapper


# ─────────────────────────────────────────────
# 6. Function Profile (cProfile)
# ─────────────────────────────────────────────
def function_profile(func):
    """Runs cProfile on the function and prints a profiling summary."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        profiler = cProfile.Profile()
        profiler.enable()
        result = func(*args, **kwargs)
        profiler.disable()

        stream = io.StringIO()
        stats = pstats.Stats(profiler, stream=stream)
        stats.strip_dirs()
        stats.sort_stats("cumulative")
        stats.print_stats(10)  # top 10 entries

        print(f"[function_profile] {func.__name__}:")
        print(stream.getvalue())
        return result
    return wrapper


# ─────────────────────────────────────────────
# 7. I/O Time (real − cpu = approximate I/O wait)
# ─────────────────────────────────────────────
def io_time(func):
    """Estimates I/O wait time by computing real_time − cpu_time."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        real_start = time.perf_counter()
        cpu_start = time.process_time()
        result = func(*args, **kwargs)
        real_elapsed = time.perf_counter() - real_start
        cpu_elapsed = time.process_time() - cpu_start
        io_elapsed = max(real_elapsed - cpu_elapsed, 0.0)
        print(
            f"[io_time] {func.__name__} -> "
            f"real: {real_elapsed:.6f}s, "
            f"cpu: {cpu_elapsed:.6f}s, "
            f"io_wait: {io_elapsed:.6f}s"
        )
        return result
    return wrapper


# ─────────────────────────────────────────────
# 8. GC Stats
# ─────────────────────────────────────────────
def gc_stats(func):
    """Reports garbage collection activity during function execution."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        gc.collect()  # clean slate
        gc.disable()  # temporarily disable auto-GC to measure manually
        stats_before = gc.get_stats()  # per-generation stats

        gc.enable()
        result = func(*args, **kwargs)
        collected = gc.collect()  # force a collection and count

        stats_after = gc.get_stats()
        collections = sum(
            stats_after[i]["collections"] - stats_before[i]["collections"]
            for i in range(len(stats_after))
        )

        print(
            f"[gc_stats] {func.__name__} -> "
            f"collected: {collected} objects, "
            f"gc runs: {collections}"
        )
        return result
    return wrapper


# ─────────────────────────────────────────────
# 9. Object Count
# ─────────────────────────────────────────────
def object_count(func):
    """Tracks the net number of new Python objects created by the function."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        gc.collect()
        before = len(gc.get_objects())
        result = func(*args, **kwargs)
        gc.collect()
        after = len(gc.get_objects())
        net_new = after - before
        print(
            f"[object_count] {func.__name__} -> "
            f"before: {before}, after: {after}, "
            f"net new: {net_new:+d}"
        )
        return result
    return wrapper
