"""Allow running speedopy as: python -m speedopy script.py"""
from .runner import main

main()
