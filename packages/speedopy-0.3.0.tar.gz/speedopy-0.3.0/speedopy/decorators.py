import time
import tracemalloc
import cProfile
import pstats
import io
import gc
from functools import wraps


# ── ANSI color helpers ────────────────────────────────────────
class _C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    CYAN    = "\033[96m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    MAGENTA = "\033[95m"
    BLUE    = "\033[94m"
    WHITE   = "\033[97m"
    RED     = "\033[91m"


# ── Box-drawing helpers ──────────────────────────────────────
_W = 52  # box width for decorators


def _fmt_time(seconds):
    """Auto-format seconds to the most readable unit."""
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.2f} µs"
    elif seconds < 1.0:
        return f"{seconds * 1_000:.2f} ms"
    else:
        return f"{seconds:.4f} s"


def _fmt_bytes(b):
    """Auto-format bytes to the most readable unit."""
    if b < 1024:
        return f"{b} B"
    elif b < 1024 ** 2:
        return f"{b / 1024:.2f} KB"
    elif b < 1024 ** 3:
        return f"{b / (1024 ** 2):.2f} MB"
    else:
        return f"{b / (1024 ** 3):.2f} GB"


def _box(title, rows, color):
    """
    Print a neat box with a title and key-value rows.
    rows: list of (label, value) tuples
    """
    inner = _W - 2
    # top border with title
    pad = inner - len(title) - 4
    lp = pad // 2
    rp = pad - lp
    lines = [f"{color}{_C.BOLD}┌{'─' * lp} {title} {'─' * rp}┐{_C.RESET}"]

    for i, (label, value) in enumerate(rows):
        content_len = _W - 4  # space inside │ ... │
        gap = content_len - len(label) - len(value)
        lines.append(f"{color}│ {label}{' ' * gap}{value} │{_C.RESET}")
        if i < len(rows) - 1:
            lines.append(f"{color}├{'─' * inner}┤{_C.RESET}")

    lines.append(f"{color}{_C.BOLD}└{'─' * inner}┘{_C.RESET}")
    print('\n'.join(lines))


# ─────────────────────────────────────────────
# 1. CPU Time
# ─────────────────────────────────────────────
def cpu_time(func):
    """Measures CPU processing time (excludes I/O wait, sleep, etc.)."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.process_time_ns()
        result = func(*args, **kwargs)
        elapsed_ns = time.process_time_ns() - start
        elapsed = elapsed_ns / 1_000_000_000
        _box(f"⏱  CPU TIME › {func.__name__}", [
            ("CPU time", _fmt_time(elapsed)),
        ], _C.GREEN)
        return result
    return wrapper


# ─────────────────────────────────────────────
# 2. Real (Wall-Clock) Time
# ─────────────────────────────────────────────
def real_time(func):
    """Measures wall-clock (real) time including I/O, sleep, etc."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        _box(f"⏱  REAL TIME › {func.__name__}", [
            ("Wall-clock time", _fmt_time(elapsed)),
        ], _C.GREEN)
        return result
    return wrapper


# ─────────────────────────────────────────────
# 3. Memory Usage
# ─────────────────────────────────────────────
def memory_usage(func):
    """Measures peak memory allocated during function execution."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        tracemalloc.start()
        result = func(*args, **kwargs)
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        _box(f"🧠  MEMORY › {func.__name__}", [
            ("Current", _fmt_bytes(current)),
            ("Peak", _fmt_bytes(peak)),
        ], _C.MAGENTA)
        return result
    return wrapper


# ─────────────────────────────────────────────
# 4. Thread Time
# ─────────────────────────────────────────────
def thread_time(func):
    """Measures CPU time consumed by the current thread only."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.thread_time_ns()
        result = func(*args, **kwargs)
        elapsed_ns = time.thread_time_ns() - start
        elapsed = elapsed_ns / 1_000_000_000
        _box(f"🧵  THREAD TIME › {func.__name__}", [
            ("Thread CPU time", _fmt_time(elapsed)),
        ], _C.CYAN)
        return result
    return wrapper


# ─────────────────────────────────────────────
# 5. Call Count
# ─────────────────────────────────────────────
def call_count(func):
    """Tracks and displays how many times a function has been called."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        wrapper.calls += 1
        result = func(*args, **kwargs)
        _box(f"🔢  CALL COUNT › {func.__name__}", [
            ("Total calls", str(wrapper.calls)),
        ], _C.YELLOW)
        return result
    wrapper.calls = 0
    return wrapper


# ─────────────────────────────────────────────
# 6. Function Profile (cProfile)
# ─────────────────────────────────────────────
def function_profile(func):
    """Runs cProfile on the function and prints a profiling summary."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        profiler = cProfile.Profile()
        profiler.enable()
        result = func(*args, **kwargs)
        profiler.disable()

        stream = io.StringIO()
        stats = pstats.Stats(profiler, stream=stream)
        stats.strip_dirs()
        stats.sort_stats("cumulative")
        stats.print_stats(10)
        profile_text = stream.getvalue().strip()

        inner = _W - 2
        color = _C.YELLOW
        print(f"{color}{_C.BOLD}┌{'─' * ((inner - len(f'📊  PROFILE › {func.__name__}') - 2) // 2)} 📊  PROFILE › {func.__name__} {'─' * ((inner - len(f'📊  PROFILE › {func.__name__}') - 2 + 1) // 2)}┐{_C.RESET}")
        for line in profile_text.split('\n'):
            trimmed = line.rstrip()
            if len(trimmed) > _W - 4:
                trimmed = trimmed[:_W - 7] + "..."
            padded = trimmed + ' ' * max(0, _W - 4 - len(trimmed))
            print(f"{color}│ {padded} │{_C.RESET}")
        print(f"{color}{_C.BOLD}└{'─' * inner}┘{_C.RESET}")
        return result
    return wrapper


# ─────────────────────────────────────────────
# 7. I/O Time (real − cpu = approximate I/O wait)
# ─────────────────────────────────────────────
def io_time(func):
    """Estimates I/O wait time by computing real_time − cpu_time."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        real_start = time.perf_counter()
        cpu_start = time.process_time()
        result = func(*args, **kwargs)
        real_elapsed = time.perf_counter() - real_start
        cpu_elapsed = time.process_time() - cpu_start
        io_elapsed = max(real_elapsed - cpu_elapsed, 0.0)
        _box(f"💾  I/O TIME › {func.__name__}", [
            ("Real time", _fmt_time(real_elapsed)),
            ("CPU time", _fmt_time(cpu_elapsed)),
            ("I/O wait", _fmt_time(io_elapsed)),
        ], _C.BLUE)
        return result
    return wrapper


# ─────────────────────────────────────────────
# 8. GC Stats
# ─────────────────────────────────────────────
def gc_stats(func):
    """Reports garbage collection activity during function execution."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        gc.collect()
        gc.disable()
        stats_before = gc.get_stats()

        gc.enable()
        result = func(*args, **kwargs)
        collected = gc.collect()

        stats_after = gc.get_stats()
        collections = sum(
            stats_after[i]["collections"] - stats_before[i]["collections"]
            for i in range(len(stats_after))
        )
        _box(f"♻  GC STATS › {func.__name__}", [
            ("Objects collected", str(collected)),
            ("GC runs", str(collections)),
        ], _C.RED)
        return result
    return wrapper


# ─────────────────────────────────────────────
# 9. Object Count
# ─────────────────────────────────────────────
def object_count(func):
    """Tracks the net number of new Python objects created by the function."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        gc.collect()
        before = len(gc.get_objects())
        result = func(*args, **kwargs)
        gc.collect()
        after = len(gc.get_objects())
        net_new = after - before
        _box(f"📦  OBJECTS › {func.__name__}", [
            ("Before", str(before)),
            ("After", str(after)),
            ("Net new", f"{net_new:+d}"),
        ], _C.CYAN)
        return result
    return wrapper
