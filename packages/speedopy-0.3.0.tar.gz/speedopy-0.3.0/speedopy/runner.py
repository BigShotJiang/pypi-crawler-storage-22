"""
speedopy CLI runner — Run any Python script and get a full performance report.

Usage:
    python -m speedopy script.py [args...]
    speedopy script.py [args...]
"""

import sys
import os
import time
import tracemalloc
import cProfile
import pstats
import io
import gc
import runpy


# ── ANSI color helpers ────────────────────────────────────────
class _Colors:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    CYAN    = "\033[96m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    MAGENTA = "\033[95m"
    BLUE    = "\033[94m"
    WHITE   = "\033[97m"
    RED     = "\033[91m"
    GRAY    = "\033[90m"

C = _Colors


# ── Formatting helpers ────────────────────────────────────────
def _fmt_time(seconds):
    """Auto-format seconds to the most readable unit."""
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.2f} µs"
    elif seconds < 1.0:
        return f"{seconds * 1_000:.2f} ms"
    else:
        return f"{seconds:.4f} s"


def _fmt_bytes(b):
    """Auto-format bytes to the most readable unit."""
    if b < 1024:
        return f"{b} B"
    elif b < 1024 ** 2:
        return f"{b / 1024:.2f} KB"
    elif b < 1024 ** 3:
        return f"{b / (1024 ** 2):.2f} MB"
    else:
        return f"{b / (1024 ** 3):.2f} GB"


def _box_top(title, width=60):
    inner = width - 2
    pad = inner - len(title) - 2
    left_pad = pad // 2
    right_pad = pad - left_pad
    return f"┌{'─' * left_pad} {title} {'─' * right_pad}┐"


def _box_row(label, value, width=60):
    inner = width - 4  # minus │ + space on each side
    content = f"{label}{' ' * (inner - len(label) - len(value))}{value}"
    return f"│ {content} │"


def _box_sep(width=60):
    return f"├{'─' * (width - 2)}┤"


def _box_bottom(width=60):
    return f"└{'─' * (width - 2)}┘"


def _box_text(text, width=60):
    inner = width - 4
    lines = []
    for line in text.split('\n'):
        if len(line) <= inner:
            lines.append(f"│ {line}{' ' * (inner - len(line))} │")
        else:
            # wrap long lines
            while len(line) > inner:
                lines.append(f"│ {line[:inner]} │")
                line = line[inner:]
            if line:
                lines.append(f"│ {line}{' ' * (inner - len(line))} │")
    return '\n'.join(lines)


# ── Core runner ───────────────────────────────────────────────
def run_script(script_path):
    """
    Execute a Python script and collect all performance metrics,
    then print an organized report to the terminal.
    """
    script_path = os.path.abspath(script_path)
    if not os.path.isfile(script_path):
        print(f"{C.RED}{C.BOLD}Error:{C.RESET} File not found: {script_path}")
        sys.exit(1)

    script_name = os.path.basename(script_path)
    W = 62  # box width

    # ── Header ────────────────────────────────────────────────
    print()
    print(f"{C.CYAN}{C.BOLD}{'━' * W}{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}  ⚡  SPEEDOPY — Performance Report{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}{'━' * W}{C.RESET}")
    print(f"{C.DIM}  Script : {script_name}{C.RESET}")
    print(f"{C.DIM}  Path   : {script_path}{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}{'━' * W}{C.RESET}")
    print()

    # ── Capture script stdout/stderr ──────────────────────────
    print(f"{C.YELLOW}{C.BOLD}{_box_top('SCRIPT OUTPUT', W)}{C.RESET}")

    # ── Setup all measurement instruments ─────────────────────
    gc.collect()
    gc.disable()
    gc_stats_before = gc.get_stats()
    gc.enable()

    gc.collect()
    obj_before = len(gc.get_objects())

    tracemalloc.start()

    profiler = cProfile.Profile()

    # ── Run the script ────────────────────────────────────────
    real_start = time.perf_counter()
    cpu_start  = time.process_time_ns()
    thr_start  = time.thread_time_ns()

    profiler.enable()
    script_error = None
    try:
        # inject the script's directory into sys.path so its imports work
        script_dir = os.path.dirname(script_path)
        if script_dir not in sys.path:
            sys.path.insert(0, script_dir)
        runpy.run_path(script_path, run_name="__main__")
    except SystemExit:
        pass  # script called sys.exit(); that's fine
    except Exception as exc:
        script_error = exc
    finally:
        profiler.disable()

    thr_ns     = time.thread_time_ns() - thr_start
    cpu_ns     = time.process_time_ns() - cpu_start
    real_sec   = time.perf_counter() - real_start

    cpu_sec    = cpu_ns / 1_000_000_000
    thr_sec    = thr_ns / 1_000_000_000
    io_sec     = max(real_sec - cpu_sec, 0.0)

    mem_current, mem_peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    gc_collected = gc.collect()
    gc_stats_after = gc.get_stats()
    gc_runs = sum(
        gc_stats_after[i]["collections"] - gc_stats_before[i]["collections"]
        for i in range(len(gc_stats_after))
    )

    gc.collect()
    obj_after = len(gc.get_objects())
    obj_net   = obj_after - obj_before

    # cProfile summary
    stream = io.StringIO()
    stats = pstats.Stats(profiler, stream=stream)
    stats.strip_dirs()
    stats.sort_stats("cumulative")
    stats.print_stats(10)
    profile_text = stream.getvalue().strip()

    # ── Close script output box ───────────────────────────────
    if script_error:
        print(f"\n{C.RED}  ✗ Script raised: {script_error}{C.RESET}")
    print(f"{C.YELLOW}{C.BOLD}{_box_bottom(W)}{C.RESET}")
    print()

    # ── 1. Timing Section ─────────────────────────────────────
    print(f"{C.GREEN}{C.BOLD}{_box_top('⏱  TIMING', W)}{C.RESET}")
    print(f"{C.GREEN}{_box_row('Real (wall-clock) time', _fmt_time(real_sec), W)}{C.RESET}")
    print(f"{C.GREEN}{_box_sep(W)}{C.RESET}")
    print(f"{C.GREEN}{_box_row('CPU time', _fmt_time(cpu_sec), W)}{C.RESET}")
    print(f"{C.GREEN}{_box_sep(W)}{C.RESET}")
    print(f"{C.GREEN}{_box_row('Thread time', _fmt_time(thr_sec), W)}{C.RESET}")
    print(f"{C.GREEN}{_box_sep(W)}{C.RESET}")
    print(f"{C.GREEN}{_box_row('I/O wait (estimated)', _fmt_time(io_sec), W)}{C.RESET}")
    print(f"{C.GREEN}{_box_bottom(W)}{C.RESET}")
    print()

    # ── 2. Memory Section ─────────────────────────────────────
    print(f"{C.MAGENTA}{C.BOLD}{_box_top('🧠  MEMORY', W)}{C.RESET}")
    print(f"{C.MAGENTA}{_box_row('Current memory', _fmt_bytes(mem_current), W)}{C.RESET}")
    print(f"{C.MAGENTA}{_box_sep(W)}{C.RESET}")
    print(f"{C.MAGENTA}{_box_row('Peak memory', _fmt_bytes(mem_peak), W)}{C.RESET}")
    print(f"{C.MAGENTA}{_box_bottom(W)}{C.RESET}")
    print()

    # ── 3. GC & Objects Section ───────────────────────────────
    print(f"{C.BLUE}{C.BOLD}{_box_top('♻  GC & OBJECTS', W)}{C.RESET}")
    print(f"{C.BLUE}{_box_row('GC objects collected', str(gc_collected), W)}{C.RESET}")
    print(f"{C.BLUE}{_box_sep(W)}{C.RESET}")
    print(f"{C.BLUE}{_box_row('GC runs during execution', str(gc_runs), W)}{C.RESET}")
    print(f"{C.BLUE}{_box_sep(W)}{C.RESET}")
    print(f"{C.BLUE}{_box_row('Objects before', str(obj_before), W)}{C.RESET}")
    print(f"{C.BLUE}{_box_sep(W)}{C.RESET}")
    print(f"{C.BLUE}{_box_row('Objects after', str(obj_after), W)}{C.RESET}")
    print(f"{C.BLUE}{_box_sep(W)}{C.RESET}")
    net_sign = f"{obj_net:+d}"
    print(f"{C.BLUE}{_box_row('Net new objects', net_sign, W)}{C.RESET}")
    print(f"{C.BLUE}{_box_bottom(W)}{C.RESET}")
    print()

    # ── 4. cProfile Section ───────────────────────────────────
    print(f"{C.YELLOW}{C.BOLD}{_box_top('📊  CPROFILE (top 10)', W)}{C.RESET}")
    # Print profile text line by line inside the box
    for line in profile_text.split('\n'):
        trimmed = line.rstrip()
        if len(trimmed) > W - 4:
            trimmed = trimmed[:W - 7] + "..."
        padded = trimmed + ' ' * max(0, W - 4 - len(trimmed))
        print(f"{C.YELLOW}│ {padded} │{C.RESET}")
    print(f"{C.YELLOW}{C.BOLD}{_box_bottom(W)}{C.RESET}")
    print()

    # ── Footer ────────────────────────────────────────────────
    print(f"{C.CYAN}{C.BOLD}{'━' * W}{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}  ✅  Report complete — powered by speedopy{C.RESET}")
    print(f"{C.CYAN}{C.BOLD}{'━' * W}{C.RESET}")
    print()


# ── CLI entry point ───────────────────────────────────────────
def main():
    if len(sys.argv) < 2:
        print(f"{C.BOLD}Usage:{C.RESET} speedopy <script.py> [args...]")
        print(f"       python -m speedopy <script.py> [args...]")
        sys.exit(1)

    script = sys.argv[1]
    # Remove speedopy's own argv so the target script sees clean args
    sys.argv = sys.argv[1:]
    run_script(script)


if __name__ == "__main__":
    main()
