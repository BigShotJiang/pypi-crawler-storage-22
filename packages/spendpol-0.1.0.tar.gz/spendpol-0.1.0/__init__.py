"""
Spendpol — AI Spend Protocol
============================
Delegated spending governance for autonomous AI agents.

Quick start:
    from spendpol import SpendpolClient

    client = SpendpolClient()
    client.grant("user:john@acme.com", "agent-47x", max_daily=10.0)

    verdict = client.check_intent(
        agent_id="agent-47x",
        vendor="openai",
        action="api_call",
        amount=0.03,
        purpose="Embedding generation"
    )

    if verdict.allowed:
        client.log_receipt(verdict, actual_amount=0.028)

https://spendpol.dev
https://github.com/spendpol/spendpol
"""

__version__ = "0.1.0"

from .client import ASPClient as SpendpolClient
from .client import ASPClient, ASPError

# Also export as SpendpolError for consistency
SpendpolError = ASPError

from .schemas import (
    SpendIntent,
    PolicyVerdict,
    SpendReceipt,
    AuditQuery,
    DelegationGrant,
    CostEstimate,
    Decision,
    Confidence,
    CostBasis,
    AuditRole,
    AnomalyAction,
    SpendStatus,
    RuleResult,
    ASP_VERSION,
)
from .delegation import DelegationRegistry, DelegationError
from .wallet import AgentWallet, WalletRegistry
from .policy import PolicyEngine, ConditionalRule
from .audit import AuditLog, AuditRecord
from .validator import Validator, ValidationError
from .langgraph import SpendpolLangGraphMiddleware, asp_tool
from .autogen import SpendpolAutoGenMiddleware

__all__ = [
    # Primary client
    "SpendpolClient",
    "SpendpolError",
    # Legacy aliases
    "ASPClient",
    "ASPError",
    # Schemas
    "SpendIntent",
    "PolicyVerdict",
    "SpendReceipt",
    "AuditQuery",
    "DelegationGrant",
    "CostEstimate",
    # Enums
    "Decision",
    "Confidence",
    "CostBasis",
    "AuditRole",
    "AnomalyAction",
    "SpendStatus",
    "RuleResult",
    # Core
    "DelegationRegistry",
    "DelegationError",
    "AgentWallet",
    "WalletRegistry",
    "PolicyEngine",
    "ConditionalRule",
    "AuditLog",
    "AuditRecord",
    "Validator",
    "ValidationError",
    # Constants
    "ASP_VERSION",
    # LangGraph integration
    "SpendpolLangGraphMiddleware",
    "asp_tool",
    # AutoGen integration
    "SpendpolAutoGenMiddleware",
]
