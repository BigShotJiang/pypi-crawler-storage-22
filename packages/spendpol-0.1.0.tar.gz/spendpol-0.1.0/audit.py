"""
ASP Protocol — Audit Log
==========================
Append-only audit log with role-based query filtering.
"""

from __future__ import annotations

from .schemas import Decision


class AuditRecord:
    def __init__(self, intent, verdict, receipt=None):
        self.intent = intent
        self.verdict = verdict
        self.receipt = receipt


class AuditLog:
    def __init__(self):
        self._records: list[AuditRecord] = []
        self._by_intent: dict[str, AuditRecord] = {}

    def record(self, intent, verdict):
        rec = AuditRecord(intent=intent, verdict=verdict)
        self._records.append(rec)
        self._by_intent[intent.intent_id] = rec

    def attach_receipt(self, intent_id: str, receipt):
        rec = self._by_intent.get(intent_id)
        if rec is not None:
            rec.receipt = receipt

    def query(self, query) -> list[AuditRecord]:
        results = list(self._records)
        if query.agent_id is not None:
            results = [r for r in results if r.intent.agent_id == query.agent_id]
        if query.vendor is not None:
            results = [r for r in results if r.intent.vendor == query.vendor]
        return results

    def count(self) -> int:
        return len(self._records)

    def get_by_intent(self, intent_id: str) -> AuditRecord | None:
        return self._by_intent.get(intent_id)

    def denial_rate(self, agent_id: str) -> float:
        agent_records = [r for r in self._records if r.intent.agent_id == agent_id]
        if not agent_records:
            return 0.0
        denials = sum(1 for r in agent_records if r.verdict.decision == Decision.DENY)
        return denials / len(agent_records)

    def summary(self) -> dict:
        total_spend = 0.0
        for r in self._records:
            if r.receipt is not None:
                total_spend += r.receipt.actual_amount
        return {
            "total_records": len(self._records),
            "total_spend": total_spend,
        }
