"""
Spendpol × AutoGen Integration
===============================
Spending control middleware for Microsoft AutoGen agent frameworks.

Usage:
    from spendpol.autogen import SpendpolAutoGenMiddleware

    asp = SpendpolAutoGenMiddleware(
        delegator="user:john@acme.com",
        default_daily_limit=10.0,
    )

    # Wrap a tool function with spending control
    @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.03)
    def embedding_tool(text: str) -> list[float]:
        return openai.embeddings.create(input=text, model="text-embedding-3-small")

    # Or use the convenience method to wrap AND register in one step
    asp.register_controlled_tool(
        agent=assistant,
        user_proxy=user_proxy,
        func=my_tool_func,
        vendor="openai",
        action="api_call",
        cost_per_call=0.03,
    )
"""

from __future__ import annotations
from functools import wraps
from typing import Optional, Callable, Any
import logging

from spendpol import (
    SpendpolClient,
    PolicyVerdict,
    Decision,
)

logger = logging.getLogger("spendpol.autogen")


class SpendpolAutoGenMiddleware:
    """
    Middleware that wraps AutoGen tool calls with Spendpol spending control.

    Automatically:
    - Registers agents on first spend
    - Checks spending intent before each tool call
    - Logs receipts after successful calls
    - Blocks calls that exceed policy
    """

    def __init__(
        self,
        delegator: str = "system:autogen",
        default_max_per_tx: float = 1.0,
        default_daily_limit: float = 10.0,
        default_monthly_limit: float = 200.0,
        allowed_vendors: Optional[list[str]] = None,
        allowed_actions: Optional[list[str]] = None,
        denied_actions: Optional[list[str]] = None,
        on_deny: str = "raise",  # "raise", "skip", "log"
        on_escalate: str = "skip",
        anomaly_sigma: float = 3.0,
    ):
        self.delegator = delegator
        self.default_max_per_tx = default_max_per_tx
        self.default_daily_limit = default_daily_limit
        self.default_monthly_limit = default_monthly_limit
        self.allowed_vendors = allowed_vendors or []
        self.allowed_actions = allowed_actions or []
        self.denied_actions = denied_actions or []
        self.on_deny = on_deny
        self.on_escalate = on_escalate

        self.client = SpendpolClient(anomaly_sigma=anomaly_sigma)
        self._registered_agents: set[str] = set()

    def _ensure_agent(self, agent_name: str):
        """Auto-register agent with default grant if not already registered."""
        if agent_name not in self._registered_agents:
            self.client.grant(
                delegator=self.delegator,
                delegatee=agent_name,
                max_per_transaction=self.default_max_per_tx,
                max_daily=self.default_daily_limit,
                max_monthly=self.default_monthly_limit,
                allowed_vendors=self.allowed_vendors,
                allowed_actions=self.allowed_actions,
                denied_actions=self.denied_actions,
            )
            self._registered_agents.add(agent_name)
            logger.info(f"Spendpol: Registered agent '{agent_name}' with default grant")

    def register_agent(
        self,
        agent_name: str,
        max_per_transaction: Optional[float] = None,
        max_daily: Optional[float] = None,
        max_monthly: Optional[float] = None,
        allowed_vendors: Optional[list[str]] = None,
        allowed_actions: Optional[list[str]] = None,
    ):
        """Explicitly register an agent with custom limits."""
        self.client.grant(
            delegator=self.delegator,
            delegatee=agent_name,
            max_per_transaction=max_per_transaction or self.default_max_per_tx,
            max_daily=max_daily or self.default_daily_limit,
            max_monthly=max_monthly or self.default_monthly_limit,
            allowed_vendors=allowed_vendors or self.allowed_vendors,
            allowed_actions=allowed_actions or self.allowed_actions,
            denied_actions=self.denied_actions,
        )
        self._registered_agents.add(agent_name)

    # ── Core spend control ────────────────────────────────────────────

    def before_tool_call(
        self,
        agent_name: str,
        vendor: str,
        action: str,
        estimated_cost: float,
        purpose: str,
        confidence: str = "medium",
        task_id: Optional[str] = None,
    ) -> PolicyVerdict:
        """
        Call before executing a paid tool.
        Returns PolicyVerdict — check .allowed before proceeding.
        """
        self._ensure_agent(agent_name)

        verdict = self.client.check_intent(
            agent_id=agent_name,
            vendor=vendor,
            action=action,
            amount=estimated_cost,
            purpose=purpose,
            confidence=confidence,
            task_id=task_id,
        )

        if verdict.denied:
            deny_reason = next(
                (e.detail for e in verdict.evaluations if e.result.value == "fail"),
                "Unknown reason"
            )
            logger.warning(f"Spendpol DENY: {agent_name} → {vendor}/{action} — {deny_reason}")

        if verdict.escalated:
            logger.info(f"Spendpol ESCALATE: {agent_name} → {vendor}/{action}")

        return verdict

    def after_tool_call(
        self,
        verdict: PolicyVerdict,
        actual_cost: float,
        payment_reference: Optional[str] = None,
    ):
        """Call after a successful paid tool execution."""
        self.client.log_receipt(
            verdict=verdict,
            actual_amount=actual_cost,
            payment_reference=payment_reference,
        )

    # ── Decorator ─────────────────────────────────────────────────────

    def controlled(
        self,
        vendor: str,
        action: str,
        cost_per_call: float,
        agent_name: str = "default-agent",
        confidence: str = "medium",
    ):
        """
        Decorator that wraps a function with Spendpol spending control.

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.03)
        def my_tool(text: str) -> str:
            return openai_call(text)
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                purpose = f"{func.__name__}({', '.join(str(a)[:50] for a in args)})"

                verdict = self.before_tool_call(
                    agent_name=agent_name,
                    vendor=vendor,
                    action=action,
                    estimated_cost=cost_per_call,
                    purpose=purpose,
                    confidence=confidence,
                )

                if verdict.denied:
                    return self._handle_deny(func.__name__, verdict)

                if verdict.escalated:
                    return self._handle_escalate(func.__name__, verdict)

                # Execute the actual tool
                try:
                    result = func(*args, **kwargs)
                    self.after_tool_call(verdict, actual_cost=cost_per_call)
                    return result
                except Exception as e:
                    # Log failed receipt
                    self.client.log_receipt(
                        verdict=verdict,
                        actual_amount=0.0,
                        status="failed",
                    )
                    raise

            wrapper._asp_controlled = True
            wrapper._asp_vendor = vendor
            wrapper._asp_action = action
            return wrapper
        return decorator

    def _handle_deny(self, func_name: str, verdict: PolicyVerdict):
        if self.on_deny == "raise":
            reason = next(
                (e.detail for e in verdict.evaluations if e.result.value == "fail"),
                "Spending denied"
            )
            raise SpendingDeniedError(f"Spendpol denied {func_name}: {reason}")
        elif self.on_deny == "skip":
            logger.warning(f"Spendpol: Skipping {func_name} (denied)")
            return None
        else:  # log
            logger.warning(f"Spendpol: {func_name} denied but continuing (log mode)")
            return None

    def _handle_escalate(self, func_name: str, verdict: PolicyVerdict):
        if self.on_escalate == "raise":
            raise SpendingEscalatedError(f"Spendpol escalated {func_name}: needs human approval")
        else:  # skip
            logger.info(f"Spendpol: Skipping {func_name} (escalated, needs approval)")
            return None

    # ── AutoGen convenience ───────────────────────────────────────────

    def register_controlled_tool(
        self,
        agent: Any,
        user_proxy: Any,
        func: Callable,
        vendor: str,
        action: str,
        cost_per_call: float,
        name: Optional[str] = None,
        description: Optional[str] = None,
        agent_name: str = "default-agent",
        confidence: str = "medium",
    ) -> Callable:
        """
        Wrap a function with spending control AND register it with AutoGen agents.

        This is a convenience that does three things:
        1. Wraps func with controlled() decorator
        2. Calls agent.register_for_llm(name, description)(wrapped)
        3. Calls user_proxy.register_for_execution(name)(wrapped)

        Args:
            agent: AutoGen ConversableAgent (the LLM agent)
            user_proxy: AutoGen UserProxyAgent (the execution agent)
            func: The tool function to wrap
            vendor: Vendor identifier for spending tracking
            action: Action identifier for spending tracking
            cost_per_call: Estimated cost per invocation
            name: Tool name (defaults to func.__name__)
            description: Tool description (defaults to func.__doc__)
            agent_name: Agent name for spending tracking
            confidence: Cost confidence level

        Returns:
            The wrapped (controlled) function
        """
        tool_name = name or func.__name__
        tool_description = description or func.__doc__ or f"Tool: {tool_name}"

        # Step 1: Wrap with controlled decorator
        wrapped = self.controlled(
            vendor=vendor,
            action=action,
            cost_per_call=cost_per_call,
            agent_name=agent_name,
            confidence=confidence,
        )(func)

        # Step 2: Register for LLM (tool schema)
        agent.register_for_llm(name=tool_name, description=tool_description)(wrapped)

        # Step 3: Register for execution
        user_proxy.register_for_execution(name=tool_name)(wrapped)

        return wrapped

    # ── Reporting ─────────────────────────────────────────────────────

    def spending_report(self, agent_name: Optional[str] = None) -> dict:
        """Get spending report for an agent or all agents."""
        if agent_name:
            return self.client.agent_summary(agent_name)
        return self.client.audit_summary()

    def get_all_agents(self) -> list[str]:
        return list(self._registered_agents)


class SpendingDeniedError(Exception):
    """Raised when Spendpol denies a spending request."""
    pass


class SpendingEscalatedError(Exception):
    """Raised when Spendpol escalates a spending request for human approval."""
    pass
