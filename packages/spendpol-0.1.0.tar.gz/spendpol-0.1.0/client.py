"""
ASP Protocol — Client SDK
===========================
The primary integration point for agent frameworks.
This is what CrewAI/LangGraph/AutoGen would import.

Usage:
    from spendpol import ASPClient

    client = ASPClient()
    client.grant("user:john@acme.com", "agent-47x", max_daily=10.0)

    verdict = client.check_intent(
        agent_id="agent-47x",
        vendor="openai",
        action="api_call",
        amount=0.03,
        purpose="Embedding generation"
    )

    if verdict.allowed:
        # ... execute payment ...
        client.log_receipt(verdict, actual_amount=0.028)
"""

from __future__ import annotations
from typing import Optional, Callable
from .schemas import (
    SpendIntent, PolicyVerdict, SpendReceipt, AuditQuery,
    DelegationGrant, CostEstimate, RuleResult,
    Decision, SpendStatus, Confidence, CostBasis, AuditRole,
    _gen_id,
)
from .delegation import DelegationRegistry
from .wallet import WalletRegistry
from .policy import PolicyEngine, ConditionalRule
from .audit import AuditLog, AuditRecord
from .validator import Validator, ValidationError


class ASPError(Exception):
    pass


class ASPClient:
    """
    High-level ASP client for agent framework integration.

    Wraps all protocol components into a simple API:
    - grant()        → Create delegation grants
    - check_intent() → Evaluate spending intents
    - log_receipt()  → Record completed payments
    - audit()        → Query audit history
    - revoke()       → Revoke delegation grants
    """

    def __init__(
        self,
        anomaly_sigma: float = 3.0,
        verdict_ttl_seconds: int = 60,
        policy_version: str = "1",
    ):
        self.delegations = DelegationRegistry()
        self.wallets = WalletRegistry()
        self.audit_log = AuditLog()
        self.engine = PolicyEngine(
            delegation_registry=self.delegations,
            wallet_registry=self.wallets,
            anomaly_sigma=anomaly_sigma,
            verdict_ttl_seconds=verdict_ttl_seconds,
            policy_version=policy_version,
        )
        self._pending_verdicts: dict[str, tuple[SpendIntent, PolicyVerdict]] = {}

    # ── Delegation ────────────────────────────────────────────────────

    def grant(
        self,
        delegator: str,
        delegatee: str,
        max_per_transaction: float = 1.0,
        max_daily: float = 10.0,
        max_monthly: float = 200.0,
        allowed_vendors: Optional[list[str]] = None,
        allowed_actions: Optional[list[str]] = None,
        denied_actions: Optional[list[str]] = None,
        valid_until: Optional[str] = None,
    ) -> DelegationGrant:
        """Create and register a delegation grant."""
        g = DelegationGrant(
            delegator=delegator,
            delegatee=delegatee,
            max_per_transaction=max_per_transaction,
            max_daily=max_daily,
            max_monthly=max_monthly,
            allowed_vendors=allowed_vendors or [],
            allowed_actions=allowed_actions or [],
            denied_actions=denied_actions or [],
            valid_until=valid_until,
        )

        # Validate
        errors = Validator.validate_grant(g)
        if errors:
            raise ASPError(f"Invalid grant: {errors[0].message}")

        return self.delegations.register(g)

    def revoke(self, grant_id: str) -> list[str]:
        """Revoke a grant and cascade to sub-grants."""
        revoked = self.delegations.revoke(grant_id)
        # Auto-deny any pending verdicts for revoked agents
        self._handle_revocation_pending(revoked)
        return revoked

    def _handle_revocation_pending(self, revoked_grant_ids: list[str]):
        """Auto-deny pending intents from revoked grants."""
        revoked_agents = set()
        for gid in revoked_grant_ids:
            grants = self.delegations.list_grants()
            for g in grants:
                if g.grant_id == gid:
                    revoked_agents.add(g.delegatee)

        to_remove = []
        for intent_id, (intent, verdict) in self._pending_verdicts.items():
            if intent.agent_id in revoked_agents:
                to_remove.append(intent_id)

        for intent_id in to_remove:
            del self._pending_verdicts[intent_id]

    # ── Spend Control ─────────────────────────────────────────────────

    def check_intent(
        self,
        agent_id: str,
        vendor: str,
        action: str,
        amount: float,
        purpose: str,
        currency: str = "USD",
        confidence: str = "medium",
        basis: str = "heuristic",
        endpoint: Optional[str] = None,
        task_id: Optional[str] = None,
        parent_intent_id: Optional[str] = None,
    ) -> PolicyVerdict:
        """
        Check whether an agent is allowed to make a spend.
        Returns a PolicyVerdict with the decision.
        """
        # Build cost estimate
        cost = CostEstimate(
            amount=amount,
            currency=currency,
            confidence=Confidence(confidence),
            basis=CostBasis(basis),
        )

        # Build delegation chain
        chain = self.delegations.get_delegation_chain(agent_id)

        # Build intent
        intent = SpendIntent(
            agent_id=agent_id,
            vendor=vendor,
            action=action,
            cost_estimate=cost,
            purpose=purpose,
            delegation_chain=chain,
            endpoint=endpoint,
            task_id=task_id,
            parent_intent_id=parent_intent_id,
        )

        # Validate
        errors = Validator.validate_intent(intent)
        if errors:
            raise ASPError(f"Invalid intent: {errors[0].message}")

        # Evaluate
        verdict = self.engine.evaluate(intent)

        # Record in audit log
        self.audit_log.record(intent, verdict)

        # Track pending if allowed
        if verdict.allowed:
            self._pending_verdicts[intent.intent_id] = (intent, verdict)

        return verdict

    def log_receipt(
        self,
        verdict: PolicyVerdict,
        actual_amount: float,
        currency: str = "USD",
        payment_reference: Optional[str] = None,
        vendor_receipt: Optional[str] = None,
        status: str = "completed",
    ) -> SpendReceipt:
        """
        Log a completed payment receipt against a verdict.
        """
        # Get the original intent
        pending = self._pending_verdicts.get(verdict.intent_id)
        estimated = None
        vendor = "unknown"
        if pending:
            intent, _ = pending
            estimated = intent.cost_estimate.amount
            vendor = intent.vendor
            del self._pending_verdicts[verdict.intent_id]

        receipt = SpendReceipt(
            intent_id=verdict.intent_id,
            verdict_id=verdict.verdict_id,
            status=SpendStatus(status),
            actual_amount=actual_amount,
            currency=currency,
            payment_reference=payment_reference,
            vendor_receipt=vendor_receipt,
            estimated_amount=estimated,
        )

        # Validate
        errors = Validator.validate_receipt(receipt)
        if errors:
            raise ASPError(f"Invalid receipt: {errors[0].message}")

        # Update wallet
        wallet = self.wallets.get_or_create(
            pending[0].agent_id if pending else "unknown"
        )
        wallet.record_spend(receipt, vendor)

        # Attach to audit log
        self.audit_log.attach_receipt(verdict.intent_id, receipt)

        return receipt

    # ── Audit ─────────────────────────────────────────────────────────

    def audit(
        self,
        querier_id: str,
        role: str = "internal_auditor",
        agent_id: Optional[str] = None,
        vendor: Optional[str] = None,
        time_from: Optional[str] = None,
        time_to: Optional[str] = None,
        min_amount: Optional[float] = None,
        max_amount: Optional[float] = None,
    ) -> list[AuditRecord]:
        """Execute an audit query."""
        query = AuditQuery(
            querier_id=querier_id,
            querier_role=AuditRole(role),
            agent_id=agent_id,
            vendor=vendor,
            time_from=time_from,
            time_to=time_to,
            min_amount=min_amount,
            max_amount=max_amount,
        )
        return self.audit_log.query(query)

    # ── Custom Rules ──────────────────────────────────────────────────

    def add_rule(
        self,
        rule_id: str,
        rule_name: str,
        evaluate_fn: Callable,
    ):
        """Register a custom conditional rule."""
        rule = ConditionalRule(
            rule_id=rule_id,
            rule_name=rule_name,
            evaluate=evaluate_fn,
        )
        self.engine.register_rule(rule)

    # ── Info ──────────────────────────────────────────────────────────

    def agent_summary(self, agent_id: str) -> dict:
        """Get spending summary for an agent."""
        wallet = self.wallets.get(agent_id)
        if wallet:
            return wallet.summary()
        return {"agent_id": agent_id, "status": "no activity"}

    def audit_summary(self) -> dict:
        """Get overall audit log summary."""
        return self.audit_log.summary()
