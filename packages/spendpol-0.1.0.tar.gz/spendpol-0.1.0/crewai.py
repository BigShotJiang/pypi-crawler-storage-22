"""
Spendpol × CrewAI Integration
==========================
Spending control middleware for CrewAI agent frameworks.

Usage:
    from spendpol.integrations.crewai import SpendpolCrewMiddleware

    asp = SpendpolCrewMiddleware(
        delegator="user:john@acme.com",
        default_daily_limit=10.0,
    )

    # Wrap a CrewAI tool with spending control
    @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.03)
    def embedding_tool(text: str) -> list[float]:
        return openai.embeddings.create(input=text, model="text-embedding-3-small")

    # Or use manually in a CrewAI task callback
    verdict = asp.before_tool_call(
        agent_name="researcher",
        vendor="openai",
        action="api_call",
        estimated_cost=0.03,
        purpose="Generate embeddings for research task",
    )
    if verdict.allowed:
        result = execute_tool()
        asp.after_tool_call(verdict, actual_cost=0.028)
"""

from __future__ import annotations
from functools import wraps
from typing import Optional, Callable, Any
import logging

from spendpol import (
    SpendpolClient,
    PolicyVerdict,
    Decision,
)

logger = logging.getLogger("spendpol.crewai")


class SpendpolCrewMiddleware:
    """
    Middleware that wraps CrewAI tool calls with Spendpol spending control.

    Automatically:
    - Registers agents on first spend
    - Checks spending intent before each tool call
    - Logs receipts after successful calls
    - Blocks calls that exceed policy
    """

    def __init__(
        self,
        delegator: str = "system:crewai",
        default_max_per_tx: float = 1.0,
        default_daily_limit: float = 10.0,
        default_monthly_limit: float = 200.0,
        allowed_vendors: Optional[list[str]] = None,
        allowed_actions: Optional[list[str]] = None,
        denied_actions: Optional[list[str]] = None,
        on_deny: str = "raise",  # "raise", "skip", "log"
        on_escalate: str = "skip",
        anomaly_sigma: float = 3.0,
    ):
        self.delegator = delegator
        self.default_max_per_tx = default_max_per_tx
        self.default_daily_limit = default_daily_limit
        self.default_monthly_limit = default_monthly_limit
        self.allowed_vendors = allowed_vendors or []
        self.allowed_actions = allowed_actions or []
        self.denied_actions = denied_actions or []
        self.on_deny = on_deny
        self.on_escalate = on_escalate

        self.client = SpendpolClient(anomaly_sigma=anomaly_sigma)
        self._registered_agents: set[str] = set()

    def _ensure_agent(self, agent_name: str):
        """Auto-register agent with default grant if not already registered."""
        if agent_name not in self._registered_agents:
            self.client.grant(
                delegator=self.delegator,
                delegatee=agent_name,
                max_per_transaction=self.default_max_per_tx,
                max_daily=self.default_daily_limit,
                max_monthly=self.default_monthly_limit,
                allowed_vendors=self.allowed_vendors,
                allowed_actions=self.allowed_actions,
                denied_actions=self.denied_actions,
            )
            self._registered_agents.add(agent_name)
            logger.info(f"Spendpol: Registered agent '{agent_name}' with default grant")

    def register_agent(
        self,
        agent_name: str,
        max_per_transaction: Optional[float] = None,
        max_daily: Optional[float] = None,
        max_monthly: Optional[float] = None,
        allowed_vendors: Optional[list[str]] = None,
        allowed_actions: Optional[list[str]] = None,
    ):
        """Explicitly register an agent with custom limits."""
        self.client.grant(
            delegator=self.delegator,
            delegatee=agent_name,
            max_per_transaction=max_per_transaction or self.default_max_per_tx,
            max_daily=max_daily or self.default_daily_limit,
            max_monthly=max_monthly or self.default_monthly_limit,
            allowed_vendors=allowed_vendors or self.allowed_vendors,
            allowed_actions=allowed_actions or self.allowed_actions,
            denied_actions=self.denied_actions,
        )
        self._registered_agents.add(agent_name)

    # ── Core spend control ────────────────────────────────────────────

    def before_tool_call(
        self,
        agent_name: str,
        vendor: str,
        action: str,
        estimated_cost: float,
        purpose: str,
        confidence: str = "medium",
        task_id: Optional[str] = None,
    ) -> PolicyVerdict:
        """
        Call before executing a paid tool.
        Returns PolicyVerdict — check .allowed before proceeding.
        """
        self._ensure_agent(agent_name)

        verdict = self.client.check_intent(
            agent_id=agent_name,
            vendor=vendor,
            action=action,
            amount=estimated_cost,
            purpose=purpose,
            confidence=confidence,
            task_id=task_id,
        )

        if verdict.denied:
            deny_reason = next(
                (e.detail for e in verdict.evaluations if e.result.value == "fail"),
                "Unknown reason"
            )
            logger.warning(f"Spendpol DENY: {agent_name} → {vendor}/{action} — {deny_reason}")

        if verdict.escalated:
            logger.info(f"Spendpol ESCALATE: {agent_name} → {vendor}/{action}")

        return verdict

    def after_tool_call(
        self,
        verdict: PolicyVerdict,
        actual_cost: float,
        payment_reference: Optional[str] = None,
    ):
        """Call after a successful paid tool execution."""
        self.client.log_receipt(
            verdict=verdict,
            actual_amount=actual_cost,
            payment_reference=payment_reference,
        )

    # ── Decorator ─────────────────────────────────────────────────────

    def controlled(
        self,
        vendor: str,
        action: str,
        cost_per_call: float,
        agent_name: str = "default-agent",
        confidence: str = "medium",
    ):
        """
        Decorator that wraps a function with Spendpol spending control.

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.03)
        def my_tool(text: str) -> str:
            return openai_call(text)
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> Any:
                purpose = f"{func.__name__}({', '.join(str(a)[:50] for a in args)})"

                verdict = self.before_tool_call(
                    agent_name=agent_name,
                    vendor=vendor,
                    action=action,
                    estimated_cost=cost_per_call,
                    purpose=purpose,
                    confidence=confidence,
                )

                if verdict.denied:
                    return self._handle_deny(func.__name__, verdict)

                if verdict.escalated:
                    return self._handle_escalate(func.__name__, verdict)

                # Execute the actual tool
                try:
                    result = func(*args, **kwargs)
                    self.after_tool_call(verdict, actual_cost=cost_per_call)
                    return result
                except Exception as e:
                    # Log failed receipt
                    self.client.log_receipt(
                        verdict=verdict,
                        actual_amount=0.0,
                        status="failed",
                    )
                    raise

            wrapper._asp_controlled = True
            wrapper._asp_vendor = vendor
            wrapper._asp_action = action
            return wrapper
        return decorator

    def _handle_deny(self, func_name: str, verdict: PolicyVerdict):
        if self.on_deny == "raise":
            reason = next(
                (e.detail for e in verdict.evaluations if e.result.value == "fail"),
                "Spending denied"
            )
            raise SpendingDeniedError(f"Spendpol denied {func_name}: {reason}")
        elif self.on_deny == "skip":
            logger.warning(f"Spendpol: Skipping {func_name} (denied)")
            return None
        else:  # log
            logger.warning(f"Spendpol: {func_name} denied but continuing (log mode)")
            return None

    def _handle_escalate(self, func_name: str, verdict: PolicyVerdict):
        if self.on_escalate == "raise":
            raise SpendingEscalatedError(f"Spendpol escalated {func_name}: needs human approval")
        else:  # skip
            logger.info(f"Spendpol: Skipping {func_name} (escalated, needs approval)")
            return None

    # ── Reporting ─────────────────────────────────────────────────────

    def spending_report(self, agent_name: Optional[str] = None) -> dict:
        """Get spending report for an agent or all agents."""
        if agent_name:
            return self.client.agent_summary(agent_name)
        return self.client.audit_summary()

    def get_all_agents(self) -> list[str]:
        return list(self._registered_agents)


class SpendingDeniedError(Exception):
    """Raised when ASP denies a spending request."""
    pass


class SpendingEscalatedError(Exception):
    """Raised when ASP escalates a spending request for human approval."""
    pass
