"""
ASP Protocol — Delegation Registry
====================================
Hierarchical grant management with attenuation enforcement and cascading revocation.
"""

from __future__ import annotations


class DelegationError(Exception):
    pass


class DelegationRegistry:
    def __init__(self):
        self._grants: dict[str, object] = {}  # grant_id -> DelegationGrant
        self._revoked: set[str] = set()
        self._by_delegatee: dict[str, str] = {}  # delegatee -> grant_id

    def register(self, grant) -> object:
        # Check attenuation: if the delegator has an active grant, child must not exceed it
        parent_grant = self.get_active_grant(grant.delegator)
        if parent_grant is not None:
            self._check_attenuation(parent_grant, grant)

        self._grants[grant.grant_id] = grant
        self._by_delegatee[grant.delegatee] = grant.grant_id
        return grant

    def _check_attenuation(self, parent, child):
        # Limits must not exceed parent
        if child.max_per_transaction > parent.max_per_transaction:
            raise DelegationError(
                f"Attenuation violation: max_per_transaction {child.max_per_transaction} "
                f"exceeds parent's {parent.max_per_transaction}"
            )
        if child.max_daily > parent.max_daily:
            raise DelegationError(
                f"Attenuation violation: max_daily {child.max_daily} "
                f"exceeds parent's {parent.max_daily}"
            )
        if child.max_monthly > parent.max_monthly:
            raise DelegationError(
                f"Attenuation violation: max_monthly {child.max_monthly} "
                f"exceeds parent's {parent.max_monthly}"
            )

        # If parent has allowed_vendors, child's must be a subset
        if parent.allowed_vendors and child.allowed_vendors:
            parent_set = set(parent.allowed_vendors)
            child_set = set(child.allowed_vendors)
            if not child_set.issubset(parent_set):
                extra = child_set - parent_set
                raise DelegationError(
                    f"Attenuation violation: vendors {extra} not in parent's allowed list"
                )

        # If parent has allowed_vendors but child has none (meaning all), that's a widening
        if parent.allowed_vendors and not child.allowed_vendors:
            raise DelegationError(
                "Attenuation violation: child must restrict vendors when parent does"
            )

    def get_active_grant(self, delegatee: str):
        grant_id = self._by_delegatee.get(delegatee)
        if grant_id is None:
            return None
        if grant_id in self._revoked:
            return None
        return self._grants.get(grant_id)

    def revoke(self, grant_id: str) -> list[str]:
        revoked = []
        self._revoke_recursive(grant_id, revoked)
        return revoked

    def _revoke_recursive(self, grant_id: str, revoked: list[str]):
        if grant_id in self._revoked:
            return
        self._revoked.add(grant_id)
        revoked.append(grant_id)

        # Find the delegatee of this grant
        grant = self._grants.get(grant_id)
        if grant is None:
            return

        # Find all grants where the delegator is this grant's delegatee (downstream)
        for gid, g in self._grants.items():
            if g.delegator == grant.delegatee and gid not in self._revoked:
                self._revoke_recursive(gid, revoked)

    def get_delegation_chain(self, delegatee: str) -> list[str]:
        chain = [delegatee]
        current = delegatee
        visited = set()

        while current not in visited:
            visited.add(current)
            grant = self.get_active_grant(current)
            if grant is None:
                break
            chain.append(grant.delegator)
            current = grant.delegator

        chain.reverse()
        return chain

    def list_grants(self) -> list:
        return list(self._grants.values())
