"""
Spendpol × LangGraph Integration
=================================
Spending control middleware for LangGraph agent frameworks.

Usage:
    from spendpol.langgraph import SpendpolLangGraphMiddleware, asp_tool

    asp = SpendpolLangGraphMiddleware(
        delegator="user:john@acme.com",
        default_daily_limit=10.0,
    )

    # Annotate tools with spending metadata
    @asp_tool(vendor="openai", action="api_call", cost_per_call=0.03)
    def embedding_tool(text: str) -> list[float]:
        return openai.embeddings.create(input=text, model="text-embedding-3-small")

    # Create a ToolNode with spending control baked in
    tool_node = asp.create_tool_node([embedding_tool], agent_name="researcher")

    # Or use the wrap_tool_call function directly with ToolNode
    from langgraph.prebuilt import ToolNode
    tool_node = ToolNode(tools, handle_tool_call=asp.wrap_tool_call)
"""

from __future__ import annotations
from typing import Optional, Any
import logging

from spendpol import (
    SpendpolClient,
    PolicyVerdict,
    Decision,
)

logger = logging.getLogger("spendpol.langgraph")


def asp_tool(vendor: str, action: str, cost_per_call: float, confidence: str = "medium"):
    """
    Annotate a LangGraph tool with spending metadata.

    @asp_tool(vendor="openai", action="api_call", cost_per_call=0.03)
    def my_tool(text: str) -> str:
        ...
    """
    def decorator(func):
        func._asp_vendor = vendor
        func._asp_action = action
        func._asp_cost = cost_per_call
        func._asp_confidence = confidence
        func._asp_controlled = True
        return func
    return decorator


class SpendingDeniedError(Exception):
    """Raised when Spendpol denies a spending request."""
    pass


class SpendingEscalatedError(Exception):
    """Raised when Spendpol escalates a spending request for human approval."""
    pass


class SpendpolLangGraphMiddleware:
    """
    Middleware that wraps LangGraph tool calls with Spendpol spending control.

    Automatically:
    - Registers agents on first spend
    - Checks spending intent before each tool call
    - Logs receipts after successful calls
    - Blocks calls that exceed policy, returning a ToolMessage with denial info
    """

    def __init__(
        self,
        delegator: str = "system:langgraph",
        default_max_per_tx: float = 1.0,
        default_daily_limit: float = 10.0,
        default_monthly_limit: float = 200.0,
        allowed_vendors: Optional[list[str]] = None,
        allowed_actions: Optional[list[str]] = None,
        denied_actions: Optional[list[str]] = None,
        on_deny: str = "message",  # "raise" or "message"
        on_escalate: str = "message",
        anomaly_sigma: float = 3.0,
    ):
        self.delegator = delegator
        self.default_max_per_tx = default_max_per_tx
        self.default_daily_limit = default_daily_limit
        self.default_monthly_limit = default_monthly_limit
        self.allowed_vendors = allowed_vendors or []
        self.allowed_actions = allowed_actions or []
        self.denied_actions = denied_actions or []
        self.on_deny = on_deny
        self.on_escalate = on_escalate

        self.client = SpendpolClient(anomaly_sigma=anomaly_sigma)
        self._registered_agents: set[str] = set()
        self._default_agent_name = "default-agent"

    def _ensure_agent(self, agent_name: str):
        """Auto-register agent with default grant if not already registered."""
        if agent_name not in self._registered_agents:
            self.client.grant(
                delegator=self.delegator,
                delegatee=agent_name,
                max_per_transaction=self.default_max_per_tx,
                max_daily=self.default_daily_limit,
                max_monthly=self.default_monthly_limit,
                allowed_vendors=self.allowed_vendors,
                allowed_actions=self.allowed_actions,
                denied_actions=self.denied_actions,
            )
            self._registered_agents.add(agent_name)
            logger.info(f"Spendpol: Registered agent '{agent_name}' with default grant")

    def register_agent(
        self,
        agent_name: str,
        max_per_transaction: Optional[float] = None,
        max_daily: Optional[float] = None,
        max_monthly: Optional[float] = None,
        allowed_vendors: Optional[list[str]] = None,
        allowed_actions: Optional[list[str]] = None,
    ):
        """Explicitly register an agent with custom limits."""
        self.client.grant(
            delegator=self.delegator,
            delegatee=agent_name,
            max_per_transaction=max_per_transaction or self.default_max_per_tx,
            max_daily=max_daily or self.default_daily_limit,
            max_monthly=max_monthly or self.default_monthly_limit,
            allowed_vendors=allowed_vendors or self.allowed_vendors,
            allowed_actions=allowed_actions or self.allowed_actions,
            denied_actions=self.denied_actions,
        )
        self._registered_agents.add(agent_name)

    # ── Core spend control ────────────────────────────────────────────

    def before_tool_call(
        self,
        agent_name: str,
        vendor: str,
        action: str,
        estimated_cost: float,
        purpose: str,
        confidence: str = "medium",
        task_id: Optional[str] = None,
    ) -> PolicyVerdict:
        """
        Call before executing a paid tool.
        Returns PolicyVerdict — check .allowed before proceeding.
        """
        self._ensure_agent(agent_name)

        verdict = self.client.check_intent(
            agent_id=agent_name,
            vendor=vendor,
            action=action,
            amount=estimated_cost,
            purpose=purpose,
            confidence=confidence,
            task_id=task_id,
        )

        if verdict.denied:
            deny_reason = next(
                (e.detail for e in verdict.evaluations if e.result.value == "fail"),
                "Unknown reason",
            )
            logger.warning(f"Spendpol DENY: {agent_name} → {vendor}/{action} — {deny_reason}")

        if verdict.escalated:
            logger.info(f"Spendpol ESCALATE: {agent_name} → {vendor}/{action}")

        return verdict

    def after_tool_call(
        self,
        verdict: PolicyVerdict,
        actual_cost: float,
        payment_reference: Optional[str] = None,
    ):
        """Call after a successful paid tool execution."""
        self.client.log_receipt(
            verdict=verdict,
            actual_amount=actual_cost,
            payment_reference=payment_reference,
        )

    # ── LangGraph wrap_tool_call ──────────────────────────────────────

    def wrap_tool_call(self, request: Any, handler: Any) -> Any:
        """
        A wrap_tool_call compatible function for LangGraph's ToolNode.

        Reads tool metadata (_asp_vendor, _asp_action, _asp_cost) from the tool.
        If the tool has no ASP metadata, it executes uncontrolled.
        If denied, returns a ToolMessage with the denial reason.
        """
        # Extract tool metadata from the request's tool or the handler
        tool = getattr(request, "tool", None) or getattr(handler, "tool", None)
        tool_func = None
        if tool is not None:
            # LangGraph tools may wrap the actual function
            tool_func = getattr(tool, "func", tool)

        has_metadata = (
            tool_func is not None
            and getattr(tool_func, "_asp_controlled", False)
        )

        if not has_metadata:
            # No ASP metadata — execute uncontrolled
            return handler(request)

        vendor = getattr(tool_func, "_asp_vendor", "unknown")
        action = getattr(tool_func, "_asp_action", "unknown")
        cost = getattr(tool_func, "_asp_cost", 0.0)
        confidence = getattr(tool_func, "_asp_confidence", "medium")

        tool_name = getattr(tool_func, "__name__", "unknown_tool")
        agent_name = getattr(request, "agent_name", self._default_agent_name)

        purpose = f"langgraph:{tool_name}"

        verdict = self.before_tool_call(
            agent_name=agent_name,
            vendor=vendor,
            action=action,
            estimated_cost=cost,
            purpose=purpose,
            confidence=confidence,
        )

        if verdict.denied:
            return self._handle_deny_message(request, verdict, tool_name)

        if verdict.escalated:
            return self._handle_escalate_message(request, verdict, tool_name)

        # Execute the actual tool
        try:
            result = handler(request)
            self.after_tool_call(verdict, actual_cost=cost)
            return result
        except Exception:
            # Log failed receipt
            self.client.log_receipt(
                verdict=verdict,
                actual_amount=0.0,
                status="failed",
            )
            raise

    def _deny_reason(self, verdict: PolicyVerdict) -> str:
        return next(
            (e.detail for e in verdict.evaluations if e.result.value == "fail"),
            "Spending denied",
        )

    def _handle_deny_message(self, request: Any, verdict: PolicyVerdict, tool_name: str) -> Any:
        reason = self._deny_reason(verdict)
        if self.on_deny == "raise":
            raise SpendingDeniedError(f"Spendpol denied {tool_name}: {reason}")
        # Return a ToolMessage-like dict with denial info
        return _make_tool_message(
            tool_call_id=getattr(request, "id", "unknown"),
            content=f"[SPENDPOL DENIED] {tool_name}: {reason}",
        )

    def _handle_escalate_message(self, request: Any, verdict: PolicyVerdict, tool_name: str) -> Any:
        if self.on_escalate == "raise":
            raise SpendingEscalatedError(
                f"Spendpol escalated {tool_name}: needs human approval"
            )
        return _make_tool_message(
            tool_call_id=getattr(request, "id", "unknown"),
            content=f"[SPENDPOL ESCALATED] {tool_name}: needs human approval",
        )

    # ── ToolNode helper ───────────────────────────────────────────────

    def create_tool_node(self, tools: list, agent_name: str = "default-agent", **kwargs) -> Any:
        """
        Create a LangGraph ToolNode with spending control baked in.

        Requires langgraph to be installed.

        Args:
            tools: List of tool functions (optionally decorated with @asp_tool)
            agent_name: Agent name for spending tracking
            **kwargs: Additional kwargs passed to ToolNode constructor
        """
        try:
            from langgraph.prebuilt import ToolNode
        except ImportError:
            raise ImportError(
                "langgraph is required for create_tool_node(). "
                "Install it with: pip install langgraph"
            )

        self._default_agent_name = agent_name
        return ToolNode(tools, handle_tool_call=self.wrap_tool_call, **kwargs)

    # ── Reporting ─────────────────────────────────────────────────────

    def spending_report(self, agent_name: Optional[str] = None) -> dict:
        """Get spending report for an agent or all agents."""
        if agent_name:
            return self.client.agent_summary(agent_name)
        return self.client.audit_summary()

    def get_all_agents(self) -> list[str]:
        return list(self._registered_agents)


def _make_tool_message(tool_call_id: str, content: str) -> dict:
    """
    Create a ToolMessage-compatible dict.

    We return a plain dict so we don't require langgraph as a dependency.
    LangGraph's ToolNode will accept this format.
    """
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": content,
    }
