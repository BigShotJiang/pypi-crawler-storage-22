"""
ASP Protocol — Policy Engine
==============================
Deterministic rule evaluation: delegation → denylist → allowlist → limits → anomaly → custom rules.
"""

from __future__ import annotations

from datetime import datetime, timezone, timedelta

from .schemas import (
    Decision,
    RuleResult,
    RuleEvaluation,
    PolicyVerdict,
    _gen_id,
)


class ConditionalRule:
    def __init__(self, rule_id: str, rule_name: str, evaluate):
        self.rule_id = rule_id
        self.rule_name = rule_name
        self.evaluate = evaluate


class PolicyEngine:
    def __init__(
        self,
        delegation_registry,
        wallet_registry,
        anomaly_sigma: float = 3.0,
        verdict_ttl_seconds: int = 60,
        policy_version: str = "1",
    ):
        self.delegation_registry = delegation_registry
        self.wallet_registry = wallet_registry
        self.anomaly_sigma = anomaly_sigma
        self.verdict_ttl_seconds = verdict_ttl_seconds
        self.policy_version = policy_version
        self._custom_rules: list[ConditionalRule] = []

    def register_rule(self, rule: ConditionalRule):
        self._custom_rules.append(rule)

    def evaluate(self, intent) -> PolicyVerdict:
        evaluations: list[RuleEvaluation] = []
        decision = Decision.ALLOW

        # 1. Delegation check
        grant = self.delegation_registry.get_active_grant(intent.agent_id)
        if grant is None:
            evaluations.append(RuleEvaluation(
                rule_id="delegation_check",
                rule_name="delegation_check",
                result=RuleResult.FAIL,
                detail=f"No active delegation grant for agent '{intent.agent_id}'",
            ))
            decision = Decision.DENY
        else:
            evaluations.append(RuleEvaluation(
                rule_id="delegation_check",
                rule_name="delegation_check",
                result=RuleResult.PASS,
                detail=f"Active grant {grant.grant_id} from {grant.delegator}",
            ))

            # 2. Denylist check
            if grant.denied_actions and intent.action in grant.denied_actions:
                evaluations.append(RuleEvaluation(
                    rule_id="denylist",
                    rule_name="denylist",
                    result=RuleResult.FAIL,
                    detail=f"Action '{intent.action}' is in the deny list",
                ))
                decision = Decision.DENY
            else:
                evaluations.append(RuleEvaluation(
                    rule_id="denylist",
                    rule_name="denylist",
                    result=RuleResult.PASS,
                    detail="Action not in deny list",
                ))

            # 3. Allowlist check
            if decision != Decision.DENY:
                # Vendor allowlist (empty = all allowed)
                if grant.allowed_vendors and intent.vendor not in grant.allowed_vendors:
                    evaluations.append(RuleEvaluation(
                        rule_id="allowlist_vendor",
                        rule_name="allowlist_vendor",
                        result=RuleResult.FAIL,
                        detail=f"Vendor '{intent.vendor}' not in allowed vendors",
                    ))
                    decision = Decision.DENY
                else:
                    evaluations.append(RuleEvaluation(
                        rule_id="allowlist_vendor",
                        rule_name="allowlist_vendor",
                        result=RuleResult.PASS,
                        detail="Vendor allowed",
                    ))

                # Action allowlist (empty = all allowed)
                if grant.allowed_actions and intent.action not in grant.allowed_actions:
                    evaluations.append(RuleEvaluation(
                        rule_id="allowlist_action",
                        rule_name="allowlist_action",
                        result=RuleResult.FAIL,
                        detail=f"Action '{intent.action}' not in allowed actions",
                    ))
                    decision = Decision.DENY
                else:
                    evaluations.append(RuleEvaluation(
                        rule_id="allowlist_action",
                        rule_name="allowlist_action",
                        result=RuleResult.PASS,
                        detail="Action allowed",
                    ))

            # 4. Per-transaction limit
            if decision != Decision.DENY:
                amount = intent.cost_estimate.amount
                if amount > grant.max_per_transaction:
                    evaluations.append(RuleEvaluation(
                        rule_id="per_tx_limit",
                        rule_name="per_tx_limit",
                        result=RuleResult.FAIL,
                        detail=f"Amount {amount} exceeds per-transaction limit {grant.max_per_transaction}",
                    ))
                    decision = Decision.DENY
                else:
                    evaluations.append(RuleEvaluation(
                        rule_id="per_tx_limit",
                        rule_name="per_tx_limit",
                        result=RuleResult.PASS,
                        detail=f"Amount {amount} within per-transaction limit",
                    ))

            # 5. Daily limit
            if decision != Decision.DENY:
                wallet = self.wallet_registry.get_or_create(intent.agent_id)
                amount = intent.cost_estimate.amount
                if wallet.daily_total + amount > grant.max_daily:
                    evaluations.append(RuleEvaluation(
                        rule_id="daily_limit",
                        rule_name="daily_limit",
                        result=RuleResult.FAIL,
                        detail=f"Daily total {wallet.daily_total} + {amount} exceeds limit {grant.max_daily}",
                    ))
                    decision = Decision.DENY
                else:
                    evaluations.append(RuleEvaluation(
                        rule_id="daily_limit",
                        rule_name="daily_limit",
                        result=RuleResult.PASS,
                        detail=f"Within daily limit",
                    ))

            # 6. Anomaly detection
            if decision != Decision.DENY:
                wallet = self.wallet_registry.get_or_create(intent.agent_id)
                mean, stddev, count = wallet.vendor_stats(intent.vendor)
                amount = intent.cost_estimate.amount

                if count < 5:
                    evaluations.append(RuleEvaluation(
                        rule_id="anomaly_check",
                        rule_name="anomaly_check",
                        result=RuleResult.SKIP,
                        detail=f"Insufficient data ({count} transactions) for anomaly detection",
                    ))
                else:
                    threshold = mean + self.anomaly_sigma * stddev
                    if stddev > 0 and amount > threshold:
                        evaluations.append(RuleEvaluation(
                            rule_id="anomaly_check",
                            rule_name="anomaly_check",
                            result=RuleResult.FAIL,
                            detail=f"Amount {amount} exceeds anomaly threshold {threshold:.4f} "
                                   f"(mean={mean:.4f}, stddev={stddev:.4f})",
                        ))
                        decision = Decision.DENY
                    else:
                        evaluations.append(RuleEvaluation(
                            rule_id="anomaly_check",
                            rule_name="anomaly_check",
                            result=RuleResult.PASS,
                            detail=f"Amount within normal range",
                        ))

        # 7. Custom rules
        if decision != Decision.DENY:
            for rule in self._custom_rules:
                result = rule.evaluate(intent)
                if isinstance(result, RuleEvaluation):
                    evaluations.append(result)
                    if result.result == RuleResult.FAIL:
                        decision = Decision.DENY

        # Build verdict
        expires_at = None
        if decision == Decision.ALLOW:
            expires_at = (
                datetime.now(timezone.utc) + timedelta(seconds=self.verdict_ttl_seconds)
            ).strftime("%Y-%m-%dT%H:%M:%S.") + \
                f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"

        verdict = PolicyVerdict(
            intent_id=intent.intent_id,
            decision=decision,
            evaluations=evaluations,
            expires_at=expires_at,
        )

        return verdict
