"""
ASP Protocol — Schema Definitions
===================================
Protocol message types: intents, verdicts, receipts, grants, queries.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from enum import Enum
from uuid import uuid4


# ── Constants ──────────────────────────────────────────────────────────

ASP_VERSION = "0.1"


# ── Enums ──────────────────────────────────────────────────────────────

class Decision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    ESCALATE = "escalate"


class Confidence(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class CostBasis(str, Enum):
    VENDOR_QUOTE = "vendor_quote"
    HISTORICAL_AVG = "historical_avg"
    HEURISTIC = "heuristic"


class SpendStatus(str, Enum):
    COMPLETED = "completed"
    FAILED = "failed"
    PENDING = "pending"


class RuleResult(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"


class AuditRole(str, Enum):
    INTERNAL_AUDITOR = "internal_auditor"
    EXTERNAL_AUDITOR = "external_auditor"
    REGULATOR = "regulator"
    AGENT_AUDITOR = "agent_auditor"


class AnomalyAction(str, Enum):
    FLAG = "flag"
    ESCALATE = "escalate"
    DENY = "deny"


# ── Helpers ────────────────────────────────────────────────────────────

def _gen_id(prefix: str) -> str:
    return prefix + uuid4().hex[:12]


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + \
           f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"


# ── Data Classes ───────────────────────────────────────────────────────

class CostEstimate:
    def __init__(
        self,
        amount: float,
        currency: str = "USD",
        confidence: Confidence = Confidence.MEDIUM,
        basis: CostBasis = CostBasis.HEURISTIC,
    ):
        self.amount = amount
        self.currency = currency
        self.confidence = confidence
        self.basis = basis

    def to_dict(self) -> dict:
        return {
            "amount": self.amount,
            "currency": self.currency,
            "confidence": self.confidence.value,
            "basis": self.basis.value,
        }


class RuleEvaluation:
    def __init__(
        self,
        rule_id: str,
        rule_name: str,
        result: RuleResult,
        detail: str,
    ):
        self.rule_id = rule_id
        self.rule_name = rule_name
        self.result = result
        self.detail = detail

    def to_dict(self) -> dict:
        return {
            "rule_id": self.rule_id,
            "rule_name": self.rule_name,
            "result": self.result.value,
            "detail": self.detail,
        }


class SpendIntent:
    def __init__(
        self,
        agent_id: str,
        vendor: str,
        action: str,
        cost_estimate: CostEstimate,
        purpose: str,
        intent_id: str | None = None,
        timestamp: str | None = None,
        delegation_chain: list[str] | None = None,
        endpoint: str | None = None,
        task_id: str | None = None,
        parent_intent_id: str | None = None,
    ):
        self.agent_id = agent_id
        self.vendor = vendor
        self.action = action
        self.cost_estimate = cost_estimate
        self.purpose = purpose
        self.intent_id = intent_id or _gen_id("si_")
        self.timestamp = timestamp or _utcnow_iso()
        self.delegation_chain = delegation_chain
        self.endpoint = endpoint
        self.task_id = task_id
        self.parent_intent_id = parent_intent_id

    def to_dict(self) -> dict:
        d = {
            "type": "SpendIntent",
            "asp_version": ASP_VERSION,
            "intent_id": self.intent_id,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "spend": {
                "vendor": self.vendor,
                "action": self.action,
                "cost_estimate": self.cost_estimate.to_dict(),
                "purpose": self.purpose,
            },
        }
        if self.delegation_chain is not None:
            d["delegation_chain"] = self.delegation_chain
        if self.endpoint is not None:
            d["spend"]["endpoint"] = self.endpoint
        if self.task_id is not None:
            d["task_id"] = self.task_id
        if self.parent_intent_id is not None:
            d["parent_intent_id"] = self.parent_intent_id
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    def hash(self) -> str:
        canonical = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class PolicyVerdict:
    def __init__(
        self,
        intent_id: str,
        decision: Decision,
        verdict_id: str | None = None,
        timestamp: str | None = None,
        evaluations: list[RuleEvaluation] | None = None,
        expires_at: str | None = None,
    ):
        self.intent_id = intent_id
        self.decision = decision
        self.verdict_id = verdict_id or _gen_id("pv_")
        self.timestamp = timestamp or _utcnow_iso()
        self.evaluations = evaluations or []
        self.expires_at = expires_at

    @property
    def allowed(self) -> bool:
        return self.decision == Decision.ALLOW

    @property
    def denied(self) -> bool:
        return self.decision == Decision.DENY

    @property
    def escalated(self) -> bool:
        return self.decision == Decision.ESCALATE

    def to_dict(self) -> dict:
        return {
            "type": "PolicyVerdict",
            "asp_version": ASP_VERSION,
            "verdict_id": self.verdict_id,
            "intent_id": self.intent_id,
            "timestamp": self.timestamp,
            "decision": self.decision.value,
            "evaluations": [e.to_dict() for e in self.evaluations],
            "expires_at": self.expires_at,
        }


class SpendReceipt:
    def __init__(
        self,
        intent_id: str,
        verdict_id: str,
        status: SpendStatus,
        actual_amount: float,
        currency: str = "USD",
        estimated_amount: float | None = None,
        payment_reference: str | None = None,
        vendor_receipt: str | None = None,
        receipt_id: str | None = None,
        timestamp: str | None = None,
    ):
        self.intent_id = intent_id
        self.verdict_id = verdict_id
        self.status = status
        self.actual_amount = actual_amount
        self.currency = currency
        self.estimated_amount = estimated_amount
        self.payment_reference = payment_reference
        self.vendor_receipt = vendor_receipt
        self.receipt_id = receipt_id or _gen_id("sr_")
        self.timestamp = timestamp or _utcnow_iso()

    @property
    def variance(self) -> float | None:
        if self.estimated_amount is None:
            return None
        return self.actual_amount - self.estimated_amount

    @property
    def within_tolerance(self) -> bool:
        if self.estimated_amount is None:
            return True
        v = abs(self.actual_amount - self.estimated_amount)
        return v <= max(self.estimated_amount, 0.01)

    def to_dict(self) -> dict:
        return {
            "type": "SpendReceipt",
            "asp_version": ASP_VERSION,
            "receipt_id": self.receipt_id,
            "intent_id": self.intent_id,
            "verdict_id": self.verdict_id,
            "timestamp": self.timestamp,
            "status": self.status.value,
            "actual_amount": self.actual_amount,
            "currency": self.currency,
            "estimated_amount": self.estimated_amount,
            "payment_reference": self.payment_reference,
            "vendor_receipt": self.vendor_receipt,
            "variance": self.variance,
            "within_tolerance": self.within_tolerance,
        }


class DelegationGrant:
    def __init__(
        self,
        delegator: str,
        delegatee: str,
        max_per_transaction: float,
        max_daily: float,
        max_monthly: float,
        allowed_vendors: list[str] | None = None,
        allowed_actions: list[str] | None = None,
        denied_actions: list[str] | None = None,
        valid_until: str | None = None,
        grant_id: str | None = None,
        timestamp: str | None = None,
    ):
        self.delegator = delegator
        self.delegatee = delegatee
        self.max_per_transaction = max_per_transaction
        self.max_daily = max_daily
        self.max_monthly = max_monthly
        self.allowed_vendors = allowed_vendors or []
        self.allowed_actions = allowed_actions or []
        self.denied_actions = denied_actions or []
        self.valid_until = valid_until
        self.grant_id = grant_id or _gen_id("dg_")
        self.timestamp = timestamp or _utcnow_iso()

    def to_dict(self) -> dict:
        return {
            "type": "DelegationGrant",
            "asp_version": ASP_VERSION,
            "grant_id": self.grant_id,
            "timestamp": self.timestamp,
            "delegator": self.delegator,
            "delegatee": self.delegatee,
            "max_per_transaction": self.max_per_transaction,
            "max_daily": self.max_daily,
            "max_monthly": self.max_monthly,
            "allowed_vendors": self.allowed_vendors,
            "allowed_actions": self.allowed_actions,
            "denied_actions": self.denied_actions,
            "valid_until": self.valid_until,
        }


class AuditQuery:
    def __init__(
        self,
        querier_id: str,
        querier_role: AuditRole,
        agent_id: str | None = None,
        vendor: str | None = None,
        time_from: str | None = None,
        time_to: str | None = None,
        min_amount: float | None = None,
        max_amount: float | None = None,
    ):
        self.querier_id = querier_id
        self.querier_role = querier_role
        self.agent_id = agent_id
        self.vendor = vendor
        self.time_from = time_from
        self.time_to = time_to
        self.min_amount = min_amount
        self.max_amount = max_amount
