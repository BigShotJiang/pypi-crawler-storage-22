"""
Tests for Spendpol × AutoGen integration.

All tests mock AutoGen types so autogen is NOT required to be installed.
"""

import pytest

from spendpol.autogen import (
    SpendpolAutoGenMiddleware,
    SpendingDeniedError,
    SpendingEscalatedError,
)


# ── Mock AutoGen classes ─────────────────────────────────────────────


class MockAutoGenAgent:
    """Mock for autogen.ConversableAgent — has register_for_llm."""

    def __init__(self):
        self.registered_tools: dict[str, dict] = {}

    def register_for_llm(self, name: str, description: str):
        """Returns a decorator that records the registration."""
        def decorator(func):
            self.registered_tools[name] = {
                "description": description,
                "func": func,
            }
            return func
        return decorator


class MockUserProxy:
    """Mock for autogen.UserProxyAgent — has register_for_execution."""

    def __init__(self):
        self.registered_tools: dict[str, callable] = {}

    def register_for_execution(self, name: str):
        """Returns a decorator that records the registration."""
        def decorator(func):
            self.registered_tools[name] = func
            return func
        return decorator


# ── Helpers ──────────────────────────────────────────────────────────


def _make_middleware(**overrides) -> SpendpolAutoGenMiddleware:
    defaults = dict(
        delegator="user:test@example.com",
        default_max_per_tx=1.0,
        default_daily_limit=10.0,
    )
    defaults.update(overrides)
    return SpendpolAutoGenMiddleware(**defaults)


def sample_tool(text: str) -> str:
    """Process text with AI."""
    return f"processed: {text}"


# ── Tests ────────────────────────────────────────────────────────────


class TestMiddlewareInit:
    def test_creates_with_defaults(self):
        asp = SpendpolAutoGenMiddleware()
        assert asp.delegator == "system:autogen"
        assert asp.default_max_per_tx == 1.0
        assert asp.default_daily_limit == 10.0
        assert asp.default_monthly_limit == 200.0
        assert asp.on_deny == "raise"
        assert asp.on_escalate == "skip"

    def test_creates_with_custom_values(self):
        asp = _make_middleware(
            default_max_per_tx=5.0,
            default_daily_limit=50.0,
            default_monthly_limit=500.0,
            allowed_vendors=["openai"],
            on_deny="skip",
        )
        assert asp.default_max_per_tx == 5.0
        assert asp.default_daily_limit == 50.0
        assert asp.default_monthly_limit == 500.0
        assert asp.allowed_vendors == ["openai"]
        assert asp.on_deny == "skip"


class TestAutoRegisterAgent:
    def test_first_call_registers_agent(self):
        asp = _make_middleware()
        assert "researcher" not in asp._registered_agents

        asp.before_tool_call(
            agent_name="researcher",
            vendor="openai",
            action="api_call",
            estimated_cost=0.01,
            purpose="test",
        )

        assert "researcher" in asp._registered_agents

    def test_second_call_does_not_reregister(self):
        asp = _make_middleware()
        asp.before_tool_call("agent-1", "openai", "api_call", 0.01, "test")
        asp.before_tool_call("agent-1", "openai", "api_call", 0.01, "test")
        assert len(asp._registered_agents) == 1

    def test_explicit_register(self):
        asp = _make_middleware()
        asp.register_agent("custom-agent", max_daily=50.0)
        assert "custom-agent" in asp._registered_agents


class TestControlledDecorator:
    def test_allowed_call_executes(self):
        asp = _make_middleware()

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.05)
        def my_tool(text: str) -> str:
            return f"result: {text}"

        result = my_tool("hello")
        assert result == "result: hello"

    def test_sets_asp_attributes(self):
        asp = _make_middleware()

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.05)
        def my_tool(text: str) -> str:
            return text

        assert my_tool._asp_controlled is True
        assert my_tool._asp_vendor == "openai"
        assert my_tool._asp_action == "api_call"

    def test_logs_receipt_after_call(self):
        asp = _make_middleware()

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.05)
        def my_tool() -> str:
            return "ok"

        my_tool()

        report = asp.spending_report("default-agent")
        assert report.get("total_spent", 0) > 0 or report.get("total_transactions", 0) > 0

    def test_preserves_function_name(self):
        asp = _make_middleware()

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.05)
        def special_tool_name() -> str:
            return "ok"

        assert special_tool_name.__name__ == "special_tool_name"


class TestControlledDeny:
    def test_deny_raise_mode(self):
        asp = _make_middleware(default_max_per_tx=0.01, on_deny="raise")

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=5.0)
        def expensive_tool() -> str:
            return "should not run"

        with pytest.raises(SpendingDeniedError, match="denied"):
            expensive_tool()

    def test_deny_skip_mode(self):
        asp = _make_middleware(default_max_per_tx=0.01, on_deny="skip")

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=5.0)
        def expensive_tool() -> str:
            return "should not run"

        result = expensive_tool()
        assert result is None

    def test_deny_log_mode(self):
        asp = _make_middleware(default_max_per_tx=0.01, on_deny="log")

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=5.0)
        def expensive_tool() -> str:
            return "should not run"

        result = expensive_tool()
        assert result is None

    def test_denied_tool_does_not_execute(self):
        asp = _make_middleware(default_max_per_tx=0.01, on_deny="skip")
        called = []

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=5.0)
        def tracked_tool() -> str:
            called.append(True)
            return "ran"

        tracked_tool()
        assert len(called) == 0


class TestControlledEscalate:
    def test_escalate_error_importable_and_raisable(self):
        err = SpendingEscalatedError("needs approval")
        assert str(err) == "needs approval"

    def test_escalate_raise_mode(self):
        asp = _make_middleware(on_escalate="raise")
        # We need to trigger escalation — force it through the handler
        err = SpendingEscalatedError("Spendpol escalated test: needs human approval")
        assert isinstance(err, Exception)


class TestRegisterControlledTool:
    def test_registers_with_both_agents(self):
        asp = _make_middleware()
        agent = MockAutoGenAgent()
        proxy = MockUserProxy()

        asp.register_controlled_tool(
            agent=agent,
            user_proxy=proxy,
            func=sample_tool,
            vendor="openai",
            action="api_call",
            cost_per_call=0.05,
        )

        assert "sample_tool" in agent.registered_tools
        assert "sample_tool" in proxy.registered_tools

    def test_wrapped_function_is_controlled(self):
        asp = _make_middleware()
        agent = MockAutoGenAgent()
        proxy = MockUserProxy()

        wrapped = asp.register_controlled_tool(
            agent=agent,
            user_proxy=proxy,
            func=sample_tool,
            vendor="openai",
            action="api_call",
            cost_per_call=0.05,
        )

        assert wrapped._asp_controlled is True
        assert wrapped._asp_vendor == "openai"
        assert wrapped._asp_action == "api_call"

    def test_enforces_policy(self):
        asp = _make_middleware(default_max_per_tx=0.01)
        agent = MockAutoGenAgent()
        proxy = MockUserProxy()

        wrapped = asp.register_controlled_tool(
            agent=agent,
            user_proxy=proxy,
            func=sample_tool,
            vendor="openai",
            action="api_call",
            cost_per_call=5.0,
        )

        with pytest.raises(SpendingDeniedError):
            wrapped("hello")

    def test_defaults_to_func_name_and_docstring(self):
        asp = _make_middleware()
        agent = MockAutoGenAgent()
        proxy = MockUserProxy()

        asp.register_controlled_tool(
            agent=agent,
            user_proxy=proxy,
            func=sample_tool,
            vendor="openai",
            action="api_call",
            cost_per_call=0.05,
        )

        reg = agent.registered_tools["sample_tool"]
        assert reg["description"] == "Process text with AI."

    def test_custom_name_and_description(self):
        asp = _make_middleware()
        agent = MockAutoGenAgent()
        proxy = MockUserProxy()

        asp.register_controlled_tool(
            agent=agent,
            user_proxy=proxy,
            func=sample_tool,
            vendor="openai",
            action="api_call",
            cost_per_call=0.05,
            name="my_custom_tool",
            description="A custom description",
        )

        assert "my_custom_tool" in agent.registered_tools
        assert "my_custom_tool" in proxy.registered_tools
        assert agent.registered_tools["my_custom_tool"]["description"] == "A custom description"


class TestFailedToolCall:
    def test_failed_tool_logs_zero_receipt(self):
        asp = _make_middleware()

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.05)
        def failing_tool() -> str:
            raise RuntimeError("API error")

        with pytest.raises(RuntimeError, match="API error"):
            failing_tool()


class TestSpendingReport:
    def test_report_after_calls(self):
        asp = _make_middleware()

        @asp.controlled(vendor="openai", action="api_call", cost_per_call=0.05)
        def my_tool() -> str:
            return "ok"

        my_tool()
        my_tool()

        report = asp.spending_report("default-agent")
        assert isinstance(report, dict)
        assert report.get("total_spent", 0) > 0 or "agent_id" in report

    def test_report_all_agents(self):
        asp = _make_middleware()
        report = asp.spending_report()
        assert isinstance(report, dict)
