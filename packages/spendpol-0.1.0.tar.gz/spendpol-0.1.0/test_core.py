"""
ASP Protocol — Test Suite
===========================
Covers: schemas, delegation, policy engine, wallet, audit, validator, client.
Run: pytest tests/ -v
"""

import pytest
from spendpol import (
    ASPClient, ASPError,
    SpendIntent, PolicyVerdict, SpendReceipt, AuditQuery,
    DelegationGrant, CostEstimate,
    Decision, Confidence, CostBasis, AuditRole, SpendStatus, RuleResult,
    DelegationRegistry, DelegationError,
    WalletRegistry,
    PolicyEngine,
    AuditLog,
    Validator, ValidationError,
)


# ═══════════════════════════════════════════════════════════════════════
# SCHEMAS
# ═══════════════════════════════════════════════════════════════════════

class TestSpendIntent:
    def test_create_intent(self):
        cost = CostEstimate(amount=0.03, currency="USD", confidence=Confidence.MEDIUM)
        intent = SpendIntent(
            agent_id="agent-1",
            vendor="openai",
            action="api_call",
            cost_estimate=cost,
            purpose="Test",
        )
        assert intent.agent_id == "agent-1"
        assert intent.intent_id.startswith("si_")
        assert intent.cost_estimate.amount == 0.03

    def test_to_dict(self):
        cost = CostEstimate(amount=0.05, confidence=Confidence.HIGH, basis=CostBasis.VENDOR_QUOTE)
        intent = SpendIntent(
            agent_id="agent-1", vendor="anthropic",
            action="api_call", cost_estimate=cost, purpose="Embed",
        )
        d = intent.to_dict()
        assert d["type"] == "SpendIntent"
        assert d["asp_version"] == "0.1"
        assert d["spend"]["cost_estimate"]["confidence"] == "high"
        assert d["spend"]["cost_estimate"]["basis"] == "vendor_quote"

    def test_to_json(self):
        cost = CostEstimate(amount=0.01)
        intent = SpendIntent(
            agent_id="a", vendor="v", action="a",
            cost_estimate=cost, purpose="p",
        )
        j = intent.to_json()
        assert '"SpendIntent"' in j

    def test_deterministic_hash(self):
        cost = CostEstimate(amount=0.03)
        intent = SpendIntent(
            agent_id="a", vendor="v", action="a",
            cost_estimate=cost, purpose="p",
            intent_id="fixed", timestamp="2026-01-01T00:00:00.000Z",
        )
        h1 = intent.hash()
        h2 = intent.hash()
        assert h1 == h2
        assert len(h1) == 64  # SHA-256


class TestCostEstimate:
    def test_defaults(self):
        c = CostEstimate(amount=1.0)
        assert c.currency == "USD"
        assert c.confidence == Confidence.MEDIUM
        assert c.basis == CostBasis.HEURISTIC

    def test_confidence_levels(self):
        assert Confidence.LOW.value == "low"
        assert Confidence.HIGH.value == "high"


class TestSpendReceipt:
    def test_variance_calculation(self):
        r = SpendReceipt(
            intent_id="si_1", verdict_id="pv_1",
            status=SpendStatus.COMPLETED,
            actual_amount=0.028, estimated_amount=0.03,
        )
        assert r.variance == pytest.approx(-0.002)
        assert r.within_tolerance is True

    def test_large_variance(self):
        r = SpendReceipt(
            intent_id="si_1", verdict_id="pv_1",
            status=SpendStatus.COMPLETED,
            actual_amount=10.0, estimated_amount=0.03,
        )
        assert r.within_tolerance is False

    def test_no_estimate(self):
        r = SpendReceipt(
            intent_id="si_1", verdict_id="pv_1",
            status=SpendStatus.COMPLETED,
            actual_amount=0.05,
        )
        assert r.variance is None
        assert r.within_tolerance is True


# ═══════════════════════════════════════════════════════════════════════
# DELEGATION
# ═══════════════════════════════════════════════════════════════════════

class TestDelegation:
    def setup_method(self):
        self.registry = DelegationRegistry()

    def test_register_grant(self):
        g = DelegationGrant(
            delegator="user:john", delegatee="agent-1",
            max_per_transaction=1.0, max_daily=10.0, max_monthly=200.0,
        )
        result = self.registry.register(g)
        assert result.grant_id == g.grant_id

    def test_get_active_grant(self):
        g = DelegationGrant(
            delegator="user:john", delegatee="agent-1",
            max_per_transaction=1.0, max_daily=10.0, max_monthly=200.0,
        )
        self.registry.register(g)
        active = self.registry.get_active_grant("agent-1")
        assert active is not None
        assert active.delegator == "user:john"

    def test_no_grant(self):
        assert self.registry.get_active_grant("nonexistent") is None

    def test_attenuation_violation(self):
        # Parent grant
        parent = DelegationGrant(
            delegator="org:root", delegatee="user:john",
            max_per_transaction=10.0, max_daily=50.0, max_monthly=500.0,
            allowed_vendors=["openai"],
        )
        self.registry.register(parent)

        # Child tries to exceed parent
        child = DelegationGrant(
            delegator="user:john", delegatee="agent-1",
            max_per_transaction=20.0,  # Exceeds parent's 10.0!
            max_daily=50.0, max_monthly=500.0,
        )
        with pytest.raises(DelegationError, match="Attenuation"):
            self.registry.register(child)

    def test_attenuation_vendor_violation(self):
        parent = DelegationGrant(
            delegator="org:root", delegatee="user:john",
            max_per_transaction=10.0, max_daily=50.0, max_monthly=500.0,
            allowed_vendors=["openai"],
        )
        self.registry.register(parent)

        child = DelegationGrant(
            delegator="user:john", delegatee="agent-1",
            max_per_transaction=5.0, max_daily=25.0, max_monthly=200.0,
            allowed_vendors=["openai", "anthropic"],  # anthropic not in parent!
        )
        with pytest.raises(DelegationError, match="Attenuation"):
            self.registry.register(child)

    def test_cascading_revocation(self):
        g1 = DelegationGrant(
            delegator="org:root", delegatee="user:john",
            max_per_transaction=10.0, max_daily=50.0, max_monthly=500.0,
        )
        self.registry.register(g1)

        g2 = DelegationGrant(
            delegator="user:john", delegatee="agent-1",
            max_per_transaction=5.0, max_daily=25.0, max_monthly=200.0,
        )
        self.registry.register(g2)

        g3 = DelegationGrant(
            delegator="agent-1", delegatee="agent-2",
            max_per_transaction=1.0, max_daily=5.0, max_monthly=50.0,
        )
        self.registry.register(g3)

        # Revoke middle grant
        revoked = self.registry.revoke(g2.grant_id)
        assert g2.grant_id in revoked
        assert g3.grant_id in revoked  # Cascaded!
        assert g1.grant_id not in revoked  # Parent untouched

        # agent-1 and agent-2 should have no active grants
        assert self.registry.get_active_grant("agent-1") is None
        assert self.registry.get_active_grant("agent-2") is None

    def test_delegation_chain(self):
        g1 = DelegationGrant(
            delegator="org:root", delegatee="user:john",
            max_per_transaction=10.0, max_daily=50.0, max_monthly=500.0,
        )
        g2 = DelegationGrant(
            delegator="user:john", delegatee="agent-1",
            max_per_transaction=5.0, max_daily=25.0, max_monthly=200.0,
        )
        self.registry.register(g1)
        self.registry.register(g2)

        chain = self.registry.get_delegation_chain("agent-1")
        assert chain == ["org:root", "user:john", "agent-1"]


# ═══════════════════════════════════════════════════════════════════════
# WALLET
# ═══════════════════════════════════════════════════════════════════════

class TestWallet:
    def test_record_spend(self):
        registry = WalletRegistry()
        wallet = registry.get_or_create("agent-1")

        receipt = SpendReceipt(
            intent_id="si_1", verdict_id="pv_1",
            status=SpendStatus.COMPLETED,
            actual_amount=0.05,
        )
        wallet.record_spend(receipt, "openai")
        assert wallet.daily_total == pytest.approx(0.05)
        assert wallet.vendor_total("openai") == pytest.approx(0.05)
        assert wallet.vendor_count("openai") == 1

    def test_ignores_failed(self):
        registry = WalletRegistry()
        wallet = registry.get_or_create("agent-1")

        receipt = SpendReceipt(
            intent_id="si_1", verdict_id="pv_1",
            status=SpendStatus.FAILED,
            actual_amount=1.00,
        )
        wallet.record_spend(receipt, "openai")
        assert wallet.daily_total == 0.0

    def test_summary(self):
        registry = WalletRegistry()
        wallet = registry.get_or_create("agent-1")

        for i in range(3):
            r = SpendReceipt(
                intent_id=f"si_{i}", verdict_id=f"pv_{i}",
                status=SpendStatus.COMPLETED, actual_amount=0.01,
            )
            wallet.record_spend(r, "openai")

        s = wallet.summary()
        assert s["agent_id"] == "agent-1"
        assert s["daily_spend"] == pytest.approx(0.03)
        assert s["total_transactions"] == 3


# ═══════════════════════════════════════════════════════════════════════
# POLICY ENGINE
# ═══════════════════════════════════════════════════════════════════════

class TestPolicyEngine:
    def setup_method(self):
        self.delegations = DelegationRegistry()
        self.wallets = WalletRegistry()
        self.engine = PolicyEngine(
            delegation_registry=self.delegations,
            wallet_registry=self.wallets,
        )
        # Setup standard grant
        self.grant = DelegationGrant(
            delegator="user:john", delegatee="agent-1",
            max_per_transaction=1.0, max_daily=10.0, max_monthly=200.0,
            allowed_vendors=["openai", "anthropic"],
            allowed_actions=["api_call", "data_retrieval"],
            denied_actions=["subscription"],
        )
        self.delegations.register(self.grant)

    def _make_intent(self, **overrides):
        defaults = dict(
            agent_id="agent-1", vendor="openai", action="api_call",
            cost_estimate=CostEstimate(amount=0.03),
            purpose="test",
        )
        defaults.update(overrides)
        return SpendIntent(**defaults)

    def test_allow(self):
        intent = self._make_intent()
        verdict = self.engine.evaluate(intent)
        assert verdict.allowed

    def test_deny_no_grant(self):
        intent = self._make_intent(agent_id="unknown-agent")
        verdict = self.engine.evaluate(intent)
        assert verdict.denied

    def test_deny_denylist(self):
        intent = self._make_intent(action="subscription")
        verdict = self.engine.evaluate(intent)
        assert verdict.denied
        assert any("denylist" in e.rule_name for e in verdict.evaluations if e.result == RuleResult.FAIL)

    def test_deny_vendor_not_allowed(self):
        intent = self._make_intent(vendor="google")
        verdict = self.engine.evaluate(intent)
        assert verdict.denied

    def test_deny_over_per_tx_limit(self):
        intent = self._make_intent(
            cost_estimate=CostEstimate(amount=5.0)  # Exceeds $1.00
        )
        verdict = self.engine.evaluate(intent)
        assert verdict.denied

    def test_deny_over_daily_limit(self):
        # Fill up daily limit
        wallet = self.wallets.get_or_create("agent-1")
        for i in range(10):
            r = SpendReceipt(
                intent_id=f"si_{i}", verdict_id=f"pv_{i}",
                status=SpendStatus.COMPLETED, actual_amount=0.99,
            )
            wallet.record_spend(r, "openai")

        # Now try one more
        intent = self._make_intent(
            cost_estimate=CostEstimate(amount=0.50)
        )
        verdict = self.engine.evaluate(intent)
        assert verdict.denied

    def test_anomaly_skip_insufficient_data(self):
        intent = self._make_intent()
        verdict = self.engine.evaluate(intent)
        assert verdict.allowed
        # Anomaly should be skipped with insufficient data
        anomaly_eval = [e for e in verdict.evaluations if e.rule_name == "anomaly_check"]
        assert len(anomaly_eval) == 1
        assert anomaly_eval[0].result == RuleResult.SKIP

    def test_deterministic_verdict(self):
        """Same intent + same state = same decision. Always."""
        intent = self._make_intent(
            intent_id="fixed_id", timestamp="2026-01-01T00:00:00.000Z"
        )
        v1 = self.engine.evaluate(intent)
        v2 = self.engine.evaluate(intent)
        assert v1.decision == v2.decision
        assert len(v1.evaluations) == len(v2.evaluations)
        for e1, e2 in zip(v1.evaluations, v2.evaluations):
            assert e1.result == e2.result

    def test_verdict_expiry(self):
        intent = self._make_intent()
        verdict = self.engine.evaluate(intent)
        assert verdict.allowed
        assert verdict.expires_at is not None

    def test_deny_has_no_expiry(self):
        intent = self._make_intent(action="subscription")
        verdict = self.engine.evaluate(intent)
        assert verdict.denied
        assert verdict.expires_at is None


# ═══════════════════════════════════════════════════════════════════════
# AUDIT
# ═══════════════════════════════════════════════════════════════════════

class TestAudit:
    def setup_method(self):
        self.log = AuditLog()

    def test_record_and_query(self):
        intent = SpendIntent(
            agent_id="agent-1", vendor="openai", action="api_call",
            cost_estimate=CostEstimate(amount=0.03), purpose="test",
        )
        verdict = PolicyVerdict(
            intent_id=intent.intent_id, decision=Decision.ALLOW,
        )
        self.log.record(intent, verdict)
        assert self.log.count() == 1

        query = AuditQuery(
            querier_id="auditor:me", querier_role=AuditRole.INTERNAL_AUDITOR,
            agent_id="agent-1",
        )
        results = self.log.query(query)
        assert len(results) == 1
        assert results[0].intent.agent_id == "agent-1"

    def test_vendor_filter(self):
        for vendor in ["openai", "anthropic", "openai"]:
            intent = SpendIntent(
                agent_id="agent-1", vendor=vendor, action="api_call",
                cost_estimate=CostEstimate(amount=0.01), purpose="test",
            )
            verdict = PolicyVerdict(intent_id=intent.intent_id, decision=Decision.ALLOW)
            self.log.record(intent, verdict)

        query = AuditQuery(
            querier_id="a", querier_role=AuditRole.INTERNAL_AUDITOR,
            vendor="openai",
        )
        results = self.log.query(query)
        assert len(results) == 2

    def test_attach_receipt(self):
        intent = SpendIntent(
            agent_id="a", vendor="v", action="a",
            cost_estimate=CostEstimate(amount=0.01), purpose="p",
        )
        verdict = PolicyVerdict(intent_id=intent.intent_id, decision=Decision.ALLOW)
        self.log.record(intent, verdict)

        receipt = SpendReceipt(
            intent_id=intent.intent_id, verdict_id=verdict.verdict_id,
            status=SpendStatus.COMPLETED, actual_amount=0.01,
        )
        self.log.attach_receipt(intent.intent_id, receipt)

        record = self.log.get_by_intent(intent.intent_id)
        assert record.receipt is not None
        assert record.receipt.actual_amount == 0.01

    def test_denial_rate(self):
        for decision in [Decision.ALLOW, Decision.DENY, Decision.DENY]:
            intent = SpendIntent(
                agent_id="agent-1", vendor="v", action="a",
                cost_estimate=CostEstimate(amount=0.01), purpose="p",
            )
            verdict = PolicyVerdict(intent_id=intent.intent_id, decision=decision)
            self.log.record(intent, verdict)

        rate = self.log.denial_rate("agent-1")
        assert rate == pytest.approx(0.6667, abs=0.001)


# ═══════════════════════════════════════════════════════════════════════
# VALIDATOR
# ═══════════════════════════════════════════════════════════════════════

class TestValidator:
    def test_valid_intent(self):
        intent = SpendIntent(
            agent_id="a", vendor="v", action="a",
            cost_estimate=CostEstimate(amount=0.01), purpose="p",
        )
        errors = Validator.validate_intent(intent)
        assert len(errors) == 0

    def test_invalid_intent_negative_amount(self):
        intent = SpendIntent(
            agent_id="a", vendor="v", action="a",
            cost_estimate=CostEstimate(amount=-1.0), purpose="p",
        )
        errors = Validator.validate_intent(intent)
        assert len(errors) > 0
        assert any("negative" in e.message for e in errors)

    def test_invalid_grant_self_delegation(self):
        grant = DelegationGrant(
            delegator="agent-1", delegatee="agent-1",
            max_per_transaction=1.0, max_daily=10.0, max_monthly=100.0,
        )
        errors = Validator.validate_grant(grant)
        assert any("self" in e.message.lower() for e in errors)

    def test_invalid_grant_daily_exceeds_monthly(self):
        grant = DelegationGrant(
            delegator="user:a", delegatee="agent-1",
            max_per_transaction=1.0, max_daily=100.0, max_monthly=50.0,
        )
        errors = Validator.validate_grant(grant)
        assert any("daily" in e.message.lower() for e in errors)

    def test_deny_verdict_must_have_fail(self):
        from spendpol.schemas import RuleEvaluation
        verdict = PolicyVerdict(
            intent_id="si_1", decision=Decision.DENY,
            evaluations=[
                RuleEvaluation(rule_id="r1", rule_name="test", result=RuleResult.PASS, detail="ok"),
            ],
        )
        errors = Validator.validate_verdict(verdict)
        assert any("FAIL" in e.message for e in errors)


# ═══════════════════════════════════════════════════════════════════════
# CLIENT (Integration Tests)
# ═══════════════════════════════════════════════════════════════════════

class TestASPClient:
    def setup_method(self):
        self.client = ASPClient()
        self.client.grant(
            delegator="user:john",
            delegatee="agent-1",
            max_per_transaction=1.0,
            max_daily=10.0,
            max_monthly=200.0,
            allowed_vendors=["openai", "anthropic"],
            allowed_actions=["api_call"],
            denied_actions=["subscription"],
        )

    def test_full_flow(self):
        """Happy path: grant → intent → verdict → receipt → audit."""
        verdict = self.client.check_intent(
            agent_id="agent-1", vendor="openai", action="api_call",
            amount=0.03, purpose="Test embedding",
        )
        assert verdict.allowed

        receipt = self.client.log_receipt(
            verdict=verdict, actual_amount=0.028,
            payment_reference="stripe:ch_test",
        )
        assert receipt.receipt_id.startswith("sr_")
        assert receipt.variance == pytest.approx(-0.002)

        summary = self.client.audit_summary()
        assert summary["total_records"] == 1
        assert summary["total_spend"] == pytest.approx(0.028)

    def test_deny_flow(self):
        verdict = self.client.check_intent(
            agent_id="agent-1", vendor="openai", action="subscription",
            amount=20.0, purpose="Upgrade plan",
        )
        assert verdict.denied

    def test_invalid_grant_raises(self):
        with pytest.raises(ASPError):
            self.client.grant(
                delegator="agent-1", delegatee="agent-1",  # Self-delegation
                max_per_transaction=1.0, max_daily=10.0, max_monthly=100.0,
            )

    def test_revoke_denies_subsequent(self):
        grant = self.client.grant(
            delegator="user:john", delegatee="agent-tmp",
            max_per_transaction=1.0, max_daily=10.0, max_monthly=100.0,
        )
        # Works before revoke
        v1 = self.client.check_intent(
            agent_id="agent-tmp", vendor="openai", action="api_call",
            amount=0.01, purpose="Pre-revoke",
        )
        assert v1.allowed

        # Revoke
        self.client.revoke(grant.grant_id)

        # Denied after revoke
        v2 = self.client.check_intent(
            agent_id="agent-tmp", vendor="openai", action="api_call",
            amount=0.01, purpose="Post-revoke",
        )
        assert v2.denied

    def test_agent_summary(self):
        verdict = self.client.check_intent(
            agent_id="agent-1", vendor="openai", action="api_call",
            amount=0.05, purpose="Summary test",
        )
        self.client.log_receipt(verdict, actual_amount=0.048)

        summary = self.client.agent_summary("agent-1")
        assert summary["daily_spend"] == pytest.approx(0.048)
        assert summary["total_transactions"] == 1

    def test_audit_query(self):
        for i in range(5):
            v = self.client.check_intent(
                agent_id="agent-1", vendor="openai", action="api_call",
                amount=0.01, purpose=f"Audit test #{i}",
            )
            if v.allowed:
                self.client.log_receipt(v, actual_amount=0.01)

        records = self.client.audit(
            querier_id="auditor:finance",
            role="internal_auditor",
            agent_id="agent-1",
        )
        assert len(records) == 5

    def test_confidence_affects_evaluation(self):
        """Low confidence should still be evaluated correctly."""
        verdict = self.client.check_intent(
            agent_id="agent-1", vendor="openai", action="api_call",
            amount=0.03, purpose="Low confidence test",
            confidence="low", basis="heuristic",
        )
        assert verdict.allowed
