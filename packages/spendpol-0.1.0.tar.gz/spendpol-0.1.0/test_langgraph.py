"""
Tests for Spendpol × LangGraph integration.

All tests mock LangGraph types so langgraph is NOT required to be installed.
"""

import pytest
from types import SimpleNamespace

from spendpol.langgraph import (
    SpendpolLangGraphMiddleware,
    SpendingDeniedError,
    SpendingEscalatedError,
    asp_tool,
    _make_tool_message,
)


# ── Helpers ──────────────────────────────────────────────────────────


def _make_middleware(**overrides) -> SpendpolLangGraphMiddleware:
    defaults = dict(
        delegator="user:test@example.com",
        default_max_per_tx=1.0,
        default_daily_limit=10.0,
    )
    defaults.update(overrides)
    return SpendpolLangGraphMiddleware(**defaults)


@asp_tool(vendor="openai", action="api_call", cost_per_call=0.05)
def sample_tool(text: str) -> str:
    return f"processed: {text}"


def uncontrolled_tool(text: str) -> str:
    return f"free: {text}"


def _make_request(tool_func, tool_call_id="call-1", agent_name=None):
    """Create a mock ToolNode request with a tool reference."""
    tool_obj = SimpleNamespace(func=tool_func)
    req = SimpleNamespace(
        id=tool_call_id,
        tool=tool_obj,
    )
    if agent_name:
        req.agent_name = agent_name
    return req


def _make_handler(result="tool-result"):
    """Create a mock handler that returns a fixed result."""
    def handler(request):
        return result
    return handler


# ── Tests ────────────────────────────────────────────────────────────


class TestMiddlewareInit:
    def test_creates_with_defaults(self):
        asp = SpendpolLangGraphMiddleware()
        assert asp.delegator == "system:langgraph"
        assert asp.default_max_per_tx == 1.0
        assert asp.default_daily_limit == 10.0
        assert asp.default_monthly_limit == 200.0
        assert asp.on_deny == "message"
        assert asp.on_escalate == "message"

    def test_creates_with_custom_values(self):
        asp = _make_middleware(
            default_max_per_tx=5.0,
            default_daily_limit=50.0,
            default_monthly_limit=500.0,
            allowed_vendors=["openai"],
            on_deny="raise",
        )
        assert asp.default_max_per_tx == 5.0
        assert asp.default_daily_limit == 50.0
        assert asp.allowed_vendors == ["openai"]
        assert asp.on_deny == "raise"


class TestAutoRegisterAgent:
    def test_first_call_registers_agent(self):
        asp = _make_middleware()
        assert "researcher" not in asp._registered_agents

        asp.before_tool_call(
            agent_name="researcher",
            vendor="openai",
            action="api_call",
            estimated_cost=0.01,
            purpose="test",
        )

        assert "researcher" in asp._registered_agents

    def test_second_call_does_not_reregister(self):
        asp = _make_middleware()
        asp.before_tool_call("agent-1", "openai", "api_call", 0.01, "test")
        asp.before_tool_call("agent-1", "openai", "api_call", 0.01, "test")
        assert len(asp._registered_agents) == 1

    def test_explicit_register(self):
        asp = _make_middleware()
        asp.register_agent("custom-agent", max_daily=50.0)
        assert "custom-agent" in asp._registered_agents


class TestWrapAllowsTool:
    def test_tool_with_metadata_executes(self):
        asp = _make_middleware()
        req = _make_request(sample_tool)
        handler = _make_handler("success")

        result = asp.wrap_tool_call(req, handler)
        assert result == "success"

    def test_after_tool_call_logs_receipt(self):
        asp = _make_middleware()
        req = _make_request(sample_tool)
        handler = _make_handler("ok")

        asp.wrap_tool_call(req, handler)

        report = asp.spending_report("default-agent")
        assert report.get("daily_spend", 0) > 0 or report.get("total_transactions", 0) > 0


class TestWrapDeniesTool:
    def test_over_limit_returns_denial_message(self):
        asp = _make_middleware(default_max_per_tx=0.01)

        @asp_tool(vendor="openai", action="api_call", cost_per_call=5.0)
        def expensive_tool(text: str) -> str:
            return "should not run"

        req = _make_request(expensive_tool)
        handler = _make_handler("should not run")

        result = asp.wrap_tool_call(req, handler)
        assert isinstance(result, dict)
        assert "DENIED" in result["content"]

    def test_handler_not_called_on_deny(self):
        asp = _make_middleware(default_max_per_tx=0.01)

        @asp_tool(vendor="openai", action="api_call", cost_per_call=5.0)
        def expensive_tool(text: str) -> str:
            return "should not run"

        called = []
        def tracking_handler(req):
            called.append(True)
            return "ran"

        req = _make_request(expensive_tool)
        asp.wrap_tool_call(req, tracking_handler)
        assert len(called) == 0


class TestWrapNoMetadata:
    def test_uncontrolled_tool_executes_directly(self):
        asp = _make_middleware()
        req = _make_request(uncontrolled_tool)
        handler = _make_handler("free-result")

        result = asp.wrap_tool_call(req, handler)
        assert result == "free-result"

    def test_no_tool_on_request_executes_handler(self):
        """If request has no tool attribute, handler runs uncontrolled."""
        asp = _make_middleware()
        req = SimpleNamespace(id="call-1")
        handler = _make_handler("direct")

        result = asp.wrap_tool_call(req, handler)
        assert result == "direct"


class TestAspToolDecorator:
    def test_sets_attributes(self):
        assert sample_tool._asp_vendor == "openai"
        assert sample_tool._asp_action == "api_call"
        assert sample_tool._asp_cost == 0.05
        assert sample_tool._asp_confidence == "medium"
        assert sample_tool._asp_controlled is True

    def test_custom_confidence(self):
        @asp_tool(vendor="aws", action="s3_put", cost_per_call=0.001, confidence="high")
        def s3_tool():
            pass

        assert s3_tool._asp_confidence == "high"

    def test_function_still_callable(self):
        result = sample_tool("hello")
        assert result == "processed: hello"


class TestDeniedReturnsToolMessage:
    def test_message_format(self):
        msg = _make_tool_message("call-123", "denied for testing")
        assert msg["role"] == "tool"
        assert msg["tool_call_id"] == "call-123"
        assert msg["content"] == "denied for testing"

    def test_denied_wrap_returns_proper_format(self):
        asp = _make_middleware(default_max_per_tx=0.001)

        @asp_tool(vendor="openai", action="api_call", cost_per_call=1.0)
        def big_tool():
            pass

        req = _make_request(big_tool, tool_call_id="call-456")
        handler = _make_handler("nope")

        result = asp.wrap_tool_call(req, handler)
        assert result["role"] == "tool"
        assert result["tool_call_id"] == "call-456"
        assert "DENIED" in result["content"]


class TestSpendingReport:
    def test_report_after_calls(self):
        asp = _make_middleware()
        req = _make_request(sample_tool)
        handler = _make_handler("ok")

        # Make a few calls
        asp.wrap_tool_call(req, handler)
        asp.wrap_tool_call(req, handler)

        report = asp.spending_report("default-agent")
        assert isinstance(report, dict)
        # Should have some spending data
        assert report.get("total_spent", 0) > 0 or "agent_id" in report

    def test_report_all_agents(self):
        asp = _make_middleware()
        report = asp.spending_report()
        assert isinstance(report, dict)


class TestOnDenyModes:
    def test_deny_raise_mode(self):
        asp = _make_middleware(default_max_per_tx=0.001, on_deny="raise")

        @asp_tool(vendor="openai", action="api_call", cost_per_call=1.0)
        def expensive():
            pass

        req = _make_request(expensive)
        handler = _make_handler("nope")

        with pytest.raises(SpendingDeniedError, match="denied"):
            asp.wrap_tool_call(req, handler)

    def test_deny_message_mode(self):
        asp = _make_middleware(default_max_per_tx=0.001, on_deny="message")

        @asp_tool(vendor="openai", action="api_call", cost_per_call=1.0)
        def expensive():
            pass

        req = _make_request(expensive)
        handler = _make_handler("nope")

        result = asp.wrap_tool_call(req, handler)
        assert isinstance(result, dict)
        assert "DENIED" in result["content"]

    def test_escalate_raise_mode(self):
        """SpendingEscalatedError is importable and raisable."""
        err = SpendingEscalatedError("needs approval")
        assert str(err) == "needs approval"


class TestFailedToolCall:
    def test_failed_tool_logs_zero_receipt(self):
        asp = _make_middleware()

        @asp_tool(vendor="openai", action="api_call", cost_per_call=0.05)
        def failing_tool():
            pass

        req = _make_request(failing_tool)

        def failing_handler(request):
            raise RuntimeError("API error")

        with pytest.raises(RuntimeError, match="API error"):
            asp.wrap_tool_call(req, failing_handler)
