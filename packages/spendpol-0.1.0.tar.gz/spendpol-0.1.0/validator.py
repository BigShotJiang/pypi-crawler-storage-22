"""
ASP Protocol — Validator
=========================
Static validation for protocol messages.
"""

from __future__ import annotations

from .schemas import Decision, RuleResult


class ValidationError:
    def __init__(self, message: str, field: str | None = None, code: str | None = None):
        self.message = message
        self.field = field
        self.code = code

    def __repr__(self) -> str:
        return f"ValidationError({self.message!r})"


class Validator:
    @staticmethod
    def validate_intent(intent) -> list[ValidationError]:
        errors: list[ValidationError] = []
        if intent.cost_estimate.amount < 0:
            errors.append(ValidationError(
                "Cost estimate amount must not be negative",
                field="cost_estimate.amount",
                code="negative_amount",
            ))
        if not intent.agent_id:
            errors.append(ValidationError("agent_id is required", field="agent_id"))
        if not intent.vendor:
            errors.append(ValidationError("vendor is required", field="vendor"))
        if not intent.action:
            errors.append(ValidationError("action is required", field="action"))
        return errors

    @staticmethod
    def validate_grant(grant) -> list[ValidationError]:
        errors: list[ValidationError] = []
        if grant.delegator == grant.delegatee:
            errors.append(ValidationError(
                "Self-delegation is not allowed",
                field="delegatee",
                code="self_delegation",
            ))
        if grant.max_daily > grant.max_monthly:
            errors.append(ValidationError(
                "Daily limit must not exceed monthly limit",
                field="max_daily",
                code="daily_exceeds_monthly",
            ))
        if grant.max_per_transaction <= 0:
            errors.append(ValidationError(
                "max_per_transaction must be positive",
                field="max_per_transaction",
            ))
        if grant.max_daily <= 0:
            errors.append(ValidationError(
                "max_daily must be positive",
                field="max_daily",
            ))
        if grant.max_monthly <= 0:
            errors.append(ValidationError(
                "max_monthly must be positive",
                field="max_monthly",
            ))
        return errors

    @staticmethod
    def validate_receipt(receipt) -> list[ValidationError]:
        errors: list[ValidationError] = []
        if not receipt.intent_id:
            errors.append(ValidationError("intent_id is required", field="intent_id"))
        if not receipt.verdict_id:
            errors.append(ValidationError("verdict_id is required", field="verdict_id"))
        if receipt.actual_amount < 0:
            errors.append(ValidationError(
                "actual_amount must not be negative",
                field="actual_amount",
                code="negative_amount",
            ))
        return errors

    @staticmethod
    def validate_verdict(verdict) -> list[ValidationError]:
        errors: list[ValidationError] = []
        if verdict.decision == Decision.DENY:
            has_fail = any(e.result == RuleResult.FAIL for e in verdict.evaluations)
            if not has_fail:
                errors.append(ValidationError(
                    "DENY verdict must have at least one FAIL evaluation",
                    field="evaluations",
                    code="deny_without_fail",
                ))
        return errors
