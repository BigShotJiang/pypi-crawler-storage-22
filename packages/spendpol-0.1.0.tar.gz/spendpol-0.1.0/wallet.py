"""
ASP Protocol — Wallet
======================
Per-agent spending tracker with daily/monthly totals and per-vendor stats.
"""

from __future__ import annotations

import math

from .schemas import SpendStatus


class AgentWallet:
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self._daily_total: float = 0.0
        self._monthly_total: float = 0.0
        self._total_transactions: int = 0
        self._vendor_totals: dict[str, float] = {}
        self._vendor_counts: dict[str, int] = {}
        # Rolling stats for anomaly detection: vendor -> list of amounts
        self._vendor_amounts: dict[str, list[float]] = {}

    def record_spend(self, receipt, vendor: str):
        if receipt.status != SpendStatus.COMPLETED:
            return
        amount = receipt.actual_amount
        self._daily_total += amount
        self._monthly_total += amount
        self._total_transactions += 1
        self._vendor_totals[vendor] = self._vendor_totals.get(vendor, 0.0) + amount
        self._vendor_counts[vendor] = self._vendor_counts.get(vendor, 0) + 1
        if vendor not in self._vendor_amounts:
            self._vendor_amounts[vendor] = []
        self._vendor_amounts[vendor].append(amount)

    @property
    def daily_total(self) -> float:
        return self._daily_total

    @property
    def monthly_total(self) -> float:
        return self._monthly_total

    def vendor_total(self, vendor: str) -> float:
        return self._vendor_totals.get(vendor, 0.0)

    def vendor_count(self, vendor: str) -> int:
        return self._vendor_counts.get(vendor, 0)

    def vendor_stats(self, vendor: str) -> tuple[float, float, int]:
        """Returns (mean, stddev, count) for a vendor's transaction amounts."""
        amounts = self._vendor_amounts.get(vendor, [])
        n = len(amounts)
        if n == 0:
            return 0.0, 0.0, 0
        mean = sum(amounts) / n
        if n < 2:
            return mean, 0.0, n
        variance = sum((x - mean) ** 2 for x in amounts) / n
        return mean, math.sqrt(variance), n

    def summary(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "daily_spend": self._daily_total,
            "monthly_spend": self._monthly_total,
            "total_transactions": self._total_transactions,
            "vendors": dict(self._vendor_totals),
        }


class WalletRegistry:
    def __init__(self):
        self._wallets: dict[str, AgentWallet] = {}

    def get_or_create(self, agent_id: str) -> AgentWallet:
        if agent_id not in self._wallets:
            self._wallets[agent_id] = AgentWallet(agent_id)
        return self._wallets[agent_id]

    def get(self, agent_id: str) -> AgentWallet | None:
        return self._wallets.get(agent_id)
