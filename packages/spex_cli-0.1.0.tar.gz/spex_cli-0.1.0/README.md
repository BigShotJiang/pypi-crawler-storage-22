<p align="center">
  <img src="docs/logo.png" alt="speX Logo" width="120" />
</p>

<h1 align="center">🌋Spex CLI</h1>

<p align="center">
  <strong>Autonomous engineering experience enabled.</strong>
  <br />
  <em>Built by the MagmaAI Team</em>
</p>

<p align="center">
  <a href="#overview">Overview</a> •
  <a href="#features">Features</a> •
  <a href="#getting-started">Getting Started</a> •
  <a href="#project-structure">Project Structure</a> •
  <a href="#development">Development</a> •
  <a href="#contributing">Contributing</a>
</p>

---

## Deployment

To deploy a new version of `spex-cli` to PyPI, use the provided deployment script:

```bash
./scripts/deploy.sh
```

This script will:
1. Verify no uncommitted changes exist.
2. Build the package using `uv` (if available) or `build`.
3. Check the distribution packages with `twine`.
4. Prompt for upload to TestPyPI or PyPI.

Make sure you have your PyPI credentials configured in `~/.pypirc` or set via environment variables (`TWINE_USERNAME` and `TWINE_PASSWORD`).