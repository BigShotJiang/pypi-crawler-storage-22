import json
import pytest
from datetime import datetime


@pytest.fixture
def temp_spex_env(tmp_path):
    """Setup a temporary .spex directory structure"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True)
    
    # Global memory files
    (memory_dir / "requirements.jsonl").touch()
    (memory_dir / "decisions.jsonl").touch()
    (memory_dir / "plans.jsonl").touch()
    (memory_dir / "traces.jsonl").touch()
    
    return tmp_path

def run_spex(cwd, args):
    """Run spex CLI with args"""
    import subprocess
    return subprocess.run(["spex"] + args, cwd=cwd, capture_output=True, text=True)

def init_feature(env, name):
    """Initialize a feature directory with state.json"""
    feat_dir = env / ".spex" / name
    feat_dir.mkdir(parents=True)
    state = {
        "featureName": name,
        "currentState": "INIT",
        "stateHistory": [{"state": "INIT", "timestamp": datetime.now().isoformat()}],
        "context": {"planId": "P-TEST-1"},
        "metadata": {"createdAt": datetime.now().isoformat(), "updatedAt": datetime.now().isoformat()}
    }
    with open(feat_dir / "state.json", "w") as f:
        json.dump(state, f)
    return feat_dir

def test_valid_transition_init_to_research(temp_spex_env):
    init_feature(temp_spex_env, "feat1")
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH_CODE"])
    assert res.returncode == 0
    data = json.loads(res.stdout)
    assert data["valid"] is True
    assert data["nextState"] == "RESEARCH_CODE"
    
    # Verify state.json was updated
    with open(temp_spex_env / ".spex/feat1/state.json", "r") as f:
        state = json.load(f)
        assert state["currentState"] == "RESEARCH_CODE"
        assert len(state["stateHistory"]) == 2

def test_invalid_transition(temp_spex_env):
    init_feature(temp_spex_env, "feat1")
    # INIT -> GENERATE_PLAN is invalid
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    data = json.loads(res.stdout)
    assert data["valid"] is False
    assert "Invalid transition" in data["error"]

def test_missing_artifact_enforcement(temp_spex_env):
    init_feature(temp_spex_env, "feat1")

    # First move to RESEARCH_CODE
    run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH_CODE"])
    
    # Now try to move to RESEARCH_MEMORY without research.json
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH_MEMORY"])
    assert res.returncode != 0
    data = json.loads(res.stdout)
    assert data["valid"] is False
    assert "Missing research.json" in data["error"]

def test_valid_research_memory_transition(temp_spex_env):
    feat_dir = init_feature(temp_spex_env, "feat1")
    run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH_CODE"])
    
    # Create research.json
    with open(feat_dir / "research.json", "w") as f:
        json.dump({"codebase": {"facts": []}}, f)
        
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "RESEARCH_MEMORY"])
    assert res.returncode == 0
    assert json.loads(res.stdout)["valid"] is True

def test_generate_plan_requires_memory_facts(temp_spex_env):
    feat_dir = init_feature(temp_spex_env, "feat1")
    # Fast track to RESEARCH_MEMORY
    with open(feat_dir / "state.json", "r") as f:
        state = json.load(f)
        state["currentState"] = "RESEARCH_MEMORY"
        with open(feat_dir / "state.json", "w") as wf:
            json.dump(state, wf)
            
    # Create research.json WITHOUT 'memory' section
    with open(feat_dir / "research.json", "w") as f:
        json.dump({"codebase": {}}, f)
        
    res = run_spex(temp_spex_env, ["validate-and-route", "--feature-name", "feat1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    assert "missing 'memory' section" in json.loads(res.stdout)["error"]
