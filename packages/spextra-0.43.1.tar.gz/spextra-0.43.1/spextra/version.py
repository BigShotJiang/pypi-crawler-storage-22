from importlib import metadata
version = metadata.version(__package__)
