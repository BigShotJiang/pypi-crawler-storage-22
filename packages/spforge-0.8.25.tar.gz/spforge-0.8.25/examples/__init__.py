from .lol.data.utils import get_sub_sample_lol_data as get_sub_sample_lol_data
from .nba.data.utils import get_sub_sample_nba_data as get_sub_sample_nba_data
