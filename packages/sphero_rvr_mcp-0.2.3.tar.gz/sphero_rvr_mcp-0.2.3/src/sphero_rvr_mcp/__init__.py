"""Sphero RVR MCP Server - Control Sphero RVR with Claude AI."""

__version__ = "0.1.1"
