"""
# ========================================================================
#  sphero_unsw: Extensions and patches for Sphero BOLT+
#  A fork of the original spherov2 library
#
#  Copyright (c) 2019-2021
#      Hanbang Wang,  https://www.cis.upenn.edu/~hanbangw
#      Elionardo Feliciano
#  Original project: https://github.com/EnotPoloskun/spherov2.py
#
#  library spherov2 was originally created for educational use in CIS 521: 
#  Artificial Intelligence at the University of Pennsylvania, where Sphero 
#  robots are used to help teach the foundations of AI.
#
#
#  This extension was developed by:
#       Kathryn Kasmarik (kathryn.kasmarik@unsw.edu.au)
#       Reda Ghanem (reda.ghanem@unsw.edu.au)
#  From the School of Systems and Computing, UNSW Canberra, to support the Sphero BOLT+ robot.
#
#  This extension has been developed for educational use as part of the course ZEIT1102:
#  Introduction to Programming at the University of New South Wales, Canberra (UNSW Canberra).
#  It is specifically designed to support students in learning programming fundamentals and 
#  introductory robotics concepts through hands-on activities using Sphero BOLT+ robots.
#
#  |---------------------------------------------------------------------|
#  | Version: 0.1.9                                                      |
#  | License: MIT License                                                |
#  | Repository: https://github.com/redaghanem/sphero_unsw               |
#  | Pypi package: https://pypi.org/project/sphero-unsw                  |
#  |---------------------------------------------------------------------|
#
# ========================================================================
"""

# ------------------------------------------------------------------------- #
# [1] Import necessary libraries
# ------------------------------------------------------------------------- #

from collections import OrderedDict
from enum import IntEnum
from functools import partialmethod, lru_cache

# Import all necessary classes and functions from sphero_unsw
from sphero_unsw.commands.api_and_shell import ApiAndShell
from sphero_unsw.commands.connection import Connection
from sphero_unsw.commands.drive import Drive
from sphero_unsw.commands.firmware import Firmware
from sphero_unsw.commands.io import IO
from sphero_unsw.commands.power import Power
from sphero_unsw.commands.sensor import Sensor              # new import for Sphero UNSW
from sphero_unsw.commands.system_info import SystemInfo
from sphero_unsw.controls.v2 import AnimationControl, DriveControl, LedControl, SensorControl, StatsControl, Processors
from sphero_unsw.toy import ToyV2, Toy, ToySensor
from sphero_unsw.types import ToyType


# ------------------------------------------------------------------------- #
# [2] Create a new class Sensor that inherits from ToyV2
# ------------------------------------------------------------------------- #
class BOLTPLUS(ToyV2):
    toy_type = ToyType('Sphero BOLT', 'BP-', 'BP', .075) 
    #_handshake = [('00020005-574f-4f20-5370-6865726f2121', bytearray(b'usetheforce...band'))] #TODO: find correct info here



    class LEDs(IntEnum):
        FRONT_RED = 0
        FRONT_GREEN = 1
        FRONT_BLUE = 2
        BACK_RED = 3
        BACK_GREEN = 4
        BACK_BLUE = 5

    # Sensors Available:
    sensors = OrderedDict(
        quaternion=OrderedDict(
            x=ToySensor(0x2000000, -1., 1.),
            y=ToySensor(0x1000000, -1., 1.),
            z=ToySensor(0x800000, -1., 1.),
            w=ToySensor(0x400000, -1., 1.)
        ),
        attitude=OrderedDict(
            pitch=ToySensor(0x40000, -179., 180.),
            roll=ToySensor(0x20000, -179., 180.),
            yaw=ToySensor(0x10000, -179., 180.)
        ),
        accelerometer=OrderedDict(
            x=ToySensor(0x8000, -8.19, 8.19),
            y=ToySensor(0x4000, -8.19, 8.19),
            z=ToySensor(0x2000, -8.19, 8.19)
        ),
        accel_one=OrderedDict(accel_one=ToySensor(0x200, 0., 8000.)),
        locator=OrderedDict(
            x=ToySensor(0x40, -32768., 32767., lambda x: x * 100.),
            y=ToySensor(0x20, -32768., 32767., lambda x: x * 100.),
        ),
        velocity=OrderedDict(
            x=ToySensor(0x10, -32768., 32767., lambda x: x * 100.),
            y=ToySensor(0x8, -32768., 32767., lambda x: x * 100.),
        ),
        speed=OrderedDict(speed=ToySensor(0x4, 0., 32767.)),
        core_time=OrderedDict(core_time=ToySensor(0x2, 0., 0.))
    )

    extended_sensors = OrderedDict(
        gyroscope=OrderedDict(
            x=ToySensor(0x2000000, -20000., 20000.),
            y=ToySensor(0x1000000, -20000., 20000.),
            z=ToySensor(0x800000, -20000., 20000.)
        ),
        ambient_light=OrderedDict(
            ambient_light=ToySensor(0x40000, 120000., 120000.))
    )

    # Bolt Supported calls
    # API and Shell:
    get_api_protocol_version = ApiAndShell.get_api_protocol_version  # GetApiProtocolVersionCommand
    get_supported_cids = ApiAndShell.get_supported_cids  # GetSupportedCidsCommand
    get_supported_dids = ApiAndShell.get_supported_dids  # GetSupportedDidsCommand
    ping = ApiAndShell.ping  # PingCommand
    send_command_to_shell = ApiAndShell.send_command_to_shell  # SendCommandToShellCommand
    add_send_string_to_console_listener = partialmethod(Toy._add_listener,
                                                        ApiAndShell.send_string_to_console)  # SendStringToConsoleCommand
    remove_send_string_to_console_listener = partialmethod(Toy._remove_listener,
                                                           ApiAndShell.send_string_to_console)  # SendStringToConsoleCommand

    # Connection
    get_bluetooth_advertising_name = Connection.get_bluetooth_advertising_name  # GetBluetoothAdvertisingNameCommand
    get_bluetooth_name = Connection.get_bluetooth_name  # GetBluetoothNameCommand
    set_bluetooth_name = Connection.set_bluetooth_name  # SetBluetoothNameCommand

    #Drive - Driving done on the Secondary Processor
    drive_with_heading = partialmethod(Drive.drive_with_heading,
                                                      proc=Processors.PRIMARY) #DriveWithHeadingCommand
    reset_yaw = partialmethod(Drive.reset_yaw,
                                                      proc=Processors.PRIMARY) #ResetYawCommand
    set_pitch_torque_modification_value = partialmethod(Drive.set_pitch_torque_modification_value,
                                                      proc=Processors.PRIMARY) #SetPitchTorqueModificationValueCommand
    set_raw_motors = partialmethod(Drive.set_raw_motors,
                                                      proc=Processors.PRIMARY) #SetRawMotorsCommand
    set_stabilization = partialmethod(Drive.set_stabilization,
                                                      proc=Processors.PRIMARY) #SetStabilizationCommand

    # Firmware
    get_pending_update_flags = Firmware.get_pending_update_flags  # GetPendingUpdateFlagsCommand

    # IO - most LED/Matrix stuff is done on Secondary Processor, if issues check that
    assign_compressed_frame_player_frames_to_animation = partialmethod(
        IO.assign_compressed_frame_player_frames_to_animation,
        proc=Processors.PRIMARY)  # AssignCompressedFramePlayerFramesToAnimationCommand
    add_compressed_frame_player_animation_complete_notify_listener = partialmethod(
        Toy._add_listener,
        IO.compressed_frame_player_animation_complete_notify)  # CompressedFramePlayerAnimationCompleteNotifyCommand
    remove_compressed_frame_player_animation_complete_notify_listener = partialmethod(
        Toy._remove_listener,
        IO.compressed_frame_player_animation_complete_notify)  # CompressedFramePlayerAnimationCompleteNotifyCommand
    delete_all_compressed_frame_player_animations_and_frames = partialmethod(
        IO.delete_all_compressed_frame_player_animations_and_frames,
        proc=Processors.PRIMARY)  # DeleteAllCompressedFramePlayerAnimationsAndFramesCommand
    draw_compressed_frame_player_fill = partialmethod(IO.draw_compressed_frame_player_fill,
                                                      proc=Processors.PRIMARY)  # DrawCompressedFramePlayerFillCommand
    draw_compressed_frame_player_line = partialmethod(IO.draw_compressed_frame_player_line,
                                                      proc=Processors.PRIMARY)  # DrawCompressedFramePlayerLineCommand
    get_compressed_frame_player_list_of_frames = partialmethod(IO.get_compressed_frame_player_list_of_frames,
                                                               proc=Processors.PRIMARY)  # GetCompressedFramePlayerListOfFramesCommand
    override_compressed_frame_player_animation_global_settings = partialmethod(
        IO.override_compressed_frame_player_animation_global_settings,
        proc=Processors.PRIMARY)  # OverrideCompressedFramePlayerAnimationGlobalSettingsCommand
    pause_compressed_frame_player_animation = partialmethod(IO.pause_compressed_frame_player_animation,
                                                            proc=Processors.PRIMARY)  # PauseCompressedFramePlayerAnimationCommand
    play_compressed_frame_player_animation = partialmethod(IO.play_compressed_frame_player_animation,
                                                           proc=Processors.PRIMARY)  # PlayCompressedFramePlayerAnimationCommand
    play_compressed_frame_player_animation_with_loop_option = partialmethod(
        IO.play_compressed_frame_player_animation_with_loop_option,
        proc=Processors.PRIMARY)  # PlayCompressedFramePlayerAnimationWithLoopOptionCommand
    play_compressed_frame_player_frame = partialmethod(IO.play_compressed_frame_player_frame,
                                                       proc=Processors.PRIMARY)  # PlayCompressedFramePlayerFrameCommand
    reset_compressed_frame_player_animation = partialmethod(IO.reset_compressed_frame_player_animation,
                                                            proc=Processors.PRIMARY)  # ResetCompressedFramePlayerAnimationCommand
    resume_compressed_frame_player_animation = partialmethod(IO.resume_compressed_frame_player_animation,
                                                             proc=Processors.PRIMARY)  # ResumeCompressedFramePlayerAnimationCommand
    save_compressed_frame_player64_bit_frame = partialmethod(IO.save_compressed_frame_player64_bit_frame,
                                                             proc=Processors.PRIMARY)  # SaveCompressedFramePlayer64BitFrameCommand
    save_compressed_frame_player_animation = partialmethod(IO.save_compressed_frame_player_animation,
                                                           proc=Processors.PRIMARY)  # SaveCompressedFramePlayerAnimationCommand
    save_compressed_frame_player_animation_without_frames = partialmethod(
        IO.save_compressed_frame_player_animation_without_frames,
        proc=Processors.PRIMARY)  # SaveCompressedFramePlayerAnimationWithoutFramesCommand
    set_all_leds_with_8_bit_mask = partialmethod(IO.set_all_leds_with_8_bit_mask,
                                                 proc=Processors.PRIMARY)  # SetAllLedsWith8BitMaskCommand
    set_compressed_frame_player = partialmethod(IO.set_compressed_frame_player,
                                                proc=Processors.PRIMARY)  # SetCompressedFramePlayerCommand
    set_compressed_frame_player_frame_rotation = partialmethod(IO.set_compressed_frame_player_frame_rotation,
                                                               proc=Processors.PRIMARY)  # SetCompressedFramePlayerFrameRotationCommand
    set_compressed_frame_player_one_color = partialmethod(IO.set_compressed_frame_player_one_color,
                                                          proc=Processors.PRIMARY)  # SetCompressedFramePlayerOneColorCommand
    set_compressed_frame_player_pixel = partialmethod(IO.set_compressed_frame_player_pixel,
                                                      proc=Processors.PRIMARY)  # SetCompressedFramePlayerPixelCommand
    set_compressed_frame_player_single_character = partialmethod(IO.set_compressed_frame_player_single_character,
                                                                 proc=Processors.PRIMARY)  # SetCompressedFramePlayerSingleCharacterCommand
    set_compressed_frame_player_text_scrolling = partialmethod(IO.set_compressed_frame_player_text_scrolling,
                                                               proc=Processors.PRIMARY)  # SetCompressedFramePlayerTextScrollingCommand
    add_compressed_frame_player_animation_complete_notify = partialmethod(
        Toy._add_listener,
        IO.set_compressed_frame_player_text_scrolling_notify)  # SetCompressedFramePlayerTextScrollingNotifyCommand
    remove_compressed_frame_player_animation_complete_notify_listener = partialmethod(
        Toy._remove_listener,
        IO.set_compressed_frame_player_text_scrolling_notify)  # SetCompressedFramePlayerTextScrollingNotifyCommand
    set_led = partialmethod(IO.set_led, proc=Processors.PRIMARY)  # SetLedCommand

    # Testing
    release_led_requests = partialmethod(IO.release_led_requests, proc=Processors.PRIMARY)

    # Power
    add_will_sleep_notify_listener = partialmethod(Toy._add_listener,
                                                   Power.charger_state_changed_notify)  # ChargerStateChangedNotifyCommand
    remove_will_sleep_notify_listener = partialmethod(Toy._remove_listener,
                                                      Power.charger_state_changed_notify)  # ChargerStateChangedNotifyCommand
    add_will_sleep_notify_listener = partialmethod(Toy._add_listener,
                                                   Power.did_sleep_notify)  # DidSleepNotifyCommand
    remove_will_sleep_notify_listener = partialmethod(Toy._remove_listener,
                                                      Power.did_sleep_notify)  # DidSleepNotifyCommand
    enable_battery_voltage_state_change_notify = Power.enable_battery_voltage_state_change_notify  # EnableBatteryVoltageStateChangeNotifyCommand
    enable_charger_state_changed_notify = Power.enable_charger_state_changed_notify  # EnableChargerStateChangedNotifyCommand
    enter_deep_sleep = Power.enter_deep_sleep  # EnterDeepSleepCommand
    get_battery_voltage = Power.get_battery_voltage  # GetBatteryVoltageCommand
    get_battery_voltage_state = Power.get_battery_voltage_state  # GetBatteryVoltageStateCommand
    get_charger_state = Power.get_charger_state  # GetChargerStateCommand
    sleep = Power.sleep  # SleepCommand
    wake = Power.wake  # WakeCommand
    add_will_sleep_notify_listener = partialmethod(Toy._add_listener,
                                                   Power.will_sleep_notify)  # WillSleepNotifyCommand
    remove_will_sleep_notify_listener = partialmethod(Toy._remove_listener,
                                                      Power.will_sleep_notify)  # WillSleepNotifyCommand

    # Sensor
    add_collision_detected_notify_listener = partialmethod(Toy._add_listener,
                                                           Sensor.collision_detected_notify)  # CollisionDetectedNotifyCommand
    remove_collision_detected_notify_listener = partialmethod(Toy._remove_listener,
                                                              Sensor.collision_detected_notify)  # CollisionDetectedNotifyCommand
    
    #######################################################################################
    # NEW CODE TO SUPPORT BOLTPLUS TO SUPPORT BOLT+
    # Enable/disable collision detection notify
    enable_collision_detected_notify = partialmethod(Sensor.enable_collision_detected_notify, proc=Processors.PRIMARY)

    
    configure_collision_detection = partialmethod(Sensor.configure_collision_detection, proc=Processors.PRIMARY)  # ConfigureCollisionDetectionCommand
    #######################################################################################

    
    
    enable_gyro_max_notify = partialmethod(Sensor.enable_gyro_max_notify, proc=Processors.PRIMARY)  # EnableGyroMaxNotifyCommand
    get_ambient_light_sensor_value = partialmethod(Sensor.get_ambient_light_sensor_value, proc=Processors.PRIMARY)
    get_bot_to_bot_infrared_readings = partialmethod(Sensor.get_bot_to_bot_infrared_readings, proc=Processors.PRIMARY)  # GetBotToBotInfraredReadingsCommand
    get_sensor_streaming_mask = partialmethod(Sensor.get_sensor_streaming_mask, proc=Processors.PRIMARY)  # GetSensorStreamingMaskCommand
    set_sensor_streaming_mask = partialmethod(Sensor.set_sensor_streaming_mask, proc=Processors.PRIMARY)  # SetSensorStreamingMaskCommand
    get_extended_sensor_streaming_mask = partialmethod(Sensor.get_extended_sensor_streaming_mask, proc=Processors.PRIMARY)  # GetExtendedSensorStreamingMaskCommand
    set_extended_sensor_streaming_mask = partialmethod(Sensor.set_extended_sensor_streaming_mask, proc=Processors.PRIMARY)  # SetExtendedSensorStreamingMaskCommand
    add_gyro_max_notify_listener = partialmethod(Toy._add_listener, Sensor.gyro_max_notify)  # GyroMaxNotifyCommand
    remove_gyro_max_notify_listener = partialmethod(Toy._remove_listener,
                                                    Sensor.gyro_max_notify)  # GyroMaxNotifyCommand
    listen_for_robot_to_robot_infrared_message = partialmethod(Sensor.listen_for_robot_to_robot_infrared_message, proc=Processors.PRIMARY)  # ListenForRobotToRobotInfraredMessageCommand
    magnetometer_calibrate_to_north = Sensor.magnetometer_calibrate_to_north  # MagnetometerCalibrateToNorthCommand
    add_magnetometer_north_yaw_notify_listener = partialmethod(Toy._add_listener,
                                                               Sensor.magnetometer_north_yaw_notify)  # MagnetometerNorthYawNotifyCommand
    remove_magnetometer_north_yaw_notify_listener = partialmethod(Toy._remove_listener,
                                                                  Sensor.magnetometer_north_yaw_notify)  # MagnetometerNorthYawNotifyCommand
    reset_locator_x_and_y = partialmethod(Sensor.reset_locator_x_and_y, proc=Processors.PRIMARY)  # ResetLocationXAndYCommand
    add_robot_to_robot_infrared_message_received_notify_listener = partialmethod(Toy._add_listener, Sensor.robot_to_robot_infrared_message_received_notify)  ##RobotToRobotInfraredMessageReceivedNotifyCommand
    remove_robot_to_robot_infrared_message_received_notify_listener = partialmethod(Toy._remove_listener,
                                                                                    Sensor.robot_to_robot_infrared_message_received_notify)  # RobotToRobotInfraredMessageReceivedNotifyCommand
    send_robot_to_robot_infrared_message = partialmethod(Sensor.send_robot_to_robot_infrared_message, proc=Processors.PRIMARY)  # SendRobotToRobotInfraredMessageCommand
    add_sensor_streaming_data_notify_listener = partialmethod(Toy._add_listener,
                                                              Sensor.sensor_streaming_data_notify)  # SensorStreamingDataNotifyCommand
    remove_sensor_streaming_data_notify_listener = partialmethod(Toy._remove_listener,
                                                                 Sensor.sensor_streaming_data_notify)  # SensorStreamingDataNotifyCommand
    set_locator_flags = partialmethod(Sensor.set_locator_flags, proc=Processors.PRIMARY)  # SetLocatorFlagsCommand
    start_robot_to_robot_infrared_broadcasting = partialmethod(Sensor.start_robot_to_robot_infrared_broadcasting, proc=Processors.PRIMARY)  # StartRobotToRobotInfraredBroadcastingCommand
    start_robot_to_robot_infrared_evading = partialmethod(Sensor.start_robot_to_robot_infrared_evading, proc=Processors.PRIMARY)  # StartRobotToRobotInfraredEvadingCommand
    start_robot_to_robot_infrared_following = partialmethod(Sensor.start_robot_to_robot_infrared_following, proc=Processors.PRIMARY)  # StartRobotToRobotInfraredFollowingCommand
    stop_robot_to_robot_infrared_broadcasting = partialmethod(Sensor.stop_robot_to_robot_infrared_broadcasting, proc=Processors.PRIMARY)  # StopRobotToRobotInfraredBroadcastingCommand
    stop_robot_to_robot_infrared_evading = partialmethod(Sensor.stop_robot_to_robot_infrared_evading, proc=Processors.PRIMARY)  # StopRobotToRobotInfraredEvadingCommand
    stop_robot_to_robot_infrared_following = partialmethod(Sensor.stop_robot_to_robot_infrared_following, proc=Processors.PRIMARY)  # StopRobotToRobotInfraredFollowingCommand

    # System Info
    erase_config_block = SystemInfo.erase_config_block  # EraseConfigBlockCommand
    get_board_revision = SystemInfo.get_board_revision  # GetBoardRevisionCommand
    get_boot_reason = SystemInfo.get_boot_reason  # GetBootReasonCommand
    get_bootloader_version = SystemInfo.get_bootloader_version  # GetBootloaderVersionCommand
    get_secondary_mcu_bootloader_version = SystemInfo.get_secondary_mcu_bootloader_version
    get_config_block = SystemInfo.get_config_block  # GetConfigBlockCommand
    get_last_error_info = SystemInfo.get_last_error_info  # GetLastErrorInfoCommand
    get_mac_address = SystemInfo.get_mac_address  # GetMacAddressCommand
    get_main_app_version = SystemInfo.get_main_app_version  # GetMainAppVersionCommand
    get_secondary_main_app_version = SystemInfo.get_secondary_main_app_version
    get_manufacturing_date = SystemInfo.get_manufacturing_date  # GetManufacturingDateCommand
    get_processor_name = SystemInfo.get_processor_name  # GetProcessorNameCommand
    get_sku = SystemInfo.get_sku  # GetSkuCommand
    get_stats_id = SystemInfo.get_stats_id  # GetStatsIdCommand
    get_swd_locking_status = SystemInfo.get_swd_locking_status  # GetSwdLockingStatusCommand
    set_config_block = SystemInfo.set_config_block  # SetConfigBlockCommand
    write_config_block = SystemInfo.write_config_block  # WriteConfigBlockCommand

    # Controls - V2
    @property
    @lru_cache(None)
    def animation_control(self):
        return AnimationControl(self)

    @property
    @lru_cache(None)
    def drive_control(self):
        return DriveControl(self)

    @property
    @lru_cache(None)
    def multi_led_control(self):
        return LedControl(self)

    @property
    def sensor_control(self):
        if self._sensor_controller is None: #Make a new SensorControl if necessary (NOT A UTIL CLASS)
            self._sensor_controller = SensorControl(self)
        return self._sensor_controller

    @property
    @lru_cache(None)
    def stats_control(self):
        return StatsControl(self)
