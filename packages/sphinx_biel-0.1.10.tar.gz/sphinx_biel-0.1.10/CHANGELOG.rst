=========
Changelog
=========

All notable changes to this project will be documented in this file.


[0.1.10] - 17 February 2026

Added
-----

* New ``hide_connect_button`` field for hiding the connect button.
* New ``hide_settings_button`` field for hiding the settings button.
* New ``initial_messages`` field for configuring initial messages.
* New ``keep_conversation`` field for keeping the conversation.
* New ``connect_button_text`` field for configuring the connect button text.
* New ``mcp_claude_copied_description`` field for configuring MCP Claude copied description.
* New ``mcp_claude_description`` field for configuring MCP Claude description.
* New ``mcp_claude_text`` field for configuring MCP Claude text.
* New ``mcp_copied_text`` field for configuring MCP copied text.
* New ``mcp_copilot_description`` field for configuring MCP Copilot description.
* New ``mcp_copilot_text`` field for configuring MCP Copilot text.
* New ``mcp_cursor_description`` field for configuring MCP Cursor description.
* New ``mcp_cursor_text`` field for configuring MCP Cursor text.
* New ``mcp_server_url`` field for configuring the MCP server URL.
* New ``mcp_url_copied_description`` field for configuring MCP URL copied description.
* New ``mcp_url_description`` field for configuring MCP URL description.
* New ``mcp_url_text`` field for configuring MCP URL text.
* New ``settings_button_text`` field for configuring the settings button text.
* New ``think_mode_auto_description`` field for configuring think mode auto description.
* New ``think_mode_auto_text`` field for configuring think mode auto text.
* New ``think_mode_fast_description`` field for configuring think mode fast description.
* New ``think_mode_fast_text`` field for configuring think mode fast text.
* New ``think_mode_think_description`` field for configuring think mode think description.
* New ``think_mode_think_text`` field for configuring think mode think text.

[0.1.9] - 04 February 2026


* New ``metadata`` field.

[0.1.7] - 11 November 2025

Added
-----

* New ``hide_think_mode_button`` field for hiding the think mode button.
* New ``hide_tooltips`` field for hiding the tooltips.
* New ``think_mode_enabled`` field for enabling the think mode.
* New ``think_mode_button_text`` field for configuring the think mode button text.

[0.1.7] - 15 September 2025
===========================

Added
-----

* New ``hide_sources`` field for hiding sources.


[0.1.6] - 29 August 2025
========================

Added
-----

* New ``ai_icon`` field for configuring the AI icon type.
* New ``hide_avatars`` field for hiding avatar display.

[1.0.5] - 22 June 2025
=======================

Added
-----

* New ``api_key`` field for configuration.

[1.0.4] - 24 May 2025
======================

Changed
-------

* Enhanced BielExtension with additional configuration options: ``disable_input``, ``email``, ``expand_modal``, ``hide_close_button``, ``hide_expand_button``, ``hide_refresh_button``, ``hide_feedback``, ``modal_position``, ``show_terms_modal``, ``error_message_4_0_3``, ``error_message_4_0_4``, ``error_message_default``, ``footer_text``, ``header_title``, ``input_placeholder_text``, ``send_button_text``, ``sources_text``, ``suggested_questions``, ``suggested_questions_title``, ``terms_checkbox_text``, ``terms_description``, ``terms_title``, ``welcome_message``.

[1.3.3] - 16 April 2025
========================

Added
-----

* Latest configuration options including ``custom_font``, ``email``, ``hide_icon``, ``input_placeholder_text``, ``send_button_text``, ``suggested_questions_title``, ``show_terms_modal``, ``terms_title``, ``terms_description``, and ``terms_checkbox_text``.

[0.1.2] - 24 February 2025
===========================

Changed
-------

* Open source code release.

[0.1.0] - 03 August 2023
========================

Added
-----

* Initial code release.
