project = "Testdocs"
author = "Documatt.com, s.r.o."
copyright = f"%Y, {author}"

extensions = [
    "sphinx.ext.napoleon",
    "sphinx.ext.autodoc",
    "sphinx.ext.autosummary",
    "sphinx.ext.todo",
    "sphinx.ext.viewcode",
    "myst_parser",
    "sphinx_design",
]

html_theme = "sphinx_clarity_theme"

html_logo = "_static/logo.svg"
# html_logo = None
html_favicon = "_static/favicon.svg"

html_theme_options = {
    # "default_layout": "default",
    "language_select": {"en": "English", "cs": "čeština", "ua": "український"},
    "language_url": "/{language}/{page}",
    "logo_dark": "_static/logo-dark.svg",
    # "logo_dark_invert": True,
    "header_menu": [
        {
            "label": "Getting Started",
            "url": "some/url",
        },
        {
            "label": "Pricing ",
            "url": "some/url",
        },
        {
            "label": "Too much",
            "url": "some/url",
        },
        {
            "label": 'Download <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width: 1em; height: 1em; vertical-align: -0.125em;" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="4" ry="4" fill="none"/><path d="M12 7c-1.657 0-3 1.343-3 3s1.343 3 3 3 3 1.343 3 3-1.343 3-3 3" /><line x1="12" y1="4" x2="12" y2="20" /></svg>',
            "url": "some/url",
            "as": "button",
        },
    ],
}
html_baseurl = "https://documatt.com/testdocs/"

html_static_path = ["_static"]

highlight_language = "none"

html_permalinks_icon = "#"

# -- Options for Markdown ----------------------------------------------------
# https://myst-parser.readthedocs.io/en/latest/configuration.html

myst_enable_extensions = [
    "attrs_inline",
    "attrs_block",
    "deflist",
    "tasklist",
    "linkify",
    "substitution",
    "html_image",
    "colon_fence",
    "strikethrough",
]

myst_substitutions = {
    "project": project,
    "author": author,
}

# Auto-generated heading anchors
# Allows
#       See settings's [HOME option](../ref/settings.md#HOME).
myst_heading_anchors = 6

# Linky only those that begin with a schema (http://, etc.). Now `documatt.com` will not be converted to a link.
myst_linkify_fuzzy_links = False
