"""Sphinx Lookup - Lightweight CLI for querying the LLM Attack Database via Supabase REST API.

No Docker, Redis, or Elasticsearch required. Just install and connect to Supabase.

Usage:
    pip install sphinx-lookup
    sphinx-lookup configure
    sphinx-lookup search "prompt injection"
"""

__version__ = "0.2.1"
