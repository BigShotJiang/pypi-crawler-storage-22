# Sphinx Lookup

**Lightweight CLI for querying the Sphinx Scanner LLM Attack Database**

Query 1900+ documented LLM/AI attacks directly from your terminal. No Docker, Redis, or Elasticsearch required — just 4 dependencies.

## Installation

```bash
pip install sphinx-lookup
```

## Quick Start

```bash
# Configure your Supabase credentials (one-time setup)
sphinx-lookup configure

# Search for attacks
sphinx-lookup search "prompt injection"

# List attacks by category
sphinx-lookup list --category jailbreak

# Show full attack details
sphinx-lookup show <attack-id>

# View statistics
sphinx-lookup stats
```

## Commands

| Command | Description |
|---------|-------------|
| `configure` | Interactive setup for Supabase credentials |
| `search <query>` | Search attacks by name or description |
| `list` | List attacks with optional filters |
| `show <id>` | Display full attack card (Steckbrief) |
| `categories` | Show category breakdown with counts |
| `stats` | Database overview statistics |

## Attack Categories

- `prompt_injection` - Manipulating LLM behavior through crafted prompts
- `jailbreak` - Bypassing safety filters and restrictions
- `adversarial_input` - Inputs designed to cause unexpected behavior
- `data_extraction` - Extracting training data or sensitive information
- `model_manipulation` - Altering model weights or behavior
- `denial_of_service` - Causing service disruption
- `privacy_attack` - Violating user privacy
- `agent_manipulation` - Targeting AI agents and tool use

## Modalities

Filter attacks by input type: `text`, `reasoning`, `vision`, `audio`, `multimodal`, `code`

```bash
sphinx-lookup list --modality vision
```

## Configuration

Credentials are read in this order (later overrides earlier):
1. `.env` in current directory
2. `~/.sphinx-lookup.env`
3. Environment variables (`SUPABASE_URL`, `SUPABASE_KEY`)

## Requirements

- Python 3.10+
- Supabase project with Sphinx Scanner database

## Part of Sphinx Scanner

This is the lightweight lookup CLI from the [Sphinx Scanner](https://github.com/sphinx-scanner/sphinx-scanner) project. For the full crawling and extraction pipeline, see the main project.

## License

MIT
