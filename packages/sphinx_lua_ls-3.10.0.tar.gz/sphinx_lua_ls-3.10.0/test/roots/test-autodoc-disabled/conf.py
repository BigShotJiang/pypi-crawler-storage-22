project = "Test"
copyright = "test"
author = "test"

extensions = ["sphinx_lua_ls"]
lua_ls_backend = "disable"
lua_ls_apidoc_roots = {"mod": "api"}
