Test autodoc
============

.. container:: regression

   .. lua:autoobject:: SomeObject
