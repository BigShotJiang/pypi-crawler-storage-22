project = "Test"
copyright = "test"
author = "test"

extensions = ["sphinx_lua_ls"]
lua_ls_backend = "emmylua"
lua_ls_project_root = "lua"
lua_ls_class_default_function_name = "__init"
lua_ls_class_default_force_non_colon = True
lua_ls_class_default_force_return_self = True
