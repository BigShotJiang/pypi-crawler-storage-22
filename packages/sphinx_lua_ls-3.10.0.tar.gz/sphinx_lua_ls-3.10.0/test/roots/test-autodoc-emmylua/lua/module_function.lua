--- Documentation.
return function() end
