Annotations
===========

.. container:: regression

   .. lua:module:: annotations

   .. lua:autoobject:: annotation_private

   .. lua:autoobject:: annotation_protected

   .. lua:autoobject:: annotation_package

   .. lua:autoobject:: annotation_async

   .. lua:autoobject:: annotation_deprecated

   .. lua:autoobject:: see_one

   .. lua:autoobject:: see_one_broken

   .. lua:autoobject:: see_many

   .. lua:autoobject:: see_many_broken

   Ref: :lua:obj:`annotation_deprecated`.
