Doctype
=======

.. container:: regression

   .. lua:autoobject:: doctype
      :members:

   .. lua:automethod:: doctype.foo(customSignature)
