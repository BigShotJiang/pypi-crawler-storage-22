Signatures
==========

.. container:: regression

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-doc-from: class

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-doc-from: both

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-doc-from: ctor

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-doc-from: separate

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-doc-from: none

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-signature: bases

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-signature: both

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-signature: ctor

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-signature: minimal

   .. lua:autoobject:: signatures.Bases
      :no-index:
      :class-signature: minimal

   .. lua:autoobject:: signatures.Ctor
      :no-index:
      :class-signature: minimal

   .. lua:autoobject:: signatures.Both
      :no-index:
      :class-signature: minimal

   .. lua:autoobject:: signatures.CtorOverloads
      :no-index:
