--- @meta

--- Description
--- !doctype module
--- @class globals_2
local globals_2 = {}

--- Description
function globals_2.foo() end

--- Description
--- @type integer
GLOBAL_BAR = 1
