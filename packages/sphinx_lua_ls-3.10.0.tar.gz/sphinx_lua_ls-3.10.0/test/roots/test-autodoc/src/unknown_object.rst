Unknown object
==============

.. container:: regression

   .. lua:autoobject:: unknown_module.UnknownObject
