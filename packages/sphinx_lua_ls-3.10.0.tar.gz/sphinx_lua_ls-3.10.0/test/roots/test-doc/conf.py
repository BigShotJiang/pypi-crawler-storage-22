project = "Test"
copyright = "test"
author = "test"

extensions = ["sphinx_lua_ls"]
lua_ls_backend = "emmylua"
lua_ls_project_root = "lua"
lua_ls_project_directories = []
