Modules
=======

.. container:: regression

   .. lua:data:: object_before_module

   .. lua:module:: module

   .. lua:data:: object_after_module

   .. lua:data:: object_redefines_module_to_global
      :module:

   .. lua:data:: object_redefines_module_to_module_2
      :module: module_2

   .. lua:module:: module_2

   .. lua:data:: object_after_module_2

   .. lua:currentmodule:: current_module

   .. lua:data:: object_after_current_module

   .. lua:currentmodule:: None

   .. lua:data:: object_after_current_module_none
