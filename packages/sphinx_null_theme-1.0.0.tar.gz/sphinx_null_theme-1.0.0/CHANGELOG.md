# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v1.0.0] - 2026-02-02

- removed: `display_local_toc` function added to Jinja context in favor of Sphinx standard [`display_toc`](https://www.sphinx-doc.org/en/master/development/html_themes/templating.html#display_toc). Affected themes shoud simply replace `display_local_toc` with `display_toc`.

## [v0.1.3] - 2026-01-31

- fixed: Search results in themes are empty. Null injected required Sphinx search scripts in non-existing Jinja block.

## [v0.1.2] - 2025-12-24

- initial release for PyPI
