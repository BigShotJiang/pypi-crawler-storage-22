===================
Pre-defined Objects
===================

.. autoobj:: obj:version

.. autoobj:: obj:autoconfval

.. autoobj:: obj:example

.. autoobj:: obj:autoobj
