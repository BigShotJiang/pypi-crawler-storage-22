"""
Test package for SPKMC.

This package contains tests for the different SPKMC modules.
"""
