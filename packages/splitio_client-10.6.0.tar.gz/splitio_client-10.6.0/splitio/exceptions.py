"""This module contains everything related to split.io exceptions"""
from splitio.client.factory import TimeoutException
from splitio.storage.adapters.redis import SentinelConfigurationException
