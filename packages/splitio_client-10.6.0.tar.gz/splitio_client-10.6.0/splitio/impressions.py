"""Compatibility module for impressions listener."""

from splitio.client.listener import ImpressionListener
