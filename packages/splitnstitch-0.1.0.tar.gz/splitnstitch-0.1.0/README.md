# splitnstitch
Split a data table to create a safe-to-share version or stitch them back together 
