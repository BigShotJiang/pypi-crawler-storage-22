"""Tests for splitzip."""
