"""Version information for opentelemetry-instrumentation-crewai."""

__version__ = "0.1.2"
