"""Unit tests for OpenTelemetry CrewAI Instrumentation."""
