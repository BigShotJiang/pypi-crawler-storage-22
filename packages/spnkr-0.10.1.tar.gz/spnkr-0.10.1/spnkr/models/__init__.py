"""Response models for Halo Infinite API endpoints."""
