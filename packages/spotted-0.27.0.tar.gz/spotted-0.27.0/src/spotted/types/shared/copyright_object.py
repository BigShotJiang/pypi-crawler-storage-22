# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["CopyrightObject"]


class CopyrightObject(BaseModel):
    published: Optional[bool] = None
    """
    The playlist's public/private status (if it should be added to the user's
    profile or not): `true` the playlist will be public, `false` the playlist will
    be private, `null` the playlist status is not relevant. For more about
    public/private status, see
    [Working with Playlists](/documentation/web-api/concepts/playlists)
    """

    text: Optional[str] = None
    """The copyright text for this content."""

    type: Optional[str] = None
    """
    The type of copyright: `C` = the copyright, `P` = the sound recording
    (performance) copyright.
    """
