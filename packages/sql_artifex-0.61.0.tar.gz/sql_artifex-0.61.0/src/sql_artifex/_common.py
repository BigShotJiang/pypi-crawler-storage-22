"""Query building functions."""

from __future__ import annotations

import abc
import enum
import typing
from collections.abc import Iterable
from copy import deepcopy
from typing import Any, TypeVar, override

import caseswitcher

from sql_artifex.types import PGEnum, SQLType

TableType = TypeVar("TableType", bound=type["Table"])
Primitive = bool | int | float | str | bytes | bytearray


class QueryBuilder(abc.ABC):
    """Base for all query builders."""

    @abc.abstractmethod
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""


class SortMixin(QueryBuilder, abc.ABC):
    """Mixin for building sorted expressions."""

    def asc(self) -> Sort:
        """Sort by expression ascending."""
        return Sort(self, SortDirection.ASCENDING)

    def desc(self) -> Sort:
        """Sort by expression descending."""
        return Sort(self, SortDirection.DESCENGIND)


class StringBuilder(QueryBuilder):
    """Simple query builder that returns a given string."""

    def __init__(self, string: str) -> None:
        self.string = string
        super().__init__()

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        return self.string, []


class OperatorMixin(SortMixin, abc.ABC):  # noqa: PLW1641
    def __gt__(self, other: Any) -> Expression:
        return Expression(self, ">", other)

    def __ge__(self, other: Any) -> Expression:
        return Expression(self, ">=", other)

    def __lt__(self, other: Any) -> Expression:
        return Expression(self, "<", other)

    def __le__(self, other: Any) -> Expression:
        return Expression(self, "<=", other)

    @override
    def __eq__(  # pyright: ignore[reportIncompatibleMethodOverride]
        self, other: object
    ) -> Expression:
        if other is None or other is True or other is False:
            return Expression(self, "IS", other)
        return Expression(self, "=", other)

    @override
    def __ne__(  # pyright: ignore[reportIncompatibleMethodOverride]
        self, other: object
    ) -> Expression:
        if other is None or other is True or other is False:
            return Expression(self, "IS NOT", other)
        return Expression(self, "!=", other)

    def __add__(self, other: Any) -> Expression:
        return Expression(self, "+", other)

    def __sub__(self, other: Any) -> Expression:
        return Expression(self, "-", other)

    def __mul__(self, other: Any) -> Expression:
        return Expression(self, "*", other)

    def __truediv__(self, other: Any) -> Expression:
        return Expression(self, "/", other)

    def __mod__(self, other: Any) -> Expression:
        return Expression(self, "%", other)

    def is_(self, other: Any) -> Expression:
        """Equality operator."""
        if other is None or other is True or other is False:
            return Expression(self, "IS", other)
        return Expression(self, "=", other)

    def is_not(self, other: Any) -> Expression:
        """Inequality operator."""
        if other is None or other is True or other is False:
            return Expression(self, "IS NOT", other)
        return Expression(self, "!=", other)

    def like(self, other: str) -> Expression:
        """Build SQL `LIKE` operator."""
        return Expression(self, "LIKE", other)

    def in_(self, *other: Any | QueryBuilder) -> Expression:
        """Build SQL `IN` operator."""
        return Expression(self, "IN", other)

    def not_in(self, *other: Any | QueryBuilder) -> Expression:
        """Build SQL `NOT IN` operator."""
        return Expression(self, "NOT IN", other)


class AsMixin(OperatorMixin, abc.ABC):
    def as_(self, alias: str) -> As:
        """Alias this sub query as the given name."""
        return As(self, alias)


class Column(AsMixin):
    """Query building object for SQL columns."""

    def __init__(  # noqa: PLR0913
        self,
        sql_type: SQLType | type[PGEnum] | None = None,
        *,
        check: str | None = None,
        default: Any | None = None,
        foreign_key: Column | None = None,
        index: bool = False,
        null: bool = False,
        primary: bool = False,
        unique: bool = False,
        alias: str | None = None,
    ) -> None:
        """Instantiate a column query building object.

        :param sql_type: SQL type of the column.
        :param check: Constraint check as raw SQL.
        :param default: Default value of this column.
        :param foreign_key: Column to add foreign key constraint to.
        :param index: Whether this column is indexed.
        :param null: Whether this column is nullable.
        :param primary: Whether this column is part of primary key.
        :param unique: Whether this column is distinct.
        :param alias: Name to use in queries.
        """
        super().__init__()
        self.name = alias or ""
        self.table = ""
        self.ascending = True
        self.check = check
        self.default = default
        self.foreign_key = foreign_key
        self.index = index
        self.nullable = null
        self.primary = primary
        self.unique = unique
        self.sql_type = sql_type

    @override
    def __str__(self) -> str:
        """Get SQL string representing this column."""
        return f"{self.table}.{self.name}"

    @override
    def __hash__(self) -> int:
        """Get SQL string representing this column."""
        return hash(str(self))

    def _create(self) -> str:
        null = " NOT NULL" if not self.nullable and not self.primary else ""
        unique = " UNIQUE" if self.unique else ""
        check = f" CHECK ({self.check})" if self.check else ""
        if self.default is not None:
            default = " DEFAULT ''" if not self.default else f" DEFAULT {self.default}"
        else:
            default = ""
        if self.foreign_key is not None:
            sql_type = self.foreign_key.sql_type
        elif hasattr(self.sql_type, "pg_enum_name"):
            sql_type = (  # pyright: ignore[reportUnknownVariableType]
                self.sql_type.pg_enum_name()  # pyright: ignore[reportUnknownMemberType, reportAttributeAccessIssue, reportOptionalMemberAccess]
            )
        else:
            sql_type = self.sql_type
        return f'"{self.name}" {sql_type}{default}{null}{unique}{check}'

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get column as SQL."""
        return str(self), []


class Table(type):
    """Represents a SQL table."""

    __table_name__: str = ""
    __table_columns__: dict[str, Column] = {}
    __alias__: str | None = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Instantiate a table subclass."""
        super().__init_subclass__(**kwargs)
        cls.__table_unique__: list[Iterable[Column]] = []
        table_name = cls.__table_name__ or f'"{caseswitcher.to_snake(cls.__name__)}"'
        table_columns: dict[str, Column] = {}
        if not cls.__table_columns__:
            cls_dict: dict[str, Any] = (
                cls.__dict__
            )  # pyright: ignore[reportAssignmentType]
            for attr_name, attr_value in cls_dict.items():
                if isinstance(attr_value, Column):
                    column = getattr(cls, attr_name)
                    if not column.name:
                        column.name = attr_name
                    column.table = cls.__alias__ or table_name
                    table_columns[attr_name] = column
            cls.__table_columns__ = table_columns
        elif cls.__alias__ is not None:
            cls.__table_columns__ = deepcopy(cls.__table_columns__)
            for column in cls.__table_columns__.values():
                column.table = cls.__alias__

        cls.__table_name__ = table_name

    @classmethod
    def table_set_unique_together(cls, *columns: Iterable[Column]) -> None:
        """Mark columns ase unique together.

        :param columns: Columns that are unique together.
        """
        cls.__table_unique__.extend(columns)

    @classmethod
    def table_get_create(cls) -> str:
        """Create table SQL script.

        :param unique: Columns that are unique together.
        :return: Create table SQL script.
        """
        columns: list[str] = []
        foreign_keys: dict[str, list[tuple[str, str]]] = {}
        indexes: list[str] = []
        primaries: list[str] = []
        for col in cls.__table_columns__.values():
            columns.append(col._create())  # pyright: ignore[reportPrivateUsage]
            if fk := col.foreign_key:
                foreign_keys[fk.table] = foreign_keys.get(fk.table) or []
                foreign_keys[fk.table].append((col.name, fk.name))
            if col.index:
                index_name = f"{col.name}_idx"
                indexes.append(
                    "".join(
                        [
                            f'CREATE INDEX IF NOT EXISTS "{index_name}"',
                            f" ON {cls.__table_name__} ({col.name});",
                        ]
                    )
                )
            if col.primary:
                primaries.append(col.name)
        col_str = ",\n  ".join(columns)
        if col_str:
            col_str = "  " + col_str
        for items in cls.__table_unique__:
            unique_cols = ", ".join(f'"{c.name}"' for c in items)
            col_str += f",\n  UNIQUE({unique_cols})"
        fks: list[str] = []
        for table, column_pairs in foreign_keys.items():
            table_cols: list[str] = []
            other_table_cols: list[str] = []
            for pair in column_pairs:
                table_cols.append(pair[0])
                other_table_cols.append(pair[1])
            tc = ", ".join(f'"{it}"' for it in table_cols)
            otc = ", ".join(f'"{it}"' for it in other_table_cols)
            fks.append(f",\n  FOREIGN KEY ({tc}) REFERENCES {table} ({otc})")
        fk_str = "".join(fks)
        idx_str = "\n".join(indexes)
        if idx_str:
            idx_str = "\n" + idx_str
        pk_str = ", ".join(primaries)
        if pk_str:
            pk_str = f",\n  PRIMARY KEY ({pk_str})"
        table = (
            f"CREATE TABLE IF NOT EXISTS {cls.__table_name__}"
            f" (\n{col_str}{pk_str}{fk_str}\n)"
        )
        return f"{table};{idx_str}"


def alias(table: TableType, alias: str) -> TableType:
    table_dict: dict[str, Any] = table.__dict__  # pyright: ignore[reportAssignmentType]
    alias_type = type(
        table.__name__,
        (table,),
        {
            **{"__table_name__": table.__table_name__, "__alias__": alias},
            **{
                attr_name: attr_value
                for attr_name, attr_value in table_dict.items()
                if isinstance(attr_value, Column)
            },
        },
    )
    alias_type.__init_subclass__()
    cls_dict: dict[str, Any] = {}
    alias_dict: dict[str, Any] = (
        alias_type.__dict__
    )  # pyright: ignore[reportAssignmentType]
    for k, v in alias_dict.items():
        if isinstance(v, Column):
            cls_dict[k] = alias_type.__table_columns__[k]
    [setattr(alias_type, k, v) for k, v in cls_dict.items()]
    return alias_type  # pyright: ignore[reportReturnType]


class As(QueryBuilder):
    """As alias."""

    def __init__(self, sub_query: Column | QueryBuilder, alias: str) -> None:
        """Instantiate an `AS` query builder.

        :param sub_query: Query up to this point.
        :param alias: Alias for a variable.
        """
        self._sub_query = sub_query
        self._alias = alias
        super().__init__()

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        if isinstance(self._sub_query, Column):
            return f"{self._sub_query} AS {self._alias}", []
        sql, params = self._sub_query.prepare()
        return f"{sql} AS {self._alias}", params


class Expression(AsMixin):
    """Represent a SQL evaluation."""

    def __init__(
        self,
        left_operand: Column | Expression | OperatorMixin,
        operator: str,
        right_operand: Any | QueryBuilder,
    ) -> None:
        """Instantiate an expression SQL builder.

        :param left_operand: Left operand of the expression.
        :param operator: Operator of the expression.
        :param right_operand: Right operand of the expression.
        """
        super().__init__()
        self.left_operand = left_operand
        self.operator = operator
        self.right_operand = right_operand
        self._params: list[Any] = []

    @override
    def prepare(self) -> tuple[str, list[Any]]:  # noqa: PLR0912
        """Evaluate an operation."""
        other_str = "?"
        params: list[Any] = self._params
        if isinstance(self.right_operand, Column):
            other_str = str(self.right_operand)
        elif isinstance(self.right_operand, QueryBuilder):
            other_str, other_params = self.right_operand.prepare()
            other_str = f"({other_str})"
            params.extend(other_params)
        elif isinstance(self.right_operand, str):
            self._other_str = other_str
            params.append(self.right_operand)
        elif self.right_operand is None:
            other_str = "NULL"
        elif self.right_operand is True:
            other_str = "TRUE"
        elif self.right_operand is False:
            other_str = "FALSE"
        elif isinstance(self.right_operand, enum.Enum):
            params.append(self.right_operand.value)
        elif isinstance(self.right_operand, Iterable):
            other_list: list[Any] = list(self.right_operand)  # type: ignore
            sql_strings: list[str] = []
            for it in other_list:
                if isinstance(it, QueryBuilder):
                    sql, other_params = it.prepare()
                    params.extend(other_params)
                    sql_strings.append(f"({sql})")
                else:
                    params.append(it)
                    sql_strings.append("?")
            other_str = "(" + ", ".join(s for s in sql_strings) + ")"
        else:
            params.append(self.right_operand)
        sql, left_params = self.left_operand.prepare()
        return f"{sql} {self.operator} {other_str}", left_params + params


class BooleanOperator(enum.Enum):
    """Boolean operator options."""

    AND = "AND"
    AND_NOT = "AND NOT"
    OR = "OR"
    OR_NOT = "OR NOT"
    IS = "IS"
    IS_NOT = "IS NOT"
    IN = "IN"
    NOT_IN = "NOT IN"


class SortDirection(enum.Enum):
    """Sort direction."""

    ASCENDING = "ASC"
    DESCENGIND = "DESC"


class Sort(QueryBuilder):
    def __init__(self, subquery: QueryBuilder, direction: SortDirection) -> None:
        super().__init__()
        self.subquery = subquery
        self.sort_direction = direction

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        sql, params = self.subquery.prepare()
        return sql + f" {self.sort_direction.value}", params


if typing.TYPE_CHECKING:
    Expression = bool  # pyright: ignore[reportAssignmentType]
