"""Query building functions."""

from __future__ import annotations

import abc
from collections.abc import Iterable
from typing import Any, Self, override

from sql_artifex._common import (
    AsMixin,
    BooleanOperator,
    Column,
    Expression,
    OperatorMixin,
    Primitive,
    QueryBuilder,
    Table,
)


def _prepare_expressions(
    *expressions: Expression | LogicGate | Paren | QueryBuilder,
) -> tuple[str, list[Any]]:
    sql = ""
    params: list[Any] = []
    for evaluation in expressions:
        s, p = evaluation.prepare()
        sql += s
        params += p
    return sql, params


def _column_str(table_columns: dict[str, Column], column: Column | str) -> str:
    if isinstance(column, Column):
        return f'"{column.name}"'
    column_name = table_columns[column].name
    return f'"{column_name}"'


class LogicGate(QueryBuilder):
    """Represents a SQL boolean operator."""

    def __init__(
        self,
        boolean_operator: BooleanOperator,
        evaluation: Expression,
        *evaluations: Expression | LogicGate,
    ) -> None:
        """Instantiate a logic gate SQL builder.

        :param boolean_operator: Boolean operator for this gate.
        :param evaluation: Expression evaluated.
        :param evaluations: Additional evalutions that will be grouped by parenthesis.
        """
        super().__init__()
        self._evaluations = [evaluation] + list(evaluations)
        self._boolean_operator = boolean_operator

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = _prepare_expressions(*self._evaluations)
        if len(self._evaluations) == 1:
            return f" {self._boolean_operator.value} {sql}", params
        return f" {self._boolean_operator.value} ({sql})", params


class _LimitMixin(AsMixin, abc.ABC):

    def limit(self, limit: int) -> Limit:
        """Limit expression."""
        return Limit(self, limit)


class _OffsetMixin(AsMixin, abc.ABC):

    def offset(self, offset: int) -> Offset:
        """Offset expression."""
        return Offset(self, offset)


class _GroupByMixin(QueryBuilder, abc.ABC):

    def group_by(self, *columns: Column) -> GroupBy:
        """Build a `GROUP BY` SQL builder.

        :param columns: Columns to group by.
        :return: `GROUP BY` SQL builder.
        """
        return GroupBy(self, *columns)


class _PaginateMixin(_OffsetMixin, _LimitMixin, _GroupByMixin, abc.ABC):
    """Combines offset and limit.

    This is as intended.
    """


class _OrderByMixin(AsMixin, abc.ABC):

    def order_by(self, *expressions: QueryBuilder) -> OrderBy:
        """Order by columns."""
        return OrderBy(self, *expressions)


class _WhereMixin(AsMixin, abc.ABC):

    def where(self, *evaluations: Expression | LogicGate | Paren) -> Where:
        """Where expression."""
        return Where(self, *evaluations)

    def where_exists(
        self, *evaluations: Expression | LogicGate | Paren | QueryBuilder
    ) -> Where:
        """Where exists expression."""
        return Where(self, *evaluations, exists=True)

    def where_not_exists(
        self, *evaluations: Expression | LogicGate | Paren | QueryBuilder
    ) -> Where:
        """Where not exists expression."""
        return Where(self, *evaluations, exists=False)


class Join(QueryBuilder):
    """Join operator."""

    def __init__(self, table: type[Table]) -> None:
        """Instantiate a SQL `JOIN` query builder.

        :param table: Table to join to.
        """
        super().__init__()
        self._table = table
        self._on: On | None = None
        self._keyword: str = "JOIN"

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        if self._on is None:
            msg = "No condition set for join, need to call `join.on(...`"
            raise ValueError(msg)
        sql, params = self._on.prepare()
        if self._table.__alias__:
            table_name = f"{self._table.__table_name__} AS {self._table.__alias__}"
            return f"{self._keyword} {table_name} {sql}", params
        return f"{self._keyword} {self._table.__table_name__} {sql}", params

    def on(self, *expressions: Expression | LogicGate | Paren) -> Self:
        """Join on."""
        self._on = On(*expressions)
        return self


class LeftJoin(Join):
    """Left join operator."""

    def __init__(self, table: type[Table]) -> None:
        """Instantiate a SQL `LEFT JOIN` query builder.

        :param table: Table to join to.
        """
        super().__init__(table)
        self._keyword = "LEFT JOIN"


class RightJoin(Join):
    """Right join operator."""

    def __init__(self, table: type[Table]) -> None:
        """Instantiate a SQL `RIGHT JOIN` query builder.

        :param table: Table to join to.
        """
        super().__init__(table)
        self._keyword = "RIGHT JOIN"


class Limit(_OffsetMixin):
    """Limit operator."""

    def __init__(self, subquery: QueryBuilder, limit: int) -> None:
        """Instantiate a SQL `LIMIT` query builder.

        :param subquery: Query to limit results of.
        :param limit: Limit to set.
        """
        super().__init__()
        self.subquery = subquery
        self.limit = limit

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self.subquery.prepare()
        return f"{sql} LIMIT ?", params + [self.limit]


class Literal(QueryBuilder):
    """Use the value as provided in the generated SQL."""

    def __init__(self, value: str) -> None:
        """Use the provided value as-is in generated SQL.

        :param value: SQL string.
        """
        super().__init__()
        self._value = value

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        return self._value, []


class Offset(QueryBuilder):
    """Offset operator."""

    def __init__(self, subquery: QueryBuilder, offset: int) -> None:
        """Instantiate an SQL `OFFSET` query builder.

        :param subquery: Query to offset results of.
        :param offset: Number of rows to offset.
        """
        super().__init__()
        self.subquery = subquery
        self.offset = offset

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self.subquery.prepare()
        return f"{sql} OFFSET ?", params + [self.offset]


class On(_PaginateMixin):
    """On operator."""

    def __init__(self, *expressions: Expression | LogicGate | Paren) -> None:
        """Instation an `ON` SQL builder.

        :param expressions: Condition to join on.
        """
        super().__init__()
        self._expressions = expressions

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = _prepare_expressions(*self._expressions)
        return f"ON {sql}", params


class From(_OrderByMixin, _WhereMixin, _PaginateMixin, _GroupByMixin):
    """SQL `FROM` query builder."""

    def __init__(
        self, subquery: QueryBuilder, table: type[Table], *joins: Join
    ) -> None:
        """Instantiate a `FROM` SQL builder.

        :param subquery: Select query preceding from.
        :param table: Table to select from.
        :param joins: Tables to join on.
        """
        super().__init__()
        self._subquery = subquery
        self._table = table
        self._joins = joins

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        join_sql = ""
        joins_params: list[Any] = []
        for join in self._joins:
            s, p = join.prepare()
            join_sql += " " + s
            joins_params += p

        if self._table.__alias__:
            table_name = f"{self._table.__table_name__} AS {self._table.__alias__}"
        else:
            table_name = self._table.__table_name__
        return f"{sql} FROM {table_name}{join_sql}", params + joins_params


class _FromMixin(QueryBuilder, abc.ABC):
    def from_(self, table: type[Table], *joins: Join) -> From:
        """Build from query."""
        return From(self, table, *joins)


class OrderBy(_PaginateMixin, _GroupByMixin):
    """Order by expression."""

    def __init__(
        self,
        subquery: Select | From | On | _OrderByMixin,
        *expressions: QueryBuilder,
    ) -> None:
        """Instantiate `ORDER BY` SQL builder.

        :param subquery: Query to order.
        :param columns: Columns to order by.
        """
        super().__init__()
        self._subquery = subquery
        self.expressions = list(expressions)

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        sqls: list[str] = []
        for expression in self.expressions:
            s, p = expression.prepare()
            sqls.append(s)
            params.extend(p)
        order_by = ", ".join(sqls)
        return f"{sql} ORDER BY {order_by}", params


class GroupBy(_PaginateMixin):
    """Group by expression."""

    def __init__(self, subquery: QueryBuilder, *columns: Column) -> None:
        """Instantiate `GROUP BY` SQL builder.

        :param subquery: Query to group.
        :param columns: Columns to group by.
        """
        super().__init__()
        self.subquery = subquery
        self.columns = list(columns)

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self.subquery.prepare()
        columns = ", ".join(col.prepare()[0] for col in self.columns)
        return f"{sql} GROUP BY {columns}", params


class _Values(QueryBuilder, abc.ABC):
    """Base class for values query builders."""

    def __init__(self, subquery: InsertInto) -> None:
        super().__init__()
        self._subquery = subquery
        self.table = subquery.table

    def _prepare_row(
        self, values: Iterable[Any | QueryBuilder | None]
    ) -> tuple[str, list[Any]]:
        params: list[Any] = []
        value_strings: list[str] = []
        for value in values:
            if isinstance(value, QueryBuilder):
                value_sql, row_params = value.prepare()
                params.extend(row_params)
                value_strings.append(f"({value_sql})")
            else:
                value_strings.append("?")
                params.append(value)
        return ", ".join(value_strings), params

    def on_conflict(self, *columns: Column | str) -> OnConflict:
        """Build `ON CONFLICT` SQL statement.

        :param columns: Columns to check for conflict.
        :return: `OnConflict` SQL builder.
        """
        return OnConflict(self, *columns)


class Values(_Values):
    """SQL `VALUES` expression."""

    def __init__(
        self, subquery: InsertInto, *values: Iterable[Any | QueryBuilder | None]
    ) -> None:
        """Instantiate a `VALUES` SQL builder.

        :param subquery: Insert query to add values to.
        :param values: Values to insert.
        """
        super().__init__(subquery)
        self.values = values

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        if not self.values:
            return f"{sql} DEFAULT VALUES", []
        if len(self.values) == 1:
            columns = ", ".join(f'"{k}"' for k in self._subquery.columns)
            values, value_params = self._prepare_row(self.values[0])
            return f"{sql} ({columns}) VALUES ({values})", value_params
        columns = ", ".join(f'"{k}"' for k in self._subquery.columns)
        rows: list[str] = []
        for row in self.values:
            row_sql, row_params = self._prepare_row(row)
            rows.append(f"({row_sql})")
            params.extend(row_params)
        rows_str = f"{', '.join(row for row in rows)}"
        return f"{sql} ({columns}) VALUES {rows_str}", params


class DictValues(_Values):
    """SQL `VALUES` expression from dictionary provided values."""

    def __init__(
        self,
        subquery: InsertInto,
        values: dict[str | Column, Any | QueryBuilder | None] | None = None,
    ) -> None:
        """Instantiate a `VALUES` SQL builder.

        :param subquery: Insert query to add values to.
        :param values: Values to insert as a dictionary.
        """
        super().__init__(subquery)
        self.values = values

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, _ = self._subquery.prepare()
        if not self.values:
            return f"{sql} DEFAULT VALUES", []
        column_strs: list[str] = []
        for column in self.values:
            if isinstance(column, Column):
                column_strs.append(f'"{column.name}"')
            else:
                column_name = self._subquery.table.__table_columns__[column].name
                column_strs.append(f'"{column_name}"')
        columns = ", ".join(column_strs)
        value_str, value_params = self._prepare_row(self.values.values())
        return f"{sql} ({columns}) VALUES ({value_str})", value_params


class DoNothing(QueryBuilder):
    """SQL `DO NOTHING` query builder."""

    def __init__(self, subquery: OnConflict) -> None:
        """Instantiate a `DO NOTHING` query builder.

        :param subquery: Query to do nothing after on conflict.
        """
        super().__init__()
        self._subquery = subquery

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        return f"{sql} DO NOTHING", params


class DoUpdate(QueryBuilder):
    """SQL `DO UPDATE` query builder."""

    def __init__(self, subquery: OnConflict) -> None:
        """Instantiate `DO UPDATE` query builder.

        :param subquery: Query to update after conflict.
        """
        super().__init__()
        self._subquery = subquery
        self.table = subquery.table

    def set(self, values: dict[Column | str, Any]) -> Set:
        """Build `SET` clause.

        :param values: Values to set.
        :return: `SET` query builder.
        """
        return Set(self, values)

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        return f"{sql} DO UPDATE", params


class OnConflict(QueryBuilder):
    """SQL `ON CONFLICT` clause builder."""

    def __init__(self, subquery: _Values, *columns: Column | str) -> None:
        """Instantiate `ON CONFLICT` query builder.

        :param subquery: Query that may conflict.
        :param columns: Columns that may conflict.
        """
        super().__init__()
        self._subquery = subquery
        self.table = subquery.table
        self.columns = columns

    def do_update_set(self, values: dict[Column | str, Any]) -> Set:
        """Build `DO UPDATE` clause.

        :param values: Values to update on conflict.
        :return: `SET` query builder.
        """
        return DoUpdate(self).set(values)

    def do_nothing(self) -> DoNothing:
        """Build `DO NOTHING` query."""
        return DoNothing(self)

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        columns = ", ".join(
            _column_str(self.table.__table_columns__, it) for it in self.columns
        )
        return f"{sql} ON CONFLICT ({columns})", params


class Where(_OrderByMixin, _PaginateMixin):
    """Where expression."""

    def __init__(
        self,
        subquery: Select | From | _WhereMixin,
        *expressions: Expression | LogicGate | Paren | QueryBuilder,
        exists: bool | None = None,
    ) -> None:
        """Instantiate a `WHERE` SQL builder.

        :param subquery: Query to filter.
        :param expressions: Expressions to filter by.
        :param exists: Whether to build a `WHERE EXISTS` statement.
        """
        super().__init__()
        self._subquery = subquery
        sql, params = _prepare_expressions(*expressions)
        self._eval_params = params
        self._exists = exists
        self._sql = sql

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        if self._exists is True:
            return f"{sql} WHERE EXISTS ({self._sql})", params + self._eval_params
        if self._exists is False:
            return f"{sql} WHERE NOT EXISTS ({self._sql})", params + self._eval_params
        return f"{sql} WHERE {self._sql}", params + self._eval_params


class Set(_WhereMixin, _FromMixin):
    """Set expression."""

    def __init__(
        self, subquery: DoUpdate | Update, values: dict[Column | str, Any]
    ) -> None:
        """Instantiate a `SET` SQL builder.

        :param subquery: Update query to set values for.
        :param values: Values to set.
        """
        super().__init__()
        self._subquery = subquery
        self.values = values

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self._subquery.prepare()
        sql += " SET "
        sets: list[str] = []
        for column, param in self.values.items():
            if isinstance(param, QueryBuilder):
                sub_q, sub_q_params = param.prepare()
                params.extend(sub_q_params)
                value = f"({sub_q})"
            else:
                params.append(param)
                value = "?"
            column_name = _column_str(self._subquery.table.__table_columns__, column)
            sets.append(f"{column_name} = {value}")
        return sql + ", ".join(sets), params


class InsertInto(QueryBuilder):
    """SQL `INSERT` query builder."""

    def __init__(self, table: type[Table], *args: Column) -> None:
        """Instantiate an `INSERT` SQL builder.

        :param table: Table to insert into.
        :param args: Columns to provide values for.
          If use dict values, dict keys will be used instead.
          If no args are provided all table columns will be used.
        """
        super().__init__()
        self.table = table
        self.columns: list[str] = []
        for arg in args:
            self.columns.append(arg.name)
        if not args:
            self.columns = [str(c) for c in self.table.__table_columns__]

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        return f"INSERT INTO {self.table.__table_name__}", []

    def values(self, *values: Iterable[Any | QueryBuilder | None]) -> Values:
        """Build SQL insert `VALUES` query."""
        return Values(self, *values)

    def dict_values(self, values: dict[Column | str, Any] | None = None) -> DictValues:
        """Build SQL insert `VALUES` query from a dictionary."""
        return DictValues(self, values or {})


class Delete(_FromMixin, _WhereMixin):
    """SQL `DELETE` query builder."""

    def __init__(self, table: type[Table]) -> None:
        """Instantiate a `DELETE` SQL builder.

        :param table: Table to delete from.
        """
        super().__init__()
        self._table = table

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        if self._table.__alias__:
            table_name = f"{self._table.__table_name__} AS {self._table.__alias__}"
        else:
            table_name = self._table.__table_name__
        return f"DELETE FROM {table_name}", []  # noqa: S608


class Select(OperatorMixin):
    """SQL `SELECT` query builder."""

    # Perhaps switch QueryBuilder out with list of valid query builders.
    def __init__(self, *args: Column | QueryBuilder | type[Table]) -> None:
        """Instantiate a `SELECT` SQL builder.

        :param args: Columns to select.
          If a table is provided, all table columns will be selected.
        """
        super().__init__()
        self._columns: list[str] = []
        self._params: list[Any] = []
        self._distinct: bool | None = None
        for arg in args:
            if isinstance(arg, Column):
                self._columns.append(str(arg))
            elif isinstance(arg, QueryBuilder):
                sql, params = arg.prepare()
                self._params.extend(params)
                self._columns.append(sql)
            else:
                self._columns.extend(map(str, arg.__table_columns__.values()))

    def distinct(self) -> Select:
        """Select distinct records."""
        self._distinct = True
        return self

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        distinct = "DISTINCT " if self._distinct is not None else ""
        select = f"SELECT {distinct}{', '.join(self._columns)}"
        return select, self._params

    def from_(self, table: type[Table], *args: Join) -> From:
        """Build SQL FROM expression."""
        return From(self, table, *args)


class Update(QueryBuilder):
    """Build SQL `UPDATE` query."""

    def __init__(self, table: type[Table]) -> None:
        """Instantiate an `UPDATE` SQL builder.

        :param table: Table to update rows of.
        """
        super().__init__()
        self.table = table

    def set(self, values: dict[Column | str, Any | QueryBuilder | None]) -> Set:
        """Build SQL SET expression."""
        return Set(self, values)

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        return f"UPDATE {self.table.__table_name__}", []


class Then(QueryBuilder):
    """SQL `THEN` clause of a when statement builder."""

    def __init__(self, subquery: When, value: QueryBuilder | Primitive) -> None:
        """Instantiate a `THEN` query builder.

        :param subquery: `WHEN` query builder.
        :param query: Value or query builder of query to run when condition is met.
        """
        super().__init__()
        self.subquery = subquery
        self.value = value

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self.subquery.prepare()
        if isinstance(self.value, QueryBuilder):
            query_sql, query_params = self.value.prepare()
            sql = sql + f" THEN {query_sql}"
            return sql, params + query_params
        return sql + " THEN ?", params + [self.value]


class When(QueryBuilder):
    """SQL `WHEN` clause of case statement builder."""

    def __init__(self, *expressions: Expression | LogicGate | Paren) -> None:
        """Instantiate a `WHEN` query builder."""
        super().__init__()
        self.expressions = expressions

    def then(self, value: QueryBuilder | Primitive) -> Then:
        """Build `THEN` clause of a case.

        :param query: Value or query to run when condition is met.
        :return: `THEN` query builder.
        """
        return Then(self, value)

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = _prepare_expressions(*self.expressions)
        return f" WHEN {sql}", params


class Case(QueryBuilder):
    """Build SQL `CASE` statement."""

    def __init__(self, *clauses: Then, else_: QueryBuilder | None) -> None:
        """Instantiate a `CASE` query builder."""
        self.clauses = clauses
        self.else_ = else_
        super().__init__()

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql = "CASE"
        params: list[Any] = []
        for clause in self.clauses:
            s, p = clause.prepare()
            sql += s
            params += p
        if self.else_:
            else_sql, else_params = self.else_.prepare()
            sql += f" ELSE {else_sql}"
            params += else_params
        return sql + " END", params


class Paren(OperatorMixin):
    """Group expressions by parenthesis."""

    def __init__(self, *queries: QueryBuilder) -> None:
        """Instantiate a parenthesis query builder."""
        self.queries = queries
        super().__init__()

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql = ""
        params: list[Any] = []
        for query in self.queries:
            s, p = query.prepare()
            sql += s
            params.extend(p)
        return f"({sql})", params
