# SQL Connector MCP

An MCP (Model Context Protocol) server that provides SQL database connectivity for AI assistants like Claude.

## Features

- **Database Exploration**: List all table names or filter tables by substring
- **Schema Inspection**: Get detailed schema definitions including columns, types, primary keys, and foreign key relationships
- **Query Execution**: Execute SQL queries with parameterized inputs and formatted results
- **Form Fetching**: Retrieve form schemas from database based on trigger keywords

## Installation

```bash
pip install sql-connector-mcp
```

## Configuration

Set the following environment variables:

```bash
# Required: Database connection URL
DB_URL=mysql://user:password@host:port/database

# Optional: Maximum characters for query results (default: 4000)
EXECUTE_QUERY_MAX_CHARS=4000

# Optional: Path for saving full result sets
CLAUDE_LOCAL_FILES_PATH=/path/to/files
```

## Usage

Run the MCP server:

```bash
python -m sql_connector_mcp.server
```


Opens the caldue code or cursor or any ai ide and add this json 
"my_database": {
        "command": "python",
        "args": ["-m", "sql_connector_mcp.server"],
        "env": {
          "DB_URL": "your dbatabase url"
        }

## Available Tools

| Tool | Description |
|------|-------------|
| `all_table_names()` | Returns all table names in the database |
| `filter_table_names(q)` | Returns table names containing the substring `q` |
| `schema_definitions(table_names)` | Returns schema and relationship info for specified tables |
| `execute_query(query, params)` | Executes a SQL query and returns formatted results |
| `fetch_form(query_text, db_name)` | Fetches form schema based on trigger keywords |

## Requirements

- Python >= 3.7
- SQLAlchemy
- PyMySQL
- FastMCP

## License

MIT License

## Author

Battula Anil Kumar (anilkumarbaatula@gmail.com)
