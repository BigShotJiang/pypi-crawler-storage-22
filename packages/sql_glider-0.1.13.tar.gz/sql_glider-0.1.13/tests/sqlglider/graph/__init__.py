"""Tests for graph-based lineage module."""
