"""SQL Glider - SQL Utility Toolkit for better understanding, use, and governance of your queries."""

__version__ = "0.1.0"
