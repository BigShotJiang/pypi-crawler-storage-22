"""Tests for catalog module."""
