"""Tests for stub generation."""
