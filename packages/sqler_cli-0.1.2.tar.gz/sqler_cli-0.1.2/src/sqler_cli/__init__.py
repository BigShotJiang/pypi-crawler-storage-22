"""sqler-cli: LLM memory management CLI."""

__version__ = "0.1.0"
