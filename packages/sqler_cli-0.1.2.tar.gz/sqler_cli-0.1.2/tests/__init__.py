"""Tests for sqler-cli."""
