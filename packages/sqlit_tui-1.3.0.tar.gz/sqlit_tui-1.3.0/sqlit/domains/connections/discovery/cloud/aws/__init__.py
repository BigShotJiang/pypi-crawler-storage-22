"""AWS cloud provider for database discovery."""

from .provider import AWSProvider

__all__ = ["AWSProvider"]
