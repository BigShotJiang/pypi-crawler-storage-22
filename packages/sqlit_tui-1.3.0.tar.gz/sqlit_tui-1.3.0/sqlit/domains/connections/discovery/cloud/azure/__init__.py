"""Azure cloud provider for database discovery."""

from .provider import AzureProvider

__all__ = ["AzureProvider"]
