"""GCP cloud provider for database discovery."""

from .provider import GCPProvider

__all__ = ["GCPProvider"]
