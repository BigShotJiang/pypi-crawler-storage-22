"""Apache Arrow Flight SQL provider."""

from sqlit.domains.connections.providers.flight.provider import SPEC

__all__ = ["SPEC"]
