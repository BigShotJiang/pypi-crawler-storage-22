"""Compatibility wrapper for schema helpers.

Prefer importing from schema_helpers instead of this module.
"""

from sqlit.domains.connections.providers.schema_helpers import *  # noqa: F403
