"""Shared constants for connection picker UI."""

from __future__ import annotations

TAB_CONNECTIONS = "connections"
TAB_DOCKER = "docker"
TAB_CLOUD = "cloud"
