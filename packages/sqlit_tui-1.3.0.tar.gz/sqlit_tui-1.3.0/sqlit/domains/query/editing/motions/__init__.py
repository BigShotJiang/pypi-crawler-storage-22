"""Pure motion functions for vim-style navigation."""

from .registry import CHAR_MOTIONS, MOTIONS

__all__ = ["CHAR_MOTIONS", "MOTIONS"]
