"""Shell/application settings store."""

from .settings import SettingsStore

__all__ = ["SettingsStore"]
