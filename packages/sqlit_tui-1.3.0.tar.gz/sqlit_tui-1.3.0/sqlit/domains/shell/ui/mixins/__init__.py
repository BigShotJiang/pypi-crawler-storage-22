"""Shell UI mixins."""

from .ui_navigation import UINavigationMixin

__all__ = ["UINavigationMixin"]
