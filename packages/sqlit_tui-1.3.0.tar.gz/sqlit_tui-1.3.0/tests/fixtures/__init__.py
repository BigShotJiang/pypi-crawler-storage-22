"""Fixture helpers for sqlit tests."""
