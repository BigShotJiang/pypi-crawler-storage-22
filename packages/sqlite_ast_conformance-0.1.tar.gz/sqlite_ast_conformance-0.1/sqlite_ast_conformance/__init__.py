from pathlib import Path

AST_TESTS_DIR = Path(__file__).parent / "ast-tests"
