from setuptools import find_packages, setup

setup(name='sqlite-web', packages=find_packages())
