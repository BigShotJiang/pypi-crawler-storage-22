"""Entry point for running SQLiter TUI as a module."""

from sqliter.tui import run

if __name__ == "__main__":  # pragma: no cover
    run()
