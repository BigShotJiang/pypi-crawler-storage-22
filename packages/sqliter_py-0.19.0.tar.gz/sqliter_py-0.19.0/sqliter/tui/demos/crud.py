"""CRUD Operations demos."""

from __future__ import annotations

import io

from sqliter import SqliterDB
from sqliter.model import BaseDBModel
from sqliter.tui.demos.base import Demo, DemoCategory, extract_demo_code


def _run_insert() -> str:
    """Insert new records into the database.

    Use db.insert() to add new records, which returns the inserted
    object with auto-generated primary key.
    """
    output = io.StringIO()

    class User(BaseDBModel):
        name: str
        email: str

    db = SqliterDB(memory=True)
    db.create_table(User)

    user1 = db.insert(User(name="Alice", email="alice@example.com"))
    output.write(f"Inserted: {user1.name} (pk={user1.pk})\n")

    user2 = db.insert(User(name="Bob", email="bob@example.com"))
    output.write(f"Inserted: {user2.name} (pk={user2.pk})\n")

    db.close()
    return output.getvalue()


def _run_get_by_pk() -> str:
    """Retrieve a single record by primary key.

    Use db.get(Model, pk) to fetch a specific record quickly.
    """
    output = io.StringIO()

    class Task(BaseDBModel):
        title: str
        done: bool = False

    db = SqliterDB(memory=True)
    db.create_table(Task)

    task: Task = db.insert(Task(title="Buy groceries"))
    output.write(f"Created: {task.title} (pk={task.pk})\n")

    retrieved = db.get(Task, task.pk)
    if retrieved is not None:
        output.write(f"Retrieved: {retrieved.title}\n")
        output.write(f"Same object: {retrieved.pk == task.pk}\n")

    db.close()
    return output.getvalue()


def _run_update() -> str:
    """Update existing records in the database.

    Modify field values and call db.update() to persist changes.
    """
    output = io.StringIO()

    class Item(BaseDBModel):
        name: str
        quantity: int

    db = SqliterDB(memory=True)
    db.create_table(Item)

    item = db.insert(Item(name="Apples", quantity=5))
    output.write(f"Created: {item.name} x{item.quantity}\n")

    item.quantity = 10
    db.update(item)
    output.write(f"Updated: {item.name} x{item.quantity}\n")

    db.close()
    return output.getvalue()


def _run_delete() -> str:
    """Delete records from the database.

    Use db.delete(Model, pk) to permanently remove a record.
    """
    output = io.StringIO()

    class Note(BaseDBModel):
        content: str

    db = SqliterDB(memory=True)
    db.create_table(Note)

    note = db.insert(Note(content="Temporary note"))
    output.write(f"Created note (pk={note.pk})\n")

    db.delete(Note, note.pk)
    output.write(f"Deleted note with pk={note.pk}\n")

    all_notes = db.select(Note).fetch_all()
    output.write(f"Remaining notes: {len(all_notes)}\n")

    db.close()
    return output.getvalue()


def _run_bulk_insert() -> str:
    """Insert multiple records in a single transaction.

    Use db.bulk_insert() to efficiently insert a batch of records.
    All records are committed together, and each returned instance
    has its primary key set.
    """
    output = io.StringIO()

    class Product(BaseDBModel):
        name: str
        price: float

    db = SqliterDB(memory=True)
    db.create_table(Product)

    products = [
        Product(name="Widget", price=9.99),
        Product(name="Gadget", price=24.99),
        Product(name="Gizmo", price=14.99),
    ]
    results = db.bulk_insert(products)

    output.write(f"Inserted {len(results)} products:\n")
    for product in results:
        output.write(f"  pk={product.pk}: {product.name} (${product.price})\n")

    total = db.select(Product).count()
    output.write(f"\nTotal products in database: {total}\n")

    db.close()
    return output.getvalue()


def _run_bulk_update() -> str:
    """Update multiple records efficiently without raw SQL.

    Use db.update_where() to perform bulk updates based on conditions.
    This is more efficient than updating rows one by one.
    """
    output = io.StringIO()

    class Task(BaseDBModel):
        title: str
        status: str = "pending"

    db = SqliterDB(memory=True)
    db.create_table(Task)

    # Insert tasks with different statuses
    tasks = [
        Task(title="Write docs", status="pending"),
        Task(title="Write tests", status="pending"),
        Task(title="Review PR", status="in_progress"),
        Task(title="Deploy app", status="pending"),
    ]
    db.bulk_insert(tasks)

    output.write("Initial tasks:\n")
    for task in db.select(Task).fetch_all():
        output.write(f"  - {task.title}: {task.status}\n")

    # Bulk update: mark all pending tasks as complete
    count = db.update_where(
        Task, where={"status": "pending"}, values={"status": "completed"}
    )
    output.write(f"\nUpdated {count} tasks from 'pending' to 'completed'\n")

    output.write("\nFinal tasks:\n")
    for task in db.select(Task).fetch_all():
        output.write(f"  - {task.title}: {task.status}\n")

    db.close()
    return output.getvalue()


def _run_query_update() -> str:
    """Update records using the QueryBuilder fluent interface.

    Use db.select(Model).filter(...).update(...) for a more flexible
    approach with complex conditions.
    """
    output = io.StringIO()

    class Item(BaseDBModel):
        name: str
        category: str
        quantity: int

    db = SqliterDB(memory=True)
    db.create_table(Item)

    # Insert items
    items = [
        Item(name="Apple", category="fruit", quantity=10),
        Item(name="Carrot", category="vegetable", quantity=5),
        Item(name="Banana", category="fruit", quantity=8),
        Item(name="Broccoli", category="vegetable", quantity=3),
    ]
    db.bulk_insert(items)

    output.write("Initial items:\n")
    for item in db.select(Item).fetch_all():
        output.write(
            f"  - {item.name}: {item.category} (qty={item.quantity})\n"
        )

    # Use QueryBuilder with filter and update
    count = db.select(Item).filter(category="fruit").update({"quantity": 20})
    output.write(f"\nUpdated {count} fruit items to quantity=20\n")

    output.write("\nFinal items:\n")
    for item in db.select(Item).fetch_all():
        output.write(
            f"  - {item.name}: {item.category} (qty={item.quantity})\n"
        )

    db.close()
    return output.getvalue()


def get_category() -> DemoCategory:
    """Get the CRUD Operations demo category."""
    return DemoCategory(
        id="crud",
        title="CRUD Operations",
        icon="",
        demos=[
            Demo(
                id="crud_insert",
                title="Insert Records",
                description="Create new records in the database",
                category="crud",
                code=extract_demo_code(_run_insert),
                execute=_run_insert,
            ),
            Demo(
                id="crud_get",
                title="Get by Primary Key",
                description="Retrieve a record by its primary key",
                category="crud",
                code=extract_demo_code(_run_get_by_pk),
                execute=_run_get_by_pk,
            ),
            Demo(
                id="crud_update",
                title="Update Records",
                description="Modify existing records",
                category="crud",
                code=extract_demo_code(_run_update),
                execute=_run_update,
            ),
            Demo(
                id="crud_delete",
                title="Delete Records",
                description="Remove records from the database",
                category="crud",
                code=extract_demo_code(_run_delete),
                execute=_run_delete,
            ),
            Demo(
                id="crud_bulk_insert",
                title="Bulk Insert",
                description="Insert multiple records in one transaction",
                category="crud",
                code=extract_demo_code(_run_bulk_insert),
                execute=_run_bulk_insert,
            ),
            Demo(
                id="crud_bulk_update",
                title="Bulk Update",
                description="Update multiple records efficiently",
                category="crud",
                code=extract_demo_code(_run_bulk_update),
                execute=_run_bulk_update,
            ),
            Demo(
                id="crud_query_update",
                title="Query Update",
                description="Update with QueryBuilder filters",
                category="crud",
                code=extract_demo_code(_run_query_update),
                execute=_run_query_update,
            ),
        ],
    )
