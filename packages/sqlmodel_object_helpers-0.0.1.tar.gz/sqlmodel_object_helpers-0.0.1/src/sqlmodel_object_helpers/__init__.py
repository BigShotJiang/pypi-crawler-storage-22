"""sqlmodel-object-helpers — reusable query helpers for SQLModel projects."""

__version__ = "0.0.1"

from .constants import QueryHelperSettings, settings
from .exceptions import (
    DatabaseError,
    InvalidFilterError,
    InvalidLoadPathError,
    MutationError,
    ObjectNotFoundError,
    QueryError,
)
from .filters import build_filter, build_flat_filter, flatten_filters
from .loaders import build_load_chain, build_load_options
from .operators import SPECIAL_OPERATORS, SUPPORTED_OPERATORS, Operator
from .mutations import (
    add_object,
    add_objects,
    check_for_related_records,
    delete_object,
    update_object,
)
from .query import get_object, get_objects, get_projection
from .session import create_session_dependency
from .types.filters import (
    FilterBool,
    FilterDate,
    FilterDatetime,
    FilterExists,
    FilterInt,
    FilterStr,
    FilterTimedelta,
    LogicalFilter,
    OrderAsc,
    OrderBy,
    OrderDesc,
)
from .types.pagination import (
    GetAllPagination,
    Pagination,
    PaginationR,
)
from .types.projections import ColumnSpec

__all__ = [
    # Settings
    "settings",
    "QueryHelperSettings",
    # Query functions (read)
    "get_object",
    "get_objects",
    "get_projection",
    # Mutation functions (create / update / delete)
    "add_object",
    "add_objects",
    "update_object",
    "delete_object",
    "check_for_related_records",
    # Filters
    "build_filter",
    "build_flat_filter",
    "flatten_filters",
    "SUPPORTED_OPERATORS",
    "SPECIAL_OPERATORS",
    "Operator",
    # Loaders
    "build_load_options",
    "build_load_chain",
    # Exceptions
    "QueryError",
    "ObjectNotFoundError",
    "InvalidFilterError",
    "InvalidLoadPathError",
    "DatabaseError",
    "MutationError",
    # Filter types
    "FilterInt",
    "FilterStr",
    "FilterDate",
    "FilterDatetime",
    "FilterTimedelta",
    "FilterBool",
    "FilterExists",
    "OrderAsc",
    "OrderDesc",
    "OrderBy",
    "LogicalFilter",
    # Pagination types
    "Pagination",
    "PaginationR",
    "GetAllPagination",
    # Projection types
    "ColumnSpec",
    # Session
    "create_session_dependency",
]
