"""
Tests for filter functionality in sqlmodel_object_helpers.

Models match production exam-crm schema from SQL dump.

Tests cover:
- flatten_filters: flattening nested filter dictionaries
- _validate_field_name: field name security validation
- build_filter: depth/AND-OR limits, field validation, relationship chains, empty dict
- build_flat_filter: flat filter building, dot-paths, multi-operator, exists, empty segments
"""

import pytest
from sqlmodel_object_helpers.constants import settings
from sqlmodel_object_helpers.exceptions import InvalidFilterError
from sqlmodel_object_helpers.filters import (
    _validate_field_name,
    build_filter,
    build_flat_filter,
    flatten_filters,
)

from conftest import (
    Applicant, Application, Attempt, Billing, Organization, Payment, Schedule, Unit,
)


# ==================== flatten_filters tests ====================


def test_flatten_simple():
    """Test flattening a simple single-level filter."""
    filters = {"last_name": {"eq": "test"}}
    result = flatten_filters(filters)
    assert result == {"last_name": {"eq": "test"}}


def test_flatten_nested():
    """Test flattening: application → applicant → last_name."""
    filters = {
        "application": {
            "applicant": {
                "last_name": {"eq": "Иванов"}
            }
        }
    }
    result = flatten_filters(filters)
    assert result == {"application.applicant.last_name": {"eq": "Иванов"}}


def test_flatten_plain_value():
    """Test flattening a filter with plain value (no operator)."""
    filters = {"status_id": 10}
    result = flatten_filters(filters)
    assert result == {"status_id": {"eq": 10}}


def test_flatten_deeply_nested():
    """Test flattening 4-level nesting: schedule.unit.organization.short_name."""
    filters = {
        "schedule": {
            "unit": {
                "organization": {
                    "short_name": {"ilike": "%Энергетик%"}
                }
            }
        }
    }
    result = flatten_filters(filters)
    assert result == {"schedule.unit.organization.short_name": {"ilike": "%Энергетик%"}}


def test_flatten_multiple_fields():
    """Test flattening multiple fields at the same nesting level."""
    filters = {
        "application": {
            "applicant": {
                "last_name": {"eq": "Иванов"},
                "is_nrs": {"eq": True},
            }
        }
    }
    result = flatten_filters(filters)
    assert result == {
        "application.applicant.last_name": {"eq": "Иванов"},
        "application.applicant.is_nrs": {"eq": True},
    }


# ==================== _validate_field_name tests ====================


def test_validate_field_name_valid():
    """Test that valid field names pass validation."""
    _validate_field_name("last_name")
    _validate_field_name("passport_number")
    _validate_field_name("is_nrs")
    _validate_field_name("schedule_date")


def test_validate_field_name_dunder():
    """Test that dunder field names are rejected."""
    with pytest.raises(InvalidFilterError) as exc_info:
        _validate_field_name("__table__")
    assert "Invalid field name" in str(exc_info.value)


def test_validate_field_name_single_underscore():
    """Test that single underscore prefixed field names are rejected."""
    with pytest.raises(InvalidFilterError) as exc_info:
        _validate_field_name("_sa_instance_state")
    assert "Invalid field name" in str(exc_info.value)


# ==================== build_filter - depth limit tests ====================


def test_build_filter_depth_limit():
    """Test that excessive nesting depth is rejected."""
    original_depth = settings.max_filter_depth
    try:
        settings.max_filter_depth = 3

        deeply_nested = {
            "AND": [{
                "AND": [{
                    "AND": [{
                        "AND": [{
                            "condition": {"status_id": {"eq": 10}}
                        }]
                    }]
                }]
            }]
        }

        with pytest.raises(InvalidFilterError) as exc_info:
            build_filter(Attempt, deeply_nested)
        assert "Filter nesting depth exceeds" in str(exc_info.value)

    finally:
        settings.max_filter_depth = original_depth


# ==================== build_filter - AND/OR item limit tests ====================


def test_build_filter_and_or_limit():
    """Test that excessive AND/OR list items are rejected."""
    original_limit = settings.max_and_or_items
    try:
        settings.max_and_or_items = 5

        many_conditions = {
            "AND": [{"condition": {"status_id": {"eq": i}}} for i in range(10)]
        }

        with pytest.raises(InvalidFilterError) as exc_info:
            build_filter(Attempt, many_conditions)
        assert "cannot contain more than" in str(exc_info.value)

    finally:
        settings.max_and_or_items = original_limit


# ==================== build_filter - field name validation tests ====================


def test_build_filter_rejects_dunder_field():
    """Test that build_filter rejects dunder field names."""
    with pytest.raises(InvalidFilterError) as exc_info:
        build_filter(Applicant, {"__table__": {"eq": 1}})
    assert "Invalid field name" in str(exc_info.value)


# ==================== build_filter - basic functionality tests ====================


def test_build_filter_simple_eq():
    """Test building a simple equality filter on passport_number."""
    expression, joins = build_filter(
        Applicant,
        {"condition": {"last_name": {"eq": "Иванов"}}}
    )
    assert expression is not None
    assert joins == []


def test_build_filter_unknown_field():
    """Test that build_filter rejects unknown field names."""
    with pytest.raises(InvalidFilterError) as exc_info:
        build_filter(Applicant, {"condition": {"nonexistent": {"eq": 1}}})
    assert "not found in model" in str(exc_info.value).lower() or "nonexistent" in str(exc_info.value)


def test_build_filter_relationship_chain():
    """Test build_filter through: Attempt → application → applicant.last_name."""
    expression, joins = build_filter(
        Attempt,
        {"condition": {
            "application": {
                "applicant": {
                    "last_name": {"eq": "Иванов"}
                }
            }
        }}
    )
    assert expression is not None
    assert len(joins) == 2


def test_build_filter_and_or_conditions():
    """Test AND/OR: (status_id=10 AND is_active=True) OR (status_id=120)."""
    expression, joins = build_filter(
        Attempt,
        {"OR": [
            {"AND": [
                {"condition": {"status_id": {"eq": 10}}},
                {"condition": {"is_active": {"eq": True}}},
            ]},
            {"condition": {"status_id": {"eq": 120}}},
        ]}
    )
    assert expression is not None
    assert isinstance(joins, list)


def test_build_filter_empty_dict():
    """Test that build_filter with empty dict returns (None, [])."""
    expression, joins = build_filter(Applicant, {})
    assert expression is None
    assert joins == []


def test_build_filter_unsupported_operator():
    """Test that build_filter rejects unsupported operators."""
    with pytest.raises(InvalidFilterError):
        build_filter(Applicant, {"condition": {"last_name": {"xxx": "test"}}})


def test_build_filter_schedule_to_org_chain():
    """Test 3-level chain: Schedule → unit → organization.inn."""
    expression, joins = build_filter(
        Schedule,
        {"condition": {
            "unit": {
                "organization": {
                    "inn": {"eq": "7701234567"}
                }
            }
        }}
    )
    assert expression is not None
    assert len(joins) == 2


# ==================== build_flat_filter tests ====================


def test_build_flat_filter_simple():
    """Test building a simple flat filter on last_name."""
    conditions, join_entities = build_flat_filter(
        Applicant, {"last_name": {"eq": "Иванов"}},
    )
    assert len(conditions) == 1
    assert len(join_entities) == 0


def test_build_flat_filter_dunder_rejected():
    """Test that build_flat_filter rejects dunder field names."""
    with pytest.raises(InvalidFilterError) as exc_info:
        build_flat_filter(Applicant, {"__table__": {"eq": 1}})
    assert "Invalid field name" in str(exc_info.value)


def test_build_flat_filter_suspend_error():
    """Test that suspend_error=True suppresses errors for unknown fields."""
    conditions, join_entities = build_flat_filter(
        Applicant, {"nonexistent": {"eq": 1}}, suspend_error=True,
    )
    assert isinstance(conditions, list)


def test_build_flat_filter_dot_path_3_levels():
    """Test 3-level: application.applicant.last_name via aliased joins."""
    conditions, join_entities = build_flat_filter(
        Attempt, {"application.applicant.last_name": {"eq": "Иванов"}},
    )
    assert len(conditions) == 1
    assert len(join_entities) == 2


def test_build_flat_filter_multiple_operators():
    """Test multi-operator: billing_type_id ge + le combined."""
    conditions, join_entities = build_flat_filter(
        Billing, {"billing_type_id": {"ge": 1, "le": 5}},
    )
    assert len(conditions) == 1
    assert len(join_entities) == 0


def test_build_flat_filter_empty_segment():
    """Test that empty segment in dot-path raises InvalidFilterError."""
    with pytest.raises(InvalidFilterError) as exc_info:
        build_flat_filter(Attempt, {"application..last_name": {"eq": "test"}})
    assert "Empty segment in filter path" in str(exc_info.value)


def test_build_flat_filter_empty_segment_suspend():
    """Test that empty segment with suspend_error=True is silently skipped."""
    conditions, join_entities = build_flat_filter(
        Attempt,
        {"application..last_name": {"eq": "test"}},
        suspend_error=True,
    )
    assert conditions == []
    assert join_entities == []


def test_build_flat_filter_exists_operator():
    """Test exists operator: email exists (is not NULL)."""
    conditions, join_entities = build_flat_filter(
        Application, {"email": {"exists": True}},
    )
    assert len(conditions) == 1
    assert len(join_entities) == 0


def test_build_flat_filter_bool_field():
    """Test filtering by boolean field: is_nrs=True."""
    conditions, join_entities = build_flat_filter(
        Applicant, {"is_nrs": {"eq": True}},
    )
    assert len(conditions) == 1
    assert len(join_entities) == 0


def test_build_flat_filter_is_paid():
    """Test filtering billing by is_paid (real production field)."""
    conditions, join_entities = build_flat_filter(
        Billing, {"is_paid": {"eq": True}},
    )
    assert len(conditions) == 1
    assert len(join_entities) == 0


def test_build_flat_filter_schedule_unit_org():
    """Test 4-level dot-path: unit.organization.inn from Schedule model."""
    conditions, join_entities = build_flat_filter(
        Schedule, {"unit.organization.inn": {"eq": "7701234567"}},
    )
    assert len(conditions) == 1
    assert len(join_entities) == 2
