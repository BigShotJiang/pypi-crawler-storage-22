"""Tests for sqlmodel_object_helpers.operators module.

Tests the Operator enum, SUPPORTED_OPERATORS dictionary, and SPECIAL_OPERATORS frozenset.
"""

from enum import StrEnum

import pytest

from sqlmodel_object_helpers.operators import (
    Operator,
    SPECIAL_OPERATORS,
    SUPPORTED_OPERATORS,
)


# ---------------------------------------------------------------------------
# Operator Enum Tests
# ---------------------------------------------------------------------------


def test_operator_enum_values():
    """Verify key Operator enum values are correct strings."""
    assert Operator.EQ.value == "eq"
    assert Operator.IN.value == "in_"
    assert Operator.IS_NOT.value == "isnot"
    assert Operator.NE.value == "ne"
    assert Operator.GT.value == "gt"
    assert Operator.LT.value == "lt"


def test_operator_is_strenum():
    """Verify Operator is a StrEnum subclass."""
    assert issubclass(Operator, StrEnum)


def test_operator_all_members():
    """Verify all expected Operator enum members exist."""
    expected_operators = {
        "EQ",
        "NE",
        "GT",
        "LT",
        "GE",
        "LE",
        "IN",
        "LIKE",
        "ILIKE",
        "BETWEEN",
        "IS",
        "IS_NOT",
        "MATCH",
        "NOT_IN",
    }
    actual_operators = {member.name for member in Operator}
    assert actual_operators == expected_operators


# ---------------------------------------------------------------------------
# SUPPORTED_OPERATORS Tests
# ---------------------------------------------------------------------------


def test_supported_operators_has_all_enum_values():
    """Verify all Operator enum members are keys in SUPPORTED_OPERATORS."""
    for op in Operator:
        assert op in SUPPORTED_OPERATORS, f"Operator.{op.name} ({op.value}) missing from SUPPORTED_OPERATORS"


def test_in_alias_exists():
    """Verify SUPPORTED_OPERATORS has both 'in_' (Operator.IN) and 'in' (alias) keys."""
    assert Operator.IN in SUPPORTED_OPERATORS
    assert "in" in SUPPORTED_OPERATORS
    # Both should reference callable operations
    assert callable(SUPPORTED_OPERATORS[Operator.IN])
    assert callable(SUPPORTED_OPERATORS["in"])


def test_exists_in_supported():
    """Verify 'exists' operator is in SUPPORTED_OPERATORS."""
    assert "exists" in SUPPORTED_OPERATORS
    assert callable(SUPPORTED_OPERATORS["exists"])


def test_supported_operators_contains_all_expected_keys():
    """Verify SUPPORTED_OPERATORS has all expected keys (enum + aliases)."""
    expected_keys = {
        # All enum members
        Operator.EQ,
        Operator.NE,
        Operator.GT,
        Operator.LT,
        Operator.GE,
        Operator.LE,
        Operator.IN,
        Operator.LIKE,
        Operator.ILIKE,
        Operator.BETWEEN,
        Operator.IS,
        Operator.IS_NOT,
        Operator.MATCH,
        Operator.NOT_IN,
        # Aliases
        "in",
        "exists",
    }
    actual_keys = set(SUPPORTED_OPERATORS.keys())
    assert actual_keys == expected_keys


def test_all_supported_operators_are_callable():
    """Verify all values in SUPPORTED_OPERATORS are callable."""
    for key, func in SUPPORTED_OPERATORS.items():
        assert callable(func), f"SUPPORTED_OPERATORS[{key!r}] is not callable"


# ---------------------------------------------------------------------------
# SPECIAL_OPERATORS Tests
# ---------------------------------------------------------------------------


def test_exists_in_special():
    """Verify 'exists' is in SPECIAL_OPERATORS."""
    assert "exists" in SPECIAL_OPERATORS


def test_special_operators_is_frozenset():
    """Verify SPECIAL_OPERATORS is a frozenset."""
    assert isinstance(SPECIAL_OPERATORS, frozenset)


def test_special_operators_only_exists():
    """Verify SPECIAL_OPERATORS only contains 'exists'."""
    assert SPECIAL_OPERATORS == frozenset({"exists"})


# ---------------------------------------------------------------------------
# Operator Function Behavior Tests
# ---------------------------------------------------------------------------


def test_eq_operator_with_equal_values():
    """Verify EQ operator returns True for equal plain Python values."""
    eq_func = SUPPORTED_OPERATORS[Operator.EQ]
    result = eq_func(5, 5)
    assert result is True


def test_eq_operator_with_unequal_values():
    """Verify EQ operator returns False for unequal plain Python values."""
    eq_func = SUPPORTED_OPERATORS[Operator.EQ]
    result = eq_func(5, 3)
    assert result is False


def test_eq_operator_with_strings():
    """Verify EQ operator works with string values."""
    eq_func = SUPPORTED_OPERATORS[Operator.EQ]
    assert eq_func("hello", "hello") is True
    assert eq_func("hello", "world") is False


def test_ne_operator_with_equal_values():
    """Verify NE operator returns False for equal values."""
    ne_func = SUPPORTED_OPERATORS[Operator.NE]
    result = ne_func(5, 5)
    assert result is False


def test_ne_operator_with_unequal_values():
    """Verify NE operator returns True for unequal values."""
    ne_func = SUPPORTED_OPERATORS[Operator.NE]
    result = ne_func(5, 3)
    assert result is True


def test_comparison_operators_with_numbers():
    """Verify comparison operators work with numeric values."""
    gt_func = SUPPORTED_OPERATORS[Operator.GT]
    lt_func = SUPPORTED_OPERATORS[Operator.LT]
    ge_func = SUPPORTED_OPERATORS[Operator.GE]
    le_func = SUPPORTED_OPERATORS[Operator.LE]

    assert gt_func(10, 5) is True
    assert gt_func(5, 10) is False
    assert lt_func(5, 10) is True
    assert lt_func(10, 5) is False
    assert ge_func(10, 5) is True
    assert ge_func(5, 5) is True
    assert le_func(5, 10) is True
    assert le_func(5, 5) is True


def test_supported_operators_count():
    """Verify SUPPORTED_OPERATORS has the expected number of entries."""
    # 14 enum members + 2 aliases ("in", "exists")
    assert len(SUPPORTED_OPERATORS) == 16
