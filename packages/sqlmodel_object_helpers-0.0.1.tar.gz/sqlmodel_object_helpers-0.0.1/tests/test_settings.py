"""Tests for sqlmodel_object_helpers.constants module.

Tests the QueryHelperSettings class and the module-level settings instance.
"""

import pytest
from pydantic import BaseModel

from sqlmodel_object_helpers.constants import QueryHelperSettings, settings


# ---------------------------------------------------------------------------
# QueryHelperSettings Class Tests
# ---------------------------------------------------------------------------


def test_default_values():
    """Verify all default values in QueryHelperSettings are correct."""
    test_settings = QueryHelperSettings()
    assert test_settings.max_filter_depth == 100
    assert test_settings.max_and_or_items == 100
    assert test_settings.max_load_depth == 10
    assert test_settings.max_in_list_size == 1000
    assert test_settings.max_per_page == 500


def test_override_settings():
    """Verify settings can be overridden and restored to defaults."""
    # Store original values
    original_max_filter_depth = settings.max_filter_depth
    original_max_and_or_items = settings.max_and_or_items
    original_max_load_depth = settings.max_load_depth
    original_max_in_list_size = settings.max_in_list_size
    original_max_per_page = settings.max_per_page

    try:
        # Override settings
        settings.max_filter_depth = 50
        settings.max_and_or_items = 75
        settings.max_load_depth = 5
        settings.max_in_list_size = 500
        settings.max_per_page = 300

        # Verify overrides
        assert settings.max_filter_depth == 50
        assert settings.max_and_or_items == 75
        assert settings.max_load_depth == 5
        assert settings.max_in_list_size == 500
        assert settings.max_per_page == 300
    finally:
        # Restore defaults
        settings.max_filter_depth = original_max_filter_depth
        settings.max_and_or_items = original_max_and_or_items
        settings.max_load_depth = original_max_load_depth
        settings.max_in_list_size = original_max_in_list_size
        settings.max_per_page = original_max_per_page

    # Verify restoration
    assert settings.max_filter_depth == 100
    assert settings.max_and_or_items == 100
    assert settings.max_load_depth == 10
    assert settings.max_in_list_size == 1000
    assert settings.max_per_page == 500


def test_settings_is_basemodel():
    """Verify QueryHelperSettings is a Pydantic BaseModel instance."""
    assert isinstance(settings, BaseModel)
    assert isinstance(settings, QueryHelperSettings)


def test_settings_is_pydantic_model_class():
    """Verify QueryHelperSettings is a Pydantic model class."""
    assert issubclass(QueryHelperSettings, BaseModel)


def test_settings_instance_has_all_attributes():
    """Verify the module-level settings instance has all expected attributes."""
    assert hasattr(settings, "max_filter_depth")
    assert hasattr(settings, "max_and_or_items")
    assert hasattr(settings, "max_load_depth")
    assert hasattr(settings, "max_in_list_size")
    assert hasattr(settings, "max_per_page")


def test_settings_attributes_are_integers():
    """Verify all settings attributes are integers."""
    assert isinstance(settings.max_filter_depth, int)
    assert isinstance(settings.max_and_or_items, int)
    assert isinstance(settings.max_load_depth, int)
    assert isinstance(settings.max_in_list_size, int)
    assert isinstance(settings.max_per_page, int)


def test_settings_attributes_are_positive():
    """Verify all settings attributes have positive values."""
    assert settings.max_filter_depth > 0
    assert settings.max_and_or_items > 0
    assert settings.max_load_depth > 0
    assert settings.max_in_list_size > 0
    assert settings.max_per_page > 0


def test_create_custom_settings_instance():
    """Verify custom QueryHelperSettings instances can be created with different values."""
    custom_settings = QueryHelperSettings(
        max_filter_depth=50,
        max_and_or_items=75,
        max_load_depth=8,
        max_in_list_size=2000,
        max_per_page=250,
    )
    assert custom_settings.max_filter_depth == 50
    assert custom_settings.max_and_or_items == 75
    assert custom_settings.max_load_depth == 8
    assert custom_settings.max_in_list_size == 2000
    assert custom_settings.max_per_page == 250


def test_partial_override_settings():
    """Verify partial overrides work with remaining defaults."""
    partial_settings = QueryHelperSettings(max_per_page=200)
    assert partial_settings.max_filter_depth == 100  # default
    assert partial_settings.max_and_or_items == 100  # default
    assert partial_settings.max_load_depth == 10  # default
    assert partial_settings.max_in_list_size == 1000  # default
    assert partial_settings.max_per_page == 200  # overridden


def test_settings_model_dump():
    """Verify QueryHelperSettings.model_dump() returns all attributes as dict."""
    settings_dict = settings.model_dump()
    assert isinstance(settings_dict, dict)
    assert settings_dict["max_filter_depth"] == 100
    assert settings_dict["max_and_or_items"] == 100
    assert settings_dict["max_load_depth"] == 10
    assert settings_dict["max_in_list_size"] == 1000
    assert settings_dict["max_per_page"] == 500


def test_settings_model_validate():
    """Verify QueryHelperSettings can validate from dict."""
    data = {
        "max_filter_depth": 75,
        "max_and_or_items": 50,
        "max_load_depth": 7,
        "max_in_list_size": 1500,
        "max_per_page": 400,
    }
    validated_settings = QueryHelperSettings.model_validate(data)
    assert validated_settings.max_filter_depth == 75
    assert validated_settings.max_and_or_items == 50
    assert validated_settings.max_load_depth == 7
    assert validated_settings.max_in_list_size == 1500
    assert validated_settings.max_per_page == 400


def test_settings_serialization():
    """Verify QueryHelperSettings can be serialized to JSON-compatible dict."""
    settings_json = settings.model_dump_json()
    assert isinstance(settings_json, str)
    assert "max_filter_depth" in settings_json
    assert "max_and_or_items" in settings_json
    assert "max_load_depth" in settings_json
    assert "max_in_list_size" in settings_json
    assert "max_per_page" in settings_json
