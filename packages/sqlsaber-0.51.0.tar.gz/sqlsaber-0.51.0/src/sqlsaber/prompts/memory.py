MEMORY_ADDITION = """# Contextual Memory Integration
Below is any relevant context, prior memories, or database-specific quirks provided from the user.
Prioritize only information that directly influences query generation or interpretation to optimize clarity and focus.
"""
