from .new_contribution import ConfigMaker
