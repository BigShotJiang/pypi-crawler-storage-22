# squawk_github

A small wrapper around the GitHub API to allow [`squawk`](https://github.com/sbdchd/squawk) to comment on PRs.
