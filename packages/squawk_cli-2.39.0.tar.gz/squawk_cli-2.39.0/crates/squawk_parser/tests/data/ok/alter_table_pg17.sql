
alter table t alter c set expression as ( a > b );

alter table t set access method default;

alter table t add foreign key (a, b) references t1 match partial;
