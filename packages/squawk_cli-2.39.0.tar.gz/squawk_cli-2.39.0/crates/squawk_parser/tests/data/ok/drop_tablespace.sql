-- simple
drop tablespace foo;

-- full
drop tablespace if exists t;

