-- pg_docs
DROP VIEW kinds;

-- full
drop view if exists foo, bar, buzz cascade;

drop view foo restrict;

