-- execute
EXECUTE fooplan(1, 'Hunter Valley', 't', 200.00);

EXECUTE usrrptplan(1, current_date);

EXECUTE foo;

