-- pg_docs
move next from cursor_name;
move prior from cursor_name;
move prior in cursor_name;
move prior cursor_name;

move NEXT FROM cursor_name;
move PRIOR FROM cursor_name;
move FIRST FROM cursor_name;
move LAST FROM cursor_name;
move ABSOLUTE 10 FROM cursor_name;
move RELATIVE 10 FROM cursor_name;
move 10 FROM cursor_name;
move ALL FROM cursor_name;
move FORWARD FROM cursor_name;
move FORWARD 10 FROM cursor_name;
move FORWARD ALL FROM cursor_name;
move BACKWARD FROM cursor_name;
move BACKWARD 10 FROM cursor_name;
move BACKWARD ALL FROM cursor_name;

