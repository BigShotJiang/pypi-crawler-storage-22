-- simple
reassign owned by set, current_role, current_user, foo to session_user;

reassign owned by current_user to current_role;

