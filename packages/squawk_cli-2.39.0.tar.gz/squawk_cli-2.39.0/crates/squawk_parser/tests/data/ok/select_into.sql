-- docs
SELECT * INTO films_recent FROM films WHERE date_prod >= '2002-01-01';

-- more_schema
select a, b, c into t from t2;

