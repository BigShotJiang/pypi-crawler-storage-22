select ['a', 'b', 'c'];

select [[1, 2]];
