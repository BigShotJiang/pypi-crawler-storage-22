#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-only
#
# @file cpp_markup_if0_single.sh
#
# @copyright Copyright (C) 2013-2024 srcML, LLC. (www.srcML.org)

# test framework
source $(dirname "$0")/framework_test.sh
# test
##
# cpp markup if0

define input <<- 'INPUT'

	#if 0
	break;
	#endif
INPUT

defineXML output <<- 'STDOUT'
	<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
	<unit xmlns="http://www.srcML.org/srcML/src" xmlns:cpp="http://www.srcML.org/srcML/cpp" revision="REVISION" language="C++">
	<cpp:if>#<cpp:directive>if</cpp:directive> <expr><literal type="number">0</literal></expr></cpp:if>
	break;
	<cpp:endif>#<cpp:directive>endif</cpp:directive></cpp:endif>

	</unit>
STDOUT

srcml -l C++ <<< "$input"
check "$output"

#srcml -l C++ --cpp-text-if0 <<< "$input"
#check "$output"

defineXML output2 <<- 'STDOUT'
	<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
	<unit xmlns="http://www.srcML.org/srcML/src" xmlns:cpp="http://www.srcML.org/srcML/cpp" revision="REVISION" language="C++" options="CPP_MARKUP_IF0">
	<cpp:if>#<cpp:directive>if</cpp:directive> <expr><literal type="number">0</literal></expr></cpp:if>
	<break>break;</break>
	<cpp:endif>#<cpp:directive>endif</cpp:directive></cpp:endif>

	</unit>
STDOUT

srcml -l C++ --cpp-markup-if0 <<< "$input"
check "$output2"
