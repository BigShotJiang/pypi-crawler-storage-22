#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-only
#
# @file implicit_xslt_identity_archive_single.sh
#
# @copyright Copyright (C) 2013-2024 srcML, LLC. (www.srcML.org)

# test framework
source $(dirname "$0")/framework_test.sh

# xslt identity transformation (archive of single file)
defineXML identity_xslt <<- 'STDOUT'
	<xsl:stylesheet
	xmlns="http://www.srcML.org/srcML/src"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:cpp="http://www.srcML.org/srcML/cpp"
	xmlns:src="http://www.srcML.org/srcML/src"
	version="1.0">
	<xsl:template match="@*|node()">
	  <xsl:copy>
	   <xsl:apply-templates select="@*|node()"/>
	  </xsl:copy>
	 </xsl:template>
	</xsl:stylesheet>
STDOUT

defineXML srcml <<- 'STDOUT'
	<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
	<unit xmlns="http://www.srcML.org/srcML/src" revision="REVISION">

	<unit revision="REVISION" language="C++" filename="sub/a.cpp" hash="1a2c5d67e6f651ae10b7673c53e8c502c97316d6">
	<expr_stmt><expr><name>a</name></expr>;</expr_stmt>
	</unit>

	</unit>
STDOUT

createfile sub/a.cpp.xml "$srcml"
createfile identity.xsl "$identity_xslt"

srcml identity.xsl sub/a.cpp.xml
check "$srcml"

srcml identity.xsl < sub/a.cpp.xml
check "$srcml"

srcml identity.xsl sub/a.cpp.xml -o sub/b.cpp.xml
check sub/b.cpp.xml "$srcml"

srcml identity.xsl -o sub/b.cpp.xml sub/a.cpp.xml
check sub/b.cpp.xml "$srcml"

srcml identity.xsl -o sub/b.cpp.xml < sub/a.cpp.xml
check sub/b.cpp.xml "$srcml"

srcml --xslt-param name=value identity.xsl -o sub/b.cpp.xml < sub/a.cpp.xml
check sub/b.cpp.xml "$srcml"
