#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-only
#
# @file show_filename_unit.sh
#
# @copyright Copyright (C) 2013-2024 srcML, LLC. (www.srcML.org)

# test framework
source $(dirname "$0")/framework_test.sh

# test on individual unit
defineXML input <<- 'STDOUT'
	<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
	<unit xmlns="http://www.srcML.org/srcML/src" revision="REVISION" language="C++" filename="sub/a.cpp"><expr_stmt><expr><name>a</name></expr>;</expr_stmt></unit>
STDOUT

createfile sub/a.cpp.xml "$input"
createfile sub/a.cpp "a;"

srcml sub/a.cpp.xml --show-filename
check "sub/a.cpp\n"

srcml --show-filename sub/a.cpp.xml
check "sub/a.cpp\n"

srcml --show-filename < sub/a.cpp.xml
check "sub/a.cpp\n"

srcml sub/a.cpp --show-filename
check "sub/a.cpp\n"

srcml --show-filename sub/a.cpp
check "sub/a.cpp\n"
