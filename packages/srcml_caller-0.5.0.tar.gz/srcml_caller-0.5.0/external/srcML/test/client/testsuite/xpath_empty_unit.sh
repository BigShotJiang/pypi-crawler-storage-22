#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-only
#
# @file xpath_empty_unit.sh
#
# @copyright Copyright (C) 2013-2024 srcML, LLC. (www.srcML.org)

# test framework
source $(dirname "$0")/framework_test.sh

# test
defineXML srcml <<- 'STDOUT'
	<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
	<unit xmlns="http://www.srcML.org/srcML/src" revision="REVISION" language="C++"/>
STDOUT

defineXML xpath <<- 'STDOUT'
	<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
	<unit xmlns="http://www.srcML.org/srcML/src" revision="REVISION">

	<unit revision="REVISION" language="C++"/>

	</unit>
STDOUT

createfile sub/a.cpp.xml "$srcml"

srcml --xpath=/src:unit sub/a.cpp.xml
check "$xpath"

srcml --xpath=/src:unit < sub/a.cpp.xml
check "$xpath"

srcml --xpath=/src:unit -o sub/b.cpp.xml sub/a.cpp.xml
check sub/b.cpp.xml "$xpath"

srcml --xpath=/src:unit sub/a.cpp.xml -o sub/b.cpp.xml
check sub/b.cpp.xml "$xpath"
