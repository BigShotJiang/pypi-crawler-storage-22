int a = b;
