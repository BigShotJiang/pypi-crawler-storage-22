# RAMS Model
