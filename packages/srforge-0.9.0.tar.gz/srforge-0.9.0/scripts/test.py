import os
import shutil
from pathlib import Path

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE" # IMPORT CORE AFTER THIS LINE !!!
import logging
from srforge.utils.logging import configure_logger
configure_logger(logging.INFO)
import hydra
from hydra.core.hydra_config import HydraConfig

import wandb
import omegaconf
from srforge import GlobalSettings
import srforge.config.utils
from srforge.config.legacy import ConfigParser
from srforge.data.loader import DataLoaderFactory
from srforge.training import runners
from srforge import observers

import torch

logger = logging.getLogger(__name__)

@hydra.main(config_path="configs", config_name="test-cfg", version_base=None)
def main(cfg) -> None:
    srforge.config.utils.clear_defaults(cfg)
    # Set global settings
    GlobalSettings().config = cfg
    GlobalSettings().output_directory = HydraConfig.get().runtime.output_dir

    configure_logger(cfg.system.debug_level)# second time because hydra overrides current global logger configuration
    out_dir = HydraConfig.get().runtime.output_dir
    wandb.init(project=cfg.wandb.project, entity=cfg.wandb.entity, name=cfg.wandb.run_name,
               id=cfg.wandb.run_id, group=cfg.wandb.group_name, notes=cfg.wandb.notes,
               dir=out_dir, tags=cfg.wandb.tags, job_type='test', resume='never',
               config=omegaconf.OmegaConf.to_container(cfg, resolve=False, throw_on_missing=True),
               mode=cfg.wandb.mode, settings=wandb.Settings(x_disable_stats=True))

    print('Configuring benchmark...')
    print(f'Run ID: {wandb.run.id}')
    print(f'Run Name: {wandb.run.name}')
    print(f'Run path: {wandb.run.path}')

    if isinstance(cfg.system.device, (list, tuple, omegaconf.ListConfig)):
        raise NotImplementedError("Multi-GPU inference is not supported yet.")
    else:
        device = torch.device(cfg.system.device)
        print(f"Using device: {device}")


    parser = ConfigParser(cfg, wandb.run)
    model = parser(cfg.model)
    model.to(device)
    metrics = parser(cfg.test_metrics)
    test_dataset = parser(cfg.dataset)
    postprocessor = parser(cfg.postprocessing)

    if cfg.system.cache_dir is not None:
        cache_path = Path(cfg.system.cache_dir) / 'cache' / f"{device.type}_{device.index}"
        print(cache_path, cache_path.absolute())
        os.makedirs(cache_path, exist_ok=True)
        if os.path.isdir(cache_path) and cfg.system.recache:
            shutil.rmtree(cache_path)
        test_dataset = test_dataset.cache(cache_path / 'test')

    test_loader = DataLoaderFactory(test_dataset, batch_size=1, shuffle=False,
                                     num_workers=0, device=cfg.system.device).get_loader()

    out_dir = Path(cfg.system.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    benchmark_runner = runners.BenchmarkRunner(metrics, device, postprocessor=postprocessor)
    benchmark_runner.add_observer(observers.ProgressBar("Testing"))

    # Example of saving images to disk
    # benchmark_runner.add_observer(observers.BatchImageSaver(
    #     img_key='sr_registered',
    #     image_processor=ImageProcessor(1.0, border=0, equalize_mode='clahe'),
    #     output_path=out_dir,
    #     dtype='uint16',
    # ))

    # Example of logging images to wandb
    # benchmark_runner.add_observer(observers.BatchImageLogger(list(range(0, 50)),
    #                                                          observers.ImageProcessor(
    #                                                              65535.0,
    #                                                              border=3,
    #                                                              equalize_mode='clahe'),
    #                                                          img_key='sr_registered'
    #                                                          ))

    benchmark_runner.run_epoch(model=model, data_loader=test_loader, epoch=0)
    wandb.finish(0)




if __name__ == "__main__":
    main()