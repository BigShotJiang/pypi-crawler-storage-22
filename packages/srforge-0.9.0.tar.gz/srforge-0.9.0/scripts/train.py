import os
import shutil
from pathlib import Path

os.environ["C10D_TCP_STORE_USE_LIBUV"] = "0"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE" # IMPORT CORE AFTER THIS LINE !!!
import logging
from srforge.utils.logging import configure_logger
configure_logger(logging.INFO)
import hydra
from hydra.core.hydra_config import HydraConfig

import wandb
import omegaconf
from srforge import GlobalSettings
import srforge.config.utils
from srforge.config.legacy import ConfigParser
from srforge.dataset import Dataset
from srforge.data.loader import DataLoaderFactory
from srforge.data import Entry, GraphEntry
from srforge import observers

from srforge.training import runners, trainers
import torch
try:
    import torch_geometric as tg
except ImportError:
    tg = None

logger = logging.getLogger(__name__)

@hydra.main(config_path="configs", config_name="train-cfg", version_base=None)
def main(cfg) -> None:
    srforge.config.utils.clear_defaults(cfg)

    # Set global settings
    GlobalSettings().config = cfg
    GlobalSettings().output_directory = HydraConfig.get().runtime.output_dir

    configure_logger(cfg.system.debug_level)# second time because hydra overrides current global logger configuration
    out_dir = GlobalSettings().output_directory
    wandb.init(project=cfg.wandb.project, entity=cfg.wandb.entity, name=cfg.wandb.run_name,
               id=cfg.wandb.run_id, group=cfg.wandb.group_name, notes=cfg.wandb.notes,
               dir=out_dir, tags=cfg.wandb.tags, job_type='training', resume='allow',
               config=omegaconf.OmegaConf.to_container(cfg, resolve=False, throw_on_missing=True),
               mode=cfg.wandb.mode)
    print('Configuring training...')
    print(f'Run ID: {wandb.run.id}')
    print(f'Run Name: {wandb.run.name}')
    print(f'Run path: {wandb.run.path}')
    if wandb.run.resumed:
        print(f'Training resumed: {wandb.run.resumed}\n')

    multigpu_training = False
    if isinstance(cfg.system.device, (list, tuple, omegaconf.ListConfig)):
        device = torch.device(cfg.system.device[0])
        if len(cfg.system.device) > 1:
            multigpu_training = True
        print(f"Using devices: {[torch.device(x) for x in cfg.system.device]}")
    else:
        device = torch.device(cfg.system.device)
        print(f"Using device: {device}")


    parser = ConfigParser(cfg, wandb.run)
    initial_epoch, best_losses = parser.get_training_data()
    model = parser.get_model()

    model.to(device)
    optimizer = parser.get_optimizer()
    lr_scheduler = parser.get_lr_scheduler()
    loss = parser(cfg.loss)
    parser._instances.setdefault("loss", loss)
    metrics = parser(cfg.validation_metrics)
    parser._instances.setdefault("validation_metrics", metrics)
    train_dataset: Dataset = parser(cfg.dataset.training)
    valid_dataset = parser(cfg.dataset.validation)

    # train_dataset = train_dataset.take(12)
    # valid_dataset = valid_dataset.take(12)

    if cfg.system.cache_dir is not None:
        cache_path = Path(cfg.system.cache_dir) / 'cache' / f"{device.type}_{device.index}"
        print(cache_path, cache_path.absolute())
        os.makedirs(cache_path, exist_ok=True)
        if os.path.isdir(cache_path) and cfg.system.recache:
            logger.info(f"Clearing {cache_path}.")
            shutil.rmtree(cache_path)
            logger.info(f"Cache directory {cache_path} removed.")
        train_dataset = train_dataset.cache(cache_path / 'train')
        valid_dataset = valid_dataset.cache(cache_path / 'val')

    train_loader = DataLoaderFactory(train_dataset, batch_size=cfg.training.batch_size, shuffle=True,
                                     num_workers=cfg.training.num_workers, device=cfg.system.device,
                                     pin_memory_device=str(device), pin_memory=True).get_loader()
    val_loader = DataLoaderFactory(valid_dataset, batch_size=1, shuffle=False,
                                   num_workers=0, device=cfg.system.device,
                                   pin_memory_device=str(device), pin_memory=True).get_loader()



    if multigpu_training:
        first_element = train_dataset[0]
        if isinstance(first_element, Entry):
            model = torch.nn.DataParallel(model, device_ids=[torch.device(x).index for x in cfg.system.device])
        elif isinstance(first_element, GraphEntry):
            model = tg.nn.DataParallel(model, device_ids=[torch.device(x).index for x in cfg.system.device])

    else:
        device = torch.device(f'cuda:{cfg.system.device}')


    dp_types = (torch.nn.DataParallel,)
    if tg is not None:
        dp_types = (tg.nn.DataParallel, torch.nn.DataParallel)
    wandb.watch(model if not isinstance(model, dp_types) else model.module,
                log='all', log_graph=True, log_freq=len(train_loader), criterion=loss)
    print('Training started...')

    # Parse runners and trainer from config.
    # Most params come from YAML via %{references} (optimizer, loss, postprocessor, etc.).
    # Only device (multi-GPU logic), model (DataParallel wrapping), and
    # initial_epoch (W&B resume) are injected here as runtime-only params.
    train_runner = parser(cfg.training_runner, device=device)
    parser._instances.setdefault("training_runner", train_runner)
    val_runner = parser(cfg.validation_runner, device=device)
    parser._instances.setdefault("validation_runner", val_runner)
    trainer = parser(cfg.trainer, model=model, initial_epoch=initial_epoch)

    # Wire observers from config
    for target, target_cfg in [
        (train_runner, cfg.training_runner),
        (val_runner, cfg.validation_runner),
        (trainer, cfg.trainer),
    ]:
        for obs_cfg in target_cfg.get("observers", []):
            obs = parser(obs_cfg)
            if isinstance(obs, observers.PyTorchModelSaver):
                obs.best_loss = best_losses['total'] if best_losses is not None else None
            target.add_observer(obs)

    trainer.train(cfg.training.epochs, train_loader, val_loader)
    wandb.finish(0)




if __name__ == "__main__":
    main()
