"""Configuration utilities.

Legacy parsing lives in `srforge.config.legacy`.
"""

from srforge.config.legacy import ConfigParser

__all__ = ["ConfigParser"]
