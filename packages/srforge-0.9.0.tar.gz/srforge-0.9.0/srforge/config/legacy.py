"""Configuration parsing and object instantiation from YAML/OmegaConf."""

import logging
import os
import importlib
import re
from typing import Union, Any, Mapping

from omegaconf import DictConfig, ListConfig

from srforge.training.schedule import BlankLRScheduler
from srforge.utils import IOModule

from srforge.registry import ClassRegistry

import torch
from srforge.models import SequentialModel, Model
logger = logging.getLogger(__name__)
CONFIG_TYPE = DictConfig

class ParamsList(list):
    """List wrapper marking positional parameters during config parsing."""

    def __init__(self, *args, **kwargs):
        """Initialize the list wrapper."""
        super().__init__(*args, **kwargs)


class ParamsDict(dict):
    """Dict wrapper marking keyword parameters during config parsing."""

    def __init__(self, *args, **kwargs):
        """Initialize the dict wrapper."""
        super().__init__(*args, **kwargs)


class ConfigParser:
    """Parse configs and instantiate objects recursively.

    Config syntax:
        _target: module.ClassName
        params:
            param1: value1
            param2: value2

    Reference syntax:
        "%{path.to.object}" resolves a previously instantiated object.
    """

    def __init__(self, config: CONFIG_TYPE, run: 'wandb_sdk.wandb_run.Run'):
        """Initialize the parser with config and run context.

        Args:
            config (CONFIG_TYPE): Root configuration object.
            run (wandb_sdk.wandb_run.Run): W&B run handle.
        """
        self.__model = None
        self.__optimizer = None
        self.__lr_scheduler = None
        self.config = config
        self._run = run
        self.__checkpoint: Any = None
        self._instances: dict[str, Any] = {}
        self._resolving: set[str] = set()

    def _select_config_node(self, path: str) -> Any:
        """Select a config node by dotted path.

        Args:
            path (str): Dotted path (e.g., "model" or "optimizer.params").

        Returns:
            Any: Config node at the given path.

        Raises:
            KeyError: If the path cannot be resolved.
        """
        if not path:
            raise KeyError("Empty config reference path.")
        current: Any = self.config
        for part in path.split("."):
            if isinstance(current, DictConfig):
                if part not in current:
                    raise KeyError(f"Config path '{path}' not found.")
                current = current[part]
                continue
            if isinstance(current, Mapping):
                if part not in current:
                    raise KeyError(f"Config path '{path}' not found.")
                current = current[part]
                continue
            if isinstance(current, (list, tuple, ListConfig, ParamsList)):
                try:
                    idx = int(part)
                except ValueError as exc:
                    raise KeyError(f"Config path '{path}' not found.") from exc
                if idx < 0 or idx >= len(current):
                    raise KeyError(f"Config path '{path}' not found.")
                current = current[idx]
                continue
            raise KeyError(f"Config path '{path}' not found.")
        return current

    def _resolve_path(self, path: str) -> Any:
        """Resolve a config path into an instantiated object.

        Args:
            path (str): Dotted path in the config.

        Returns:
            Any: Resolved object.

        Raises:
            ValueError: If a circular reference is detected.
        """
        if path in self._instances:
            return self._instances[path]
        if path in self._resolving:
            raise ValueError(f"Circular reference detected while resolving '{path}'.")
        self._resolving.add(path)
        node = self._select_config_node(path)
        value = self._load_class_from_config(node, path=path)
        self._instances[path] = value
        self._resolving.remove(path)
        return value

    def _resolve_reference_string(self, value: str) -> Any:
        """Resolve a reference string of the form "%{path.to.object}".

        Args:
            value (str): String to resolve.

        Returns:
            Any: Resolved object if the string is a reference, otherwise the original string.
        """
        if not isinstance(value, str):
            return value
        match = re.fullmatch(r"%\{([^}]+)\}", value.strip())
        if not match:
            return value
        path = match.group(1).strip()
        if not path:
            raise ValueError("Reference path cannot be empty.")
        return self._resolve_path(path)

    def resolve_all(self) -> dict[str, Any]:
        """Resolve all top-level config fields.

        Returns:
            dict[str, Any]: Mapping of top-level keys to resolved objects.
        """
        resolved: dict[str, Any] = {}
        if isinstance(self.config, DictConfig):
            keys = list(self.config.keys())
        elif isinstance(self.config, Mapping):
            keys = list(self.config.keys())
        else:
            return resolved
        for key in keys:
            resolved[key] = self._resolve_path(key)
        return resolved

    @property
    def _model(self) -> 'torch.nn.Module':
        """Return the instantiated model (lazy)."""
        if self.__model is None:
            self.get_model()
        return self.__model

    @property
    def _optimizer(self) -> 'torch.optim.Optimizer':
        """Return the instantiated optimizer (lazy)."""
        if self.__optimizer is None:
            self.get_optimizer()
        return self.__optimizer

    @property
    def _lr_scheduler(self) -> 'torch.optim.lr_scheduler.LRScheduler':
        """Return the instantiated scheduler (lazy)."""
        if self.__lr_scheduler is None:
            self.get_lr_scheduler()
        return self.__lr_scheduler

    def __get_stored_file(self, file: str) -> Any:
        """Restore a file from W&B and load it with torch.

        Args:
            file (str): File name to restore.

        Returns:
            Any: Loaded object from the restored file.
        """
        import wandb
        file = wandb.run.restore(file).name
        loaded_file = torch.load(file, map_location='cpu')
        # remove the downloaded file
        os.remove(file)
        return loaded_file



    @property
    def _checkpoint(self):
        """Return cached checkpoint contents if available."""
        if self.__checkpoint is None:
            checkpoint_files = ['checkpoint_last.pth', 'model_last.pth', 'model.pth']

            for checkpoint in checkpoint_files:
                try:
                    self.__checkpoint = self.__get_stored_file(checkpoint)
                    # remove the downloaded file
                    logger.info(f"Loaded checkpoint '{checkpoint}' for run {self._run.id}.")
                    return self.__checkpoint
                except Exception as e:
                    logger.warning(f"Could not load checkpoint 'checkpoint_last.pth' for run {self._run.id}.")
            logger.critical(f"Could not load any checkpoint for run {self._run.id}.")
        return self.__checkpoint

    def get_model(self) -> 'torch.nn.Module':
        """Instantiate the model defined in the config.

        Returns:
            torch.nn.Module: Instantiated model.

        Raises:
            FileNotFoundError: If requested resume weights are missing.
        """
        config = self.config.model
        self.__dict_to_params_list(config)
        self.__model = self._load_class_from_config(config)
        self._instances.setdefault("model", self.__model)
        logger.info(f'Model initialized: {self.__model}')
        if hasattr(self._run, 'resumed') and self._run.resumed:
            if isinstance(self.__model, SequentialModel):
                raise NotImplementedError("Resuming training for Sequential models is not supported yet.")
                # for i in range(len(self.__model.models)):
                #     self.__model[i].load_state_dict(self._checkpoint[self.__model[i].name])
            else:
                model_weights = self.__get_stored_file(f'{self._model.name}_last.pth')
                if model_weights is not None:
                    self._model.load_state_dict(model_weights)
                else:
                    raise FileNotFoundError(f"Could not find model weights for {self._model.name}.")
            logger.info(f"Loaded model weights from the last checkpoint.")
        return self._model

    def get_optimizer(self) -> 'torch.optim.Optimizer':
        """Instantiate the optimizer defined in the config.

        Returns:
            torch.optim.Optimizer: Instantiated optimizer.
        """
        config = self.config.optimizer
        model = self._model
        if not isinstance(model, Model):
            raise TypeError(
                "Optimizer config expects a Model instance (including SequentialModel). "
                f"Got {type(model)}."
            )
        try:
            trainable_params = list(model.trainable_params())
        except Exception as exc:
            raise RuntimeError(
                f"Failed to collect trainable parameters for model ({type(model)})."
            ) from exc
        self.__optimizer = self._load_class_from_config(config, params=trainable_params)
        self._instances.setdefault("optimizer", self.__optimizer)
        logger.info(f'Optimizer initialized: {self.__optimizer}')
        if self._run.resumed:
            self.__optimizer.load_state_dict(self._checkpoint['optimizer'])
            logger.info(f"Loaded optimizer state from checkpoint.")
        return self._optimizer

    def get_lr_scheduler(self) -> 'torch.optim.lr_scheduler.LRScheduler':
        """Instantiate the learning rate scheduler defined in the config.

        Returns:
            torch.optim.lr_scheduler.LRScheduler: Instantiated scheduler.
        """
        config = self.config.lr_scheduler
        if config is None:
            self.__lr_scheduler = BlankLRScheduler(self._optimizer)
            self._instances.setdefault("lr_scheduler", self.__lr_scheduler)
            return self._lr_scheduler

        self.__lr_scheduler = self._load_class_from_config(config, optimizer=self._optimizer)
        self._instances.setdefault("lr_scheduler", self.__lr_scheduler)
        logger.debug(f'LR Scheduler initialized: {self.__lr_scheduler}')
        if self._run.resumed:
            if 'lr_scheduler' in self._checkpoint:
                self.__lr_scheduler.load_state_dict(self._checkpoint['lr_scheduler'])
                logger.debug(f"Loaded lr scheduler state from checkpoint.")
            else:
                logger.warning(f"Could not find lr scheduler state in checkpoint.")
        return self._lr_scheduler

    def get_training_data(self) -> tuple:
        """Return resume-related training metadata.

        Returns:
            tuple[int, Any]: Initial epoch and best losses (if resuming).
        """
        initial_epoch = 0
        best_losses = None
        if self._run.resumed:
            initial_epoch = self._run.summary.get('epoch') + 1
            best_losses = self._run.summary.get('best_losses')
        return initial_epoch, best_losses

    @staticmethod
    def __dict_to_params_list(config: Union[ListConfig[CONFIG_TYPE], CONFIG_TYPE]) -> Union[ListConfig, CONFIG_TYPE]:
        """Normalize a config object into a list wrapper.

        Args:
            config (Union[ListConfig[CONFIG_TYPE], CONFIG_TYPE]): Config to normalize.

        Returns:
            Union[ListConfig, CONFIG_TYPE]: The normalized config.
        """
        if isinstance(config, DictConfig):
            return ListConfig([config])
        return config

    def _load_class_from_config(self, config: Union[DictConfig, ListConfig], *args, path: str | None = None, **kwargs):
        """Recursively instantiate objects from config.

        Args:
            config (Union[DictConfig, ListConfig]): Config node to parse.
            *args: Positional args to pass through.
            **kwargs: Keyword args to pass through.

        Returns:
            Any: Instantiated object or parsed value.

        Raises:
            ModuleNotFoundError: If the target module cannot be imported.
            AttributeError: If the target class is missing.
            TypeError: If io bindings are provided for a non-IOModule target.
            Exception: If instantiation fails for other reasons.
        """
        if path is not None and path in self._instances:
            return self._instances[path]
        if isinstance(config, str):
            return self._resolve_reference_string(config)
        if isinstance(config, DictConfig) or isinstance(config, ParamsDict):
            if '_target' in config:
                # if 'module' in config and 'name' in config:
                _target = config['_target']
                if _target in ClassRegistry():
                    module, class_name = ClassRegistry().get(_target)
                else:
                    module = '.'.join(_target.split('.')[:-1])

                    class_name = _target.split('.')[-1]
                if module in [None, ''] or class_name in [None, '']:
                    raise ValueError(
                        f"Module and class name must be provided in the configuration file for the key '_target' or "
                        f"the class must be registered in the CLASS_REGISTRY. Got {_target}"
                    )

                kwargs_params = ParamsDict()
                args_params = ParamsList()
                io_cfg = config.get("io") if isinstance(config, Mapping) else None
                if 'params' in config and config['params'] is not None:
                    params = self._load_class_from_config(
                        config['params'],
                        path=f"{path}.params" if path else None,
                    )
                    if isinstance(params, ParamsList):
                        params = ParamsList(list(params))
                        args_params.append(params)
                    elif isinstance(params, ParamsDict):
                        kwargs_params = params

                try:
                    imported_module = importlib.import_module(module)
                except ModuleNotFoundError as e:
                    logger.critical(f"Trying to import module '{module}' for class '{class_name}' failed.")
                    raise e
                try:
                    cls = getattr(imported_module, class_name)
                except AttributeError as e:
                    logger.critical(f"Module '{module}' does not have a class '{class_name}'.")
                    raise e
                try:
                    instance = cls(*args, *args_params, **kwargs, **kwargs_params)
                    if io_cfg is not None:
                        if isinstance(instance, IOModule):
                            instance.set_io(io_cfg)
                        else:
                            raise TypeError(
                                f"{cls.__name__} does not support io bindings but config provided 'io'."
                            )
                    if path is not None:
                        self._instances[path] = instance
                    return instance
                except Exception as e:
                    logger.critical(f"Could not instantiate class '{class_name}' from module '{module}' with parameters:\n"
                                    f"args: {args}\nkwargs: {kwargs}\nargs_params: {args_params}\nkwargs_params {kwargs_params}.")
                    raise e
            params = ParamsDict()
            for key, subconfig in config.items():
                params[key] = self._load_class_from_config(
                    subconfig,
                    path=f"{path}.{key}" if path else None,
                )
            return params
        elif isinstance(config, ListConfig) or isinstance(config, ParamsList):
            params = ParamsList()
            for idx, subconfig in enumerate(config):
                params.append(
                    self._load_class_from_config(
                        subconfig,
                        path=f"{path}.{idx}" if path else None,
                    )
                )
            return params
        return config

    def __call__(self, config: Any, *arg_params: Any, **kwarg_params: Any) -> Any:
        """Parse and instantiate a config node.

        Args:
            config: Config node to parse.
            *arg_params: Positional args to forward.
            **kwarg_params: Keyword args to forward.

        Returns:
            Any: Parsed object.
        """
        parsed_config = self._load_class_from_config(config, *arg_params, **kwarg_params)
        return parsed_config
