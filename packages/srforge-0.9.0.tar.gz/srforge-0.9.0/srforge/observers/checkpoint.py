import logging
import os
from typing import Union

import torch
import wandb

import srforge.events.trainer
from srforge import GlobalSettings
from srforge.models import Model, SequentialModel
from srforge.registry import register_class
from .base import Observer

logger = logging.getLogger(__name__)


@register_class
class PyTorchModelSaver(Observer):
    """Observer that saves model checkpoints to disk and W&B after each epoch.

    Tracks the best validation loss and saves both ``_best`` and ``_last``
    checkpoints (model weights, optimizer state, LR scheduler, scaler, epoch).
    """

    EVENTS = [srforge.events.trainer.TrainerEpochFinished]
    def __init__(self, best_loss: float = None):
        self.best_loss = best_loss

    def on_epoch_finished(self, event: srforge.events.trainer.TrainerEpochFinished):
        val_loss_mean = event.val_loss.total_weighted().mean()
        if self.best_loss is None or self.best_loss > val_loss_mean:
            if self.best_loss is not None:
                logger.info(f"New best loss: {self.best_loss} -> {val_loss_mean}")
            wandb.run.summary[f"best_losses"] = event.val_loss.as_summary_dict()
            # for key in data.val_loss.keys():
            #     wandb.run.summary[f"best_{key}"] = data.val_loss[key]
            wandb.run.summary["best_epoch"] = event.epoch
            self.best_loss = val_loss_mean
            self.save_states(event, "_best")
        wandb.summary['epoch'] = event.epoch
        self.save_states(event, "_last")

    def save_states(self, data: srforge.events.trainer.TrainerEpochFinished, suffix: str = ""):
        # save optimizer, epoch and scaler
        out_path = os.path.join(GlobalSettings().output_directory, f'checkpoint{suffix}.pth')
        torch.save({"optimizer": data.optimizer.state_dict(), "lr_scheduler": data.lr_scheduler.state_dict(),
                    "epoch": data.epoch, "scaler": data.scaler.state_dict()}, out_path)
        wandb.save(out_path, base_path=GlobalSettings().output_directory)

        #save models
        self._save_model(data.model, suffix)

    def _save_model(self, model: Union[Model, SequentialModel], suffix: str):
        """Save model state dicts to disk and upload to W&B.

        Handles ``DataParallel`` wrappers and ``SequentialModel`` by saving
        each sub-model individually.
        """
        try:
            from torch_geometric.nn import DataParallel as tgDataParallel
        except ImportError:
            tgDataParallel = None
        dp_types = (torch.nn.DataParallel,)
        if tgDataParallel is not None:
            dp_types = (tgDataParallel, torch.nn.DataParallel)
        model = model if not isinstance(model, dp_types) else model.module
        if isinstance(model, SequentialModel):
            model = list(model.models.values())
        elif isinstance(model, Model):
            model = [model]
        else:
            raise ValueError(f"Model type not supported: {type(model)}")

        for m in model:
            out_path = os.path.join(GlobalSettings().output_directory, f'{m.name}{suffix}.pth')
            torch.save(m.state_dict(), out_path)
            wandb.save(out_path, base_path=GlobalSettings().output_directory)
