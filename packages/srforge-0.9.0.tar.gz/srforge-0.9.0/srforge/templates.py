"""Embedded templates for `srforge init` scaffolding."""

TRAIN_SCRIPT = '''\
import os
import shutil
from pathlib import Path

os.environ["C10D_TCP_STORE_USE_LIBUV"] = "0"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE" # IMPORT CORE AFTER THIS LINE !!!
import logging
from srforge.utils.logging import configure_logger
configure_logger(logging.INFO)
import hydra
from hydra.core.hydra_config import HydraConfig

import wandb
import omegaconf
from srforge import GlobalSettings
import srforge.config.utils
from srforge.config.legacy import ConfigParser
from srforge.dataset import Dataset
from srforge.data.loader import DataLoaderFactory
from srforge.data import Entry, GraphEntry
from srforge import observers

from srforge.training import runners, trainers
import torch
try:
    import torch_geometric as tg
except ImportError:
    tg = None

logger = logging.getLogger(__name__)

@hydra.main(config_path="configs", config_name="train-cfg", version_base=None)
def main(cfg) -> None:
    srforge.config.utils.clear_defaults(cfg)

    # Set global settings
    GlobalSettings().config = cfg
    GlobalSettings().output_directory = HydraConfig.get().runtime.output_dir

    configure_logger(cfg.system.debug_level)# second time because hydra overrides current global logger configuration
    out_dir = GlobalSettings().output_directory
    wandb.init(project=cfg.wandb.project, entity=cfg.wandb.entity, name=cfg.wandb.run_name,
               id=cfg.wandb.run_id, group=cfg.wandb.group_name, notes=cfg.wandb.notes,
               dir=out_dir, tags=cfg.wandb.tags, job_type=\'training\', resume=\'allow\',
               config=omegaconf.OmegaConf.to_container(cfg, resolve=False, throw_on_missing=True),
               mode=cfg.wandb.mode)
    print(\'Configuring training...\')
    print(f\'Run ID: {wandb.run.id}\')
    print(f\'Run Name: {wandb.run.name}\')
    print(f\'Run path: {wandb.run.path}\')
    if wandb.run.resumed:
        print(f\'Training resumed: {wandb.run.resumed}\\n\')

    multigpu_training = False
    if isinstance(cfg.system.device, (list, tuple, omegaconf.ListConfig)):
        device = torch.device(cfg.system.device[0])
        if len(cfg.system.device) > 1:
            multigpu_training = True
        print(f"Using devices: {[torch.device(x) for x in cfg.system.device]}")
    else:
        device = torch.device(cfg.system.device)
        print(f"Using device: {device}")


    parser = ConfigParser(cfg, wandb.run)
    initial_epoch, best_losses = parser.get_training_data()
    model = parser.get_model()

    model.to(device)
    optimizer = parser.get_optimizer()
    lr_scheduler = parser.get_lr_scheduler()
    loss = parser(cfg.loss)
    parser._instances.setdefault("loss", loss)
    metrics = parser(cfg.validation_metrics)
    parser._instances.setdefault("validation_metrics", metrics)
    train_dataset: Dataset = parser(cfg.dataset.training)
    valid_dataset = parser(cfg.dataset.validation)

    if cfg.system.cache_dir is not None:
        cache_path = Path(cfg.system.cache_dir) / \'cache\' / f"{device.type}_{device.index}"
        print(cache_path, cache_path.absolute())
        os.makedirs(cache_path, exist_ok=True)
        if os.path.isdir(cache_path) and cfg.system.recache:
            logger.info(f"Clearing {cache_path}.")
            shutil.rmtree(cache_path)
            logger.info(f"Cache directory {cache_path} removed.")
        train_dataset = train_dataset.cache(cache_path / \'train\')
        valid_dataset = valid_dataset.cache(cache_path / \'val\')

    train_loader = DataLoaderFactory(train_dataset, batch_size=cfg.training.batch_size, shuffle=True,
                                     num_workers=cfg.training.num_workers, device=cfg.system.device,
                                     pin_memory_device=str(device), pin_memory=True).get_loader()
    val_loader = DataLoaderFactory(valid_dataset, batch_size=1, shuffle=False,
                                   num_workers=0, device=cfg.system.device,
                                   pin_memory_device=str(device), pin_memory=True).get_loader()



    if multigpu_training:
        first_element = train_dataset[0]
        if isinstance(first_element, Entry):
            model = torch.nn.DataParallel(model, device_ids=[torch.device(x).index for x in cfg.system.device])
        elif isinstance(first_element, GraphEntry):
            model = tg.nn.DataParallel(model, device_ids=[torch.device(x).index for x in cfg.system.device])

    else:
        device = torch.device(f\'cuda:{cfg.system.device}\')


    dp_types = (torch.nn.DataParallel,)
    if tg is not None:
        dp_types = (tg.nn.DataParallel, torch.nn.DataParallel)
    wandb.watch(model if not isinstance(model, dp_types) else model.module,
                log=\'all\', log_graph=True, log_freq=len(train_loader), criterion=loss)
    print(\'Training started...\')

    # Parse runners and trainer from config.
    # Most params come from YAML via %{references} (optimizer, loss, postprocessor, etc.).
    # Only device (multi-GPU logic), model (DataParallel wrapping), and
    # initial_epoch (W&B resume) are injected here as runtime-only params.
    train_runner = parser(cfg.training_runner, device=device)
    parser._instances.setdefault("training_runner", train_runner)
    val_runner = parser(cfg.validation_runner, device=device)
    parser._instances.setdefault("validation_runner", val_runner)
    trainer = parser(cfg.trainer, model=model, initial_epoch=initial_epoch)

    # Wire observers from config
    for target, target_cfg in [
        (train_runner, cfg.training_runner),
        (val_runner, cfg.validation_runner),
        (trainer, cfg.trainer),
    ]:
        for obs_cfg in target_cfg.get("observers", []):
            obs = parser(obs_cfg)
            if isinstance(obs, observers.PyTorchModelSaver):
                obs.best_loss = best_losses[\'total\'] if best_losses is not None else None
            target.add_observer(obs)

    trainer.train(cfg.training.epochs, train_loader, val_loader)
    wandb.finish(0)




if __name__ == "__main__":
    main()
'''

TRAIN_CONFIG = '''\
system:
  cache_dir: # Dataset cache directory. Null = no caching.
  device: 0
#      - 0
#      - 1 # List for multi-GPU DataParallel. Single int or 'cpu' for single device.
  recache: True # Force re-cache even if cache exists.
  mixed_precision: False # Enable automatic mixed precision (AMP).
  debug_level: INFO # DEBUG, INFO, WARNING, ERROR, CRITICAL

wandb:
  mode: online # online, offline, or disabled
  entity: my-team
  project: my-project
  run_name: # Auto-generated if null.
  run_id: # Set to resume a previous run.
  group_name: # Group related runs. Null = no grouping.
  tags: # List of strings for W&B UI tags.
  notes: # Free-text description of the run.

training:
  epochs: 1000
  batch_size: 8
  num_workers: 0
  gradient_accumulation_steps: 1


# ═══════════════════════════════════════════════════════════════════════════
# Model
# ═══════════════════════════════════════════════════════════════════════════
# The model declares logical IO ports via io_spec (e.g. "image", "hr", "sr").
# The 'io:' block maps those ports to actual Entry field names from the dataset.
#
# Bicubic.io_spec:
#   required_inputs: (image,)  — the low-res input
#   optional_inputs: (hr,)     — optional HR reference for target-size upsampling
#   required_outputs: (sr,)    — the super-resolved output
#
# After the model runs, its outputs are merged into the Entry. So after this
# step the Entry gains a new field "sr" (or whatever the output port maps to).

model:
  _target: srforge.models.basic.Bicubic
  params:
    scale: 3
  io:
    inputs:
      image: lr        # port "image" reads from Entry field "lr"
      hr: hr           # port "hr" reads from Entry field "hr"
    outputs:
      sr: sr           # port "sr" writes to Entry field "sr"

optimizer:
  _target: torch.optim.AdamW
  params:
    lr: 0.0005
    weight_decay: 0

lr_scheduler: # Null = no scheduler (constant LR).
  _target: torch.optim.lr_scheduler.ReduceLROnPlateau
  params:
    mode: "min"
    factor: 0.5
    patience: 10
    threshold: 1e-6
    cooldown: 10
    min_lr: 0
    eps: 1e-8


# ═══════════════════════════════════════════════════════════════════════════
# Loss
# ═══════════════════════════════════════════════════════════════════════════
# Loss.calculate_score parameter names are matched against Entry field names.
# L1 and SSIM both expect (x, y) — by default, they look for Entry fields
# "x" and "y". Use 'io' to remap them to different Entry fields.
#
# After the model runs, the Entry contains at least: lr, hr, sr.
# L1(x, y) needs x=sr (prediction) and y=hr (ground truth), so we remap:

loss:
  _target: LossScheduler
  params:
    schedule:
      0:
        _target: LossCombiner
        params:
          losses:
            - _target: L1
              params:
                weight: 1.0
              io:
                inputs: {x: sr, y: hr}
            - _target: SSIM
              params:
                weight: 0.01
              io:
                inputs: {x: sr, y: hr}
      50:
        _target: LossCombiner
        params:
          losses:
            - _target: L1
              params:
                weight: 1.0
              io:
                inputs: {x: sr, y: hr}
            - _target: SSIM
              params:
                weight: 0.05
              io:
                inputs: {x: sr, y: hr}

validation_metrics: ${loss} # Same structure as loss, or define a different one.


# ═══════════════════════════════════════════════════════════════════════════
# Dataset
# ═══════════════════════════════════════════════════════════════════════════
# LazyDataset loads data from a directory tree. The 'mappings' dict maps
# Entry field names to filename patterns inside each example folder.
#
# Example directory structure:
#   root/
#     scene_001/
#       HR.tif          <- matched by pattern "HR"
#       LR.tif          <- matched by pattern "LR"
#     scene_002/
#       HR.tif
#       LR.tif
#
# With mappings: {hr: HR, lr: LR}, each Entry gets:
#   entry.name = "scene_001"
#   entry.hr   = <loaded tensor from HR.tif>
#   entry.lr   = <loaded tensor from LR.tif>

dataset:
  training:
    _target: LazyDataset
    params:
      root: /path/to/train
      mappings:
        hr: HR
        lr: LR
      depth: 0
  validation:
    _target: LazyDataset
    params:
      root: /path/to/val
      mappings:
        hr: HR
        lr: LR
      depth: 0


# ═══════════════════════════════════════════════════════════════════════════
# Preprocessing / Postprocessing
# ═══════════════════════════════════════════════════════════════════════════
# Transforms are applied to the Entry before/after the model.
# Each transform uses 'io:' to declare which Entry fields it reads/writes.
# See docs/src/io-binding.md for all config syntax options.

preprocessing:
  training:
    # Normalize pixel values to [0, 1] — applied to both lr and hr.
    - _target: srforge.transform.data.Divide
      params:
        value: 255.0
      io:
        inputs: [{image: lr}, {image: hr}]
    # Convert to float32.
    - _target: srforge.transform.data.ToFloat
      io:
        inputs: [{image: lr}, {image: hr}]
  validation: ${preprocessing.training}

postprocessing:  # List of transforms applied after model outputs are merged.
  training: []
  validation: ${postprocessing.training}


# ═══════════════════════════════════════════════════════════════════════════
# Runners, trainer, and observers
# ═══════════════════════════════════════════════════════════════════════════
# Params use "%{path}" to reference already-instantiated objects (optimizer,
# loss, postprocessor, etc.) and ${path} for raw config values.
# Only device (multi-GPU logic), model (DataParallel wrapping), and
# initial_epoch (W&B resume) are injected by train.py at runtime.
#
# 'observers:' lists are wired by train.py via target.add_observer().

training_runner:
  _target: TrainingEpochRunner
  params:
    optimizer: "%{optimizer}"
    postprocessor: "%{postprocessing.training}"
    mixed_precision: ${system.mixed_precision}
    gradient_accumulation_steps: ${training.gradient_accumulation_steps}
  observers:
    - _target: ProgressBar
      params:
        name: "T"

validation_runner:
  _target: ValidationEpochRunner
  params:
    postprocessor: "%{postprocessing.validation}"
    mixed_precision: ${system.mixed_precision}
  observers:
    - _target: ProgressBar
      params:
        name: "V"
    - _target: BatchImageLogger
      params:
        batch_id: 0
        transforms:
          - _target: CLAHE
        img_key: sr
        log_dir: val_pred

trainer:
  _target: PyTorchTrainer
  params:
    training_epoch_runner: "%{training_runner}"
    validation_epoch_runner: "%{validation_runner}"
    training_criterion: "%{loss}"
    validation_criterion: "%{validation_metrics}"
    lr_scheduler: "%{lr_scheduler}"
    # stop_condition:
    #   _target: ValidationLossDidNotImprove
    #   params:
    #     patience: 50
    #     min_delta: 0.0001
  observers:
    - _target: LossLogger
    - _target: PyTorchModelSaver
'''
