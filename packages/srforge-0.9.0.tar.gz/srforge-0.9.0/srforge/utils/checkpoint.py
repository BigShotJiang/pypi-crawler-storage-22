import logging

import wandb
import torch
import os
import omegaconf

from srforge.config.legacy import ConfigParser

logger = logging.getLogger(__name__)


def load_weights_from_wandb(module: torch.nn.Module, project: str, entity: str, run_id: str, module_name: str = None, load_best_model: bool = True):
    """
    Restore Module weights from a file stored in W&B for a specific run.
    :param module: Torch.nn.Module instance to load the weights into.
    :param project: The wandb project name.
    :param entity: The wandb entity name.
    :param run_id: The wandb run ID.
    :param module_name: Name of the file to load (without suffix). DEFAULT: use the class name of the module.
    :param load_best_model: If True, load the best model from wandb, otherwise load the last model. It basically decides the filename suffix (_best.pth or _last.pth).
    """
    import wandb
    import torch
    import os
    # if any of the arguments are None, return
    if module_name is None:
        module_name = module.__class__.__name__
    if load_best_model:
        filename = f"{module_name}_best.pth"
    else:
        filename = f"{module_name}_last.pth"

    run = wandb.Api().run(f"{entity}/{project}/{run_id}")
    if run is None:
        raise ValueError(f"Run with ID '{run_id}' not found in project '{project}' and entity '{entity}'.")
    file = run.file(filename).download(replace=True).name
    loaded_file = torch.load(file, map_location='cpu')
    # remove the downloaded file
    os.remove(file)
    module.load_state_dict(loaded_file)
    logger.info(f"Loaded model weights from '{filename}' for run {run_id}.")
    return module


def get_model_from_wandb(model_name: str,
                         run_id: str,
                         project: str,
                         entity: str,
                         load_best_model: bool,
                         target_class: str = None) -> torch.nn.Module:
    """
    Load a model from wandb.
    :param model_name: The model name.
    :param run_id: The wandb run ID.
    :param project: The wandb project name.
    :param entity: The wandb entity name.
    :param load_best_model: If True, load the best model from wandb, otherwise load the last model.
    :param target_class: If specified, the model class to instantiate. If None, the class will be inferred from the config.
    :return: The model instance with loaded weights
    """
    run = wandb.Api().run(f"{entity}/{project}/{run_id}")
    if run is None:
        raise ValueError(f"Run with ID '{run_id}' not found in project '{project}' and entity '{entity}'.")
    config = omegaconf.OmegaConf.create(run.config)
    parser = ConfigParser(config, run)
    if target_class is not None:
        logger.info(f"Instantiating model of class '{target_class}' instead of the one defined in the config: {config.model._target}.")
        # from pprint import pprint
        # pprint(omegaconf.OmegaConf.to_container(config.model, resolve=True))
        config.model._target = target_class
        # raise NotImplementedError("Specifying 'target_class' is not implemented yet.")
    model = parser.get_model()
    filename = f"{model_name}_best.pth" if load_best_model else f"{model_name}_last.pth"
    file = run.file(filename).download(replace=True).name
    loaded_file = torch.load(file, map_location='cpu')
    # remove the downloaded file
    os.remove(file)
    model.load_state_dict(loaded_file)
    logger.info(f"Loaded model weights from '{filename}' for run '{run.name}' (ID: {run_id}).")
    return model