"""Tests for config-driven observer wiring to runners/trainer."""

import pytest
from dataclasses import dataclass
from omegaconf import OmegaConf

from srforge.events.base import Event
from srforge.observers.base import Observer, Observable
from srforge.config.legacy import ConfigParser


# ── Test events & observers ──────────────────────────────────────────────

@dataclass(frozen=True)
class DummyEvent(Event):
    value: int


class DummyObserver(Observer):
    EVENTS = [DummyEvent]

    def __init__(self, name: str = "default"):
        self.name = name
        self.received = []

    def on_dummy_event(self, event: DummyEvent):
        self.received.append(event.value)


# Register for ConfigParser resolution
from srforge.registry import register_class
register_class(DummyObserver)


# ── Helpers ──────────────────────────────────────────────────────────────

def make_parser():
    """Create a minimal ConfigParser (cfg/wandb_run unused for direct parsing)."""
    cfg = OmegaConf.create({})
    return ConfigParser(cfg, None)


# ── Tests ────────────────────────────────────────────────────────────────

class TestObserverFromConfig:
    def test_parse_single_observer(self):
        parser = make_parser()
        obs_cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "test_obs"}
        })
        obs = parser(obs_cfg)
        assert isinstance(obs, DummyObserver)
        assert obs.name == "test_obs"

    def test_attach_parsed_observer_to_observable(self):
        parser = make_parser()
        obs_cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "attached"}
        })
        obs = parser(obs_cfg)

        target = Observable()
        target.add_observer(obs)
        target.notify(DummyEvent(value=42))

        assert obs.received == [42]

    def test_multiple_observers_from_config_list(self):
        parser = make_parser()
        observers_cfg = OmegaConf.create([
            {"_target": "DummyObserver", "params": {"name": "A"}},
            {"_target": "DummyObserver", "params": {"name": "B"}},
        ])

        target = Observable()
        for obs_cfg in observers_cfg:
            obs = parser(obs_cfg)
            target.add_observer(obs)

        target.notify(DummyEvent(value=99))

        # Both observers should have received the event
        assert len(target._observers[DummyEvent]) == 2

    def test_observer_config_with_extra_keys_ignored(self):
        """ConfigParser ignores keys it doesn't know about (like 'observers')."""
        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "x"},
            "observers": [{"_target": "DummyObserver"}],  # unknown key
        })
        obs = parser(cfg)
        assert isinstance(obs, DummyObserver)
        assert obs.name == "x"


class TestRuntimeKwargsInjection:
    def test_config_params_merged_with_runtime_kwargs(self):
        """ConfigParser merges config params with extra **kwargs passed to __call__."""
        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "DummyObserver",
        })
        # name provided as runtime kwarg instead of in config params
        obs = parser(cfg, name="injected")
        assert isinstance(obs, DummyObserver)
        assert obs.name == "injected"

    def test_runtime_kwargs_override_config_params(self):
        """Runtime kwargs take precedence when both config and kwargs specify same key."""
        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "from_config"},
        })
        # This will cause a conflict — Python kwargs merge means runtime wins
        # Actually, ConfigParser does: cls(**kwargs, **kwargs_params) where kwargs = runtime, kwargs_params = config
        # If both have "name", Python raises TypeError for duplicate kwarg.
        # So config params and runtime kwargs should NOT overlap.
        # This test documents the expected behavior.
        with pytest.raises(TypeError):
            parser(cfg, name="from_runtime")


class TestObserverWiringPattern:
    def test_full_wiring_loop(self):
        """Simulate the pattern used in train.py: parse target, then wire observers."""
        parser = make_parser()

        target_cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "target_itself"},
            "observers": [
                {"_target": "DummyObserver", "params": {"name": "child_A"}},
                {"_target": "DummyObserver", "params": {"name": "child_B"}},
            ]
        })

        # Parse the target (DummyObserver is also an Observable stand-in here,
        # but in real code this would be a runner/trainer)
        target = Observable()

        # Wire observers from config
        wired = []
        for obs_cfg in target_cfg.get("observers", []):
            obs = parser(obs_cfg)
            target.add_observer(obs)
            wired.append(obs)

        assert len(wired) == 2
        assert wired[0].name == "child_A"
        assert wired[1].name == "child_B"

        # Verify events reach all wired observers
        target.notify(DummyEvent(value=7))
        assert wired[0].received == [7]
        assert wired[1].received == [7]

    def test_empty_observers_list_is_fine(self):
        """No observers configured — should work without errors."""
        target_cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "lonely"},
        })

        target = Observable()
        for obs_cfg in target_cfg.get("observers", []):
            pass  # no iterations

        # No observers, notify should be a no-op
        target.notify(DummyEvent(value=1))


class TestPostInstantiationInjection:
    def test_set_attribute_after_parsing(self):
        """Simulate PyTorchModelSaver.best_loss injection pattern."""
        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "saver"},
        })
        obs = parser(cfg)
        # Post-instantiation attribute injection
        obs.best_loss = 0.123
        assert obs.best_loss == 0.123


class TestRegisteredRunnerClasses:
    def test_training_epoch_runner_registered(self):
        from srforge.registry import ClassRegistry
        assert "TrainingEpochRunner" in ClassRegistry()

    def test_validation_epoch_runner_registered(self):
        from srforge.registry import ClassRegistry
        assert "ValidationEpochRunner" in ClassRegistry()

    def test_benchmark_runner_registered(self):
        from srforge.registry import ClassRegistry
        assert "BenchmarkRunner" in ClassRegistry()

    def test_pytorch_trainer_registered(self):
        from srforge.registry import ClassRegistry
        assert "PyTorchTrainer" in ClassRegistry()


class TestRegisteredObserverClasses:
    def test_progress_bar_registered(self):
        from srforge.registry import ClassRegistry
        assert "ProgressBar" in ClassRegistry()

    def test_loss_logger_registered(self):
        from srforge.registry import ClassRegistry
        assert "LossLogger" in ClassRegistry()

    def test_pytorch_model_saver_registered(self):
        from srforge.registry import ClassRegistry
        assert "PyTorchModelSaver" in ClassRegistry()

    def test_batch_image_logger_registered(self):
        from srforge.registry import ClassRegistry
        assert "BatchImageLogger" in ClassRegistry()

    def test_batch_image_saver_registered(self):
        from srforge.registry import ClassRegistry
        assert "BatchImageSaver" in ClassRegistry()

    def test_logits_logger_registered(self):
        from srforge.registry import ClassRegistry
        assert "LogitsLogger" in ClassRegistry()


class TestRegisteredTransformClasses:
    def test_histogram_equalize_registered(self):
        from srforge.registry import ClassRegistry
        assert "HistogramEqualize" in ClassRegistry()

    def test_clahe_registered(self):
        from srforge.registry import ClassRegistry
        assert "CLAHE" in ClassRegistry()

    def test_match_reference_registered(self):
        from srforge.registry import ClassRegistry
        assert "MatchReference" in ClassRegistry()
