# Hello Class

Shared Python class utility.

## Installation

From PyPI:

```bash
uv add srvc-io-hello-class
```

Or with pip:

```bash
pip install srvc-io-hello-class
```

From GitHub (for unreleased versions):

```bash
uv add "srvc-io-hello-class @ git+ssh://git@github.com/johard/python-packages.git@hello-class-v0.2.1#subdirectory=hello-class"
```

## Usage

```python
from hello_class import Hello, json_to_text

# Greeting class
hello = Hello("World")
print(hello.greet())

# JSON to text conversion
json_to_text("input.json", "output.txt")
```

### json_to_text

Converts a JSON file to a text file with `key:value` format.

**Input (input.json):**

```json
[{"foo": "bar"}]
```

**Output (output.txt):**

```text
foo:bar
```
