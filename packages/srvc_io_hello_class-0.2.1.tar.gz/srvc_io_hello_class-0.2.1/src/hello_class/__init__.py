"""Hello class package."""

__version__ = "0.2.1"

import json
from pathlib import Path


def json_to_text(json_path: str | Path, output_path: str | Path) -> None:
    """Parse a JSON file and write key:value pairs to a text file.

    Args:
        json_path: Path to the input JSON file.
        output_path: Path to the output text file.
    """
    json_path = Path(json_path)
    output_path = Path(output_path)

    with json_path.open() as f:
        data = json.load(f)

    lines: list[str] = []
    for item in data:
        for key, value in item.items():
            lines.append(f"{key}:{value}")

    output_path.write_text("\n".join(lines) + "\n")


class Hello:
    """A simple greeting class."""

    def __init__(self, name: str) -> None:
        self.name = name

    def greet(self) -> str:
        """Return a greeting message."""
        return f"Hello, {self.name}!"
