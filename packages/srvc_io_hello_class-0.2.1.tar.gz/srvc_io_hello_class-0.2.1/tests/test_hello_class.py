import json
from pathlib import Path

from hello_class import Hello, json_to_text


def test_json_to_text(tmp_path: Path) -> None:
    json_file = tmp_path / "input.json"
    output_file = tmp_path / "output.txt"

    json_file.write_text(json.dumps([{"foo": "bar"}]))

    json_to_text(json_file, output_file)

    assert output_file.read_text() == "foo:bar\n"


def test_json_to_text_multiple_items(tmp_path: Path) -> None:
    json_file = tmp_path / "input.json"
    output_file = tmp_path / "output.txt"

    json_file.write_text(json.dumps([{"foo": "bar"}, {"baz": "qux"}]))

    json_to_text(json_file, output_file)

    assert output_file.read_text() == "foo:bar\nbaz:qux\n"


def test_json_to_text_multiple_keys(tmp_path: Path) -> None:
    json_file = tmp_path / "input.json"
    output_file = tmp_path / "output.txt"

    json_file.write_text(json.dumps([{"foo": "bar", "baz": "qux"}]))

    json_to_text(json_file, output_file)

    content = output_file.read_text()
    assert "foo:bar" in content
    assert "baz:qux" in content


def test_hello_init() -> None:
    hello = Hello("World")
    assert hello.name == "World"


def test_hello_greet() -> None:
    hello = Hello("World")
    assert hello.greet() == "Hello, World!"


def test_hello_greet_with_name() -> None:
    hello = Hello("Johan")
    assert hello.greet() == "Hello, Johan!"
