# Hello World

Shared Python utility.

## Installation

From PyPI:

```bash
uv add srvc-io-hello-world
```

Or with pip:

```bash
pip install srvc-io-hello-world
```

From GitHub (for unreleased versions):

```bash
uv add "srvc-io-hello-world @ git+ssh://git@github.com/johard/python-packages.git@hello-world-v0.2.1#subdirectory=hello-world"
```

## Usage

```python
from hello_world import greet

print(greet("World"))
```
