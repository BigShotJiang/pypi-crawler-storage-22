"""Hello World - Shared Python utilities."""

__version__ = "0.2.1"


def greet(name: str) -> str:
    """Return a greeting message."""
    return f"Hello, {name}!"
