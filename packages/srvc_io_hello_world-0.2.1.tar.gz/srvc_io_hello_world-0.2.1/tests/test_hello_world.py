from hello_world import greet


def test_greet() -> None:
    assert greet("World") == "Hello, World!"


def test_greet_with_name() -> None:
    assert greet("Johan") == "Hello, Johan!"
