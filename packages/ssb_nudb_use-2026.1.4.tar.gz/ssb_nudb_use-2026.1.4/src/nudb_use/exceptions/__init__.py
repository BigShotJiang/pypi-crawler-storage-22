"""Custom exception types and helpers for nudb_use."""
