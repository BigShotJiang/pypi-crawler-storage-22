import sys

from ssb_pubmd.cli import run_cli
from ssb_pubmd.config import get_config


def main() -> None:
    config = get_config()
    run_cli(sys.argv, config)


if __name__ == "__main__":
    main()
