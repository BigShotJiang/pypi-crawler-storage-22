import subprocess
import sys
from pathlib import Path

from watchfiles import watch

from ssb_pubmd.adapters.content_parser import MimirContentParser
from ssb_pubmd.adapters.document_processor import PandocDocumentProcessor
from ssb_pubmd.adapters.publish_client import PublishClient
from ssb_pubmd.adapters.publish_client import get_publish_client
from ssb_pubmd.adapters.storage import LocalFileStorage
from ssb_pubmd.config import Config
from ssb_pubmd.domain.document_publisher import sync_document


def run_cli(system_arguments: list[str], config: Config) -> None:
    match system_arguments:
        case [_, "preview", file_path]:
            _preview(file_path, config)
        case _:
            print("Usage: ssb-pubmd preview QUARTO_MARKDOWN_FILE")
            sys.exit(1)


def _preview(file_path: str, config: Config) -> None:
    if Path(file_path).suffix != ".qmd":
        print("Only Quarto Markdown (.qmd) files are supported.")
        sys.exit(1)
    try:
        print("Fetching labid token...")
        publish_client = get_publish_client(config, use_dapla_token_client=True)
    except Exception:
        print("Failed to fetch labid token; using environment variable...")
        publish_client = get_publish_client(config, use_dapla_token_client=False)

    _sync_updated_file(file_path, publish_client)

    print("Watching for file changes...")
    for changes in watch(file_path):
        _sync_updated_file(file_path, publish_client)

def _sync_updated_file(file_path: str, publish_client: PublishClient) -> None:
    print("Syncing updated document...")
    try:
        preview_url = _sync_quarto_file(file_path, publish_client)
        print(f"Content synced successfully. Preview URL: {preview_url}")
    except Exception as e:
        print(f"Error during sync: {e}")

def _sync_quarto_file(file_path: str, publish_client: PublishClient) -> str:
    pandoc_document = _quarto_to_pandoc(file_path)
    adapters = (
        PandocDocumentProcessor(),
        MimirContentParser(),
        LocalFileStorage(project_folder=Path(file_path).parent),
        publish_client,
    )
    return sync_document(pandoc_document, *adapters)


def _quarto_to_pandoc(file_path: str) -> str:
    result = subprocess.run(
        [
            "quarto",
            "render",
            file_path,
            "--to",
            "json",
            "-M",
            "include:false",
            "--output",
            "-",
        ],
        text=True,
        capture_output=True,
        check=True,
    )
    return result.stdout
