"""App configuration through environment variables."""

import os
from dataclasses import dataclass
from pathlib import Path

APP_NAME = "SSB_PUBMD"


@dataclass
class Config:
    publish_base_url: str
    publish_endpoint: str
    publish_preview_base_path: str


def get_config(metadata_file_path: Path | None = None) -> Config:
    """Get config from enviromnent variables."""
    return Config(
        publish_base_url=os.environ[f"{APP_NAME}_BASE_URL"],
        publish_endpoint=os.environ[f"{APP_NAME}_ENDPOINT"],
        publish_preview_base_path=os.environ[f"{APP_NAME}_PREVIEW_BASE_PATH"],
    )
