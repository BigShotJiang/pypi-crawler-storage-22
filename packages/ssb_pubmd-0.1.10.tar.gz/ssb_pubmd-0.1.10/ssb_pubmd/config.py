import os
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Config:
    publish_base_url: str
    publish_admin_path: str
    use_dapla_token_client: bool


_TEST_CONFIG = Config(
    publish_base_url="https://i.test.ssb.no",
    publish_admin_path="/xp/admin",
    use_dapla_token_client=True,
)

_LOCAL_CONFIG = Config(
    publish_base_url="http://localhost:8080",
    publish_admin_path="/admin",
    use_dapla_token_client=False,
)


def get_config(metadata_file_path: Path | None = None) -> Config:
    if os.environ.get("SSB_PUBMD_ENVIRONMENT") == "local":
        config = _LOCAL_CONFIG
    else:
        config = _TEST_CONFIG

    if os.environ.get("SSB_PUBMD_TOKEN_CLIENT") == "local":
        config.use_dapla_token_client = False

    return config
