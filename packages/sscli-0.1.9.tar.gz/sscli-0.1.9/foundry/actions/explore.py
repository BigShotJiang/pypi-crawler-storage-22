from foundry.constants import console, TIER_HIERARCHY
from foundry.utils import get_templates, get_template_info
from foundry.auth import get_current_license_info
from rich.panel import Panel
from rich.tree import Tree


def run_explore():
    # Get user info for tier checking
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)

    # Group templates by category
    buckets = {
        "Backend Services": [],
        "Frontend & UI": [],
        "Mobile App": [],
        "Data Engineering": [],
        "Infrastructure": [],
        "Other": [],
    }

    templates = get_templates()

    for tmpl in templates:
        name = tmpl.name
        # Fetch metadata to get the tier
        info = get_template_info(name)
        tmpl_tier = info.get("tier", "free").lower()
        tmpl_rank = TIER_HIERARCHY.get(tmpl_tier, 0)

        # Append tier info to the object for the tree rendering
        tmpl_display_name = name
        if tmpl_rank > user_rank:
            tmpl_display_name = f"[dim]{name} [red](🔐 {tmpl_tier.upper()})[/dim]"
        elif tmpl_tier != "free":
             tmpl_display_name = f"{name} [green](✅ {tmpl_tier.upper()})[/green]"
        
        # Store both for processing
        tmpl_data = {"name": name, "display": tmpl_display_name, "path": tmpl}

        if name in ["python-saas", "rails-api"]:
            buckets["Backend Services"].append(tmpl_data)
        elif name in ["react-client", "rails-ui-kit"]:
            buckets["Frontend & UI"].append(tmpl_data)
        elif name.startswith("mobile-"):
            buckets["Mobile App"].append(tmpl_data)
        elif name == "data-pipeline":
            buckets["Data Engineering"].append(tmpl_data)
        elif name == "terraform-infra":
            buckets["Infrastructure"].append(tmpl_data)
        else:
            buckets["Other"].append(tmpl_data)

    tree = Tree("[bold green]Stack Foundry Inventory[/bold green]")

    for category, items in buckets.items():
        if not items:
            continue

        cat_node = tree.add(f"[bold yellow]{category}[/bold yellow]")
        for item in items:
            node = cat_node.add(f"[bold cyan]{item['display']}[/bold cyan]")
            tmpl = item['path']

            # Add technology details
            if (tmpl / "pyproject.toml").exists():
                node.add("[dim]Python (FastAPI/NiceGUI)[/dim]")
            elif (tmpl / "Gemfile").exists():
                node.add("[dim]Ruby on Rails[/dim]")
            elif (tmpl / "package.json").exists():
                node.add("[dim]React/Vite[/dim]")
            elif (tmpl / "build.gradle.kts").exists():
                node.add("[dim]Android (Kotlin/Compose)[/dim]")
            elif (tmpl / "StackApp").exists():
                node.add("[dim]iOS (Swift/SwiftUI)[/dim]")
            elif (tmpl / "main.tf").exists():
                node.add("[dim]Terraform[/dim]")

    console.print(Panel(tree, title="Available Templates", border_style="green"))
