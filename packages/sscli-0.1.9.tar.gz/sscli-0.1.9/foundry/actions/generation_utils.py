from pathlib import Path
from rich.panel import Panel
from foundry.constants import console, TIER_HIERARCHY, PRICING_URL
from foundry.telemetry import log_event
from foundry.auth import get_current_license_info


def check_tier_access(template_name: str, required_tier: str) -> bool:
    """Check if the user has the required tier for a template."""
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")

    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        console.print(
            Panel(
                f"[bold red]Access Denied[/bold red]\n\n"
                f"The template [cyan]{template_name}[/cyan] requires a [bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"Upgrade your license at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="License Requirement",
                border_style="red",
            )
        )
        log_event(
            "GENERATE_FORBIDDEN", f"Template: {template_name}, User Tier: {user_tier}"
        )
        return False
    return True


def inject_metadata(path: Path, template: str, app_name: str):

    console.print(f"   - Injecting name '{app_name}' into configuration...")

    # Generic replacement in key files
    files_to_touch = [
        path / "package.json",
        path / "pyproject.toml",
        path / "Gemfile",
        path / "README.md",
        path / ".env.example",
    ]

    for f in files_to_touch:
        if f.exists():
            content = f.read_text(encoding="utf-8")
            # Simple replacement of template name identifiers
            new_content = content.replace(f"{template}", app_name)
            new_content = new_content.replace("StackApp", app_name.capitalize())
            f.write_text(new_content, encoding="utf-8")


def disable_linters(path: Path, template: str):
    # Python SaaS
    if (path / "pyproject.toml").exists():
        pyproject = path / "pyproject.toml"
        content = pyproject.read_text(encoding="utf-8")
        filtered_lines = [
            line
            for line in content.splitlines()
            if not line.startswith("ruff =") and not line.startswith("mypy =")
        ]
        # Persist changes to disable linters sections
        pyproject.write_text("\n".join(filtered_lines) + "\n", encoding="utf-8")
        console.print("   - Removed Ruff/MyPy config from pyproject.toml")

    # Rails
    if (path / "Gemfile").exists():
        gemfile = path / "Gemfile"
        content = gemfile.read_text(encoding="utf-8")
        new_content = content.replace("gem 'rubocop'", "# gem 'rubocop'").replace(
            "gem 'rubocop-rails'", "# gem 'rubocop-rails'"
        )
        gemfile.write_text(new_content, encoding="utf-8")
        console.print("   - Commented out Rubocop in Gemfile")

    # React
    if (path / "package.json").exists():
        console.print("   - (Manual step required) Remove eslint from package.json")


def setup_secrets(path: Path, strategy: str):
    """Setup the elected secrets management strategy for the new project."""

    if "Dotenv" in strategy:
        # Standard behavior: Copy .env.example to .env
        example_env = path / ".env.example"
        if example_env.exists():
            target_env = path / ".env"
            if not target_env.exists():
                import shutil

                shutil.copy(example_env, target_env)
                console.print(f"   - Created .env from .env.example")

    elif "Doppler" in strategy:
        # Doppler strategy: Add doppler.yaml and instructions
        doppler_config = path / "doppler.yaml"
        doppler_config.write_text("setup:\n  project: my-project\n  config: dev\n")
        console.print(f"   - Added doppler.yaml config")

        # Append to README with specific upload instructions
        readme = path / "README.md"
        if readme.exists():
            with open(readme, "a") as f:
                f.write(
                    "\n\n## 🔐 Secrets Management (Doppler)\n"
                    "This project is configured to use Doppler. To synchronize your secrets:\n"
                    "1. Install the Doppler CLI\n"
                    "2. Run `doppler setup` to link your project\n"
                    "3. Run `doppler secrets upload .env.example` to seed your initial secrets\n"
                    "4. Run your app with `doppler run -- command` instead of standard methods.\n"
                )

    elif "Environment Only" in strategy:
        # Environment only: Remove .env.example and add warning
        example_env = path / ".env.example"
        if example_env.exists():
            example_env.unlink()
            console.print(f"   - Removed .env.example (Environment-only mode)")

        readme = path / "README.md"
        if readme.exists():
            with open(readme, "a") as f:
                f.write(
                    "\n\n## 🔐 Secrets Management\nThis project expects secrets to be provided via environment variables (no .env files).\n"
                )
