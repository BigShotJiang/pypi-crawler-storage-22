import os
import json
import time
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from foundry.constants import console, API_BASE_URL

# Configuration
# The base URL is managed in foundry/constants.py (configurable via environment variables)
LICENSE_SERVER = API_BASE_URL
CREDENTIALS_FILE = Path.home() / ".config" / "sscli" / "credentials.json"


def get_access_token() -> Optional[str]:
    """Retrieve the stored access token if it exists."""
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
            return data.get("access_token")
    except Exception:
        return None


def save_credentials(data: Dict[str, Any]) -> None:
    """Save user credentials to the home directory."""
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(data, f, indent=2)


def login_flow() -> None:
    """Execute the GitHub Device Flow via the License Server."""
    console.print("Initiating login with GitHub...")

    try:
        response = requests.post(f"{LICENSE_SERVER}/auth/device/code")
        response.raise_for_status()
    except Exception as e:
        console.print(f"Error connecting to License Server at {LICENSE_SERVER}: {e}")
        return

    data = response.json()
    device_code = data["device_code"]
    user_code = data["user_code"]
    verification_uri = data["verification_uri"]
    interval = data.get("interval", 5)

    console.print(f"\n1. Go to: {verification_uri}")
    console.print(f"2. Enter code: {user_code}\n")
    console.print("Waiting for authorization...")

    while True:
        try:
            token_resp = requests.get(
                f"{LICENSE_SERVER}/auth/device/token",
                params={"device_code": device_code},
            )

            if token_resp.status_code == 200:
                credentials = token_resp.json()
                save_credentials(credentials)
                console.print(
                    f"\nSuccessfully logged in as {credentials.get('email', 'User')}!"
                )
                console.print(
                    f"License Tier: {credentials.get('tier', 'free').upper()}"
                )
                break

            if token_resp.status_code == 428:  # Pending
                time.sleep(interval)
                continue

            # If we get here, something went wrong
            console.print(
                f"Login failed: {token_resp.json().get('detail', 'Unknown error')}"
            )
            break

        except Exception as e:
            console.print(f"Polling error: {e}")
            break


def get_current_license_info() -> Dict[str, Any]:
    """Read the current license/tier info from local storage.

    Returns a dict with at least `tier` and `authorized` keys when no
    credentials are present or when reading fails.
    """
    if not CREDENTIALS_FILE.exists():
        return {"tier": "free", "authorized": False}
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            # If stored data is malformed, return a sensible default
            return {"tier": "free", "authorized": False}
    except Exception:
        return {"tier": "free", "authorized": False}


def logout() -> None:
    """Clear local stored credentials (logout).

    Removes the `credentials.json` file if present and reports status to the console.
    """
    try:
        if CREDENTIALS_FILE.exists():
            CREDENTIALS_FILE.unlink()
            console.print("[green]Logged out:[/] removed local credentials.")
        else:
            console.print("[yellow]No credentials found to remove.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error clearing credentials:[/] {e}")
