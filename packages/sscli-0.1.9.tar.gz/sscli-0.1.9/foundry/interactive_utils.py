import questionary
from foundry.constants import console
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup


def manage_config_menu():
    while True:
        action = questionary.select(
            "Configuration Management:",
            choices=[
                "View Validation Status",
                "Run Template Setup (Full Suite)",
                "Back",
            ],
        ).ask()

        if action == "Back":
            break

        if action == "View Validation Status":
            run_health_check()
            pause()

        if action == "Run Template Setup (Full Suite)":
            run_setup()
            pause()


def pause():
    input("\nPress Enter to return...")


def internal_ops_menu():
    """Menu for internal development and ops tasks."""
    try:
        from foundry.ops.manager import InternalManager
    except ImportError:
        console.print("[red]Ops manager not available in this build.[/]")
        return

    # Show auth status for internal devs too
    from foundry.auth import get_current_license_info
    auth_info = get_current_license_info()
    if auth_info.get("tier") != "free":
        console.print(f"[green]✓ Authenticated as {auth_info.get('tier', 'user').upper()}[/green]")
    else:
        console.print("[yellow]⚠️  Not authenticated - limited access[/yellow]")

    manager = InternalManager()

    while True:
        choice = questionary.select(
            "Foundry Ops - Internal Development:",
            choices=[
                "Verify All Builds (Docker)",
                "Run Hygiene Checks (Repo Health)",
                "Full Verification Suite",
                "Clean Verification Reports",
                "Back to Main",
            ],
            style=questionary.Style([("highlighted", "fg:#ff00ff bold")]),
        ).ask()

        if not choice or choice == "Back to Main":
            break

        if choice == "Verify All Builds (Docker)":
            manager.verify_builds()
            pause()
        elif choice == "Run Hygiene Checks (Repo Health)":
            manager.run_verification_script(
                "verify_hygiene", "Code Hygiene (File Lengths)"
            )
            pause()
        elif choice == "Full Verification Suite":
            manager.verify_full_suite()
            pause()
        elif choice == "Clean Verification Reports":
            manager.clean_reports()
            pause()
