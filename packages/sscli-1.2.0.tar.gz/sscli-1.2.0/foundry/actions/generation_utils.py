from pathlib import Path
from rich.panel import Panel
from foundry.constants import console, TIER_HIERARCHY, PRICING_URL
from foundry.telemetry import log_event
from foundry.auth import get_current_license_info


def check_tier_access(template_name: str, required_tier: str) -> bool:
    """Check if the user has the required tier for a template."""
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")

    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        console.print(
            Panel(
                f"[bold red]Access Denied[/bold red]\n\n"
                f"The template [cyan]{template_name}[/cyan] requires a [bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"Upgrade your license at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="License Requirement",
                border_style="red",
            )
        )
        log_event(
            "GENERATE_FORBIDDEN", f"Template: {template_name}, User Tier: {user_tier}"
        )
        return False
    return True


def inject_metadata(path: Path, template: str, app_name: str):

    console.print(f"   - Injecting name '{app_name}' into configuration...")

    # Generic replacement in key files
    files_to_touch = [
        path / "package.json",
        path / "pyproject.toml",
        path / "Gemfile",
        path / "README.md",
        path / ".env.example",
    ]

    for f in files_to_touch:
        if f.exists():
            content = f.read_text(encoding="utf-8")
            # Simple replacement of template name identifiers
            new_content = content.replace(f"{template}", app_name)
            new_content = new_content.replace("StackApp", app_name.capitalize())
            f.write_text(new_content, encoding="utf-8")


def validate_and_fix_pyproject(path: Path):
    """
    Validate and fix pyproject.toml to ensure Poetry can parse it.
    
    - Ensures all version strings in [tool.poetry.dependencies] sections are properly quoted
    - Removes any malformed dependencies
    - Validates TOML structure
    """
    pyproject = path / "pyproject.toml"
    if not pyproject.exists():
        return
    
    try:
        content = pyproject.read_text(encoding="utf-8")
        fixed_lines = []
        in_dependencies_section = False
        
        for line in content.splitlines():
            # Detect if we're in a dependencies section
            if line.strip().startswith("[tool.poetry"):
                in_dependencies_section = "dependencies" in line
            elif line.strip().startswith("["):
                # Entering a different section
                in_dependencies_section = False
            
            # Only apply version quoting in dependency sections
            if in_dependencies_section and " = " in line and not line.strip().startswith("#"):
                key, value = line.split(" = ", 1)
                key = key.strip()
                value = value.strip()
                
                # If value is an unquoted number/version spec (like 8.0.0), quote it
                # Skip if it already has quotes or is a complex spec starting with { or [
                if (value and not value.startswith('"') and not value.startswith("'") 
                    and not value.startswith("{") and not value.startswith("[")):
                    # Check if it looks like an unquoted version number
                    # Should start with a digit or version specifier like ^ ~ < > = !
                    if value[0].isdigit() or value[0] in "^~<>=!":
                        # It's likely an unquoted version - quote it
                        value = f'"{value}"'
                        line = f"{key} = {value}"
            
            fixed_lines.append(line)
        
        fixed_content = "\n".join(fixed_lines) + "\n"
        
        # Validate the TOML syntax by attempting to parse it
        try:
            import sys
            if sys.version_info >= (3, 11):
                import tomllib
                tomllib.loads(fixed_content)
            else:
                # For Python < 3.11, do basic validation
                # Check for common issues like unclosed brackets
                if fixed_content.count("[") == fixed_content.count("]"):
                    pass  # Basic balance check passed
                else:
                    raise ValueError("Mismatched brackets in TOML")
        except Exception as parse_error:
            console.print(f"   [yellow]⚠️  TOML validation failed: {parse_error}[/yellow]")
            return
        
        # Write the fixed content back
        pyproject.write_text(fixed_content, encoding="utf-8")
        console.print("   - Validated and fixed pyproject.toml (ensured quoted versions)")
    
    except Exception as e:
        console.print(f"   [yellow]⚠️  Could not validate pyproject.toml: {e}[/yellow]")


def disable_linters(path: Path, template: str):
    # Python SaaS
    if (path / "pyproject.toml").exists():
        pyproject = path / "pyproject.toml"
        content = pyproject.read_text(encoding="utf-8")
        
        # Remove ruff/mypy dependencies AND their tool sections
        filtered_lines = []
        skip_tool_section = False
        
        for line in content.splitlines():
            # Check if we're entering a tool section we want to skip
            if line.strip().startswith("[tool.ruff"):
                skip_tool_section = True
                continue
            elif line.strip().startswith("[tool.mypy"):
                skip_tool_section = True
                continue
            # Check if we're entering a different section (stop skipping)
            elif line.strip().startswith("[") and skip_tool_section:
                skip_tool_section = False
            
            # Skip lines for ruff/mypy dependencies and tool sections
            if skip_tool_section:
                continue
            if line.startswith("ruff =") or line.startswith("mypy ="):
                continue
            
            filtered_lines.append(line)
        
        # Persist changes to disable linters sections
        pyproject.write_text("\n".join(filtered_lines) + "\n", encoding="utf-8")
        console.print("   - Removed Ruff/MyPy dependencies and tool configuration from pyproject.toml")

    # Rails
    if (path / "Gemfile").exists():
        gemfile = path / "Gemfile"
        content = gemfile.read_text(encoding="utf-8")
        new_content = content.replace("gem 'rubocop'", "# gem 'rubocop'").replace(
            "gem 'rubocop-rails'", "# gem 'rubocop-rails'"
        )
        gemfile.write_text(new_content, encoding="utf-8")
        console.print("   - Commented out Rubocop in Gemfile")

    # React
    if (path / "package.json").exists():
        console.print("   - (Manual step required) Remove eslint from package.json")


def setup_secrets(path: Path, strategy: str):
    """Setup the elected secrets management strategy for the new project."""

    if "Dotenv" in strategy:
        # Standard behavior: Copy .env.example to .env
        example_env = path / ".env.example"
        if example_env.exists():
            target_env = path / ".env"
            if not target_env.exists():
                import shutil

                shutil.copy(example_env, target_env)
                console.print(f"   - Created .env from .env.example")

    elif "Doppler" in strategy:
        # Doppler strategy: Add doppler.yaml and instructions
        doppler_config = path / "doppler.yaml"
        doppler_config.write_text("setup:\n  project: my-project\n  config: dev\n")
        console.print(f"   - Added doppler.yaml config")


def inject_features(path: Path, template: str, commerce: bool, tunnel: bool):
    """Inject or clean up optional features based on user selection."""
    
    # 1. Commerce Injection
    if commerce:
        console.print("   - [bold blue]Injecting Commerce Modules (Shopify/Stripe)...[/bold blue]")
        _perform_feature_injection(path, "commerce")
        _inject_commerce_env_vars(path)
    else:
        # Cleanup if files exist in standard locations (backwards compatibility)
        _remove_commerce_files(path, template)

    # 2. Tunnel Configuration
    if tunnel:
        console.print("   - [bold cyan]Configuring Local Tunnel (ngrok)...[/bold cyan]")
        _perform_feature_injection(path, "tunnel")
        _inject_tunnel_config(path, template)


def _perform_feature_injection(project_path: Path, feature_name: str):
    """
    Look for a 'features/{feature_name}' directory in the template.
    If it exists, recursively copy its contents into the project root.
    """
    import shutil
    feature_dir = project_path / "features" / feature_name
    if feature_dir.exists():
        console.print(f"   - Moving {feature_name} files from features/ into source...")
        for item in feature_dir.glob("**/*"):
            if item.is_file():
                # Determine relative path from features/{feature_name}
                rel_path = item.relative_to(feature_dir)
                target_file = project_path / rel_path
                
                # Ensure parent directory exists
                target_file.parent.mkdir(parents=True, exist_ok=True)
                
                # Copy or move
                shutil.copy2(item, target_file)
        
        # Optionally remove the features directory after injection
        # shutil.rmtree(project_path / "features") 
        # (Better to leave it for now or remove it at the end of generator)


def _inject_commerce_env_vars(path: Path):
    """Add Shopify placeholders to .env and .env.example."""
    env_files = [path / ".env", path / ".env.example"]
    commerce_vars = [
        "\n# --- Commerce (Shopify) ---",
        "SHOPIFY_SHOP_NAME=your-shop-name",
        "SHOPIFY_API_KEY=your-api-key",
        "SHOPIFY_API_SECRET=your-api-secret",
        "SHOPIFY_ACCESS_TOKEN=your-access-token\n",
    ]
    
    for env_file in env_files:
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8")
            if "SHOPIFY_SHOP_NAME" not in content:
                with env_file.open("a", encoding="utf-8") as f:
                    f.write("\n".join(commerce_vars))


def _remove_commerce_files(path: Path, template: str):
    """Remove commerce-related files if feature is not requested."""
    import shutil
    
    python_saas_paths = [
        path / "src" / "infrastructure" / "commerce",
        path / "src" / "core" / "interfaces" / "commerce.py",
        path / "src" / "ui" / "api" / "webhooks.py",
    ]
    
    rails_paths = [
        path / "app" / "services" / "commerce",
        path / "app" / "controllers" / "webhooks" / "shopify_controller.rb",
    ]

    targets = []
    if template == "python-saas":
        targets = python_saas_paths
    elif "rails" in template:
        targets = rails_paths

    for t in targets:
        if t.exists():
            if t.is_dir():
                shutil.rmtree(t)
            else:
                t.unlink()


def _inject_tunnel_config(path: Path, template: str):
    """Add ngrok/tunnel configuration to the project."""
    # 1. Add NGROK_AUTHTOKEN to .env
    env_files = [path / ".env", path / ".env.example"]
    for env_file in env_files:
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8")
            if "NGROK_AUTHTOKEN" not in content:
                with env_file.open("a", encoding="utf-8") as f:
                    f.write("\n# --- Tunneling ---\nNGROK_AUTHTOKEN=your-ngrok-token\n")

    # 2. If docker-compose.yml exists, add a tunnel service
    compose_file = path / "docker-compose.yml"
    if compose_file.exists():
        content = compose_file.read_text(encoding="utf-8")
        if "tunnel:" not in content:
            # Determine target port based on template
            port = "8080" if template == "python-saas" else "3000"
            service_name = "python-saas" if template == "python-saas" else "api"
            
            tunnel_service = f"""
  tunnel:
    image: ngrok/ngrok:latest
    command:
      - "http"
      - "{service_name}:{port}"
    environment:
      - NGROK_AUTHTOKEN=${{NGROK_AUTHTOKEN}}
    depends_on:
      - {service_name}
"""
            # Append to services section - this is a crude but effective way
            if "services:" in content:
                new_content = content.replace("services:", f"services:\n{tunnel_service}")
                compose_file.write_text(new_content, encoding="utf-8")

        # Append to README with tunnel instructions
        readme = path / "README.md"
        if readme.exists():
            with open(readme, "a") as f:
                f.write(
                    "\n\n## 🌐 Local Tunneling (ngrok)\n"
                    "This project is configured to use ngrok for local tunneling. To set up:\n"
                    "1. Sign up at https://ngrok.com/ and get your authtoken\n"
                    "2. Add your NGROK_AUTHTOKEN to .env\n"
                    "3. Run `docker-compose up` to start the tunnel service\n"
                    "4. Your public tunnel URL will be displayed in the ngrok service logs\n"
                )


def regenerate_poetry_lock(path: Path):
    """
    Regenerate poetry.lock after inject_metadata() has modified pyproject.toml.
    This prevents Docker build errors like "pyproject.toml changed significantly since poetry.lock was last generated."
    """
    import subprocess
    
    # Only attempt if this is a Python project with pyproject.toml
    if not (path / "pyproject.toml").exists():
        return
    
    # Only attempt if poetry.lock exists (indicates a poetry-based project)
    if not (path / "poetry.lock").exists():
        return
    
    console.print("   - Regenerating poetry.lock...")
    
    try:
        result = subprocess.run(
            ["poetry", "lock", "--no-update"],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=60,
        )
        
        if result.returncode == 0:
            console.print("   - poetry.lock regenerated successfully")
        else:
            # Check if it's a "command not found" type error
            if "not found" in result.stderr.lower() or "no such file" in result.stderr.lower():
                console.print(
                    f"   [yellow]⚠️  Poetry not installed - skipping lock file regeneration[/yellow]\n"
                    f"   [dim]After installation, run: cd {path.name} && poetry lock --no-update[/dim]"
                )
            else:
                # Other subprocess errors
                console.print(
                    f"   [yellow]⚠️  Could not regenerate poetry.lock: {result.stderr.strip()}[/yellow]\n"
                    f"   [dim]Manual fix: cd {path.name} && poetry lock --no-update[/dim]"
                )
    
    except FileNotFoundError:
        # Poetry executable not found
        console.print(
            f"   [yellow]⚠️  Poetry not installed - skipping lock file regeneration[/yellow]\n"
            f"   [dim]After installation, run: cd {path.name} && poetry lock --no-update[/dim]"
        )
    except subprocess.TimeoutExpired:
        console.print(
            f"   [yellow]⚠️  Poetry lock generation timed out[/yellow]\n"
            f"   [dim]Manual fix: cd {path.name} && poetry lock --no-update[/dim]"
        )
    except Exception as e:
        console.print(
            f"   [yellow]⚠️  Unexpected error regenerating poetry.lock: {str(e)}[/yellow]\n"
            f"   [dim]Manual fix: cd {path.name} && poetry lock --no-update[/dim]"
        )

