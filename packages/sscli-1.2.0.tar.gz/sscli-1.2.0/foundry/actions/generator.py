import shutil
import subprocess
from pathlib import Path

import questionary
from foundry.auth import get_access_token, get_current_license_info
from foundry.constants import TIER_HIERARCHY, console, TEMPLATES_DIR
from foundry.telemetry import get_feedback_link, log_event
from foundry.utils import get_template_info, get_templates, is_internal_dev
from foundry.actions.generation_utils import (
    inject_metadata,
    disable_linters,
    validate_and_fix_pyproject,
    check_tier_access,
    setup_secrets,
    inject_features,
    regenerate_poetry_lock,
)
from rich.panel import Panel


def run_generator(
    template_name: str = None,
    app_name: str = None,
    target_dir_name: str = None,
    use_linters: bool = True,
    with_commerce: bool = False,
    with_tunnel: bool = False,
    interactive: bool = False,
    secrets_strategy: str = "Dotenv (Standard .env files)",
):

    if interactive:
        # Filter templates based on user tier for a cleaner experience
        user_info = get_current_license_info()
        user_tier = user_info.get("tier", "free")
        user_rank = TIER_HIERARCHY.get(user_tier, 0)
        
        available_templates = []
        for tmpl in get_templates():
            info = get_template_info(tmpl.name)
            tmpl_tier = info.get("tier", "free").lower()
            if user_rank >= TIER_HIERARCHY.get(tmpl_tier, 0):
                available_templates.append(tmpl.name)

        if not available_templates:
            console.print("[yellow]No templates available for your current tier.[/yellow]")
            return

        # Add Back button for better navigation
        choices = ["Back"] + available_templates

        template_name = questionary.select(
            "Select a template to deploy:", choices=choices
        ).ask()

        if template_name == "Back" or not template_name:
            return

        console.print(Panel(f"[bold]Configuring {template_name}[/bold]", style="blue"))

    # Tier Enforcement Check
    template_info = get_template_info(template_name)
    if not check_tier_access(template_name, template_info.get("tier", "free")):
        return

    if interactive:
        app_name = questionary.text(
            "Enter your Application Name:", default=f"my-{template_name}"
        ).ask()
        
        # PRO Feature Injection
        user_info = get_current_license_info()
        user_tier = user_info.get("tier", "free")
        user_rank = TIER_HIERARCHY.get(user_tier, 0)
        
        if user_rank >= TIER_HIERARCHY.get("pro"):
            with_commerce = questionary.confirm(
                "Would you like to include Commerce modules (Shopify/Stripe)?", 
                default=False
            ).ask()
            with_tunnel = questionary.confirm(
                "Enable local tunneling (ngrok)?", 
                default=False
            ).ask()
        else:
            with_commerce = False
            with_tunnel = False

        use_linters = questionary.confirm(
            "Enable default linters (Ruff/Rubocop/ESLint)?", default=True
        ).ask()
        secrets_strategy = questionary.select(
            "Select Secrets Management Strategy:",
            choices=[
                "Dotenv (Standard .env files)",
                "Doppler (Managed cloud secrets)",
                "Environment Only (PaaS/CI friendly)",
            ],
            default="Dotenv (Standard .env files)",
        ).ask()
    else:
        secrets_strategy = "Dotenv (Standard .env files)"

    # Validation
    if not template_name:
        console.print("[red]Error: Template name required.[/red]")
        log_event("GENERATE_FAIL", "Template name required")
        return

    # Determine destination path
    if interactive:
        # In interactive mode, ask for destination path
        actual_execution_path = str(Path.cwd())
        target_path_input = questionary.text(
            "Where would you like to install the repository?", default=actual_execution_path
        ).ask()

        if not target_path_input:
            console.print("[red]Error: Installation path required.[/red]")
            return

        target_path = Path(target_path_input)
    else:
        # In non-interactive mode, use target_dir_name if provided, else use current directory
        if target_dir_name:
            target_path = Path(target_dir_name)
        else:
            target_path = Path.cwd()

    log_event(
        "GENERATE_START",
        f"Template: {template_name}, App: {app_name}, Target: {target_path.name}, Commerce: {with_commerce}, Tunnel: {with_tunnel}",
    )
    console.print(
        f"\n[bold green]Deploying {template_name} to {target_path.name}...[/bold green]"
    )

    try:
        if target_path.exists() and any(target_path.iterdir()):
            console.print(
                f"[red]Error: {target_path.name} already exists and is not empty![/red]"
            )
            log_event(
                "GENERATE_FAIL", f"Target directory {target_path.name} already exists"
            )
            return

        # Secure Git Clone Logic
        repo_url = template_info.get("repo")
        if not repo_url:
            console.print(
                f"[red]Error: No repository found for template '{template_name}'[/red]"
            )
            return

        # Local template fallback for internal development
        local_template_path = TEMPLATES_DIR / template_name
        if is_internal_dev() and local_template_path.exists():
            console.print("   - Using local template from development environment...")
            try:
                shutil.copytree(
                    local_template_path,
                    target_path,
                    dirs_exist_ok=False,
                )
            except FileExistsError:
                console.print(
                    f"[red]Error: {target_path.name} already exists![/red]"
                )
                return
        else:
            # Remote template: Clone from GitHub with authentication
            token = get_access_token()
            if token:
                # Inject token into URL for authenticated clone
                auth_url = repo_url.replace("https://", f"https://{token}@")
            else:
                auth_url = (
                    repo_url  # Fallback to public if token missing (for public repos)
                )

            console.print("   - Downloading template from Seed & Source...")
            result = subprocess.run(
                ["git", "clone", "--depth", "1", auth_url, str(target_path)],
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:
                console.print("[bold red]Download Error:[/bold red]")
                if "403" in result.stderr or "401" in result.stderr:
                    console.print(
                        Panel(
                            "[bold yellow]Organization Access Required[/bold yellow]\n\n"
                            "It looks like your GitHub token doesn't have access to the private repository.\n"
                            "1. Go to your [bold]GitHub Settings -> Applications -> Authorized OAuth Apps[/bold].\n"
                            "2. Find 'Seed & Source License'.\n"
                            "3. Ensure access is [bold]GRANTED[/bold] for the 'seed-source' organization.",
                            title="Access Denied",
                            border_style="red",
                        )
                    )
                else:
                    console.print(f"Error Message: {result.stderr}")
                return

            # Remove template git history
            if (target_path / ".git").exists():
                shutil.rmtree(target_path / ".git")

        # Inject metadata
        inject_metadata(target_path, template_name, app_name or target_path.name)
        
        # Validate pyproject.toml to ensure proper TOML syntax
        validate_and_fix_pyproject(target_path)

        if not use_linters:
            console.print("[yellow]Disabling linters...[/yellow]")
            disable_linters(target_path, template_name)

        # Setup Secrets Management
        console.print(f"[yellow]Configuring secrets ({secrets_strategy})...[/yellow]")
        setup_secrets(target_path, secrets_strategy)

        # Optional Feature Injection
        inject_features(target_path, template_name, with_commerce, with_tunnel)

        # Regenerate poetry.lock if pyproject.toml was modified
        regenerate_poetry_lock(target_path)

        # Cleanup: Remove features folder if it exists in the generated project
        features_dir = target_path / "features"
        if features_dir.exists():
            shutil.rmtree(features_dir)

        console.print(
            f"[bold green]Success! Project created at {target_path}[/bold green]"
        )
        console.print(
            f"\n[bold blue]Feedback Wanted![/bold blue] Please help us improve: [link={get_feedback_link()}]{get_feedback_link()}[/link]"
        )
        log_event(
            "GENERATE_SUCCESS", f"Template: {template_name}, Target: {target_path}"
        )

    except Exception as e:
        console.print(f"[bold red]Deployment failed:[/bold red] {e}")
        log_event("GENERATE_ERROR", str(e))
