from foundry.constants import console
from foundry.actions.documentation import run_view_docs
from foundry.actions.explore import run_explore
from foundry.actions.generator import run_generator
from foundry.actions.validation import run_smoke_tests
from foundry.auth import get_current_license_info, login_flow
from foundry.interactive_utils import manage_config_menu, pause, internal_ops_menu
from foundry.utils import is_internal_dev

import questionary

from typing import cast, List
from foundry.animations.base import Animation

# Animation Imports - moved inside function to avoid unbound variables
# try:
#     from foundry.animations import (AnimationSequence,
#                                     InteractiveAnimationEngine)
#     from foundry.animations.scenes import (LogoDisperseAnimation,
#                                            LogoRevealAnimation,
#                                            LogoStaticAnimation,
#                                            TranquilityAnimation)

#     HAS_ANIMATIONS = True
# except Exception:
#     HAS_ANIMATIONS = False


def run_animated_experience():
    """Plays the full robust animation sequence and handles user choice loop."""
    # Import animations here to avoid unbound variables
    try:
        from foundry.animations import (AnimationSequence,
                                        InteractiveAnimationEngine)
        from foundry.animations.scenes import (LogoDisperseAnimation,
                                               LogoRevealAnimation,
                                               LogoStaticAnimation,
                                               TranquilityAnimation,
                                               ForgeAnimation)
    except Exception:
        console.print("[bold red]Animation system not fully loaded.[/]")
        return

    # Check authentication status
    auth_info = get_current_license_info()
    if auth_info.get("tier") == "free":
        console.print("\n[bold yellow]🔐 Authentication Required[/bold yellow]")
        console.print("You need to authenticate to access PRO and ALPHA features.\n")

        auth_choice = questionary.select(
            "Would you like to authenticate now?",
            choices=[
                "Login with GitHub (Recommended)",
                "Continue as Free User",
                "Exit",
            ],
        ).ask()

        if auth_choice == "Exit" or auth_choice is None:
            console.print("[yellow]Goodbye![/yellow]")
            return
        elif auth_choice == "Login with GitHub (Recommended)":
            try:
                login_flow()
                # Refresh auth info after login
                auth_info = get_current_license_info()
                console.print("\n[green]✓ Authentication successful![/green]\n")
            except Exception as e:
                console.print(f"\n[red]✗ Authentication failed:[/red] {e}\n")
                console.print("Continuing as free user...\n")

    # Internal Mode selection for Developers
    # HARDENING: Force server-side verification if non-free
    if auth_info.get("tier") != "free":
        auth_info = get_current_license_info(verify=True)

    is_admin = auth_info.get("tier") == "admin"
    if (is_internal_dev() and auth_info.get("tier") != "free") or is_admin:
        mode = questionary.select(
            "Select Your Experience:",
            choices=[
                "Seed & Source (Client Side)",
                "Foundry Ops (Internal Side)",
                "Exit",
            ],
            style=questionary.Style([("highlighted", "fg:#00ffff bold")]),
        ).ask()

        if mode == "Exit" or mode is None:
            console.print("[yellow]Goodbye![/yellow]")
            return

        if mode == "Foundry Ops (Internal Side)":
            run_internal_animated_experience()
            return

    engine = InteractiveAnimationEngine(fps=60, console=console)

    # 1. Play Intro Sequence once
    try:
        intro = AnimationSequence(
            cast(List[Animation], [
                LogoRevealAnimation(duration=1.2),
                LogoStaticAnimation(duration=1.0),
                LogoDisperseAnimation(duration=2.0),
            ])
        )
        engine.play(intro)
    except KeyboardInterrupt:
        console.print("[yellow]Goodbye![/yellow]")
        return
    except Exception as e:
        console.print(f"[red]Error during intro: {e}[/]")

    # 2. Main Menu Loop
    while True:
        try:
            # Play Tranquility with menu until a choice is made
            choice = engine.play(TranquilityAnimation())

            if not choice or choice == "Exit":
                console.print("[yellow]Goodbye![/yellow]")
                break

            # Dispatch the choice
            if choice == "Explore Templates":
                run_explore()
                pause()
            elif choice == "Generate Project":
                run_generator(interactive=True)
                pause()
            elif choice == "Manage Config":
                manage_config_menu()
            elif choice == "System Validation":
                run_smoke_tests()
                pause()
            elif choice == "View Docs":
                run_view_docs(interactive=True)
                pause()

        except KeyboardInterrupt:
            console.print("[yellow]Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error during menu: {e}[/]")
            break


def run_internal_animated_experience():
    """Plays the internal development animation sequence with industrial theme."""
    # Import animations here to avoid unbound variables
    try:
        from foundry.animations import (AnimationSequence,
                                        InteractiveAnimationEngine)
        from foundry.animations.scenes import (LogoDisperseAnimation,
                                               LogoRevealAnimation,
                                               LogoStaticAnimation,
                                               ForgeAnimation)
    except Exception:
        console.print("[bold red]Animation system not fully loaded.[/]")
        return

    engine = InteractiveAnimationEngine(fps=60, console=console)

    # 1. Play Intro Sequence once (industrial theme)
    try:
        intro = AnimationSequence(
            [
                LogoRevealAnimation(duration=1.2),
                LogoStaticAnimation(duration=1.0),
                LogoDisperseAnimation(duration=2.0),
            ]
        )
        engine.play(intro)
    except KeyboardInterrupt:
        console.print("[yellow]Goodbye![/yellow]")
        return
    except Exception as e:
        console.print(f"[red]Error during intro: {e}[/]")

    # 2. Main Menu Loop with Forge theme
    while True:
        try:
            # Play Forge animation with industrial menu
            choice = engine.play(ForgeAnimation())

            if not choice or choice == "Back to Main":
                console.print("[yellow]Goodbye![/yellow]")
                break

            # Dispatch the choice for internal ops
            try:
                from foundry.ops.manager import InternalManager
                from foundry.ops.runner import run_verification_script
                manager = InternalManager()

                if choice == "Verify Builds":
                    manager.verify_builds()
                    pause()
                elif choice == "Hygiene Check":
                    run_verification_script(manager.root_dir, "verify_hygiene", "Code Hygiene (File Lengths)")
                    pause()
                elif choice == "Full Suite":
                    manager.verify_full_suite()
                    pause()
                elif choice == "Clean Reports":
                    manager.clean_reports()
                    pause()
                elif choice == "View Docs":
                    run_view_docs(interactive=True)
                    pause()
                elif choice == "Back to Main":
                    break

            except ImportError:
                console.print("[red]Ops manager not available in this build.[/]")
                break

        except KeyboardInterrupt:
            console.print("[yellow]Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error during menu: {e}[/]")
            break
