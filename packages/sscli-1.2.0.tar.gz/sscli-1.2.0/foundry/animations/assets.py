"""
Foundry Visual Assets: ASCII art, logos, and static text blocks.
"""

RAW_LOGO = [
    "███████╗███████╗███████╗██████╗            █████╗. ",
    "██╔════╝██╔════╝██╔════╝██╔══██╗          ██╔══██╗ ",
    "███████╗█████╗  █████╗  ██║  ██║          ╚███████╗",
    "╚════██║██╔══╝  ██╔══╝  ██║  ██║          ██╔══██║ ",
    "███████║███████╗███████╗██████╔╝          ╚██████╔╝",
    "╚══════╝╚══════╝╚══════╝╚═════╝            ╚═════╝ ",
    "",
    "███████╗ ██████╗ ██╗   ██╗██████╗  ██████╗███████╗ ",
    "██╔════╝██╔═══██╗██║   ██║██╔══██╗██╔════╝██╔════╝ ",
    "███████╗██║   ██║██║   ██║██████╔╝██║     █████╗   ",
    "╚════██║██║   ██║██║   ██║██╔══██╗██║     ██╔══╝   ",
    "███████║╚██████╔╝╚██████╔╝██║  ██║╚██████╗███████╗ ",
    "╚══════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝ ",
]

SMALL_LOGO = [
    " ╔═╗╔═╗╔═╗╔╦╗  ⬢ SOURCE",
    " ╚═╗║╣ ║╣  ║║  ⬢ FOUNDRY",
    " ╚═╝╚═╝╚═╝═╩╝  YEAR:2026",
]

SUN_CIRCLE = [
    "      .      ",
    "   \\  |  /   ",
    " '- {###} -' ",
    " -- {###} -- ",
    " .- {###} -. ",
    "   /  |  \\   ",
]

FINAL_TREE = [
    "                        +                       ",
    "                        #                       ",
    "                       ###                      ",
    "                      #####                     ",
    "                    #########                   ",
    "                   ###########                  ",
    "                  #############                 ",
    "                 ###############                ",
    "                #################               ",
    "                 ###############                ",
    "                  #############                 ",
    "                    #########                   ",
    "                       ###                      ",
    "                       000                      ",
    "                      O000O                     ",
]

# Grass characters for wind-synced animation: u (low/still), v (medium), w (high/windy)
GRASS_CHARS = ["u", "v", "w"]

SPROUT = ["  .  ", " ( ) ", "  |  "]

CHARACTERISTICS = [
    "[bold blue]⬢  Seed & Source - Management & Deployment System[/bold blue]",
    "",
    "├─ [yellow]📦[/yellow]  9 Production-Ready Templates",
    "├─ [cyan]🏗️[/cyan]  Hexagonal Architecture Patterns",
    "├─ [blue]🐳[/blue]  Docker-First Deployment",
    "├─ [magenta]🔧[/magenta]  Automated Configuration & Setup",
    "└─ [green]✅[/green]  Built-in Validation & Smoke Tests",
    "",
    "STATUS: [bold green]● OPERATIONAL[/bold green]",
    "PATTERN: [cyan]PORTS & ADAPTERS[/cyan]  │  YEAR: 2026",
]
