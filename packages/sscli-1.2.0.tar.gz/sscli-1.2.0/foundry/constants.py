from pathlib import Path
import os

from rich.console import Console

# Base directory navigation
# In a pipx/PyPI install, code is isolated. We need to find the actual monorepo.
def _get_foundry_root() -> Path:
    # 1. Allow explicit override
    if os.getenv("FOUNDRY_ROOT"):
        return Path(os.getenv("FOUNDRY_ROOT"))
    
    # 2. Check if we are running from within the monorepo (CWD)
    cwd = Path.cwd()
    if (cwd / "scripts").exists() and (cwd / "python-saas").exists():
        return cwd
    
    # 3. Check if we are one level deep (e.g. in stack-cli/ or python-saas/)
    if (cwd.parent / "scripts").exists() and (cwd.parent / "python-saas").exists():
        return cwd.parent
        
    # 4. Fallback to where the code is installed (Legacy behavior)
    return Path(__file__).resolve().parent.parent.parent

TEMPLATES_DIR = _get_foundry_root()

# Production License Server (Hardcoded for security)
SEED_SOURCE_PRODUCTION_API = "https://license-server-53oj.onrender.com/api/v1"

# Development Override
# Only enabled if FOUNDRY_INTERNAL_DEV is explicitly set AND we are in a dev mono-repo
def _get_api_url() -> str:
    # Check for developer override via environment variable
    env_url = os.getenv("LICENSE_SERVER_URL")
    if env_url:
        # In a production build, we might want to warn or restrict here
        # but for ALPHA we allow env var overrides.
        return env_url
    
    # If running locally in the mono-repo, default to production unless specified
    return SEED_SOURCE_PRODUCTION_API

API_BASE_URL = _get_api_url()
FORMS_BASE_URL = os.getenv("FORMS_BASE_URL", "https://forms.seedandsource.dev")
PRICING_URL = os.getenv("PRICING_URL", f"https://{SEED_SOURCE_DOMAIN}/pricing")
SALES_EMAIL = f"sales@{SEED_SOURCE_DOMAIN}"
ALPHA_SUPPORT_EMAIL = f"alpha-support@{SEED_SOURCE_DOMAIN}"
ALPHA_FEEDBACK_FORM = f"{FORMS_BASE_URL}/alpha"

# Metadata-based template registry for PyPI distribution
# This allows the CLI to know about templates without them being on disk
TEMPLATE_REGISTRY = {
    "python-saas": {
        "name": "Python SaaS Boilerplate",
        "description": "Hexagonal Architecture (FastAPI + SQLAlchemy)",
        "tier": "free",
        "repo": "https://github.com/seed-source/python-saas.git",
    },
    "rails-api": {
        "name": "Rails API Suite",
        "description": "JSON API with Devise, RSpec, and Docker",
        "tier": "free",
        "repo": "https://github.com/seed-source/rails-api.git",
    },
    "react-client": {
        "name": "React Vite Client",
        "description": "Modern frontend with Tailwind and React Query",
        "tier": "free",
        "repo": "https://github.com/seed-source/react-client.git",
    },
    "rails-ui-kit": {
        "name": "Rails UI Kit",
        "description": "Full-stack Rails with ViewComponent and Tailwind",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/rails-ui-kit-private.git",
    },
    "data-pipeline": {
        "name": "Data Pipeline (dbt)",
        "description": "Modern data stack with dbt and Python",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/data-pipeline-private.git",
    },
    "mobile-android": {
        "name": "Mobile Android",
        "description": "Kotlin-based Android application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-android-private.git",
    },
    "mobile-ios": {
        "name": "Mobile iOS",
        "description": "SwiftUI-based iOS application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-ios-private.git",
    },
    "terraform-infra": {
        "name": "Terraform Infrastructure",
        "description": "Multi-cloud IaC modules",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/terraform-infra-private.git",
    },
    "wiring": {
        "name": "Docker Wiring",
        "description": "Orchestration for multi-service stacks",
        "tier": "free",
        "repo": "https://github.com/seed-source/wiring.git",
    },
}

AVAILABLE_EXTENSIONS = {
    "commerce": {
        "name": "Commerce (Shopify/Stripe)",
        "tier": "pro",
        "description": "Injects Shopify/Commerce adapters and webhooks.",
    },
    "tunnel": {
        "name": "Local Tunneling (ngrok)",
        "tier": "pro",
        "description": "Configures the project for ngrok/local tunneling.",
    },
}

TIER_HIERARCHY = {"free": 0, "alpha": 1, "pro": 2, "enterprise": 3, "admin": 10}

console = Console()

FOUNDRY_BANNER = """
[bold cyan]
╔════════════════════════════════════════════════════════════════════════╗
║                                                                        ║
║         ███████╗████████╗ █████╗  ██████╗██╗  ██╗                    ║
║         ██╔════╝╚══██╔══╝██╔══██╗██╔════╝██║ ██╔╝                    ║
║         ███████╗   ██║   ███████║██║     █████╔╝                     ║
║         ╚════██║   ██║   ██╔══██║██║     ██╔═██╗                     ║
║         ███████║   ██║   ██║  ██║╚██████╗██║  ██╗                    ║
║         ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝                    ║
║                                                                        ║
║    ███████╗ ██████╗ ██╗   ██╗███╗   ██╗██████╗ ██████╗ ██╗   ██╗    ║
║    ██╔════╝██╔═══██╗██║   ██║████╗  ██║██╔══██╗██╔══██╗╚██╗ ██╔╝    ║
║    █████╗  ██║   ██║██║   ██║██╔██╗ ██║██║  ██║██████╔╝ ╚████╔╝     ║
║    ██╔══╝  ██║   ██║██║   ██║██║╚██╗██║██║  ██║██╔══██╗  ╚██╔╝      ║
║    ██║     ╚██████╔╝╚██████╔╝██║ ╚████║██████╔╝██║  ██║   ██║       ║
║    ╚═╝      ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ ╚═╝  ╚═╝   ╚═╝       ║
║                                                                        ║
╟────────────────────────────────────────────────────────────────────────╢
║                                                                        ║
║    ⬢  Template Management & Deployment System                         ║
║                                                                        ║
║    ├─ 📦  9 Production-Ready Templates                                ║
║    ├─ 🏗️   Hexagonal Architecture Patterns                            ║
║    ├─ 🐳  Docker-First Deployment                                     ║
║    ├─ 🔧  Automated Configuration & Setup                             ║
║    └─ ✅  Built-in Validation & Smoke Tests                           ║
║                                                                        ║
╟────────────────────────────────────────────────────────────────────────╢
║                                                                        ║
║  STATUS: [green]●[/green] OPERATIONAL  │  PATTERN: PORTS & ADAPTERS  │  YEAR: 2026      ║
║                                                                        ║
╚════════════════════════════════════════════════════════════════════════╝
[/bold cyan]
[dim]                The Foundry Overseer - Stack Management CLI[/dim]
"""

# Menu configuration
ANIMATED_MENU_ITEMS = [
    "Explore Templates",
    "Generate Project",
    "Manage Config",
    "System Validation",
    "View Docs",
    "Exit",
]
