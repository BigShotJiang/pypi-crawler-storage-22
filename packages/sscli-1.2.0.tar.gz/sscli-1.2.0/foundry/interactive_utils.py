import questionary
from pathlib import Path
from foundry.constants import console
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup


def is_repo_mode() -> bool:
    """
    Detect if running from the repo (development mode) vs installed package.
    Repo mode means: foundry-meta/stack-cli exists and services/license-server is accessible.
    """
    try:
        repo_root = Path(__file__).resolve().parent.parent.parent
        license_server = repo_root / "services" / "license-server"
        onboarding = repo_root / "docs" / "onboarding"
        return license_server.exists() and onboarding.exists()
    except Exception:
        return False


def manage_config_menu():
    while True:
        action = questionary.select(
            "Configuration Management:",
            choices=[
                "View Validation Status",
                "Run Template Setup (Full Suite)",
                "Back",
            ],
        ).ask()

        if action == "Back":
            break

        if action == "View Validation Status":
            run_health_check()
            pause()

        if action == "Run Template Setup (Full Suite)":
            run_setup()
            pause()


def pause():
    input("\nPress Enter to return...")


def internal_ops_menu():
    """Menu for internal development and ops tasks."""
    try:
        from foundry.ops.manager import InternalManager
    except ImportError:
        console.print("[red]Ops manager not available in this build.[/]")
        return

    # Show auth status for internal devs too
    from foundry.auth import get_current_license_info
    auth_info = get_current_license_info()
    if auth_info.get("tier") != "free":
        console.print(f"[green]✓ Authenticated as {auth_info.get('tier', 'user').upper()}[/green]")
    else:
        console.print("[yellow]⚠️  Not authenticated - limited access[/yellow]")

    manager = InternalManager()

    while True:
        # Build choices based on repo mode
        base_choices = [
            "Verify All Builds (Docker)",
            "Run Hygiene Checks (Repo Health)",
            "Full Verification Suite",
            "Clean Verification Reports",
        ]
        
        # Only show admin/sensitive options in repo mode
        if is_repo_mode():
            base_choices.extend([
                "Manage Licenses (User/Org)",
                "Generate Onboarding Materials (PDF)",
            ])
        
        base_choices.append("Back to Main")
        
        choice = questionary.select(
            "Foundry Ops - Internal Development:",
            choices=base_choices,
            style=questionary.Style([("highlighted", "fg:#ff00ff bold")]),
        ).ask()

        if not choice or choice == "Back to Main":
            break

        if choice == "Verify All Builds (Docker)":
            manager.verify_builds()
            pause()
        elif choice == "Run Hygiene Checks (Repo Health)":
            manager.run_verification_script(
                "verify_hygiene", "Code Hygiene (File Lengths)"
            )
            pause()
        elif choice == "Full Verification Suite":
            manager.verify_full_suite()
            pause()
        elif choice == "Clean Verification Reports":
            manager.clean_reports()
            pause()
        elif choice == "Manage Licenses (User/Org)" and is_repo_mode():
            manage_licenses_menu()
            pause()
        elif choice == "Generate Onboarding Materials (PDF)" and is_repo_mode():
            generate_pdf_menu()
            pause()


def manage_licenses_menu():
    """Sub-menu for managing user and organization licenses."""
    import sys
    from pathlib import Path

    # Add license-server to path to import upgrade functions
    repo_root = Path(__file__).resolve().parent.parent.parent
    license_server_path = repo_root / "services" / "license-server"
    
    if str(license_server_path) not in sys.path:
        sys.path.insert(0, str(license_server_path))

    while True:
        action = questionary.select(
            "What would you like to manage?",
            choices=[
                "Upgrade User",
                "Upgrade Organization",
                "Create Org Membership",
                "Back",
            ],
        ).ask()

        if action == "Back" or not action:
            break

        if action == "Upgrade User":
            tier = questionary.select(
                "Select Tier:",
                choices=["free", "alpha", "pro", "enterprise"],
            ).ask()
            
            identifier_type = questionary.select(
                "Identify user by:",
                choices=["github", "email"],
            ).ask()

            identifier = questionary.text(
                f"Enter {identifier_type.capitalize()} for the user:"
            ).ask()

            if tier and identifier:
                try:
                    from upgrade_user import upgrade_user_by_identifier
                    upgrade_user_by_identifier(tier, identifier, identifier_type)
                except Exception as e:
                    console.print(f"[red]Error upgrading user: {e}[/red]")

        elif action == "Upgrade Organization":
            tier = questionary.select(
                "Select Tier:",
                choices=["free", "alpha", "pro", "enterprise"],
            ).ask()

            org_name = questionary.text("Enter Organization Name:").ask()

            if tier and org_name:
                try:
                    from upgrade_org import upgrade_org_by_name
                    upgrade_org_by_name(tier, org_name)
                except Exception as e:
                    console.print(f"[red]Error upgrading organization: {e}[/red]")
        
        elif action == "Create Org Membership":
            org_name = questionary.text("Enter Organization Name:").ask()
            username = questionary.text("Enter GitHub Username:").ask()
            role = questionary.select(
                "Select Role:",
                choices=["member", "admin"],
            ).ask()

            if org_name and username and role:
                try:
                    from manage_members import add_user_to_org
                    add_user_to_org(org_name, username, role)
                except Exception as e:
                    console.print(f"[red]Error adding member: {e}[/red]")

def generate_pdf_menu():
    """Sub-menu for generating branded onboarding PDFs."""
    import sys
    from pathlib import Path

    # Add onboarding to path to import GuideGenerator
    repo_root = Path(__file__).resolve().parent.parent.parent
    onboarding_path = repo_root / "docs" / "onboarding"
    
    if str(onboarding_path) not in sys.path:
        sys.path.insert(0, str(onboarding_path))

    console.print("\n[bold cyan]Seed & Source — PDF Guide Generator[/bold cyan]")
    console.print("Generate branded onboarding materials for your customers.\n")

    # Gather inputs
    org_name = questionary.text(
        "Organization Name (e.g., 'Acme Corp'):",
        default="Seed & Source"
    ).ask()

    support_email = questionary.text(
        "Support Email Address:",
        default="support@seedsource.dev"
    ).ask()

    docs_url = questionary.text(
        "Documentation URL:",
        default="https://docs.seedsource.dev"
    ).ask()

    engine = questionary.select(
        "PDF Generation Engine:",
        choices=["pandoc", "weasyprint"],
        default="pandoc"
    ).ask()

    # Optional: custom output path
    custom_output = questionary.confirm(
        "Customize output file path?",
        default=False
    ).ask()

    output_path = "invite-developers-guide.pdf"
    if custom_output:
        output_path = questionary.text(
            "Output file path (relative to current directory):",
            default="invite-developers-guide.pdf"
        ).ask()

    try:
        from generate_guides import GuideGenerator

        # Initialize generator
        source_md = onboarding_path / "invite-developers-guide.md"
        source_css = onboarding_path / "invite-developers-guide.css"
        
        if not source_md.exists():
            console.print(f"[red]❌ Source markdown not found: {source_md}[/red]")
            return
        
        if not source_css.exists():
            console.print(f"[red]❌ Source CSS not found: {source_css}[/red]")
            return

        console.print("\n📝 Substituting placeholders...")
        generator = GuideGenerator(str(source_md), str(source_css))
        content = generator.substitute_placeholders(org_name, support_email, docs_url)
        temp_md = generator.write_temp_markdown(content)
        console.print("   ✓ Placeholders substituted")

        # Generate PDF
        console.print(f"\n🎨 Generating PDF with {engine}...")
        
        if engine == "pandoc":
            success = generator.generate_pdf_pandoc(output_path)
        else:
            success = generator.generate_pdf_weasyprint(output_path)

        # Cleanup
        generator.cleanup()

        if success:
            console.print(f"\n[green]✅ Success![/green]")
            console.print(f"   PDF saved to: [bold]{output_path}[/bold]")
            console.print(f"\n[cyan]📊 Next steps:[/cyan]")
            console.print(f"   1. Review the PDF for quality and accuracy")
            console.print(f"   2. Distribute to {org_name} stakeholders")
            console.print(f"   3. Include in customer onboarding emails")
        else:
            console.print(f"\n[red]❌ Failed to generate PDF[/red]")
            console.print(f"[yellow]💡 Troubleshooting:[/yellow]")
            if engine == "pandoc":
                console.print(f"   Install pandoc: brew install pandoc")
            else:
                console.print(f"   Install weasyprint: pip install weasyprint")

    except ImportError as e:
        console.print(f"[red]❌ Import error: {e}[/red]")
        console.print(f"[yellow]Make sure generate_guides.py is available in {onboarding_path}[/yellow]")
    except Exception as e:
        console.print(f"[red]❌ Error generating PDF: {e}[/red]")