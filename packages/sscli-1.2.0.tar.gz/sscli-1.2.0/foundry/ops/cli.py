import typer
from foundry.constants import console
from foundry.ops.manager import InternalManager

ops_app = typer.Typer(help="Internal maintenance commands for Seed & Source.")


@ops_app.command("dev-mode")
def dev_mode(enable: bool = typer.Option(True, help="Enable or disable local dev mode")):
    """Point sscli to the LOCAL license-server (localhost:8000)."""
    if enable:
        console.print("[bold yellow]Switching to LOCAL LICENSE SERVER (localhost:8000)...[/bold yellow]")
        console.print("Run: [bold]export LICENSE_SERVER_URL=http://localhost:8000/api/v1[/bold]")
        console.print("[dim]Ensure your license-server is running locally with 'python -m app.main'[/dim]")
    else:
        console.print("[bold green]Switching to PRODUCTION LICENSE SERVER...[/bold green]")
        console.print("Run: [bold]unset LICENSE_SERVER_URL[/bold]")

@ops_app.command("verify-builds")
def verify_builds():
    """Run docker builds for all templates."""
    manager = InternalManager()
    manager.verify_builds()


@ops_app.command("hygiene")
def hygiene():
    """Run code hygiene checks (file lengths)."""
    manager = InternalManager()
    manager.run_verification_script("verify_hygiene", "Code Hygiene (File Lengths)")


@ops_app.command("suite")
def suite():
    """Run full verification suite (Builds, Install, Runtime)."""
    manager = InternalManager()
    manager.verify_full_suite()


@ops_app.command("clean")
def clean():
    """Clean up verification reports."""
    manager = InternalManager()
    report = manager.root_dir / "verification_results.csv"
    if report.exists():
        report.unlink()
        console.print("Cleaned verification_results.csv")
    else:
        console.print("No report found.")
