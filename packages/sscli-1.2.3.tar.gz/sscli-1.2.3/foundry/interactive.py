import questionary
from foundry.actions.documentation import run_view_docs
from foundry.actions.explore import run_explore
from foundry.actions.generator import run_generator
from foundry.actions.validation import run_smoke_tests
from foundry.alpha_expiration import get_expiration_manager
from foundry.alpha.view import show_warning_message
from foundry.auth import get_current_license_info, login_flow
from foundry.constants import console
from foundry.animations.assets import FOUNDRY_BANNER
from foundry.utils import is_internal_dev
from foundry.interactive_utils import manage_config_menu, pause, internal_ops_menu


# Animation Imports - Standard Menu only needs to know if they exist for banner display
try:
    from foundry.animations import InteractiveAnimationEngine
    HAS_ANIMATIONS = True
except Exception:
    HAS_ANIMATIONS = False


def run_animated_experience():
    """Proxy to the actual animated experience implementation."""
    from foundry.animated_experience import run_animated_experience as _run
    _run()


def interactive_menu():
    if HAS_ANIMATIONS:
        try:
            # No intro sequence for standard menu - jumping straight to banner
            console.print(FOUNDRY_BANNER)
        except Exception:
            console.print(FOUNDRY_BANNER)
    else:
        console.print(FOUNDRY_BANNER)

    # Check authentication status
    auth_info = get_current_license_info()
    if auth_info.get("tier") == "free":
        console.print("\n[bold yellow]🔐 Authentication Required[/bold yellow]")
        console.print("You need to authenticate to access PRO and ALPHA features.\n")

        auth_choice = questionary.select(
            "Would you like to authenticate now?",
            choices=[
                "Login with GitHub (Recommended)",
                "Continue as Free User",
                "Exit",
            ],
        ).ask()

        if auth_choice == "Exit" or auth_choice is None:
            console.print("[yellow]Goodbye![/yellow]")
            return
        elif auth_choice == "Login with GitHub (Recommended)":
            try:
                login_flow()
                # Refresh auth info after login
                auth_info = get_current_license_info()
                console.print("\n[green]✓ Authentication successful![/green]\n")
            except Exception as e:
                console.print(f"\n[red]✗ Authentication failed:[/red] {e}\n")
                console.print("Continuing as free user...\n")

    # Internal Mode selection for Developers
    # This is the "Admin Gate". Shown if:
    # 1. Developer mode is detected via disk markers AND user is not Free.
    # 2. The user has an 'ADMIN' license (Verified with server).
    
    # HARDENING: Force a server-side verify if the local tier claims to be non-free
    if auth_info.get("tier") != "free":
        auth_info = get_current_license_info(verify=True)

    is_admin = auth_info.get("tier") == "admin"
    if (is_internal_dev() and auth_info.get("tier") != "free") or is_admin:
        mode = questionary.select(
            "Select Your Experience:",
            choices=[
                "Seed & Source (Client Side)",
                "Foundry Ops (Internal Side)",
                "Exit",
            ],
            style=questionary.Style([("highlighted", "fg:#00ffff bold")]),
        ).ask()

        if mode == "Exit" or mode is None:
            console.print("[yellow]Goodbye![/yellow]")
            return

        if mode == "Foundry Ops (Internal Side)":
            internal_ops_menu()
            return

    # Check for alpha package expiration
    alpha_mgr = get_expiration_manager()
    if alpha_mgr.is_alpha():
        alpha_mgr.show_status()
        if alpha_mgr.is_near_expiration():
            show_warning_message(alpha_mgr.alpha_info)

    while True:
        # Build menu choices based on auth status
        base_choices = [
            "Explore Templates",
            "Generate New Project",
            "Manage Stack Configuration",
            "Run System Validation (Smoke Tests)",
            "View Documentation",
        ]

        # Add auth option if not authenticated
        if auth_info.get("tier") == "free":
            base_choices.insert(0, "🔐 Login to Unlock PRO Features")
        else:
            base_choices.insert(0, f"👤 Account ({auth_info.get('tier', 'free').upper()})")

        base_choices.append("Exit")

        choice = questionary.select(
            "What would you like to do?",
            choices=base_choices,
        ).ask()

        if choice == "🔐 Login to Unlock PRO Features":
            try:
                login_flow()
                # Refresh auth info after login
                auth_info = get_current_license_info()
                console.print("\n[green]✓ Authentication successful![/green]\n")
            except Exception as e:
                console.print(f"\n[red]✗ Authentication failed:[/red] {e}\n")
        elif choice == f"👤 Account ({auth_info.get('tier', 'free').upper()})":
            # Show account info
            console.print(f"\n[bold]Account Information:[/bold]")
            console.print(f"Email: {auth_info.get('email', 'Not available')}")
            console.print(f"Tier: {auth_info.get('tier', 'free').upper()}")
            console.print(f"Expires: {auth_info.get('expires', 'N/A')}")
            console.print(f"User ID: {auth_info.get('user_id', 'N/A')}\n")
            pause()
        elif choice == "Explore Templates":
            run_explore()
            pause()
        elif choice == "Generate New Project":
            # Check expiration before generation
            if not alpha_mgr.check_before_action("Generate New Project"):
                continue
            run_generator(interactive=True)
            pause()
        elif choice == "Manage Stack Configuration":
            manage_config_menu()
        elif choice == "Run System Validation (Smoke Tests)":
            run_smoke_tests()
            pause()
        elif choice == "View Documentation":
            run_view_docs(interactive=True)
            pause()
        else:
            console.print("[yellow]Goodbye![/yellow]")
            break
