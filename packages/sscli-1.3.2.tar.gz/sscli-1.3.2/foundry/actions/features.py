import shutil
from pathlib import Path
from foundry.constants import console

def setup_secrets(path: Path, strategy: str):
    if "Dotenv" in strategy:
        example_env = path / ".env.example"
        if example_env.exists():
            target_env = path / ".env"
            if not target_env.exists():
                shutil.copy(example_env, target_env)
                console.print(f"   - Created .env from .env.example")
    elif "Doppler" in strategy:
        (path / "doppler.yaml").write_text("setup:\n  project: my-project\n  config: dev\n")
        console.print(f"   - Added doppler.yaml config")

def inject_features(path: Path, template: str, commerce: bool, tunnel: bool, landing: bool = False):
    if commerce:
        console.print("   - [bold blue]Injecting Commerce Modules (Shopify/Stripe)...[/bold blue]")
        _perform_feature_injection(path, "commerce")
        _inject_commerce_env_vars(path)
        if "rails" in template: _inject_rails_commerce_routes(path)
    else:
        _remove_commerce_files(path, template)
    if tunnel:
        console.print("   - [bold cyan]Configuring Local Tunnel (ngrok)...[/bold cyan]")
        _perform_feature_injection(path, "tunnel")
        _inject_tunnel_config(path, template)
    if landing:
        console.print("   - [bold magenta]Integrating Static Landing Page (Astro)...[/bold magenta]")
        _perform_feature_injection(path, "landing")
        _inject_landing_instructions(path)

def _perform_feature_injection(project_path: Path, feature_name: str):
    feature_dir = project_path / "features" / feature_name
    if feature_dir.exists():
        console.print(f"   - Moving {feature_name} files from features/ into source...")
        for item in feature_dir.glob("**/*"):
            if item.is_file():
                rel_path = item.relative_to(feature_dir)
                target_file = project_path / rel_path
                target_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target_file)

def _inject_commerce_env_vars(path: Path):
    env_files = [path / ".env", path / ".env.example"]
    commerce_vars = ["\n# --- Commerce (Shopify) ---", "SHOPIFY_SHOP_NAME=your-shop-name", "SHOPIFY_API_KEY=your-api-key", "SHOPIFY_API_SECRET=your-api-secret", "SHOPIFY_ACCESS_TOKEN=your-access-token\n"]
    for env_file in env_files:
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8")
            if "SHOPIFY_SHOP_NAME" not in content:
                with env_file.open("a", encoding="utf-8") as f: f.write("\n".join(commerce_vars))

def _inject_rails_commerce_routes(path: Path):
    routes_file = path / "config" / "routes.rb"
    if not routes_file.exists(): return
    content = routes_file.read_text(encoding="utf-8")
    if "namespace :webhooks" in content: return
    lines = content.splitlines()
    target_idx = -1
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip() == "end":
            target_idx = i
            break
    if target_idx != -1:
        webhook_routes = ["", "  namespace :webhooks do", "    post 'shopify', to: 'shopify#callback'", "  end"]
        for i, line in enumerate(webhook_routes): lines.insert(target_idx + i, line)
        routes_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        console.print("   - Injected Shopify webhook routes into config/routes.rb")

def _remove_commerce_files(path: Path, template: str):
    python_saas_paths = [path / "src" / "infrastructure" / "commerce", path / "src" / "core" / "interfaces" / "commerce.py", path / "src" / "ui" / "api" / "webhooks.py"]
    rails_paths = [path / "app" / "services" / "commerce", path / "app" / "controllers" / "webhooks" / "shopify_controller.rb"]
    targets = python_saas_paths if template == "python-saas" else (rails_paths if "rails" in template else [])
    for t in targets:
        if t.exists():
            if t.is_dir(): shutil.rmtree(t)
            else: t.unlink()

def _inject_tunnel_config(path: Path, template: str):
    env_files = [path / ".env", path / ".env.example"]
    for env_file in env_files:
        if env_file.exists() and "NGROK_AUTHTOKEN" not in env_file.read_text(encoding="utf-8"):
            with env_file.open("a", encoding="utf-8") as f: f.write("\n# --- Tunneling ---\nNGROK_AUTHTOKEN=your-ngrok-token\n")
    compose_file = path / "docker-compose.yml"
    if compose_file.exists():
        content = compose_file.read_text(encoding="utf-8")
        if "tunnel:" not in content:
            port = "8080" if template == "python-saas" else "3000"
            service_name = "python-saas" if template == "python-saas" else "api"
            tunnel_service = f"\n  tunnel:\n    image: ngrok/ngrok:latest\n    command:\n      - \"http\"\n      - \"{service_name}:{port}\"\n    environment:\n      - NGROK_AUTHTOKEN=${{NGROK_AUTHTOKEN}}\n    depends_on:\n      - {service_name}\n"
            if "services:" in content: compose_file.write_text(content.replace("services:", f"services:\n{tunnel_service}"), encoding="utf-8")
    readme = path / "README.md"
    if readme.exists():
        with open(readme, "a") as f: f.write("\n\n## 🌐 Local Tunneling (ngrok)\nThis project is configured to use ngrok for local tunneling. Add your NGROK_AUTHTOKEN to .env and run `docker-compose up`.\n")

def _inject_landing_instructions(path: Path):
    """Add landing page setup instructions to README."""
    readme = path / "README.md"
    if readme.exists():
        with open(readme, "a") as f:
            f.write("\n\n## 🚀 Static Landing Page (Astro)\n"
                   "This project includes an Astro-powered static landing page.\n"
                   "### Getting Started\n"
                   "```bash\n"
                   "cd static-landing\n"
                   "npm install\n"
                   "npm run dev\n"
                   "```\n"
                   "Visit http://localhost:3000/\n")
        console.print("   - Added landing page documentation to README.md")
