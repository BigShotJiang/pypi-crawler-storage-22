import shutil
from pathlib import Path

import questionary
from foundry.constants import console
from foundry.telemetry import get_feedback_link, log_event
from foundry.utils import get_template_info
from foundry.actions.generation_utils import (
    inject_metadata,
    disable_linters,
    validate_and_fix_pyproject,
    check_tier_access,
    setup_secrets,
    inject_features,
    regenerate_poetry_lock,
)
from .interactive_config import get_interactive_config
from .repo_utils import download_template


def run_generator(
    template_name: str = None,
    app_name: str = None,
    target_dir_name: str = None,
    use_linters: bool = True,
    with_commerce: bool = False,
    with_tunnel: bool = False,
    with_landing: bool = False,
    interactive: bool = False,
    secrets_strategy: str = "Dotenv (Standard .env files)",
):

    if interactive:
        config = get_interactive_config(template_name)
        if not config: return
        
        template_name = config["template_name"]
        app_name = config["app_name"]
        with_commerce = config["with_commerce"]
        with_tunnel = config["with_tunnel"]
        with_landing = config["with_landing"]
        use_linters = config["use_linters"]
        secrets_strategy = config["secrets_strategy"]
    else:
        secrets_strategy = secrets_strategy or "Dotenv (Standard .env files)"

    # Tier Enforcement Check
    template_info = get_template_info(template_name)
    if not check_tier_access(template_name, template_info.get("tier", "free")):
        return

    # Determine destination path
    if interactive:
        target_path_input = questionary.text(
            "Where would you like to install the repository?", default=str(Path.cwd())
        ).ask()
        if not target_path_input:
            console.print("[red]Error: Installation path required.[/red]")
            return
        target_path = Path(target_path_input)
    else:
        target_path = Path(target_dir_name) if target_dir_name else Path.cwd()

    if not template_name:
        console.print("[red]Error: Template name required.[/red]")
        return

    log_event("GENERATE_START", f"Template: {template_name}, App: {app_name}")
    console.print(f"\n[bold green]Deploying {template_name} to {target_path.name}...[/bold green]")

    try:
        if target_path.exists() and any(target_path.iterdir()):
            console.print(f"[red]Error: {target_path.name} already exists and is not empty![/red]")
            return

        if not download_template(template_name, template_info, target_path):
            return

        # Post-download processing
        inject_metadata(target_path, template_name, app_name or target_path.name)
        validate_and_fix_pyproject(target_path)

        if not use_linters:
            disable_linters(target_path, template_name)

        setup_secrets(target_path, secrets_strategy)
        inject_features(target_path, template_name, with_commerce, with_tunnel, with_landing)
        regenerate_poetry_lock(target_path)

        # Cleanup
        features_dir = target_path / "features"
        if features_dir.exists(): shutil.rmtree(features_dir)

        console.print(f"[bold green]Success! Project created at {target_path}[/bold green]")
        console.print(f"\n[bold blue]Feedback Wanted![/bold blue] [link={get_feedback_link()}]{get_feedback_link()}[/link]")
        log_event("GENERATE_SUCCESS", f"Template: {template_name}, Target: {target_path}")

    except Exception as e:
        console.print(f"[bold red]Deployment failed:[/bold red] {e}")
        log_event("GENERATE_ERROR", str(e))

