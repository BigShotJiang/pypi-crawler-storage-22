import questionary
from foundry.auth import get_current_license_info
from foundry.constants import TIER_HIERARCHY, console
from foundry.utils import get_template_info, get_templates
from rich.panel import Panel

def get_interactive_config(template_name=None):
    """Gathers all configuration interactively from the user."""
    # Filter templates based on user tier for a cleaner experience
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)
    
    if not template_name:
        available_templates = []
        for tmpl in get_templates():
            info = get_template_info(tmpl.name)
            tmpl_tier = info.get("tier", "free").lower()
            if user_rank >= TIER_HIERARCHY.get(tmpl_tier, 0):
                available_templates.append(tmpl.name)

        if not available_templates:
            console.print("[yellow]No templates available for your current tier.[/yellow]")
            return None

        # Add Back button for better navigation
        choices = ["Back"] + available_templates

        template_name = questionary.select(
            "Select a template to deploy:", choices=choices
        ).ask()

        if template_name == "Back" or not template_name:
            return None

        console.print(Panel(f"[bold]Configuring {template_name}[/bold]", style="blue"))

    app_name = questionary.text(
        "Enter your Application Name:", default=f"my-{template_name}"
    ).ask()
    
    # PRO Feature Injection
    if user_rank >= TIER_HIERARCHY.get("pro"):
        with_commerce = questionary.confirm(
            "Would you like to include Commerce modules (Shopify/Stripe)?", 
            default=False
        ).ask()
        with_tunnel = questionary.confirm(
            "Enable local tunneling (ngrok)?", 
            default=False
        ).ask()
        with_landing = questionary.confirm(
            "Include a static landing page (Astro)?",
            default=False
        ).ask()
    else:
        with_commerce = with_tunnel = with_landing = False

    use_linters = questionary.confirm(
        "Enable default linters (Ruff/Rubocop/ESLint)?", default=True
    ).ask()
    
    secrets_strategy = questionary.select(
        "Select Secrets Management Strategy:",
        choices=[
            "Dotenv (Standard .env files)",
            "Doppler (Managed cloud secrets)",
            "Environment Only (PaaS/CI friendly)",
        ],
        default="Dotenv (Standard .env files)",
    ).ask()
    
    return {
        "template_name": template_name,
        "app_name": app_name,
        "with_commerce": with_commerce,
        "with_tunnel": with_tunnel,
        "with_landing": with_landing,
        "use_linters": use_linters,
        "secrets_strategy": secrets_strategy
    }
