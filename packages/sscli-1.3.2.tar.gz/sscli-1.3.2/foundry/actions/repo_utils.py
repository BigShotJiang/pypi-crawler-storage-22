import shutil
import subprocess
from pathlib import Path
from foundry.auth import get_access_token
from foundry.constants import console, TEMPLATES_DIR
from foundry.utils import is_internal_dev
from rich.panel import Panel

def download_template(template_name, template_info, target_path):
    """Clones or copies the template to the target path."""
    # Local template fallback for internal development
    local_template_path = TEMPLATES_DIR / template_name
    if is_internal_dev() and local_template_path.exists():
        console.print("   - Using local template from development environment...")
        try:
            shutil.copytree(local_template_path, target_path, dirs_exist_ok=False)
            return True
        except FileExistsError:
            console.print(f"[red]Error: {target_path.name} already exists![/red]")
            return False
    else:
        # Remote template: Clone from GitHub with authentication
        repo_url = template_info.get("repo")
        if not repo_url:
            console.print(f"[red]Error: No repository found for template '{template_name}'[/red]")
            return False

        token = get_access_token()
        auth_url = repo_url.replace("https://", f"https://{token}@") if token else repo_url

        console.print("   - Downloading template from Seed & Source...")
        result = subprocess.run(
            ["git", "clone", "--depth", "1", auth_url, str(target_path)],
            capture_output=True, text=True
        )

        if result.returncode != 0:
            handle_clone_error(result.stderr)
            return False

        # Remove template git history
        if (target_path / ".git").exists():
            shutil.rmtree(target_path / ".git")
        return True

def handle_clone_error(stderr):
    """Provides helpful feedback for Git clone failures."""
    console.print("[bold red]Download Error:[/bold red]")
    if "403" in stderr or "401" in stderr:
        console.print(Panel(
            "[bold yellow]Organization Access Required[/bold yellow]\n\n"
            "It looks like your GitHub token doesn't have access to the private repository.\n"
            "1. Go to your [bold]GitHub Settings -> Applications -> Authorized OAuth Apps[/bold].\n"
            "2. Find 'Seed & Source License'.\n"
            "3. Ensure access is [bold]GRANTED[/bold] for the 'seed-source' organization.",
            title="Access Denied", border_style="red"
        ))
    else:
        console.print(f"Error Message: {stderr}")
