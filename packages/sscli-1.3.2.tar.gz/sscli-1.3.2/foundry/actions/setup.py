import subprocess
import sys
from typing import Optional

from foundry.constants import TEMPLATES_DIR, console


def run_setup(
    verbose: bool = False,
    force: bool = False,
    skip_deps: bool = False,
    env: str = "dev",
    strategy: Optional[str] = None,
):
    """
    Orchestrates the setup process for all available templates.
    Hands off execution to each template's local bin/setup.py.
    """
    templates = [
        "python-saas",
        "rails-api",
        "rails-ui-kit",
        "data-pipeline",
        "react-client",
        "mobile-android",
        "mobile-ios",
        "terraform-infra",
    ]

    console.print("[bold yellow]Foundry: Running Template Setup Suite[/bold yellow]")

    for tmpl in templates:
        tmpl_path = TEMPLATES_DIR / tmpl
        if not tmpl_path.exists():
            continue

        console.print(f"\n[bold cyan]▶ Setting up {tmpl}[/bold cyan]")

        setup_script = tmpl_path / "bin" / "setup.py"
        if not setup_script.exists():
            console.print(f"  [dim]No setup.py found for {tmpl}, skipping.[/dim]")
            continue

        cmd = [sys.executable, str(setup_script), "--env", env]
        if force:
            cmd.append("--force")
        if skip_deps:
            cmd.append("--skip-deps")
        # Strategy is currently handled per-template if they support it
        if strategy:
            cmd.extend(["--strategy", strategy])

        try:
            # We use check_call to ensure we stop on first failure
            subprocess.check_call(cmd, cwd=tmpl_path)
            console.print(f"  [green]✔ {tmpl} setup complete.[/green]")
        except subprocess.CalledProcessError:
            console.print(f"  [red]✘ {tmpl} setup failed.[/red]")
            # We don't exit here to allow other templates if needed,
            # but bin/setup usually wants total success.
            # However, for the orchestrator, we might want to continue or exit.
            # Given bin/setup's use case, exit 1 is safer.
            sys.exit(1)
        except Exception as e:
            console.print(f"  [red]Unexpected error:[/red] {e}")
            sys.exit(1)

    console.print(
        "\n[bold green]Template setup suite completed successfully.[/bold green]"
    )
