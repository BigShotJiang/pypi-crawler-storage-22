import os
import json
import time
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from foundry.constants import console, API_BASE_URL

# Configuration
# The base URL is managed in foundry/constants.py (configurable via environment variables)
LICENSE_SERVER = API_BASE_URL
CREDENTIALS_FILE = Path.home() / ".config" / "sscli" / "credentials.json"


def get_access_token() -> Optional[str]:
    """Retrieve the stored access token if it exists."""
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
            return data.get("access_token")
    except Exception:
        return None


def save_credentials(data: Dict[str, Any]) -> None:
    """Save user credentials to the home directory."""
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CREDENTIALS_FILE, "w") as f:
        json.dump(data, f, indent=2)


def login_flow() -> None:
    """Execute the GitHub Device Flow via the License Server."""
    console.print("Initiating login with GitHub...")

    try:
        response = requests.post(f"{LICENSE_SERVER}/auth/device/code")
        response.raise_for_status()
    except Exception as e:
        console.print(f"[red]Error connecting to License Server at {LICENSE_SERVER}:[/] {e}")
        return

    try:
        data = response.json()
    except Exception:
        console.print("[red]Error:[/] Server response was not valid JSON.")
        return

    device_code = data.get("device_code")
    user_code = data.get("user_code")
    verification_uri = data.get("verification_uri")
    interval = data.get("interval", 5)

    if not all([device_code, user_code, verification_uri]):
        console.print("[red]Error:[/] Server provided incomplete device flow information.")
        return

    console.print(f"\n1. Go to: {verification_uri}")
    console.print(f"2. Enter code: {user_code}\n")
    console.print("Waiting for authorization...")

    while True:
        try:
            token_resp = requests.get(
                f"{LICENSE_SERVER}/auth/device/token",
                params={"device_code": device_code},
                timeout=10,
            )

            # 428 Precondition Required is used for "authorization_pending"
            if token_resp.status_code == 428:
                time.sleep(interval)
                continue

            # Attempt to safely parse the response JSON
            try:
                data = token_resp.json() if token_resp.text.strip() else {}
            except Exception:
                data = {}

            if token_resp.status_code == 200:
                if not data:
                    console.print("\n[red]Login failed:[/] Server returned an empty response.")
                    break
                
                save_credentials(data)
                console.print(
                    f"\nSuccessfully logged in as {data.get('email', 'User')}!"
                )
                
                tier_str = data.get('tier', 'free').upper()
                org_name = data.get('org_name')
                if org_name:
                    console.print(f"License Tier: {tier_str} (via {org_name})")
                else:
                    console.print(f"License Tier: {tier_str}")
                break

            # If we are here, some other error occurred (400, 401, 403, 404, 500, etc.)
            error_detail = data.get("detail") if isinstance(data, dict) else None
            if not error_detail:
                error_detail = f"Server returned status {token_resp.status_code}"
            
            console.print(f"\n[red]Login failed:[/] {error_detail}")
            break

        except Exception as e:
            console.print(f"\n[red]Polling error:[/] {e}")
            break


def get_current_license_info(verify: bool = False) -> Dict[str, Any]:
    """Read the current license/tier info from local storage.

    If verify=True, it pings the server to ensure the local tier hasn't been tampered with.
    """
    default_info = {"tier": "free", "authorized": False, "org_name": None, "status": "active"}
    
    if not CREDENTIALS_FILE.exists():
        return default_info
        
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
            
        if not isinstance(data, dict):
            return default_info

        # Server-side hardening: If we need a verified tier, don't trust the local file
        if verify and data.get("access_token"):
            try:
                # Lightweight check to current license server
                response = requests.get(
                    f"{LICENSE_SERVER}/auth/validate",
                    headers={"Authorization": f"Bearer {data['access_token']}"},
                    timeout=2.0
                )
                if response.status_code == 200:
                    server_data = response.json()
                    # Sync local cache with server truth
                    data["tier"] = server_data.get("tier", "free")
                    data["status"] = server_data.get("status", "active")
                    save_credentials(data)
                else:
                    # Token invalid or expired
                    return default_info
            except Exception:
                # If server is unreachable, and we require verification, 
                # we downgrade to free for safety during the session
                data["tier"] = "free"

        return data
    except Exception:
        return default_info


def logout() -> None:
    """Clear local stored credentials (logout).

    Removes the `credentials.json` file if present and reports status to the console.
    """
    try:
        if CREDENTIALS_FILE.exists():
            CREDENTIALS_FILE.unlink()
            console.print("[green]Logged out:[/] removed local credentials.")
        else:
            console.print("[yellow]No credentials found to remove.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error clearing credentials:[/] {e}")
