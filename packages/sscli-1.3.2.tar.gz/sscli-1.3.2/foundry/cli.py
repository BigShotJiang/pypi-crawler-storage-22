from typing import Optional
from foundry.constants import console
import typer
from foundry.actions.documentation import run_view_docs
from foundry.actions.explore import run_explore
from foundry.actions.generator import run_generator
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup
from foundry.actions.validation import run_smoke_tests
from foundry.actions.verify import run_verification
from foundry.auth import get_current_license_info
from foundry.telemetry import log_event
from foundry.commands.auth import auth_app, run_whoami
from foundry.commands.interactive import interactive_app
from foundry.utils import is_internal_dev

app = typer.Typer(
    help="Seed & Source CLI Tool",
    no_args_is_help=True,
    add_completion=True,
)

# Add sub-apps from separate modules
app.add_typer(auth_app, name="auth")
app.add_typer(interactive_app, name="interactive")

# Only expose Internal Ops commands if running in a development context
if is_internal_dev():
    from foundry.ops.cli import ops_app
    app.add_typer(ops_app, name="ops", help="Internal operations and maintenance.")


@app.command("whoami")
def whoami():
    run_whoami()



@app.command("explore")
def explore():
    """List available templates."""
    log_event("COMMAND", "explore")
    run_explore()


@app.command("new")
def new(
    template: str = typer.Option(..., help="Name of the template to use"),
    name: str = typer.Option(..., help="Name of the application"),
    target: Optional[str] = typer.Option(
        None, help="Target directory (defaults to name)"
    ),
    no_lint: bool = typer.Option(False, "--no-lint", help="Disable default linters"),
    with_commerce: bool = typer.Option(
        False, "--with-commerce", help="Inject Commerce modules (Shopify/Stripe)"
    ),
    with_tunnel: bool = typer.Option(
        False, "--with-tunnel", help="Enable local tunneling (ngrok)"
    ),
    with_landing: bool = typer.Option(
        False, "--with-landing", help="Include static landing page (Astro)"
    ),
    secrets: str = typer.Option(
        "Dotenv (Standard .env files)", help="Secrets management strategy"
    ),
):
    """Generate a new project from a template."""
    log_event("COMMAND", f"new --template {template} --name {name} --commerce {with_commerce} --tunnel {with_tunnel} --landing {with_landing}")
    run_generator(
        template_name=template,
        app_name=name,
        target_dir_name=target,
        use_linters=not no_lint,
        with_commerce=with_commerce,
        with_tunnel=with_tunnel,
        with_landing=with_landing,
        interactive=False,
        secrets_strategy=secrets,
    )


@app.command("setup")
def setup(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable detailed logging"
    ),
    force: bool = typer.Option(
        False, "--force", help="Force setup even if already configured"
    ),
    skip_deps: bool = typer.Option(
        False, "--skip-deps", help="Skip dependency installation"
    ),
    env: str = typer.Option("dev", "--env", help="Environment to setup (default: dev)"),
    strategy: Optional[str] = typer.Option(
        None, "--strategy", help="Setup strategy (docker, etc)"
    ),
):
    """Run setup for templates."""
    log_event("COMMAND", f"setup --env {env}")
    run_setup(
        verbose=verbose, force=force, skip_deps=skip_deps, env=env, strategy=strategy
    )


@app.command("validate")
def validate():
    """Run smoke tests."""
    log_event("COMMAND", "validate")
    run_smoke_tests()


@app.command("health")
def health():
    """Check configuration and health of templates."""
    log_event("COMMAND", "health")
    run_health_check()


@app.command("verify")
def verify(
    skip_docker: bool = typer.Option(
        False, "--skip-docker", help="Skip Docker builds (faster, less thorough)"
    ),
    no_reports: bool = typer.Option(
        False, "--no-reports", help="Skip generating CSV/MD reports"
    ),
):
    """Verify template integrity and buildability."""
    log_event("COMMAND", "verify")
    run_verification(include_docker=not skip_docker, output_reports=not no_reports)


@app.command("docs")
def docs():
    """List available documentation."""
    log_event("COMMAND", "docs")
    run_view_docs(interactive=False)
