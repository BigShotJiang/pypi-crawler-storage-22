import questionary
from foundry.constants import console
from foundry.auth import get_current_license_info, login_flow
from foundry.utils import is_internal_dev
from foundry.interactive_utils import internal_ops_menu

def check_auth_gate():
    """Handles the login or continue flow. Returns current auth_info."""
    auth_info = get_current_license_info()
    if auth_info.get("tier") == "free":
        console.print("\n[bold yellow]🔐 Authentication Required[/bold yellow]")
        console.print("You need to authenticate to access PRO and ALPHA features.\n")
        auth_choice = questionary.select(
            "Would you like to authenticate now?",
            choices=["Login with GitHub (Recommended)", "Continue as Free User", "Exit"],
        ).ask()
        if auth_choice == "Exit" or auth_choice is None:
            return None
        elif auth_choice == "Login with GitHub (Recommended)":
            try:
                login_flow()
                auth_info = get_current_license_info()
            except Exception as e:
                console.print(f"\n[red]✗ Authentication failed:[/red] {e}\nContinuing as free user...\n")
    if auth_info.get("tier") != "free":
        auth_info = get_current_license_info(verify=True)
    return auth_info

def check_internal_gate(auth_info):
    """Checks if the user can and wants to enter internal ops. Returns True if handled internal flow."""
    is_admin = auth_info.get("tier") == "admin"
    if (is_internal_dev() and auth_info.get("tier") != "free") or is_admin:
        mode = questionary.select(
            "Select Your Experience:",
            choices=["Seed & Source (Client Side)", "Foundry Ops (Internal Side)", "Exit"],
            style=questionary.Style([("highlighted", "fg:#00ffff bold")]),
        ).ask()
        if mode == "Exit" or mode is None:
            return "EXIT"
        if mode == "Foundry Ops (Internal Side)":
            return "INTERNAL"
    return "CLIENT"
