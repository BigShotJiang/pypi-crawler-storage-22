import questionary
import sys
from pathlib import Path
from foundry.constants import console

def manage_licenses_menu():
    """Sub-menu for managing user and organization licenses."""
    # Add license-server to path to import upgrade functions
    repo_root = Path(__file__).resolve().parent.parent.parent
    license_server_path = repo_root / "services" / "license-server"
    
    if str(license_server_path) not in sys.path:
        sys.path.insert(0, str(license_server_path))

    while True:
        action = questionary.select(
            "What would you like to manage?",
            choices=[
                "Upgrade User",
                "Upgrade Organization",
                "Create Org Membership",
                "Back",
            ],
        ).ask()

        if action == "Back" or not action:
            break

        if action == "Upgrade User":
            tier = questionary.select(
                "Select Tier:",
                choices=["free", "alpha", "pro", "enterprise"],
            ).ask()
            
            identifier_type = questionary.select(
                "Identify user by:",
                choices=["github", "email"],
            ).ask()

            identifier = questionary.text(
                f"Enter {identifier_type.capitalize()} for the user:"
            ).ask()

            if tier and identifier:
                try:
                    from upgrade_user import upgrade_user_by_identifier
                    upgrade_user_by_identifier(tier, identifier, identifier_type)
                except Exception as e:
                    console.print(f"[red]Error upgrading user: {e}[/red]")

        elif action == "Upgrade Organization":
            tier = questionary.select(
                "Select Tier:",
                choices=["free", "alpha", "pro", "enterprise"],
            ).ask()

            org_name = questionary.text("Enter Organization Name:").ask()

            if tier and org_name:
                try:
                    from upgrade_org import upgrade_org_by_name
                    upgrade_org_by_name(tier, org_name)
                except Exception as e:
                    console.print(f"[red]Error upgrading organization: {e}[/red]")
        
        elif action == "Create Org Membership":
            org_name = questionary.text("Enter Organization Name:").ask()
            username = questionary.text("Enter GitHub Username:").ask()
            role = questionary.select(
                "Select Role:",
                choices=["member", "admin"],
            ).ask()

            if org_name and username and role:
                try:
                    from manage_members import add_user_to_org
                    add_user_to_org(org_name, username, role)
                except Exception as e:
                    console.print(f"[red]Error adding member: {e}[/red]")
