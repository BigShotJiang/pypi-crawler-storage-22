# Seed & Source CLI v1.1.0

Unified interface for Seed & Source templates. Now with **Seed & Source Core** — production-ready multi-tenant SaaS APIs.

## 🎯 What is sscli?

`sscli` scaffolds complete, enterprise-grade SaaS stacks with:
- ✅ Multi-tenant isolation (database-level RLS)
- ✅ Third-party integrations (Shopify, Stripe, WooCommerce)
- ✅ Hexagonal Architecture (clean, testable code)
- ✅ Security by default (HMAC validation, RLS policies)
- ✅ Ready-to-deploy applications

## 📦 Quick Install

```bash
# Via pip
pip install sscli==1.1.0

# Via pipx (recommended)
pipx install sscli==1.1.0

# Verify
sscli --version
# Output: sscli 1.1.0
```

## 🚀 Quick Start

### Create a Multi-Tenant Rails API

```bash
sscli new \
  --template rails-api \
  --name my-saas-api \
  --with-commerce \
  --with-shopify
```

This scaffolds:
- Rails 8.0 API with PostgreSQL
- Multi-tenant core (Tenant → Integration → CommercialAgreement → SecurityToken)
- HMAC webhook validation
- Shopify adapter (ready for orders/create webhooks)
- Row-Level Security (RLS) enforcement

### Create a Python SaaS Backend

```bash
sscli new \
  --template python-saas \
  --name my-python-service
```

This scaffolds:
- Python 3.11+ FastAPI or Django
- SQLAlchemy ORM
- Pydantic validation
- Pre-configured logging

### Create a React Client

```bash
sscli new \
  --template react-client \
  --name my-frontend \
  --with-tailwind
```

This scaffolds:
- React 18+ with Vite
- React Query for state
- Tailwind CSS
- TypeScript

## 📋 Available Templates

| Template | Description | Use Case |
|----------|-------------|----------|
| `rails-api` | Multi-tenant Rails API (v1.1.0) | SaaS backends, microservices |
| `python-saas` | Python FastAPI backend | Data processing, ML services |
| `react-client` | React + Vite frontend | Web UIs, dashboards |
| `data-pipeline` | dbt + Airflow pipeline | Analytics, ETL |
| `mobile-android` | Android native app | Mobile apps |
| `mobile-ios` | iOS Swift app | Mobile apps |

## 🔧 CLI Commands

```bash
sscli new              # Create new project
sscli interactive      # Interactive mode
sscli list            # List available templates
sscli verify          # Verify template integrity
```

## 🔐 Seed & Source Core (NEW in v1.1.0)

The `rails-api` template now uses **Seed & Source Core** — a Hexagonal Architecture pattern with:

### Domain Models

```ruby
# SaaS customer
Tenant.create!(name: "Organization", subdomain: "org")

# Platform credentials (Shopify, Stripe, etc.)
Integration.create!(
  tenant: tenant,
  platform_domain: "store.myshopify.com",
  provider_type: "shopify",
  platform_token: "access_token_here"
)

# Order/contract bridge
agreement = CommercialAgreement.create!(provider_id: "shopify_order_123")

# Access grant
token = SecurityToken.generate_for(agreement)
# => token.token = "secure_random_hex"
```

### Security Features

- ✅ **HMAC Validation**: All webhooks are signature-verified
- ✅ **Row-Level Security**: PostgreSQL policies enforce tenant isolation
- ✅ **Idempotency**: Duplicate webhooks don't create duplicate resources
- ✅ **Tenant Scoping**: All queries automatically scoped by `ActsAsTenant`

### Architecture

```
External System (Shopify) → HMAC Validator → ShopifyAdapter → 
Provisioning::IssueResource → CommercialAgreement + SecurityToken
```

## 📖 Documentation

- **Installation**: See this README
- **Rails API Setup**: `rails-api/README.md`
- **v1.1.0 Changelog**: `stack-cli/CHANGELOG_v1.1.0.md`
- **PactaPay Case Study**: `PACTAPAY_IMPLEMENTATION.md`

## 🎯 Use Cases

### Use Case: SaaS with Shopify Integration

```bash
sscli new \
  --template rails-api \
  --name shopify-saas \
  --with-commerce \
  --with-shopify

cd shopify-saas
rails db:migrate
# Create Tenant and Integration records
# Configure Shopify webhooks
rails server
```

### Use Case: Multi-Provider Payment Platform

```bash
# Start with Shopify
sscli new \
  --template rails-api \
  --name payment-platform \
  --with-shopify

# Add Stripe adapter later (v1.2.0)
# One codebase, multiple providers
```

### Use Case: Data-Critical SaaS

```bash
# Create Rails API
sscli new --template rails-api --name analytics-api

# Create data pipeline
sscli new --template data-pipeline --name analytics-pipeline

# They integrate seamlessly
```

## 🔌 Adding Custom Adapters

Create a new provider adapter in 3 steps:

1. **Implement the Port** (`ICommerceProvider`):
```ruby
module Commerce
  class MyAdapter
    include ICommerceProvider
    
    def handle_webhook(event_type, payload)
      # Your logic here
    end
  end
end
```

2. **Register in Controller**:
```ruby
# app/controllers/api/v1/webhooks_controller.rb
adapter = Commerce::MyAdapter.new(tenant)
adapter.handle_webhook(topic, payload)
```

3. **Test**:
```bash
curl -X POST http://localhost:3000/api/v1/webhooks/myservice \
  -H "X-Signature: ..." \
  -d '{...}'
```

## 🧪 Testing Templates

Verify templates work correctly:

```bash
sscli verify --template rails-api
sscli verify --template python-saas
sscli verify --template react-client
```

## 🚀 Deployment

Each template includes deployment configs for:
- Docker
- Heroku
- AWS ECS
- Kubernetes

See individual template READMEs for details.

## 🔄 Updates

Update to latest version:

```bash
pip install --upgrade sscli
# or
pipx upgrade sscli
```

## ❓ Troubleshooting

### Command not found

```bash
# Ensure installation worked
sscli --version

# If not found, reinstall
pipx uninstall sscli
pipx install sscli==1.1.0
```

### Template not creating correctly

```bash
# Check template integrity
sscli verify --template rails-api

# Use verbose mode
sscli new --template rails-api --name test --verbose
```

## 📞 Support

- **GitHub**: [seed-source/foundry-meta](https://github.com/seed-source/foundry-meta)
- **Docs**: [Seed & Source Docs](https://docs.seedsource.dev)
- **Email**: support@seedsource.dev

## 📄 License

MIT

---

**v1.1.0 - Now with Seed & Source Core** 🚀
