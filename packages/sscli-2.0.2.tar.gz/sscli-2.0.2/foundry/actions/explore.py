from foundry.constants import console, TIER_HIERARCHY
from foundry.utils import get_templates, get_template_info
from foundry.auth import get_current_license_info
from rich.panel import Panel
from rich.tree import Tree
import questionary


def _get_template_tech(tmpl):
    """Get technology stack for a template."""
    if (tmpl / "pyproject.toml").exists():
        return "Python (FastAPI/NiceGUI)"
    elif (tmpl / "Gemfile").exists():
        return "Ruby on Rails"
    elif (tmpl / "package.json").exists():
        return "React/Vite"
    elif (tmpl / "build.gradle.kts").exists():
        return "Android (Kotlin/Compose)"
    elif (tmpl / "StackApp").exists():
        return "iOS (Swift/SwiftUI)"
    elif (tmpl / "main.tf").exists():
        return "Terraform"
    elif (tmpl / "astro.config.mjs").exists():
        return "Astro (Static Site)"
    return "Unknown"


def _render_interactive_tree(buckets, expansion_state):
    """Render an interactive tree view with collapsible categories."""
    tree = Tree("[bold green]Seed & Source Inventory[/bold green]")

    for category, items in buckets.items():
        if not items:
            continue

        count = len(items)
        is_expanded = expansion_state.get(category, True)
        toggle_icon = "▼" if is_expanded else "►"
        
        cat_node = tree.add(f"[bold yellow]{toggle_icon} {category} ({count})[/bold yellow]")
        
        if is_expanded:
            for item in items:
                node = cat_node.add(f"[bold cyan]{item['display']}[/bold cyan]")
                tmpl = item['path']
                tech = _get_template_tech(tmpl)
                node.add(f"[dim]{tech}[/dim]")
        else:
            cat_node.add("[dim]Click to expand...[/dim]")

    console.print(Panel(tree, title="Available Templates", border_style="green"))


def run_explore():
    """Interactive template explorer with interactive collapsible sections using tree view design."""
    # Get user info for tier checking
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)

    # Group templates by category
    buckets = {
        "Backend Services": [],
        "Frontend & UI": [],
        "Mobile App": [],
        "Data Engineering": [],
        "Infrastructure": [],
        "Other": [],
    }

    templates = get_templates()

    for tmpl in templates:
        name = tmpl.name
        # Fetch metadata to get the tier
        info = get_template_info(name)
        tmpl_tier = info.get("tier", "free").lower()
        tmpl_rank = TIER_HIERARCHY.get(tmpl_tier, 0)

        # Format display name with access status badge
        tmpl_display_name = name
        if tmpl_rank > user_rank:
            tmpl_display_name = f"[dim]{name} [red](🔐 {tmpl_tier.upper()})[/dim]"
        elif tmpl_tier != "free":
            tmpl_display_name = f"{name} [green](✅ {tmpl_tier.upper()})[/green]"
        
        # Store template data for processing
        tmpl_data = {"name": name, "display": tmpl_display_name, "path": tmpl}

        if name in ["python-saas", "rails-api"]:
            buckets["Backend Services"].append(tmpl_data)
        elif name in ["react-client", "rails-ui-kit", "static-landing"]:
            buckets["Frontend & UI"].append(tmpl_data)
        elif name.startswith("mobile-"):
            buckets["Mobile App"].append(tmpl_data)
        elif name == "data-pipeline":
            buckets["Data Engineering"].append(tmpl_data)
        elif name == "terraform-infra":
            buckets["Infrastructure"].append(tmpl_data)
        else:
            buckets["Other"].append(tmpl_data)

    # Remove empty categories
    buckets = {k: v for k, v in buckets.items() if v}
    
    # Track expansion state for each category (all start expanded)
    expansion_state = {category: True for category in buckets.keys()}

    # Interactive menu loop
    while True:
        # Display the interactive tree
        console.clear()
        _render_interactive_tree(buckets, expansion_state)
        
        # Build menu choices for toggling categories
        choices = []
        for category in buckets.keys():
            is_expanded = expansion_state.get(category, True)
            icon = "▼" if is_expanded else "►"
            count = len(buckets[category])
            action = "Collapse" if is_expanded else "Expand"
            choices.append(f"{icon} {action} {category} ({count})")
        
        choices.append("🔄 Expand All")
        choices.append("🔒 Collapse All")
        choices.append("Exit")

        selection = questionary.select(
            "[bold]Toggle Categories[/bold]",
            choices=choices,
        ).ask()

        if selection is None or selection == "Exit":
            break
        elif selection == "🔄 Expand All":
            expansion_state = {k: True for k in expansion_state.keys()}
        elif selection == "🔒 Collapse All":
            expansion_state = {k: False for k in expansion_state.keys()}
        else:
            # Extract category name from choice
            for category in buckets.keys():
                if category in selection:
                    expansion_state[category] = not expansion_state[category]
                    break
                input("[dim]Press Enter to continue...[/dim]")
