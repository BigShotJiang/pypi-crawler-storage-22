from foundry.constants import console, TIER_HIERARCHY, QUESTIONARY_STYLE, TEMPLATE_REGISTRY
from foundry.utils import get_templates, get_template_info
from foundry.auth import get_current_license_info
from rich.panel import Panel
from rich.tree import Tree
import questionary
import re


def _get_template_tech(name):
    """Get technology stack for a template by name."""
    # Map template names to tech descriptions
    tech_map = {
        "python-saas": "Python (FastAPI/SQLAlchemy)",
        "rails-api": "Ruby on Rails",
        "react-client": "React/Vite",
        "rails-ui-kit": "Rails + ViewComponent",
        "static-landing": "Astro (Static Site)",
        "mobile-android": "Android (Kotlin/Compose)",
        "mobile-ios": "iOS (Swift/SwiftUI)",
        "data-pipeline": "Data Stack (dbt + Python)",
        "terraform-infra": "Terraform (Multi-cloud)",
        "wiring": "Docker Orchestration",
    }
    return tech_map.get(name, "Multi-tech Stack")


def _strip_markup(text):
    """Remove Rich markup tags from text."""
    return re.sub(r'\[/?[^\]]+\]', '', text)


def _render_templates_tree(buckets):
    """Render a tree view with all categories expanded showing available templates."""
    tree = Tree("[bold green]Seed & Source Inventory[/bold green]")

    for category, items in buckets.items():
        if not items:
            continue

        count = len(items)
        cat_node = tree.add(f"[bold yellow]▼ {category} ({count})[/bold yellow]")
        
        for item in items:
            node = cat_node.add(f"[bold cyan]{item['name']}[/bold cyan]")
            # Show tier badge in tree
            if item['tier'] != "free":
                tier_display = f"(🔐 {item['tier'].upper()})" if item['locked'] else f"(✅ {item['tier'].upper()})"
                node.add(f"[yellow]{tier_display}[/yellow]")
            # Show tech
            tech = _get_template_tech(item['name'])
            node.add(f"[dim]{tech}[/dim]")

    console.print(Panel(tree, title="Available Templates", border_style="green"))


def run_explore():
    """Interactive template explorer with expanded tree and selectable templates."""
    # Get user info for tier checking
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)

    # Group templates by category
    buckets = {
        "Backend Services": [],
        "Frontend & UI": [],
        "Mobile App": [],
        "Data Engineering": [],
        "Infrastructure": [],
        "Other": [],
    }

    templates = get_templates()

    for tmpl in templates:
        name = tmpl.name
        # Fetch metadata to get the tier
        info = get_template_info(name)
        tmpl_tier = info.get("tier", "free").lower()
        tmpl_rank = TIER_HIERARCHY.get(tmpl_tier, 0)

        # Check if locked
        locked = tmpl_rank > user_rank
        
        # Simple menu label (no markup for questionary)
        menu_label = name
        if locked:
            menu_label = f"{name} 🔐"
        elif tmpl_tier != "free":
            menu_label = f"{name} ✅"
        
        # Store template data for processing
        tmpl_data = {
            "name": name,
            "menu_label": menu_label,
            "tier": tmpl_tier,
            "locked": locked,
        }

        if name in ["python-saas", "rails-api"]:
            buckets["Backend Services"].append(tmpl_data)
        elif name in ["react-client", "rails-ui-kit", "static-landing"]:
            buckets["Frontend & UI"].append(tmpl_data)
        elif name.startswith("mobile-"):
            buckets["Mobile App"].append(tmpl_data)
        elif name == "data-pipeline":
            buckets["Data Engineering"].append(tmpl_data)
        elif name == "terraform-infra":
            buckets["Infrastructure"].append(tmpl_data)
        else:
            buckets["Other"].append(tmpl_data)

    # Remove empty categories
    buckets = {k: v for k, v in buckets.items() if v}

    # Display the tree with all categories expanded
    console.clear()
    _render_templates_tree(buckets)
    
    # Build flat list of templates for selection (without Rich markup for questionary)
    template_choices = []
    for category, items in buckets.items():
        for item in items:
            template_choices.append((item['name'], item['menu_label']))
    
    # Add back button
    template_choices.append(("back", "← Back to Main Menu"))

    # Show template selection menu
    selected = questionary.select(
        "Select a template to view details:",
        choices=[questionary.Choice(label, value=name) for name, label in template_choices],
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()

    if selected is None or selected == "back":
        return

