# ssh-tunnel-gateway

Single Python package that ships both the server and agent CLIs.

## Install (editable)

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .
```

## Server

```bash
API_KEY="change-me" ssh-tunnel-server
```

## Agent

```bash
ssh-tunnel-agent --api-key change-me --endpoint http://server:12000
```

## Build & Upload

```bash
make build
make upload
```
