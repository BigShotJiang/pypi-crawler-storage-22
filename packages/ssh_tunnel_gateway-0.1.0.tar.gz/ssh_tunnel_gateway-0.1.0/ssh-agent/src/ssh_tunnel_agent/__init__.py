from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _version
from pathlib import Path

__all__ = ["__version__"]


def _read_version_file() -> str:
    for parent in Path(__file__).resolve().parents:
        candidate = parent / "VERSION"
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8").strip()
    return "0.0.0"


try:
    __version__ = _version("ssh-tunnel-gateway")
except PackageNotFoundError:
    __version__ = _read_version_file()
