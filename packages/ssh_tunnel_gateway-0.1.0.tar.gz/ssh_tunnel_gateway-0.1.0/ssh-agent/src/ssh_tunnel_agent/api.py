from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests

from .crypto import EncryptedBlob


@dataclass(frozen=True)
class RegisterResponse:
    agent_id: str
    port_b: int
    ssh_user: str
    public_key: str
    encrypted_private_key: EncryptedBlob


def register_agent(api_url: str, api_key: str, agent_id: str | None) -> RegisterResponse:
    payload: dict[str, Any] = {}
    if agent_id:
        payload["agent_id"] = agent_id

    response = requests.post(
        api_url,
        json=payload,
        headers={"X-API-Key": api_key},
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()

    encrypted = EncryptedBlob(
        kdf=data["encrypted_private_key"]["kdf"],
        salt_b64=data["encrypted_private_key"]["salt_b64"],
        nonce_b64=data["encrypted_private_key"]["nonce_b64"],
        ciphertext_b64=data["encrypted_private_key"]["ciphertext_b64"],
        n=int(data["encrypted_private_key"]["n"]),
        r=int(data["encrypted_private_key"]["r"]),
        p=int(data["encrypted_private_key"]["p"]),
    )

    return RegisterResponse(
        agent_id=data["agent_id"],
        port_b=int(data["port_b"]),
        ssh_user=data["ssh_user"],
        public_key=data["public_key"],
        encrypted_private_key=encrypted,
    )
