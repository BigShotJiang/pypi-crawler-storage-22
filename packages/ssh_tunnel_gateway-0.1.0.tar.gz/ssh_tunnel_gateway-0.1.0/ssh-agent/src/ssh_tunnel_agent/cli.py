from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from .api import register_agent
from .config import get_settings
from .crypto import decrypt_private_key
from .tunnel import TunnelConfig, ensure_key_permissions, run_tunnel


def _write_key(path: Path, private_key: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(private_key)
    ensure_key_permissions(path)


def main() -> None:
    parser = argparse.ArgumentParser(description="ssh-tunnel-agent")
    parser.add_argument(
        "-d",
        "--systemd",
        action="store_true",
        help="Run once and let systemd handle restarts",
    )
    parser.add_argument(
        "--endpoint",
        help="Server registration endpoint (overrides API_URL)",
    )
    parser.add_argument(
        "--api-key",
        help="API key (overrides API_KEY)",
    )
    parser.add_argument(
        "--agent-id",
        help="Optional agent id (overrides AGENT_ID)",
    )
    args = parser.parse_args()

    if args.endpoint:
        os.environ["API_URL"] = args.endpoint
    if args.api_key:
        os.environ["API_KEY"] = args.api_key
    if args.agent_id:
        os.environ["AGENT_ID"] = args.agent_id

    try:
        settings = get_settings()
    except RuntimeError as exc:
        message = str(exc)
        if "API_KEY must be set" in message:
            print("Missing API key configuration.", file=sys.stderr)
            print("Set API_KEY before starting the agent, or pass --api-key.", file=sys.stderr)
            print("Examples:", file=sys.stderr)
            print("  API_KEY=change-me ssh-tunnel-agent", file=sys.stderr)
            print("  ssh-tunnel-agent --api-key change-me --endpoint http://server:12000", file=sys.stderr)
            return
        raise

    response = register_agent(settings.api_url, settings.api_key, settings.agent_id)
    private_key = decrypt_private_key(response.encrypted_private_key, settings.api_key)
    _write_key(settings.key_path, private_key)

    ssh_user = settings.ssh_user or response.ssh_user
    if not ssh_user:
        raise RuntimeError("SSH user not provided by server or SSH_USER")

    tunnel_config = TunnelConfig(
        ssh_user=ssh_user,
        ssh_host=settings.ssh_host,
        ssh_port=settings.ssh_port,
        port_b=response.port_b,
        local_target_host=settings.local_target_host,
        local_target_port=settings.local_target_port,
        key_path=settings.key_path,
        strict_host_key_checking=settings.strict_host_key_checking,
        known_hosts_path=settings.known_hosts_path,
        ssh_options=settings.ssh_options,
        reconnect_delay=settings.reconnect_delay,
    )
    exit_code = run_tunnel(tunnel_config, reconnect=not args.systemd)
    if exit_code != 0 and args.systemd:
        sys.exit(exit_code)


if __name__ == "__main__":
    main()
