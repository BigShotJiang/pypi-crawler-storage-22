from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from urllib.parse import urlparse, urlunparse


@dataclass(frozen=True)
class Settings:
    api_key: str
    api_url: str
    agent_id: str | None
    state_dir: Path
    key_path: Path
    ssh_user: str | None
    ssh_host: str
    ssh_port: int
    local_target_host: str
    local_target_port: int
    strict_host_key_checking: str
    known_hosts_path: Path | None
    ssh_options: tuple[str, ...]
    reconnect_delay: int


def get_settings() -> Settings:
    api_key = os.getenv("API_KEY")
    if not api_key:
        raise RuntimeError("API_KEY must be set")

    api_url = _normalize_api_url(
        os.getenv("API_URL", "http://127.0.0.1:12000/v1/agents/register")
    )
    agent_id = os.getenv("AGENT_ID") or None

    state_dir = Path(os.getenv("STATE_DIR", str(Path.cwd() / "data")))
    key_path = Path(os.getenv("KEY_PATH", str(state_dir / "agent.pem")))

    ssh_user = os.getenv("SSH_USER") or None
    ssh_host = os.getenv("SSH_HOST", "127.0.0.1")
    ssh_port = int(os.getenv("SSH_PORT", "22"))

    local_target_host = os.getenv("LOCAL_TARGET_HOST", "127.0.0.1")
    local_target_port = int(os.getenv("LOCAL_TARGET_PORT", "22"))

    strict_host_key_checking = os.getenv("SSH_STRICT_HOST_KEY_CHECKING", "accept-new")
    known_hosts_raw = os.getenv("SSH_KNOWN_HOSTS")
    known_hosts_path = Path(known_hosts_raw) if known_hosts_raw else None

    ssh_options_raw = os.getenv("SSH_OPTIONS", "")
    ssh_options = tuple(part for part in ssh_options_raw.split() if part)

    reconnect_delay = int(os.getenv("RECONNECT_DELAY", "5"))

    return Settings(
        api_key=api_key,
        api_url=api_url,
        agent_id=agent_id,
        state_dir=state_dir,
        key_path=key_path,
        ssh_user=ssh_user,
        ssh_host=ssh_host,
        ssh_port=ssh_port,
        local_target_host=local_target_host,
        local_target_port=local_target_port,
        strict_host_key_checking=strict_host_key_checking,
        known_hosts_path=known_hosts_path,
        ssh_options=ssh_options,
        reconnect_delay=reconnect_delay,
    )


def _normalize_api_url(raw: str) -> str:
    url = raw.strip()
    if "://" not in url:
        url = f"http://{url}"
    parsed = urlparse(url)
    path = parsed.path or ""
    if path in ("", "/"):
        path = "/v1/agents/register"
    return urlunparse(parsed._replace(path=path))
