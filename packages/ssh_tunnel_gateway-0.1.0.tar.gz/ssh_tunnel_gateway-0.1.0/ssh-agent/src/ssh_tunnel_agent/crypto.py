from __future__ import annotations

import base64
from dataclasses import dataclass

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


@dataclass(frozen=True)
class EncryptedBlob:
    kdf: str
    salt_b64: str
    nonce_b64: str
    ciphertext_b64: str
    n: int
    r: int
    p: int


def decrypt_private_key(blob: EncryptedBlob, api_key: str) -> bytes:
    if blob.kdf != "scrypt":
        raise ValueError("Unsupported KDF")

    salt = base64.b64decode(blob.salt_b64)
    nonce = base64.b64decode(blob.nonce_b64)
    ciphertext = base64.b64decode(blob.ciphertext_b64)

    kdf = Scrypt(salt=salt, length=32, n=blob.n, r=blob.r, p=blob.p)
    key = kdf.derive(api_key.encode("utf-8"))

    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ciphertext, None)
