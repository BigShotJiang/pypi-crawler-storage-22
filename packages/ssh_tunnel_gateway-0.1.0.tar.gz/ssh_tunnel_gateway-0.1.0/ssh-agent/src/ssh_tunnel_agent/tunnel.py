from __future__ import annotations

import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class TunnelConfig:
    ssh_user: str
    ssh_host: str
    ssh_port: int
    port_b: int
    local_target_host: str
    local_target_port: int
    key_path: Path
    strict_host_key_checking: str
    known_hosts_path: Path | None
    ssh_options: tuple[str, ...]
    reconnect_delay: int


def _build_ssh_command(config: TunnelConfig) -> list[str]:
    cmd = [
        "ssh",
        "-N",
        "-T",
        "-i",
        str(config.key_path),
        "-p",
        str(config.ssh_port),
        "-o",
        "ExitOnForwardFailure=yes",
        "-o",
        f"ServerAliveInterval=30",
        "-o",
        f"ServerAliveCountMax=3",
        "-o",
        f"StrictHostKeyChecking={config.strict_host_key_checking}",
    ]

    if config.known_hosts_path is not None:
        cmd.extend(["-o", f"UserKnownHostsFile={config.known_hosts_path}"])

    if config.ssh_options:
        cmd.extend(list(config.ssh_options))

    reverse = f"0.0.0.0:{config.port_b}:{config.local_target_host}:{config.local_target_port}"
    cmd.extend(["-R", reverse])
    cmd.append(f"{config.ssh_user}@{config.ssh_host}")
    return cmd


def run_tunnel(config: TunnelConfig, reconnect: bool = True) -> int:
    cmd = _build_ssh_command(config)
    while True:
        process = subprocess.Popen(cmd)
        try:
            return_code = process.wait()
        except KeyboardInterrupt:
            process.terminate()
            raise

        if not reconnect or return_code == 0:
            return return_code

        time.sleep(config.reconnect_delay)


def ensure_key_permissions(key_path: Path) -> None:
    os.chmod(key_path, 0o600)
