from __future__ import annotations

import hmac
import logging
from datetime import datetime, timezone
from uuid import uuid4

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from .auth_keys import append_authorized_key
from .config import get_settings
from .crypto import EncryptedBlob, encrypt_private_key, generate_rsa_keypair
from .ports import find_available_port
from .store import locked_state

settings = get_settings()
app = FastAPI(title="ssh-tunnel-server")
logger = logging.getLogger("ssh_tunnel_server")


class RegisterRequest(BaseModel):
    agent_id: str | None = Field(default=None, description="Optional agent identifier")


class EncryptedPrivateKey(BaseModel):
    kdf: str
    salt_b64: str
    nonce_b64: str
    ciphertext_b64: str
    n: int
    r: int
    p: int


class RegisterResponse(BaseModel):
    agent_id: str
    port_b: int
    ssh_user: str
    public_key: str
    encrypted_private_key: EncryptedPrivateKey


def _match_key(candidate: str) -> bool:
    for key in settings.api_keys:
        if hmac.compare_digest(candidate, key):
            return True
    return False


def authenticate(api_key: str | None = Header(default=None, alias=settings.api_key_header)) -> str:
    if not api_key:
        raise HTTPException(status_code=401, detail="Missing API key")
    if not _match_key(api_key):
        raise HTTPException(status_code=403, detail="Invalid API key")
    return api_key


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/agents/register", response_model=RegisterResponse)
async def register_agent(
    payload: RegisterRequest,
    api_key: str = Depends(authenticate),
) -> RegisterResponse:
    agent_id = payload.agent_id or str(uuid4())
    state_path = settings.state_dir / "allocations.json"

    with locked_state(state_path) as state:
        used_ports = [item["port_b"] for item in state.get("allocations", [])]
        port_b = find_available_port(settings.port_range_start, settings.port_range_end, used_ports)

        private_pem, public_key = generate_rsa_keypair()
        encrypted = encrypt_private_key(private_pem, api_key)

        comment = f"tunnel-agent={agent_id} port_b={port_b}"
        append_authorized_key(settings.authorized_keys_path, public_key, comment)

        allocation = {
            "agent_id": agent_id,
            "port_b": port_b,
            "public_key": public_key,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        state.setdefault("allocations", []).append(allocation)

    public_host = _public_host_for_log()
    logger.info(
        "Now open port %s for clients: ssh -p %s %s@%s (agent %s)",
        port_b,
        port_b,
        settings.ssh_user,
        public_host,
        agent_id,
    )

    return RegisterResponse(
        agent_id=agent_id,
        port_b=port_b,
        ssh_user=settings.ssh_user,
        public_key=public_key,
        encrypted_private_key=EncryptedPrivateKey(**encrypted.__dict__),
    )


def _public_host_for_log() -> str:
    if settings.ssh_public_host:
        return settings.ssh_public_host
    if settings.server_host and settings.server_host not in {"0.0.0.0", "::"}:
        return settings.server_host
    return "SERVER_HOST"
