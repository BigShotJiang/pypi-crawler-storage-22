from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None


def append_authorized_key(
    authorized_keys_path: Path,
    public_key: str,
    comment: Optional[str] = None,
) -> None:
    if fcntl is None:
        raise RuntimeError("File locking is not supported on this platform")

    authorized_keys_path.parent.mkdir(parents=True, exist_ok=True)
    if not authorized_keys_path.exists():
        authorized_keys_path.touch(mode=0o600)
    else:
        os.chmod(authorized_keys_path, 0o600)

    entry = public_key
    if comment:
        entry = f"{entry} {comment}"

    with open(authorized_keys_path, "a", encoding="utf-8") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        handle.write(entry + "\n")
        handle.flush()
        os.fsync(handle.fileno())
        fcntl.flock(handle, fcntl.LOCK_UN)
