from __future__ import annotations

import argparse
import os
import sys

import uvicorn

from .config import get_settings


def main() -> None:
    parser = argparse.ArgumentParser(description="ssh-tunnel-server")
    parser.add_argument(
        "-d",
        "--systemd",
        action="store_true",
        help="Run in foreground without reload; systemd should handle restarts",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload (dev only)",
    )
    args = parser.parse_args()

    try:
        settings = get_settings()
    except RuntimeError as exc:
        message = str(exc)
        if "API_KEY or API_KEYS must be set" in message:
            print("Missing API key configuration.", file=sys.stderr)
            print("", file=sys.stderr)
            print("Set one of the following environment variables:", file=sys.stderr)
            print("  API_KEY=\"your-key\"", file=sys.stderr)
            print("  API_KEYS=\"key1,key2\"", file=sys.stderr)
            print("", file=sys.stderr)
            print("Example:", file=sys.stderr)
            print("  API_KEY=\"change-me\" ssh-tunnel-server", file=sys.stderr)
            return
        raise
    if args.systemd:
        reload_enabled = False
    elif args.reload:
        reload_enabled = True
    else:
        reload_enabled = os.getenv("RELOAD", "0") == "1"
    uvicorn.run(
        "ssh_tunnel_server.app:app",
        host=settings.server_host,
        port=settings.server_port,
        reload=reload_enabled,
        log_level="info",
    )


if __name__ == "__main__":
    main()
