from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Iterable
import getpass


@dataclass(frozen=True)
class Settings:
    api_key_header: str
    api_keys: tuple[str, ...]
    authorized_keys_path: Path
    state_dir: Path
    port_range_start: int
    port_range_end: int
    server_host: str
    server_port: int
    ssh_user: str
    ssh_public_host: str | None


def _split_keys(raw: str | None) -> Iterable[str]:
    if not raw:
        return []
    return [part.strip() for part in raw.split(",") if part.strip()]


def get_settings() -> Settings:
    api_key_header = os.getenv("API_KEY_HEADER", "X-API-Key")

    keys = []
    keys.extend(_split_keys(os.getenv("API_KEY")))
    keys.extend(_split_keys(os.getenv("API_KEYS")))
    if not keys:
        raise RuntimeError("API_KEY or API_KEYS must be set")

    authorized_keys_path = Path(
        os.getenv("AUTHORIZED_KEYS_PATH", str(Path.home() / ".ssh" / "authorized_keys"))
    )
    state_dir = Path(os.getenv("STATE_DIR", str(Path.cwd() / "data")))

    port_range_start = int(os.getenv("PORT_RANGE_START", "20000"))
    port_range_end = int(os.getenv("PORT_RANGE_END", "40000"))
    if port_range_end <= port_range_start:
        raise RuntimeError("PORT_RANGE_END must be greater than PORT_RANGE_START")

    server_host = os.getenv("SERVER_HOST", "0.0.0.0")
    server_port = int(os.getenv("SERVER_PORT", "12000"))
    ssh_user = os.getenv("SSH_USER", getpass.getuser())
    ssh_public_host = os.getenv("SSH_PUBLIC_HOST") or None

    return Settings(
        api_key_header=api_key_header,
        api_keys=tuple(dict.fromkeys(keys)),
        authorized_keys_path=authorized_keys_path,
        state_dir=state_dir,
        port_range_start=port_range_start,
        port_range_end=port_range_end,
        server_host=server_host,
        server_port=server_port,
        ssh_user=ssh_user,
        ssh_public_host=ssh_public_host,
    )
