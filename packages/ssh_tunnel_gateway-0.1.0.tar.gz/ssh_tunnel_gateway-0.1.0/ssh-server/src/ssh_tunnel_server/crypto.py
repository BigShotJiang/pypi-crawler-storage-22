from __future__ import annotations

import base64
import os
from dataclasses import dataclass

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


@dataclass(frozen=True)
class EncryptedBlob:
    kdf: str
    salt_b64: str
    nonce_b64: str
    ciphertext_b64: str
    n: int
    r: int
    p: int


def generate_rsa_keypair() -> tuple[bytes, str]:
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_key = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    )
    return private_pem, public_key.decode("ascii")


def encrypt_private_key(private_pem: bytes, api_key: str) -> EncryptedBlob:
    salt = os.urandom(16)
    n = 2**14
    r = 8
    p = 1
    kdf = Scrypt(salt=salt, length=32, n=n, r=r, p=p)
    key = kdf.derive(api_key.encode("utf-8"))

    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, private_pem, None)

    return EncryptedBlob(
        kdf="scrypt",
        salt_b64=base64.b64encode(salt).decode("ascii"),
        nonce_b64=base64.b64encode(nonce).decode("ascii"),
        ciphertext_b64=base64.b64encode(ciphertext).decode("ascii"),
        n=n,
        r=r,
        p=p,
    )
