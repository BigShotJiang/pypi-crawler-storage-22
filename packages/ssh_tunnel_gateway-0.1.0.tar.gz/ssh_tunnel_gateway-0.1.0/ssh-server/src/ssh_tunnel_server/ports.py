from __future__ import annotations

import random
import socket
from typing import Iterable


def is_port_free(port: int, bind_address: str = "0.0.0.0") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind((bind_address, port))
        except OSError:
            return False
    return True


def find_available_port(
    start: int,
    end: int,
    used_ports: Iterable[int],
) -> int:
    used_set = set(used_ports)
    candidates = list(range(start, end + 1))
    random.shuffle(candidates)
    for port in candidates:
        if port in used_set:
            continue
        if is_port_free(port):
            return port
    raise RuntimeError("No free port available in configured range")
