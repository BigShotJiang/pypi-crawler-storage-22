from __future__ import annotations

import json
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None


def _default_state() -> dict:
    return {"allocations": []}


@contextmanager
def locked_state(state_path: Path) -> Iterator[dict]:
    state_path.parent.mkdir(parents=True, exist_ok=True)
    if fcntl is None:
        raise RuntimeError("File locking is not supported on this platform")

    with open(state_path, "a+", encoding="utf-8") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        handle.seek(0)
        raw = handle.read().strip()
        state = json.loads(raw) if raw else _default_state()
        try:
            yield state
        finally:
            handle.seek(0)
            handle.truncate()
            json.dump(state, handle, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
            fcntl.flock(handle, fcntl.LOCK_UN)
