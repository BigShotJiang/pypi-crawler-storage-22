"""
SSHer - Ultimate SSH Configuration Manager
Developed by Inioluwa Adeyinka
"""

__version__ = "3.0.0"
APP_NAME = "SSHer"
DEVELOPER = "Inioluwa Adeyinka"
