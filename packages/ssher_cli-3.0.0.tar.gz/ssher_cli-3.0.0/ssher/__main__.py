"""Allow running as python -m ssher."""
from ssher.cli import main

main()
