# 🔐 Mottu SSO Tool

Professional SSO authentication tool for the Mottu engineering team. Get authentication tokens quickly and easily.

**✨ Works out of the box** - Includes a default test user, no configuration needed to get started!

## 🚀 Quick Start

```bash
# Clone or download the repository
cd sso

# Install (one command!)
./install.sh

# Or use Make
make install

# Use it!
sso io teste
# (ou ./sso-local.sh se estiver no diretório do projeto)
```

That's it! The tool works immediately with the default test user (`teste@mottu.dev`).

## 📋 Features

- ✅ **Works out of the box** - Default test user included
- ✅ **Interactive mode** - Beautiful CLI interface
- ✅ **Command line mode** - Perfect for scripts and automation
- ✅ **Multiple environments** - Cloud and IO support
- ✅ **Multiple auth types** - Password and client credentials
- ✅ **Auto clipboard** - Tokens copied automatically
- ✅ **Easy distribution** - Simple installation for the team

## 🌍 Environments

- **Cloud Environment**: `https://sso.mottu.cloud/realms/Internal`
- **IO Environment**: `https://sso.mottu.io/realms/Admin`

## Configuration

The tool uses **YAML configuration file** (`sso_config.yaml`) in the same directory as the script. This is the modern Python way - clean, readable, and supports comments.

**Why YAML?** YAML is the standard for configuration files in modern Python applications (Docker Compose, Kubernetes, Ansible, etc.). It's much more readable than JSON and allows comments.

**Example `sso_config.yaml` file:**
```yaml
# SSO Authentication Configuration
# All users are configured in this YAML file

cloud:
  rpa:
    name: RPA User (Cloud)
    auth_type: password
    email: rpa.subsidios@mottu.com.br
    password: U3VV11H7@
  caetano:
    name: Caetano (Cloud)
    auth_type: password
    email: caetano@mottu.com.br
    password: senha123

io:
  warehouse:
    name: Warehouse User (IO)
    auth_type: password
    email: warehouse@mottu.com.br
    password: Mottu@123
  caetano:
    name: Caetano (IO)
    auth_type: password
    email: caetano.minuzzo@mottu.com.br
    password: C7TUV5HU@
  teste_dev:
    name: Teste Dev (IO)
    auth_type: password
    email: teste@mottu.dev
    password: Mottu@123
  kb_gateway:
    name: KB Gateway Auto Client (IO)
    auth_type: client_credentials
    client_id: kb-gateway-auto-client
    client_secret: IlBLDXuYxWo1NJrgZLYYGH6gAhhamHqH
  ai_gateway:
    name: AI Gateway Auto Client (IO)
    auth_type: client_credentials
    client_id: ai-gateway-auto-client
    client_secret: GTdt68PcULtKp8oItTKRZQbMMsjP0Yg2
```

**YAML Structure:**
- Top level: environment keys (`cloud`, `io`)
- Second level: user keys (e.g., `rpa`, `caetano`, `warehouse`)
- User object fields:
  - `name`: Display name for the user
  - `auth_type`: `password` or `client_credentials`
  - For password auth: `email` and `password`
  - For client_credentials auth: `client_id` and `client_secret`

**Advantages:**
- ✅ **Readable**: Much cleaner than JSON in env vars
- ✅ **Comments**: Can add comments to document users
- ✅ **Dynamic**: Add/remove users without code changes
- ✅ **Scalable**: Easy to manage many users
- ✅ **Standard**: YAML is the modern Python standard
- ✅ **Version control**: Easy to track changes (with proper security)

## Authentication Types

The tool supports two types of authentication:

### Password Authentication
- Uses email and password credentials
- Authenticates as a specific user
- Uses the `password` grant type

### Client Credentials Authentication
- Uses client_id and client_secret credentials
- Authenticates as an application/service
- Uses the `client_credentials` grant type
- Ideal for service-to-service authentication

## User Organization

### Cloud Environment Users
- **RPA User**: `rpa.subsidios@mottu.com.br` (Cloud only)
- **Caetano**: `caetano.minuzzo@mottu.com.br` (Cloud)

### IO Environment Users
- **Warehouse User**: `warehouse@mottu.com.br` (IO only)
- **Caetano**: `caetano.minuzzo@mottu.com.br` (IO)
- **Teste Dev**: `teste@mottu.dev` (IO)
- **KB Gateway Auto Client**: `kb-gateway-auto-client` (Client Credentials - IO only)
- **AI Gateway Auto Client**: `ai-gateway-auto-client` (Client Credentials - IO only)


## 📦 Installation

### Option 1: Install from Private PyPI (Recommended for Team)

```bash
# Configure pip to use private PyPI (one-time setup)
pip config set global.extra-index-url https://pypi.mottu.io/simple/

# Install the tool
pip install sso-cli

# Use it!
sso io teste
```

### Option 2: Local Development Installation

```bash
# Automated installation
./install.sh

# Or using Make
make install
```

### Option 3: Manual Installation

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## 🎯 Usage

### Interactive Mode

```bash
./sso
# or
python3 sso_auth.py
```

Then select your environment and user from the menu.

### Command Line Mode

```bash
# Get token for test user (works out of the box!)
./sso io teste

# Use in scripts
TOKEN=$(./sso io teste)
curl -H "Authorization: Bearer $TOKEN" https://api.example.com
```

### Available Commands

```bash
# Interactive mode
./sso

# Get token for specific user
./sso io teste
./sso cloud rpa

# Show help
./sso --help
```

## ⚙️ Configuration

**The tool works out of the box** with a default test user. No configuration needed!

```bash
# Works immediately after installation!
sso io teste
```

### Adding Your Own Users (Optional)

To add your own users, create a configuration file. See [SETUP.md](SETUP.md) for detailed instructions.

**Quick setup:**

```bash
# Copy the example template
cp sso_config.yaml.example sso_config.yaml

# Edit and add your users
vim sso_config.yaml
```

## Examples

### Command Line Usage
```bash
# Get token for Caetano on IO environment
sso io caetano

# Get token for RPA user on Cloud environment  
sso cloud rpa

# Get token for KB Gateway client on IO environment
sso io kb_gateway

# Get token for AI Gateway client on IO environment
sso io ai_gateway

# Use in curl commands
curl -H "Authorization: Bearer $(sso io caetano)" https://api.example.com
curl -H "Authorization: Bearer $(sso io kb_gateway)" https://api.example.com
curl -H "Authorization: Bearer $(sso io ai_gateway)" https://api.example.com
```

### Interactive Mode
```bash
# Run without arguments for interactive selection
sso
```

## Features

- **Modern CLI Interface**: Beautiful, colorful interface using Rich library
- **Environment-based user selection**: Users are filtered by environment
- **Multiple Authentication Types**: Supports both password and client credentials authentication
- **YAML Configuration**: Clean, readable YAML config file (`sso_config.yaml`)
- **Automatic clipboard copy**: Tokens are automatically copied to clipboard
- **Clean output**: No verbose HTTP logs or unnecessary instructions
- **Error handling**: Clear, styled error messages for missing configurations
- **User info extraction**: Displays user information from JWT tokens
- **Shell compatibility**: Works with all modern terminals

## 📋 Requirements

- Python 3.7+
- pip

All other dependencies are installed automatically during installation.

## 🛠️ Development

```bash
# Install with dev dependencies
make install-dev

# Run tests
make test

# Clean build artifacts
make clean

# Show all available commands
make help
```

## 📦 Publishing & Versioning

### Increment Version and Publish

The easiest way to bump the version and publish:

```bash
# Bump patch version (1.0.0 -> 1.0.1) - default
make bump
# or
./bump_and_publish.sh patch

# Bump minor version (1.0.0 -> 1.1.0)
make bump-minor
# or
./bump_and_publish.sh minor

# Bump major version (1.0.0 -> 2.0.0)
make bump-major
# or
./bump_and_publish.sh major
```

### Publish with Specific Version

```bash
# Publish with a specific version
make publish-version VERSION=1.0.2
# or
./publish.sh 1.0.2
```

### Manual Publishing

```bash
# Set PyPI credentials
export PYPI_USERNAME=mottu
export PYPI_PASSWORD=your_password

# Public PyPI with API token
export PYPI_ORG_TOKEN=pypi-...
export PUBLIC_PYPI_USERNAME=__token__
export PUBLIC_PYPI_PASSWORD=$PYPI_ORG_TOKEN

# Publish (private + public)
make publish
# or
./publish.sh
```

### Reinstall After Publishing

After publishing a new version, users can upgrade with:

```bash
# Upgrade to latest version (private)
pip install --upgrade --index-url https://pypi.mottu.io/simple/ sso-cli

# Or from public PyPI
pip install --upgrade sso-cli

# Verify installation
pip show sso-cli
```

## 📁 Project Structure

```
sso/
├── sso_auth.py          # Main application
├── sso_config.yaml      # Your configuration (optional)
├── sso_config.yaml.example  # Configuration template
├── install.sh           # Installation script
├── Makefile            # Common commands
├── requirements.txt    # Python dependencies
├── pyproject.toml      # Package configuration
└── README.md           # This file
```

## CLI Improvements

The new interface features:
- **Clean menus**: No verbose instructions cluttering the interface
- **Styled panels**: Beautiful bordered panels for better visual organization
- **Color coding**: Green for success, red for errors, blue for information
- **Suppressed logs**: HTTP request logs are hidden for cleaner output
- **Modern prompts**: Simple number-based selection instead of arrow key navigation