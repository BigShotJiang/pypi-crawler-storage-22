#!/usr/bin/env python3
"""
Interactive SSO Authentication Script
Allows users to select environment and user credentials to get authentication tokens.

Environment-based Configuration:
- Users are now organized by environment (cloud/io) for better clarity
- Each environment has its own set of users with environment-specific credentials
- Supports both new environment-based config and legacy config for backward compatibility

Example .env structure:
CLOUD_RPA_EMAIL=rpa.subsidios@mottu.com.br
CLOUD_RPA_PASSWORD=U3VV11H7@
CLOUD_CAETANO_EMAIL=caetano.minuzzo@mottu.com.br
CLOUD_CAETANO_PASSWORD="C7TUV5HU@"

IO_WAREHOUSE_EMAIL=warehouse@mottu.com.br
IO_WAREHOUSE_PASSWORD=Mottu@123
IO_CAETANO_EMAIL=caetano.minuzzo@mottu.com.br
IO_CAETANO_PASSWORD="C7TUV5HU@"
"""

import os
import sys
import asyncio
import base64
import json
import httpx
import logging
import argparse
from typing import Dict, Any, Optional, List
from dotenv import load_dotenv
import pyperclip
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.text import Text
from rich import print as rprint
from rich.prompt import Confirm
import inquirer

# Configure logging - suppress HTTP logs for cleaner output
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)
# Suppress httpx logs
logging.getLogger("httpx").setLevel(logging.WARNING)

# Initialize Rich console
console = Console()

# Environment configurations
ENVIRONMENTS = {
    "cloud": {
        "name": "Cloud",
        "sso_url": "https://sso.mottu.cloud/realms/Internal"
    },
    "io": {
        "name": "IO",
        "sso_url": "https://sso.mottu.io/realms/Admin"
    }
}

# Environment-based user configurations
# Users are now organized by environment for better clarity
ENVIRONMENT_USERS = {
    "cloud": {
        "rpa": {
            "name": "RPA User (Cloud)",
            "email_key": "CLOUD_RPA_EMAIL",
            "password_key": "CLOUD_RPA_PASSWORD",
            "auth_type": "password"
        },
        "caetano": {
            "name": "Caetano (Cloud)",
            "email_key": "CLOUD_CAETANO_EMAIL", 
            "password_key": "CLOUD_CAETANO_PASSWORD",
            "auth_type": "password"
        }
    },
    "io": {
        "warehouse": {
            "name": "Warehouse User (IO)",
            "email_key": "IO_WAREHOUSE_EMAIL",
            "password_key": "IO_WAREHOUSE_PASSWORD",
            "auth_type": "password"
        },
        "caetano": {
            "name": "Caetano (IO)",
            "email_key": "IO_CAETANO_EMAIL",
            "password_key": "IO_CAETANO_PASSWORD",
            "auth_type": "password"
        },
        "teste_dev": {
            "name": "Teste Dev (IO)",
            "email_key": "IO_TESTE_DEV_EMAIL",
            "password_key": "IO_TESTE_DEV_PASSWORD",
            "auth_type": "password"
        },
        "kb_gateway": {
            "name": "KB Gateway Auto Client (IO)",
            "client_id_key": "IO_KB_CLIENT_ID",
            "client_secret_key": "IO_KB_CLIENT_SECRET",
            "auth_type": "client_credentials"
        },
        "ai_gateway": {
            "name": "AI Gateway Auto Client (IO)",
            "client_id_key": "IO_AI_CLIENT_ID",
            "client_secret_key": "IO_AI_CLIENT_SECRET",
            "auth_type": "client_credentials"
        }
    }
}

# Legacy user configurations (for backward compatibility)
LEGACY_USERS = {
    "warehouse": {
        "name": "Warehouse User (Legacy)",
        "email_key": "WAREHOUSE_EMAIL",
        "password_key": "WAREHOUSE_PASSWORD"
    },
    "rpa": {
        "name": "RPA User (Legacy)", 
        "email_key": "RPA_EMAIL",
        "password_key": "RPA_PASSWORD"
    },
    "caetano": {
        "name": "Caetano (Legacy)",
        "email_key": "CAETANO_EMAIL",
        "password_key": "CAETANO_PASSWORD"
    },
    "teste_dev": {
        "name": "Teste Dev (Legacy)",
        "email_key": "TESTE_DEV_EMAIL",
        "password_key": "TESTE_DEV_PASSWORD"
    }
}

class SSOAuthenticator:
    def __init__(self):
        self.env_vars = {}
        self.load_environment()
    
    def load_environment(self):
        """Load environment variables from .env file"""
        env_path = os.path.join(os.path.dirname(__file__), '.env')
        if os.path.exists(env_path):
            load_dotenv(env_path)
            logger.info("Loaded environment variables from .env file")
        else:
            logger.warning(".env file not found. Please create one based on .env.template")
        
        # Load all environment variables
        self.env_vars = dict(os.environ)
    
    def get_available_users_for_environment(self, environment: str) -> Dict[str, Dict[str, str]]:
        """Get available users for a specific environment"""
        return ENVIRONMENT_USERS.get(environment, {})
    
    def get_all_available_users(self) -> Dict[str, Dict[str, Dict[str, str]]]:
        """Get all available users organized by environment"""
        return ENVIRONMENT_USERS
    
    def get_user_credentials(self, environment: str, user_key: str) -> tuple[str, str, str]:
        """Get credentials for a specific user in a specific environment
        
        Returns:
            tuple: (credential1, credential2, auth_type) where:
                - For password auth: (email, password, "password")
                - For client_credentials auth: (client_id, client_secret, "client_credentials")
        """
        # First try the new environment-based configuration
        if environment in ENVIRONMENT_USERS and user_key in ENVIRONMENT_USERS[environment]:
            user_config = ENVIRONMENT_USERS[environment][user_key]
            auth_type = user_config.get("auth_type", "password")
            
            if auth_type == "client_credentials":
                client_id = self.env_vars.get(user_config["client_id_key"])
                client_secret = self.env_vars.get(user_config["client_secret_key"])
                
                if client_id and client_secret:
                    return client_id, client_secret, auth_type
            else:  # password auth
                email = self.env_vars.get(user_config["email_key"])
                password = self.env_vars.get(user_config["password_key"])
                
                if email and password:
                    return email, password, auth_type
        
        # Fallback to legacy configuration for backward compatibility
        if user_key in LEGACY_USERS:
            user_config = LEGACY_USERS[user_key]
            email = self.env_vars.get(user_config["email_key"])
            password = self.env_vars.get(user_config["password_key"])
            
            if email and password:
                logger.warning(f"Using legacy configuration for {user_config['name']}. "
                             f"Consider migrating to environment-based configuration.")
                return email, password, "password"
        
        # If we get here, no valid configuration was found
        available_users = list(ENVIRONMENT_USERS.get(environment, {}).keys())
        if available_users:
            raise ValueError(f"User '{user_key}' not found for environment '{environment}'. "
                           f"Available users: {', '.join(available_users)}")
        else:
            raise ValueError(f"No users configured for environment '{environment}'. "
                           f"Please check your .env file configuration.")
    
    async def get_token(self, environment: str, user_key: str) -> str:
        """Get authentication token for the specified environment and user"""
        env_config = ENVIRONMENTS[environment]
        cred1, cred2, auth_type = self.get_user_credentials(environment, user_key)
        
        token_url = f"{env_config['sso_url']}/protocol/openid-connect/token"
        
        # Prepare data based on authentication type
        if auth_type == "client_credentials":
            # Client credentials flow
            data = {
                "grant_type": "client_credentials",
                "client_id": cred1,  # client_id
                "client_secret": cred2  # client_secret
            }
        else:
            # Password flow (default)
            data = {
                "grant_type": "password",
                "client_id": "delivery-ops-frontend-client",  # Public client ID for the web app
                "username": cred1,  # email
                "password": cred2  # password
            }
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(token_url, data=data)
                response.raise_for_status()
                token_data = response.json()
                
                return token_data["access_token"]
        except httpx.HTTPError as e:
            logger.error(f"Failed to get token: {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response content: {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}")
            raise
    
    def extract_user_from_token(self, token: str) -> Dict[str, Any]:
        """Extract user information from a JWT token"""
        try:
            # JWT tokens have 3 parts: header.payload.signature
            parts = token.split('.')
            if len(parts) != 3:
                logger.error("Invalid JWT token format")
                return {}
            
            # Decode the payload (middle part)
            # Add padding if needed
            payload = parts[1]
            payload += '=' * (4 - len(payload) % 4) if len(payload) % 4 else ''
            
            # Decode base64
            decoded = base64.urlsafe_b64decode(payload)
            user_info = json.loads(decoded)
            
            return user_info
        except Exception as e:
            logger.error(f"Failed to extract user from token: {str(e)}")
            return {}


class ModernSelector:
    def __init__(self):
        self.console = Console()
    
    def select_from_list(self, title: str, options: List[str], description: str = None) -> int:
        """Selection using inquirer for proper arrow key navigation"""
        # Use inquirer for arrow key navigation with custom message
        questions = [
            inquirer.List('choice',
                         message=title,  # Use title as the message to avoid [?] prompt
                         choices=options,
                         carousel=True)
        ]
        
        try:
            answers = inquirer.prompt(questions)
            if answers is None:  # User pressed Ctrl+C
                self.console.print("\n[yellow]Exiting...[/yellow]")
                sys.exit(0)
            
            selected_option = answers['choice']
            return options.index(selected_option)
            
        except (KeyboardInterrupt, EOFError):
            self.console.print("\n[yellow]Exiting...[/yellow]")
            sys.exit(0)


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard if possible"""
    try:
        pyperclip.copy(text)
        return True
    except Exception as e:
        logger.warning(f"Failed to copy to clipboard: {e}")
        return False


def show_help():
    """Show help information with available environments and users"""
    console.print()
    help_panel = Panel(
        Text("🔐 SSO Authentication Tool - Help", style="bold green"),
        border_style="green"
    )
    console.print(help_panel)
    
    console.print("\n[bold]Usage:[/bold]")
    console.print("  sso [environment] [user]     # Get token for specific environment and user")
    console.print("  sso --help                   # Show this help")
    console.print("  sso                          # Interactive mode")
    
    console.print("\n[bold]Available Environments:[/bold]")
    for env_key, config in ENVIRONMENTS.items():
        console.print(f"  • [cyan]{env_key}[/cyan] - {config['name']}")
    
    console.print("\n[bold]Available Users by Environment:[/bold]")
    for env_key, users in ENVIRONMENT_USERS.items():
        console.print(f"\n[bold cyan]{env_key.upper()}:[/bold cyan]")
        for user_key, user_config in users.items():
            console.print(f"  • [yellow]{user_key}[/yellow] - {user_config['name']}")
    
    console.print("\n[bold]Examples:[/bold]")
    console.print("  sso io caetano               # Get token for Caetano on IO environment")
    console.print("  sso cloud rpa               # Get token for RPA user on Cloud environment")
    console.print("  curl -H \"Authorization: Bearer $(sso io caetano)\" https://api.example.com")
    
    console.print()


async def get_token_non_interactive(environment: str, user: str) -> str:
    """Get token in non-interactive mode"""
    authenticator = SSOAuthenticator()
    
    # Validate environment
    if environment not in ENVIRONMENTS:
        available_envs = ", ".join(ENVIRONMENTS.keys())
        raise ValueError(f"Environment '{environment}' not found. Available: {available_envs}")
    
    # Validate user for environment
    env_users = ENVIRONMENT_USERS.get(environment, {})
    if user not in env_users:
        available_users = ", ".join(env_users.keys()) if env_users else "none"
        raise ValueError(f"User '{user}' not found for environment '{environment}'. Available: {available_users}")
    
    # Get token
    token = await authenticator.get_token(environment, user)
    return token


async def main():
    """Main function"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description="SSO Authentication Tool",
        add_help=False  # We'll handle help manually
    )
    parser.add_argument('environment', nargs='?', help='Environment (cloud, io)')
    parser.add_argument('user', nargs='?', help='User name')
    parser.add_argument('--help', action='store_true', help='Show help')
    
    args = parser.parse_args()
    
    # Handle help
    if args.help:
        show_help()
        return
    
    # Non-interactive mode: environment and user provided
    if args.environment and args.user:
        try:
            token = await get_token_non_interactive(args.environment, args.user)
            # In non-interactive mode, just output the token (for use in scripts/curl)
            print(token)
            return
        except Exception as e:
            print(f"Error: {str(e)}", file=sys.stderr)
            sys.exit(1)
    
    # Interactive mode: no arguments provided
    if not args.environment and not args.user:
        # Welcome message with Rich styling
        console.print()
        welcome_panel = Panel(
            Text("🔐 SSO Authentication Tool", style="bold green"),
            border_style="green"
        )
        console.print(welcome_panel)
        
        # Initialize authenticator
        authenticator = SSOAuthenticator()
        selector = ModernSelector()
        
        # Select environment
        env_options = [f"{config['name']} ({env_key})" for env_key, config in ENVIRONMENTS.items()]
        env_choice = selector.select_from_list(
            "Select Environment", 
            env_options
        )
        selected_env = list(ENVIRONMENTS.keys())[env_choice]
        
        # Select user based on the selected environment
        env_users = ENVIRONMENT_USERS.get(selected_env, {})
        if not env_users:
            error_panel = Panel(
                f"[red]❌ No users configured for environment '{selected_env}'[/red]\n\n"
                "[yellow]Available environments with users:[/yellow]\n" +
                "\n".join([f"  • {env_key}: {', '.join(users.keys())}" 
                          for env_key, users in ENVIRONMENT_USERS.items() if users]),
                title="Configuration Error",
                border_style="red"
            )
            console.print(error_panel)
            sys.exit(1)
        
        user_options = [config['name'] for user_key, config in env_users.items()]
        user_choice = selector.select_from_list(
            "Select User", 
            user_options
        )
        selected_user = list(env_users.keys())[user_choice]
        
        # Show authentication progress
        console.print()
        progress_text = Text(f"🔄 Authenticating as ", style="yellow")
        progress_text.append(env_users[selected_user]['name'], style="bold")
        progress_text.append(f" on ", style="yellow")
        progress_text.append(ENVIRONMENTS[selected_env]['name'], style="bold blue")
        progress_text.append("...", style="yellow")
        console.print(progress_text)
        
        try:
            # Get token
            token = await authenticator.get_token(selected_env, selected_user)
            
            # Extract user info from token
            user_info = authenticator.extract_user_from_token(token)
            
            # Success message
            console.print()
            if copy_to_clipboard(token):
                success_panel = Panel(
                    Text("✅ Token copied to clipboard!", style="bold green"),
                    border_style="green"
                )
                console.print(success_panel)
            else:
                # Only display token if clipboard copy failed
                success_panel = Panel(
                    Text("✅ Authentication successful!", style="bold green"),
                    border_style="green"
                )
                console.print(success_panel)
                
                if user_info:
                    user_display = Text("👤 User: ", style="cyan")
                    user_display.append(user_info.get('preferred_username', 'Unknown'), style="bold")
                    console.print(user_display)
                
                console.print()
                token_panel = Panel(
                    f"[bold]🔑 Token:[/bold]\n{token}\n\n[bold]🎯 Authorization:[/bold] Bearer {token}",
                    title="Authentication Token",
                    border_style="blue"
                )
                console.print(token_panel)
            
        except Exception as e:
            error_panel = Panel(
                f"[red]❌ Authentication failed:[/red]\n{str(e)}",
                title="Error",
                border_style="red"
            )
            console.print(error_panel)
            sys.exit(1)
    
    # Invalid usage: only one argument provided
    else:
        print("Error: Both environment and user must be provided for non-interactive mode.", file=sys.stderr)
        print("Usage: sso [environment] [user] or sso --help", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\n[yellow]👋 Goodbye![/yellow]")
        sys.exit(0)
