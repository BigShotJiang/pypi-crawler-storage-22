from ssp4onnx.onnx_network_split import split, main

__version__ = '1.0.3'
