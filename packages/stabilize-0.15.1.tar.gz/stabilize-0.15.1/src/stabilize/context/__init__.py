"""Context handling for pipeline execution."""

from stabilize.context.stage_context import StageContext

__all__ = [
    "StageContext",
]
