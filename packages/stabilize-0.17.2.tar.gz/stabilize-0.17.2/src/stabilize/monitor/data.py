"""Data fetching layer for the monitor command."""

from __future__ import annotations

import time
from datetime import datetime
from typing import TYPE_CHECKING, Any

from stabilize.models.status import WorkflowStatus
from stabilize.monitor.models import (
    MonitorData,
    QueueStats,
    StageView,
    TaskView,
    WorkflowStats,
    WorkflowView,
    format_duration,
)

if TYPE_CHECKING:
    from stabilize.persistence.store import WorkflowStore
    from stabilize.queue import Queue

# Re-export for backward compatibility
__all__ = [
    "MonitorDataFetcher",
    "MonitorData",
    "QueueStats",
    "StageView",
    "TaskView",
    "WorkflowStats",
    "WorkflowView",
    "format_duration",
]


class MonitorDataFetcher:
    """Fetches monitoring data from the database."""

    def __init__(
        self,
        store: WorkflowStore,
        queue: Queue | None = None,
        stuck_threshold_seconds: int = 300,
    ):
        self.store = store
        self.queue = queue
        self.stuck_threshold_seconds = stuck_threshold_seconds

    def fetch(
        self,
        app_filter: str | None = None,
        limit: int = 50,
        status_filter: str = "all",
    ) -> MonitorData:
        """Fetch current monitoring data from the database."""
        try:
            workflows = self._fetch_workflows(app_filter, limit, status_filter)
            queue_stats = self._fetch_queue_stats()
            workflow_stats = self._calculate_workflow_stats(workflows)

            return MonitorData(
                workflows=workflows,
                queue_stats=queue_stats,
                workflow_stats=workflow_stats,
                fetch_time=datetime.now(),
            )
        except Exception as e:
            return MonitorData(
                workflows=[],
                queue_stats=QueueStats(),
                workflow_stats=WorkflowStats(),
                fetch_time=datetime.now(),
                error=str(e),
            )

    def _fetch_workflows(
        self,
        app_filter: str | None,
        limit: int,
        status_filter: str,
    ) -> list[WorkflowView]:
        """Fetch workflows efficiently using batch queries (3-query pattern)."""
        workflows_map: dict[str, WorkflowView] = {}
        stage_ids: list[str] = []
        workflow_ids: list[str] = []

        # 1. Fetch Workflows
        # ------------------
        if hasattr(self.store, "_pool"):
            # PostgreSQL
            with getattr(self.store, "_pool").connection() as conn:
                with conn.cursor() as cur:
                    # Build Query
                    query, params = self._build_workflow_query(app_filter, limit, status_filter, dialect="postgres")
                    cur.execute(query, params)
                    rows = cur.fetchall()

                    for row in rows:
                        wf_view = self._row_to_workflow_view(row)
                        workflows_map[wf_view.id] = wf_view
                        workflow_ids.append(wf_view.id)

                    if not workflow_ids:
                        return []

                    # 2. Fetch Stages
                    # ---------------
                    cur.execute(
                        """
                        SELECT * FROM stage_executions
                        WHERE execution_id = ANY(%(ids)s)
                        ORDER BY start_time ASC
                        """,
                        {"ids": workflow_ids},
                    )
                    stage_rows = cur.fetchall()

                    stage_map = {}  # id -> StageView
                    for row in stage_rows:
                        stage_view = self._row_to_stage_view(row)
                        # Temp map by ref_id for linking? No, need unique ID
                        stage_map[stage_view.ref_id] = stage_view
                        # Actually we need to attach to workflow immediately
                        if stage_view.execution_id in workflows_map:
                            workflows_map[stage_view.execution_id].stages.append(stage_view)
                            stage_ids.append(row["id"])

                    if not stage_ids:
                        return list(workflows_map.values())

                    # 3. Fetch Tasks
                    # --------------
                    cur.execute(
                        """
                        SELECT * FROM task_executions
                        WHERE stage_id = ANY(%(ids)s)
                        ORDER BY start_time ASC
                        """,
                        {"ids": stage_ids},
                    )
                    task_rows = cur.fetchall()

                    # Map tasks to stages. We need a way to find stage by ID.
                    # Re-iterate stages to build a lookup map by DB ID
                    stage_lookup = {}
                    for wf in workflows_map.values():
                        for stage in wf.stages:
                            # We need the internal DB ID to link tasks, but StageView doesn't have it by default.
                            # We stored it in _row_to_stage_view temporarily
                            if stage.db_id is not None:
                                stage_lookup[stage.db_id] = stage

                    for row in task_rows:
                        task_view = self._row_to_task_view(row)
                        stage_id = row["stage_id"]
                        if stage_id in stage_lookup:
                            stage_lookup[stage_id].tasks.append(task_view)

        elif hasattr(self.store, "_manager"):
            # SQLite
            conn_mgr = getattr(self.store, "_manager")
            conn = conn_mgr.get_sqlite_connection(getattr(self.store, "connection_string"))
            cursor = conn.cursor()

            # 1. Fetch Workflows
            query, params = self._build_workflow_query(app_filter, limit, status_filter, dialect="sqlite")
            cursor.execute(query, params)
            rows = cursor.fetchall()

            for row in rows:
                wf_view = self._row_to_workflow_view(row)
                workflows_map[wf_view.id] = wf_view
                workflow_ids.append(wf_view.id)

            if not workflow_ids:
                return []

            # 2. Fetch Stages
            # SQLite doesn't support = ANY(), use IN (?,?,?)
            placeholders = ",".join("?" * len(workflow_ids))
            cursor.execute(
                f"""
                SELECT * FROM stage_executions
                WHERE execution_id IN ({placeholders})
                ORDER BY start_time ASC
                """,
                workflow_ids,
            )
            stage_rows = cursor.fetchall()

            stage_lookup = {}  # db_id -> StageView

            for row in stage_rows:
                stage_view = self._row_to_stage_view(row)
                # SQLite rows can be accessed by name if RowFactory is set, usually is in Stabilize
                ex_id = row["execution_id"]
                if ex_id in workflows_map:
                    workflows_map[ex_id].stages.append(stage_view)
                    stage_ids.append(row["id"])
                    stage_lookup[row["id"]] = stage_view

            if not stage_ids:
                return list(workflows_map.values())

            # 3. Fetch Tasks
            placeholders = ",".join("?" * len(stage_ids))
            cursor.execute(
                f"""
                SELECT * FROM task_executions
                WHERE stage_id IN ({placeholders})
                ORDER BY start_time ASC
                """,
                stage_ids,
            )
            task_rows = cursor.fetchall()

            for row in task_rows:
                task_view = self._row_to_task_view(row)
                st_id = row["stage_id"]
                if st_id in stage_lookup:
                    stage_lookup[st_id].tasks.append(task_view)

        # Sort stages and tasks just in case DB didn't
        # And convert dictionary to list
        sorted_workflows = sorted(
            workflows_map.values(),
            key=lambda w: (0 if w.status == WorkflowStatus.RUNNING else 1, w.start_time or 0),
        )
        return sorted_workflows

    def _build_workflow_query(self, app: str | None, limit: int, status: str, dialect: str) -> tuple[str, Any]:
        """Build the SQL query for fetching workflows."""
        clauses: list[str] = []

        if dialect == "postgres":
            pg_params: dict[str, Any] = {}
            if app:
                clauses.append("application = %(app)s")
                pg_params["app"] = app

            if status == "running":
                clauses.append("status = 'RUNNING'")
            elif status == "failed":
                clauses.append("status IN ('TERMINAL', 'FAILED_CONTINUE', 'CANCELED')")

            where = "WHERE " + " AND ".join(clauses) if clauses else ""
            pg_params["limit"] = limit

            query = f"""
                SELECT * FROM pipeline_executions
                {where}
                ORDER BY
                    CASE WHEN status = 'RUNNING' THEN 0 ELSE 1 END,
                    created_at DESC
                LIMIT %(limit)s
            """
            return query, pg_params
        else:
            sqlite_params: list[Any] = []
            if app:
                clauses.append("application = ?")
                sqlite_params.append(app)

            if status == "running":
                clauses.append("status = 'RUNNING'")
            elif status == "failed":
                clauses.append("status IN ('TERMINAL', 'FAILED_CONTINUE', 'CANCELED')")

            where = "WHERE " + " AND ".join(clauses) if clauses else ""
            sqlite_params.append(limit)

            query = f"""
                SELECT * FROM pipeline_executions
                {where}
                ORDER BY
                    CASE WHEN status = 'RUNNING' THEN 0 ELSE 1 END,
                    created_at DESC
                LIMIT ?
            """
            return query, sqlite_params

    def _row_to_workflow_view(self, row: Any) -> WorkflowView:
        return WorkflowView(
            id=row["id"],
            application=row["application"],
            name=row["name"] or "",
            status=WorkflowStatus[row["status"]],
            start_time=row["start_time"],
            end_time=row["end_time"],
            stages=[],
        )

    def _row_to_stage_view(self, row: Any) -> StageView:
        return StageView(
            ref_id=row["ref_id"],
            name=row["name"] or "",
            status=WorkflowStatus[row["status"]],
            start_time=row["start_time"],
            end_time=row["end_time"],
            execution_id=row["execution_id"],
            tasks=[],
            db_id=row["id"],
        )

    def _row_to_task_view(self, row: Any) -> TaskView:
        # Handle JSON exception details safely
        error = None
        try:
            details = row["task_exception_details"]
            if details:
                if isinstance(details, str):
                    import json

                    details = json.loads(details)
                if isinstance(details, dict):
                    error = details.get("message")
        except Exception:
            pass

        return TaskView(
            name=row["name"],
            implementing_class=row["implementing_class"],
            status=WorkflowStatus[row["status"]],
            start_time=row["start_time"],
            end_time=row["end_time"],
            error=error,
        )

        # Removed _fetch_recent_workflows and _convert_workflow as they are replaced by the batch logic above

    def _fetch_queue_stats(self) -> QueueStats:
        """Fetch queue statistics."""
        if self.queue is None:
            return QueueStats()

        try:
            # Try to get queue stats from the queue object
            if hasattr(self.queue, "_manager") and hasattr(self.queue, "connection_string"):
                conn_mgr = getattr(self.queue, "_manager")
                conn = conn_mgr.get_sqlite_connection(getattr(self.queue, "connection_string"))
                cursor = conn.cursor()

                now = datetime.now().isoformat()
                threshold = int(time.time()) - self.stuck_threshold_seconds

                # Count pending (not locked, ready to deliver)
                cursor.execute(
                    """
                    SELECT COUNT(*) FROM queue_messages
                    WHERE (locked_until IS NULL OR locked_until < ?)
                    AND deliver_at <= ?
                    """,
                    (now, now),
                )
                pending = cursor.fetchone()[0]

                # Count processing (locked and not expired)
                cursor.execute(
                    """
                    SELECT COUNT(*) FROM queue_messages
                    WHERE locked_until IS NOT NULL AND locked_until > ?
                    """,
                    (now,),
                )
                processing = cursor.fetchone()[0]

                # Count stuck (locked for too long)
                stuck_threshold = datetime.fromtimestamp(threshold).isoformat()
                cursor.execute(
                    """
                    SELECT COUNT(*) FROM queue_messages
                    WHERE locked_until IS NOT NULL
                    AND locked_until < ?
                    AND locked_until < ?
                    """,
                    (now, stuck_threshold),
                )
                stuck = cursor.fetchone()[0]

                return QueueStats(pending=pending, processing=processing, stuck=stuck)

        except Exception:
            pass

        return QueueStats()

    def _calculate_workflow_stats(self, workflows: list[WorkflowView]) -> WorkflowStats:
        """Calculate aggregate workflow statistics."""
        stats = WorkflowStats(total=len(workflows))

        for wf in workflows:
            if wf.status == WorkflowStatus.RUNNING:
                stats.running += 1
            elif wf.status == WorkflowStatus.SUCCEEDED:
                stats.succeeded += 1
            elif wf.status.is_failure:
                stats.failed += 1

        return stats
