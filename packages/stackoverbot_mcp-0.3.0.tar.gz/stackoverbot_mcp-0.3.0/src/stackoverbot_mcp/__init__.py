from stackoverbot_mcp.server import mcp


def main():
    mcp.run()
