from stackoverbot_mcp import main

main()
