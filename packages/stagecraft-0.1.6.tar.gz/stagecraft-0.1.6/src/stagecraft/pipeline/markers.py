from enum import Enum


class IOMarker(Enum):
    INPUT = "__stage_input__"
    OUTPUT = "__stage_output__"
