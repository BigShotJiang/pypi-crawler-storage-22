"""STALWART - Structural Testing and Lifecycle Warning through Advanced Real-Time Tracking

A comprehensive sensor-driven framework for predictive bridge safety monitoring.
Version: 1.0.0 (Test Release)
"""

__version__ = "2.0.0"
__author__ = "Samir Baladi"
__email__ = "gitdeeper@gmail.com"
__license__ = "MIT"

# Core classes
from .core.bridge import Bridge
from .core.sensor import Sensor, SensorArray
from .core.measurement import Measurement, TimeSeries

# Analysis modules
from .analysis.metrics import (
    calculate_afc, calculate_alsa, calculate_cpii,
    calculate_ffd, calculate_lts, calculate_ccf,
    calculate_tvr, calculate_bd, calculate_sed,
    calculate_health_index, MetricResult
)

__all__ = [
    '__version__', '__author__', '__email__', '__license__',
    'Bridge', 'Sensor', 'SensorArray', 'Measurement', 'TimeSeries',
    'calculate_afc', 'calculate_alsa', 'calculate_cpii',
    'calculate_ffd', 'calculate_lts', 'calculate_ccf',
    'calculate_tvr', 'calculate_bd', 'calculate_sed',
    'calculate_health_index', 'MetricResult'
]
