"""STALWART test package."""
