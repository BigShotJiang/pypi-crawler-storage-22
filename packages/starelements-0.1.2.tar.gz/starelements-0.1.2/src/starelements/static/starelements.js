// typescript/starelements.ts
import { effect, mergePatch, getPath } from "datastar";
var globalWindow = window;
var instanceCounter = 0;
var toCamelCase = (s) => s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
var extractPrefixedAttrs = (el, prefix, valueFn = (v) => v) => {
  const result = {};
  for (const attr of el.attributes) {
    if (attr.name.startsWith(prefix)) {
      result[attr.name.slice(prefix.length)] = valueFn(attr.value);
    }
  }
  return result;
};
var PARSERS = {
  string: (v) => v,
  int: (v) => parseInt(v, 10),
  float: (v) => parseFloat(v),
  boolean: (v) => v === "true" || v === "" || v === true,
  json: (v) => JSON.parse(v)
};
function parseCodec(codecStr) {
  let type = "string";
  let defaultStr = null;
  for (const part of codecStr.split("|")) {
    if (part in PARSERS) type = part;
    else if (part.startsWith("=")) defaultStr = part.slice(1);
  }
  const parse = PARSERS[type];
  return { parse, default: defaultStr !== null ? parse(defaultStr) : null };
}
function initStarElements() {
  for (const template of document.querySelectorAll("template")) {
    const starAttr = Array.from(template.attributes).find((a) => a.name.startsWith("data-star:"));
    if (starAttr) registerStarElement(starAttr.name.replace("data-star:", ""), template);
  }
}
function registerStarElement(name, template) {
  const signals = extractPrefixedAttrs(template, "data-signal:", parseCodec);
  const imports = extractPrefixedAttrs(template, "data-import:");
  const scripts = extractPrefixedAttrs(template, "data-script:");
  const useShadow = template.hasAttribute("data-shadow-open") || template.hasAttribute("data-shadow-closed");
  const shadowMode = template.hasAttribute("data-shadow-closed") ? "closed" : "open";
  const setupCode = template.content.querySelector("script:not([data-static])")?.textContent ?? "";
  const staticScript = template.content.querySelector("script[data-static]");
  if (staticScript) {
    try {
      new Function(staticScript.textContent)();
    } catch (e) {
      console.error(`[starelements] Static script error in ${name}:`, e);
    }
  }
  class StarElement extends HTMLElement {
    static observedAttributes = Object.keys(signals);
    _namespace;
    _hydrating;
    _cleanups;
    _imports;
    _connected;
    _signalValues;
    constructor() {
      super();
      const serverId = this.getAttribute("data-star-id");
      this._namespace = serverId || `_star_${name.replace(/-/g, "_")}_id${instanceCounter++}`;
      this._hydrating = !!serverId;
      this._cleanups = [];
      this._imports = {};
      this._connected = false;
    }
    _namespaceSignalRefs(text) {
      return text.replace(/\$\$([a-z_][a-z0-9_]*)/gi, (_, sig) => `$${this._namespace}_${sig}`);
    }
    async connectedCallback() {
      try {
        await this._loadImports();
        if (!this.isConnected) return;
        this._signalValues = this._buildSignalValues();
        if (!this._hydrating) {
          const content = template.content.cloneNode(true);
          for (const s of content.querySelectorAll("script")) s.remove();
          this._rewriteSignals(content);
          if (useShadow) {
            this.attachShadow({ mode: shadowMode }).appendChild(content);
          } else {
            this.appendChild(content);
          }
        }
        this._initSignals();
        this._triggerDatastarScan();
        this._runSetup(setupCode);
      } catch (e) {
        console.error(`[starelements] connectedCallback error in <${name}>:`, e);
      } finally {
        this._connected = true;
        this.style.visibility = "";
        this.setAttribute("data-star-ready", "");
      }
    }
    disconnectedCallback() {
      for (const fn of this._cleanups) {
        try {
          fn();
        } catch (e) {
          console.error(e);
        }
      }
      this._cleanups = [];
      this._removeSignals();
    }
    attributeChangedCallback(attrName, oldVal, newVal) {
      if (oldVal === newVal || !this._connected) return;
      const signalDef = signals[attrName];
      const fullName = `${this._namespace}_${toCamelCase(attrName)}`;
      const parsed = newVal !== null && signalDef ? signalDef.parse(newVal) : newVal;
      mergePatch({ [fullName]: parsed });
    }
    async _loadImports() {
      for (const [alias, url] of Object.entries(imports)) {
        if (!globalWindow[alias]) {
          try {
            globalWindow[alias] = await import(url);
          } catch (e) {
            console.error(`[starelements] Failed to load ${alias} from ${url}:`, e);
          }
        }
        this._imports[alias] = globalWindow[alias];
      }
      const findGlobal = (alias) => {
        const pascal = alias.charAt(0).toUpperCase() + alias.slice(1);
        return globalWindow[alias] || globalWindow[pascal] || globalWindow[alias.toUpperCase()];
      };
      for (const [alias, url] of Object.entries(scripts)) {
        if (!findGlobal(alias)) {
          await new Promise((resolve, reject) => {
            const script = document.createElement("script");
            script.src = url;
            script.onload = () => resolve();
            script.onerror = () => reject(new Error(`Failed to load ${alias} from ${url}`));
            document.head.appendChild(script);
          }).catch((e) => console.error(`[starelements] ${e.message}`));
        }
        this._imports[alias] = findGlobal(alias);
      }
    }
    _rewriteSignals(node) {
      const walk = (el) => {
        if (el.attributes) {
          const renames = [];
          for (const attr of el.attributes) {
            if (attr.name === "data-ref" && attr.value) {
              attr.value = `${this._namespace}_${attr.value}`;
            } else if (attr.name.startsWith("data-computed:")) {
              const signalName = attr.name.slice("data-computed:".length);
              const newName = `data-computed:${this._namespace}_${signalName}`;
              const newValue = this._namespaceSignalRefs(attr.value);
              renames.push([attr.name, newName, newValue]);
            } else if (attr.value.includes("$$")) {
              attr.value = this._namespaceSignalRefs(attr.value);
            }
          }
          for (const [oldName, newName, newValue] of renames) {
            el.removeAttribute(oldName);
            el.setAttribute(newName, newValue);
          }
        }
        for (const child of el.childNodes) walk(child);
      };
      walk(node);
    }
    _buildSignalValues() {
      const values = {};
      for (const [name2, def] of Object.entries(signals)) {
        const attr = this.getAttribute(name2);
        values[toCamelCase(name2)] = attr !== null ? def.parse(attr) : def.default;
      }
      return values;
    }
    _initSignals() {
      const signalData = Object.fromEntries(
        Object.entries(this._signalValues).map(([k, v]) => [`${this._namespace}_${k}`, v])
      );
      mergePatch(signalData);
      const safeStringify = (s) => {
        return JSON.stringify(s).replace(
          /[$@]/g,
          (ch) => `\\u${ch.charCodeAt(0).toString(16).padStart(4, "0")}`
        );
      };
      const parts = Object.entries(signalData).map(([key, value]) => {
        const jsVal = typeof value === "string" && /[@$]/.test(value) ? safeStringify(value) : JSON.stringify(value);
        return `"${key}":${jsVal}`;
      });
      this.setAttribute("data-signals", `{${parts.join(",")}}`);
    }
    _removeSignals() {
      const patch = {};
      for (const name2 of Object.keys(signals)) {
        patch[`${this._namespace}_${toCamelCase(name2)}`] = null;
      }
      mergePatch(patch);
    }
    _runSetup(code) {
      if (!code.trim()) return;
      const refs = (refName) => this.querySelector(`[data-ref="${this._namespace}_${refName}"]`);
      const namespace = this._namespace;
      const sp = new Proxy({}, {
        has: (target, prop) => {
          if (typeof prop === "string" && prop.startsWith("$$")) return true;
          return Reflect.has(target, prop);
        },
        get: (target, prop) => {
          if (typeof prop === "string" && prop.startsWith("$$")) {
            return getPath(`${namespace}_${prop.slice(2)}`);
          }
          return Reflect.get(target, prop);
        },
        set: (target, prop, value) => {
          if (typeof prop === "string" && prop.startsWith("$$")) {
            mergePatch({ [`${namespace}_${prop.slice(2)}`]: value });
            return true;
          }
          return Reflect.set(target, prop, value);
        }
      });
      const trackedEffect = (fn) => {
        const dispose = effect(fn);
        this._cleanups.push(dispose);
        return dispose;
      };
      try {
        const wrappedCode = `with(sp) { ${code} }`;
        new Function(
          "el",
          "onCleanup",
          "refs",
          "effect",
          "sp",
          "datastar",
          ...Object.keys(this._imports),
          wrappedCode
        )(
          this,
          (fn) => this._cleanups.push(fn),
          refs,
          trackedEffect,
          sp,
          { effect: trackedEffect, mergePatch, getPath },
          ...Object.values(this._imports)
        );
      } catch (e) {
        console.error(`[starelements] Setup error in ${name}:`, e);
      }
    }
    // Web components insert DOM after Datastar's initial scan; re-trigger to process new data-* attrs
    _triggerDatastarScan() {
      this.dispatchEvent(new CustomEvent("datastar:scan", { bubbles: true, detail: { root: this } }));
    }
    emit(eventName, detail) {
      this.dispatchEvent(new CustomEvent(eventName, { detail, bubbles: true, cancelable: true, composed: false }));
    }
  }
  customElements.define(name, StarElement);
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initStarElements);
} else {
  initStarElements();
}
var starelements_default = initStarElements;
export {
  starelements_default as default,
  initStarElements
};
