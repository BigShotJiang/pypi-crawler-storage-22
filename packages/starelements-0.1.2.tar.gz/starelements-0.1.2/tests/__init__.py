"""Tests for starelements package."""
