import { animate, scroll, inView, stagger } from "https://cdn.jsdelivr.net/npm/motion@11/+esm";
import { stagger as stagger2 } from "https://cdn.jsdelivr.net/npm/motion@11/+esm";
import { mergePatch, effect, getPath } from "datastar";
const animationRegistry = /* @__PURE__ */ new Map();
const exitConfigMap = /* @__PURE__ */ new WeakMap();
const SPRING_PRESETS = {
  gentle: { stiffness: 120, damping: 14 },
  bouncy: { stiffness: 300, damping: 10 },
  tight: { stiffness: 400, damping: 30 },
  slow: { stiffness: 50, damping: 20 },
  snappy: { stiffness: 500, damping: 25 }
};
const ANIMATION_PRESETS = {
  fade: { opacity: [0, 1] },
  "slide-up": { y: [40, 0], opacity: [0, 1] },
  "slide-down": { y: [-40, 0], opacity: [0, 1] },
  "slide-left": { x: [-40, 0], opacity: [0, 1] },
  "slide-right": { x: [40, 0], opacity: [0, 1] },
  scale: { scale: [0.5, 1], opacity: [0, 1] },
  bounce: { y: [-10, 0], opacity: [0, 1] }
};
function parseMotionAttribute(value) {
  const config = { type: "enter" };
  for (const part of value.split(" ")) {
    const colonIdx = part.indexOf(":");
    if (colonIdx === -1) continue;
    const key = part.slice(0, colonIdx);
    const val = part.slice(colonIdx + 1);
    if (key === "type") {
      config.type = val;
    } else if (key === "name") {
      config.name = val;
    } else {
      parseConfigValue(config, key, val);
    }
  }
  return config;
}
function parseVisibilityConfig(value) {
  const enterConfig = { type: "enter" };
  const exitConfig = { type: "exit" };
  let signal = "";
  for (const part of value.split(" ")) {
    const colonIdx = part.indexOf(":");
    if (colonIdx === -1) continue;
    const key = part.slice(0, colonIdx);
    const val = part.slice(colonIdx + 1);
    if (key === "signal") {
      signal = val;
    } else if (key.startsWith("enter_")) {
      const subKey = key.slice(6);
      parseConfigValue(enterConfig, subKey, val);
    } else if (key.startsWith("exit_")) {
      const subKey = key.slice(5);
      parseConfigValue(exitConfig, subKey, val);
    }
  }
  return { signal, enter: enterConfig, exit: exitConfig };
}
function parseConfigValue(config, key, val) {
  if (key === "preset" || key === "ease" || key === "spring") {
    config[key] = val;
  } else if (key === "once") {
    config.once = val === "true";
  } else if (key === "repeat") {
    config.repeat = val === "infinite" ? Number.POSITIVE_INFINITY : Number(val);
  } else if (val.includes(",")) {
    config[key] = val.split(",").map(Number);
  } else {
    const numVal = Number(val);
    config[key] = Number.isNaN(numVal) ? val : numVal;
  }
}
function getKeyframes(config) {
  const preset = config.preset && ANIMATION_PRESETS[config.preset];
  if (preset) return { ...preset };
  const keyframes = {};
  if (config.x !== void 0) keyframes.x = [config.x, 0];
  if (config.y !== void 0) keyframes.y = [config.y, 0];
  if (config.scale !== void 0) keyframes.scale = [config.scale, 1];
  if (config.rotate !== void 0) keyframes.rotate = [config.rotate, 0];
  if (config.opacity !== void 0) keyframes.opacity = [config.opacity, 1];
  return keyframes;
}
function getExitKeyframes(config) {
  const preset = config.preset && ANIMATION_PRESETS[config.preset];
  if (preset) {
    const exitKeyframes = {};
    for (const [key, val] of Object.entries(preset)) {
      if (Array.isArray(val) && val.length >= 2) {
        exitKeyframes[key] = [val[1], val[0]];
      }
    }
    return exitKeyframes;
  }
  const keyframes = {};
  if (config.x !== void 0) keyframes.x = [0, config.x];
  if (config.y !== void 0) keyframes.y = [0, config.y];
  if (config.scale !== void 0) keyframes.scale = [1, config.scale];
  if (config.rotate !== void 0) keyframes.rotate = [0, config.rotate];
  if (config.opacity !== void 0) keyframes.opacity = [1, config.opacity];
  return keyframes;
}
function getAnimationOptions(config) {
  const options = {
    duration: (Number(config.duration) || 300) / 1e3
  };
  if (config.delay) options.delay = Number(config.delay) / 1e3;
  if (config.ease) options.ease = config.ease;
  if (config.repeat !== void 0) {
    options.repeat = config.repeat === "infinite" ? Number.POSITIVE_INFINITY : Number(config.repeat);
  }
  if (config.repeatType) {
    options.repeatType = config.repeatType;
  }
  if (config.inertia) {
    options.type = "inertia";
    if (config.power !== void 0) options.power = Number(config.power);
    if (config.timeConstant !== void 0) options.timeConstant = Number(config.timeConstant);
    if (config.min !== void 0) options.min = Number(config.min);
    if (config.max !== void 0) options.max = Number(config.max);
    if (config.velocity !== void 0) options.velocity = Number(config.velocity);
    return options;
  }
  const springPreset = config.spring ? SPRING_PRESETS[config.spring] : null;
  if (springPreset || config.stiffness !== void 0 || config.damping !== void 0 || config.mass !== void 0 || config.velocity !== void 0) {
    options.type = "spring";
    if (springPreset) Object.assign(options, springPreset);
    if (config.stiffness !== void 0) options.stiffness = Number(config.stiffness);
    if (config.damping !== void 0) options.damping = Number(config.damping);
    if (config.mass !== void 0) options.mass = Number(config.mass);
    if (config.velocity !== void 0) options.velocity = Number(config.velocity);
    if (config.restSpeed !== void 0) options.restSpeed = Number(config.restSpeed);
    if (config.restDelta !== void 0) options.restDelta = Number(config.restDelta);
  }
  if (config.stagger !== void 0) {
    options.delay = stagger(Number(config.stagger) / 1e3);
  }
  return options;
}
function dispatchMotionEvent(el, eventName, detail) {
  queueMicrotask(() => {
    el.dispatchEvent(
      new CustomEvent(eventName, {
        bubbles: true,
        detail: { name: detail.name, type: detail.type, element: el }
      })
    );
  });
}
function registerAnimation(name, anim, el) {
  if (name) {
    const existing = animationRegistry.get(name);
    if (existing && existing.anim !== anim) {
      existing.anim.cancel();
    }
    animationRegistry.set(name, { anim, el });
  }
}
function unregisterAnimation(name, anim) {
  if (name) {
    const entry = animationRegistry.get(name);
    if (!anim || entry?.anim === anim) {
      animationRegistry.delete(name);
    }
  }
}
function createMotionTriggerHandler(el) {
  return (e) => {
    const detail = e.detail;
    if (detail.op === "remove") {
      playExitAndThen(el, () => el.remove());
    } else if (detail.op === "replace" && detail.html) {
      playExitAndThen(el, () => {
        el.outerHTML = detail.html;
      });
    }
  };
}
function playExitAndThen(el, callback) {
  const exitConfig = exitConfigMap.get(el);
  if (!exitConfig) {
    callback();
    return;
  }
  const keyframes = getExitKeyframes(exitConfig);
  const options = getAnimationOptions(exitConfig);
  dispatchMotionEvent(el, "motion-start", { name: exitConfig.name, type: "exit" });
  const exitAnim = animate(el, keyframes, options);
  registerAnimation(exitConfig.name, exitAnim, el);
  return exitAnim.finished.then(() => {
    dispatchMotionEvent(el, "motion-complete", { name: exitConfig.name, type: "exit" });
    unregisterAnimation(exitConfig.name, exitAnim);
    if (el.isConnected) {
      callback();
    }
  });
}
const motionAttributePlugin = {
  name: "motion",
  requirement: { key: "allowed", value: "allowed" },
  argNames: [],
  apply(ctx) {
    const { el, value } = ctx;
    if (!value) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      el.setAttribute("data-motion-ready", "true");
      return;
    }
    const config = parseMotionAttribute(value);
    let cleanup = null;
    const animType = config.type === "tap" ? "press" : config.type;
    switch (animType) {
      case "enter": {
        const keyframes = getKeyframes(config);
        const options = getAnimationOptions(config);
        el.setAttribute("data-motion-ready", "true");
        dispatchMotionEvent(el, "motion-start", { name: config.name, type: "enter" });
        const anim = animate(el, keyframes, options);
        registerAnimation(config.name, anim, el);
        anim.finished.then(() => {
          dispatchMotionEvent(el, "motion-complete", { name: config.name, type: "enter" });
          unregisterAnimation(config.name, anim);
        });
        cleanup = () => {
          anim.cancel();
          dispatchMotionEvent(el, "motion-cancel", { name: config.name, type: "enter" });
          unregisterAnimation(config.name, anim);
        };
        break;
      }
      case "exit": {
        el.setAttribute("data-motion-ready", "true");
        const originalDisplay = el.style.display || getComputedStyle(el).display;
        let isAnimating = false;
        const playExitAnimation = () => {
          if (isAnimating) return;
          isAnimating = true;
          el.style.display = originalDisplay === "none" ? "block" : originalDisplay;
          el.hidden = false;
          const keyframes = getExitKeyframes(config);
          const options = getAnimationOptions(config);
          dispatchMotionEvent(el, "motion-start", { name: config.name, type: "exit" });
          const exitAnim = animate(el, keyframes, options);
          registerAnimation(config.name, exitAnim, el);
          exitAnim.finished.then(() => {
            if (el.isConnected) {
              el.style.display = "none";
            }
            dispatchMotionEvent(el, "motion-complete", { name: config.name, type: "exit" });
            unregisterAnimation(config.name, exitAnim);
            isAnimating = false;
          });
        };
        const observer = new MutationObserver((mutations) => {
          for (const mutation of mutations) {
            if (mutation.type === "attributes") {
              const isHiding = mutation.attributeName === "style" && el.style.display === "none" || mutation.attributeName === "hidden" && el.hidden;
              if (isHiding) {
                playExitAnimation();
              }
            }
          }
        });
        observer.observe(el, { attributes: true, attributeFilter: ["style", "hidden"] });
        cleanup = () => observer.disconnect();
        break;
      }
      case "hover": {
        el.setAttribute("data-motion-ready", "true");
        const duration = (config.duration ?? 200) / 1e3;
        const hoverKeyframes = {};
        const restKeyframes = {};
        for (const key of ["scale", "y", "rotate"]) {
          const val = config[key];
          if (val !== void 0) {
            hoverKeyframes[key] = val;
            restKeyframes[key] = key === "scale" ? 1 : 0;
          }
        }
        let currentAnim = null;
        const onEnter = () => {
          currentAnim?.cancel();
          dispatchMotionEvent(el, "motion-start", { name: config.name, type: "hover" });
          currentAnim = animate(el, hoverKeyframes, { duration });
          currentAnim.finished.then(() => {
            dispatchMotionEvent(el, "motion-complete", { name: config.name, type: "hover" });
          });
        };
        const onLeave = () => {
          currentAnim?.cancel();
          currentAnim = animate(el, restKeyframes, { duration });
        };
        el.addEventListener("mouseenter", onEnter);
        el.addEventListener("mouseleave", onLeave);
        cleanup = () => {
          el.removeEventListener("mouseenter", onEnter);
          el.removeEventListener("mouseleave", onLeave);
          currentAnim?.cancel();
        };
        break;
      }
      case "press": {
        el.setAttribute("data-motion-ready", "true");
        const duration = (config.duration ?? 100) / 1e3;
        const pressKeyframes = {};
        const restKeyframes = {};
        for (const key of ["scale", "y"]) {
          const val = config[key];
          if (val !== void 0) {
            pressKeyframes[key] = val;
            restKeyframes[key] = key === "scale" ? 1 : 0;
          }
        }
        let currentAnim = null;
        let isPressed = false;
        const onDown = () => {
          isPressed = true;
          currentAnim?.cancel();
          dispatchMotionEvent(el, "motion-start", { name: config.name, type: "press" });
          currentAnim = animate(el, pressKeyframes, { duration });
        };
        const onUp = () => {
          if (!isPressed) return;
          isPressed = false;
          currentAnim?.cancel();
          currentAnim = animate(el, restKeyframes, { duration });
          currentAnim.finished.then(() => {
            dispatchMotionEvent(el, "motion-complete", { name: config.name, type: "press" });
          });
        };
        el.addEventListener("pointerdown", onDown);
        el.addEventListener("pointerup", onUp);
        el.addEventListener("pointerleave", onUp);
        cleanup = () => {
          el.removeEventListener("pointerdown", onDown);
          el.removeEventListener("pointerup", onUp);
          el.removeEventListener("pointerleave", onUp);
          currentAnim?.cancel();
        };
        break;
      }
      case "resize": {
        el.setAttribute("data-motion-ready", "true");
        const duration = (config.duration ?? 200) / 1e3;
        let currentAnim = null;
        let initialSize = null;
        const resizeObserver = new ResizeObserver((entries) => {
          for (const entry of entries) {
            const { width, height } = entry.contentRect;
            if (!initialSize) {
              initialSize = { width, height };
              return;
            }
            if (width !== initialSize.width || height !== initialSize.height) {
              currentAnim?.cancel();
              const keyframes = {};
              if (config.scale !== void 0) keyframes.scale = [config.scale, 1];
              if (config.opacity !== void 0) keyframes.opacity = [config.opacity, 1];
              dispatchMotionEvent(el, "motion-start", { name: config.name, type: "resize" });
              currentAnim = animate(el, keyframes, { duration });
              currentAnim.finished.then(() => {
                dispatchMotionEvent(el, "motion-complete", { name: config.name, type: "resize" });
              });
              initialSize = { width, height };
            }
          }
        });
        resizeObserver.observe(el);
        cleanup = () => {
          resizeObserver.disconnect();
          currentAnim?.cancel();
        };
        break;
      }
      case "in-view": {
        const keyframes = getKeyframes(config);
        const options = getAnimationOptions(config);
        const initialState = {};
        for (const [key, val] of Object.entries(keyframes)) {
          initialState[key] = Array.isArray(val) ? val[0] : val;
        }
        animate(el, initialState, { duration: 0 });
        const stopObserving = inView(
          el,
          () => {
            el.setAttribute("data-motion-ready", "true");
            dispatchMotionEvent(el, "motion-start", { name: config.name, type: "in-view" });
            const anim = animate(el, keyframes, options);
            registerAnimation(config.name, anim, el);
            anim.finished.then(() => {
              dispatchMotionEvent(el, "motion-complete", { name: config.name, type: "in-view" });
              unregisterAnimation(config.name, anim);
            });
            if (config.once === false) {
              return () => animate(el, initialState, { duration: 0 });
            }
            return void 0;
          },
          { amount: config.threshold ?? 0.1 }
        );
        cleanup = stopObserving;
        break;
      }
      case "scroll": {
        el.setAttribute("data-motion-ready", "true");
        const scrollKeyframes = {};
        for (const prop of ["x", "y", "scale", "opacity", "rotate"]) {
          const val = config[prop];
          if (Array.isArray(val) && val.length === 2) {
            scrollKeyframes[prop] = val;
          }
        }
        const anim = animate(el, scrollKeyframes, { duration: 1 });
        anim.pause();
        const progressSignal = config.name ? `${config.name}_progress` : null;
        const stopScrolling = scroll(
          (progress) => {
            anim.time = progress;
            if (progressSignal) {
              mergePatch({ [progressSignal]: Math.round(progress * 100) });
            }
          },
          { target: el, offset: ["start end", "end start"] }
        );
        cleanup = () => {
          stopScrolling();
          anim.cancel();
        };
        break;
      }
      case "visibility": {
        const visConfig = parseVisibilityConfig(value);
        if (!visConfig.signal) {
          console.warn("data-motion visibility requires a signal");
          el.setAttribute("data-motion-ready", "true");
          return;
        }
        if (visConfig.exit) {
          visConfig.exit.type = "exit";
          exitConfigMap.set(el, visConfig.exit);
        }
        const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        const originalDisplay = el.style.display || getComputedStyle(el).display || "block";
        let isAnimating = false;
        let currentlyVisible = null;
        const playEnterAnimation = () => {
          el.style.display = originalDisplay;
          el.setAttribute("data-motion-ready", "true");
          if (prefersReducedMotion) {
            isAnimating = false;
            return;
          }
          const enterKeyframes = getKeyframes(visConfig.enter);
          if (Object.keys(enterKeyframes).length === 0) {
            isAnimating = false;
            return;
          }
          isAnimating = true;
          const options = getAnimationOptions(visConfig.enter);
          dispatchMotionEvent(el, "motion-start", { name: visConfig.enter.name, type: "enter" });
          const enterAnim = animate(el, enterKeyframes, options);
          registerAnimation(visConfig.enter.name, enterAnim, el);
          enterAnim.finished.then(() => {
            dispatchMotionEvent(el, "motion-complete", {
              name: visConfig.enter.name,
              type: "enter"
            });
            unregisterAnimation(visConfig.enter.name, enterAnim);
            isAnimating = false;
          });
        };
        const playExitAnimation = () => {
          if (prefersReducedMotion) {
            el.style.display = "none";
            return Promise.resolve();
          }
          const exitKeyframes = getExitKeyframes(visConfig.exit);
          if (Object.keys(exitKeyframes).length === 0 || isAnimating) {
            el.style.display = "none";
            return Promise.resolve();
          }
          isAnimating = true;
          const options = getAnimationOptions(visConfig.exit);
          dispatchMotionEvent(el, "motion-start", { name: visConfig.exit.name, type: "exit" });
          const exitAnim = animate(el, exitKeyframes, options);
          registerAnimation(visConfig.exit.name, exitAnim, el);
          return exitAnim.finished.then(() => {
            if (el.isConnected) {
              el.style.display = "none";
            }
            dispatchMotionEvent(el, "motion-complete", { name: visConfig.exit.name, type: "exit" });
            unregisterAnimation(visConfig.exit.name, exitAnim);
            isAnimating = false;
          });
        };
        const handleTrigger = createMotionTriggerHandler(el);
        el.addEventListener("motion-trigger", handleTrigger);
        const signalName = visConfig.signal.startsWith("$") ? visConfig.signal.slice(1) : visConfig.signal;
        const dispose = effect(() => {
          try {
            const shouldBeVisible = Boolean(getPath(signalName));
            if (currentlyVisible === null) {
              currentlyVisible = shouldBeVisible;
              el.style.display = shouldBeVisible ? originalDisplay : "none";
              if (shouldBeVisible) {
                el.setAttribute("data-motion-ready", "true");
              }
              return;
            }
            if (shouldBeVisible && !currentlyVisible) {
              currentlyVisible = true;
              playEnterAnimation();
            } else if (!shouldBeVisible && currentlyVisible) {
              currentlyVisible = false;
              playExitAnimation();
            }
          } catch (err) {
            console.warn("data-motion visibility: Failed to evaluate signal expression:", err);
          }
        });
        cleanup = () => {
          dispose();
          el.removeEventListener("motion-trigger", handleTrigger);
          exitConfigMap.delete(el);
        };
        break;
      }
    }
    return () => cleanup?.();
  }
};
const OPTION_KEYS = /* @__PURE__ */ new Set([
  "duration",
  "delay",
  "ease",
  "spring",
  "stagger",
  "repeat",
  "repeatType",
  "name",
  "at",
  "stiffness",
  "damping",
  "mass",
  "velocity",
  "restSpeed",
  "restDelta",
  "inertia",
  "power",
  "timeConstant",
  "min",
  "max"
]);
function extractKeyframes(props) {
  const keyframes = {};
  for (const [key, value] of Object.entries(props)) {
    if (!OPTION_KEYS.has(key)) {
      keyframes[key] = value;
    }
  }
  return keyframes;
}
function resolveElement(ctx, selectorOrProps, maybeProps) {
  if (typeof selectorOrProps === "string") {
    const el = selectorOrProps === "el" ? ctx.el : document.querySelector(selectorOrProps);
    return { el, props: maybeProps ?? {} };
  }
  return { el: ctx.el, props: selectorOrProps ?? {} };
}
const motionActionPlugin = {
  name: "motion",
  apply: (ctx, operation, ...args) => {
    switch (operation) {
      case "animate": {
        const { el, props } = resolveElement(
          ctx,
          ...args
        );
        if (!el) {
          console.warn(`@motion('animate'): Element not found`);
          return;
        }
        const keyframes = extractKeyframes(props);
        const options = getAnimationOptions(props);
        const name = props.name;
        const isInfinite = props.repeat === "infinite";
        if (name) {
          const existing = animationRegistry.get(name);
          if (existing) {
            return;
          }
        }
        const animOptions = { ...options };
        if (isInfinite) {
          animOptions.repeat = Number.POSITIVE_INFINITY;
        }
        dispatchMotionEvent(el, "motion-start", { name, type: "animate" });
        const anim = animate(el, keyframes, animOptions);
        registerAnimation(name, anim, el);
        return anim.finished.then(() => {
          dispatchMotionEvent(el, "motion-complete", { name, type: "animate" });
          unregisterAnimation(name, anim);
        }).catch(() => unregisterAnimation(name, anim));
      }
      case "sequence": {
        const [steps] = args;
        if (!Array.isArray(steps) || steps.length === 0) {
          console.warn(`@motion('sequence'): Invalid steps array`);
          return;
        }
        let chain = Promise.resolve();
        let lastAt = 0;
        for (const step of steps) {
          const [selector, keyframeProps, stepOptions = {}] = step;
          const el = selector === "el" ? ctx.el : document.querySelector(selector);
          if (!el) {
            console.warn(`@motion('sequence'): Element not found: ${selector}`);
            continue;
          }
          const options = getAnimationOptions({ ...keyframeProps, ...stepOptions });
          const kf = extractKeyframes(keyframeProps);
          const atValue = stepOptions.at;
          let delayOffset = 0;
          if (typeof atValue === "string" && atValue.startsWith("+")) {
            delayOffset = Number.parseFloat(atValue.slice(1));
          } else if (typeof atValue === "number") {
            delayOffset = atValue - lastAt;
            lastAt = atValue;
          }
          if (delayOffset > 0 && typeof options.delay !== "function") {
            options.delay = (options.delay ?? 0) + delayOffset;
          }
          const capturedEl = el;
          chain = chain.then(() => {
            dispatchMotionEvent(capturedEl, "motion-start", { name: void 0, type: "sequence" });
            const anim = animate(capturedEl, kf, options);
            return anim.finished.then(() => {
              dispatchMotionEvent(capturedEl, "motion-complete", {
                name: void 0,
                type: "sequence"
              });
            });
          });
        }
        return chain;
      }
      case "set": {
        const { el, props } = resolveElement(
          ctx,
          ...args
        );
        if (!el) {
          console.warn(`@motion('set'): Element not found`);
          return;
        }
        animate(el, extractKeyframes(props), { duration: 0 });
        return;
      }
      case "pause":
      case "play":
      case "stop":
      case "cancel": {
        const [name] = args;
        const entry = animationRegistry.get(name);
        if (!entry) {
          return;
        }
        entry.anim[operation]();
        if (operation === "stop" || operation === "cancel") {
          if (operation === "cancel") {
            dispatchMotionEvent(entry.el, "motion-cancel", { name, type: "cancel" });
          }
          animationRegistry.delete(name);
        }
        return;
      }
      case "remove": {
        const [selector] = args;
        const el = selector === "el" ? ctx.el : document.querySelector(selector);
        if (!el) {
          console.warn(`@motion('remove'): Element not found: ${selector}`);
          return;
        }
        return playExitAndThen(el, () => el.remove());
      }
      case "replace": {
        const [selector, html] = args;
        const el = selector === "el" ? ctx.el : document.querySelector(selector);
        if (!el) {
          console.warn(`@motion('replace'): Element not found: ${selector}`);
          return;
        }
        return playExitAndThen(el, () => {
          el.outerHTML = html;
        });
      }
      default:
        console.warn(`@motion: Unknown operation: ${operation}`);
    }
  }
};
const motionExitAttributePlugin = {
  name: "motion-exit",
  requirement: { key: "allowed", value: "allowed" },
  argNames: [],
  apply(ctx) {
    const { el, value } = ctx;
    if (!value) return;
    const config = parseMotionAttribute(value);
    config.type = "exit";
    exitConfigMap.set(el, config);
    const handleTrigger = createMotionTriggerHandler(el);
    el.addEventListener("motion-trigger", handleTrigger);
    return () => {
      el.removeEventListener("motion-trigger", handleTrigger);
      exitConfigMap.delete(el);
    };
  }
};
var motion_default = motionAttributePlugin;
export {
  animationRegistry,
  motion_default as default,
  motionActionPlugin,
  motionExitAttributePlugin,
  stagger2 as stagger
};
