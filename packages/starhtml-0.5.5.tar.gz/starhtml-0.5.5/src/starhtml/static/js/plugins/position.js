import { autoUpdate, offset, flip, shift, hide, size, computePosition } from "https://cdn.jsdelivr.net/npm/@floating-ui/dom@1/+esm";
import { mergePatch, effect, getPath } from "datastar";
const SHOW_DELAY_MS = 10;
const SETTLE_MS = 100;
const SECONDARY_UPDATE_MS = 150;
const DEFAULTS = {
  padding: 10,
  verticalGapPx: 3,
  horizontalOverlapPx: -4
};
function resolveReferenceEl(el, anchor, config) {
  if (!anchor?.isConnected) return null;
  const parentPopover = el.parentElement?.closest("[popover]:popover-open");
  const side = config.placement.split("-")[0];
  if (config.container === "parent" && parentPopover) return parentPopover;
  if (config.container === "auto" && parentPopover && (side === "top" || side === "bottom"))
    return parentPopover;
  return anchor;
}
function computeDefaultOffset(reference, config, defaults) {
  let offsetValue = config.offset;
  const side = config.placement.split("-")[0];
  try {
    const htmlRef = reference;
    const parentPopover = htmlRef?.parentElement?.closest(
      "[popover]:popover-open"
    );
    const nested = !!parentPopover;
    const needsEdgeDistance = nested && (config.container === "parent" || config.container === "auto" && (side === "left" || side === "right"));
    if (needsEdgeDistance && parentPopover) {
      const parentRect = parentPopover.getBoundingClientRect();
      const refRect = htmlRef.getBoundingClientRect();
      const edgeDistances = {
        right: parentRect.right - refRect.right,
        left: refRect.left - parentRect.left,
        bottom: parentRect.bottom - refRect.bottom,
        top: refRect.top - parentRect.top
      };
      const distanceToEdge = edgeDistances[side];
      const adjust = side === "top" || side === "bottom" ? defaults.verticalGapPx : defaults.horizontalOverlapPx;
      offsetValue = distanceToEdge + (config.hasCustomOffset ? config.offset : adjust);
    } else if (nested && config.container !== "none" && !config.hasCustomOffset) {
      offsetValue = side === "top" || side === "bottom" ? defaults.verticalGapPx : defaults.horizontalOverlapPx;
    }
  } catch {
  }
  return offsetValue;
}
const VALID_PLACEMENTS = [
  "top",
  "bottom",
  "left",
  "right",
  "top-start",
  "top-end",
  "bottom-start",
  "bottom-end",
  "left-start",
  "left-end",
  "right-start",
  "right-end"
];
function adjustFixedY(side, align, refRect, floatRect, offset2) {
  if (side === "left" || side === "right") {
    if (align === "start") return refRect.top;
    if (align === "end") return refRect.bottom - floatRect.height;
    return refRect.y + (refRect.height - floatRect.height) / 2;
  }
  if (side === "top") return refRect.top - floatRect.height - offset2;
  if (side === "bottom") return refRect.bottom + offset2;
  return refRect.y;
}
function buildVirtualRef(pageX, pageY, el) {
  const viewportX = pageX - window.scrollX;
  const viewportY = pageY - window.scrollY;
  return {
    getBoundingClientRect: () => ({
      x: viewportX,
      y: viewportY,
      left: viewportX,
      top: viewportY,
      right: viewportX,
      bottom: viewportY,
      width: 0,
      height: 0
    }),
    contextElement: el
  };
}
async function computeFloatingPosition(reference, floating, config) {
  const cfgDefaults = getGlobalConfig().defaults || {};
  const padding = Number(cfgDefaults.padding ?? DEFAULTS.padding);
  const offsetValue = computeDefaultOffset(reference, config, {
    padding,
    verticalGapPx: Number(cfgDefaults.verticalGapPx ?? DEFAULTS.verticalGapPx),
    horizontalOverlapPx: Number(cfgDefaults.horizontalOverlapPx ?? DEFAULTS.horizontalOverlapPx)
  });
  const mainAxis = config.offsetMain ?? offsetValue;
  const crossAxis = config.offsetCross ?? void 0;
  const middleware = [
    crossAxis === void 0 ? offset(mainAxis) : offset({ mainAxis, crossAxis })
  ];
  if (config.flip) middleware.push(flip({ padding }));
  if (config.shift) middleware.push(shift({ padding }));
  if (config.hide) middleware.push(hide());
  if (config.autoSize) {
    middleware.push(
      size({
        apply: ({ availableWidth, availableHeight, elements }) => {
          Object.assign(elements.floating.style, {
            maxWidth: `${availableWidth}px`,
            maxHeight: `${availableHeight}px`
          });
        },
        padding: 10
      })
    );
  }
  const strategy = floating.hasAttribute("popover") ? "fixed" : config.strategy;
  const { x, y, placement } = await computePosition(reference, floating, {
    placement: config.placement,
    strategy,
    middleware
  });
  if (x === 0 && y === 0) {
    const { width, height } = reference.getBoundingClientRect();
    if (width === 0 || height === 0) {
      return { x: -9999, y: -9999, placement };
    }
  }
  let finalY = y;
  if (strategy === "fixed" && !config.isVirtual) {
    const refRect = reference.getBoundingClientRect();
    const floatRect = floating.getBoundingClientRect();
    const [side, align] = config.placement.split("-");
    finalY = adjustFixedY(side, align, refRect, floatRect, offsetValue);
  }
  const position = { x: Math.round(x), y: Math.round(finalY), placement };
  return position;
}
const shouldUpdatePosition = (current, last, threshold = 2) => Math.abs(current.x - last.x) > threshold || Math.abs(current.y - last.y) > threshold || current.placement !== last.placement;
const extract = (value) => {
  if (typeof value === "string") return value;
  if (value instanceof Set) {
    const arr = Array.from(value);
    if (arr.length === 0) return "true";
    return String(arr[0]) || "";
  }
  return "";
};
const extractPlacement = (value) => {
  let str = extract(value) || "bottom";
  str = str.replace(/^(top|bottom|left|right)(start|end)$/i, "$1-$2");
  const hyphenMap = {
    topstart: "top-start",
    topend: "top-end",
    bottomstart: "bottom-start",
    bottomend: "bottom-end",
    leftstart: "left-start",
    leftend: "left-end",
    rightstart: "right-start",
    rightend: "right-end"
  };
  const normalized = hyphenMap[str.toLowerCase()] || str;
  return VALID_PLACEMENTS.includes(normalized) ? normalized : "bottom";
};
function getPositionArgNames(signal = "position") {
  return [
    `${signal}_x`,
    `${signal}_y`,
    `${signal}_placement`,
    `${signal}_visible`,
    `${signal}_is_positioning`
  ];
}
function getGlobalConfig() {
  const cfg = window.__starhtml_position_config || {};
  return {
    signal: cfg.signal ?? "position",
    defaults: cfg.defaults,
    autoUpdate: cfg.autoUpdate
  };
}
const positionAttributePlugin = {
  name: "position",
  requirement: { key: "must", value: "allowed" },
  apply({ el, value, mods }) {
    const modSigRaw = extract(mods.get("signal_prefix"));
    const fallback = getGlobalConfig().signal;
    const sig = modSigRaw || fallback;
    const initPatch = {
      [`${sig}_x`]: 0,
      [`${sig}_y`]: 0,
      [`${sig}_placement`]: "bottom",
      [`${sig}_visible`]: false,
      [`${sig}_is_positioning`]: false
    };
    mergePatch(initPatch);
    let offsetValue = extract(mods.get("offset"));
    if (offsetValue?.startsWith("n")) {
      offsetValue = `-${offsetValue.substring(1)}`;
    }
    const hasCustomOffset = !!offsetValue;
    const offsetMain = extract(mods.get("offset_main"));
    const offsetCross = extract(mods.get("offset_cross"));
    const containerParam = extract(mods.get("container")) || "auto";
    if (!["auto", "none", "parent"].includes(containerParam)) {
      console.warn(`Invalid container parameter: ${containerParam}. Using 'auto'.`);
    }
    const anchorFromValue = value?.split(" ")[0].trim() ?? "";
    const config = {
      anchor: extract(mods.get("anchor")) || anchorFromValue,
      placement: extractPlacement(mods.get("placement")),
      strategy: extract(mods.get("strategy")) || "absolute",
      offset: offsetValue ? Number(offsetValue) : 8,
      hasCustomOffset,
      offsetMain: offsetMain ? Number(offsetMain) : null,
      offsetCross: offsetCross ? Number(offsetCross) : null,
      // For boolean flags: if the modifier exists (even as empty Set), it's true unless explicitly "false"
      flip: mods.has("flip") ? extract(mods.get("flip")) !== "false" : true,
      shift: mods.has("shift") ? extract(mods.get("shift")) !== "false" : true,
      hide: mods.has("hide") ? extract(mods.get("hide")) !== "false" : false,
      autoSize: mods.has("auto_size") ? extract(mods.get("auto_size")) !== "false" : false,
      container: ["auto", "none", "parent"].includes(containerParam) ? containerParam : "auto"
    };
    const cursorXPathRaw = extract(mods.get("cursor_x"));
    const cursorYPathRaw = extract(mods.get("cursor_y"));
    const cursorXPath = cursorXPathRaw?.replace(/^\$/, "");
    const cursorYPath = cursorYPathRaw?.replace(/^\$/, "");
    const isCursorMode = Boolean(cursorXPath && cursorYPath);
    const anchor = config.anchor ? document.getElementById(config.anchor) : null;
    if (!isCursorMode && !anchor && !el.hasAttribute("popover")) return;
    let cleanup = null;
    let lastPos = { x: -999, y: -999, placement: "" };
    let hasPositioned = false;
    let showTimer = null;
    let settlementTimer = null;
    let domHistory = [];
    let isLocked = false;
    let lockUntil = 0;
    const prepareHiddenState = () => {
      const baseStyle = { visibility: "hidden", opacity: "0" };
      const style = config.hide ? { ...baseStyle, transition: "opacity 150ms ease-out" } : baseStyle;
      if (config.hide || el.hasAttribute("popover")) {
        Object.assign(el.style, style);
      }
    };
    prepareHiddenState();
    const checkDOMOscillation = (x, y) => {
      const now = Date.now();
      domHistory.push({ x, y, timestamp: now });
      domHistory = domHistory.filter((h) => now - h.timestamp < 1e3);
      if (domHistory.length >= 4) {
        const recent = domHistory.slice(-4);
        const positions = new Set(recent.map((p) => `${p.x},${p.y}`));
        if (positions.size === 2 && now - recent[0].timestamp < 300) {
          isLocked = true;
          lockUntil = now + 2e3;
          return true;
        }
      }
      if (now > lockUntil) isLocked = false;
      return isLocked;
    };
    const setPositioning = (state) => {
      el.setAttribute("data-positioning", state);
      mergePatch({ [`${sig}_is_positioning`]: state === "true" });
    };
    const getTargetElement = () => {
      if (isCursorMode) return null;
      const target = anchor || document.getElementById(config.anchor);
      if (!target?.isConnected) return null;
      return resolveReferenceEl(el, target, config);
    };
    const updatePosition = async () => {
      const useVirtual = isCursorMode;
      let reference = null;
      if (useVirtual) {
        let pageX = 0;
        let pageY = 0;
        try {
          pageX = Number(getPath(cursorXPath)) || 0;
          pageY = Number(getPath(cursorYPath)) || 0;
        } catch {
        }
        reference = buildVirtualRef(pageX, pageY, el);
      } else {
        const target = getTargetElement();
        if (!target) return;
        reference = target;
      }
      if (!reference) return;
      try {
        const hasDataShow = el.hasAttribute("data-show");
        const effStrategy = hasDataShow && !mods.has("strategy") ? "fixed" : el.hasAttribute("popover") || useVirtual ? mods.has("strategy") ? config.strategy : "fixed" : config.strategy;
        const result = await computeFloatingPosition(reference, el, {
          ...config,
          strategy: effStrategy,
          isVirtual: useVirtual
        });
        const patch = {};
        if (shouldUpdatePosition(result, lastPos)) {
          if (!checkDOMOscillation(result.x, result.y)) {
            const strategy = effStrategy;
            Object.assign(el.style, {
              position: strategy,
              left: "0px",
              top: "0px",
              transform: `translate3d(${result.x}px, ${result.y}px, 0)`,
              willChange: "transform"
            });
            lastPos = result;
            patch[`${sig}_x`] = result.x;
            patch[`${sig}_y`] = result.y;
            patch[`${sig}_placement`] = result.placement;
            if (settlementTimer) clearTimeout(settlementTimer);
            settlementTimer = window.setTimeout(() => setPositioning("false"), SETTLE_MS);
          } else {
            setPositioning("false");
          }
        }
        const isValidPosition = result.x !== 0 && result.y !== 0 && result.x > -1e3 && result.y > -1e3;
        if (!hasPositioned && isValidPosition) {
          hasPositioned = true;
          if (config.hide || el.hasAttribute("popover")) {
            el.style.visibility = "visible";
            if (config.hide) {
              showTimer = window.setTimeout(() => {
                el.style.opacity = "1";
              }, SHOW_DELAY_MS);
            } else {
              el.style.opacity = "1";
            }
          }
          patch[`${sig}_visible`] = true;
        }
        if (Object.keys(patch).length) mergePatch(patch);
      } finally {
      }
    };
    const isVisible = () => {
      const { display, visibility } = getComputedStyle(el);
      return display !== "none" && visibility !== "hidden" && el.offsetWidth > 0 && el.offsetHeight > 0;
    };
    const start = () => {
      const useVirtual = isCursorMode;
      if (useVirtual) {
        updatePosition();
        const handleScroll = () => {
          updatePosition();
        };
        window.addEventListener("scroll", handleScroll, true);
        cleanup = () => {
          window.removeEventListener("scroll", handleScroll, true);
        };
        return;
      }
      const target = getTargetElement();
      if (!target || cleanup) return;
      if (el.hasAttribute("popover")) {
        requestAnimationFrame(updatePosition);
      }
      const cfg = getGlobalConfig();
      const au = cfg.autoUpdate || {};
      const elementResize = au.elementResize ?? false;
      const layoutShift = au.layoutShift ?? false;
      cleanup = autoUpdate(target, el, updatePosition, {
        ancestorScroll: true,
        ancestorResize: true,
        elementResize,
        layoutShift
      });
    };
    const stop = () => {
      cleanup?.();
      cleanup = null;
      hasPositioned = false;
      for (const timer of [showTimer, settlementTimer]) {
        if (timer) clearTimeout(timer);
      }
      showTimer = settlementTimer = null;
      domHistory = [];
      isLocked = false;
      lockUntil = 0;
      el.removeAttribute("data-positioning");
      if (config.hide || el.hasAttribute("popover")) {
        prepareHiddenState();
      }
      lastPos = { x: -999, y: -999, placement: "" };
      mergePatch({ [`${sig}_is_positioning`]: false, [`${sig}_visible`]: false });
    };
    const handleManualUpdate = () => {
      if (!cleanup) {
        start();
      }
      requestAnimationFrame(() => updatePosition());
    };
    el.addEventListener("position-update", handleManualUpdate);
    const dataShowAttr = el.getAttribute("data-show") || "";
    const showSignalMatch = dataShowAttr.match(/\$([a-zA-Z_][\w]*)/);
    let cleanupEffect = null;
    let isPositioning = false;
    if (!el.hasAttribute("popover") && (showSignalMatch || isCursorMode)) {
      const showSignal = showSignalMatch ? showSignalMatch[1] : null;
      cleanupEffect = effect(() => {
        const hasSignal = !!showSignal;
        const isShown = hasSignal ? Boolean(getPath(showSignal)) : false;
        if (isShown && !isPositioning) {
          isPositioning = true;
          setPositioning("true");
          start();
          if (isCursorMode) {
            updatePosition();
            setTimeout(() => {
              updatePosition();
            }, 0);
          } else {
            setTimeout(() => {
              updatePosition();
              setTimeout(() => updatePosition(), SECONDARY_UPDATE_MS);
            }, SHOW_DELAY_MS);
          }
        } else if (!isShown && isPositioning) {
          isPositioning = false;
          stop();
        }
      });
    }
    if (el.hasAttribute("popover")) {
      const handleToggle = (e) => {
        if (e.newState === "open") {
          config.strategy = "fixed";
          Object.assign(el.style, { margin: "0", inset: "unset" });
          prepareHiddenState();
          const isNested = el.parentElement?.closest("[popover]:popover-open") !== null;
          const startFn = () => el.matches(":popover-open") && start();
          if (isNested) {
            setTimeout(startFn, 20);
          } else {
            requestAnimationFrame(startFn);
          }
        } else if (e.newState === "closed") {
          stop();
        }
      };
      const handleBeforeToggle = (e) => {
        if (e.newState === "open") {
          Object.assign(el.style, { margin: "0", inset: "unset" });
          prepareHiddenState();
        }
      };
      el.addEventListener("toggle", handleToggle);
      el.addEventListener("beforetoggle", handleBeforeToggle);
      return () => {
        el.removeEventListener("toggle", handleToggle);
        el.removeEventListener("beforetoggle", handleBeforeToggle);
        el.removeEventListener("position-update", handleManualUpdate);
        cleanupEffect?.();
        stop();
      };
    }
    if (isVisible()) start();
    return () => {
      el.removeEventListener("position-update", handleManualUpdate);
      cleanupEffect?.();
      stop();
    };
  }
};
const positionPlugin = {
  ...positionAttributePlugin,
  argNames: [],
  setConfig(config) {
    window.__starhtml_position_config = config;
    const signal = config?.signal ? String(config.signal) : "position";
    this.argNames = getPositionArgNames(signal);
  }
};
var position_default = positionPlugin;
export {
  position_default as default
};
