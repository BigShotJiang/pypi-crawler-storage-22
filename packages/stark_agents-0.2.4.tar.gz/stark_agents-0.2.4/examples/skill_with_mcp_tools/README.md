# Skill with MCP tools
- You need to add the `tools.py` file with the tool `TOOLS` containing MCP tool information.
- MCP tools can be passed in `mcp` dictionary key.
- You can also pass `@stark_tool` functions as `list` in `function` key of the `TOOLS` dictionary.