# StarsTurtle

StarsTurtle 是一个基于 PyQt5 的海龟图形库，提供了丰富的绘图功能，支持多种形状、填充模式、画笔样式等功能。

## 安装

```bash
pip install starsturtle