# Created by a Chinese developer @ChengCheng
# -*- coding: utf-8 -*-
import sys
import math
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget
from PyQt5.QtGui import QPainter, QPen, QColor, QBrush, QPolygonF, QFont
from PyQt5.QtCore import Qt, QPointF, QTimer

# ====================== 全局状态 ======================
_draw_queue = []
_turtle_pos = QPointF(400.0, 300.0)  # 浮点坐标，提升精度
_turtle_angle = 0
_turtle_pen_down = True
_turtle_color = QColor(255, 0, 0)
_turtle_width = 2

_animation_queue = []
_timer = QTimer()
_animation_speed = 150  # 动画间隔(ms)，越小越快

# 填充相关状态
_fill_mode = False
_fill_path = []
_fill_color = QColor(255, 0, 0)

# 画笔形状和显示状态
_turtle_visible = True  # 画笔是否可见
_turtle_shape = "classic"  # 画笔形状，可以是 "classic", "arrow", "turtle", "circle", "square", "triangle"

# 颜色常量
RED = QColor(255, 0, 0)
GREEN = QColor(0, 255, 0)
BLUE = QColor(0, 0, 255)
WHITE = QColor(255, 255, 255)
BLACK = QColor(0, 0, 0)
YELLOW = QColor(255, 255, 0)
CYAN = QColor(0, 255, 255)
MAGENTA = QColor(255, 0, 255)

# 窗口背景
BG_COLOR = QColor(20, 20, 30)

# ====================== 窗口 ======================
class PyDrawWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PyDraw1")
        self.setGeometry(100, 100, 800, 600)
        self.canvas = CanvasWidget(self)
        self.setCentralWidget(self.canvas)

class CanvasWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background-color: rgb({BG_COLOR.red()}, {BG_COLOR.green()}, {BG_COLOR.blue()});")

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        
        # 绘制填充区域
        if _fill_mode and _fill_path:
            p.setBrush(QBrush(_fill_color))
            p.setPen(QPen(_fill_color, _turtle_width))
            p.drawPolygon(QPolygonF(_fill_path))
        
        # 绘制普通图形
        for f in _draw_queue:
            f(p)
        
        # 绘制海龟
        if _turtle_visible:
            self.draw_turtle(p)

    def draw_turtle(self, p):
        p.setPen(QPen(QColor(255, 100, 100), 2))
        p.setBrush(QBrush(QColor(255, 100, 100)))
        
        x, y = _turtle_pos.x(), _turtle_pos.y()
        rad = math.radians(_turtle_angle)
        
        # 根据不同的画笔形状绘制不同的图形
        if _turtle_shape == "classic":
            # 经典三角形
            pts = [
                QPointF(x, y),
                QPointF(x - 12 * math.cos(rad - math.pi/6), y + 12 * math.sin(rad - math.pi/6)),
                QPointF(x - 12 * math.cos(rad + math.pi/6), y + 12 * math.sin(rad + math.pi/6))
            ]
            p.drawPolygon(QPolygonF(pts))
        elif _turtle_shape == "arrow":
            # 箭头形状
            head_len = 12
            arrow_width = 8
            pts = [
                QPointF(x, y),  # 尖端
                QPointF(x - head_len * math.cos(rad - math.pi/6), y + head_len * math.sin(rad - math.pi/6)),  # 左后
                QPointF(x - (head_len*0.6) * math.cos(rad), y + (head_len*0.6) * math.sin(rad)),  # 后方中间
                QPointF(x - head_len * math.cos(rad + math.pi/6), y + head_len * math.sin(rad + math.pi/6))  # 右后
            ]
            p.drawPolygon(QPolygonF(pts))
        elif _turtle_shape == "turtle":
            # 乌龟形状（简化版）
            p.setBrush(QBrush(QColor(120, 180, 60)))  # 绿色乌龟壳
            p.drawEllipse(int(x - 10), int(y - 8), 20, 16)  # 乌龟壳
            
            p.setBrush(QBrush(QColor(200, 150, 100)))  # 棕色头部
            head_x = x + 8 * math.cos(rad)
            head_y = y - 8 * math.sin(rad)
            p.drawEllipse(int(head_x - 4), int(head_y - 4), 8, 8)  # 头部
        elif _turtle_shape == "circle":
            # 圆形
            p.setBrush(QBrush(QColor(255, 100, 100)))
            p.drawEllipse(int(x - 8), int(y - 8), 16, 16)
        elif _turtle_shape == "square":
            # 正方形
            p.setBrush(QBrush(QColor(255, 100, 100)))
            p.drawRect(int(x - 8), int(y - 8), 16, 16)
        elif _turtle_shape == "triangle":
            # 三角形（等边）
            size = 10
            angle_offset = math.pi / 6  # 30度
            pts = [
                QPointF(x + size * math.cos(rad), y - size * math.sin(rad)),
                QPointF(x + size * math.cos(rad + 2*math.pi/3), y - size * math.sin(rad + 2*math.pi/3)),
                QPointF(x + size * math.cos(rad + 4*math.pi/3), y - size * math.sin(rad + 4*math.pi/3))
            ]
            p.drawPolygon(QPolygonF(pts))

# ====================== 基础绘图函数 ======================
def line(x1, y1, x2, y2, color=None, width=None):
    c = color if isinstance(color, QColor) else _turtle_color
    w = float(width) if width is not None else float(_turtle_width)
    def draw_func(painter):
        painter.setPen(QPen(c, w))
        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))
    _draw_queue.append(draw_func)
    
    # 如果是填充模式，记录路径点
    if _fill_mode:
        _fill_path.append(QPointF(x2, y2))

def forward(d, color=None):
    _animation_queue.append(lambda: _forward_real(d, color))

def _forward_real(d, color):
    global _turtle_pos
    x1, y1 = _turtle_pos.x(), _turtle_pos.y()
    rad = math.radians(_turtle_angle)
    x2 = x1 + d * math.cos(rad)
    y2 = y1 - d * math.sin(rad)
    
    if _turtle_pen_down:
        line(x1, y1, x2, y2, color)
    
    _turtle_pos = QPointF(x2, y2)
    
    # 如果是填充模式，记录路径点
    if _fill_mode:
        _fill_path.append(QPointF(x2, y2))
    
    win.canvas.update()

def left(a):
    _animation_queue.append(lambda: _left_real(a))

def _left_real(a):
    global _turtle_angle
    _turtle_angle += a
    win.canvas.update()

def penup():
    _animation_queue.append(_penup_real)

def _penup_real():
    global _turtle_pen_down
    _turtle_pen_down = False

def pendown():
    _animation_queue.append(_pendown_real)

def _pendown_real():
    global _turtle_pen_down
    _turtle_pen_down = True

# ====================== 新增函数 ======================
def goto(x, y, color=None):
    """移动海龟到指定坐标，画笔落下时绘制线条"""
    _animation_queue.append(lambda: _goto_real(x, y, color))

def _goto_real(x, y, color):
    global _turtle_pos
    x1, y1 = _turtle_pos.x(), _turtle_pos.y()
    if _turtle_pen_down:
        line(x1, y1, x, y, color)
    _turtle_pos = QPointF(float(x), float(y))
    
    # 如果是填充模式，记录路径点
    if _fill_mode:
        _fill_path.append(QPointF(float(x), float(y)))
    
    win.canvas.update()

def speed(s):
    """设置动画速度，范围1-10（1最慢，10最快）"""
    global _animation_speed
    s = max(1, min(10, s))
    _animation_speed = int(200 / s)
    _timer.setInterval(_animation_speed)

def clear():
    """清空画布"""
    _animation_queue.append(_clear_real)

def _clear_real():
    global _draw_queue, _fill_path
    _draw_queue = []
    _fill_path = []
    win.canvas.update()

def text(content, x, y, color=None, font_size=12, font_name="SimHei"):
    """
    在指定坐标绘制文本
    :param content: 文字内容
    :param x: 文本左上角X坐标
    :param y: 文本左上角Y坐标
    :param color: 文本颜色，默认海龟颜色
    :param font_size: 字体大小，默认12
    :param font_name: 字体名称，默认"SimHei"
    """
    _animation_queue.append(lambda: _text_real(content, x, y, color, font_size, font_name))

def _text_real(content, x, y, color, font_size, font_name):
    c = color if isinstance(color, QColor) else _turtle_color
    
    def draw_func(painter):
        painter.setPen(QPen(c, _turtle_width))
        painter.setFont(QFont(font_name, font_size))
        painter.drawText(x, y, content)
    _draw_queue.append(draw_func)
    win.canvas.update()

def begin_fill(color=None):
    """开始填充模式，记录后续绘制路径"""
    _animation_queue.append(lambda: _begin_fill_real(color))

def _begin_fill_real(color):
    global _fill_mode, _fill_color, _fill_path
    _fill_mode = True
    _fill_color = color if isinstance(color, QColor) else _turtle_color
    _fill_path = [QPointF(_turtle_pos.x(), _turtle_pos.y())]


# ====================== 2D图形函数 ======================
def draw_square(size, color, x=None, y=None):
    """绘制正方形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        for _ in range(4):
            forward(size, color)
            left(90)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_triangle(size, color, x=None, y=None):
    """绘制三角形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        for _ in range(3):
            forward(size, color)
            left(120)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_rectangle(width, height, color, x=None, y=None):
    """绘制矩形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        for _ in range(2):
            forward(width, color)
            left(90)
            forward(height, color)
            left(90)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_polygon(sides, size, color, x=None, y=None):
    """绘制多边形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        angle = 360 / sides
        for _ in range(sides):
            forward(size, color)
            left(angle)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_circle(radius, color, step_mode=False, x=None, y=None):
    """绘制圆形，支持直接坐标定位，画完后海龟停在圆右侧且无多余线条"""
    def _draw():
        # 记录画圆前海龟的原始位置
        original_x, original_y = _turtle_pos.x(), _turtle_pos.y()
        # 确定圆心坐标
        center_x = x if x is not None else original_x
        center_y = y if y is not None else original_y

        # 移动到圆心（如果传入了坐标）
        if x is not None and y is not None:
            penup()
            goto(center_x, center_y)
            pendown()
        
        # 绘制圆形
        if step_mode:
            _draw_circle_step(radius, color)
        else:
            def draw_func(painter):
                painter.setPen(QPen(color, _turtle_width))
                painter.drawEllipse(
                    center_x - radius,
                    center_y - radius,
                    radius * 2,
                    radius * 2
                )
            _draw_queue.append(draw_func)
            win.canvas.update()
        
        # 核心修复：抬笔移动到圆的右侧，使用圆心坐标计算
        penup()
        goto(center_x + radius, center_y)
        pendown()
    
    _animation_queue.append(_draw)

def _draw_circle_step(radius, color):
    """修复版分步圆弧绘制：无多余半径线，纯圆周轨迹移动"""
    steps = 360  # 分步数量，数值越大越平滑
    rad_step = 2 * math.pi / steps  # 每步递增的弧度值

    # 记录圆心坐标
    center_x = _turtle_pos.x()
    center_y = _turtle_pos.y()
    # 初始角度：匹配海龟当前朝向
    current_rad = math.radians(_turtle_angle)

    # 1. 抬笔移动到圆周的第一个点（不画线）
    penup()
    start_x = center_x + radius * math.cos(current_rad)
    start_y = center_y - radius * math.sin(current_rad)
    goto(start_x, start_y)
    pendown()

    # 2. 绘制圆周
    for _ in range(steps):
        current_rad += rad_step
        point_x = center_x + radius * math.cos(current_rad)
        point_y = center_y - radius * math.sin(current_rad)
        goto(point_x, point_y, color)

    win.canvas.update()

# ====================== 新增功能函数 ======================

def shape(shape_type=None):
    """设置或获取画笔形状
    :param shape_type: 形状类型 ("classic", "arrow", "turtle", "circle", "square", "triangle")
    :return: 当前形状（如果不提供参数）
    """
    global _turtle_shape
    if shape_type is None:
        return _turtle_shape
    else:
        valid_shapes = ["classic", "arrow", "turtle", "circle", "square", "triangle"]
        if shape_type in valid_shapes:
            _turtle_shape = shape_type
            win.canvas.update()
        else:
            print(f"Invalid shape: {shape_type}. Valid shapes are: {valid_shapes}")

def showturtle():
    """显示画笔"""
    global _turtle_visible
    _turtle_visible = True
    win.canvas.update()

def hideturtle():
    """隐藏画笔"""
    global _turtle_visible
    _turtle_visible = False
    win.canvas.update()

def isvisible():
    """返回画笔是否可见"""
    return _turtle_visible

# ====================== 动画控制 ======================
def done():
    def execute_step():
        if _animation_queue:
            _animation_queue.pop(0)()
    _timer.timeout.connect(execute_step)
    _timer.setInterval(_animation_speed)
    _timer.start()
    win.show()
    sys.exit(app.exec_())

# ====================== 初始化 ======================
app = QApplication(sys.argv)
win = PyDrawWindow()