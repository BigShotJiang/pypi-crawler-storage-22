﻿from .StarsTurtle import (
    # 函数
    forward, left, penup, pendown, goto, speed, clear, text,
    begin_fill, draw_square, draw_triangle, draw_rectangle,
    draw_polygon, draw_circle, shape, showturtle, hideturtle, isvisible,
    line, done,
    
    # 颜色常量
    RED, GREEN, BLUE, WHITE, BLACK, YELLOW, CYAN, MAGENTA,
    
    # 全局变量
    app, win
)

__version__ = "1.0.0"
__author__ = "LittleLambPython"
__all__ = [
    # 函数列表
    'forward', 'left', 'penup', 'pendown', 'goto', 'speed', 'clear', 'text',
    'begin_fill','draw_square', 'draw_triangle', 'draw_rectangle',
    'draw_polygon', 'draw_circle', 'shape', 'showturtle', 'hideturtle', 'isvisible',
    'line', 'done',
    # 颜色常量
    'RED', 'GREEN', 'BLUE', 'WHITE', 'BLACK', 'YELLOW', 'CYAN', 'MAGENTA'
]