# StarsTurtle1.0.3

StarsTurtle 是一个基于 PyQt5 的海龟图形库，提供了丰富的绘图功能，支持多种形状、填充模式、画笔样式等功能。

## 新增功能:
1.增加抗锯齿功能。
2.增加保存图片功能。

## 安装

请先安装PyQt5
```bash
pip install PyQt5

pip install starsturtle
```
## 代码示例:
```python
# main.py - StarsTurtle 使用示例
from StarsTurtle.StarsTurtle import *
import time

def demo():
    # 设置画笔速度
    speed(5)  # 速度为5（1-10之间）

    # 绘制多个图形展示功能
    # 绘制一个蓝色正方形
    draw_square(100, BLUE, 100, 100)

    # 绘制一个绿色三角形
    draw_triangle(100, GREEN, 300, 100)

    # 绘制一个红色圆形
    draw_circle(50, RED, x=200, y=300)

    # 绘制一个多边形
    draw_polygon(6, 60, YELLOW, 500, 200)

    # 使用默认海龟绘制一个五角星
    penup()
    goto(400, 300)
    pendown()
    for i in range(5):
        forward(100)
        left(144)

    # 绘制一个填充的矩形
    penup()
    goto(500, 400)
    pendown()
    begin_fill(CYAN)
    draw_rectangle(120, 80, CYAN)
    end_fill()
    
    # 创建另一个海龟并演示多海龟功能
    turtle2 = create_turtle(200, 200, 0, GREEN, 3, "turtle")
    turtle2.width = 3  # 直接赋值，而不是函数调用
    turtle2.forward(100)
    turtle2.left(90)
    turtle2.forward(100)
    turtle2.left(90)
    turtle2.forward(100)
    turtle2.left(90)
    turtle2.forward(100)

    # 添加文字
    text("StarsTurtle 绘图示例", 300, 550, WHITE, 16, "SimHei")

    # 在done()之后执行保存图片（使用线程来实现）
    import threading
    
    def save_after_done():
        time.sleep(3)  # 等待动画完成
        save_image("my_artwork.png", "PNG")
        print("绘图完成，图片已保存！")
    
    # 启动保存线程
    save_thread = threading.Thread(target=save_after_done)
    save_thread.daemon = True
    save_thread.start()
    
    # 显示窗口和执行动画
    done()

if __name__ == "__main__":
    demo()
```