# Created by a Chinese developer @ChengCheng
# -*- coding: utf-8 -*-
import sys
import math
import os
from collections import deque
try:
    from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QFileDialog
    from PyQt5.QtGui import QPainter, QPen, QColor, QBrush, QPolygonF, QFont, QPixmap, QImage
    from PyQt5.QtCore import Qt, QPointF, QTimer
except ImportError:
    vbs = """MsgBox "错误:未安装PyQt5\n\n请运行CMD命令:pip install PyQt5",16,"StarsTurtle 错误"
    """
    with open("temp_error.vbs","w",encoding="gbk") as f:
        f.write(vbs)
    os.system("cscript //nologo temp_error.vbs")
    os.remove("temp_error.vbs")
    sys.exit(1)

# ====================== 全局状态 ======================
_draw_queue = []
_turtle_pos = QPointF(400.0, 300.0)  # 浮点坐标，提升精度
_turtle_angle = 0
_turtle_pen_down = True
_turtle_color = QColor(255, 0, 0)
_turtle_width = 2

_animation_queue = []
_timer = QTimer()
_animation_speed = 150  # 动画间隔(ms)，越小越快

# 填充相关状态
_fill_mode = False
_fill_path = []
_fill_color = QColor(255, 0, 0)

# 画笔形状和显示状态
_turtle_visible = True  # 画笔是否可见
_turtle_shape = "classic"  # 画笔形状，可以是 "classic", "arrow", "turtle", "circle", "square", "triangle"

# 颜色常量
RED = QColor(255, 0, 0)
GREEN = QColor(0, 255, 0)
BLUE = QColor(0, 0, 255)
WHITE = QColor(255, 255, 255)
BLACK = QColor(0, 0, 0)
YELLOW = QColor(255, 255, 0)
CYAN = QColor(0, 255, 255)
MAGENTA = QColor(255, 0, 255)

# 窗口背景
BG_COLOR = QColor(20, 20, 30)

# 多海龟支持
_all_turtles = []  # 存储所有海龟对象

# ====================== 海龟类定义 ======================
class Turtle:
    def __init__(self, x=400.0, y=300.0, angle=0, color=RED, width=2, shape="classic"):
        self.pos = QPointF(float(x), float(y))
        self.angle = angle
        self.pen_down = True
        self.color = color
        self.width = width
        self.shape = shape
        self.visible = True
        self.fill_mode = False
        self.fill_path = []
        self.fill_color = color
        self.active = True  # 是否活跃
        _all_turtles.append(self)

    def forward(self, d):
        _animation_queue.append(lambda: self._forward_real(d))

    def _forward_real(self, d):
        x1, y1 = self.pos.x(), self.pos.y()
        rad = math.radians(self.angle)
        x2 = x1 + d * math.cos(rad)
        y2 = y1 - d * math.sin(rad)

        if self.pen_down:
            line(x1, y1, x2, y2, self.color, self.width)

        self.pos = QPointF(x2, y2)

        # 如果是填充模式，记录路径点
        if self.fill_mode:
            self.fill_path.append(QPointF(x2, y2))

        win.canvas.update()

    def left(self, a):
        _animation_queue.append(lambda: self._left_real(a))

    def _left_real(self, a):
        self.angle += a
        win.canvas.update()

    def penup(self):
        _animation_queue.append(lambda: self._penup_real())

    def _penup_real(self):
        self.pen_down = False

    def pendown(self):
        _animation_queue.append(lambda: self._pendown_real())

    def _pendown_real(self):
        self.pen_down = True

    def goto(self, x, y):
        """移动海龟到指定坐标，画笔落下时绘制线条"""
        _animation_queue.append(lambda: self._goto_real(x, y))

    def _goto_real(self, x, y):
        x1, y1 = self.pos.x(), self.pos.y()
        if self.pen_down:
            line(x1, y1, x, y, self.color)
        self.pos = QPointF(float(x), float(y))

        # 如果是填充模式，记录路径点
        if self.fill_mode:
            self.fill_path.append(QPointF(float(x), float(y)))

        win.canvas.update()

    def setpos(self, x, y):
        """设置海龟位置，等同于goto"""
        self.goto(x, y)

    def setx(self, x):
        """设置海龟x坐标"""
        self.goto(x, self.pos.y())

    def sety(self, y):
        """设置海龟y坐标"""
        self.goto(self.pos.x(), y)

    def setheading(self, angle):
        """设置海龟朝向"""
        self.angle = angle

    def home(self):
        """回到原点"""
        self.goto(400, 300)
        self.setheading(0)

    def distance(self, x, y=None):
        """计算到某点的距离"""
        if y is None:
            # 假设x是一个点对象
            if hasattr(x, 'x') and hasattr(x, 'y'):
                target_x, target_y = x.x(), x.y()
            # 如果x是QPointF对象
            elif isinstance(x, QPointF):
                target_x, target_y = x.x(), x.y()
            # 如果x是元组或列表形式的坐标
            elif isinstance(x, (tuple, list)) and len(x) >= 2:
                target_x, target_y = x[0], x[1]
            else:
                raise ValueError("distance参数错误: 期望一个点对象、坐标对或两个数字参数")
        else:
            target_x, target_y = x, y

        dx = self.pos.x() - target_x
        dy = self.pos.y() - target_y
        return math.sqrt(dx*dx + dy*dy)

    def pos(self):
        """获取当前位置"""
        return self.pos

    def xcor(self):
        """获取x坐标"""
        return self.pos.x()

    def ycor(self):
        """获取y坐标"""
        return self.pos.y()

    def heading(self):
        """获取朝向"""
        return self.angle

    def color(self, color=None):
        """设置或获取颜色"""
        if color is None:
            return self.color
        else:
            self.color = color if isinstance(color, QColor) else QColor(color)

    def width(self, width=None):
        """设置或获取线条宽度"""
        if width is None:
            return self.width
        else:
            self.width = width

    def shape(self, shape_type=None):
        """设置或获取形状"""
        if shape_type is None:
            return self.shape
        else:
            valid_shapes = ["classic", "arrow", "turtle", "circle", "square", "triangle"]
            if shape_type in valid_shapes:
                self.shape = shape_type
                win.canvas.update()
            else:
                print(f"Invalid shape: {shape_type}. Valid shapes are: {valid_shapes}")

    def showturtle(self):
        """显示海龟"""
        self.visible = True
        win.canvas.update()

    def hideturtle(self):
        """隐藏海龟"""
        self.visible = False
        win.canvas.update()

    def isvisible(self):
        """返回海龟是否可见"""
        return self.visible

    def begin_fill(self, color=None):
        """开始填充模式，记录后续绘制路径"""
        _animation_queue.append(lambda: self._begin_fill_real(color))

    def _begin_fill_real(self, color):
        self.fill_mode = True
        self.fill_color = color if isinstance(color, QColor) else self.color
        self.fill_path = [QPointF(self.pos.x(), self.pos.y())]

    def end_fill(self):
        """结束填充模式"""
        _animation_queue.append(self._end_fill_real)

    def _end_fill_real(self):
        if self.fill_mode and len(self.fill_path) > 2:
            def draw_func(painter):
                painter.setBrush(QBrush(self.fill_color))
                painter.setPen(QPen(self.fill_color, self.width))
                painter.drawPolygon(QPolygonF(self.fill_path))
            _draw_queue.append(draw_func)
        self.fill_mode = False
        self.fill_path = []

    def stamp(self):
        """留下印记"""
        # 这里可以绘制一个当前海龟形状的小图像
        pass

    # 绘制图形的方法
    def draw_square(self, size, color=None, x=None, y=None):
        """绘制正方形，支持直接坐标定位"""
        def _draw():
            old_x, old_y = self.pos.x(), self.pos.y()
            if x is not None and y is not None:
                self.penup()
                self.goto(x, y)
                self.pendown()

            for _ in range(4):
                self.forward(size)
                self.left(90)

            self.penup()
            self.goto(old_x, old_y)
            self.pendown()

        _animation_queue.append(_draw)

    def draw_triangle(self, size, color=None, x=None, y=None):
        """绘制三角形，支持直接坐标定位"""
        def _draw():
            old_x, old_y = self.pos.x(), self.pos.y()
            if x is not None and y is not None:
                self.penup()
                self.goto(x, y)
                self.pendown()

            for _ in range(3):
                self.forward(size)
                self.left(120)

            self.penup()
            self.goto(old_x, old_y)
            self.pendown()

        _animation_queue.append(_draw)

    def draw_rectangle(self, width, height, color=None, x=None, y=None):
        """绘制矩形，支持直接坐标定位"""
        def _draw():
            old_x, old_y = self.pos.x(), self.pos.y()
            if x is not None and y is not None:
                self.penup()
                self.goto(x, y)
                self.pendown()

            for _ in range(2):
                self.forward(width)
                self.left(90)
                self.forward(height)
                self.left(90)

            self.penup()
            self.goto(old_x, old_y)
            self.pendown()

        _animation_queue.append(_draw)

    def draw_polygon(self, sides, size, color=None, x=None, y=None):
        """绘制多边形，支持直接坐标定位"""
        def _draw():
            old_x, old_y = self.pos.x(), self.pos.y()
            if x is not None and y is not None:
                self.penup()
                self.goto(x, y)
                self.pendown()

            angle = 360 / sides
            for _ in range(sides):
                self.forward(size)
                self.left(angle)

            self.penup()
            self.goto(old_x, old_y)
            self.pendown()

        _animation_queue.append(_draw)

    def draw_circle(self, radius, color=None, step_mode=False, x=None, y=None):
        """绘制圆形，支持直接坐标定位，画完后海龟停在圆右侧且无多余线条"""
        def _draw():
            # 记录画圆前海龟的原始位置
            original_x, original_y = self.pos.x(), self.pos.y()
            # 确定圆心坐标
            center_x = x if x is not None else original_x
            center_y = y if y is not None else original_y

            # 移动到圆心（如果传入了坐标）
            if x is not None and y is not None:
                self.penup()
                self.goto(center_x, center_y)
                self.pendown()

            # 绘制圆形
            if step_mode:
                self._draw_circle_step(radius)
            else:
                def draw_func(painter):
                    painter.setPen(QPen(color or self.color, self.width))
                    painter.drawEllipse(
                        int(center_x - radius),
                        int(center_y - radius),
                        int(radius * 2),
                        int(radius * 2)
                    )
                _draw_queue.append(draw_func)
                win.canvas.update()

            # 核心修复：抬笔移动到圆的右侧，使用圆心坐标计算
            self.penup()
            self.goto(center_x + radius, center_y)
            self.pendown()

        _animation_queue.append(_draw)

    def _draw_circle_step(self, radius):
        """修复版分步圆弧绘制：无多余半径线，纯圆周轨迹移动"""
        steps = 360  # 分步数量，数值越大越平滑
        rad_step = 2 * math.pi / steps  # 每步递增的弧度值

        # 记录圆心坐标
        center_x = self.pos.x()
        center_y = self.pos.y()
        # 初始角度：匹配海龟当前朝向
        current_rad = math.radians(self.angle)

        # 1. 抬笔移动到圆周的第一个点（不画线）
        self.penup()
        start_x = center_x + radius * math.cos(current_rad)
        start_y = center_y - radius * math.sin(current_rad)
        self.goto(start_x, start_y)
        self.pendown()

        # 2. 绘制圆周
        for _ in range(steps):
            current_rad += rad_step
            point_x = center_x + radius * math.cos(current_rad)
            point_y = center_y - radius * math.sin(current_rad)
            self.goto(point_x, point_y)

        win.canvas.update()


# ====================== 窗口 ======================
class StarsTurtleWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("StarsTurtle1 - 支持多海龟与高清渲染")
        self.setGeometry(100, 100, 800, 600)
        self.canvas = CanvasWidget(self)
        self.setCentralWidget(self.canvas)

class CanvasWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background-color: rgb({BG_COLOR.red()}, {BG_COLOR.green()}, {BG_COLOR.blue()});")

    def paintEvent(self, event):
        p = QPainter(self)
        # 启用抗锯齿，提高渲染质量
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setRenderHint(QPainter.HighQualityAntialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        
        # 绘制填充区域（全局状态中的填充区域）
        if _fill_mode and _fill_path:
            p.setBrush(QBrush(_fill_color))
            p.setPen(QPen(_fill_color, _turtle_width))
            p.drawPolygon(QPolygonF(_fill_path))
        
        # 绘制普通图形
        for f in _draw_queue:
            f(p)
        
        # 绘制所有活跃海龟
        for turtle in _all_turtles:
            if turtle.visible and turtle.active:
                self.draw_turtle(p, turtle)

    def draw_turtle(self, p, turtle):
        p.setPen(QPen(QColor(255, 100, 100), 2))
        p.setBrush(QBrush(QColor(255, 100, 100)))
        
        x, y = turtle.pos.x(), turtle.pos.y()
        rad = math.radians(turtle.angle)
        
        # 根据不同的画笔形状绘制不同的图形
        if turtle.shape == "classic":
            # 经典三角形
            pts = [
                QPointF(x, y),
                QPointF(x - 12 * math.cos(rad - math.pi/6), y + 12 * math.sin(rad - math.pi/6)),
                QPointF(x - 12 * math.cos(rad + math.pi/6), y + 12 * math.sin(rad + math.pi/6))
            ]
            p.drawPolygon(QPolygonF(pts))
        elif turtle.shape == "arrow":
            # 箭头形状
            head_len = 12
            arrow_width = 8
            pts = [
                QPointF(x, y),  # 尖端
                QPointF(x - head_len * math.cos(rad - math.pi/6), y + head_len * math.sin(rad - math.pi/6)),  # 左后
                QPointF(x - (head_len*0.6) * math.cos(rad), y + (head_len*0.6) * math.sin(rad)),  # 后方中间
                QPointF(x - head_len * math.cos(rad + math.pi/6), y + head_len * math.sin(rad + math.pi/6))  # 右后
            ]
            p.drawPolygon(QPolygonF(pts))
        elif turtle.shape == "turtle":
            # 乌龟形状（简化版）
            p.setBrush(QBrush(QColor(120, 180, 60)))  # 绿色乌龟壳
            p.drawEllipse(int(x - 10), int(y - 8), 20, 16)  # 乌龟壳
            
            p.setBrush(QBrush(QColor(200, 150, 100)))  # 棕色头部
            head_x = x + 8 * math.cos(rad)
            head_y = y - 8 * math.sin(rad)
            p.drawEllipse(int(head_x - 4), int(head_y - 4), 8, 8)  # 头部
        elif turtle.shape == "circle":
            # 圆形
            p.setBrush(QBrush(QColor(255, 100, 100)))
            p.drawEllipse(int(x - 8), int(y - 8), 16, 16)
        elif turtle.shape == "square":
            # 正方形
            p.setBrush(QBrush(QColor(255, 100, 100)))
            p.drawRect(int(x - 8), int(y - 8), 16, 16)
        elif turtle.shape == "triangle":
            # 三角形（等边）
            size = 10
            angle_offset = math.pi / 6  # 30度
            pts = [
                QPointF(x + size * math.cos(rad), y - size * math.sin(rad)),
                QPointF(x + size * math.cos(rad + 2*math.pi/3), y - size * math.sin(rad + 2*math.pi/3)),
                QPointF(x + size * math.cos(rad + 4*math.pi/3), y - size * math.sin(rad + 4*math.pi/3))
            ]
            p.drawPolygon(QPolygonF(pts))

# ====================== 基础绘图函数 ======================
def line(x1, y1, x2, y2, color=None, width=None):
    c = color if isinstance(color, QColor) else _turtle_color
    w = float(width) if width is not None else float(_turtle_width)
    def draw_func(painter):
        painter.setPen(QPen(c, w))
        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))
    _draw_queue.append(draw_func)
    
    # 如果是填充模式，记录路径点
    if _fill_mode:
        _fill_path.append(QPointF(x2, y2))

def forward(d, color=None):
    _animation_queue.append(lambda: _forward_real(d, color))

def _forward_real(d, color):
    global _turtle_pos
    x1, y1 = _turtle_pos.x(), _turtle_pos.y()
    rad = math.radians(_turtle_angle)
    x2 = x1 + d * math.cos(rad)
    y2 = y1 - d * math.sin(rad)
    
    if _turtle_pen_down:
        line(x1, y1, x2, y2, color)
    
    _turtle_pos = QPointF(x2, y2)
    
    # 如果是填充模式，记录路径点
    if _fill_mode:
        _fill_path.append(QPointF(x2, y2))
    
    win.canvas.update()

def left(a):
    _animation_queue.append(lambda: _left_real(a))

def _left_real(a):
    global _turtle_angle
    _turtle_angle += a
    win.canvas.update()

def penup():
    _animation_queue.append(_penup_real)

def _penup_real():
    global _turtle_pen_down
    _turtle_pen_down = False

def pendown():
    _animation_queue.append(_pendown_real)

def _pendown_real():
    global _turtle_pen_down
    _turtle_pen_down = True

# ====================== 新增函数 ======================
def goto(x, y, color=None):
    """移动海龟到指定坐标，画笔落下时绘制线条"""
    _animation_queue.append(lambda: _goto_real(x, y, color))

def _goto_real(x, y, color=None):
    global _turtle_pos
    x1, y1 = _turtle_pos.x(), _turtle_pos.y()
    if _turtle_pen_down:
        line(x1, y1, x, y, color)
    _turtle_pos = QPointF(float(x), float(y))
    
    # 如果是填充模式，记录路径点
    if _fill_mode:
        _fill_path.append(QPointF(float(x), float(y)))
    
    win.canvas.update()

def speed(s):
    """设置动画速度，范围1-10（1最慢，10最快）"""
    global _animation_speed
    s = max(1, min(10, s))
    _animation_speed = int(200 / s)
    _timer.setInterval(_animation_speed)

def clear():
    """清空画布"""
    _animation_queue.append(_clear_real)

def _clear_real():
    global _draw_queue, _fill_path
    _draw_queue = []
    _fill_path = []
    # 清空所有海龟的绘制路径
    for t in _all_turtles:
        t.fill_path = []
    win.canvas.update()

def text(content, x, y, color=None, font_size=12, font_name="SimHei"):
    """
    在指定坐标绘制文本
    :param content: 文字内容
    :param x: 文本左上角X坐标
    :param y: 文本左上角Y坐标
    :param color: 文本颜色，默认海龟颜色
    :param font_size: 字体大小，默认12
    :param font_name: 字体名称，默认"SimHei"
    """
    _animation_queue.append(lambda: _text_real(content, x, y, color, font_size, font_name))

def _text_real(content, x, y, color, font_size, font_name):
    c = color if isinstance(color, QColor) else _turtle_color
    
    def draw_func(painter):
        painter.setPen(QPen(c, _turtle_width))
        painter.setFont(QFont(font_name, font_size))
        painter.drawText(x, y, content)
    _draw_queue.append(draw_func)
    win.canvas.update()

def begin_fill(color=None):
    """开始填充模式，记录后续绘制路径"""
    _animation_queue.append(lambda: _begin_fill_real(color))

def _begin_fill_real(color):
    global _fill_mode, _fill_color, _fill_path
    _fill_mode = True
    _fill_color = color if isinstance(color, QColor) else _turtle_color
    _fill_path = [QPointF(_turtle_pos.x(), _turtle_pos.y())]

def end_fill():
    """结束填充模式"""
    _animation_queue.append(_end_fill_real)

def _end_fill_real():
    global _fill_mode, _fill_path
    if _fill_mode and len(_fill_path) > 2:
        def draw_func(painter):
            painter.setBrush(QBrush(_fill_color))
            painter.setPen(QPen(_fill_color, _turtle_width))
            painter.drawPolygon(QPolygonF(_fill_path))
        _draw_queue.append(draw_func)
    _fill_mode = False
    _fill_path = []

# ====================== 2D图形函数 ======================
def draw_square(size, color, x=None, y=None):
    """绘制正方形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        for _ in range(4):
            forward(size, color)
            left(90)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_triangle(size, color, x=None, y=None):
    """绘制三角形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        for _ in range(3):
            forward(size, color)
            left(120)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_rectangle(width, height, color, x=None, y=None):
    """绘制矩形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        for _ in range(2):
            forward(width, color)
            left(90)
            forward(height, color)
            left(90)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_polygon(sides, size, color, x=None, y=None):
    """绘制多边形，支持直接坐标定位"""
    def _draw():
        old_x, old_y = _turtle_pos.x(), _turtle_pos.y()
        if x is not None and y is not None:
            penup()
            goto(x, y)
            pendown()
        
        angle = 360 / sides
        for _ in range(sides):
            forward(size, color)
            left(angle)
        
        penup()
        goto(old_x, old_y)
        pendown()
    
    _animation_queue.append(_draw)

def draw_circle(radius, color, step_mode=False, x=None, y=None):
    """绘制圆形，支持直接坐标定位，画完后海龟停在圆右侧且无多余线条"""
    def _draw():
        # 记录画圆前海龟的原始位置
        original_x, original_y = _turtle_pos.x(), _turtle_pos.y()
        # 确定圆心坐标
        center_x = x if x is not None else original_x
        center_y = y if y is not None else original_y

        # 移动到圆心（如果传入了坐标）
        if x is not None and y is not None:
            penup()
            goto(center_x, center_y)
            pendown()
        
        # 绘制圆形
        if step_mode:
            _draw_circle_step(radius, color)
        else:
            def draw_func(painter):
                painter.setPen(QPen(color, _turtle_width))
                painter.drawEllipse(
                    int(center_x - radius),
                    int(center_y - radius),
                    int(radius * 2),
                    int(radius * 2)
                )
            _draw_queue.append(draw_func)
            win.canvas.update()
        
        # 核心修复：抬笔移动到圆的右侧，使用圆心坐标计算
        penup()
        goto(center_x + radius, center_y)
        pendown()
    
    _animation_queue.append(_draw)

def _draw_circle_step(radius, color):
    """修复版分步圆弧绘制：无多余半径线，纯圆周轨迹移动"""
    steps = 360  # 分步数量，数值越大越平滑
    rad_step = 2 * math.pi / steps  # 每步递增的弧度值

    # 记录圆心坐标
    center_x = _turtle_pos.x()
    center_y = _turtle_pos.y()
    # 初始角度：匹配海龟当前朝向
    current_rad = math.radians(_turtle_angle)

    # 1. 抬笔移动到圆周的第一个点（不画线）
    penup()
    start_x = center_x + radius * math.cos(current_rad)
    start_y = center_y - radius * math.sin(current_rad)
    goto(start_x, start_y)
    pendown()

    # 2. 绘制圆周
    for _ in range(steps):
        current_rad += rad_step
        point_x = center_x + radius * math.cos(current_rad)
        point_y = center_y - radius * math.sin(current_rad)
        goto(point_x, point_y, color)

    win.canvas.update()

# ====================== 新增功能函数 ======================

def shape(shape_type=None):
    """设置或获取画笔形状
    :param shape_type: 形状类型 ("classic", "arrow", "turtle", "circle", "square", "triangle")
    :return: 当前形状（如果不提供参数）
    """
    global _turtle_shape
    if shape_type is None:
        return _turtle_shape
    else:
        valid_shapes = ["classic", "arrow", "turtle", "circle", "square", "triangle"]
        if shape_type in valid_shapes:
            _turtle_shape = shape_type
            win.canvas.update()
        else:
            print(f"Invalid shape: {shape_type}. Valid shapes are: {valid_shapes}")

def showturtle():
    """显示画笔"""
    global _turtle_visible
    _turtle_visible = True
    win.canvas.update()

def hideturtle():
    """隐藏画笔"""
    global _turtle_visible
    _turtle_visible = False
    win.canvas.update()

def isvisible():
    """返回画笔是否可见"""
    return _turtle_visible

# ====================== 多海龟支持函数 ======================
def create_turtle(x=400.0, y=300.0, angle=0, color=RED, width=2, shape="classic"):
    """创建一个新的海龟对象
    :param x: 起始x坐标
    :param y: 起始y坐标
    :param angle: 起始角度
    :param color: 画笔颜色
    :param width: 画笔宽度
    :param shape: 海龟形状
    :return: 新的海龟对象
    """
    return Turtle(x, y, angle, color, width, shape)

def get_all_turtles():
    """获取所有海龟对象列表"""
    return _all_turtles

def clear_all_turtles():
    """清除所有海龟对象"""
    for t in _all_turtles:
        t.active = False
    _all_turtles.clear()

# ====================== 保存图片功能 ======================
def save_image(file_path=None, image_format="PNG"):
    """保存画布为图片
    :param file_path: 图片保存路径，如果为None则弹出保存对话框
    :param image_format: 图片格式，默认PNG
    """
    if file_path is None:
        file_path, _ = QFileDialog.getSaveFileName(win, "保存图片", "", "Images (*.png *.jpg *.jpeg *.bmp *.gif)")
        if not file_path:
            return  # 用户取消了操作

    # 获取画布大小
    size = win.canvas.size()
    # 创建一个高质量的图像
    pixmap = QPixmap(size)
    pixmap.fill(BG_COLOR)
    painter = QPainter(pixmap)
    # 启用高质量渲染
    painter.setRenderHint(QPainter.Antialiasing)
    painter.setRenderHint(QPainter.SmoothPixmapTransform)
    painter.setRenderHint(QPainter.HighQualityAntialiasing)
    painter.setRenderHint(QPainter.TextAntialiasing)
    
    # 执行绘制
    win.canvas.render(painter)
    painter.end()
    
    # 保存图像
    success = pixmap.save(file_path, image_format)
    if success:
        print(f"图像已保存至: {file_path}")
    else:
        print("保存图像失败")

# ====================== 动画控制 ======================
def done():
    def execute_step():
        if _animation_queue:
            _animation_queue.pop(0)()
    # 使用deque提高性能
    _timer.timeout.connect(execute_step)
    _timer.setInterval(_animation_speed)
    _timer.start()
    win.show()
    sys.exit(app.exec_())

# ====================== 初始化 ======================
app = QApplication(sys.argv)
win = StarsTurtleWindow()

# 创建默认海龟
default_turtle = Turtle()