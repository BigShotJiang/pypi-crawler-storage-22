# StarsTurtle - Python 海龟绘图库

StarsTurtle 是一个基于 PyQt5 实现的 Python 海龟绘图库，提供了类似于 Python 内置 `turtle` 模块的功能，但具有更多高级特性和更好的可视化效果。

## 特性

- **兼容性**: 提供与标准 `turtle` 模块类似的 API
- **多海龟支持**: 可以同时创建多个海龟对象进行绘制
- **高清渲染**: 支持抗锯齿和高质量渲染
- **多种形状**: 海龟支持多种形状（classic, arrow, turtle, circle, square, triangle）
- **丰富的绘图功能**: 支持绘制各种几何图形和自定义图形
- **填充功能**: 支持图形填充功能
- **动画控制**: 可调节绘制速度
- **图片导出**: 支持将绘制结果保存为图片

## 安装依赖

```bash
pip install PyQt5
```

## 快速开始
## 基本使用
```python
import StarsTurtle

# 移动和绘制
StarsTurtle.forward(100)  # 向前移动100像素
StarsTurtle.left(90)      # 左转90度
StarsTurtle.right(45)     # 右转45度

# 设置属性
StarsTurtle.color(StarsTurtle.RED)  # 设置颜色
StarsTurtle.width(3)                # 设置线条宽度

# 绘制基本图形
StarsTurtle.draw_square(100)        # 绘制正方形
StarsTurtle.draw_circle(50)         # 绘制圆形
StarsTurtle.draw_triangle(80)       # 绘制三角形

# 显示窗口
StarsTurtle.done()
使用海龟对象
python
import StarsTurtle

# 创建海龟对象
t = StarsTurtle.create_turtle()

# 使用面向对象的方式
t.forward(100)
t.left(90)
t.color(StarsTurtle.BLUE)

# 绘制复杂图形
t.begin_fill(StarsTurtle.YELLOW)
t.draw_square(100)
t.end_fill()

StarsTurtle.done()
```
## API 说明
# 基本移动命令
```python
forward(distance): 向前移动指定距离
left(angle): 左转指定角度
right(angle): 右转指定角度
goto(x, y): 移动到指定坐标
home(): 回到起始位置 (400, 300)
绘图控制
penup(): 抬起画笔
pendown(): 放下画笔
speed(s): 设置绘制速度 (1-10)
clear(): 清空画布
颜色和样式
color(color): 设置画笔颜色
width(width): 设置线条宽度
shape(shape_type): 设置海龟形状
可视化控制
showturtle(): 显示海龟
hideturtle(): 隐藏海龟
isvisible(): 检查海龟是否可见
填充功能
begin_fill(color=None): 开始填充
end_fill(): 结束填充
绘制几何图形
draw_square(size, color=None, x=None, y=None): 绘制正方形
draw_circle(radius, color=None, step_mode=False, x=None, y=None): 绘制圆形
draw_triangle(size, color=None, x=None, y=None): 绘制三角形
draw_rectangle(width, height, color=None, x=None, y=None): 绘制矩形
draw_polygon(sides, size, color=None, x=None, y=None): 绘制多边形
文字绘制
text(content, x, y, color=None, font_size=12, font_name="SimHei"): 绘制文字
图片保存
save_image(file_path=None, image_format="PNG"): 保存图片
预定义颜色常量
RED, GREEN, BLUE, WHITE, BLACK, YELLOW, CYAN, MAGENTA
多海龟示例
python
import StarsTurtle

# 创建多个海龟
t1 = StarsTurtle.create_turtle(x=200, y=200, color=StarsTurtle.RED)
t2 = StarsTurtle.create_turtle(x=400, y=400, color=StarsTurtle.BLUE)

# 分别控制
t1.forward(100)
t2.left(90)
t2.forward(100)

StarsTurtle.done()
```
## 错误处理
当遇到参数错误时，系统会提供详细的错误信息和正确的使用示例。

## 保存作品
使用 save_image() 函数可以将绘制的作品保存为图片文件。

## 贡献
欢迎去CSDN账号:@小羊羊Python来改进这个项目！

## 许可证
MIT License