from setuptools import setup, find_packages

with open("README.md", encoding='utf-8') as fh:
    long_description = fh.read()

setup(
    name="starsturtle",
    version="1.0.4",
    author="ChengCheng",
    author_email="qwerasdzx20150308@qq.com",
    description="A Python turtle graphics library with multi-turtle support and OpenGL rendering",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        "PyQt5>=5.15.0",
    ]
)