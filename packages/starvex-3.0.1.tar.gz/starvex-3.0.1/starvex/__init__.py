"""
Starvex - Production-ready AI agents with semantic guardrails, observability, and security

Build AI agents that are safe, measurable, and ready to ship.

Starvex is organized into 3 product areas:

1. **Guardrails** - Rules, blocking, and content filtering
2. **Observability** - Event logging, tracing, and metrics
3. **Simulation** - Test suites and security scoring

Quick Start:
    ```python
    from starvex import StarvexGuard
    from starvex.rules import BlockPII, TopicRestriction

    guard = StarvexGuard(
        rules=[
            BlockPII(),
            TopicRestriction(allowed_topics=["support", "billing"], sensitivity=0.8)
        ]
    )

    # Use as a Decorator (Easiest)
    @guard.protect
    def my_agent_chat(user_message):
        return agent_response

    # OR use explicitly (More control)
    def chat_api(request):
        if not guard.check_input(request.text).passed:
            return "Sorry, I can't discuss that."

        response = agent.run(request.text)

        if not guard.check_output(response).passed:
            return "Error: Safety violation."

        return response
    ```

Get your API key at: https://starvex.in/dashboard
Documentation: https://starvex.in/docs
"""

# =============================================================================
# Product Subpackages
# =============================================================================
from . import observability
from . import simulation
from . import guardrails

# =============================================================================
# Guardrails Re-exports
# =============================================================================
from .guardrails import (
    StarvexGuard,
    Guard,
    CheckResult,
    GuardedResponse,
    GuardConfig,
    GuardVerdict,
)

from .guardrails.rules import (
    GuardRule,
    RuleResult,
    RuleAction,
    RiskLevel,
    RISK_THRESHOLDS,
    RULE_RISK_LEVELS,
    BlockPII,
    TopicRestriction,
    BlockJailbreak,
    BlockToxicity,
    BlockCompetitor,
    PolicyCompliance,
    CustomBlocklist,
    default_rules,
    strict_rules,
    enterprise_rules,
)

# =============================================================================
# Observability Re-exports
# =============================================================================
from .observability import (
    instrument,
    get_stats,
    get_calls,
    AlertManager,
    AlertRule,
    AlertSeverity,
    AlertType,
    SupabaseAlertSink,
    DriftMonitor,
    DriftConfig,
    PredictionRecord,
    RateLimiter,
    BudgetTracker,
    GuardMiddleware,
)

# =============================================================================
# Experiments (A/B Testing)
# =============================================================================
from .experiments import (
    Experiment,
    ExperimentVariant,
    ExperimentAssignment,
    ExperimentOutcome,
    VariantMetrics,
    ExperimentComparison,
)

# =============================================================================
# Utilities
# =============================================================================
from .utils import (
    generate_api_key,
    validate_api_key_format,
    redact_sensitive_data,
    setup_logging,
)

# =============================================================================
# Advanced Features
# =============================================================================
from ._internals.hybrid_router import (
    HybridRouter,
    HybridRouteResult,
    create_hybrid_router,
)
from ._internals.auto_fix_pipeline import (
    AutoFixPipeline,
    run_auto_fix,
)

# =============================================================================
# Batch Processing
# =============================================================================
from .batch import (
    BatchProcessor,
    StreamingBatchProcessor,
    BatchRequest,
    BatchResult,
    BatchConfig,
)

# =============================================================================
# Model Quantization
# =============================================================================
try:
    from .models.quantized import (
        QuantizedModel,
        QuantizationConfig,
        load_quantized_model,
        quantize_model,
        quantize_transformers_model,
        QuantizedONNXEngine,
        QuantizedTransformerEngine,
    )
except ImportError:
    # Quantization requires optional dependencies
    QuantizedModel = None  # type: ignore[assignment,misc]
    QuantizationConfig = None  # type: ignore[assignment,misc]
    load_quantized_model = None  # type: ignore[assignment,misc]
    quantize_model = None  # type: ignore[assignment,misc]
    quantize_transformers_model = None  # type: ignore[assignment,misc]
    QuantizedONNXEngine = None  # type: ignore[assignment,misc]
    QuantizedTransformerEngine = None  # type: ignore[assignment,misc]

# =============================================================================
# Optional Engine Exports
# =============================================================================
try:
    from .guardrails.engines.onnx import OnnxEngine, OnnxResult
except ImportError:
    OnnxEngine = None  # type: ignore[assignment,misc]
    OnnxResult = None  # type: ignore[assignment,misc]

# =============================================================================
# Version and Metadata
# =============================================================================
__version__ = "3.0.1"
__author__ = "Starvex Team"

__all__ = [
    # Product Subpackages
    "observability",
    "simulation",
    "guardrails",
    # Guardrails
    "StarvexGuard",
    "Guard",
    "CheckResult",
    "GuardedResponse",
    "GuardConfig",
    "GuardVerdict",
    # Rules
    "GuardRule",
    "RuleResult",
    "RuleAction",
    "RiskLevel",
    "RISK_THRESHOLDS",
    "RULE_RISK_LEVELS",
    "BlockPII",
    "TopicRestriction",
    "BlockJailbreak",
    "BlockToxicity",
    "BlockCompetitor",
    "PolicyCompliance",
    "CustomBlocklist",
    "default_rules",
    "strict_rules",
    "enterprise_rules",
    # Observability
    "instrument",
    "get_stats",
    "get_calls",
    "AlertManager",
    "AlertRule",
    "AlertSeverity",
    "AlertType",
    "SupabaseAlertSink",
    "DriftMonitor",
    "DriftConfig",
    "PredictionRecord",
    "RateLimiter",
    "BudgetTracker",
    "GuardMiddleware",
    # Experiments
    "Experiment",
    "ExperimentVariant",
    "ExperimentAssignment",
    "ExperimentOutcome",
    "VariantMetrics",
    "ExperimentComparison",
    # Utilities
    "generate_api_key",
    "validate_api_key_format",
    "redact_sensitive_data",
    "setup_logging",
    # Advanced Features
    "HybridRouter",
    "HybridRouteResult",
    "create_hybrid_router",
    "AutoFixPipeline",
    "run_auto_fix",
    # Batch Processing
    "BatchProcessor",
    "StreamingBatchProcessor",
    "BatchRequest",
    "BatchResult",
    "BatchConfig",
    # Model Quantization (optional)
    "QuantizedModel",
    "QuantizationConfig",
    "load_quantized_model",
    "quantize_model",
    "quantize_transformers_model",
    "QuantizedONNXEngine",
    "QuantizedTransformerEngine",
    # Engines (optional)
    "OnnxEngine",
    "OnnxResult",
]
