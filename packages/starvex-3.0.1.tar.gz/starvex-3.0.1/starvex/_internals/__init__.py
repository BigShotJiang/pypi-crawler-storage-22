"""
Starvex internal modules - Advanced features.

- hybrid_router: Multi-engine routing for optimal accuracy
- auto_fix_pipeline: Automatic remediation of flagged content
- ensemble_engine: Ensemble detection combining multiple engines
- cache: Embedding caching for performance
"""

from .hybrid_router import HybridRouter, HybridRouteResult, create_hybrid_router
from .auto_fix_pipeline import AutoFixPipeline, run_auto_fix
from .ensemble_engine import EnsembleDetector, EnsembleResult, VotingStrategy
from .cache import EmbeddingCache, CacheStats, get_cache

__all__ = [
    # Multi-engine routing
    "HybridRouter",
    "HybridRouteResult",
    "create_hybrid_router",
    # Auto-remediation
    "AutoFixPipeline",
    "run_auto_fix",
    # Ensemble detection
    "EnsembleDetector",
    "EnsembleResult",
    "VotingStrategy",
    # Caching
    "EmbeddingCache",
    "CacheStats",
    "get_cache",
]
