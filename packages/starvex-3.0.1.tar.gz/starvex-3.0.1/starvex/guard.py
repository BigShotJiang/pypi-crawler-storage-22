"""
Starvex Guard - Pythonic SDK for AI Agent Protection

Backward-compatible re-export from starvex.guardrails.guard.
All new features (semantic caching, parallel execution, middleware,
shadow mode) are available through a single unified StarvexGuard class.

Example Usage:
    from starvex import StarvexGuard
    from starvex.rules import BlockPII, TopicRestriction

    guard = StarvexGuard(
        rules=[
            BlockPII(),
            TopicRestriction(allowed_topics=["support", "billing"], sensitivity=0.8)
        ]
    )

    @guard.protect
    def my_agent_chat(user_message):
        return agent_response
"""

from .guardrails.guard import (
    StarvexGuard,
    Guard,
    CheckResult,
    GuardedResponse,
)

__all__ = [
    "StarvexGuard",
    "Guard",
    "CheckResult",
    "GuardedResponse",
]
