"""
Starvex Guardrails - Rules, blocking, and content filtering

This module provides guardrail rules for protecting AI agents:
- Block jailbreak attempts and prompt injection attacks
- Detect and redact PII (Personal Identifiable Information)
- Filter toxic and harmful content
- Enforce topic restrictions and custom policies

Example:
    from starvex.guardrails import StarvexGuard, BlockPII, BlockJailbreak

    guard = StarvexGuard(
        rules=[
            BlockPII(),
            BlockJailbreak(),
        ]
    )

    # Check input
    result = guard.check_input("My SSN is 123-45-6789")
    if not result.passed:
        print(f"Blocked by: {result.blocked_by}")

    # Or use as decorator
    @guard.protect
    def my_agent(message):
        return llm.generate(message)
"""

from .guard import StarvexGuard, Guard, CheckResult, GuardedResponse
from .rules import (
    GuardRule,
    RuleResult,
    RuleAction,
    RiskLevel,
    RISK_THRESHOLDS,
    RULE_RISK_LEVELS,
    BlockPII,
    TopicRestriction,
    BlockJailbreak,
    BlockToxicity,
    BlockCompetitor,
    PolicyCompliance,
    CustomBlocklist,
    default_rules,
    strict_rules,
    enterprise_rules,
)
from .models import GuardConfig, GuardVerdict

# Optional engine exports for advanced usage
try:
    from .engines.onnx import OnnxEngine, OnnxResult
except ImportError:
    OnnxEngine = None  # type: ignore[assignment,misc]
    OnnxResult = None  # type: ignore[assignment,misc]

__all__ = [
    # Main classes
    "StarvexGuard",
    "Guard",
    "CheckResult",
    "GuardedResponse",
    # Rules base
    "GuardRule",
    "RuleResult",
    "RuleAction",
    "RiskLevel",
    "RISK_THRESHOLDS",
    "RULE_RISK_LEVELS",
    # Built-in rules
    "BlockPII",
    "TopicRestriction",
    "BlockJailbreak",
    "BlockToxicity",
    "BlockCompetitor",
    "PolicyCompliance",
    "CustomBlocklist",
    # Rule presets
    "default_rules",
    "strict_rules",
    "enterprise_rules",
    # Models
    "GuardConfig",
    "GuardVerdict",
    # Engines (optional)
    "OnnxEngine",
    "OnnxResult",
]
