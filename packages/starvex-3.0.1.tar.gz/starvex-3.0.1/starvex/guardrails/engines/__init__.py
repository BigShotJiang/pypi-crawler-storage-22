"""
Starvex Guardrails Engines - Detection engines for guardrail rules

These engines provide the actual detection logic for various guardrail rules.
They wrap ML models and pattern matching systems.
"""

from .pii import PIIEngine, PIIEntity, PIIResult
from .nemo import NemoEngine, NemoResult
from .semantic import SemanticRouter, RouteMatch

# NLI engine is optional
try:
    from .nli import NLIEngine, NLIResult
except ImportError:
    NLIEngine = None
    NLIResult = None

# ONNX ML engine is optional
try:
    from .onnx import OnnxEngine, OnnxResult
except ImportError:
    OnnxEngine = None
    OnnxResult = None

__all__ = [
    "PIIEngine",
    "PIIEntity",
    "PIIResult",
    "NemoEngine",
    "NemoResult",
    "SemanticRouter",
    "RouteMatch",
    "NLIEngine",
    "NLIResult",
    "OnnxEngine",
    "OnnxResult",
]
