"""
Starvex Guardrails Models - Data models for guard configuration
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum


class GuardVerdict(str, Enum):
    """Verdict from guard check"""

    PASSED = "PASSED"
    BLOCKED_JAILBREAK = "BLOCKED_JAILBREAK"
    BLOCKED_PII = "BLOCKED_PII"
    BLOCKED_TOXICITY = "BLOCKED_TOXICITY"
    BLOCKED_TOPIC = "BLOCKED_TOPIC"
    BLOCKED_COMPETITOR = "BLOCKED_COMPETITOR"
    BLOCKED_POLICY = "BLOCKED_POLICY"
    BLOCKED_CUSTOM = "BLOCKED_CUSTOM"
    BLOCKED_SHADOW = "BLOCKED_SHADOW"
    FLAGGED = "FLAGGED"
    ERROR = "ERROR"


@dataclass
class GuardConfig:
    """Configuration for StarvexGuard"""

    # Rule toggles
    enable_jailbreak: bool = True
    enable_pii: bool = True
    enable_toxicity: bool = True
    enable_topic_restriction: bool = False
    enable_competitor_blocking: bool = False
    enable_policy_compliance: bool = False

    # Thresholds
    jailbreak_threshold: float = 0.7
    toxicity_threshold: float = 0.7
    pii_score_threshold: float = 0.5
    topic_sensitivity: float = 0.75

    # PII options
    pii_redact_instead_of_block: bool = False
    pii_block_high_risk_only: bool = False

    # Topic restriction
    allowed_topics: List[str] = field(default_factory=list)
    blocked_topics: List[str] = field(
        default_factory=lambda: [
            "politics",
            "competitors",
            "investment_advice",
            "medical_advice",
            "legal_advice",
        ]
    )

    # Competitor blocking
    competitor_names: List[str] = field(default_factory=list)

    # Policy compliance
    policies: List[str] = field(default_factory=list)

    # Custom blocklist
    blocked_phrases: List[str] = field(default_factory=list)
    blocked_patterns: List[str] = field(default_factory=list)

    # Tracing
    enable_tracing: bool = True
    api_key: Optional[str] = None

    # Behavior
    fail_open: bool = False  # If True, allow on error; if False, block on error
    mode: str = "enforce"  # "enforce" (default) or "shadow" (log but don't block)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "enable_jailbreak": self.enable_jailbreak,
            "enable_pii": self.enable_pii,
            "enable_toxicity": self.enable_toxicity,
            "enable_topic_restriction": self.enable_topic_restriction,
            "enable_competitor_blocking": self.enable_competitor_blocking,
            "enable_policy_compliance": self.enable_policy_compliance,
            "jailbreak_threshold": self.jailbreak_threshold,
            "toxicity_threshold": self.toxicity_threshold,
            "pii_score_threshold": self.pii_score_threshold,
            "topic_sensitivity": self.topic_sensitivity,
            "pii_redact_instead_of_block": self.pii_redact_instead_of_block,
            "allowed_topics": self.allowed_topics,
            "blocked_topics": self.blocked_topics,
            "competitor_names": self.competitor_names,
            "policies": self.policies,
            "blocked_phrases": self.blocked_phrases,
            "blocked_patterns": self.blocked_patterns,
            "enable_tracing": self.enable_tracing,
            "fail_open": self.fail_open,
            "mode": self.mode,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GuardConfig":
        """Create config from dictionary"""
        return cls(**{k: v for k, v in data.items() if hasattr(cls, k)})

    @classmethod
    def default(cls) -> "GuardConfig":
        """Default configuration"""
        return cls()

    @classmethod
    def strict(cls) -> "GuardConfig":
        """Strict configuration with all protections enabled"""
        return cls(
            enable_jailbreak=True,
            enable_pii=True,
            enable_toxicity=True,
            enable_topic_restriction=True,
            jailbreak_threshold=0.6,
            toxicity_threshold=0.6,
            pii_score_threshold=0.4,
        )

    @classmethod
    def enterprise(
        cls,
        competitors: Optional[List[str]] = None,
        policies: Optional[List[str]] = None,
        mode: str = "enforce",
    ) -> "GuardConfig":
        """Enterprise configuration with full protection"""
        return cls(
            enable_jailbreak=True,
            enable_pii=True,
            enable_toxicity=True,
            enable_topic_restriction=True,
            enable_competitor_blocking=bool(competitors),
            enable_policy_compliance=bool(policies),
            jailbreak_threshold=0.5,
            toxicity_threshold=0.5,
            pii_score_threshold=0.3,
            competitor_names=competitors or [],
            policies=policies or [],
            mode=mode,
        )
