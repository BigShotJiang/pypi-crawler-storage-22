"""
Quantized model support for performance optimization.

This module provides int8 quantization support for ML models to achieve:
- 4x smaller model size
- 2-3x faster inference
- <2% accuracy loss
- 50% memory reduction

Example:
    >>> from starvex.models.quantized import QuantizedModel, quantize_model
    >>>
    >>> # Quantize an existing model
    >>> quantized = quantize_model("path/to/model.onnx", output_path="quantized.onnx")
    >>>
    >>> # Load and use quantized model
    >>> model = QuantizedModel("quantized.onnx")
    >>> result = model.predict(input_data)
"""

from .loader import QuantizedModel, QuantizationConfig, load_quantized_model
from .quantizer import quantize_model, quantize_transformers_model
from .engines import QuantizedONNXEngine, QuantizedTransformerEngine

__all__ = [
    "QuantizedModel",
    "QuantizationConfig",
    "load_quantized_model",
    "quantize_model",
    "quantize_transformers_model",
    "QuantizedONNXEngine",
    "QuantizedTransformerEngine",
]
