"""
Starvex Observability - Event logging, tracing, and metrics

This module provides observability features for AI agent monitoring:
- Automatic instrumentation for popular AI libraries (OpenAI, Anthropic, LangChain)
- Event tracing and logging to the Starvex dashboard
- Metrics collection and aggregation

Example:
    from starvex.observability import instrument, get_stats, Tracer

    # One-line instrumentation
    import openai
    instrument(openai)

    # Custom tracer for advanced use
    tracer = Tracer(api_key="sv_live_xxx")
    tracer.log_event(trace_id="...", input_text="...", ...)
"""

from .tracer import Tracer, InternalTracer
from .middleware import RateLimiter, BudgetTracker, GuardMiddleware
from .alerts import AlertManager, AlertRule, AlertSeverity, AlertType, SupabaseAlertSink
from .drift_monitor import DriftMonitor, DriftConfig, PredictionRecord
from .instrument import (
    instrument,
    get_stats,
    get_calls,
    Instrumentor,
    InstrumentedCall,
)
from .models import TraceEvent, MetricsSnapshot

__all__ = [
    # Core tracing
    "Tracer",
    "InternalTracer",
    # Instrumentation
    "instrument",
    "get_stats",
    "get_calls",
    "Instrumentor",
    "InstrumentedCall",
    # Models
    "TraceEvent",
    "MetricsSnapshot",
    # Rate limiting & budgets
    "RateLimiter",
    "BudgetTracker",
    "GuardMiddleware",
    # Alerting
    "AlertManager",
    "AlertRule",
    "AlertSeverity",
    "AlertType",
    "SupabaseAlertSink",
    # Drift detection
    "DriftMonitor",
    "DriftConfig",
    "PredictionRecord",
]
