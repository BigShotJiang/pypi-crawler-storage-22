"""
Starvex Rules - Composable guardrail rules for protection.

Backward-compatible re-export from starvex.guardrails.rules.
All rule classes, risk levels, and preset functions are available
through the unified v3 implementation.

Example:
    from starvex import StarvexGuard
    from starvex.rules import BlockPII, TopicRestriction, BlockJailbreak

    guard = StarvexGuard(
        rules=[
            BlockPII(),
            TopicRestriction(allowed_topics=["support", "billing"]),
            BlockJailbreak(),
        ]
    )
"""

from .guardrails.rules import (
    RuleAction,
    RiskLevel,
    RISK_THRESHOLDS,
    RULE_RISK_LEVELS,
    RuleResult,
    GuardRule,
    BlockPII,
    TopicRestriction,
    BlockJailbreak,
    BlockToxicity,
    BlockCompetitor,
    PolicyCompliance,
    CustomBlocklist,
    default_rules,
    strict_rules,
    enterprise_rules,
)

__all__ = [
    "RuleAction",
    "RiskLevel",
    "RISK_THRESHOLDS",
    "RULE_RISK_LEVELS",
    "RuleResult",
    "GuardRule",
    "BlockPII",
    "TopicRestriction",
    "BlockJailbreak",
    "BlockToxicity",
    "BlockCompetitor",
    "PolicyCompliance",
    "CustomBlocklist",
    "default_rules",
    "strict_rules",
    "enterprise_rules",
]
