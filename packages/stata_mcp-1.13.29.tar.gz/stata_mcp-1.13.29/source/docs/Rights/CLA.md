# Contributor License Agreement (CLA)

This CLA content is based on the [Google's CLA](https://cla.developers.google.com/about), and is modified to fit the project. If you are trying to join, that reveals that you have ever signed the CLA or agree with the CLA.

# More CLA information
By submitting a pull request to this project, you certify that:

1. The contribution is your original work, or you have the right to submit it.
2. You grant the project maintainers an irrevocable license to use, modify, and distribute your contribution.
3. You agree that your contribution is provided under the project's license.

If you do not agree, do not submit contributions.
