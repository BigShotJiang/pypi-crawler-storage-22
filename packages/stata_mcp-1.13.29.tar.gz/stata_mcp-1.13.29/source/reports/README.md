# Stata-MCP Research Reports Index

## 2025

- 20250921: [Stata-MCP: A Research Report on AI-Assisted Empirical Research](2025/0921/stata_mcp_a_research_report_on_ai_assisted_empirical_research.md)

## Others

- AI coding ability: [code](ai_coding_ability/main.ipynb) and [figure](ai_coding_ability/ability.png)
