"""Schedule sub-app: manage scheduled/recurring agent tasks with cron expressions."""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._constants import AGENT_TYPE_MAP
from cli._errors import print_error
from cli._output import output, rich_table

schedule_app = typer.Typer(name="schedule", help="Manage scheduled agent tasks")


# ---------------------------------------------------------------------------
# Schedule storage
# ---------------------------------------------------------------------------

def _schedules_dir() -> Path:
    """Return (and create) the schedules directory."""
    d = get_state_dir() / "schedules"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _schedule_path(schedule_id: str) -> Path:
    """Return the file path for a schedule by ID."""
    safe_id = "".join(c if c.isalnum() or c in "-_" else "_" for c in schedule_id)
    return _schedules_dir() / f"{safe_id}.json"


def _load_schedule(schedule_id: str) -> Optional[dict]:
    """Load a schedule by ID or name."""
    # Try direct ID match first
    path = _schedule_path(schedule_id)
    if path.exists():
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, IOError):
            return None

    # Try name match
    for s in _list_all_schedules():
        if s.get("name") == schedule_id:
            return s

    return None


def _save_schedule(schedule: dict) -> None:
    """Save a schedule to disk."""
    sid = schedule.get("id", str(uuid.uuid4())[:8])
    schedule["id"] = sid
    schedule["updated_at"] = datetime.now().isoformat()
    path = _schedule_path(sid)
    path.write_text(json.dumps(schedule, indent=2, default=str))


def _delete_schedule(schedule_id: str) -> bool:
    """Delete a schedule file."""
    path = _schedule_path(schedule_id)
    if path.exists():
        path.unlink()
        return True

    # Try by name
    for s in _list_all_schedules():
        if s.get("name") == schedule_id:
            p = _schedule_path(s["id"])
            if p.exists():
                p.unlink()
                return True

    return False


def _list_all_schedules() -> list:
    """Load all schedules from disk."""
    schedules = []
    for path in sorted(_schedules_dir().glob("*.json")):
        try:
            data = json.loads(path.read_text())
            schedules.append(data)
        except (json.JSONDecodeError, IOError):
            continue
    return schedules


# ---------------------------------------------------------------------------
# Cron helpers
# ---------------------------------------------------------------------------

_CRON_PRESETS = {
    "hourly": "0 * * * *",
    "daily": "0 9 * * *",
    "weekly": "0 9 * * 1",
    "weekdays": "0 9 * * 1-5",
    "monthly": "0 9 1 * *",
    "every-5m": "*/5 * * * *",
    "every-15m": "*/15 * * * *",
    "every-30m": "*/30 * * * *",
}


def _describe_cron(expression: str) -> str:
    """Provide a human-readable description of a cron expression."""
    # Check presets first
    for name, expr in _CRON_PRESETS.items():
        if expression == expr:
            return name

    parts = expression.split()
    if len(parts) != 5:
        return expression

    minute, hour, dom, month, dow = parts

    if expression == "* * * * *":
        return "every minute"
    if minute.startswith("*/"):
        interval = minute[2:]
        return f"every {interval} minutes"
    if hour == "*" and minute != "*":
        return f"every hour at :{minute.zfill(2)}"
    if dom == "*" and month == "*" and dow == "*":
        return f"daily at {hour.zfill(2)}:{minute.zfill(2)}"
    if dow != "*" and dom == "*":
        return f"weekly ({dow}) at {hour.zfill(2)}:{minute.zfill(2)}"

    return expression


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@schedule_app.command("list")
def schedule_list() -> None:
    """List all scheduled tasks."""
    console = get_console()
    schedules = _list_all_schedules()

    if not schedules:
        if is_json_mode():
            output({"schedules": [], "count": 0})
        else:
            console.print("[dim]No scheduled tasks.[/dim]")
            console.print(
                "[dim]Add one with: stateset-cua schedule add <name> --cron '...' --instruction '...'[/dim]"
            )
        return

    if is_json_mode():
        output({"schedules": schedules, "count": len(schedules)})
        return

    headers = ["ID", "Name", "Schedule", "Agent", "Instruction", "Enabled"]
    rows = []
    for s in schedules:
        sid = s.get("id", "?")[:8]
        name = s.get("name", "unnamed")
        cron = s.get("cron", "?")
        cron_desc = _describe_cron(cron)
        agent = s.get("agent_type") or "auto"
        instruction = s.get("instruction", "")[:35]
        if len(s.get("instruction", "")) > 35:
            instruction += "..."
        enabled = s.get("enabled", True)
        enabled_str = "[success]yes[/success]" if enabled else "[dim]no[/dim]"
        rows.append([sid, name, f"{cron_desc} ({cron})", agent, instruction, enabled_str])

    rich_table(headers, rows, title="Scheduled Tasks")


@schedule_app.command("add")
def schedule_add(
    name: str = typer.Argument(..., help="Schedule name (e.g. 'daily-ticket-cleanup')"),
    instruction: str = typer.Option(
        ..., "--instruction", "-i", help="Task instruction"
    ),
    cron: str = typer.Option(
        ..., "--cron", "-c",
        help=f"Cron expression or preset ({', '.join(_CRON_PRESETS.keys())})"
    ),
    agent_type: Optional[str] = typer.Option(
        None, "--agent", "-a", help="Agent type"
    ),
    enabled: bool = typer.Option(True, "--enabled/--disabled", help="Enable the schedule"),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Human-readable description"
    ),
) -> None:
    """Add a new scheduled task."""
    console = get_console()

    # Resolve cron preset
    resolved_cron = _CRON_PRESETS.get(cron, cron)

    # Validate cron expression (basic check: 5 fields)
    parts = resolved_cron.split()
    if len(parts) != 5:
        print_error(
            f"Invalid cron expression: {resolved_cron}",
            details=(
                "Cron must have 5 fields: minute hour day-of-month month day-of-week\n"
                f"Or use a preset: {', '.join(sorted(_CRON_PRESETS.keys()))}"
            ),
        )
        raise typer.Exit(1)

    # Validate agent type
    if agent_type and agent_type not in AGENT_TYPE_MAP:
        print_error(
            f"Unknown agent type: {agent_type}",
            details=f"Available: {', '.join(AGENT_TYPE_MAP.keys())}",
        )
        raise typer.Exit(1)

    # Check for duplicate name
    existing = _load_schedule(name)
    if existing:
        print_error(
            f"Schedule '{name}' already exists (ID: {existing.get('id', '?')})",
            details="Use 'stateset-cua schedule remove' first, or choose a different name.",
        )
        raise typer.Exit(1)

    schedule = {
        "id": str(uuid.uuid4())[:8],
        "name": name,
        "instruction": instruction,
        "cron": resolved_cron,
        "agent_type": agent_type,
        "enabled": enabled,
        "description": description,
        "created_at": datetime.now().isoformat(),
        "last_run": None,
        "run_count": 0,
    }

    _save_schedule(schedule)

    if is_json_mode():
        output({"created": schedule})
    else:
        console.print(f"[success]Schedule '{name}' created.[/success]")
        console.print(f"  [dim]ID: {schedule['id']}[/dim]")
        console.print(f"  [dim]Cron: {resolved_cron} ({_describe_cron(resolved_cron)})[/dim]")
        console.print(f"  [dim]Instruction: {instruction[:60]}[/dim]")
        if agent_type:
            console.print(f"  [dim]Agent: {agent_type}[/dim]")


@schedule_app.command("remove")
def schedule_remove(
    name_or_id: str = typer.Argument(..., help="Schedule name or ID to remove"),
) -> None:
    """Remove a scheduled task."""
    console = get_console()

    if not _delete_schedule(name_or_id):
        print_error(
            f"Schedule '{name_or_id}' not found",
            details="Use 'stateset-cua schedule list' to see available schedules.",
        )
        raise typer.Exit(1)

    if is_json_mode():
        output({"removed": name_or_id})
    else:
        console.print(f"[success]Schedule '{name_or_id}' removed.[/success]")


@schedule_app.command("run")
def schedule_run(
    name_or_id: str = typer.Argument(..., help="Schedule name or ID to run now"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
) -> None:
    """Manually trigger a scheduled task immediately."""
    console = get_console()
    schedule = _load_schedule(name_or_id)

    if not schedule:
        print_error(
            f"Schedule '{name_or_id}' not found",
            details="Use 'stateset-cua schedule list' to see available schedules.",
        )
        raise typer.Exit(1)

    instruction = schedule.get("instruction", "")
    agent_type = schedule.get("agent_type")
    name = schedule.get("name", name_or_id)

    if dry_run:
        if is_json_mode():
            output({
                "dry_run": True,
                "schedule": name,
                "instruction": instruction,
                "agent_type": agent_type or "auto-detect",
            })
        else:
            from rich.panel import Panel
            body = (
                f"[bold]Schedule:[/bold] {name}\n"
                f"[bold]Instruction:[/bold] {instruction}\n"
                f"[bold]Agent:[/bold] {agent_type or 'auto-detect'}\n"
                f"[bold]Cron:[/bold] {schedule.get('cron', '?')}"
            )
            console.print(Panel(body, title="Dry Run", border_style="yellow"))
        return

    if not is_json_mode():
        console.print(f"[bold]Running schedule:[/bold] {name}")
        console.print(f"  [dim]{instruction[:80]}[/dim]")
        console.print()

    import asyncio

    try:
        from main import main as agent_main
        from agent.types import RuntimeOptions
        from typing import cast

        agent_types = None
        if agent_type:
            internal = AGENT_TYPE_MAP.get(agent_type)
            if internal:
                agent_types = [internal]

        options = RuntimeOptions(
            instruction=instruction,
            agent_types=agent_types,
        )

        if not is_json_mode():
            with console.status("[info]Executing scheduled task...[/info]"):
                asyncio.run(agent_main(options))
        else:
            asyncio.run(agent_main(options))

        # Update run metadata
        schedule["last_run"] = datetime.now().isoformat()
        schedule["run_count"] = schedule.get("run_count", 0) + 1
        _save_schedule(schedule)

        if is_json_mode():
            output({"schedule": name, "status": "completed", "run_count": schedule["run_count"]})
        else:
            console.print(f"\n[success]Schedule '{name}' executed successfully.[/success]")

    except KeyboardInterrupt:
        console.print("\n[warning]Interrupted by user.[/warning]")
        raise typer.Exit(130)
    except Exception as exc:
        print_error(f"Schedule execution failed: {exc}")
        raise typer.Exit(1)


@schedule_app.command("pause")
def schedule_pause(
    name_or_id: str = typer.Argument(..., help="Schedule name or ID to pause"),
) -> None:
    """Pause a scheduled task (disable without removing)."""
    console = get_console()
    schedule = _load_schedule(name_or_id)

    if not schedule:
        print_error(
            f"Schedule '{name_or_id}' not found",
            details="Use 'stateset-cua schedule list' to see available schedules.",
        )
        raise typer.Exit(1)

    if not schedule.get("enabled", True):
        if is_json_mode():
            output({"message": f"Schedule '{name_or_id}' is already paused"})
        else:
            console.print(f"[dim]Schedule '{name_or_id}' is already paused.[/dim]")
        return

    schedule["enabled"] = False
    _save_schedule(schedule)

    name = schedule.get("name", name_or_id)
    if is_json_mode():
        output({"paused": name, "id": schedule.get("id")})
    else:
        console.print(f"[success]Schedule '{name}' paused.[/success]")
        console.print("[dim]Use 'stateset-cua schedule resume' to re-enable.[/dim]")


@schedule_app.command("resume")
def schedule_resume(
    name_or_id: str = typer.Argument(..., help="Schedule name or ID to resume"),
) -> None:
    """Resume a paused scheduled task."""
    console = get_console()
    schedule = _load_schedule(name_or_id)

    if not schedule:
        print_error(
            f"Schedule '{name_or_id}' not found",
            details="Use 'stateset-cua schedule list' to see available schedules.",
        )
        raise typer.Exit(1)

    if schedule.get("enabled", True):
        if is_json_mode():
            output({"message": f"Schedule '{name_or_id}' is already enabled"})
        else:
            console.print(f"[dim]Schedule '{name_or_id}' is already enabled.[/dim]")
        return

    schedule["enabled"] = True
    _save_schedule(schedule)

    name = schedule.get("name", name_or_id)
    cron = schedule.get("cron", "?")
    if is_json_mode():
        output({"resumed": name, "id": schedule.get("id"), "cron": cron})
    else:
        console.print(f"[success]Schedule '{name}' resumed.[/success]")
        console.print(f"  [dim]Cron: {cron} ({_describe_cron(cron)})[/dim]")
