"""Templates sub-app: save, list, run, show, delete reusable task templates."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._constants import AGENT_TYPE_MAP, TOOL_VERSIONS
from cli._errors import print_error
from cli._output import output, rich_table

templates_app = typer.Typer(name="templates", help="Manage reusable task templates")


# ---------------------------------------------------------------------------
# Template storage
# ---------------------------------------------------------------------------

def _templates_dir() -> Path:
    """Return (and create) the templates directory."""
    d = get_state_dir() / "templates"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _template_path(name: str) -> Path:
    """Return the path for a named template."""
    # Sanitize name for filesystem
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)
    return _templates_dir() / f"{safe_name}.json"


def _load_template(name: str) -> Optional[dict]:
    """Load a template by name."""
    path = _template_path(name)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return None


def _save_template(name: str, template: dict) -> None:
    """Save a template to disk."""
    path = _template_path(name)
    template["name"] = name
    template.setdefault("created_at", datetime.now().isoformat())
    template["updated_at"] = datetime.now().isoformat()
    path.write_text(json.dumps(template, indent=2, default=str))


def _list_all_templates() -> list:
    """List all saved templates."""
    templates = []
    for path in sorted(_templates_dir().glob("*.json")):
        try:
            data = json.loads(path.read_text())
            data["_file"] = path.name
            templates.append(data)
        except (json.JSONDecodeError, IOError):
            continue
    return templates


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@templates_app.command("list")
def templates_list() -> None:
    """List all saved templates."""
    console = get_console()
    templates = _list_all_templates()

    if not templates:
        if is_json_mode():
            output({"templates": [], "count": 0})
        else:
            console.print("[dim]No templates saved.[/dim]")
            console.print(
                "[dim]Save one with: stateset-cua templates save <name> --instruction '...'[/dim]"
            )
        return

    if is_json_mode():
        # Strip internal fields
        clean = [{k: v for k, v in t.items() if not k.startswith("_")} for t in templates]
        output({"templates": clean, "count": len(clean)})
        return

    headers = ["Name", "Agent", "Instruction", "Tool Version", "Updated"]
    rows = []
    for t in templates:
        name = t.get("name", "?")
        agent = t.get("agent_type", "auto")
        instruction = t.get("instruction", "")[:45]
        if len(t.get("instruction", "")) > 45:
            instruction += "..."
        tool_ver = t.get("tool_version", "default")
        updated = t.get("updated_at", "?")[:10]
        rows.append([name, agent, instruction, tool_ver, updated])

    rich_table(headers, rows, title="Task Templates")


@templates_app.command("save")
def templates_save(
    name: str = typer.Argument(..., help="Template name (e.g. 'close-tickets')"),
    instruction: str = typer.Option(
        ..., "--instruction", "-i", help="Task instruction for the template"
    ),
    agent_type: Optional[str] = typer.Option(
        None, "--agent", "-a",
        help=f"Agent type ({', '.join(AGENT_TYPE_MAP.keys())})",
    ),
    tool_version: str = typer.Option(
        "computer_use_20251124", "--tool-version",
        help="Tool version to use",
    ),
    effort: Optional[str] = typer.Option(
        None, "--effort", "-e", help="Effort level (low, medium, high)"
    ),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="Human-readable description"
    ),
    tags: Optional[str] = typer.Option(
        None, "--tags", "-t", help="Comma-separated tags"
    ),
) -> None:
    """Save a new task template."""
    console = get_console()

    # Validate agent type if provided
    if agent_type and agent_type not in AGENT_TYPE_MAP:
        print_error(
            f"Unknown agent type: {agent_type}",
            details=f"Available: {', '.join(AGENT_TYPE_MAP.keys())}",
        )
        raise typer.Exit(1)

    # Validate tool version
    if tool_version not in TOOL_VERSIONS:
        print_error(
            f"Unknown tool version: {tool_version}",
            details=f"Available: {', '.join(TOOL_VERSIONS)}",
        )
        raise typer.Exit(1)

    existing = _load_template(name)
    is_update = existing is not None

    template = {
        "instruction": instruction,
        "agent_type": agent_type,
        "tool_version": tool_version,
        "effort": effort,
        "description": description,
        "tags": [t.strip() for t in tags.split(",")] if tags else [],
    }

    if existing:
        template["created_at"] = existing.get("created_at")

    _save_template(name, template)

    action = "updated" if is_update else "saved"
    if is_json_mode():
        output({"name": name, "action": action, "template": template})
    else:
        console.print(f"[success]Template '{name}' {action}.[/success]")
        console.print(f"  [dim]Instruction: {instruction[:60]}[/dim]")
        if agent_type:
            console.print(f"  [dim]Agent: {agent_type}[/dim]")


@templates_app.command("show")
def templates_show(
    name: str = typer.Argument(..., help="Template name to show"),
) -> None:
    """Show details of a saved template."""
    console = get_console()
    template = _load_template(name)

    if not template:
        print_error(
            f"Template '{name}' not found",
            details="Use 'stateset-cua templates list' to see available templates.",
        )
        raise typer.Exit(1)

    if is_json_mode():
        output(template)
        return

    from rich.panel import Panel

    lines = []
    lines.append(f"[bold]Name:[/bold] {template.get('name', name)}")
    lines.append(f"[bold]Instruction:[/bold] {template.get('instruction', '')}")
    lines.append(f"[bold]Agent:[/bold] {template.get('agent_type') or 'auto-detect'}")
    lines.append(f"[bold]Tool Version:[/bold] {template.get('tool_version', 'default')}")

    if template.get("effort"):
        lines.append(f"[bold]Effort:[/bold] {template['effort']}")
    if template.get("description"):
        lines.append(f"[bold]Description:[/bold] {template['description']}")
    if template.get("tags"):
        lines.append(f"[bold]Tags:[/bold] {', '.join(template['tags'])}")

    lines.append(f"[bold]Created:[/bold] {template.get('created_at', '?')}")
    lines.append(f"[bold]Updated:[/bold] {template.get('updated_at', '?')}")

    console.print(Panel("\n".join(lines), title=f"Template: {name}", border_style="cyan"))


@templates_app.command("run")
def templates_run(
    name: str = typer.Argument(..., help="Template name to run"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    override_agent: Optional[str] = typer.Option(
        None, "--agent", "-a", help="Override the template's agent type"
    ),
    override_effort: Optional[str] = typer.Option(
        None, "--effort", "-e", help="Override the template's effort level"
    ),
) -> None:
    """Run a saved template."""
    console = get_console()
    template = _load_template(name)

    if not template:
        print_error(
            f"Template '{name}' not found",
            details="Use 'stateset-cua templates list' to see available templates.",
        )
        raise typer.Exit(1)

    instruction = template.get("instruction", "")
    agent_type = override_agent or template.get("agent_type")
    tool_version = template.get("tool_version", "computer_use_20251124")
    effort = override_effort or template.get("effort")

    if dry_run:
        if is_json_mode():
            output({
                "dry_run": True,
                "template": name,
                "instruction": instruction,
                "agent_type": agent_type or "auto-detect",
                "tool_version": tool_version,
                "effort": effort or "default",
            })
        else:
            from rich.panel import Panel
            body = (
                f"[bold]Template:[/bold] {name}\n"
                f"[bold]Instruction:[/bold] {instruction}\n"
                f"[bold]Agent:[/bold] {agent_type or 'auto-detect'}\n"
                f"[bold]Tool Version:[/bold] {tool_version}\n"
                f"[bold]Effort:[/bold] {effort or 'default'}"
            )
            console.print(Panel(body, title="Dry Run", border_style="yellow"))
        return

    # Build run command arguments and invoke via Typer context
    if not is_json_mode():
        console.print(f"[bold]Running template:[/bold] {name}")
        console.print(f"  [dim]{instruction[:80]}[/dim]")
        console.print()

    # Import and execute via the run command
    try:
        import asyncio
        from main import main as agent_main
        from agent.types import RuntimeOptions, EffortLevel
        from typing import cast

        # Map CLI agent name to internal name
        agent_types = None
        if agent_type:
            internal = AGENT_TYPE_MAP.get(agent_type)
            if internal:
                agent_types = [internal]

        options = RuntimeOptions(
            instruction=instruction,
            tool_version=cast(str, tool_version),
            agent_types=agent_types,
            effort_level=cast(EffortLevel, effort) if effort else None,
        )

        if not is_json_mode():
            with console.status("[info]Executing template...[/info]"):
                asyncio.run(agent_main(options))
        else:
            asyncio.run(agent_main(options))

        if is_json_mode():
            output({"template": name, "status": "completed"})
        else:
            console.print(f"\n[success]Template '{name}' completed.[/success]")

    except KeyboardInterrupt:
        console.print("\n[warning]Interrupted by user.[/warning]")
        raise typer.Exit(130)
    except Exception as exc:
        print_error(f"Template execution failed: {exc}")
        raise typer.Exit(1)


@templates_app.command("delete")
def templates_delete(
    name: str = typer.Argument(..., help="Template name to delete"),
) -> None:
    """Delete a saved template."""
    console = get_console()
    path = _template_path(name)

    if not path.exists():
        print_error(
            f"Template '{name}' not found",
            details="Use 'stateset-cua templates list' to see available templates.",
        )
        raise typer.Exit(1)

    path.unlink()

    if is_json_mode():
        output({"deleted": name})
    else:
        console.print(f"[success]Template '{name}' deleted.[/success]")
