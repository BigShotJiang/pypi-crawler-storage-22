"""
StateSet Computer Use Agent - AI Automation Platform

This package provides the core functionality for the StateSet Computer Use Agent,
a production-grade AI automation platform powered by Claude.

Key modules:
- loop: Main agent sampling loop and API interaction
- tools: Tool implementations (computer, bash, edit, memory, AGI)
- exceptions: Comprehensive exception hierarchy
- config: Configuration management with validation
- logging_config: Structured logging with rotation
- observability: Tracing and metrics (OpenTelemetry, Prometheus)
- parallel_executor: Concurrent tool execution
- context_optimizer: Context window management

Basic usage:
    from agent import get_config, get_logger
    from agent.loop import sampling_loop
    from agent.exceptions import AgentError, ToolError

For tool access:
    from agent.tools import ToolCollection, ComputerTool, BashTool, MemoryTool

For observability:
    from agent.observability import get_tracer, trace_async, get_metrics_collector
"""

__version__ = "2.0.1"

# Core exports for convenience
from agent.config import get_config, Config, ConfigurationError
from agent.logging_config import get_logger, configure_logging
from agent.exceptions import (
    # Base exceptions
    AgentError,
    ErrorCategory,
    ErrorSeverity,
    ErrorContext,
    # Retryable
    RetryableError,
    NetworkError,
    RateLimitError,
    OperationTimeoutError,
    # Non-retryable
    NonRetryableError,
    ConfigurationError as AgentConfigurationError,
    ValidationError,
    SecurityError,
    # Tool errors
    ToolError,
    ToolExecutionError,
    ToolTimeoutError,
    # Budget errors
    BudgetError,
    DailyBudgetExceededError,
    TaskBudgetExceededError,
    # Utilities
    is_retryable,
    get_retry_delay,
    wrap_exception,
)

__all__ = [
    # Version
    '__version__',
    # Config
    'get_config',
    'Config',
    'ConfigurationError',
    # Logging
    'get_logger',
    'configure_logging',
    # Exceptions
    'AgentError',
    'ErrorCategory',
    'ErrorSeverity',
    'ErrorContext',
    'RetryableError',
    'NetworkError',
    'RateLimitError',
    'OperationTimeoutError',
    'NonRetryableError',
    'AgentConfigurationError',
    'ValidationError',
    'SecurityError',
    'ToolError',
    'ToolExecutionError',
    'ToolTimeoutError',
    'BudgetError',
    'DailyBudgetExceededError',
    'TaskBudgetExceededError',
    'is_retryable',
    'get_retry_delay',
    'wrap_exception',
]
