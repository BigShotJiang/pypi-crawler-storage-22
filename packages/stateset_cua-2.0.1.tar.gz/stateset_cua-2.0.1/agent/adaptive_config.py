"""
Adaptive Configuration System for StateSet Computer Use Agent.
Dynamically adjusts parameters based on task complexity.
"""

import re
from typing import Dict, Any


class AdaptiveConfig:
    """Dynamically configure agent parameters based on task"""
    
    # Task complexity indicators
    SIMPLE_KEYWORDS = [
        'click', 'type', 'screenshot', 'simple', 'basic',
        'open', 'close', 'single', 'one'
    ]
    
    COMPLEX_KEYWORDS = [
        'analyze', 'debug', 'complex', 'all', 'every', 'multiple',
        'research', 'investigate', 'comprehensive', 'detailed',
        'optimize', 'refactor', 'review'
    ]
    
    @classmethod
    def get_thinking_budget(cls, instruction: str) -> int:
        """
        Calculate optimal thinking budget based on task complexity.
        
        Returns:
            1024 for simple tasks
            2048 for normal tasks
            4096 for complex tasks
        """
        instruction_lower = instruction.lower()
        
        # Count keywords
        simple_score = sum(1 for kw in cls.SIMPLE_KEYWORDS if kw in instruction_lower)
        complex_score = sum(1 for kw in cls.COMPLEX_KEYWORDS if kw in instruction_lower)
        
        # Length-based complexity
        word_count = len(instruction.split())
        
        # Calculate complexity score
        complexity = complex_score * 2 - simple_score + (word_count / 20)
        
        if complexity <= 1:
            return 1024  # Simple: quick actions
        elif complexity >= 5:
            return 4096  # Complex: deep analysis needed
        else:
            return 2048  # Normal: balanced
    
    @classmethod
    def get_max_tokens(cls, instruction: str) -> int:
        """
        Calculate optimal max_tokens based on expected response length.
        
        Returns:
            4096 for simple responses
            8192 for normal responses
            16384 for complex/verbose responses (if available)
        """
        instruction_lower = instruction.lower()
        
        # Check for verbose output indicators
        verbose_keywords = ['explain', 'describe', 'detail', 'comprehensive', 'all', 'list']
        verbose_score = sum(1 for kw in verbose_keywords if kw in instruction_lower)
        
        if verbose_score >= 2:
            return 8192  # Detailed response expected
        elif verbose_score == 1:
            return 8192  # Normal
        else:
            return 4096  # Quick response
    
    @classmethod
    def should_skip_screenshot(cls, action: str, context: Dict[str, Any] = None) -> bool:
        """
        Determine if screenshot can be skipped for this action.
        
        Skip screenshots for:
        - Actions that don't change UI (cursor_position, wait with own screenshot)
        - Bash commands that don't affect display
        - Consecutive similar actions (user already sees state)
        """
        
        # Actions that never need screenshots
        NO_SCREENSHOT_ACTIONS = {
            'cursor_position',  # Just returns coordinates
        }
        
        if action in NO_SCREENSHOT_ACTIONS:
            return True
        
        # Context-based skipping
        if context:
            # If we just took a screenshot, skip for certain fast actions
            last_screenshot_time = context.get('last_screenshot_time', 0)
            time_since_screenshot = context.get('current_time', float('inf')) - last_screenshot_time
            
            if time_since_screenshot < 0.5:  # Less than 0.5s ago
                # Skip for fast non-visual actions
                if action in ['key', 'mouse_move']:
                    return True
        
        return False
    
    @classmethod
    def get_optimized_config(cls, instruction: str, agent_type: str) -> Dict[str, Any]:
        """
        Get complete optimized configuration for a task.
        
        Returns dict with all adaptive parameters.
        """
        
        return {
            'thinking_budget': cls.get_thinking_budget(instruction),
            'max_tokens': cls.get_max_tokens(instruction),
            'complexity_score': cls._calculate_complexity_score(instruction),
            'agent_type': agent_type
        }
    
    @classmethod
    def _calculate_complexity_score(cls, instruction: str) -> float:
        """Calculate 0-1 complexity score"""
        instruction_lower = instruction.lower()
        
        simple = sum(1 for kw in cls.SIMPLE_KEYWORDS if kw in instruction_lower)
        complex = sum(1 for kw in cls.COMPLEX_KEYWORDS if kw in instruction_lower)
        words = len(instruction.split())
        
        # Normalize to 0-1 scale
        score = (complex * 2 - simple + words / 50) / 10
        return max(0.0, min(1.0, score))  # Clamp to 0-1
    
    @classmethod
    def print_config(cls, config: Dict[str, Any]):
        """Print configuration in human-readable format"""
        print(f"📊 Adaptive Configuration:")
        print(f"   Thinking budget: {config['thinking_budget']} tokens")
        print(f"   Max tokens: {config['max_tokens']}")
        print(f"   Complexity: {config['complexity_score']:.0%}")


# Convenience function
def get_adaptive_config(instruction: str, agent_type: str) -> Dict[str, Any]:
    """Get adaptive configuration for instruction"""
    return AdaptiveConfig.get_optimized_config(instruction, agent_type) 