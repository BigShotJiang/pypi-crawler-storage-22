"""
Agent configuration loading and instruction-based agent selection.

Extracted from main.py.
"""

import os
from typing import Dict, List, Optional

from agent.logging_config import get_logger
from agent.types import AgentConfig

logger = get_logger(__name__)


def load_agent_configs() -> Dict[str, AgentConfig]:
    """Load agent configurations from environment variables."""
    configs = {}

    # Default values (used as fallback when env vars are not set)
    _DEFAULT_ORG_ID = "org_2LYmcWRL93PE6Os5NMthLARFEd2"
    _DEFAULT_AGENT_ID = "agent_2LYmcWRL93PE6Os5NMthLARFEd2"
    _DEFAULT_STRIPE_ID = "cus_2LYmcWRL93PE6Os5NMthLARFEd2"

    # Helper function to load config for a specific agent
    def load_config(agent_name: str, description: str, capabilities: List[str]) -> Optional[AgentConfig]:
        prefix = agent_name.upper().replace("-", "_")
        org_id = os.environ.get(f"{prefix}_ORG_ID", os.environ.get("DEFAULT_ORG_ID", _DEFAULT_ORG_ID))
        agent_id = os.environ.get(f"{prefix}_AGENT_ID", os.environ.get("DEFAULT_AGENT_ID", _DEFAULT_AGENT_ID))
        stripe_customer_id = os.environ.get(f"{prefix}_STRIPE_ID", os.environ.get("DEFAULT_STRIPE_ID", _DEFAULT_STRIPE_ID))

        if org_id and agent_id and stripe_customer_id:
            return AgentConfig(
                org_id=org_id,
                agent_id=agent_id,
                description=description,
                capabilities=capabilities,
                stripe_customer_id=stripe_customer_id
            )
        return None

    # Load each agent configuration
    agent_definitions = {
        "SOCIAL_MEDIA": ("Handles social media interactions", ["hiding_comments"]),
        "AUTO_CLOSE": ("Automatically closes tickets", ["ticket_closing", "selecting_contact_reason"]),
        "ONBOARDING": ("Handles user onboarding", ["user_setup", "create_rules", "create_attributes"]),
        "LINKEDIN_MESSENGER": ("Handles sending messages in LinkedIn to set a meeting", ["linkedin_messaging"]),
        "SLACK_SUPPORT": ("Handles sending messages in Slack to customer inquiries", ["slack_messaging"]),
        "SHOPIFY": ("Handles Shopify tasks", ["shopify_tasks"]),
        "STATESET_AGENTIC": ("Handles general agentic tasks", ["general_tasks"])
    }

    for agent_name, (description, capabilities) in agent_definitions.items():
        config = load_config(agent_name, description, capabilities)
        if config:
            configs[agent_name] = config
        else:
            logger.warning(f"Configuration for {agent_name} not found in environment variables. Agent will be unavailable.")

    if not configs:
        logger.error("No agent configurations loaded. Please set environment variables for at least one agent.")
        raise ValueError("No agent configurations available. Check your .env file.")

    return configs


def get_active_agents(instruction: str, agent_configs: Dict[str, AgentConfig]) -> List[AgentConfig]:
    """Determine which agents should handle the instruction"""
    active_agents = []
    instruction = instruction.lower()

    if "social media" in instruction:
        active_agents.append(agent_configs["SOCIAL_MEDIA"])
    if "auto-close" in instruction:
        active_agents.append(agent_configs["AUTO_CLOSE"])
    if "onboarding" in instruction:
        active_agents.append(agent_configs["ONBOARDING"])
    if "linkedin" in instruction:
        active_agents.append(agent_configs["LINKEDIN_MESSENGER"])
    if "slack" in instruction:
        active_agents.append(agent_configs["SLACK_SUPPORT"])
    if "shopify" in instruction:
        active_agents.append(agent_configs["SHOPIFY"])
    if "agentic" in instruction:
        active_agents.append(agent_configs["STATESET_AGENTIC"])
    return active_agents
