"""
Business Intelligence Dashboard for StateSet Computer Use Agent.

This module provides comprehensive analytics and reporting for enterprise
agent operations:

1. Real-time Metrics
   - Agent performance tracking
   - Task completion rates
   - Cost analytics
   - SLA monitoring

2. Cross-Agent Analytics
   - Department-level insights
   - Process efficiency metrics
   - Bottleneck detection
   - Trend analysis

3. Reporting
   - Automated report generation
   - Custom dashboards
   - Export capabilities
   - Scheduled reporting

4. Alerts and Notifications
   - Threshold-based alerts
   - Anomaly detection
   - Escalation workflows
   - Multi-channel notifications

Designed for executive visibility into AI operations.
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from collections import defaultdict
import statistics

from agent.logging_config import get_logger

logger = get_logger(__name__)


class MetricType(Enum):
    """Types of metrics"""
    COUNTER = "counter"        # Monotonically increasing
    GAUGE = "gauge"            # Point-in-time value
    HISTOGRAM = "histogram"    # Distribution
    SUMMARY = "summary"        # Statistical summary


class TimeGranularity(Enum):
    """Time granularities for aggregation"""
    MINUTE = "minute"
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"


class AlertSeverity(Enum):
    """Alert severity levels"""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


@dataclass
class MetricPoint:
    """A single metric data point"""
    timestamp: datetime
    value: float
    labels: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'timestamp': self.timestamp.isoformat(),
            'value': self.value,
            'labels': self.labels
        }


@dataclass
class MetricSeries:
    """A time series of metric points"""
    name: str
    metric_type: MetricType
    description: str = ""
    unit: str = ""
    points: List[MetricPoint] = field(default_factory=list)

    # Retention
    max_points: int = 10000
    retention_days: int = 30

    def add_point(self, value: float, labels: Dict[str, str] = None):
        """Add a data point"""
        point = MetricPoint(
            timestamp=datetime.utcnow(),
            value=value,
            labels=labels or {}
        )
        self.points.append(point)

        # Trim old points
        if len(self.points) > self.max_points:
            self.points = self.points[-self.max_points:]

    def get_latest(self) -> Optional[MetricPoint]:
        """Get latest point"""
        return self.points[-1] if self.points else None

    def get_range(
        self,
        start: datetime,
        end: datetime = None,
        labels: Dict[str, str] = None
    ) -> List[MetricPoint]:
        """Get points in time range"""
        end = end or datetime.utcnow()

        points = [
            p for p in self.points
            if start <= p.timestamp <= end
        ]

        if labels:
            points = [
                p for p in points
                if all(p.labels.get(k) == v for k, v in labels.items())
            ]

        return points

    def get_statistics(
        self,
        start: datetime = None,
        end: datetime = None
    ) -> Dict[str, float]:
        """Get statistical summary"""
        start = start or datetime.utcnow() - timedelta(hours=1)
        points = self.get_range(start, end)

        if not points:
            return {'count': 0}

        values = [p.value for p in points]

        return {
            'count': len(values),
            'min': min(values),
            'max': max(values),
            'avg': statistics.mean(values),
            'median': statistics.median(values),
            'stddev': statistics.stdev(values) if len(values) > 1 else 0,
            'sum': sum(values)
        }


@dataclass
class DashboardWidget:
    """A dashboard widget configuration"""
    widget_id: str
    title: str
    widget_type: str  # line_chart, bar_chart, pie_chart, stat, table, gauge
    metrics: List[str]
    config: Dict[str, Any] = field(default_factory=dict)

    # Layout
    row: int = 0
    col: int = 0
    width: int = 4
    height: int = 2

    def to_dict(self) -> Dict[str, Any]:
        return {
            'widget_id': self.widget_id,
            'title': self.title,
            'widget_type': self.widget_type,
            'metrics': self.metrics,
            'config': self.config,
            'layout': {
                'row': self.row,
                'col': self.col,
                'width': self.width,
                'height': self.height
            }
        }


@dataclass
class Dashboard:
    """A dashboard configuration"""
    dashboard_id: str
    name: str
    description: str = ""
    widgets: List[DashboardWidget] = field(default_factory=list)

    # Access control
    owner: str = ""
    department: str = ""
    is_public: bool = False

    # Auto-refresh
    refresh_interval_seconds: int = 30

    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'dashboard_id': self.dashboard_id,
            'name': self.name,
            'description': self.description,
            'widgets': [w.to_dict() for w in self.widgets],
            'owner': self.owner,
            'department': self.department,
            'refresh_interval_seconds': self.refresh_interval_seconds,
            'created_at': self.created_at.isoformat()
        }


@dataclass
class AlertRule:
    """An alert rule definition"""
    rule_id: str
    name: str
    description: str
    metric: str
    condition: str  # gt, lt, eq, ne, gte, lte
    threshold: float
    severity: AlertSeverity

    # Evaluation
    evaluation_window_seconds: int = 300
    evaluation_interval_seconds: int = 60

    # Notifications
    notification_channels: List[str] = field(default_factory=list)
    cooldown_seconds: int = 3600

    # State
    enabled: bool = True
    last_fired: Optional[datetime] = None
    last_value: Optional[float] = None

    def evaluate(self, value: float) -> bool:
        """Evaluate if alert should fire"""
        ops = {
            'gt': lambda v, t: v > t,
            'lt': lambda v, t: v < t,
            'eq': lambda v, t: v == t,
            'ne': lambda v, t: v != t,
            'gte': lambda v, t: v >= t,
            'lte': lambda v, t: v <= t
        }

        self.last_value = value
        return ops.get(self.condition, lambda v, t: False)(value, self.threshold)

    def can_fire(self) -> bool:
        """Check if alert can fire (cooldown check)"""
        if not self.last_fired:
            return True
        elapsed = (datetime.utcnow() - self.last_fired).total_seconds()
        return elapsed >= self.cooldown_seconds

    def to_dict(self) -> Dict[str, Any]:
        return {
            'rule_id': self.rule_id,
            'name': self.name,
            'metric': self.metric,
            'condition': f"{self.condition} {self.threshold}",
            'severity': self.severity.value,
            'enabled': self.enabled,
            'last_fired': self.last_fired.isoformat() if self.last_fired else None
        }


@dataclass
class AlertInstance:
    """A fired alert instance"""
    alert_id: str
    rule_id: str
    severity: AlertSeverity
    message: str
    value: float
    threshold: float

    fired_at: datetime = field(default_factory=datetime.utcnow)
    acknowledged_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None

    acknowledged_by: Optional[str] = None
    resolution_note: Optional[str] = None

    @property
    def is_active(self) -> bool:
        return self.resolved_at is None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'alert_id': self.alert_id,
            'rule_id': self.rule_id,
            'severity': self.severity.value,
            'message': self.message,
            'value': self.value,
            'threshold': self.threshold,
            'fired_at': self.fired_at.isoformat(),
            'is_active': self.is_active,
            'acknowledged': self.acknowledged_at is not None
        }


@dataclass
class Report:
    """A generated report"""
    report_id: str
    name: str
    report_type: str  # daily, weekly, monthly, custom
    period_start: datetime
    period_end: datetime

    # Content
    sections: List[Dict[str, Any]] = field(default_factory=list)
    summary: Dict[str, Any] = field(default_factory=dict)

    generated_at: datetime = field(default_factory=datetime.utcnow)
    generated_by: str = "system"

    def to_dict(self) -> Dict[str, Any]:
        return {
            'report_id': self.report_id,
            'name': self.name,
            'report_type': self.report_type,
            'period': {
                'start': self.period_start.isoformat(),
                'end': self.period_end.isoformat()
            },
            'summary': self.summary,
            'sections': self.sections,
            'generated_at': self.generated_at.isoformat()
        }


class MetricsCollector:
    """Collects and stores metrics from various sources"""

    def __init__(self, retention_days: int = 30):
        self.retention_days = retention_days
        self._series: Dict[str, MetricSeries] = {}
        self._lock = asyncio.Lock()

    def register_metric(
        self,
        name: str,
        metric_type: MetricType,
        description: str = "",
        unit: str = ""
    ):
        """Register a metric series"""
        if name not in self._series:
            self._series[name] = MetricSeries(
                name=name,
                metric_type=metric_type,
                description=description,
                unit=unit,
                retention_days=self.retention_days
            )

    async def record(
        self,
        name: str,
        value: float,
        labels: Dict[str, str] = None
    ):
        """Record a metric value"""
        async with self._lock:
            if name not in self._series:
                # Auto-register as gauge
                self.register_metric(name, MetricType.GAUGE)

            self._series[name].add_point(value, labels)

    async def increment(
        self,
        name: str,
        value: float = 1.0,
        labels: Dict[str, str] = None
    ):
        """Increment a counter metric"""
        async with self._lock:
            if name not in self._series:
                self.register_metric(name, MetricType.COUNTER)

            series = self._series[name]
            latest = series.get_latest()
            new_value = (latest.value if latest else 0) + value
            series.add_point(new_value, labels)

    def get_series(self, name: str) -> Optional[MetricSeries]:
        """Get a metric series"""
        return self._series.get(name)

    def list_metrics(self) -> List[str]:
        """List all registered metrics"""
        return list(self._series.keys())

    def query(
        self,
        name: str,
        start: datetime = None,
        end: datetime = None,
        labels: Dict[str, str] = None,
        aggregation: str = None
    ) -> Dict[str, Any]:
        """Query metric data"""
        series = self._series.get(name)
        if not series:
            return {'error': f'Metric not found: {name}'}

        start = start or datetime.utcnow() - timedelta(hours=1)
        points = series.get_range(start, end, labels)

        result = {
            'name': name,
            'type': series.metric_type.value,
            'unit': series.unit,
            'points': [p.to_dict() for p in points]
        }

        if aggregation:
            stats = series.get_statistics(start, end)
            result['statistics'] = stats

            if aggregation == 'avg':
                result['value'] = stats.get('avg', 0)
            elif aggregation == 'sum':
                result['value'] = stats.get('sum', 0)
            elif aggregation == 'max':
                result['value'] = stats.get('max', 0)
            elif aggregation == 'min':
                result['value'] = stats.get('min', 0)

        return result


class AlertManager:
    """Manages alert rules and notifications"""

    def __init__(self, metrics_collector: MetricsCollector):
        self.metrics = metrics_collector
        self._rules: Dict[str, AlertRule] = {}
        self._active_alerts: Dict[str, AlertInstance] = {}
        self._alert_history: List[AlertInstance] = []
        self._notification_handlers: Dict[str, Callable] = {}
        self._running = False

    def add_rule(self, rule: AlertRule):
        """Add an alert rule"""
        self._rules[rule.rule_id] = rule
        logger.info(f"Added alert rule: {rule.name}")

    def remove_rule(self, rule_id: str):
        """Remove an alert rule"""
        if rule_id in self._rules:
            del self._rules[rule_id]

    def register_notification_channel(
        self,
        channel: str,
        handler: Callable[[AlertInstance], None]
    ):
        """Register a notification channel"""
        self._notification_handlers[channel] = handler

    async def evaluate_rules(self):
        """Evaluate all alert rules"""
        for rule in self._rules.values():
            if not rule.enabled:
                continue

            try:
                # Get metric value
                series = self.metrics.get_series(rule.metric)
                if not series:
                    continue

                # Calculate value over evaluation window
                start = datetime.utcnow() - timedelta(seconds=rule.evaluation_window_seconds)
                stats = series.get_statistics(start)

                if stats['count'] == 0:
                    continue

                value = stats['avg']

                # Evaluate condition
                if rule.evaluate(value) and rule.can_fire():
                    await self._fire_alert(rule, value)

            except Exception as e:
                logger.error(f"Error evaluating rule {rule.rule_id}: {e}")

    async def _fire_alert(self, rule: AlertRule, value: float):
        """Fire an alert"""
        alert = AlertInstance(
            alert_id=f"alert-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}-{rule.rule_id[:8]}",
            rule_id=rule.rule_id,
            severity=rule.severity,
            message=f"{rule.name}: {rule.metric} is {value:.2f} ({rule.condition} {rule.threshold})",
            value=value,
            threshold=rule.threshold
        )

        self._active_alerts[alert.alert_id] = alert
        self._alert_history.append(alert)
        rule.last_fired = datetime.utcnow()

        # Keep history limited
        self._alert_history = self._alert_history[-1000:]

        # Send notifications
        for channel in rule.notification_channels:
            if channel in self._notification_handlers:
                try:
                    await asyncio.to_thread(
                        self._notification_handlers[channel],
                        alert
                    )
                except Exception as e:
                    logger.error(f"Notification error ({channel}): {e}")

        logger.warning(f"Alert fired: {alert.message}")

    def acknowledge_alert(self, alert_id: str, user: str):
        """Acknowledge an alert"""
        if alert_id in self._active_alerts:
            alert = self._active_alerts[alert_id]
            alert.acknowledged_at = datetime.utcnow()
            alert.acknowledged_by = user

    def resolve_alert(self, alert_id: str, note: str = None):
        """Resolve an alert"""
        if alert_id in self._active_alerts:
            alert = self._active_alerts[alert_id]
            alert.resolved_at = datetime.utcnow()
            alert.resolution_note = note
            del self._active_alerts[alert_id]

    def get_active_alerts(
        self,
        severity: AlertSeverity = None
    ) -> List[AlertInstance]:
        """Get active alerts"""
        alerts = list(self._active_alerts.values())
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        return sorted(alerts, key=lambda a: a.fired_at, reverse=True)

    async def start(self):
        """Start the alert evaluation loop"""
        self._running = True
        while self._running:
            try:
                await self.evaluate_rules()
                await asyncio.sleep(60)  # Evaluate every minute
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Alert manager error: {e}")

    def stop(self):
        """Stop the alert manager"""
        self._running = False


class ReportGenerator:
    """Generates business intelligence reports"""

    def __init__(self, metrics_collector: MetricsCollector):
        self.metrics = metrics_collector

    async def generate_daily_report(
        self,
        date: datetime = None
    ) -> Report:
        """Generate a daily operations report"""
        date = date or datetime.utcnow() - timedelta(days=1)
        start = date.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)

        report = Report(
            report_id=f"daily-{start.strftime('%Y%m%d')}",
            name=f"Daily Operations Report - {start.strftime('%Y-%m-%d')}",
            report_type="daily",
            period_start=start,
            period_end=end
        )

        # Collect metrics
        sections = []

        # Task metrics
        task_section = await self._generate_task_section(start, end)
        sections.append(task_section)

        # Agent metrics
        agent_section = await self._generate_agent_section(start, end)
        sections.append(agent_section)

        # Cost metrics
        cost_section = await self._generate_cost_section(start, end)
        sections.append(cost_section)

        # Performance metrics
        perf_section = await self._generate_performance_section(start, end)
        sections.append(perf_section)

        report.sections = sections

        # Generate summary
        report.summary = {
            'total_tasks': task_section.get('metrics', {}).get('total_tasks', 0),
            'success_rate': task_section.get('metrics', {}).get('success_rate', 0),
            'total_cost': cost_section.get('metrics', {}).get('total_cost', 0),
            'active_agents': agent_section.get('metrics', {}).get('active_agents', 0)
        }

        return report

    async def _generate_task_section(
        self,
        start: datetime,
        end: datetime
    ) -> Dict[str, Any]:
        """Generate task metrics section"""
        completed = self.metrics.query(
            'tasks.completed', start, end, aggregation='sum'
        )
        failed = self.metrics.query(
            'tasks.failed', start, end, aggregation='sum'
        )

        total = completed.get('value', 0) + failed.get('value', 0)
        success_rate = completed.get('value', 0) / total if total > 0 else 0

        return {
            'title': 'Task Metrics',
            'metrics': {
                'total_tasks': total,
                'completed': completed.get('value', 0),
                'failed': failed.get('value', 0),
                'success_rate': success_rate
            }
        }

    async def _generate_agent_section(
        self,
        start: datetime,
        end: datetime
    ) -> Dict[str, Any]:
        """Generate agent metrics section"""
        active = self.metrics.query(
            'agents.active', start, end, aggregation='max'
        )
        created = self.metrics.query(
            'agents.created', start, end, aggregation='sum'
        )

        return {
            'title': 'Agent Metrics',
            'metrics': {
                'active_agents': active.get('value', 0),
                'agents_created': created.get('value', 0),
                'peak_utilization': 0  # Would calculate from data
            }
        }

    async def _generate_cost_section(
        self,
        start: datetime,
        end: datetime
    ) -> Dict[str, Any]:
        """Generate cost metrics section"""
        total_cost = self.metrics.query(
            'cost.total', start, end, aggregation='sum'
        )
        api_cost = self.metrics.query(
            'cost.api', start, end, aggregation='sum'
        )

        return {
            'title': 'Cost Metrics',
            'metrics': {
                'total_cost': total_cost.get('value', 0),
                'api_cost': api_cost.get('value', 0),
                'cost_per_task': 0  # Would calculate
            }
        }

    async def _generate_performance_section(
        self,
        start: datetime,
        end: datetime
    ) -> Dict[str, Any]:
        """Generate performance metrics section"""
        latency = self.metrics.query(
            'task.latency', start, end, aggregation='avg'
        )
        throughput = self.metrics.query(
            'tasks.completed', start, end, aggregation='sum'
        )

        return {
            'title': 'Performance Metrics',
            'metrics': {
                'avg_latency_ms': latency.get('value', 0),
                'throughput': throughput.get('value', 0),
                'error_rate': 0  # Would calculate
            }
        }

    async def generate_department_report(
        self,
        department: str,
        start: datetime,
        end: datetime
    ) -> Report:
        """Generate a department-specific report"""
        report = Report(
            report_id=f"dept-{department}-{start.strftime('%Y%m%d')}",
            name=f"{department} Department Report",
            report_type="custom",
            period_start=start,
            period_end=end
        )

        # Would filter metrics by department label
        # Simplified for now
        report.sections = [{
            'title': f'{department} Overview',
            'metrics': {
                'total_tasks': 0,
                'active_agents': 0,
                'total_cost': 0
            }
        }]

        return report


class AnalyticsDashboard:
    """
    Main analytics dashboard for business intelligence.

    Provides a unified interface for metrics, alerts, and reporting.
    """

    def __init__(
        self,
        storage_dir: str = "/tmp/analytics"
    ):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # Components
        self.metrics = MetricsCollector()
        self.alerts = AlertManager(self.metrics)
        self.reports = ReportGenerator(self.metrics)

        # Dashboards
        self._dashboards: Dict[str, Dashboard] = {}

        # Initialize standard metrics
        self._init_standard_metrics()

        # Initialize default dashboard
        self._init_default_dashboard()

        # Background tasks
        self._running = False
        self._background_tasks: List[asyncio.Task] = []

    def _init_standard_metrics(self):
        """Initialize standard metric series"""
        # Task metrics
        self.metrics.register_metric('tasks.completed', MetricType.COUNTER, 'Completed tasks')
        self.metrics.register_metric('tasks.failed', MetricType.COUNTER, 'Failed tasks')
        self.metrics.register_metric('tasks.pending', MetricType.GAUGE, 'Pending tasks')
        self.metrics.register_metric('task.duration', MetricType.HISTOGRAM, 'Task duration', 'seconds')
        self.metrics.register_metric('task.latency', MetricType.HISTOGRAM, 'Task latency', 'ms')

        # Agent metrics
        self.metrics.register_metric('agents.active', MetricType.GAUGE, 'Active agents')
        self.metrics.register_metric('agents.created', MetricType.COUNTER, 'Agents created')
        self.metrics.register_metric('agents.terminated', MetricType.COUNTER, 'Agents terminated')
        self.metrics.register_metric('agent.utilization', MetricType.GAUGE, 'Agent utilization', '%')

        # Cost metrics
        self.metrics.register_metric('cost.total', MetricType.COUNTER, 'Total cost', 'USD')
        self.metrics.register_metric('cost.api', MetricType.COUNTER, 'API cost', 'USD')
        self.metrics.register_metric('cost.per_task', MetricType.GAUGE, 'Cost per task', 'USD')

        # Process metrics
        self.metrics.register_metric('processes.running', MetricType.GAUGE, 'Running processes')
        self.metrics.register_metric('processes.completed', MetricType.COUNTER, 'Completed processes')
        self.metrics.register_metric('process.duration', MetricType.HISTOGRAM, 'Process duration', 'seconds')

        # System metrics
        self.metrics.register_metric('system.cpu', MetricType.GAUGE, 'CPU usage', '%')
        self.metrics.register_metric('system.memory', MetricType.GAUGE, 'Memory usage', '%')
        self.metrics.register_metric('system.disk', MetricType.GAUGE, 'Disk usage', '%')

    def _init_default_dashboard(self):
        """Initialize the default dashboard"""
        dashboard = Dashboard(
            dashboard_id='main',
            name='Operations Overview',
            description='Main operations dashboard',
            is_public=True,
            widgets=[
                DashboardWidget(
                    widget_id='tasks-completed',
                    title='Tasks Completed (24h)',
                    widget_type='stat',
                    metrics=['tasks.completed'],
                    row=0, col=0, width=2, height=1
                ),
                DashboardWidget(
                    widget_id='success-rate',
                    title='Success Rate',
                    widget_type='gauge',
                    metrics=['tasks.completed', 'tasks.failed'],
                    config={'format': 'percent'},
                    row=0, col=2, width=2, height=1
                ),
                DashboardWidget(
                    widget_id='active-agents',
                    title='Active Agents',
                    widget_type='stat',
                    metrics=['agents.active'],
                    row=0, col=4, width=2, height=1
                ),
                DashboardWidget(
                    widget_id='total-cost',
                    title='Total Cost (24h)',
                    widget_type='stat',
                    metrics=['cost.total'],
                    config={'format': 'currency'},
                    row=0, col=6, width=2, height=1
                ),
                DashboardWidget(
                    widget_id='task-trend',
                    title='Task Completion Trend',
                    widget_type='line_chart',
                    metrics=['tasks.completed'],
                    config={'timeRange': '24h'},
                    row=1, col=0, width=4, height=2
                ),
                DashboardWidget(
                    widget_id='agent-utilization',
                    title='Agent Utilization',
                    widget_type='line_chart',
                    metrics=['agent.utilization'],
                    config={'timeRange': '24h'},
                    row=1, col=4, width=4, height=2
                ),
                DashboardWidget(
                    widget_id='cost-breakdown',
                    title='Cost Breakdown',
                    widget_type='pie_chart',
                    metrics=['cost.api', 'cost.total'],
                    row=3, col=0, width=4, height=2
                ),
                DashboardWidget(
                    widget_id='recent-alerts',
                    title='Recent Alerts',
                    widget_type='table',
                    metrics=[],
                    config={'source': 'alerts'},
                    row=3, col=4, width=4, height=2
                )
            ]
        )

        self._dashboards[dashboard.dashboard_id] = dashboard

    def _init_default_alerts(self):
        """Initialize default alert rules"""
        # High error rate alert
        self.alerts.add_rule(AlertRule(
            rule_id='high-error-rate',
            name='High Error Rate',
            description='Task failure rate exceeds threshold',
            metric='tasks.failed',
            condition='gt',
            threshold=10,
            severity=AlertSeverity.WARNING,
            evaluation_window_seconds=300,
            notification_channels=['log']
        ))

        # Budget warning
        self.alerts.add_rule(AlertRule(
            rule_id='budget-warning',
            name='Budget Warning',
            description='Daily cost approaching limit',
            metric='cost.total',
            condition='gt',
            threshold=100,
            severity=AlertSeverity.WARNING,
            evaluation_window_seconds=3600,
            notification_channels=['log']
        ))

        # Low agent availability
        self.alerts.add_rule(AlertRule(
            rule_id='low-agents',
            name='Low Agent Availability',
            description='Active agents below minimum',
            metric='agents.active',
            condition='lt',
            threshold=2,
            severity=AlertSeverity.CRITICAL,
            notification_channels=['log']
        ))

    # Metric Recording

    async def record_task_completed(
        self,
        agent_type: str,
        duration_seconds: float,
        cost: float
    ):
        """Record a task completion"""
        labels = {'agent_type': agent_type}
        await self.metrics.increment('tasks.completed', labels=labels)
        await self.metrics.record('task.duration', duration_seconds, labels=labels)
        await self.metrics.increment('cost.total', cost)

    async def record_task_failed(
        self,
        agent_type: str,
        error: str
    ):
        """Record a task failure"""
        labels = {'agent_type': agent_type, 'error': error[:50]}
        await self.metrics.increment('tasks.failed', labels=labels)

    async def record_agent_metrics(
        self,
        active_count: int,
        utilization: float
    ):
        """Record agent metrics"""
        await self.metrics.record('agents.active', active_count)
        await self.metrics.record('agent.utilization', utilization)

    async def record_process_completed(
        self,
        process_id: str,
        duration_seconds: float
    ):
        """Record process completion"""
        labels = {'process_id': process_id}
        await self.metrics.increment('processes.completed', labels=labels)
        await self.metrics.record('process.duration', duration_seconds, labels=labels)

    # Dashboard Management

    def create_dashboard(
        self,
        name: str,
        department: str = "",
        owner: str = ""
    ) -> Dashboard:
        """Create a new dashboard"""
        import uuid
        dashboard = Dashboard(
            dashboard_id=str(uuid.uuid4())[:8],
            name=name,
            department=department,
            owner=owner
        )
        self._dashboards[dashboard.dashboard_id] = dashboard
        return dashboard

    def get_dashboard(self, dashboard_id: str) -> Optional[Dashboard]:
        """Get a dashboard"""
        return self._dashboards.get(dashboard_id)

    def add_widget(
        self,
        dashboard_id: str,
        widget: DashboardWidget
    ) -> bool:
        """Add a widget to a dashboard"""
        dashboard = self._dashboards.get(dashboard_id)
        if not dashboard:
            return False

        dashboard.widgets.append(widget)
        dashboard.updated_at = datetime.utcnow()
        return True

    def get_dashboard_data(
        self,
        dashboard_id: str,
        time_range: str = "24h"
    ) -> Dict[str, Any]:
        """Get data for dashboard rendering"""
        dashboard = self._dashboards.get(dashboard_id)
        if not dashboard:
            return {'error': 'Dashboard not found'}

        # Parse time range
        ranges = {
            '1h': timedelta(hours=1),
            '6h': timedelta(hours=6),
            '24h': timedelta(hours=24),
            '7d': timedelta(days=7),
            '30d': timedelta(days=30)
        }
        delta = ranges.get(time_range, timedelta(hours=24))
        start = datetime.utcnow() - delta

        # Collect data for each widget
        widget_data = {}
        for widget in dashboard.widgets:
            data = self._get_widget_data(widget, start)
            widget_data[widget.widget_id] = data

        return {
            'dashboard': dashboard.to_dict(),
            'data': widget_data,
            'generated_at': datetime.utcnow().isoformat()
        }

    def _get_widget_data(
        self,
        widget: DashboardWidget,
        start: datetime
    ) -> Dict[str, Any]:
        """Get data for a specific widget"""
        if widget.config.get('source') == 'alerts':
            # Special handling for alerts widget
            alerts = self.alerts.get_active_alerts()
            return {
                'type': 'table',
                'data': [a.to_dict() for a in alerts[:10]]
            }

        # Get metric data
        data = {}
        for metric in widget.metrics:
            result = self.metrics.query(metric, start, aggregation='avg')
            data[metric] = result

        return {
            'type': widget.widget_type,
            'data': data
        }

    # Reporting

    async def generate_report(
        self,
        report_type: str = "daily",
        **kwargs
    ) -> Report:
        """Generate a report"""
        if report_type == "daily":
            return await self.reports.generate_daily_report(**kwargs)
        elif report_type == "department":
            return await self.reports.generate_department_report(**kwargs)
        else:
            raise ValueError(f"Unknown report type: {report_type}")

    # Executive Summary

    def get_executive_summary(self) -> Dict[str, Any]:
        """Get executive summary of operations"""
        now = datetime.utcnow()
        day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

        # Get key metrics
        tasks_completed = self.metrics.query(
            'tasks.completed', day_start, aggregation='sum'
        )
        tasks_failed = self.metrics.query(
            'tasks.failed', day_start, aggregation='sum'
        )
        total_cost = self.metrics.query(
            'cost.total', day_start, aggregation='sum'
        )
        active_agents = self.metrics.query(
            'agents.active', aggregation='avg'
        )

        completed = tasks_completed.get('value', 0)
        failed = tasks_failed.get('value', 0)
        total = completed + failed

        return {
            'period': 'today',
            'generated_at': now.isoformat(),
            'summary': {
                'total_tasks': total,
                'tasks_completed': completed,
                'tasks_failed': failed,
                'success_rate': completed / total if total > 0 else 1.0,
                'total_cost': total_cost.get('value', 0),
                'cost_per_task': total_cost.get('value', 0) / total if total > 0 else 0,
                'active_agents': active_agents.get('value', 0)
            },
            'alerts': {
                'active': len(self.alerts.get_active_alerts()),
                'critical': len(self.alerts.get_active_alerts(AlertSeverity.CRITICAL))
            },
            'trends': {
                'tasks_vs_yesterday': 0,  # Would calculate
                'cost_vs_yesterday': 0,
                'success_rate_trend': 'stable'
            }
        }

    # Lifecycle

    async def start(self):
        """Start the analytics dashboard"""
        if self._running:
            return

        self._running = True
        self._init_default_alerts()

        # Start background tasks
        self._background_tasks = [
            asyncio.create_task(self.alerts.start()),
            asyncio.create_task(self._metrics_aggregation_loop())
        ]

        logger.info("Analytics dashboard started")

    async def stop(self):
        """Stop the analytics dashboard"""
        self._running = False
        self.alerts.stop()

        for task in self._background_tasks:
            task.cancel()

        await asyncio.gather(*self._background_tasks, return_exceptions=True)

        logger.info("Analytics dashboard stopped")

    async def _metrics_aggregation_loop(self):
        """Background loop for metrics aggregation"""
        while self._running:
            try:
                # Periodic cleanup and aggregation
                await asyncio.sleep(300)  # Every 5 minutes

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Metrics aggregation error: {e}")


def get_analytics_dashboard(
    storage_dir: str = "/tmp/analytics"
) -> AnalyticsDashboard:
    """Get or create the analytics dashboard singleton"""
    if not hasattr(get_analytics_dashboard, '_instance'):
        get_analytics_dashboard._instance = AnalyticsDashboard(storage_dir)
    return get_analytics_dashboard._instance
