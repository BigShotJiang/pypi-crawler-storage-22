"""
Autonomous Agent Coordinator for StateSet Computer Use Agent.

This module provides the master coordinator for 24/7 multi-agent operation:

1. Multi-Agent Orchestration
   - Spawn and manage multiple agent instances
   - Load balancing across agents
   - Inter-agent communication

2. Production Observability
   - Real-time metrics dashboard
   - Alert management
   - Performance tracking

3. Autonomous Decision Making
   - Task prioritization
   - Resource allocation
   - Failure handling

4. System Governance
   - Budget enforcement
   - Rate limiting
   - SLA monitoring

This is the top-level coordinator that manages all other components.
"""

import asyncio
import logging
import time
import uuid
import os
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import (
    Any, Callable, Coroutine, Dict, List, Optional,
    Set, Tuple, TypeVar
)
from collections import defaultdict
import json
from pathlib import Path

from agent.resilience_engine import (
    ResilienceEngine, get_resilience_engine, initialize_resilience_engine,
    TaskState, TaskMetadata
)
from agent.adaptive_context import (
    AdaptiveContextManager, AttentionQuality,
    get_adaptive_context_manager
)
from agent.task_orchestrator import (
    TaskOrchestrator, TaskPriority, TaskComplexity,
    TaskResult, get_task_orchestrator
)
from agent.self_healing_loop import (
    SelfHealingLoop, SelfHealingLoopFactory, LoopState, LoopMetrics
)
from agent.health import HealthChecker, HealthStatus, get_health_checker
from agent.logging_config import get_logger

logger = get_logger(__name__)

T = TypeVar('T')


class AgentStatus(Enum):
    """Individual agent status"""
    IDLE = "idle"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    PAUSED = "paused"
    ERROR = "error"
    RECOVERING = "recovering"
    SHUTDOWN = "shutdown"


class AlertSeverity(Enum):
    """Alert severity levels"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class Alert:
    """System alert"""
    id: str
    severity: AlertSeverity
    title: str
    message: str
    source: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    acknowledged: bool = False
    resolved: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'severity': self.severity.value,
            'title': self.title,
            'message': self.message,
            'source': self.source,
            'timestamp': self.timestamp.isoformat(),
            'acknowledged': self.acknowledged,
            'resolved': self.resolved,
            'metadata': self.metadata
        }


@dataclass
class AgentInstance:
    """Represents a running agent instance"""
    instance_id: str
    agent_type: str
    agent_id: str
    status: AgentStatus
    task_id: Optional[str] = None
    instruction: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    last_heartbeat: Optional[datetime] = None
    metrics: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'instance_id': self.instance_id,
            'agent_type': self.agent_type,
            'agent_id': self.agent_id,
            'status': self.status.value,
            'task_id': self.task_id,
            'instruction': self.instruction[:100] + '...' if self.instruction and len(self.instruction) > 100 else self.instruction,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'last_heartbeat': self.last_heartbeat.isoformat() if self.last_heartbeat else None,
            'uptime_seconds': self.get_uptime(),
            'metrics': self.metrics,
            'error_message': self.error_message
        }

    def get_uptime(self) -> Optional[float]:
        if not self.started_at:
            return None
        return (datetime.utcnow() - self.started_at).total_seconds()


@dataclass
class SystemMetrics:
    """System-wide metrics"""
    total_tasks_completed: int = 0
    total_tasks_failed: int = 0
    total_tokens_used: int = 0
    total_cost: float = 0.0
    uptime_seconds: float = 0.0
    start_time: datetime = field(default_factory=datetime.utcnow)

    # Real-time metrics
    active_agents: int = 0
    pending_tasks: int = 0
    current_throughput: float = 0.0  # tasks/minute

    # Health metrics
    health_score: float = 1.0
    last_health_check: Optional[datetime] = None

    # Cost tracking
    daily_cost: float = 0.0
    hourly_cost: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            'total_tasks_completed': self.total_tasks_completed,
            'total_tasks_failed': self.total_tasks_failed,
            'success_rate': self.get_success_rate(),
            'total_tokens_used': self.total_tokens_used,
            'total_cost': f"${self.total_cost:.4f}",
            'uptime_seconds': self.uptime_seconds,
            'uptime_hours': self.uptime_seconds / 3600,
            'active_agents': self.active_agents,
            'pending_tasks': self.pending_tasks,
            'current_throughput': f"{self.current_throughput:.2f} tasks/min",
            'health_score': self.health_score,
            'daily_cost': f"${self.daily_cost:.4f}",
            'hourly_cost': f"${self.hourly_cost:.4f}"
        }

    def get_success_rate(self) -> float:
        total = self.total_tasks_completed + self.total_tasks_failed
        if total == 0:
            return 1.0
        return self.total_tasks_completed / total


class BudgetManager:
    """Manage cost budgets and enforcement"""

    def __init__(
        self,
        daily_budget: float = 100.0,
        hourly_budget: float = 10.0,
        per_task_budget: float = 5.0
    ):
        self.daily_budget = daily_budget
        self.hourly_budget = hourly_budget
        self.per_task_budget = per_task_budget

        self._daily_spend: float = 0.0
        self._hourly_spend: float = 0.0
        self._last_hour_reset = datetime.utcnow()
        self._last_day_reset = datetime.utcnow()

    def record_spend(self, amount: float) -> bool:
        """Record spending, return True if within budget"""
        now = datetime.utcnow()

        # Reset hourly if needed
        if (now - self._last_hour_reset).total_seconds() > 3600:
            self._hourly_spend = 0.0
            self._last_hour_reset = now

        # Reset daily if needed
        if (now - self._last_day_reset).total_seconds() > 86400:
            self._daily_spend = 0.0
            self._last_day_reset = now

        self._hourly_spend += amount
        self._daily_spend += amount

        return self.is_within_budget()

    def is_within_budget(self) -> bool:
        """Check if within budget limits"""
        return (
            self._daily_spend < self.daily_budget and
            self._hourly_spend < self.hourly_budget
        )

    def can_start_task(self, estimated_cost: float = 0.0) -> Tuple[bool, str]:
        """Check if a new task can be started within budget"""
        if estimated_cost > self.per_task_budget:
            return False, f"Estimated cost ${estimated_cost:.2f} exceeds per-task budget ${self.per_task_budget:.2f}"

        if self._daily_spend + estimated_cost > self.daily_budget:
            return False, f"Would exceed daily budget (${self._daily_spend:.2f} + ${estimated_cost:.2f} > ${self.daily_budget:.2f})"

        if self._hourly_spend + estimated_cost > self.hourly_budget:
            return False, f"Would exceed hourly budget"

        return True, ""

    def get_status(self) -> Dict[str, Any]:
        return {
            'daily_budget': self.daily_budget,
            'daily_spend': self._daily_spend,
            'daily_remaining': self.daily_budget - self._daily_spend,
            'hourly_budget': self.hourly_budget,
            'hourly_spend': self._hourly_spend,
            'hourly_remaining': self.hourly_budget - self._hourly_spend,
            'per_task_budget': self.per_task_budget,
            'within_budget': self.is_within_budget()
        }


class AlertManager:
    """Manage system alerts"""

    def __init__(self, max_alerts: int = 1000):
        self.max_alerts = max_alerts
        self._alerts: List[Alert] = []
        self._alert_handlers: List[Callable[[Alert], None]] = []

    def add_handler(self, handler: Callable[[Alert], None]):
        """Add alert handler callback"""
        self._alert_handlers.append(handler)

    def create_alert(
        self,
        severity: AlertSeverity,
        title: str,
        message: str,
        source: str,
        **metadata
    ) -> Alert:
        """Create and dispatch an alert"""
        alert = Alert(
            id=str(uuid.uuid4())[:8],
            severity=severity,
            title=title,
            message=message,
            source=source,
            metadata=metadata
        )

        self._alerts.append(alert)

        # Maintain max size
        if len(self._alerts) > self.max_alerts:
            self._alerts = self._alerts[-self.max_alerts:]

        # Log based on severity
        log_func = {
            AlertSeverity.INFO: logger.info,
            AlertSeverity.WARNING: logger.warning,
            AlertSeverity.ERROR: logger.error,
            AlertSeverity.CRITICAL: logger.critical
        }.get(severity, logger.info)

        log_func(f"[ALERT] {title}: {message}")

        # Dispatch to handlers
        for handler in self._alert_handlers:
            try:
                handler(alert)
            except Exception as e:
                logger.error(f"Alert handler error: {e}")

        return alert

    def acknowledge(self, alert_id: str) -> bool:
        """Acknowledge an alert"""
        for alert in self._alerts:
            if alert.id == alert_id:
                alert.acknowledged = True
                return True
        return False

    def resolve(self, alert_id: str) -> bool:
        """Resolve an alert"""
        for alert in self._alerts:
            if alert.id == alert_id:
                alert.resolved = True
                return True
        return False

    def get_active_alerts(self) -> List[Alert]:
        """Get unresolved alerts"""
        return [a for a in self._alerts if not a.resolved]

    def get_critical_alerts(self) -> List[Alert]:
        """Get critical unresolved alerts"""
        return [a for a in self._alerts
                if a.severity == AlertSeverity.CRITICAL and not a.resolved]

    def get_all_alerts(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent alerts as dicts"""
        return [a.to_dict() for a in self._alerts[-limit:]]


class AutonomousCoordinator:
    """
    Master coordinator for 24/7 autonomous multi-agent operation.

    This is the top-level component that orchestrates all agents,
    monitors system health, manages resources, and ensures continuous operation.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        max_agents: int = 10,
        daily_budget: float = 100.0,
        enable_auto_scaling: bool = True
    ):
        self.api_key = api_key or os.environ.get('ANTHROPIC_API_KEY', '')
        self.max_agents = max_agents
        self.enable_auto_scaling = enable_auto_scaling

        # Core components
        self.resilience_engine: Optional[ResilienceEngine] = None
        self.task_orchestrator: Optional[TaskOrchestrator] = None
        self.health_checker = get_health_checker()
        self.budget_manager = BudgetManager(daily_budget=daily_budget)
        self.alert_manager = AlertManager()

        # State tracking
        self._agents: Dict[str, AgentInstance] = {}
        self._agent_tasks: Dict[str, asyncio.Task] = {}
        self.metrics = SystemMetrics()

        # Control
        self._running = False
        self._shutdown_event = asyncio.Event()

        # Background tasks
        self._background_tasks: List[asyncio.Task] = []

        # Throughput tracking
        self._task_completions: List[float] = []  # timestamps

    async def start(self):
        """Start the autonomous coordinator"""
        logger.info("Starting Autonomous Coordinator...")

        if not self.api_key:
            raise ValueError("API key required for coordinator")

        # Initialize resilience engine
        self.resilience_engine = await initialize_resilience_engine()

        # Initialize task orchestrator
        self.task_orchestrator = get_task_orchestrator(self.api_key)

        # Start background tasks
        self._running = True

        self._background_tasks = [
            asyncio.create_task(self._health_monitor_loop()),
            asyncio.create_task(self._metrics_update_loop()),
            asyncio.create_task(self._auto_scaling_loop()),
            asyncio.create_task(self._alert_check_loop())
        ]

        self.metrics.start_time = datetime.utcnow()

        logger.info("Autonomous Coordinator started successfully")
        self.alert_manager.create_alert(
            AlertSeverity.INFO,
            "System Started",
            "Autonomous coordinator initialized and running",
            "coordinator"
        )

    async def stop(self):
        """Stop the coordinator gracefully"""
        logger.info("Stopping Autonomous Coordinator...")

        self._running = False
        self._shutdown_event.set()

        # Cancel background tasks
        for task in self._background_tasks:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # Stop all agents
        for instance_id in list(self._agents.keys()):
            await self.stop_agent(instance_id)

        # Cleanup components
        if self.resilience_engine:
            await self.resilience_engine.stop()

        if self.task_orchestrator:
            await self.task_orchestrator.shutdown()

        await SelfHealingLoopFactory.cleanup_all()

        logger.info("Autonomous Coordinator stopped")

    async def spawn_agent(
        self,
        agent_type: str,
        instruction: str,
        priority: TaskPriority = TaskPriority.NORMAL,
        **config
    ) -> str:
        """Spawn a new agent instance"""

        # Check capacity
        if len(self._agents) >= self.max_agents:
            raise RuntimeError(f"Max agents ({self.max_agents}) reached")

        # Check budget
        estimated_cost = config.get('estimated_cost', 0.5)
        can_start, reason = self.budget_manager.can_start_task(estimated_cost)
        if not can_start:
            raise RuntimeError(f"Budget constraint: {reason}")

        # Create instance
        instance_id = str(uuid.uuid4())[:8]
        agent_id = f"{agent_type.lower()}-{instance_id}"
        task_id = f"task-{instance_id}"

        instance = AgentInstance(
            instance_id=instance_id,
            agent_type=agent_type,
            agent_id=agent_id,
            status=AgentStatus.IDLE,
            task_id=task_id,
            instruction=instruction
        )

        self._agents[instance_id] = instance

        logger.info(f"Spawned agent '{instance_id}' ({agent_type})")

        # Start the agent
        agent_task = asyncio.create_task(
            self._run_agent(instance_id, instruction, priority, **config)
        )
        self._agent_tasks[instance_id] = agent_task

        return instance_id

    async def _run_agent(
        self,
        instance_id: str,
        instruction: str,
        priority: TaskPriority,
        **config
    ):
        """Run an agent instance"""
        instance = self._agents.get(instance_id)
        if not instance:
            return

        instance.status = AgentStatus.RUNNING
        instance.started_at = datetime.utcnow()

        # Create self-healing loop
        loop = SelfHealingLoopFactory.create(
            task_id=instance.task_id,
            agent_type=instance.agent_type,
            agent_id=instance.agent_id
        )

        try:
            await loop.initialize()

            # Run with resilience
            result = await self.resilience_engine.run_task_with_timeout(
                task_id=instance.task_id,
                agent_type=instance.agent_type,
                instruction=instruction,
                task_func=self._create_agent_task(instance, loop),
                timeout=config.get('timeout', 1800),
                **config
            )

            # Success
            instance.status = AgentStatus.IDLE
            self.metrics.total_tasks_completed += 1
            self._record_task_completion()

            logger.info(f"Agent '{instance_id}' completed task successfully")

        except asyncio.CancelledError:
            instance.status = AgentStatus.SHUTDOWN
            logger.info(f"Agent '{instance_id}' was cancelled")

        except Exception as e:
            instance.status = AgentStatus.ERROR
            instance.error_message = str(e)
            self.metrics.total_tasks_failed += 1

            logger.error(f"Agent '{instance_id}' failed: {e}")
            self.alert_manager.create_alert(
                AlertSeverity.ERROR,
                f"Agent {instance_id} Failed",
                str(e),
                f"agent-{instance_id}"
            )

        finally:
            await SelfHealingLoopFactory.cleanup(
                instance.task_id,
                instance.agent_type
            )

    def _create_agent_task(
        self,
        instance: AgentInstance,
        loop: SelfHealingLoop
    ) -> Callable[..., Coroutine[Any, Any, Any]]:
        """Create the actual agent task function"""

        async def agent_task(**kwargs):
            # Import here to avoid circular imports
            from agent.loop import sampling_loop

            # Get context manager
            context_manager = get_adaptive_context_manager(instance.agent_id)

            # Build initial message
            messages = [{
                'role': 'user',
                'content': [{'type': 'text', 'text': instance.instruction}]
            }]

            result = None
            should_continue = True

            while should_continue and loop.state in (LoopState.RUNNING, LoopState.RECOVERING):
                # Update heartbeat
                instance.last_heartbeat = datetime.utcnow()

                # Run iteration with self-healing
                result, messages, should_continue = await loop.run_iteration(
                    iteration_func=self._sampling_iteration,
                    messages=messages,
                    context_manager=context_manager,
                    instance=instance
                )

                # Update metrics
                if hasattr(result, 'input_tokens'):
                    self.metrics.total_tokens_used += result.input_tokens
                    self.metrics.total_tokens_used += result.output_tokens

            return result

        return agent_task

    async def _sampling_iteration(
        self,
        messages: List[Dict[str, Any]],
        context_manager: AdaptiveContextManager,
        instance: AgentInstance,
        **kwargs
    ):
        """Single sampling loop iteration"""
        from agent.loop import sampling_loop, APIProvider
        from agent.tools import TOOL_GROUPS_BY_VERSION

        # Get tool version
        tool_version = os.environ.get('TOOL_VERSION', 'computer_use_20251124')

        # Callbacks
        def output_callback(block):
            pass

        def tool_output_callback(result, tool_id):
            pass

        def api_response_callback(request, response, error):
            pass

        # Run sampling loop
        result = await sampling_loop(
            model="claude-opus-4-6-20260131",
            provider=APIProvider.ANTHROPIC,
            system_prompt_suffix="",
            messages=messages,
            output_callback=output_callback,
            tool_output_callback=tool_output_callback,
            api_response_callback=api_response_callback,
            api_key=self.api_key,
            org_id=os.environ.get('ORG_ID', 'default'),
            agent_id=instance.agent_id,
            agent_type=instance.agent_type,
            max_tokens=4096,
            tool_version=tool_version,
            width=int(os.environ.get('WIDTH', 1920)),
            height=int(os.environ.get('HEIGHT', 1080)),
            enable_context_management=True
        )

        # Update context metrics
        if hasattr(result, 'input_tokens'):
            context_manager.update_metrics(
                input_tokens=result.input_tokens,
                output_tokens=result.output_tokens
            )

        return result

    async def stop_agent(self, instance_id: str):
        """Stop a specific agent"""
        if instance_id not in self._agents:
            return

        instance = self._agents[instance_id]
        instance.status = AgentStatus.SHUTDOWN

        # Cancel the task
        if instance_id in self._agent_tasks:
            self._agent_tasks[instance_id].cancel()
            try:
                await self._agent_tasks[instance_id]
            except asyncio.CancelledError:
                pass
            del self._agent_tasks[instance_id]

        logger.info(f"Stopped agent '{instance_id}'")

    async def _health_monitor_loop(self):
        """Background health monitoring"""
        while self._running:
            try:
                health = await self.health_checker.get_system_health()

                self.metrics.health_score = {
                    HealthStatus.HEALTHY: 1.0,
                    HealthStatus.DEGRADED: 0.5,
                    HealthStatus.UNHEALTHY: 0.0
                }.get(health.status, 0.5)

                self.metrics.last_health_check = datetime.utcnow()

                # Create alerts for health issues
                if health.status == HealthStatus.UNHEALTHY:
                    for check in health.checks:
                        if check.status == HealthStatus.UNHEALTHY:
                            self.alert_manager.create_alert(
                                AlertSeverity.CRITICAL,
                                f"Health Check Failed: {check.name}",
                                check.message,
                                "health_monitor"
                            )

                await asyncio.sleep(30)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Health monitor error: {e}")
                await asyncio.sleep(10)

    async def _metrics_update_loop(self):
        """Background metrics updates"""
        while self._running:
            try:
                # Update uptime
                self.metrics.uptime_seconds = (
                    datetime.utcnow() - self.metrics.start_time
                ).total_seconds()

                # Update active agents
                self.metrics.active_agents = len([
                    a for a in self._agents.values()
                    if a.status == AgentStatus.RUNNING
                ])

                # Update throughput (tasks/minute over last 5 minutes)
                now = time.time()
                recent = [t for t in self._task_completions if now - t < 300]
                self._task_completions = recent
                self.metrics.current_throughput = len(recent) / 5.0

                # Update cost metrics
                budget_status = self.budget_manager.get_status()
                self.metrics.daily_cost = budget_status['daily_spend']
                self.metrics.hourly_cost = budget_status['hourly_spend']

                await asyncio.sleep(10)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Metrics update error: {e}")
                await asyncio.sleep(10)

    async def _auto_scaling_loop(self):
        """Background auto-scaling"""
        while self._running and self.enable_auto_scaling:
            try:
                # Check if we need to scale
                pending = self.task_orchestrator.task_queue.get_stats()['queue_size']
                active = self.metrics.active_agents

                # Scale up if queue is growing
                if pending > active * 2 and active < self.max_agents:
                    logger.info(
                        f"Auto-scaling: {pending} pending tasks, {active} active agents"
                    )
                    # Note: Actual scaling would need task context
                    # This is a placeholder for the scaling logic

                await asyncio.sleep(60)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Auto-scaling error: {e}")
                await asyncio.sleep(60)

    async def _alert_check_loop(self):
        """Background alert checking"""
        while self._running:
            try:
                # Check for critical conditions

                # Budget alerts
                budget = self.budget_manager.get_status()
                if budget['daily_remaining'] < budget['daily_budget'] * 0.1:
                    self.alert_manager.create_alert(
                        AlertSeverity.WARNING,
                        "Low Budget",
                        f"Only ${budget['daily_remaining']:.2f} remaining of daily budget",
                        "budget_monitor"
                    )

                # Health alerts are handled in health monitor

                # Performance alerts
                if self.metrics.health_score < 0.3:
                    self.alert_manager.create_alert(
                        AlertSeverity.ERROR,
                        "Low Health Score",
                        f"System health score is {self.metrics.health_score:.2f}",
                        "performance_monitor"
                    )

                await asyncio.sleep(60)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Alert check error: {e}")
                await asyncio.sleep(60)

    def _record_task_completion(self):
        """Record task completion for throughput tracking"""
        self._task_completions.append(time.time())

    def get_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        return {
            'running': self._running,
            'metrics': self.metrics.to_dict(),
            'agents': {
                id: agent.to_dict()
                for id, agent in self._agents.items()
            },
            'budget': self.budget_manager.get_status(),
            'alerts': {
                'active': len(self.alert_manager.get_active_alerts()),
                'critical': len(self.alert_manager.get_critical_alerts()),
                'recent': self.alert_manager.get_all_alerts(limit=10)
            },
            'resilience': self.resilience_engine.get_status() if self.resilience_engine else {},
            'orchestrator': self.task_orchestrator.get_metrics() if self.task_orchestrator else {}
        }

    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get data formatted for dashboard display"""
        status = self.get_status()

        return {
            'summary': {
                'status': 'running' if self._running else 'stopped',
                'health': self.metrics.health_score,
                'active_agents': self.metrics.active_agents,
                'tasks_completed': self.metrics.total_tasks_completed,
                'success_rate': self.metrics.get_success_rate(),
                'uptime_hours': self.metrics.uptime_seconds / 3600,
                'daily_cost': self.metrics.daily_cost
            },
            'agents': list(status['agents'].values()),
            'alerts': status['alerts'],
            'budget': status['budget'],
            'performance': {
                'throughput': self.metrics.current_throughput,
                'total_tokens': self.metrics.total_tokens_used,
                'avg_task_cost': (
                    self.metrics.total_cost / max(1, self.metrics.total_tasks_completed)
                )
            }
        }


# Global instance
_coordinator_instance: Optional[AutonomousCoordinator] = None


def get_coordinator(
    api_key: Optional[str] = None,
    **kwargs
) -> AutonomousCoordinator:
    """Get or create global coordinator"""
    global _coordinator_instance

    if _coordinator_instance is None:
        _coordinator_instance = AutonomousCoordinator(api_key, **kwargs)

    return _coordinator_instance


async def initialize_coordinator(
    api_key: Optional[str] = None,
    **kwargs
) -> AutonomousCoordinator:
    """Initialize and start the coordinator"""
    coordinator = get_coordinator(api_key, **kwargs)
    await coordinator.start()
    return coordinator


async def shutdown_coordinator():
    """Shutdown the global coordinator"""
    global _coordinator_instance

    if _coordinator_instance:
        await _coordinator_instance.stop()
        _coordinator_instance = None
