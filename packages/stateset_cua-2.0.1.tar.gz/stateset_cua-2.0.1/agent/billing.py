"""
Stripe billing integration for metered usage events.

Extracted from main.py.
"""

import os
from datetime import datetime

import httpx

from agent.logging_config import get_logger

logger = get_logger(__name__)


async def send_stripe_meter_event(stripe_customer_id: str, total_tokens: int, agent_type: str = "UNKNOWN"):
    """Send metered billing event to Stripe"""
    if not stripe_customer_id or total_tokens <= 0:
        return

    stripe_key = os.environ.get('STRIPE_API_KEY')
    if not stripe_key:
        logger.warning("STRIPE_API_KEY not set - skipping billing event",
                    extra={'agent_type': 'system'})
        return

    # Map agent types to Stripe meter event names
    event_name_map = {
        "AUTO_CLOSE": "auto_close_tickets",
        "SOCIAL_MEDIA": "social_media_moderation",
        "LINKEDIN_MESSENGER": "linkedin_messaging",
        "SLACK_SUPPORT": "slack_support",
        "ONBOARDING": "onboarding_tasks",
        "SHOPIFY": "shopify_tasks",
        "STATESET_AGENTIC": "general_agentic_tasks"
    }
    event_name = event_name_map.get(agent_type, f"agent_{agent_type.lower()}")

    timestamp = int(datetime.now().timestamp())
    url = "https://api.stripe.com/v1/billing/meter_events"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Bearer {stripe_key}"
    }
    data = {
        "event_name": event_name,
        "timestamp": timestamp,
        "payload[stripe_customer_id]": stripe_customer_id,
        "payload[value]": total_tokens
    }

    try:
        async with httpx.AsyncClient(timeout=30.0) as session:
            response = await session.post(url, headers=headers, data=data)
            response.raise_for_status()
            result = response.json()
            logger.info(f"Stripe metered usage logged: {total_tokens} tokens for customer {stripe_customer_id}",
                          extra={'agent_type': 'system'})
    except httpx.HTTPStatusError as e:
        logger.error(f"Stripe API error ({e.response.status_code}): {e.response.text}",
                    extra={'agent_type': 'system'})
    except httpx.TimeoutException:
        logger.error("Stripe API request timed out",
                    extra={'agent_type': 'system'})
    except Exception as e:
        logger.error(f"Unexpected error sending Stripe meter event: {str(e)}",
                    extra={'agent_type': 'system'})
