"""
Business Process Engine for StateSet Computer Use Agent.

This module provides enterprise-grade workflow orchestration for running
multiple agents across a business:

1. Process Definitions
   - YAML/JSON workflow definitions
   - Conditional branching and loops
   - Parallel and sequential execution
   - Error handling and compensation

2. Process Execution
   - State machine-based execution
   - Checkpoint and resume support
   - Timeout and deadline management
   - Resource allocation

3. Process Monitoring
   - Real-time process tracking
   - SLA monitoring
   - Bottleneck detection
   - Performance analytics

4. Business Rules
   - Rule-based routing
   - Dynamic agent selection
   - Priority escalation
   - Approval workflows

Designed for enterprise deployment across departments.
"""

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
import yaml

from agent.logging_config import get_logger

logger = get_logger(__name__)


class ProcessState(Enum):
    """Process execution states"""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    WAITING = "waiting"  # Waiting for external input/approval
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    COMPENSATING = "compensating"  # Running compensation/rollback


class StepType(Enum):
    """Types of workflow steps"""
    AGENT_TASK = "agent_task"      # Execute an agent
    HUMAN_TASK = "human_task"      # Requires human input
    SERVICE_CALL = "service_call"  # External API call
    DECISION = "decision"          # Conditional branching
    PARALLEL = "parallel"          # Parallel execution
    SUBPROCESS = "subprocess"      # Nested workflow
    WAIT = "wait"                  # Time-based wait
    SCRIPT = "script"              # Custom script execution


class TriggerType(Enum):
    """Process trigger types"""
    MANUAL = "manual"
    SCHEDULED = "scheduled"
    WEBHOOK = "webhook"
    EVENT = "event"
    CONDITION = "condition"


@dataclass
class StepDefinition:
    """Definition of a workflow step"""
    id: str
    name: str
    type: StepType
    config: Dict[str, Any] = field(default_factory=dict)

    # Execution settings
    timeout_seconds: int = 3600
    retry_count: int = 3
    retry_delay_seconds: int = 60

    # Flow control
    next_steps: List[str] = field(default_factory=list)
    on_error: Optional[str] = None  # Error handler step
    on_timeout: Optional[str] = None  # Timeout handler step

    # Conditions
    condition: Optional[str] = None  # Expression to evaluate

    # For parallel steps
    parallel_steps: List[str] = field(default_factory=list)
    join_type: str = "all"  # all, any, n_of_m

    # Compensation (rollback)
    compensation_step: Optional[str] = None

    # Resource requirements
    required_agents: List[str] = field(default_factory=list)
    priority: int = 5  # 1-10, higher = more important

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'type': self.type.value,
            'config': self.config,
            'timeout_seconds': self.timeout_seconds,
            'retry_count': self.retry_count,
            'next_steps': self.next_steps,
            'on_error': self.on_error,
            'condition': self.condition,
            'priority': self.priority
        }


@dataclass
class ProcessDefinition:
    """Definition of a business process"""
    id: str
    name: str
    description: str
    version: str = "1.0.0"

    # Structure
    steps: Dict[str, StepDefinition] = field(default_factory=dict)
    start_step: str = ""

    # Triggers
    triggers: List[Dict[str, Any]] = field(default_factory=list)

    # Settings
    timeout_seconds: int = 86400  # 24 hours default
    max_concurrent_instances: int = 10

    # Input/Output schema
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)

    # Metadata
    department: str = ""
    owner: str = ""
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def validate(self) -> Tuple[bool, List[str]]:
        """Validate process definition"""
        errors = []

        if not self.id:
            errors.append("Process ID is required")

        if not self.name:
            errors.append("Process name is required")

        if not self.steps:
            errors.append("Process must have at least one step")

        if self.start_step not in self.steps:
            errors.append(f"Start step '{self.start_step}' not found in steps")

        # Validate step references
        for step_id, step in self.steps.items():
            for next_step in step.next_steps:
                if next_step not in self.steps:
                    errors.append(f"Step '{step_id}' references unknown step '{next_step}'")

            if step.on_error and step.on_error not in self.steps:
                errors.append(f"Step '{step_id}' error handler references unknown step '{step.on_error}'")

        return len(errors) == 0, errors

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'version': self.version,
            'steps': {k: v.to_dict() for k, v in self.steps.items()},
            'start_step': self.start_step,
            'triggers': self.triggers,
            'timeout_seconds': self.timeout_seconds,
            'department': self.department,
            'owner': self.owner,
            'tags': self.tags
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ProcessDefinition':
        """Create from dictionary"""
        steps = {}
        for step_id, step_data in data.get('steps', {}).items():
            steps[step_id] = StepDefinition(
                id=step_id,
                name=step_data.get('name', step_id),
                type=StepType(step_data.get('type', 'agent_task')),
                config=step_data.get('config', {}),
                timeout_seconds=step_data.get('timeout_seconds', 3600),
                retry_count=step_data.get('retry_count', 3),
                next_steps=step_data.get('next_steps', []),
                on_error=step_data.get('on_error'),
                condition=step_data.get('condition'),
                parallel_steps=step_data.get('parallel_steps', []),
                required_agents=step_data.get('required_agents', []),
                priority=step_data.get('priority', 5)
            )

        return cls(
            id=data.get('id', str(uuid.uuid4())),
            name=data.get('name', 'Unnamed Process'),
            description=data.get('description', ''),
            version=data.get('version', '1.0.0'),
            steps=steps,
            start_step=data.get('start_step', ''),
            triggers=data.get('triggers', []),
            timeout_seconds=data.get('timeout_seconds', 86400),
            max_concurrent_instances=data.get('max_concurrent_instances', 10),
            input_schema=data.get('input_schema', {}),
            output_schema=data.get('output_schema', {}),
            department=data.get('department', ''),
            owner=data.get('owner', ''),
            tags=data.get('tags', [])
        )

    @classmethod
    def from_yaml(cls, yaml_content: str) -> 'ProcessDefinition':
        """Create from YAML content"""
        data = yaml.safe_load(yaml_content)
        return cls.from_dict(data)

    @classmethod
    def from_file(cls, file_path: str) -> 'ProcessDefinition':
        """Load from file"""
        path = Path(file_path)
        content = path.read_text()

        if path.suffix in ('.yaml', '.yml'):
            return cls.from_yaml(content)
        else:
            return cls.from_dict(json.loads(content))


@dataclass
class StepExecution:
    """Execution state of a step"""
    step_id: str
    state: ProcessState = ProcessState.PENDING
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Execution details
    attempt: int = 0
    assigned_agent: Optional[str] = None

    # Results
    output: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'step_id': self.step_id,
            'state': self.state.value,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'attempt': self.attempt,
            'assigned_agent': self.assigned_agent,
            'output': self.output,
            'error': self.error
        }


@dataclass
class ProcessInstance:
    """Running instance of a process"""
    instance_id: str
    process_id: str
    state: ProcessState = ProcessState.PENDING

    # Timing
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    deadline: Optional[datetime] = None

    # Current state
    current_step: Optional[str] = None
    step_executions: Dict[str, StepExecution] = field(default_factory=dict)

    # Data
    input_data: Dict[str, Any] = field(default_factory=dict)
    variables: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)

    # Tracking
    triggered_by: str = "manual"
    correlation_id: Optional[str] = None
    parent_instance_id: Optional[str] = None  # For subprocesses

    # History
    history: List[Dict[str, Any]] = field(default_factory=list)

    def record_event(self, event_type: str, details: Dict[str, Any] = None):
        """Record event in history"""
        self.history.append({
            'timestamp': datetime.utcnow().isoformat(),
            'event_type': event_type,
            'details': details or {}
        })

    def to_dict(self) -> Dict[str, Any]:
        return {
            'instance_id': self.instance_id,
            'process_id': self.process_id,
            'state': self.state.value,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'current_step': self.current_step,
            'step_executions': {k: v.to_dict() for k, v in self.step_executions.items()},
            'variables': self.variables,
            'output_data': self.output_data,
            'triggered_by': self.triggered_by,
            'history_length': len(self.history)
        }


class ExpressionEvaluator:
    """Safe expression evaluator for conditions"""

    @staticmethod
    def evaluate(expression: str, context: Dict[str, Any]) -> Any:
        """Evaluate expression in context"""
        # Simple expression evaluation (not using eval for security)
        # Supports: comparisons, boolean logic, variable access

        expression = expression.strip()

        # Variable access: ${variable_name}
        import re
        var_pattern = r'\$\{(\w+(?:\.\w+)*)\}'

        def replace_var(match):
            var_path = match.group(1)
            value = context
            for part in var_path.split('.'):
                if isinstance(value, dict):
                    value = value.get(part)
                else:
                    return 'None'
            return json.dumps(value) if not isinstance(value, (int, float, bool)) else str(value)

        expression = re.sub(var_pattern, replace_var, expression)

        # Simple evaluations
        if expression.lower() == 'true':
            return True
        elif expression.lower() == 'false':
            return False

        # Comparison operators
        for op, func in [
            ('==', lambda a, b: a == b),
            ('!=', lambda a, b: a != b),
            ('>=', lambda a, b: a >= b),
            ('<=', lambda a, b: a <= b),
            ('>', lambda a, b: a > b),
            ('<', lambda a, b: a < b),
        ]:
            if op in expression:
                parts = expression.split(op, 1)
                if len(parts) == 2:
                    left = parts[0].strip().strip('"\'')
                    right = parts[1].strip().strip('"\'')

                    # Try numeric comparison
                    try:
                        left = float(left)
                        right = float(right)
                    except ValueError:
                        pass

                    return func(left, right)

        # Boolean operators
        if ' and ' in expression.lower():
            parts = expression.lower().split(' and ')
            return all(ExpressionEvaluator.evaluate(p.strip(), context) for p in parts)

        if ' or ' in expression.lower():
            parts = expression.lower().split(' or ')
            return any(ExpressionEvaluator.evaluate(p.strip(), context) for p in parts)

        # Default: check if truthy
        try:
            return bool(json.loads(expression))
        except (json.JSONDecodeError, ValueError, TypeError):
            return bool(expression)


class StepExecutor:
    """Executes individual workflow steps"""

    def __init__(
        self,
        agent_executor: Callable = None,
        service_registry: Dict[str, Callable] = None
    ):
        self.agent_executor = agent_executor
        self.service_registry = service_registry or {}
        self._handlers: Dict[StepType, Callable] = {
            StepType.AGENT_TASK: self._execute_agent_task,
            StepType.HUMAN_TASK: self._execute_human_task,
            StepType.SERVICE_CALL: self._execute_service_call,
            StepType.DECISION: self._execute_decision,
            StepType.PARALLEL: self._execute_parallel,
            StepType.WAIT: self._execute_wait,
            StepType.SCRIPT: self._execute_script,
        }

    async def execute(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """
        Execute a step.
        Returns: (success, output, next_step_id)
        """
        handler = self._handlers.get(step.type)
        if not handler:
            return False, {'error': f'Unknown step type: {step.type}'}, step.on_error

        try:
            return await handler(step, instance, context)
        except Exception as e:
            logger.error(f"Step execution failed: {e}")
            return False, {'error': str(e)}, step.on_error

    async def _execute_agent_task(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """Execute an agent task"""
        config = step.config

        agent_type = config.get('agent_type', 'GENERAL')
        instruction = config.get('instruction', '')

        # Variable substitution in instruction
        for key, value in instance.variables.items():
            instruction = instruction.replace(f'${{{key}}}', str(value))

        if self.agent_executor:
            try:
                result = await self.agent_executor(
                    agent_type=agent_type,
                    instruction=instruction,
                    context=context
                )
                return True, {'result': result}, step.next_steps[0] if step.next_steps else None
            except Exception as e:
                return False, {'error': str(e)}, step.on_error
        else:
            # Placeholder for when no executor is configured
            logger.info(f"Would execute agent task: {agent_type} - {instruction}")
            return True, {'result': 'simulated'}, step.next_steps[0] if step.next_steps else None

    async def _execute_human_task(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """Create a human task and wait for completion"""
        config = step.config

        # In a real implementation, this would create a task in a task management system
        logger.info(f"Human task created: {step.name}")
        logger.info(f"  Assignee: {config.get('assignee', 'unassigned')}")
        logger.info(f"  Description: {config.get('description', '')}")

        # For now, auto-approve (in production, this would wait)
        if config.get('auto_approve', False):
            return True, {'approved': True}, step.next_steps[0] if step.next_steps else None

        # Return waiting state
        return True, {'status': 'waiting_for_human'}, None

    async def _execute_service_call(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """Execute an external service call"""
        config = step.config
        service_name = config.get('service')

        if service_name in self.service_registry:
            try:
                result = await self.service_registry[service_name](
                    **config.get('params', {})
                )
                return True, {'result': result}, step.next_steps[0] if step.next_steps else None
            except Exception as e:
                return False, {'error': str(e)}, step.on_error
        else:
            return False, {'error': f'Service not found: {service_name}'}, step.on_error

    async def _execute_decision(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """Execute a decision/branching step"""
        config = step.config
        conditions = config.get('conditions', [])

        eval_context = {
            'input': instance.input_data,
            'variables': instance.variables,
            'steps': {k: v.output for k, v in instance.step_executions.items()},
            **context
        }

        for condition in conditions:
            expr = condition.get('expression', 'true')
            target = condition.get('target')

            if ExpressionEvaluator.evaluate(expr, eval_context):
                return True, {'matched_condition': expr}, target

        # Default path
        default_target = config.get('default')
        return True, {'matched_condition': 'default'}, default_target

    async def _execute_parallel(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """Execute parallel steps"""
        # Parallel execution is handled by the engine
        return True, {'parallel_started': step.parallel_steps}, None

    async def _execute_wait(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """Execute a wait step"""
        config = step.config
        wait_seconds = config.get('seconds', 0)
        wait_until = config.get('until')  # ISO datetime string

        if wait_until:
            target_time = datetime.fromisoformat(wait_until)
            wait_seconds = (target_time - datetime.utcnow()).total_seconds()
            wait_seconds = max(0, wait_seconds)

        if wait_seconds > 0:
            await asyncio.sleep(min(wait_seconds, 60))  # Cap at 60s for testing

        return True, {'waited_seconds': wait_seconds}, step.next_steps[0] if step.next_steps else None

    async def _execute_script(
        self,
        step: StepDefinition,
        instance: ProcessInstance,
        context: Dict[str, Any]
    ) -> Tuple[bool, Dict[str, Any], Optional[str]]:
        """Execute a custom script"""
        config = step.config
        script_type = config.get('type', 'python')

        # For security, we only support predefined script actions
        action = config.get('action')

        if action == 'set_variable':
            var_name = config.get('variable')
            var_value = config.get('value')

            # Evaluate if it's an expression
            if isinstance(var_value, str) and var_value.startswith('${'):
                eval_context = {
                    'input': instance.input_data,
                    'variables': instance.variables,
                    'steps': {k: v.output for k, v in instance.step_executions.items()},
                }
                var_value = ExpressionEvaluator.evaluate(var_value, eval_context)

            instance.variables[var_name] = var_value
            return True, {'set': {var_name: var_value}}, step.next_steps[0] if step.next_steps else None

        elif action == 'aggregate':
            # Aggregate results from multiple steps
            source_steps = config.get('source_steps', [])
            target_var = config.get('target_variable', 'aggregated')

            results = []
            for step_id in source_steps:
                if step_id in instance.step_executions:
                    results.append(instance.step_executions[step_id].output)

            instance.variables[target_var] = results
            return True, {'aggregated': len(results)}, step.next_steps[0] if step.next_steps else None

        return False, {'error': f'Unknown script action: {action}'}, step.on_error


class BusinessProcessEngine:
    """
    Main engine for executing business processes.

    Orchestrates workflow execution across multiple agents and departments.
    """

    def __init__(
        self,
        storage_dir: str = "/tmp/business_processes",
        agent_executor: Callable = None
    ):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # Process definitions
        self._definitions: Dict[str, ProcessDefinition] = {}

        # Running instances
        self._instances: Dict[str, ProcessInstance] = {}

        # Execution
        self._executor = StepExecutor(agent_executor=agent_executor)
        self._running_tasks: Dict[str, asyncio.Task] = {}

        # Event handlers
        self._event_handlers: Dict[str, List[Callable]] = {}

        # Statistics
        self._stats = {
            'total_instances': 0,
            'completed_instances': 0,
            'failed_instances': 0,
            'active_instances': 0
        }

    # Process Definition Management

    def register_process(self, definition: ProcessDefinition) -> bool:
        """Register a process definition"""
        valid, errors = definition.validate()
        if not valid:
            logger.error(f"Invalid process definition: {errors}")
            return False

        self._definitions[definition.id] = definition
        logger.info(f"Registered process '{definition.name}' (v{definition.version})")
        return True

    def load_process_from_file(self, file_path: str) -> Optional[ProcessDefinition]:
        """Load and register a process from file"""
        try:
            definition = ProcessDefinition.from_file(file_path)
            if self.register_process(definition):
                return definition
        except Exception as e:
            logger.error(f"Failed to load process from {file_path}: {e}")
        return None

    def get_process(self, process_id: str) -> Optional[ProcessDefinition]:
        """Get a process definition"""
        return self._definitions.get(process_id)

    def list_processes(
        self,
        department: str = None,
        tags: List[str] = None
    ) -> List[ProcessDefinition]:
        """List process definitions with optional filters"""
        results = list(self._definitions.values())

        if department:
            results = [p for p in results if p.department == department]

        if tags:
            results = [p for p in results if any(t in p.tags for t in tags)]

        return results

    # Process Instance Management

    async def start_process(
        self,
        process_id: str,
        input_data: Dict[str, Any] = None,
        triggered_by: str = "manual",
        correlation_id: str = None
    ) -> Optional[ProcessInstance]:
        """Start a new process instance"""
        definition = self._definitions.get(process_id)
        if not definition:
            logger.error(f"Process not found: {process_id}")
            return None

        # Check concurrent instance limit
        active_count = sum(
            1 for i in self._instances.values()
            if i.process_id == process_id and i.state == ProcessState.RUNNING
        )

        if active_count >= definition.max_concurrent_instances:
            logger.warning(f"Max concurrent instances reached for {process_id}")
            return None

        # Create instance
        instance = ProcessInstance(
            instance_id=str(uuid.uuid4()),
            process_id=process_id,
            input_data=input_data or {},
            variables=dict(input_data or {}),  # Copy input to variables
            triggered_by=triggered_by,
            correlation_id=correlation_id,
            deadline=datetime.utcnow() + timedelta(seconds=definition.timeout_seconds)
        )

        self._instances[instance.instance_id] = instance
        self._stats['total_instances'] += 1
        self._stats['active_instances'] += 1

        instance.record_event('process_started', {'input': input_data})
        logger.info(f"Started process instance {instance.instance_id} for {process_id}")

        # Start execution
        task = asyncio.create_task(self._execute_instance(instance, definition))
        self._running_tasks[instance.instance_id] = task

        return instance

    async def _execute_instance(
        self,
        instance: ProcessInstance,
        definition: ProcessDefinition
    ):
        """Execute a process instance"""
        instance.state = ProcessState.RUNNING
        instance.started_at = datetime.utcnow()
        instance.current_step = definition.start_step

        try:
            while instance.current_step and instance.state == ProcessState.RUNNING:
                # Check deadline
                if instance.deadline and datetime.utcnow() > instance.deadline:
                    instance.state = ProcessState.FAILED
                    instance.record_event('deadline_exceeded')
                    break

                step = definition.steps.get(instance.current_step)
                if not step:
                    logger.error(f"Step not found: {instance.current_step}")
                    instance.state = ProcessState.FAILED
                    break

                # Execute step
                await self._execute_step(instance, step)

                # Check if waiting for external input
                if instance.state == ProcessState.WAITING:
                    break

            # Check completion
            if instance.state == ProcessState.RUNNING and not instance.current_step:
                instance.state = ProcessState.COMPLETED
                instance.completed_at = datetime.utcnow()
                instance.record_event('process_completed', {'output': instance.output_data})
                self._stats['completed_instances'] += 1
                logger.info(f"Process instance {instance.instance_id} completed")

        except Exception as e:
            logger.error(f"Process execution error: {e}")
            instance.state = ProcessState.FAILED
            instance.record_event('process_failed', {'error': str(e)})
            self._stats['failed_instances'] += 1

        finally:
            self._stats['active_instances'] -= 1
            if instance.instance_id in self._running_tasks:
                del self._running_tasks[instance.instance_id]

    async def _execute_step(
        self,
        instance: ProcessInstance,
        step: StepDefinition
    ):
        """Execute a single step"""
        # Initialize step execution
        step_exec = StepExecution(step_id=step.id)
        step_exec.state = ProcessState.RUNNING
        step_exec.started_at = datetime.utcnow()
        step_exec.attempt += 1
        instance.step_executions[step.id] = step_exec

        instance.record_event('step_started', {'step_id': step.id, 'attempt': step_exec.attempt})

        # Handle parallel steps
        if step.type == StepType.PARALLEL:
            await self._execute_parallel_steps(instance, step)
            return

        # Execute with retry
        success = False
        for attempt in range(step.retry_count):
            step_exec.attempt = attempt + 1

            context = {
                'instance_id': instance.instance_id,
                'step_id': step.id,
                'attempt': step_exec.attempt
            }

            success, output, next_step = await asyncio.wait_for(
                self._executor.execute(step, instance, context),
                timeout=step.timeout_seconds
            )

            step_exec.output = output

            if success:
                break

            if attempt < step.retry_count - 1:
                await asyncio.sleep(step.retry_delay_seconds)

        # Update step execution
        step_exec.completed_at = datetime.utcnow()
        step_exec.state = ProcessState.COMPLETED if success else ProcessState.FAILED

        if success:
            instance.record_event('step_completed', {'step_id': step.id, 'output': output})
            instance.current_step = next_step

            # Store output in variables
            instance.variables[f'step_{step.id}_output'] = output
        else:
            step_exec.error = output.get('error', 'Unknown error')
            instance.record_event('step_failed', {'step_id': step.id, 'error': step_exec.error})

            # Handle error
            if step.on_error:
                instance.current_step = step.on_error
            else:
                instance.state = ProcessState.FAILED

    async def _execute_parallel_steps(
        self,
        instance: ProcessInstance,
        step: StepDefinition
    ):
        """Execute steps in parallel"""
        definition = self._definitions[instance.process_id]

        tasks = []
        for parallel_step_id in step.parallel_steps:
            parallel_step = definition.steps.get(parallel_step_id)
            if parallel_step:
                task = asyncio.create_task(
                    self._execute_step(instance, parallel_step)
                )
                tasks.append((parallel_step_id, task))

        # Wait based on join type
        if step.join_type == 'all':
            await asyncio.gather(*[t for _, t in tasks])
        elif step.join_type == 'any':
            done, pending = await asyncio.wait(
                [t for _, t in tasks],
                return_when=asyncio.FIRST_COMPLETED
            )
            for t in pending:
                t.cancel()

        # Move to next step
        instance.current_step = step.next_steps[0] if step.next_steps else None

    def get_instance(self, instance_id: str) -> Optional[ProcessInstance]:
        """Get a process instance"""
        return self._instances.get(instance_id)

    def list_instances(
        self,
        process_id: str = None,
        state: ProcessState = None,
        limit: int = 100
    ) -> List[ProcessInstance]:
        """List process instances with optional filters"""
        results = list(self._instances.values())

        if process_id:
            results = [i for i in results if i.process_id == process_id]

        if state:
            results = [i for i in results if i.state == state]

        # Sort by creation time, newest first
        results.sort(key=lambda i: i.created_at, reverse=True)

        return results[:limit]

    async def cancel_instance(self, instance_id: str) -> bool:
        """Cancel a running process instance"""
        instance = self._instances.get(instance_id)
        if not instance:
            return False

        if instance.state not in (ProcessState.RUNNING, ProcessState.WAITING, ProcessState.PAUSED):
            return False

        # Cancel running task
        if instance_id in self._running_tasks:
            self._running_tasks[instance_id].cancel()

        instance.state = ProcessState.CANCELLED
        instance.completed_at = datetime.utcnow()
        instance.record_event('process_cancelled')

        self._stats['active_instances'] -= 1
        logger.info(f"Cancelled process instance {instance_id}")

        return True

    async def resume_instance(
        self,
        instance_id: str,
        input_data: Dict[str, Any] = None
    ) -> bool:
        """Resume a waiting process instance"""
        instance = self._instances.get(instance_id)
        if not instance or instance.state != ProcessState.WAITING:
            return False

        definition = self._definitions.get(instance.process_id)
        if not definition:
            return False

        # Update variables with new input
        if input_data:
            instance.variables.update(input_data)

        instance.state = ProcessState.RUNNING
        instance.record_event('process_resumed', {'input': input_data})

        # Continue execution
        task = asyncio.create_task(self._execute_instance(instance, definition))
        self._running_tasks[instance.instance_id] = task

        return True

    # Statistics and Monitoring

    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics"""
        return {
            **self._stats,
            'registered_processes': len(self._definitions),
            'processes_by_state': self._get_state_distribution()
        }

    def _get_state_distribution(self) -> Dict[str, int]:
        """Get distribution of instances by state"""
        distribution = {state.value: 0 for state in ProcessState}
        for instance in self._instances.values():
            distribution[instance.state.value] += 1
        return distribution

    def get_process_metrics(self, process_id: str) -> Dict[str, Any]:
        """Get metrics for a specific process"""
        instances = [i for i in self._instances.values() if i.process_id == process_id]

        completed = [i for i in instances if i.state == ProcessState.COMPLETED]
        failed = [i for i in instances if i.state == ProcessState.FAILED]

        # Calculate average duration
        durations = []
        for i in completed:
            if i.started_at and i.completed_at:
                durations.append((i.completed_at - i.started_at).total_seconds())

        avg_duration = sum(durations) / len(durations) if durations else 0

        return {
            'process_id': process_id,
            'total_instances': len(instances),
            'completed': len(completed),
            'failed': len(failed),
            'success_rate': len(completed) / len(instances) if instances else 0,
            'average_duration_seconds': avg_duration,
            'active_instances': sum(1 for i in instances if i.state == ProcessState.RUNNING)
        }


# Pre-built process templates for common business workflows

TICKET_RESOLUTION_PROCESS = """
id: ticket_resolution
name: Customer Ticket Resolution
description: Automated ticket triage, routing, and resolution
version: "1.0.0"
department: customer_support
owner: support_team
tags:
  - customer_service
  - automation
  - tickets

start_step: triage

steps:
  triage:
    name: Triage Ticket
    type: agent_task
    config:
      agent_type: AUTO_CLOSE
      instruction: "Analyze ticket ${ticket_id} and determine priority and category"
    next_steps:
      - route_ticket
    timeout_seconds: 300

  route_ticket:
    name: Route Ticket
    type: decision
    config:
      conditions:
        - expression: "${variables.priority} == 'high'"
          target: escalate_to_human
        - expression: "${variables.category} == 'billing'"
          target: process_billing
        - expression: "${variables.category} == 'technical'"
          target: process_technical
      default: auto_respond

  escalate_to_human:
    name: Escalate to Human Agent
    type: human_task
    config:
      assignee: senior_support
      description: "High priority ticket requires human attention"
    next_steps:
      - close_ticket

  process_billing:
    name: Process Billing Issue
    type: agent_task
    config:
      agent_type: BILLING
      instruction: "Review and resolve billing issue for ticket ${ticket_id}"
    next_steps:
      - close_ticket
    on_error: escalate_to_human

  process_technical:
    name: Process Technical Issue
    type: agent_task
    config:
      agent_type: TECHNICAL_SUPPORT
      instruction: "Diagnose and resolve technical issue for ticket ${ticket_id}"
    next_steps:
      - close_ticket
    on_error: escalate_to_human

  auto_respond:
    name: Auto Respond
    type: agent_task
    config:
      agent_type: AUTO_CLOSE
      instruction: "Generate and send automated response for ticket ${ticket_id}"
    next_steps:
      - close_ticket

  close_ticket:
    name: Close Ticket
    type: agent_task
    config:
      agent_type: AUTO_CLOSE
      instruction: "Close ticket ${ticket_id} and send satisfaction survey"
"""

CONTENT_MODERATION_PROCESS = """
id: content_moderation
name: Social Media Content Moderation
description: Automated content review and moderation pipeline
version: "1.0.0"
department: marketing
owner: social_media_team
tags:
  - social_media
  - moderation
  - compliance

start_step: scan_content

steps:
  scan_content:
    name: Scan Content
    type: agent_task
    config:
      agent_type: SOCIAL_MEDIA
      instruction: "Scan and analyze content for policy violations"
    next_steps:
      - evaluate_risk

  evaluate_risk:
    name: Evaluate Risk Level
    type: decision
    config:
      conditions:
        - expression: "${variables.risk_level} == 'high'"
          target: human_review
        - expression: "${variables.risk_level} == 'medium'"
          target: auto_moderate
      default: approve_content

  human_review:
    name: Human Review Required
    type: human_task
    config:
      assignee: content_moderator
      description: "High-risk content requires human review"
    next_steps:
      - apply_action

  auto_moderate:
    name: Auto Moderate
    type: agent_task
    config:
      agent_type: SOCIAL_MEDIA
      instruction: "Apply automated moderation action"
    next_steps:
      - log_action

  approve_content:
    name: Approve Content
    type: script
    config:
      action: set_variable
      variable: moderation_result
      value: approved
    next_steps:
      - log_action

  apply_action:
    name: Apply Moderation Action
    type: agent_task
    config:
      agent_type: SOCIAL_MEDIA
      instruction: "Apply moderation decision: ${variables.moderation_decision}"
    next_steps:
      - log_action

  log_action:
    name: Log Moderation Action
    type: service_call
    config:
      service: audit_logger
      params:
        action_type: content_moderation
        content_id: "${variables.content_id}"
        result: "${variables.moderation_result}"
"""


def get_business_process_engine(
    storage_dir: str = "/tmp/business_processes",
    agent_executor: Callable = None
) -> BusinessProcessEngine:
    """Get or create the business process engine singleton"""
    if not hasattr(get_business_process_engine, '_instance'):
        get_business_process_engine._instance = BusinessProcessEngine(
            storage_dir=storage_dir,
            agent_executor=agent_executor
        )
    return get_business_process_engine._instance
