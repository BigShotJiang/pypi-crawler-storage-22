"""
Checkpoint system for long-running tasks.
Enables resume from crashes, progress tracking, and heartbeat monitoring.
"""

import asyncio
import json
import os
import time
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict, field

logger = logging.getLogger('agent.checkpoint')

_agent_data_dir = os.environ.get("AGENT_DATA_DIR", "/tmp")

@dataclass
class TaskProgress:
    """Progress information for a long-running task"""
    task_id: str
    agent_type: str
    instruction: str
    total_items: int
    completed_items: int = 0
    successful_items: int = 0
    failed_items: int = 0
    start_time: float = field(default_factory=time.time)
    last_updated: float = field(default_factory=time.time)
    errors: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'TaskProgress':
        """Create from dictionary"""
        return cls(**data)
    
    def get_progress_percent(self) -> float:
        """Get completion percentage"""
        return (self.completed_items / self.total_items * 100) if self.total_items > 0 else 0
    
    def get_success_rate(self) -> float:
        """Get success rate"""
        if self.completed_items == 0:
            return 0.0
        return self.successful_items / self.completed_items
    
    def get_eta_hours(self) -> float:
        """Estimate hours remaining"""
        elapsed = time.time() - self.start_time
        if self.completed_items == 0 or elapsed <= 0:
            return 0.0

        rate = self.completed_items / elapsed  # items per second
        remaining = self.total_items - self.completed_items
        eta_seconds = remaining / rate if rate > 0 else 0
        return eta_seconds / 3600  # Convert to hours


class CheckpointManager:
    """Manage checkpoints for long-running tasks using memory tool"""
    
    def __init__(self, agent_type: str):
        self.agent_type = agent_type
        self.checkpoint_dir = f"{_agent_data_dir}/agent_memories/checkpoints"
        Path(self.checkpoint_dir).mkdir(parents=True, exist_ok=True)
    
    async def save_checkpoint(self, progress: TaskProgress) -> None:
        """Save checkpoint to memory"""
        try:
            from agent.tools.memory import MemoryTool
            
            # Use agent-specific memory
            memory = MemoryTool(memory_base_dir=f"{_agent_data_dir}/agent_memories/{self.agent_type}")
            
            checkpoint_data = progress.to_dict()
            checkpoint_data['saved_at'] = datetime.now().isoformat()
            
            # Save to memory
            await memory(
                command="create",
                path=f"/memories/checkpoint_{progress.task_id}.json",
                file_text=json.dumps(checkpoint_data, indent=2)
            )
            
            logger.info(
                f"[{self.agent_type}] Checkpoint saved: {progress.completed_items}/{progress.total_items} "
                f"({progress.get_progress_percent():.1f}%)",
                extra={'agent_type': self.agent_type}
            )
        
        except Exception as e:
            logger.error(f"Failed to save checkpoint: {e}", extra={'agent_type': self.agent_type})
            # Don't fail the task if checkpoint fails
    
    async def load_checkpoint(self, task_id: str) -> Optional[TaskProgress]:
        """Load checkpoint from memory"""
        try:
            from agent.tools.memory import MemoryTool
            
            memory = MemoryTool(memory_base_dir=f"{_agent_data_dir}/agent_memories/{self.agent_type}")
            
            result = await memory(
                command="view",
                path=f"/memories/checkpoint_{task_id}.json"
            )
            
            # Parse checkpoint data from memory tool output
            # Memory tool returns: "File: /memories/checkpoint_X.json\n{json content}"
            output_text = result.output
            
            # Find the JSON content (after the first line)
            if '\n' in output_text:
                json_content = output_text.split('\n', 1)[1]
            else:
                json_content = output_text
            
            checkpoint_data = json.loads(json_content)
            progress = TaskProgress.from_dict(checkpoint_data)
            
            logger.info(
                f"[{self.agent_type}] Loaded checkpoint: {progress.completed_items}/{progress.total_items} completed",
                extra={'agent_type': self.agent_type}
            )
            
            return progress
        
        except Exception as e:
            logger.info(
                f"No checkpoint found for task {task_id}, starting fresh",
                extra={'agent_type': self.agent_type}
            )
            return None
    
    async def delete_checkpoint(self, task_id: str) -> None:
        """Delete checkpoint after task completion"""
        try:
            from agent.tools.memory import MemoryTool
            
            memory = MemoryTool(memory_base_dir=f"{_agent_data_dir}/agent_memories/{self.agent_type}")
            
            await memory(
                command="delete",
                path=f"/memories/checkpoint_{task_id}.json"
            )
            
            logger.info(f"Checkpoint deleted for task {task_id}", extra={'agent_type': self.agent_type})
        
        except Exception as e:
            logger.warning(f"Could not delete checkpoint: {e}", extra={'agent_type': self.agent_type})


class ProgressTracker:
    """Track and log progress for long-running tasks"""
    
    def __init__(self, task_id: str, agent_type: str, total_items: int, log_interval: int = 50):
        self.task_id = task_id
        self.agent_type = agent_type
        self.total_items = total_items
        self.log_interval = log_interval
        self.progress = TaskProgress(
            task_id=task_id,
            agent_type=agent_type,
            instruction="",
            total_items=total_items
        )
    
    def record_success(self):
        """Record successful item completion"""
        self.progress.completed_items += 1
        self.progress.successful_items += 1
        self.progress.last_updated = time.time()
        
        # Log every N items
        if self.progress.completed_items % self.log_interval == 0:
            self._log_progress()
    
    def record_failure(self, error: str):
        """Record failed item (keeps only the last 100 errors)."""
        self.progress.completed_items += 1
        self.progress.failed_items += 1
        self.progress.errors.append({
            'item': self.progress.completed_items,
            'error': error,
            'timestamp': datetime.now().isoformat()
        })
        # Cap errors list to prevent unbounded growth in long-running tasks
        if len(self.progress.errors) > 100:
            self.progress.errors = self.progress.errors[-100:]
        self.progress.last_updated = time.time()
    
    def _log_progress(self):
        """Log detailed progress"""
        percent = self.progress.get_progress_percent()
        success_rate = self.progress.get_success_rate()
        eta_hours = self.progress.get_eta_hours()
        
        elapsed_hours = (time.time() - self.progress.start_time) / 3600
        
        logger.info(
            f"[{self.agent_type}] Progress: {self.progress.completed_items}/{self.total_items} "
            f"({percent:.1f}%) | Success: {success_rate*100:.1f}% | "
            f"Elapsed: {elapsed_hours:.1f}h | ETA: {eta_hours:.1f}h",
            extra={'agent_type': self.agent_type}
        )
    
    def get_progress(self) -> TaskProgress:
        """Get current progress"""
        return self.progress
    
    def is_complete(self) -> bool:
        """Check if task is complete"""
        return self.progress.completed_items >= self.total_items


class HeartbeatMonitor:
    """Monitor agent health during long-running tasks"""
    
    def __init__(self, agent_type: str, interval: int = 300):
        self.agent_type = agent_type
        self.interval = interval  # 5 minutes default
        self.start_time = time.time()
        self.last_activity = time.time()
        self.heartbeat_count = 0
    
    async def start(self):
        """Start heartbeat monitoring"""
        while True:
            await asyncio.sleep(self.interval)
            self.heartbeat_count += 1
            
            uptime_hours = (time.time() - self.start_time) / 3600
            idle_seconds = time.time() - self.last_activity
            
            logger.info(
                f"[{self.agent_type}] ❤️ Heartbeat #{self.heartbeat_count} | "
                f"Uptime: {uptime_hours:.1f}h | Idle: {idle_seconds:.0f}s",
                extra={'agent_type': self.agent_type}
            )
            
            # Save heartbeat to memory (optional)
            try:
                from agent.tools.memory import MemoryTool
                memory = MemoryTool(memory_base_dir=f"{_agent_data_dir}/agent_memories/{self.agent_type}")
                
                await memory(
                    command="create",
                    path="/memories/heartbeat.json",
                    file_text=json.dumps({
                        'heartbeat_count': self.heartbeat_count,
                        'uptime_hours': uptime_hours,
                        'last_heartbeat': datetime.now().isoformat()
                    }, indent=2)
                )
            except Exception as e:
                # Don't fail if heartbeat save fails, but log it
                logger.debug("Failed to save heartbeat: %s", e)
    
    def record_activity(self):
        """Record agent activity"""
        self.last_activity = time.time()


class LongRunningTaskExecutor:
    """
    Execute long-running tasks with checkpoint/resume capability.
    
    Features:
    - Automatic checkpointing every N items or M minutes
    - Resume from last checkpoint on crash
    - Progress tracking with ETA
    - Heartbeat monitoring
    - Error recovery
    """
    
    def __init__(
        self,
        task_id: str,
        agent_type: str,
        instruction_template: str,
        checkpoint_interval: int = 3600,  # 1 hour
        checkpoint_items: int = 50  # Every 50 items
    ):
        self.task_id = task_id
        self.agent_type = agent_type
        self.instruction_template = instruction_template
        self.checkpoint_interval = checkpoint_interval
        self.checkpoint_items = checkpoint_items
        
        self.checkpoint_manager = CheckpointManager(agent_type)
        self.heartbeat_monitor = HeartbeatMonitor(agent_type)
    
    async def execute(
        self,
        total_items: int,
        agent_config: Any,
        api_key: str,
        process_func: Any = None
    ) -> Dict[str, Any]:
        """
        Execute long-running task with checkpoint support.
        
        Args:
            total_items: Total number of items to process
            agent_config: Agent configuration
            api_key: API key
            process_func: Optional custom processing function
        
        Returns:
            Summary of task execution
        """
        
        # Start heartbeat monitoring in background
        heartbeat_task = asyncio.create_task(self.heartbeat_monitor.start())
        
        try:
            # Load checkpoint if exists
            progress = await self.checkpoint_manager.load_checkpoint(self.task_id)
            
            if progress:
                logger.info(
                    f"[{self.agent_type}] Resuming from checkpoint: "
                    f"{progress.completed_items}/{total_items} items completed",
                    extra={'agent_type': self.agent_type}
                )
                tracker = ProgressTracker(self.task_id, self.agent_type, total_items)
                tracker.progress = progress
            else:
                logger.info(
                    f"[{self.agent_type}] Starting new task: {total_items} items to process",
                    extra={'agent_type': self.agent_type}
                )
                tracker = ProgressTracker(self.task_id, self.agent_type, total_items)
            
            start_from = progress.completed_items if progress else 0
            last_checkpoint_time = time.time()
            
            # Main processing loop
            for item_num in range(start_from, total_items):
                self.heartbeat_monitor.record_activity()
                
                try:
                    # Process item
                    if process_func:
                        result = await process_func(item_num)
                    else:
                        result = await self._default_process_item(
                            item_num, agent_config, api_key
                        )
                    
                    # Record success
                    tracker.record_success()
                
                except Exception as e:
                    logger.error(
                        f"[{self.agent_type}] Error processing item {item_num}: {e}",
                        extra={'agent_type': self.agent_type}
                    )
                    tracker.record_failure(str(e))
                
                # Checkpoint based on time or item count
                time_since_checkpoint = time.time() - last_checkpoint_time
                items_since_checkpoint = tracker.progress.completed_items - start_from
                
                should_checkpoint = (
                    time_since_checkpoint >= self.checkpoint_interval or
                    items_since_checkpoint % self.checkpoint_items == 0
                )
                
                if should_checkpoint and tracker.progress.completed_items > start_from:
                    await self.checkpoint_manager.save_checkpoint(tracker.get_progress())
                    last_checkpoint_time = time.time()
            
            # Final checkpoint
            tracker.progress.metadata['finished'] = True
            tracker.progress.metadata['finished_at'] = datetime.now().isoformat()
            await self.checkpoint_manager.save_checkpoint(tracker.get_progress())
            
            # Generate summary
            summary = self._generate_summary(tracker.get_progress())
            
            logger.info(
                f"[{self.agent_type}] Task complete! {tracker.progress.successful_items}/"
                f"{tracker.progress.completed_items} successful",
                extra={'agent_type': self.agent_type}
            )
            
            # Clean up checkpoint
            await self.checkpoint_manager.delete_checkpoint(self.task_id)
            
            return summary
        
        finally:
            # Stop heartbeat
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except asyncio.CancelledError:
                pass
    
    async def _default_process_item(
        self,
        item_num: int,
        agent_config: Any,
        api_key: str
    ) -> Any:
        """Default item processing using run_agent"""
        from main import run_agent
        
        # Create instruction for this specific item
        instruction = self.instruction_template.format(item_num=item_num)
        
        result = await run_agent(
            instruction=instruction,
            agent_config=agent_config,
            api_key=api_key,
            agent_type=self.agent_type
        )
        
        return result
    
    def _generate_summary(self, progress: TaskProgress) -> Dict[str, Any]:
        """Generate task summary"""
        duration_hours = (time.time() - progress.start_time) / 3600
        
        return {
            'task_id': progress.task_id,
            'agent_type': progress.agent_type,
            'duration_hours': duration_hours,
            'total_items': progress.total_items,
            'completed_items': progress.completed_items,
            'successful_items': progress.successful_items,
            'failed_items': progress.failed_items,
            'success_rate': progress.get_success_rate(),
            'items_per_hour': progress.completed_items / duration_hours if duration_hours > 0 else 0,
            'errors': progress.errors[-10:] if progress.errors else [],  # Last 10 errors
            'metadata': progress.metadata
        }


class RateLimitHandler:
    """Handle API rate limits gracefully"""
    
    def __init__(self, max_retries: int = 10):
        self.max_retries = max_retries
        self.rate_limit_count = 0
    
    async def execute_with_rate_limit_handling(self, func, *args, **kwargs):
        """Execute function with rate limit handling"""
        from anthropic import RateLimitError
        
        for attempt in range(self.max_retries):
            try:
                return await func(*args, **kwargs)
            
            except RateLimitError as e:
                self.rate_limit_count += 1
                
                if attempt == self.max_retries - 1:
                    raise
                
                # Get retry-after from headers or use default
                retry_after = 60  # Default 60 seconds
                if hasattr(e, 'response') and e.response:
                    retry_after = int(e.response.headers.get('retry-after', 60))
                
                logger.warning(
                    f"Rate limited (attempt {attempt + 1}/{self.max_retries}). "
                    f"Waiting {retry_after}s..."
                )
                
                await asyncio.sleep(retry_after)
            
            except Exception as e:
                # For other errors, use exponential backoff
                if attempt == self.max_retries - 1:
                    raise
                
                wait_time = min(60 * (2 ** attempt), 600)  # Max 10 minutes
                logger.warning(f"Error (attempt {attempt + 1}), retrying in {wait_time}s: {e}")
                await asyncio.sleep(wait_time)
        
        raise Exception(f"Failed after {self.max_retries} attempts")


# Convenience function for simple use cases
async def run_long_task(
    task_id: str,
    agent_type: str,
    instruction_template: str,
    total_items: int,
    agent_config: Any,
    api_key: str,
    checkpoint_every_n_items: int = 50
) -> Dict[str, Any]:
    """
    Convenience function to run a long task with checkpointing.
    
    Args:
        task_id: Unique identifier for this task
        agent_type: Type of agent to use
        instruction_template: Template with {item_num} placeholder
        total_items: Total number of items to process
        agent_config: Agent configuration
        api_key: API key
        checkpoint_every_n_items: Checkpoint frequency
    
    Returns:
        Task summary dictionary
    
    Example:
        summary = await run_long_task(
            task_id="close_1000_tickets",
            agent_type="AUTO_CLOSE",
            instruction_template="Close ticket number {item_num}",
            total_items=1000,
            agent_config=AGENT_CONFIGS['AUTO_CLOSE'],
            api_key=api_key,
            checkpoint_every_n_items=50
        )
    """
    
    executor = LongRunningTaskExecutor(
        task_id=task_id,
        agent_type=agent_type,
        instruction_template=instruction_template,
        checkpoint_interval=3600,  # 1 hour
        checkpoint_items=checkpoint_every_n_items
    )
    
    return await executor.execute(
        total_items=total_items,
        agent_config=agent_config,
        api_key=api_key
    ) 