"""
Configuration management for StateSet Computer Use Agent.

This module provides centralized configuration with:
- YAML-based configuration files
- Environment-specific overrides (dev, prod)
- Environment variable substitution
- Type-safe configuration access
- Documented default values (previously "magic numbers")

All timing and threshold values are documented with rationale based on:
- Production benchmarks
- Anthropic's context engineering research
- Testing across different environments

Usage:
    from agent.config import get_config

    config = get_config()
    timeout = config.tools.bash["timeout"]
"""

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
import yaml


@dataclass
class AgentSettings:
    """Agent-specific settings."""

    workspace_path: str = "/tmp/stateset-workspace"
    """Base workspace directory for agent operations."""

    data_dir: str = field(default_factory=lambda: os.environ.get("AGENT_DATA_DIR", "/tmp"))
    """Root directory for agent runtime data (memories, checkpoints, metrics, prompts).
    Set AGENT_DATA_DIR to override. Sub-paths: agent_memories/, agent_checkpoints/,
    agent_metrics/, agent_system_prompts/."""

    screenshot_retention: int = 5
    """Number of screenshots to retain for context.
    Rationale: Balances visual history with context window efficiency."""

    checkpoint_enabled: bool = True
    """Enable state checkpointing for recovery."""

    checkpoint_interval: int = 300
    """Checkpoint interval in seconds.
    Rationale: 5 minutes balances recovery granularity with I/O overhead."""


@dataclass
class ModelSettings:
    """Model configuration settings."""

    provider: str = "anthropic"
    """API provider (anthropic, bedrock, vertex)."""

    name: str = "claude-opus-4-6-20260131"
    """Model name/ID to use."""

    max_tokens: int = 4096
    """Maximum tokens for model response.
    Rationale: 4096 is sufficient for most tool-use responses."""

    thinking_budget: Optional[int] = None
    """Token budget for extended thinking (None = disabled)."""

    temperature: float = 1.0
    """Model temperature (0-1). 1.0 recommended for tool use."""

    effort: str = "high"
    """Effort level for Opus 4.6 (low, medium, high)."""


@dataclass
class ContextSettings:
    """
    Context management settings based on Anthropic's research.

    Reference: https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents

    Key findings:
    - Attention degrades exponentially with context size (n² scaling)
    - Optimal: <50k tokens (EXCELLENT quality)
    - Degraded: 50k-100k tokens (GOOD/DEGRADED quality)
    - Critical: >150k tokens (CRITICAL quality)
    """

    enable_management: bool = True
    """Enable automatic context management."""

    attention_budget: str = "EXCELLENT"
    """Target attention quality (EXCELLENT, GOOD, DEGRADED, CRITICAL)."""

    optimal_token_budget: int = 50000
    """Target token budget for optimal attention quality.
    Rationale: Research shows attention is excellent under 50k."""

    degradation_threshold: int = 100000
    """Threshold where attention quality starts degrading.
    Rationale: Research shows degraded quality above 100k tokens."""

    warning_threshold: int = 150000
    """Threshold for critical attention warnings.
    Rationale: Research shows critical quality above 150k tokens."""

    max_context_window: int = 200000
    """Maximum context window (Claude's limit)."""

    # Compaction settings
    compaction_trigger_tokens: int = 100000
    """Token count that triggers automatic compaction.
    Rationale: Trigger before critical threshold to prevent quality loss."""

    compaction_keep_tool_uses: int = 10
    """Recent tool uses to keep during compaction."""

    compaction_clear_tokens: int = 30000
    """Minimum tokens to clear during compaction.
    Rationale: Make compaction meaningful to avoid frequent small compactions."""

    # Message compression
    max_message_history: int = 20
    """Maximum messages to keep in history."""

    compress_after_messages: int = 10
    """Recent messages to keep uncompressed."""

    max_text_block_chars: int = 500
    """Max chars for text blocks in compressed messages."""

    max_assistant_text_chars: int = 800
    """Max chars for assistant responses.
    Rationale: Claude can be verbose; truncating saves tokens."""

    max_tool_output_chars: int = 1500
    """Max chars for tool output.
    Rationale: Key info is usually in first/last portions."""

    max_error_chars: int = 500
    """Max chars for error messages."""


@dataclass
class ToolSettings:
    """
    Tools configuration settings.

    Timing values derived from production benchmarks:
    - bash_timeout: 60s handles most operations
    - bash_output_delay: 0.05s for terminal output to settle
    - typing_delay_ms: 8ms reliable across GUI frameworks
    """

    version: str = "computer_use_20251124"
    """Tool version to use."""

    enable_tool_search: bool = False
    """Enable Anthropic tool search beta."""

    tool_search_variant: str = "regex"
    """Tool search variant (regex or bm25)."""

    deferred_tools: list = field(default_factory=list)
    """Tools to defer loading until needed."""

    computer: Dict[str, Any] = field(default_factory=lambda: {
        "typing_delay_ms": 8,  # Benchmarked across GTK, Qt, Electron
        "click_delay_ms": 100,  # Time for UI to respond
        "screenshot_quality": 85,  # JPEG quality (1-100)
        "screenshot_group_size": 5,  # Screenshots to batch
    })
    """Computer tool settings."""

    bash: Dict[str, Any] = field(default_factory=lambda: {
        "timeout": 60.0,  # Seconds; handles most operations
        "output_delay": 0.05,  # Seconds; buffer flush time
        "max_output_chars": 50000,  # Prevent memory bloat
    })
    """Bash tool settings."""

    memory: Dict[str, Any] = field(default_factory=lambda: {
        "max_file_size": 10000,  # Characters per file
        "max_files": 100,  # Files per agent
        "base_path": "/tmp/agent_memories",
    })
    """Memory tool settings."""


@dataclass
class WebSettings:
    """Web tools settings."""

    enable_search: bool = True
    """Enable web search tool."""

    search_max_uses: int = 5
    """Maximum web searches per request."""

    enable_fetch: bool = True
    """Enable web fetch tool."""

    fetch_max_uses: int = 10
    """Maximum web fetches per request."""

    fetch_max_content_tokens: int = 100000
    """Max tokens per fetched document."""


@dataclass
class PerformanceSettings:
    """Performance optimization settings."""

    enable_parallel_execution: bool = True
    """Enable parallel tool execution."""

    max_parallel_tools: int = 5
    """Maximum tools to execute in parallel.
    Rationale: 5 balances parallelism with resource usage."""

    parallel_timeout_multiplier: float = 1.5
    """Timeout multiplier for parallel execution."""

    enable_prompt_caching: bool = True
    """Enable prompt caching for cost reduction."""

    token_efficient_tools: bool = True
    """Use token-efficient tool representations."""

    # Performance targets (based on production metrics)
    target_tokens_per_task: int = 7500
    """Target token usage per task."""

    target_cost_per_task: float = 0.11
    """Target cost per task in USD."""

    target_task_duration: float = 30.0
    """Target task duration in seconds."""

    # Screenshot optimization
    screenshot_cache_size: int = 5
    """Screenshot hashes to cache for deduplication."""

    screenshot_hash_length: int = 1000
    """Base64 chars to hash for uniqueness detection."""


@dataclass
class ObservabilitySettings:
    """Observability and monitoring settings."""

    enable_tracing: bool = False
    """Enable distributed tracing."""

    enable_metrics: bool = False
    """Enable metrics collection."""

    metrics_port: int = 9090
    """Prometheus metrics port."""

    log_level: str = "INFO"
    """Logging level."""

    log_format: str = "json"
    """Log format (json, human, compact)."""

    enable_request_tracing: bool = True
    """Enable request ID propagation."""


@dataclass
class SecuritySettings:
    """Security configuration."""

    enable_sandbox: bool = False
    """Enable sandboxed execution."""

    validate_tool_inputs: bool = True
    """Validate tool inputs before execution."""

    max_file_size: int = 10485760
    """Maximum file size in bytes (10MB)."""

    allowed_commands: list = field(default_factory=list)
    """Whitelist of allowed shell commands (empty = all)."""

    enable_prompt_injection_protection: bool = True
    """Scan memory files for injection patterns."""


@dataclass
class BillingSettings:
    """Billing and usage tracking."""

    enable_stripe: bool = False
    """Enable Stripe billing integration."""

    stripe_api_key: Optional[str] = None
    """Stripe API key."""

    meter_event_name: str = "agent_execution"
    """Stripe meter event name."""


@dataclass
class BudgetSettings:
    """
    Budget limits and cost tracking.

    Default budgets based on typical agent usage:
    - daily: $100 allows ~900 tasks at $0.11 average
    - per_task: $5 catches runaway tasks early
    - monthly: $2000 reasonable for production
    """

    daily_budget: float = 100.0
    """Daily cost limit in USD."""

    per_task_budget: float = 5.0
    """Per-task cost limit in USD."""

    monthly_budget: float = 2000.0
    """Monthly cost limit in USD."""

    warning_percent: float = 80.0
    """Budget percentage that triggers warnings."""

    # Pricing (Claude Opus 4.6)
    input_token_price: float = 0.000003
    """Price per input token ($3/1M)."""

    output_token_price: float = 0.000015
    """Price per output token ($15/1M)."""

    cache_write_price: float = 0.00000375
    """Price per cache write token ($3.75/1M)."""

    cache_read_price: float = 0.0000003
    """Price per cache read token ($0.30/1M)."""

    web_search_price: float = 0.01
    """Price per web search ($10/1K)."""

    code_execution_price: float = 0.05
    """Price per hour of code execution."""


@dataclass
class HealthSettings:
    """
    Health check and circuit breaker settings.

    Thresholds based on production monitoring.
    """

    memory_warning_percent: float = 80.0
    """Memory usage warning threshold."""

    memory_critical_percent: float = 90.0
    """Memory usage critical threshold."""

    disk_warning_percent: float = 85.0
    """Disk usage warning threshold."""

    disk_critical_percent: float = 95.0
    """Disk usage critical threshold."""

    circuit_breaker_failure_threshold: int = 5
    """Failures before opening circuit."""

    circuit_breaker_timeout: float = 60.0
    """Seconds before attempting recovery."""

    circuit_breaker_success_threshold: int = 2
    """Successes needed to close circuit."""

    health_check_interval: float = 30.0
    """Seconds between health checks."""


@dataclass
class APISettings:
    """API interaction settings."""

    max_retries: int = 3
    """Maximum retry attempts.
    Rationale: 3 retries with exponential backoff handles most transient failures."""

    retry_base_delay: float = 1.0
    """Base delay for exponential backoff (seconds)."""

    retry_max_delay: float = 60.0
    """Maximum delay between retries (seconds)."""

    api_timeout: float = 120.0
    """API call timeout (seconds).
    Rationale: Complex multi-tool responses need time."""

    http_timeout: float = 10.0
    """Simple HTTP request timeout (seconds)."""

    system_prompt_cache_ttl: int = 300
    """System prompt cache TTL (seconds)."""


class ConfigurationError(Exception):
    """Raised when configuration validation fails."""
    pass


@dataclass
class Config:
    """Complete configuration for the agent."""
    agent: AgentSettings = field(default_factory=AgentSettings)
    model: ModelSettings = field(default_factory=ModelSettings)
    context: ContextSettings = field(default_factory=ContextSettings)
    tools: ToolSettings = field(default_factory=ToolSettings)
    web: WebSettings = field(default_factory=WebSettings)
    performance: PerformanceSettings = field(default_factory=PerformanceSettings)
    observability: ObservabilitySettings = field(default_factory=ObservabilitySettings)
    security: SecuritySettings = field(default_factory=SecuritySettings)
    billing: BillingSettings = field(default_factory=BillingSettings)
    budget: BudgetSettings = field(default_factory=BudgetSettings)
    health: HealthSettings = field(default_factory=HealthSettings)
    api: APISettings = field(default_factory=APISettings)

    def __post_init__(self):
        """Validate configuration after initialization."""
        errors = []

        # Model validation
        valid_providers = {"anthropic", "bedrock", "vertex"}
        if self.model.provider not in valid_providers:
            errors.append(f"Invalid model provider '{self.model.provider}'. Must be one of: {valid_providers}")

        if self.model.max_tokens < 1 or self.model.max_tokens > 32768:
            errors.append(f"model.max_tokens must be between 1 and 32768, got {self.model.max_tokens}")

        if self.model.temperature < 0 or self.model.temperature > 2:
            errors.append(f"model.temperature must be between 0 and 2, got {self.model.temperature}")

        valid_efforts = {"low", "medium", "high"}
        if self.model.effort not in valid_efforts:
            errors.append(f"Invalid model effort '{self.model.effort}'. Must be one of: {valid_efforts}")

        # Context validation
        valid_attention_budgets = {"EXCELLENT", "GOOD", "DEGRADED", "CRITICAL"}
        if self.context.attention_budget not in valid_attention_budgets:
            errors.append(f"Invalid attention_budget '{self.context.attention_budget}'. Must be one of: {valid_attention_budgets}")

        if self.context.optimal_token_budget >= self.context.degradation_threshold:
            errors.append("context.optimal_token_budget must be less than context.degradation_threshold")

        if self.context.degradation_threshold >= self.context.warning_threshold:
            errors.append("context.degradation_threshold must be less than context.warning_threshold")

        if self.context.warning_threshold >= self.context.max_context_window:
            errors.append("context.warning_threshold must be less than context.max_context_window")

        # Tool validation
        valid_tool_versions = {"computer_use_20241022", "computer_use_20250124", "computer_use_20251124"}
        if self.tools.version not in valid_tool_versions:
            errors.append(f"Invalid tools.version '{self.tools.version}'. Must be one of: {valid_tool_versions}")

        if self.tools.enable_tool_search and self.tools.tool_search_variant not in {"regex", "bm25"}:
            errors.append(f"Invalid tool_search_variant '{self.tools.tool_search_variant}'. Must be 'regex' or 'bm25'")

        # Performance validation
        if self.performance.max_parallel_tools < 1 or self.performance.max_parallel_tools > 20:
            errors.append(f"performance.max_parallel_tools must be between 1 and 20, got {self.performance.max_parallel_tools}")

        if self.performance.parallel_timeout_multiplier < 1.0:
            errors.append(f"performance.parallel_timeout_multiplier must be >= 1.0, got {self.performance.parallel_timeout_multiplier}")

        # Budget validation
        if self.budget.daily_budget <= 0:
            errors.append(f"budget.daily_budget must be positive, got {self.budget.daily_budget}")

        if self.budget.per_task_budget <= 0:
            errors.append(f"budget.per_task_budget must be positive, got {self.budget.per_task_budget}")

        if self.budget.per_task_budget > self.budget.daily_budget:
            errors.append("budget.per_task_budget should not exceed budget.daily_budget")

        if self.budget.warning_percent < 0 or self.budget.warning_percent > 100:
            errors.append(f"budget.warning_percent must be between 0 and 100, got {self.budget.warning_percent}")

        # Health validation
        if self.health.memory_warning_percent >= self.health.memory_critical_percent:
            errors.append("health.memory_warning_percent must be less than health.memory_critical_percent")

        if self.health.disk_warning_percent >= self.health.disk_critical_percent:
            errors.append("health.disk_warning_percent must be less than health.disk_critical_percent")

        if self.health.circuit_breaker_failure_threshold < 1:
            errors.append(f"health.circuit_breaker_failure_threshold must be >= 1, got {self.health.circuit_breaker_failure_threshold}")

        # API validation
        if self.api.max_retries < 0:
            errors.append(f"api.max_retries must be >= 0, got {self.api.max_retries}")

        if self.api.retry_base_delay <= 0:
            errors.append(f"api.retry_base_delay must be positive, got {self.api.retry_base_delay}")

        if self.api.retry_max_delay < self.api.retry_base_delay:
            errors.append("api.retry_max_delay must be >= api.retry_base_delay")

        # Observability validation
        valid_log_formats = {"json", "human", "compact"}
        if self.observability.log_format not in valid_log_formats:
            errors.append(f"Invalid log_format '{self.observability.log_format}'. Must be one of: {valid_log_formats}")

        valid_log_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if self.observability.log_level.upper() not in valid_log_levels:
            errors.append(f"Invalid log_level '{self.observability.log_level}'. Must be one of: {valid_log_levels}")

        # Raise all validation errors at once
        if errors:
            error_msg = "Configuration validation failed:\n" + "\n".join(f"  - {e}" for e in errors)
            raise ConfigurationError(error_msg)


class ConfigLoader:
    """Loads and merges configuration from multiple sources."""

    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)

    def load(self, environment: Optional[str] = None) -> Config:
        """
        Load configuration for the specified environment.

        Args:
            environment: Environment name (development, production, etc.)
                        If None, uses AGENT_ENV environment variable or defaults to development.

        Returns:
            Config: Merged configuration object
        """
        # Determine environment
        env = environment or os.getenv("AGENT_ENV", "development")

        # Load base config
        base_config = self._load_yaml("base.yaml")

        # Load environment-specific config
        env_config = {}
        env_file = self.config_dir / f"{env}.yaml"
        if env_file.exists():
            env_config = self._load_yaml(f"{env}.yaml")

        # Merge configurations (env overrides base)
        merged = self._deep_merge(base_config, env_config)

        # Substitute environment variables
        merged = self._substitute_env_vars(merged)

        # Convert to Config object
        return self._dict_to_config(merged)

    def _load_yaml(self, filename: str) -> Dict[str, Any]:
        """Load a YAML configuration file."""
        file_path = self.config_dir / filename
        if not file_path.exists():
            return {}

        with open(file_path, 'r') as f:
            return yaml.safe_load(f) or {}

    def _deep_merge(self, base: Dict, override: Dict) -> Dict:
        """Deep merge two dictionaries, with override taking precedence."""
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value

        return result

    def _substitute_env_vars(self, config: Any) -> Any:
        """Recursively substitute environment variables in configuration."""
        if isinstance(config, dict):
            return {k: self._substitute_env_vars(v) for k, v in config.items()}
        elif isinstance(config, list):
            return [self._substitute_env_vars(item) for item in config]
        elif isinstance(config, str):
            # Replace ${VAR_NAME} with environment variable value
            pattern = r'\$\{([^}]+)\}'
            matches = re.findall(pattern, config)
            for var_name in matches:
                value = os.getenv(var_name, f"${{{var_name}}}")
                config = config.replace(f"${{{var_name}}}", value)
            return config
        else:
            return config

    def _dict_to_config(self, data: Dict[str, Any]) -> Config:
        """Convert dictionary to Config object."""
        return Config(
            agent=AgentSettings(**data.get('agent', {})),
            model=ModelSettings(**data.get('model', {})),
            context=ContextSettings(**data.get('context', {})),
            tools=ToolSettings(
                version=data.get('tools', {}).get('version', 'computer_use_20251124'),
                enable_tool_search=data.get('tools', {}).get('enable_tool_search', False),
                tool_search_variant=data.get('tools', {}).get('tool_search_variant', 'regex'),
                deferred_tools=data.get('tools', {}).get('deferred_tools', []),
                computer=data.get('tools', {}).get('computer', {}),
                bash=data.get('tools', {}).get('bash', {}),
                memory=data.get('tools', {}).get('memory', {}),
            ),
            web=WebSettings(**data.get('web', {})),
            performance=PerformanceSettings(**data.get('performance', {})),
            observability=ObservabilitySettings(**data.get('observability', {})),
            security=SecuritySettings(**data.get('security', {})),
            billing=BillingSettings(**data.get('billing', {})),
        )


# Global config instance
_config_loader = ConfigLoader()
_config: Optional[Config] = None


def get_config(environment: Optional[str] = None, reload: bool = False) -> Config:
    """
    Get the application configuration.

    Args:
        environment: Environment name (development, production, etc.)
        reload: Force reload configuration from files

    Returns:
        Config: Configuration object
    """
    global _config

    if _config is None or reload:
        _config = _config_loader.load(environment)

    return _config


def reload_config(environment: Optional[str] = None) -> Config:
    """Reload configuration from files."""
    return get_config(environment, reload=True)


# Convenience functions for common config access
def get_model_name() -> str:
    """Get configured model name."""
    return get_config().model.name


def get_tool_version() -> str:
    """Get configured tool version."""
    return get_config().tools.version


def is_tracing_enabled() -> bool:
    """Check if distributed tracing is enabled."""
    return get_config().observability.enable_tracing


def is_metrics_enabled() -> bool:
    """Check if metrics collection is enabled."""
    return get_config().observability.enable_metrics


def get_workspace_path() -> str:
    """Get workspace path."""
    return get_config().agent.workspace_path
