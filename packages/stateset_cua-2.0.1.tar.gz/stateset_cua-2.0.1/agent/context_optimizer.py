"""
Context Optimizer for StateSet Computer Use Agent.
Based on Anthropic's context engineering research.

Key Principles:
1. Attention Budget - Monitor token usage and prevent context rot
2. Just-in-Time Retrieval - Use tools to analyze without loading full content
3. Smart Compaction - Summarize aggressively, keep architectural decisions
4. Structured Notes - Maintain persistent knowledge outside context
5. Sub-Agent Compression - Return summaries instead of raw exploration

Research: https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents
"""

import logging
import threading
from enum import Enum
from typing import Dict, Any, List, Optional, Sequence
from dataclasses import dataclass
import json
import base64
from io import BytesIO

logger = logging.getLogger(__name__)

# Import imagehash for proper screenshot deduplication
try:
    import imagehash
    from PIL import Image
    IMAGEHASH_AVAILABLE = True
except ImportError:
    logger.warning("imagehash or PIL not available - screenshot deduplication will use fallback method")
    IMAGEHASH_AVAILABLE = False


class AttentionQuality(Enum):
    """Attention quality levels based on context size."""

    EXCELLENT = "excellent"
    GOOD = "good"
    DEGRADED = "degraded"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class ContextBudget:
    """Track context window usage and attention budget"""
    
    # Token budget thresholds (mirrors agent.config.ContextSettings defaults)
    MAX_CONTEXT_TOKENS = 200_000
    OPTIMAL_THRESHOLD = 50_000
    ATTENTION_DEGRADATION_THRESHOLD = 100_000
    WARNING_THRESHOLD = 150_000
    CRITICAL_THRESHOLD = 200_000

    # Cost tracking — sourced from agent.config.BudgetSettings at class init.
    # Expressed as $/1K tokens for backward compat with existing callers.
    COST_PER_1K_INPUT = 0.003  # default; overridden by _sync_pricing()
    COST_PER_1K_OUTPUT = 0.015
    COST_PER_1K_CACHED_INPUT = 0.0003
    
    current_tokens: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0

    @property
    def max_tokens(self) -> int:
        return self.MAX_CONTEXT_TOKENS

    @property
    def optimal_threshold(self) -> int:
        return self.OPTIMAL_THRESHOLD

    @property
    def attention_degradation_threshold(self) -> int:
        return self.ATTENTION_DEGRADATION_THRESHOLD

    @property
    def warning_threshold(self) -> int:
        return self.WARNING_THRESHOLD

    @property
    def critical_threshold(self) -> int:
        return self.CRITICAL_THRESHOLD

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """Roughly estimate token count (~4 chars/token)."""

        if not text:
            return 0
        return max(1, len(text) // 4)

    def count_tokens(self, messages: Sequence[Dict[str, Any]]) -> int:
        """Estimate tokens across a list of Anthropic-style message dicts."""

        total_chars = 0
        for message in messages:
            content = message.get("content", "")
            if isinstance(content, str):
                total_chars += len(content)
                continue
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        block_type = block.get("type")
                        if block_type == "text" and isinstance(block.get("text"), str):
                            total_chars += len(block["text"])
                            continue
                        if block_type == "tool_use":
                            total_chars += len(str(block.get("name", "")))
                            total_chars += len(json.dumps(block.get("input", {}), sort_keys=True, default=str))
                            continue
                        if block_type == "tool_result":
                            total_chars += len(str(block.get("content", "")))
                            continue
                        total_chars += len(json.dumps(block, sort_keys=True, default=str))
                    else:
                        total_chars += len(str(block))
                continue
            total_chars += len(str(content))

        if total_chars <= 0:
            return 0
        return max(1, total_chars // 4)

    def get_attention_quality(self, tokens: int) -> AttentionQuality:
        """Return the attention quality enum for a token count."""

        if tokens < self.OPTIMAL_THRESHOLD:
            return AttentionQuality.EXCELLENT
        if tokens < self.ATTENTION_DEGRADATION_THRESHOLD:
            return AttentionQuality.GOOD
        if tokens < self.WARNING_THRESHOLD:
            return AttentionQuality.DEGRADED
        if tokens < self.CRITICAL_THRESHOLD:
            return AttentionQuality.WARNING
        return AttentionQuality.CRITICAL
    
    @property
    def utilization(self) -> float:
        """Calculate context utilization as percentage"""
        return (self.current_tokens / self.MAX_CONTEXT_TOKENS) * 100
    
    @property
    def attention_quality(self) -> str:
        """Estimate attention quality string for status reporting."""

        return self.get_attention_quality(self.current_tokens).name
    
    @property
    def estimated_cost(self) -> float:
        """Estimate current request cost"""
        fresh_input_tokens = max(0, self.input_tokens - self.cached_tokens)
        input_cost = (fresh_input_tokens / 1000) * self.COST_PER_1K_INPUT
        cached_cost = (self.cached_tokens / 1000) * self.COST_PER_1K_CACHED_INPUT
        output_cost = (self.output_tokens / 1000) * self.COST_PER_1K_OUTPUT
        return input_cost + cached_cost + output_cost
    
    def should_compact(self) -> bool:
        """Determine if aggressive compaction is needed - trigger earlier"""
        return self.current_tokens > self.ATTENTION_DEGRADATION_THRESHOLD
    
    def get_status(self) -> Dict[str, Any]:
        """Get comprehensive status"""
        return {
            'tokens': self.current_tokens,
            'utilization': f"{self.utilization:.1f}%",
            'quality': self.attention_quality,
            'needs_compaction': self.should_compact(),
            'budget_remaining': self.MAX_CONTEXT_TOKENS - self.current_tokens,
            'estimated_cost': f"${self.estimated_cost:.4f}"
        }


class JustInTimeRetrieval:
    """
    Patterns for analyzing content without loading it into context.
    Based on Anthropic's recommendation to use grep/head/tail.
    """
    
    @staticmethod
    def get_file_analysis_command(filepath: str, purpose: str) -> str:
        """
        Generate efficient bash commands to analyze files without reading them fully.
        
        Examples:
        - Check file size: wc -l, du -h
        - Preview structure: head -n 20
        - Search patterns: grep -n "pattern"
        - Get summary: head + tail
        """
        
        commands = {
            'size': f'wc -l {filepath} && du -h {filepath}',
            'preview': f'head -n 30 {filepath}',
            'structure': f'head -n 50 {filepath} && echo "..." && tail -n 20 {filepath}',
            'search': f'grep -n "TODO\\|FIXME\\|BUG" {filepath} | head -n 20',
            'functions': f'grep -n "def \\|class \\|async def" {filepath}',
            'imports': f'head -n 50 {filepath} | grep -E "^import |^from "',
        }
        
        return commands.get(purpose, commands['preview'])
    
    @staticmethod
    def get_database_analysis_command(table: str, purpose: str) -> str:
        """Generate efficient SQL for database analysis"""
        
        commands = {
            'schema': f'DESCRIBE {table};',
            'sample': f'SELECT * FROM {table} LIMIT 10;',
            'count': f'SELECT COUNT(*) FROM {table};',
            'columns': f'SHOW COLUMNS FROM {table};',
        }
        
        return commands.get(purpose, commands['schema'])
    
    @staticmethod
    def should_use_jit(content_size: int, operation: str) -> bool:
        """
        Determine if just-in-time retrieval should be used instead of full load.
        
        Rules:
        - Files > 500 lines: Use JIT
        - Database tables > 100 rows: Use JIT  
        - Images: Always summarize
        - Logs: Always grep/tail
        """
        
        # Token estimation: ~4 chars per token
        estimated_tokens = content_size / 4
        
        # Operations that benefit from JIT
        jit_operations = {
            'search', 'analyze', 'debug', 'explore', 'investigate'
        }
        
        return (
            estimated_tokens > 2000  # > 2K tokens
            or operation in jit_operations
            or content_size > 500  # > 500 lines
        )


class ContextCompactor:
    """
    Intelligent context compaction following Anthropic's guidelines.
    """
    
    # What to keep
    KEEP_PATTERNS = [
        'architectural decision',
        'user preference',
        'discovered pattern',
        'critical error',
        'security issue',
        'performance metric'
    ]
    
    # What to discard
    DISCARD_PATTERNS = [
        'redundant tool output',
        'duplicate screenshot',
        'verbose log',
        'intermediate result',
        'exploration output'
    ]
    
    @classmethod
    def get_compaction_config(cls, context_tokens: int, task_type: str) -> Dict[str, Any]:
        """
        Generate dynamic compaction configuration based on context usage.
        
        Returns optimized clear_tool_uses_20250919 configuration.
        
        Anthropic Research Insight:
        - Pricing modeled here: ~$3/M input, ~$0.30/M cached input, ~$15/M output
        - Attention quality degrades significantly after 50k tokens
        - Aggressive early compaction is more cost-effective than late cleanup
        """
        
        # CRITICAL: Very aggressive compaction for high token usage
        if context_tokens > 100_000:
            return {
                'trigger': {'type': 'input_tokens', 'value': 5_000},  # Clear very often
                'keep': {'type': 'tool_uses', 'value': 2},  # Keep only last 2
                'clear_at_least': {'type': 'input_tokens', 'value': 10_000}  # Clear more
            }
        
        # DEGRADED: Aggressive compaction for medium usage  
        elif context_tokens > 50_000:
            return {
                'trigger': {'type': 'input_tokens', 'value': 10_000},
                'keep': {'type': 'tool_uses', 'value': 3},
                'clear_at_least': {'type': 'input_tokens', 'value': 5_000}
            }
        
        # GOOD: Moderate compaction for lower usage
        elif context_tokens > 30_000:
            return {
                'trigger': {'type': 'input_tokens', 'value': 20_000},
                'keep': {'type': 'tool_uses', 'value': 5},
                'clear_at_least': {'type': 'input_tokens', 'value': 3_000}
            }
        
        # EXCELLENT: Light compaction for low usage
        else:
            return {
                'trigger': {'type': 'input_tokens', 'value': 30_000},
                'keep': {'type': 'tool_uses', 'value': 8},
                'clear_at_least': {'type': 'input_tokens', 'value': 2_000}
            }
    
    @classmethod
    def compress_tool_results(cls, tool_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Compress tool results to reduce token count.
        
        - Keep last result only for duplicate screenshots
        - Summarize long outputs
        - Remove intermediate exploration
        """
        
        compressed = []
        screenshot_hashes = set()

        for result in tool_results:
            # Skip duplicate screenshots using proper image hashing
            if result.get('type') == 'screenshot':
                base64_img = result.get('base64_image', '')
                if base64_img:
                    if IMAGEHASH_AVAILABLE:
                        try:
                            # Decode base64 and compute perceptual hash
                            img_data = base64.b64decode(base64_img)
                            img = Image.open(BytesIO(img_data))
                            img_hash = str(imagehash.average_hash(img))
                            if img_hash in screenshot_hashes:
                                logger.debug("Skipping duplicate screenshot")
                                continue
                            screenshot_hashes.add(img_hash)
                        except Exception as e:
                            logger.debug(f"Error hashing screenshot: {e}, using fallback")
                            import hashlib
                            img_hash = hashlib.sha256(base64_img[:4000].encode()).hexdigest()
                            if img_hash in screenshot_hashes:
                                continue
                            screenshot_hashes.add(img_hash)
                    else:
                        import hashlib
                        img_hash = hashlib.sha256(base64_img[:4000].encode()).hexdigest()
                        if img_hash in screenshot_hashes:
                            continue
                        screenshot_hashes.add(img_hash)
            
            # Compress long text outputs
            if 'output' in result and len(str(result['output'])) > 1000:
                result['output'] = str(result['output'])[:500] + '\n... [truncated]'
            
            compressed.append(result)
        
        return compressed


class SubAgentCompressor:
    """
    Compress sub-agent exploration into concise summaries.
    Implements Anthropic's pattern: 50k exploration → 2k summary
    """
    
    @staticmethod
    def compress_exploration(
        task: str,
        full_output: str,
        key_findings: List[str],
        max_tokens: int = 500
    ) -> str:
        """
        Compress large exploration into concise summary.
        
        Args:
            task: What was being explored
            full_output: Full exploration output (may be 50k+ tokens)
            key_findings: List of important discoveries
            max_tokens: Target summary size
            
        Returns:
            Compressed summary maintaining critical info
        """
        
        # Estimate current size
        current_tokens = len(full_output) / 4
        
        if current_tokens <= max_tokens:
            return full_output  # Already small enough
        
        # Build compressed summary
        summary_parts = [
            f"EXPLORATION: {task}",
            "",
            "KEY FINDINGS:",
        ]
        
        # Add findings (most important)
        for i, finding in enumerate(key_findings[:10], 1):
            summary_parts.append(f"{i}. {finding}")
        
        # Add compressed context
        summary_parts.extend([
            "",
            "DETAILS:",
            full_output[:200] + "...",  # First 200 chars
            "...",
            full_output[-200:]  # Last 200 chars
        ])
        
        return "\n".join(summary_parts)
    
    @staticmethod
    def should_use_sub_agent(task_complexity: float, context_tokens: int) -> bool:
        """
        Determine if task should use sub-agent pattern.
        
        Use sub-agents when:
        - Task is complex (research, analysis, debugging)
        - Context budget is already high
        - Exploration will generate > 10k tokens
        """
        
        return (
            task_complexity > 0.6  # Complex task
            or context_tokens > 100_000  # High context already
        )


class ContextOptimizer:
    """
    Main context optimization orchestrator.
    Integrates all Anthropic patterns into the agent.
    """
    
    def __init__(self):
        self.budget = ContextBudget()
        self.jit = JustInTimeRetrieval()
        self.compactor = ContextCompactor()
        self.sub_agent = SubAgentCompressor()
        self._notes: list[str] = []
    
    def update_budget(self, usage: Dict[str, int]):
        """Update context budget from API response"""
        self.budget.input_tokens = usage.get('input_tokens', 0)
        self.budget.output_tokens = usage.get('output_tokens', 0)
        self.budget.cached_tokens = usage.get('cache_creation_input_tokens', 0)
        self.budget.current_tokens = self.budget.input_tokens
        
        # Log if attention quality is degraded
        status = self.budget.get_status()
        if status['quality'] in ['DEGRADED', 'CRITICAL']:
            logger.warning(
                f"Context attention quality: {status['quality']} | "
                f"Tokens: {status['tokens']:,} | "
                f"Utilization: {status['utilization']}"
            )
    
    def get_compaction_strategy(self, task_type: str) -> Dict[str, Any]:
        """Get optimal compaction configuration"""
        return self.compactor.get_compaction_config(
            self.budget.current_tokens,
            task_type
        )

    def apply_just_in_time_retrieval(self, content: str, *, max_lines: int = 100) -> str:
        """Truncate large text payloads to a bounded number of lines."""

        lines = content.splitlines()
        if len(lines) <= max_lines:
            return content
        if max_lines <= 0:
            return "[truncated]"
        truncated = lines[:max_lines]
        truncated[-1] = f"{truncated[-1]}  ... [truncated]"
        return "\n".join(truncated)

    def apply_dynamic_compaction(
        self,
        messages: list[Dict[str, Any]],
        *,
        keep_recent: int = 2,
    ) -> list[Dict[str, Any]]:
        """Keep a recent window of messages when the context budget degrades."""

        if keep_recent < 1:
            keep_recent = 1

        token_count = self.budget.count_tokens(messages)
        if token_count <= self.budget.attention_degradation_threshold:
            return messages

        # Preserve a leading system message if present.
        system_prefix: list[Dict[str, Any]] = []
        remaining = messages
        if messages and messages[0].get("role") == "system":
            system_prefix = [messages[0]]
            remaining = messages[1:]

        keep_messages = keep_recent * 2
        window = remaining[-keep_messages:] if len(remaining) > keep_messages else remaining
        return system_prefix + window

    def add_note(self, note: str) -> None:
        if not note:
            return
        self._notes.append(note.strip())

    def get_notes_summary(self, *, max_chars: int = 400) -> str:
        """Return a compact, keyword-preserving summary of accumulated notes."""

        if not self._notes:
            return ""

        condensed: list[str] = []
        for note in self._notes[-25:]:
            lowered = note.lower()
            if "config" in lowered:
                condensed.append(note.replace("Found ", "").replace("found ", ""))
            elif "error" in lowered:
                condensed.append(note)
            elif "database" in lowered or "connection" in lowered:
                condensed.append(note)
            else:
                condensed.append(note[:80])

        summary = "; ".join(condensed)
        if len(summary) > max_chars:
            return summary[: max(0, max_chars - 20)] + "... [truncated]"
        return summary

    def compress_subagent_output(self, raw_output: str, *, max_tokens: int = 2000) -> str:
        """Compress large sub-agent outputs to a token budget."""

        if max_tokens <= 0:
            return ""

        max_chars = max_tokens * 4
        if len(raw_output) <= max_chars:
            return raw_output

        head_chars = max(0, (max_chars // 2) - 100)
        tail_chars = max(0, (max_chars // 2) - 100)
        head = raw_output[:head_chars]
        tail = raw_output[-tail_chars:] if tail_chars else ""
        return f"{head}\n... [compressed]\n{tail}"

    def assess_attention_quality(self, messages: list[Dict[str, Any]]) -> str:
        """Assess attention quality for a conversation window."""

        tokens = self.budget.count_tokens(messages)
        return self.budget.get_attention_quality(tokens).value

    def should_trigger_compaction(self, tokens: int) -> bool:
        return tokens > self.budget.attention_degradation_threshold

    def apply_adaptive_window(
        self,
        messages: list[Dict[str, Any]],
        *,
        target_tokens: int,
    ) -> list[Dict[str, Any]]:
        """Return the most recent messages that fit under a token budget."""

        if target_tokens <= 0 or not messages:
            return messages[-1:] if messages else []

        # Preserve a leading system message if present.
        system_prefix: list[Dict[str, Any]] = []
        remaining = messages
        if messages[0].get("role") == "system":
            system_prefix = [messages[0]]
            remaining = messages[1:]

        # Hard cap long histories to keep agent latency/cost bounded even when
        # individual messages are short.
        max_history = 20
        if len(remaining) > max_history:
            remaining = remaining[-max_history:]

        selected: list[Dict[str, Any]] = []
        total_tokens = 0
        for message in reversed(remaining):
            msg_tokens = self.budget.count_tokens([message])
            if selected and total_tokens + msg_tokens > target_tokens:
                break
            total_tokens += msg_tokens
            selected.append(message)

        return system_prefix + list(reversed(selected))

    def compress_tool_result(self, output: str, *, tool_name: str = "") -> str:
        """Compress overly large tool outputs to something context-friendly."""

        if not output:
            return ""
        if len(output) <= 4000:
            return output

        lines = output.splitlines()
        head = "\n".join(lines[:25])
        tail = "\n".join(lines[-25:]) if len(lines) > 25 else ""
        return f"{head}\n... [truncated {tool_name} output]\n{tail}"

    def calculate_cost(self, *, input_tokens: int, output_tokens: int, cached_tokens: int = 0) -> float:
        """Estimate request cost given token counts."""

        fresh_input_tokens = max(0, input_tokens - cached_tokens)
        input_cost = (fresh_input_tokens / 1000) * self.budget.COST_PER_1K_INPUT
        cached_cost = (cached_tokens / 1000) * self.budget.COST_PER_1K_CACHED_INPUT
        output_cost = (output_tokens / 1000) * self.budget.COST_PER_1K_OUTPUT
        return input_cost + cached_cost + output_cost
    
    def get_system_prompt_guidance(self) -> str:
        """
        Generate dynamic system prompt guidance based on context state.
        
        Quality levels (updated for Claude Opus 4.6 cost optimization):
        - EXCELLENT: < 30k tokens
        - GOOD: 30k-50k tokens
        - DEGRADED: 50k-80k tokens
        - WARNING: 80k-100k tokens
        - CRITICAL: > 100k tokens
        """
        
        status = self.budget.get_status()
        
        if status['quality'] in ('CRITICAL', 'WARNING'):
            return """
<CRITICAL_CONTEXT_WARNING>
Your context window is near capacity ({utilization}).

IMMEDIATE ACTIONS REQUIRED:
1. Use grep/head/tail instead of reading full files
2. Summarize findings in memory immediately
3. Request aggressive context clearing
4. Avoid loading large outputs into context
5. Use bash commands for analysis, not full file reads

EXAMPLE - Don't do this:
  ❌ Read entire 1000-line log file
  
Instead do this:
  ✅ grep "ERROR" logfile.txt | tail -n 20
  ✅ head -n 50 logfile.txt  # Preview only
  ✅ wc -l logfile.txt  # Get size first

Your attention budget is depleted. Work smarter, not harder.
</CRITICAL_CONTEXT_WARNING>
""".format(utilization=status['utilization'])
        
        elif status['quality'] == 'DEGRADED':
            return """
<CONTEXT_GUIDANCE>
Context usage: {utilization} - Attention quality degrading.

OPTIMIZE YOUR APPROACH:
- Prefer grep over reading full files
- Use head/tail for previews
- Summarize findings in /memories
- Be selective about what you load

Efficiency = Better performance
</CONTEXT_GUIDANCE>
""".format(utilization=status['utilization'])
        
        else:
            return """
<CONTEXT_BEST_PRACTICES>
Use just-in-time retrieval:
- grep for searching
- head/tail for previews
- wc for file sizes
- Analyze before loading

Save important findings to /memories for future reference.
</CONTEXT_BEST_PRACTICES>
"""
    
    def get_retrieval_recommendation(
        self,
        content_type: str,
        size_estimate: int,
        operation: str
    ) -> Dict[str, Any]:
        """
        Recommend optimal retrieval strategy.
        
        Returns:
            {
                'method': 'jit' or 'full',
                'command': Suggested bash command or None,
                'reason': Explanation
            }
        """
        
        use_jit = self.jit.should_use_jit(size_estimate, operation)
        
        if use_jit:
            if content_type == 'file':
                command = self.jit.get_file_analysis_command('TARGET_FILE', operation)
                return {
                    'method': 'jit',
                    'command': command,
                    'reason': f'File too large ({size_estimate} bytes). Use grep/head/tail.'
                }
            elif content_type == 'database':
                command = self.jit.get_database_analysis_command('TARGET_TABLE', operation)
                return {
                    'method': 'jit',
                    'command': command,
                    'reason': 'Database too large. Sample and describe instead.'
                }
        
        return {
            'method': 'full',
            'command': None,
            'reason': 'Content small enough for full load'
        }
    
    def print_status(self, use_logger: bool = False):
        """
        Output current context optimization status.

        Args:
            use_logger: If True, outputs via logger.info. If False, prints to stdout.
        """
        status = self.budget.get_status()

        lines = [
            "\n" + "="*70,
            "CONTEXT OPTIMIZATION STATUS",
            "="*70,
            f"  Tokens: {status['tokens']:,} / {self.budget.MAX_CONTEXT_TOKENS:,}",
            f"  Utilization: {status['utilization']}",
            f"  Attention Quality: {status['quality']}",
            f"  Needs Compaction: {'YES' if status['needs_compaction'] else 'NO'}",
            f"  Budget Remaining: {status['budget_remaining']:,} tokens",
            "="*70 + "\n"
        ]
        output = "\n".join(lines)

        if use_logger:
            logger.info("Context optimization status:\n%s", output)
        else:
            print(output)


# Singleton instance
_optimizer_instance: Optional[ContextOptimizer] = None
_optimizer_lock = threading.Lock()


def get_context_optimizer() -> ContextOptimizer:
    """Get global context optimizer instance (thread-safe)."""
    global _optimizer_instance
    if _optimizer_instance is None:
        with _optimizer_lock:
            if _optimizer_instance is None:
                _optimizer_instance = ContextOptimizer()
    return _optimizer_instance


def reset_context_optimizer():
    """Reset optimizer (for testing or new sessions)"""
    global _optimizer_instance
    with _optimizer_lock:
        _optimizer_instance = None
