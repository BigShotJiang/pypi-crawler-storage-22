"""
Environment validation utilities.

Extracted from main.py. Validates required environment variables and returns
configuration for the agent system.
"""

import os
from typing import Dict


def _get_int_env(name: str, default: int) -> int:
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def validate_environment(*, require_display: bool = True) -> Dict[str, str]:
    """
    Validate required environment variables and return configuration.
    Raises ValueError with helpful message if validation fails.
    Args:
        require_display: Whether to enforce DISPLAY being set for GUI automation.
    """
    errors = []
    config = {}

    # Required: Anthropic API key
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if not anthropic_key:
        errors.append(
            "ANTHROPIC_API_KEY is required\n"
            "  Get your API key from: https://console.anthropic.com/\n"
            "  Set it with: export ANTHROPIC_API_KEY='sk-ant-api03-...'"
        )
    elif not anthropic_key.startswith('sk-ant-'):
        errors.append(
            "ANTHROPIC_API_KEY appears to be invalid (should start with 'sk-ant-')"
        )
    else:
        config['ANTHROPIC_API_KEY'] = anthropic_key

    # Required: Display server for GUI automation
    display = os.environ.get('DISPLAY')
    if require_display:
        if not display:
            errors.append(
                "DISPLAY environment variable is required for GUI automation\n"
                "  Start Xvfb with: Xvfb :1 -screen 0 1920x1080x24 &\n"
                "  Set display with: export DISPLAY=:1"
            )
        else:
            config['DISPLAY'] = display
    elif display:
        config['DISPLAY'] = display

    # Optional: Stripe API key (for billing)
    stripe_key = os.environ.get('STRIPE_API_KEY')
    if stripe_key:
        if not stripe_key.startswith('sk_'):
            errors.append(
                "STRIPE_API_KEY appears to be invalid (should start with 'sk_live_' or 'sk_test_')"
            )
        else:
            config['STRIPE_API_KEY'] = stripe_key

    # Optional: Workspace path
    workspace = os.environ.get('WORKSPACE_PATH', os.getcwd())
    config['WORKSPACE_PATH'] = workspace

    if errors:
        error_msg = "Environment validation failed:\n\n" + "\n\n".join(f"❌ {err}" for err in errors)
        raise ValueError(error_msg)

    return config
