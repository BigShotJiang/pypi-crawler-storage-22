"""
Comprehensive exception hierarchy for StateSet Computer Use Agent.

This module provides a structured exception hierarchy that:
1. Distinguishes between retryable and non-retryable errors
2. Preserves exception context and chaining
3. Provides rich error information for debugging
4. Enables precise error handling at each layer

Exception Categories:
- AgentError: Base class for all agent-related errors
- RetryableError: Transient errors that can be retried
- NonRetryableError: Permanent errors that should not be retried
- ConfigurationError: Environment/setup issues
- SecurityError: Security violations
- BudgetError: Cost/budget limit violations
- ToolError: Tool execution failures
"""

import builtins
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class ErrorSeverity(Enum):
    """Error severity levels for logging and alerting"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class ErrorCategory(Enum):
    """Error categories for classification and handling"""
    CONFIGURATION = "configuration"
    NETWORK = "network"
    API = "api"
    TOOL = "tool"
    SECURITY = "security"
    BUDGET = "budget"
    VALIDATION = "validation"
    TIMEOUT = "timeout"
    RESOURCE = "resource"
    INTERNAL = "internal"


@dataclass
class ErrorContext:
    """Rich context for error tracking and debugging"""
    timestamp: datetime = field(default_factory=datetime.utcnow)
    agent_id: Optional[str] = None
    agent_type: Optional[str] = None
    request_id: Optional[str] = None
    tool_name: Optional[str] = None
    operation: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    stack_trace: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging/serialization"""
        return {
            "timestamp": self.timestamp.isoformat(),
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "request_id": self.request_id,
            "tool_name": self.tool_name,
            "operation": self.operation,
            "details": self.details,
            "stack_trace": self.stack_trace,
        }


class AgentError(Exception):
    """
    Base exception class for all agent-related errors.

    Provides:
    - Rich error context
    - Exception chaining support
    - Severity and category classification
    - Structured logging support

    Usage:
        raise AgentError(
            message="Failed to execute tool",
            category=ErrorCategory.TOOL,
            context=ErrorContext(tool_name="bash", operation="execute"),
            cause=original_exception
        )
    """

    def __init__(
        self,
        message: str,
        category: ErrorCategory = ErrorCategory.INTERNAL,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        context: Optional[ErrorContext] = None,
        cause: Optional[Exception] = None,
        retryable: bool = False,
    ):
        self.message = message
        self.category = category
        self.severity = severity
        self.context = context or ErrorContext()
        self.retryable = retryable

        # Capture stack trace if not already present
        if not self.context.stack_trace:
            self.context.stack_trace = traceback.format_exc()

        # Proper exception chaining
        super().__init__(message)
        if cause:
            self.__cause__ = cause

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging/serialization"""
        return {
            "error_type": self.__class__.__name__,
            "message": self.message,
            "category": self.category.value,
            "severity": self.severity.value,
            "retryable": self.retryable,
            "context": self.context.to_dict(),
            "cause": str(self.__cause__) if self.__cause__ else None,
        }

    def __str__(self) -> str:
        parts = [f"{self.__class__.__name__}: {self.message}"]
        if self.context.operation:
            parts.append(f"Operation: {self.context.operation}")
        if self.context.tool_name:
            parts.append(f"Tool: {self.context.tool_name}")
        if self.__cause__:
            parts.append(f"Caused by: {self.__cause__}")
        return " | ".join(parts)


# ============================================================================
# Retryable Errors - Transient failures that can be retried
# ============================================================================

class RetryableError(AgentError):
    """
    Base class for transient errors that should be retried.

    These errors represent temporary failures where retrying
    may succeed (network issues, rate limits, etc.)
    """

    def __init__(
        self,
        message: str,
        category: ErrorCategory = ErrorCategory.NETWORK,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        **kwargs
    ):
        super().__init__(message, category=category, retryable=True, **kwargs)
        self.max_retries = max_retries
        self.retry_delay = retry_delay


class NetworkError(RetryableError):
    """Network connectivity issues (timeouts, DNS failures, etc.)"""

    def __init__(self, message: str, **kwargs):
        super().__init__(
            message,
            category=ErrorCategory.NETWORK,
            severity=ErrorSeverity.WARNING,
            **kwargs
        )


class RateLimitError(RetryableError):
    """API rate limit exceeded - should retry after delay"""

    def __init__(
        self,
        message: str,
        retry_after: Optional[float] = None,
        **kwargs
    ):
        # Use retry_after from header if available
        delay = retry_after or 60.0
        super().__init__(
            message,
            category=ErrorCategory.API,
            severity=ErrorSeverity.WARNING,
            retry_delay=delay,
            **kwargs
        )
        self.retry_after = retry_after


class ServiceUnavailableError(RetryableError):
    """External service temporarily unavailable (5xx errors)"""

    def __init__(self, message: str, service_name: str = "unknown", **kwargs):
        super().__init__(
            message,
            category=ErrorCategory.API,
            severity=ErrorSeverity.WARNING,
            **kwargs
        )
        self.service_name = service_name


class OperationTimeoutError(RetryableError):
    """
    Operation timed out - may succeed on retry.

    Note: Named OperationTimeoutError to avoid shadowing the builtin TimeoutError.
    """

    def __init__(
        self,
        message: str,
        timeout_seconds: float = 0,
        **kwargs
    ):
        super().__init__(
            message,
            category=ErrorCategory.TIMEOUT,
            severity=ErrorSeverity.WARNING,
            **kwargs
        )
        self.timeout_seconds = timeout_seconds


# Backward compatibility alias (deprecated)
TimeoutError = OperationTimeoutError


class CircuitBreakerOpenError(RetryableError):
    """Circuit breaker is open - service needs recovery time"""

    def __init__(self, message: str, breaker_name: str = "unknown", **kwargs):
        super().__init__(
            message,
            category=ErrorCategory.API,
            severity=ErrorSeverity.WARNING,
            retry_delay=60.0,  # Wait for circuit breaker timeout
            **kwargs
        )
        self.breaker_name = breaker_name


# ============================================================================
# Non-Retryable Errors - Permanent failures that should not be retried
# ============================================================================

class NonRetryableError(AgentError):
    """
    Base class for permanent errors that should not be retried.

    These errors represent permanent failures where retrying
    will not help (validation errors, missing resources, etc.)
    """

    def __init__(self, message: str, **kwargs):
        super().__init__(message, retryable=False, **kwargs)


class ConfigurationError(NonRetryableError):
    """
    Configuration or environment setup errors.

    Examples:
    - Missing API keys
    - Invalid configuration values
    - Missing required dependencies
    """

    def __init__(
        self,
        message: str,
        config_key: Optional[str] = None,
        expected_value: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            message,
            category=ErrorCategory.CONFIGURATION,
            severity=ErrorSeverity.CRITICAL,
            **kwargs
        )
        self.config_key = config_key
        self.expected_value = expected_value


class ValidationError(NonRetryableError):
    """
    Input validation failures.

    Examples:
    - Invalid parameters
    - Malformed data
    - Type mismatches
    """

    def __init__(
        self,
        message: str,
        field_name: Optional[str] = None,
        invalid_value: Optional[Any] = None,
        **kwargs
    ):
        super().__init__(
            message,
            category=ErrorCategory.VALIDATION,
            severity=ErrorSeverity.ERROR,
            **kwargs
        )
        self.field_name = field_name
        self.invalid_value = invalid_value


class SecurityError(NonRetryableError):
    """
    Security-related errors.

    Examples:
    - Authentication failures
    - Authorization denied
    - Prompt injection detected
    - Path traversal attempts
    """

    def __init__(
        self,
        message: str,
        violation_type: str = "unknown",
        **kwargs
    ):
        super().__init__(
            message,
            category=ErrorCategory.SECURITY,
            severity=ErrorSeverity.CRITICAL,
            **kwargs
        )
        self.violation_type = violation_type


class AuthenticationError(SecurityError):
    """Authentication failed (invalid credentials)"""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, violation_type="authentication", **kwargs)


class AuthorizationError(SecurityError):
    """Authorization denied (insufficient permissions)"""

    def __init__(self, message: str, required_permission: Optional[str] = None, **kwargs):
        super().__init__(message, violation_type="authorization", **kwargs)
        self.required_permission = required_permission


class PromptInjectionError(SecurityError):
    """Prompt injection attack detected"""

    def __init__(self, message: str, detected_pattern: Optional[str] = None, **kwargs):
        super().__init__(message, violation_type="prompt_injection", **kwargs)
        self.detected_pattern = detected_pattern


# ============================================================================
# Budget Errors
# ============================================================================

class BudgetError(NonRetryableError):
    """
    Budget or cost limit violations.

    Examples:
    - Daily budget exceeded
    - Per-task budget exceeded
    - Monthly budget exceeded
    """

    def __init__(
        self,
        message: str,
        budget_type: str = "unknown",
        limit: float = 0.0,
        current: float = 0.0,
        **kwargs
    ):
        super().__init__(
            message,
            category=ErrorCategory.BUDGET,
            severity=ErrorSeverity.ERROR,
            **kwargs
        )
        self.budget_type = budget_type
        self.limit = limit
        self.current = current
        self.overage = current - limit


class DailyBudgetExceededError(BudgetError):
    """Daily cost limit exceeded"""

    def __init__(self, message: str, limit: float, current: float, **kwargs):
        super().__init__(
            message,
            budget_type="daily",
            limit=limit,
            current=current,
            **kwargs
        )


class TaskBudgetExceededError(BudgetError):
    """Per-task cost limit exceeded"""

    def __init__(self, message: str, limit: float, current: float, **kwargs):
        super().__init__(
            message,
            budget_type="task",
            limit=limit,
            current=current,
            **kwargs
        )


class MonthlyBudgetExceededError(BudgetError):
    """Monthly cost limit exceeded"""

    def __init__(self, message: str, limit: float, current: float, **kwargs):
        super().__init__(
            message,
            budget_type="monthly",
            limit=limit,
            current=current,
            **kwargs
        )


# ============================================================================
# Tool Errors
# ============================================================================

class ToolError(AgentError):
    """
    Tool execution errors.

    Can be retryable or non-retryable depending on the specific failure.

    Supports two calling conventions for backward compatibility:
    1. Simple: ToolError("message") - for basic tool errors
    2. Rich: ToolError("message", tool_name="bash", tool_input={...}) - for detailed errors
    """

    def __init__(
        self,
        message: str,
        tool_name: Optional[str] = None,
        tool_input: Optional[Dict[str, Any]] = None,
        retryable: bool = False,
        **kwargs
    ):
        context = kwargs.pop("context", None) or ErrorContext()
        if tool_name:
            context.tool_name = tool_name

        super().__init__(
            message,
            category=ErrorCategory.TOOL,
            context=context,
            retryable=retryable,
            **kwargs
        )
        self.tool_name = tool_name
        self.tool_input = tool_input
        # Backward compatibility: store message for code accessing .message directly
        self.message = message


class ToolExecutionError(ToolError):
    """Tool failed during execution"""

    def __init__(self, message: str, tool_name: str, exit_code: Optional[int] = None, **kwargs):
        super().__init__(message, tool_name=tool_name, retryable=False, **kwargs)
        self.exit_code = exit_code


class ToolTimeoutError(ToolError):
    """Tool execution timed out"""

    def __init__(self, message: str, tool_name: str, timeout_seconds: float, **kwargs):
        super().__init__(message, tool_name=tool_name, retryable=True, **kwargs)
        self.timeout_seconds = timeout_seconds


class ToolValidationError(ToolError):
    """Tool input validation failed"""

    def __init__(self, message: str, tool_name: str, invalid_params: List[str] = None, **kwargs):
        super().__init__(message, tool_name=tool_name, retryable=False, **kwargs)
        self.invalid_params = invalid_params or []


# ============================================================================
# Resource Errors
# ============================================================================

class ResourceError(AgentError):
    """Resource-related errors (memory, disk, etc.)"""

    def __init__(self, message: str, resource_type: str = "unknown", **kwargs):
        super().__init__(
            message,
            category=ErrorCategory.RESOURCE,
            **kwargs
        )
        self.resource_type = resource_type


class MemoryError(ResourceError):
    """Memory limit exceeded"""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, resource_type="memory", retryable=False, **kwargs)


class DiskSpaceError(ResourceError):
    """Disk space exhausted"""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, resource_type="disk", retryable=False, **kwargs)


class ContextWindowExceededError(ResourceError):
    """Context window limit exceeded"""

    def __init__(self, message: str, token_count: int = 0, max_tokens: int = 200000, **kwargs):
        super().__init__(message, resource_type="context_window", retryable=False, **kwargs)
        self.token_count = token_count
        self.max_tokens = max_tokens


# ============================================================================
# API Errors
# ============================================================================

class APIError(AgentError):
    """Base class for API-related errors"""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_body: Optional[str] = None,
        **kwargs
    ):
        # Determine if retryable based on status code
        retryable = status_code in (429, 500, 502, 503, 504) if status_code else False

        super().__init__(
            message,
            category=ErrorCategory.API,
            retryable=retryable,
            **kwargs
        )
        self.status_code = status_code
        self.response_body = response_body


class APIClientError(APIError):
    """4xx client errors (except rate limit)"""

    def __init__(self, message: str, status_code: int, **kwargs):
        super().__init__(message, status_code=status_code, **kwargs)


class APIServerError(APIError):
    """5xx server errors"""

    def __init__(self, message: str, status_code: int, **kwargs):
        super().__init__(message, status_code=status_code, **kwargs)


# ============================================================================
# Utility Functions
# ============================================================================

def is_retryable(error: Exception) -> bool:
    """Check if an error is retryable"""
    if isinstance(error, AgentError):
        return error.retryable

    # Common retryable exception types (using builtins.TimeoutError for the builtin)
    retryable_types = (
        ConnectionError,
        builtins.TimeoutError,
        IOError,
    )
    return isinstance(error, retryable_types)


def get_retry_delay(error: Exception) -> float:
    """Get recommended retry delay for an error"""
    if isinstance(error, RetryableError):
        return error.retry_delay
    if isinstance(error, RateLimitError) and error.retry_after:
        return error.retry_after
    return 1.0  # Default 1 second


def wrap_exception(
    error: Exception,
    message: str,
    context: Optional[ErrorContext] = None,
) -> AgentError:
    """
    Wrap a standard exception in an AgentError while preserving context.

    Usage:
        try:
            some_operation()
        except ValueError as e:
            raise wrap_exception(e, "Invalid input", context=ctx) from e
    """
    # Map common exceptions to appropriate AgentError types
    # Note: Use builtins.TimeoutError to check for the builtin exception
    if isinstance(error, ConnectionError):
        return NetworkError(message, context=context, cause=error)
    elif isinstance(error, builtins.TimeoutError):
        return OperationTimeoutError(message, context=context, cause=error)
    elif isinstance(error, PermissionError):
        return SecurityError(message, violation_type="permission", context=context, cause=error)
    elif isinstance(error, FileNotFoundError):
        return ConfigurationError(message, context=context, cause=error)
    else:
        return AgentError(message, context=context, cause=error)
