"""
Agent Fleet Manager for StateSet Computer Use Agent.

This module provides enterprise-grade agent fleet management for running
multiple agents across a business:

1. Fleet Orchestration
   - Dynamic agent provisioning
   - Load balancing across agents
   - Auto-scaling based on demand
   - Health-based routing

2. Business Unit Management
   - Department-based agent pools
   - Resource quotas per unit
   - Cross-department coordination
   - Isolated execution environments

3. Capacity Planning
   - Workload prediction
   - Resource reservation
   - Peak load handling
   - Cost optimization

4. Agent Lifecycle
   - Warm-up and cool-down
   - Graceful shutdown
   - Version management
   - Rolling updates

Designed for enterprise deployment at scale.
"""

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from collections import defaultdict
import heapq

from agent.logging_config import get_logger
from agent.autonomous_coordinator import AgentInstance, AgentStatus, BudgetManager

logger = get_logger(__name__)


class AgentPoolStrategy(Enum):
    """Agent pool scaling strategies"""
    FIXED = "fixed"              # Fixed number of agents
    DEMAND = "demand"            # Scale based on queue length
    SCHEDULED = "scheduled"      # Scale based on time/schedule
    PREDICTIVE = "predictive"    # ML-based prediction


class LoadBalanceStrategy(Enum):
    """Load balancing strategies"""
    ROUND_ROBIN = "round_robin"
    LEAST_LOADED = "least_loaded"
    RANDOM = "random"
    WEIGHTED = "weighted"
    CAPABILITY_MATCH = "capability_match"


class AgentCapability(Enum):
    """Standard agent capabilities"""
    TICKET_MANAGEMENT = "ticket_management"
    CONTENT_MODERATION = "content_moderation"
    DATA_ENTRY = "data_entry"
    RESEARCH = "research"
    CODE_REVIEW = "code_review"
    CUSTOMER_SERVICE = "customer_service"
    SALES_AUTOMATION = "sales_automation"
    HR_AUTOMATION = "hr_automation"
    FINANCE_AUTOMATION = "finance_automation"
    GENERAL_PURPOSE = "general_purpose"


@dataclass
class AgentSpec:
    """Specification for an agent type"""
    agent_type: str
    capabilities: List[AgentCapability]
    model_tier: str = "sonnet"  # haiku, sonnet, opus
    max_concurrent_tasks: int = 3
    memory_limit_mb: int = 512
    timeout_seconds: int = 3600
    cost_per_hour: float = 0.50
    warm_up_seconds: int = 5
    cool_down_seconds: int = 30

    # Specialization
    specialized_instructions: str = ""
    required_tools: List[str] = field(default_factory=list)
    mcp_servers: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'agent_type': self.agent_type,
            'capabilities': [c.value for c in self.capabilities],
            'model_tier': self.model_tier,
            'max_concurrent_tasks': self.max_concurrent_tasks,
            'cost_per_hour': self.cost_per_hour
        }


@dataclass
class FleetAgent:
    """An agent instance in the fleet"""
    agent_id: str
    spec: AgentSpec
    pool_id: str
    status: AgentStatus = AgentStatus.IDLE

    # Metrics
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_task_at: Optional[datetime] = None
    tasks_completed: int = 0
    tasks_failed: int = 0
    total_runtime_seconds: float = 0.0

    # Current state
    current_tasks: List[str] = field(default_factory=list)
    health_score: float = 1.0  # 0.0 - 1.0

    @property
    def utilization(self) -> float:
        """Current utilization percentage"""
        return len(self.current_tasks) / self.spec.max_concurrent_tasks

    @property
    def success_rate(self) -> float:
        """Task success rate"""
        total = self.tasks_completed + self.tasks_failed
        return self.tasks_completed / total if total > 0 else 1.0

    def can_accept_task(self) -> bool:
        """Check if agent can accept more tasks"""
        return (
            self.status in (AgentStatus.IDLE, AgentStatus.RUNNING) and
            len(self.current_tasks) < self.spec.max_concurrent_tasks and
            self.health_score > 0.3
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            'agent_id': self.agent_id,
            'agent_type': self.spec.agent_type,
            'pool_id': self.pool_id,
            'status': self.status.value,
            'utilization': self.utilization,
            'tasks_completed': self.tasks_completed,
            'success_rate': self.success_rate,
            'health_score': self.health_score
        }


@dataclass
class AgentPool:
    """A pool of agents for a specific purpose"""
    pool_id: str
    name: str
    description: str

    # Agent configuration
    agent_spec: AgentSpec
    min_agents: int = 1
    max_agents: int = 10
    target_utilization: float = 0.7

    # Scaling
    strategy: AgentPoolStrategy = AgentPoolStrategy.DEMAND
    scale_up_threshold: float = 0.8
    scale_down_threshold: float = 0.3
    scale_cooldown_seconds: int = 300

    # Business unit assignment
    department: str = ""
    cost_center: str = ""
    budget_limit: float = 1000.0  # Daily budget

    # Current state
    agents: Dict[str, FleetAgent] = field(default_factory=dict)
    last_scale_action: Optional[datetime] = None
    daily_spend: float = 0.0

    @property
    def current_size(self) -> int:
        return len(self.agents)

    @property
    def available_capacity(self) -> int:
        """Number of task slots available"""
        return sum(
            a.spec.max_concurrent_tasks - len(a.current_tasks)
            for a in self.agents.values()
            if a.can_accept_task()
        )

    @property
    def utilization(self) -> float:
        """Pool-wide utilization"""
        if not self.agents:
            return 0.0
        total_capacity = sum(a.spec.max_concurrent_tasks for a in self.agents.values())
        total_tasks = sum(len(a.current_tasks) for a in self.agents.values())
        return total_tasks / total_capacity if total_capacity > 0 else 0.0

    def get_available_agents(self) -> List[FleetAgent]:
        """Get agents that can accept tasks"""
        return [a for a in self.agents.values() if a.can_accept_task()]

    def to_dict(self) -> Dict[str, Any]:
        return {
            'pool_id': self.pool_id,
            'name': self.name,
            'department': self.department,
            'agent_type': self.agent_spec.agent_type,
            'current_size': self.current_size,
            'min_agents': self.min_agents,
            'max_agents': self.max_agents,
            'utilization': self.utilization,
            'available_capacity': self.available_capacity,
            'daily_spend': self.daily_spend,
            'budget_limit': self.budget_limit
        }


@dataclass
class BusinessUnit:
    """A business unit with its own agent resources"""
    unit_id: str
    name: str
    department: str

    # Resource allocation
    pools: List[str] = field(default_factory=list)
    budget: BudgetManager = None
    priority: int = 5  # 1-10, higher = more priority

    # Quotas
    max_concurrent_agents: int = 20
    max_daily_tasks: int = 1000

    # Current state
    current_agents: int = 0
    tasks_today: int = 0

    # Contacts
    owner: str = ""
    contacts: List[str] = field(default_factory=list)

    def __post_init__(self):
        if self.budget is None:
            self.budget = BudgetManager(
                daily_budget=500.0,
                hourly_budget=50.0,
                per_task_budget=10.0
            )

    def can_start_task(self) -> Tuple[bool, str]:
        """Check if business unit can start a new task"""
        if self.tasks_today >= self.max_daily_tasks:
            return False, "Daily task limit reached"

        can_budget, reason = self.budget.can_start_task(1.0)
        if not can_budget:
            return False, reason

        return True, ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            'unit_id': self.unit_id,
            'name': self.name,
            'department': self.department,
            'pools': self.pools,
            'priority': self.priority,
            'current_agents': self.current_agents,
            'tasks_today': self.tasks_today,
            'max_daily_tasks': self.max_daily_tasks,
            'budget_status': self.budget.get_status()
        }


@dataclass
class TaskAssignment:
    """A task assigned to an agent"""
    task_id: str
    agent_id: str
    pool_id: str
    instruction: str
    priority: int = 5

    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    status: str = "pending"
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    # Metadata
    business_unit: str = ""
    correlation_id: Optional[str] = None
    timeout_seconds: int = 3600


class LoadBalancer:
    """Load balancer for distributing tasks across agents"""

    def __init__(self, strategy: LoadBalanceStrategy = LoadBalanceStrategy.LEAST_LOADED):
        self.strategy = strategy
        self._round_robin_index: Dict[str, int] = defaultdict(int)

    def select_agent(
        self,
        pool: AgentPool,
        task_capabilities: List[AgentCapability] = None
    ) -> Optional[FleetAgent]:
        """Select an agent from the pool for a task"""
        available = pool.get_available_agents()

        if not available:
            return None

        # Filter by capability if specified
        if task_capabilities:
            available = [
                a for a in available
                if all(cap in a.spec.capabilities for cap in task_capabilities)
            ]

        if not available:
            return None

        if self.strategy == LoadBalanceStrategy.ROUND_ROBIN:
            return self._round_robin(pool.pool_id, available)
        elif self.strategy == LoadBalanceStrategy.LEAST_LOADED:
            return self._least_loaded(available)
        elif self.strategy == LoadBalanceStrategy.WEIGHTED:
            return self._weighted(available)
        elif self.strategy == LoadBalanceStrategy.CAPABILITY_MATCH:
            return self._capability_match(available, task_capabilities)
        else:
            import random
            return random.choice(available)

    def _round_robin(self, pool_id: str, agents: List[FleetAgent]) -> FleetAgent:
        """Round-robin selection"""
        index = self._round_robin_index[pool_id] % len(agents)
        self._round_robin_index[pool_id] += 1
        return agents[index]

    def _least_loaded(self, agents: List[FleetAgent]) -> FleetAgent:
        """Select least loaded agent"""
        return min(agents, key=lambda a: a.utilization)

    def _weighted(self, agents: List[FleetAgent]) -> FleetAgent:
        """Select based on health score and capacity"""
        return max(
            agents,
            key=lambda a: a.health_score * (1 - a.utilization) * a.success_rate
        )

    def _capability_match(
        self,
        agents: List[FleetAgent],
        capabilities: List[AgentCapability]
    ) -> FleetAgent:
        """Select agent with best capability match"""
        if not capabilities:
            return self._least_loaded(agents)

        def capability_score(agent: FleetAgent) -> int:
            return sum(1 for cap in capabilities if cap in agent.spec.capabilities)

        return max(agents, key=lambda a: (capability_score(a), -a.utilization))


class AutoScaler:
    """Auto-scaler for agent pools"""

    def __init__(self):
        self._scale_history: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    async def evaluate_scaling(
        self,
        pool: AgentPool,
        pending_tasks: int = 0
    ) -> Optional[Tuple[str, int]]:
        """
        Evaluate if pool needs scaling.
        Returns: (action, count) or None
        """
        # Check cooldown
        if pool.last_scale_action:
            elapsed = (datetime.utcnow() - pool.last_scale_action).total_seconds()
            if elapsed < pool.scale_cooldown_seconds:
                return None

        current = pool.current_size
        utilization = pool.utilization

        # Calculate desired size based on strategy
        if pool.strategy == AgentPoolStrategy.FIXED:
            desired = pool.min_agents

        elif pool.strategy == AgentPoolStrategy.DEMAND:
            # Scale based on current utilization and pending tasks
            if utilization > pool.scale_up_threshold or pending_tasks > current * 2:
                desired = min(current + 1, pool.max_agents)
            elif utilization < pool.scale_down_threshold and pending_tasks == 0:
                desired = max(current - 1, pool.min_agents)
            else:
                desired = current

        elif pool.strategy == AgentPoolStrategy.SCHEDULED:
            # Would integrate with schedule - for now use demand
            desired = current

        elif pool.strategy == AgentPoolStrategy.PREDICTIVE:
            # Would use ML prediction - for now use demand
            desired = current

        else:
            desired = current

        # Determine action
        if desired > current:
            count = desired - current
            self._record_scale_event(pool.pool_id, 'scale_up', count)
            return ('scale_up', count)
        elif desired < current:
            count = current - desired
            self._record_scale_event(pool.pool_id, 'scale_down', count)
            return ('scale_down', count)

        return None

    def _record_scale_event(self, pool_id: str, action: str, count: int):
        """Record scaling event for analysis"""
        self._scale_history[pool_id].append({
            'timestamp': datetime.utcnow().isoformat(),
            'action': action,
            'count': count
        })

        # Keep last 100 events
        self._scale_history[pool_id] = self._scale_history[pool_id][-100:]

    def get_scale_history(self, pool_id: str) -> List[Dict[str, Any]]:
        """Get scaling history for a pool"""
        return self._scale_history.get(pool_id, [])


class FleetManager:
    """
    Main fleet manager for orchestrating agents across a business.

    Manages multiple agent pools, business units, and provides
    enterprise-grade orchestration capabilities.
    """

    def __init__(
        self,
        storage_dir: str = "/tmp/agent_fleet",
        agent_factory: Callable = None
    ):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # Components
        self._pools: Dict[str, AgentPool] = {}
        self._business_units: Dict[str, BusinessUnit] = {}
        self._agent_specs: Dict[str, AgentSpec] = {}

        # Task management
        self._pending_tasks: Dict[str, TaskAssignment] = {}
        self._active_tasks: Dict[str, TaskAssignment] = {}
        self._completed_tasks: List[TaskAssignment] = []

        # Components
        self._load_balancer = LoadBalancer(LoadBalanceStrategy.WEIGHTED)
        self._auto_scaler = AutoScaler()
        self._agent_factory = agent_factory

        # Background tasks
        self._running = False
        self._background_tasks: List[asyncio.Task] = []

        # Statistics
        self._stats = {
            'total_tasks_assigned': 0,
            'total_tasks_completed': 0,
            'total_tasks_failed': 0,
            'total_agents_created': 0,
            'total_agents_terminated': 0
        }

        # Initialize default specs
        self._init_default_specs()

    def _init_default_specs(self):
        """Initialize default agent specifications"""
        self._agent_specs = {
            'AUTO_CLOSE': AgentSpec(
                agent_type='AUTO_CLOSE',
                capabilities=[
                    AgentCapability.TICKET_MANAGEMENT,
                    AgentCapability.CUSTOMER_SERVICE
                ],
                model_tier='sonnet',
                max_concurrent_tasks=5,
                specialized_instructions="Specialized in ticket resolution and customer support"
            ),
            'SOCIAL_MEDIA': AgentSpec(
                agent_type='SOCIAL_MEDIA',
                capabilities=[
                    AgentCapability.CONTENT_MODERATION,
                    AgentCapability.CUSTOMER_SERVICE
                ],
                model_tier='sonnet',
                max_concurrent_tasks=3,
                specialized_instructions="Specialized in social media management and moderation"
            ),
            'DATA_ENTRY': AgentSpec(
                agent_type='DATA_ENTRY',
                capabilities=[
                    AgentCapability.DATA_ENTRY,
                    AgentCapability.GENERAL_PURPOSE
                ],
                model_tier='haiku',
                max_concurrent_tasks=10,
                specialized_instructions="Specialized in data entry and form filling"
            ),
            'RESEARCH': AgentSpec(
                agent_type='RESEARCH',
                capabilities=[
                    AgentCapability.RESEARCH,
                    AgentCapability.GENERAL_PURPOSE
                ],
                model_tier='opus',
                max_concurrent_tasks=2,
                specialized_instructions="Specialized in deep research and analysis"
            ),
            'GENERAL': AgentSpec(
                agent_type='GENERAL',
                capabilities=[AgentCapability.GENERAL_PURPOSE],
                model_tier='sonnet',
                max_concurrent_tasks=3
            )
        }

    # Agent Spec Management

    def register_agent_spec(self, spec: AgentSpec):
        """Register an agent specification"""
        self._agent_specs[spec.agent_type] = spec
        logger.info(f"Registered agent spec: {spec.agent_type}")

    def get_agent_spec(self, agent_type: str) -> Optional[AgentSpec]:
        """Get an agent specification"""
        return self._agent_specs.get(agent_type)

    # Pool Management

    def create_pool(
        self,
        name: str,
        agent_type: str,
        min_agents: int = 1,
        max_agents: int = 10,
        department: str = "",
        budget_limit: float = 1000.0,
        strategy: AgentPoolStrategy = AgentPoolStrategy.DEMAND
    ) -> Optional[AgentPool]:
        """Create an agent pool"""
        spec = self._agent_specs.get(agent_type)
        if not spec:
            logger.error(f"Unknown agent type: {agent_type}")
            return None

        pool = AgentPool(
            pool_id=str(uuid.uuid4())[:8],
            name=name,
            description=f"Pool for {agent_type} agents",
            agent_spec=spec,
            min_agents=min_agents,
            max_agents=max_agents,
            department=department,
            budget_limit=budget_limit,
            strategy=strategy
        )

        self._pools[pool.pool_id] = pool
        logger.info(f"Created pool '{name}' ({pool.pool_id}) for {agent_type}")

        # Spin up minimum agents
        asyncio.create_task(self._ensure_minimum_agents(pool))

        return pool

    async def _ensure_minimum_agents(self, pool: AgentPool):
        """Ensure pool has minimum number of agents"""
        while pool.current_size < pool.min_agents:
            await self._create_agent(pool)

    async def _create_agent(self, pool: AgentPool) -> Optional[FleetAgent]:
        """Create a new agent in a pool"""
        if pool.current_size >= pool.max_agents:
            return None

        agent = FleetAgent(
            agent_id=str(uuid.uuid4())[:8],
            spec=pool.agent_spec,
            pool_id=pool.pool_id
        )

        pool.agents[agent.agent_id] = agent
        self._stats['total_agents_created'] += 1

        logger.info(f"Created agent {agent.agent_id} in pool {pool.pool_id}")

        # Warm up period
        await asyncio.sleep(pool.agent_spec.warm_up_seconds)
        agent.status = AgentStatus.IDLE

        return agent

    async def _terminate_agent(self, pool: AgentPool, agent: FleetAgent):
        """Terminate an agent"""
        if agent.current_tasks:
            logger.warning(f"Cannot terminate agent {agent.agent_id} with active tasks")
            return

        agent.status = AgentStatus.STOPPING

        # Cool down period
        await asyncio.sleep(pool.agent_spec.cool_down_seconds)

        if agent.agent_id in pool.agents:
            del pool.agents[agent.agent_id]
            self._stats['total_agents_terminated'] += 1
            logger.info(f"Terminated agent {agent.agent_id}")

    def get_pool(self, pool_id: str) -> Optional[AgentPool]:
        """Get a pool by ID"""
        return self._pools.get(pool_id)

    def list_pools(self, department: str = None) -> List[AgentPool]:
        """List all pools, optionally filtered by department"""
        pools = list(self._pools.values())
        if department:
            pools = [p for p in pools if p.department == department]
        return pools

    # Business Unit Management

    def create_business_unit(
        self,
        name: str,
        department: str,
        budget_daily: float = 500.0,
        max_concurrent_agents: int = 20,
        owner: str = ""
    ) -> BusinessUnit:
        """Create a business unit"""
        unit = BusinessUnit(
            unit_id=str(uuid.uuid4())[:8],
            name=name,
            department=department,
            max_concurrent_agents=max_concurrent_agents,
            owner=owner,
            budget=BudgetManager(
                daily_budget=budget_daily,
                hourly_budget=budget_daily / 8,
                per_task_budget=budget_daily / 100
            )
        )

        self._business_units[unit.unit_id] = unit
        logger.info(f"Created business unit '{name}' ({unit.unit_id})")

        return unit

    def assign_pool_to_unit(self, pool_id: str, unit_id: str) -> bool:
        """Assign a pool to a business unit"""
        pool = self._pools.get(pool_id)
        unit = self._business_units.get(unit_id)

        if not pool or not unit:
            return False

        if pool_id not in unit.pools:
            unit.pools.append(pool_id)
            pool.department = unit.department

        logger.info(f"Assigned pool {pool_id} to unit {unit_id}")
        return True

    def get_business_unit(self, unit_id: str) -> Optional[BusinessUnit]:
        """Get a business unit"""
        return self._business_units.get(unit_id)

    def list_business_units(self) -> List[BusinessUnit]:
        """List all business units"""
        return list(self._business_units.values())

    # Task Assignment

    async def submit_task(
        self,
        instruction: str,
        agent_type: str = None,
        pool_id: str = None,
        business_unit: str = None,
        capabilities: List[AgentCapability] = None,
        priority: int = 5,
        timeout_seconds: int = 3600,
        correlation_id: str = None
    ) -> Optional[TaskAssignment]:
        """
        Submit a task to the fleet.
        Will be routed to the best available agent.
        """
        # Find appropriate pool
        pool = None

        if pool_id:
            pool = self._pools.get(pool_id)
        elif agent_type:
            # Find pool with matching agent type
            for p in self._pools.values():
                if p.agent_spec.agent_type == agent_type:
                    pool = p
                    break
        elif capabilities:
            # Find pool with matching capabilities
            for p in self._pools.values():
                if all(cap in p.agent_spec.capabilities for cap in capabilities):
                    pool = p
                    break

        if not pool:
            # Use first available pool
            if self._pools:
                pool = list(self._pools.values())[0]
            else:
                logger.error("No pools available")
                return None

        # Check business unit constraints
        if business_unit:
            unit = self._business_units.get(business_unit)
            if unit:
                can_start, reason = unit.can_start_task()
                if not can_start:
                    logger.warning(f"Business unit constraint: {reason}")
                    return None

        # Select agent
        agent = self._load_balancer.select_agent(pool, capabilities)

        if not agent:
            # Queue the task for later
            task = TaskAssignment(
                task_id=str(uuid.uuid4())[:8],
                agent_id="",
                pool_id=pool.pool_id,
                instruction=instruction,
                priority=priority,
                timeout_seconds=timeout_seconds,
                business_unit=business_unit or "",
                correlation_id=correlation_id
            )
            self._pending_tasks[task.task_id] = task
            logger.info(f"Task {task.task_id} queued (no available agents)")

            # Trigger scaling evaluation
            asyncio.create_task(self._evaluate_scaling(pool))

            return task

        # Create and assign task
        task = TaskAssignment(
            task_id=str(uuid.uuid4())[:8],
            agent_id=agent.agent_id,
            pool_id=pool.pool_id,
            instruction=instruction,
            priority=priority,
            timeout_seconds=timeout_seconds,
            business_unit=business_unit or "",
            correlation_id=correlation_id,
            status="assigned"
        )

        # Update agent state
        agent.current_tasks.append(task.task_id)
        if agent.status == AgentStatus.IDLE:
            agent.status = AgentStatus.RUNNING

        self._active_tasks[task.task_id] = task
        self._stats['total_tasks_assigned'] += 1

        logger.info(f"Task {task.task_id} assigned to agent {agent.agent_id}")

        # Start task execution
        asyncio.create_task(self._execute_task(task, agent, pool))

        return task

    async def _execute_task(
        self,
        task: TaskAssignment,
        agent: FleetAgent,
        pool: AgentPool
    ):
        """Execute a task on an agent"""
        task.status = "running"
        task.started_at = datetime.utcnow()
        agent.last_task_at = datetime.utcnow()

        try:
            # Execute with timeout
            if self._agent_factory:
                result = await asyncio.wait_for(
                    self._agent_factory(
                        agent_type=agent.spec.agent_type,
                        agent_id=agent.agent_id,
                        instruction=task.instruction
                    ),
                    timeout=task.timeout_seconds
                )
                task.result = {'output': result}
            else:
                # Simulated execution
                await asyncio.sleep(1)  # Simulate work
                task.result = {'output': 'simulated_result'}

            task.status = "completed"
            agent.tasks_completed += 1
            self._stats['total_tasks_completed'] += 1
            logger.info(f"Task {task.task_id} completed")

        except asyncio.TimeoutError:
            task.status = "timeout"
            task.error = "Task timed out"
            agent.tasks_failed += 1
            self._stats['total_tasks_failed'] += 1
            logger.warning(f"Task {task.task_id} timed out")

        except Exception as e:
            task.status = "failed"
            task.error = str(e)
            agent.tasks_failed += 1
            self._stats['total_tasks_failed'] += 1
            logger.error(f"Task {task.task_id} failed: {e}")

        finally:
            task.completed_at = datetime.utcnow()

            # Update agent state
            if task.task_id in agent.current_tasks:
                agent.current_tasks.remove(task.task_id)

            if not agent.current_tasks:
                agent.status = AgentStatus.IDLE

            # Calculate runtime
            if task.started_at:
                runtime = (task.completed_at - task.started_at).total_seconds()
                agent.total_runtime_seconds += runtime

                # Update cost
                cost = (runtime / 3600) * agent.spec.cost_per_hour
                pool.daily_spend += cost

            # Move to completed
            if task.task_id in self._active_tasks:
                del self._active_tasks[task.task_id]
            self._completed_tasks.append(task)

            # Keep last 1000 completed tasks
            self._completed_tasks = self._completed_tasks[-1000:]

            # Process pending tasks
            await self._process_pending_tasks(pool)

    async def _process_pending_tasks(self, pool: AgentPool):
        """Process pending tasks for a pool"""
        pending_for_pool = [
            t for t in self._pending_tasks.values()
            if t.pool_id == pool.pool_id
        ]

        # Sort by priority
        pending_for_pool.sort(key=lambda t: t.priority, reverse=True)

        for task in pending_for_pool:
            agent = self._load_balancer.select_agent(pool)
            if not agent:
                break

            # Assign task
            task.agent_id = agent.agent_id
            task.status = "assigned"

            agent.current_tasks.append(task.task_id)
            if agent.status == AgentStatus.IDLE:
                agent.status = AgentStatus.RUNNING

            del self._pending_tasks[task.task_id]
            self._active_tasks[task.task_id] = task

            logger.info(f"Pending task {task.task_id} assigned to agent {agent.agent_id}")

            asyncio.create_task(self._execute_task(task, agent, pool))

    async def _evaluate_scaling(self, pool: AgentPool):
        """Evaluate and apply scaling for a pool"""
        pending_count = sum(
            1 for t in self._pending_tasks.values()
            if t.pool_id == pool.pool_id
        )

        action = await self._auto_scaler.evaluate_scaling(pool, pending_count)

        if action:
            action_type, count = action

            if action_type == 'scale_up':
                for _ in range(count):
                    await self._create_agent(pool)
                pool.last_scale_action = datetime.utcnow()
                logger.info(f"Scaled up pool {pool.pool_id} by {count} agents")

            elif action_type == 'scale_down':
                # Find idle agents to terminate
                idle_agents = [
                    a for a in pool.agents.values()
                    if a.status == AgentStatus.IDLE and not a.current_tasks
                ]

                for agent in idle_agents[:count]:
                    await self._terminate_agent(pool, agent)

                pool.last_scale_action = datetime.utcnow()
                logger.info(f"Scaled down pool {pool.pool_id} by {count} agents")

    # Task Management

    def get_task(self, task_id: str) -> Optional[TaskAssignment]:
        """Get a task by ID"""
        return (
            self._pending_tasks.get(task_id) or
            self._active_tasks.get(task_id) or
            next((t for t in self._completed_tasks if t.task_id == task_id), None)
        )

    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task status"""
        task = self.get_task(task_id)
        if not task:
            return None

        return {
            'task_id': task.task_id,
            'status': task.status,
            'agent_id': task.agent_id,
            'created_at': task.created_at.isoformat(),
            'started_at': task.started_at.isoformat() if task.started_at else None,
            'completed_at': task.completed_at.isoformat() if task.completed_at else None,
            'result': task.result,
            'error': task.error
        }

    def list_tasks(
        self,
        status: str = None,
        pool_id: str = None,
        limit: int = 100
    ) -> List[TaskAssignment]:
        """List tasks with optional filters"""
        all_tasks = (
            list(self._pending_tasks.values()) +
            list(self._active_tasks.values()) +
            self._completed_tasks
        )

        if status:
            all_tasks = [t for t in all_tasks if t.status == status]

        if pool_id:
            all_tasks = [t for t in all_tasks if t.pool_id == pool_id]

        return all_tasks[-limit:]

    # Fleet Operations

    async def start(self):
        """Start the fleet manager"""
        if self._running:
            return

        self._running = True

        # Start background tasks
        self._background_tasks = [
            asyncio.create_task(self._health_check_loop()),
            asyncio.create_task(self._scaling_loop()),
            asyncio.create_task(self._metrics_loop())
        ]

        logger.info("Fleet manager started")

    async def stop(self):
        """Stop the fleet manager"""
        self._running = False

        # Cancel background tasks
        for task in self._background_tasks:
            task.cancel()

        # Wait for tasks to complete
        await asyncio.gather(*self._background_tasks, return_exceptions=True)

        # Terminate all agents
        for pool in self._pools.values():
            for agent in list(pool.agents.values()):
                agent.status = AgentStatus.STOPPING

        logger.info("Fleet manager stopped")

    async def _health_check_loop(self):
        """Background health check loop"""
        while self._running:
            try:
                for pool in self._pools.values():
                    for agent in pool.agents.values():
                        # Update health score based on success rate and activity
                        agent.health_score = min(1.0, agent.success_rate)

                        # Check for stale agents
                        if agent.last_task_at:
                            idle_time = (datetime.utcnow() - agent.last_task_at).total_seconds()
                            if idle_time > 3600 and agent.status == AgentStatus.IDLE:
                                # Agent has been idle for too long
                                agent.health_score *= 0.9

                await asyncio.sleep(60)  # Check every minute

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Health check error: {e}")

    async def _scaling_loop(self):
        """Background scaling evaluation loop"""
        while self._running:
            try:
                for pool in self._pools.values():
                    await self._evaluate_scaling(pool)

                await asyncio.sleep(30)  # Evaluate every 30 seconds

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Scaling loop error: {e}")

    async def _metrics_loop(self):
        """Background metrics collection loop"""
        while self._running:
            try:
                # Aggregate metrics
                total_agents = sum(p.current_size for p in self._pools.values())
                total_capacity = sum(
                    sum(a.spec.max_concurrent_tasks for a in p.agents.values())
                    for p in self._pools.values()
                )
                total_tasks = sum(
                    sum(len(a.current_tasks) for a in p.agents.values())
                    for p in self._pools.values()
                )

                logger.debug(
                    f"Fleet metrics: {total_agents} agents, "
                    f"{total_tasks}/{total_capacity} capacity, "
                    f"{len(self._pending_tasks)} pending"
                )

                await asyncio.sleep(60)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Metrics loop error: {e}")

    # Statistics and Reporting

    def get_stats(self) -> Dict[str, Any]:
        """Get fleet statistics"""
        total_agents = sum(p.current_size for p in self._pools.values())
        total_capacity = sum(p.available_capacity for p in self._pools.values())

        return {
            **self._stats,
            'pools': len(self._pools),
            'business_units': len(self._business_units),
            'total_agents': total_agents,
            'total_capacity': total_capacity,
            'pending_tasks': len(self._pending_tasks),
            'active_tasks': len(self._active_tasks),
            'pools_summary': [p.to_dict() for p in self._pools.values()]
        }

    def get_fleet_dashboard(self) -> Dict[str, Any]:
        """Get dashboard data for the fleet"""
        return {
            'overview': self.get_stats(),
            'pools': {
                p.pool_id: {
                    **p.to_dict(),
                    'agents': [a.to_dict() for a in p.agents.values()]
                }
                for p in self._pools.values()
            },
            'business_units': {
                u.unit_id: u.to_dict()
                for u in self._business_units.values()
            },
            'recent_tasks': [
                self.get_task_status(t.task_id)
                for t in self._completed_tasks[-20:]
            ]
        }


def get_fleet_manager(
    storage_dir: str = "/tmp/agent_fleet",
    agent_factory: Callable = None
) -> FleetManager:
    """Get or create the fleet manager singleton"""
    if not hasattr(get_fleet_manager, '_instance'):
        get_fleet_manager._instance = FleetManager(
            storage_dir=storage_dir,
            agent_factory=agent_factory
        )
    return get_fleet_manager._instance
