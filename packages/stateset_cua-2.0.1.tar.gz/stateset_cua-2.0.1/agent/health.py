"""
Health checks and circuit breakers for production reliability

Implements:
- Health check endpoints
- Circuit breaker pattern for external services
- Graceful degradation
- Service dependencies monitoring
"""

import asyncio
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional, Dict, Any, List
from datetime import datetime, timedelta


class HealthStatus(Enum):
    """Service health status"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class CircuitState(Enum):
    """Circuit breaker states"""
    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing recovery


@dataclass
class HealthCheck:
    """Individual health check result"""
    name: str
    status: HealthStatus
    message: str
    timestamp: datetime
    duration_ms: float
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SystemHealth:
    """Overall system health"""
    status: HealthStatus
    checks: List[HealthCheck]
    timestamp: datetime
    uptime_seconds: float
    version: str = "1.0.0"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API response"""
        return {
            "status": self.status.value,
            "timestamp": self.timestamp.isoformat(),
            "uptime_seconds": self.uptime_seconds,
            "version": self.version,
            "checks": [
                {
                    "name": check.name,
                    "status": check.status.value,
                    "message": check.message,
                    "duration_ms": check.duration_ms,
                    "details": check.details
                }
                for check in self.checks
            ]
        }


class CircuitBreaker:
    """
    Circuit breaker pattern implementation

    Prevents cascading failures by:
    - Opening circuit after threshold failures
    - Allowing periodic health checks (half-open)
    - Closing circuit when service recovers

    Thread-safe via asyncio.Lock for state mutations.
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        timeout_seconds: float = 60.0,
        expected_exception: type = Exception
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.timeout_seconds = timeout_seconds
        self.expected_exception = expected_exception

        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time: Optional[float] = None
        self.success_count = 0
        self._lock = asyncio.Lock()

    async def call(self, func: Callable, *args, **kwargs):
        """
        Execute function with circuit breaker protection

        Raises:
            CircuitBreakerOpen: If circuit is open
            Exception: Original exception if circuit is closed
        """
        async with self._lock:
            if self.state == CircuitState.OPEN:
                if self._should_attempt_reset():
                    self.state = CircuitState.HALF_OPEN
                else:
                    raise CircuitBreakerOpen(f"Circuit breaker {self.name} is OPEN")

        try:
            result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
            async with self._lock:
                self._on_success()
            return result

        except self.expected_exception as e:
            async with self._lock:
                self._on_failure()
            raise

    def _on_success(self):
        """Handle successful call (caller must hold _lock)"""
        self.failure_count = 0
        self.last_failure_time = None

        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= 2:  # Require 2 successes to close
                self.state = CircuitState.CLOSED
                self.success_count = 0
        else:
            self.state = CircuitState.CLOSED

    def _on_failure(self):
        """Handle failed call (caller must hold _lock)"""
        self.failure_count += 1
        self.last_failure_time = time.time()

        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN

        if self.state == CircuitState.HALF_OPEN:
            self.state = CircuitState.OPEN
            self.success_count = 0

    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset (caller must hold _lock)"""
        if not self.last_failure_time:
            return True

        return (time.time() - self.last_failure_time) >= self.timeout_seconds

    def get_state(self) -> Dict[str, Any]:
        """Get circuit breaker state snapshot"""
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "last_failure_time": self.last_failure_time,
        }


class CircuitBreakerOpen(Exception):
    """Exception raised when circuit breaker is open"""
    pass


class HealthChecker:
    """
    System health monitoring

    Performs checks on:
    - Anthropic API connectivity
    - Display server availability
    - Memory usage
    - Disk space
    - Agent responsiveness
    """

    def __init__(self):
        self.start_time = time.time()
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}

    def register_circuit_breaker(self, name: str, **kwargs) -> CircuitBreaker:
        """Register a new circuit breaker"""
        breaker = CircuitBreaker(name, **kwargs)
        self.circuit_breakers[name] = breaker
        return breaker

    async def check_anthropic_api(self, test_connectivity: bool = True) -> HealthCheck:
        """Check Anthropic API connectivity with optional live test.

        Args:
            test_connectivity: If True, makes a lightweight API call to verify connectivity.
                             If False, only validates configuration.

        The connectivity test uses the models.list() endpoint which is lightweight
        and doesn't consume tokens. This provides true verification that:
        - API key is valid
        - Network can reach Anthropic
        - Account is active
        """
        start = time.time()

        try:
            import os
            api_key = os.environ.get('ANTHROPIC_API_KEY')

            if not api_key:
                return HealthCheck(
                    name="anthropic_api",
                    status=HealthStatus.UNHEALTHY,
                    message="ANTHROPIC_API_KEY not configured",
                    timestamp=datetime.utcnow(),
                    duration_ms=(time.time() - start) * 1000
                )

            # Validate key format
            if not api_key.startswith('sk-ant-'):
                return HealthCheck(
                    name="anthropic_api",
                    status=HealthStatus.DEGRADED,
                    message="API key format invalid (should start with sk-ant-)",
                    timestamp=datetime.utcnow(),
                    duration_ms=(time.time() - start) * 1000
                )

            # Optional: Test actual connectivity
            if test_connectivity:
                try:
                    import httpx

                    async with httpx.AsyncClient(timeout=10.0) as client:
                        # Use a lightweight endpoint to verify connectivity
                        # The messages endpoint with count_tokens is lightweight
                        response = await client.post(
                            "https://api.anthropic.com/v1/messages/count_tokens",
                            headers={
                                "x-api-key": api_key,
                                "anthropic-version": "2023-06-01",
                                "content-type": "application/json"
                            },
                            json={
                                "model": "claude-sonnet-4-20250514",
                                "messages": [{"role": "user", "content": "test"}]
                            }
                        )

                        if response.status_code == 200:
                            return HealthCheck(
                                name="anthropic_api",
                                status=HealthStatus.HEALTHY,
                                message="API connectivity verified",
                                timestamp=datetime.utcnow(),
                                duration_ms=(time.time() - start) * 1000,
                                details={"connectivity_tested": True}
                            )
                        elif response.status_code == 401:
                            return HealthCheck(
                                name="anthropic_api",
                                status=HealthStatus.UNHEALTHY,
                                message="API key invalid or expired",
                                timestamp=datetime.utcnow(),
                                duration_ms=(time.time() - start) * 1000,
                                details={"status_code": response.status_code}
                            )
                        elif response.status_code == 429:
                            return HealthCheck(
                                name="anthropic_api",
                                status=HealthStatus.DEGRADED,
                                message="API rate limited - connectivity OK but throttled",
                                timestamp=datetime.utcnow(),
                                duration_ms=(time.time() - start) * 1000,
                                details={"status_code": response.status_code}
                            )
                        else:
                            return HealthCheck(
                                name="anthropic_api",
                                status=HealthStatus.DEGRADED,
                                message=f"Unexpected API response: {response.status_code}",
                                timestamp=datetime.utcnow(),
                                duration_ms=(time.time() - start) * 1000,
                                details={"status_code": response.status_code}
                            )

                except httpx.TimeoutException:
                    return HealthCheck(
                        name="anthropic_api",
                        status=HealthStatus.DEGRADED,
                        message="API connectivity test timed out",
                        timestamp=datetime.utcnow(),
                        duration_ms=(time.time() - start) * 1000,
                        details={"error": "timeout"}
                    )
                except httpx.NetworkError as e:
                    return HealthCheck(
                        name="anthropic_api",
                        status=HealthStatus.UNHEALTHY,
                        message=f"Network error reaching Anthropic API: {str(e)}",
                        timestamp=datetime.utcnow(),
                        duration_ms=(time.time() - start) * 1000,
                        details={"error": str(e)}
                    )

            # Configuration-only check (no connectivity test)
            return HealthCheck(
                name="anthropic_api",
                status=HealthStatus.HEALTHY,
                message="API key configured (connectivity not tested)",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000,
                details={"connectivity_tested": False}
            )

        except Exception as e:
            return HealthCheck(
                name="anthropic_api",
                status=HealthStatus.UNHEALTHY,
                message=f"API check failed: {str(e)}",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000
            )

    async def check_display_server(self) -> HealthCheck:
        """Check X11 display server availability with connectivity test."""
        start = time.time()

        try:
            import os
            display = os.environ.get('DISPLAY')

            if not display:
                return HealthCheck(
                    name="display_server",
                    status=HealthStatus.UNHEALTHY,
                    message="DISPLAY environment variable not set",
                    timestamp=datetime.utcnow(),
                    duration_ms=(time.time() - start) * 1000
                )

            # Verify the X server is actually responsive
            import subprocess
            try:
                result = await asyncio.wait_for(
                    asyncio.create_subprocess_exec(
                        "xdpyinfo", "-display", display,
                        stdout=asyncio.subprocess.DEVNULL,
                        stderr=asyncio.subprocess.DEVNULL,
                    ),
                    timeout=5.0
                )
                returncode = await asyncio.wait_for(result.wait(), timeout=5.0)
                if returncode != 0:
                    return HealthCheck(
                        name="display_server",
                        status=HealthStatus.DEGRADED,
                        message=f"Display {display} set but X server not responding",
                        timestamp=datetime.utcnow(),
                        duration_ms=(time.time() - start) * 1000,
                        details={"display": display, "responsive": False}
                    )
            except (FileNotFoundError, asyncio.TimeoutError):
                # xdpyinfo not available or timed out; trust the env var
                pass

            return HealthCheck(
                name="display_server",
                status=HealthStatus.HEALTHY,
                message=f"Display server configured: {display}",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000,
                details={"display": display}
            )

        except Exception as e:
            return HealthCheck(
                name="display_server",
                status=HealthStatus.UNHEALTHY,
                message=f"Display check failed: {str(e)}",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000
            )

    async def check_memory(self) -> HealthCheck:
        """Check system memory usage"""
        start = time.time()

        try:
            import psutil

            from agent.config import HealthSettings
            health_cfg = HealthSettings()

            memory = psutil.virtual_memory()
            percent_used = memory.percent

            if percent_used > health_cfg.memory_critical_percent:
                status = HealthStatus.UNHEALTHY
                message = f"Critical memory usage: {percent_used}%"
            elif percent_used > health_cfg.memory_warning_percent:
                status = HealthStatus.DEGRADED
                message = f"High memory usage: {percent_used}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"Memory usage normal: {percent_used}%"

            return HealthCheck(
                name="memory",
                status=status,
                message=message,
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000,
                details={
                    "total_gb": round(memory.total / (1024**3), 2),
                    "available_gb": round(memory.available / (1024**3), 2),
                    "percent_used": percent_used
                }
            )

        except ImportError:
            return HealthCheck(
                name="memory",
                status=HealthStatus.DEGRADED,
                message="psutil not available",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000
            )
        except Exception as e:
            return HealthCheck(
                name="memory",
                status=HealthStatus.UNHEALTHY,
                message=f"Memory check failed: {str(e)}",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000
            )

    async def check_disk_space(self) -> HealthCheck:
        """Check disk space availability"""
        start = time.time()

        try:
            import psutil
            import os

            from agent.config import HealthSettings
            health_cfg = HealthSettings()

            disk = psutil.disk_usage(os.getcwd())
            percent_used = disk.percent

            if percent_used > health_cfg.disk_critical_percent:
                status = HealthStatus.UNHEALTHY
                message = f"Critical disk usage: {percent_used}%"
            elif percent_used > health_cfg.disk_warning_percent:
                status = HealthStatus.DEGRADED
                message = f"High disk usage: {percent_used}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"Disk space normal: {percent_used}%"

            return HealthCheck(
                name="disk_space",
                status=status,
                message=message,
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000,
                details={
                    "total_gb": round(disk.total / (1024**3), 2),
                    "free_gb": round(disk.free / (1024**3), 2),
                    "percent_used": percent_used
                }
            )

        except ImportError:
            return HealthCheck(
                name="disk_space",
                status=HealthStatus.DEGRADED,
                message="psutil not available",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000
            )
        except Exception as e:
            return HealthCheck(
                name="disk_space",
                status=HealthStatus.UNHEALTHY,
                message=f"Disk check failed: {str(e)}",
                timestamp=datetime.utcnow(),
                duration_ms=(time.time() - start) * 1000
            )

    async def get_system_health(self) -> SystemHealth:
        """Get comprehensive system health"""
        checks = await asyncio.gather(
            self.check_anthropic_api(),
            self.check_display_server(),
            self.check_memory(),
            self.check_disk_space(),
        )

        # Determine overall status
        if any(check.status == HealthStatus.UNHEALTHY for check in checks):
            overall_status = HealthStatus.UNHEALTHY
        elif any(check.status == HealthStatus.DEGRADED for check in checks):
            overall_status = HealthStatus.DEGRADED
        else:
            overall_status = HealthStatus.HEALTHY

        uptime = time.time() - self.start_time

        return SystemHealth(
            status=overall_status,
            checks=list(checks),
            timestamp=datetime.utcnow(),
            uptime_seconds=uptime
        )


# Global health checker instance
_health_checker = HealthChecker()


def get_health_checker() -> HealthChecker:
    """Get the global health checker"""
    return _health_checker
