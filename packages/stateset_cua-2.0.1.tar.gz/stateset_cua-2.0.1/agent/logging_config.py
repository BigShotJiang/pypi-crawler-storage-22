"""
Centralized logging configuration for StateSet Computer Use Agent.

This module provides:
1. Unified StructuredLogger factory with automatic context injection
2. Request ID propagation for distributed tracing
3. JSON-formatted logs for production environments
4. Human-readable logs for development
5. Log level configuration based on environment

Usage:
    from agent.logging_config import get_logger, set_request_id, get_request_id

    logger = get_logger(__name__, agent_type="AUTO_CLOSE")
    logger.info("Task started", task_id="123", tokens=1500)

    # Set request ID for tracing
    with request_context(request_id="req-abc-123"):
        logger.info("Processing request")  # Automatically includes request_id
"""

import contextvars
import json
import logging
import logging.handlers
import os
import sys
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional


# Context variables for request tracing
_request_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "request_id", default=None
)
_agent_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "agent_id", default=None
)
_agent_type: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "agent_type", default=None
)


class LogFormat(Enum):
    """Log output formats"""
    JSON = "json"
    HUMAN = "human"
    COMPACT = "compact"


@dataclass
class LogConfig:
    """Logging configuration"""
    level: int = logging.INFO
    format: LogFormat = LogFormat.JSON
    include_timestamp: bool = True
    include_trace: bool = True
    output_file: Optional[str] = None
    # Log rotation settings
    max_file_size_mb: int = 50  # Max size before rotation (in MB)
    backup_count: int = 5  # Number of backup files to keep
    rotate_at_midnight: bool = False  # Alternative: rotate daily at midnight

    @classmethod
    def from_environment(cls) -> "LogConfig":
        """Create config from environment variables"""
        level_name = os.environ.get("LOG_LEVEL", "INFO").upper()
        level = getattr(logging, level_name, logging.INFO)

        format_name = os.environ.get("LOG_FORMAT", "json").lower()
        try:
            log_format = LogFormat(format_name)
        except ValueError:
            log_format = LogFormat.JSON

        return cls(
            level=level,
            format=log_format,
            include_timestamp=os.environ.get("LOG_TIMESTAMP", "true").lower() == "true",
            include_trace=os.environ.get("LOG_TRACE", "true").lower() == "true",
            output_file=os.environ.get("LOG_FILE"),
            max_file_size_mb=int(os.environ.get("LOG_MAX_SIZE_MB", "50")),
            backup_count=int(os.environ.get("LOG_BACKUP_COUNT", "5")),
            rotate_at_midnight=os.environ.get("LOG_ROTATE_DAILY", "false").lower() == "true",
        )


# Global configuration
_config: Optional[LogConfig] = None


def get_config() -> LogConfig:
    """Get current logging configuration"""
    global _config
    if _config is None:
        _config = LogConfig.from_environment()
    return _config


def configure_logging(config: Optional[LogConfig] = None):
    """
    Configure the logging system.

    Call this once at application startup to set up logging.
    """
    global _config
    _config = config or LogConfig.from_environment()

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(_config.level)

    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Add appropriate handler based on format
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(_config.level)

    if _config.format == LogFormat.JSON:
        handler.setFormatter(JsonFormatter())
    elif _config.format == LogFormat.HUMAN:
        handler.setFormatter(HumanFormatter())
    else:
        handler.setFormatter(CompactFormatter())

    root_logger.addHandler(handler)

    # Add file handler with rotation if configured
    if _config.output_file:
        if _config.rotate_at_midnight:
            # Rotate at midnight, keep backup_count days
            file_handler = logging.handlers.TimedRotatingFileHandler(
                _config.output_file,
                when="midnight",
                interval=1,
                backupCount=_config.backup_count,
                encoding="utf-8",
            )
        else:
            # Rotate based on file size
            max_bytes = _config.max_file_size_mb * 1024 * 1024
            file_handler = logging.handlers.RotatingFileHandler(
                _config.output_file,
                maxBytes=max_bytes,
                backupCount=_config.backup_count,
                encoding="utf-8",
            )
        file_handler.setLevel(_config.level)
        file_handler.setFormatter(JsonFormatter())  # Always JSON for files
        root_logger.addHandler(file_handler)


class JsonFormatter(logging.Formatter):
    """JSON log formatter for production environments"""

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Add context from context variables
        request_id = _request_id.get()
        if request_id:
            log_entry["request_id"] = request_id

        agent_id = _agent_id.get()
        if agent_id:
            log_entry["agent_id"] = agent_id

        agent_type = _agent_type.get()
        if agent_type:
            log_entry["agent_type"] = agent_type

        # Add extra fields from record
        if hasattr(record, "extra_fields"):
            log_entry.update(record.extra_fields)

        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        # Add source location for errors
        if record.levelno >= logging.ERROR:
            log_entry["source"] = {
                "file": record.pathname,
                "line": record.lineno,
                "function": record.funcName,
            }

        return json.dumps(log_entry, default=str)


class HumanFormatter(logging.Formatter):
    """Human-readable formatter for development"""

    COLORS = {
        "DEBUG": "\033[36m",     # Cyan
        "INFO": "\033[32m",      # Green
        "WARNING": "\033[33m",   # Yellow
        "ERROR": "\033[31m",     # Red
        "CRITICAL": "\033[35m",  # Magenta
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelname, "")
        reset = self.RESET if color else ""

        # Build timestamp
        timestamp = datetime.utcnow().strftime("%H:%M:%S.%f")[:-3]

        # Build context prefix
        context_parts = []
        agent_type = _agent_type.get() or getattr(record, "agent_type", None)
        if agent_type:
            context_parts.append(agent_type)
        request_id = _request_id.get()
        if request_id:
            context_parts.append(request_id[:8])
        context = f"[{' | '.join(context_parts)}] " if context_parts else ""

        # Format message
        message = record.getMessage()

        # Add extra fields
        extra_str = ""
        if hasattr(record, "extra_fields") and record.extra_fields:
            extra_parts = [f"{k}={v}" for k, v in record.extra_fields.items()]
            extra_str = f" | {', '.join(extra_parts)}"

        formatted = f"{timestamp} {color}{record.levelname:7}{reset} {context}{message}{extra_str}"

        if record.exc_info:
            formatted += "\n" + self.formatException(record.exc_info)

        return formatted


class CompactFormatter(logging.Formatter):
    """Compact formatter for minimal output"""

    def format(self, record: logging.LogRecord) -> str:
        level_char = record.levelname[0]
        agent_type = _agent_type.get() or getattr(record, "agent_type", "SYS")
        return f"[{level_char}][{agent_type}] {record.getMessage()}"


class StructuredLoggerAdapter(logging.LoggerAdapter):
    """
    Logger adapter that automatically injects context and supports structured fields.

    Usage:
        logger = get_logger(__name__)
        logger.info("Processing task", task_id="123", tokens=1500)
    """

    def __init__(
        self,
        logger: logging.Logger,
        agent_type: Optional[str] = None,
        agent_id: Optional[str] = None,
    ):
        super().__init__(logger, {})
        self._agent_type = agent_type
        self._agent_id = agent_id

    def process(self, msg: str, kwargs: Dict[str, Any]):
        # Extract extra fields from kwargs
        extra_fields = {}
        for key in list(kwargs.keys()):
            if key not in ("exc_info", "stack_info", "stacklevel", "extra"):
                extra_fields[key] = kwargs.pop(key)

        # Merge with existing extra
        extra = kwargs.get("extra", {})
        extra["extra_fields"] = extra_fields

        # Add agent context
        if self._agent_type:
            extra["agent_type"] = self._agent_type
        if self._agent_id:
            extra["agent_id"] = self._agent_id

        kwargs["extra"] = extra
        return msg, kwargs

    def bind(self, **kwargs) -> "StructuredLoggerAdapter":
        """Create a new logger with additional bound context"""
        new_logger = StructuredLoggerAdapter(
            self.logger,
            agent_type=kwargs.get("agent_type", self._agent_type),
            agent_id=kwargs.get("agent_id", self._agent_id),
        )
        return new_logger


# Logger cache
_loggers: Dict[str, StructuredLoggerAdapter] = {}


def get_logger(
    name: str,
    agent_type: Optional[str] = None,
    agent_id: Optional[str] = None,
) -> StructuredLoggerAdapter:
    """
    Get a structured logger instance.

    Args:
        name: Logger name (usually __name__)
        agent_type: Optional agent type for context
        agent_id: Optional agent ID for context

    Returns:
        StructuredLoggerAdapter with context support

    Usage:
        logger = get_logger(__name__, agent_type="AUTO_CLOSE")
        logger.info("Task started", task_id="123")
    """
    cache_key = f"{name}:{agent_type}:{agent_id}"

    if cache_key not in _loggers:
        base_logger = logging.getLogger(name)
        _loggers[cache_key] = StructuredLoggerAdapter(
            base_logger,
            agent_type=agent_type,
            agent_id=agent_id,
        )

    return _loggers[cache_key]


# ============================================================================
# Request ID Tracing
# ============================================================================

def generate_request_id() -> str:
    """Generate a new request ID"""
    return str(uuid.uuid4())


def set_request_id(request_id: str) -> contextvars.Token:
    """Set the current request ID"""
    return _request_id.set(request_id)


def get_request_id() -> Optional[str]:
    """Get the current request ID"""
    return _request_id.get()


def set_agent_context(
    agent_id: Optional[str] = None,
    agent_type: Optional[str] = None,
) -> tuple:
    """Set agent context for logging"""
    tokens = []
    if agent_id:
        tokens.append(_agent_id.set(agent_id))
    if agent_type:
        tokens.append(_agent_type.set(agent_type))
    return tuple(tokens)


def clear_agent_context(tokens: tuple):
    """Clear agent context"""
    for token in tokens:
        if token:
            try:
                token.var.reset(token)
            except ValueError:
                pass


@contextmanager
def request_context(
    request_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    agent_type: Optional[str] = None,
):
    """
    Context manager for request tracing.

    Usage:
        with request_context(request_id="req-123", agent_type="AUTO_CLOSE"):
            logger.info("Processing")  # Automatically includes request_id
    """
    if request_id is None:
        request_id = generate_request_id()

    # Set context
    request_token = _request_id.set(request_id)
    agent_id_token = _agent_id.set(agent_id) if agent_id else None
    agent_type_token = _agent_type.set(agent_type) if agent_type else None

    try:
        yield request_id
    finally:
        # Reset context
        _request_id.reset(request_token)
        if agent_id_token:
            _agent_id.reset(agent_id_token)
        if agent_type_token:
            _agent_type.reset(agent_type_token)


# ============================================================================
# Convenience Functions
# ============================================================================

def log_error(
    logger: StructuredLoggerAdapter,
    message: str,
    error: Exception,
    **kwargs
):
    """
    Log an error with full context.

    Usage:
        try:
            do_something()
        except Exception as e:
            log_error(logger, "Operation failed", e, operation="do_something")
    """
    kwargs["error_type"] = type(error).__name__
    kwargs["error_message"] = str(error)

    # Add AgentError context if available
    from agent.exceptions import AgentError
    if isinstance(error, AgentError):
        kwargs["error_category"] = error.category.value
        kwargs["error_retryable"] = error.retryable
        if error.context:
            kwargs["error_context"] = error.context.to_dict()

    logger.error(message, exc_info=True, **kwargs)


def log_metric(
    logger: StructuredLoggerAdapter,
    metric_name: str,
    value: float,
    unit: str = "",
    **kwargs
):
    """
    Log a metric value.

    Usage:
        log_metric(logger, "task_duration", 1.5, unit="seconds", task_id="123")
    """
    kwargs["metric_name"] = metric_name
    kwargs["metric_value"] = value
    if unit:
        kwargs["metric_unit"] = unit
    logger.info(f"METRIC: {metric_name}={value}{unit}", **kwargs)


def log_event(
    logger: StructuredLoggerAdapter,
    event_name: str,
    **kwargs
):
    """
    Log a structured event.

    Usage:
        log_event(logger, "task_completed", task_id="123", success=True)
    """
    kwargs["event"] = event_name
    logger.info(f"EVENT: {event_name}", **kwargs)


# Initialize logging on module import
configure_logging()
