"""
MCP (Model Context Protocol) Client Integration

Enables the agent to connect to external MCP servers and use their tools.
Supports stdio, SSE, and HTTP transport protocols.

Key Features:
- Connect to any MCP-compatible server (Slack, GitHub, databases, etc.)
- Automatic tool discovery and registration
- Resource access (files, data sources)
- Prompt templates from servers
- Connection pooling and lifecycle management

Example Usage:
    mcp_manager = MCPManager()

    # Add servers
    await mcp_manager.add_server("slack", {
        "command": "npx",
        "args": ["-y", "@anthropic/mcp-slack"],
        "env": {"SLACK_TOKEN": "xoxb-..."}
    })

    await mcp_manager.add_server("github", {
        "command": "npx",
        "args": ["-y", "@anthropic/mcp-github"],
        "env": {"GITHUB_TOKEN": "ghp_..."}
    })

    # Get tools for Claude
    tools = mcp_manager.get_all_tools()

    # Execute tool
    result = await mcp_manager.call_tool("slack", "send_message", {
        "channel": "#general",
        "text": "Hello from the agent!"
    })

Based on the Model Context Protocol specification.
"""

import asyncio
import json
import logging
import os
import subprocess
import sys
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union
import aiohttp

logger = logging.getLogger(__name__)


class MCPTransport(str, Enum):
    """Supported MCP transport protocols."""
    STDIO = "stdio"
    SSE = "sse"
    HTTP = "http"


@dataclass
class MCPServerConfig:
    """Configuration for an MCP server connection."""
    name: str
    transport: MCPTransport = MCPTransport.STDIO

    # For stdio transport
    command: Optional[str] = None
    args: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)

    # For SSE/HTTP transport
    url: Optional[str] = None
    headers: Dict[str, str] = field(default_factory=dict)

    # Connection settings
    timeout_seconds: float = 30.0
    auto_reconnect: bool = True
    max_retries: int = 3


@dataclass
class MCPTool:
    """Represents a tool exposed by an MCP server."""
    server_name: str
    name: str
    description: str
    input_schema: Dict[str, Any]

    @property
    def full_name(self) -> str:
        """Get the fully qualified tool name (mcp__server__tool)."""
        return f"mcp__{self.server_name}__{self.name}"

    def to_anthropic_tool(self) -> Dict[str, Any]:
        """Convert to Anthropic tool format."""
        return {
            "type": "custom",
            "name": self.full_name,
            "description": f"[MCP:{self.server_name}] {self.description}",
            "input_schema": self.input_schema
        }


@dataclass
class MCPResource:
    """Represents a resource exposed by an MCP server."""
    server_name: str
    uri: str
    name: str
    description: Optional[str] = None
    mime_type: Optional[str] = None


@dataclass
class MCPPrompt:
    """Represents a prompt template from an MCP server."""
    server_name: str
    name: str
    description: Optional[str] = None
    arguments: List[Dict[str, Any]] = field(default_factory=list)


class MCPConnection(ABC):
    """Abstract base class for MCP server connections."""

    def __init__(self, config: MCPServerConfig):
        self.config = config
        self.connected = False
        self.tools: List[MCPTool] = []
        self.resources: List[MCPResource] = []
        self.prompts: List[MCPPrompt] = []
        self._request_id = 0

    @abstractmethod
    async def connect(self) -> bool:
        """Establish connection to the MCP server."""
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """Close the connection."""
        pass

    @abstractmethod
    async def send_request(self, method: str, params: Optional[Dict] = None) -> Dict:
        """Send a JSON-RPC request to the server."""
        pass

    def _next_request_id(self) -> int:
        self._request_id += 1
        return self._request_id

    async def initialize(self) -> bool:
        """Initialize the MCP session and discover capabilities."""
        try:
            # Send initialize request
            result = await self.send_request("initialize", {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "roots": {"listChanged": True},
                    "sampling": {}
                },
                "clientInfo": {
                    "name": "stateset-agent",
                    "version": "1.0.0"
                }
            })

            # Send initialized notification
            await self.send_request("notifications/initialized", {})

            # Discover tools
            await self._discover_tools()

            # Discover resources
            await self._discover_resources()

            # Discover prompts
            await self._discover_prompts()

            self.connected = True
            return True

        except Exception as e:
            logger.error(f"Failed to initialize MCP connection to {self.config.name}: {e}")
            return False

    async def _discover_tools(self) -> None:
        """Discover available tools from the server."""
        try:
            result = await self.send_request("tools/list", {})
            self.tools = []
            for tool_data in result.get("tools", []):
                self.tools.append(MCPTool(
                    server_name=self.config.name,
                    name=tool_data["name"],
                    description=tool_data.get("description", ""),
                    input_schema=tool_data.get("inputSchema", {"type": "object", "properties": {}})
                ))
            logger.info(f"Discovered {len(self.tools)} tools from {self.config.name}")
        except Exception as e:
            logger.warning(f"Failed to discover tools from {self.config.name}: {e}")

    async def _discover_resources(self) -> None:
        """Discover available resources from the server."""
        try:
            result = await self.send_request("resources/list", {})
            self.resources = []
            for res_data in result.get("resources", []):
                self.resources.append(MCPResource(
                    server_name=self.config.name,
                    uri=res_data["uri"],
                    name=res_data["name"],
                    description=res_data.get("description"),
                    mime_type=res_data.get("mimeType")
                ))
            logger.info(f"Discovered {len(self.resources)} resources from {self.config.name}")
        except Exception as e:
            logger.debug(f"No resources from {self.config.name}: {e}")

    async def _discover_prompts(self) -> None:
        """Discover available prompt templates from the server."""
        try:
            result = await self.send_request("prompts/list", {})
            self.prompts = []
            for prompt_data in result.get("prompts", []):
                self.prompts.append(MCPPrompt(
                    server_name=self.config.name,
                    name=prompt_data["name"],
                    description=prompt_data.get("description"),
                    arguments=prompt_data.get("arguments", [])
                ))
            logger.info(f"Discovered {len(self.prompts)} prompts from {self.config.name}")
        except Exception as e:
            logger.debug(f"No prompts from {self.config.name}: {e}")

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool on the MCP server."""
        result = await self.send_request("tools/call", {
            "name": tool_name,
            "arguments": arguments
        })
        return result

    async def read_resource(self, uri: str) -> Dict[str, Any]:
        """Read a resource from the MCP server."""
        result = await self.send_request("resources/read", {
            "uri": uri
        })
        return result

    async def get_prompt(self, name: str, arguments: Optional[Dict] = None) -> Dict[str, Any]:
        """Get a prompt template from the MCP server."""
        result = await self.send_request("prompts/get", {
            "name": name,
            "arguments": arguments or {}
        })
        return result


class StdioMCPConnection(MCPConnection):
    """MCP connection over stdio (subprocess)."""

    _MAX_PENDING_REQUESTS = 100

    def __init__(self, config: MCPServerConfig):
        super().__init__(config)
        self.process: Optional[asyncio.subprocess.Process] = None
        self._pending_requests: Dict[int, asyncio.Future] = {}
        self._pending_lock = asyncio.Lock()
        self._reader_task: Optional[asyncio.Task] = None

    async def connect(self) -> bool:
        """Start the MCP server subprocess."""
        if not self.config.command:
            raise ValueError("Command required for stdio transport")

        # Merge environment
        env = os.environ.copy()
        env.update(self.config.env)

        try:
            self.process = await asyncio.create_subprocess_exec(
                self.config.command,
                *self.config.args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env
            )

            # Start reader task
            self._reader_task = asyncio.create_task(self._read_responses())

            # Initialize the connection
            return await self.initialize()

        except Exception as e:
            logger.error(f"Failed to start MCP server {self.config.name}: {e}")
            return False

    async def disconnect(self) -> None:
        """Stop the MCP server subprocess."""
        self.connected = False

        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass

        if self.process:
            self.process.terminate()
            try:
                await asyncio.wait_for(self.process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self.process.kill()

    async def send_request(self, method: str, params: Optional[Dict] = None) -> Dict:
        """Send a JSON-RPC request via stdio."""
        if not self.process or not self.process.stdin:
            raise RuntimeError("Not connected")

        request_id = self._next_request_id()
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params:
            request["params"] = params

        async with self._pending_lock:
            # Cleanup stale pending requests (prevent unbounded growth)
            if len(self._pending_requests) > self._MAX_PENDING_REQUESTS:
                stale = [rid for rid, f in self._pending_requests.items() if f.done()]
                for rid in stale:
                    del self._pending_requests[rid]

            # Create future for response
            future: asyncio.Future = asyncio.get_running_loop().create_future()
            self._pending_requests[request_id] = future

        # Send request
        request_str = json.dumps(request) + "\n"
        self.process.stdin.write(request_str.encode())
        await self.process.stdin.drain()

        # Wait for response
        try:
            response = await asyncio.wait_for(future, timeout=self.config.timeout_seconds)
            return response.get("result", {})
        except asyncio.TimeoutError:
            async with self._pending_lock:
                self._pending_requests.pop(request_id, None)
            raise TimeoutError(f"Request {method} timed out")

    async def _read_responses(self) -> None:
        """Read responses from the subprocess stdout."""
        if not self.process or not self.process.stdout:
            return

        try:
            while True:
                line = await self.process.stdout.readline()
                if not line:
                    break

                try:
                    response = json.loads(line.decode())
                    request_id = response.get("id")

                    if request_id:
                        async with self._pending_lock:
                            future = self._pending_requests.pop(request_id, None)
                        if future and not future.done():
                            if "error" in response:
                                future.set_exception(
                                    RuntimeError(response["error"].get("message", "Unknown error"))
                                )
                            else:
                                future.set_result(response)

                except json.JSONDecodeError:
                    continue

        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Error reading MCP responses: {e}")


class SSEMCPConnection(MCPConnection):
    """MCP connection over Server-Sent Events."""

    _MAX_PENDING_REQUESTS = 100

    def __init__(self, config: MCPServerConfig):
        super().__init__(config)
        self._session: Optional[aiohttp.ClientSession] = None
        self._pending_requests: Dict[int, asyncio.Future] = {}
        self._pending_lock = asyncio.Lock()
        self._reader_task: Optional[asyncio.Task] = None

    async def connect(self) -> bool:
        """Connect to the SSE endpoint."""
        if not self.config.url:
            raise ValueError("URL required for SSE transport")

        try:
            self._session = aiohttp.ClientSession(
                headers=self.config.headers,
                timeout=aiohttp.ClientTimeout(total=self.config.timeout_seconds)
            )

            # Start SSE reader
            self._reader_task = asyncio.create_task(self._read_sse())

            # Initialize
            return await self.initialize()

        except Exception as e:
            logger.error(f"Failed to connect to MCP SSE server {self.config.name}: {e}")
            return False

    async def disconnect(self) -> None:
        """Close the SSE connection."""
        self.connected = False

        try:
            if self._reader_task:
                self._reader_task.cancel()
                try:
                    await self._reader_task
                except asyncio.CancelledError:
                    pass
        finally:
            # Guarantee session cleanup even if reader cancel fails
            if self._session:
                await self._session.close()
                self._session = None
            # Cancel any pending futures
            for future in self._pending_requests.values():
                if not future.done():
                    future.cancel()
            self._pending_requests.clear()

    async def send_request(self, method: str, params: Optional[Dict] = None) -> Dict:
        """Send a request via HTTP POST."""
        if not self._session:
            raise RuntimeError("Not connected")

        request_id = self._next_request_id()
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params:
            request["params"] = params

        async with self._pending_lock:
            # Cleanup stale pending requests (prevent unbounded growth)
            if len(self._pending_requests) > self._MAX_PENDING_REQUESTS:
                stale = [rid for rid, f in self._pending_requests.items() if f.done()]
                for rid in stale:
                    del self._pending_requests[rid]

            # Create future
            future: asyncio.Future = asyncio.get_running_loop().create_future()
            self._pending_requests[request_id] = future

        # Send request
        async with self._session.post(self.config.url, json=request) as resp:
            if resp.status != 200:
                async with self._pending_lock:
                    self._pending_requests.pop(request_id, None)
                raise RuntimeError(f"HTTP {resp.status}: {await resp.text()}")

        # Wait for response via SSE
        try:
            response = await asyncio.wait_for(future, timeout=self.config.timeout_seconds)
            return response.get("result", {})
        except asyncio.TimeoutError:
            async with self._pending_lock:
                self._pending_requests.pop(request_id, None)
            raise TimeoutError(f"Request {method} timed out")

    async def _read_sse(self) -> None:
        """Read SSE events."""
        if not self._session or not self.config.url:
            return

        try:
            async with self._session.get(self.config.url, headers={"Accept": "text/event-stream"}) as resp:
                async for line in resp.content:
                    line = line.decode().strip()
                    if line.startswith("data:"):
                        data = line[5:].strip()
                        try:
                            response = json.loads(data)
                            request_id = response.get("id")
                            async with self._pending_lock:
                                future = self._pending_requests.pop(request_id, None) if request_id else None
                            if future is not None:
                                if "error" in response:
                                    future.set_exception(
                                        RuntimeError(response["error"].get("message", "Unknown error"))
                                    )
                                else:
                                    future.set_result(response)
                        except json.JSONDecodeError:
                            continue
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Error reading SSE: {e}")


class HTTPMCPConnection(MCPConnection):
    """MCP connection over HTTP (stateless)."""

    def __init__(self, config: MCPServerConfig):
        super().__init__(config)
        self._session: Optional[aiohttp.ClientSession] = None

    async def connect(self) -> bool:
        """Create HTTP session."""
        if not self.config.url:
            raise ValueError("URL required for HTTP transport")

        try:
            self._session = aiohttp.ClientSession(
                headers=self.config.headers,
                timeout=aiohttp.ClientTimeout(total=self.config.timeout_seconds)
            )
            return await self.initialize()
        except Exception as e:
            logger.error(f"Failed to connect to MCP HTTP server {self.config.name}: {e}")
            return False

    async def disconnect(self) -> None:
        """Close HTTP session."""
        self.connected = False
        if self._session:
            await self._session.close()

    async def send_request(self, method: str, params: Optional[Dict] = None) -> Dict:
        """Send a JSON-RPC request via HTTP POST."""
        if not self._session:
            raise RuntimeError("Not connected")

        request = {
            "jsonrpc": "2.0",
            "id": self._next_request_id(),
            "method": method,
        }
        if params:
            request["params"] = params

        async with self._session.post(self.config.url, json=request) as resp:
            if resp.status != 200:
                raise RuntimeError(f"HTTP {resp.status}: {await resp.text()}")

            response = await resp.json()
            if "error" in response:
                raise RuntimeError(response["error"].get("message", "Unknown error"))

            return response.get("result", {})


class MCPManager:
    """
    Manages multiple MCP server connections.

    Provides unified interface for:
    - Adding/removing servers
    - Tool discovery and execution
    - Resource access
    - Prompt templates
    """

    def __init__(self):
        self.connections: Dict[str, MCPConnection] = {}

    async def __aenter__(self) -> "MCPManager":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close_all()

    async def add_server(
        self,
        name: str,
        config: Union[MCPServerConfig, Dict[str, Any]]
    ) -> bool:
        """
        Add and connect to an MCP server.

        Args:
            name: Unique name for this server
            config: Server configuration (MCPServerConfig or dict)

        Returns:
            True if connection successful
        """
        if isinstance(config, dict):
            # Convert dict to MCPServerConfig
            transport = MCPTransport(config.get("type", "stdio"))
            config = MCPServerConfig(
                name=name,
                transport=transport,
                command=config.get("command"),
                args=config.get("args", []),
                env=config.get("env", {}),
                url=config.get("url"),
                headers=config.get("headers", {}),
                timeout_seconds=config.get("timeout", 30.0),
            )
        else:
            config.name = name

        # Create appropriate connection type
        if config.transport == MCPTransport.STDIO:
            connection = StdioMCPConnection(config)
        elif config.transport == MCPTransport.SSE:
            connection = SSEMCPConnection(config)
        elif config.transport == MCPTransport.HTTP:
            connection = HTTPMCPConnection(config)
        else:
            raise ValueError(f"Unknown transport: {config.transport}")

        # Connect
        success = await connection.connect()
        if success:
            self.connections[name] = connection
            logger.info(
                f"Connected to MCP server '{name}' | "
                f"tools={len(connection.tools)} resources={len(connection.resources)}"
            )

        return success

    async def remove_server(self, name: str) -> None:
        """Disconnect and remove an MCP server."""
        if name in self.connections:
            await self.connections[name].disconnect()
            del self.connections[name]
            logger.info(f"Disconnected from MCP server '{name}'")

    async def close_all(self) -> None:
        """Disconnect from all MCP servers."""
        for name in list(self.connections.keys()):
            await self.remove_server(name)

    def get_all_tools(self) -> List[MCPTool]:
        """Get all tools from all connected servers."""
        tools = []
        for connection in self.connections.values():
            tools.extend(connection.tools)
        return tools

    def get_tools_as_anthropic_format(self) -> List[Dict[str, Any]]:
        """Get all tools in Anthropic API format."""
        return [tool.to_anthropic_tool() for tool in self.get_all_tools()]

    def get_server_tools(self, server_name: str) -> List[MCPTool]:
        """Get tools from a specific server."""
        if server_name not in self.connections:
            return []
        return self.connections[server_name].tools

    async def call_tool(
        self,
        server_name: str,
        tool_name: str,
        arguments: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute a tool on a specific MCP server.

        Sends a ``tools/call`` JSON-RPC request to the named server and
        returns the result. The server must have been previously registered
        via :meth:`add_server`.

        Args:
            server_name: Registered server name (e.g. ``"slack"``, ``"github"``).
            tool_name: Tool name without server prefix
                (e.g. ``"send_message"``, not ``"mcp__slack__send_message"``).
            arguments: Keyword arguments forwarded to the tool.

        Returns:
            Dict containing the tool execution result from the MCP server.

        Raises:
            ValueError: If ``server_name`` is not a registered connection.
            RuntimeError: If the server is not connected.

        Example::

            manager = MCPManager()
            await manager.add_server("slack", {"command": "npx", ...})
            result = await manager.call_tool(
                "slack", "send_message",
                {"channel": "#general", "text": "Hello!"},
            )
        """
        if server_name not in self.connections:
            raise ValueError(f"Unknown MCP server: {server_name}")

        connection = self.connections[server_name]
        if not connection.connected:
            raise RuntimeError(f"MCP server {server_name} is not connected")

        return await connection.call_tool(tool_name, arguments)

    async def call_tool_by_full_name(
        self,
        full_name: str,
        arguments: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute a tool using its full name (mcp__server__tool).

        Args:
            full_name: Full tool name (e.g., "mcp__slack__send_message")
            arguments: Tool arguments

        Returns:
            Tool execution result
        """
        if not full_name.startswith("mcp__"):
            raise ValueError(f"Invalid MCP tool name: {full_name}")

        parts = full_name.split("__")
        if len(parts) != 3:
            raise ValueError(f"Invalid MCP tool name format: {full_name}")

        _, server_name, tool_name = parts
        return await self.call_tool(server_name, tool_name, arguments)

    def get_all_resources(self) -> List[MCPResource]:
        """Get all resources from all connected servers."""
        resources = []
        for connection in self.connections.values():
            resources.extend(connection.resources)
        return resources

    async def read_resource(self, server_name: str, uri: str) -> Dict[str, Any]:
        """Read a resource from an MCP server."""
        if server_name not in self.connections:
            raise ValueError(f"Unknown MCP server: {server_name}")

        return await self.connections[server_name].read_resource(uri)

    def get_all_prompts(self) -> List[MCPPrompt]:
        """Get all prompt templates from all connected servers."""
        prompts = []
        for connection in self.connections.values():
            prompts.extend(connection.prompts)
        return prompts

    async def get_prompt(
        self,
        server_name: str,
        prompt_name: str,
        arguments: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Get a prompt template from an MCP server."""
        if server_name not in self.connections:
            raise ValueError(f"Unknown MCP server: {server_name}")

        return await self.connections[server_name].get_prompt(prompt_name, arguments)


# Global MCP manager instance
_global_mcp_manager: Optional[MCPManager] = None


def get_mcp_manager() -> MCPManager:
    """Get or create the global MCP manager."""
    global _global_mcp_manager
    if _global_mcp_manager is None:
        _global_mcp_manager = MCPManager()
    return _global_mcp_manager


async def setup_mcp_servers(configs: Dict[str, Dict[str, Any]]) -> MCPManager:
    """
    Convenience function to set up multiple MCP servers.

    Args:
        configs: Dict mapping server names to their configurations

    Returns:
        Configured MCPManager

    Example:
        manager = await setup_mcp_servers({
            "slack": {
                "command": "npx",
                "args": ["-y", "@anthropic/mcp-slack"],
                "env": {"SLACK_TOKEN": os.environ["SLACK_TOKEN"]}
            },
            "github": {
                "command": "npx",
                "args": ["-y", "@anthropic/mcp-github"],
                "env": {"GITHUB_TOKEN": os.environ["GITHUB_TOKEN"]}
            }
        })
    """
    manager = get_mcp_manager()

    for name, config in configs.items():
        success = await manager.add_server(name, config)
        if not success:
            logger.warning(f"Failed to connect to MCP server: {name}")

    return manager


# Pre-defined MCP server configurations for common services
MCP_SERVER_PRESETS: Dict[str, Dict[str, Any]] = {
    "slack": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-slack"],
        "env_keys": ["SLACK_BOT_TOKEN", "SLACK_TEAM_ID"]
    },
    "github": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-github"],
        "env_keys": ["GITHUB_PERSONAL_ACCESS_TOKEN"]
    },
    "postgres": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-postgres"],
        "env_keys": ["POSTGRES_CONNECTION_STRING"]
    },
    "filesystem": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem"],
        "env_keys": []
    },
    "memory": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-memory"],
        "env_keys": []
    },
    "brave-search": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-brave-search"],
        "env_keys": ["BRAVE_API_KEY"]
    },
    "puppeteer": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-puppeteer"],
        "env_keys": []
    },
    "sqlite": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-sqlite"],
        "env_keys": ["SQLITE_DB_PATH"]
    }
}


async def add_preset_server(name: str, **env_overrides) -> bool:
    """
    Add a pre-configured MCP server.

    Args:
        name: Name of the preset (slack, github, postgres, etc.)
        **env_overrides: Override environment variables

    Returns:
        True if connection successful
    """
    if name not in MCP_SERVER_PRESETS:
        raise ValueError(f"Unknown preset: {name}. Available: {list(MCP_SERVER_PRESETS.keys())}")

    preset = MCP_SERVER_PRESETS[name]

    # Build environment
    env = {}
    for key in preset.get("env_keys", []):
        value = env_overrides.get(key) or os.environ.get(key)
        if value:
            env[key] = value

    config = {
        "command": preset["command"],
        "args": preset["args"],
        "env": env
    }

    manager = get_mcp_manager()
    return await manager.add_server(name, config)
