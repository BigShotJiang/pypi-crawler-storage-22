"""
Inter-Agent Communication Bus for StateSet Computer Use Agent.

This module provides a message-based communication system for agent coordination:

1. Message Passing
   - Asynchronous message delivery
   - Request-response patterns
   - Publish-subscribe for broadcasts
   - Message persistence and replay

2. Event Streaming
   - Real-time event propagation
   - Event sourcing support
   - Cross-agent notifications
   - Audit trail

3. Shared State
   - Distributed key-value store
   - Locks and semaphores
   - Atomic operations
   - State synchronization

4. Coordination Primitives
   - Leader election
   - Distributed barriers
   - Task coordination
   - Consensus protocols

Designed for reliable inter-agent communication at scale.
"""

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Awaitable
from collections import defaultdict
import weakref

from agent.logging_config import get_logger

logger = get_logger(__name__)


class MessageType(Enum):
    """Types of messages"""
    COMMAND = "command"           # Direct command to agent
    QUERY = "query"               # Request for information
    RESPONSE = "response"         # Response to query/command
    EVENT = "event"               # Event notification
    BROADCAST = "broadcast"       # Broadcast to all
    HEARTBEAT = "heartbeat"       # Keepalive message


class MessagePriority(Enum):
    """Message priorities"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


class DeliveryMode(Enum):
    """Message delivery modes"""
    AT_MOST_ONCE = "at_most_once"    # Fire and forget
    AT_LEAST_ONCE = "at_least_once"  # Retry until ack
    EXACTLY_ONCE = "exactly_once"    # Deduplication


@dataclass
class Message:
    """A message in the communication bus"""
    message_id: str
    message_type: MessageType
    sender: str
    recipient: str  # Agent ID or "*" for broadcast
    topic: str
    payload: Dict[str, Any]

    # Delivery settings
    priority: MessagePriority = MessagePriority.NORMAL
    delivery_mode: DeliveryMode = DeliveryMode.AT_LEAST_ONCE
    ttl_seconds: int = 3600
    require_ack: bool = True

    # Metadata
    created_at: datetime = field(default_factory=datetime.utcnow)
    correlation_id: Optional[str] = None
    reply_to: Optional[str] = None

    # State
    delivered: bool = False
    acknowledged: bool = False
    retries: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            'message_id': self.message_id,
            'message_type': self.message_type.value,
            'sender': self.sender,
            'recipient': self.recipient,
            'topic': self.topic,
            'payload': self.payload,
            'priority': self.priority.value,
            'created_at': self.created_at.isoformat(),
            'correlation_id': self.correlation_id
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        return cls(
            message_id=data.get('message_id', str(uuid.uuid4())),
            message_type=MessageType(data.get('message_type', 'event')),
            sender=data.get('sender', ''),
            recipient=data.get('recipient', '*'),
            topic=data.get('topic', ''),
            payload=data.get('payload', {}),
            priority=MessagePriority(data.get('priority', 1)),
            correlation_id=data.get('correlation_id')
        )

    def is_expired(self) -> bool:
        """Check if message has expired"""
        expiry = self.created_at + timedelta(seconds=self.ttl_seconds)
        return datetime.utcnow() > expiry


@dataclass
class Subscription:
    """A subscription to messages"""
    subscription_id: str
    subscriber: str  # Agent ID
    topic_pattern: str  # Can include wildcards: "agent.*", "*.completed"
    handler: Callable[[Message], Awaitable[None]]
    created_at: datetime = field(default_factory=datetime.utcnow)
    message_types: Set[MessageType] = field(default_factory=lambda: set(MessageType))
    active: bool = True

    def matches(self, topic: str, message_type: MessageType) -> bool:
        """Check if subscription matches topic and type"""
        if not self.active:
            return False

        if message_type not in self.message_types:
            return False

        # Simple wildcard matching
        pattern_parts = self.topic_pattern.split('.')
        topic_parts = topic.split('.')

        if len(pattern_parts) != len(topic_parts):
            if '*' not in pattern_parts:
                return False

        for p, t in zip(pattern_parts, topic_parts):
            if p == '*':
                continue
            if p != t:
                return False

        return True


@dataclass
class SharedState:
    """A piece of shared state"""
    key: str
    value: Any
    version: int = 0
    owner: Optional[str] = None
    expires_at: Optional[datetime] = None
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at


class MessageQueue:
    """Priority queue for messages"""

    def __init__(self, max_size: int = 10000):
        self.max_size = max_size
        self._queues: Dict[str, asyncio.PriorityQueue] = defaultdict(
            lambda: asyncio.PriorityQueue(maxsize=max_size)
        )

    async def enqueue(self, recipient: str, message: Message):
        """Add message to queue"""
        priority = -message.priority.value  # Negative for max-priority
        await self._queues[recipient].put((priority, message.created_at, message))

    async def dequeue(self, recipient: str, timeout: float = None) -> Optional[Message]:
        """Get next message for recipient"""
        try:
            if timeout:
                _, _, message = await asyncio.wait_for(
                    self._queues[recipient].get(),
                    timeout=timeout
                )
            else:
                _, _, message = self._queues[recipient].get_nowait()
            return message
        except (asyncio.TimeoutError, asyncio.QueueEmpty):
            return None

    def size(self, recipient: str = None) -> int:
        """Get queue size"""
        if recipient:
            return self._queues[recipient].qsize()
        return sum(q.qsize() for q in self._queues.values())


class EventLog:
    """Persistent event log for audit and replay"""

    def __init__(self, storage_dir: str = "/tmp/agent_events"):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self._events: List[Dict[str, Any]] = []
        self._max_memory_events = 10000

    async def append(self, message: Message):
        """Append event to log"""
        event = {
            'timestamp': datetime.utcnow().isoformat(),
            'message': message.to_dict()
        }

        self._events.append(event)

        # Trim memory buffer
        if len(self._events) > self._max_memory_events:
            self._events = self._events[-self._max_memory_events:]

        # Persist to disk (async would be better, simplified here)
        log_file = self.storage_dir / f"events_{datetime.utcnow().strftime('%Y%m%d')}.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(event) + '\n')

    async def replay(
        self,
        topic: str = None,
        since: datetime = None,
        limit: int = 100
    ) -> List[Message]:
        """Replay events from log"""
        results = []

        for event in reversed(self._events):
            if len(results) >= limit:
                break

            msg_data = event.get('message', {})
            timestamp = datetime.fromisoformat(event.get('timestamp', ''))

            if since and timestamp < since:
                continue

            if topic and msg_data.get('topic') != topic:
                continue

            results.append(Message.from_dict(msg_data))

        return list(reversed(results))


class DistributedLock:
    """Distributed lock for coordination"""

    def __init__(self):
        self._locks: Dict[str, Tuple[str, datetime, int]] = {}  # key -> (owner, acquired_at, ttl)
        self._waiters: Dict[str, List[asyncio.Event]] = defaultdict(list)
        self._lock = asyncio.Lock()

    async def acquire(
        self,
        key: str,
        owner: str,
        ttl_seconds: int = 60,
        wait: bool = True,
        timeout: float = 30.0
    ) -> bool:
        """Acquire a lock"""
        async with self._lock:
            # Check if lock is available or expired
            if key in self._locks:
                current_owner, acquired_at, current_ttl = self._locks[key]
                if datetime.utcnow() < acquired_at + timedelta(seconds=current_ttl):
                    if not wait:
                        return False
                else:
                    # Lock expired
                    del self._locks[key]

        if wait:
            event = asyncio.Event()
            self._waiters[key].append(event)

            try:
                await asyncio.wait_for(event.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                self._waiters[key].remove(event)
                return False

        async with self._lock:
            if key not in self._locks:
                self._locks[key] = (owner, datetime.utcnow(), ttl_seconds)
                return True

        return False

    async def release(self, key: str, owner: str) -> bool:
        """Release a lock"""
        async with self._lock:
            if key in self._locks:
                current_owner, _, _ = self._locks[key]
                if current_owner == owner:
                    del self._locks[key]

                    # Notify waiters
                    if key in self._waiters and self._waiters[key]:
                        waiter = self._waiters[key].pop(0)
                        waiter.set()

                    return True
        return False

    async def extend(self, key: str, owner: str, ttl_seconds: int) -> bool:
        """Extend lock TTL"""
        async with self._lock:
            if key in self._locks:
                current_owner, acquired_at, _ = self._locks[key]
                if current_owner == owner:
                    self._locks[key] = (owner, datetime.utcnow(), ttl_seconds)
                    return True
        return False


class MessageBus:
    """
    Central message bus for inter-agent communication.

    Provides:
    - Point-to-point messaging
    - Publish-subscribe
    - Request-response
    - Shared state
    - Distributed coordination
    """

    def __init__(
        self,
        storage_dir: str = "/tmp/agent_bus",
        enable_persistence: bool = True
    ):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # Message handling
        self._queue = MessageQueue()
        self._subscriptions: Dict[str, Subscription] = {}
        self._pending_responses: Dict[str, asyncio.Future] = {}

        # Event log
        self._event_log = EventLog(str(self.storage_dir / "events")) if enable_persistence else None

        # Shared state
        self._state: Dict[str, SharedState] = {}
        self._state_lock = asyncio.Lock()

        # Distributed locks
        self._dist_lock = DistributedLock()

        # Agent registry
        self._registered_agents: Dict[str, Dict[str, Any]] = {}

        # Background tasks
        self._running = False
        self._background_tasks: List[asyncio.Task] = []

        # Statistics
        self._stats = {
            'messages_sent': 0,
            'messages_delivered': 0,
            'messages_failed': 0,
            'events_published': 0
        }

    # Agent Registration

    def register_agent(
        self,
        agent_id: str,
        agent_type: str,
        capabilities: List[str] = None,
        metadata: Dict[str, Any] = None
    ):
        """Register an agent with the message bus"""
        self._registered_agents[agent_id] = {
            'agent_id': agent_id,
            'agent_type': agent_type,
            'capabilities': capabilities or [],
            'metadata': metadata or {},
            'registered_at': datetime.utcnow().isoformat(),
            'last_heartbeat': datetime.utcnow().isoformat()
        }
        logger.info(f"Agent {agent_id} registered with message bus")

    def unregister_agent(self, agent_id: str):
        """Unregister an agent"""
        if agent_id in self._registered_agents:
            del self._registered_agents[agent_id]

            # Remove agent's subscriptions
            to_remove = [
                sid for sid, sub in self._subscriptions.items()
                if sub.subscriber == agent_id
            ]
            for sid in to_remove:
                del self._subscriptions[sid]

            logger.info(f"Agent {agent_id} unregistered from message bus")

    def get_registered_agents(self) -> List[Dict[str, Any]]:
        """Get list of registered agents"""
        return list(self._registered_agents.values())

    def update_heartbeat(self, agent_id: str):
        """Update agent heartbeat"""
        if agent_id in self._registered_agents:
            self._registered_agents[agent_id]['last_heartbeat'] = datetime.utcnow().isoformat()

    # Message Sending

    async def send(
        self,
        sender: str,
        recipient: str,
        topic: str,
        payload: Dict[str, Any],
        message_type: MessageType = MessageType.COMMAND,
        priority: MessagePriority = MessagePriority.NORMAL,
        require_ack: bool = True,
        correlation_id: str = None
    ) -> str:
        """Send a message to a specific recipient"""
        message = Message(
            message_id=str(uuid.uuid4()),
            message_type=message_type,
            sender=sender,
            recipient=recipient,
            topic=topic,
            payload=payload,
            priority=priority,
            require_ack=require_ack,
            correlation_id=correlation_id
        )

        await self._queue.enqueue(recipient, message)
        self._stats['messages_sent'] += 1

        logger.debug(f"Message {message.message_id} sent from {sender} to {recipient}")

        return message.message_id

    async def publish(
        self,
        sender: str,
        topic: str,
        payload: Dict[str, Any],
        priority: MessagePriority = MessagePriority.NORMAL
    ) -> str:
        """Publish an event to all subscribers"""
        message = Message(
            message_id=str(uuid.uuid4()),
            message_type=MessageType.EVENT,
            sender=sender,
            recipient="*",
            topic=topic,
            payload=payload,
            priority=priority,
            require_ack=False
        )

        # Log event
        if self._event_log:
            await self._event_log.append(message)

        # Deliver to matching subscriptions
        delivered_count = 0
        for sub in self._subscriptions.values():
            if sub.matches(topic, MessageType.EVENT):
                try:
                    await sub.handler(message)
                    delivered_count += 1
                except Exception as e:
                    logger.error(f"Subscription handler error: {e}")

        self._stats['events_published'] += 1
        logger.debug(f"Event {message.message_id} published to {delivered_count} subscribers")

        return message.message_id

    async def broadcast(
        self,
        sender: str,
        topic: str,
        payload: Dict[str, Any]
    ) -> str:
        """Broadcast a message to all agents"""
        message = Message(
            message_id=str(uuid.uuid4()),
            message_type=MessageType.BROADCAST,
            sender=sender,
            recipient="*",
            topic=topic,
            payload=payload,
            require_ack=False
        )

        # Send to all registered agents
        for agent_id in self._registered_agents.keys():
            if agent_id != sender:
                await self._queue.enqueue(agent_id, message)

        return message.message_id

    async def request(
        self,
        sender: str,
        recipient: str,
        topic: str,
        payload: Dict[str, Any],
        timeout: float = 30.0
    ) -> Optional[Dict[str, Any]]:
        """Send a request and wait for response"""
        correlation_id = str(uuid.uuid4())

        # Create future for response
        response_future = asyncio.Future()
        self._pending_responses[correlation_id] = response_future

        try:
            # Send query
            await self.send(
                sender=sender,
                recipient=recipient,
                topic=topic,
                payload=payload,
                message_type=MessageType.QUERY,
                correlation_id=correlation_id
            )

            # Wait for response
            response = await asyncio.wait_for(response_future, timeout=timeout)
            return response

        except asyncio.TimeoutError:
            logger.warning(f"Request to {recipient} timed out")
            return None

        finally:
            self._pending_responses.pop(correlation_id, None)

    async def respond(
        self,
        original_message: Message,
        payload: Dict[str, Any]
    ):
        """Send a response to a query"""
        if not original_message.correlation_id:
            logger.warning("Cannot respond to message without correlation_id")
            return

        response = Message(
            message_id=str(uuid.uuid4()),
            message_type=MessageType.RESPONSE,
            sender=original_message.recipient,
            recipient=original_message.sender,
            topic=original_message.topic + ".response",
            payload=payload,
            correlation_id=original_message.correlation_id
        )

        # Check if there's a pending future
        if original_message.correlation_id in self._pending_responses:
            future = self._pending_responses[original_message.correlation_id]
            if not future.done():
                future.set_result(payload)

        await self._queue.enqueue(original_message.sender, response)

    # Subscriptions

    def subscribe(
        self,
        subscriber: str,
        topic_pattern: str,
        handler: Callable[[Message], Awaitable[None]],
        message_types: Set[MessageType] = None
    ) -> str:
        """Subscribe to messages matching a topic pattern"""
        subscription = Subscription(
            subscription_id=str(uuid.uuid4())[:8],
            subscriber=subscriber,
            topic_pattern=topic_pattern,
            handler=handler,
            message_types=message_types or set(MessageType)
        )

        self._subscriptions[subscription.subscription_id] = subscription
        logger.info(f"Agent {subscriber} subscribed to '{topic_pattern}'")

        return subscription.subscription_id

    def unsubscribe(self, subscription_id: str):
        """Unsubscribe from a topic"""
        if subscription_id in self._subscriptions:
            del self._subscriptions[subscription_id]

    # Message Receiving

    async def receive(
        self,
        agent_id: str,
        timeout: float = None
    ) -> Optional[Message]:
        """Receive next message for an agent"""
        message = await self._queue.dequeue(agent_id, timeout)

        if message:
            message.delivered = True
            self._stats['messages_delivered'] += 1

        return message

    async def receive_batch(
        self,
        agent_id: str,
        max_messages: int = 10
    ) -> List[Message]:
        """Receive multiple messages"""
        messages = []
        for _ in range(max_messages):
            message = await self._queue.dequeue(agent_id, timeout=0.1)
            if message:
                messages.append(message)
            else:
                break
        return messages

    # Shared State

    async def set_state(
        self,
        key: str,
        value: Any,
        owner: str = None,
        ttl_seconds: int = None
    ) -> bool:
        """Set a shared state value"""
        async with self._state_lock:
            expires_at = None
            if ttl_seconds:
                expires_at = datetime.utcnow() + timedelta(seconds=ttl_seconds)

            if key in self._state:
                state = self._state[key]
                state.value = value
                state.version += 1
                state.owner = owner
                state.expires_at = expires_at
                state.updated_at = datetime.utcnow()
            else:
                self._state[key] = SharedState(
                    key=key,
                    value=value,
                    owner=owner,
                    expires_at=expires_at
                )

            # Publish state change event
            await self.publish(
                sender="message_bus",
                topic=f"state.changed.{key}",
                payload={'key': key, 'value': value}
            )

            return True

    async def get_state(self, key: str) -> Optional[Any]:
        """Get a shared state value"""
        async with self._state_lock:
            state = self._state.get(key)
            if state and not state.is_expired():
                return state.value
            return None

    async def delete_state(self, key: str, owner: str = None) -> bool:
        """Delete a shared state value"""
        async with self._state_lock:
            if key in self._state:
                state = self._state[key]
                if owner and state.owner != owner:
                    return False
                del self._state[key]
                return True
            return False

    async def compare_and_set(
        self,
        key: str,
        expected_value: Any,
        new_value: Any,
        owner: str = None
    ) -> bool:
        """Atomic compare-and-set operation"""
        async with self._state_lock:
            state = self._state.get(key)

            if state is None:
                if expected_value is None:
                    self._state[key] = SharedState(key=key, value=new_value, owner=owner)
                    return True
                return False

            if state.value == expected_value:
                state.value = new_value
                state.version += 1
                state.updated_at = datetime.utcnow()
                return True

            return False

    # Distributed Locks

    async def acquire_lock(
        self,
        key: str,
        owner: str,
        ttl_seconds: int = 60,
        wait: bool = True,
        timeout: float = 30.0
    ) -> bool:
        """Acquire a distributed lock"""
        return await self._dist_lock.acquire(key, owner, ttl_seconds, wait, timeout)

    async def release_lock(self, key: str, owner: str) -> bool:
        """Release a distributed lock"""
        return await self._dist_lock.release(key, owner)

    # Event Replay

    async def replay_events(
        self,
        topic: str = None,
        since: datetime = None,
        limit: int = 100
    ) -> List[Message]:
        """Replay events from log"""
        if self._event_log:
            return await self._event_log.replay(topic, since, limit)
        return []

    # Lifecycle

    async def start(self):
        """Start the message bus"""
        if self._running:
            return

        self._running = True

        # Start background tasks
        self._background_tasks = [
            asyncio.create_task(self._cleanup_loop()),
            asyncio.create_task(self._heartbeat_check_loop())
        ]

        logger.info("Message bus started")

    async def stop(self):
        """Stop the message bus"""
        self._running = False

        for task in self._background_tasks:
            task.cancel()

        await asyncio.gather(*self._background_tasks, return_exceptions=True)

        logger.info("Message bus stopped")

    async def _cleanup_loop(self):
        """Background cleanup loop"""
        while self._running:
            try:
                # Clean up expired state
                async with self._state_lock:
                    expired = [k for k, v in self._state.items() if v.is_expired()]
                    for key in expired:
                        del self._state[key]

                await asyncio.sleep(60)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Cleanup loop error: {e}")

    async def _heartbeat_check_loop(self):
        """Check for stale agents"""
        while self._running:
            try:
                now = datetime.utcnow()
                stale_threshold = timedelta(minutes=5)

                stale_agents = []
                for agent_id, info in self._registered_agents.items():
                    last_heartbeat = datetime.fromisoformat(info['last_heartbeat'])
                    if now - last_heartbeat > stale_threshold:
                        stale_agents.append(agent_id)

                for agent_id in stale_agents:
                    logger.warning(f"Agent {agent_id} appears stale (no heartbeat)")
                    await self.publish(
                        sender="message_bus",
                        topic="agent.stale",
                        payload={'agent_id': agent_id}
                    )

                await asyncio.sleep(60)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat check error: {e}")

    # Statistics

    def get_stats(self) -> Dict[str, Any]:
        """Get message bus statistics"""
        return {
            **self._stats,
            'registered_agents': len(self._registered_agents),
            'active_subscriptions': len(self._subscriptions),
            'shared_state_keys': len(self._state),
            'pending_messages': self._queue.size()
        }


# Convenience functions for common patterns

class AgentCommunicator:
    """Simplified communication interface for agents"""

    def __init__(self, bus: MessageBus, agent_id: str, agent_type: str):
        self.bus = bus
        self.agent_id = agent_id
        self.agent_type = agent_type

        # Register with bus
        self.bus.register_agent(agent_id, agent_type)

        # Message handlers
        self._handlers: Dict[str, Callable] = {}

    async def send_command(
        self,
        recipient: str,
        command: str,
        params: Dict[str, Any] = None
    ) -> str:
        """Send a command to another agent"""
        return await self.bus.send(
            sender=self.agent_id,
            recipient=recipient,
            topic=f"command.{command}",
            payload={'command': command, 'params': params or {}},
            message_type=MessageType.COMMAND
        )

    async def query(
        self,
        recipient: str,
        query: str,
        params: Dict[str, Any] = None,
        timeout: float = 30.0
    ) -> Optional[Dict[str, Any]]:
        """Query another agent"""
        return await self.bus.request(
            sender=self.agent_id,
            recipient=recipient,
            topic=f"query.{query}",
            payload={'query': query, 'params': params or {}},
            timeout=timeout
        )

    async def emit_event(self, event: str, data: Dict[str, Any] = None):
        """Emit an event"""
        await self.bus.publish(
            sender=self.agent_id,
            topic=f"agent.{self.agent_type}.{event}",
            payload={'event': event, 'data': data or {}, 'agent_id': self.agent_id}
        )

    def on_event(self, topic_pattern: str, handler: Callable[[Message], Awaitable[None]]):
        """Subscribe to events"""
        return self.bus.subscribe(
            subscriber=self.agent_id,
            topic_pattern=topic_pattern,
            handler=handler,
            message_types={MessageType.EVENT}
        )

    async def receive_messages(self, timeout: float = None) -> Optional[Message]:
        """Receive messages"""
        return await self.bus.receive(self.agent_id, timeout)

    async def heartbeat(self):
        """Send heartbeat"""
        self.bus.update_heartbeat(self.agent_id)

    def cleanup(self):
        """Cleanup on shutdown"""
        self.bus.unregister_agent(self.agent_id)


def get_message_bus(
    storage_dir: str = "/tmp/agent_bus",
    enable_persistence: bool = True
) -> MessageBus:
    """Get or create the message bus singleton"""
    if not hasattr(get_message_bus, '_instance'):
        get_message_bus._instance = MessageBus(
            storage_dir=storage_dir,
            enable_persistence=enable_persistence
        )
    return get_message_bus._instance
