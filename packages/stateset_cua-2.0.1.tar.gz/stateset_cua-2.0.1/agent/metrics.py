"""
Metrics and cost tracking for StateSet Computer Use Agent.
Provides real-time monitoring, cost tracking, and budget enforcement.
"""

import json
import os
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict, field
from collections import defaultdict

logger = logging.getLogger('agent.metrics')

_agent_data_dir = os.environ.get("AGENT_DATA_DIR", "/tmp")


@dataclass
class TaskMetrics:
    """Metrics for a single task execution"""
    task_id: str
    agent_type: str
    instruction: str
    start_time: float
    end_time: float = 0
    success: bool = False
    
    # Token usage
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    
    # Tool usage
    screenshots_taken: int = 0
    bash_commands: int = 0
    file_operations: int = 0
    memory_operations: int = 0
    web_searches: int = 0
    web_fetches: int = 0
    code_executions: int = 0
    
    # Cost breakdown
    token_cost: float = 0.0
    web_search_cost: float = 0.0
    code_execution_cost: float = 0.0
    total_cost: float = 0.0
    
    # Errors
    errors: List[str] = field(default_factory=list)
    
    def duration(self) -> float:
        """Get task duration in seconds"""
        return self.end_time - self.start_time if self.end_time > 0 else time.time() - self.start_time
    
    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return asdict(self)


class MetricsCollector:
    """Collect and aggregate metrics across all tasks"""
    
    def __init__(self, export_dir: str = None):
        self.export_dir = Path(export_dir or f"{_agent_data_dir}/agent_metrics")
        self.export_dir.mkdir(parents=True, exist_ok=True)
        
        # Metrics storage
        self.tasks: List[TaskMetrics] = []
        self.agent_stats: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            'total_tasks': 0,
            'successful_tasks': 0,
            'failed_tasks': 0,
            'total_tokens': 0,
            'total_cost': 0.0,
            'tool_usage': defaultdict(int)
        })
        
        self.start_time = time.time()
    
    def record_task(self, task: TaskMetrics):
        """Record completed task"""
        self.tasks.append(task)
        
        # Update agent stats
        stats = self.agent_stats[task.agent_type]
        stats['total_tasks'] += 1
        
        if task.success:
            stats['successful_tasks'] += 1
        else:
            stats['failed_tasks'] += 1
        
        stats['total_tokens'] += task.input_tokens + task.output_tokens
        stats['total_cost'] += task.total_cost
        
        # Update tool usage
        stats['tool_usage']['screenshots'] += task.screenshots_taken
        stats['tool_usage']['bash_commands'] += task.bash_commands
        stats['tool_usage']['file_operations'] += task.file_operations
        stats['tool_usage']['memory_operations'] += task.memory_operations
        stats['tool_usage']['web_searches'] += task.web_searches
        stats['tool_usage']['web_fetches'] += task.web_fetches
        stats['tool_usage']['code_executions'] += task.code_executions
    
    def get_summary(self) -> Dict[str, Any]:
        """Get comprehensive metrics summary"""
        total_tasks = len(self.tasks)
        successful_tasks = sum(1 for t in self.tasks if t.success)
        
        total_cost = sum(t.total_cost for t in self.tasks)
        total_tokens = sum(t.input_tokens + t.output_tokens for t in self.tasks)
        
        uptime_hours = (time.time() - self.start_time) / 3600
        
        return {
            'summary': {
                'uptime_hours': uptime_hours,
                'total_tasks': total_tasks,
                'successful_tasks': successful_tasks,
                'failed_tasks': total_tasks - successful_tasks,
                'success_rate': successful_tasks / total_tasks if total_tasks > 0 else 0,
                'total_tokens': total_tokens,
                'total_cost_usd': total_cost,
                'avg_cost_per_task': total_cost / total_tasks if total_tasks > 0 else 0,
                'tasks_per_hour': total_tasks / uptime_hours if uptime_hours > 0 else 0
            },
            'by_agent': dict(self.agent_stats),
            'recent_tasks': [t.to_dict() for t in self.tasks[-10:]],  # Last 10 tasks
            'cost_breakdown': self._get_cost_breakdown(),
            'performance_trends': self._get_performance_trends()
        }
    
    def _get_cost_breakdown(self) -> Dict[str, float]:
        """Get cost breakdown by type"""
        return {
            'tokens': sum(t.token_cost for t in self.tasks),
            'web_search': sum(t.web_search_cost for t in self.tasks),
            'code_execution': sum(t.code_execution_cost for t in self.tasks)
        }
    
    def _get_performance_trends(self) -> Dict[str, Any]:
        """Calculate performance trends"""
        if len(self.tasks) < 10:
            return {}
        
        # Compare recent vs older tasks
        recent = self.tasks[-10:]
        older = self.tasks[-20:-10] if len(self.tasks) >= 20 else self.tasks[:-10]
        
        recent_success = sum(1 for t in recent if t.success) / len(recent)
        older_success = sum(1 for t in older if t.success) / len(older) if older else 0
        
        recent_cost = sum(t.total_cost for t in recent) / len(recent)
        older_cost = sum(t.total_cost for t in older) / len(older) if older else 0
        
        return {
            'success_rate_trend': 'improving' if recent_success > older_success else 'declining',
            'cost_trend': 'increasing' if recent_cost > older_cost else 'decreasing',
            'recent_success_rate': recent_success,
            'recent_avg_cost': recent_cost
        }
    
    def export_to_json(self, filename: str = None):
        """Export metrics to JSON file"""
        if filename is None:
            filename = f"metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        filepath = self.export_dir / filename
        
        with open(filepath, 'w') as f:
            json.dump(self.get_summary(), f, indent=2)
        
        logger.info(f"Metrics exported to {filepath}")
        return filepath
    
    def get_agent_summary(self, agent_type: str) -> Dict[str, Any]:
        """Get summary for specific agent"""
        agent_tasks = [t for t in self.tasks if t.agent_type == agent_type]
        
        if not agent_tasks:
            return {}
        
        return {
            'total_tasks': len(agent_tasks),
            'successful': sum(1 for t in agent_tasks if t.success),
            'success_rate': sum(1 for t in agent_tasks if t.success) / len(agent_tasks),
            'total_cost': sum(t.total_cost for t in agent_tasks),
            'avg_cost': sum(t.total_cost for t in agent_tasks) / len(agent_tasks),
            'total_tokens': sum(t.input_tokens + t.output_tokens for t in agent_tasks)
        }


class CostTracker:
    """
    Track costs in real-time with budget enforcement.
    Prevents runaway costs by enforcing budget limits.
    """
    
    # Pricing sourced from agent.config.BudgetSettings (single source of truth)
    @staticmethod
    def _load_pricing():
        from agent.config import get_config
        budget = get_config().budget
        return budget

    @property
    def SONNET_INPUT_PRICE(self):
        return self._load_pricing().input_token_price

    @property
    def SONNET_OUTPUT_PRICE(self):
        return self._load_pricing().output_token_price

    @property
    def CACHE_WRITE_PRICE(self):
        return self._load_pricing().cache_write_price

    @property
    def CACHE_READ_PRICE(self):
        return self._load_pricing().cache_read_price

    @property
    def WEB_SEARCH_PRICE(self):
        return self._load_pricing().web_search_price

    @property
    def CODE_EXECUTION_PRICE(self):
        return self._load_pricing().code_execution_price
    
    def __init__(
        self,
        daily_budget: float = 100.0,
        per_task_budget: float = 5.0,
        monthly_budget: float = 2000.0
    ):
        self.daily_budget = daily_budget
        self.per_task_budget = per_task_budget
        self.monthly_budget = monthly_budget
        
        # Cost tracking
        self.daily_costs = []
        self.monthly_costs = []
        self.current_task_cost = 0.0
        
        # Budget enforcement
        self.budget_exceeded_count = 0
    
    def calculate_token_cost(
        self,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0
    ) -> float:
        """Calculate cost for token usage"""
        cost = (
            input_tokens * self.SONNET_INPUT_PRICE +
            output_tokens * self.SONNET_OUTPUT_PRICE +
            cache_read_tokens * self.CACHE_READ_PRICE +
            cache_write_tokens * self.CACHE_WRITE_PRICE
        )
        return cost
    
    def calculate_web_search_cost(self, search_count: int) -> float:
        """Calculate cost for web searches"""
        return search_count * self.WEB_SEARCH_PRICE
    
    def calculate_code_execution_cost(self, duration_hours: float) -> float:
        """Calculate cost for code execution (minimum 5 minutes)"""
        billable_hours = max(duration_hours, 5/60)  # Minimum 5 minutes
        return billable_hours * self.CODE_EXECUTION_PRICE
    
    def record_cost(self, cost: float, cost_type: str = 'tokens'):
        """Record cost and check against budgets"""
        self.current_task_cost += cost
        
        # Add to daily tracking
        today = datetime.now().date()
        if not self.daily_costs or self.daily_costs[-1]['date'] != str(today):
            self.daily_costs.append({'date': str(today), 'cost': 0.0})
        
        self.daily_costs[-1]['cost'] += cost
        
        # Check budgets
        self._check_budgets()
    
    def _check_budgets(self):
        """Check if any budgets are exceeded"""
        # Check per-task budget
        if self.current_task_cost > self.per_task_budget:
            logger.warning(
                f"⚠️ Task cost ${self.current_task_cost:.2f} exceeds per-task budget ${self.per_task_budget:.2f}"
            )
            self.budget_exceeded_count += 1
        
        # Check daily budget
        daily_total = self.get_daily_cost()
        if daily_total > self.daily_budget:
            logger.error(
                f"🚨 Daily cost ${daily_total:.2f} exceeds daily budget ${self.daily_budget:.2f}"
            )
            raise BudgetExceededError(f"Daily budget exceeded: ${daily_total:.2f} > ${self.daily_budget:.2f}")
        
        # Warn at 80% of daily budget
        if daily_total > self.daily_budget * 0.8:
            logger.warning(
                f"⚠️ Daily cost ${daily_total:.2f} is at {daily_total/self.daily_budget*100:.0f}% of budget"
            )
    
    def start_task(self):
        """Start tracking a new task"""
        self.current_task_cost = 0.0
    
    def get_task_cost(self) -> float:
        """Get current task cost"""
        return self.current_task_cost
    
    def get_daily_cost(self) -> float:
        """Get today's total cost"""
        today = str(datetime.now().date())
        for day in self.daily_costs:
            if day['date'] == today:
                return day['cost']
        return 0.0
    
    def get_monthly_cost(self) -> float:
        """Get current month's total cost"""
        current_month = datetime.now().strftime('%Y-%m')
        total = 0.0
        
        for day in self.daily_costs:
            if day['date'].startswith(current_month):
                total += day['cost']
        
        return total
    
    def get_budget_status(self) -> Dict[str, Any]:
        """Get current budget status"""
        daily = self.get_daily_cost()
        monthly = self.get_monthly_cost()
        
        return {
            'daily': {
                'spent': daily,
                'budget': self.daily_budget,
                'remaining': self.daily_budget - daily,
                'percent_used': (daily / self.daily_budget * 100) if self.daily_budget > 0 else 0
            },
            'monthly': {
                'spent': monthly,
                'budget': self.monthly_budget,
                'remaining': self.monthly_budget - monthly,
                'percent_used': (monthly / self.monthly_budget * 100) if self.monthly_budget > 0 else 0
            },
            'current_task': {
                'spent': self.current_task_cost,
                'budget': self.per_task_budget,
                'remaining': self.per_task_budget - self.current_task_cost
            }
        }
    
    def export_costs(self, filename: str = None) -> Path:
        """Export cost history to JSON"""
        if filename is None:
            filename = f"costs_{datetime.now().strftime('%Y%m%d')}.json"
        
        filepath = Path(f"{_agent_data_dir}/agent_metrics") / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w') as f:
            json.dump({
                'daily_costs': self.daily_costs,
                'budget_status': self.get_budget_status(),
                'budget_exceeded_count': self.budget_exceeded_count
            }, f, indent=2)
        
        return filepath


class BudgetExceededError(Exception):
    """Raised when budget limits are exceeded"""
    pass


class AgentMetrics:
    """
    Main metrics and cost tracking system.
    Use this singleton for all metric collection.
    """
    
    def __init__(
        self,
        daily_budget: float = 100.0,
        per_task_budget: float = 5.0,
        monthly_budget: float = 2000.0
    ):
        self.collector = MetricsCollector()
        self.cost_tracker = CostTracker(daily_budget, per_task_budget, monthly_budget)
        
        # Current task tracking
        self.current_task: Optional[TaskMetrics] = None
    
    def start_task(self, task_id: str, agent_type: str, instruction: str):
        """Start tracking a new task"""
        self.current_task = TaskMetrics(
            task_id=task_id,
            agent_type=agent_type,
            instruction=instruction[:200],  # Truncate long instructions
            start_time=time.time()
        )
        self.cost_tracker.start_task()
    
    def record_tokens(
        self,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0
    ):
        """Record token usage and calculate cost"""
        if not self.current_task:
            return
        
        self.current_task.input_tokens += input_tokens
        self.current_task.output_tokens += output_tokens
        self.current_task.cache_read_tokens += cache_read_tokens
        self.current_task.cache_write_tokens += cache_write_tokens
        
        # Calculate and record cost
        cost = self.cost_tracker.calculate_token_cost(
            input_tokens, output_tokens, cache_read_tokens, cache_write_tokens
        )
        self.current_task.token_cost += cost
        self.cost_tracker.record_cost(cost, 'tokens')
    
    def record_tool_use(self, tool_name: str, count: int = 1):
        """Record tool usage"""
        if not self.current_task:
            return
        
        tool_map = {
            'computer': 'screenshots_taken',
            'bash': 'bash_commands',
            'str_replace_based_edit_tool': 'file_operations',
            'memory': 'memory_operations'
        }
        
        attr = tool_map.get(tool_name)
        if attr:
            setattr(self.current_task, attr, getattr(self.current_task, attr) + count)
    
    def record_web_search(self, search_count: int):
        """Record web search usage and cost"""
        if not self.current_task:
            return
        
        self.current_task.web_searches += search_count
        cost = self.cost_tracker.calculate_web_search_cost(search_count)
        self.current_task.web_search_cost += cost
        self.cost_tracker.record_cost(cost, 'web_search')
    
    def record_web_fetch(self, fetch_count: int):
        """Record web fetch usage (FREE, but track for metrics)"""
        if not self.current_task:
            return
        
        self.current_task.web_fetches += fetch_count
    
    def record_code_execution(self, duration_hours: float):
        """Record code execution usage and cost"""
        if not self.current_task:
            return
        
        self.current_task.code_executions += 1
        cost = self.cost_tracker.calculate_code_execution_cost(duration_hours)
        self.current_task.code_execution_cost += cost
        self.cost_tracker.record_cost(cost, 'code_execution')
    
    def record_error(self, error: str):
        """Record task error"""
        if self.current_task:
            self.current_task.errors.append(error)
    
    def end_task(self, success: bool):
        """End current task and record metrics"""
        if not self.current_task:
            return
        
        self.current_task.end_time = time.time()
        self.current_task.success = success
        self.current_task.total_cost = self.cost_tracker.get_task_cost()
        
        # Record to collector
        self.collector.record_task(self.current_task)
        
        # Log task summary
        logger.info(
            f"[{self.current_task.agent_type}] Task complete: "
            f"Duration: {self.current_task.duration():.1f}s | "
            f"Tokens: {self.current_task.input_tokens + self.current_task.output_tokens:,} | "
            f"Cost: ${self.current_task.total_cost:.4f} | "
            f"Success: {success}",
            extra={'agent_type': self.current_task.agent_type}
        )
        
        self.current_task = None
    
    def get_summary(self) -> Dict[str, Any]:
        """Get comprehensive metrics summary"""
        return self.collector.get_summary()
    
    def get_budget_status(self) -> Dict[str, Any]:
        """Get budget status"""
        return self.cost_tracker.get_budget_status()
    
    def export_metrics(self) -> Path:
        """Export all metrics to JSON"""
        return self.collector.export_to_json()
    
    def export_costs(self) -> Path:
        """Export cost tracking to JSON"""
        return self.cost_tracker.export_costs()
    
    def print_summary(self, use_logger: bool = False):
        """
        Generate and output human-readable metrics summary.

        Args:
            use_logger: If True, outputs via logger.info. If False, prints to stdout.
        """
        summary = self.get_summary()
        budget = self.get_budget_status()

        lines = []
        lines.append("\n" + "="*70)
        lines.append("  Metrics Summary")
        lines.append("="*70)

        s = summary['summary']
        lines.append(f"\nUptime: {s['uptime_hours']:.1f} hours")
        lines.append(f"Total tasks: {s['total_tasks']}")
        lines.append(f"Success rate: {s['success_rate']*100:.1f}%")
        lines.append(f"Total cost: ${s['total_cost_usd']:.2f}")
        lines.append(f"Avg cost/task: ${s['avg_cost_per_task']:.4f}")
        lines.append(f"Tasks/hour: {s['tasks_per_hour']:.1f}")

        lines.append("\n" + "-"*70)
        lines.append("  Budget Status")
        lines.append("-"*70)

        lines.append(f"\nDaily: ${budget['daily']['spent']:.2f} / ${budget['daily']['budget']:.2f} "
              f"({budget['daily']['percent_used']:.1f}%)")
        lines.append(f"Monthly: ${budget['monthly']['spent']:.2f} / ${budget['monthly']['budget']:.2f} "
              f"({budget['monthly']['percent_used']:.1f}%)")

        if budget['daily']['percent_used'] > 80:
            lines.append("WARNING: Close to daily budget limit!")

        lines.append("\n" + "-"*70)
        lines.append("  By Agent")
        lines.append("-"*70)

        for agent_type, stats in summary['by_agent'].items():
            lines.append(f"\n{agent_type}:")
            lines.append(f"  Tasks: {stats['total_tasks']} | Cost: ${stats['total_cost']:.2f}")

        output = "\n".join(lines)

        if use_logger:
            logger.info("Metrics summary:\n%s", output)
        else:
            print(output)


# Global singleton instance
_global_metrics: Optional[AgentMetrics] = None


def get_metrics(
    daily_budget: float = 100.0,
    per_task_budget: float = 5.0,
    monthly_budget: float = 2000.0
) -> AgentMetrics:
    """Get or create global metrics instance"""
    global _global_metrics
    
    if _global_metrics is None:
        _global_metrics = AgentMetrics(daily_budget, per_task_budget, monthly_budget)
    
    return _global_metrics 