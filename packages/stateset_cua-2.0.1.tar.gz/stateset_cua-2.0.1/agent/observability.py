"""
DEPRECATED: This module is deprecated. Use agent.observability package instead.

This file is kept for backward compatibility and will be removed in a future version.
Please update your imports to use:

    from agent.observability import (
        get_tracer, trace_async, trace_span,
        get_metrics_collector, PerformanceMonitor,
    )

For structured logging, use:

    from agent.logging_config import get_logger
"""

import warnings

# Issue deprecation warning on import
warnings.warn(
    "agent.observability module is deprecated. Use 'from agent.observability import ...' "
    "(the package) or 'from agent.logging_config import get_logger' instead.",
    DeprecationWarning,
    stacklevel=2
)

# Re-export from the new package for backward compatibility
from agent.observability import (
    get_tracer,
    trace_async,
    trace_sync,
    trace_span,
    get_metrics_collector as get_metrics,
    PerformanceMonitor,
    get_performance_monitor as get_monitor,
)

# Re-export logging from logging_config
from agent.logging_config import get_logger

# Legacy exports that may still be used
from agent.logging_config import (
    StructuredLoggerAdapter as StructuredLogger,
)


__all__ = [
    'get_logger',
    'get_tracer',
    'get_metrics',
    'get_monitor',
    'StructuredLogger',
    'PerformanceMonitor',
    'trace_async',
    'trace_sync',
    'trace_span',
]
