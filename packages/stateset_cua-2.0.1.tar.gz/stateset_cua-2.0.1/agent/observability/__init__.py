"""
Observability module for StateSet Computer Use Agent.

This is the canonical observability module providing:
- Unified observability facade (recommended)
- Distributed tracing with OpenTelemetry
- Metrics collection with Prometheus
- Structured logging integration
- Health monitoring and circuit breakers
- Real-time event streaming

Recommended Usage (Unified API):
    from agent.observability import get_observability, configure_observability

    # Configure at startup
    configure_observability(
        enable_metrics=True,
        enable_tracing=True,
        metrics_port=9090,
    )

    # Get singleton instance
    obs = get_observability()

    # Use context manager for automatic correlation
    async with obs.task_context("AUTO_CLOSE", "agent-123", "Close tickets"):
        obs.log_info("Starting task", tickets_count=10)

        with obs.tool_execution("computer", action="click"):
            # tool code
            pass

    # Subscribe to real-time events
    queue = obs.subscribe("my-subscriber")
    event = await queue.get()

Legacy Usage (Individual Components):
    from agent.observability import (
        get_tracer, trace_async, trace_span,
        get_metrics_collector, record_agent_execution,
        PerformanceMonitor
    )

    @trace_async
    async def my_function():
        pass

    record_agent_execution("AUTO_CLOSE", success=True, duration=1.5)
"""

from .tracing import (
    get_tracer,
    trace_async,
    trace_sync,
    trace_span,
    initialize_tracing,
    TracingManager,
    NoOpTracer,
    NoOpSpan,
    TRACING_AVAILABLE,
)
from .metrics import (
    MetricsCollector,
    get_metrics_collector,
    record_agent_execution,
    record_tool_execution,
    record_api_call,
    MetricsStatus,
    MetricLabels,
    METRICS_AVAILABLE,
)

# Re-export PerformanceMonitor for convenience
from contextlib import contextmanager
from typing import Dict, Optional
import time


class PerformanceMonitor:
    """
    Performance monitoring with automatic metric collection.

    Provides a context manager interface for measuring operation duration
    and recording metrics automatically.

    Usage:
        monitor = PerformanceMonitor(get_metrics_collector())
        with monitor.measure("api_call", {"endpoint": "/users"}):
            # code to measure
            pass
    """

    def __init__(self, metrics_collector: MetricsCollector):
        self.metrics = metrics_collector

    @contextmanager
    def measure(self, operation: str, labels: Optional[Dict[str, str]] = None):
        """
        Measure operation duration and record metrics.

        Args:
            operation: Name of the operation being measured
            labels: Optional labels for the metrics
        """
        start = time.time()
        error_occurred = False

        try:
            yield
        except Exception:
            error_occurred = True
            raise
        finally:
            duration_seconds = time.time() - start

            # Record duration
            if self.metrics._initialized:
                self.metrics.tool_duration.labels(
                    tool_name=operation
                ).observe(duration_seconds)

                # Record success/failure
                status = "failure" if error_occurred else "success"
                self.metrics.tool_executions.labels(
                    tool_name=operation,
                    status=status
                ).inc()


# Global performance monitor instance
_performance_monitor: Optional[PerformanceMonitor] = None


def get_performance_monitor() -> PerformanceMonitor:
    """Get or create the global performance monitor."""
    global _performance_monitor
    if _performance_monitor is None:
        _performance_monitor = PerformanceMonitor(get_metrics_collector())
    return _performance_monitor


# Import unified observability facade
from .unified import (
    UnifiedObservability,
    get_observability,
    configure_observability,
    observed_task,
    observed_tool,
    EventType,
    ObservableEvent,
    TaskContext,
    EventBus,
)

__all__ = [
    # Unified API (Recommended)
    'UnifiedObservability',
    'get_observability',
    'configure_observability',
    'observed_task',
    'observed_tool',
    'EventType',
    'ObservableEvent',
    'TaskContext',
    'EventBus',
    # Tracing
    'get_tracer',
    'trace_async',
    'trace_sync',
    'trace_span',
    'initialize_tracing',
    'TracingManager',
    'NoOpTracer',
    'NoOpSpan',
    'TRACING_AVAILABLE',
    # Metrics
    'MetricsCollector',
    'get_metrics_collector',
    'record_agent_execution',
    'record_tool_execution',
    'record_api_call',
    'MetricsStatus',
    'MetricLabels',
    'METRICS_AVAILABLE',
    # Performance
    'PerformanceMonitor',
    'get_performance_monitor',
]
