"""
Prometheus metrics collection for agent performance monitoring.

Metrics tracked:
- Agent execution duration and count
- Tool execution performance
- API call latency
- Token usage and cost
- Error rates
"""

import logging
import time
from typing import Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

try:
    from prometheus_client import Counter, Histogram, Gauge, start_http_server, REGISTRY
    METRICS_AVAILABLE = True
except ImportError:
    METRICS_AVAILABLE = False


class MetricsStatus(Enum):
    """Status codes for operations."""
    SUCCESS = "success"
    FAILURE = "failure"
    ERROR = "error"


@dataclass
class MetricLabels:
    """Common labels for metrics."""
    agent_type: str
    tool_name: Optional[str] = None
    model_name: Optional[str] = None
    status: str = MetricsStatus.SUCCESS.value


class MetricsCollector:
    """Collects and exposes Prometheus metrics."""

    def __init__(self, port: int = 9090):
        self.port = port
        self._initialized = False
        self._server_started = False

        if not METRICS_AVAILABLE:
            logger.warning("prometheus_client not installed. Metrics disabled.")
            return

        # Agent execution metrics
        self.agent_executions = Counter(
            'agent_executions_total',
            'Total number of agent executions',
            ['agent_type', 'status']
        )

        self.agent_duration = Histogram(
            'agent_execution_duration_seconds',
            'Agent execution duration in seconds',
            ['agent_type'],
            buckets=[1, 5, 10, 30, 60, 120, 300, 600]
        )

        # Tool execution metrics
        self.tool_executions = Counter(
            'tool_executions_total',
            'Total number of tool executions',
            ['tool_name', 'status']
        )

        self.tool_duration = Histogram(
            'tool_execution_duration_seconds',
            'Tool execution duration in seconds',
            ['tool_name'],
            buckets=[0.1, 0.5, 1, 2, 5, 10, 30]
        )

        # API call metrics
        self.api_calls = Counter(
            'api_calls_total',
            'Total number of API calls',
            ['provider', 'model', 'status']
        )

        self.api_latency = Histogram(
            'api_call_latency_seconds',
            'API call latency in seconds',
            ['provider', 'model'],
            buckets=[0.5, 1, 2, 5, 10, 30, 60]
        )

        # Token usage metrics
        self.tokens_used = Counter(
            'tokens_used_total',
            'Total tokens used',
            ['model', 'token_type']  # token_type: input, output, cached
        )

        # Cost metrics
        self.cost_total = Counter(
            'cost_dollars_total',
            'Total cost in dollars',
            ['model']
        )

        # Active agents
        self.active_agents = Gauge(
            'active_agents',
            'Number of currently active agents',
            ['agent_type']
        )

        # Error metrics
        self.errors = Counter(
            'errors_total',
            'Total number of errors',
            ['component', 'error_type']
        )

        self._initialized = True

    def start_metrics_server(self):
        """Start Prometheus metrics HTTP server."""
        if not METRICS_AVAILABLE or not self._initialized:
            return

        if self._server_started:
            return

        try:
            start_http_server(self.port)
            self._server_started = True
            logger.info("Metrics server started on port %d", self.port)
        except Exception as e:
            logger.error("Failed to start metrics server: %s", e)

    def record_agent_execution(
        self,
        agent_type: str,
        duration: float,
        status: MetricsStatus = MetricsStatus.SUCCESS
    ):
        """Record an agent execution."""
        if not self._initialized:
            return

        self.agent_executions.labels(
            agent_type=agent_type,
            status=status.value
        ).inc()

        self.agent_duration.labels(
            agent_type=agent_type
        ).observe(duration)

    def record_tool_execution(
        self,
        tool_name: str,
        duration: float,
        status: MetricsStatus = MetricsStatus.SUCCESS
    ):
        """Record a tool execution."""
        if not self._initialized:
            return

        self.tool_executions.labels(
            tool_name=tool_name,
            status=status.value
        ).inc()

        self.tool_duration.labels(
            tool_name=tool_name
        ).observe(duration)

    def record_api_call(
        self,
        provider: str,
        model: str,
        latency: float,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int = 0,
        cost: float = 0.0,
        status: MetricsStatus = MetricsStatus.SUCCESS
    ):
        """Record an API call with token usage and cost."""
        if not self._initialized:
            return

        self.api_calls.labels(
            provider=provider,
            model=model,
            status=status.value
        ).inc()

        self.api_latency.labels(
            provider=provider,
            model=model
        ).observe(latency)

        # Record token usage
        self.tokens_used.labels(
            model=model,
            token_type="input"
        ).inc(input_tokens)

        self.tokens_used.labels(
            model=model,
            token_type="output"
        ).inc(output_tokens)

        if cached_tokens > 0:
            self.tokens_used.labels(
                model=model,
                token_type="cached"
            ).inc(cached_tokens)

        # Record cost
        if cost > 0:
            self.cost_total.labels(model=model).inc(cost)

    def record_error(self, component: str, error_type: str):
        """Record an error."""
        if not self._initialized:
            return

        self.errors.labels(
            component=component,
            error_type=error_type
        ).inc()

    def set_active_agents(self, agent_type: str, count: int):
        """Set the number of active agents."""
        if not self._initialized:
            return

        self.active_agents.labels(agent_type=agent_type).set(count)


# Global metrics collector
_metrics_collector: Optional[MetricsCollector] = None


def get_metrics_collector(port: int = 9090) -> MetricsCollector:
    """Get the global metrics collector instance."""
    global _metrics_collector

    if _metrics_collector is None:
        _metrics_collector = MetricsCollector(port)

    return _metrics_collector


def start_metrics_server(port: int = 9090):
    """Start the Prometheus metrics server."""
    collector = get_metrics_collector(port)
    collector.start_metrics_server()


# Convenience functions
def record_agent_execution(agent_type: str, duration: float, status: MetricsStatus = MetricsStatus.SUCCESS):
    """Record an agent execution."""
    get_metrics_collector().record_agent_execution(agent_type, duration, status)


def record_tool_execution(tool_name: str, duration: float, status: MetricsStatus = MetricsStatus.SUCCESS):
    """Record a tool execution."""
    get_metrics_collector().record_tool_execution(tool_name, duration, status)


def record_api_call(
    provider: str,
    model: str,
    latency: float,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
    cost: float = 0.0,
    status: MetricsStatus = MetricsStatus.SUCCESS
):
    """Record an API call."""
    get_metrics_collector().record_api_call(
        provider, model, latency, input_tokens, output_tokens,
        cached_tokens, cost, status
    )
