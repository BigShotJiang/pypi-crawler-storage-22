"""
Distributed tracing with OpenTelemetry for agent execution monitoring.

Features:
- Full execution path tracing
- Tool execution spans
- API call tracking
- Error recording
- Custom attributes
"""

import functools
import logging
from typing import Any, Callable, Dict, Optional
from contextlib import contextmanager

logger = logging.getLogger(__name__)

try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    TRACING_AVAILABLE = True
except ImportError:
    TRACING_AVAILABLE = False
    trace = None


class TracingManager:
    """Manages OpenTelemetry tracing setup and lifecycle."""

    def __init__(self):
        self._initialized = False
        self._tracer = None

    def initialize(
        self,
        service_name: str = "stateset-agent",
        otlp_endpoint: Optional[str] = None
    ):
        """
        Initialize OpenTelemetry tracing.

        Args:
            service_name: Name of the service for tracing
            otlp_endpoint: OTLP collector endpoint (e.g., "localhost:4317")
        """
        if not TRACING_AVAILABLE:
            logger.warning("OpenTelemetry not installed. Tracing disabled.")
            return

        if self._initialized:
            return

        # Create resource with service information
        resource = Resource.create({
            "service.name": service_name,
            "service.version": "1.0.0",
        })

        # Create tracer provider
        provider = TracerProvider(resource=resource)

        # Add OTLP exporter if endpoint provided
        if otlp_endpoint:
            otlp_exporter = OTLPSpanExporter(endpoint=otlp_endpoint)
            processor = BatchSpanProcessor(otlp_exporter)
            provider.add_span_processor(processor)

        # Set global tracer provider
        trace.set_tracer_provider(provider)

        # Get tracer
        self._tracer = trace.get_tracer(__name__)
        self._initialized = True

        logger.info("Tracing initialized for %s", service_name)

    def get_tracer(self):
        """Get the tracer instance."""
        if not TRACING_AVAILABLE:
            return NoOpTracer()

        if not self._initialized:
            self.initialize()

        return self._tracer or NoOpTracer()


class NoOpTracer:
    """No-op tracer for when OpenTelemetry is not available."""

    @contextmanager
    def start_as_current_span(self, name: str, **kwargs):
        """No-op span context manager."""
        yield NoOpSpan()


class NoOpSpan:
    """No-op span for when tracing is disabled."""

    def set_attribute(self, key: str, value: Any):
        pass

    def record_exception(self, exception: Exception):
        pass

    def set_status(self, status):
        pass


# Global tracing manager
_tracing_manager = TracingManager()


def get_tracer():
    """Get the global tracer instance."""
    return _tracing_manager.get_tracer()


def trace_async(func: Callable) -> Callable:
    """
    Decorator for tracing async functions.

    Usage:
        @trace_async
        async def my_function(arg1, arg2):
            # function code
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        tracer = get_tracer()
        span_name = f"{func.__module__}.{func.__name__}"

        with tracer.start_as_current_span(span_name) as span:
            # Add function arguments as attributes
            span.set_attribute("function.name", func.__name__)
            span.set_attribute("function.module", func.__module__)

            try:
                result = await func(*args, **kwargs)
                span.set_attribute("success", True)
                return result
            except Exception as e:
                span.record_exception(e)
                span.set_attribute("success", False)
                raise

    return wrapper


def trace_sync(func: Callable) -> Callable:
    """
    Decorator for tracing synchronous functions.

    Usage:
        @trace_sync
        def my_function(arg1, arg2):
            # function code
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        tracer = get_tracer()
        span_name = f"{func.__module__}.{func.__name__}"

        with tracer.start_as_current_span(span_name) as span:
            # Add function arguments as attributes
            span.set_attribute("function.name", func.__name__)
            span.set_attribute("function.module", func.__module__)

            try:
                result = func(*args, **kwargs)
                span.set_attribute("success", True)
                return result
            except Exception as e:
                span.record_exception(e)
                span.set_attribute("success", False)
                raise

    return wrapper


@contextmanager
def trace_span(name: str, attributes: Optional[Dict[str, Any]] = None):
    """
    Context manager for creating custom trace spans.

    Usage:
        with trace_span("my_operation", {"key": "value"}):
            # operation code
    """
    tracer = get_tracer()

    with tracer.start_as_current_span(name) as span:
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, value)

        try:
            yield span
        except Exception as e:
            span.record_exception(e)
            raise


def initialize_tracing(service_name: str = "stateset-agent", otlp_endpoint: Optional[str] = None):
    """
    Initialize distributed tracing.

    Args:
        service_name: Name of the service
        otlp_endpoint: OTLP collector endpoint
    """
    _tracing_manager.initialize(service_name, otlp_endpoint)


# ============================================================================
# Specialized Tracing Decorators for Critical Paths
# ============================================================================

def trace_tool_execution(tool_name: str):
    """
    Decorator for tracing tool executions with tool-specific attributes.

    Usage:
        @trace_tool_execution("bash")
        async def execute_bash(command: str) -> ToolResult:
            # tool implementation
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            tracer = get_tracer()
            span_name = f"tool.{tool_name}"

            with tracer.start_as_current_span(span_name) as span:
                span.set_attribute("tool.name", tool_name)
                span.set_attribute("tool.type", "computer_use")

                # Extract relevant input attributes
                if args:
                    span.set_attribute("tool.has_args", True)
                if kwargs:
                    # Safely extract non-sensitive kwargs
                    safe_keys = ["action", "coordinate", "text"]
                    for key in safe_keys:
                        if key in kwargs:
                            span.set_attribute(f"tool.input.{key}", str(kwargs[key])[:100])

                start_time = __import__("time").time()
                try:
                    result = await func(*args, **kwargs)
                    span.set_attribute("tool.success", True)
                    span.set_attribute("tool.has_output", bool(getattr(result, 'output', None)))
                    span.set_attribute("tool.has_error", bool(getattr(result, 'error', None)))
                    return result
                except Exception as e:
                    span.record_exception(e)
                    span.set_attribute("tool.success", False)
                    span.set_attribute("tool.error_type", type(e).__name__)
                    raise
                finally:
                    duration = __import__("time").time() - start_time
                    span.set_attribute("tool.duration_ms", duration * 1000)

        return wrapper
    return decorator


def trace_api_call(provider: str):
    """
    Decorator for tracing API calls with provider-specific attributes.

    Usage:
        @trace_api_call("anthropic")
        async def call_claude(messages: list) -> BetaMessage:
            # API call implementation
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            tracer = get_tracer()
            span_name = f"api.{provider}"

            with tracer.start_as_current_span(span_name) as span:
                span.set_attribute("api.provider", provider)
                span.set_attribute("api.operation", func.__name__)

                # Extract model if available
                model = kwargs.get("model")
                if model:
                    span.set_attribute("api.model", model)

                start_time = __import__("time").time()
                try:
                    result = await func(*args, **kwargs)
                    span.set_attribute("api.success", True)

                    # Extract token usage if available
                    if hasattr(result, "usage"):
                        usage = result.usage
                        if hasattr(usage, "input_tokens"):
                            span.set_attribute("api.input_tokens", usage.input_tokens)
                        if hasattr(usage, "output_tokens"):
                            span.set_attribute("api.output_tokens", usage.output_tokens)

                    return result
                except Exception as e:
                    span.record_exception(e)
                    span.set_attribute("api.success", False)
                    span.set_attribute("api.error_type", type(e).__name__)
                    raise
                finally:
                    duration = __import__("time").time() - start_time
                    span.set_attribute("api.duration_ms", duration * 1000)

        return wrapper
    return decorator


def trace_agent_task(agent_type: str):
    """
    Decorator for tracing agent task executions.

    Usage:
        @trace_agent_task("AUTO_CLOSE")
        async def run_auto_close_task(instruction: str) -> TaskStatus:
            # task implementation
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            tracer = get_tracer()
            span_name = f"agent.{agent_type.lower()}"

            with tracer.start_as_current_span(span_name) as span:
                span.set_attribute("agent.type", agent_type)
                span.set_attribute("agent.task", func.__name__)

                # Extract instruction if available
                instruction = kwargs.get("instruction") or (args[0] if args else None)
                if instruction and isinstance(instruction, str):
                    span.set_attribute("agent.instruction_length", len(instruction))
                    span.set_attribute("agent.instruction_preview", instruction[:100])

                start_time = __import__("time").time()
                try:
                    result = await func(*args, **kwargs)
                    span.set_attribute("agent.success", True)

                    # Extract completion status if available
                    if hasattr(result, "completed"):
                        span.set_attribute("agent.completed", result.completed)
                    if hasattr(result, "tokens_used"):
                        span.set_attribute("agent.tokens_used", result.tokens_used)

                    return result
                except Exception as e:
                    span.record_exception(e)
                    span.set_attribute("agent.success", False)
                    span.set_attribute("agent.error_type", type(e).__name__)
                    raise
                finally:
                    duration = __import__("time").time() - start_time
                    span.set_attribute("agent.duration_seconds", duration)

        return wrapper
    return decorator


class TracingContext:
    """
    Context manager for creating custom trace spans with automatic cleanup.

    Usage:
        async with TracingContext("process_batch", batch_size=100) as span:
            span.set_attribute("processed", processed_count)
            # processing logic
    """

    def __init__(self, name: str, **attributes):
        self.name = name
        self.attributes = attributes
        self._span = None
        self._context = None

    async def __aenter__(self):
        tracer = get_tracer()
        self._context = tracer.start_as_current_span(self.name)
        self._span = self._context.__enter__()

        for key, value in self.attributes.items():
            self._span.set_attribute(key, value)

        return self._span

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self._span.record_exception(exc_val)
            self._span.set_attribute("error", True)

        self._context.__exit__(exc_type, exc_val, exc_tb)
        return False
