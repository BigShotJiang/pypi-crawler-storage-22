"""
Unified Observability Facade for StateSet Computer Use Agent.

This module provides a single interface for all observability concerns:
- Structured logging with correlation IDs
- Distributed tracing (OpenTelemetry)
- Prometheus metrics
- Health monitoring
- Real-time event streaming

Usage:
    from agent.observability.unified import get_observability, ObservabilityContext

    # Get the singleton instance
    obs = get_observability()

    # Use context manager for automatic correlation
    async with obs.task_context("AUTO_CLOSE", "task-123", instruction="Close tickets"):
        obs.log_info("Starting task", tickets_count=10)

        with obs.span("process_ticket", ticket_id="TKT-001"):
            obs.record_tool_execution("computer", duration=1.5)

    # Or use individual methods
    obs.log_info("Message", key="value")
    obs.record_api_call(provider="anthropic", model="opus", latency=2.5, ...)
"""

import asyncio
import json
import time
import uuid
from contextlib import contextmanager, asynccontextmanager
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set
from collections import deque
import threading

# Import existing modules
from agent.logging_config import (
    get_logger,
    request_context,
    set_request_id,
    get_request_id,
    set_agent_context,
    clear_agent_context,
    log_error,
    log_metric,
    log_event,
    StructuredLoggerAdapter,
)

from agent.observability.tracing import (
    get_tracer,
    trace_span,
    initialize_tracing,
    TRACING_AVAILABLE,
)

from agent.observability.metrics import (
    get_metrics_collector,
    start_metrics_server,
    record_agent_execution,
    record_tool_execution,
    record_api_call,
    MetricsStatus,
    METRICS_AVAILABLE,
)

from agent.health import (
    get_health_checker,
    HealthStatus,
    SystemHealth,
    CircuitBreaker,
    CircuitBreakerOpen,
)


class EventType(Enum):
    """Types of observable events for streaming."""
    TASK_START = "task_start"
    TASK_END = "task_end"
    ITERATION_START = "iteration_start"
    ITERATION_END = "iteration_end"
    TOOL_START = "tool_start"
    TOOL_END = "tool_end"
    API_CALL = "api_call"
    ERROR = "error"
    METRIC = "metric"
    HEALTH_CHECK = "health_check"
    BUDGET_WARNING = "budget_warning"
    CONTEXT_COMPACTION = "context_compaction"


@dataclass
class ObservableEvent:
    """An observable event that can be streamed to subscribers."""
    event_type: EventType
    timestamp: datetime
    request_id: Optional[str]
    agent_type: Optional[str]
    agent_id: Optional[str]
    data: Dict[str, Any]
    duration_ms: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "request_id": self.request_id,
            "agent_type": self.agent_type,
            "agent_id": self.agent_id,
            "data": self.data,
            "duration_ms": self.duration_ms,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)


@dataclass
class TaskContext:
    """Context for a single task execution."""
    request_id: str
    agent_type: str
    agent_id: str
    instruction: str
    start_time: float
    iteration: int = 0
    tool_calls: int = 0
    api_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    errors: List[str] = field(default_factory=list)

    def duration_seconds(self) -> float:
        return time.time() - self.start_time


class EventBus:
    """
    In-memory event bus for real-time observability streaming.

    Supports multiple subscribers with optional filtering.
    Events are stored in a bounded buffer for late subscribers.
    """

    def __init__(self, buffer_size: int = 1000):
        self._subscribers: Dict[str, asyncio.Queue] = {}
        self._filters: Dict[str, Set[EventType]] = {}
        self._buffer: deque = deque(maxlen=buffer_size)
        self._lock = threading.Lock()

    def subscribe(
        self,
        subscriber_id: str,
        event_types: Optional[Set[EventType]] = None,
        replay_buffer: bool = False
    ) -> asyncio.Queue:
        """
        Subscribe to events.

        Args:
            subscriber_id: Unique identifier for this subscriber
            event_types: Optional filter - only receive these event types
            replay_buffer: If True, replay buffered events to new subscriber

        Returns:
            Queue to receive events from
        """
        queue: asyncio.Queue = asyncio.Queue()

        with self._lock:
            self._subscribers[subscriber_id] = queue
            if event_types:
                self._filters[subscriber_id] = event_types

            if replay_buffer:
                for event in self._buffer:
                    if not event_types or event.event_type in event_types:
                        queue.put_nowait(event)

        return queue

    def unsubscribe(self, subscriber_id: str):
        """Unsubscribe from events."""
        with self._lock:
            self._subscribers.pop(subscriber_id, None)
            self._filters.pop(subscriber_id, None)

    def publish(self, event: ObservableEvent):
        """Publish an event to all subscribers."""
        with self._lock:
            self._buffer.append(event)

            for sub_id, queue in self._subscribers.items():
                event_filter = self._filters.get(sub_id)
                if not event_filter or event.event_type in event_filter:
                    try:
                        queue.put_nowait(event)
                    except asyncio.QueueFull:
                        # Drop events if subscriber is too slow
                        pass

    def get_recent_events(
        self,
        count: int = 100,
        event_types: Optional[Set[EventType]] = None
    ) -> List[ObservableEvent]:
        """Get recent events from buffer."""
        with self._lock:
            events = list(self._buffer)
            if event_types:
                events = [e for e in events if e.event_type in event_types]
            return events[-count:]


class UnifiedObservability:
    """
    Unified observability facade providing a single interface for:
    - Structured logging
    - Distributed tracing
    - Prometheus metrics
    - Health monitoring
    - Real-time event streaming

    Thread-safe singleton pattern.
    """

    _instance: Optional["UnifiedObservability"] = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._initialized = True

        # Core components
        self._logger = get_logger(__name__)
        self._tracer = get_tracer()
        self._metrics = get_metrics_collector()
        self._health_checker = get_health_checker()
        self._event_bus = EventBus()

        # Circuit breakers for external services
        self._circuit_breakers: Dict[str, CircuitBreaker] = {}

        # Current context tracking (per-task)
        self._task_contexts: Dict[str, TaskContext] = {}
        self._context_lock = threading.Lock()

        # Configuration
        self._metrics_enabled = METRICS_AVAILABLE
        self._tracing_enabled = TRACING_AVAILABLE
        self._streaming_enabled = True

    # ========================================================================
    # Configuration
    # ========================================================================

    def configure(
        self,
        enable_metrics: bool = True,
        enable_tracing: bool = True,
        enable_streaming: bool = True,
        metrics_port: int = 9090,
        otlp_endpoint: Optional[str] = None,
        service_name: str = "stateset-agent",
    ):
        """
        Configure observability components.

        Call this once at application startup.
        """
        self._metrics_enabled = enable_metrics and METRICS_AVAILABLE
        self._tracing_enabled = enable_tracing and TRACING_AVAILABLE
        self._streaming_enabled = enable_streaming

        # Initialize tracing
        if self._tracing_enabled and otlp_endpoint:
            initialize_tracing(service_name, otlp_endpoint)

        # Start metrics server
        if self._metrics_enabled:
            start_metrics_server(metrics_port)

        self._logger.info(
            "Observability configured",
            metrics_enabled=self._metrics_enabled,
            tracing_enabled=self._tracing_enabled,
            streaming_enabled=self._streaming_enabled,
        )

    # ========================================================================
    # Context Management
    # ========================================================================

    @asynccontextmanager
    async def task_context(
        self,
        agent_type: str,
        agent_id: str,
        instruction: str,
        request_id: Optional[str] = None,
    ):
        """
        Context manager for task execution with automatic observability.

        Usage:
            async with obs.task_context("AUTO_CLOSE", "agent-123", "Close tickets"):
                # Task code here - all logging/metrics auto-correlated
                pass
        """
        request_id = request_id or str(uuid.uuid4())
        start_time = time.time()

        # Create task context
        ctx = TaskContext(
            request_id=request_id,
            agent_type=agent_type,
            agent_id=agent_id,
            instruction=instruction,
            start_time=start_time,
        )

        with self._context_lock:
            self._task_contexts[request_id] = ctx

        # Set up logging context
        with request_context(request_id=request_id, agent_type=agent_type, agent_id=agent_id):
            # Emit task start event
            self._emit_event(EventType.TASK_START, {
                "instruction": instruction[:200],
                "agent_type": agent_type,
                "agent_id": agent_id,
            }, request_id=request_id, agent_type=agent_type, agent_id=agent_id)

            # Create root span for tracing
            with trace_span(f"task.{agent_type.lower()}", {
                "agent.type": agent_type,
                "agent.id": agent_id,
                "task.instruction": instruction[:100],
            }) as span:
                try:
                    self.log_info(
                        "Task started",
                        instruction_length=len(instruction),
                    )

                    yield ctx

                    # Task completed successfully
                    duration = ctx.duration_seconds()
                    self.log_info(
                        "Task completed",
                        duration_seconds=duration,
                        iterations=ctx.iteration,
                        tool_calls=ctx.tool_calls,
                        input_tokens=ctx.input_tokens,
                        output_tokens=ctx.output_tokens,
                    )

                    # Record metrics
                    if self._metrics_enabled:
                        record_agent_execution(agent_type, duration, MetricsStatus.SUCCESS)

                    # Emit completion event
                    self._emit_event(EventType.TASK_END, {
                        "success": True,
                        "duration_seconds": duration,
                        "iterations": ctx.iteration,
                        "tool_calls": ctx.tool_calls,
                        "input_tokens": ctx.input_tokens,
                        "output_tokens": ctx.output_tokens,
                    }, request_id=request_id, agent_type=agent_type, agent_id=agent_id,
                    duration_ms=duration * 1000)

                except Exception as e:
                    duration = ctx.duration_seconds()
                    ctx.errors.append(str(e))

                    self.log_error("Task failed", e, duration_seconds=duration)

                    # Record failure metrics
                    if self._metrics_enabled:
                        record_agent_execution(agent_type, duration, MetricsStatus.FAILURE)
                        self._metrics.record_error("agent", type(e).__name__)

                    # Emit error event
                    self._emit_event(EventType.ERROR, {
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "duration_seconds": duration,
                    }, request_id=request_id, agent_type=agent_type, agent_id=agent_id)

                    raise
                finally:
                    # Cleanup
                    with self._context_lock:
                        self._task_contexts.pop(request_id, None)

    @contextmanager
    def iteration_context(self, request_id: str, iteration: int):
        """
        Context manager for a single iteration within a task.

        Usage:
            with obs.iteration_context(request_id, iteration=1):
                # Iteration code here
                pass
        """
        ctx = self._get_task_context(request_id)
        if ctx:
            ctx.iteration = iteration

        start_time = time.time()

        self._emit_event(EventType.ITERATION_START, {
            "iteration": iteration,
        }, request_id=request_id, agent_type=ctx.agent_type if ctx else None)

        self.log_debug(f"Iteration {iteration} started")

        try:
            yield
        finally:
            duration_ms = (time.time() - start_time) * 1000
            self._emit_event(EventType.ITERATION_END, {
                "iteration": iteration,
            }, request_id=request_id, agent_type=ctx.agent_type if ctx else None,
            duration_ms=duration_ms)

            self.log_debug(f"Iteration {iteration} completed", duration_ms=duration_ms)

    @contextmanager
    def span(self, name: str, **attributes):
        """
        Create a trace span.

        Usage:
            with obs.span("process_ticket", ticket_id="TKT-001"):
                # Span code here
                pass
        """
        with trace_span(name, attributes) as span:
            yield span

    # ========================================================================
    # Logging Methods
    # ========================================================================

    def _get_logger(self) -> StructuredLoggerAdapter:
        """Get contextual logger."""
        request_id = get_request_id()
        if request_id:
            ctx = self._get_task_context(request_id)
            if ctx:
                return get_logger(__name__, agent_type=ctx.agent_type, agent_id=ctx.agent_id)
        return self._logger

    def log_debug(self, message: str, **kwargs):
        """Log at DEBUG level."""
        self._get_logger().debug(message, **kwargs)

    def log_info(self, message: str, **kwargs):
        """Log at INFO level."""
        self._get_logger().info(message, **kwargs)

    def log_warning(self, message: str, **kwargs):
        """Log at WARNING level."""
        self._get_logger().warning(message, **kwargs)

    def log_error(self, message: str, error: Optional[Exception] = None, **kwargs):
        """Log at ERROR level with optional exception."""
        logger = self._get_logger()
        if error:
            log_error(logger, message, error, **kwargs)
        else:
            logger.error(message, **kwargs)

    def log_metric(self, metric_name: str, value: float, unit: str = "", **kwargs):
        """Log a metric value."""
        log_metric(self._get_logger(), metric_name, value, unit, **kwargs)

        self._emit_event(EventType.METRIC, {
            "metric_name": metric_name,
            "value": value,
            "unit": unit,
            **kwargs,
        })

    def log_event(self, event_name: str, **kwargs):
        """Log a structured event."""
        log_event(self._get_logger(), event_name, **kwargs)

    # ========================================================================
    # Tool Execution Recording
    # ========================================================================

    @contextmanager
    def tool_execution(self, tool_name: str, **attributes):
        """
        Context manager for recording tool execution.

        Usage:
            with obs.tool_execution("bash", command="ls -la"):
                result = await tool.execute()
        """
        request_id = get_request_id()
        ctx = self._get_task_context(request_id) if request_id else None

        start_time = time.time()

        # Emit tool start event
        self._emit_event(EventType.TOOL_START, {
            "tool_name": tool_name,
            **{k: str(v)[:100] for k, v in attributes.items()},  # Truncate long values
        }, request_id=request_id, agent_type=ctx.agent_type if ctx else None)

        # Create trace span
        with trace_span(f"tool.{tool_name}", {"tool.name": tool_name, **attributes}):
            status = MetricsStatus.SUCCESS
            error_info = None

            try:
                yield
            except Exception as e:
                status = MetricsStatus.FAILURE
                error_info = {"type": type(e).__name__, "message": str(e)}
                raise
            finally:
                duration = time.time() - start_time

                # Update task context
                if ctx:
                    ctx.tool_calls += 1

                # Record metrics
                if self._metrics_enabled:
                    record_tool_execution(tool_name, duration, status)

                # Emit tool end event
                self._emit_event(EventType.TOOL_END, {
                    "tool_name": tool_name,
                    "success": status == MetricsStatus.SUCCESS,
                    "error": error_info,
                }, request_id=request_id, agent_type=ctx.agent_type if ctx else None,
                duration_ms=duration * 1000)

                self.log_debug(
                    f"Tool {tool_name} completed",
                    duration_ms=duration * 1000,
                    success=status == MetricsStatus.SUCCESS,
                )

    def record_tool_execution_simple(
        self,
        tool_name: str,
        duration: float,
        success: bool = True,
        request_id: Optional[str] = None,
    ):
        """
        Record a tool execution without context manager.

        Use this when you can't use the context manager pattern.
        """
        status = MetricsStatus.SUCCESS if success else MetricsStatus.FAILURE

        request_id = request_id or get_request_id()
        ctx = self._get_task_context(request_id) if request_id else None

        if ctx:
            ctx.tool_calls += 1

        if self._metrics_enabled:
            record_tool_execution(tool_name, duration, status)

        self._emit_event(EventType.TOOL_END, {
            "tool_name": tool_name,
            "success": success,
        }, request_id=request_id, agent_type=ctx.agent_type if ctx else None,
        duration_ms=duration * 1000)

    # ========================================================================
    # API Call Recording
    # ========================================================================

    def record_api_call(
        self,
        provider: str,
        model: str,
        latency: float,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int = 0,
        cost: float = 0.0,
        success: bool = True,
        request_id: Optional[str] = None,
    ):
        """Record an API call with token usage."""
        status = MetricsStatus.SUCCESS if success else MetricsStatus.FAILURE

        request_id = request_id or get_request_id()
        ctx = self._get_task_context(request_id) if request_id else None

        # Update task context
        if ctx:
            ctx.api_calls += 1
            ctx.input_tokens += input_tokens
            ctx.output_tokens += output_tokens

        # Record metrics
        if self._metrics_enabled:
            record_api_call(
                provider, model, latency,
                input_tokens, output_tokens, cached_tokens,
                cost, status
            )

        # Emit event
        self._emit_event(EventType.API_CALL, {
            "provider": provider,
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cached_tokens": cached_tokens,
            "cost": cost,
            "success": success,
        }, request_id=request_id, agent_type=ctx.agent_type if ctx else None,
        duration_ms=latency * 1000)

        self.log_debug(
            "API call completed",
            provider=provider,
            model=model,
            latency_ms=latency * 1000,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )

    # ========================================================================
    # Budget & Context Monitoring
    # ========================================================================

    def record_budget_warning(
        self,
        warning_type: str,
        current_value: float,
        threshold: float,
        unit: str = "tokens",
        request_id: Optional[str] = None,
    ):
        """Record a budget warning (token usage, cost, etc.)."""
        request_id = request_id or get_request_id()
        ctx = self._get_task_context(request_id) if request_id else None

        self.log_warning(
            f"Budget warning: {warning_type}",
            current_value=current_value,
            threshold=threshold,
            unit=unit,
        )

        self._emit_event(EventType.BUDGET_WARNING, {
            "warning_type": warning_type,
            "current_value": current_value,
            "threshold": threshold,
            "unit": unit,
        }, request_id=request_id, agent_type=ctx.agent_type if ctx else None)

        # Alert routing based on severity
        percent_used = (current_value / threshold * 100) if threshold > 0 else 0
        if percent_used >= 90:
            self._route_alert(
                severity="critical",
                title=f"Budget {warning_type} at {percent_used:.0f}%",
                details={"current": current_value, "threshold": threshold, "unit": unit},
                request_id=request_id,
            )
        elif percent_used >= 80:
            self._route_alert(
                severity="warning",
                title=f"Budget {warning_type} at {percent_used:.0f}%",
                details={"current": current_value, "threshold": threshold, "unit": unit},
                request_id=request_id,
            )

    def _route_alert(
        self,
        severity: str,
        title: str,
        details: dict,
        request_id: Optional[str] = None,
    ):
        """Route alerts via logging + SSE event + optional webhook."""
        import os

        log_fn = self.log_error if severity == "critical" else self.log_warning
        log_fn(f"ALERT [{severity.upper()}]: {title}", **details)

        self._emit_event(EventType.BUDGET_WARNING, {
            "alert": True,
            "severity": severity,
            "title": title,
            **details,
        }, request_id=request_id)

        webhook_url = os.environ.get("ALERT_WEBHOOK_URL")
        if webhook_url:
            try:
                import httpx
                httpx.post(
                    webhook_url,
                    json={"severity": severity, "title": title, "details": details},
                    timeout=5.0,
                )
            except Exception as e:
                self.log_error(f"Failed to send alert webhook: {e}")

    def record_context_compaction(
        self,
        cleared_tool_uses: int,
        cleared_tokens: int,
        request_id: Optional[str] = None,
    ):
        """Record when context management clears old tool results."""
        request_id = request_id or get_request_id()
        ctx = self._get_task_context(request_id) if request_id else None

        self.log_info(
            "Context compacted",
            cleared_tool_uses=cleared_tool_uses,
            cleared_tokens=cleared_tokens,
        )

        self._emit_event(EventType.CONTEXT_COMPACTION, {
            "cleared_tool_uses": cleared_tool_uses,
            "cleared_tokens": cleared_tokens,
        }, request_id=request_id, agent_type=ctx.agent_type if ctx else None)

    # ========================================================================
    # Health Monitoring
    # ========================================================================

    async def get_health(self) -> SystemHealth:
        """Get current system health."""
        return await self._health_checker.get_system_health()

    async def check_health_and_emit(self):
        """Check health and emit event."""
        health = await self.get_health()

        self._emit_event(EventType.HEALTH_CHECK, health.to_dict())

        if health.status == HealthStatus.UNHEALTHY:
            self.log_error("System unhealthy", checks=[c.name for c in health.checks if c.status == HealthStatus.UNHEALTHY])
        elif health.status == HealthStatus.DEGRADED:
            self.log_warning("System degraded", checks=[c.name for c in health.checks if c.status == HealthStatus.DEGRADED])

        return health

    def get_circuit_breaker(self, name: str, **kwargs) -> CircuitBreaker:
        """Get or create a circuit breaker."""
        if name not in self._circuit_breakers:
            self._circuit_breakers[name] = self._health_checker.register_circuit_breaker(name, **kwargs)
        return self._circuit_breakers[name]

    # ========================================================================
    # Event Streaming
    # ========================================================================

    def subscribe(
        self,
        subscriber_id: str,
        event_types: Optional[Set[EventType]] = None,
        replay_buffer: bool = False,
    ) -> asyncio.Queue:
        """Subscribe to real-time events."""
        return self._event_bus.subscribe(subscriber_id, event_types, replay_buffer)

    def unsubscribe(self, subscriber_id: str):
        """Unsubscribe from events."""
        self._event_bus.unsubscribe(subscriber_id)

    def get_recent_events(
        self,
        count: int = 100,
        event_types: Optional[Set[EventType]] = None,
    ) -> List[ObservableEvent]:
        """Get recent events from buffer."""
        return self._event_bus.get_recent_events(count, event_types)

    def _emit_event(
        self,
        event_type: EventType,
        data: Dict[str, Any],
        request_id: Optional[str] = None,
        agent_type: Optional[str] = None,
        agent_id: Optional[str] = None,
        duration_ms: Optional[float] = None,
    ):
        """Emit an observable event."""
        if not self._streaming_enabled:
            return

        event = ObservableEvent(
            event_type=event_type,
            timestamp=datetime.utcnow(),
            request_id=request_id or get_request_id(),
            agent_type=agent_type,
            agent_id=agent_id,
            data=data,
            duration_ms=duration_ms,
        )

        self._event_bus.publish(event)

    # ========================================================================
    # Utilities
    # ========================================================================

    def _get_task_context(self, request_id: str) -> Optional[TaskContext]:
        """Get task context by request ID."""
        with self._context_lock:
            return self._task_contexts.get(request_id)

    def get_active_tasks(self) -> List[Dict[str, Any]]:
        """Get summary of all active tasks."""
        with self._context_lock:
            return [
                {
                    "request_id": ctx.request_id,
                    "agent_type": ctx.agent_type,
                    "duration_seconds": ctx.duration_seconds(),
                    "iteration": ctx.iteration,
                    "tool_calls": ctx.tool_calls,
                }
                for ctx in self._task_contexts.values()
            ]


# ============================================================================
# Module-level Singleton Access
# ============================================================================

_observability: Optional[UnifiedObservability] = None


def get_observability() -> UnifiedObservability:
    """Get the global observability instance."""
    global _observability
    if _observability is None:
        _observability = UnifiedObservability()
    return _observability


def configure_observability(
    enable_metrics: bool = True,
    enable_tracing: bool = True,
    enable_streaming: bool = True,
    metrics_port: int = 9090,
    otlp_endpoint: Optional[str] = None,
    service_name: str = "stateset-agent",
):
    """Configure the global observability instance."""
    obs = get_observability()
    obs.configure(
        enable_metrics=enable_metrics,
        enable_tracing=enable_tracing,
        enable_streaming=enable_streaming,
        metrics_port=metrics_port,
        otlp_endpoint=otlp_endpoint,
        service_name=service_name,
    )
    return obs


# ============================================================================
# Decorators for Easy Integration
# ============================================================================

def observed_task(agent_type: str):
    """
    Decorator for observed async task functions.

    Usage:
        @observed_task("AUTO_CLOSE")
        async def my_task(instruction: str):
            # Task code
            pass
    """
    def decorator(func: Callable):
        async def wrapper(*args, **kwargs):
            obs = get_observability()
            instruction = kwargs.get("instruction", str(args[0]) if args else "")
            agent_id = kwargs.get("agent_id", "unknown")

            async with obs.task_context(agent_type, agent_id, instruction):
                return await func(*args, **kwargs)

        return wrapper
    return decorator


def observed_tool(tool_name: str):
    """
    Decorator for observed tool execution.

    Usage:
        @observed_tool("bash")
        async def execute_bash(command: str):
            # Tool code
            pass
    """
    def decorator(func: Callable):
        async def wrapper(*args, **kwargs):
            obs = get_observability()

            with obs.tool_execution(tool_name, **{k: str(v)[:50] for k, v in kwargs.items()}):
                return await func(*args, **kwargs)

        return wrapper
    return decorator
