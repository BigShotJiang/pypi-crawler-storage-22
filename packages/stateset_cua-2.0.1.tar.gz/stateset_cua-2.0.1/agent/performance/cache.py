"""
Result caching for expensive operations.

Features:
- Memory-based caching (LRU)
- Redis caching (optional)
- TTL support
- Cache invalidation
- Hit/miss metrics
"""

import logging
import time
import json
import hashlib
from typing import Optional, Any, Dict
from functools import lru_cache
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class CacheStats:
    """Cache statistics."""
    hits: int = 0
    misses: int = 0
    evictions: int = 0

    @property
    def hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.hits + self.misses
        if total == 0:
            return 0.0
        return self.hits / total


class CacheEntry:
    """Cache entry with TTL support."""

    def __init__(self, value: Any, ttl: Optional[int] = None):
        """
        Initialize cache entry.

        Args:
            value: Value to cache
            ttl: Time to live in seconds (None = no expiry)
        """
        self.value = value
        self.created_at = time.time()
        self.ttl = ttl

    def is_expired(self) -> bool:
        """Check if entry has expired."""
        if self.ttl is None:
            return False
        return (time.time() - self.created_at) > self.ttl


class MemoryCache:
    """In-memory LRU cache with TTL support."""

    def __init__(self, max_size: int = 1000):
        """
        Initialize memory cache.

        Args:
            max_size: Maximum number of entries
        """
        self.max_size = max_size
        self._cache: Dict[str, CacheEntry] = {}
        self.stats = CacheStats()

    def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache.

        Args:
            key: Cache key

        Returns:
            Cached value or None if not found/expired
        """
        entry = self._cache.get(key)

        if entry is None:
            self.stats.misses += 1
            return None

        if entry.is_expired():
            del self._cache[key]
            self.stats.misses += 1
            return None

        self.stats.hits += 1
        return entry.value

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """
        Set value in cache.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds
        """
        # Evict if at max size
        if len(self._cache) >= self.max_size and key not in self._cache:
            # Remove oldest entry
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
            self.stats.evictions += 1

        self._cache[key] = CacheEntry(value, ttl)

    def delete(self, key: str):
        """Delete entry from cache."""
        if key in self._cache:
            del self._cache[key]

    def clear(self):
        """Clear all cache entries."""
        self._cache.clear()

    def get_stats(self) -> CacheStats:
        """Get cache statistics."""
        return self.stats


class CacheManager:
    """Manages caching for tool results and API responses."""

    def __init__(
        self,
        memory_cache_size: int = 1000,
        default_ttl: int = 3600,
        use_redis: bool = False,
        redis_url: Optional[str] = None
    ):
        """
        Initialize cache manager.

        Args:
            memory_cache_size: Size of memory cache
            default_ttl: Default TTL in seconds
            use_redis: Whether to use Redis
            redis_url: Redis connection URL
        """
        self.memory_cache = MemoryCache(max_size=memory_cache_size)
        self.default_ttl = default_ttl
        self.use_redis = use_redis
        
        self._redis_client = None
        if use_redis and redis_url:
            try:
                import redis.asyncio as redis
                self._redis_client = redis.from_url(redis_url)
                logger.info("Redis cache initialized")
            except ImportError:
                logger.warning("redis package not installed. Using memory cache only.")
                self.use_redis = False

    def _make_key(self, namespace: str, *args, **kwargs) -> str:
        """
        Generate cache key from arguments.

        Args:
            namespace: Cache namespace
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Cache key string
        """
        key_data = {
            'namespace': namespace,
            'args': args,
            'kwargs': kwargs
        }
        key_json = json.dumps(key_data, sort_keys=True)
        key_hash = hashlib.sha256(key_json.encode()).hexdigest()
        return f"{namespace}:{key_hash}"

    async def get(self, namespace: str, *args, **kwargs) -> Optional[Any]:
        """
        Get value from cache.

        Args:
            namespace: Cache namespace
            *args: Key arguments
            **kwargs: Key keyword arguments

        Returns:
            Cached value or None
        """
        key = self._make_key(namespace, *args, **kwargs)

        # Try Redis first if enabled
        if self.use_redis and self._redis_client:
            try:
                value = await self._redis_client.get(key)
                if value:
                    return json.loads(value)
            except Exception as e:
                logger.warning("Redis get error: %s", e)

        # Fall back to memory cache
        return self.memory_cache.get(key)

    async def set(
        self,
        namespace: str,
        value: Any,
        *args,
        ttl: Optional[int] = None,
        **kwargs
    ):
        """
        Set value in cache.

        Args:
            namespace: Cache namespace
            value: Value to cache
            *args: Key arguments
            ttl: Time to live (uses default if None)
            **kwargs: Key keyword arguments
        """
        key = self._make_key(namespace, *args, **kwargs)
        ttl = ttl or self.default_ttl

        # Set in memory cache
        self.memory_cache.set(key, value, ttl)

        # Set in Redis if enabled
        if self.use_redis and self._redis_client:
            try:
                await self._redis_client.setex(
                    key,
                    ttl,
                    json.dumps(value)
                )
            except Exception as e:
                logger.warning("Redis set error: %s", e)

    async def delete(self, namespace: str, *args, **kwargs):
        """Delete entry from cache."""
        key = self._make_key(namespace, *args, **kwargs)

        # Delete from memory
        self.memory_cache.delete(key)

        # Delete from Redis
        if self.use_redis and self._redis_client:
            try:
                await self._redis_client.delete(key)
            except Exception as e:
                logger.warning("Redis delete error: %s", e)

    def get_stats(self) -> CacheStats:
        """Get cache statistics."""
        return self.memory_cache.get_stats()


# Global cache manager
_cache_manager: Optional[CacheManager] = None


def get_cache_manager(
    memory_cache_size: int = 1000,
    default_ttl: int = 3600,
    use_redis: bool = False,
    redis_url: Optional[str] = None
) -> CacheManager:
    """Get the global cache manager instance."""
    global _cache_manager

    if _cache_manager is None:
        _cache_manager = CacheManager(
            memory_cache_size=memory_cache_size,
            default_ttl=default_ttl,
            use_redis=use_redis,
            redis_url=redis_url
        )

    return _cache_manager
