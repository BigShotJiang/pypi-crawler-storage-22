"""
HTTP connection pooling for efficient API calls.

Features:
- Reusable HTTP connections
- Configurable pool size
- Connection timeout management
- Automatic retry logic
"""

import httpx
from typing import Optional, Dict, Any
from contextlib import asynccontextmanager


class ConnectionPool:
    """Manages HTTP connection pool for API calls."""

    def __init__(
        self,
        max_connections: int = 100,
        max_keepalive_connections: int = 20,
        keepalive_expiry: float = 30.0,
        timeout: float = 30.0
    ):
        """
        Initialize connection pool.

        Args:
            max_connections: Maximum number of concurrent connections
            max_keepalive_connections: Maximum number of keepalive connections
            keepalive_expiry: Keepalive expiry time in seconds
            timeout: Request timeout in seconds
        """
        self.limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
            keepalive_expiry=keepalive_expiry
        )
        
        self.timeout = httpx.Timeout(timeout)
        
        self._client: Optional[httpx.AsyncClient] = None

    async def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure HTTP client is initialized."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                limits=self.limits,
                timeout=self.timeout,
                http2=True  # Enable HTTP/2 for better performance
            )
        return self._client

    @asynccontextmanager
    async def get_client(self):
        """
        Get HTTP client from pool.

        Usage:
            async with pool.get_client() as client:
                response = await client.get(url)
        """
        client = await self._ensure_client()
        try:
            yield client
        finally:
            pass  # Client is reused, not closed

    async def close(self):
        """Close the connection pool."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def get(self, url: str, **kwargs) -> httpx.Response:
        """
        Perform GET request using pooled connection.

        Args:
            url: Request URL
            **kwargs: Additional httpx request parameters

        Returns:
            httpx.Response
        """
        async with self.get_client() as client:
            return await client.get(url, **kwargs)

    async def post(self, url: str, **kwargs) -> httpx.Response:
        """
        Perform POST request using pooled connection.

        Args:
            url: Request URL
            **kwargs: Additional httpx request parameters

        Returns:
            httpx.Response
        """
        async with self.get_client() as client:
            return await client.post(url, **kwargs)

    async def put(self, url: str, **kwargs) -> httpx.Response:
        """Perform PUT request using pooled connection."""
        async with self.get_client() as client:
            return await client.put(url, **kwargs)

    async def delete(self, url: str, **kwargs) -> httpx.Response:
        """Perform DELETE request using pooled connection."""
        async with self.get_client() as client:
            return await client.delete(url, **kwargs)


# Global connection pool
_connection_pool: Optional[ConnectionPool] = None


def get_connection_pool(
    max_connections: int = 100,
    max_keepalive_connections: int = 20,
    keepalive_expiry: float = 30.0,
    timeout: float = 30.0
) -> ConnectionPool:
    """Get the global connection pool instance."""
    global _connection_pool

    if _connection_pool is None:
        _connection_pool = ConnectionPool(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
            keepalive_expiry=keepalive_expiry,
            timeout=timeout
        )

    return _connection_pool


async def close_connection_pool():
    """Close the global connection pool."""
    global _connection_pool
    
    if _connection_pool:
        await _connection_pool.close()
        _connection_pool = None
