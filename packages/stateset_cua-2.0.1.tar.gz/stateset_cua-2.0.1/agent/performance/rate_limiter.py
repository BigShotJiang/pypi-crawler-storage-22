"""
Token bucket rate limiter for API calls.

Features:
- Per-customer rate limiting
- Per-agent rate limiting
- Burst support
- Distributed rate limiting (Redis)
"""

import time
import asyncio
from typing import Optional, Dict
from dataclasses import dataclass


@dataclass
class RateLimitConfig:
    """Rate limit configuration."""
    requests_per_second: float = 10.0
    burst_size: int = 20


class TokenBucket:
    """Token bucket algorithm implementation."""

    def __init__(self, rate: float, capacity: int):
        """
        Initialize token bucket.

        Args:
            rate: Tokens per second
            capacity: Maximum tokens (burst size)
        """
        self.rate = rate
        self.capacity = capacity
        self.tokens = capacity
        self.last_update = time.time()
        self._lock = asyncio.Lock()

    async def consume(self, tokens: int = 1) -> bool:
        """
        Try to consume tokens.

        Args:
            tokens: Number of tokens to consume

        Returns:
            True if tokens were consumed, False otherwise
        """
        async with self._lock:
            now = time.time()
            elapsed = now - self.last_update

            # Add new tokens based on elapsed time
            self.tokens = min(
                self.capacity,
                self.tokens + elapsed * self.rate
            )
            self.last_update = now

            # Try to consume tokens
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True

            return False

    async def wait_for_token(self, tokens: int = 1, timeout: Optional[float] = None) -> bool:
        """
        Wait for tokens to become available.

        Args:
            tokens: Number of tokens needed
            timeout: Maximum wait time in seconds

        Returns:
            True if tokens were acquired, False if timed out
        """
        start_time = time.time()

        while True:
            if await self.consume(tokens):
                return True

            # Check timeout
            if timeout and (time.time() - start_time) >= timeout:
                return False

            # Wait a bit before retrying
            await asyncio.sleep(0.1)


class RateLimiter:
    """Manages rate limiting for API calls."""

    def __init__(self, config: Optional[RateLimitConfig] = None):
        """
        Initialize rate limiter.

        Args:
            config: Rate limit configuration
        """
        self.config = config or RateLimitConfig()
        self._buckets: Dict[str, TokenBucket] = {}

    def _get_bucket(self, key: str) -> TokenBucket:
        """Get or create token bucket for key."""
        if key not in self._buckets:
            self._buckets[key] = TokenBucket(
                rate=self.config.requests_per_second,
                capacity=self.config.burst_size
            )
        return self._buckets[key]

    async def acquire(self, key: str, tokens: int = 1, timeout: Optional[float] = None) -> bool:
        """
        Acquire rate limit tokens.

        Args:
            key: Rate limit key (e.g., customer_id, agent_id)
            tokens: Number of tokens to acquire
            timeout: Maximum wait time

        Returns:
            True if acquired, False if timed out
        """
        bucket = self._get_bucket(key)
        return await bucket.wait_for_token(tokens, timeout)

    async def try_acquire(self, key: str, tokens: int = 1) -> bool:
        """
        Try to acquire tokens without waiting.

        Args:
            key: Rate limit key
            tokens: Number of tokens

        Returns:
            True if acquired, False otherwise
        """
        bucket = self._get_bucket(key)
        return await bucket.consume(tokens)


# Global rate limiter
_rate_limiter: Optional[RateLimiter] = None


def get_rate_limiter(config: Optional[RateLimitConfig] = None) -> RateLimiter:
    """Get the global rate limiter instance."""
    global _rate_limiter

    if _rate_limiter is None:
        _rate_limiter = RateLimiter(config)

    return _rate_limiter
