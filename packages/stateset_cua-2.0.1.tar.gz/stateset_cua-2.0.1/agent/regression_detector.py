"""
Performance monitoring and regression detection for StateSet Computer Use Agent.

This module provides:
1. Performance baseline tracking
2. Automatic regression detection
3. Benchmark storage and comparison
4. Alerting for performance degradation

Usage:
    from agent.regression_detector import get_performance_monitor, track_performance

    monitor = get_performance_monitor()

    # Track a task
    with monitor.track("task_execution", agent_type="AUTO_CLOSE"):
        execute_task()

    # Check for regressions
    regressions = monitor.check_for_regressions()
"""

import json
import statistics
import time
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class PerformanceStatus(Enum):
    """Performance status levels"""
    EXCELLENT = "excellent"  # Better than baseline
    NORMAL = "normal"        # Within expected range
    DEGRADED = "degraded"    # Slightly worse than baseline
    REGRESSION = "regression"  # Significant regression detected


@dataclass
class PerformanceMetric:
    """Individual performance measurement"""
    name: str
    value: float
    unit: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    labels: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "unit": self.unit,
            "timestamp": self.timestamp.isoformat(),
            "labels": self.labels
        }


@dataclass
class PerformanceBaseline:
    """Performance baseline for comparison"""
    metric_name: str
    mean: float
    std_dev: float
    p50: float
    p95: float
    p99: float
    sample_count: int
    last_updated: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PerformanceBaseline":
        if isinstance(data.get("last_updated"), str):
            data["last_updated"] = datetime.fromisoformat(data["last_updated"])
        return cls(**data)


@dataclass
class RegressionReport:
    """Report of detected performance regression"""
    metric_name: str
    current_value: float
    baseline_mean: float
    baseline_std_dev: float
    deviation_factor: float  # How many std devs from mean
    severity: PerformanceStatus
    message: str
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "metric_name": self.metric_name,
            "current_value": self.current_value,
            "baseline_mean": self.baseline_mean,
            "baseline_std_dev": self.baseline_std_dev,
            "deviation_factor": self.deviation_factor,
            "severity": self.severity.value,
            "message": self.message,
            "timestamp": self.timestamp.isoformat()
        }


class PerformanceMonitor:
    """
    Monitor performance and detect regressions.

    Features:
    - Rolling window for recent measurements
    - Baseline calculation from historical data
    - Automatic regression detection with configurable thresholds
    - Persistent storage for baselines
    """

    # Regression detection thresholds
    DEGRADED_THRESHOLD = 1.5  # 1.5 std devs = degraded
    REGRESSION_THRESHOLD = 2.5  # 2.5 std devs = regression

    # Minimum samples for reliable baseline
    MIN_BASELINE_SAMPLES = 20

    def __init__(
        self,
        storage_path: str = "/tmp/agent_performance",
        window_size: int = 100,
    ):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)

        self.window_size = window_size
        self.metrics: Dict[str, List[PerformanceMetric]] = {}
        self.baselines: Dict[str, PerformanceBaseline] = {}

        # Load existing baselines
        self._load_baselines()

    def _load_baselines(self):
        """Load baselines from storage"""
        baseline_file = self.storage_path / "baselines.json"
        if baseline_file.exists():
            try:
                with open(baseline_file) as f:
                    data = json.load(f)
                    for name, baseline_data in data.items():
                        self.baselines[name] = PerformanceBaseline.from_dict(baseline_data)
                logger.info(f"Loaded {len(self.baselines)} performance baselines")
            except Exception as e:
                logger.warning(f"Failed to load baselines: {e}")

    def _save_baselines(self):
        """Save baselines to storage"""
        baseline_file = self.storage_path / "baselines.json"
        try:
            data = {name: baseline.to_dict() for name, baseline in self.baselines.items()}
            # Convert datetime to string for JSON serialization
            for baseline_data in data.values():
                if isinstance(baseline_data.get("last_updated"), datetime):
                    baseline_data["last_updated"] = baseline_data["last_updated"].isoformat()
            with open(baseline_file, "w") as f:
                json.dump(data, f, indent=2, default=str)
        except Exception as e:
            logger.warning(f"Failed to save baselines: {e}")

    def record(
        self,
        metric_name: str,
        value: float,
        unit: str = "",
        labels: Optional[Dict[str, str]] = None
    ):
        """
        Record a performance metric.

        Args:
            metric_name: Name of the metric (e.g., "task_duration")
            value: Measured value
            unit: Unit of measurement (e.g., "seconds", "tokens")
            labels: Optional labels for filtering
        """
        metric = PerformanceMetric(
            name=metric_name,
            value=value,
            unit=unit,
            labels=labels or {}
        )

        if metric_name not in self.metrics:
            self.metrics[metric_name] = []

        self.metrics[metric_name].append(metric)

        # Maintain rolling window
        if len(self.metrics[metric_name]) > self.window_size:
            self.metrics[metric_name] = self.metrics[metric_name][-self.window_size:]

    @contextmanager
    def track(
        self,
        metric_name: str,
        unit: str = "seconds",
        labels: Optional[Dict[str, str]] = None
    ):
        """
        Context manager for tracking operation duration.

        Usage:
            with monitor.track("api_call_duration", labels={"endpoint": "messages"}):
                response = client.messages.create(...)
        """
        start = time.perf_counter()
        try:
            yield
        finally:
            duration = time.perf_counter() - start
            self.record(metric_name, duration, unit, labels)

    def update_baseline(self, metric_name: str) -> Optional[PerformanceBaseline]:
        """
        Update baseline for a metric from recent measurements.

        Returns the new baseline if successful, None if insufficient data.
        """
        if metric_name not in self.metrics:
            return None

        values = [m.value for m in self.metrics[metric_name]]

        if len(values) < self.MIN_BASELINE_SAMPLES:
            logger.info(
                f"Insufficient samples for baseline ({len(values)}/{self.MIN_BASELINE_SAMPLES})"
            )
            return None

        sorted_values = sorted(values)

        baseline = PerformanceBaseline(
            metric_name=metric_name,
            mean=statistics.mean(values),
            std_dev=statistics.stdev(values) if len(values) > 1 else 0,
            p50=sorted_values[len(sorted_values) // 2],
            p95=sorted_values[int(len(sorted_values) * 0.95)],
            p99=sorted_values[int(len(sorted_values) * 0.99)],
            sample_count=len(values)
        )

        self.baselines[metric_name] = baseline
        self._save_baselines()

        logger.info(
            f"Updated baseline for {metric_name}: "
            f"mean={baseline.mean:.3f}, std_dev={baseline.std_dev:.3f}"
        )

        return baseline

    def check_value(
        self,
        metric_name: str,
        value: float
    ) -> Tuple[PerformanceStatus, Optional[RegressionReport]]:
        """
        Check if a value indicates a regression.

        Returns:
            Tuple of (status, regression_report). Report is None if no regression.
        """
        if metric_name not in self.baselines:
            return PerformanceStatus.NORMAL, None

        baseline = self.baselines[metric_name]

        # Can't detect regressions with zero std dev
        if baseline.std_dev == 0:
            return PerformanceStatus.NORMAL, None

        deviation = (value - baseline.mean) / baseline.std_dev

        if deviation < -self.DEGRADED_THRESHOLD:
            # Better than baseline!
            return PerformanceStatus.EXCELLENT, None

        if deviation < self.DEGRADED_THRESHOLD:
            return PerformanceStatus.NORMAL, None

        if deviation < self.REGRESSION_THRESHOLD:
            severity = PerformanceStatus.DEGRADED
            message = (
                f"{metric_name} is degraded: {value:.3f} vs baseline {baseline.mean:.3f} "
                f"({deviation:.1f} std devs)"
            )
        else:
            severity = PerformanceStatus.REGRESSION
            message = (
                f"REGRESSION DETECTED in {metric_name}: {value:.3f} vs baseline {baseline.mean:.3f} "
                f"({deviation:.1f} std devs)"
            )

        report = RegressionReport(
            metric_name=metric_name,
            current_value=value,
            baseline_mean=baseline.mean,
            baseline_std_dev=baseline.std_dev,
            deviation_factor=deviation,
            severity=severity,
            message=message
        )

        return severity, report

    def check_for_regressions(self) -> List[RegressionReport]:
        """
        Check all recent metrics for regressions.

        Returns list of regression reports.
        """
        regressions = []

        for metric_name, metrics in self.metrics.items():
            if not metrics:
                continue

            # Check the most recent value
            latest = metrics[-1]
            status, report = self.check_value(metric_name, latest.value)

            if report:
                regressions.append(report)
                if status == PerformanceStatus.REGRESSION:
                    logger.error(f"Performance regression: {report.message}")
                elif status == PerformanceStatus.DEGRADED:
                    logger.warning(f"Performance degraded: {report.message}")

        return regressions

    def get_summary(self) -> Dict[str, Any]:
        """Get performance summary"""
        summary = {
            "metrics": {},
            "baselines": {},
            "regressions": []
        }

        for metric_name, metrics in self.metrics.items():
            if not metrics:
                continue

            values = [m.value for m in metrics]
            summary["metrics"][metric_name] = {
                "count": len(values),
                "mean": statistics.mean(values),
                "min": min(values),
                "max": max(values),
                "latest": values[-1]
            }

        for name, baseline in self.baselines.items():
            summary["baselines"][name] = {
                "mean": baseline.mean,
                "std_dev": baseline.std_dev,
                "p95": baseline.p95,
                "sample_count": baseline.sample_count
            }

        regressions = self.check_for_regressions()
        summary["regressions"] = [r.to_dict() for r in regressions]

        return summary

    def export_metrics(self, filepath: Optional[str] = None) -> Path:
        """Export metrics to JSON file"""
        if filepath is None:
            filepath = self.storage_path / f"metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        else:
            filepath = Path(filepath)

        data = {
            "exported_at": datetime.now().isoformat(),
            "summary": self.get_summary(),
            "raw_metrics": {
                name: [m.to_dict() for m in metrics]
                for name, metrics in self.metrics.items()
            }
        }

        with open(filepath, "w") as f:
            json.dump(data, f, indent=2, default=str)

        return filepath


# Standard metrics for agent tasks
class StandardMetrics:
    """Standard metric names for consistency"""
    TASK_DURATION = "task_duration_seconds"
    TOKEN_USAGE = "token_usage"
    TASK_COST = "task_cost_usd"
    TOOL_EXECUTIONS = "tool_executions"
    API_LATENCY = "api_latency_seconds"
    CONTEXT_SIZE = "context_size_tokens"
    SCREENSHOT_COUNT = "screenshot_count"


# Global monitor instance
_monitor: Optional[PerformanceMonitor] = None


def get_performance_monitor(
    storage_path: str = "/tmp/agent_performance"
) -> PerformanceMonitor:
    """Get or create the global performance monitor"""
    global _monitor
    if _monitor is None:
        _monitor = PerformanceMonitor(storage_path=storage_path)
    return _monitor


@contextmanager
def track_performance(
    metric_name: str,
    unit: str = "seconds",
    labels: Optional[Dict[str, str]] = None
):
    """
    Convenience function for tracking performance.

    Usage:
        with track_performance("task_duration", labels={"agent": "AUTO_CLOSE"}):
            execute_task()
    """
    monitor = get_performance_monitor()
    with monitor.track(metric_name, unit, labels):
        yield
