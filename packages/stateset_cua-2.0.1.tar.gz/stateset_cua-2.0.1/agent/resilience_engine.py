"""
24/7 Resilience Engine for StateSet Computer Use Agent.

This module provides production-grade reliability for continuous operation:

1. Automatic Recovery System
   - Circuit breakers for all external services
   - Intelligent retry with exponential backoff
   - Graceful degradation when services are unavailable

2. Health Monitoring
   - Real-time system health checks
   - Predictive failure detection
   - Automatic resource management

3. Self-Healing Capabilities
   - Automatic restart on failures
   - State recovery from checkpoints
   - Memory/resource cleanup

4. Task Lifecycle Management
   - Task-level timeouts
   - Progress tracking
   - Automatic task recovery

Based on Anthropic's production best practices and research.
"""

import asyncio
import logging
import time
import os
import signal
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import (
    Any, Callable, Coroutine, Dict, List, Optional,
    Set, Tuple, TypeVar, Generic
)
from contextlib import asynccontextmanager
import json
from pathlib import Path

from agent.health import (
    CircuitBreaker, CircuitBreakerOpen, CircuitState,
    HealthChecker, HealthStatus, SystemHealth
)
from agent.checkpoint import (
    CheckpointManager, TaskProgress, ProgressTracker,
    HeartbeatMonitor, RateLimitHandler
)
from agent.stuck_detection import StuckDetector, get_stuck_detector
from agent.exceptions import (
    AgentError, RetryableError, NonRetryableError,
    NetworkError, RateLimitError, TimeoutError as AgentTimeoutError,
    is_retryable, get_retry_delay, wrap_exception
)
from agent.logging_config import get_logger, request_context

logger = get_logger(__name__)

T = TypeVar('T')


class TaskState(Enum):
    """Task lifecycle states"""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    RECOVERING = "recovering"
    CANCELLED = "cancelled"


class ServiceState(Enum):
    """Service availability states"""
    AVAILABLE = "available"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"
    RECOVERING = "recovering"


@dataclass
class TaskMetadata:
    """Metadata for task tracking"""
    task_id: str
    agent_type: str
    instruction: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    state: TaskState = TaskState.PENDING
    retries: int = 0
    max_retries: int = 3
    timeout_seconds: float = 1800.0  # 30 minutes default
    checkpoint_id: Optional[str] = None
    error_message: Optional[str] = None
    metrics: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'agent_type': self.agent_type,
            'instruction': self.instruction[:100] + '...' if len(self.instruction) > 100 else self.instruction,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'state': self.state.value,
            'retries': self.retries,
            'timeout_seconds': self.timeout_seconds,
            'error_message': self.error_message,
            'duration_seconds': self.get_duration(),
        }

    def get_duration(self) -> Optional[float]:
        if not self.started_at:
            return None
        end = self.completed_at or datetime.utcnow()
        return (end - self.started_at).total_seconds()


@dataclass
class ServiceHealth:
    """Health status for a service"""
    name: str
    state: ServiceState
    circuit_breaker: Optional[CircuitBreaker] = None
    last_check: datetime = field(default_factory=datetime.utcnow)
    consecutive_failures: int = 0
    last_error: Optional[str] = None
    latency_ms: float = 0.0


class ResilienceConfig:
    """Configuration for resilience engine"""

    # Task settings
    DEFAULT_TASK_TIMEOUT: float = 1800.0  # 30 minutes
    MAX_TASK_TIMEOUT: float = 7200.0  # 2 hours
    MAX_TASK_RETRIES: int = 3

    # Circuit breaker settings
    CIRCUIT_FAILURE_THRESHOLD: int = 5
    CIRCUIT_TIMEOUT_SECONDS: float = 60.0
    CIRCUIT_SUCCESS_THRESHOLD: int = 2

    # Health check settings
    HEALTH_CHECK_INTERVAL: float = 30.0
    DEGRADED_THRESHOLD: int = 2  # Consecutive failures before degraded
    UNAVAILABLE_THRESHOLD: int = 5  # Consecutive failures before unavailable

    # Recovery settings
    RECOVERY_DELAY_BASE: float = 1.0
    RECOVERY_DELAY_MAX: float = 60.0
    RECOVERY_JITTER: float = 0.1

    # Resource limits
    MAX_CONCURRENT_TASKS: int = 10
    MAX_MEMORY_PERCENT: float = 85.0
    MAX_DISK_PERCENT: float = 90.0

    # Checkpoint settings
    CHECKPOINT_INTERVAL: float = 300.0  # 5 minutes
    CHECKPOINT_DIR: str = "/tmp/agent_checkpoints"


class ServiceRegistry:
    """Registry for tracking service health and circuit breakers"""

    def __init__(self):
        self.services: Dict[str, ServiceHealth] = {}
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}

    def register_service(
        self,
        name: str,
        failure_threshold: int = ResilienceConfig.CIRCUIT_FAILURE_THRESHOLD,
        timeout_seconds: float = ResilienceConfig.CIRCUIT_TIMEOUT_SECONDS
    ) -> CircuitBreaker:
        """Register a service with circuit breaker protection"""

        breaker = CircuitBreaker(
            name=name,
            failure_threshold=failure_threshold,
            timeout_seconds=timeout_seconds
        )

        self.circuit_breakers[name] = breaker
        self.services[name] = ServiceHealth(
            name=name,
            state=ServiceState.AVAILABLE,
            circuit_breaker=breaker
        )

        logger.info(f"Registered service '{name}' with circuit breaker")
        return breaker

    def get_circuit_breaker(self, name: str) -> Optional[CircuitBreaker]:
        """Get circuit breaker for a service"""
        return self.circuit_breakers.get(name)

    def update_service_health(
        self,
        name: str,
        success: bool,
        latency_ms: float = 0.0,
        error: Optional[str] = None
    ):
        """Update service health based on call result"""

        if name not in self.services:
            return

        service = self.services[name]
        service.last_check = datetime.utcnow()
        service.latency_ms = latency_ms

        if success:
            service.consecutive_failures = 0
            service.last_error = None

            # Recover from degraded state
            if service.state in (ServiceState.DEGRADED, ServiceState.RECOVERING):
                service.state = ServiceState.AVAILABLE
                logger.info(f"Service '{name}' recovered to AVAILABLE")
        else:
            service.consecutive_failures += 1
            service.last_error = error

            # Update state based on failure count
            if service.consecutive_failures >= ResilienceConfig.UNAVAILABLE_THRESHOLD:
                if service.state != ServiceState.UNAVAILABLE:
                    service.state = ServiceState.UNAVAILABLE
                    logger.error(f"Service '{name}' marked UNAVAILABLE after {service.consecutive_failures} failures")
            elif service.consecutive_failures >= ResilienceConfig.DEGRADED_THRESHOLD:
                if service.state != ServiceState.DEGRADED:
                    service.state = ServiceState.DEGRADED
                    logger.warning(f"Service '{name}' marked DEGRADED after {service.consecutive_failures} failures")

    def get_all_health(self) -> Dict[str, Dict[str, Any]]:
        """Get health status for all services"""
        return {
            name: {
                'state': service.state.value,
                'consecutive_failures': service.consecutive_failures,
                'last_check': service.last_check.isoformat(),
                'last_error': service.last_error,
                'latency_ms': service.latency_ms,
                'circuit_state': service.circuit_breaker.state.value if service.circuit_breaker else None
            }
            for name, service in self.services.items()
        }


class TaskRegistry:
    """Registry for tracking active tasks"""

    def __init__(self):
        self.tasks: Dict[str, TaskMetadata] = {}
        self.active_tasks: Set[str] = set()
        self._lock = asyncio.Lock()

    async def register_task(self, metadata: TaskMetadata) -> str:
        """Register a new task"""
        async with self._lock:
            self.tasks[metadata.task_id] = metadata
            logger.info(f"Registered task '{metadata.task_id}' ({metadata.agent_type})")
            return metadata.task_id

    async def start_task(self, task_id: str):
        """Mark task as started"""
        async with self._lock:
            if task_id in self.tasks:
                self.tasks[task_id].state = TaskState.RUNNING
                self.tasks[task_id].started_at = datetime.utcnow()
                self.active_tasks.add(task_id)

    async def complete_task(
        self,
        task_id: str,
        success: bool,
        error_message: Optional[str] = None,
        metrics: Optional[Dict[str, Any]] = None
    ):
        """Mark task as completed"""
        async with self._lock:
            if task_id in self.tasks:
                task = self.tasks[task_id]
                task.completed_at = datetime.utcnow()
                task.state = TaskState.COMPLETED if success else TaskState.FAILED
                task.error_message = error_message
                if metrics:
                    task.metrics.update(metrics)
                self.active_tasks.discard(task_id)

    async def update_task_state(self, task_id: str, state: TaskState):
        """Update task state"""
        async with self._lock:
            if task_id in self.tasks:
                self.tasks[task_id].state = state

    async def increment_retry(self, task_id: str) -> Tuple[int, int]:
        """Increment retry count, return (current, max)"""
        async with self._lock:
            if task_id in self.tasks:
                self.tasks[task_id].retries += 1
                task = self.tasks[task_id]
                return task.retries, task.max_retries
            return 0, 0

    def get_active_count(self) -> int:
        """Get count of active tasks"""
        return len(self.active_tasks)

    def get_task(self, task_id: str) -> Optional[TaskMetadata]:
        """Get task metadata"""
        return self.tasks.get(task_id)

    def get_all_tasks(self) -> List[Dict[str, Any]]:
        """Get all task metadata as dicts"""
        return [task.to_dict() for task in self.tasks.values()]


class AutoRecoverySystem:
    """Automatic recovery for failed tasks"""

    def __init__(
        self,
        task_registry: TaskRegistry,
        checkpoint_dir: str = ResilienceConfig.CHECKPOINT_DIR
    ):
        self.task_registry = task_registry
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.recovery_handlers: Dict[str, Callable] = {}

    def register_recovery_handler(
        self,
        agent_type: str,
        handler: Callable[[str, TaskMetadata], Coroutine[Any, Any, bool]]
    ):
        """Register a recovery handler for an agent type"""
        self.recovery_handlers[agent_type] = handler
        logger.info(f"Registered recovery handler for '{agent_type}'")

    async def save_checkpoint(
        self,
        task_id: str,
        state: Dict[str, Any]
    ):
        """Save task checkpoint"""
        checkpoint_path = self.checkpoint_dir / f"{task_id}.json"

        checkpoint = {
            'task_id': task_id,
            'timestamp': datetime.utcnow().isoformat(),
            'state': state
        }

        try:
            checkpoint_path.write_text(json.dumps(checkpoint, indent=2))
            logger.debug(f"Saved checkpoint for task '{task_id}'")
        except Exception as e:
            logger.error(f"Failed to save checkpoint: {e}")

    async def load_checkpoint(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Load task checkpoint"""
        checkpoint_path = self.checkpoint_dir / f"{task_id}.json"

        if not checkpoint_path.exists():
            return None

        try:
            data = json.loads(checkpoint_path.read_text())
            logger.info(f"Loaded checkpoint for task '{task_id}'")
            return data.get('state')
        except Exception as e:
            logger.error(f"Failed to load checkpoint: {e}")
            return None

    async def delete_checkpoint(self, task_id: str):
        """Delete task checkpoint"""
        checkpoint_path = self.checkpoint_dir / f"{task_id}.json"

        try:
            if checkpoint_path.exists():
                checkpoint_path.unlink()
                logger.debug(f"Deleted checkpoint for task '{task_id}'")
        except Exception as e:
            logger.warning(f"Failed to delete checkpoint: {e}")

    async def attempt_recovery(
        self,
        task_id: str
    ) -> bool:
        """Attempt to recover a failed task"""
        task = self.task_registry.get_task(task_id)

        if not task:
            logger.warning(f"Cannot recover unknown task '{task_id}'")
            return False

        # Check if we have a recovery handler
        handler = self.recovery_handlers.get(task.agent_type)
        if not handler:
            logger.warning(f"No recovery handler for agent type '{task.agent_type}'")
            return False

        # Check retry limit
        retries, max_retries = await self.task_registry.increment_retry(task_id)
        if retries > max_retries:
            logger.error(f"Task '{task_id}' exceeded max retries ({max_retries})")
            await self.task_registry.update_task_state(task_id, TaskState.FAILED)
            return False

        # Attempt recovery
        logger.info(f"Attempting recovery for task '{task_id}' (attempt {retries}/{max_retries})")
        await self.task_registry.update_task_state(task_id, TaskState.RECOVERING)

        try:
            success = await handler(task_id, task)

            if success:
                logger.info(f"Successfully recovered task '{task_id}'")
                return True
            else:
                logger.warning(f"Recovery failed for task '{task_id}'")
                return False

        except Exception as e:
            logger.error(f"Recovery exception for task '{task_id}': {e}")
            return False


class ResourceMonitor:
    """Monitor system resources and enforce limits"""

    def __init__(self):
        self.health_checker = HealthChecker()
        self._last_check: Optional[SystemHealth] = None
        self._check_interval = 30.0
        self._last_check_time = 0.0

    async def check_resources(self, force: bool = False) -> SystemHealth:
        """Check system resources"""
        current_time = time.time()

        # Use cached result if recent
        if not force and self._last_check and (current_time - self._last_check_time) < self._check_interval:
            return self._last_check

        self._last_check = await self.health_checker.get_system_health()
        self._last_check_time = current_time

        return self._last_check

    async def is_healthy_for_new_task(self) -> Tuple[bool, str]:
        """Check if system is healthy enough for a new task"""
        health = await self.check_resources()

        if health.status == HealthStatus.UNHEALTHY:
            # Find the unhealthy component
            for check in health.checks:
                if check.status == HealthStatus.UNHEALTHY:
                    return False, f"System unhealthy: {check.name} - {check.message}"
            return False, "System unhealthy: Unknown reason"

        # Check specific thresholds
        for check in health.checks:
            if check.name == "memory":
                percent = check.details.get('percent_used', 0)
                if percent > ResilienceConfig.MAX_MEMORY_PERCENT:
                    return False, f"Memory usage too high: {percent}%"

            elif check.name == "disk_space":
                percent = check.details.get('percent_used', 0)
                if percent > ResilienceConfig.MAX_DISK_PERCENT:
                    return False, f"Disk usage too high: {percent}%"

        return True, "System healthy"

    def get_resource_status(self) -> Dict[str, Any]:
        """Get current resource status"""
        if not self._last_check:
            return {'status': 'unknown', 'message': 'No health check performed'}

        return self._last_check.to_dict()


class ResilienceEngine:
    """
    Main resilience engine for 24/7 operation.

    Coordinates:
    - Service health monitoring
    - Task lifecycle management
    - Automatic recovery
    - Resource management
    - Circuit breakers
    """

    def __init__(self):
        self.service_registry = ServiceRegistry()
        self.task_registry = TaskRegistry()
        self.resource_monitor = ResourceMonitor()
        self.recovery_system = AutoRecoverySystem(self.task_registry)

        # Background task handles
        self._health_check_task: Optional[asyncio.Task] = None
        self._recovery_task: Optional[asyncio.Task] = None
        self._shutdown_event = asyncio.Event()

        # Register core services
        self._register_core_services()

    def _register_core_services(self):
        """Register core services with circuit breakers"""

        # Anthropic API
        self.service_registry.register_service(
            'anthropic_api',
            failure_threshold=5,
            timeout_seconds=60.0
        )

        # StateSet API
        self.service_registry.register_service(
            'stateset_api',
            failure_threshold=3,
            timeout_seconds=30.0
        )

        # Display server
        self.service_registry.register_service(
            'display_server',
            failure_threshold=3,
            timeout_seconds=10.0
        )

    async def start(self):
        """Start the resilience engine"""
        logger.info("Starting Resilience Engine...")

        # Start background health checks
        self._health_check_task = asyncio.create_task(
            self._health_check_loop()
        )

        # Start recovery monitor
        self._recovery_task = asyncio.create_task(
            self._recovery_loop()
        )

        logger.info("Resilience Engine started")

    async def stop(self):
        """Stop the resilience engine"""
        logger.info("Stopping Resilience Engine...")

        self._shutdown_event.set()

        # Cancel background tasks
        for task in [self._health_check_task, self._recovery_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        logger.info("Resilience Engine stopped")

    async def _health_check_loop(self):
        """Background health check loop"""
        while not self._shutdown_event.is_set():
            try:
                await self.resource_monitor.check_resources(force=True)
                await asyncio.sleep(ResilienceConfig.HEALTH_CHECK_INTERVAL)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Health check error: {e}")
                await asyncio.sleep(10.0)

    async def _recovery_loop(self):
        """Background recovery monitor loop"""
        while not self._shutdown_event.is_set():
            try:
                # Check for failed tasks that need recovery
                for task_id in list(self.task_registry.active_tasks):
                    task = self.task_registry.get_task(task_id)
                    if task and task.state == TaskState.FAILED:
                        await self.recovery_system.attempt_recovery(task_id)

                await asyncio.sleep(30.0)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Recovery loop error: {e}")
                await asyncio.sleep(10.0)

    @asynccontextmanager
    async def protected_call(
        self,
        service_name: str,
        timeout: Optional[float] = None
    ):
        """
        Context manager for protected service calls with circuit breaker.

        Usage:
            async with engine.protected_call('anthropic_api', timeout=30.0) as breaker:
                result = await api_call()
        """
        breaker = self.service_registry.get_circuit_breaker(service_name)

        if not breaker:
            # No circuit breaker, just execute
            yield None
            return

        start_time = time.time()
        error = None

        try:
            # Check circuit state
            if breaker.state == CircuitState.OPEN:
                if breaker._should_attempt_reset():
                    breaker.state = CircuitState.HALF_OPEN
                else:
                    raise CircuitBreakerOpen(f"Circuit breaker '{service_name}' is OPEN")

            # Execute with optional timeout
            if timeout:
                async with asyncio.timeout(timeout):
                    yield breaker
            else:
                yield breaker

            # Success
            breaker._on_success()
            self.service_registry.update_service_health(
                service_name,
                success=True,
                latency_ms=(time.time() - start_time) * 1000
            )

        except asyncio.TimeoutError as e:
            error = f"Timeout after {timeout}s"
            breaker._on_failure()
            self.service_registry.update_service_health(
                service_name,
                success=False,
                latency_ms=(time.time() - start_time) * 1000,
                error=error
            )
            raise

        except CircuitBreakerOpen:
            self.service_registry.update_service_health(
                service_name,
                success=False,
                error="Circuit breaker open"
            )
            raise

        except Exception as e:
            error = str(e)
            breaker._on_failure()
            self.service_registry.update_service_health(
                service_name,
                success=False,
                latency_ms=(time.time() - start_time) * 1000,
                error=error
            )
            raise

    async def execute_with_resilience(
        self,
        func: Callable[..., Coroutine[Any, Any, T]],
        *args,
        service_name: Optional[str] = None,
        task_id: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: int = 3,
        **kwargs
    ) -> T:
        """
        Execute a function with full resilience protection.

        Features:
        - Circuit breaker protection
        - Automatic retries with backoff
        - Timeout enforcement
        - Health tracking
        """
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                if service_name:
                    async with self.protected_call(service_name, timeout):
                        return await func(*args, **kwargs)
                else:
                    if timeout:
                        async with asyncio.timeout(timeout):
                            return await func(*args, **kwargs)
                    else:
                        return await func(*args, **kwargs)

            except CircuitBreakerOpen as e:
                logger.warning(f"Circuit breaker open for '{service_name}', not retrying")
                raise

            except Exception as e:
                last_error = e
                wrapped = wrap_exception(e, f"Resilience retry for '{service_name}'")

                if not is_retryable(wrapped) or attempt >= max_retries:
                    logger.error(f"Non-retryable error or max retries reached: {e}")
                    raise

                delay = get_retry_delay(wrapped, attempt)
                logger.warning(f"Attempt {attempt + 1} failed, retrying in {delay:.1f}s: {e}")
                await asyncio.sleep(delay)

        raise last_error or RuntimeError("Unknown error in resilient execution")

    async def run_task_with_timeout(
        self,
        task_id: str,
        agent_type: str,
        instruction: str,
        task_func: Callable[..., Coroutine[Any, Any, Any]],
        timeout: Optional[float] = None,
        checkpoint_interval: float = ResilienceConfig.CHECKPOINT_INTERVAL,
        *args,
        **kwargs
    ) -> Any:
        """
        Run a task with full lifecycle management.

        Features:
        - Task registration and tracking
        - Timeout enforcement
        - Automatic checkpointing
        - Recovery on failure
        """
        # Create task metadata
        metadata = TaskMetadata(
            task_id=task_id,
            agent_type=agent_type,
            instruction=instruction,
            timeout_seconds=timeout or ResilienceConfig.DEFAULT_TASK_TIMEOUT
        )

        # Register task
        await self.task_registry.register_task(metadata)

        # Check if system is healthy
        healthy, reason = await self.resource_monitor.is_healthy_for_new_task()
        if not healthy:
            await self.task_registry.complete_task(
                task_id,
                success=False,
                error_message=f"System not healthy: {reason}"
            )
            raise RuntimeError(f"Cannot start task: {reason}")

        # Check concurrent task limit
        if self.task_registry.get_active_count() >= ResilienceConfig.MAX_CONCURRENT_TASKS:
            await self.task_registry.complete_task(
                task_id,
                success=False,
                error_message="Max concurrent tasks reached"
            )
            raise RuntimeError("Max concurrent tasks reached")

        # Start task
        await self.task_registry.start_task(task_id)

        # Setup checkpoint timer
        checkpoint_task = None
        last_checkpoint_state: Dict[str, Any] = {}

        async def checkpoint_loop():
            while True:
                await asyncio.sleep(checkpoint_interval)
                if last_checkpoint_state:
                    await self.recovery_system.save_checkpoint(task_id, last_checkpoint_state)

        try:
            # Start checkpoint loop
            checkpoint_task = asyncio.create_task(checkpoint_loop())

            # Execute task with timeout
            effective_timeout = timeout or metadata.timeout_seconds

            async with asyncio.timeout(effective_timeout):
                result = await task_func(*args, **kwargs)

            # Success
            await self.task_registry.complete_task(
                task_id,
                success=True,
                metrics={'result': 'success'}
            )

            # Cleanup checkpoint
            await self.recovery_system.delete_checkpoint(task_id)

            return result

        except asyncio.TimeoutError:
            logger.error(f"Task '{task_id}' timed out after {effective_timeout}s")
            await self.task_registry.update_task_state(task_id, TaskState.TIMEOUT)
            await self.task_registry.complete_task(
                task_id,
                success=False,
                error_message=f"Timeout after {effective_timeout}s"
            )
            raise

        except asyncio.CancelledError:
            logger.warning(f"Task '{task_id}' was cancelled")
            await self.task_registry.update_task_state(task_id, TaskState.CANCELLED)
            raise

        except Exception as e:
            logger.error(f"Task '{task_id}' failed: {e}")
            await self.task_registry.complete_task(
                task_id,
                success=False,
                error_message=str(e)
            )
            raise

        finally:
            # Stop checkpoint loop
            if checkpoint_task:
                checkpoint_task.cancel()
                try:
                    await checkpoint_task
                except asyncio.CancelledError:
                    pass

    def get_status(self) -> Dict[str, Any]:
        """Get comprehensive engine status"""
        return {
            'services': self.service_registry.get_all_health(),
            'tasks': {
                'active_count': self.task_registry.get_active_count(),
                'tasks': self.task_registry.get_all_tasks()
            },
            'resources': self.resource_monitor.get_resource_status(),
            'config': {
                'max_concurrent_tasks': ResilienceConfig.MAX_CONCURRENT_TASKS,
                'default_timeout': ResilienceConfig.DEFAULT_TASK_TIMEOUT,
                'max_retries': ResilienceConfig.MAX_TASK_RETRIES
            }
        }


# Global instance
_engine_instance: Optional[ResilienceEngine] = None


def get_resilience_engine() -> ResilienceEngine:
    """Get global resilience engine instance"""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = ResilienceEngine()
    return _engine_instance


async def initialize_resilience_engine() -> ResilienceEngine:
    """Initialize and start the resilience engine"""
    engine = get_resilience_engine()
    await engine.start()
    return engine


async def shutdown_resilience_engine():
    """Shutdown the resilience engine"""
    global _engine_instance
    if _engine_instance:
        await _engine_instance.stop()
        _engine_instance = None
