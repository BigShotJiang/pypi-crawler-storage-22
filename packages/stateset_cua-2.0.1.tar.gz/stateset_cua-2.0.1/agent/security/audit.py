"""
Immutable audit logging for compliance (SOC2, GDPR).

Features:
- Immutable log entries
- Tool execution tracking
- API call logging
- User action recording
- Exportable audit trail
"""

import json
import hashlib
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List
from pathlib import Path
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class AuditEvent:
    """Single audit event."""
    timestamp: str
    event_type: str
    agent_id: str
    org_id: str
    action: str
    details: Dict[str, Any]
    user_id: Optional[str] = None
    ip_address: Optional[str] = None
    session_id: Optional[str] = None
    hash: Optional[str] = None

    def compute_hash(self, previous_hash: str = "") -> str:
        """Compute hash for this event (blockchain-style)."""
        data = f"{self.timestamp}{self.event_type}{self.action}{json.dumps(self.details)}{previous_hash}"
        return hashlib.sha256(data.encode()).hexdigest()


class AuditLogger:
    """Manages audit logging with immutable log chain."""

    def __init__(self, log_dir: str = "./logs/audit"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.log_dir / f"audit_{datetime.now().strftime('%Y%m%d')}.jsonl"
        self.last_hash = self._get_last_hash()

    def _get_last_hash(self) -> str:
        """Get the last hash from the log file."""
        if not self.log_file.exists():
            return ""

        try:
            with open(self.log_file, 'r') as f:
                lines = f.readlines()
                if lines:
                    last_event = json.loads(lines[-1])
                    return last_event.get('hash', '')
        except Exception:
            pass

        return ""

    def log_event(
        self,
        event_type: str,
        agent_id: str,
        org_id: str,
        action: str,
        details: Dict[str, Any],
        user_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        session_id: Optional[str] = None
    ):
        """
        Log an audit event.

        Args:
            event_type: Type of event (tool_execution, api_call, etc.)
            agent_id: ID of the agent
            org_id: Organization ID
            action: Action performed
            details: Additional details
            user_id: Optional user ID
            ip_address: Optional IP address
            session_id: Optional session ID
        """
        event = AuditEvent(
            timestamp=datetime.utcnow().isoformat(),
            event_type=event_type,
            agent_id=agent_id,
            org_id=org_id,
            action=action,
            details=details,
            user_id=user_id,
            ip_address=ip_address,
            session_id=session_id
        )

        # Compute hash linking to previous event
        event.hash = event.compute_hash(self.last_hash)
        self.last_hash = event.hash

        # Write to log file (append-only)
        try:
            with open(self.log_file, 'a') as f:
                f.write(json.dumps(asdict(event)) + '\n')
        except Exception as e:
            logger.error("Failed to write audit log: %s", e)

    def log_tool_execution(
        self,
        agent_id: str,
        org_id: str,
        tool_name: str,
        tool_input: Dict[str, Any],
        success: bool,
        duration: float
    ):
        """Log a tool execution."""
        self.log_event(
            event_type="tool_execution",
            agent_id=agent_id,
            org_id=org_id,
            action=f"execute_{tool_name}",
            details={
                "tool_name": tool_name,
                "input": tool_input,
                "success": success,
                "duration_seconds": duration
            }
        )

    def log_api_call(
        self,
        agent_id: str,
        org_id: str,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cost: float
    ):
        """Log an API call."""
        self.log_event(
            event_type="api_call",
            agent_id=agent_id,
            org_id=org_id,
            action=f"call_{provider}_api",
            details={
                "provider": provider,
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cost_dollars": cost
            }
        )

    def export_audit_trail(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        event_type: Optional[str] = None
    ) -> List[AuditEvent]:
        """
        Export audit trail with optional filters.

        Args:
            start_date: ISO format date string
            end_date: ISO format date string
            event_type: Filter by event type

        Returns:
            List of audit events
        """
        events = []

        for log_file in sorted(self.log_dir.glob("audit_*.jsonl")):
            try:
                with open(log_file, 'r') as f:
                    for line in f:
                        event_dict = json.loads(line)
                        event = AuditEvent(**event_dict)

                        # Apply filters
                        if start_date and event.timestamp < start_date:
                            continue
                        if end_date and event.timestamp > end_date:
                            continue
                        if event_type and event.event_type != event_type:
                            continue

                        events.append(event)
            except Exception as e:
                logger.error("Error reading %s: %s", log_file, e)

        return events

    def verify_integrity(self) -> tuple[bool, Optional[str]]:
        """
        Verify the integrity of the audit log chain.

        Returns:
            (is_valid, error_message)
        """
        previous_hash = ""

        try:
            with open(self.log_file, 'r') as f:
                for line_num, line in enumerate(f, 1):
                    event_dict = json.loads(line)
                    event = AuditEvent(**event_dict)

                    # Verify hash
                    expected_hash = event.compute_hash(previous_hash)
                    if event.hash != expected_hash:
                        return False, f"Hash mismatch at line {line_num}"

                    previous_hash = event.hash

            return True, None
        except Exception as e:
            return False, f"Verification error: {str(e)}"


# Global audit logger
_audit_logger: Optional[AuditLogger] = None


def get_audit_logger(log_dir: str = "./logs/audit") -> AuditLogger:
    """Get the global audit logger instance."""
    global _audit_logger

    if _audit_logger is None:
        _audit_logger = AuditLogger(log_dir)

    return _audit_logger
