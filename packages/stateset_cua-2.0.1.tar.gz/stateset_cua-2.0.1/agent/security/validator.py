"""
Input validation for tool execution.

Validates:
- File paths (no traversal)
- Command safety
- Input size limits
- Data types
- Prompt injection detection
- Environment variable safety

This module provides comprehensive input validation for all tool executions
to prevent security vulnerabilities like command injection, path traversal,
and prompt injection attacks.
"""

import re
import os
import hashlib
import logging
from pathlib import Path
from typing import Any, Dict, Optional, List, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class ValidationSeverity(Enum):
    """Severity levels for validation issues."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class ValidationResult:
    """Result of a validation check."""
    is_valid: bool
    severity: ValidationSeverity = ValidationSeverity.INFO
    message: str = ""
    field: str = ""
    sanitized_value: Optional[Any] = None

    def __bool__(self) -> bool:
        return self.is_valid


@dataclass
class ValidationConfig:
    """Configuration for input validation."""
    max_file_size: int = 10485760  # 10MB
    max_command_length: int = 10000
    max_string_length: int = 100000
    max_path_depth: int = 20
    allow_sudo: bool = False
    allowed_env_vars: Set[str] = field(default_factory=lambda: {
        "PATH", "HOME", "USER", "DISPLAY", "TERM", "LANG", "LC_ALL"
    })
    blocked_env_prefixes: Set[str] = field(default_factory=lambda: {
        "AWS_", "ANTHROPIC_", "STRIPE_", "SECRET_", "API_KEY", "TOKEN_"
    })


class ValidationError(Exception):
    """Raised when validation fails."""

    def __init__(
        self,
        message: str,
        severity: ValidationSeverity = ValidationSeverity.ERROR,
        field: str = "",
        value: Any = None
    ):
        super().__init__(message)
        self.severity = severity
        self.field = field
        self.value = value


class ToolInputValidator:
    """
    Validates tool inputs for security and correctness.

    This class provides comprehensive validation for all tool inputs,
    including file paths, shell commands, and arbitrary string inputs.
    It implements multiple security checks to prevent common attacks.

    Attributes:
        config: ValidationConfig instance with validation settings.

    Example:
        validator = ToolInputValidator()
        try:
            safe_path = validator.validate_file_path("/etc/passwd")
        except ValidationError as e:
            logger.error(f"Validation failed: {e}")
    """

    # Patterns that indicate potential prompt injection
    PROMPT_INJECTION_PATTERNS = [
        r"ignore\s+(previous|all|above)\s+instructions?",
        r"disregard\s+(previous|all|above)",
        r"forget\s+(everything|previous|all)",
        r"new\s+instructions?:",
        r"system\s*prompt:",
        r"<\|.*\|>",  # Special tokens
        r"\[INST\]|\[\/INST\]",  # Instruction markers
        r"<<SYS>>|<</SYS>>",  # System markers
        r"Human:|Assistant:|User:|AI:",  # Role markers
    ]

    # Dangerous shell patterns
    DANGEROUS_SHELL_PATTERNS = [
        r"rm\s+-rf\s+/",
        r"rm\s+-rf\s+~",
        r">\s*/dev/sd[a-z]",
        r"mkfs\.",
        r"dd\s+if=/dev/zero",
        r":\(\)\{\s*:\|:&\s*\};:",  # Fork bomb
        r"wget.*\|.*sh",
        r"curl.*\|.*bash",
        r"chmod\s+777\s+/",
        r"chown\s+-R.*:/",
        r"/etc/passwd",
        r"/etc/shadow",
        r"\.ssh/",
        r"eval\s*\(",
        r"\$\(.*\)",  # Command substitution
        r"`.*`",  # Backtick command substitution
        r";\s*rm\s+",  # Command chaining with rm
        r"\|\s*sh\b",
        r"\|\s*bash\b",
    ]

    # Dangerous file paths
    DANGEROUS_PATHS = [
        "/etc/passwd",
        "/etc/shadow",
        "/etc/sudoers",
        "/root",
        "/sys",
        "/proc",
        "/.ssh",
        "/boot",
        "/dev",
    ]

    def __init__(self, config: Optional[ValidationConfig] = None):
        """
        Initialize the validator with optional configuration.

        Args:
            config: Optional ValidationConfig instance. Uses defaults if not provided.
        """
        self.config = config or ValidationConfig()
        self._compiled_injection_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.PROMPT_INJECTION_PATTERNS
        ]
        self._compiled_shell_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.DANGEROUS_SHELL_PATTERNS
        ]

    def validate_file_path(self, path: str, base_dir: Optional[str] = None) -> str:
        """
        Validate file path for security concerns.

        Args:
            path: File path to validate
            base_dir: Base directory to restrict to

        Returns:
            Validated absolute path

        Raises:
            ValidationError: If path is invalid or dangerous
        """
        # Convert to Path object
        file_path = Path(path).resolve()

        # Check for path traversal
        if ".." in str(path):
            raise ValidationError("Path traversal detected")

        # Check if within base directory
        if base_dir:
            base_path = Path(base_dir).resolve()
            try:
                file_path.relative_to(base_path)
            except ValueError:
                raise ValidationError(f"Path {path} is outside base directory {base_dir}")

        # Check for dangerous paths
        dangerous_paths = [
            "/etc/passwd",
            "/etc/shadow",
            "/root",
            "/sys",
            "/proc",
            "/.ssh",
        ]

        for dangerous in dangerous_paths:
            if str(file_path).startswith(dangerous):
                raise ValidationError(f"Access to {dangerous} is prohibited")

        return str(file_path)

    def validate_command(self, command: str, allowed_commands: Optional[List[str]] = None) -> str:
        """
        Validate bash command for safety.

        Args:
            command: Command to validate
            allowed_commands: Optional whitelist of allowed commands

        Returns:
            Validated command

        Raises:
            ValidationError: If command is dangerous
        """
        # Check length
        if len(command) > 10000:
            raise ValidationError("Command too long")

        # Check for dangerous patterns
        dangerous_patterns = [
            r"rm\s+-rf\s+/",
            r">\s*/dev/sda",
            r"mkfs",
            r"dd\s+if=/dev/zero",
            r":\(\)\{\s*:\|:&\s*\};:",  # Fork bomb
            r"wget.*\|.*sh",
            r"curl.*\|.*bash",
        ]

        for pattern in dangerous_patterns:
            if re.search(pattern, command):
                raise ValidationError(f"Dangerous pattern detected: {pattern}")

        # Check whitelist if provided
        if allowed_commands:
            command_name = command.split()[0] if command.strip() else ""
            if command_name not in allowed_commands:
                raise ValidationError(f"Command '{command_name}' not in allowed list")

        return command

    def validate_string_input(
        self,
        value: str,
        max_length: Optional[int] = None,
        pattern: Optional[str] = None
    ) -> str:
        """
        Validate string input.

        Args:
            value: String to validate
            max_length: Maximum allowed length
            pattern: Regex pattern to match

        Returns:
            Validated string

        Raises:
            ValidationError: If validation fails
        """
        if max_length and len(value) > max_length:
            raise ValidationError(f"String exceeds maximum length of {max_length}")

        if pattern and not re.match(pattern, value):
            raise ValidationError(f"String does not match required pattern")

        return value

    def validate_tool_input(self, tool_name: str, tool_input: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate complete tool input based on tool type.

        Args:
            tool_name: Name of the tool
            tool_input: Tool input dictionary

        Returns:
            Validated tool input

        Raises:
            ValidationError: If validation fails
        """
        if tool_name == "bash":
            if "command" in tool_input:
                tool_input["command"] = self.validate_command(tool_input["command"])

        elif tool_name in ["str_replace_based_edit_tool", "memory"]:
            if "path" in tool_input:
                tool_input["path"] = self.validate_file_path(tool_input["path"])

        elif tool_name == "computer":
            if "action" in tool_input:
                allowed_actions = ["screenshot", "mouse_move", "left_click", "type", "key", "cursor_position"]
                if tool_input["action"] not in allowed_actions:
                    raise ValidationError(f"Invalid computer action: {tool_input['action']}")

        return tool_input

    def check_prompt_injection(self, text: str) -> ValidationResult:
        """
        Check text for potential prompt injection attempts.

        Args:
            text: Text to check for injection patterns.

        Returns:
            ValidationResult with detection status.
        """
        if not text:
            return ValidationResult(is_valid=True)

        for pattern in self._compiled_injection_patterns:
            match = pattern.search(text)
            if match:
                logger.warning(
                    "Potential prompt injection detected: %s",
                    match.group()[:50]
                )
                return ValidationResult(
                    is_valid=False,
                    severity=ValidationSeverity.CRITICAL,
                    message=f"Potential prompt injection detected",
                    field="text",
                )

        return ValidationResult(is_valid=True)

    def validate_environment_access(self, var_name: str) -> ValidationResult:
        """
        Validate that an environment variable access is safe.

        Args:
            var_name: Name of the environment variable.

        Returns:
            ValidationResult indicating if access is allowed.
        """
        # Check if explicitly allowed
        if var_name in self.config.allowed_env_vars:
            return ValidationResult(is_valid=True)

        # Check blocked prefixes
        for prefix in self.config.blocked_env_prefixes:
            if var_name.startswith(prefix):
                return ValidationResult(
                    is_valid=False,
                    severity=ValidationSeverity.ERROR,
                    message=f"Access to {prefix}* environment variables is blocked",
                    field="env_var",
                )

        return ValidationResult(is_valid=True)

    def sanitize_output(self, output: str, max_length: int = 10000) -> str:
        """
        Sanitize output to prevent sensitive data leakage.

        Args:
            output: Output string to sanitize.
            max_length: Maximum allowed length.

        Returns:
            Sanitized output string.
        """
        if not output:
            return output

        # Truncate if too long
        if len(output) > max_length:
            output = output[:max_length] + "... [truncated]"

        # Redact potential secrets
        secret_patterns = [
            (r'sk-ant-[a-zA-Z0-9-]+', '[REDACTED_API_KEY]'),
            (r'sk_live_[a-zA-Z0-9]+', '[REDACTED_STRIPE_KEY]'),
            (r'sk_test_[a-zA-Z0-9]+', '[REDACTED_STRIPE_KEY]'),
            (r'Bearer\s+[a-zA-Z0-9._-]+', 'Bearer [REDACTED]'),
            (r'password["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'password=[REDACTED]'),
            (r'api[_-]?key["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'api_key=[REDACTED]'),
        ]

        for pattern, replacement in secret_patterns:
            output = re.sub(pattern, replacement, output, flags=re.IGNORECASE)

        return output

    def validate_url(self, url: str) -> ValidationResult:
        """
        Validate a URL for safety.

        Args:
            url: URL to validate.

        Returns:
            ValidationResult with validation status.
        """
        import urllib.parse

        try:
            parsed = urllib.parse.urlparse(url)
        except Exception:
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message="Invalid URL format",
                field="url",
            )

        # Check scheme
        if parsed.scheme not in ("http", "https"):
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message=f"URL scheme must be http or https, got {parsed.scheme}",
                field="url",
            )

        # Check for internal/private networks
        blocked_hosts = [
            "localhost",
            "127.0.0.1",
            "0.0.0.0",
            "169.254.",  # Link-local
            "10.",  # Private
            "172.16.", "172.17.", "172.18.", "172.19.",  # Private
            "172.20.", "172.21.", "172.22.", "172.23.",
            "172.24.", "172.25.", "172.26.", "172.27.",
            "172.28.", "172.29.", "172.30.", "172.31.",
            "192.168.",  # Private
        ]

        host = parsed.hostname or ""
        for blocked in blocked_hosts:
            if host == blocked or host.startswith(blocked):
                return ValidationResult(
                    is_valid=False,
                    severity=ValidationSeverity.CRITICAL,
                    message="Access to internal/private networks is blocked",
                    field="url",
                )

        return ValidationResult(is_valid=True, sanitized_value=url)

    def validate_json_input(self, data: Dict[str, Any], schema: Optional[Dict] = None) -> ValidationResult:
        """
        Validate JSON input data.

        Args:
            data: Dictionary to validate.
            schema: Optional schema for validation.

        Returns:
            ValidationResult with validation status.
        """
        if not isinstance(data, dict):
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message="Input must be a dictionary",
                field="data",
            )

        # Check for nested depth (prevent DoS via deeply nested JSON)
        def check_depth(obj: Any, current_depth: int = 0, max_depth: int = 20) -> bool:
            if current_depth > max_depth:
                return False
            if isinstance(obj, dict):
                return all(check_depth(v, current_depth + 1, max_depth) for v in obj.values())
            if isinstance(obj, list):
                return all(check_depth(v, current_depth + 1, max_depth) for v in obj)
            return True

        if not check_depth(data):
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message="JSON nesting depth exceeds maximum allowed",
                field="data",
            )

        return ValidationResult(is_valid=True)


# Global validator instance
_validator: Optional[ToolInputValidator] = None


def get_validator(config: Optional[ValidationConfig] = None) -> ToolInputValidator:
    """
    Get the global validator instance.

    Args:
        config: Optional configuration for the validator.

    Returns:
        ToolInputValidator instance.
    """
    global _validator
    if _validator is None:
        _validator = ToolInputValidator(config)
    return _validator


def validate_tool_input(tool_name: str, tool_input: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convenience function to validate tool input.

    Args:
        tool_name: Name of the tool.
        tool_input: Input dictionary for the tool.

    Returns:
        Validated and potentially sanitized input.

    Raises:
        ValidationError: If validation fails.
    """
    return get_validator().validate_tool_input(tool_name, tool_input)
