"""
Skill management for StateSet Computer Use Agent.

This module provides a central registry describing the skills available to the
agentic runtime along with helper utilities for resolving Anthropic container
skills, building system prompt augmentations, and tracking which agent
configuration activates which skills.
"""

from __future__ import annotations

import logging
import os
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import httpx

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SkillContainerSpec:
    """Anthropic container specification for a skill."""

    type: str  # "anthropic" or "custom"
    skill_id: str
    version: str = "latest"

    def to_payload(self) -> Dict[str, str]:
        """Return payload that can be sent in the Messages API container field."""
        return {
            "type": self.type,
            "skill_id": self.skill_id,
            "version": self.version,
        }


@dataclass(frozen=True)
class SkillProfile:
    """Declarative definition of a reusable skill."""

    key: str
    display_name: str
    description: str
    triggers: Tuple[str, ...] = ()
    default_launcher: Optional[str] = None
    container: Optional[SkillContainerSpec] = None
    container_env_var: Optional[str] = None
    resources: Tuple[str, ...] = ()
    tags: Tuple[str, ...] = ()


@dataclass(frozen=True)
class ResolvedSkill:
    """Runtime representation of a skill with resolved container information."""

    profile: SkillProfile
    container: Optional[SkillContainerSpec] = None

    @property
    def key(self) -> str:
        return self.profile.key

    @property
    def display_name(self) -> str:
        return self.profile.display_name

    @property
    def description(self) -> str:
        return self.profile.description

    @property
    def triggers(self) -> Tuple[str, ...]:
        return self.profile.triggers

    @property
    def resources(self) -> Tuple[str, ...]:
        return self.profile.resources

    def container_payload(self) -> Optional[Dict[str, str]]:
        """Return container payload if container is configured."""
        if not self.container:
            return None
        return self.container.to_payload()


def _skill_env_var(key: str) -> str:
    """Default environment variable name for overriding a skill id."""
    sanitized = key.upper()
    return f"STATESET_SKILL_{sanitized}_ID"


# Registry of core skills shipped with the platform.
_SKILL_REGISTRY: Dict[str, SkillProfile] = {
    "AUTO_CLOSE": SkillProfile(
        key="AUTO_CLOSE",
        display_name="Auto-Close Support Tickets",
        description="Closes resolved tickets, selects contact reasons, and logs audit trails.",
        triggers=("auto-close", "close tickets", "resolve support"),
        default_launcher="./start-autoclose-agent.sh",
        container=SkillContainerSpec(type="custom", skill_id=""),
        container_env_var="STATESET_SKILL_AUTO_CLOSE_ID",
        resources=("rules:auto_close", "memories/support_playbook"),
        tags=("support", "operations"),
    ),
    "SOCIAL_MEDIA": SkillProfile(
        key="SOCIAL_MEDIA",
        display_name="Social Media Moderation",
        description="Moderates social feeds, hides harmful content, and documents moderation outcomes.",
        triggers=("social media", "moderate", "hide comments"),
        default_launcher="./start-socialmedia-agent.sh",
        container=SkillContainerSpec(type="custom", skill_id=""),
        container_env_var="STATESET_SKILL_SOCIAL_MEDIA_ID",
        resources=("memories/moderation_guidelines",),
        tags=("moderation", "trust_and_safety"),
    ),
    "LINKEDIN_MESSENGER": SkillProfile(
        key="LINKEDIN_MESSENGER",
        display_name="LinkedIn Outreach",
        description="Sends targeted connection requests and follow-up messages on LinkedIn.",
        triggers=("linkedin", "inmail", "connect"),
        default_launcher="./start-linkedin-agent.sh",
        container=SkillContainerSpec(type="custom", skill_id=""),
        container_env_var="STATESET_SKILL_LINKEDIN_ID",
        resources=("prompts/outreach_templates",),
        tags=("sales", "outreach"),
    ),
    "SLACK_SUPPORT": SkillProfile(
        key="SLACK_SUPPORT",
        display_name="Slack Support Response",
        description="Responds to customer conversations inside Slack and updates ticket systems.",
        triggers=("slack", "support", "respond in slack"),
        default_launcher="./start-slack-agent.sh",
        container=SkillContainerSpec(type="custom", skill_id=""),
        container_env_var="STATESET_SKILL_SLACK_SUPPORT_ID",
        resources=("memories/slack/escalation_matrix",),
        tags=("support", "communications"),
    ),
    "SHOPIFY": SkillProfile(
        key="SHOPIFY",
        display_name="Shopify Operations",
        description="Manages catalog updates, inventory adjustments, and order workflows inside Shopify.",
        triggers=("shopify", "store", "inventory"),
        default_launcher="./start-shopify-agent.sh",
        container=SkillContainerSpec(type="custom", skill_id=""),
        container_env_var="STATESET_SKILL_SHOPIFY_ID",
        resources=("scripts/shopify/post_run.sh",),
        tags=("commerce", "operations"),
    ),
    "ONBOARDING": SkillProfile(
        key="ONBOARDING",
        display_name="Customer Onboarding",
        description="Creates new customer environments, rules, and attributes for launch.",
        triggers=("onboarding", "new account", "setup"),
        default_launcher=None,
        container=SkillContainerSpec(type="custom", skill_id=""),
        container_env_var="STATESET_SKILL_ONBOARDING_ID",
        resources=("memories/onboarding/checklists",),
        tags=("implementation", "operations"),
    ),
    "STATESET_AGENTIC": SkillProfile(
        key="STATESET_AGENTIC",
        display_name="StateSet Agentic Core",
        description="General-purpose automation that composes specialized skills for bespoke workflows.",
        triggers=("agentic", "general", "multi-step"),
        default_launcher="./start-general-agent.sh",
        container=SkillContainerSpec(type="custom", skill_id=""),
        container_env_var="STATESET_SKILL_AGENTIC_ID",
        resources=("memories/agentic/patterns",),
        tags=("agentic", "meta"),
    ),
}


# Mapping between agent configuration keys and the skills they activate.
_AGENT_SKILL_MAP: Dict[str, Tuple[str, ...]] = {
    "AUTO_CLOSE": ("AUTO_CLOSE",),
    "SOCIAL_MEDIA": ("SOCIAL_MEDIA",),
    "LINKEDIN_MESSENGER": ("LINKEDIN_MESSENGER",),
    "SLACK_SUPPORT": ("SLACK_SUPPORT",),
    "SHOPIFY": ("SHOPIFY",),
    "ONBOARDING": ("ONBOARDING",),
    "STATESET_AGENTIC": (
        "STATESET_AGENTIC",
        "AUTO_CLOSE",
        "SOCIAL_MEDIA",
        "LINKEDIN_MESSENGER",
        "SLACK_SUPPORT",
        "SHOPIFY",
        "ONBOARDING",
    ),
}


class SkillManager:
    """Central access point for skill metadata and container resolution."""

    def __init__(
        self,
        registry: Dict[str, SkillProfile] | None = None,
        agent_skill_map: Dict[str, Tuple[str, ...]] | None = None,
    ) -> None:
        base_registry = registry or _SKILL_REGISTRY
        self._registry: Dict[str, SkillProfile] = dict(base_registry)

        base_map = agent_skill_map or _AGENT_SKILL_MAP
        self._agent_skill_map: Dict[str, List[str]] = {
            agent: list(skills) for agent, skills in base_map.items()
        }

        self._load_external_registry()

    def registered_skills(self) -> Sequence[SkillProfile]:
        return tuple(self._registry.values())

    def get_skill(self, key: str) -> SkillProfile:
        if key not in self._registry:
            raise KeyError(f"Skill '{key}' is not registered")
        return self._registry[key]

    def get_agent_skill_keys(self, agent_key: str) -> Tuple[str, ...]:
        skills = self._agent_skill_map.get(agent_key, [])
        return tuple(skills)

    def get_agent_skills(self, agent_key: str) -> List[ResolvedSkill]:
        """Return resolved skills for a given agent configuration key."""
        skills: List[ResolvedSkill] = []
        for key in self.get_agent_skill_keys(agent_key):
            profile = self._registry.get(key)
            if not profile:
                logger.warning("Agent '%s' references unknown skill '%s'", agent_key, key)
                continue
            resolved = self._resolve_container(profile)
            skills.append(ResolvedSkill(profile=profile, container=resolved))
        return skills

    def _resolve_container(self, profile: SkillProfile) -> Optional[SkillContainerSpec]:
        """Resolve container spec for a skill, honoring environment overrides."""
        if not profile.container:
            return None

        env_var = profile.container_env_var or _skill_env_var(profile.key)
        override_skill_id = os.getenv(env_var, "").strip()
        skill_id = override_skill_id or profile.container.skill_id

        if not skill_id:
            logger.debug(
                "Skill '%s' has no container skill_id configured (env var %s).",
                profile.key,
                env_var,
            )
            return None

        if override_skill_id:
            logger.info(
                "Using container skill override for '%s' from %s",
                profile.key,
                env_var,
            )

        return SkillContainerSpec(
            type=profile.container.type,
            skill_id=skill_id,
            version=profile.container.version,
        )

    def build_system_suffix(self, skills: Sequence[ResolvedSkill]) -> str:
        """Render system prompt suffix describing active skills."""
        if not skills:
            return ""

        lines: List[str] = ["", "<SKILLS_AVAILABLE>"]
        for skill in skills:
            lines.append(f"* {skill.display_name}: {skill.description}")
            if skill.resources:
                resources = ", ".join(skill.resources)
                lines.append(f"  Resources: {resources}")
            if skill.triggers:
                triggers = ", ".join(skill.triggers)
                lines.append(f"  Triggers: {triggers}")
        lines.append("</SKILLS_AVAILABLE>")
        return "\n".join(lines)

    def container_payload(self, skills: Iterable[ResolvedSkill]) -> List[Dict[str, str]]:
        """Build the Messages API container payload for a sequence of skills."""
        payload: List[Dict[str, str]] = []
        for skill in skills:
            container_payload = skill.container_payload()
            if container_payload:
                payload.append(container_payload)
        return payload

    def _profile_from_payload(self, payload: Dict[str, Any]) -> SkillProfile:
        key = payload["key"]
        container_spec = None
        container_type = payload.get("container_type")
        container_skill_id = payload.get("container_skill_id")
        if container_type and container_skill_id:
            container_spec = SkillContainerSpec(
                type=container_type,
                skill_id=container_skill_id,
                version=payload.get("container_version") or "latest",
            )

        return SkillProfile(
            key=key,
            display_name=payload.get("display_name", key),
            description=payload.get("description", ""),
            triggers=tuple(payload.get("triggers") or ()),
            default_launcher=payload.get("default_launcher"),
            container=container_spec,
            container_env_var=payload.get("container_env_var"),
            resources=tuple(payload.get("resources") or ()),
            tags=tuple(payload.get("tags") or ()),
        )

    def _load_external_registry(self) -> None:
        base_url = os.getenv("STATESET_SKILLS_API_BASE_URL")
        if not base_url:
            return

        url = f"{base_url.rstrip('/')}/skills"
        headers = {}
        token = os.getenv("STATESET_SKILLS_API_TOKEN")
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            with httpx.Client(timeout=5.0) as client:
                response = client.get(url, headers=headers)
                response.raise_for_status()
                payload = response.json()
        except Exception as exc:
            logger.warning("Failed to load skills registry from API: %s", exc)
            return

        if not isinstance(payload, list):
            logger.warning("Unexpected skills API payload type: %s", type(payload))
            return

        agent_updates: Dict[str, List[Tuple[int, str]]] = defaultdict(list)

        loaded = 0
        for item in payload:
            if not isinstance(item, dict):
                continue
            try:
                profile = self._profile_from_payload(item)
            except Exception as exc:
                logger.warning("Skipping malformed skill payload: %s", exc)
                continue

            self._registry[profile.key] = profile
            loaded += 1

            for mapping in item.get("agent_mappings") or []:
                agent_key = mapping.get("agent_key")
                if not agent_key:
                    continue
                priority = mapping.get("priority", 100)
                agent_updates[agent_key].append((priority, profile.key))

        for agent_key, entries in agent_updates.items():
            ordered = [
                skill_key
                for _, skill_key in sorted(entries, key=lambda pair: (pair[0], pair[1]))
            ]
            self._agent_skill_map[agent_key] = ordered

        if loaded:
            logger.info("Loaded %s skill(s) from external API", loaded)


_SKILL_MANAGER: Optional[SkillManager] = None


def get_skill_manager() -> SkillManager:
    """Return singleton skill manager instance."""
    global _SKILL_MANAGER
    if _SKILL_MANAGER is None:
        _SKILL_MANAGER = SkillManager()
    return _SKILL_MANAGER
