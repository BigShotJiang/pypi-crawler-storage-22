"""
Global state management and shutdown coordination.

Extracted from main.py. Provides thread-safe async state for the multi-agent
system including task tracking and graceful shutdown.

Note: ``main.py`` defines its own ``cancel_all_tasks``, ``shutdown``, and
``signal_handler`` wrappers that resolve the ``state`` variable through the
``main`` module namespace so that tests can monkey-patch ``main.state``.
The versions here use the module-level ``state`` directly and are suitable
for standalone use or from code that patches ``agent.state.state``.
"""

import asyncio
import sys
from typing import Set

from agent.logging_config import get_logger

logger = get_logger(__name__)


class GlobalState:
    def __init__(self):
        self.running = True
        self.tasks: Set[asyncio.Task] = set()
        self.shutdown_event = asyncio.Event()
        self._lock = asyncio.Lock()
        self._shutdown_started = False

    async def start_shutdown(self) -> bool:
        async with self._lock:
            if self._shutdown_started:
                return False
            self._shutdown_started = True
            self.running = False
            self.shutdown_event.set()
            return True

    @property
    def is_shutting_down(self) -> bool:
        # Property access for shutdown state (no lock needed for reads)
        return self._shutdown_started

    async def add_task(self, task: asyncio.Task):
        async with self._lock:
            if not self._shutdown_started:
                self.tasks.add(task)

    async def remove_task(self, task: asyncio.Task):
        async with self._lock:
            self.tasks.discard(task)

    async def get_all_tasks(self) -> Set[asyncio.Task]:
        async with self._lock:
            return self.tasks.copy()


# Module-level singleton
state = GlobalState()


async def cancel_all_tasks():
    """Cancel all running tasks"""
    tasks = await state.get_all_tasks()
    if not tasks:
        return

    logger.info(f"Cancelling {len(tasks)} running tasks...",
                extra={'agent_type': 'system'})

    for task in tasks:
        if not task.done():
            task.cancel()

    await asyncio.gather(*tasks, return_exceptions=True)

    for task in tasks:
        await state.remove_task(task)


async def shutdown():
    """Graceful shutdown sequence"""
    if not await state.start_shutdown():
        # Another shutdown already in progress
        return

    logger.info("Initiating shutdown sequence...", extra={'agent_type': 'system'})

    try:
        await cancel_all_tasks()
        logger.info("All tasks cancelled successfully", extra={'agent_type': 'system'})
    except Exception as e:
        logger.error(f"Error during shutdown: {str(e)}", extra={'agent_type': 'system'})
    finally:
        # Get the current event loop
        try:
            loop = asyncio.get_running_loop()
            # Stop accepting new tasks
            loop.stop()
        except Exception as e:
            logger.error(f"Error stopping event loop: {str(e)}", extra={'agent_type': 'system'})


def signal_handler(sig, frame):
    """Handle interrupt signals"""
    if state.is_shutting_down:
        logger.info("Forced shutdown...", extra={'agent_type': 'system'})
        sys.exit(1)

    loop = asyncio.get_running_loop()
    loop.create_task(shutdown())
