"""
Structured Output / JSON Schema Support

Enables forcing Claude to return valid JSON matching a specified schema.
Provides type-safe parsing and validation of agent responses.

Key Features:
- JSON Schema definition for output format
- Automatic validation of responses
- Type-safe parsing with Pydantic models
- Schema generation from Python types
- Error recovery with retry logic

Example Usage:
    from agent.structured_output import StructuredOutput, OutputSchema

    # Define schema
    schema = OutputSchema(
        name="TicketAnalysis",
        schema={
            "type": "object",
            "properties": {
                "tickets_to_close": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of ticket IDs that should be closed"
                },
                "summary": {
                    "type": "string",
                    "description": "Brief summary of the analysis"
                },
                "confidence": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 1
                }
            },
            "required": ["tickets_to_close", "summary"]
        }
    )

    # Use with agent
    result = await get_structured_response(
        prompt="Analyze these tickets and identify which should be closed",
        schema=schema
    )

    # Result is validated JSON
    print(result["tickets_to_close"])
"""

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Generic, List, Optional, Type, TypeVar, Union, get_type_hints

logger = logging.getLogger(__name__)

# Type variable for generic schema types
T = TypeVar('T')


@dataclass
class OutputSchema:
    """
    Defines a JSON schema for structured output.

    Attributes:
        name: Human-readable name for the schema
        schema: JSON Schema definition
        description: Optional description of what the output represents
        strict: If True, fail on any validation error (default: True)
    """
    name: str
    schema: Dict[str, Any]
    description: Optional[str] = None
    strict: bool = True

    def to_api_format(self) -> Dict[str, Any]:
        """Convert to Anthropic API output_format."""
        return {
            "type": "json_schema",
            "json_schema": {
                "name": self.name,
                "description": self.description or f"Structured output for {self.name}",
                "schema": self.schema,
                "strict": self.strict
            }
        }

    def validate(self, data: Any) -> tuple[bool, Optional[str]]:
        """
        Validate data against this schema.

        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            _validate_against_schema(data, self.schema)
            return True, None
        except ValidationError as e:
            return False, str(e)


class ValidationError(Exception):
    """Raised when output doesn't match schema."""
    pass


def _validate_against_schema(data: Any, schema: Dict[str, Any], path: str = "") -> None:
    """
    Validate data against a JSON schema.

    This is a lightweight validator for common schema patterns.
    For full JSON Schema support, use jsonschema library.
    """
    schema_type = schema.get("type")

    if schema_type == "object":
        if not isinstance(data, dict):
            raise ValidationError(f"{path}: Expected object, got {type(data).__name__}")

        # Check required fields
        required = schema.get("required", [])
        for field in required:
            if field not in data:
                raise ValidationError(f"{path}: Missing required field '{field}'")

        # Validate properties
        properties = schema.get("properties", {})
        for key, value in data.items():
            if key in properties:
                _validate_against_schema(
                    value,
                    properties[key],
                    path=f"{path}.{key}" if path else key
                )

    elif schema_type == "array":
        if not isinstance(data, list):
            raise ValidationError(f"{path}: Expected array, got {type(data).__name__}")

        items_schema = schema.get("items")
        if items_schema:
            for i, item in enumerate(data):
                _validate_against_schema(
                    item,
                    items_schema,
                    path=f"{path}[{i}]"
                )

        # Check array constraints
        min_items = schema.get("minItems")
        max_items = schema.get("maxItems")
        if min_items is not None and len(data) < min_items:
            raise ValidationError(f"{path}: Array must have at least {min_items} items")
        if max_items is not None and len(data) > max_items:
            raise ValidationError(f"{path}: Array must have at most {max_items} items")

    elif schema_type == "string":
        if not isinstance(data, str):
            raise ValidationError(f"{path}: Expected string, got {type(data).__name__}")

        # Check string constraints
        min_length = schema.get("minLength")
        max_length = schema.get("maxLength")
        pattern = schema.get("pattern")
        enum = schema.get("enum")

        if min_length is not None and len(data) < min_length:
            raise ValidationError(f"{path}: String must be at least {min_length} characters")
        if max_length is not None and len(data) > max_length:
            raise ValidationError(f"{path}: String must be at most {max_length} characters")
        if pattern and not re.match(pattern, data):
            raise ValidationError(f"{path}: String must match pattern '{pattern}'")
        if enum and data not in enum:
            raise ValidationError(f"{path}: Value must be one of {enum}")

    elif schema_type == "number" or schema_type == "integer":
        if schema_type == "integer" and not isinstance(data, int):
            raise ValidationError(f"{path}: Expected integer, got {type(data).__name__}")
        if schema_type == "number" and not isinstance(data, (int, float)):
            raise ValidationError(f"{path}: Expected number, got {type(data).__name__}")

        # Check numeric constraints
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if minimum is not None and data < minimum:
            raise ValidationError(f"{path}: Value must be >= {minimum}")
        if maximum is not None and data > maximum:
            raise ValidationError(f"{path}: Value must be <= {maximum}")

    elif schema_type == "boolean":
        if not isinstance(data, bool):
            raise ValidationError(f"{path}: Expected boolean, got {type(data).__name__}")

    elif schema_type == "null":
        if data is not None:
            raise ValidationError(f"{path}: Expected null")

    # Handle anyOf, oneOf, allOf
    if "anyOf" in schema:
        valid = False
        for sub_schema in schema["anyOf"]:
            try:
                _validate_against_schema(data, sub_schema, path)
                valid = True
                break
            except ValidationError:
                continue
        if not valid:
            raise ValidationError(f"{path}: Value doesn't match any of the allowed schemas")

    if "oneOf" in schema:
        matches = 0
        for sub_schema in schema["oneOf"]:
            try:
                _validate_against_schema(data, sub_schema, path)
                matches += 1
            except ValidationError:
                continue
        if matches != 1:
            raise ValidationError(f"{path}: Value must match exactly one schema (matched {matches})")


def extract_json_from_response(text: str) -> Optional[Dict[str, Any]]:
    """
    Extract JSON from a Claude response that may contain markdown code blocks.

    Handles:
    - Pure JSON responses
    - JSON in ```json code blocks
    - JSON in ``` code blocks
    - JSON mixed with other text
    """
    # Try direct JSON parse first
    try:
        return json.loads(text.strip())
    except json.JSONDecodeError:
        pass

    # Try to find JSON in code blocks
    patterns = [
        r'```json\s*([\s\S]*?)\s*```',  # ```json ... ```
        r'```\s*([\s\S]*?)\s*```',       # ``` ... ```
        r'\{[\s\S]*\}',                   # Raw JSON object
        r'\[[\s\S]*\]',                   # Raw JSON array
    ]

    for pattern in patterns:
        matches = re.findall(pattern, text)
        for match in matches:
            try:
                return json.loads(match.strip())
            except json.JSONDecodeError:
                continue

    return None


class StructuredOutputParser:
    """
    Parses and validates structured output from Claude responses.
    """

    def __init__(self, schema: OutputSchema):
        self.schema = schema

    def parse(self, response_text: str) -> Dict[str, Any]:
        """
        Parse a response and validate against schema.

        Args:
            response_text: Raw response text from Claude

        Returns:
            Validated JSON data

        Raises:
            ValidationError: If parsing or validation fails
        """
        # Extract JSON
        data = extract_json_from_response(response_text)
        if data is None:
            raise ValidationError(f"Could not extract JSON from response: {response_text[:200]}...")

        # Validate
        is_valid, error = self.schema.validate(data)
        if not is_valid and self.schema.strict:
            raise ValidationError(f"Validation failed: {error}")

        return data

    def parse_safe(self, response_text: str) -> tuple[Optional[Dict[str, Any]], Optional[str]]:
        """
        Parse response without raising exceptions.

        Returns:
            Tuple of (parsed_data, error_message)
        """
        try:
            data = self.parse(response_text)
            return data, None
        except Exception as e:
            return None, str(e)


# Pre-defined schemas for common use cases

TICKET_ANALYSIS_SCHEMA = OutputSchema(
    name="TicketAnalysis",
    description="Analysis of support tickets with closure recommendations",
    schema={
        "type": "object",
        "properties": {
            "tickets_to_close": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of ticket IDs that should be closed"
            },
            "tickets_to_escalate": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of ticket IDs that need escalation"
            },
            "summary": {
                "type": "string",
                "description": "Brief summary of the analysis"
            },
            "confidence": {
                "type": "number",
                "minimum": 0,
                "maximum": 1,
                "description": "Confidence score for the analysis"
            }
        },
        "required": ["tickets_to_close", "summary"]
    }
)

TASK_RESULT_SCHEMA = OutputSchema(
    name="TaskResult",
    description="Result of a completed task",
    schema={
        "type": "object",
        "properties": {
            "success": {
                "type": "boolean",
                "description": "Whether the task completed successfully"
            },
            "actions_taken": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of actions performed"
            },
            "errors": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of errors encountered"
            },
            "output": {
                "type": "string",
                "description": "Main output or result"
            },
            "next_steps": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Recommended follow-up actions"
            }
        },
        "required": ["success", "actions_taken"]
    }
)

CODE_ANALYSIS_SCHEMA = OutputSchema(
    name="CodeAnalysis",
    description="Analysis of code files or changes",
    schema={
        "type": "object",
        "properties": {
            "files_analyzed": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of files that were analyzed"
            },
            "issues": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "file": {"type": "string"},
                        "line": {"type": "integer"},
                        "severity": {"type": "string", "enum": ["error", "warning", "info"]},
                        "message": {"type": "string"}
                    },
                    "required": ["file", "severity", "message"]
                },
                "description": "List of issues found"
            },
            "summary": {
                "type": "string",
                "description": "Overall summary of the analysis"
            },
            "recommendations": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Recommendations for improvement"
            }
        },
        "required": ["files_analyzed", "summary"]
    }
)

ENTITY_EXTRACTION_SCHEMA = OutputSchema(
    name="EntityExtraction",
    description="Extracted entities from text",
    schema={
        "type": "object",
        "properties": {
            "entities": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string"},
                        "value": {"type": "string"},
                        "confidence": {"type": "number", "minimum": 0, "maximum": 1}
                    },
                    "required": ["type", "value"]
                }
            },
            "relationships": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "source": {"type": "string"},
                        "target": {"type": "string"},
                        "relation": {"type": "string"}
                    },
                    "required": ["source", "target", "relation"]
                }
            }
        },
        "required": ["entities"]
    }
)


def create_schema_from_example(name: str, example: Dict[str, Any]) -> OutputSchema:
    """
    Create a schema from an example JSON object.

    Useful for quickly defining schemas based on expected output.
    """
    def infer_schema(value: Any) -> Dict[str, Any]:
        if isinstance(value, dict):
            properties = {}
            for k, v in value.items():
                properties[k] = infer_schema(v)
            return {
                "type": "object",
                "properties": properties,
                "required": list(value.keys())
            }
        elif isinstance(value, list):
            if value:
                return {
                    "type": "array",
                    "items": infer_schema(value[0])
                }
            return {"type": "array", "items": {}}
        elif isinstance(value, bool):
            return {"type": "boolean"}
        elif isinstance(value, int):
            return {"type": "integer"}
        elif isinstance(value, float):
            return {"type": "number"}
        elif isinstance(value, str):
            return {"type": "string"}
        elif value is None:
            return {"type": "null"}
        else:
            return {}

    return OutputSchema(
        name=name,
        schema=infer_schema(example)
    )


def build_structured_prompt(
    base_prompt: str,
    schema: OutputSchema,
    examples: Optional[List[Dict[str, Any]]] = None
) -> str:
    """
    Build a prompt that instructs Claude to return structured JSON.

    Args:
        base_prompt: The original prompt
        schema: The output schema
        examples: Optional example outputs

    Returns:
        Enhanced prompt with JSON instructions
    """
    schema_json = json.dumps(schema.schema, indent=2)

    structured_prompt = f"""{base_prompt}

IMPORTANT: You must respond with valid JSON matching this schema:

```json
{schema_json}
```

{f"Description: {schema.description}" if schema.description else ""}
"""

    if examples:
        structured_prompt += "\n\nExamples of valid output:\n"
        for i, example in enumerate(examples, 1):
            structured_prompt += f"\nExample {i}:\n```json\n{json.dumps(example, indent=2)}\n```\n"

    structured_prompt += """
Respond ONLY with the JSON object, no additional text or explanation.
Do not wrap the JSON in markdown code blocks unless specifically requested."""

    return structured_prompt


# Integration with the sampling loop

def create_output_format_param(schema: OutputSchema) -> Dict[str, Any]:
    """
    Create the output_format parameter for the Anthropic API.

    This can be passed directly to the messages.create() call.
    """
    return schema.to_api_format()


async def get_structured_response(
    client,  # Anthropic client
    prompt: str,
    schema: OutputSchema,
    model: str = "claude-sonnet-4-20250514",
    max_tokens: int = 4096,
    max_retries: int = 2,
    **kwargs
) -> Dict[str, Any]:
    """
    Get a structured JSON response from Claude.

    Args:
        client: Anthropic client instance
        prompt: The prompt to send
        schema: Output schema for validation
        model: Model to use
        max_tokens: Maximum tokens in response
        max_retries: Number of retries on validation failure
        **kwargs: Additional API parameters

    Returns:
        Validated JSON response

    Raises:
        ValidationError: If response doesn't match schema after retries
    """
    parser = StructuredOutputParser(schema)
    enhanced_prompt = build_structured_prompt(prompt, schema)

    last_error = None
    for attempt in range(max_retries + 1):
        response = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": enhanced_prompt}],
            **kwargs
        )

        response_text = ""
        for block in response.content:
            if hasattr(block, 'text'):
                response_text += block.text

        data, error = parser.parse_safe(response_text)
        if data is not None:
            return data

        last_error = error
        logger.warning(f"Structured output attempt {attempt + 1} failed: {error}")

        # Add error feedback for retry
        if attempt < max_retries:
            enhanced_prompt = f"""{prompt}

PREVIOUS ATTEMPT FAILED VALIDATION: {error}

Please provide a valid JSON response matching this schema:
```json
{json.dumps(schema.schema, indent=2)}
```

Respond ONLY with the JSON object."""

    raise ValidationError(f"Failed to get valid structured output after {max_retries + 1} attempts: {last_error}")
