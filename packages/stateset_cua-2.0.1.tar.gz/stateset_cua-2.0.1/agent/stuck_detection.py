"""
Stuck Detection System for StateSet Computer Use Agent.
Detects when agent is stuck in loops and suggests recovery.
"""

import time
import logging
import hashlib
from collections import defaultdict
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass, field

logger = logging.getLogger('agent.stuck_detection')


@dataclass
class ActionRecord:
    """Record of an action taken by the agent"""
    action_type: str
    action_details: str
    screenshot_hash: str
    timestamp: float
    tool_name: str


class StuckDetector:
    """
    Detect when agent is stuck and suggest recovery.
    
    Detects:
    - Repeating same action
    - Cycling between 2-3 actions
    - No visual progress (same screenshots)
    - Slow progress (too few actions per time)
    """
    
    def __init__(self, window_size: int = 10, stuck_threshold: int = 3):
        self.window_size = window_size
        self.stuck_threshold = stuck_threshold
        self.action_history: List[ActionRecord] = []
        self.stuck_count = 0
        self.last_stuck_warning = 0
    
    def record_action(
        self,
        tool_name: str,
        action_details: str,
        screenshot: Optional[str] = None
    ):
        """Record an action for stuck detection"""
        
        screenshot_hash = ""
        if screenshot:
            screenshot_hash = hashlib.sha256(screenshot.encode()).hexdigest()[:32]
        
        record = ActionRecord(
            action_type=tool_name,
            action_details=action_details[:100],  # Truncate long details
            screenshot_hash=screenshot_hash,
            timestamp=time.time(),
            tool_name=tool_name
        )
        
        self.action_history.append(record)
        
        # Keep only recent window
        if len(self.action_history) > self.window_size:
            self.action_history = self.action_history[-self.window_size:]
    
    def check_if_stuck(self) -> Tuple[bool, str, str]:
        """
        Check if agent appears stuck.
        
        Returns:
            (is_stuck: bool, reason: str, suggestion: str)
        """
        
        if len(self.action_history) < 6:
            return False, "", ""
        
        recent = self.action_history[-6:]
        
        # Detection 1: Repeating exact same action
        if self._is_repeating_action(recent):
            return True, "Repeating same action 3+ times", self._suggest_recovery("repeat")
        
        # Detection 2: No visual changes (identical screenshots)
        if self._has_no_visual_progress(recent):
            return True, "No visual changes in last 5 actions", self._suggest_recovery("no_visual")
        
        # Detection 3: Cycling between 2-3 actions
        if self._is_cycling(recent):
            cycle = self._identify_cycle(recent)
            return True, f"Cycling between: {cycle}", self._suggest_recovery("cycle")
        
        # Detection 4: Slow progress
        if self._is_progressing_too_slowly(recent):
            return True, "Too slow - less than 1 action/minute", self._suggest_recovery("slow")
        
        return False, "", ""
    
    def _is_repeating_action(self, recent: List[ActionRecord]) -> bool:
        """Check if same action repeated 3+ times"""
        if len(recent) < 3:
            return False
        
        # Check last 5 actions
        actions = [r.action_details for r in recent[-5:]]
        
        # Count most common action
        action_counts = defaultdict(int)
        for action in actions:
            action_counts[action] += 1
        
        max_count = max(action_counts.values())
        return max_count >= self.stuck_threshold
    
    def _has_no_visual_progress(self, recent: List[ActionRecord]) -> bool:
        """Check if screenshots are identical (no visual change).

        Note: Some valid scenarios have identical screenshots:
        - Black/blank screens (virtual display not initialized)
        - Login screens waiting for input
        - Modal dialogs that don't change until dismissed

        Be conservative - only flag if many consecutive identical screenshots.
        """
        if len(recent) < 5:
            return False

        # Get screenshot hashes
        hashes = [r.screenshot_hash for r in recent if r.screenshot_hash]

        if len(hashes) < 5:
            return False

        # Check if last 7 screenshots are identical
        recent_hashes = hashes[-7:] if len(hashes) >= 7 else hashes[-5:]
        unique_hashes = set(recent_hashes)

        # Only flag if all screenshots in window are identical (1 unique hash)
        # 2 unique hashes could be alternating states which is progress
        return len(unique_hashes) == 1 and len(recent_hashes) >= 5
    
    def _is_cycling(self, recent: List[ActionRecord]) -> bool:
        """Check if cycling between 2-3 actions repeatedly with no progress.

        Note: Some tool combinations are legitimate patterns, not cycles:
        - memory → computer (check state, then act)
        - computer → bash (GUI check, then command)
        - screenshot → click → screenshot (normal workflow)

        Only flag as cycling if the exact same action_details repeat.
        """
        if len(recent) < 6:  # Need more history to detect true cycles
            return False

        # Get detailed action strings (not just tool names)
        action_details = [r.action_details for r in recent]

        # Count how many times each exact action appears
        from collections import Counter
        detail_counts = Counter(action_details)

        # If any exact action repeated 4+ times in 6 actions = cycling
        max_repeats = max(detail_counts.values())
        if max_repeats >= 4:
            return True

        # Check for A-B-A-B-A-B pattern (require 3 full cycles to avoid false positives)
        if len(action_details) >= 6:
            for i in range(len(action_details) - 5):
                if (action_details[i] == action_details[i+2] == action_details[i+4] and
                    action_details[i+1] == action_details[i+3] == action_details[i+5] and
                    action_details[i] != action_details[i+1]):
                    return True

        return False
    
    def _identify_cycle(self, recent: List[ActionRecord]) -> str:
        """Identify the cycling pattern"""
        actions = [r.action_type for r in recent[-6:]]
        unique = list(set(actions))
        return " → ".join(unique) + " → ..."
    
    def _is_progressing_too_slowly(self, recent: List[ActionRecord]) -> bool:
        """Check if progress is too slow"""
        if len(recent) < 3:
            return False
        
        time_elapsed = recent[-1].timestamp - recent[0].timestamp
        actions_per_minute = len(recent) / (time_elapsed / 60)
        
        # Less than 1 action per minute = stuck or thinking too long
        return actions_per_minute < 1.0
    
    def _suggest_recovery(self, stuck_type: str) -> str:
        """Suggest recovery based on stuck type"""
        
        suggestions = {
            "repeat": """
RECOVERY SUGGESTION: You're repeating the same action.
- Take a screenshot and analyze what's actually on screen
- Try a completely different approach (if using GUI, try bash; if using bash, try GUI)
- Check if the element you're trying to interact with actually exists
- Consider using a different tool or method
            """,
            
            "no_visual": """
RECOVERY SUGGESTION: No visual changes detected.
- Verify the current screen state with a fresh screenshot
- Check if you're interacting with the right elements
- Try a different method (keyboard shortcuts instead of clicking, bash instead of GUI)
- The current approach may not be working - reconsider your strategy
            """,
            
            "cycle": """
RECOVERY SUGGESTION: You're cycling between actions without progress.
- Step back and re-analyze the task requirements
- Review recent screenshots to understand current state
- Try a fundamentally different approach
- Consider if the task requires a tool you haven't tried yet
            """,
            
            "slow": """
RECOVERY SUGGESTION: Progress is too slow.
- Current method may be too inefficient for this task
- Consider batch operations instead of one-by-one
- Look for automation opportunities (bash scripts, code execution)
- Break the task into smaller chunks
            """
        }
        
        return suggestions.get(stuck_type, "Try a different approach")
    
    def should_intervene(self) -> bool:
        """
        Decide if we should intervene (don't spam warnings).
        
        Only warn every 5 minutes to avoid overwhelming the agent.
        """
        current_time = time.time()
        
        if current_time - self.last_stuck_warning > 300:  # 5 minutes
            self.last_stuck_warning = current_time
            return True
        
        return False
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get stuck detection statistics"""
        total_actions = len(self.action_history)
        
        if total_actions == 0:
            return {'total_actions': 0}
        
        # Analyze action diversity
        unique_actions = len(set(r.action_type for r in self.action_history))
        unique_screenshots = len(set(r.screenshot_hash for r in self.action_history if r.screenshot_hash))
        
        return {
            'total_actions': total_actions,
            'unique_action_types': unique_actions,
            'unique_screenshots': unique_screenshots,
            'stuck_warnings': self.stuck_count,
            'action_diversity': unique_actions / total_actions if total_actions > 0 else 0
        }


# Global detector instance
_global_detector: Optional[StuckDetector] = None


def get_stuck_detector(window_size: int = 10) -> StuckDetector:
    """Get or create global stuck detector instance"""
    global _global_detector
    
    if _global_detector is None:
        _global_detector = StuckDetector(window_size=window_size)
    
    return _global_detector 