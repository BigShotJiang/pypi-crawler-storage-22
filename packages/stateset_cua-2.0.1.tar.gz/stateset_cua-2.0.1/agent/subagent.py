"""
Subagent Spawning System

Enables the main agent to delegate tasks to specialized subagents that run
in isolated contexts and return compressed summaries.

Key Features:
- Recursive task decomposition
- Isolated context per subagent (no context pollution)
- Automatic result compression (sub-agent compression pattern)
- Model routing (use Haiku for simple tasks, Opus for complex)
- Resource limits (max tokens, max turns, timeout)
- Parallel subagent execution support

Architecture:
    MainAgent
    ├── spawn_subagent("explore", "Find all Python files")
    │   └── Returns: 2k summary instead of 50k raw output
    ├── spawn_subagent("analyze", "Review code patterns")
    │   └── Returns: Structured insights
    └── spawn_subagent("execute", "Refactor function X")
        └── Returns: Confirmation + diff summary

Based on Anthropic's sub-agent compression pattern for 95% context savings.
"""

import asyncio
import json
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Literal, Optional

from anthropic import Anthropic
from anthropic.types.beta import BetaMessageParam, BetaTextBlockParam

# Lazy imports to avoid circular dependencies
# These are imported at runtime when needed
ToolCollection = None
ToolResult = None
TOOL_GROUPS_BY_VERSION = None
ToolVersion = None
BaseAnthropicTool = None
ToolError = None

def _ensure_imports():
    """Lazily import tool modules to avoid circular dependencies."""
    global ToolCollection, ToolResult, TOOL_GROUPS_BY_VERSION, ToolVersion, BaseAnthropicTool, ToolError
    if ToolCollection is None:
        from agent.tools import ToolCollection as TC, ToolResult as TR, TOOL_GROUPS_BY_VERSION as TGBV, ToolVersion as TV
        from agent.tools.base import BaseAnthropicTool as BAT, ToolError as TE
        ToolCollection = TC
        ToolResult = TR
        TOOL_GROUPS_BY_VERSION = TGBV
        ToolVersion = TV
        BaseAnthropicTool = BAT
        ToolError = TE

logger = logging.getLogger(__name__)


class SubagentType(str, Enum):
    """Predefined subagent types with optimized configurations."""
    EXPLORE = "explore"      # Fast exploration, returns summaries
    ANALYZE = "analyze"      # Deep analysis, structured output
    EXECUTE = "execute"      # Task execution, confirmation
    RESEARCH = "research"    # Web search and synthesis
    CODE = "code"            # Code generation/modification
    CUSTOM = "custom"        # User-defined behavior


@dataclass
class SubagentConfig:
    """Configuration for a subagent instance."""
    type: SubagentType
    model: str = "claude-haiku-4-5-20251001"  # Default to fast model
    max_tokens: int = 4096
    max_turns: int = 10
    timeout_seconds: float = 120.0
    thinking_budget: Optional[int] = None
    tool_version: ToolVersion = "computer_use_20251124"
    system_prompt_override: Optional[str] = None
    compress_output: bool = True
    max_output_tokens: int = 2000  # Compress results to this size

    # Resource isolation
    isolated_memory: bool = True  # Separate memory namespace
    inherit_context: bool = False  # Don't inherit parent context by default


# Optimized configs for each subagent type
SUBAGENT_CONFIGS: Dict[SubagentType, SubagentConfig] = {
    SubagentType.EXPLORE: SubagentConfig(
        type=SubagentType.EXPLORE,
        model="claude-haiku-4-5-20251001",
        max_tokens=2048,
        max_turns=5,
        timeout_seconds=60.0,
        compress_output=True,
        max_output_tokens=1500,
    ),
    SubagentType.ANALYZE: SubagentConfig(
        type=SubagentType.ANALYZE,
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        max_turns=8,
        timeout_seconds=90.0,
        thinking_budget=2048,
        compress_output=True,
        max_output_tokens=2500,
    ),
    SubagentType.EXECUTE: SubagentConfig(
        type=SubagentType.EXECUTE,
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        max_turns=15,
        timeout_seconds=180.0,
        compress_output=True,
        max_output_tokens=1000,
    ),
    SubagentType.RESEARCH: SubagentConfig(
        type=SubagentType.RESEARCH,
        model="claude-haiku-4-5-20251001",
        max_tokens=4096,
        max_turns=8,
        timeout_seconds=120.0,
        compress_output=True,
        max_output_tokens=2000,
    ),
    SubagentType.CODE: SubagentConfig(
        type=SubagentType.CODE,
        model="claude-sonnet-4-20250514",
        max_tokens=8192,
        max_turns=12,
        timeout_seconds=180.0,
        thinking_budget=4096,
        compress_output=True,
        max_output_tokens=3000,
    ),
    SubagentType.CUSTOM: SubagentConfig(
        type=SubagentType.CUSTOM,
        model="claude-haiku-4-5-20251001",
        max_tokens=4096,
        max_turns=10,
        timeout_seconds=120.0,
    ),
}


@dataclass
class SubagentResult:
    """Result from a subagent execution."""
    subagent_id: str
    subagent_type: SubagentType
    task: str
    success: bool
    result: str  # Compressed summary
    raw_output: Optional[str] = None  # Full output if needed
    error: Optional[str] = None
    turns_used: int = 0
    tokens_used: int = 0
    duration_seconds: float = 0.0
    artifacts: List[Dict[str, Any]] = field(default_factory=list)


class SubagentManager:
    """
    Manages subagent spawning and execution.

    Implements Anthropic's sub-agent compression pattern:
    - Subagents run in isolated contexts
    - Results are compressed before returning to parent
    - Prevents context pollution in main agent
    """

    def __init__(
        self,
        api_key: str,
        default_tool_version: ToolVersion = "computer_use_20251124",
    ):
        self.api_key = api_key
        self.default_tool_version = default_tool_version
        self.active_subagents: Dict[str, asyncio.Task] = {}
        self._client = Anthropic(api_key=api_key, timeout=180.0, max_retries=3)

    def close(self) -> None:
        """Release the underlying Anthropic HTTP client."""
        self._client.close()

    async def __aenter__(self) -> "SubagentManager":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        self.close()

    async def spawn(
        self,
        task: str,
        subagent_type: SubagentType = SubagentType.EXPLORE,
        config_overrides: Optional[Dict[str, Any]] = None,
        parent_context: Optional[str] = None,
    ) -> SubagentResult:
        """
        Spawn a subagent to handle a specific task in an isolated context.

        Implements Anthropic's sub-agent compression pattern for 95% context
        savings. The subagent runs a short conversation with Claude, then
        returns a compressed summary instead of the full raw output.

        Args:
            task: Natural language task description for the subagent.
            subagent_type: Determines model, token limits, and behavior.
                EXPLORE (Haiku) — Fast codebase exploration, returns summaries.
                ANALYZE (Sonnet) — Deep analysis with thinking budget.
                EXECUTE (Sonnet) — Task execution with verification.
                RESEARCH (Haiku) — Web search and synthesis.
                CODE (Sonnet) — Code generation/modification.
            config_overrides: Override default SubagentConfig values.
                Common overrides: ``max_turns``, ``timeout_seconds``,
                ``max_output_tokens``.
            parent_context: Optional context string from the parent agent.
                Only used if the config has ``inherit_context=True``.

        Returns:
            SubagentResult with fields:
                ``success`` (bool), ``result`` (str), ``error`` (str | None),
                ``duration_seconds`` (float), ``tokens_used`` (int).

        Example::

            manager = SubagentManager(api_key)
            result = await manager.spawn(
                task="Find all Python files that import requests",
                subagent_type=SubagentType.EXPLORE,
            )
            if result.success:
                print(result.result)  # Compressed summary
        """
        subagent_id = f"sub_{uuid.uuid4().hex[:8]}"

        # Get base config and apply overrides
        config = SUBAGENT_CONFIGS.get(subagent_type, SUBAGENT_CONFIGS[SubagentType.CUSTOM])
        if config_overrides:
            config = SubagentConfig(
                type=config.type,
                model=config_overrides.get("model", config.model),
                max_tokens=config_overrides.get("max_tokens", config.max_tokens),
                max_turns=config_overrides.get("max_turns", config.max_turns),
                timeout_seconds=config_overrides.get("timeout_seconds", config.timeout_seconds),
                thinking_budget=config_overrides.get("thinking_budget", config.thinking_budget),
                tool_version=config_overrides.get("tool_version", config.tool_version),
                system_prompt_override=config_overrides.get("system_prompt_override", config.system_prompt_override),
                compress_output=config_overrides.get("compress_output", config.compress_output),
                max_output_tokens=config_overrides.get("max_output_tokens", config.max_output_tokens),
                isolated_memory=config_overrides.get("isolated_memory", config.isolated_memory),
                inherit_context=config_overrides.get("inherit_context", config.inherit_context),
            )

        logger.info(
            f"Spawning subagent {subagent_id} | type={subagent_type.value} | model={config.model}",
            extra={"agent_type": "subagent", "subagent_id": subagent_id}
        )

        start_time = time.time()

        try:
            result = await asyncio.wait_for(
                self._run_subagent(subagent_id, task, config, parent_context),
                timeout=config.timeout_seconds
            )
            result.duration_seconds = time.time() - start_time
            return result

        except asyncio.TimeoutError:
            logger.warning(
                f"Subagent {subagent_id} timed out after {config.timeout_seconds}s",
                extra={"agent_type": "subagent", "subagent_id": subagent_id}
            )
            return SubagentResult(
                subagent_id=subagent_id,
                subagent_type=subagent_type,
                task=task,
                success=False,
                result="",
                error=f"Subagent timed out after {config.timeout_seconds} seconds",
                duration_seconds=time.time() - start_time,
            )
        except Exception as e:
            logger.error(
                f"Subagent {subagent_id} failed: {str(e)}",
                extra={"agent_type": "subagent", "subagent_id": subagent_id}
            )
            return SubagentResult(
                subagent_id=subagent_id,
                subagent_type=subagent_type,
                task=task,
                success=False,
                result="",
                error=str(e),
                duration_seconds=time.time() - start_time,
            )
        finally:
            # Cleanup isolated memory directory to prevent disk exhaustion.
            # In finally so it runs even on timeout or unexpected error.
            if config.isolated_memory:
                try:
                    import shutil
                    memory_dir = f"/tmp/agent_memories/subagent_{subagent_id}"
                    shutil.rmtree(memory_dir, ignore_errors=True)
                except Exception:
                    pass

    async def spawn_parallel(
        self,
        tasks: List[Dict[str, Any]],
    ) -> List[SubagentResult]:
        """
        Spawn multiple subagents in parallel.

        Args:
            tasks: List of task configs, each with:
                - task: str (required)
                - subagent_type: SubagentType (optional)
                - config_overrides: dict (optional)

        Returns:
            List of SubagentResults in same order as input
        """
        coroutines = []
        for t in tasks:
            coroutines.append(
                self.spawn(
                    task=t["task"],
                    subagent_type=t.get("subagent_type", SubagentType.EXPLORE),
                    config_overrides=t.get("config_overrides"),
                    parent_context=t.get("parent_context"),
                )
            )

        results = await asyncio.gather(*coroutines, return_exceptions=True)

        # Convert exceptions to failed results
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed_results.append(SubagentResult(
                    subagent_id=f"sub_failed_{i}",
                    subagent_type=tasks[i].get("subagent_type", SubagentType.EXPLORE),
                    task=tasks[i]["task"],
                    success=False,
                    result="",
                    error=str(result),
                ))
            else:
                processed_results.append(result)

        return processed_results

    async def _run_subagent(
        self,
        subagent_id: str,
        task: str,
        config: SubagentConfig,
        parent_context: Optional[str],
    ) -> SubagentResult:
        """Execute a subagent with isolated context."""
        # Ensure imports are loaded
        _ensure_imports()

        # Build system prompt for subagent
        system_prompt = self._build_system_prompt(config, parent_context)

        # Initialize tools for subagent
        tool_group = TOOL_GROUPS_BY_VERSION[config.tool_version]
        tools = []
        for ToolCls in tool_group.tools:
            if ToolCls.__name__ == 'MemoryTool' and config.isolated_memory:
                # Isolated memory namespace for subagent
                memory_dir = f"/tmp/agent_memories/subagent_{subagent_id}"
                tools.append(ToolCls(memory_base_dir=memory_dir))
            else:
                tools.append(ToolCls())

        tool_collection = ToolCollection(*tools)

        # Build messages
        messages: List[BetaMessageParam] = [{
            "role": "user",
            "content": task,
        }]

        total_input_tokens = 0
        total_output_tokens = 0
        turns = 0
        all_outputs: List[str] = []
        artifacts: List[Dict[str, Any]] = []

        # Build API params
        betas = []
        if tool_group.beta_flag:
            betas.append(tool_group.beta_flag)

        while turns < config.max_turns:
            turns += 1

            api_params = {
                "model": config.model,
                "max_tokens": config.max_tokens,
                "system": [{"type": "text", "text": system_prompt}],
                "messages": messages,
                "tools": tool_collection.to_params(),
            }

            if betas:
                api_params["betas"] = betas

            if config.thinking_budget:
                api_params["thinking"] = {
                    "type": "enabled",
                    "budget_tokens": config.thinking_budget
                }

            response = await asyncio.to_thread(
                self._client.beta.messages.create, **api_params
            )

            # Track tokens
            if hasattr(response, 'usage'):
                total_input_tokens += response.usage.input_tokens
                total_output_tokens += response.usage.output_tokens

            # Process response
            assistant_content = []
            tool_uses = []

            for block in response.content:
                if hasattr(block, 'text'):
                    all_outputs.append(block.text)
                    assistant_content.append({
                        "type": "text",
                        "text": block.text
                    })
                elif hasattr(block, 'id') and hasattr(block, 'name'):
                    # Tool use block
                    tool_uses.append({
                        "id": block.id,
                        "name": block.name,
                        "input": block.input if hasattr(block, 'input') else {}
                    })
                    assistant_content.append({
                        "type": "tool_use",
                        "id": block.id,
                        "name": block.name,
                        "input": block.input if hasattr(block, 'input') else {}
                    })

            messages.append({"role": "assistant", "content": assistant_content})

            # Execute tools if any
            if tool_uses:
                tool_results = []
                for tool_use in tool_uses:
                    result = await tool_collection.run(
                        name=tool_use["name"],
                        tool_input=tool_use["input"]
                    )

                    # Collect artifacts (screenshots, files, etc.)
                    if result.base64_image:
                        artifacts.append({
                            "type": "image",
                            "tool": tool_use["name"],
                            "data": result.base64_image[:100] + "..."  # Truncate for summary
                        })

                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use["id"],
                        "content": result.output or result.error or "",
                        "is_error": bool(result.error),
                    })

                messages.append({"role": "user", "content": tool_results})
            else:
                # No tool use, subagent is done
                break

            # Check stop reason
            if response.stop_reason == "end_turn":
                break
        else:
            # Loop exhausted max_turns without natural completion
            logger.warning(
                f"Subagent hit max_turns limit ({config.max_turns}) without completing",
                extra={'agent_type': 'subagent'},
            )

        # Compress output if configured
        raw_output = "\n\n".join(all_outputs)
        if config.compress_output and len(raw_output) > config.max_output_tokens * 4:
            compressed = await self._compress_output(
                raw_output,
                config.max_output_tokens,
                task
            )
        else:
            compressed = raw_output

        return SubagentResult(
            subagent_id=subagent_id,
            subagent_type=config.type,
            task=task,
            success=True,
            result=compressed,
            raw_output=raw_output if raw_output != compressed else None,
            turns_used=turns,
            tokens_used=total_input_tokens + total_output_tokens,
            artifacts=artifacts,
        )

    def _build_system_prompt(
        self,
        config: SubagentConfig,
        parent_context: Optional[str],
    ) -> str:
        """Build system prompt for subagent based on type."""

        if config.system_prompt_override:
            return config.system_prompt_override

        base_prompts = {
            SubagentType.EXPLORE: """You are an exploration subagent. Your role is to quickly find and summarize information.

RULES:
- Be fast and efficient - use grep/find instead of reading entire files
- Return ONLY the essential findings, not raw data
- Summarize patterns, not individual items
- If you find what you're looking for, stop immediately
- Maximum 5 tool calls before summarizing""",

            SubagentType.ANALYZE: """You are an analysis subagent. Your role is to provide deep, structured analysis.

RULES:
- Think step by step before concluding
- Provide structured insights with clear sections
- Identify patterns, risks, and recommendations
- Support conclusions with specific evidence
- Be thorough but concise in final output""",

            SubagentType.EXECUTE: """You are an execution subagent. Your role is to complete specific tasks.

RULES:
- Focus on the single task assigned
- Verify success before reporting completion
- Report only: what was done, outcome, any issues
- Don't explore beyond the task scope
- Confirm completion with evidence""",

            SubagentType.RESEARCH: """You are a research subagent. Your role is to find and synthesize information.

RULES:
- Use web search efficiently
- Cross-reference multiple sources
- Synthesize findings into clear summary
- Cite sources when relevant
- Focus on accuracy over comprehensiveness""",

            SubagentType.CODE: """You are a code subagent. Your role is to write or modify code.

RULES:
- Write clean, well-documented code
- Follow existing code patterns in the project
- Test changes when possible
- Report what was changed and why
- Keep changes minimal and focused""",

            SubagentType.CUSTOM: """You are a specialized subagent. Complete the assigned task efficiently.

RULES:
- Focus on the specific task
- Be concise in responses
- Report results clearly""",
        }

        prompt = base_prompts.get(config.type, base_prompts[SubagentType.CUSTOM])

        if parent_context and config.inherit_context:
            prompt += f"\n\nCONTEXT FROM PARENT AGENT:\n{parent_context}"

        prompt += "\n\nIMPORTANT: You are a subagent with limited context. Complete your task and provide a clear, compressed summary of results."

        return prompt

    async def _compress_output(
        self,
        raw_output: str,
        max_tokens: int,
        original_task: str,
    ) -> str:
        """Compress verbose output to essential summary."""

        # Simple compression: use Claude to summarize
        # This is the "sub-agent compression" pattern from Anthropic
        compression_prompt = f"""Compress the following output into a concise summary of maximum {max_tokens // 4} words.

ORIGINAL TASK: {original_task}

OUTPUT TO COMPRESS:
{raw_output[:20000]}  # Limit input to avoid token explosion

RULES:
- Keep essential findings, decisions, and outcomes
- Remove verbose explanations and repetition
- Maintain actionable information
- Use bullet points for clarity
- Include any errors or warnings

COMPRESSED SUMMARY:"""

        try:
            response = await asyncio.to_thread(
                self._client.messages.create,
                model="claude-haiku-4-5-20251001",  # Fast model for compression
                max_tokens=max_tokens,
                messages=[{"role": "user", "content": compression_prompt}]
            )

            if response.content and hasattr(response.content[0], 'text'):
                return response.content[0].text
            return raw_output[:max_tokens * 4]  # Fallback to truncation

        except Exception as e:
            logger.warning(f"Output compression failed: {e}, using truncation")
            return raw_output[:max_tokens * 4]


def _create_subagent_tool_class():
    """Factory to create SubagentTool class with proper base class import."""
    _ensure_imports()

    class SubagentTool(BaseAnthropicTool):
        """
        Tool that allows the main agent to spawn subagents.

        This tool is added to the main agent's tool collection to enable
        recursive task decomposition.
        """

        def __init__(self, api_key: str, tool_version: str = "computer_use_20251124"):
            self.manager = SubagentManager(api_key, tool_version)

        def to_params(self):
            return {
                "type": "custom",
                "name": "spawn_subagent",
                "description": """Spawn a specialized subagent to handle a specific task in an isolated context.

Use subagents for:
- Exploring codebases or files (type: explore) - fast, returns summaries
- Deep analysis tasks (type: analyze) - thorough, structured output
- Executing specific actions (type: execute) - focused task completion
- Research and web searches (type: research) - information synthesis
- Code generation/modification (type: code) - development tasks

Subagents run independently and return compressed results, preventing context pollution.
Spawn multiple subagents in parallel for independent tasks.""",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "Clear description of what the subagent should accomplish"
                        },
                        "subagent_type": {
                            "type": "string",
                            "enum": ["explore", "analyze", "execute", "research", "code", "custom"],
                            "description": "Type of subagent to spawn (affects model and behavior)",
                            "default": "explore"
                        },
                        "model_override": {
                            "type": "string",
                            "description": "Override the default model for this subagent",
                            "enum": ["claude-haiku-4-5-20251001", "claude-sonnet-4-20250514", "claude-opus-4-6-20260131"]
                        },
                        "context": {
                            "type": "string",
                            "description": "Optional context to pass to the subagent"
                        }
                    },
                    "required": ["task"]
                }
            }

        async def __call__(
            self,
            task: str,
            subagent_type: str = "explore",
            model_override: Optional[str] = None,
            context: Optional[str] = None,
        ) -> "ToolResult":
            """Execute the subagent and return results."""
            _ensure_imports()

            try:
                agent_type = SubagentType(subagent_type)
            except ValueError:
                agent_type = SubagentType.EXPLORE

            config_overrides = {}
            if model_override:
                config_overrides["model"] = model_override
            if context:
                config_overrides["inherit_context"] = True

            result = await self.manager.spawn(
                task=task,
                subagent_type=agent_type,
                config_overrides=config_overrides if config_overrides else None,
                parent_context=context,
            )

            if result.success:
                output = f"""## Subagent Result ({result.subagent_type.value})

**Task:** {result.task}
**Status:** ✅ Completed
**Turns:** {result.turns_used} | **Tokens:** {result.tokens_used} | **Duration:** {result.duration_seconds:.1f}s

### Summary
{result.result}
"""
                if result.artifacts:
                    output += f"\n**Artifacts:** {len(result.artifacts)} item(s) collected"

                return ToolResult(output=output)
            else:
                return ToolResult(
                    error=f"Subagent failed: {result.error}",
                    output=f"Task: {result.task}\nType: {result.subagent_type.value}"
                )

    return SubagentTool


# Create the class - will be None if imports fail
SubagentTool = None
try:
    SubagentTool = _create_subagent_tool_class()
except Exception:
    pass  # Will be created lazily when needed


def get_subagent_tool_class():
    """Get the SubagentTool class, creating it if needed."""
    global SubagentTool
    if SubagentTool is None:
        SubagentTool = _create_subagent_tool_class()
    return SubagentTool


# Convenience function for spawning from anywhere
_global_manager: Optional[SubagentManager] = None
_global_manager_lock = threading.Lock()


def get_subagent_manager(api_key: Optional[str] = None) -> SubagentManager:
    """Get or create the global subagent manager (thread-safe)."""
    global _global_manager
    if _global_manager is None:
        with _global_manager_lock:
            if _global_manager is None:
                if api_key is None:
                    import os
                    api_key = os.environ.get("ANTHROPIC_API_KEY")
                if not api_key:
                    raise ValueError("API key required for subagent manager")
                _global_manager = SubagentManager(api_key)
    return _global_manager


async def spawn_subagent(
    task: str,
    subagent_type: SubagentType = SubagentType.EXPLORE,
    **kwargs
) -> SubagentResult:
    """Convenience function to spawn a subagent."""
    manager = get_subagent_manager()
    return await manager.spawn(task, subagent_type, **kwargs)
