"""
Task completion analysis for agent workflows.

Extracted from main.py. Analyses message history to determine whether an
agent task has been completed successfully.
"""

from anthropic.types.beta import BetaMessageParam

from agent.logging_config import get_logger
from agent.types import TaskStatus

logger = get_logger(__name__)


async def analyze_task_completion(messages: list[BetaMessageParam], agent_type: str) -> TaskStatus:
    """Analyze messages to determine if task was completed successfully with enhanced detection"""
    try:
        # Define completion indicators for each agent type
        completion_indicators = {
            "AUTO_CLOSE": [
                "ticket closed", "successfully closed", "marked as resolved",
                "completed the task", "task finished", "ticket resolved",
                "closure complete", "all tickets closed"
            ],
            "SOCIAL_MEDIA": [
                "comment hidden", "content removed", "content has been removed",
                "moderation complete", "post hidden", "comment deleted",
                "content moderated", "task completed", "moderation finished"
            ],
            "LINKEDIN_MESSENGER": [
                "message sent", "connection request sent", "invite sent",
                "linkedin message delivered", "outreach complete",
                "messages sent successfully", "task completed"
            ],
            "SLACK_SUPPORT": [
                "response sent", "message sent", "replied to customer",
                "support ticket updated", "customer inquiry handled",
                "slack message delivered", "task completed"
            ],
            "SHOPIFY": [
                "product updated", "inventory changed", "order processed",
                "store updated", "changes saved", "shopify task complete",
                "task finished", "update successful"
            ],
            "ONBOARDING": [
                "user created", "setup complete", "onboarding finished",
                "user onboarded", "configuration complete", "setup successful",
                "onboarding task complete"
            ],
            "STATESET_AGENTIC": [
                "task completed", "task finished", "successfully completed",
                "done", "finished", "complete"
            ]
        }

        indicators = completion_indicators.get(agent_type, [])

        # Check recent messages for completion indicators
        recent_messages = list(reversed(messages[-10:]))  # Check last 10 messages

        for message in recent_messages:
            content = message.get("content", [])
            if not isinstance(content, list):
                continue

            for block in content:
                # Check tool usage for completion patterns
                if block.get("type") == "tool_use":
                    tool_name = block.get("name", "")
                    tool_input = block.get("input", {})
                    tool_str = f"{tool_name} {str(tool_input)}".lower()

                    # Look for completion-related tool usage
                    if any(indicator in tool_str for indicator in ["close", "complete", "finish", "done", "submit"]):
                        return TaskStatus(
                            completed=True,
                            tokens_used=0,
                            details=f"{agent_type}: Completion action detected in tool usage"
                        )

                # Check text responses for completion indicators
                elif block.get("type") == "text":
                    text = block.get("text")
                    if isinstance(text, str):
                        text_lower = text.lower()

                        # Check against agent-specific indicators
                        for indicator in indicators:
                            if indicator in text_lower:
                                return TaskStatus(
                                    completed=True,
                                    tokens_used=0,
                                    details=f"{agent_type}: Found completion indicator '{indicator}'"
                                )

        # Check for stuck/looping behavior (repeated actions)
        if len(messages) >= 8:
            recent_actions = []
            for msg in messages[-8:]:
                content = msg.get("content", [])
                if isinstance(content, list):
                    for block in content:
                        if block.get("type") == "tool_use":
                            action = f"{block.get('name')}:{str(block.get('input', {}))[:50]}"
                            recent_actions.append(action)

            # If same action repeated 3+ times, likely stuck
            if recent_actions:
                action_counts = {}
                for action in recent_actions[-6:]:
                    action_counts[action] = action_counts.get(action, 0) + 1

                if any(count >= 3 for count in action_counts.values()):
                    return TaskStatus(
                        completed=False,
                        tokens_used=0,
                        details=f"{agent_type}: Agent appears stuck in loop"
                    )

        return TaskStatus(
            completed=False,
            tokens_used=0,
            details=f"{agent_type}: No completion indicators found"
        )

    except Exception as e:
        logger.error(f"Error analyzing task completion: {str(e)}",
                    extra={'agent_type': agent_type})
        return TaskStatus(
            completed=False,
            tokens_used=0,
            details=f"Error analyzing completion: {str(e)}"
        )
