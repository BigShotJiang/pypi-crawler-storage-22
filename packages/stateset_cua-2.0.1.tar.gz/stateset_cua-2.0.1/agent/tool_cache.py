"""Simple caching layer for read-only tool invocations."""

from __future__ import annotations

import hashlib
import json
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Dict, Optional

from agent.tools.base import ToolResult


@dataclass
class CachedEntry:
    result: ToolResult
    timestamp: float


class ToolResultCache:
    def __init__(self, ttl_seconds: int = 60, max_entries: int = 128):
        self._ttl = ttl_seconds
        self._max_entries = max_entries
        self._cache: "OrderedDict[str, CachedEntry]" = OrderedDict()

    def _key(self, tool_name: str, tool_input: Dict[str, Any]) -> str:
        fingerprint = json.dumps(tool_input, sort_keys=True, default=str)
        return hashlib.sha256(f"{tool_name}:{fingerprint}".encode()).hexdigest()

    def get(self, tool_name: str, tool_input: Dict[str, Any]) -> Optional[ToolResult]:
        key = self._key(tool_name, tool_input)
        entry = self._cache.get(key)
        if not entry:
            return None

        if time.time() - entry.timestamp > self._ttl:
            self._cache.pop(key, None)
            return None

        self._cache.move_to_end(key)
        return entry.result

    def set(self, tool_name: str, tool_input: Dict[str, Any], result: ToolResult) -> None:
        key = self._key(tool_name, tool_input)
        self._cache[key] = CachedEntry(result=result, timestamp=time.time())
        self._cache.move_to_end(key)

        while len(self._cache) > self._max_entries:
            self._cache.popitem(last=False)

    def delete(self, tool_name: str, tool_input: Dict[str, Any]) -> None:
        key = self._key(tool_name, tool_input)
        self._cache.pop(key, None)

    def clear(self) -> None:
        self._cache.clear()
