"""Execution guard that adds human-level safety features to tool calls."""

from __future__ import annotations

import logging
import os
from textwrap import shorten
from typing import Any, Dict, List

from agent.stuck_detection import get_stuck_detector
from agent.verification import get_verifier
from agent.tools.base import ToolFailure, ToolResult
from agent.tool_cache import ToolResultCache
from agent.tool_traits import is_cacheable_tool_call

logger = logging.getLogger(__name__)

# Speed mode configuration
# Set AGENT_FAST_MODE=1 to skip verification for faster execution
FAST_MODE = os.environ.get("AGENT_FAST_MODE", "0") == "1"


class ToolExecutionGuard:
    """Wrap tool execution with verification and stuck-detection logic.
    
    Speed Optimization:
    - Set AGENT_FAST_MODE=1 to skip visual verification (2-3x faster)
    - Verification adds ~0.5-1.0s per action but catches failures
    - Use fast mode for simple, repetitive tasks where failures are obvious
    """

    # Computer actions that MIGHT trigger visual verification
    # Note: Verification is now disabled by default because:
    # 1. Many valid actions don't produce visual changes (clicking empty areas, already-focused elements)
    # 2. The retry loop wastes significant time and tokens
    # 3. Claude can self-correct when it sees the screenshot after the action
    VERIFY_ACTIONS: set = set()  # Empty set = no verification by default

    # Actions that are low-risk and can skip verification even in normal mode
    # These rarely fail and failures are immediately obvious
    LOW_RISK_ACTIONS = {
        "key",  # Keyboard shortcuts
        "scroll",  # Scrolling
        "mouse_move",  # Just moving cursor
        "left_click",  # Click actions - let Claude observe results
        "right_click",
        "double_click",
        "triple_click",
        "middle_click",
        "left_click_drag",
        "type",  # Typing - Claude will see result in screenshot
    }

    def __init__(
        self,
        *,
        agent_type: str,
        verifier=None,
        stuck_detector=None,
        fast_mode: bool = None,
    ):
        self.agent_type = agent_type
        self._verifier = verifier or get_verifier()
        self._stuck_detector = stuck_detector or get_stuck_detector()
        self._interventions: List[str] = []
        self._cache = ToolResultCache(ttl_seconds=120)
        # Fast mode: skip verification for speed (set via env or parameter)
        self._fast_mode = fast_mode if fast_mode is not None else FAST_MODE
        if self._fast_mode:
            logger.info(
                "⚡ Fast mode enabled - skipping visual verification for speed",
                extra={"agent_type": agent_type}
            )

    async def execute(
        self,
        call: Dict[str, Any],
        tool_collection,
    ) -> ToolResult:
        """Execute a tool call with safety instrumentation."""

        name = call.get("name")
        tool_input = call.get("input", {})

        result: ToolResult

        if name == "computer":
            result = await self._execute_computer_action(tool_input, tool_collection)
        else:
            result = await self._run_tool(tool_collection, name, tool_input)

        self._record_action(name, tool_input, result)
        return result

    def pop_interventions(self) -> List[str]:
        """Return and clear any system notices generated during execution."""

        interventions = self._interventions[:]
        self._interventions.clear()
        return interventions

    async def _execute_computer_action(self, tool_input: Dict[str, Any], tool_collection) -> ToolResult:
        """Execute computer tool actions with visual verification.
        
        Speed optimizations:
        - Fast mode: Skip all verification
        - Low-risk actions: Skip verification (key, scroll, mouse_move)
        - Normal mode: Full verification with retries
        """

        computer_tool = getattr(tool_collection, "tool_map", {}).get("computer")
        if computer_tool is None:
            # Fallback – run through the collection like any other tool
            return await self._run_tool(tool_collection, "computer", tool_input)

        action = tool_input.get("action")
        
        # Fast mode: skip all verification
        if self._fast_mode:
            return await self._run_tool(tool_collection, "computer", tool_input)

        if action in self.VERIFY_ACTIONS:
            action_desc = self._describe_computer_action(tool_input)
            logger.info(
                "Verifying computer action: %s", action_desc,
                extra={"agent_type": self.agent_type},
            )

            async def action_func():
                return await self._run_tool(
                    tool_collection,
                    "computer",
                    tool_input,
                )

            async def screenshot_func():
                return await self._run_tool(
                    tool_collection,
                    "computer",
                    {"action": "screenshot"},
                )

            verification = await self._verifier.execute_and_verify(
                action_func=action_func,
                action_description=action_desc,
                expected_outcome="Visual change on screen",
                screenshot_func=screenshot_func,
            )

            if verification["success"]:
                verified_result = self._ensure_tool_result(verification["action_result"])
                note = (
                    f"Verification: success after {verification['attempts']} attempt(s). "
                    f"Similarity={verification['verification'].similarity_score:.1%}"
                )
                return self._attach_system_note(verified_result, note)

            # Verification failure – surface as tool error with final screenshot
            failure = verification["verification"]
            error_msg = (
                f"Action verification failed after {verification['attempts']} attempts: "
                f"{failure.reason}"
            )
            logger.warning(
                "Verification failed: %s", error_msg,
                extra={"agent_type": self.agent_type},
            )
            return ToolFailure(
                error=error_msg,
                base64_image=verification.get("final_screenshot"),
            )

        # Low-risk actions: skip verification even in normal mode
        if action in self.LOW_RISK_ACTIONS:
            return await self._run_tool(tool_collection, "computer", tool_input)

        # Non-verified actions (e.g. screenshots) execute normally
        return await self._run_tool(tool_collection, "computer", tool_input)

    async def _run_tool(self, tool_collection, name: str, tool_input: Dict[str, Any]) -> ToolResult:
        if is_cacheable_tool_call(name, tool_input):
            cached = self._cache.get(name, tool_input)
            if cached is not None:
                logger.info(
                    "Cache hit for tool '%s'",
                    name,
                    extra={"agent_type": self.agent_type},
                )
                return cached

        result = await tool_collection.run(name=name, tool_input=tool_input)
        result = self._ensure_tool_result(result)

        if is_cacheable_tool_call(name, tool_input) and not result.error:
            self._cache.set(name, tool_input, result)

        return result

    def _record_action(self, name: str, tool_input: Dict[str, Any], result: ToolResult):
        if not self._stuck_detector:
            return

        screenshot = result.base64_image if isinstance(result, ToolResult) else None
        summary = self._summarize_call(name, tool_input)

        self._stuck_detector.record_action(
            tool_name=name,
            action_details=summary,
            screenshot=screenshot,
        )

        is_stuck, reason, suggestion = self._stuck_detector.check_if_stuck()
        if is_stuck and self._stuck_detector.should_intervene():
            notice = (
                "⚠️ SYSTEM NOTICE: You appear to be stuck. "
                f"Reason: {reason}. Recommendation: {suggestion.strip()}"
            )
            logger.warning(
                "Stuck detection triggered: %s", reason,
                extra={"agent_type": self.agent_type},
            )
            self._interventions.append(notice)

    @staticmethod
    def _ensure_tool_result(result: Any) -> ToolResult:
        if isinstance(result, ToolResult):
            return result
        if isinstance(result, dict):
            return ToolResult(
                output=result.get("output"),
                error=result.get("error"),
                base64_image=result.get("base64_image"),
                system=result.get("system"),
            )
        return ToolResult(output=str(result))

    @staticmethod
    def _attach_system_note(result: ToolResult, note: str) -> ToolResult:
        if result.system:
            note = f"{result.system}\n{note}"
        return result.replace(system=note)

    @staticmethod
    def _describe_computer_action(tool_input: Dict[str, Any]) -> str:
        action = tool_input.get("action", "")
        coordinate = tool_input.get("coordinate")
        text = tool_input.get("text")

        parts = [action]
        if coordinate:
            parts.append(f"coord={coordinate}")
        if text:
            parts.append(f"text={shorten(str(text), width=40, placeholder='…')}")
        return " ".join(part for part in parts if part)

    @staticmethod
    def _summarize_call(name: str, tool_input: Dict[str, Any]) -> str:
        if name == "computer":
            return ToolExecutionGuard._describe_computer_action(tool_input)
        if name == "bash":
            command = tool_input.get("command", "")
            return f"bash: {shorten(command, width=60, placeholder='…')}"
        if name == "memory":
            command = tool_input.get("command")
            path = tool_input.get("path")
            return f"memory:{command or ''}:{path or ''}"
        return name
