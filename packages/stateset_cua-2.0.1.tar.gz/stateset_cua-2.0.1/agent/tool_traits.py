"""Shared helpers for reasoning about tool characteristics."""

from __future__ import annotations

import re
from functools import lru_cache
from typing import Any, Dict


_SERVER_READ_ONLY_TOOLS = {
    "web_search",
    "web_fetch",
}

_CLIENT_READ_ONLY_TOOLS = {
    "screenshot",
    "cursor_position",
}

_BASH_READ_ONLY_PATTERNS = [
    r"^ls(?:\s|$)",
    r"^cat(?:\s|$)",
    r"^grep(?:\s|$)",
    r"^find(?:\s|$)",
    r"^head(?:\s|$)",
    r"^tail(?:\s|$)",
    r"^wc(?:\s|$)",
    r"^du(?:\s|$)",
    r"^echo(?:\s|$)",
    r"^pwd(?:\s|$)",
    r"^whoami(?:\s|$)",
    r"^which(?:\s|$)",
]

_COMPILED_BASH_PATTERNS = [re.compile(pattern) for pattern in _BASH_READ_ONLY_PATTERNS]


@lru_cache(maxsize=None)
def _memory_command_metadata(command: str) -> Dict[str, bool]:
    from agent.tools.memory import MemoryTool

    return MemoryTool.COMMAND_METADATA.get(command, {})


def is_read_only_tool_call(name: str, tool_input: Dict[str, Any]) -> bool:
    """Return True if the tool call is considered read-only."""

    if name in _SERVER_READ_ONLY_TOOLS or name in _CLIENT_READ_ONLY_TOOLS:
        return True

    if name == "memory":
        command = tool_input.get("command", "")
        metadata = _memory_command_metadata(command)
        return metadata.get("read_only", False)

    if name == "bash":
        command = tool_input.get("command", "")
        if any(token in command for token in (">", ">>", "| tee", "|tee", " tee ")):
            return False
        for pattern in _COMPILED_BASH_PATTERNS:
            if pattern.match(command):
                return True
        return False

    if name == "computer":
        action = tool_input.get("action")
        return action in {"screenshot", "cursor_position", "zoom"}

    if name == "stateset_cli":
        return bool(tool_input.get("read_only", False))

    return False


def is_cacheable_tool_call(name: str, tool_input: Dict[str, Any]) -> bool:
    """Return True if the tool call is safe to cache."""

    if not is_read_only_tool_call(name, tool_input):
        return False

    if name == "bash":
        # Shell output can change quickly due to external state.
        return False

    if name in {"web_search", "web_fetch"}:
        # External data can change rapidly; avoid caching here.
        return False

    if name == "computer":
        # Screenshots are large and tied to time; skip caching.
        return False

    return True


# Backwards-compatible aliases used in unit tests
def is_read_only(name: str, tool_input: Dict[str, Any]) -> bool:
    return is_read_only_tool_call(name, tool_input)


def is_cacheable(name: str, tool_input: Dict[str, Any]) -> bool:
    return is_cacheable_tool_call(name, tool_input)
