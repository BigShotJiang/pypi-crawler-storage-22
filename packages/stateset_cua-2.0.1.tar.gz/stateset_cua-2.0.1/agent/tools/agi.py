"""
AGI Agents API integration tool.

This tool allows your agent to delegate tasks to AGI.tech agents,
combining Anthropic's Claude capabilities with AGI's browser automation.
"""

import asyncio
import json
import logging
import os
import time
from typing import Any, Literal

import requests
from anthropic.types.beta import BetaToolUnionParam
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .base import BaseAnthropicTool, ToolError, ToolResult

logger = logging.getLogger(__name__)

# Configuration
AGI_API_BASE_URL = os.getenv("AGI_API_BASE_URL", "https://api.agi.tech")
AGI_API_KEY = os.getenv("AGI_API_KEY")
REQUEST_TIMEOUT_SECS = 60.0
POLL_INTERVAL_SECS = 2.0
MAX_POLL_SECONDS = 300.0  # 5 minutes max wait

# Validate API key is configured
if not AGI_API_KEY:
    logger.warning(
        "AGI_API_KEY not set in environment variables. "
        "AGI tool will not be available. "
        "Set AGI_API_KEY in your .env file to enable extended AGI capabilities."
    )


class AGIAPIClient:
    """Client for AGI Agents API v1."""

    def __init__(self, base_url: str = AGI_API_BASE_URL, api_key: str = AGI_API_KEY, timeout: float = REQUEST_TIMEOUT_SECS):
        if not base_url:
            raise ValueError("base_url is required for AGIAPIClient")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.api_key = api_key
        self.sess = self._mk_session()
        self.headers = self._build_headers()

    def close(self):
        """Close the HTTP session to free resources."""
        if self.sess:
            self.sess.close()

    def _mk_session(self) -> requests.Session:
        s = requests.Session()
        retries = Retry(total=5, backoff_factor=0.3, status_forcelist=[429, 500, 502, 503, 504])
        s.mount("http://", HTTPAdapter(max_retries=retries))
        s.mount("https://", HTTPAdapter(max_retries=retries))
        return s

    def _build_headers(self) -> dict:
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _req(self, method: str, path: str, **kwargs):
        url = self._url(path)
        headers = kwargs.pop("headers", {})
        merged_headers = {**self.headers, **headers}
        try:
            r = self.sess.request(method, url, headers=merged_headers, timeout=self.timeout, **kwargs)
            r.raise_for_status()
            return r
        except requests.HTTPError as e:
            try:
                payload = r.json()
                error_detail = payload.get("detail", "Request failed")
            except (ValueError, AttributeError):
                error_detail = f"HTTP {r.status_code}"
            raise RuntimeError(f"{method} {path} -> {error_detail}") from e
        except requests.RequestException as e:
            raise RuntimeError(f"{method} {url} -> Request failed: {str(e)}") from e

    def health(self):
        return self._req("GET", "/health").json()

    def list_models(self):
        return self._req("GET", "/v1/models").json()

    def create_session(self, agent_name: str = "agi-0"):
        payload = {"agent_name": agent_name}
        return self._req("POST", "/v1/sessions", json=payload).json()

    def list_sessions(self):
        return self._req("GET", "/v1/sessions").json()

    def get_session(self, session_id: str):
        return self._req("GET", f"/v1/sessions/{session_id}").json()

    def delete_session(self, session_id: str):
        return self._req("DELETE", f"/v1/sessions/{session_id}").json()

    def message_agent(self, session_id: str, message: str):
        payload = {"message": message}
        return self._req("POST", f"/v1/sessions/{session_id}/message", json=payload).json()

    def get_status(self, session_id: str):
        return self._req("GET", f"/v1/sessions/{session_id}/status").json()

    def get_messages(self, session_id: str, after_id: int = 0, sanitize: bool = True):
        params = {"after_id": after_id, "sanitize": str(bool(sanitize)).lower()}
        return self._req("GET", f"/v1/sessions/{session_id}/messages", params=params).json()

    def navigate(self, session_id: str, url: str):
        payload = {"url": url}
        return self._req("POST", f"/v1/sessions/{session_id}/navigate", json=payload).json()

    def screenshot(self, session_id: str):
        return self._req("GET", f"/v1/sessions/{session_id}/screenshot").json()

    def pause(self, session_id: str):
        return self._req("POST", f"/v1/sessions/{session_id}/pause").json()

    def resume(self, session_id: str):
        return self._req("POST", f"/v1/sessions/{session_id}/resume").json()

    def cancel(self, session_id: str):
        return self._req("POST", f"/v1/sessions/{session_id}/cancel").json()


class AGITool(BaseAnthropicTool):
    """
    Tool for delegating tasks to AGI.tech agents.
    
    This tool allows your Claude agent to create AGI sessions, send tasks,
    and retrieve results from AGI's browser automation agents.
    """

    def __init__(self):
        super().__init__()
        self.client = AGIAPIClient()
        self._active_sessions = {}  # Track active sessions for cleanup

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.cleanup()
        self.client.close()

    def to_params(self) -> BetaToolUnionParam:
        return {
            "name": "agi_agent",
            "type": "custom",
            "description": """Delegate tasks to an AGI.tech agent for browser automation and web research.
            
Use this tool when you need to:
- Perform complex web searches and research
- Navigate websites and extract information
- Book flights, hotels, or other online services
- Fill out forms and complete web-based tasks
- Take screenshots of websites
- Interact with web applications

The AGI agent runs in its own browser environment and can handle tasks that require
visual navigation, form filling, and complex multi-step web interactions.""",
            "input_schema": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": [
                            "create_session",
                            "send_task",
                            "get_status",
                            "get_results",
                            "screenshot",
                            "navigate",
                            "pause",
                            "resume",
                            "cancel",
                            "delete_session",
                        ],
                        "description": "The action to perform with the AGI agent.",
                    },
                    "session_id": {
                        "type": "string",
                        "description": "The AGI session ID (required for all actions except create_session).",
                    },
                    "agent_name": {
                        "type": "string",
                        "enum": ["agi-0", "agi-0-fast"],
                        "description": "The AGI agent model to use (for create_session).",
                        "default": "agi-0",
                    },
                    "message": {
                        "type": "string",
                        "description": "The task or question to send to the AGI agent (for send_task).",
                    },
                    "url": {
                        "type": "string",
                        "description": "The URL to navigate to (for navigate action).",
                    },
                    "wait": {
                        "type": "boolean",
                        "description": "Whether to wait for task completion (for send_task). Default: true.",
                        "default": True,
                    },
                    "max_wait_seconds": {
                        "type": "number",
                        "description": f"Maximum seconds to wait for completion. Default: {MAX_POLL_SECONDS}.",
                        "default": MAX_POLL_SECONDS,
                    },
                },
                "required": ["action"],
            },
        }

    async def __call__(
        self,
        action: Literal[
            "create_session",
            "send_task",
            "get_status",
            "get_results",
            "screenshot",
            "navigate",
            "pause",
            "resume",
            "cancel",
            "delete_session",
        ],
        session_id: str | None = None,
        agent_name: str = "agi-0",
        message: str | None = None,
        url: str | None = None,
        wait: bool = True,
        max_wait_seconds: float = MAX_POLL_SECONDS,
        **kwargs,
    ) -> ToolResult:
        """Execute AGI agent action."""
        
        if not AGI_API_KEY:
            return ToolResult(
                error="AGI_API_KEY environment variable not set. Please configure your AGI API key."
            )

        try:
            if action == "create_session":
                return await self._create_session(agent_name)
            
            # All other actions require session_id
            if not session_id:
                return ToolResult(error=f"session_id is required for action '{action}'")

            if action == "send_task":
                if not message:
                    return ToolResult(error="message is required for send_task action")
                return await self._send_task(session_id, message, wait, max_wait_seconds)
            
            elif action == "get_status":
                return await self._get_status(session_id)
            
            elif action == "get_results":
                return await self._get_results(session_id)
            
            elif action == "screenshot":
                return await self._screenshot(session_id)
            
            elif action == "navigate":
                if not url:
                    return ToolResult(error="url is required for navigate action")
                return await self._navigate(session_id, url)
            
            elif action == "pause":
                return await self._pause(session_id)
            
            elif action == "resume":
                return await self._resume(session_id)
            
            elif action == "cancel":
                return await self._cancel(session_id)
            
            elif action == "delete_session":
                return await self._delete_session(session_id)
            
            else:
                return ToolResult(error=f"Unknown action: {action}")

        except (RuntimeError, requests.RequestException, TimeoutError) as e:
            logger.error(f"AGI tool error: {str(e)}", exc_info=True)
            return ToolResult(error=f"AGI API error: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected AGI error: {type(e).__name__}", exc_info=True)
            return ToolResult(error=f"Unexpected error in AGI tool: {type(e).__name__}")

    async def _create_session(self, agent_name: str) -> ToolResult:
        """Create a new AGI session."""
        try:
            result = await asyncio.to_thread(self.client.create_session, agent_name)
            session_id = result.get("session_id")
            vnc_url = result.get("vnc_url", "")
            
            self._active_sessions[session_id] = {
                "created_at": time.time(),
                "agent_name": agent_name,
            }
            
            output = f"""AGI Session Created Successfully

Session ID: {session_id}
Agent: {agent_name}
Status: {result.get('status', 'unknown')}
VNC URL: {vnc_url if vnc_url else 'Not available'}

You can now use this session_id to send tasks, get status, or take screenshots.

Example next steps:
1. Send a task: action="send_task", session_id="{session_id}", message="Your task here"
2. Take screenshot: action="screenshot", session_id="{session_id}"
3. Navigate: action="navigate", session_id="{session_id}", url="https://example.com"
"""
            return ToolResult(output=output)
        except Exception as e:
            return ToolResult(error=f"Failed to create session: {str(e)}")

    async def _send_task(
        self, session_id: str, message: str, wait: bool, max_wait_seconds: float
    ) -> ToolResult:
        """Send a task to the AGI agent and optionally wait for completion."""
        try:
            # Send the message
            await asyncio.to_thread(self.client.message_agent, session_id, message)
            
            if not wait:
                return ToolResult(
                    output=f"Task sent to AGI agent (session: {session_id}). Use get_status or get_results to check progress."
                )
            
            # Poll for completion with exponential backoff
            start_time = time.time()
            after_id = 0
            all_messages = []
            poll_interval = POLL_INTERVAL_SECS
            max_poll_interval = 10.0

            while time.time() - start_time < max_wait_seconds:
                # Get status
                status_result = await asyncio.to_thread(self.client.get_status, session_id)
                status = status_result.get("status")

                # Get new messages
                messages_result = await asyncio.to_thread(
                    self.client.get_messages, session_id, after_id
                )
                new_messages = messages_result.get("messages", [])

                for msg in new_messages:
                    msg_id = msg.get("id", 0)
                    if msg_id > after_id:
                        after_id = msg_id
                    all_messages.append(msg)

                # Check if finished
                if status in ("finished", "error"):
                    # Format the result
                    output = self._format_task_result(session_id, status, all_messages)
                    return ToolResult(output=output)

                # Wait with exponential backoff (reset on new messages)
                if new_messages:
                    poll_interval = POLL_INTERVAL_SECS  # Reset on activity
                else:
                    poll_interval = min(poll_interval * 1.5, max_poll_interval)
                await asyncio.sleep(poll_interval)
            
            # Timeout
            output = self._format_task_result(
                session_id, "timeout", all_messages, timeout=True
            )
            return ToolResult(output=output)
            
        except Exception as e:
            return ToolResult(error=f"Failed to send task: {str(e)}")

    def _format_task_result(
        self, session_id: str, status: str, messages: list, timeout: bool = False
    ) -> str:
        """Format the task execution result."""
        output_parts = [f"AGI Task Execution Result (Session: {session_id})"]
        output_parts.append(f"Status: {status}")
        
        if timeout:
            output_parts.append("\n⚠️ Task did not complete within the timeout period.")
            output_parts.append("Use get_results to check later, or increase max_wait_seconds.")
        
        output_parts.append(f"\nMessages from AGI Agent ({len(messages)} total):\n")
        
        # Group messages by type
        thoughts = [m for m in messages if m.get("type") == "THOUGHT"]
        questions = [m for m in messages if m.get("type") == "QUESTION"]
        logs = [m for m in messages if m.get("type") == "LOG"]
        
        if thoughts:
            output_parts.append("\n📝 Agent Thoughts:")
            for msg in thoughts[-5:]:  # Last 5 thoughts
                content = msg.get("content", "")
                output_parts.append(f"  - {content[:200]}")
        
        if questions:
            output_parts.append("\n❓ Questions (may need user input):")
            for msg in questions:
                output_parts.append(f"  - {msg.get('content', '')}")
        
        if logs:
            output_parts.append("\n📊 Activity Log:")
            for msg in logs[-10:]:  # Last 10 logs
                output_parts.append(f"  - {msg.get('content', '')[:150]}")
        
        # Get the final result/answer if available
        final_messages = [m for m in messages if m.get("type") not in ["THOUGHT", "LOG"]]
        if final_messages:
            output_parts.append("\n✅ Final Result:")
            for msg in final_messages[-3:]:  # Last 3 meaningful messages
                output_parts.append(f"{msg.get('content', '')}")
        
        return "\n".join(output_parts)

    async def _get_status(self, session_id: str) -> ToolResult:
        """Get the current status of an AGI session."""
        try:
            result = await asyncio.to_thread(self.client.get_status, session_id)
            status = result.get("status")
            
            status_desc = {
                "running": "🏃 Agent is actively working on the task",
                "waiting_for_input": "⏸️ Agent is waiting for user input or clarification",
                "finished": "✅ Task completed successfully",
                "error": "❌ Task encountered an error",
            }.get(status, f"Unknown status: {status}")
            
            output = f"""AGI Session Status

Session ID: {session_id}
Status: {status}
{status_desc}

Use 'get_results' to retrieve messages and output from the agent.
"""
            return ToolResult(output=output)
        except Exception as e:
            return ToolResult(error=f"Failed to get status: {str(e)}")

    async def _get_results(self, session_id: str) -> ToolResult:
        """Get all messages and results from an AGI session."""
        try:
            messages_result = await asyncio.to_thread(
                self.client.get_messages, session_id, after_id=0
            )
            messages = messages_result.get("messages", [])
            status = messages_result.get("status", {})
            
            if not messages:
                return ToolResult(output=f"No messages yet from AGI agent (session: {session_id})")
            
            output = self._format_task_result(session_id, status.get("status", "unknown"), messages)
            return ToolResult(output=output)
            
        except Exception as e:
            return ToolResult(error=f"Failed to get results: {str(e)}")

    async def _screenshot(self, session_id: str) -> ToolResult:
        """Take a screenshot of the AGI agent's browser."""
        try:
            result = await asyncio.to_thread(self.client.screenshot, session_id)
            screenshot_data = result.get("screenshot", "")
            current_url = result.get("url", "")
            title = result.get("title", "")
            
            # Extract base64 data
            if screenshot_data.startswith("data:image/jpeg;base64,"):
                base64_data = screenshot_data.split(",", 1)[1]
            else:
                base64_data = screenshot_data
            
            output = f"""AGI Browser Screenshot

Session: {session_id}
Current URL: {current_url}
Page Title: {title}

Screenshot captured successfully.
"""
            return ToolResult(output=output, base64_image=base64_data)
            
        except Exception as e:
            return ToolResult(error=f"Failed to take screenshot: {str(e)}")

    async def _navigate(self, session_id: str, url: str) -> ToolResult:
        """Navigate the AGI agent's browser to a URL."""
        try:
            result = await asyncio.to_thread(self.client.navigate, session_id, url)
            current_url = result.get("current_url", url)
            
            output = f"""AGI Browser Navigation

Session: {session_id}
Navigated to: {current_url}

Use 'screenshot' to see the page, or 'send_task' to interact with it.
"""
            return ToolResult(output=output)
        except Exception as e:
            return ToolResult(error=f"Failed to navigate: {str(e)}")

    async def _pause(self, session_id: str) -> ToolResult:
        """Pause an AGI session."""
        try:
            result = await asyncio.to_thread(self.client.pause, session_id)
            return ToolResult(
                output=f"AGI session {session_id} paused. Use 'resume' to continue."
            )
        except Exception as e:
            return ToolResult(error=f"Failed to pause: {str(e)}")

    async def _resume(self, session_id: str) -> ToolResult:
        """Resume a paused AGI session."""
        try:
            result = await asyncio.to_thread(self.client.resume, session_id)
            return ToolResult(output=f"AGI session {session_id} resumed.")
        except Exception as e:
            return ToolResult(error=f"Failed to resume: {str(e)}")

    async def _cancel(self, session_id: str) -> ToolResult:
        """Cancel an AGI session."""
        try:
            result = await asyncio.to_thread(self.client.cancel, session_id)
            return ToolResult(output=f"AGI session {session_id} cancelled.")
        except Exception as e:
            return ToolResult(error=f"Failed to cancel: {str(e)}")

    async def _delete_session(self, session_id: str) -> ToolResult:
        """Delete an AGI session."""
        try:
            result = await asyncio.to_thread(self.client.delete_session, session_id)
            self._active_sessions.pop(session_id, None)
            
            return ToolResult(
                output=f"AGI session {session_id} deleted successfully."
            )
        except Exception as e:
            return ToolResult(error=f"Failed to delete session: {str(e)}")

    async def cleanup(self):
        """Cleanup all active sessions."""
        for session_id in list(self._active_sessions.keys()):
            try:
                await self._delete_session(session_id)
                logger.info(f"Cleaned up AGI session: {session_id}")
            except Exception as e:
                logger.warning(f"Failed to cleanup session {session_id}: {e}")

