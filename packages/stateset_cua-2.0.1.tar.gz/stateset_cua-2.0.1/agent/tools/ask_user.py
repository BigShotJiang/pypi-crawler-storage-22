"""
Ask User Tool.

This custom tool allows the agent to pause and ask the human operator a
question, optionally presenting multiple choice options and allowing a
free-form response.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
import sys
from typing import Any, Literal, Sequence

from anthropic.types.beta import BetaToolUnionParam

from .base import BaseAnthropicTool, ToolError, ToolResult


class AskUserTool(BaseAnthropicTool):
    """Prompt the human operator for input during agent execution."""

    name: Literal["ask_user"] = "ask_user"
    api_type: Literal["custom"] = "custom"

    def to_params(self) -> BetaToolUnionParam:
        return {
            "name": self.name,
            "type": self.api_type,
            "description": (
                "Ask the human operator a question and wait for their response. "
                "Use this when you need clarification, confirmation, or a choice "
                "between multiple next actions. Provide `options` to offer "
                "multiple-choice answers; set `allow_freeform` to let the user "
                "type a custom answer."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "question": {
                        "type": "string",
                        "description": "The question to ask the user.",
                    },
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Optional multiple-choice options to present. "
                            "The user can reply with an option number."
                        ),
                    },
                    "allow_freeform": {
                        "type": "boolean",
                        "default": True,
                        "description": (
                            "If true, the user may type any answer instead of selecting an option."
                        ),
                    },
                    "default_option": {
                        "type": "integer",
                        "minimum": 1,
                        "description": (
                            "Optional default option number (1-based). Used when the user presses Enter."
                        ),
                    },
                },
                "required": ["question"],
            },
        }

    async def __call__(
        self,
        *,
        question: str,
        options: Sequence[str] | None = None,
        allow_freeform: bool = True,
        default_option: int | None = None,
        **kwargs: Any,
    ) -> ToolResult:
        normalized_question = question.strip() if isinstance(question, str) else ""
        if not normalized_question:
            raise ToolError("question must be a non-empty string")

        if options is None:
            option_list: list[str] = []
        elif isinstance(options, (list, tuple)):
            option_list = [str(opt).strip() for opt in options if str(opt).strip()]
        else:
            raise ToolError("options must be an array of strings")

        if not allow_freeform and not option_list:
            raise ToolError("allow_freeform=false requires at least one option")

        if default_option is not None:
            if not option_list:
                raise ToolError("default_option requires non-empty options")
            if not isinstance(default_option, int):
                raise ToolError("default_option must be an integer (1-based)")
            if default_option < 1 or default_option > len(option_list):
                raise ToolError(
                    f"default_option must be between 1 and {len(option_list)} (got {default_option})"
                )

        if not sys.stdin or not hasattr(sys.stdin, "isatty") or not sys.stdin.isatty():
            return ToolResult(
                error=(
                    "ask_user requires interactive stdin (TTY). "
                    "Re-run in an interactive terminal, or provide the missing information directly."
                )
            )

        # Render prompt
        print("\n[User input needed]")
        print(normalized_question)

        if option_list:
            for idx, opt in enumerate(option_list, start=1):
                suffix = " (default)" if default_option == idx else ""
                print(f"  {idx}) {opt}{suffix}")
            if allow_freeform:
                print("  (or type your own answer)")

        prompt = "Select an option number" if option_list else "Answer"
        if allow_freeform and option_list:
            prompt += " (or type an answer)"
        if default_option is not None:
            prompt += f" [default {default_option}]"
        prompt += ": "

        while True:
            try:
                raw = await self._read_user_input(prompt)
            except EOFError:
                return ToolResult(error="User input unavailable (EOF)")

            response = raw.strip()
            if not response:
                if default_option is not None and option_list:
                    selected_number = default_option
                    selected_value = option_list[selected_number - 1]
                    return ToolResult(
                        output=json.dumps(
                            {
                                "answer": selected_value,
                                "selected_option_number": selected_number,
                                "selected_option": selected_value,
                                "was_freeform": False,
                            }
                        )
                    )
                print("Please enter a response.")
                continue

            lowered = response.lower()
            if lowered in {"q", "quit", "exit", "cancel"}:
                return ToolResult(error="User cancelled the request")

            if option_list:
                if response.isdigit():
                    selected_number = int(response)
                    if 1 <= selected_number <= len(option_list):
                        selected_value = option_list[selected_number - 1]
                        return ToolResult(
                            output=json.dumps(
                                {
                                    "answer": selected_value,
                                    "selected_option_number": selected_number,
                                    "selected_option": selected_value,
                                    "was_freeform": False,
                                }
                            )
                        )
                    print(
                        f"Invalid option. Enter a number between 1 and {len(option_list)}."
                    )
                    continue

                if not allow_freeform:
                    print(
                        f"Please select an option number between 1 and {len(option_list)}."
                    )
                    continue

            # Free-form answer
            return ToolResult(
                output=json.dumps(
                    {
                        "answer": response,
                        "selected_option_number": None,
                        "selected_option": None,
                        "was_freeform": True,
                    }
                )
            )

    @staticmethod
    async def _read_user_input(prompt: str) -> str:
        """
        Read a line of user input without relying on the event loop's default executor.

        Pytest-asyncio creates many short-lived event loops; using `asyncio.to_thread`
        can leave default executor threads around during teardown. We use a dedicated
        per-call executor and shut it down immediately after the read completes.
        """
        loop = asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            return await loop.run_in_executor(executor, input, prompt)
