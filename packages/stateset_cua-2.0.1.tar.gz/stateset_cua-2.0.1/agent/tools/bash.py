import asyncio
import logging
import os
from typing import Any, Literal

from .base import BaseAnthropicTool, CLIResult, ToolError, ToolResult

logger = logging.getLogger(__name__)


def _get_bash_settings() -> dict:
    """Load bash tool settings from config, with safe fallback to defaults."""
    try:
        from agent.config import get_config
        return get_config().tools.bash
    except Exception:
        return {"timeout": 60.0, "output_delay": 0.05}


class _BashSession:
    """A session of a bash shell."""

    _started: bool
    _process: asyncio.subprocess.Process

    command: str = "/bin/bash"
    _sentinel: str = "<<exit>>"

    def __init__(self):
        settings = _get_bash_settings()
        self._output_delay: float = settings.get("output_delay", 0.05)
        self._timeout: float = settings.get("timeout", 60.0)
        self._started = False
        self._timed_out = False

    async def start(self):
        if self._started:
            return

        logger.debug("Starting bash session (timeout=%.1fs)", self._timeout)
        self._process = await asyncio.create_subprocess_shell(
            self.command,
            preexec_fn=os.setsid,
            shell=True,
            bufsize=0,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        self._started = True
        self._timed_out = False  # Reset timeout flag on restart

    async def stop(self):
        """Terminate the bash shell with graceful shutdown and kill fallback."""
        if not self._started:
            raise ToolError("Session has not started.")
        if self._process.returncode is not None:
            return
        self._process.terminate()
        try:
            await asyncio.wait_for(self._process.wait(), timeout=5.0)
        except asyncio.TimeoutError:
            self._process.kill()
            await self._process.wait()

    def _validate_command(self, command: str) -> tuple[bool, str]:
        """
        Validate command safety. Returns (is_safe, reason).

        Security approach:
        1. Block known dangerous patterns and commands
        2. Detect obfuscation attempts (variable expansion, command substitution)
        3. Check for path traversal in arguments
        """
        import re
        import shlex

        # Normalize command - expand common obfuscation techniques for analysis
        normalized = command.lower()

        # Block command substitution that could hide dangerous commands
        if re.search(r'\$\([^)]+\)', command) or re.search(r'`[^`]+`', command):
            # Command substitution detected - check for dangerous commands inside
            inner_commands = re.findall(r'\$\(([^)]+)\)', command) + re.findall(r'`([^`]+)`', command)
            for inner in inner_commands:
                is_safe, reason = self._validate_command(inner)
                if not is_safe:
                    return False, f"Dangerous command in substitution: {reason}"

        # Dangerous patterns that should trigger warnings
        dangerous_patterns = [
            # File deletion
            (r'\brm\s+(-[a-zA-Z]*r[a-zA-Z]*\s+)?(/|~|\$HOME)', "Recursive deletion of critical directory"),
            (r'\brm\s+-[a-zA-Z]*f[a-zA-Z]*\s+-[a-zA-Z]*r', "Force recursive deletion"),
            (r'\brm\s+-[a-zA-Z]*r[a-zA-Z]*\s+-[a-zA-Z]*f', "Force recursive deletion"),
            # Disk/device operations
            (r'\bdd\s+.*\bof=/dev/', "Writing to device"),
            (r'\bdd\s+.*\bif=/dev/(zero|random|urandom)', "Writing from device to file"),
            (r'>\s*/dev/[hs]d[a-z]', "Writing to disk device"),
            (r'\bmkfs', "Formatting filesystem"),
            (r'\bfdisk\b', "Disk partitioning"),
            (r'\bparted\b', "Disk partitioning"),
            # Fork bomb variations
            (r':\(\)\s*\{', "Potential fork bomb"),
            (r'\bwhile\s+true.*;\s*do.*&', "Infinite loop spawning background processes"),
            # Permission changes on critical paths
            (r'\bchmod\s+(-[a-zA-Z]*R[a-zA-Z]*\s+)?[0-7]*\s+(/|~|\$HOME)', "Changing permissions on critical directory"),
            (r'\bchown\s+(-[a-zA-Z]*R[a-zA-Z]*\s+)?.*\s+(/|~|\$HOME)', "Changing ownership on critical directory"),
            # System modification
            (r'\b(shutdown|reboot|poweroff|init\s+[0-6])\b', "System shutdown/reboot"),
            (r'\bsystemctl\s+(stop|disable|mask)\s+(ssh|sshd|network)', "Disabling critical services"),
            # Dangerous redirections
            (r'>\s*/etc/', "Overwriting system configuration"),
            (r'>\s*/boot/', "Overwriting boot files"),
            # Network exfiltration indicators
            (r'\bcurl\s+.*\|\s*bash', "Remote code execution via curl pipe to bash"),
            (r'\bwget\s+.*\|\s*bash', "Remote code execution via wget pipe to bash"),
            (r'\bnc\s+-[a-zA-Z]*e', "Netcat with execute flag"),
            # Cleanup of evidence
            (r'\bhistory\s+-[cd]', "Clearing command history"),
            (r'>\s*~/.bash_history', "Overwriting bash history"),
            (r'\bunset\s+HISTFILE', "Disabling history"),
        ]

        for pattern, reason in dangerous_patterns:
            if re.search(pattern, command, re.IGNORECASE):
                return False, reason

        # Check for suspicious variable expansion that could bypass filters
        # E.g., rm -rf $DANGEROUS_PATH where DANGEROUS_PATH=/
        if re.search(r'\$[A-Za-z_][A-Za-z0-9_]*', command):
            # Variables detected - warn if used with dangerous commands
            dangerous_commands = ['rm', 'dd', 'mkfs', 'chmod', 'chown', 'mv']
            for cmd in dangerous_commands:
                if re.search(rf'\b{cmd}\b.*\$[A-Za-z_]', command, re.IGNORECASE):
                    return False, f"Variable expansion with {cmd} command requires review"

        return True, ""

    async def run(self, command: str):
        """Execute a command in the bash shell."""
        if not self._started:
            raise ToolError("Session has not started.")
        if self._process.returncode is not None:
            return ToolResult(
                system="tool must be restarted",
                error=f"bash has exited with returncode {self._process.returncode}",
            )
        if self._timed_out:
            raise ToolError(
                f"timed out: bash has not returned in {self._timeout} seconds and must be restarted",
            )

        # Validate command safety
        is_safe, reason = self._validate_command(command)
        if not is_safe:
            logger.warning("Command blocked: %s (reason: %s)", command[:80], reason)
            return ToolResult(
                error=f"Command blocked for safety: {reason}. If you need to run this command, please ask the user for confirmation.",
                system="dangerous_command_blocked"
            )

        # we know these are not None because we created the process with PIPEs
        assert self._process.stdin
        assert self._process.stdout
        assert self._process.stderr

        # send command to the process
        self._process.stdin.write(
            command.encode() + f"; echo '{self._sentinel}'\n".encode()
        )
        await self._process.stdin.drain()

        async def _read_output() -> str:
            while True:
                await asyncio.sleep(self._output_delay)
                # if we read directly from stdout/stderr, it will wait forever for
                # EOF. use the StreamReader buffer directly instead.
                buffered_output = self._process.stdout._buffer.decode()  # pyright: ignore[reportAttributeAccessIssue]
                if self._sentinel in buffered_output:
                    return buffered_output[: buffered_output.index(self._sentinel)]

        # read output from the process, until the sentinel is found
        try:
            output = await asyncio.wait_for(_read_output(), timeout=self._timeout)
        except asyncio.TimeoutError:
            self._timed_out = True
            logger.error("Bash command timed out after %.1fs: %s", self._timeout, command[:120])
            raise ToolError(
                f"timed out: bash has not returned in {self._timeout} seconds and must be restarted",
            ) from None
        else:
            if output.endswith("\n"):
                output = output[:-1]

        error = self._process.stderr._buffer.decode()  # pyright: ignore[reportAttributeAccessIssue]
        if error.endswith("\n"):
            error = error[:-1]

        # clear the buffers so that the next output can be read correctly
        self._process.stdout._buffer.clear()  # pyright: ignore[reportAttributeAccessIssue]
        self._process.stderr._buffer.clear()  # pyright: ignore[reportAttributeAccessIssue]

        return CLIResult(output=output, error=error)


class BashTool20250124(BaseAnthropicTool):
    """
    A tool that allows the agent to run bash commands.
    The tool parameters are defined by Anthropic and are not editable.
    """

    _session: _BashSession | None

    api_type: Literal["bash_20250124"] = "bash_20250124"
    name: Literal["bash"] = "bash"

    def __init__(self):
        self._session = None
        super().__init__()

    def to_params(self) -> Any:
        return {
            "type": self.api_type,
            "name": self.name,
        }

    async def __call__(
        self, command: str | None = None, restart: bool = False, **kwargs
    ):
        if restart:
            if self._session:
                await self._session.stop()
            self._session = _BashSession()
            await self._session.start()

            return ToolResult(system="tool has been restarted.")

        if self._session is None:
            self._session = _BashSession()
            await self._session.start()

        if command is not None:
            return await self._session.run(command)

        raise ToolError("no command provided.")


class BashTool20241022(BashTool20250124):
    api_type: Literal["bash_20241022"] = "bash_20241022"  # pyright: ignore[reportIncompatibleVariableOverride]