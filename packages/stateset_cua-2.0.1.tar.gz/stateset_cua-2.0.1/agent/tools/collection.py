"""Collection classes for managing multiple tools."""

from typing import Any, Iterable

from anthropic.types.beta import BetaToolUnionParam

from .base import (
    BaseAnthropicTool,
    ToolError,
    ToolFailure,
    ToolResult,
)


class ToolCollection:
    """A collection of anthropic-defined tools."""

    def __init__(self, *tools: BaseAnthropicTool):
        self.tools = tools
        self.tool_map: dict[str, BaseAnthropicTool] = {}
        for tool in tools:
            params = dict(tool.to_params())
            name = params.get("name")
            if not isinstance(name, str) or not name:
                raise ValueError(
                    "All tools must provide a string name in to_params() output"
                )
            self.tool_map[name] = tool

    def to_params(
        self,
    ) -> list[BetaToolUnionParam]:
        params_list: list[BetaToolUnionParam] = []
        for tool in self.tools:
            params = dict(tool.to_params())
            if getattr(tool, "_defer_loading_override", False):
                params["defer_loading"] = True
            params_list.append(params)
        return params_list

    def set_deferred_tools(
        self, tool_names: Iterable[str]
    ) -> tuple[list[str], list[str]]:
        """
        Flag specific tools so their definitions are marked with defer_loading.

        Returns:
            applied: Tools found in the collection and marked as deferred.
            missing: Requested tool names that are not present.
        """
        applied: list[str] = []
        missing: list[str] = []
        seen: set[str] = set()

        for name in tool_names:
            if not name:
                continue
            if name in seen:
                continue
            seen.add(name)
            tool = self.tool_map.get(name)
            if tool:
                setattr(tool, "_defer_loading_override", True)
                applied.append(name)
            else:
                missing.append(name)

        return applied, missing

    async def run(self, *, name: str, tool_input: dict[str, Any]) -> ToolResult:
        tool = self.tool_map.get(name)
        if not tool:
            return ToolFailure(error=f"Tool {name} is invalid")
        try:
            return await tool(**tool_input)
        except ToolError as e:
            return ToolFailure(error=e.message)