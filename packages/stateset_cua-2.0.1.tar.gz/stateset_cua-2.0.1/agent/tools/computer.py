import asyncio
import base64
import io
import logging
import os
import shlex
import shutil
from enum import Enum
from pathlib import Path
from typing import Literal, TypedDict, cast, get_args
from uuid import uuid4

from anthropic.types.beta import BetaToolComputerUse20241022Param, BetaToolUnionParam

from .base import BaseAnthropicTool, ToolError, ToolResult
from .run import run

logger = logging.getLogger(__name__)

OUTPUT_DIR = os.environ.get(
    "AGENT_OUTPUT_DIR",
    os.path.join(os.environ.get("AGENT_DATA_DIR", "/tmp"), "outputs"),
)

# Typing configuration - sourced from agent/config.py ToolSettings with fallback defaults
def _get_computer_settings() -> dict:
    """Load computer tool settings from config, with safe fallback to defaults."""
    try:
        from agent.config import get_config
        return get_config().tools.computer
    except Exception:
        return {"typing_delay_ms": 8, "click_delay_ms": 100}

TYPING_DELAY_MS = _get_computer_settings().get("typing_delay_ms", 8)
TYPING_GROUP_SIZE = 100  # Batch size for fewer shell calls

Action_20241022 = Literal[
    "key",
    "type",
    "mouse_move",
    "left_click",
    "left_click_drag",
    "right_click",
    "middle_click",
    "double_click",
    "screenshot",
    "cursor_position",
]

Action_20250124 = (
    Action_20241022
    | Literal[
        "left_mouse_down",
        "left_mouse_up",
        "scroll",
        "hold_key",
        "wait",
        "triple_click",
    ]
)

Action_20251124 = Action_20250124 | Literal["zoom"]

ZoomRegion = tuple[int, int, int, int]

ScrollDirection = Literal["up", "down", "left", "right"]


class Resolution(TypedDict):
    width: int
    height: int


# sizes above XGA/WXGA are not recommended (see README.md)
# scale down to one of these targets if ComputerTool._scaling_enabled is set
MAX_SCALING_TARGETS: dict[str, Resolution] = {
    "XGA": Resolution(width=1024, height=768),  # 4:3
    "WXGA": Resolution(width=1280, height=800),  # 16:10
    "FWXGA": Resolution(width=1366, height=768),  # ~16:9
}

CLICK_BUTTONS = {
    "left_click": 1,
    "right_click": 3,
    "middle_click": 2,
    "double_click": "--repeat 2 --delay 10 1",
    "triple_click": "--repeat 3 --delay 10 1",
}


class ScalingSource(Enum):
    COMPUTER = "computer"
    API = "api"


class ComputerToolOptions(TypedDict):
    display_height_px: int
    display_width_px: int
    display_number: int | None


def chunks(s: str, chunk_size: int) -> list[str]:
    return [s[i : i + chunk_size] for i in range(0, len(s), chunk_size)]


class BaseComputerTool:
    """
    A tool that allows the agent to interact with the screen, keyboard, and mouse of the current computer.
    The tool parameters are defined by Anthropic and are not editable.
    """

    name: Literal["computer"] = "computer"
    width: int
    height: int
    display_num: int | None

    # Adaptive screenshot delays based on action type
    # SPEED OPTIMIZED: Reduced delays to minimum viable values
    # Modern displays update at 60Hz (16.7ms), so delays > 100ms are for UI animations
    _screenshot_delays = {
        'screenshot': 0.0,      # No delay for screenshot-only
        'cursor_position': 0.0, # Just returns coordinates
        'key': 0.05,           # Key presses are instant (reduced from 0.2)
        'left_click': 0.1,     # Fast click actions (reduced from 0.3)
        'right_click': 0.1,    # (reduced from 0.3)
        'double_click': 0.15,  # Slightly longer for double-click animation (reduced from 0.3)
        'triple_click': 0.15,  # (reduced from 0.3)
        'middle_click': 0.1,   # (reduced from 0.3)
        'type': 0.15,          # Typing needs text to settle (reduced from 0.4)
        'scroll': 0.1,         # Scrolling is fast (reduced from 0.3)
        'mouse_move': 0.05,    # Mouse movement is instant (reduced from 0.2)
        'left_click_drag': 0.2, # Drag needs settling (reduced from 0.4)
        'hold_key': 0.1,       # (reduced from 0.3)
        'wait': 0.0,           # Wait action takes its own screenshot
        'default': 0.2         # Conservative fallback (reduced from 0.6)
    }
    _screenshot_delay = 0.2  # Fallback delay (reduced from 0.6)
    _scaling_enabled = True

    @property
    def options(self) -> ComputerToolOptions:
        width, height = self.scale_coordinates(
            ScalingSource.COMPUTER, self.width, self.height
        )
        return {
            "display_width_px": width,
            "display_height_px": height,
            "display_number": self.display_num,
        }

    def __init__(self):
        super().__init__()

        self.width = int(os.getenv("WIDTH") or 0)
        self.height = int(os.getenv("HEIGHT") or 0)
        assert self.width and self.height, "WIDTH, HEIGHT must be set"
        if (display_num := os.getenv("DISPLAY_NUM")) is not None:
            self.display_num = int(display_num)
            self._display_prefix = f"DISPLAY=:{self.display_num} "
        else:
            self.display_num = None
            self._display_prefix = ""

        self.xdotool = f"{self._display_prefix}xdotool"
        
        # Initialize screenshot caching for duplicate prevention
        self._last_screenshot_hash = None
        self._last_screenshot_data = None

    async def __call__(
        self,
        *,
        action: Action_20241022,
        text: str | None = None,
        coordinate: tuple[int, int] | None = None,
        **kwargs,
    ):
        if action in ("mouse_move", "left_click_drag"):
            if coordinate is None:
                raise ToolError(f"coordinate is required for {action}")
            if text is not None:
                raise ToolError(f"text is not accepted for {action}")

            x, y = self.validate_and_get_coordinates(coordinate)

            if action == "mouse_move":
                command_parts = [self.xdotool, f"mousemove --sync {x} {y}"]
                return await self.shell(" ".join(command_parts), action_type='mouse_move')
            elif action == "left_click_drag":
                command_parts = [
                    self.xdotool,
                    f"mousedown 1 mousemove --sync {x} {y} mouseup 1",
                ]
                return await self.shell(" ".join(command_parts), action_type='left_click_drag')

        if action in ("key", "type"):
            if text is None:
                raise ToolError(f"text is required for {action}")
            if coordinate is not None:
                raise ToolError(f"coordinate is not accepted for {action}")
            if not isinstance(text, str):
                raise ToolError(output=f"{text} must be a string")

            if action == "key":
                command_parts = [self.xdotool, f"key -- {shlex.quote(text)}"]
                return await self.shell(" ".join(command_parts), action_type='key')
            elif action == "type":
                results: list[ToolResult] = []
                for chunk in chunks(text, TYPING_GROUP_SIZE):
                    command_parts = [
                        self.xdotool,
                        f"type --delay {TYPING_DELAY_MS} -- {shlex.quote(chunk)}",
                    ]
                    results.append(
                        await self.shell(" ".join(command_parts), take_screenshot=False)
                    )
                screenshot_base64 = (await self.screenshot()).base64_image
                return ToolResult(
                    output="".join(result.output or "" for result in results),
                    error="".join(result.error or "" for result in results),
                    base64_image=screenshot_base64,
                )

        if action in (
            "left_click",
            "right_click",
            "double_click",
            "middle_click",
            "screenshot",
            "cursor_position",
        ):
            if text is not None:
                raise ToolError(f"text is not accepted for {action}")
            if coordinate is not None:
                raise ToolError(f"coordinate is not accepted for {action}")

            if action == "screenshot":
                return await self.screenshot()
            elif action == "cursor_position":
                command_parts = [self.xdotool, "getmouselocation --shell"]
                result = await self.shell(
                    " ".join(command_parts),
                    take_screenshot=False,
                    action_type='cursor_position'
                )
                output = result.output or ""
                x, y = self.scale_coordinates(
                    ScalingSource.COMPUTER,
                    int(output.split("X=")[1].split("\n")[0]),
                    int(output.split("Y=")[1].split("\n")[0]),
                )
                return result.replace(output=f"X={x},Y={y}")
            else:
                command_parts = [self.xdotool, f"click {CLICK_BUTTONS[action]}"]
                return await self.shell(" ".join(command_parts), action_type=action)

        raise ToolError(f"Invalid action: {action}")

    def validate_and_get_coordinates(self, coordinate: tuple[int, int] | None = None):
        if not isinstance(coordinate, list) or len(coordinate) != 2:
            raise ToolError(f"{coordinate} must be a tuple of length 2")
        if not all(isinstance(i, int) and i >= 0 for i in coordinate):
            raise ToolError(f"{coordinate} must be a tuple of non-negative ints")

        return self.scale_coordinates(ScalingSource.API, coordinate[0], coordinate[1])

    async def screenshot(self):
        """Take a screenshot and return base64 image without redundant disk processing."""
        output_dir = Path(OUTPUT_DIR)
        output_dir.mkdir(parents=True, exist_ok=True)
        os.chmod(str(output_dir), 0o700)
        path = output_dir / f"screenshot_{uuid4().hex}.png"

        # Prefer gnome-screenshot; fallback to scrot
        if shutil.which("gnome-screenshot"):
            screenshot_cmd = f"{self._display_prefix}gnome-screenshot -f {path} -p"
        else:
            screenshot_cmd = f"{self._display_prefix}scrot -p {path}"

        result = await self.shell(screenshot_cmd, take_screenshot=False)

        if not path.exists():
            logger.error("Screenshot failed: %s", result.error)
            raise ToolError(f"Failed to take screenshot: {result.error}")

        screenshot_bytes = path.read_bytes()
        path.unlink(missing_ok=True)

        import hashlib

        current_hash = hashlib.sha256(screenshot_bytes).hexdigest()
        if self._last_screenshot_hash == current_hash and self._last_screenshot_data:
            return result.replace(base64_image=self._last_screenshot_data)

        encoded = None

        try:
            from PIL import Image

            img = Image.open(io.BytesIO(screenshot_bytes))

            if self._scaling_enabled:
                target_width, target_height = self.scale_coordinates(
                    ScalingSource.COMPUTER, self.width, self.height
                )
                if img.width != target_width or img.height != target_height:
                    img = img.resize((target_width, target_height), Image.Resampling.LANCZOS)

            # Save as PNG to ensure consistency with media_type detection
            # PNG is lossless and handles all image types (including screenshots with text)
            buffer = io.BytesIO()
            img.save(buffer, "PNG", optimize=True)
            encoded = base64.b64encode(buffer.getvalue()).decode()
        except ImportError:
            # Fallback: use raw screenshot bytes (already PNG from gnome-screenshot/scrot)
            encoded = base64.b64encode(screenshot_bytes).decode()
        except Exception:
            # Fallback: use raw screenshot bytes (already PNG from gnome-screenshot/scrot)
            encoded = base64.b64encode(screenshot_bytes).decode()

        self._last_screenshot_hash = current_hash
        self._last_screenshot_data = encoded

        return result.replace(base64_image=encoded)

    async def shell(self, command: str, take_screenshot=True, action_type: str = 'default') -> ToolResult:
        """Run a shell command and return the output, error, and optionally a screenshot."""
        logger.debug("Computer action=%s cmd=%s", action_type, command[:80])
        _, stdout, stderr = await run(command)
        base64_image = None

        if take_screenshot:
            # Adaptive delay based on action type for optimal speed
            delay = self._screenshot_delays.get(action_type, self._screenshot_delay)
            await asyncio.sleep(delay)
            base64_image = (await self.screenshot()).base64_image

        return ToolResult(output=stdout, error=stderr, base64_image=base64_image)

    def scale_coordinates(self, source: ScalingSource, x: int, y: int):
        """Scale coordinates to a target maximum resolution."""
        if not self._scaling_enabled:
            return x, y
        ratio = self.width / self.height
        target_dimension = None
        for dimension in MAX_SCALING_TARGETS.values():
            # allow some error in the aspect ratio - not ratios are exactly 16:9
            if abs(dimension["width"] / dimension["height"] - ratio) < 0.02:
                if dimension["width"] < self.width:
                    target_dimension = dimension
                break
        if target_dimension is None:
            return x, y
        # should be less than 1
        x_scaling_factor = target_dimension["width"] / self.width
        y_scaling_factor = target_dimension["height"] / self.height
        if source == ScalingSource.API:
            if x > self.width or y > self.height:
                raise ToolError(f"Coordinates {x}, {y} are out of bounds")
            # scale up
            return round(x / x_scaling_factor), round(y / y_scaling_factor)
        # scale down
        return round(x * x_scaling_factor), round(y * y_scaling_factor)


class ComputerTool20241022(BaseComputerTool, BaseAnthropicTool):
    api_type: Literal["computer_20241022"] = "computer_20241022"

    def to_params(self) -> BetaToolComputerUse20241022Param:
        return {"name": self.name, "type": self.api_type, **self.options}


class ComputerTool20250124(BaseComputerTool, BaseAnthropicTool):
    api_type: Literal["computer_20250124"] = "computer_20250124"

    def to_params(self):
        return cast(
            BetaToolUnionParam,
            {"name": self.name, "type": self.api_type, **self.options},
        )

    async def __call__(
        self,
        *,
        action: Action_20250124,
        text: str | None = None,
        coordinate: tuple[int, int] | None = None,
        scroll_direction: ScrollDirection | None = None,
        scroll_amount: int | None = None,
        duration: int | float | None = None,
        key: str | None = None,
        **kwargs,
    ):
        if action in ("left_mouse_down", "left_mouse_up"):
            if coordinate is not None:
                raise ToolError(f"coordinate is not accepted for {action=}.")
            command_parts = [
                self.xdotool,
                f"{'mousedown' if action == 'left_mouse_down' else 'mouseup'} 1",
            ]
            return await self.shell(" ".join(command_parts))
        if action == "scroll":
            if scroll_direction is None or scroll_direction not in get_args(
                ScrollDirection
            ):
                raise ToolError(
                    f"{scroll_direction=} must be 'up', 'down', 'left', or 'right'"
                )
            if not isinstance(scroll_amount, int) or scroll_amount < 0:
                raise ToolError(f"{scroll_amount=} must be a non-negative int")
            mouse_move_part = ""
            if coordinate is not None:
                x, y = self.validate_and_get_coordinates(coordinate)
                mouse_move_part = f"mousemove --sync {x} {y}"
            scroll_button = {
                "up": 4,
                "down": 5,
                "left": 6,
                "right": 7,
            }[scroll_direction]

            command_parts = [self.xdotool, mouse_move_part]
            if text:
                command_parts.append(f"keydown {text}")
            command_parts.append(f"click --repeat {scroll_amount} {scroll_button}")
            if text:
                command_parts.append(f"keyup {text}")

            return await self.shell(" ".join(command_parts))

        if action in ("hold_key", "wait"):
            if duration is None or not isinstance(duration, (int, float)):
                raise ToolError(f"{duration=} must be a number")
            if duration < 0:
                raise ToolError(f"{duration=} must be non-negative")
            if duration > 100:
                raise ToolError(f"{duration=} is too long.")

            if action == "hold_key":
                if text is None:
                    raise ToolError(f"text is required for {action}")
                escaped_keys = shlex.quote(text)
                command_parts = [
                    self.xdotool,
                    f"keydown {escaped_keys}",
                    f"sleep {duration}",
                    f"keyup {escaped_keys}",
                ]
                return await self.shell(" ".join(command_parts))

            if action == "wait":
                await asyncio.sleep(duration)
                return await self.screenshot()

        if action in (
            "left_click",
            "right_click",
            "double_click",
            "triple_click",
            "middle_click",
        ):
            if text is not None:
                raise ToolError(f"text is not accepted for {action}")
            mouse_move_part = ""
            if coordinate is not None:
                x, y = self.validate_and_get_coordinates(coordinate)
                mouse_move_part = f"mousemove --sync {x} {y}"

            command_parts = [self.xdotool, mouse_move_part]
            if key:
                command_parts.append(f"keydown {key}")
            command_parts.append(f"click {CLICK_BUTTONS[action]}")
            if key:
                command_parts.append(f"keyup {key}")

            return await self.shell(" ".join(command_parts))

        return await super().__call__(
            action=action, text=text, coordinate=coordinate, key=key, **kwargs
        )


class ComputerTool20251124(ComputerTool20250124):
    api_type: Literal["computer_20251124"] = "computer_20251124"

    async def __call__(
        self,
        *,
        action: Action_20251124,
        text: str | None = None,
        coordinate: tuple[int, int] | None = None,
        scroll_direction: ScrollDirection | None = None,
        scroll_amount: int | None = None,
        duration: int | float | None = None,
        key: str | None = None,
        zoom_region: list[int] | ZoomRegion | None = None,
        zoom_padding: int = 24,
        **kwargs,
    ):
        if action == "zoom":
            return await self._handle_zoom(zoom_region, zoom_padding)

        return await super().__call__(
            action=cast(Action_20250124, action),
            text=text,
            coordinate=coordinate,
            scroll_direction=scroll_direction,
            scroll_amount=scroll_amount,
            duration=duration,
            key=key,
            **kwargs,
        )

    async def _handle_zoom(
        self,
        zoom_region_input: list[int] | ZoomRegion | None,
        zoom_padding: int,
    ) -> ToolResult:
        if zoom_region_input is None:
            raise ToolError("zoom_region is required for zoom action")
        if isinstance(zoom_region_input, tuple):
            zoom_region = list(zoom_region_input)
        else:
            zoom_region = zoom_region_input
        if (
            not isinstance(zoom_region, list)
            or len(zoom_region) != 4
            or not all(isinstance(value, int) for value in zoom_region)
        ):
            raise ToolError("zoom_region must be a list of four integers [x, y, width, height]")

        x, y, width, height = zoom_region
        if width <= 0 or height <= 0:
            raise ToolError("zoom_region width and height must be positive integers")

        pad = max(0, min(int(zoom_padding), 200))
        x = max(0, x - pad)
        y = max(0, y - pad)
        width += pad * 2
        height += pad * 2

        max_x = max(1, self.width)
        max_y = max(1, self.height)
        x2 = min(max_x, x + width)
        y2 = min(max_y, y + height)
        if x >= x2 or y >= y2:
            raise ToolError("zoom_region is out of bounds")

        try:
            native_x1, native_y1 = self.validate_and_get_coordinates([x, y])
            native_x2, native_y2 = self.validate_and_get_coordinates([x2, y2])
        except ToolError as exc:
            raise ToolError(f"zoom_region {zoom_region_input} is invalid: {exc}") from exc

        native_x2 = max(native_x1 + 1, native_x2)
        native_y2 = max(native_y1 + 1, native_y2)

        native_shot = await self._native_screenshot()
        if not native_shot.base64_image:
            raise ToolError("Failed to capture screenshot for zoom action")

        try:
            from PIL import Image
        except ImportError as exc:
            raise ToolError("Pillow is required for zoom action") from exc

        decoded = base64.b64decode(native_shot.base64_image)
        img = Image.open(io.BytesIO(decoded))
        crop_box = (
            max(0, min(native_x1, img.width - 1)),
            max(0, min(native_y1, img.height - 1)),
            max(1, min(native_x2, img.width)),
            max(1, min(native_y2, img.height)),
        )
        if crop_box[2] - crop_box[0] < 2 or crop_box[3] - crop_box[1] < 2:
            raise ToolError("zoom_region is too small to capture detail")

        zoom_img = img.crop(crop_box)
        buffer = io.BytesIO()
        # Save as PNG for consistency with main screenshot function
        zoom_img.save(buffer, "PNG", optimize=True)
        zoom_base64 = base64.b64encode(buffer.getvalue()).decode()

        return ToolResult(
            output=f"Zoomed region captured at ({x}, {y}) with size {x2 - x}x{y2 - y}px",
            base64_image=zoom_base64,
        )

    async def _native_screenshot(self) -> ToolResult:
        previous = self._scaling_enabled
        self._scaling_enabled = False
        try:
            return await super().screenshot()
        finally:
            self._scaling_enabled = previous