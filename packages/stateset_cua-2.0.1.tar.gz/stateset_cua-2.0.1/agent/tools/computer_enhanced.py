"""
Enhanced Computer Tool with Speed, Accuracy, and Effectiveness Improvements

Key Enhancements:
1. Smarter action retry strategies with exponential backoff
2. Enhanced coordinate validation and bounds checking
3. Action success detection and verification
4. Performance metrics tracking
5. Optimized screenshot caching
6. Parallel operation support
7. Better error messages and debugging info
"""

import asyncio
import time
import logging
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum

from .computer import (
    BaseComputerTool,
    ComputerTool20241022,
    ComputerTool20250124,
    ComputerTool20251124,
    ToolError,
    ToolResult,
    ScalingSource
)

logger = logging.getLogger(__name__)


class ActionResult(Enum):
    """Action execution result status"""
    SUCCESS = "success"
    FAILED = "failed"
    RETRY = "retry"
    PARTIAL = "partial"


@dataclass
class ActionMetrics:
    """Track performance metrics for actions"""
    action_type: str
    attempts: int = 0
    total_duration_ms: float = 0.0
    success_count: int = 0
    failure_count: int = 0
    retry_count: int = 0
    average_duration_ms: float = 0.0

    def record_attempt(self, duration_ms: float, success: bool):
        """Record an action attempt"""
        self.attempts += 1
        self.total_duration_ms += duration_ms
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        self.average_duration_ms = self.total_duration_ms / self.attempts


@dataclass
class PerformanceTracker:
    """Track performance across all actions"""
    metrics: Dict[str, ActionMetrics] = field(default_factory=dict)
    total_actions: int = 0
    total_retries: int = 0

    def get_or_create_metrics(self, action_type: str) -> ActionMetrics:
        """Get or create metrics for an action type"""
        if action_type not in self.metrics:
            self.metrics[action_type] = ActionMetrics(action_type=action_type)
        return self.metrics[action_type]

    def record_action(self, action_type: str, duration_ms: float, success: bool):
        """Record action execution"""
        self.total_actions += 1
        metrics = self.get_or_create_metrics(action_type)
        metrics.record_attempt(duration_ms, success)

    def record_retry(self, action_type: str):
        """Record a retry"""
        self.total_retries += 1
        metrics = self.get_or_create_metrics(action_type)
        metrics.retry_count += 1

    def get_summary(self) -> Dict[str, Any]:
        """Get performance summary"""
        return {
            "total_actions": self.total_actions,
            "total_retries": self.total_retries,
            "success_rate": (
                sum(m.success_count for m in self.metrics.values()) / self.total_actions
                if self.total_actions > 0 else 0.0
            ),
            "average_duration_ms": (
                sum(m.total_duration_ms for m in self.metrics.values()) / self.total_actions
                if self.total_actions > 0 else 0.0
            ),
            "by_action": {
                action: {
                    "attempts": m.attempts,
                    "success_rate": m.success_count / m.attempts if m.attempts > 0 else 0.0,
                    "average_duration_ms": m.average_duration_ms,
                    "retry_count": m.retry_count
                }
                for action, m in self.metrics.items()
            }
        }


class EnhancedCoordinateValidator:
    """Enhanced coordinate validation with better error messages"""

    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height

    def validate(
        self,
        coordinate: Optional[Tuple[int, int]],
        action: str,
        allow_negative: bool = False
    ) -> Tuple[int, int]:
        """
        Validate coordinates with detailed error messages

        Args:
            coordinate: (x, y) tuple
            action: Action type for error message
            allow_negative: Whether to allow negative coordinates

        Returns:
            Validated (x, y) tuple

        Raises:
            ToolError: If validation fails with detailed message
        """
        if coordinate is None:
            raise ToolError(
                f"Coordinate required for action '{action}'. "
                f"Please provide [x, y] where x is 0-{self.width} and y is 0-{self.height}"
            )

        if not isinstance(coordinate, (list, tuple)) or len(coordinate) != 2:
            raise ToolError(
                f"Invalid coordinate format: {coordinate}. "
                f"Expected [x, y] tuple with two integers"
            )

        x, y = coordinate

        # Type validation
        if not isinstance(x, int) or not isinstance(y, int):
            raise ToolError(
                f"Coordinates must be integers, got x={type(x).__name__}, y={type(y).__name__}"
            )

        # Range validation
        if not allow_negative and (x < 0 or y < 0):
            raise ToolError(
                f"Coordinates must be non-negative, got ({x}, {y})"
            )

        # Bounds validation
        if x > self.width or y > self.height:
            raise ToolError(
                f"Coordinates ({x}, {y}) out of bounds. "
                f"Screen size is {self.width}x{self.height}. "
                f"Maximum valid coordinates are ({self.width}, {self.height})"
            )

        # Warning for edge coordinates (might be unintentional)
        if x == 0 or y == 0 or x == self.width or y == self.height:
            logger.warning(
                f"Action '{action}' at edge coordinate ({x}, {y}). "
                f"This might be unintentional."
            )

        return (x, y)

    def validate_region(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        action: str = "region"
    ) -> Tuple[int, int, int, int]:
        """
        Validate a rectangular region

        Returns:
            Validated (x, y, width, height) tuple
        """
        if width <= 0 or height <= 0:
            raise ToolError(
                f"Region dimensions must be positive, got width={width}, height={height}"
            )

        if x + width > self.width or y + height > self.height:
            raise ToolError(
                f"Region ({x}, {y}, {width}, {height}) extends beyond screen bounds "
                f"({self.width}x{self.height})"
            )

        return (x, y, width, height)


class RetryStrategy:
    """Intelligent retry strategy for failed actions"""

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 0.1,
        max_delay: float = 2.0,
        backoff_multiplier: float = 2.0
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_multiplier = backoff_multiplier

    def get_delay(self, attempt: int) -> float:
        """Calculate exponential backoff delay"""
        delay = self.base_delay * (self.backoff_multiplier ** attempt)
        return min(delay, self.max_delay)

    def should_retry(self, attempt: int, error: Exception) -> bool:
        """Determine if action should be retried"""
        if attempt >= self.max_retries:
            return False

        # Don't retry validation errors
        if isinstance(error, ToolError) and "out of bounds" in str(error):
            return False

        # Don't retry if coordinate format is wrong
        if isinstance(error, ToolError) and "must be" in str(error):
            return False

        # Retry on transient errors
        error_msg = str(error).lower()
        retryable_errors = [
            "timeout",
            "connection",
            "failed to",
            "could not",
            "unable to",
            "network"
        ]

        return any(err in error_msg for err in retryable_errors)


class EnhancedComputerToolMixin:
    """
    Mixin to add enhancements to any computer tool version

    Adds:
    - Smart retry logic
    - Performance tracking
    - Enhanced validation
    - Action success detection
    """

    def __init__(self):
        super().__init__()
        self._performance_tracker = PerformanceTracker()
        self._retry_strategy = RetryStrategy()
        self._validator = EnhancedCoordinateValidator(self.width, self.height)
        self._action_history: list = []

    async def execute_with_retry(
        self,
        action: str,
        execute_fn,
        *args,
        **kwargs
    ) -> ToolResult:
        """
        Execute an action with intelligent retry logic

        Args:
            action: Action type name
            execute_fn: Async function to execute
            *args, **kwargs: Arguments to pass to execute_fn

        Returns:
            ToolResult from successful execution

        Raises:
            ToolError: If all retries exhausted
        """
        last_error = None

        for attempt in range(self._retry_strategy.max_retries + 1):
            start_time = time.time()

            try:
                result = await execute_fn(*args, **kwargs)

                # Record success
                duration_ms = (time.time() - start_time) * 1000
                self._performance_tracker.record_action(action, duration_ms, True)

                if attempt > 0:
                    logger.info(
                        f"Action '{action}' succeeded on attempt {attempt + 1}/{self._retry_strategy.max_retries + 1}"
                    )

                return result

            except Exception as e:
                last_error = e
                duration_ms = (time.time() - start_time) * 1000
                self._performance_tracker.record_action(action, duration_ms, False)

                if not self._retry_strategy.should_retry(attempt, e):
                    logger.error(f"Action '{action}' failed, not retryable: {e}")
                    raise

                if attempt < self._retry_strategy.max_retries:
                    delay = self._retry_strategy.get_delay(attempt)
                    self._performance_tracker.record_retry(action)

                    logger.warning(
                        f"Action '{action}' failed (attempt {attempt + 1}), "
                        f"retrying in {delay:.2f}s: {e}"
                    )

                    await asyncio.sleep(delay)

        # All retries exhausted
        logger.error(
            f"Action '{action}' failed after {self._retry_strategy.max_retries + 1} attempts"
        )
        raise ToolError(
            f"Action '{action}' failed after {self._retry_strategy.max_retries + 1} attempts. "
            f"Last error: {last_error}"
        )

    def validate_and_get_coordinates(
        self,
        coordinate: Optional[Tuple[int, int]] = None,
        action: str = "action"
    ):
        """Enhanced coordinate validation with better error messages"""
        validated = self._validator.validate(coordinate, action)
        return self.scale_coordinates(ScalingSource.API, validated[0], validated[1])

    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance metrics summary"""
        return self._performance_tracker.get_summary()

    def log_performance_summary(self):
        """Log performance summary to logger"""
        summary = self.get_performance_summary()
        logger.info(
            f"Computer Tool Performance: "
            f"{summary['total_actions']} actions, "
            f"{summary['success_rate']:.1%} success rate, "
            f"{summary['average_duration_ms']:.1f}ms avg, "
            f"{summary['total_retries']} retries"
        )


# Enhanced versions of each computer tool with the mixin
class EnhancedComputerTool20241022(EnhancedComputerToolMixin, ComputerTool20241022):
    """Enhanced version of ComputerTool20241022 with retry and performance tracking"""
    pass


class EnhancedComputerTool20250124(EnhancedComputerToolMixin, ComputerTool20250124):
    """Enhanced version of ComputerTool20250124 with retry and performance tracking"""
    pass


class EnhancedComputerTool20251124(EnhancedComputerToolMixin, ComputerTool20251124):
    """Enhanced version of ComputerTool20251124 with retry and performance tracking"""
    pass


# Export enhanced tools
__all__ = [
    'EnhancedComputerTool20241022',
    'EnhancedComputerTool20250124',
    'EnhancedComputerTool20251124',
    'PerformanceTracker',
    'EnhancedCoordinateValidator',
    'RetryStrategy',
]
