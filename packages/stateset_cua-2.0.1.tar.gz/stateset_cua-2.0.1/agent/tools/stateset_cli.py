"""
StateSet CLI Tool.

This custom tool exposes the StateSet Node CLI (`@stateset-cli`) to the agent
as a first-class tool. It prefers a globally installed `stateset-cli` binary
and falls back to `npx @stateset-cli` when available.

The tool is intentionally conservative about safety:
- It runs without a shell via `create_subprocess_exec`.
- It treats commands as non-read-only unless explicitly marked.
"""

from __future__ import annotations

import asyncio
import json
import os
import shlex
import shutil
from typing import Any, Literal, Sequence

from anthropic.types.beta import BetaToolUnionParam

from .base import BaseAnthropicTool, ToolError, ToolResult


DEFAULT_TIMEOUT_SECONDS = 60.0


class StateSetCLITool(BaseAnthropicTool):
    """Run StateSet CLI commands (`stateset-cli`)."""

    name: Literal["stateset_cli"] = "stateset_cli"
    api_type: Literal["custom"] = "custom"

    def to_params(self) -> BetaToolUnionParam:
        return {
            "name": self.name,
            "type": self.api_type,
            "description": (
                "Run StateSet project/API commands using the Node CLI package "
                "`@stateset-cli`. Use this for listing, creating, or updating "
                "StateSet resources when a CLI workflow is faster than GUI automation."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "subcommand": {
                        "type": "string",
                        "description": "CLI subcommand to run, e.g. 'projects list' or 'rules apply'.",
                    },
                    "args": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Additional flags/args (e.g., ['--json']).",
                    },
                    "json_output": {
                        "type": "boolean",
                        "description": "If true, try to parse stdout as JSON and pretty-print it.",
                        "default": False,
                    },
                    "read_only": {
                        "type": "boolean",
                        "description": (
                            "Set true only for commands that do not modify StateSet state "
                            "(list/get/show). This enables safe parallelization/caching."
                        ),
                        "default": True,
                    },
                    "timeout_seconds": {
                        "type": "number",
                        "description": "Abort the command if it exceeds this timeout.",
                        "default": DEFAULT_TIMEOUT_SECONDS,
                    },
                },
                "required": ["subcommand"],
            },
        }

    async def __call__(
        self,
        *,
        subcommand: str,
        args: Sequence[str] | None = None,
        json_output: bool = False,
        read_only: bool = True,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        **kwargs: Any,
    ) -> ToolResult:
        if not isinstance(subcommand, str) or not subcommand.strip():
            raise ToolError("subcommand must be a non-empty string")

        argv = self._build_argv(subcommand, list(args) if args else [])
        if argv is None:
            return ToolResult(
                error=(
                    "stateset-cli is not installed. Install with "
                    "`npm install -g @stateset-cli` or use `npx @stateset-cli ...`."
                )
            )

        try:
            proc = await asyncio.create_subprocess_exec(
                *argv,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=os.environ.copy(),
            )

            try:
                stdout_b, stderr_b = await asyncio.wait_for(
                    proc.communicate(), timeout=timeout_seconds
                )
            except asyncio.TimeoutError:
                proc.kill()
                raise ToolError(
                    f"stateset-cli command timed out after {timeout_seconds} seconds"
                )

            stdout = (stdout_b or b"").decode(errors="replace").strip()
            stderr = (stderr_b or b"").decode(errors="replace").strip()

            if proc.returncode not in (0, None):
                return ToolResult(
                    error=stderr or stdout or f"stateset-cli exited with code {proc.returncode}"
                )

            if json_output:
                parsed = self._maybe_parse_json(stdout)
                if parsed is not None:
                    return ToolResult(output=json.dumps(parsed, indent=2))

            return ToolResult(output=stdout or "stateset-cli command completed")

        except FileNotFoundError:
            return ToolResult(error="stateset-cli binary not found on PATH")
        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"stateset-cli error: {str(e)}") from e

    @staticmethod
    def _build_argv(subcommand: str, extra_args: list[str]) -> list[str] | None:
        """Build argv for either global binary or npx fallback."""

        binary = shutil.which("stateset-cli")
        if binary:
            return [binary, *shlex.split(subcommand), *extra_args]

        npx = shutil.which("npx")
        if npx:
            return [npx, "--yes", "@stateset-cli", *shlex.split(subcommand), *extra_args]

        return None

    @staticmethod
    def _maybe_parse_json(output: str) -> Any | None:
        try:
            return json.loads(output)
        except Exception:
            return None

