"""
Core type definitions for the agent system.

Extracted from main.py to provide shared types without circular imports.
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Literal, NamedTuple, Optional, Sequence, Set, cast

from agent.tools import ToolVersion

ToolSearchVariant = Literal["regex", "bm25"]
EffortLevel = Literal["low", "medium", "high"]


class AgentType(Enum):
    """Available agent types"""
    SOCIAL_MEDIA = auto()
    AUTO_CLOSE = auto()
    ONBOARDING = auto()


@dataclass
class AgentConfig:
    """Configuration for each agent type"""
    org_id: str
    agent_id: str
    description: str
    capabilities: List[str]
    stripe_customer_id: str


@dataclass
class RuntimeOptions:
    """Runtime configuration selected via CLI."""
    instruction: str
    tool_version: ToolVersion
    agent_types: Optional[List[str]] = None
    tool_search_variant: Optional[ToolSearchVariant] = None
    tool_search_defer: tuple[str, ...] = tuple()
    effort_level: Optional[EffortLevel] = None


class TaskStatus(NamedTuple):
    """Result type for agent task status"""
    completed: bool
    tokens_used: int
    details: str
