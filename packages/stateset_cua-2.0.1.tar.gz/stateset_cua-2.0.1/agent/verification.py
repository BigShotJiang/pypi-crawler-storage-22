"""
Visual Verification System for StateSet Computer Use Agent.
Verifies that actions actually worked through screenshot comparison.
"""

import io
import base64
import logging
import hashlib
from typing import Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger('agent.verification')

try:
    from PIL import Image
    import imagehash
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    logger.warning("PIL/imagehash not available - visual verification will use hash comparison only")

from agent.tools.base import ToolResult


@dataclass
class VerificationResult:
    """Result of action verification"""
    success: bool
    confidence: float
    reason: str
    visual_changed: bool
    similarity_score: float


class VisualVerifier:
    """
    Verify actions succeeded through visual confirmation.

    Uses two-tier verification:
    1. Image similarity (fast, catches obvious failures)
    2. Hash comparison (fallback if PIL unavailable)

    Note: Many valid actions don't produce visible changes:
    - Clicking on already-focused elements
    - Clicking on empty/blank areas
    - Key presses that don't change screen state
    - Actions with delayed visual feedback

    The similarity threshold is set conservatively to avoid false negatives.
    """

    def __init__(self, similarity_threshold: float = 0.95):
        # Higher threshold (0.95) means only flag as failed if screens are nearly identical
        # This reduces false positives for actions that have subtle visual changes
        self.similarity_threshold = similarity_threshold
        self.verification_history = []
    
    def verify_visual_change(
        self,
        screenshot_before: str,
        screenshot_after: str,
        action_description: str,
        expected_change: str = "visual change"
    ) -> VerificationResult:
        """
        Verify that a visual change occurred after an action.
        
        Args:
            screenshot_before: Base64 encoded screenshot before action
            screenshot_after: Base64 encoded screenshot after action
            action_description: Description of action performed
            expected_change: What change was expected
        
        Returns:
            VerificationResult with success status and details
        """
        
        # Calculate similarity
        similarity = self._calculate_similarity(screenshot_before, screenshot_after)
        
        # High similarity = no change = action likely failed
        if similarity > self.similarity_threshold:
            result = VerificationResult(
                success=False,
                confidence=1.0 - similarity,
                reason=f"No visual change detected (similarity: {similarity:.1%})",
                visual_changed=False,
                similarity_score=similarity
            )
            
            logger.warning(
                f"⚠️  Verification failed: {action_description} - No visual change "
                f"(similarity: {similarity:.1%})"
            )
        else:
            result = VerificationResult(
                success=True,
                confidence=1.0 - similarity,
                reason=f"Visual change detected as expected",
                visual_changed=True,
                similarity_score=similarity
            )
            
            logger.info(
                f"✅ Verification passed: {action_description} - Visual change confirmed "
                f"(similarity: {similarity:.1%})"
            )
        
        # Record for history
        self.verification_history.append({
            'action': action_description,
            'expected': expected_change,
            'result': result,
            'timestamp': __import__('time').time()
        })
        
        return result
    
    def _calculate_similarity(self, img1_b64: str, img2_b64: str) -> float:
        """
        Calculate similarity between two base64 screenshots.
        
        Returns:
            Similarity score (0.0 = completely different, 1.0 = identical)
        """
        
        if PIL_AVAILABLE:
            # Use perceptual hashing for better comparison
            try:
                img1_bytes = base64.b64decode(img1_b64)
                img2_bytes = base64.b64decode(img2_b64)
                
                img1 = Image.open(io.BytesIO(img1_bytes))
                img2 = Image.open(io.BytesIO(img2_bytes))
                
                hash1 = imagehash.average_hash(img1)
                hash2 = imagehash.average_hash(img2)
                
                # Calculate similarity from hamming distance
                diff = hash1 - hash2  # Hamming distance
                max_diff = 64  # Maximum possible difference for 8x8 hash
                similarity = 1 - (diff / max_diff)
                
                return similarity
            
            except Exception as e:
                logger.warning(f"PIL comparison failed, falling back to hash: {e}")
                # Fall through to hash comparison
        
        # Fallback: Simple hash comparison
        hash1 = hashlib.md5(img1_b64.encode()).hexdigest()
        hash2 = hashlib.md5(img2_b64.encode()).hexdigest()
        
        # Binary: either identical (1.0) or different (0.0)
        return 1.0 if hash1 == hash2 else 0.0
    
    def get_recent_failures(self, count: int = 5) -> list:
        """Get recent verification failures"""
        failures = [
            v for v in self.verification_history
            if not v['result'].success
        ]
        return failures[-count:]
    
    def get_success_rate(self) -> float:
        """Get overall verification success rate"""
        if not self.verification_history:
            return 0.0
        
        successes = sum(
            1 for v in self.verification_history
            if v['result'].success
        )
        return successes / len(self.verification_history)


class ActionVerifier:
    """
    High-level action verification with retry logic.
    
    Wraps VisualVerifier with retry and recovery logic.
    """
    
    def __init__(self, max_retries: int = 3):
        self.visual_verifier = VisualVerifier()
        self.max_retries = max_retries
    
    async def execute_and_verify(
        self,
        action_func,
        action_description: str,
        expected_outcome: str,
        screenshot_func
    ) -> Dict[str, Any]:
        """
        Execute action and verify it worked, with retry logic.
        
        Args:
            action_func: Async function that performs the action
            action_description: Human-readable description
            expected_outcome: What should change
            screenshot_func: Async function to take screenshot
        
        Returns:
            {
                'success': bool,
                'attempts': int,
                'verification': VerificationResult,
                'final_screenshot': base64 string
            }
        """
        
        action_result: ToolResult | None = None

        for attempt in range(self.max_retries):
            # Take before screenshot
            before = await screenshot_func()
            before_screenshot = before.base64_image if hasattr(before, 'base64_image') else before
            
            # Perform action
            logger.info(f"🎬 Executing: {action_description} (attempt {attempt + 1}/{self.max_retries})")
            try:
                raw_result = await action_func()
                action_result = self._ensure_tool_result(raw_result)
            except Exception as exc:  # Capture unexpected tool errors
                logger.error(
                    f"Tool action raised error during verification: {exc}",
                    exc_info=True,
                )
                action_result = ToolResult(error=str(exc))
            
            # Take after screenshot
            if action_result and action_result.base64_image:
                after_screenshot = action_result.base64_image
            else:
                after = await screenshot_func()
                after_screenshot = after.base64_image if hasattr(after, 'base64_image') else after
            
            # Verify visual change
            verification = self.visual_verifier.verify_visual_change(
                screenshot_before=before_screenshot,
                screenshot_after=after_screenshot,
                action_description=action_description,
                expected_change=expected_outcome
            )
            
            if verification.success:
                return {
                    'success': True,
                    'attempts': attempt + 1,
                    'verification': verification,
                    'final_screenshot': after_screenshot,
                    'action_result': action_result
                }
            else:
                if attempt < self.max_retries - 1:
                    logger.warning(
                        f"⚠️  Action verification failed, retrying... "
                        f"({verification.reason})"
                    )
                    # Wait a moment before retry (optimized from 1.0s)
                    await __import__('asyncio').sleep(0.3)
        
        # All retries failed
        logger.error(
            f"❌ Action failed after {self.max_retries} attempts: {action_description}"
        )
        
        return {
            'success': False,
            'attempts': self.max_retries,
            'verification': verification,
            'final_screenshot': after_screenshot,
            'action_result': action_result
        }
    
    def get_verification_stats(self) -> Dict[str, Any]:
        """Get verification statistics"""
        return {
            'total_verifications': len(self.visual_verifier.verification_history),
            'success_rate': self.visual_verifier.get_success_rate(),
            'recent_failures': len(self.visual_verifier.get_recent_failures())
        }

    @staticmethod
    def _ensure_tool_result(result: Any) -> ToolResult:
        if isinstance(result, ToolResult):
            return result
        if isinstance(result, dict):
            return ToolResult(
                output=result.get('output'),
                error=result.get('error'),
                base64_image=result.get('base64_image'),
                system=result.get('system'),
            )
        return ToolResult(output=str(result))


# Global verifier instance
_global_verifier: Optional[ActionVerifier] = None


def get_verifier(max_retries: int = 3) -> ActionVerifier:
    """Get or create global verifier instance"""
    global _global_verifier
    
    if _global_verifier is None:
        _global_verifier = ActionVerifier(max_retries=max_retries)
    
    return _global_verifier 