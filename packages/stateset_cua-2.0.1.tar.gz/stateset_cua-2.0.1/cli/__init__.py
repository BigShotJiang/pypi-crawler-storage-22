"""
StateSet Agent CLI - Command-line interface for the StateSet Computer Use Agent.

Usage:
    stateset-cua run "your task instruction"
    stateset-cua run --agent auto-close "close resolved tickets"
    stateset-cua agents list
    stateset-cua config show
    stateset-cua chat
    stateset-cua doctor
"""

from cli._version import __version__


def main() -> None:
    """Entry point for ``stateset-cua`` and ``stateset-agent`` console scripts."""
    import shlex
    import sys

    from cli._config import get_config

    args = sys.argv[1:]

    # Expand aliases before Typer sees the arguments
    if args:
        try:
            cfg = get_config()
            alias_cmd = cfg.get_alias(args[0])
            if alias_cmd:
                expanded = shlex.split(alias_cmd)
                sys.argv = [sys.argv[0]] + expanded + args[1:]
        except Exception:
            pass  # Config not available yet, skip alias expansion

    # Import triggers command registration in cli/commands/__init__.py
    from cli.commands import app  # noqa: F401

    app()


__all__ = ["main", "__version__"]
