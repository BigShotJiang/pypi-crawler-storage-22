"""Allow ``python -m cli`` to work."""
from cli import main

main()
