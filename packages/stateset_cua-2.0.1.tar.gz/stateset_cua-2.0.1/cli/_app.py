"""Root Typer application and global callback."""

from __future__ import annotations

import typer

from cli._version import __version__

app = typer.Typer(
    name="stateset-cua",
    help="StateSet Computer Use Agent - AI automation platform powered by Claude Opus 4.6",
    no_args_is_help=True,
    rich_markup_mode="rich",
    pretty_exceptions_enable=True,
    pretty_exceptions_show_locals=False,
    invoke_without_command=True,
)


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-v", help="Show version and exit", is_eager=True,
    ),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress banner"),
    json_output: bool = typer.Option(False, "--json", help="JSON output mode"),
    completions: str = typer.Option(
        None, "--completions", help="Generate shell completions (bash/zsh/fish)",
    ),
) -> None:
    """StateSet Computer Use Agent - AI automation for complex tasks."""
    # Handle --version
    if version:
        typer.echo(f"stateset-cua {__version__}")
        raise typer.Exit()

    # Handle --completions
    if completions:
        try:
            from cli.completions import print_completion
            print_completion(completions)
        except ImportError:
            typer.echo(f"Completions for '{completions}' not available")
        raise typer.Exit()

    # Initialize console and state
    from cli._state import AppState
    from cli._console import init_console, print_banner

    state = AppState(json_mode=json_output, quiet=quiet)
    ctx.ensure_object(dict)
    ctx.obj = state
    init_console(state)

    # Print banner (unless suppressed or in JSON mode)
    if (
        not quiet
        and not json_output
        and ctx.invoked_subcommand not in ("version", None)
    ):
        print_banner()
