"""Persistent configuration management (~/.stateset/)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional


def get_state_dir() -> Path:
    """Return (and create) the persistent state directory."""
    d = Path.home() / ".stateset"
    d.mkdir(parents=True, exist_ok=True)
    return d


class ConfigManager:
    """Read/write CLI configuration from ``~/.stateset/config.yaml``."""

    DEFAULT_CONFIG: Dict[str, Any] = {
        "default_agent": None,
        "default_effort": "medium",
        "tool_version": "computer_use_20251124",
        "quiet": False,
        "json_output": False,
        "aliases": {},
        "mcp_servers": {},
    }

    def __init__(self) -> None:
        self.config_file = get_state_dir() / "config.yaml"
        self._config: Optional[Dict[str, Any]] = None

    # -- load / save -----------------------------------------------------------

    def _load(self) -> Dict[str, Any]:
        if self._config is not None:
            return self._config

        config = self.DEFAULT_CONFIG.copy()

        if self.config_file.exists():
            try:
                import yaml
                with open(self.config_file) as f:
                    file_config = yaml.safe_load(f) or {}
                config.update(file_config)
            except ImportError:
                json_file = self.config_file.with_suffix(".json")
                if json_file.exists():
                    try:
                        config.update(json.loads(json_file.read_text()))
                    except (json.JSONDecodeError, IOError):
                        pass
            except Exception:
                pass

        self._config = config
        return config

    def _save(self, config: Dict[str, Any]) -> None:
        try:
            import yaml
            with open(self.config_file, "w") as f:
                yaml.dump(config, f, default_flow_style=False)
        except ImportError:
            json_file = self.config_file.with_suffix(".json")
            json_file.write_text(json.dumps(config, indent=2))
        self._config = config

    # -- public API ------------------------------------------------------------

    def get(self, key: str, default: Any = None) -> Any:
        return self._load().get(key, default)

    def set(self, key: str, value: Any) -> None:
        config = self._load()
        config[key] = value
        self._save(config)

    # -- alias helpers ---------------------------------------------------------

    def get_alias(self, name: str) -> Optional[str]:
        return self.get("aliases", {}).get(name)

    def set_alias(self, name: str, command: str) -> None:
        aliases = self.get("aliases", {})
        aliases[name] = command
        self.set("aliases", aliases)

    def remove_alias(self, name: str) -> bool:
        aliases = self.get("aliases", {})
        if name in aliases:
            del aliases[name]
            self.set("aliases", aliases)
            return True
        return False

    def list_aliases(self) -> Dict[str, str]:
        return self.get("aliases", {})


# -- singleton -----------------------------------------------------------------

_config_manager: Optional[ConfigManager] = None


def get_config() -> ConfigManager:
    """Get the global ConfigManager singleton."""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager
