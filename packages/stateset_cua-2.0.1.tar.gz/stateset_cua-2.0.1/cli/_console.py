"""Rich Console singleton, theme, and display helpers."""

from __future__ import annotations

from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.theme import Theme

from cli._state import AppState
from cli._version import __version__

# StateSet brand theme
STATESET_THEME = Theme({
    "info": "cyan",
    "success": "green",
    "warning": "yellow",
    "error": "red bold",
    "header": "bold cyan",
    "dim": "dim",
    "agent.name": "cyan bold",
    "tool.name": "yellow",
    "key": "bold",
    "value": "dim",
})

LOGO = r"""   _____ _        _       _____      _
  / ____| |      | |     / ____|    | |
 | (___ | |_ __ _| |_ ___| (___   ___| |_
  \___ \| __/ _` | __/ _ \\___ \ / _ \ __|
  ____) | || (_| | ||  __/____) |  __/ |_
 |_____/ \__\__,_|\__\___|_____/ \___|\__|"""

_console: Optional[Console] = None
_state: Optional[AppState] = None


def init_console(state: AppState) -> Console:
    """Initialize the global console from AppState."""
    global _console, _state
    _state = state
    if state.json_mode:
        _console = Console(no_color=True, markup=False)
    else:
        _console = Console(theme=STATESET_THEME)
    state.console = _console
    return _console


def get_console() -> Console:
    """Get the global Rich console (creates one if needed)."""
    if _console is None:
        return Console(theme=STATESET_THEME)
    return _console


def is_json_mode() -> bool:
    """Check if JSON output mode is active."""
    return _state.json_mode if _state else False


def print_banner() -> None:
    """Print the StateSet CLI banner."""
    console = get_console()
    if is_json_mode():
        return
    console.print(
        f"[header]StateSet[/header] [info]Agent[/info] [dim]v{__version__}[/dim]"
    )
    console.print("[dim]AI automation powered by Claude Opus 4.6[/dim]")
    console.print()


def print_logo() -> None:
    """Print the full ASCII logo."""
    console = get_console()
    if is_json_mode():
        return
    console.print(LOGO, style="cyan")
    console.print()
    console.print(f"  [bold]Computer Use Agent[/bold] [dim]v{__version__}[/dim]")
    console.print("  [dim]AI automation powered by Claude Opus 4.6[/dim]")
    console.print()
