"""Shared constants: agent types, descriptions, MCP presets."""

from __future__ import annotations

from typing import Dict, List

# CLI agent name -> internal agent name
AGENT_TYPE_MAP: Dict[str, str] = {
    "auto-close": "AUTO_CLOSE",
    "social-media": "SOCIAL_MEDIA",
    "onboarding": "ONBOARDING",
    "linkedin": "LINKEDIN_MESSENGER",
    "slack": "SLACK_SUPPORT",
    "shopify": "SHOPIFY",
    "agentic": "STATESET_AGENTIC",
}

AGENT_DESCRIPTIONS: Dict[str, Dict[str, str]] = {
    "auto-close": {
        "description": "Automatically close resolved support tickets",
        "capabilities": "ticket_closing, selecting_contact_reason",
    },
    "social-media": {
        "description": "Monitor and moderate social media content",
        "capabilities": "hiding_comments, content_moderation",
    },
    "onboarding": {
        "description": "Set up new users and configure accounts",
        "capabilities": "user_setup, create_rules, create_attributes",
    },
    "linkedin": {
        "description": "LinkedIn messaging and connection management",
        "capabilities": "linkedin_messaging, connection_requests",
    },
    "slack": {
        "description": "Slack support automation and messaging",
        "capabilities": "slack_messaging, channel_management",
    },
    "shopify": {
        "description": "E-commerce management and order processing",
        "capabilities": "shopify_tasks, order_management",
    },
    "agentic": {
        "description": "General-purpose AI agent for any task",
        "capabilities": "general_tasks, web_browsing, coding",
    },
}

TOOL_VERSIONS: List[str] = [
    "computer_use_20251124",
    "computer_use_20250124",
    "computer_use_20241022",
    "cli_20250124",
]

MCP_PRESETS: List[str] = [
    "slack",
    "github",
    "postgres",
    "filesystem",
    "memory",
    "brave-search",
    "puppeteer",
    "sqlite",
]
