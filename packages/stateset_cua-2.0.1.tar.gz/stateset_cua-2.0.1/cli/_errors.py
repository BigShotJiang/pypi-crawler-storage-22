"""Error handling with Rich panels and contextual suggestions."""

from __future__ import annotations

from typing import Dict, List, Optional

from rich.panel import Panel

from cli._console import get_console, is_json_mode
from cli._output import output


SUGGESTIONS: Dict[str, List[str]] = {
    "ANTHROPIC_API_KEY": [
        "Set your API key: export ANTHROPIC_API_KEY='sk-ant-...'",
        "Or add it to your .env file",
        "Get an API key at: https://console.anthropic.com/",
    ],
    "DISPLAY": [
        "Start Xvfb: Xvfb :1 -screen 0 1920x1080x24 &",
        "Set DISPLAY: export DISPLAY=:1",
        "Or use --cli mode for non-GUI tasks",
    ],
    "connection": [
        "Check your internet connection",
        "Verify API endpoint is accessible",
        "Try again in a few moments",
    ],
    "rate_limit": [
        "You've hit the API rate limit",
        "Wait a moment and try again",
        "Consider using --effort low for lighter workloads",
    ],
    "timeout": [
        "The operation timed out",
        "Try breaking the task into smaller steps",
        "Check if the target application is responsive",
    ],
    "permission": [
        "Check file/directory permissions",
        "Run with appropriate privileges if needed",
        "Verify the path exists and is accessible",
    ],
}


def get_suggestions(error_msg: str) -> List[str]:
    """Return up to 3 contextual suggestions for an error message."""
    error_lower = error_msg.lower()
    result: List[str] = []
    for key, suggs in SUGGESTIONS.items():
        if key.lower() in error_lower:
            result.extend(suggs)
    return result[:3]


def print_error(error_msg: str, details: Optional[str] = None) -> None:
    """Print a Rich error panel with optional suggestions."""
    console = get_console()

    if is_json_mode():
        output({
            "error": error_msg,
            "details": details,
            "suggestions": get_suggestions(error_msg),
        })
        return

    body = f"[bold red]{error_msg}[/bold red]"
    if details:
        body += f"\n[dim]{details}[/dim]"

    suggestions = get_suggestions(error_msg)
    if suggestions:
        body += "\n\n[yellow]Suggestions:[/yellow]"
        for s in suggestions:
            body += f"\n  [dim]>[/dim] {s}"

    console.print(Panel(body, title="Error", border_style="red"))
