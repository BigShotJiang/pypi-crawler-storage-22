"""Persistent history and running-agent registry."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from cli._config import get_state_dir


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------

def _history_file() -> Path:
    return get_state_dir() / "history.json"


def load_history(limit: int = 50) -> List[Dict[str, Any]]:
    """Load the most recent *limit* history entries."""
    path = _history_file()
    if not path.exists():
        return []
    try:
        entries = json.loads(path.read_text())
        return entries[-limit:]
    except (json.JSONDecodeError, IOError):
        return []


def add_to_history(entry: Dict[str, Any]) -> None:
    """Append an entry to the history file."""
    entries = load_history(limit=500)
    entry.setdefault("timestamp", datetime.now().isoformat())
    entries.append(entry)
    # Keep last 500
    entries = entries[-500:]
    _history_file().write_text(json.dumps(entries, indent=2, default=str))


def clear_history() -> None:
    path = _history_file()
    if path.exists():
        path.write_text("[]")


# ---------------------------------------------------------------------------
# Running agents registry
# ---------------------------------------------------------------------------

def _running_file() -> Path:
    return get_state_dir() / "running_agents.json"


def load_running_agents() -> List[Dict[str, Any]]:
    path = _running_file()
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return []


def save_running_agents(agents: List[Dict[str, Any]]) -> None:
    _running_file().write_text(json.dumps(agents, indent=2, default=str))


def register_agent(agent_info: Dict[str, Any]) -> None:
    agents = load_running_agents()
    agent_info.setdefault("started_at", datetime.now().isoformat())
    agents.append(agent_info)
    save_running_agents(agents)


def unregister_agent(agent_id: str) -> bool:
    agents = load_running_agents()
    new = [a for a in agents if a.get("id") != agent_id]
    if len(new) < len(agents):
        save_running_agents(new)
        return True
    return False
