"""Import helper for resolving the top-level ``main`` module.

Setuptools editable installs (``pip install -e .``) map *packages* (``agent``,
``cli``) but do **not** map standalone ``py-modules`` such as ``main``.  This
module provides a fallback that locates ``main.py`` relative to the project
root so the CLI works regardless of how the package was installed.
"""

from __future__ import annotations


def get_agent_main():
    """Return the ``main()`` coroutine from the project's ``main.py``."""
    try:
        from main import main as agent_main

        return agent_main
    except ModuleNotFoundError:
        import importlib.util
        from pathlib import Path

        main_path = Path(__file__).resolve().parents[1] / "main.py"
        if not main_path.exists():
            raise ModuleNotFoundError(
                f"Cannot find main.py at {main_path}. "
                "Make sure you are running from the project directory or "
                "reinstall the package with: pip install -e ."
            )
        spec = importlib.util.spec_from_file_location("main", main_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
        return mod.main
