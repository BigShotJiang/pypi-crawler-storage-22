"""Output helpers: tables, formatting, dual-mode (JSON/human) output."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, List, Optional

from rich.table import Table

from cli._console import get_console, is_json_mode


# ---------------------------------------------------------------------------
# Dual-mode output
# ---------------------------------------------------------------------------

def output(data: Any, human_format: Optional[str] = None) -> None:
    """Emit *data* as JSON or human-readable text depending on mode."""
    console = get_console()
    if is_json_mode():
        if isinstance(data, str):
            console.print_json(json.dumps({"message": data}))
        else:
            console.print_json(json.dumps(data, default=str))
    elif human_format:
        console.print(human_format)
    else:
        console.print(data)


# ---------------------------------------------------------------------------
# Rich table builder
# ---------------------------------------------------------------------------

def rich_table(
    headers: List[str],
    rows: List[List[str]],
    title: Optional[str] = None,
) -> Optional[Table]:
    """Build and print a Rich table (or JSON array in JSON mode)."""
    console = get_console()
    if is_json_mode():
        data = [dict(zip(headers, row)) for row in rows]
        console.print_json(json.dumps(data, default=str))
        return None

    table = Table(title=title, show_header=True, header_style="bold")
    for h in headers:
        table.add_column(h)
    for row in rows:
        table.add_row(*[str(c) for c in row])
    console.print(table)
    return table


# ---------------------------------------------------------------------------
# Scalar formatters
# ---------------------------------------------------------------------------

def format_duration(seconds: float) -> str:
    """Format seconds as human-readable duration."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins}m {secs}s"
    else:
        hours = int(seconds // 3600)
        mins = int((seconds % 3600) // 60)
        return f"{hours}h {mins}m"


def format_tokens(tokens: int) -> str:
    """Format token count with K/M suffix."""
    if tokens < 1000:
        return str(tokens)
    elif tokens < 1_000_000:
        return f"{tokens / 1000:.1f}K"
    else:
        return f"{tokens / 1_000_000:.2f}M"


def format_cost(cost: float) -> str:
    """Format a dollar cost."""
    if cost < 0.01:
        return f"${cost:.4f}"
    elif cost < 1:
        return f"${cost:.3f}"
    else:
        return f"${cost:.2f}"


def format_relative_time(timestamp: str) -> str:
    """Format an ISO timestamp as relative time (e.g. '2 hours ago')."""
    try:
        dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
        diff = now - dt
        seconds = diff.total_seconds()

        if seconds < 60:
            return "just now"
        elif seconds < 3600:
            mins = int(seconds // 60)
            return f"{mins}m ago"
        elif seconds < 86400:
            hours = int(seconds // 3600)
            return f"{hours}h ago"
        else:
            days = int(seconds // 86400)
            return f"{days}d ago"
    except (ValueError, TypeError):
        return timestamp
