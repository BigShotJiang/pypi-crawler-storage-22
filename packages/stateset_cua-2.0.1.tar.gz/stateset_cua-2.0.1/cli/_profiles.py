"""Execution profile management."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from cli._config import get_state_dir


class ProfileManager:
    """Manages named execution profiles stored in ~/.stateset/profiles/."""

    def __init__(self) -> None:
        self.profiles_dir = get_state_dir() / "profiles"
        self.profiles_dir.mkdir(parents=True, exist_ok=True)

    def list_profiles(self) -> List[str]:
        return sorted(p.stem for p in self.profiles_dir.glob("*.json"))

    def get_profile(self, name: str) -> Optional[Dict[str, Any]]:
        path = self.profiles_dir / f"{name}.json"
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, IOError):
            return None

    def save_profile(self, name: str, profile: Dict[str, Any]) -> None:
        path = self.profiles_dir / f"{name}.json"
        path.write_text(json.dumps(profile, indent=2))

    def delete_profile(self, name: str) -> bool:
        path = self.profiles_dir / f"{name}.json"
        if path.exists():
            path.unlink()
            return True
        return False

    def get_active_profile(self) -> Optional[str]:
        marker = get_state_dir() / "active_profile"
        if marker.exists():
            return marker.read_text().strip()
        return None

    def set_active_profile(self, name: str) -> None:
        marker = get_state_dir() / "active_profile"
        marker.write_text(name)
