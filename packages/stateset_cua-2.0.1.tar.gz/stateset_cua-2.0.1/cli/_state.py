"""Global application state passed through Typer context."""

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class AppState:
    """State shared across all CLI commands via typer.Context.obj."""

    json_mode: bool = False
    quiet: bool = False
    console: Any = field(default=None, repr=False)  # Rich Console, typed as Any to avoid import
