"""Rich-powered streaming output for agent execution."""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

from rich.console import Group
from rich.live import Live
from rich.spinner import Spinner as RichSpinner
from rich.text import Text

from cli._console import get_console, is_json_mode
from cli._output import format_duration, format_tokens


class RichStreamingOutput:
    """Real-time agent execution display using ``rich.live.Live``."""

    def __init__(self, verbose: bool = False) -> None:
        self.verbose = verbose
        self.tool_count = 0
        self.token_count: Dict[str, int] = {"input": 0, "output": 0}
        self.start_time = time.time()
        self._live: Optional[Live] = None
        self._status_text = ""
        self._last_text = ""
        self._tool_log: List[str] = []

    # -- lifecycle -------------------------------------------------------------

    def start(self) -> None:
        if is_json_mode():
            return
        self._live = Live(
            self._build_display(),
            console=get_console(),
            refresh_per_second=4,
            transient=True,
        )
        self._live.start()

    def stop(self, success: bool = True) -> None:
        if self._live:
            self._live.stop()
        self._print_summary(success)

    # -- event handlers --------------------------------------------------------

    def on_text(self, text: str) -> None:
        if is_json_mode():
            print(json.dumps({"type": "text", "content": text}))
            return
        self._last_text = text
        self._refresh()

    def on_tool_use(self, tool_name: str, tool_input: Dict[str, Any]) -> None:
        self.tool_count += 1
        if is_json_mode():
            print(json.dumps({"type": "tool_use", "tool": tool_name, "input": tool_input}))
            return

        summary = _summarize_tool(tool_name, tool_input)
        icon = _TOOL_ICONS.get(tool_name, "[tool.name]#[/tool.name]")
        self._tool_log.append(f"  {icon} [tool.name]{tool_name}[/tool.name] {summary}")
        self._tool_log = self._tool_log[-8:]
        self._refresh()

    def on_tool_result(self, tool_name: str, result: str, success: bool = True) -> None:
        if is_json_mode():
            print(json.dumps({"type": "tool_result", "tool": tool_name, "success": success}))
        elif self.verbose:
            status = "[success]ok[/success]" if success else "[error]err[/error]"
            preview = result[:80].replace("\n", " ")
            self._tool_log.append(f"    {status} {preview}")
            self._tool_log = self._tool_log[-8:]
            self._refresh()

    def on_tokens(self, input_tokens: int, output_tokens: int) -> None:
        self.token_count["input"] += input_tokens
        self.token_count["output"] += output_tokens

    def on_status(self, message: str) -> None:
        self._status_text = message
        if is_json_mode():
            print(json.dumps({"type": "status", "message": message}))
        else:
            self._refresh()

    # -- internals -------------------------------------------------------------

    def _build_display(self) -> Any:
        parts: list[Any] = []
        if self._status_text:
            parts.append(Text.from_markup(f"  [info]> {self._status_text}[/info]"))
        for line in self._tool_log:
            parts.append(Text.from_markup(line))
        if self._last_text and self.verbose:
            parts.append(Text(f"\n  {self._last_text[:200]}", style="dim"))
        return Group(*parts) if parts else RichSpinner("dots", text="Working...")

    def _refresh(self) -> None:
        if self._live:
            self._live.update(self._build_display())

    def _print_summary(self, success: bool) -> None:
        console = get_console()
        elapsed = time.time() - self.start_time

        if is_json_mode():
            print(json.dumps({
                "type": "complete",
                "success": success,
                "tools_used": self.tool_count,
                "tokens": self.token_count,
                "elapsed_seconds": round(elapsed, 2),
            }))
            return

        icon = "[success]Completed[/success]" if success else "[error]Failed[/error]"
        console.print()
        console.print(f"  {icon} in {format_duration(elapsed)}")
        console.print(f"  Tools used: {self.tool_count}")
        console.print(
            f"  Tokens: {format_tokens(self.token_count['input'])} in / "
            f"{format_tokens(self.token_count['output'])} out"
        )


# ---------------------------------------------------------------------------
# Tool display helpers
# ---------------------------------------------------------------------------

_TOOL_ICONS: Dict[str, str] = {
    "computer": "[cyan]scr[/cyan]",
    "bash": "[green]$[/green]",
    "str_replace_editor": "[yellow]ed[/yellow]",
    "memory": "[magenta]mem[/magenta]",
    "spawn_subagent": "[blue]sub[/blue]",
    "ask_user": "[bold]?[/bold]",
}


def _summarize_tool(tool_name: str, tool_input: Dict[str, Any]) -> str:
    """Create a compact summary of a tool invocation."""
    if tool_name == "computer":
        action = tool_input.get("action", "")
        if action == "screenshot":
            return ""
        elif action in ("left_click", "right_click", "double_click"):
            coord = tool_input.get("coordinate", [0, 0])
            return f"{action} ({coord[0]}, {coord[1]})"
        elif action == "type":
            text = tool_input.get("text", "")
            return f'type "{text[:30]}{"..." if len(text) > 30 else ""}"'
        elif action == "key":
            return f"key {tool_input.get('text', '')}"
        return action
    elif tool_name == "bash":
        cmd = tool_input.get("command", "")
        return f'"{cmd[:50]}{"..." if len(cmd) > 50 else ""}"'
    elif tool_name == "str_replace_editor":
        cmd = tool_input.get("command", "view")
        path = tool_input.get("path", "")
        if "/" in path:
            path = "..." + path.rsplit("/", 1)[-1]
        return f"{cmd} {path}"
    elif tool_name == "spawn_subagent":
        return f"-> {tool_input.get('subagent_type', '')}"
    return ""
