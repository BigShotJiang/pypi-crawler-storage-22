"""Version and package metadata."""

__version__ = "2.0.1"
__package_name__ = "stateset-cua"
__repo_url__ = "https://github.com/stateset/stateset-computer-use-agent"
