"""Register all CLI commands on the root Typer app."""

from cli._app import app

# ── Wave 1: Version & Agents ─────────────────────────────────────────────
from cli.commands.version import version_cmd
from cli.commands.agents import agents_app

app.command("version")(version_cmd)
app.add_typer(agents_app, name="agents")

# ── Wave 2: Core Execution ───────────────────────────────────────────────
from cli.commands.run import run
from cli.commands.chat import chat

app.command("run")(run)
app.command("chat")(chat)

# ── Wave 3: Configuration ────────────────────────────────────────────────
from cli.commands.config_cmd import config_app
from cli.commands.init_cmd import init_cmd
from cli.commands.doctor import doctor

app.add_typer(config_app, name="config")
app.command("init")(init_cmd)
app.command("doctor")(doctor)

# ── Wave 4: Monitoring ───────────────────────────────────────────────────
from cli.commands.monitor import status, stop, watch, tail
from cli.commands.logs import logs

app.command("status")(status)
app.command("stop")(stop)
app.command("watch")(watch)
app.command("tail")(tail)
app.command("logs")(logs)

# ── Wave 5: Events & Auth ────────────────────────────────────────────────
from cli.commands.events import events_app
from cli.commands.auth import login, whoami
from cli.commands.secrets import secrets_app

app.add_typer(events_app, name="events")
app.command("login")(login)
app.command("whoami")(whoami)
app.add_typer(secrets_app, name="secrets")

# ── Wave 6: Integrations ─────────────────────────────────────────────────
from cli.commands.mcp import mcp_app
from cli.commands.templates import templates_app
from cli.commands.schedule import schedule_app

app.add_typer(mcp_app, name="mcp")
app.add_typer(templates_app, name="templates")
app.add_typer(schedule_app, name="schedule")

# ── Wave 7: Analytics ────────────────────────────────────────────────────
from cli.commands.history import history
from cli.commands.metrics import metrics
from cli.commands.benchmark import benchmark
from cli.commands.profile import profile_app

app.command("history")(history)
app.command("metrics")(metrics)
app.command("benchmark")(benchmark)
app.add_typer(profile_app, name="profile")

# ── Wave 8: Data Management ──────────────────────────────────────────────
from cli.commands.export_cmd import export_cmd
from cli.commands.context import context_app
from cli.commands.workspace import workspace_app
from cli.commands.env import env_app

app.command("export")(export_cmd)
app.add_typer(context_app, name="context")
app.add_typer(workspace_app, name="workspace")
app.add_typer(env_app, name="env")

# ── Wave 9: System ───────────────────────────────────────────────────────
from cli.commands.cache import cache_app
from cli.commands.inspect_cmd import inspect_app
from cli.commands.audit import audit_app

app.add_typer(cache_app, name="cache")
app.add_typer(inspect_app, name="inspect")
app.add_typer(audit_app, name="audit")

# ── Wave 10: Customization ───────────────────────────────────────────────
from cli.commands.plugins import plugin_app
from cli.commands.theme import theme_app
from cli.commands.alias import alias_app
from cli.commands.wizard import wizard
from cli.commands.replay import replay

app.add_typer(plugin_app, name="plugin")
app.add_typer(theme_app, name="theme")
app.add_typer(alias_app, name="alias")
app.command("wizard")(wizard)
app.command("replay")(replay)

# ── Wave 11: External ────────────────────────────────────────────────────
from cli.commands.webhook import webhook_app
from cli.commands.notify import notify_app
from cli.commands.rollback import rollback_app
from cli.commands.sync import sync_app
from cli.commands.api import api_app

app.add_typer(webhook_app, name="webhook")
app.add_typer(notify_app, name="notify")
app.add_typer(rollback_app, name="rollback")
app.add_typer(sync_app, name="sync")
app.add_typer(api_app, name="api")

# ── Wave 12: Final ───────────────────────────────────────────────────────
from cli.commands.completion import completion_app
from cli.commands.upgrade import upgrade

app.add_typer(completion_app, name="completion")
app.command("upgrade")(upgrade)
