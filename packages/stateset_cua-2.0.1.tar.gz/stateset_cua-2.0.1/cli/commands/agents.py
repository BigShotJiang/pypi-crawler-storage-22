"""Agents command group."""

import typer

from cli._console import get_console, is_json_mode
from cli._constants import AGENT_DESCRIPTIONS, AGENT_TYPE_MAP
from cli._output import output, rich_table

agents_app = typer.Typer(name="agents", help="Manage agent types")


@agents_app.command("list")
def agents_list() -> None:
    """List all available agent types."""
    headers = ["Name", "Internal", "Description", "Capabilities"]
    rows = []
    for cli_name, internal_name in AGENT_TYPE_MAP.items():
        info = AGENT_DESCRIPTIONS.get(cli_name, {})
        rows.append([
            cli_name,
            internal_name,
            info.get("description", ""),
            info.get("capabilities", ""),
        ])

    if is_json_mode():
        output([dict(zip(headers, r)) for r in rows])
    else:
        rich_table(headers, rows, title="Available Agents")
