"""Alias command group - manage command aliases."""

from __future__ import annotations

import typer

from cli._config import get_config
from cli._console import get_console, is_json_mode
from cli._output import output, rich_table

alias_app = typer.Typer(name="alias", help="Manage command aliases")


@alias_app.command("list")
def alias_list() -> None:
    """List all aliases."""
    cfg = get_config()
    aliases = cfg.list_aliases()

    if not aliases:
        output({"aliases": {}}, human_format="[dim]No aliases defined. Create one with: stateset-cua alias set <name> <command>[/dim]")
        return

    if is_json_mode():
        output(aliases)
        return

    headers = ["Alias", "Command"]
    rows = [[name, cmd] for name, cmd in sorted(aliases.items())]
    rich_table(headers, rows, title="Command Aliases")


@alias_app.command("set")
def alias_set(
    name: str = typer.Argument(..., help="Alias name"),
    command: str = typer.Argument(..., help="Command to alias"),
) -> None:
    """Create or update an alias."""
    cfg = get_config()
    cfg.set_alias(name, command)
    output({"alias": name, "command": command},
           human_format=f"[success]Alias '{name}' -> '{command}'[/success]")


@alias_app.command("remove")
def alias_remove(name: str = typer.Argument(..., help="Alias name to remove")) -> None:
    """Remove an alias."""
    cfg = get_config()
    if cfg.remove_alias(name):
        output({"removed": name}, human_format=f"[success]Alias '{name}' removed.[/success]")
    else:
        from cli._errors import print_error
        print_error(f"Alias '{name}' not found.")
        raise typer.Exit(1)
