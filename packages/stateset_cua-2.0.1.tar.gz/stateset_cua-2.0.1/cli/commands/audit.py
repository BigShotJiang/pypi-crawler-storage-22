"""Audit command group - audit logging and search."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import format_relative_time, output, rich_table

audit_app = typer.Typer(name="audit", help="Audit logging and search")


def _audit_file() -> Path:
    return get_state_dir() / "audit.json"


def _load_audit() -> list:
    path = _audit_file()
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return []


def _save_audit(entries: list) -> None:
    _audit_file().write_text(json.dumps(entries[-1000:], indent=2, default=str))


@audit_app.command("log")
def audit_log(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of entries"),
    level: Optional[str] = typer.Option(None, "--level", "-l", help="Filter by level: info, warn, error"),
) -> None:
    """Show audit log entries."""
    entries = _load_audit()

    if level:
        entries = [e for e in entries if e.get("level", "").lower() == level.lower()]

    entries = entries[-limit:]

    if is_json_mode():
        output(entries)
        return

    if not entries:
        get_console().print("[dim]No audit entries found.[/dim]")
        return

    headers = ["Time", "Level", "Action", "Details"]
    rows = []
    for e in reversed(entries):
        lvl = e.get("level", "info").upper()
        style = {"INFO": "info", "WARN": "warning", "ERROR": "error"}.get(lvl, "")
        rows.append([
            format_relative_time(e.get("timestamp", "")),
            f"[{style}]{lvl}[/{style}]" if style else lvl,
            e.get("action", ""),
            str(e.get("details", ""))[:60],
        ])
    rich_table(headers, rows, title="Audit Log")


@audit_app.command("export")
def audit_export(
    output_file: Path = typer.Option(Path("audit-export.json"), "--output", "-o", help="Output file"),
) -> None:
    """Export audit log to file."""
    entries = _load_audit()
    output_file.write_text(json.dumps(entries, indent=2, default=str))
    output({"exported": str(output_file), "count": len(entries)},
           human_format=f"[success]Exported {len(entries)} audit entries to {output_file}[/success]")


@audit_app.command("search")
def audit_search(
    query: str = typer.Argument(..., help="Search term"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max results"),
) -> None:
    """Search audit log entries."""
    entries = _load_audit()
    query_lower = query.lower()
    matches = [
        e for e in entries
        if query_lower in json.dumps(e).lower()
    ][-limit:]

    if is_json_mode():
        output(matches)
        return

    if not matches:
        get_console().print(f"[dim]No audit entries matching '{query}'.[/dim]")
        return

    headers = ["Time", "Level", "Action", "Details"]
    rows = []
    for e in matches:
        rows.append([
            format_relative_time(e.get("timestamp", "")),
            e.get("level", "info").upper(),
            e.get("action", ""),
            str(e.get("details", ""))[:60],
        ])
    rich_table(headers, rows, title=f"Audit Search: '{query}'")


@audit_app.command("stats")
def audit_stats() -> None:
    """Show audit log statistics."""
    entries = _load_audit()

    if not entries:
        output({"message": "No audit data."}, human_format="[dim]No audit data.[/dim]")
        return

    by_level = {}
    by_action = {}
    for e in entries:
        lvl = e.get("level", "info")
        by_level[lvl] = by_level.get(lvl, 0) + 1
        act = e.get("action", "unknown")
        by_action[act] = by_action.get(act, 0) + 1

    stats = {"total": len(entries), "by_level": by_level, "by_action": by_action}

    if is_json_mode():
        output(stats)
        return

    from rich.panel import Panel

    lines = [f"[bold]Total entries:[/bold] {len(entries)}"]
    lines.append("\n[bold]By Level:[/bold]")
    for lvl, count in sorted(by_level.items()):
        lines.append(f"  {lvl}: {count}")
    lines.append("\n[bold]By Action:[/bold]")
    for act, count in sorted(by_action.items(), key=lambda x: -x[1])[:10]:
        lines.append(f"  {act}: {count}")

    get_console().print(Panel("\n".join(lines), title="Audit Stats", border_style="cyan"))
