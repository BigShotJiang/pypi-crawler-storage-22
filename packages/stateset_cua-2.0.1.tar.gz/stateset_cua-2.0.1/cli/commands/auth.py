"""Auth commands: login, whoami (flat commands, not a sub-app)."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output


def _credentials_file() -> Path:
    """Return the path to the credentials file."""
    return get_state_dir() / "credentials"


def _load_credentials() -> dict:
    """Load stored credentials."""
    path = _credentials_file()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return {}


def _save_credentials(creds: dict) -> None:
    """Save credentials to disk with restricted permissions."""
    path = _credentials_file()
    path.write_text(json.dumps(creds, indent=2))
    # Restrict permissions to owner only
    try:
        path.chmod(0o600)
    except OSError:
        pass


def login(
    logout: bool = typer.Option(False, "--logout", help="Remove stored credentials"),
    check: bool = typer.Option(False, "--check", help="Check if credentials are valid"),
) -> None:
    """Store or check API credentials for StateSet and Anthropic."""
    console = get_console()

    if logout:
        path = _credentials_file()
        if path.exists():
            path.unlink()
            if is_json_mode():
                output({"message": "Credentials removed"})
            else:
                console.print("[success]Credentials removed.[/success]")
        else:
            if is_json_mode():
                output({"message": "No credentials stored"})
            else:
                console.print("[dim]No credentials stored.[/dim]")
        return

    if check:
        _check_credentials()
        return

    # Interactive login
    creds = _load_credentials()

    if is_json_mode():
        # In JSON mode, expect env vars or existing credentials
        api_key = os.environ.get("ANTHROPIC_API_KEY", creds.get("anthropic_api_key", ""))
        if not api_key:
            output({"error": "No API key found. Set ANTHROPIC_API_KEY environment variable."})
            raise typer.Exit(1)
        creds["anthropic_api_key"] = api_key
        _save_credentials(creds)
        output({"message": "Credentials saved from environment"})
        return

    console.print("[bold]StateSet Agent Login[/bold]")
    console.print()

    # Anthropic API key
    current_key = creds.get("anthropic_api_key", os.environ.get("ANTHROPIC_API_KEY", ""))
    masked_current = _mask_key(current_key) if current_key else "not set"
    console.print(f"  Current Anthropic API key: [dim]{masked_current}[/dim]")

    api_key = typer.prompt(
        "  Anthropic API key",
        default="",
        show_default=False,
    )

    if api_key:
        if not api_key.startswith("sk-ant-"):
            print_error(
                "Invalid API key format",
                details="Anthropic API keys should start with 'sk-ant-'.",
            )
            raise typer.Exit(1)
        creds["anthropic_api_key"] = api_key
    elif current_key:
        creds["anthropic_api_key"] = current_key

    # Optional: StateSet API key
    current_ss_key = creds.get("stateset_api_key", "")
    masked_ss = _mask_key(current_ss_key) if current_ss_key else "not set"
    console.print(f"\n  Current StateSet API key: [dim]{masked_ss}[/dim]")

    ss_key = typer.prompt(
        "  StateSet API key (optional, press Enter to skip)",
        default="",
        show_default=False,
    )
    if ss_key:
        creds["stateset_api_key"] = ss_key

    # Save
    _save_credentials(creds)
    console.print()
    console.print("[success]Credentials saved to ~/.stateset/credentials[/success]")
    console.print("[dim]File permissions set to owner-only (600).[/dim]")


def whoami() -> None:
    """Show the current authenticated user and credentials status."""
    console = get_console()
    creds = _load_credentials()

    # Check both stored and environment credentials
    anthropic_key = creds.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY")
    stateset_key = creds.get("stateset_api_key") or os.environ.get("STATESET_API_KEY")
    stripe_key = os.environ.get("STRIPE_API_KEY")

    info = {
        "anthropic_api_key": {
            "set": bool(anthropic_key),
            "source": _key_source("anthropic_api_key", creds),
            "masked": _mask_key(anthropic_key) if anthropic_key else None,
        },
        "stateset_api_key": {
            "set": bool(stateset_key),
            "source": _key_source("stateset_api_key", creds),
            "masked": _mask_key(stateset_key) if stateset_key else None,
        },
        "stripe_api_key": {
            "set": bool(stripe_key),
            "source": "environment" if stripe_key else None,
            "masked": _mask_key(stripe_key) if stripe_key else None,
        },
    }

    if is_json_mode():
        output(info)
        return

    from rich.panel import Panel

    lines = []
    for key_name, key_info in info.items():
        if key_info["set"]:
            source_tag = f" [dim]({key_info['source']})[/dim]"
            lines.append(
                f"  [success]ok[/success] [bold]{key_name}[/bold]: "
                f"{key_info['masked']}{source_tag}"
            )
        else:
            lines.append(
                f"  [error]--[/error] [bold]{key_name}[/bold]: [dim]not configured[/dim]"
            )

    body = "\n".join(lines)

    # Add credentials file info
    creds_path = _credentials_file()
    if creds_path.exists():
        body += f"\n\n[dim]Credentials file: {creds_path}[/dim]"
    else:
        body += "\n\n[dim]No credentials file (using environment variables only)[/dim]"

    console.print(Panel(body, title="Authentication Status", border_style="cyan"))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mask_key(key: Optional[str]) -> str:
    """Mask an API key, showing only first 8 and last 4 chars."""
    if not key:
        return ""
    if len(key) <= 12:
        return key[:4] + "..." + key[-2:]
    return key[:8] + "..." + key[-4:]


def _key_source(key_name: str, stored_creds: dict) -> str:
    """Determine the source of a credential."""
    env_map = {
        "anthropic_api_key": "ANTHROPIC_API_KEY",
        "stateset_api_key": "STATESET_API_KEY",
    }
    env_var = env_map.get(key_name, "")

    if key_name in stored_creds and stored_creds[key_name]:
        return "credentials file"
    elif env_var and os.environ.get(env_var):
        return "environment"
    return "not set"


def _check_credentials() -> None:
    """Validate that stored/environment credentials are functional."""
    console = get_console()
    creds = _load_credentials()

    api_key = creds.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY")

    if not api_key:
        if is_json_mode():
            output({"valid": False, "error": "No API key configured"})
        else:
            print_error(
                "No API key configured",
                details="Run 'stateset-cua login' or set ANTHROPIC_API_KEY.",
            )
        raise typer.Exit(1)

    # Basic format validation
    if not api_key.startswith("sk-ant-"):
        if is_json_mode():
            output({"valid": False, "error": "Invalid API key format"})
        else:
            print_error("Invalid API key format", details="Key should start with 'sk-ant-'.")
        raise typer.Exit(1)

    # Try a lightweight API connectivity check if the anthropic library is available
    try:
        import anthropic

        client = anthropic.Anthropic(api_key=api_key)
        # Use a minimal call to check validity
        client.models.list()

        if is_json_mode():
            output({"valid": True, "message": "API key is valid"})
        else:
            console.print("[success]API key is valid.[/success]")

    except ImportError:
        if is_json_mode():
            output({"valid": None, "message": "Format OK, cannot verify (anthropic SDK not installed)"})
        else:
            console.print(
                "[warning]API key format looks correct, but cannot verify "
                "(anthropic SDK not installed).[/warning]"
            )
    except Exception as exc:
        if is_json_mode():
            output({"valid": False, "error": str(exc)})
        else:
            print_error("API key validation failed", details=str(exc))
        raise typer.Exit(1)
