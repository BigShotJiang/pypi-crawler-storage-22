"""Benchmark command - run performance benchmarks."""

from __future__ import annotations

import subprocess
import time

import typer

from cli._console import get_console, is_json_mode
from cli._output import format_duration, output


def benchmark(
    ctx: typer.Context,
    iterations: int = typer.Option(3, "--iterations", "-n", help="Number of iterations"),
    skip_api: bool = typer.Option(False, "--skip-api", help="Skip API latency test"),
) -> None:
    """Run performance benchmarks (API latency, bash tool, memory)."""
    console = get_console()
    results = {}

    if not is_json_mode():
        console.print("[bold]Running benchmarks...[/bold]\n")

    # 1. Bash tool timing
    if not is_json_mode():
        console.print("  [dim]Bash tool timing...[/dim]")
    times = []
    for _ in range(iterations):
        start = time.perf_counter()
        subprocess.run(["echo", "benchmark"], capture_output=True, timeout=10)
        times.append(time.perf_counter() - start)
    results["bash_tool"] = {
        "avg_ms": round(sum(times) / len(times) * 1000, 2),
        "min_ms": round(min(times) * 1000, 2),
        "max_ms": round(max(times) * 1000, 2),
    }

    # 2. API latency
    if not skip_api:
        if not is_json_mode():
            console.print("  [dim]API latency...[/dim]")
        try:
            import httpx

            api_times = []
            for _ in range(iterations):
                start = time.perf_counter()
                try:
                    resp = httpx.get("https://api.anthropic.com/v1/models", timeout=10.0)
                    api_times.append(time.perf_counter() - start)
                except httpx.HTTPError:
                    api_times.append(time.perf_counter() - start)
            results["api_latency"] = {
                "avg_ms": round(sum(api_times) / len(api_times) * 1000, 2),
                "min_ms": round(min(api_times) * 1000, 2),
                "max_ms": round(max(api_times) * 1000, 2),
            }
        except ImportError:
            results["api_latency"] = {"error": "httpx not installed"}

    # 3. Memory usage
    if not is_json_mode():
        console.print("  [dim]Memory usage...[/dim]")
    try:
        import psutil

        proc = psutil.Process()
        mem = proc.memory_info()
        sys_mem = psutil.virtual_memory()
        results["memory"] = {
            "process_rss_mb": round(mem.rss / (1024 * 1024), 1),
            "process_vms_mb": round(mem.vms / (1024 * 1024), 1),
            "system_available_gb": round(sys_mem.available / (1024 ** 3), 1),
            "system_percent_used": sys_mem.percent,
        }
    except ImportError:
        results["memory"] = {"error": "psutil not installed"}

    # 4. File I/O
    if not is_json_mode():
        console.print("  [dim]File I/O...[/dim]")
    import tempfile
    io_times = []
    for _ in range(iterations):
        start = time.perf_counter()
        with tempfile.NamedTemporaryFile(mode="w", delete=True, suffix=".tmp") as f:
            f.write("x" * 10000)
            f.flush()
        io_times.append(time.perf_counter() - start)
    results["file_io"] = {
        "avg_ms": round(sum(io_times) / len(io_times) * 1000, 2),
        "min_ms": round(min(io_times) * 1000, 2),
        "max_ms": round(max(io_times) * 1000, 2),
    }

    if is_json_mode():
        output(results)
        return

    from rich.panel import Panel

    lines = []
    for name, data in results.items():
        title = name.replace("_", " ").title()
        if "error" in data:
            lines.append(f"[bold]{title}:[/bold] [error]{data['error']}[/error]")
        elif "avg_ms" in data:
            lines.append(
                f"[bold]{title}:[/bold] avg={data['avg_ms']}ms  "
                f"min={data['min_ms']}ms  max={data['max_ms']}ms"
            )
        else:
            parts = [f"{k}={v}" for k, v in data.items()]
            lines.append(f"[bold]{title}:[/bold] {', '.join(parts)}")

    console.print()
    console.print(Panel("\n".join(lines), title="Benchmark Results", border_style="cyan"))
