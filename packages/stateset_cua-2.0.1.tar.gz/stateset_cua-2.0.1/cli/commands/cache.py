"""Cache command group - manage agent cache."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table

cache_app = typer.Typer(name="cache", help="Manage agent cache")


def _cache_dir() -> Path:
    d = get_state_dir() / "cache"
    d.mkdir(parents=True, exist_ok=True)
    return d


@cache_app.command("stats")
def cache_stats() -> None:
    """Show cache statistics."""
    cache = _cache_dir()
    files = list(cache.rglob("*"))
    file_count = sum(1 for f in files if f.is_file())
    total_size = sum(f.stat().st_size for f in files if f.is_file())

    stats = {
        "path": str(cache),
        "files": file_count,
        "total_size_kb": round(total_size / 1024, 1),
        "subdirectories": sum(1 for f in files if f.is_dir()),
    }

    if is_json_mode():
        output(stats)
        return

    from rich.panel import Panel

    lines = [
        f"[bold]Path:[/bold] {stats['path']}",
        f"[bold]Files:[/bold] {stats['files']}",
        f"[bold]Size:[/bold] {stats['total_size_kb']} KB",
        f"[bold]Subdirectories:[/bold] {stats['subdirectories']}",
    ]
    get_console().print(Panel("\n".join(lines), title="Cache Stats", border_style="cyan"))


@cache_app.command("clear")
def cache_clear(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Clear the cache directory."""
    cache = _cache_dir()
    files = list(cache.rglob("*"))
    file_count = sum(1 for f in files if f.is_file())

    if file_count == 0:
        output({"message": "Cache is empty."}, human_format="[dim]Cache is already empty.[/dim]")
        return

    if not force:
        typer.confirm(f"Clear {file_count} cached files?", abort=True)

    shutil.rmtree(cache)
    cache.mkdir(parents=True, exist_ok=True)

    output({"cleared": file_count}, human_format=f"[success]Cleared {file_count} cached files.[/success]")


@cache_app.command("show")
def cache_show(
    limit: int = typer.Option(20, "--limit", "-n", help="Max entries"),
) -> None:
    """Show cached files."""
    cache = _cache_dir()
    files = sorted(
        (f for f in cache.rglob("*") if f.is_file()),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )[:limit]

    if not files:
        output({"files": []}, human_format="[dim]No cached files.[/dim]")
        return

    if is_json_mode():
        output([{"name": f.name, "size": f.stat().st_size, "path": str(f.relative_to(cache))} for f in files])
        return

    headers = ["File", "Size", "Path"]
    rows = [[f.name, f"{f.stat().st_size} B", str(f.relative_to(cache))] for f in files]
    rich_table(headers, rows, title="Cached Files")


@cache_app.command("config")
def cache_config() -> None:
    """Show cache configuration."""
    from cli._config import get_config

    cfg = get_config()
    cache_dir = _cache_dir()

    config = {
        "cache_dir": str(cache_dir),
        "max_screenshots": 5,
        "screenshot_dedup": True,
        "prompt_caching": True,
    }

    if is_json_mode():
        output(config)
        return

    from rich.panel import Panel

    lines = [f"[bold]{k}:[/bold] {v}" for k, v in config.items()]
    get_console().print(Panel("\n".join(lines), title="Cache Config", border_style="cyan"))
