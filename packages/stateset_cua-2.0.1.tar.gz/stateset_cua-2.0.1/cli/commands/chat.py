"""Interactive chat REPL command."""

from __future__ import annotations

import asyncio
import readline
import time
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode, print_logo
from cli._constants import AGENT_DESCRIPTIONS, AGENT_TYPE_MAP
from cli._errors import print_error
from cli._history import add_to_history
from cli._output import format_duration, rich_table


def chat(
    ctx: typer.Context,
    agent_type: Optional[str] = typer.Option(
        None, "--agent", "-a", help="Agent type to use",
    ),
    cli_mode: bool = typer.Option(False, "--cli", help="CLI-only mode (no GUI)"),
    effort: Optional[str] = typer.Option(
        None, "--effort", help="Effort level (low, medium, high)",
    ),
) -> None:
    """Start an interactive chat session with an agent."""
    console = get_console()

    tool_version = "cli_20250124" if cli_mode else "computer_use_20251124"
    agent_types = None
    agent_display = agent_type
    if agent_type:
        internal_name = AGENT_TYPE_MAP.get(agent_type)
        if internal_name:
            agent_types = [internal_name]

    # Welcome screen
    _print_welcome(console, agent_display, cli_mode)

    # Readline history
    history_file = get_state_dir() / "chat_history"
    try:
        readline.read_history_file(str(history_file))
    except FileNotFoundError:
        pass
    readline.set_history_length(1000)

    session_id = f"chat_{int(time.time())}"
    message_count = 0
    start_time = time.time()

    while True:
        try:
            # Build prompt (raw ANSI for readline compatibility)
            if agent_display:
                prompt_text = f"\033[2m[{agent_display}]\033[0m\033[92m> \033[0m"
            else:
                prompt_text = "\033[92m> \033[0m"

            user_input = input(prompt_text).strip()

            if not user_input:
                continue

            # Slash commands
            if user_input.startswith("/"):
                cmd = user_input.lower().split()[0]
                if cmd in ("/exit", "/quit", "/q"):
                    _print_goodbye(console, start_time, message_count)
                    break
                elif cmd == "/clear":
                    console.clear()
                    _print_welcome(console, agent_display, cli_mode)
                    message_count = 0
                    continue
                elif cmd == "/help":
                    _print_help(console)
                    continue
                elif cmd == "/status":
                    elapsed = time.time() - start_time
                    console.print(f"  [bold]Session:[/bold] {session_id}")
                    console.print(f"  [bold]Messages:[/bold] {message_count}")
                    console.print(f"  [bold]Duration:[/bold] {format_duration(elapsed)}")
                    console.print(f"  [bold]Agent:[/bold] {agent_display or 'auto'}")
                    console.print(f"  [bold]Mode:[/bold] {'CLI' if cli_mode else 'Computer Use'}")
                    continue
                elif cmd == "/agent":
                    rows = [
                        [name, info.get("description", "")]
                        for name, info in AGENT_DESCRIPTIONS.items()
                    ]
                    rich_table(["Name", "Description"], rows)
                    continue
                else:
                    console.print(f"  [warning]Unknown command: {cmd}. Type /help[/warning]")
                    continue

            # Legacy exit
            if user_input.lower() in ("exit", "quit"):
                _print_goodbye(console, start_time, message_count)
                break

            message_count += 1
            console.print()

            # Execute
            try:
                from cli._import import get_agent_main
                from agent.types import RuntimeOptions, EffortLevel

                agent_main = get_agent_main()
                from typing import cast

                options = RuntimeOptions(
                    instruction=user_input,
                    tool_version=tool_version,
                    agent_types=agent_types,
                    effort_level=cast(EffortLevel, effort) if effort else None,
                )

                with console.status("[info]Thinking...[/info]"):
                    asyncio.run(agent_main(options))

            except KeyboardInterrupt:
                console.print("\n  [warning]Task interrupted.[/warning]")
            except Exception as e:
                print_error(str(e))

            console.print()

        except KeyboardInterrupt:
            console.print("\n  [warning]Interrupted. Type /exit to quit.[/warning]")
        except EOFError:
            console.print("\n  [info]Goodbye![/info]")
            break

    # Save readline history
    try:
        readline.write_history_file(str(history_file))
    except IOError:
        pass

    add_to_history({
        "type": "chat_session",
        "session_id": session_id,
        "messages": message_count,
        "agent_type": agent_type or "auto",
        "status": "completed",
        "duration_seconds": round(time.time() - start_time, 2),
    })


def _print_welcome(console, agent_display, cli_mode) -> None:
    print_logo()
    mode = "CLI" if cli_mode else "Computer Use"
    console.print(f"  [bold]Interactive Chat[/bold] [dim]({mode} mode)[/dim]")
    if agent_display:
        console.print(f"  [dim]Agent: {agent_display}[/dim]")
    console.print("  [dim]Type /help for commands, /exit to quit[/dim]")
    console.print()


def _print_help(console) -> None:
    console.print("  [bold]Chat Commands:[/bold]")
    console.print("    [info]/help[/info]    Show this help")
    console.print("    [info]/status[/info]  Show session status")
    console.print("    [info]/agent[/info]   List available agents")
    console.print("    [info]/clear[/info]   Clear screen")
    console.print("    [info]/exit[/info]    End session")


def _print_goodbye(console, start_time, message_count) -> None:
    elapsed = time.time() - start_time
    console.print()
    console.print(f"  [info]Session ended[/info] - {message_count} messages in {format_duration(elapsed)}")
