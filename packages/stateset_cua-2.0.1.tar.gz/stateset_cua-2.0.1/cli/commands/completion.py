"""Completion command group - shell completion management."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output

completion_app = typer.Typer(name="completion", help="Shell completion management")

_SHELLS = ["bash", "zsh", "fish"]

_INSTALL_PATHS = {
    "bash": Path.home() / ".bash_completion.d" / "stateset-cua",
    "zsh": Path.home() / ".zfunc" / "_stateset-cua",
    "fish": Path.home() / ".config" / "fish" / "completions" / "stateset-cua.fish",
}


def _generate_completion(shell: str) -> str:
    """Generate completion script for a shell."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "cli._app", "--show-completion", shell],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout:
            return result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Fallback: generate a basic completion script
    if shell == "bash":
        return f'eval "$(_STATESET_CUA_COMPLETE=bash_source stateset-cua)"'
    elif shell == "zsh":
        return f'eval "$(_STATESET_CUA_COMPLETE=zsh_source stateset-cua)"'
    elif shell == "fish":
        return f'eval (env _STATESET_CUA_COMPLETE=fish_source stateset-cua)'
    return ""


@completion_app.command("install")
def completion_install(
    shell: str = typer.Argument(..., help=f"Shell type: {', '.join(_SHELLS)}"),
) -> None:
    """Install shell completions."""
    if shell not in _SHELLS:
        print_error(f"Unsupported shell: {shell}", details=f"Supported: {', '.join(_SHELLS)}")
        raise typer.Exit(1)

    script = _generate_completion(shell)
    if not script:
        print_error(f"Failed to generate completion for {shell}")
        raise typer.Exit(1)

    install_path = _INSTALL_PATHS[shell]
    install_path.parent.mkdir(parents=True, exist_ok=True)
    install_path.write_text(script)

    console = get_console()
    result = {"installed": str(install_path), "shell": shell}

    if is_json_mode():
        output(result)
        return

    console.print(f"[success]Completions installed to {install_path}[/success]")

    if shell == "bash":
        console.print("[dim]Add to ~/.bashrc: source ~/.bash_completion.d/stateset-cua[/dim]")
    elif shell == "zsh":
        console.print("[dim]Add to ~/.zshrc: fpath+=~/.zfunc; autoload -Uz compinit && compinit[/dim]")
    elif shell == "fish":
        console.print("[dim]Fish completions are loaded automatically.[/dim]")


@completion_app.command("show")
def completion_show(
    shell: str = typer.Argument(..., help=f"Shell type: {', '.join(_SHELLS)}"),
) -> None:
    """Show completion script for a shell."""
    if shell not in _SHELLS:
        print_error(f"Unsupported shell: {shell}")
        raise typer.Exit(1)

    script = _generate_completion(shell)

    if is_json_mode():
        output({"shell": shell, "script": script})
    else:
        console = get_console()
        from rich.syntax import Syntax
        console.print(Syntax(script, shell, theme="monokai"))


@completion_app.command("status")
def completion_status() -> None:
    """Show completion installation status."""
    results = []
    for shell, path in _INSTALL_PATHS.items():
        results.append({
            "shell": shell,
            "installed": path.exists(),
            "path": str(path),
        })

    if is_json_mode():
        output(results)
        return

    console = get_console()
    for r in results:
        icon = "[success]installed[/success]" if r["installed"] else "[dim]not installed[/dim]"
        console.print(f"  {r['shell']:6} {icon}  {r['path']}")
