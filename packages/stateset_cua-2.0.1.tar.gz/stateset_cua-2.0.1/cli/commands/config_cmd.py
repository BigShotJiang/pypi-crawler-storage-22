"""Config command group: show, check, env."""

from __future__ import annotations

import json
import os

import typer

from cli._config import get_config
from cli._console import get_console, is_json_mode
from cli._output import output, rich_table

config_app = typer.Typer(name="config", help="View and manage configuration")


@config_app.command("show")
def config_show() -> None:
    """Show current configuration."""
    console = get_console()
    cfg = get_config()
    data = cfg._load()

    if is_json_mode():
        output(data)
        return

    from rich.panel import Panel
    lines = []
    for k, v in sorted(data.items()):
        if isinstance(v, dict):
            lines.append(f"[bold]{k}:[/bold] ({len(v)} items)")
        else:
            lines.append(f"[bold]{k}:[/bold] {v}")
    console.print(Panel("\n".join(lines), title="Configuration", border_style="cyan"))


@config_app.command("check")
def config_check() -> None:
    """Validate environment configuration."""
    console = get_console()

    checks = [
        ("ANTHROPIC_API_KEY", os.environ.get("ANTHROPIC_API_KEY")),
        ("DISPLAY", os.environ.get("DISPLAY")),
        ("WORKSPACE_PATH", os.environ.get("WORKSPACE_PATH")),
    ]

    if is_json_mode():
        output([{"key": k, "set": bool(v), "value": v[:8] + "..." if v and len(v) > 8 else v} for k, v in checks])
        return

    for key, value in checks:
        if value:
            masked = value[:8] + "..." if len(value) > 8 else value
            console.print(f"  [success]ok[/success] {key} = {masked}")
        else:
            console.print(f"  [error]missing[/error] {key}")

    # Check optional
    optional = ["STRIPE_API_KEY", "AGENT_DATA_DIR", "METRICS_PORT"]
    console.print()
    for key in optional:
        value = os.environ.get(key)
        if value:
            console.print(f"  [success]ok[/success] {key} (optional)")
        else:
            console.print(f"  [dim]--[/dim] {key} [dim](optional, not set)[/dim]")


@config_app.command("env")
def config_env() -> None:
    """Show required environment variables."""
    console = get_console()

    env_vars = [
        ("ANTHROPIC_API_KEY", "Anthropic API key", True),
        ("DISPLAY", "X11 display (e.g. :1)", True),
        ("WORKSPACE_PATH", "Agent workspace directory", False),
        ("STRIPE_API_KEY", "Stripe billing key", False),
        ("AGENT_DATA_DIR", "Data directory for agent runtime", False),
        ("DASHBOARD_ADMIN_PASSWORD", "Dashboard login password", False),
    ]

    if is_json_mode():
        output([{"key": k, "description": d, "required": r, "set": bool(os.environ.get(k))} for k, d, r in env_vars])
        return

    headers = ["Variable", "Description", "Required", "Status"]
    rows = []
    for key, desc, required in env_vars:
        is_set = bool(os.environ.get(key))
        status = "[success]set[/success]" if is_set else ("[error]missing[/error]" if required else "[dim]not set[/dim]")
        req = "[bold]yes[/bold]" if required else "no"
        rows.append([key, desc, req, status])

    rich_table(headers, rows, title="Environment Variables")
