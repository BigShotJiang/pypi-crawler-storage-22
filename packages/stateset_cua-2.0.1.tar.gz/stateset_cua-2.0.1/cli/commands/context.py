"""Context command group - manage agent context/memory."""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import format_relative_time, output, rich_table

context_app = typer.Typer(name="context", help="Manage agent context and memory")


def _memories_dir() -> Path:
    base = os.environ.get("AGENT_DATA_DIR", str(get_state_dir()))
    d = Path(base) / "memories"
    d.mkdir(parents=True, exist_ok=True)
    return d


@context_app.command("list")
def context_list() -> None:
    """List all agent memory files."""
    mem_dir = _memories_dir()
    files = sorted(mem_dir.glob("*.json"))

    if not files:
        output({"memories": []}, human_format="[dim]No agent memories found.[/dim]")
        return

    if is_json_mode():
        output([{"name": f.stem, "size": f.stat().st_size, "path": str(f)} for f in files])
        return

    headers = ["Agent", "Size", "Modified"]
    rows = []
    for f in files:
        stat = f.stat()
        from datetime import datetime
        modified = datetime.fromtimestamp(stat.st_mtime).isoformat()
        rows.append([f.stem, f"{stat.st_size} B", format_relative_time(modified)])
    rich_table(headers, rows, title="Agent Memories")


@context_app.command("show")
def context_show(agent: str = typer.Argument(..., help="Agent ID or memory name")) -> None:
    """Show contents of an agent's memory."""
    mem_dir = _memories_dir()
    path = mem_dir / f"{agent}.json"

    if not path.exists():
        print_error(f"Memory not found for agent: {agent}")
        raise typer.Exit(1)

    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, IOError) as e:
        print_error(f"Could not read memory: {e}")
        raise typer.Exit(1)

    if is_json_mode():
        output(data)
        return

    from rich.panel import Panel
    from rich.syntax import Syntax

    console = get_console()
    formatted = json.dumps(data, indent=2)
    console.print(Panel(
        Syntax(formatted, "json", theme="monokai"),
        title=f"Memory: {agent}",
        border_style="cyan",
    ))


@context_app.command("clear")
def context_clear(
    agent: str = typer.Argument(None, help="Agent ID to clear (omit for all)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Clear agent memory/context."""
    mem_dir = _memories_dir()

    if agent:
        path = mem_dir / f"{agent}.json"
        if not path.exists():
            print_error(f"Memory not found for agent: {agent}")
            raise typer.Exit(1)
        if not force:
            typer.confirm(f"Clear memory for '{agent}'?", abort=True)
        path.unlink()
        output({"cleared": agent}, human_format=f"[success]Cleared memory for '{agent}'.[/success]")
    else:
        files = list(mem_dir.glob("*.json"))
        if not files:
            output({"message": "No memories to clear."}, human_format="[dim]No memories to clear.[/dim]")
            return
        if not force:
            typer.confirm(f"Clear all {len(files)} agent memories?", abort=True)
        for f in files:
            f.unlink()
        output({"cleared": len(files)}, human_format=f"[success]Cleared {len(files)} agent memories.[/success]")
