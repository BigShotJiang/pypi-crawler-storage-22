"""Doctor command - system diagnostics."""

from __future__ import annotations

import os
import shutil

import typer

from cli._console import get_console, is_json_mode
from cli._output import output


def doctor(ctx: typer.Context) -> None:
    """Run system diagnostics and environment health checks."""
    console = get_console()
    checks = []

    # 1. API key
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    checks.append({
        "name": "Anthropic API Key",
        "ok": bool(api_key and api_key.startswith("sk-ant-")),
        "detail": "Set and valid format" if api_key and api_key.startswith("sk-ant-") else "Missing or invalid format",
    })

    # 2. Display
    display = os.environ.get("DISPLAY", "")
    checks.append({
        "name": "X11 Display",
        "ok": bool(display),
        "detail": f"DISPLAY={display}" if display else "DISPLAY not set",
    })

    # 3. Required tools
    for tool in ["xdotool", "scrot", "xvfb-run"]:
        found = shutil.which(tool) is not None
        checks.append({
            "name": f"Tool: {tool}",
            "ok": found,
            "detail": "Installed" if found else "Not found",
        })

    # 4. Python packages
    for pkg_name, import_name in [("anthropic", "anthropic"), ("PIL", "PIL"), ("pyautogui", "pyautogui")]:
        try:
            __import__(import_name)
            checks.append({"name": f"Package: {pkg_name}", "ok": True, "detail": "Available"})
        except ImportError:
            checks.append({"name": f"Package: {pkg_name}", "ok": False, "detail": "Not installed"})
        except Exception as exc:
            # Some packages (e.g. pyautogui) raise non-ImportError on missing display
            checks.append({"name": f"Package: {pkg_name}", "ok": False, "detail": f"Import error: {type(exc).__name__}"})

    # 5. Disk space
    try:
        usage = shutil.disk_usage("/")
        free_gb = usage.free / (1024**3)
        checks.append({
            "name": "Disk Space",
            "ok": free_gb > 1.0,
            "detail": f"{free_gb:.1f} GB free",
        })
    except Exception:
        checks.append({"name": "Disk Space", "ok": False, "detail": "Could not check"})

    # 6. Memory
    try:
        import psutil
        mem = psutil.virtual_memory()
        avail_gb = mem.available / (1024**3)
        checks.append({
            "name": "Memory",
            "ok": avail_gb > 0.5,
            "detail": f"{avail_gb:.1f} GB available",
        })
    except ImportError:
        checks.append({"name": "Memory", "ok": True, "detail": "psutil not available, skipped"})

    # Output
    if is_json_mode():
        output(checks)
        return

    from rich.tree import Tree

    tree = Tree("[bold]System Diagnostics[/bold]")
    passed = sum(1 for c in checks if c["ok"])
    failed = len(checks) - passed

    for check in checks:
        icon = "[success]pass[/success]" if check["ok"] else "[error]FAIL[/error]"
        tree.add(f"{icon} [bold]{check['name']}[/bold] - {check['detail']}")

    console.print(tree)
    console.print()

    if failed == 0:
        console.print(f"  [success]All {passed} checks passed[/success]")
    else:
        console.print(f"  [success]{passed} passed[/success], [error]{failed} failed[/error]")
