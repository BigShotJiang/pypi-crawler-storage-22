"""Env command group - manage environment variables."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table

env_app = typer.Typer(name="env", help="Manage agent environment variables")

_AGENT_VARS = [
    "ANTHROPIC_API_KEY", "DISPLAY", "WORKSPACE_PATH", "STRIPE_API_KEY",
    "AGENT_DATA_DIR", "METRICS_PORT", "OTLP_ENDPOINT", "LOG_FORMAT",
    "LOG_LEVEL", "DASHBOARD_ADMIN_PASSWORD", "SLACK_BOT_TOKEN",
    "GITHUB_TOKEN",
]


@env_app.command("list")
def env_list(
    all_vars: bool = typer.Option(False, "--all", "-a", help="Show all environment variables"),
) -> None:
    """List agent-related environment variables."""
    if all_vars:
        items = dict(os.environ)
    else:
        items = {k: os.environ.get(k, "") for k in _AGENT_VARS}

    if is_json_mode():
        # Mask secrets
        safe = {}
        for k, v in items.items():
            if v and ("KEY" in k or "TOKEN" in k or "PASSWORD" in k or "SECRET" in k):
                safe[k] = v[:6] + "..." if len(v) > 6 else "***"
            else:
                safe[k] = v
        output(safe)
        return

    headers = ["Variable", "Value", "Status"]
    rows = []
    for k in sorted(items):
        v = items[k]
        if v and ("KEY" in k or "TOKEN" in k or "PASSWORD" in k or "SECRET" in k):
            display = v[:6] + "..." if len(v) > 6 else "***"
        else:
            display = v or ""
        status = "[success]set[/success]" if v else "[dim]not set[/dim]"
        rows.append([k, display, status])
    rich_table(headers, rows, title="Environment Variables")


@env_app.command("get")
def env_get(name: str = typer.Argument(..., help="Variable name")) -> None:
    """Get a specific environment variable."""
    value = os.environ.get(name, "")
    if value and ("KEY" in name or "TOKEN" in name or "PASSWORD" in name):
        display = value[:6] + "..."
    else:
        display = value
    output({"name": name, "value": display, "set": bool(value)},
           human_format=f"[bold]{name}[/bold] = {display}" if value else f"[bold]{name}[/bold] [dim]not set[/dim]")


@env_app.command("set")
def env_set(
    name: str = typer.Argument(..., help="Variable name"),
    value: str = typer.Argument(..., help="Variable value"),
) -> None:
    """Set an environment variable for the current session."""
    os.environ[name] = value
    output({"set": name}, human_format=f"[success]Set {name} for current session.[/success]")


@env_app.command("unset")
def env_unset(name: str = typer.Argument(..., help="Variable name")) -> None:
    """Unset an environment variable."""
    if name in os.environ:
        del os.environ[name]
    output({"unset": name}, human_format=f"[success]Unset {name}.[/success]")


@env_app.command("export")
def env_export(
    output_file: Path = typer.Option(Path(".env"), "--output", "-o", help="Output file"),
) -> None:
    """Export agent environment variables to a .env file."""
    lines = []
    for k in _AGENT_VARS:
        v = os.environ.get(k, "")
        if v:
            lines.append(f"{k}={v}")
    output_file.write_text("\n".join(lines) + "\n")
    output({"exported": str(output_file), "count": len(lines)},
           human_format=f"[success]Exported {len(lines)} variables to {output_file}[/success]")


@env_app.command("check")
def env_check() -> None:
    """Check required environment variables."""
    console = get_console()
    required = ["ANTHROPIC_API_KEY", "DISPLAY"]
    optional = ["WORKSPACE_PATH", "STRIPE_API_KEY", "AGENT_DATA_DIR"]

    results = []
    for k in required:
        v = os.environ.get(k, "")
        results.append({"name": k, "required": True, "set": bool(v)})
    for k in optional:
        v = os.environ.get(k, "")
        results.append({"name": k, "required": False, "set": bool(v)})

    if is_json_mode():
        output(results)
        return

    for r in results:
        if r["set"]:
            console.print(f"  [success]ok[/success] {r['name']}")
        elif r["required"]:
            console.print(f"  [error]MISSING[/error] {r['name']} [dim](required)[/dim]")
        else:
            console.print(f"  [dim]--[/dim] {r['name']} [dim](optional)[/dim]")
