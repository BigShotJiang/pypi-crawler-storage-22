"""Events sub-app: list, watch, clear, subscribe."""

from __future__ import annotations

import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import format_relative_time, output, rich_table

events_app = typer.Typer(name="events", help="Manage and view agent events")


def _events_file() -> Path:
    """Return the path to the events JSON file."""
    return get_state_dir() / "events.json"


def _load_events() -> list:
    """Load all events from disk."""
    path = _events_file()
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return []


def _save_events(events: list) -> None:
    """Save events to disk."""
    _events_file().write_text(json.dumps(events, indent=2, default=str))


@events_app.command("list")
def events_list(
    type: Optional[str] = typer.Option(
        None, "--type", "-t", help="Filter by event type (e.g. agent.started, tool.executed)"
    ),
    limit: int = typer.Option(25, "--limit", "-n", help="Maximum number of events to show"),
    since: Optional[str] = typer.Option(
        None, "--since", "-s",
        help="Show events since time (e.g. '1h', '30m', '2d', or ISO timestamp)"
    ),
) -> None:
    """List recorded events."""
    console = get_console()
    events = _load_events()

    # Apply time filter
    if since:
        cutoff = _parse_since(since)
        if cutoff:
            events = [
                e for e in events
                if _event_after(e, cutoff)
            ]

    # Apply type filter
    if type:
        type_lower = type.lower()
        events = [
            e for e in events
            if type_lower in e.get("type", "").lower()
        ]

    # Apply limit (most recent first)
    events = events[-limit:]

    if is_json_mode():
        output({"events": events, "count": len(events)})
        return

    if not events:
        console.print("[dim]No events found.[/dim]")
        return

    headers = ["Time", "Type", "Agent", "Details"]
    rows = []
    for event in reversed(events):  # Most recent first
        ts = format_relative_time(event.get("timestamp", ""))
        etype = event.get("type", "unknown")
        agent = event.get("agent_type", event.get("agent_id", "-"))[:20]
        details = event.get("message", event.get("details", ""))[:50]
        rows.append([ts, etype, agent, details])

    rich_table(headers, rows, title=f"Events ({len(rows)} shown)")


@events_app.command("watch")
def events_watch() -> None:
    """Watch events in real-time."""
    console = get_console()

    if is_json_mode():
        output({"message": "Event watching is not supported in JSON mode"})
        return

    console.print("[bold]Watching events...[/bold] [dim](Ctrl+C to stop)[/dim]")
    console.print()

    last_count = len(_load_events())

    try:
        while True:
            time.sleep(1)
            events = _load_events()
            current_count = len(events)

            if current_count > last_count:
                new_events = events[last_count:]
                for event in new_events:
                    _print_event(event)
                last_count = current_count

    except KeyboardInterrupt:
        console.print("\n[dim]Event watching stopped.[/dim]")


@events_app.command("clear")
def events_clear() -> None:
    """Clear all recorded events."""
    console = get_console()
    events = _load_events()
    count = len(events)

    if count == 0:
        if is_json_mode():
            output({"message": "No events to clear"})
        else:
            console.print("[dim]No events to clear.[/dim]")
        return

    _save_events([])

    if is_json_mode():
        output({"cleared": count})
    else:
        console.print(f"[success]Cleared {count} event(s).[/success]")


@events_app.command("subscribe")
def events_subscribe(
    channel: str = typer.Argument(
        ..., help="Notification channel (e.g. 'agent.started', 'agent.completed', 'tool.*')"
    ),
) -> None:
    """Subscribe to event notifications for a specific channel pattern."""
    console = get_console()

    # Load or create subscriptions
    subs_file = get_state_dir() / "event_subscriptions.json"
    subscriptions = []
    if subs_file.exists():
        try:
            subscriptions = json.loads(subs_file.read_text())
        except (json.JSONDecodeError, IOError):
            subscriptions = []

    # Check for duplicates
    if channel in subscriptions:
        if is_json_mode():
            output({"message": f"Already subscribed to '{channel}'"})
        else:
            console.print(f"[warning]Already subscribed to '{channel}'.[/warning]")
        return

    subscriptions.append(channel)
    subs_file.write_text(json.dumps(subscriptions, indent=2))

    if is_json_mode():
        output({"subscribed": channel, "total_subscriptions": len(subscriptions)})
    else:
        console.print(f"[success]Subscribed to '{channel}'.[/success]")
        console.print(
            f"[dim]Active subscriptions: {', '.join(subscriptions)}[/dim]"
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_since(since: str) -> Optional[datetime]:
    """Parse a relative or absolute time string into a datetime."""
    since = since.strip()

    # Try relative formats: 1h, 30m, 2d
    if since.endswith("m"):
        try:
            minutes = int(since[:-1])
            return datetime.now() - timedelta(minutes=minutes)
        except ValueError:
            pass
    elif since.endswith("h"):
        try:
            hours = int(since[:-1])
            return datetime.now() - timedelta(hours=hours)
        except ValueError:
            pass
    elif since.endswith("d"):
        try:
            days = int(since[:-1])
            return datetime.now() - timedelta(days=days)
        except ValueError:
            pass

    # Try ISO format
    try:
        return datetime.fromisoformat(since.replace("Z", "+00:00"))
    except ValueError:
        return None


def _event_after(event: dict, cutoff: datetime) -> bool:
    """Check if an event's timestamp is after the cutoff."""
    ts = event.get("timestamp", "")
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        # Make both tz-naive for comparison
        if dt.tzinfo and not cutoff.tzinfo:
            dt = dt.replace(tzinfo=None)
        elif cutoff.tzinfo and not dt.tzinfo:
            cutoff = cutoff.replace(tzinfo=None)
        return dt >= cutoff
    except (ValueError, TypeError):
        return True  # Include events with unparseable timestamps


def _print_event(event: dict) -> None:
    """Print a single event with color coding."""
    console = get_console()
    etype = event.get("type", "unknown")
    ts = event.get("timestamp", "now")
    agent = event.get("agent_type", event.get("agent_id", ""))
    message = event.get("message", event.get("details", ""))

    # Color by event type
    if "error" in etype.lower() or "fail" in etype.lower():
        style = "red"
    elif "complete" in etype.lower() or "success" in etype.lower():
        style = "green"
    elif "start" in etype.lower():
        style = "cyan"
    elif "warn" in etype.lower():
        style = "yellow"
    else:
        style = "dim"

    time_short = ts.split("T")[-1][:8] if "T" in ts else ts
    agent_tag = f" [{agent}]" if agent else ""
    console.print(
        f"  [{style}]{time_short}[/{style}] "
        f"[bold]{etype}[/bold]{agent_tag} {message}"
    )
