"""Export command - export data to file."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_config, get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._history import load_history
from cli._output import output


def export_cmd(
    ctx: typer.Context,
    data_type: str = typer.Argument(
        ..., help="Data type to export: history, logs, metrics, config",
    ),
    output_file: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    fmt: str = typer.Option("json", "--format", "-f", help="Output format: json, csv, yaml"),
) -> None:
    """Export data (history, logs, metrics, config) to a file."""
    console = get_console()

    # Load data based on type
    if data_type == "history":
        data = load_history(limit=500)
    elif data_type == "metrics":
        metrics_path = get_state_dir() / "metrics.json"
        data = json.loads(metrics_path.read_text()) if metrics_path.exists() else {}
    elif data_type == "config":
        data = get_config()._load()
    elif data_type == "logs":
        logs_path = get_state_dir() / "logs"
        if logs_path.exists():
            data = [f.name for f in logs_path.iterdir() if f.is_file()]
        else:
            data = []
    else:
        print_error(f"Unknown data type: {data_type}", details="Available: history, logs, metrics, config")
        raise typer.Exit(1)

    # Determine output path
    if output_file is None:
        output_file = Path(f"stateset-{data_type}.{fmt}")

    # Format and write
    try:
        if fmt == "json":
            content = json.dumps(data, indent=2, default=str)
        elif fmt == "csv":
            import csv
            import io

            buf = io.StringIO()
            if isinstance(data, list) and data and isinstance(data[0], dict):
                writer = csv.DictWriter(buf, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
            elif isinstance(data, dict):
                writer = csv.writer(buf)
                writer.writerow(["key", "value"])
                for k, v in data.items():
                    writer.writerow([k, json.dumps(v) if isinstance(v, (dict, list)) else v])
            else:
                writer = csv.writer(buf)
                for item in data:
                    writer.writerow([item])
            content = buf.getvalue()
        elif fmt == "yaml":
            try:
                import yaml
                content = yaml.dump(data, default_flow_style=False)
            except ImportError:
                print_error("PyYAML not installed", details="pip install pyyaml")
                raise typer.Exit(1)
        else:
            print_error(f"Unknown format: {fmt}", details="Available: json, csv, yaml")
            raise typer.Exit(1)

        output_file.write_text(content)
        output(
            {"exported": str(output_file), "type": data_type, "format": fmt},
            human_format=f"[success]Exported {data_type} to {output_file}[/success]",
        )
    except Exception as e:
        print_error(f"Export failed: {e}")
        raise typer.Exit(1)
