"""History command - show past task executions."""

from __future__ import annotations

from typing import Optional

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._history import clear_history, load_history
from cli._output import format_relative_time, output, rich_table


def history(
    ctx: typer.Context,
    limit: int = typer.Option(20, "--limit", "-n", help="Number of entries to show"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Filter by agent type"),
    clear: bool = typer.Option(False, "--clear", help="Clear all history"),
) -> None:
    """Show past task executions."""
    console = get_console()

    if clear:
        clear_history()
        output({"cleared": True}, human_format="[success]History cleared.[/success]")
        return

    entries = load_history(limit=limit)

    if agent:
        entries = [e for e in entries if e.get("agent_type", "").lower() == agent.lower()]

    if not entries:
        output({"entries": []}, human_format="[dim]No history entries found.[/dim]")
        return

    if is_json_mode():
        output(entries)
        return

    headers = ["Time", "Type", "Agent", "Instruction", "Status"]
    rows = []
    for entry in reversed(entries):
        rows.append([
            format_relative_time(entry.get("timestamp", "")),
            entry.get("type", "?"),
            entry.get("agent_type", "auto"),
            (entry.get("instruction", "")[:50] + "...") if len(entry.get("instruction", "")) > 50 else entry.get("instruction", ""),
            entry.get("status", "?"),
        ])

    rich_table(headers, rows, title=f"Task History (last {limit})")
