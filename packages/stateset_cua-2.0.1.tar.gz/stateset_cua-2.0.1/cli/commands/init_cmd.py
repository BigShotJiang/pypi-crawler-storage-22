"""Init command - first-time setup wizard."""

from __future__ import annotations

import os

import typer

from cli._config import get_config, get_state_dir
from cli._console import get_console, print_logo


def init_cmd() -> None:
    """Initialize StateSet CUA configuration."""
    console = get_console()
    print_logo()
    console.print("[bold]First-time setup[/bold]")
    console.print()

    state_dir = get_state_dir()
    console.print(f"  Config directory: [info]{state_dir}[/info]")
    console.print()

    cfg = get_config()

    # API key
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if api_key:
        console.print("  [success]ok[/success] ANTHROPIC_API_KEY is set")
    else:
        console.print("  [warning]ANTHROPIC_API_KEY not set[/warning]")
        console.print("  Set it with: [bold]export ANTHROPIC_API_KEY='sk-ant-...'[/bold]")

    # Display
    display = os.environ.get("DISPLAY", "")
    if display:
        console.print(f"  [success]ok[/success] DISPLAY = {display}")
    else:
        console.print("  [warning]DISPLAY not set[/warning]")
        console.print("  Start Xvfb: [bold]Xvfb :1 -screen 0 1920x1080x24 &[/bold]")
        console.print("  Then: [bold]export DISPLAY=:1[/bold]")

    # Default agent
    console.print()
    default_agent = typer.prompt(
        "  Default agent type",
        default=cfg.get("default_agent") or "agentic",
        show_default=True,
    )
    cfg.set("default_agent", default_agent)

    # Default effort
    default_effort = typer.prompt(
        "  Default effort level",
        default=cfg.get("default_effort", "medium"),
        show_default=True,
    )
    cfg.set("default_effort", default_effort)

    console.print()
    console.print("[success]Setup complete![/success]")
    console.print(f"  Config saved to [info]{cfg.config_file}[/info]")
    console.print()
    console.print("  Next steps:")
    console.print("    [bold]stateset-cua run[/bold] 'your task'")
    console.print("    [bold]stateset-cua chat[/bold]")
    console.print("    [bold]stateset-cua doctor[/bold]")
