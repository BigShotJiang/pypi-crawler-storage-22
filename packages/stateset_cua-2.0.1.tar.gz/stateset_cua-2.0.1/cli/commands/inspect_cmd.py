"""Inspect command group - deep inspection of components."""

from __future__ import annotations

import json
import os
import platform
import sys
from pathlib import Path

import typer

from cli._config import get_config, get_state_dir
from cli._console import get_console, is_json_mode
from cli._constants import AGENT_DESCRIPTIONS, AGENT_TYPE_MAP, TOOL_VERSIONS
from cli._output import output, rich_table

inspect_app = typer.Typer(name="inspect", help="Inspect agent components in detail")


@inspect_app.command("task")
def inspect_task(task_id: str = typer.Argument(..., help="Task ID from history")) -> None:
    """Inspect a specific task from history."""
    from cli._history import load_history

    entries = load_history(limit=500)
    match = [e for e in entries if e.get("timestamp", "").startswith(task_id) or str(entries.index(e)) == task_id]

    if not match:
        from cli._errors import print_error
        print_error(f"Task not found: {task_id}")
        raise typer.Exit(1)

    entry = match[0]
    if is_json_mode():
        output(entry)
        return

    from rich.panel import Panel
    lines = [f"[bold]{k}:[/bold] {v}" for k, v in entry.items()]
    get_console().print(Panel("\n".join(lines), title="Task Details", border_style="cyan"))


@inspect_app.command("agent")
def inspect_agent(name: str = typer.Argument(..., help="Agent name (e.g. auto-close)")) -> None:
    """Inspect an agent type in detail."""
    info = AGENT_DESCRIPTIONS.get(name, {})
    internal = AGENT_TYPE_MAP.get(name)

    if not internal:
        from cli._errors import print_error
        print_error(f"Unknown agent: {name}", details=f"Available: {', '.join(AGENT_TYPE_MAP)}")
        raise typer.Exit(1)

    data = {"name": name, "internal_name": internal, **info}

    if is_json_mode():
        output(data)
        return

    from rich.panel import Panel
    lines = [f"[bold]{k}:[/bold] {v}" for k, v in data.items()]
    get_console().print(Panel("\n".join(lines), title=f"Agent: {name}", border_style="cyan"))


@inspect_app.command("config")
def inspect_config() -> None:
    """Inspect full configuration."""
    cfg = get_config()._load()
    if is_json_mode():
        output(cfg)
        return

    from rich.syntax import Syntax
    from rich.panel import Panel
    get_console().print(Panel(
        Syntax(json.dumps(cfg, indent=2), "json", theme="monokai"),
        title="Configuration", border_style="cyan",
    ))


@inspect_app.command("system")
def inspect_system() -> None:
    """Inspect system information."""
    info = {
        "platform": platform.platform(),
        "python": sys.version,
        "cwd": os.getcwd(),
        "display": os.environ.get("DISPLAY", "not set"),
        "state_dir": str(get_state_dir()),
        "tool_versions": TOOL_VERSIONS,
        "api_key_set": bool(os.environ.get("ANTHROPIC_API_KEY")),
    }

    if is_json_mode():
        output(info)
        return

    from rich.panel import Panel
    lines = [f"[bold]{k}:[/bold] {v}" for k, v in info.items()]
    get_console().print(Panel("\n".join(lines), title="System Info", border_style="cyan"))


@inspect_app.command("tools")
def inspect_tools() -> None:
    """Inspect available tools and versions."""
    tools = [
        {"name": "ComputerTool", "type": "GUI automation", "versions": TOOL_VERSIONS[:3]},
        {"name": "BashTool", "type": "System commands", "versions": ["all"]},
        {"name": "EditTool", "type": "File editing", "versions": ["all"]},
        {"name": "MemoryTool", "type": "Persistent memory", "versions": ["all"]},
        {"name": "AGITool", "type": "Extended AGI", "versions": ["all"]},
        {"name": "SubagentTool", "type": "Subagent spawning", "versions": ["all"]},
    ]

    if is_json_mode():
        output(tools)
        return

    headers = ["Tool", "Type", "Versions"]
    rows = [[t["name"], t["type"], ", ".join(t["versions"])] for t in tools]
    rich_table(headers, rows, title="Available Tools")
