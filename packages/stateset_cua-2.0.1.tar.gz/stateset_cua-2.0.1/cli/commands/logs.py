"""Logs command: view and follow agent log output."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._output import output


def logs(
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output in real-time"),
    level: Optional[str] = typer.Option(
        None, "--level", "-l", help="Filter by log level (DEBUG, INFO, WARNING, ERROR)"
    ),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of recent lines to show"),
    agent: Optional[str] = typer.Option(
        None, "--agent", "-a", help="Filter by agent type or ID"
    ),
) -> None:
    """Show logs from ~/.stateset/logs/agent.log."""
    console = get_console()
    log_dir = get_state_dir() / "logs"

    if not log_dir.exists():
        log_dir.mkdir(parents=True, exist_ok=True)

    # Determine which log file to read
    log_file = _resolve_log_file(log_dir, agent)

    if not log_file.exists():
        if is_json_mode():
            output({"message": "No log file found", "path": str(log_file)})
        else:
            console.print(f"[dim]No log file found at {log_file}[/dim]")
            console.print("[dim]Logs will appear here once an agent runs.[/dim]")
        return

    level_upper = level.upper() if level else None

    # Show the tail of the log
    _display_log_tail(log_file, lines, level_upper, agent)

    if not follow:
        return

    if is_json_mode():
        # In JSON mode, just output the tail and exit
        return

    # Follow mode: watch for new lines
    console.print()
    console.print("[dim]--- Following log output (Ctrl+C to stop) ---[/dim]")

    try:
        with open(log_file, "r") as f:
            # Seek to end of file
            f.seek(0, 2)
            while True:
                new_line = f.readline()
                if not new_line:
                    time.sleep(0.2)
                    continue

                new_line = new_line.rstrip()
                if not new_line:
                    continue

                if level_upper and not _matches_level(new_line, level_upper):
                    continue

                if agent and not _matches_agent(new_line, agent):
                    continue

                console.print(_colorize_log_line(new_line))

    except KeyboardInterrupt:
        console.print("\n[dim]Log following stopped.[/dim]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_log_file(log_dir: Path, agent: Optional[str]) -> Path:
    """Determine the log file path based on optional agent filter.

    If a specific agent is given and a per-agent log file exists, use it.
    Otherwise fall back to the main agent.log.
    """
    if agent:
        # Try agent-specific log first
        agent_log = log_dir / f"{agent}.log"
        if agent_log.exists():
            return agent_log

    return log_dir / "agent.log"


def _display_log_tail(
    log_file: Path,
    num_lines: int,
    level_filter: Optional[str],
    agent_filter: Optional[str],
) -> None:
    """Read and display the last N lines from the log file."""
    console = get_console()

    try:
        all_lines = log_file.read_text().splitlines()
    except IOError as exc:
        console.print(f"[error]Could not read log file: {exc}[/error]")
        return

    # Apply filters
    filtered = all_lines
    if level_filter:
        filtered = [ln for ln in filtered if _matches_level(ln, level_filter)]
    if agent_filter:
        filtered = [ln for ln in filtered if _matches_agent(ln, agent_filter)]

    tail = filtered[-num_lines:]

    if is_json_mode():
        output({
            "lines": tail,
            "count": len(tail),
            "total_lines": len(all_lines),
            "file": str(log_file),
            "filters": {
                "level": level_filter,
                "agent": agent_filter,
            },
        })
        return

    if not tail:
        console.print("[dim]No matching log entries found.[/dim]")
        return

    from rich.panel import Panel

    console.print(
        Panel(
            f"[dim]Showing last {len(tail)} of {len(all_lines)} lines from {log_file.name}[/dim]",
            border_style="dim",
            expand=False,
        )
    )

    for line in tail:
        console.print(_colorize_log_line(line))


def _matches_level(line: str, level: str) -> bool:
    """Check if a log line matches the given log level."""
    upper = level.upper()
    return (
        f" {upper} " in line
        or f"[{upper}]" in line
        or f"level={upper}" in line.upper()
        or line.upper().startswith(upper)
    )


def _matches_agent(line: str, agent: str) -> bool:
    """Check if a log line matches the given agent type or ID."""
    agent_upper = agent.upper()
    return (
        f"[{agent_upper}]" in line.upper()
        or f"agent={agent}" in line.lower()
        or f"agent_type={agent}" in line.lower()
        or agent.lower() in line.lower()
    )


def _colorize_log_line(line: str) -> str:
    """Apply Rich color markup to a log line based on its level."""
    upper = line.upper()
    if "ERROR" in upper or "CRITICAL" in upper:
        return f"[bold red]{line}[/bold red]"
    elif "WARNING" in upper or "WARN" in upper:
        return f"[yellow]{line}[/yellow]"
    elif "DEBUG" in upper:
        return f"[dim]{line}[/dim]"
    elif "INFO" in upper:
        return line
    return f"[dim]{line}[/dim]"
