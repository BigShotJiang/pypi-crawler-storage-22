"""MCP sub-app: manage Model Context Protocol server connections."""

from __future__ import annotations

import json
from typing import Optional

import typer

from cli._config import get_config
from cli._console import get_console, is_json_mode
from cli._constants import MCP_PRESETS
from cli._errors import print_error
from cli._output import output, rich_table

mcp_app = typer.Typer(name="mcp", help="Manage MCP (Model Context Protocol) servers")

# Preset configurations for common MCP servers
_PRESET_CONFIGS = {
    "slack": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-slack"],
        "env_keys": ["SLACK_BOT_TOKEN"],
        "description": "Slack workspace integration",
    },
    "github": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-github"],
        "env_keys": ["GITHUB_PERSONAL_ACCESS_TOKEN"],
        "description": "GitHub repository access",
    },
    "postgres": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-postgres"],
        "env_keys": ["POSTGRES_CONNECTION_STRING"],
        "description": "PostgreSQL database access",
    },
    "filesystem": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem"],
        "env_keys": [],
        "description": "Local filesystem access",
    },
    "memory": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-memory"],
        "env_keys": [],
        "description": "Persistent memory store",
    },
    "brave-search": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-brave-search"],
        "env_keys": ["BRAVE_API_KEY"],
        "description": "Brave search engine integration",
    },
    "puppeteer": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-puppeteer"],
        "env_keys": [],
        "description": "Browser automation with Puppeteer",
    },
    "sqlite": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-sqlite"],
        "env_keys": ["SQLITE_DB_PATH"],
        "description": "SQLite database access",
    },
}


@mcp_app.command("list")
def mcp_list() -> None:
    """Show configured MCP servers and available presets."""
    console = get_console()
    cfg = get_config()
    configured = cfg.get("mcp_servers", {})

    if is_json_mode():
        output({
            "configured": configured,
            "available_presets": MCP_PRESETS,
        })
        return

    # Show configured servers
    if configured:
        headers = ["Name", "Command", "Args", "Status"]
        rows = []
        for name, server in sorted(configured.items()):
            cmd = server.get("command", "?")
            args = " ".join(server.get("args", []))[:40]
            enabled = server.get("enabled", True)
            status = "[success]enabled[/success]" if enabled else "[dim]disabled[/dim]"
            rows.append([name, cmd, args, status])

        rich_table(headers, rows, title="Configured MCP Servers")
    else:
        console.print("[dim]No MCP servers configured.[/dim]")

    # Show available presets
    console.print()
    console.print("[bold]Available Presets:[/bold]")
    for preset_name in sorted(MCP_PRESETS):
        preset_info = _PRESET_CONFIGS.get(preset_name, {})
        desc = preset_info.get("description", "")
        env_keys = preset_info.get("env_keys", [])
        env_hint = f" [dim](requires: {', '.join(env_keys)})[/dim]" if env_keys else ""
        is_configured = preset_name in configured
        marker = "[success]*[/success] " if is_configured else "  "
        console.print(f"  {marker}[cyan]{preset_name}[/cyan] - {desc}{env_hint}")

    console.print()
    console.print(
        "[dim]Add a preset with: stateset-cua mcp add <name> --preset <preset>[/dim]"
    )


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Argument(..., help="Name for the MCP server"),
    preset: Optional[str] = typer.Option(
        None, "--preset", "-p",
        help=f"Use a preset configuration ({', '.join(MCP_PRESETS)})"
    ),
    command: Optional[str] = typer.Option(
        None, "--command", "-c", help="Server command (for custom servers)"
    ),
    args: Optional[str] = typer.Option(
        None, "--args", help="Server arguments (space-separated, for custom servers)"
    ),
) -> None:
    """Add an MCP server configuration."""
    console = get_console()
    cfg = get_config()
    servers = cfg.get("mcp_servers", {})

    if name in servers:
        print_error(
            f"MCP server '{name}' already configured",
            details="Use 'stateset-cua mcp remove' first, then re-add.",
        )
        raise typer.Exit(1)

    if preset:
        if preset not in _PRESET_CONFIGS:
            print_error(
                f"Unknown preset: {preset}",
                details=f"Available presets: {', '.join(sorted(_PRESET_CONFIGS.keys()))}",
            )
            raise typer.Exit(1)

        preset_cfg = _PRESET_CONFIGS[preset]
        server_config = {
            "command": preset_cfg["command"],
            "args": preset_cfg["args"],
            "env_keys": preset_cfg.get("env_keys", []),
            "preset": preset,
            "enabled": True,
        }

        # Build env dict from required environment variables
        env = {}
        missing_keys = []
        for key in preset_cfg.get("env_keys", []):
            import os
            val = os.environ.get(key)
            if val:
                env[key] = val
            else:
                missing_keys.append(key)

        if env:
            server_config["env"] = env

        if missing_keys and not is_json_mode():
            console.print(
                f"[warning]Missing environment variables: {', '.join(missing_keys)}[/warning]"
            )
            console.print(
                "[dim]Set them before running the agent, or add them to your .env file.[/dim]"
            )

    elif command:
        server_config = {
            "command": command,
            "args": args.split() if args else [],
            "enabled": True,
        }
    else:
        print_error(
            "Must specify either --preset or --command",
            details="Use --preset for common services or --command for custom servers.",
        )
        raise typer.Exit(1)

    servers[name] = server_config
    cfg.set("mcp_servers", servers)

    if is_json_mode():
        output({"added": name, "config": server_config})
    else:
        console.print(f"[success]MCP server '{name}' added.[/success]")
        if preset:
            preset_info = _PRESET_CONFIGS[preset]
            console.print(f"  [dim]Preset: {preset}[/dim]")
            console.print(f"  [dim]Command: {preset_info['command']}[/dim]")
            console.print(f"  [dim]Args: {' '.join(preset_info['args'])}[/dim]")


@mcp_app.command("remove")
def mcp_remove(
    name: str = typer.Argument(..., help="Name of the MCP server to remove"),
) -> None:
    """Remove an MCP server configuration."""
    console = get_console()
    cfg = get_config()
    servers = cfg.get("mcp_servers", {})

    if name not in servers:
        print_error(
            f"MCP server '{name}' not found",
            details=f"Configured servers: {', '.join(sorted(servers.keys())) or 'none'}",
        )
        raise typer.Exit(1)

    del servers[name]
    cfg.set("mcp_servers", servers)

    if is_json_mode():
        output({"removed": name})
    else:
        console.print(f"[success]MCP server '{name}' removed.[/success]")


@mcp_app.command("status")
def mcp_status() -> None:
    """Show MCP server connection status and health."""
    console = get_console()
    cfg = get_config()
    servers = cfg.get("mcp_servers", {})

    if not servers:
        if is_json_mode():
            output({"servers": [], "message": "No MCP servers configured"})
        else:
            console.print("[dim]No MCP servers configured.[/dim]")
            console.print(
                "[dim]Add one with: stateset-cua mcp add <name> --preset <preset>[/dim]"
            )
        return

    import os
    import shutil

    statuses = []
    for name, server in sorted(servers.items()):
        cmd = server.get("command", "")
        enabled = server.get("enabled", True)
        preset = server.get("preset")
        env_keys = server.get("env_keys", [])

        # Check if the command is available
        cmd_available = bool(shutil.which(cmd))

        # Check if required env vars are set
        missing_env = [k for k in env_keys if not os.environ.get(k)]

        # Determine overall status
        if not enabled:
            health = "disabled"
        elif not cmd_available:
            health = "error"
        elif missing_env:
            health = "warning"
        else:
            health = "ready"

        status_entry = {
            "name": name,
            "command": cmd,
            "preset": preset,
            "enabled": enabled,
            "command_available": cmd_available,
            "missing_env": missing_env,
            "health": health,
        }
        statuses.append(status_entry)

    if is_json_mode():
        output({"servers": statuses})
        return

    headers = ["Name", "Preset", "Command", "Env", "Health"]
    rows = []
    for s in statuses:
        name = s["name"]
        preset = s.get("preset") or "-"
        cmd = s["command"]
        cmd_display = f"[success]{cmd}[/success]" if s["command_available"] else f"[error]{cmd}[/error]"

        if s["missing_env"]:
            env_display = f"[warning]{len(s['missing_env'])} missing[/warning]"
        else:
            env_keys = _PRESET_CONFIGS.get(s.get("preset", ""), {}).get("env_keys", [])
            env_display = "[success]ok[/success]" if env_keys else "[dim]none needed[/dim]"

        health_map = {
            "ready": "[success]ready[/success]",
            "warning": "[warning]warning[/warning]",
            "error": "[error]error[/error]",
            "disabled": "[dim]disabled[/dim]",
        }
        health = health_map.get(s["health"], s["health"])

        rows.append([name, preset, cmd_display, env_display, health])

    rich_table(headers, rows, title="MCP Server Status")

    # Show details for servers with issues
    issues = [s for s in statuses if s["health"] in ("error", "warning")]
    if issues:
        console.print()
        for s in issues:
            if not s["command_available"]:
                console.print(
                    f"  [error]{s['name']}:[/error] Command '{s['command']}' not found. "
                    f"Install with: npm install -g {s['command']}"
                )
            if s["missing_env"]:
                console.print(
                    f"  [warning]{s['name']}:[/warning] Missing env vars: "
                    f"{', '.join(s['missing_env'])}"
                )
