"""Metrics command - show token usage and cost metrics."""

from __future__ import annotations

import json
from pathlib import Path

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._output import format_cost, format_tokens, output, rich_table


def _load_metrics() -> dict:
    path = get_state_dir() / "metrics.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return {}


def metrics(
    ctx: typer.Context,
    period: str = typer.Option("all", "--period", "-p", help="Time period: today, week, month, all"),
    reset: bool = typer.Option(False, "--reset", help="Reset all metrics"),
) -> None:
    """Show token usage and cost metrics."""
    console = get_console()
    metrics_path = get_state_dir() / "metrics.json"

    if reset:
        if metrics_path.exists():
            metrics_path.write_text("{}")
        output({"reset": True}, human_format="[success]Metrics reset.[/success]")
        return

    data = _load_metrics()
    if not data:
        output({"message": "No metrics data found."}, human_format="[dim]No metrics data found.[/dim]")
        return

    if is_json_mode():
        output(data)
        return

    from rich.panel import Panel

    total_input = data.get("total_input_tokens", 0)
    total_output = data.get("total_output_tokens", 0)
    total_cost = data.get("total_cost", 0.0)
    task_count = data.get("task_count", 0)

    summary = (
        f"[bold]Tasks run:[/bold] {task_count}\n"
        f"[bold]Input tokens:[/bold] {format_tokens(total_input)}\n"
        f"[bold]Output tokens:[/bold] {format_tokens(total_output)}\n"
        f"[bold]Total tokens:[/bold] {format_tokens(total_input + total_output)}\n"
        f"[bold]Estimated cost:[/bold] {format_cost(total_cost)}"
    )

    if task_count > 0:
        avg_cost = total_cost / task_count
        avg_tokens = (total_input + total_output) / task_count
        summary += (
            f"\n\n[bold]Avg tokens/task:[/bold] {format_tokens(int(avg_tokens))}\n"
            f"[bold]Avg cost/task:[/bold] {format_cost(avg_cost)}"
        )

    console.print(Panel(summary, title="Usage Metrics", border_style="cyan"))

    # Per-agent breakdown if available
    agents = data.get("by_agent", {})
    if agents:
        headers = ["Agent", "Tasks", "Input Tokens", "Output Tokens", "Cost"]
        rows = []
        for agent_name, stats in agents.items():
            rows.append([
                agent_name,
                str(stats.get("task_count", 0)),
                format_tokens(stats.get("input_tokens", 0)),
                format_tokens(stats.get("output_tokens", 0)),
                format_cost(stats.get("cost", 0.0)),
            ])
        rich_table(headers, rows, title="Per-Agent Breakdown")
