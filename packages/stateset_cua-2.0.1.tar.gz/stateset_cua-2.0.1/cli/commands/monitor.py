"""Monitor commands: status, stop, watch, tail (flat commands, not a sub-app)."""

from __future__ import annotations

import json
import os
import signal
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._history import load_running_agents, save_running_agents, unregister_agent
from cli._output import format_duration, format_relative_time, output, rich_table


def status() -> None:
    """Show currently running agents."""
    console = get_console()
    agents = load_running_agents()

    if not agents:
        if is_json_mode():
            output({"agents": [], "count": 0})
        else:
            console.print("[dim]No agents currently running.[/dim]")
        return

    if is_json_mode():
        output({"agents": agents, "count": len(agents)})
        return

    headers = ["ID", "Agent Type", "Task", "PID", "Started", "Status"]
    rows = []
    for agent in agents:
        agent_id = agent.get("id", "unknown")[:12]
        agent_type = agent.get("agent_type", "unknown")
        task = agent.get("task", "")[:40]
        pid = str(agent.get("pid", "?"))
        started = format_relative_time(agent.get("started_at", ""))
        # Check if the process is actually alive
        alive = _is_process_alive(agent.get("pid"))
        status_str = "[success]running[/success]" if alive else "[error]dead[/error]"
        rows.append([agent_id, agent_type, task, pid, started, status_str])

    rich_table(headers, rows, title="Running Agents")

    # Summary
    alive_count = sum(1 for a in agents if _is_process_alive(a.get("pid")))
    console.print(
        f"\n[dim]{alive_count} alive, {len(agents) - alive_count} dead "
        f"of {len(agents)} registered[/dim]"
    )


def stop(
    agent_id: str = typer.Argument(..., help="Agent ID to stop (or 'all')"),
    force: bool = typer.Option(False, "--force", "-f", help="Force kill (SIGKILL)"),
) -> None:
    """Stop a running agent by ID."""
    console = get_console()
    agents = load_running_agents()

    if agent_id == "all":
        if not agents:
            if is_json_mode():
                output({"message": "No agents to stop"})
            else:
                console.print("[dim]No agents to stop.[/dim]")
            return

        stopped = 0
        for agent in agents:
            pid = agent.get("pid")
            if pid and _is_process_alive(pid):
                _kill_process(pid, force=force)
                stopped += 1

        save_running_agents([])
        if is_json_mode():
            output({"stopped": stopped, "total": len(agents)})
        else:
            console.print(
                f"[success]Stopped {stopped} agent(s) and cleared registry.[/success]"
            )
        return

    # Find the matching agent (prefix match)
    matching = [
        a for a in agents
        if a.get("id", "").startswith(agent_id)
    ]

    if not matching:
        print_error(
            f"Agent not found: {agent_id}",
            details="Run 'stateset-cua status' to see running agents.",
        )
        raise typer.Exit(1)

    if len(matching) > 1:
        print_error(
            f"Ambiguous ID: {agent_id} matches {len(matching)} agents",
            details="Provide a more specific agent ID prefix.",
        )
        raise typer.Exit(1)

    target = matching[0]
    pid = target.get("pid")

    if pid and _is_process_alive(pid):
        _kill_process(pid, force=force)
        sig_name = "SIGKILL" if force else "SIGTERM"
        if is_json_mode():
            output({
                "stopped": target.get("id"),
                "pid": pid,
                "signal": sig_name,
            })
        else:
            console.print(
                f"[success]Sent {sig_name} to agent "
                f"{target.get('id', '')[:12]}[/success] (PID {pid})"
            )
    else:
        if is_json_mode():
            output({"removed": target.get("id"), "note": "process already dead"})
        else:
            console.print(
                f"[warning]Agent {target.get('id', '')[:12]} process already dead, "
                f"removing from registry.[/warning]"
            )

    unregister_agent(target.get("id", ""))


def watch() -> None:
    """Real-time monitoring of running agents (refreshes every 2s)."""
    console = get_console()

    if is_json_mode():
        # In JSON mode, just print once and exit
        agents = load_running_agents()
        output({"agents": agents, "count": len(agents)})
        return

    try:
        from rich.live import Live
        from rich.table import Table
        from rich.panel import Panel
        from rich.layout import Layout
        from rich.text import Text

        def build_display() -> Panel:
            agents = load_running_agents()
            now = datetime.now().strftime("%H:%M:%S")

            if not agents:
                return Panel(
                    f"[dim]No agents running. Watching... (Ctrl+C to exit)[/dim]\n"
                    f"[dim]Last check: {now}[/dim]",
                    title="Agent Monitor",
                    border_style="cyan",
                )

            table = Table(show_header=True, header_style="bold", expand=True)
            table.add_column("ID", style="cyan", width=14)
            table.add_column("Type", style="bold")
            table.add_column("Task", ratio=2)
            table.add_column("PID", width=8)
            table.add_column("Uptime", width=10)
            table.add_column("Status", width=10)

            alive_count = 0
            for agent in agents:
                agent_id = agent.get("id", "unknown")[:12]
                agent_type = agent.get("agent_type", "unknown")
                task = agent.get("task", "")[:50]
                pid = str(agent.get("pid", "?"))

                # Calculate uptime
                started_at = agent.get("started_at", "")
                uptime = _compute_uptime(started_at)

                alive = _is_process_alive(agent.get("pid"))
                if alive:
                    alive_count += 1
                status_str = "[green]running[/green]" if alive else "[red]dead[/red]"

                table.add_row(agent_id, agent_type, task, pid, uptime, status_str)

            summary = Text.from_markup(
                f"\n  [bold]{alive_count}[/bold] running, "
                f"[dim]{len(agents) - alive_count} dead[/dim]  |  "
                f"Last refresh: {now}  |  [dim]Ctrl+C to exit[/dim]"
            )

            from rich.console import Group
            return Panel(
                Group(table, summary),
                title="Agent Monitor",
                border_style="cyan",
            )

        with Live(
            build_display(),
            console=console,
            refresh_per_second=0.5,
            screen=False,
        ) as live:
            while True:
                time.sleep(2)
                live.update(build_display())

    except KeyboardInterrupt:
        console.print("\n[dim]Monitor stopped.[/dim]")


def tail(
    lines: int = typer.Option(20, "--lines", "-n", help="Number of lines to show"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
    level: Optional[str] = typer.Option(
        None, "--level", "-l", help="Filter by log level (DEBUG, INFO, WARNING, ERROR)"
    ),
) -> None:
    """Show recent log entries from the agent log."""
    console = get_console()
    log_dir = get_state_dir() / "logs"

    if not log_dir.exists():
        log_dir.mkdir(parents=True, exist_ok=True)

    log_file = log_dir / "agent.log"
    if not log_file.exists():
        if is_json_mode():
            output({"message": "No log file found", "path": str(log_file)})
        else:
            console.print(f"[dim]No log file found at {log_file}[/dim]")
        return

    level_upper = level.upper() if level else None

    if not follow:
        # Just show the last N lines
        _show_tail(log_file, lines, level_upper)
        return

    # Follow mode: show existing lines then watch for new ones
    _show_tail(log_file, lines, level_upper)

    if is_json_mode():
        # Cannot follow in JSON mode meaningfully, just show and exit
        return

    console.print("[dim]--- Following log (Ctrl+C to exit) ---[/dim]")
    try:
        with open(log_file, "r") as f:
            # Seek to end
            f.seek(0, 2)
            while True:
                line = f.readline()
                if not line:
                    time.sleep(0.3)
                    continue
                line = line.rstrip()
                if level_upper and not _matches_level(line, level_upper):
                    continue
                console.print(_colorize_log_line(line))
    except KeyboardInterrupt:
        console.print("\n[dim]Log tailing stopped.[/dim]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _is_process_alive(pid: Optional[int]) -> bool:
    """Check if a process with the given PID is alive."""
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError, TypeError):
        return False


def _kill_process(pid: int, force: bool = False) -> None:
    """Send a signal to terminate a process."""
    try:
        sig = signal.SIGKILL if force else signal.SIGTERM
        os.kill(pid, sig)
    except (OSError, ProcessLookupError):
        pass


def _compute_uptime(started_at: str) -> str:
    """Compute uptime from an ISO timestamp."""
    try:
        dt = datetime.fromisoformat(started_at.replace("Z", "+00:00"))
        now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
        diff = (now - dt).total_seconds()
        return format_duration(diff)
    except (ValueError, TypeError):
        return "?"


def _show_tail(log_file: Path, num_lines: int, level_filter: Optional[str]) -> None:
    """Read and display the last N lines of a log file."""
    console = get_console()
    try:
        all_lines = log_file.read_text().splitlines()
    except IOError:
        console.print("[error]Could not read log file.[/error]")
        return

    if level_filter:
        all_lines = [ln for ln in all_lines if _matches_level(ln, level_filter)]

    tail_lines = all_lines[-num_lines:]

    if is_json_mode():
        output({"lines": tail_lines, "count": len(tail_lines), "file": str(log_file)})
        return

    if not tail_lines:
        console.print("[dim]No matching log entries.[/dim]")
        return

    for line in tail_lines:
        console.print(_colorize_log_line(line))


def _matches_level(line: str, level: str) -> bool:
    """Check if a log line matches the given level."""
    level_upper = level.upper()
    # Match common log formats: "2025-01-01 INFO ..." or "[INFO]" or "level=INFO"
    return (
        f" {level_upper} " in line
        or f"[{level_upper}]" in line
        or f"level={level_upper}" in line.upper()
        or line.upper().startswith(level_upper)
    )


def _colorize_log_line(line: str) -> str:
    """Add Rich markup to a log line based on level."""
    line_upper = line.upper()
    if "ERROR" in line_upper or "CRITICAL" in line_upper:
        return f"[red]{line}[/red]"
    elif "WARNING" in line_upper or "WARN" in line_upper:
        return f"[yellow]{line}[/yellow]"
    elif "DEBUG" in line_upper:
        return f"[dim]{line}[/dim]"
    elif "INFO" in line_upper:
        return line
    return line
