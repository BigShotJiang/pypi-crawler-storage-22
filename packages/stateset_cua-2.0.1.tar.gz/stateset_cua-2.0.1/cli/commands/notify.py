"""Notify command group - notification management."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_config, get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table

notify_app = typer.Typer(name="notify", help="Manage notifications")


def _notify_config_file() -> Path:
    return get_state_dir() / "notify.json"


def _load_notify_config() -> dict:
    path = _notify_config_file()
    if not path.exists():
        return {"channels": {}, "enabled": True}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return {"channels": {}, "enabled": True}


def _save_notify_config(config: dict) -> None:
    _notify_config_file().write_text(json.dumps(config, indent=2))


@notify_app.command("send")
def notify_send(
    message: str = typer.Argument(..., help="Notification message"),
    channel: str = typer.Option("console", "--channel", "-c", help="Channel: console, slack, webhook"),
    title: str = typer.Option("StateSet Agent", "--title", "-t", help="Notification title"),
) -> None:
    """Send a notification."""
    console = get_console()
    config = _load_notify_config()

    if not config.get("enabled", True):
        output({"sent": False, "reason": "notifications disabled"},
               human_format="[warning]Notifications are disabled.[/warning]")
        return

    if channel == "console":
        from rich.panel import Panel
        console.print(Panel(message, title=title, border_style="cyan"))
        output({"sent": True, "channel": "console"})
    elif channel == "slack":
        ch_config = config.get("channels", {}).get("slack", {})
        webhook_url = ch_config.get("webhook_url")
        if not webhook_url:
            print_error("Slack not configured.", details="Run: stateset-cua notify config --channel slack --webhook-url <url>")
            raise typer.Exit(1)
        try:
            import httpx
            resp = httpx.post(webhook_url, json={"text": f"*{title}*\n{message}"}, timeout=10.0)
            output({"sent": True, "channel": "slack", "status": resp.status_code},
                   human_format=f"[success]Slack notification sent (status {resp.status_code}).[/success]")
        except Exception as e:
            print_error(f"Failed to send Slack notification: {e}")
            raise typer.Exit(1)
    elif channel == "webhook":
        ch_config = config.get("channels", {}).get("webhook", {})
        url = ch_config.get("url")
        if not url:
            print_error("Webhook not configured.", details="Run: stateset-cua notify config --channel webhook --webhook-url <url>")
            raise typer.Exit(1)
        try:
            import httpx
            resp = httpx.post(url, json={"title": title, "message": message}, timeout=10.0)
            output({"sent": True, "channel": "webhook", "status": resp.status_code},
                   human_format=f"[success]Webhook notification sent (status {resp.status_code}).[/success]")
        except Exception as e:
            print_error(f"Failed to send webhook notification: {e}")
            raise typer.Exit(1)
    else:
        print_error(f"Unknown channel: {channel}", details="Available: console, slack, webhook")
        raise typer.Exit(1)


@notify_app.command("config")
def notify_config(
    channel: Optional[str] = typer.Option(None, "--channel", "-c", help="Channel to configure"),
    webhook_url: Optional[str] = typer.Option(None, "--webhook-url", help="Webhook URL for channel"),
    enable: Optional[bool] = typer.Option(None, "--enable/--disable", help="Enable or disable notifications"),
) -> None:
    """Configure notification channels."""
    config = _load_notify_config()

    if enable is not None:
        config["enabled"] = enable
        _save_notify_config(config)
        state = "enabled" if enable else "disabled"
        output({"enabled": enable}, human_format=f"[success]Notifications {state}.[/success]")
        return

    if channel and webhook_url:
        channels = config.setdefault("channels", {})
        channels.setdefault(channel, {})
        if channel == "slack":
            channels[channel]["webhook_url"] = webhook_url
        else:
            channels[channel]["url"] = webhook_url
        _save_notify_config(config)
        output({"configured": channel},
               human_format=f"[success]Channel '{channel}' configured.[/success]")
        return

    # Show current config
    if is_json_mode():
        output(config)
        return

    from rich.panel import Panel
    lines = [f"[bold]Enabled:[/bold] {config.get('enabled', True)}"]
    for ch_name, ch_conf in config.get("channels", {}).items():
        lines.append(f"[bold]{ch_name}:[/bold] {json.dumps(ch_conf)}")
    if not config.get("channels"):
        lines.append("[dim]No channels configured.[/dim]")
    get_console().print(Panel("\n".join(lines), title="Notification Config", border_style="cyan"))


@notify_app.command("test")
def notify_test(
    channel: str = typer.Option("console", "--channel", "-c", help="Channel to test"),
) -> None:
    """Send a test notification."""
    from cli.commands.notify import notify_send
    notify_send.callback(
        message="This is a test notification from stateset-cua.",
        channel=channel,
        title="Test Notification",
    )
