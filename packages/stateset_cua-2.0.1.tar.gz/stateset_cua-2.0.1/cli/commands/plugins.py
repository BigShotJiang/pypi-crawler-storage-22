"""Plugins command group - manage CLI plugins."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table

plugin_app = typer.Typer(name="plugins", help="Manage CLI plugins")


def _plugins_dir() -> Path:
    d = get_state_dir() / "plugins"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _registry_file() -> Path:
    return _plugins_dir() / "registry.json"


def _load_registry() -> dict:
    path = _registry_file()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return {}


def _save_registry(reg: dict) -> None:
    _registry_file().write_text(json.dumps(reg, indent=2))


@plugin_app.command("list")
def plugin_list() -> None:
    """List installed plugins."""
    registry = _load_registry()

    if not registry:
        output({"plugins": []}, human_format="[dim]No plugins installed.[/dim]")
        return

    if is_json_mode():
        output(registry)
        return

    headers = ["Name", "Version", "Enabled", "Description"]
    rows = []
    for name, info in registry.items():
        rows.append([
            name,
            info.get("version", "?"),
            "[success]yes[/success]" if info.get("enabled", True) else "[dim]no[/dim]",
            info.get("description", ""),
        ])
    rich_table(headers, rows, title="Installed Plugins")


@plugin_app.command("install")
def plugin_install(
    name: str = typer.Argument(..., help="Plugin name or path"),
    version: str = typer.Option("latest", "--version", "-v", help="Plugin version"),
) -> None:
    """Install a plugin."""
    registry = _load_registry()
    registry[name] = {
        "version": version,
        "enabled": True,
        "description": f"Plugin: {name}",
        "installed_at": __import__("datetime").datetime.now().isoformat(),
    }
    _save_registry(registry)
    output({"installed": name, "version": version},
           human_format=f"[success]Plugin '{name}' installed (v{version}).[/success]")


@plugin_app.command("uninstall")
def plugin_uninstall(name: str = typer.Argument(..., help="Plugin name")) -> None:
    """Uninstall a plugin."""
    registry = _load_registry()
    if name not in registry:
        print_error(f"Plugin '{name}' not found.")
        raise typer.Exit(1)
    del registry[name]
    _save_registry(registry)

    # Remove plugin files if they exist
    plugin_dir = _plugins_dir() / name
    if plugin_dir.exists():
        import shutil
        shutil.rmtree(plugin_dir)

    output({"uninstalled": name}, human_format=f"[success]Plugin '{name}' uninstalled.[/success]")


@plugin_app.command("enable")
def plugin_enable(name: str = typer.Argument(..., help="Plugin name")) -> None:
    """Enable a plugin."""
    registry = _load_registry()
    if name not in registry:
        print_error(f"Plugin '{name}' not found.")
        raise typer.Exit(1)
    registry[name]["enabled"] = True
    _save_registry(registry)
    output({"enabled": name}, human_format=f"[success]Plugin '{name}' enabled.[/success]")


@plugin_app.command("disable")
def plugin_disable(name: str = typer.Argument(..., help="Plugin name")) -> None:
    """Disable a plugin."""
    registry = _load_registry()
    if name not in registry:
        print_error(f"Plugin '{name}' not found.")
        raise typer.Exit(1)
    registry[name]["enabled"] = False
    _save_registry(registry)
    output({"disabled": name}, human_format=f"[success]Plugin '{name}' disabled.[/success]")


@plugin_app.command("search")
def plugin_search(query: str = typer.Argument(..., help="Search term")) -> None:
    """Search available plugins (from registry)."""
    # Placeholder: in production this would query a remote registry
    available = [
        {"name": "slack-notifier", "description": "Send Slack notifications on task completion"},
        {"name": "github-issues", "description": "Auto-create GitHub issues from failures"},
        {"name": "csv-export", "description": "Export results to CSV format"},
        {"name": "webhook-relay", "description": "Forward events to webhooks"},
        {"name": "metrics-prometheus", "description": "Prometheus metrics exporter"},
    ]
    matches = [p for p in available if query.lower() in p["name"] or query.lower() in p["description"].lower()]

    if is_json_mode():
        output(matches)
        return

    if not matches:
        get_console().print(f"[dim]No plugins matching '{query}'.[/dim]")
        return

    headers = ["Name", "Description"]
    rows = [[p["name"], p["description"]] for p in matches]
    rich_table(headers, rows, title=f"Plugin Search: '{query}'")
