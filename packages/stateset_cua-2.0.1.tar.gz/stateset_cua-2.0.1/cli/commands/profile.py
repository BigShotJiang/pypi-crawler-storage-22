"""Profile command group - manage execution profiles."""

from __future__ import annotations

import json
from typing import Optional

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table
from cli._profiles import ProfileManager

profile_app = typer.Typer(name="profile", help="Manage execution profiles")


def _mgr() -> ProfileManager:
    return ProfileManager()


@profile_app.command("list")
def profile_list() -> None:
    """List all saved profiles."""
    mgr = _mgr()
    names = mgr.list_profiles()
    active = mgr.get_active_profile()

    if is_json_mode():
        output({"profiles": names, "active": active})
        return

    if not names:
        get_console().print("[dim]No profiles found. Create one with: stateset-cua profile create <name>[/dim]")
        return

    headers = ["Name", "Active", "Agent", "Effort"]
    rows = []
    for name in names:
        data = mgr.get_profile(name) or {}
        rows.append([
            name,
            "[success]yes[/success]" if name == active else "",
            data.get("agent_type", "auto"),
            data.get("effort", "medium"),
        ])
    rich_table(headers, rows, title="Execution Profiles")


@profile_app.command("create")
def profile_create(
    name: str = typer.Argument(..., help="Profile name"),
    agent_type: Optional[str] = typer.Option(None, "--agent", "-a", help="Default agent type"),
    effort: str = typer.Option("medium", "--effort", help="Effort level"),
    tool_version: str = typer.Option("computer_use_20251124", "--tool-version", help="Tool version"),
) -> None:
    """Create a new execution profile."""
    mgr = _mgr()
    profile = {
        "agent_type": agent_type,
        "effort": effort,
        "tool_version": tool_version,
    }
    mgr.save_profile(name, profile)
    output({"created": name, "profile": profile}, human_format=f"[success]Profile '{name}' created.[/success]")


@profile_app.command("use")
def profile_use(name: str = typer.Argument(..., help="Profile name to activate")) -> None:
    """Activate a profile."""
    mgr = _mgr()
    if mgr.get_profile(name) is None:
        print_error(f"Profile '{name}' not found.")
        raise typer.Exit(1)
    mgr.set_active_profile(name)
    output({"active": name}, human_format=f"[success]Active profile set to '{name}'.[/success]")


@profile_app.command("show")
def profile_show(name: str = typer.Argument(..., help="Profile name")) -> None:
    """Show profile details."""
    mgr = _mgr()
    data = mgr.get_profile(name)
    if data is None:
        print_error(f"Profile '{name}' not found.")
        raise typer.Exit(1)

    if is_json_mode():
        output(data)
        return

    from rich.panel import Panel
    lines = [f"[bold]{k}:[/bold] {v}" for k, v in data.items()]
    get_console().print(Panel("\n".join(lines), title=f"Profile: {name}", border_style="cyan"))


@profile_app.command("delete")
def profile_delete(name: str = typer.Argument(..., help="Profile name to delete")) -> None:
    """Delete a profile."""
    mgr = _mgr()
    if mgr.delete_profile(name):
        output({"deleted": name}, human_format=f"[success]Profile '{name}' deleted.[/success]")
    else:
        print_error(f"Profile '{name}' not found.")
        raise typer.Exit(1)
