"""Replay command - re-run a previous task from history."""

from __future__ import annotations

from typing import Optional

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._history import load_history
from cli._output import output


def replay(
    ctx: typer.Context,
    task_id: Optional[str] = typer.Option(None, "--id", help="Task index or timestamp prefix"),
    last: bool = typer.Option(False, "--last", "-l", help="Replay the most recent task"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
) -> None:
    """Re-run a previous task from history."""
    console = get_console()
    entries = load_history(limit=500)

    if not entries:
        print_error("No history entries found.")
        raise typer.Exit(1)

    # Find the entry to replay
    entry = None
    if last:
        entry = entries[-1]
    elif task_id is not None:
        # Try numeric index first
        try:
            idx = int(task_id)
            if 0 <= idx < len(entries):
                entry = entries[idx]
        except ValueError:
            pass

        # Try timestamp prefix match
        if entry is None:
            matches = [e for e in entries if e.get("timestamp", "").startswith(task_id)]
            if matches:
                entry = matches[-1]

    if entry is None:
        print_error("Task not found.", details="Use --last or --id <index>. See 'stateset-cua history' for available tasks.")
        raise typer.Exit(1)

    instruction = entry.get("instruction", "")
    agent_type = entry.get("agent_type", "auto")
    tool_version = entry.get("tool_version", "computer_use_20251124")

    if not instruction:
        print_error("No instruction found in task entry.")
        raise typer.Exit(1)

    if is_json_mode():
        output({"replay": True, "instruction": instruction, "agent_type": agent_type, "dry_run": dry_run})
        if dry_run:
            return
    else:
        from rich.panel import Panel
        console.print(Panel(
            f"[bold]Instruction:[/bold] {instruction}\n"
            f"[bold]Agent:[/bold] {agent_type}\n"
            f"[bold]Tool version:[/bold] {tool_version}",
            title="Replay Task",
            border_style="yellow",
        ))

    if dry_run:
        output({"dry_run": True}, human_format="[dim]Dry run mode - not executing.[/dim]")
        return

    if not is_json_mode():
        if not typer.confirm("Run this task?", default=True):
            raise typer.Abort()

    # Re-invoke the run command
    from cli.commands.run import run as run_cmd
    ctx.invoke(
        run_cmd,
        instruction=[instruction],
        agent_type=agent_type if agent_type != "auto" else None,
        tool_version=tool_version,
    )
