"""Rollback command group - configuration checkpoints."""

from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

import typer

from cli._config import get_config, get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import format_relative_time, output, rich_table

rollback_app = typer.Typer(name="rollback", help="Configuration checkpoint management")


def _checkpoints_dir() -> Path:
    d = get_state_dir() / "checkpoints"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _list_checkpoints() -> list:
    cp_dir = _checkpoints_dir()
    checkpoints = []
    for f in sorted(cp_dir.glob("*.json"), reverse=True):
        try:
            data = json.loads(f.read_text())
            data["file"] = f.name
            checkpoints.append(data)
        except (json.JSONDecodeError, IOError):
            pass
    return checkpoints


@rollback_app.command("list")
def rollback_list() -> None:
    """List configuration checkpoints."""
    checkpoints = _list_checkpoints()

    if not checkpoints:
        output({"checkpoints": []}, human_format="[dim]No checkpoints found. Create one with: stateset-cua rollback create[/dim]")
        return

    if is_json_mode():
        output(checkpoints)
        return

    headers = ["ID", "Label", "Created"]
    rows = []
    for i, cp in enumerate(checkpoints):
        rows.append([
            str(i),
            cp.get("label", "unlabeled"),
            format_relative_time(cp.get("created_at", "")),
        ])
    rich_table(headers, rows, title="Configuration Checkpoints")


@rollback_app.command("create")
def rollback_create(
    label: str = typer.Option("", "--label", "-l", help="Checkpoint label"),
) -> None:
    """Create a configuration checkpoint."""
    cfg = get_config()
    config_data = cfg._load()

    timestamp = datetime.now().isoformat()
    checkpoint = {
        "label": label or f"checkpoint-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
        "created_at": timestamp,
        "config": config_data,
    }

    filename = f"cp-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    cp_path = _checkpoints_dir() / filename
    cp_path.write_text(json.dumps(checkpoint, indent=2, default=str))

    output({"created": filename, "label": checkpoint["label"]},
           human_format=f"[success]Checkpoint created: {checkpoint['label']}[/success]")


@rollback_app.command("to")
def rollback_to(
    checkpoint_id: int = typer.Argument(..., help="Checkpoint ID from list"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Restore configuration from a checkpoint."""
    checkpoints = _list_checkpoints()
    if checkpoint_id < 0 or checkpoint_id >= len(checkpoints):
        print_error(f"Checkpoint {checkpoint_id} not found.")
        raise typer.Exit(1)

    cp = checkpoints[checkpoint_id]
    if not force:
        typer.confirm(f"Restore config from '{cp.get('label', 'unknown')}'?", abort=True)

    cfg = get_config()
    cfg._save(cp["config"])

    output({"restored": cp.get("label")},
           human_format=f"[success]Configuration restored from '{cp.get('label')}'.[/success]")


@rollback_app.command("last")
def rollback_last(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Restore the most recent checkpoint."""
    checkpoints = _list_checkpoints()
    if not checkpoints:
        print_error("No checkpoints available.")
        raise typer.Exit(1)

    cp = checkpoints[0]
    if not force:
        typer.confirm(f"Restore config from '{cp.get('label', 'unknown')}'?", abort=True)

    cfg = get_config()
    cfg._save(cp["config"])

    output({"restored": cp.get("label")},
           human_format=f"[success]Configuration restored from '{cp.get('label')}'.[/success]")
