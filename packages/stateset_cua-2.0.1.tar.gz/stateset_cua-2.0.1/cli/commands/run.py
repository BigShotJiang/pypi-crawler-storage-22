"""Run command - execute agent tasks."""

from __future__ import annotations

import asyncio
from typing import List, Optional

import typer

from cli._console import get_console, is_json_mode
from cli._constants import AGENT_TYPE_MAP, TOOL_VERSIONS
from cli._errors import print_error
from cli._history import add_to_history
from cli._output import output
from cli._streaming import RichStreamingOutput


def run(
    ctx: typer.Context,
    instruction: List[str] = typer.Argument(
        ..., help="Task instruction for the agent",
    ),
    agent_type: Optional[str] = typer.Option(
        None, "--agent", "-a",
        help="Agent type (auto-close, social-media, linkedin, slack, shopify, agentic)",
    ),
    tool_version: str = typer.Option(
        "computer_use_20251124", "--tool-version",
        help="Tool version to use",
    ),
    cli_mode: bool = typer.Option(False, "--cli", help="CLI-only mode (no GUI)"),
    tool_search: Optional[str] = typer.Option(
        None, "--tool-search", help="Tool search variant (regex or bm25)",
    ),
    defer_tool: Optional[List[str]] = typer.Option(
        None, "--defer-tool", help="Tool names to defer loading",
    ),
    effort: Optional[str] = typer.Option(
        None, "--effort", help="Effort level (low, medium, high)",
    ),
    thinking_budget: Optional[int] = typer.Option(
        None, "--thinking-budget", help="Max thinking tokens",
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing"),
    stream: bool = typer.Option(False, "--stream", "-s", help="Stream output in real-time"),
    verbose: bool = typer.Option(False, "--verbose", help="Verbose output"),
) -> None:
    """Run an agent task with the given instruction."""
    console = get_console()
    instruction_text = " ".join(instruction)

    if not instruction_text:
        print_error("No instruction provided", details="Usage: stateset-cua run 'your task'")
        raise typer.Exit(1)

    if cli_mode:
        tool_version = "cli_20250124"

    # Map agent type
    agent_types = None
    if agent_type:
        internal_name = AGENT_TYPE_MAP.get(agent_type)
        if internal_name:
            agent_types = [internal_name]
        else:
            print_error(
                f"Unknown agent type: {agent_type}",
                details=f"Available: {', '.join(AGENT_TYPE_MAP.keys())}",
            )
            raise typer.Exit(1)

    # Dry run
    if dry_run:
        if is_json_mode():
            output({
                "dry_run": True,
                "instruction": instruction_text,
                "tool_version": tool_version,
                "agent_types": agent_types or "auto-detect",
                "effort": effort or "default",
            })
        else:
            from rich.panel import Panel

            body = (
                f"[bold]Instruction:[/bold] {instruction_text}\n"
                f"[bold]Tool version:[/bold] {tool_version}\n"
                f"[bold]Agent:[/bold] {agent_types or 'auto-detect'}\n"
                f"[bold]Effort:[/bold] {effort or 'default'}\n"
                f"[bold]Stream:[/bold] {stream}\n"
                f"[bold]Verbose:[/bold] {verbose}"
            )
            console.print(Panel(body, title="Dry Run", border_style="yellow"))
        return

    # Set up streaming
    streamer = RichStreamingOutput(verbose=verbose) if stream else None

    try:
        from cli._import import get_agent_main
        from agent.types import RuntimeOptions, ToolSearchVariant, EffortLevel

        agent_main = get_agent_main()
        from typing import cast

        options = RuntimeOptions(
            instruction=instruction_text,
            tool_version=cast(str, tool_version),
            agent_types=agent_types,
            tool_search_variant=cast(ToolSearchVariant, tool_search) if tool_search else None,
            tool_search_defer=tuple(defer_tool or []),
            effort_level=cast(EffortLevel, effort) if effort else None,
        )

        if stream and streamer:
            console.print(f"[bold]Task:[/bold] {instruction_text}")
            console.print(f"[dim]Agent: {agent_type or 'auto-detect'}[/dim]")
            console.print()
            streamer.start()

        if not stream and not is_json_mode():
            with console.status(f"[info]Running: {instruction_text[:60]}...[/info]"):
                asyncio.run(agent_main(options))
        else:
            asyncio.run(agent_main(options))

        if streamer:
            streamer.stop(success=True)

        add_to_history({
            "type": "run",
            "instruction": instruction_text,
            "agent_type": agent_type or "auto",
            "tool_version": tool_version,
            "status": "completed",
        })

    except KeyboardInterrupt:
        console.print("\n[warning]Interrupted by user[/warning]")
        if streamer:
            streamer.stop(success=False)
        raise typer.Exit(130)
    except Exception as e:
        print_error(str(e))
        if streamer:
            streamer.stop(success=False)
        raise typer.Exit(1)
