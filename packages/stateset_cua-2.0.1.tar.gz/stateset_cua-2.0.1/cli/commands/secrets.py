"""Secrets sub-app: encrypted credential vault using Fernet encryption."""

from __future__ import annotations

import base64
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table

secrets_app = typer.Typer(name="secrets", help="Manage encrypted secrets vault")


# ---------------------------------------------------------------------------
# Vault management
# ---------------------------------------------------------------------------

def _secrets_dir() -> Path:
    """Return (and create) the secrets directory."""
    d = get_state_dir() / "secrets"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _key_file() -> Path:
    """Return the path to the Fernet encryption key."""
    return _secrets_dir() / ".key"


def _vault_file() -> Path:
    """Return the path to the encrypted vault."""
    return _secrets_dir() / "vault.json"


def _get_or_create_key() -> bytes:
    """Load or generate the Fernet encryption key."""
    try:
        from cryptography.fernet import Fernet
    except ImportError:
        print_error(
            "cryptography package not installed",
            details="Install it with: pip install cryptography",
        )
        raise typer.Exit(1)

    kf = _key_file()
    if kf.exists():
        return kf.read_bytes().strip()

    # Generate a new key
    key = Fernet.generate_key()
    kf.write_bytes(key)
    try:
        kf.chmod(0o600)
    except OSError:
        pass
    return key


def _get_fernet():
    """Create a Fernet instance with the stored key."""
    try:
        from cryptography.fernet import Fernet
    except ImportError:
        print_error(
            "cryptography package not installed",
            details="Install it with: pip install cryptography",
        )
        raise typer.Exit(1)

    key = _get_or_create_key()
    return Fernet(key)


def _load_vault() -> dict:
    """Load and decrypt the vault contents."""
    vf = _vault_file()
    if not vf.exists():
        return {}
    try:
        data = json.loads(vf.read_text())
        return data
    except (json.JSONDecodeError, IOError):
        return {}


def _save_vault(vault: dict) -> None:
    """Save the vault to disk."""
    vf = _vault_file()
    vf.write_text(json.dumps(vault, indent=2, default=str))
    try:
        vf.chmod(0o600)
    except OSError:
        pass


def _encrypt_value(value: str) -> str:
    """Encrypt a value using Fernet."""
    f = _get_fernet()
    return f.encrypt(value.encode()).decode()


def _decrypt_value(encrypted: str) -> str:
    """Decrypt a Fernet-encrypted value."""
    try:
        from cryptography.fernet import InvalidToken
    except ImportError:
        raise typer.Exit(1)

    f = _get_fernet()
    try:
        return f.decrypt(encrypted.encode()).decode()
    except Exception:
        return "<decryption failed>"


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@secrets_app.command("list")
def secrets_list() -> None:
    """List all stored secrets (names only, values hidden)."""
    console = get_console()
    vault = _load_vault()

    if not vault:
        if is_json_mode():
            output({"secrets": [], "count": 0})
        else:
            console.print("[dim]No secrets stored.[/dim]")
            console.print("[dim]Add one with: stateset-cua secrets set <name> <value>[/dim]")
        return

    if is_json_mode():
        secrets_info = []
        for name, entry in vault.items():
            secrets_info.append({
                "name": name,
                "created_at": entry.get("created_at"),
                "updated_at": entry.get("updated_at"),
            })
        output({"secrets": secrets_info, "count": len(secrets_info)})
        return

    headers = ["Name", "Created", "Updated"]
    rows = []
    for name, entry in sorted(vault.items()):
        created = entry.get("created_at", "?")
        updated = entry.get("updated_at", created)
        rows.append([name, created[:19], updated[:19]])

    rich_table(headers, rows, title="Secrets Vault")
    console.print(f"\n[dim]{len(vault)} secret(s) stored[/dim]")


@secrets_app.command("set")
def secrets_set(
    name: str = typer.Argument(..., help="Secret name (e.g. SLACK_BOT_TOKEN)"),
    value: Optional[str] = typer.Argument(
        None, help="Secret value (omit to enter interactively)"
    ),
) -> None:
    """Store an encrypted secret in the vault."""
    console = get_console()

    if value is None:
        if is_json_mode():
            print_error("Value required in JSON mode")
            raise typer.Exit(1)
        value = typer.prompt(f"Enter value for '{name}'", hide_input=True)

    if not value:
        print_error("Empty value not allowed")
        raise typer.Exit(1)

    vault = _load_vault()
    now = datetime.now().isoformat()

    encrypted = _encrypt_value(value)
    is_update = name in vault

    vault[name] = {
        "value": encrypted,
        "created_at": vault.get(name, {}).get("created_at", now),
        "updated_at": now,
    }

    _save_vault(vault)

    action = "updated" if is_update else "stored"
    if is_json_mode():
        output({"name": name, "action": action})
    else:
        console.print(f"[success]Secret '{name}' {action}.[/success]")


@secrets_app.command("get")
def secrets_get(
    name: str = typer.Argument(..., help="Secret name to retrieve"),
    reveal: bool = typer.Option(False, "--reveal", "-r", help="Show the decrypted value"),
) -> None:
    """Retrieve a secret from the vault."""
    console = get_console()
    vault = _load_vault()

    if name not in vault:
        print_error(f"Secret '{name}' not found")
        raise typer.Exit(1)

    entry = vault[name]

    if reveal:
        decrypted = _decrypt_value(entry["value"])
        if is_json_mode():
            output({
                "name": name,
                "value": decrypted,
                "created_at": entry.get("created_at"),
            })
        else:
            console.print(f"[bold]{name}[/bold] = {decrypted}")
    else:
        masked = "********"
        if is_json_mode():
            output({
                "name": name,
                "value": masked,
                "created_at": entry.get("created_at"),
                "hint": "Use --reveal to see the actual value",
            })
        else:
            console.print(f"[bold]{name}[/bold] = [dim]{masked}[/dim]")
            console.print("[dim]Use --reveal to show the actual value.[/dim]")


@secrets_app.command("delete")
def secrets_delete(
    name: str = typer.Argument(..., help="Secret name to delete"),
) -> None:
    """Delete a secret from the vault."""
    console = get_console()
    vault = _load_vault()

    if name not in vault:
        print_error(f"Secret '{name}' not found")
        raise typer.Exit(1)

    del vault[name]
    _save_vault(vault)

    if is_json_mode():
        output({"deleted": name})
    else:
        console.print(f"[success]Secret '{name}' deleted.[/success]")


@secrets_app.command("export")
def secrets_export(
    file: Optional[str] = typer.Option(
        None, "--file", "-f", help="Export to file (default: stdout)"
    ),
    decrypt: bool = typer.Option(False, "--decrypt", help="Export decrypted values"),
) -> None:
    """Export secrets (encrypted by default)."""
    console = get_console()
    vault = _load_vault()

    if not vault:
        if is_json_mode():
            output({"message": "No secrets to export"})
        else:
            console.print("[dim]No secrets to export.[/dim]")
        return

    export_data = {}
    for name, entry in vault.items():
        if decrypt:
            export_data[name] = _decrypt_value(entry["value"])
        else:
            export_data[name] = entry

    serialized = json.dumps(export_data, indent=2, default=str)

    if file:
        output_path = Path(file)
        output_path.write_text(serialized)
        try:
            output_path.chmod(0o600)
        except OSError:
            pass

        if is_json_mode():
            output({"exported": len(vault), "file": str(output_path)})
        else:
            console.print(
                f"[success]Exported {len(vault)} secret(s) to {output_path}[/success]"
            )
    else:
        if is_json_mode():
            output(export_data)
        else:
            console.print(serialized)


@secrets_app.command("import")
def secrets_import(
    file: str = typer.Argument(..., help="Path to JSON file to import"),
    encrypted: bool = typer.Option(
        False, "--encrypted", help="File contains encrypted values (from export)"
    ),
) -> None:
    """Import secrets from a JSON file."""
    console = get_console()
    input_path = Path(file)

    if not input_path.exists():
        print_error(f"File not found: {file}")
        raise typer.Exit(1)

    try:
        import_data = json.loads(input_path.read_text())
    except (json.JSONDecodeError, IOError) as exc:
        print_error("Invalid JSON file", details=str(exc))
        raise typer.Exit(1)

    if not isinstance(import_data, dict):
        print_error("Expected a JSON object mapping names to values")
        raise typer.Exit(1)

    vault = _load_vault()
    now = datetime.now().isoformat()
    imported = 0

    for name, value in import_data.items():
        if encrypted and isinstance(value, dict):
            # Import as-is (already encrypted)
            vault[name] = value
        elif isinstance(value, str):
            # Encrypt plain-text values
            vault[name] = {
                "value": _encrypt_value(value),
                "created_at": now,
                "updated_at": now,
            }
        else:
            continue
        imported += 1

    _save_vault(vault)

    if is_json_mode():
        output({"imported": imported, "total": len(vault)})
    else:
        console.print(
            f"[success]Imported {imported} secret(s). "
            f"Vault now has {len(vault)} total.[/success]"
        )
