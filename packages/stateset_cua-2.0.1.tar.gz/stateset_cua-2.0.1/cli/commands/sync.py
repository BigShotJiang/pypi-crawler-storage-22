"""Sync command group - configuration sync."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_config, get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table

sync_app = typer.Typer(name="sync", help="Sync configuration across environments")


def _sync_dir() -> Path:
    d = get_state_dir() / "sync"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _file_hash(path: Path) -> str:
    if not path.exists():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()[:12]


def _sync_manifest() -> Path:
    return _sync_dir() / "manifest.json"


def _load_manifest() -> dict:
    path = _sync_manifest()
    if not path.exists():
        return {"remote_path": None, "last_sync": None, "files": {}}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return {"remote_path": None, "last_sync": None, "files": {}}


def _save_manifest(manifest: dict) -> None:
    _sync_manifest().write_text(json.dumps(manifest, indent=2, default=str))


_SYNC_FILES = ["config.yaml", "config.json", "profiles/", "plugins/registry.json", "notify.json"]


@sync_app.command("status")
def sync_status() -> None:
    """Show sync status."""
    manifest = _load_manifest()
    state_dir = get_state_dir()

    local_files = {}
    for name in _SYNC_FILES:
        path = state_dir / name
        if path.exists():
            local_files[name] = _file_hash(path) if path.is_file() else "dir"

    data = {
        "remote_path": manifest.get("remote_path"),
        "last_sync": manifest.get("last_sync"),
        "local_files": local_files,
        "tracked_files": manifest.get("files", {}),
    }

    if is_json_mode():
        output(data)
        return

    from rich.panel import Panel

    lines = [
        f"[bold]Remote:[/bold] {manifest.get('remote_path') or 'not configured'}",
        f"[bold]Last sync:[/bold] {manifest.get('last_sync') or 'never'}",
        f"[bold]Local files:[/bold] {len(local_files)}",
        f"[bold]Tracked files:[/bold] {len(manifest.get('files', {}))}",
    ]
    get_console().print(Panel("\n".join(lines), title="Sync Status", border_style="cyan"))


@sync_app.command("push")
def sync_push() -> None:
    """Push local configuration to sync directory."""
    manifest = _load_manifest()
    remote = manifest.get("remote_path")
    if not remote:
        print_error("Sync not set up.", details="Run: stateset-cua sync setup <path>")
        raise typer.Exit(1)

    state_dir = get_state_dir()
    remote_path = Path(remote)
    remote_path.mkdir(parents=True, exist_ok=True)
    pushed = 0

    for name in _SYNC_FILES:
        src = state_dir / name
        dst = remote_path / name
        if src.is_file() and src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            manifest.setdefault("files", {})[name] = _file_hash(src)
            pushed += 1
        elif src.is_dir() and src.exists():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            pushed += 1

    from datetime import datetime
    manifest["last_sync"] = datetime.now().isoformat()
    _save_manifest(manifest)

    output({"pushed": pushed}, human_format=f"[success]Pushed {pushed} items to {remote}.[/success]")


@sync_app.command("pull")
def sync_pull() -> None:
    """Pull configuration from sync directory."""
    manifest = _load_manifest()
    remote = manifest.get("remote_path")
    if not remote:
        print_error("Sync not set up.", details="Run: stateset-cua sync setup <path>")
        raise typer.Exit(1)

    state_dir = get_state_dir()
    remote_path = Path(remote)
    pulled = 0

    for name in _SYNC_FILES:
        src = remote_path / name
        dst = state_dir / name
        if src.is_file() and src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            pulled += 1
        elif src.is_dir() and src.exists():
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            pulled += 1

    from datetime import datetime
    manifest["last_sync"] = datetime.now().isoformat()
    _save_manifest(manifest)

    output({"pulled": pulled}, human_format=f"[success]Pulled {pulled} items from {remote}.[/success]")


@sync_app.command("diff")
def sync_diff() -> None:
    """Show differences between local and synced config."""
    manifest = _load_manifest()
    remote = manifest.get("remote_path")
    if not remote:
        print_error("Sync not set up.")
        raise typer.Exit(1)

    state_dir = get_state_dir()
    remote_path = Path(remote)
    diffs = []

    for name in _SYNC_FILES:
        local = state_dir / name
        remote_f = remote_path / name
        local_hash = _file_hash(local) if local.is_file() else ("dir" if local.is_dir() else "missing")
        remote_hash = _file_hash(remote_f) if remote_f.is_file() else ("dir" if remote_f.is_dir() else "missing")
        status = "same" if local_hash == remote_hash else "changed"
        diffs.append({"file": name, "local": local_hash, "remote": remote_hash, "status": status})

    if is_json_mode():
        output(diffs)
        return

    headers = ["File", "Local", "Remote", "Status"]
    rows = [[d["file"], d["local"][:8], d["remote"][:8],
             f"[success]{d['status']}[/success]" if d["status"] == "same" else f"[warning]{d['status']}[/warning]"]
            for d in diffs]
    rich_table(headers, rows, title="Sync Diff")


@sync_app.command("setup")
def sync_setup(path: str = typer.Argument(..., help="Remote sync directory path")) -> None:
    """Set up sync with a directory."""
    manifest = _load_manifest()
    manifest["remote_path"] = str(Path(path).resolve())
    _save_manifest(manifest)
    Path(path).mkdir(parents=True, exist_ok=True)
    output({"remote_path": manifest["remote_path"]},
           human_format=f"[success]Sync configured with: {manifest['remote_path']}[/success]")
