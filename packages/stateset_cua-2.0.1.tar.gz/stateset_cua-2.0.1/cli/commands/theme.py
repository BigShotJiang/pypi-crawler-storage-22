"""Theme command group - terminal theme management."""

from __future__ import annotations

import typer

from cli._config import get_config
from cli._console import get_console, is_json_mode
from cli._output import output, rich_table

theme_app = typer.Typer(name="theme", help="Manage terminal themes")

THEMES = {
    "default": {"primary": "cyan", "success": "green", "warning": "yellow", "error": "red"},
    "ocean": {"primary": "blue", "success": "cyan", "warning": "yellow", "error": "red"},
    "forest": {"primary": "green", "success": "bright_green", "warning": "yellow", "error": "red"},
    "sunset": {"primary": "bright_red", "success": "yellow", "warning": "bright_yellow", "error": "red"},
    "mono": {"primary": "white", "success": "bright_white", "warning": "white", "error": "bright_white"},
    "nord": {"primary": "#88C0D0", "success": "#A3BE8C", "warning": "#EBCB8B", "error": "#BF616A"},
}


@theme_app.command("list")
def theme_list() -> None:
    """List available themes."""
    cfg = get_config()
    active = cfg.get("theme", "default")

    if is_json_mode():
        output({"themes": list(THEMES.keys()), "active": active})
        return

    headers = ["Theme", "Active", "Primary", "Success", "Warning", "Error"]
    rows = []
    for name, colors in THEMES.items():
        rows.append([
            name,
            "[success]yes[/success]" if name == active else "",
            colors["primary"],
            colors["success"],
            colors["warning"],
            colors["error"],
        ])
    rich_table(headers, rows, title="Available Themes")


@theme_app.command("set")
def theme_set(name: str = typer.Argument(..., help="Theme name")) -> None:
    """Set the active theme."""
    if name not in THEMES:
        from cli._errors import print_error
        print_error(f"Unknown theme: {name}", details=f"Available: {', '.join(THEMES)}")
        raise typer.Exit(1)

    cfg = get_config()
    cfg.set("theme", name)
    output({"theme": name}, human_format=f"[success]Theme set to '{name}'. Restart CLI to apply.[/success]")


@theme_app.command("preview")
def theme_preview(name: str = typer.Argument("default", help="Theme name to preview")) -> None:
    """Preview a theme's colors."""
    if name not in THEMES:
        from cli._errors import print_error
        print_error(f"Unknown theme: {name}")
        raise typer.Exit(1)

    colors = THEMES[name]
    if is_json_mode():
        output({"theme": name, "colors": colors})
        return

    console = get_console()
    from rich.panel import Panel

    lines = []
    for role, color in colors.items():
        lines.append(f"[{color}]{role}: This is {color} text[/{color}]")

    console.print(Panel("\n".join(lines), title=f"Theme Preview: {name}", border_style="cyan"))


@theme_app.command("reset")
def theme_reset() -> None:
    """Reset to default theme."""
    cfg = get_config()
    cfg.set("theme", "default")
    output({"theme": "default"}, human_format="[success]Theme reset to default.[/success]")
