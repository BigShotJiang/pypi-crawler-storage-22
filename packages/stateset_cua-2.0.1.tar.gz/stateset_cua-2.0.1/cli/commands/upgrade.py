"""Upgrade command - check for and install CLI updates."""

from __future__ import annotations

import subprocess
import sys

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output
from cli._version import __version__


def upgrade(
    ctx: typer.Context,
    check_only: bool = typer.Option(False, "--check", "-c", help="Check for updates without installing"),
    pre: bool = typer.Option(False, "--pre", help="Include pre-release versions"),
) -> None:
    """Check for and install CLI updates from PyPI."""
    console = get_console()
    package = "stateset-cua"

    if not is_json_mode():
        console.print(f"[dim]Current version: {__version__}[/dim]")
        console.print("[dim]Checking for updates...[/dim]")

    # Check latest version on PyPI
    latest = None
    try:
        import httpx
        resp = httpx.get(f"https://pypi.org/pypi/{package}/json", timeout=10.0)
        if resp.is_success:
            data = resp.json()
            latest = data.get("info", {}).get("version", "")
    except ImportError:
        # Fallback: use pip index
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "index", "versions", package],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if "LATEST" in line.upper() or "Available" in line:
                        parts = line.strip().split()
                        if parts:
                            latest = parts[-1].strip("()")
                            break
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
    except Exception:
        pass

    if not latest:
        output(
            {"current": __version__, "latest": None, "error": "Could not check for updates"},
            human_format="[warning]Could not check for updates. Check your internet connection.[/warning]",
        )
        return

    is_up_to_date = latest == __version__

    if is_up_to_date:
        output(
            {"current": __version__, "latest": latest, "up_to_date": True},
            human_format=f"[success]Already up to date (v{__version__}).[/success]",
        )
        return

    if check_only:
        output(
            {"current": __version__, "latest": latest, "up_to_date": False},
            human_format=f"[warning]Update available: {__version__} -> {latest}[/warning]",
        )
        return

    # Install update
    if not is_json_mode():
        console.print(f"[info]Updating {__version__} -> {latest}...[/info]")

    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", package]
    if pre:
        cmd.append("--pre")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode == 0:
            output(
                {"current": __version__, "updated_to": latest, "success": True},
                human_format=f"[success]Updated to v{latest}. Restart the CLI to use the new version.[/success]",
            )
        else:
            print_error(f"Update failed: {result.stderr.strip()}")
            raise typer.Exit(1)
    except subprocess.TimeoutExpired:
        print_error("Update timed out.")
        raise typer.Exit(1)
