"""Version command."""

import json
import typer

from cli._version import __version__, __package_name__
from cli._console import get_console, is_json_mode


def version_cmd(ctx: typer.Context) -> None:
    """Show the CLI version."""
    console = get_console()
    if is_json_mode():
        console.print_json(json.dumps({
            "version": __version__,
            "package": __package_name__,
        }))
    else:
        console.print(f"[bold]{__package_name__}[/bold] [dim]v{__version__}[/dim]")
