"""Webhook command group - manage webhooks."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from cli._config import get_state_dir
from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import format_relative_time, output, rich_table

webhook_app = typer.Typer(name="webhook", help="Manage webhooks")


def _webhooks_file() -> Path:
    d = get_state_dir() / "webhooks"
    d.mkdir(parents=True, exist_ok=True)
    return d / "config.json"


def _load_webhooks() -> list:
    path = _webhooks_file()
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, IOError):
        return []


def _save_webhooks(hooks: list) -> None:
    _webhooks_file().write_text(json.dumps(hooks, indent=2, default=str))


@webhook_app.command("list")
def webhook_list() -> None:
    """List configured webhooks."""
    hooks = _load_webhooks()

    if not hooks:
        output({"webhooks": []}, human_format="[dim]No webhooks configured.[/dim]")
        return

    if is_json_mode():
        output(hooks)
        return

    headers = ["ID", "URL", "Events", "Created"]
    rows = []
    for i, h in enumerate(hooks):
        rows.append([
            str(i),
            h.get("url", "")[:50],
            ", ".join(h.get("events", ["all"])),
            format_relative_time(h.get("created_at", "")),
        ])
    rich_table(headers, rows, title="Webhooks")


@webhook_app.command("add")
def webhook_add(
    url: str = typer.Argument(..., help="Webhook URL"),
    events: str = typer.Option("all", "--events", "-e", help="Comma-separated events to trigger on"),
    secret: Optional[str] = typer.Option(None, "--secret", "-s", help="Webhook secret for signing"),
) -> None:
    """Add a new webhook."""
    hooks = _load_webhooks()
    hook = {
        "url": url,
        "events": [e.strip() for e in events.split(",")],
        "secret": secret,
        "created_at": datetime.now().isoformat(),
    }
    hooks.append(hook)
    _save_webhooks(hooks)
    output({"added": url, "events": hook["events"]},
           human_format=f"[success]Webhook added: {url}[/success]")


@webhook_app.command("remove")
def webhook_remove(
    webhook_id: int = typer.Argument(..., help="Webhook ID (from list)"),
) -> None:
    """Remove a webhook."""
    hooks = _load_webhooks()
    if webhook_id < 0 or webhook_id >= len(hooks):
        print_error(f"Webhook ID {webhook_id} not found.")
        raise typer.Exit(1)

    removed = hooks.pop(webhook_id)
    _save_webhooks(hooks)
    output({"removed": removed["url"]},
           human_format=f"[success]Webhook removed: {removed['url']}[/success]")


@webhook_app.command("test")
def webhook_test(
    webhook_id: int = typer.Argument(..., help="Webhook ID to test"),
) -> None:
    """Send a test event to a webhook."""
    hooks = _load_webhooks()
    if webhook_id < 0 or webhook_id >= len(hooks):
        print_error(f"Webhook ID {webhook_id} not found.")
        raise typer.Exit(1)

    hook = hooks[webhook_id]
    console = get_console()

    try:
        import httpx

        payload = {"event": "test", "timestamp": datetime.now().isoformat(), "message": "Test webhook from stateset-cua"}
        resp = httpx.post(hook["url"], json=payload, timeout=10.0)
        result = {"url": hook["url"], "status": resp.status_code, "success": resp.is_success}
        output(result, human_format=f"[success]Test sent to {hook['url']} - Status: {resp.status_code}[/success]")
    except ImportError:
        print_error("httpx not installed", details="pip install httpx")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Webhook test failed: {e}")
        raise typer.Exit(1)


@webhook_app.command("logs")
def webhook_logs(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of log entries"),
) -> None:
    """Show webhook delivery logs."""
    logs_file = get_state_dir() / "webhooks" / "logs.json"
    if not logs_file.exists():
        output({"logs": []}, human_format="[dim]No webhook logs found.[/dim]")
        return

    try:
        logs = json.loads(logs_file.read_text())[-limit:]
    except (json.JSONDecodeError, IOError):
        logs = []

    if is_json_mode():
        output(logs)
        return

    if not logs:
        get_console().print("[dim]No webhook logs found.[/dim]")
        return

    headers = ["Time", "URL", "Event", "Status"]
    rows = []
    for log in reversed(logs):
        rows.append([
            format_relative_time(log.get("timestamp", "")),
            log.get("url", "")[:40],
            log.get("event", ""),
            str(log.get("status", "")),
        ])
    rich_table(headers, rows, title="Webhook Logs")
