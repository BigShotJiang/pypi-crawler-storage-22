"""Wizard command - interactive step-by-step task builder."""

from __future__ import annotations

import typer

from cli._console import get_console, is_json_mode
from cli._constants import AGENT_TYPE_MAP, TOOL_VERSIONS
from cli._output import output


def wizard(ctx: typer.Context) -> None:
    """Interactive step-by-step task builder."""
    console = get_console()

    if is_json_mode():
        output({"error": "Wizard requires interactive mode. Remove --json flag."})
        raise typer.Exit(1)

    console.print("[bold]Task Builder Wizard[/bold]\n")
    console.print("[dim]Answer the following questions to configure your task.[/dim]\n")

    # Step 1: Task instruction
    instruction = typer.prompt("What task should the agent perform?")

    # Step 2: Agent type
    agent_choices = list(AGENT_TYPE_MAP.keys())
    console.print(f"\n[bold]Available agents:[/bold] {', '.join(agent_choices)}")
    agent_type = typer.prompt(
        "Which agent type? (leave empty for auto-detect)",
        default="",
    )
    if agent_type and agent_type not in agent_choices:
        console.print(f"[warning]Unknown agent '{agent_type}', using auto-detect.[/warning]")
        agent_type = ""

    # Step 3: Effort level
    effort = typer.prompt(
        "Effort level (low/medium/high)",
        default="medium",
    )
    if effort not in ("low", "medium", "high"):
        effort = "medium"

    # Step 4: Tool version
    console.print(f"\n[bold]Tool versions:[/bold] {', '.join(TOOL_VERSIONS)}")
    tool_version = typer.prompt(
        "Tool version",
        default="computer_use_20251124",
    )

    # Step 5: CLI mode
    cli_mode = typer.confirm("Run in CLI-only mode (no GUI)?", default=False)

    # Step 6: Streaming
    stream = typer.confirm("Enable streaming output?", default=False)

    # Build command
    parts = ["stateset-cua", "run"]
    if agent_type:
        parts.extend(["--agent", agent_type])
    parts.extend(["--effort", effort])
    parts.extend(["--tool-version", tool_version])
    if cli_mode:
        parts.append("--cli")
    if stream:
        parts.append("--stream")
    parts.append(f'"{instruction}"')

    command = " ".join(parts)

    console.print()
    from rich.panel import Panel
    console.print(Panel(
        f"[bold]Command:[/bold]\n{command}\n\n"
        f"[bold]Instruction:[/bold] {instruction}\n"
        f"[bold]Agent:[/bold] {agent_type or 'auto-detect'}\n"
        f"[bold]Effort:[/bold] {effort}\n"
        f"[bold]Tool version:[/bold] {tool_version}\n"
        f"[bold]CLI mode:[/bold] {cli_mode}\n"
        f"[bold]Stream:[/bold] {stream}",
        title="Task Configuration",
        border_style="cyan",
    ))

    if typer.confirm("\nRun this task now?", default=False):
        # Execute the task
        import subprocess
        import sys
        subprocess.run([sys.executable, "-m", "cli._app"] + parts[1:])
    else:
        console.print(f"\n[dim]Run it later with:[/dim]\n  {command}")
