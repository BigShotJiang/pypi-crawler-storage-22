"""Workspace command group - manage workspace directory."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import output, rich_table

workspace_app = typer.Typer(name="workspace", help="Manage agent workspace")


def _workspace_path() -> Path:
    return Path(os.environ.get("WORKSPACE_PATH", os.getcwd()))


@workspace_app.command("info")
def workspace_info() -> None:
    """Show workspace directory info."""
    ws = _workspace_path()

    if not ws.exists():
        print_error(f"Workspace not found: {ws}")
        raise typer.Exit(1)

    usage = shutil.disk_usage(str(ws))
    file_count = sum(1 for _ in ws.rglob("*") if _.is_file())
    dir_count = sum(1 for _ in ws.rglob("*") if _.is_dir())

    info = {
        "path": str(ws),
        "exists": True,
        "files": file_count,
        "directories": dir_count,
        "disk_total_gb": round(usage.total / (1024 ** 3), 1),
        "disk_used_gb": round(usage.used / (1024 ** 3), 1),
        "disk_free_gb": round(usage.free / (1024 ** 3), 1),
    }

    if is_json_mode():
        output(info)
        return

    from rich.panel import Panel

    lines = [f"[bold]{k.replace('_', ' ').title()}:[/bold] {v}" for k, v in info.items()]
    get_console().print(Panel("\n".join(lines), title="Workspace Info", border_style="cyan"))


@workspace_app.command("open")
def workspace_open() -> None:
    """Open workspace directory in file manager."""
    ws = _workspace_path()
    import subprocess
    import sys

    if sys.platform == "darwin":
        subprocess.run(["open", str(ws)])
    elif sys.platform == "linux":
        subprocess.run(["xdg-open", str(ws)])
    else:
        subprocess.run(["explorer", str(ws)])

    output({"opened": str(ws)}, human_format=f"[success]Opened {ws}[/success]")


@workspace_app.command("clear")
def workspace_clear(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Clear temporary files from workspace."""
    ws = _workspace_path()
    temp_patterns = ["*.tmp", "*.pyc", "__pycache__", ".cache"]
    removed = 0

    if not force:
        typer.confirm(f"Clear temporary files from {ws}?", abort=True)

    for pattern in temp_patterns:
        for item in ws.rglob(pattern):
            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
                removed += 1
            except OSError:
                pass

    output({"removed": removed}, human_format=f"[success]Removed {removed} temporary items.[/success]")


@workspace_app.command("list")
def workspace_list(
    pattern: str = typer.Option("*", "--pattern", "-p", help="Glob pattern"),
    limit: int = typer.Option(30, "--limit", "-n", help="Max entries"),
) -> None:
    """List files in the workspace."""
    ws = _workspace_path()
    files = sorted(ws.glob(pattern))[:limit]

    if is_json_mode():
        output([{"name": f.name, "type": "dir" if f.is_dir() else "file", "size": f.stat().st_size if f.is_file() else 0} for f in files])
        return

    headers = ["Name", "Type", "Size"]
    rows = []
    for f in files:
        ftype = "dir" if f.is_dir() else "file"
        size = f"{f.stat().st_size} B" if f.is_file() else "-"
        rows.append([f.name, ftype, size])
    rich_table(headers, rows, title=f"Workspace: {ws}")
