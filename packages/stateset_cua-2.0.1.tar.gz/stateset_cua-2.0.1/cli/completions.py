"""
Shell completion scripts for the StateSet CLI.

Generate completions with:
    stateset --completions bash > ~/.local/share/bash-completion/completions/stateset
    stateset --completions zsh > ~/.zfunc/_stateset
    stateset --completions fish > ~/.config/fish/completions/stateset.fish
"""

BASH_COMPLETION = '''
# Bash completion for stateset
# Add to ~/.bashrc: eval "$(stateset completions bash)"

_stateset_completions() {
    local cur prev opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"

    # Top-level commands
    local commands="run chat agents config check version status stop logs history init mcp doctor metrics templates alias replay upgrade watch profile export context benchmark plugin theme wizard schedule webhook secrets workspace notify audit cache completion login whoami env tail inspect rollback sync api events"

    # Agent types
    local agents="auto-close social-media onboarding linkedin slack shopify agentic"

    # Tool versions
    local tool_versions="computer_use_20251124 computer_use_20250124 computer_use_20241022 cli_20250124"

    # Effort levels
    local effort_levels="low medium high"

    # MCP presets
    local mcp_presets="slack github postgres filesystem brave-search puppeteer"

    # Log levels
    local log_levels="debug info warning error"

    case "${prev}" in
        stateset)
            COMPREPLY=( $(compgen -W "${commands}" -- ${cur}) )
            return 0
            ;;
        run)
            COMPREPLY=( $(compgen -W "--agent -a --tool-version --cli --effort --tool-search --defer-tool --dry-run --stream -s --verbose -v" -- ${cur}) )
            return 0
            ;;
        chat)
            COMPREPLY=( $(compgen -W "--agent -a --cli --effort" -- ${cur}) )
            return 0
            ;;
        --agent|-a)
            COMPREPLY=( $(compgen -W "${agents}" -- ${cur}) )
            return 0
            ;;
        --tool-version)
            COMPREPLY=( $(compgen -W "${tool_versions}" -- ${cur}) )
            return 0
            ;;
        --effort)
            COMPREPLY=( $(compgen -W "${effort_levels}" -- ${cur}) )
            return 0
            ;;
        --tool-search)
            COMPREPLY=( $(compgen -W "regex bm25" -- ${cur}) )
            return 0
            ;;
        --level)
            COMPREPLY=( $(compgen -W "${log_levels}" -- ${cur}) )
            return 0
            ;;
        --status)
            COMPREPLY=( $(compgen -W "success failed running" -- ${cur}) )
            return 0
            ;;
        agents)
            COMPREPLY=( $(compgen -W "list" -- ${cur}) )
            return 0
            ;;
        config)
            COMPREPLY=( $(compgen -W "show check env" -- ${cur}) )
            return 0
            ;;
        status)
            COMPREPLY=( $(compgen -W "--all -a" -- ${cur}) )
            return 0
            ;;
        stop)
            COMPREPLY=( $(compgen -W "--force" -- ${cur}) )
            return 0
            ;;
        logs)
            COMPREPLY=( $(compgen -W "--follow -f --lines -n --level" -- ${cur}) )
            return 0
            ;;
        history)
            COMPREPLY=( $(compgen -W "--limit -n --agent --status" -- ${cur}) )
            return 0
            ;;
        init)
            COMPREPLY=( $(compgen -W "--force" -- ${cur}) )
            return 0
            ;;
        mcp)
            COMPREPLY=( $(compgen -W "list add remove status" -- ${cur}) )
            return 0
            ;;
        add)
            COMPREPLY=( $(compgen -W "${mcp_presets} --preset" -- ${cur}) )
            return 0
            ;;
        remove)
            COMPREPLY=( $(compgen -W "${mcp_presets}" -- ${cur}) )
            return 0
            ;;
        doctor)
            COMPREPLY=( $(compgen -W "--fix" -- ${cur}) )
            return 0
            ;;
        metrics)
            COMPREPLY=( $(compgen -W "--period --reset" -- ${cur}) )
            return 0
            ;;
        --period)
            COMPREPLY=( $(compgen -W "day week month all" -- ${cur}) )
            return 0
            ;;
        templates)
            COMPREPLY=( $(compgen -W "list save run delete show" -- ${cur}) )
            return 0
            ;;
        alias)
            COMPREPLY=( $(compgen -W "list set remove" -- ${cur}) )
            return 0
            ;;
        replay)
            COMPREPLY=( $(compgen -W "--modify" -- ${cur}) )
            return 0
            ;;
        upgrade)
            COMPREPLY=( $(compgen -W "--check" -- ${cur}) )
            return 0
            ;;
        watch)
            COMPREPLY=( $(compgen -W "--interval" -- ${cur}) )
            return 0
            ;;
        profile)
            COMPREPLY=( $(compgen -W "list create use show delete edit" -- ${cur}) )
            return 0
            ;;
        export)
            COMPREPLY=( $(compgen -W "history logs metrics config" -- ${cur}) )
            return 0
            ;;
        context)
            COMPREPLY=( $(compgen -W "list show clear save load export" -- ${cur}) )
            return 0
            ;;
        benchmark)
            COMPREPLY=( $(compgen -W "list run history" -- ${cur}) )
            return 0
            ;;
        plugin)
            COMPREPLY=( $(compgen -W "list install uninstall enable disable search" -- ${cur}) )
            return 0
            ;;
        theme)
            COMPREPLY=( $(compgen -W "list set show" -- ${cur}) )
            return 0
            ;;
        wizard)
            COMPREPLY=( $(compgen -W "--agent --template" -- ${cur}) )
            return 0
            ;;
        schedule)
            COMPREPLY=( $(compgen -W "list add remove enable pause run show history" -- ${cur}) )
            return 0
            ;;
        webhook)
            COMPREPLY=( $(compgen -W "list create delete show test logs regenerate" -- ${cur}) )
            return 0
            ;;
        secrets)
            COMPREPLY=( $(compgen -W "list set get delete export import" -- ${cur}) )
            return 0
            ;;
        workspace)
            COMPREPLY=( $(compgen -W "list current create use delete show edit" -- ${cur}) )
            return 0
            ;;
        notify)
            COMPREPLY=( $(compgen -W "list add remove test enable disable show" -- ${cur}) )
            return 0
            ;;
        audit)
            COMPREPLY=( $(compgen -W "log export search stats retention" -- ${cur}) )
            return 0
            ;;
        cache)
            COMPREPLY=( $(compgen -W "stats clear show config" -- ${cur}) )
            return 0
            ;;
        completion)
            COMPREPLY=( $(compgen -W "install show status" -- ${cur}) )
            return 0
            ;;
        login)
            COMPREPLY=( $(compgen -W "--key --check --logout" -- ${cur}) )
            return 0
            ;;
        whoami)
            COMPREPLY=( $(compgen -W "--verbose" -- ${cur}) )
            return 0
            ;;
        env)
            COMPREPLY=( $(compgen -W "list get set unset export check" -- ${cur}) )
            return 0
            ;;
        tail)
            COMPREPLY=( $(compgen -W "--filter --no-color" -- ${cur}) )
            return 0
            ;;
        inspect)
            COMPREPLY=( $(compgen -W "task agent config system tools" -- ${cur}) )
            return 0
            ;;
        rollback)
            COMPREPLY=( $(compgen -W "list create to last" -- ${cur}) )
            return 0
            ;;
        sync)
            COMPREPLY=( $(compgen -W "status setup push pull diff" -- ${cur}) )
            return 0
            ;;
        api)
            COMPREPLY=( $(compgen -W "messages models usage limits" -- ${cur}) )
            return 0
            ;;
        events)
            COMPREPLY=( $(compgen -W "list watch clear subscribe" -- ${cur}) )
            return 0
            ;;
    esac

    # Default to commands if at start
    if [[ ${COMP_CWORD} -eq 1 ]]; then
        COMPREPLY=( $(compgen -W "${commands} --help --version --quiet --json" -- ${cur}) )
    fi

    return 0
}

complete -F _stateset_completions stateset
complete -F _stateset_completions stateset-agent
'''

ZSH_COMPLETION = '''
#compdef stateset stateset-agent
# Zsh completion for stateset
# Add to ~/.zshrc: eval "$(stateset completions zsh)"

_stateset() {
    local -a commands agents tool_versions effort_levels mcp_presets log_levels

    commands=(
        'run:Run an agent with a task instruction'
        'chat:Start an interactive chat session'
        'agents:List and manage agent types'
        'config:Show and manage configuration'
        'check:Validate environment setup'
        'version:Show version information'
        'status:Show status of running agents'
        'stop:Stop running agents'
        'logs:View agent execution logs'
        'history:Show task execution history'
        'init:Initialize project configuration'
        'mcp:Manage MCP servers'
        'doctor:Run comprehensive diagnostics'
        'metrics:Show usage statistics'
        'templates:Manage task templates'
        'alias:Manage command aliases'
        'replay:Re-run previous tasks'
        'upgrade:Check for and install updates'
        'watch:Monitor agent execution in real-time'
        'profile:Manage configuration profiles'
        'export:Export task results, logs, and data'
        'context:Manage agent context and memory'
        'benchmark:Run performance benchmarks'
        'plugin:Manage CLI plugins and extensions'
        'theme:Customize CLI appearance'
        'wizard:Interactive task builder wizard'
        'schedule:Schedule recurring tasks with cron'
        'webhook:Manage webhook endpoints'
        'secrets:Securely manage credentials'
        'workspace:Manage project workspaces'
        'notify:Configure notification channels'
        'audit:View audit logs and compliance'
        'cache:Manage CLI caches'
        'completion:Manage shell completions'
        'login:Authenticate with Anthropic API'
        'whoami:Show current identity and config'
        'env:Manage environment variables'
        'tail:Stream real-time task output'
        'inspect:Inspect tasks, agents, and config'
        'rollback:Revert configuration changes'
        'sync:Synchronize configuration'
        'api:Make direct API calls'
        'events:View and manage system events'
    )

    agents=(
        'auto-close:Auto-close support tickets'
        'social-media:Social media moderation'
        'onboarding:User onboarding workflows'
        'linkedin:LinkedIn messaging automation'
        'slack:Slack support management'
        'shopify:E-commerce operations'
        'agentic:General-purpose agentic tasks'
    )

    tool_versions=(
        'computer_use_20251124:Latest computer use bundle'
        'computer_use_20250124:Previous computer use bundle'
        'computer_use_20241022:Legacy computer use bundle'
        'cli_20250124:CLI-only mode'
    )

    effort_levels=(
        'low:Minimal token usage'
        'medium:Balanced token usage'
        'high:Maximum capability'
    )

    mcp_presets=(
        'slack:Slack messaging integration'
        'github:GitHub repository integration'
        'postgres:PostgreSQL database access'
        'filesystem:Local filesystem access'
        'brave-search:Brave web search'
        'puppeteer:Browser automation'
    )

    log_levels=(
        'debug:Show all logs'
        'info:Show info and above'
        'warning:Show warnings and errors'
        'error:Show only errors'
    )

    _arguments -C \\
        '(-h --help)'{-h,--help}'[Show help message]' \\
        '(-v --version)'{-v,--version}'[Show version]' \\
        '(-q --quiet)'{-q,--quiet}'[Suppress banner]' \\
        '--json[Output in JSON format]' \\
        '1: :->command' \\
        '*:: :->args'

    case $state in
        command)
            _describe -t commands 'command' commands
            ;;
        args)
            case $words[1] in
                run)
                    _arguments \\
                        '(-a --agent)'{-a,--agent}'[Agent type]:agent:->agents' \\
                        '--tool-version[Tool bundle]:version:->versions' \\
                        '--cli[CLI-only mode]' \\
                        '--effort[Effort level]:effort:->effort' \\
                        '--tool-search[Tool search variant]:variant:(regex bm25)' \\
                        '--defer-tool[Defer tool loading]:tool:' \\
                        '--dry-run[Show what would run]' \\
                        '(-s --stream)'{-s,--stream}'[Enable real-time streaming output]' \\
                        '(-v --verbose)'{-v,--verbose}'[Show verbose output]' \\
                        '*:instruction:'
                    case $state in
                        agents)
                            _describe -t agents 'agent' agents
                            ;;
                        versions)
                            _describe -t versions 'version' tool_versions
                            ;;
                        effort)
                            _describe -t effort 'effort' effort_levels
                            ;;
                    esac
                    ;;
                chat)
                    _arguments \\
                        '(-a --agent)'{-a,--agent}'[Agent type]:agent:->agents' \\
                        '--cli[CLI-only mode]' \\
                        '--effort[Effort level]:effort:->effort'
                    case $state in
                        agents)
                            _describe -t agents 'agent' agents
                            ;;
                        effort)
                            _describe -t effort 'effort' effort_levels
                            ;;
                    esac
                    ;;
                agents)
                    _arguments '1:subcommand:(list)'
                    ;;
                config)
                    _arguments '1:subcommand:(show check env)'
                    ;;
                status)
                    _arguments \\
                        '(-a --all)'{-a,--all}'[Show all agents including completed]'
                    ;;
                stop)
                    _arguments \\
                        '--force[Force stop without confirmation]' \\
                        '1:agent_id:'
                    ;;
                logs)
                    _arguments \\
                        '(-f --follow)'{-f,--follow}'[Follow log output]' \\
                        '(-n --lines)'{-n,--lines}'[Number of lines]:lines:' \\
                        '--level[Log level]:level:->log_levels' \\
                        '1:agent_id:'
                    case $state in
                        log_levels)
                            _describe -t log_levels 'level' log_levels
                            ;;
                    esac
                    ;;
                history)
                    _arguments \\
                        '(-n --limit)'{-n,--limit}'[Number of tasks]:limit:' \\
                        '--agent[Filter by agent]:agent:->agents' \\
                        '--status[Filter by status]:status:(success failed running)'
                    case $state in
                        agents)
                            _describe -t agents 'agent' agents
                            ;;
                    esac
                    ;;
                init)
                    _arguments \\
                        '--force[Overwrite existing configuration]'
                    ;;
                mcp)
                    _arguments '1:subcommand:(list add remove status)'
                    case $words[2] in
                        add)
                            _arguments \\
                                '--preset[Use preset configuration]' \\
                                '1:name:->mcp_presets'
                            case $state in
                                mcp_presets)
                                    _describe -t mcp_presets 'preset' mcp_presets
                                    ;;
                            esac
                            ;;
                        remove)
                            _arguments '1:name:->mcp_presets'
                            case $state in
                                mcp_presets)
                                    _describe -t mcp_presets 'preset' mcp_presets
                                    ;;
                            esac
                            ;;
                        list)
                            _arguments '--running[Only show running servers]'
                            ;;
                    esac
                    ;;
                doctor)
                    _arguments \\
                        '--fix[Attempt to fix issues automatically]'
                    ;;
                metrics)
                    _arguments \\
                        '--period[Time period]:period:(day week month all)' \\
                        '--reset[Reset metrics data]'
                    ;;
                templates)
                    _arguments '1:subcommand:(list save run delete show)'
                    case $words[2] in
                        save)
                            _arguments \\
                                '1:name:' \\
                                '2:instruction:'
                            ;;
                        run)
                            _arguments \\
                                '1:name:' \\
                                '--vars[Variables]:vars:'
                            ;;
                        delete|show)
                            _arguments '1:name:'
                            ;;
                    esac
                    ;;
                alias)
                    _arguments '1:subcommand:(list set remove)'
                    case $words[2] in
                        set)
                            _arguments \\
                                '1:name:' \\
                                '*:command:'
                            ;;
                        remove)
                            _arguments '1:name:'
                            ;;
                    esac
                    ;;
                replay)
                    _arguments \\
                        '1:task_id:' \\
                        '--modify[Modified instruction]:instruction:'
                    ;;
                upgrade)
                    _arguments \\
                        '--check[Check only, do not install]'
                    ;;
                watch)
                    _arguments \\
                        '1:agent_id:' \\
                        '--interval[Refresh interval]:seconds:'
                    ;;
                profile)
                    _arguments '1:subcommand:(list create use show delete edit)'
                    case $words[2] in
                        create)
                            _arguments \\
                                '1:name:' \\
                                '--api-key[API key]:key:' \\
                                '--base-url[Base URL]:url:' \\
                                '--model[Default model]:model:' \\
                                '--copy-from[Copy from profile]:profile:'
                            ;;
                        use|show|delete)
                            _arguments '1:name:'
                            ;;
                        edit)
                            _arguments \\
                                '1:name:' \\
                                '--api-key[Update API key]:key:' \\
                                '--base-url[Update base URL]:url:' \\
                                '--model[Update model]:model:'
                            ;;
                    esac
                    ;;
                export)
                    _arguments '1:subcommand:(history logs metrics config)'
                    case $words[2] in
                        history)
                            _arguments \\
                                '(-f --format)'{-f,--format}'[Output format]:format:(json csv markdown)' \\
                                '(-o --output)'{-o,--output}'[Output file]:file:_files' \\
                                '(-n --limit)'{-n,--limit}'[Limit entries]:count:' \\
                                '--agent[Filter by agent]:agent:'
                            ;;
                        logs)
                            _arguments \\
                                '1:agent_id:' \\
                                '(-o --output)'{-o,--output}'[Output file]:file:_files'
                            ;;
                        metrics)
                            _arguments \\
                                '(-f --format)'{-f,--format}'[Output format]:format:(json csv prometheus)' \\
                                '(-o --output)'{-o,--output}'[Output file]:file:_files'
                            ;;
                        config)
                            _arguments \\
                                '(-o --output)'{-o,--output}'[Output file]:file:_files' \\
                                '--include-secrets[Include API keys]'
                            ;;
                    esac
                    ;;
                context)
                    _arguments '1:subcommand:(list show clear save load export)'
                    case $words[2] in
                        show|clear|export)
                            _arguments '1:name:'
                            ;;
                        save)
                            _arguments \\
                                '1:name:' \\
                                '--agent[Agent ID]:agent:'
                            ;;
                        load)
                            _arguments '1:name:'
                            ;;
                        clear)
                            _arguments \\
                                '1:name:' \\
                                '--force[Skip confirmation]'
                            ;;
                    esac
                    ;;
                benchmark)
                    _arguments '1:subcommand:(list run history)'
                    case $words[2] in
                        run)
                            _arguments \\
                                '--suite[Benchmark suite]:suite:(quick standard comprehensive)' \\
                                '(-o --output)'{-o,--output}'[Output file]:file:_files' \\
                                '--compare[Compare with run]:run_id:'
                            ;;
                        history)
                            _arguments \\
                                '(-n --limit)'{-n,--limit}'[Number of runs]:count:'
                            ;;
                    esac
                    ;;
                plugin)
                    _arguments '1:subcommand:(list install uninstall enable disable search)'
                    case $words[2] in
                        install)
                            _arguments \\
                                '1:name:' \\
                                '--force[Force reinstall]'
                            ;;
                        uninstall|enable|disable)
                            _arguments '1:name:'
                            ;;
                    esac
                    ;;
                theme)
                    _arguments '1:subcommand:(list set show)'
                    case $words[2] in
                        set)
                            _arguments '1:name:(default dark light minimal colorful none)'
                            ;;
                    esac
                    ;;
                wizard)
                    _arguments \\
                        '(-a --agent)'{-a,--agent}'[Pre-select agent]:agent:->agents' \\
                        '--template[Start from template]:template:'
                    case $state in
                        agents)
                            _describe -t agents 'agent' agents
                            ;;
                    esac
                    ;;
                schedule)
                    _arguments '1:subcommand:(list add remove enable pause run show history)'
                    case $words[2] in
                        add)
                            _arguments \\
                                '1:name:' \\
                                '2:cron:' \\
                                '(-a --agent)'{-a,--agent}'[Agent type]:agent:' \\
                                '--timezone[Timezone]:timezone:'
                            ;;
                        remove|enable|pause|run|show)
                            _arguments '1:name:'
                            ;;
                        history)
                            _arguments \\
                                '1:name:' \\
                                '(-n --limit)'{-n,--limit}'[Number of entries]:count:'
                            ;;
                    esac
                    ;;
                webhook)
                    _arguments '1:subcommand:(list create delete show test logs regenerate)'
                    case $words[2] in
                        create)
                            _arguments \\
                                '1:name:' \\
                                '(-a --agent)'{-a,--agent}'[Default agent]:agent:' \\
                                '--secret[Webhook secret]:secret:' \\
                                '--template[Template to use]:template:'
                            ;;
                        delete|show|test|logs|regenerate)
                            _arguments '1:name:'
                            ;;
                    esac
                    ;;
                secrets)
                    _arguments '1:subcommand:(list set get delete export import)'
                    case $words[2] in
                        set)
                            _arguments \\
                                '1:name:' \\
                                '2:value:' \\
                                '--from-env[Copy from env var]:var:' \\
                                '--from-file[Read from file]:file:_files'
                            ;;
                        get)
                            _arguments \\
                                '1:name:' \\
                                '--show[Show actual value]'
                            ;;
                        delete)
                            _arguments \\
                                '1:name:' \\
                                '--force[Skip confirmation]'
                            ;;
                    esac
                    ;;
                workspace)
                    _arguments '1:subcommand:(list current create use delete show edit)'
                    case $words[2] in
                        create)
                            _arguments \\
                                '1:name:' \\
                                '(-p --path)'{-p,--path}'[Project path]:path:_files -/' \\
                                '--profile[Config profile]:profile:' \\
                                '(-d --description)'{-d,--description}'[Description]:desc:'
                            ;;
                        use|delete|show)
                            _arguments '1:name:'
                            ;;
                        edit)
                            _arguments \\
                                '1:name:' \\
                                '(-p --path)'{-p,--path}'[Update path]:path:_files -/' \\
                                '--profile[Update profile]:profile:' \\
                                '(-d --description)'{-d,--description}'[Update description]:desc:'
                            ;;
                    esac
                    ;;
                notify)
                    _arguments '1:subcommand:(list add remove test enable disable show)'
                    case $words[2] in
                        add)
                            _arguments \\
                                '1:type:(slack discord email webhook telegram pagerduty)' \\
                                '--name[Channel name]:name:' \\
                                '--webhook-url[Webhook URL]:url:' \\
                                '--address[Email address]:address:' \\
                                '--token[API token]:token:' \\
                                '--on-success[Notify on success]' \\
                                '--on-failure[Notify on failure]' \\
                                '--on-start[Notify on start]'
                            ;;
                        remove|test|enable|disable|show)
                            _arguments '1:name:'
                            ;;
                    esac
                    ;;
                audit)
                    _arguments '1:subcommand:(log export search stats retention)'
                    case $words[2] in
                        log)
                            _arguments \\
                                '--since[Start date]:date:' \\
                                '--until[End date]:date:' \\
                                '--type[Event type]:type:(all api task config auth)' \\
                                '(-n --limit)'{-n,--limit}'[Number of entries]:count:' \\
                                '--agent[Filter by agent]:agent:'
                            ;;
                        export)
                            _arguments \\
                                '(-f --format)'{-f,--format}'[Export format]:format:(json csv html)' \\
                                '(-o --output)'{-o,--output}'[Output file]:file:_files' \\
                                '--since[Start date]:date:' \\
                                '--until[End date]:date:'
                            ;;
                        search)
                            _arguments \\
                                '1:query:' \\
                                '(-n --limit)'{-n,--limit}'[Number of results]:count:'
                            ;;
                        stats)
                            _arguments \\
                                '--period[Time period]:period:(day week month year)'
                            ;;
                        retention)
                            _arguments \\
                                '--days[Retention days]:days:' \\
                                '--show[Show current policy]'
                            ;;
                    esac
                    ;;
                cache)
                    _arguments '1:subcommand:(stats clear show config)'
                    case $words[2] in
                        clear)
                            _arguments \\
                                '(-t --type)'{-t,--type}'[Cache type]:type:(api screenshots contexts prompts all)' \\
                                '--all[Clear all caches]' \\
                                '--force[Skip confirmation]' \\
                                '--older-than[Clear older than]:duration:'
                            ;;
                        show)
                            _arguments \\
                                '(-t --type)'{-t,--type}'[Cache type]:type:(api screenshots contexts prompts)' \\
                                '(-n --limit)'{-n,--limit}'[Number of entries]:count:'
                            ;;
                        config)
                            _arguments \\
                                '--max-size[Max cache size]:size:' \\
                                '--ttl[Cache TTL]:ttl:' \\
                                '--disable[Disable caching]' \\
                                '--enable[Enable caching]'
                            ;;
                    esac
                    ;;
                completion)
                    _arguments '1:subcommand:(install show status)'
                    case $words[2] in
                        install|show)
                            _arguments '1:shell:(bash zsh fish)'
                            ;;
                    esac
                    ;;
                login)
                    _arguments \\
                        '(-k --key)'{-k,--key}'[API key]:key:' \\
                        '--check[Verify authentication]' \\
                        '--logout[Remove credentials]'
                    ;;
                whoami)
                    _arguments \\
                        '(-v --verbose)'{-v,--verbose}'[Show detailed info]'
                    ;;
                env)
                    _arguments '1:subcommand:(list get set unset export check)'
                    case $words[2] in
                        get|unset)
                            _arguments '1:variable:'
                            ;;
                        set)
                            _arguments \\
                                '1:variable:' \\
                                '2:value:' \\
                                '--persist[Save to .env]'
                            ;;
                        export)
                            _arguments \\
                                '(-o --output)'{-o,--output}'[Output file]:file:_files' \\
                                '--all[Include all vars]'
                            ;;
                    esac
                    ;;
                tail)
                    _arguments \\
                        '1:task_id:' \\
                        '(-f --filter)'{-f,--filter}'[Filter keyword]:keyword:' \\
                        '--no-color[Disable colors]'
                    ;;
                inspect)
                    _arguments '1:subcommand:(task agent config system tools)'
                    case $words[2] in
                        task)
                            _arguments \\
                                '1:task_id:' \\
                                '(-o --output)'{-o,--output}'[Output format]:format:(json yaml table)'
                            ;;
                        agent)
                            _arguments '1:agent_type:(auto-close social-media linkedin slack)'
                            ;;
                    esac
                    ;;
                rollback)
                    _arguments '1:subcommand:(list create to last)'
                    case $words[2] in
                        create)
                            _arguments \\
                                '(-n --name)'{-n,--name}'[Checkpoint name]:name:' \\
                                '(-m --message)'{-m,--message}'[Message]:message:'
                            ;;
                        to)
                            _arguments '1:checkpoint_id:'
                            ;;
                    esac
                    ;;
                sync)
                    _arguments '1:subcommand:(status setup push pull diff)'
                    case $words[2] in
                        setup)
                            _arguments \\
                                '(-r --remote)'{-r,--remote}'[Remote URL]:url:' \\
                                '--disable[Disable sync]'
                            ;;
                        push|pull)
                            _arguments '--force[Force overwrite]'
                            ;;
                    esac
                    ;;
                api)
                    _arguments '1:subcommand:(messages models usage limits)'
                    case $words[2] in
                        messages)
                            _arguments \\
                                '(-p --prompt)'{-p,--prompt}'[Message prompt]:prompt:' \\
                                '(-m --model)'{-m,--model}'[Model]:model:' \\
                                '--max-tokens[Max tokens]:tokens:' \\
                                '(-s --system)'{-s,--system}'[System prompt]:system:'
                            ;;
                    esac
                    ;;
                events)
                    _arguments '1:subcommand:(list watch clear subscribe)'
                    case $words[2] in
                        list)
                            _arguments \\
                                '(-t --type)'{-t,--type}'[Event type]:type:(all error warning info success)' \\
                                '(-n --limit)'{-n,--limit}'[Number of events]:count:' \\
                                '--since[Since time]:time:'
                            ;;
                        subscribe)
                            _arguments '--channel[Notification channel]:channel:'
                            ;;
                    esac
                    ;;
            esac
            ;;
    esac
}

_stateset "$@"
'''

FISH_COMPLETION = '''
# Fish completion for stateset
# Save to ~/.config/fish/completions/stateset.fish

# Disable file completions for all subcommands
complete -c stateset -f
complete -c stateset-agent -f

# Top-level commands
complete -c stateset -n "__fish_use_subcommand" -a "run" -d "Run an agent with a task instruction"
complete -c stateset -n "__fish_use_subcommand" -a "chat" -d "Start an interactive chat session"
complete -c stateset -n "__fish_use_subcommand" -a "agents" -d "List and manage agent types"
complete -c stateset -n "__fish_use_subcommand" -a "config" -d "Show and manage configuration"
complete -c stateset -n "__fish_use_subcommand" -a "check" -d "Validate environment setup"
complete -c stateset -n "__fish_use_subcommand" -a "version" -d "Show version information"
complete -c stateset -n "__fish_use_subcommand" -a "status" -d "Show status of running agents"
complete -c stateset -n "__fish_use_subcommand" -a "stop" -d "Stop running agents"
complete -c stateset -n "__fish_use_subcommand" -a "logs" -d "View agent execution logs"
complete -c stateset -n "__fish_use_subcommand" -a "history" -d "Show task execution history"
complete -c stateset -n "__fish_use_subcommand" -a "init" -d "Initialize project configuration"
complete -c stateset -n "__fish_use_subcommand" -a "mcp" -d "Manage MCP servers"
complete -c stateset -n "__fish_use_subcommand" -a "doctor" -d "Run comprehensive diagnostics"
complete -c stateset -n "__fish_use_subcommand" -a "metrics" -d "Show usage statistics"
complete -c stateset -n "__fish_use_subcommand" -a "templates" -d "Manage task templates"
complete -c stateset -n "__fish_use_subcommand" -a "alias" -d "Manage command aliases"
complete -c stateset -n "__fish_use_subcommand" -a "replay" -d "Re-run previous tasks"
complete -c stateset -n "__fish_use_subcommand" -a "upgrade" -d "Check for and install updates"
complete -c stateset -n "__fish_use_subcommand" -a "watch" -d "Monitor agent execution in real-time"
complete -c stateset -n "__fish_use_subcommand" -a "profile" -d "Manage configuration profiles"
complete -c stateset -n "__fish_use_subcommand" -a "export" -d "Export task results, logs, and data"
complete -c stateset -n "__fish_use_subcommand" -a "context" -d "Manage agent context and memory"
complete -c stateset -n "__fish_use_subcommand" -a "benchmark" -d "Run performance benchmarks"
complete -c stateset -n "__fish_use_subcommand" -a "plugin" -d "Manage CLI plugins and extensions"
complete -c stateset -n "__fish_use_subcommand" -a "theme" -d "Customize CLI appearance"
complete -c stateset -n "__fish_use_subcommand" -a "wizard" -d "Interactive task builder wizard"
complete -c stateset -n "__fish_use_subcommand" -a "schedule" -d "Schedule recurring tasks with cron"
complete -c stateset -n "__fish_use_subcommand" -a "webhook" -d "Manage webhook endpoints"
complete -c stateset -n "__fish_use_subcommand" -a "secrets" -d "Securely manage credentials"
complete -c stateset -n "__fish_use_subcommand" -a "workspace" -d "Manage project workspaces"
complete -c stateset -n "__fish_use_subcommand" -a "notify" -d "Configure notification channels"
complete -c stateset -n "__fish_use_subcommand" -a "audit" -d "View audit logs and compliance"
complete -c stateset -n "__fish_use_subcommand" -a "cache" -d "Manage CLI caches"

# Global options
complete -c stateset -s h -l help -d "Show help"
complete -c stateset -s v -l version -d "Show version"
complete -c stateset -s q -l quiet -d "Suppress banner"
complete -c stateset -l json -d "Output in JSON format"

# run subcommand
complete -c stateset -n "__fish_seen_subcommand_from run" -s a -l agent -d "Agent type" -xa "auto-close social-media onboarding linkedin slack shopify agentic"
complete -c stateset -n "__fish_seen_subcommand_from run" -l tool-version -d "Tool bundle" -xa "computer_use_20251124 computer_use_20250124 computer_use_20241022 cli_20250124"
complete -c stateset -n "__fish_seen_subcommand_from run" -l cli -d "CLI-only mode"
complete -c stateset -n "__fish_seen_subcommand_from run" -l effort -d "Effort level" -xa "low medium high"
complete -c stateset -n "__fish_seen_subcommand_from run" -l tool-search -d "Tool search variant" -xa "regex bm25"
complete -c stateset -n "__fish_seen_subcommand_from run" -l defer-tool -d "Defer tool loading"
complete -c stateset -n "__fish_seen_subcommand_from run" -l dry-run -d "Show what would run"
complete -c stateset -n "__fish_seen_subcommand_from run" -s s -l stream -d "Enable real-time streaming output"
complete -c stateset -n "__fish_seen_subcommand_from run" -s v -l verbose -d "Show verbose output"

# chat subcommand
complete -c stateset -n "__fish_seen_subcommand_from chat" -s a -l agent -d "Agent type" -xa "auto-close social-media onboarding linkedin slack shopify agentic"
complete -c stateset -n "__fish_seen_subcommand_from chat" -l cli -d "CLI-only mode"
complete -c stateset -n "__fish_seen_subcommand_from chat" -l effort -d "Effort level" -xa "low medium high"

# agents subcommand
complete -c stateset -n "__fish_seen_subcommand_from agents" -a "list" -d "List available agents"

# config subcommand
complete -c stateset -n "__fish_seen_subcommand_from config" -a "show" -d "Show current configuration"
complete -c stateset -n "__fish_seen_subcommand_from config" -a "check" -d "Validate environment"
complete -c stateset -n "__fish_seen_subcommand_from config" -a "env" -d "Show environment variables"

# status subcommand
complete -c stateset -n "__fish_seen_subcommand_from status" -s a -l all -d "Show all agents including completed"

# stop subcommand
complete -c stateset -n "__fish_seen_subcommand_from stop" -l force -d "Force stop without confirmation"

# logs subcommand
complete -c stateset -n "__fish_seen_subcommand_from logs" -s f -l follow -d "Follow log output"
complete -c stateset -n "__fish_seen_subcommand_from logs" -s n -l lines -d "Number of lines to show"
complete -c stateset -n "__fish_seen_subcommand_from logs" -l level -d "Log level" -xa "debug info warning error"

# history subcommand
complete -c stateset -n "__fish_seen_subcommand_from history" -s n -l limit -d "Number of tasks to show"
complete -c stateset -n "__fish_seen_subcommand_from history" -l agent -d "Filter by agent type" -xa "auto-close social-media onboarding linkedin slack shopify agentic"
complete -c stateset -n "__fish_seen_subcommand_from history" -l status -d "Filter by status" -xa "success failed running"

# init subcommand
complete -c stateset -n "__fish_seen_subcommand_from init" -l force -d "Overwrite existing configuration"

# mcp subcommand
complete -c stateset -n "__fish_seen_subcommand_from mcp" -a "list" -d "List available MCP servers"
complete -c stateset -n "__fish_seen_subcommand_from mcp" -a "add" -d "Add an MCP server"
complete -c stateset -n "__fish_seen_subcommand_from mcp" -a "remove" -d "Remove an MCP server"
complete -c stateset -n "__fish_seen_subcommand_from mcp" -a "status" -d "Show MCP server status"

# mcp add options
complete -c stateset -n "__fish_seen_subcommand_from add" -l preset -d "Use preset configuration"
complete -c stateset -n "__fish_seen_subcommand_from add" -a "slack github postgres filesystem brave-search puppeteer" -d "MCP preset"

# mcp remove options
complete -c stateset -n "__fish_seen_subcommand_from remove" -a "slack github postgres filesystem brave-search puppeteer" -d "MCP server"

# mcp list options
complete -c stateset -n "__fish_seen_subcommand_from list" -l running -d "Only show running servers"

# doctor subcommand
complete -c stateset -n "__fish_seen_subcommand_from doctor" -l fix -d "Attempt to fix issues automatically"

# metrics subcommand
complete -c stateset -n "__fish_seen_subcommand_from metrics" -l period -d "Time period" -xa "day week month all"
complete -c stateset -n "__fish_seen_subcommand_from metrics" -l reset -d "Reset metrics data"

# templates subcommand
complete -c stateset -n "__fish_seen_subcommand_from templates" -a "list" -d "List saved templates"
complete -c stateset -n "__fish_seen_subcommand_from templates" -a "save" -d "Save a new template"
complete -c stateset -n "__fish_seen_subcommand_from templates" -a "run" -d "Run a template"
complete -c stateset -n "__fish_seen_subcommand_from templates" -a "delete" -d "Delete a template"
complete -c stateset -n "__fish_seen_subcommand_from templates" -a "show" -d "Show template details"

# alias subcommand
complete -c stateset -n "__fish_seen_subcommand_from alias" -a "list" -d "List all aliases"
complete -c stateset -n "__fish_seen_subcommand_from alias" -a "set" -d "Create or update an alias"
complete -c stateset -n "__fish_seen_subcommand_from alias" -a "remove" -d "Remove an alias"

# replay subcommand
complete -c stateset -n "__fish_seen_subcommand_from replay" -l modify -d "Modified instruction"

# upgrade subcommand
complete -c stateset -n "__fish_seen_subcommand_from upgrade" -l check -d "Check only, do not install"

# watch subcommand
complete -c stateset -n "__fish_seen_subcommand_from watch" -l interval -d "Refresh interval in seconds"

# profile subcommand
complete -c stateset -n "__fish_seen_subcommand_from profile" -a "list" -d "List all profiles"
complete -c stateset -n "__fish_seen_subcommand_from profile" -a "create" -d "Create a new profile"
complete -c stateset -n "__fish_seen_subcommand_from profile" -a "use" -d "Switch to a profile"
complete -c stateset -n "__fish_seen_subcommand_from profile" -a "show" -d "Show profile details"
complete -c stateset -n "__fish_seen_subcommand_from profile" -a "delete" -d "Delete a profile"
complete -c stateset -n "__fish_seen_subcommand_from profile" -a "edit" -d "Edit a profile"

# profile create options
complete -c stateset -n "__fish_seen_subcommand_from profile; and __fish_seen_subcommand_from create" -l api-key -d "API key for the profile"
complete -c stateset -n "__fish_seen_subcommand_from profile; and __fish_seen_subcommand_from create" -l base-url -d "Base URL for API"
complete -c stateset -n "__fish_seen_subcommand_from profile; and __fish_seen_subcommand_from create" -l model -d "Default model"
complete -c stateset -n "__fish_seen_subcommand_from profile; and __fish_seen_subcommand_from create" -l copy-from -d "Copy from existing profile"

# profile edit options
complete -c stateset -n "__fish_seen_subcommand_from profile; and __fish_seen_subcommand_from edit" -l api-key -d "Update API key"
complete -c stateset -n "__fish_seen_subcommand_from profile; and __fish_seen_subcommand_from edit" -l base-url -d "Update base URL"
complete -c stateset -n "__fish_seen_subcommand_from profile; and __fish_seen_subcommand_from edit" -l model -d "Update model"

# export subcommand
complete -c stateset -n "__fish_seen_subcommand_from export" -a "history" -d "Export task history"
complete -c stateset -n "__fish_seen_subcommand_from export" -a "logs" -d "Export agent logs"
complete -c stateset -n "__fish_seen_subcommand_from export" -a "metrics" -d "Export usage metrics"
complete -c stateset -n "__fish_seen_subcommand_from export" -a "config" -d "Export configuration"

# export history options
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from history" -s f -l format -d "Output format" -xa "json csv markdown"
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from history" -s o -l output -d "Output file" -r
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from history" -s n -l limit -d "Limit entries"
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from history" -l agent -d "Filter by agent"

# export logs options
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from logs" -s o -l output -d "Output file" -r

# export metrics options
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from metrics" -s f -l format -d "Output format" -xa "json csv prometheus"
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from metrics" -s o -l output -d "Output file" -r

# export config options
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from config" -s o -l output -d "Output file" -r
complete -c stateset -n "__fish_seen_subcommand_from export; and __fish_seen_subcommand_from config" -l include-secrets -d "Include API keys"

# context subcommand
complete -c stateset -n "__fish_seen_subcommand_from context" -a "list" -d "List all contexts"
complete -c stateset -n "__fish_seen_subcommand_from context" -a "show" -d "Show context details"
complete -c stateset -n "__fish_seen_subcommand_from context" -a "clear" -d "Clear context"
complete -c stateset -n "__fish_seen_subcommand_from context" -a "save" -d "Save current context"
complete -c stateset -n "__fish_seen_subcommand_from context" -a "load" -d "Load a saved context"
complete -c stateset -n "__fish_seen_subcommand_from context" -a "export" -d "Export context to file"

# context save options
complete -c stateset -n "__fish_seen_subcommand_from context; and __fish_seen_subcommand_from save" -l agent -d "Agent ID"

# context clear options
complete -c stateset -n "__fish_seen_subcommand_from context; and __fish_seen_subcommand_from clear" -l force -d "Skip confirmation"

# benchmark subcommand
complete -c stateset -n "__fish_seen_subcommand_from benchmark" -a "list" -d "List available benchmarks"
complete -c stateset -n "__fish_seen_subcommand_from benchmark" -a "run" -d "Run benchmarks"
complete -c stateset -n "__fish_seen_subcommand_from benchmark" -a "history" -d "Show benchmark history"

# benchmark run options
complete -c stateset -n "__fish_seen_subcommand_from benchmark; and __fish_seen_subcommand_from run" -l suite -d "Benchmark suite" -xa "quick standard comprehensive"
complete -c stateset -n "__fish_seen_subcommand_from benchmark; and __fish_seen_subcommand_from run" -s o -l output -d "Output file" -r
complete -c stateset -n "__fish_seen_subcommand_from benchmark; and __fish_seen_subcommand_from run" -l compare -d "Compare with previous run"

# benchmark history options
complete -c stateset -n "__fish_seen_subcommand_from benchmark; and __fish_seen_subcommand_from history" -s n -l limit -d "Number of runs to show"

# plugin subcommand
complete -c stateset -n "__fish_seen_subcommand_from plugin" -a "list" -d "List installed plugins"
complete -c stateset -n "__fish_seen_subcommand_from plugin" -a "install" -d "Install a plugin"
complete -c stateset -n "__fish_seen_subcommand_from plugin" -a "uninstall" -d "Uninstall a plugin"
complete -c stateset -n "__fish_seen_subcommand_from plugin" -a "enable" -d "Enable a plugin"
complete -c stateset -n "__fish_seen_subcommand_from plugin" -a "disable" -d "Disable a plugin"
complete -c stateset -n "__fish_seen_subcommand_from plugin" -a "search" -d "Search for plugins"

# plugin install options
complete -c stateset -n "__fish_seen_subcommand_from plugin; and __fish_seen_subcommand_from install" -l force -d "Force reinstall"

# theme subcommand
complete -c stateset -n "__fish_seen_subcommand_from theme" -a "list" -d "List available themes"
complete -c stateset -n "__fish_seen_subcommand_from theme" -a "set" -d "Set active theme"
complete -c stateset -n "__fish_seen_subcommand_from theme" -a "show" -d "Show current theme"

# theme set options
complete -c stateset -n "__fish_seen_subcommand_from theme; and __fish_seen_subcommand_from set" -a "default dark light minimal colorful none" -d "Theme name"

# wizard subcommand
complete -c stateset -n "__fish_seen_subcommand_from wizard" -s a -l agent -d "Pre-select agent" -xa "auto-close social-media onboarding linkedin slack shopify agentic"
complete -c stateset -n "__fish_seen_subcommand_from wizard" -l template -d "Start from template"

# schedule subcommand
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "list" -d "List scheduled tasks"
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "add" -d "Add a scheduled task"
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "remove" -d "Remove a scheduled task"
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "enable" -d "Enable a scheduled task"
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "pause" -d "Pause a scheduled task"
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "run" -d "Run a scheduled task now"
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "show" -d "Show schedule details"
complete -c stateset -n "__fish_seen_subcommand_from schedule" -a "history" -d "Show execution history"

# schedule add options
complete -c stateset -n "__fish_seen_subcommand_from schedule; and __fish_seen_subcommand_from add" -s a -l agent -d "Agent type"
complete -c stateset -n "__fish_seen_subcommand_from schedule; and __fish_seen_subcommand_from add" -l timezone -d "Timezone"

# schedule history options
complete -c stateset -n "__fish_seen_subcommand_from schedule; and __fish_seen_subcommand_from history" -s n -l limit -d "Number of entries"

# webhook subcommand
complete -c stateset -n "__fish_seen_subcommand_from webhook" -a "list" -d "List webhook endpoints"
complete -c stateset -n "__fish_seen_subcommand_from webhook" -a "create" -d "Create a webhook"
complete -c stateset -n "__fish_seen_subcommand_from webhook" -a "delete" -d "Delete a webhook"
complete -c stateset -n "__fish_seen_subcommand_from webhook" -a "show" -d "Show webhook details"
complete -c stateset -n "__fish_seen_subcommand_from webhook" -a "test" -d "Test a webhook"
complete -c stateset -n "__fish_seen_subcommand_from webhook" -a "logs" -d "View webhook logs"
complete -c stateset -n "__fish_seen_subcommand_from webhook" -a "regenerate" -d "Regenerate webhook URL/secret"

# webhook create options
complete -c stateset -n "__fish_seen_subcommand_from webhook; and __fish_seen_subcommand_from create" -s a -l agent -d "Default agent"
complete -c stateset -n "__fish_seen_subcommand_from webhook; and __fish_seen_subcommand_from create" -l secret -d "Webhook secret"
complete -c stateset -n "__fish_seen_subcommand_from webhook; and __fish_seen_subcommand_from create" -l template -d "Template to use"

# webhook regenerate options
complete -c stateset -n "__fish_seen_subcommand_from webhook; and __fish_seen_subcommand_from regenerate" -l secret-only -d "Only regenerate secret"

# secrets subcommand
complete -c stateset -n "__fish_seen_subcommand_from secrets" -a "list" -d "List stored secrets"
complete -c stateset -n "__fish_seen_subcommand_from secrets" -a "set" -d "Set a secret value"
complete -c stateset -n "__fish_seen_subcommand_from secrets" -a "get" -d "Get a secret value"
complete -c stateset -n "__fish_seen_subcommand_from secrets" -a "delete" -d "Delete a secret"
complete -c stateset -n "__fish_seen_subcommand_from secrets" -a "export" -d "Export secrets"
complete -c stateset -n "__fish_seen_subcommand_from secrets" -a "import" -d "Import secrets"

# secrets set options
complete -c stateset -n "__fish_seen_subcommand_from secrets; and __fish_seen_subcommand_from set" -l from-env -d "Copy from env var"
complete -c stateset -n "__fish_seen_subcommand_from secrets; and __fish_seen_subcommand_from set" -l from-file -d "Read from file" -r

# secrets get options
complete -c stateset -n "__fish_seen_subcommand_from secrets; and __fish_seen_subcommand_from get" -l show -d "Show actual value"

# secrets delete options
complete -c stateset -n "__fish_seen_subcommand_from secrets; and __fish_seen_subcommand_from delete" -l force -d "Skip confirmation"

# workspace subcommand
complete -c stateset -n "__fish_seen_subcommand_from workspace" -a "list" -d "List all workspaces"
complete -c stateset -n "__fish_seen_subcommand_from workspace" -a "current" -d "Show current workspace"
complete -c stateset -n "__fish_seen_subcommand_from workspace" -a "create" -d "Create a workspace"
complete -c stateset -n "__fish_seen_subcommand_from workspace" -a "use" -d "Switch to a workspace"
complete -c stateset -n "__fish_seen_subcommand_from workspace" -a "delete" -d "Delete a workspace"
complete -c stateset -n "__fish_seen_subcommand_from workspace" -a "show" -d "Show workspace details"
complete -c stateset -n "__fish_seen_subcommand_from workspace" -a "edit" -d "Edit workspace settings"

# workspace create options
complete -c stateset -n "__fish_seen_subcommand_from workspace; and __fish_seen_subcommand_from create" -s p -l path -d "Project path" -r
complete -c stateset -n "__fish_seen_subcommand_from workspace; and __fish_seen_subcommand_from create" -l profile -d "Config profile"
complete -c stateset -n "__fish_seen_subcommand_from workspace; and __fish_seen_subcommand_from create" -s d -l description -d "Description"

# workspace delete options
complete -c stateset -n "__fish_seen_subcommand_from workspace; and __fish_seen_subcommand_from delete" -l force -d "Skip confirmation"

# workspace edit options
complete -c stateset -n "__fish_seen_subcommand_from workspace; and __fish_seen_subcommand_from edit" -s p -l path -d "Update path" -r
complete -c stateset -n "__fish_seen_subcommand_from workspace; and __fish_seen_subcommand_from edit" -l profile -d "Update profile"
complete -c stateset -n "__fish_seen_subcommand_from workspace; and __fish_seen_subcommand_from edit" -s d -l description -d "Update description"

# notify subcommand
complete -c stateset -n "__fish_seen_subcommand_from notify" -a "list" -d "List notification channels"
complete -c stateset -n "__fish_seen_subcommand_from notify" -a "add" -d "Add a notification channel"
complete -c stateset -n "__fish_seen_subcommand_from notify" -a "remove" -d "Remove a channel"
complete -c stateset -n "__fish_seen_subcommand_from notify" -a "test" -d "Send test notification"
complete -c stateset -n "__fish_seen_subcommand_from notify" -a "enable" -d "Enable notifications"
complete -c stateset -n "__fish_seen_subcommand_from notify" -a "disable" -d "Disable notifications"
complete -c stateset -n "__fish_seen_subcommand_from notify" -a "show" -d "Show channel details"

# notify add options
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -a "slack discord email webhook telegram pagerduty" -d "Channel type"
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -l name -d "Channel name"
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -l webhook-url -d "Webhook URL"
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -l address -d "Email address"
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -l token -d "API token"
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -l on-success -d "Notify on success"
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -l on-failure -d "Notify on failure"
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from add" -l on-start -d "Notify on start"

# notify test options
complete -c stateset -n "__fish_seen_subcommand_from notify; and __fish_seen_subcommand_from test" -s m -l message -d "Custom test message"

# audit subcommand
complete -c stateset -n "__fish_seen_subcommand_from audit" -a "log" -d "View audit log entries"
complete -c stateset -n "__fish_seen_subcommand_from audit" -a "export" -d "Export audit logs"
complete -c stateset -n "__fish_seen_subcommand_from audit" -a "search" -d "Search audit logs"
complete -c stateset -n "__fish_seen_subcommand_from audit" -a "stats" -d "Show audit statistics"
complete -c stateset -n "__fish_seen_subcommand_from audit" -a "retention" -d "Configure log retention"

# audit log options
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from log" -l since -d "Start date"
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from log" -l until -d "End date"
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from log" -l type -d "Event type" -xa "all api task config auth"
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from log" -s n -l limit -d "Number of entries"
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from log" -l agent -d "Filter by agent"

# audit export options
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from export" -s f -l format -d "Export format" -xa "json csv html"
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from export" -s o -l output -d "Output file" -r
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from export" -l since -d "Start date"
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from export" -l until -d "End date"

# audit search options
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from search" -s n -l limit -d "Number of results"

# audit stats options
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from stats" -l period -d "Time period" -xa "day week month year"

# audit retention options
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from retention" -l days -d "Retention days"
complete -c stateset -n "__fish_seen_subcommand_from audit; and __fish_seen_subcommand_from retention" -l show -d "Show current policy"

# cache subcommand
complete -c stateset -n "__fish_seen_subcommand_from cache" -a "stats" -d "Show cache statistics"
complete -c stateset -n "__fish_seen_subcommand_from cache" -a "clear" -d "Clear cached data"
complete -c stateset -n "__fish_seen_subcommand_from cache" -a "show" -d "Show cache contents"
complete -c stateset -n "__fish_seen_subcommand_from cache" -a "config" -d "Configure cache settings"

# cache clear options
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from clear" -s t -l type -d "Cache type" -xa "api screenshots contexts prompts all"
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from clear" -l all -d "Clear all caches"
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from clear" -l force -d "Skip confirmation"
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from clear" -l older-than -d "Clear entries older than"

# cache show options
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from show" -s t -l type -d "Cache type" -xa "api screenshots contexts prompts"
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from show" -s n -l limit -d "Number of entries"

# cache config options
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from config" -l max-size -d "Max cache size"
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from config" -l ttl -d "Cache TTL"
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from config" -l disable -d "Disable caching"
complete -c stateset -n "__fish_seen_subcommand_from cache; and __fish_seen_subcommand_from config" -l enable -d "Enable caching"

# ============================================================================
# v1.6.0 Commands
# ============================================================================

# completion subcommand
complete -c stateset -n "__fish_seen_subcommand_from completion" -a "install" -d "Install completions to shell config"
complete -c stateset -n "__fish_seen_subcommand_from completion" -a "show" -d "Show completion script"
complete -c stateset -n "__fish_seen_subcommand_from completion" -a "status" -d "Check completion installation status"

# completion install options
complete -c stateset -n "__fish_seen_subcommand_from completion; and __fish_seen_subcommand_from install" -s s -l shell -d "Shell type" -xa "bash zsh fish"
complete -c stateset -n "__fish_seen_subcommand_from completion; and __fish_seen_subcommand_from install" -l path -d "Custom install path" -r
complete -c stateset -n "__fish_seen_subcommand_from completion; and __fish_seen_subcommand_from install" -l force -d "Overwrite existing"

# completion show options
complete -c stateset -n "__fish_seen_subcommand_from completion; and __fish_seen_subcommand_from show" -s s -l shell -d "Shell type" -xa "bash zsh fish"

# login subcommand options
complete -c stateset -n "__fish_seen_subcommand_from login" -l key -d "API key (prompted if not provided)"
complete -c stateset -n "__fish_seen_subcommand_from login" -l provider -d "API provider" -xa "anthropic bedrock vertex"
complete -c stateset -n "__fish_seen_subcommand_from login" -l verify -d "Verify key with API call"
complete -c stateset -n "__fish_seen_subcommand_from login" -l no-verify -d "Skip verification"

# whoami subcommand options
complete -c stateset -n "__fish_seen_subcommand_from whoami" -l json -d "Output as JSON"
complete -c stateset -n "__fish_seen_subcommand_from whoami" -l verbose -d "Show detailed info"

# env subcommand
complete -c stateset -n "__fish_seen_subcommand_from env" -a "list" -d "List environment variables"
complete -c stateset -n "__fish_seen_subcommand_from env" -a "get" -d "Get variable value"
complete -c stateset -n "__fish_seen_subcommand_from env" -a "set" -d "Set variable value"
complete -c stateset -n "__fish_seen_subcommand_from env" -a "unset" -d "Remove variable"
complete -c stateset -n "__fish_seen_subcommand_from env" -a "export" -d "Export as shell commands"
complete -c stateset -n "__fish_seen_subcommand_from env" -a "check" -d "Validate environment"

# env list options
complete -c stateset -n "__fish_seen_subcommand_from env; and __fish_seen_subcommand_from list" -l show-values -d "Show actual values"
complete -c stateset -n "__fish_seen_subcommand_from env; and __fish_seen_subcommand_from list" -l json -d "Output as JSON"
complete -c stateset -n "__fish_seen_subcommand_from env; and __fish_seen_subcommand_from list" -l filter -d "Filter by prefix"

# env export options
complete -c stateset -n "__fish_seen_subcommand_from env; and __fish_seen_subcommand_from export" -s f -l format -d "Export format" -xa "shell dotenv json"
complete -c stateset -n "__fish_seen_subcommand_from env; and __fish_seen_subcommand_from export" -s o -l output -d "Output file" -r

# tail subcommand options
complete -c stateset -n "__fish_seen_subcommand_from tail" -s n -l lines -d "Number of lines to show"
complete -c stateset -n "__fish_seen_subcommand_from tail" -s f -l follow -d "Follow output in real-time"
complete -c stateset -n "__fish_seen_subcommand_from tail" -l no-color -d "Disable colored output"
complete -c stateset -n "__fish_seen_subcommand_from tail" -l timestamps -d "Show timestamps"
complete -c stateset -n "__fish_seen_subcommand_from tail" -l filter -d "Filter by pattern"

# inspect subcommand
complete -c stateset -n "__fish_seen_subcommand_from inspect" -a "task" -d "Inspect a task"
complete -c stateset -n "__fish_seen_subcommand_from inspect" -a "agent" -d "Inspect an agent"
complete -c stateset -n "__fish_seen_subcommand_from inspect" -a "config" -d "Inspect configuration"
complete -c stateset -n "__fish_seen_subcommand_from inspect" -a "system" -d "System diagnostics"
complete -c stateset -n "__fish_seen_subcommand_from inspect" -a "tools" -d "Inspect available tools"

# inspect task options
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from task" -l json -d "Output as JSON"
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from task" -l verbose -d "Show all details"

# inspect agent options
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from agent" -l json -d "Output as JSON"
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from agent" -l verbose -d "Show all details"

# inspect config options
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from config" -l json -d "Output as JSON"
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from config" -l resolved -d "Show resolved values"

# inspect system options
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from system" -l json -d "Output as JSON"
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from system" -l verbose -d "Show all details"

# inspect tools options
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from tools" -l json -d "Output as JSON"
complete -c stateset -n "__fish_seen_subcommand_from inspect; and __fish_seen_subcommand_from tools" -l version -d "Tool version" -xa "20251124 20250124 20241022"

# rollback subcommand
complete -c stateset -n "__fish_seen_subcommand_from rollback" -a "list" -d "List available checkpoints"
complete -c stateset -n "__fish_seen_subcommand_from rollback" -a "create" -d "Create a checkpoint"
complete -c stateset -n "__fish_seen_subcommand_from rollback" -a "to" -d "Rollback to checkpoint"
complete -c stateset -n "__fish_seen_subcommand_from rollback" -a "last" -d "Rollback to last checkpoint"

# rollback list options
complete -c stateset -n "__fish_seen_subcommand_from rollback; and __fish_seen_subcommand_from list" -s n -l limit -d "Number of checkpoints"
complete -c stateset -n "__fish_seen_subcommand_from rollback; and __fish_seen_subcommand_from list" -l json -d "Output as JSON"

# rollback create options
complete -c stateset -n "__fish_seen_subcommand_from rollback; and __fish_seen_subcommand_from create" -s m -l message -d "Checkpoint description"

# rollback to options
complete -c stateset -n "__fish_seen_subcommand_from rollback; and __fish_seen_subcommand_from to" -l force -d "Skip confirmation"
complete -c stateset -n "__fish_seen_subcommand_from rollback; and __fish_seen_subcommand_from to" -l dry-run -d "Show what would change"

# rollback last options
complete -c stateset -n "__fish_seen_subcommand_from rollback; and __fish_seen_subcommand_from last" -l force -d "Skip confirmation"

# sync subcommand
complete -c stateset -n "__fish_seen_subcommand_from sync" -a "status" -d "Show sync status"
complete -c stateset -n "__fish_seen_subcommand_from sync" -a "setup" -d "Configure remote sync"
complete -c stateset -n "__fish_seen_subcommand_from sync" -a "push" -d "Push config to remote"
complete -c stateset -n "__fish_seen_subcommand_from sync" -a "pull" -d "Pull config from remote"
complete -c stateset -n "__fish_seen_subcommand_from sync" -a "diff" -d "Show differences"

# sync setup options
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from setup" -l provider -d "Sync provider" -xa "git s3 gcs"
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from setup" -l url -d "Remote URL"

# sync push options
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from push" -l force -d "Force overwrite"
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from push" -l dry-run -d "Show what would sync"
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from push" -s m -l message -d "Sync message"

# sync pull options
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from pull" -l force -d "Force overwrite local"
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from pull" -l dry-run -d "Show what would change"
complete -c stateset -n "__fish_seen_subcommand_from sync; and __fish_seen_subcommand_from pull" -l backup -d "Backup before pulling"

# api subcommand
complete -c stateset -n "__fish_seen_subcommand_from api" -a "messages" -d "Send messages API request"
complete -c stateset -n "__fish_seen_subcommand_from api" -a "models" -d "List available models"
complete -c stateset -n "__fish_seen_subcommand_from api" -a "usage" -d "Show API usage stats"
complete -c stateset -n "__fish_seen_subcommand_from api" -a "limits" -d "Show rate limits"

# api messages options
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from messages" -s m -l model -d "Model to use" -xa "claude-opus-4-6-20260131 claude-sonnet-4-5-20251101 claude-haiku-4-5-20251101"
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from messages" -l max-tokens -d "Max tokens"
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from messages" -l system -d "System prompt"
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from messages" -l json -d "Output raw JSON"
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from messages" -l stream -d "Stream response"

# api usage options
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from usage" -l period -d "Time period" -xa "day week month"
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from usage" -l json -d "Output as JSON"

# api limits options
complete -c stateset -n "__fish_seen_subcommand_from api; and __fish_seen_subcommand_from limits" -l json -d "Output as JSON"

# events subcommand
complete -c stateset -n "__fish_seen_subcommand_from events" -a "list" -d "List recent events"
complete -c stateset -n "__fish_seen_subcommand_from events" -a "watch" -d "Watch events in real-time"
complete -c stateset -n "__fish_seen_subcommand_from events" -a "clear" -d "Clear event history"
complete -c stateset -n "__fish_seen_subcommand_from events" -a "subscribe" -d "Subscribe to event types"

# events list options
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from list" -s n -l limit -d "Number of events"
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from list" -l type -d "Event type" -xa "all task agent api error system"
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from list" -l since -d "Events since time"
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from list" -l json -d "Output as JSON"

# events watch options
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from watch" -l type -d "Event type filter" -xa "all task agent api error system"
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from watch" -l no-color -d "Disable colors"

# events clear options
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from clear" -l force -d "Skip confirmation"
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from clear" -l older-than -d "Clear events older than"

# events subscribe options
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from subscribe" -l webhook -d "Webhook URL"
complete -c stateset -n "__fish_seen_subcommand_from events; and __fish_seen_subcommand_from subscribe" -l types -d "Event types (comma-separated)"
'''


def get_completion(shell: str) -> str:
    """Get completion script for the specified shell."""
    completions = {
        "bash": BASH_COMPLETION,
        "zsh": ZSH_COMPLETION,
        "fish": FISH_COMPLETION,
    }
    return completions.get(shell, "")


def print_completion(shell: str) -> None:
    """Print completion script for the specified shell."""
    script = get_completion(shell)
    if script:
        print(script.strip())
    else:
        print(f"Unknown shell: {shell}", file=__import__("sys").stderr)
        print(f"Supported shells: bash, zsh, fish", file=__import__("sys").stderr)
