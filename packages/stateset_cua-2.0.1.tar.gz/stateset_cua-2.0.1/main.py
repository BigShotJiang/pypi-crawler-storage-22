"""
Main entry point for multi-agent system with proper shutdown handling.

Architecture note (Workstream 2 refactoring):
    The following modules were extracted from this file to improve
    maintainability.  All symbols are re-exported here for backward
    compatibility so that ``from main import X`` continues to work.

    - agent.types          -- AgentType, AgentConfig, RuntimeOptions, TaskStatus
    - agent.task_completion -- analyze_task_completion()
    - agent.billing        -- send_stripe_meter_event()
    - agent.model_router   -- ModelRoutingPolicy, select_model_for_task(), …
    - agent.agent_selector -- load_agent_configs(), get_active_agents()
    - agent.state          -- GlobalState, cancel_all_tasks(), shutdown(), signal_handler()
    - agent.environment    -- validate_environment(), _get_int_env()
"""

import argparse
import asyncio
import os
import sys
import json
import base64
import signal
from typing import Any, Dict, List, Optional, Sequence, cast

import logging

# Use structured logging from logging_config module
from agent.logging_config import (
    get_logger,
    configure_logging,
    request_context,
    LogConfig,
    LogFormat,
)

# Import unified observability
from agent.observability import (
    get_observability,
    configure_observability,
    EventType,
)

# ── Re-exports from extracted modules (backward compatibility) ───────────────

from agent.types import (
    AgentType,
    AgentConfig,
    RuntimeOptions,
    TaskStatus,
    ToolSearchVariant,
    EffortLevel,
)

from agent.task_completion import analyze_task_completion

from agent.billing import send_stripe_meter_event

from agent.model_router import (
    MODEL_CLAUDE_OPUS,
    MODEL_CLAUDE_HAIKU,
    HAIKU_COMPLEXITY_THRESHOLD,
    HAIKU_MAX_THINKING_BUDGET,
    HAIKU_MAX_WORD_COUNT,
    SIMPLE_ACTION_KEYWORDS,
    HIGH_REASONING_KEYWORDS,
    ModelRoutingPolicy,
    DEFAULT_MODEL_POLICY,
    select_model_for_task,
    DEFAULT_MODEL_ROUTING_TEMPLATE,
    load_model_routing_policies,
    reload_model_routing_policies,
)
# MODEL_ROUTING_POLICIES is mutable module-level state in agent.model_router;
# we import the reference and also maintain a local alias updated at startup.
import agent.model_router as _model_router

from agent.agent_selector import load_agent_configs, get_active_agents as _get_active_agents

from agent.state import GlobalState
import agent.state as _agent_state

# ``state`` is the module-level singleton.  Tests may replace ``main.state``
# (via ``import main; main.state = ...``).  The helper functions below resolve
# the variable through the *main* module namespace so that such patches take
# effect.  We start with the canonical instance from ``agent.state``.
state: GlobalState = _agent_state.state


async def cancel_all_tasks():
    """Cancel all running tasks with timeout (uses ``main.state`` for test-patchability)."""
    import main as _self
    _state = _self.state
    tasks = await _state.get_all_tasks()
    if not tasks:
        return

    logger.info(f"Cancelling {len(tasks)} running tasks...",
                extra={'agent_type': 'system'})

    for task in tasks:
        if not task.done():
            task.cancel()

    try:
        await asyncio.wait_for(
            asyncio.gather(*tasks, return_exceptions=True),
            timeout=10.0,
        )
    except asyncio.TimeoutError:
        logger.warning(
            "Task cancellation timed out after 10s, forcing cleanup",
            extra={'agent_type': 'system'},
        )

    for task in tasks:
        await _state.remove_task(task)


async def shutdown():
    """Graceful shutdown sequence (uses ``main.state`` for test-patchability)."""
    import main as _self
    _state = _self.state
    if not await _state.start_shutdown():
        # Another shutdown already in progress
        return

    logger.info("Initiating shutdown sequence...", extra={'agent_type': 'system'})

    try:
        await cancel_all_tasks()
        logger.info("All tasks cancelled successfully", extra={'agent_type': 'system'})
    except asyncio.CancelledError:
        logger.info("Shutdown cancelled, forcing exit", extra={'agent_type': 'system'})
    except Exception as e:
        logger.error(f"Error during shutdown: {str(e)}", extra={'agent_type': 'system'})


def signal_handler(sig, frame):
    """Handle interrupt signals (uses ``main.state`` for test-patchability)."""
    import main as _self
    _state = _self.state
    if _state.is_shutting_down:
        logger.info("Forced shutdown...", extra={'agent_type': 'system'})
        sys.exit(1)

    loop = asyncio.get_running_loop()
    loop.create_task(shutdown())

from agent.environment import validate_environment, _get_int_env

# ── Core loop / tool imports ─────────────────────────────────────────────────

from agent.loop import sampling_loop, APIProvider
from agent.tools import ToolResult, ToolVersion, TOOL_GROUPS_BY_VERSION
from agent.skill_manager import get_skill_manager
from anthropic.types.beta import BetaMessage, BetaMessageParam
from anthropic import APIResponse

# ── Module-level initialisation ──────────────────────────────────────────────

# Configure structured logging based on environment
_log_config = LogConfig.from_environment()
configure_logging(_log_config)

# Use structured logger from logging_config
logger = get_logger(__name__, agent_type="system")

# Suppress verbose httpx logging
httpx_logger = logging.getLogger('httpx')
httpx_logger.setLevel(logging.WARNING)

# Load configurations at startup
AGENT_CONFIGS: Dict[str, AgentConfig] = load_agent_configs()

# Create reverse mapping for O(1) agent name lookup
AGENT_NAME_BY_ID: Dict[int, str] = {id(config): name for name, config in AGENT_CONFIGS.items()}

# Initialize model routing policies on startup (needs AGENT_CONFIGS)
MODEL_ROUTING_POLICIES: Dict[str, ModelRoutingPolicy] = load_model_routing_policies(AGENT_CONFIGS)
_model_router.MODEL_ROUTING_POLICIES = MODEL_ROUTING_POLICIES

# Screen size defaults (override via environment variables WIDTH/HEIGHT)
WIDTH = _get_int_env("WIDTH", 1280)
HEIGHT = _get_int_env("HEIGHT", 720)


# ── Wrapper for get_active_agents (uses module-level AGENT_CONFIGS) ──────────

def get_active_agents(instruction: str) -> List[AgentConfig]:
    """Determine which agents should handle the instruction"""
    return _get_active_agents(instruction, AGENT_CONFIGS)


# ── CLI Parsing ──────────────────────────────────────────────────────────────

def parse_runtime_options() -> RuntimeOptions:
    """Parse CLI arguments into runtime options."""
    parser = argparse.ArgumentParser(description="Run the Stateset agent loop.")
    parser.add_argument(
        "-i",
        "--instruction",
        dest="instruction_tokens",
        nargs="+",
        help="Instruction text (overrides positional instruction).",
    )
    parser.add_argument(
        "positional_instruction",
        nargs="*",
        help="Instruction text supplied without flags.",
    )
    parser.add_argument(
        "--tool-version",
        choices=sorted(TOOL_GROUPS_BY_VERSION.keys()),
        help="Select a specific tool bundle to use.",
    )
    parser.add_argument(
        "--cli",
        dest="cli_mode",
        action="store_true",
        help="Shortcut for --tool-version cli_20250124 (disables computer-use tools).",
    )
    parser.add_argument(
        "--agent-type",
        dest="agent_types",
        action="append",
        choices=sorted(AGENT_CONFIGS.keys()),
        help="Restrict execution to specific agent types (can be repeated).",
    )
    parser.add_argument(
        "--tool-search",
        dest="tool_search_variant",
        choices=["regex", "bm25"],
        help="Enable Anthropic tool search beta and choose the variant.",
    )
    parser.add_argument(
        "--defer-tool",
        dest="defer_tools",
        action="append",
        metavar="TOOL_NAME",
        help="Mark a tool name to load via tool search (repeatable).",
    )
    parser.add_argument(
        "--effort",
        dest="effort_level",
        choices=["low", "medium", "high"],
        help="Control Claude Opus effort level (requires opus 4.5).",
    )

    args = parser.parse_args()

    instruction_tokens: List[str] = []
    if args.instruction_tokens:
        instruction_tokens = args.instruction_tokens
    elif args.positional_instruction:
        instruction_tokens = args.positional_instruction

    instruction = " ".join(instruction_tokens)

    tool_version = args.tool_version
    if args.cli_mode:
        if tool_version and tool_version != "cli_20250124":
            parser.error("Cannot combine --cli with --tool-version (choose one).")
        tool_version = "cli_20250124"
    if not tool_version:
        tool_version = "computer_use_20251124"

    agent_types = args.agent_types or None
    tool_search_variant = cast(Optional[ToolSearchVariant], args.tool_search_variant)
    defer_tool_names = tuple(args.defer_tools or [])
    if not tool_search_variant:
        defer_tool_names = tuple()
    effort_level = cast(Optional[EffortLevel], args.effort_level)

    return RuntimeOptions(
        instruction=instruction,
        tool_version=cast(ToolVersion, tool_version),
        agent_types=agent_types,
        tool_search_variant=tool_search_variant,
        tool_search_defer=defer_tool_names,
        effort_level=effort_level,
    )


# ── Agent Execution ──────────────────────────────────────────────────────────

async def run_agent(
    instruction: str,
    agent_config: AgentConfig,
    api_key: str,
    agent_type: str,
    tool_version: ToolVersion,
    tool_search_variant: Optional[ToolSearchVariant] = None,
    tool_search_defer: Sequence[str] | None = None,
    effort_level: Optional[EffortLevel] = None,
):
    """Run a single agent with error handling, billing and completion detection"""
    from agent.metrics import get_metrics
    from agent.adaptive_config import get_adaptive_config
    import uuid

    # Get observability instance
    obs = get_observability()

    # Start metrics tracking
    metrics = get_metrics()
    task_id = str(uuid.uuid4())[:8]
    metrics.start_task(task_id, agent_type, instruction)

    # Get adaptive configuration
    adaptive_config = get_adaptive_config(instruction, agent_type)
    thinking_budget = adaptive_config.get("thinking_budget")
    max_tokens = adaptive_config.get("max_tokens")
    if isinstance(thinking_budget, int):
        minimum_max_tokens = thinking_budget + max(512, thinking_budget // 4)
        if not isinstance(max_tokens, int) or max_tokens <= thinking_budget:
            adjusted_max_tokens = minimum_max_tokens if isinstance(max_tokens, int) else minimum_max_tokens
            adaptive_config["max_tokens"] = adjusted_max_tokens
            logger.info(
                "Adjusted max_tokens to %s to exceed thinking budget %s",
                adaptive_config["max_tokens"],
                thinking_budget,
                extra={'agent_type': agent_type}
            )
        elif max_tokens < minimum_max_tokens:
            adaptive_config["max_tokens"] = minimum_max_tokens
            logger.info(
                "Raised max_tokens from %s to %s to provide headroom over thinking budget %s",
                max_tokens,
                adaptive_config["max_tokens"],
                thinking_budget,
                extra={'agent_type': agent_type}
            )

    # Resolve skills for this agent
    skill_manager = get_skill_manager()
    agent_skills = skill_manager.get_agent_skills(agent_type)
    skill_container_payload = skill_manager.container_payload(agent_skills)
    skill_suffix = skill_manager.build_system_suffix(agent_skills)
    if agent_skills:
        activated = ", ".join(skill.display_name for skill in agent_skills)
        logger.info(
            f"Loaded skills: {activated}",
            extra={'agent_type': agent_type}
        )
    else:
        logger.warning(
            "No skills resolved for agent",
            extra={'agent_type': agent_type}
        )

    logger.info(
        f"Running agent {agent_type} with instruction: '{instruction}' | "
        f"Thinking: {adaptive_config['thinking_budget']} | "
        f"Complexity: {adaptive_config['complexity_score']:.0%}",
        extra={'agent_type': agent_type}
    )

    model_name, model_reason = select_model_for_task(
        instruction=instruction,
        agent_type=agent_type,
        adaptive_config=adaptive_config,
        agent_config=agent_config,
    )
    logger.info(
        f"Selected model: {model_name} ({model_reason})",
        extra={'agent_type': agent_type}
    )
    logger.info(
        f"Using tool version: {tool_version}",
        extra={'agent_type': agent_type}
    )
    if tool_search_variant:
        deferred_display = ", ".join(tool_search_defer or []) or "none"
        logger.info(
            f"Tool search enabled ({tool_search_variant}) | deferred tools: {deferred_display}",
            extra={'agent_type': agent_type}
        )
    if effort_level:
        logger.info(
            f"Effort level set to {effort_level}",
            extra={'agent_type': agent_type}
        )

    def output_callback(content_block):
        if isinstance(content_block, dict) and content_block.get("type") == "text":
            print(f"[{agent_type}] Assistant:", content_block.get("text"))

    def tool_output_callback(result: ToolResult, tool_use_id: str):
        if result.output:
            print(f"[{agent_type}] > Tool Output [{tool_use_id}]:", result.output)
        if result.error:
            print(f"[{agent_type}] !!! Tool Error [{tool_use_id}]:", result.error)
        if result.base64_image:
            os.makedirs(f"screenshots/{agent_type}", exist_ok=True)
            image_data = result.base64_image
            with open(f"screenshots/{agent_type}/screenshot_{tool_use_id}.png", "wb") as f:
                f.write(base64.b64decode(image_data))
            print(f"[{agent_type}] Took screenshot screenshot_{tool_use_id}.png")

    def api_response_callback(request, response, error):
        if error:
            print(f"[{agent_type}] API Error: {error}")
            return
        try:
            if response and hasattr(response, 'model_dump'):
                content = response.model_dump().get("content", [])
                print(f"\n[{agent_type}] ---------------\nAPI Response:\n",
                      json.dumps(content, indent=4), "\n")
        except Exception as e:
            print(f"[{agent_type}] Error parsing API response: {e}")

    task = asyncio.current_task()
    if task:
        await state.add_task(task)

    # Use observability task context for automatic correlation and tracing
    async with obs.task_context(agent_type, agent_config.agent_id, instruction, request_id=task_id):
        try:
            messages: List[BetaMessageParam] = [{
                "role": "user",
                "content": instruction,
            }]

            response = await sampling_loop(
                model=model_name,
                provider=APIProvider.ANTHROPIC,
                system_prompt_suffix=skill_suffix,
                messages=messages,
                output_callback=output_callback,
                tool_output_callback=tool_output_callback,
                api_response_callback=api_response_callback,
                api_key=api_key,
                org_id=agent_config.org_id,
                agent_id=agent_config.agent_id,
                agent_type=agent_type,
                only_n_most_recent_images=20,
                max_tokens=adaptive_config['max_tokens'],  # Adaptive based on task
                tool_version=tool_version,
                thinking_budget=adaptive_config['thinking_budget'],  # Adaptive based on complexity
                width=WIDTH,
                height=HEIGHT,
                skill_container=skill_container_payload,
                enable_tool_search=tool_search_variant is not None,
                tool_search_variant=tool_search_variant or "regex",
                deferred_tool_names=tool_search_defer if tool_search_variant else None,
                effort_level=effort_level,
            )

            # Analyze task completion
            total_tokens = response.input_tokens + response.output_tokens
            task_status = await analyze_task_completion(response.messages, agent_type)
            task_status = task_status._replace(tokens_used=total_tokens)

            # Record metrics
            metrics.record_tokens(
                input_tokens=response.input_tokens,
                output_tokens=response.output_tokens
            )

            # Log completion status via observability
            if task_status.completed:
                obs.log_info(
                    f"Task completed successfully: {task_status.details}",
                    task_completed=True,
                    tokens_used=total_tokens,
                )

                # Handle billing for completed tasks (all agent types)
                if agent_config.stripe_customer_id:
                    await send_stripe_meter_event(
                        agent_config.stripe_customer_id,
                        task_status.tokens_used,
                        agent_type
                    )
                    obs.log_info(
                        f"Logged {task_status.tokens_used} tokens for completed {agent_type} task",
                        stripe_customer_id=agent_config.stripe_customer_id,
                        tokens_logged=task_status.tokens_used,
                    )
            else:
                obs.log_warning(
                    f"Task may not be complete: {task_status.details}",
                    task_completed=False,
                )

            # End metrics tracking
            metrics.end_task(success=task_status.completed)

            # Log cost summary via observability
            budget_status = metrics.get_budget_status()
            obs.log_metric(
                "task_cost",
                metrics.cost_tracker.get_task_cost(),
                unit="USD",
                daily_spent=budget_status['daily']['spent'],
                daily_budget=budget_status['daily']['budget'],
            )

            return response, task_status

        except asyncio.CancelledError:
            obs.log_info(f"Agent {agent_type} task cancelled", cancelled=True)
            if metrics.current_task:
                metrics.record_error("Task cancelled")
                metrics.end_task(success=False)
            raise
        except Exception as e:
            obs.log_error(f"Error in agent {agent_type}: {str(e)}", e)
            if metrics.current_task:
                metrics.record_error(str(e))
                metrics.end_task(success=False)
            raise
        finally:
            if task:
                await state.remove_task(task)


async def continuous_loop(options: RuntimeOptions):
    """Run multiple agents continuously with completion tracking."""
    tool_group = TOOL_GROUPS_BY_VERSION[options.tool_version]

    try:
        config = validate_environment(require_display=tool_group.requires_display)
        api_key = config['ANTHROPIC_API_KEY']
        logger.info("✓ Environment validation passed", extra={'agent_type': 'system'})
        logger.info(
            f"Active tool version: {options.tool_version} (requires_display={tool_group.requires_display})",
            extra={'agent_type': 'system'}
        )
        if not tool_group.requires_display:
            logger.info(
                "Computer-use tools disabled; running in CLI-only mode",
                extra={'agent_type': 'system'}
            )
    except ValueError as e:
        logger.error(str(e), extra={'agent_type': 'system'})
        raise

    instruction = options.instruction.strip() if options.instruction else ""
    if not instruction:
        instruction = "Monitor and process tasks"

    specified_agents: Optional[List[AgentConfig]] = None
    if options.agent_types:
        invalid = [agent for agent in options.agent_types if agent not in AGENT_CONFIGS]
        if invalid:
            raise ValueError(f"Unknown agent types requested: {', '.join(invalid)}")
        specified_agents = [AGENT_CONFIGS[agent_name] for agent_name in options.agent_types]

    while state.running:
        try:
            logger.info(
                f"Starting new task with instruction: '{instruction}'",
                extra={'agent_type': 'system'}
            )
            logger.info(
                "Press Ctrl+C to exit gracefully...",
                extra={'agent_type': 'system'}
            )

            active_agents = specified_agents or get_active_agents(instruction)
            if not active_agents:
                logger.warning(
                    "No matching agents found for the instruction",
                    extra={'agent_type': 'system'}
                )
                return

            # Budget pre-flight check before spawning agents
            try:
                metrics = get_metrics()
                budget_status = metrics.get_budget_status()
                if budget_status['daily']['remaining'] <= 0:
                    logger.warning(
                        "Daily budget exhausted ($%.2f spent of $%.2f). Skipping task.",
                        budget_status['daily']['spent'],
                        budget_status['daily']['budget'],
                        extra={'agent_type': 'system'},
                    )
                    await asyncio.sleep(60)  # Wait before checking again
                    continue
            except Exception:
                pass  # Budget tracking may not be configured; proceed anyway

            tasks = []
            for agent in active_agents:
                if not state.running:
                    break

                # O(1) lookup using reverse mapping
                agent_type = AGENT_NAME_BY_ID.get(id(agent), "UNKNOWN")

                task = asyncio.create_task(
                    run_agent(
                        instruction=instruction,
                        agent_config=agent,
                        api_key=api_key,
                        agent_type=agent_type,
                        tool_version=options.tool_version,
                        tool_search_variant=options.tool_search_variant,
                        tool_search_defer=options.tool_search_defer,
                        effort_level=options.effort_level,
                    )
                )
                await state.add_task(task)
                tasks.append(task)

            if tasks and state.running:
                try:
                    results = await asyncio.gather(*tasks)

                    for (response, task_status), agent in zip(results, active_agents):
                        agent_type = next(
                            name for name, config in AGENT_CONFIGS.items()
                            if config == agent
                        )
                        if not task_status.completed:
                            logger.warning(
                                f"{agent_type} task incomplete: {task_status.details}",
                                extra={'agent_type': 'system'}
                            )

                except asyncio.CancelledError:
                    logger.info(
                        "Tasks cancelled during shutdown",
                        extra={'agent_type': 'system'}
                    )
                except Exception as e:
                    logger.error(
                        f"Error in tasks: {str(e)}",
                        extra={'agent_type': 'system'}
                    )
                finally:
                    for task in tasks:
                        await state.remove_task(task)

            if not state.running:
                break

            await asyncio.sleep(1)

        except Exception as e:
            logger.error(
                f"Error in continuous loop: {str(e)}",
                extra={'agent_type': 'system'}
            )
            if not state.running:
                break

            # Use exception-aware retry delays instead of fixed 5s
            from agent.exceptions import is_retryable, get_retry_delay
            if is_retryable(e):
                delay = get_retry_delay(e)
                logger.info(
                    f"Retryable error, waiting {delay:.1f}s before retry",
                    extra={'agent_type': 'system'},
                )
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "Non-retryable error encountered, waiting 5s",
                    extra={'agent_type': 'system'},
                )
                await asyncio.sleep(5)

async def main(options: RuntimeOptions):
    """Main entry point"""
    from agent.metrics import get_metrics

    # Configure observability at startup
    obs = configure_observability(
        enable_metrics=True,
        enable_tracing=True,
        enable_streaming=True,
        metrics_port=int(os.environ.get("METRICS_PORT", "9090")),
        otlp_endpoint=os.environ.get("OTLP_ENDPOINT"),  # e.g., "localhost:4317"
        service_name="stateset-agent",
    )

    obs.log_info(
        "Observability configured",
        metrics_enabled=True,
        tracing_enabled=True,
        streaming_enabled=True,
    )

    # Perform initial health check — block startup on critical failures
    try:
        health = await obs.get_health()
        if health.status.value == "unhealthy":
            failed_checks = [c.name for c in health.checks if c.status.value != "healthy"]
            obs.log_error(
                "Initial health check failed",
                health_status=health.status.value,
                checks=failed_checks,
            )
            # Block startup if the API check failed (can't do any work without it)
            api_failed = any(c.name == "anthropic_api" for c in health.checks
                            if c.status.value != "healthy")
            if api_failed:
                raise RuntimeError(
                    f"Cannot start: Anthropic API health check failed. "
                    f"Failing checks: {failed_checks}"
                )
        else:
            obs.log_info(
                f"Initial health check: {health.status.value}",
                uptime_seconds=health.uptime_seconds,
                checks_passed=len([c for c in health.checks if c.status.value == "healthy"]),
            )
    except RuntimeError:
        raise  # Re-raise blocking startup errors
    except Exception as e:
        obs.log_warning(f"Health check failed: {e}", error=str(e))

    try:
        # Set up signal handlers
        for sig in (signal.SIGINT, signal.SIGTERM):
            signal.signal(sig, signal_handler)

        # Run the continuous loop
        await continuous_loop(options)
    except asyncio.CancelledError:
        obs.log_info("Main task cancelled", cancelled=True)
    except Exception as e:
        obs.log_error(f"Error in main: {str(e)}", e)
    finally:
        # Export metrics before shutdown
        try:
            metrics = get_metrics()
            metrics_file = metrics.export_metrics()
            costs_file = metrics.export_costs()
            logger.info(f"Metrics exported to {metrics_file}", extra={'agent_type': 'system'})
            logger.info(f"Costs exported to {costs_file}", extra={'agent_type': 'system'})
            metrics.print_summary()

            # Print parallel execution stats
            try:
                from agent.parallel_executor import get_parallel_executor
                parallel_executor = get_parallel_executor()
                parallel_executor.print_stats()
            except Exception:
                pass  # Parallel executor may not have been used
        except Exception as e:
            logger.error(f"Error exporting metrics: {e}", extra={'agent_type': 'system'})

        if not state.is_shutting_down:
            await shutdown()

if __name__ == "__main__":
    runtime_options = parse_runtime_options()
    try:
        asyncio.run(main(runtime_options))
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.error(f"Critical error: {str(e)}", extra={'agent_type': 'system'})
    finally:
        sys.exit(0)
