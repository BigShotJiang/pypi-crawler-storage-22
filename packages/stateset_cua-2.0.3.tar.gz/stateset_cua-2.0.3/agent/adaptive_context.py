"""
Adaptive Context Manager for StateSet Computer Use Agent.

This module provides intelligent context management for 24/7 operation:

1. Automatic Context Compaction
   - Proactive compression before thresholds are hit
   - Intelligent retention of important information
   - Aggressive cleanup for long-running tasks

2. Memory Optimization
   - Hierarchical memory system (hot/warm/cold)
   - Automatic persistence of important discoveries
   - Context-aware retrieval

3. Attention Budget Management
   - Real-time attention quality monitoring
   - Dynamic threshold adjustment
   - Cost-aware optimization

4. Smart Summarization
   - Automatic summarization of verbose outputs
   - Key finding extraction
   - Progressive detail reduction

Based on Anthropic's context engineering research for 95% cost savings.
"""

import asyncio
import logging
import time
import json
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Set
from pathlib import Path
from collections import deque

from agent.context_optimizer import (
    ContextBudget, JustInTimeRetrieval, ContextCompactor,
    SubAgentCompressor, get_context_optimizer
)
from agent.logging_config import get_logger

logger = get_logger(__name__)


class AttentionQuality(Enum):
    """Attention quality levels based on context size"""
    EXCELLENT = "excellent"  # < 30k tokens - optimal performance
    GOOD = "good"            # 30k-50k tokens - good performance
    DEGRADED = "degraded"    # 50k-80k tokens - noticeable degradation
    WARNING = "warning"      # 80k-120k tokens - significant degradation
    CRITICAL = "critical"    # > 120k tokens - severe degradation


class MemoryTier(Enum):
    """Memory tiers for hierarchical storage"""
    HOT = "hot"      # In context, immediate access
    WARM = "warm"    # In persistent memory, quick retrieval
    COLD = "cold"    # Archived, needs explicit loading


@dataclass
class ContextMetrics:
    """Real-time context metrics"""
    current_tokens: int = 0
    peak_tokens: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    compactions_performed: int = 0
    tokens_freed: int = 0
    estimated_cost: float = 0.0

    # Quality tracking
    time_at_excellent: float = 0.0
    time_at_good: float = 0.0
    time_at_degraded: float = 0.0
    time_at_warning: float = 0.0
    time_at_critical: float = 0.0

    def update_quality_time(self, quality: AttentionQuality, duration: float):
        """Update time spent at each quality level"""
        if quality == AttentionQuality.EXCELLENT:
            self.time_at_excellent += duration
        elif quality == AttentionQuality.GOOD:
            self.time_at_good += duration
        elif quality == AttentionQuality.DEGRADED:
            self.time_at_degraded += duration
        elif quality == AttentionQuality.WARNING:
            self.time_at_warning += duration
        elif quality == AttentionQuality.CRITICAL:
            self.time_at_critical += duration

    def get_quality_distribution(self) -> Dict[str, float]:
        """Get percentage of time at each quality level"""
        total = (self.time_at_excellent + self.time_at_good +
                self.time_at_degraded + self.time_at_warning + self.time_at_critical)

        if total == 0:
            return {q.value: 0.0 for q in AttentionQuality}

        return {
            AttentionQuality.EXCELLENT.value: (self.time_at_excellent / total) * 100,
            AttentionQuality.GOOD.value: (self.time_at_good / total) * 100,
            AttentionQuality.DEGRADED.value: (self.time_at_degraded / total) * 100,
            AttentionQuality.WARNING.value: (self.time_at_warning / total) * 100,
            AttentionQuality.CRITICAL.value: (self.time_at_critical / total) * 100,
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            'current_tokens': self.current_tokens,
            'peak_tokens': self.peak_tokens,
            'total_input_tokens': self.total_input_tokens,
            'total_output_tokens': self.total_output_tokens,
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'compactions_performed': self.compactions_performed,
            'tokens_freed': self.tokens_freed,
            'estimated_cost': f"${self.estimated_cost:.4f}",
            'quality_distribution': self.get_quality_distribution()
        }


@dataclass
class MemoryEntry:
    """Entry in the hierarchical memory system"""
    key: str
    content: str
    tier: MemoryTier
    created_at: datetime
    accessed_at: datetime
    access_count: int = 0
    importance: float = 0.5  # 0.0 - 1.0
    token_estimate: int = 0
    tags: Set[str] = field(default_factory=set)

    def __post_init__(self):
        # Estimate tokens (4 chars per token)
        self.token_estimate = len(self.content) // 4


class AdaptiveThresholds:
    """Dynamically adjusting thresholds based on task patterns"""

    def __init__(self):
        # Base thresholds (from Anthropic research)
        self.base_excellent = 30_000
        self.base_good = 50_000
        self.base_degraded = 80_000
        self.base_warning = 120_000
        self.base_critical = 160_000

        # Adjustment factors
        self.task_complexity_factor = 1.0
        self.error_rate_factor = 1.0
        self.time_pressure_factor = 1.0

        # History for learning
        self._performance_history: deque = deque(maxlen=100)

    def adjust_for_task(
        self,
        task_complexity: float,
        error_rate: float,
        remaining_time_percent: float
    ):
        """Adjust thresholds based on current task characteristics"""

        # Complex tasks need more headroom
        self.task_complexity_factor = 1.0 - (task_complexity * 0.2)

        # High error rate means we need more context for debugging
        if error_rate > 0.3:
            self.error_rate_factor = 1.2  # Allow more context
        else:
            self.error_rate_factor = 1.0

        # Time pressure reduces thresholds (be more aggressive)
        if remaining_time_percent < 0.2:
            self.time_pressure_factor = 0.8
        else:
            self.time_pressure_factor = 1.0

    def get_threshold(self, level: AttentionQuality) -> int:
        """Get adjusted threshold for a quality level"""
        factor = (self.task_complexity_factor *
                 self.error_rate_factor *
                 self.time_pressure_factor)

        base = {
            AttentionQuality.EXCELLENT: self.base_excellent,
            AttentionQuality.GOOD: self.base_good,
            AttentionQuality.DEGRADED: self.base_degraded,
            AttentionQuality.WARNING: self.base_warning,
            AttentionQuality.CRITICAL: self.base_critical,
        }.get(level, self.base_critical)

        return int(base * factor)

    def record_performance(
        self,
        tokens_used: int,
        task_success: bool,
        quality: AttentionQuality
    ):
        """Record performance for future threshold learning"""
        self._performance_history.append({
            'tokens': tokens_used,
            'success': task_success,
            'quality': quality.value,
            'timestamp': datetime.utcnow().isoformat()
        })


class HierarchicalMemory:
    """
    Hierarchical memory system for persistent knowledge.

    Tiers:
    - HOT: Currently in context (immediate access)
    - WARM: In persistent memory (quick retrieval)
    - COLD: Archived (needs explicit loading)
    """

    def __init__(
        self,
        memory_dir: str = "/tmp/agent_adaptive_memory",
        hot_limit_tokens: int = 10000,
        warm_limit_tokens: int = 50000
    ):
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)

        self.hot_limit = hot_limit_tokens
        self.warm_limit = warm_limit_tokens

        # In-memory storage for hot tier
        self.hot_memory: Dict[str, MemoryEntry] = {}
        self.warm_index: Dict[str, str] = {}  # key -> file path

        # Access tracking
        self.access_log: deque = deque(maxlen=1000)

    def _generate_key(self, content: str, tags: Optional[Set[str]] = None) -> str:
        """Generate a unique key for content"""
        hash_input = content[:500] + str(tags or set())
        return hashlib.md5(hash_input.encode()).hexdigest()[:12]

    async def store(
        self,
        content: str,
        importance: float = 0.5,
        tags: Optional[Set[str]] = None,
        force_tier: Optional[MemoryTier] = None
    ) -> str:
        """Store content in appropriate tier"""

        key = self._generate_key(content, tags)
        now = datetime.utcnow()

        entry = MemoryEntry(
            key=key,
            content=content,
            tier=force_tier or self._determine_tier(importance),
            created_at=now,
            accessed_at=now,
            importance=importance,
            tags=tags or set()
        )

        if entry.tier == MemoryTier.HOT:
            await self._store_hot(entry)
        elif entry.tier == MemoryTier.WARM:
            await self._store_warm(entry)
        else:
            await self._store_cold(entry)

        logger.debug(f"Stored memory '{key}' in {entry.tier.value} tier")
        return key

    def _determine_tier(self, importance: float) -> MemoryTier:
        """Determine storage tier based on importance"""
        if importance >= 0.8:
            return MemoryTier.HOT
        elif importance >= 0.4:
            return MemoryTier.WARM
        else:
            return MemoryTier.COLD

    async def _store_hot(self, entry: MemoryEntry):
        """Store in hot tier (in-memory)"""
        # Check capacity and demote if needed
        current_tokens = sum(e.token_estimate for e in self.hot_memory.values())

        while current_tokens + entry.token_estimate > self.hot_limit and self.hot_memory:
            # Demote least important/accessed entry
            demote_key = min(
                self.hot_memory.keys(),
                key=lambda k: self.hot_memory[k].importance * self.hot_memory[k].access_count
            )
            await self._demote_to_warm(demote_key)
            current_tokens = sum(e.token_estimate for e in self.hot_memory.values())

        self.hot_memory[entry.key] = entry

    async def _store_warm(self, entry: MemoryEntry):
        """Store in warm tier (persistent file)"""
        file_path = self.memory_dir / "warm" / f"{entry.key}.json"
        file_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            'key': entry.key,
            'content': entry.content,
            'tier': entry.tier.value,
            'created_at': entry.created_at.isoformat(),
            'accessed_at': entry.accessed_at.isoformat(),
            'access_count': entry.access_count,
            'importance': entry.importance,
            'tags': list(entry.tags)
        }

        file_path.write_text(json.dumps(data, indent=2))
        self.warm_index[entry.key] = str(file_path)

    async def _store_cold(self, entry: MemoryEntry):
        """Store in cold tier (archived)"""
        file_path = self.memory_dir / "cold" / f"{entry.key}.json"
        file_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            'key': entry.key,
            'content': entry.content,
            'tier': entry.tier.value,
            'created_at': entry.created_at.isoformat(),
            'accessed_at': entry.accessed_at.isoformat(),
            'access_count': entry.access_count,
            'importance': entry.importance,
            'tags': list(entry.tags)
        }

        file_path.write_text(json.dumps(data, indent=2))

    async def _demote_to_warm(self, key: str):
        """Demote an entry from hot to warm tier"""
        if key in self.hot_memory:
            entry = self.hot_memory.pop(key)
            entry.tier = MemoryTier.WARM
            await self._store_warm(entry)
            logger.debug(f"Demoted memory '{key}' to warm tier")

    async def retrieve(self, key: str) -> Optional[str]:
        """Retrieve content by key"""
        self.access_log.append({
            'key': key,
            'timestamp': datetime.utcnow().isoformat()
        })

        # Check hot tier
        if key in self.hot_memory:
            entry = self.hot_memory[key]
            entry.accessed_at = datetime.utcnow()
            entry.access_count += 1
            return entry.content

        # Check warm tier
        if key in self.warm_index:
            file_path = Path(self.warm_index[key])
            if file_path.exists():
                data = json.loads(file_path.read_text())
                # Promote to hot if frequently accessed
                if data.get('access_count', 0) > 5:
                    await self._promote_to_hot(data)
                return data.get('content')

        # Check cold tier
        cold_path = self.memory_dir / "cold" / f"{key}.json"
        if cold_path.exists():
            data = json.loads(cold_path.read_text())
            return data.get('content')

        return None

    async def _promote_to_hot(self, data: Dict[str, Any]):
        """Promote an entry to hot tier"""
        entry = MemoryEntry(
            key=data['key'],
            content=data['content'],
            tier=MemoryTier.HOT,
            created_at=datetime.fromisoformat(data['created_at']),
            accessed_at=datetime.utcnow(),
            access_count=data.get('access_count', 0) + 1,
            importance=data.get('importance', 0.5),
            tags=set(data.get('tags', []))
        )
        await self._store_hot(entry)
        logger.debug(f"Promoted memory '{entry.key}' to hot tier")

    async def search(
        self,
        query: str,
        tags: Optional[Set[str]] = None,
        limit: int = 5
    ) -> List[Tuple[str, str]]:
        """Search for relevant memories"""
        results = []
        query_lower = query.lower()

        # Search hot tier first
        for key, entry in self.hot_memory.items():
            if tags and not tags.intersection(entry.tags):
                continue
            if query_lower in entry.content.lower():
                results.append((key, entry.content[:200] + '...'))

        # Search warm tier
        for key, file_path in self.warm_index.items():
            if len(results) >= limit:
                break
            try:
                data = json.loads(Path(file_path).read_text())
                if tags and not tags.intersection(set(data.get('tags', []))):
                    continue
                if query_lower in data.get('content', '').lower():
                    results.append((key, data['content'][:200] + '...'))
            except Exception:
                continue

        return results[:limit]

    def get_hot_content(self) -> str:
        """Get all hot tier content for context injection"""
        if not self.hot_memory:
            return ""

        content_parts = ["<MEMORY_HOT_TIER>"]
        for key, entry in sorted(
            self.hot_memory.items(),
            key=lambda x: x[1].importance,
            reverse=True
        ):
            tags_str = ', '.join(entry.tags) if entry.tags else 'general'
            content_parts.append(f"[{tags_str}]: {entry.content[:500]}")
        content_parts.append("</MEMORY_HOT_TIER>")

        return '\n'.join(content_parts)

    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics"""
        hot_tokens = sum(e.token_estimate for e in self.hot_memory.values())

        return {
            'hot_entries': len(self.hot_memory),
            'hot_tokens': hot_tokens,
            'warm_entries': len(self.warm_index),
            'access_count': len(self.access_log),
            'hot_limit': self.hot_limit,
            'warm_limit': self.warm_limit
        }


class SmartSummarizer:
    """Intelligent summarization for context compression"""

    @staticmethod
    def extract_key_findings(content: str, max_findings: int = 10) -> List[str]:
        """Extract key findings from verbose content"""
        findings = []

        # Look for common patterns indicating important info
        patterns = [
            'error:', 'warning:', 'success:', 'found:', 'discovered:',
            'important:', 'note:', 'bug:', 'fixed:', 'issue:',
            '✓', '✗', '→', '•', '-'
        ]

        lines = content.split('\n')

        for line in lines:
            line_lower = line.lower().strip()

            # Check for pattern matches
            for pattern in patterns:
                if pattern in line_lower:
                    finding = line.strip()
                    if finding and len(finding) > 10:
                        findings.append(finding[:200])
                        break

            if len(findings) >= max_findings:
                break

        # If not enough pattern matches, take first/last lines
        if len(findings) < 3:
            if lines:
                findings.insert(0, lines[0].strip()[:200])
            if len(lines) > 1:
                findings.append(lines[-1].strip()[:200])

        return findings[:max_findings]

    @staticmethod
    def summarize_tool_output(
        tool_name: str,
        output: str,
        max_tokens: int = 300
    ) -> str:
        """Summarize tool output for context efficiency"""

        max_chars = max_tokens * 4  # Rough token-to-char ratio

        if len(output) <= max_chars:
            return output

        # Different strategies for different tools
        if tool_name == 'bash':
            # For bash, keep first and last lines (often most important)
            lines = output.split('\n')
            if len(lines) > 10:
                summary_lines = (
                    lines[:5] +
                    [f'... [{len(lines) - 10} lines omitted] ...'] +
                    lines[-5:]
                )
                return '\n'.join(summary_lines)

        elif tool_name == 'computer':
            # For computer tool, just indicate action was taken
            return f"[Action completed - {len(output)} chars of output]"

        elif tool_name == 'memory':
            # For memory, keep key info
            return output[:max_chars] + '...[truncated]'

        # Default: head + tail strategy
        head_size = int(max_chars * 0.6)
        tail_size = int(max_chars * 0.3)

        return (
            output[:head_size] +
            f'\n...[{len(output) - head_size - tail_size} chars omitted]...\n' +
            output[-tail_size:]
        )

    @staticmethod
    def compress_message_history(
        messages: List[Dict[str, Any]],
        target_tokens: int = 50000,
        keep_recent: int = 5
    ) -> List[Dict[str, Any]]:
        """Compress message history to target token count"""

        if len(messages) <= keep_recent:
            return messages

        # Estimate current size
        total_chars = sum(len(json.dumps(m)) for m in messages)
        current_tokens = total_chars // 4

        if current_tokens <= target_tokens:
            return messages

        # Keep recent messages intact
        recent = messages[-keep_recent:]
        older = messages[:-keep_recent]

        # Compress older messages
        compressed_older = []
        for msg in older:
            compressed_msg = {
                'role': msg.get('role'),
                'content': SmartSummarizer._compress_content(msg.get('content', ''))
            }
            compressed_older.append(compressed_msg)

        return compressed_older + recent

    @staticmethod
    def _compress_content(content: Any) -> Any:
        """Compress message content"""
        if isinstance(content, str):
            if len(content) > 500:
                return content[:200] + '...[compressed]...' + content[-100:]
            return content

        elif isinstance(content, list):
            compressed = []
            for item in content:
                if isinstance(item, dict):
                    item_type = item.get('type', '')

                    # Remove old images entirely
                    if item_type == 'image':
                        continue

                    # Compress text
                    elif item_type == 'text':
                        text = item.get('text', '')
                        if len(text) > 300:
                            item = {
                                'type': 'text',
                                'text': text[:150] + '...[truncated]'
                            }

                    # Compress tool results
                    elif item_type == 'tool_result':
                        tool_content = item.get('content', [])
                        if isinstance(tool_content, list):
                            compressed_content = []
                            for tc in tool_content:
                                if isinstance(tc, dict):
                                    if tc.get('type') == 'image':
                                        continue
                                    if tc.get('type') == 'text':
                                        text = tc.get('text', '')
                                        if len(text) > 200:
                                            tc = {'type': 'text', 'text': text[:100] + '...[truncated]'}
                                compressed_content.append(tc)
                            item = dict(item)
                            item['content'] = compressed_content

                compressed.append(item)

            return compressed

        return content


class AdaptiveContextManager:
    """
    Main adaptive context manager for 24/7 operation.

    Orchestrates:
    - Real-time attention monitoring
    - Automatic compaction triggers
    - Hierarchical memory management
    - Smart summarization
    - Cost optimization
    """

    def __init__(
        self,
        agent_id: str,
        memory_dir: Optional[str] = None
    ):
        self.agent_id = agent_id

        # Initialize components
        self.metrics = ContextMetrics()
        self.thresholds = AdaptiveThresholds()
        self.memory = HierarchicalMemory(
            memory_dir=memory_dir or f"/tmp/agent_adaptive_memory/{agent_id}"
        )
        self.summarizer = SmartSummarizer()

        # Base context optimizer
        self.base_optimizer = get_context_optimizer()

        # State tracking
        self._last_quality = AttentionQuality.EXCELLENT
        self._last_quality_check = time.time()
        self._compaction_in_progress = False

    def get_attention_quality(self, tokens: Optional[int] = None) -> AttentionQuality:
        """Get current attention quality level"""
        current_tokens = tokens or self.metrics.current_tokens

        if current_tokens < self.thresholds.get_threshold(AttentionQuality.EXCELLENT):
            return AttentionQuality.EXCELLENT
        elif current_tokens < self.thresholds.get_threshold(AttentionQuality.GOOD):
            return AttentionQuality.GOOD
        elif current_tokens < self.thresholds.get_threshold(AttentionQuality.DEGRADED):
            return AttentionQuality.DEGRADED
        elif current_tokens < self.thresholds.get_threshold(AttentionQuality.WARNING):
            return AttentionQuality.WARNING
        else:
            return AttentionQuality.CRITICAL

    def update_metrics(
        self,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int = 0
    ):
        """Update context metrics from API response"""
        now = time.time()

        # Update token counts
        self.metrics.current_tokens = input_tokens
        self.metrics.total_input_tokens += input_tokens
        self.metrics.total_output_tokens += output_tokens

        if input_tokens > self.metrics.peak_tokens:
            self.metrics.peak_tokens = input_tokens

        # Track cache effectiveness
        if cached_tokens > 0:
            self.metrics.cache_hits += 1
        else:
            self.metrics.cache_misses += 1

        # Estimate cost (Claude Opus 4.6 pricing) — use instance for property access
        _budget = ContextBudget()
        fresh_input_tokens = max(0, input_tokens - cached_tokens)
        input_cost = (fresh_input_tokens / 1000) * _budget.COST_PER_1K_INPUT
        cached_cost = (cached_tokens / 1000) * _budget.COST_PER_1K_CACHED_INPUT
        output_cost = (output_tokens / 1000) * _budget.COST_PER_1K_OUTPUT
        self.metrics.estimated_cost += input_cost + cached_cost + output_cost

        # Update quality tracking
        quality = self.get_attention_quality(input_tokens)
        duration = now - self._last_quality_check
        self.metrics.update_quality_time(self._last_quality, duration)

        self._last_quality = quality
        self._last_quality_check = now

        # Log quality changes
        if quality != self._last_quality:
            logger.info(
                f"Attention quality changed: {self._last_quality.value} → {quality.value} "
                f"(tokens: {input_tokens:,})"
            )

        # Update base optimizer
        self.base_optimizer.update_budget({
            'input_tokens': input_tokens,
            'output_tokens': output_tokens,
            'cache_creation_input_tokens': cached_tokens
        })

    def should_compact(self) -> Tuple[bool, str]:
        """Determine if compaction is needed"""
        quality = self.get_attention_quality()

        if quality == AttentionQuality.CRITICAL:
            return True, "Critical token usage - immediate compaction required"

        if quality == AttentionQuality.WARNING:
            return True, "Warning level token usage - compaction recommended"

        if quality == AttentionQuality.DEGRADED:
            # Only compact if we've been degraded for a while
            if self.metrics.time_at_degraded > 60:
                return True, "Extended degraded quality - proactive compaction"

        return False, ""

    def get_compaction_strategy(self, agent_type: str = "") -> Dict[str, Any]:
        """Get optimal compaction configuration"""
        quality = self.get_attention_quality()

        # More aggressive compaction at worse quality levels
        strategies = {
            AttentionQuality.CRITICAL: {
                'trigger': {'type': 'input_tokens', 'value': 5_000},
                'keep': {'type': 'tool_uses', 'value': 2},
                'clear_at_least': {'type': 'input_tokens', 'value': 20_000}
            },
            AttentionQuality.WARNING: {
                'trigger': {'type': 'input_tokens', 'value': 10_000},
                'keep': {'type': 'tool_uses', 'value': 3},
                'clear_at_least': {'type': 'input_tokens', 'value': 10_000}
            },
            AttentionQuality.DEGRADED: {
                'trigger': {'type': 'input_tokens', 'value': 20_000},
                'keep': {'type': 'tool_uses', 'value': 5},
                'clear_at_least': {'type': 'input_tokens', 'value': 5_000}
            },
            AttentionQuality.GOOD: {
                'trigger': {'type': 'input_tokens', 'value': 40_000},
                'keep': {'type': 'tool_uses', 'value': 8},
                'clear_at_least': {'type': 'input_tokens', 'value': 3_000}
            },
            AttentionQuality.EXCELLENT: {
                'trigger': {'type': 'input_tokens', 'value': 60_000},
                'keep': {'type': 'tool_uses', 'value': 10},
                'clear_at_least': {'type': 'input_tokens', 'value': 2_000}
            }
        }

        return strategies.get(quality, strategies[AttentionQuality.EXCELLENT])

    async def compress_messages(
        self,
        messages: List[Dict[str, Any]],
        force: bool = False
    ) -> List[Dict[str, Any]]:
        """Compress message history if needed"""
        should_compact, reason = self.should_compact()

        if not should_compact and not force:
            return messages

        logger.info(f"Compressing messages: {reason}")
        self._compaction_in_progress = True

        try:
            # Get target token count based on quality
            quality = self.get_attention_quality()
            target_tokens = {
                AttentionQuality.CRITICAL: 30_000,
                AttentionQuality.WARNING: 50_000,
                AttentionQuality.DEGRADED: 70_000,
                AttentionQuality.GOOD: 90_000,
                AttentionQuality.EXCELLENT: 120_000
            }.get(quality, 90_000)

            # Compress messages
            compressed = self.summarizer.compress_message_history(
                messages,
                target_tokens=target_tokens,
                keep_recent=5
            )

            # Calculate tokens freed
            original_chars = sum(len(json.dumps(m)) for m in messages)
            compressed_chars = sum(len(json.dumps(m)) for m in compressed)
            tokens_freed = (original_chars - compressed_chars) // 4

            self.metrics.compactions_performed += 1
            self.metrics.tokens_freed += tokens_freed

            logger.info(
                f"Compaction complete: freed ~{tokens_freed:,} tokens "
                f"({len(messages)} → {len(compressed)} messages)"
            )

            return compressed

        finally:
            self._compaction_in_progress = False

    async def store_discovery(
        self,
        content: str,
        importance: float = 0.5,
        tags: Optional[Set[str]] = None
    ) -> str:
        """Store an important discovery in hierarchical memory"""
        key = await self.memory.store(
            content=content,
            importance=importance,
            tags=tags
        )

        logger.debug(
            f"Stored discovery '{key}' with importance {importance}"
        )

        return key

    async def retrieve_relevant_context(
        self,
        query: str,
        limit: int = 3
    ) -> str:
        """Retrieve relevant context from memory"""
        results = await self.memory.search(query, limit=limit)

        if not results:
            return ""

        context_parts = ["<RELEVANT_MEMORY>"]
        for key, preview in results:
            context_parts.append(f"[{key}]: {preview}")
        context_parts.append("</RELEVANT_MEMORY>")

        return '\n'.join(context_parts)

    def get_context_guidance(self) -> str:
        """Get dynamic guidance based on current context state"""
        quality = self.get_attention_quality()

        if quality in (AttentionQuality.CRITICAL, AttentionQuality.WARNING):
            return f"""
<CRITICAL_CONTEXT_ALERT>
⚠️ Context budget: {quality.value.upper()} ({self.metrics.current_tokens:,} tokens)

REQUIRED ACTIONS:
1. Stop loading large files - use grep/head/tail only
2. Summarize all findings immediately to /memories
3. Avoid verbose responses
4. Request context clearing if stuck

Your attention is severely degraded. Work efficiently!
</CRITICAL_CONTEXT_ALERT>
"""

        elif quality == AttentionQuality.DEGRADED:
            return f"""
<CONTEXT_WARNING>
Context budget: {quality.value} ({self.metrics.current_tokens:,} tokens)

RECOMMENDATIONS:
- Prefer grep over reading files
- Summarize findings to memory
- Be concise in responses
</CONTEXT_WARNING>
"""

        else:
            return ""  # No guidance needed for good/excellent quality

    def get_status(self) -> Dict[str, Any]:
        """Get comprehensive context manager status"""
        return {
            'quality': self.get_attention_quality().value,
            'metrics': self.metrics.to_dict(),
            'memory': self.memory.get_stats(),
            'thresholds': {
                'excellent': self.thresholds.get_threshold(AttentionQuality.EXCELLENT),
                'good': self.thresholds.get_threshold(AttentionQuality.GOOD),
                'degraded': self.thresholds.get_threshold(AttentionQuality.DEGRADED),
                'warning': self.thresholds.get_threshold(AttentionQuality.WARNING),
                'critical': self.thresholds.get_threshold(AttentionQuality.CRITICAL),
            },
            'compaction_in_progress': self._compaction_in_progress
        }


# Global instances per agent
_context_managers: Dict[str, AdaptiveContextManager] = {}


def get_adaptive_context_manager(agent_id: str) -> AdaptiveContextManager:
    """Get or create adaptive context manager for an agent"""
    if agent_id not in _context_managers:
        _context_managers[agent_id] = AdaptiveContextManager(agent_id)
    return _context_managers[agent_id]


def reset_context_manager(agent_id: str):
    """Reset context manager for an agent"""
    if agent_id in _context_managers:
        del _context_managers[agent_id]
