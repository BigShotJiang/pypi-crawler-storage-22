"""
Agent configuration loading and instruction-based agent selection.

Extracted from main.py.
"""

import os
from typing import Dict, List, Optional, Tuple
import re

from agent.logging_config import get_logger
from agent.types import AgentConfig

logger = get_logger(__name__)


def load_agent_configs() -> Dict[str, AgentConfig]:
    """Load agent configurations from environment variables."""
    configs = {}

    # Helper function to load config for a specific agent
    def load_config(agent_name: str, description: str, capabilities: List[str]) -> Optional[AgentConfig]:
        prefix = agent_name.upper().replace("-", "_")
        org_id = os.environ.get(f"{prefix}_ORG_ID", os.environ.get("DEFAULT_ORG_ID"))
        agent_id = os.environ.get(f"{prefix}_AGENT_ID", os.environ.get("DEFAULT_AGENT_ID"))
        stripe_customer_id = os.environ.get(f"{prefix}_STRIPE_ID", os.environ.get("DEFAULT_STRIPE_ID"))

        if org_id and agent_id:
            return AgentConfig(
                org_id=org_id,
                agent_id=agent_id,
                description=description,
                capabilities=capabilities,
                stripe_customer_id=stripe_customer_id or "",
            )
        return None

    # Load each agent configuration
    agent_definitions = {
        "SOCIAL_MEDIA": ("Handles social media interactions", ["hiding_comments"]),
        "AUTO_CLOSE": ("Automatically closes tickets", ["ticket_closing", "selecting_contact_reason"]),
        "ONBOARDING": ("Handles user onboarding", ["user_setup", "create_rules", "create_attributes"]),
        "LINKEDIN_MESSENGER": ("Handles sending messages in LinkedIn to set a meeting", ["linkedin_messaging"]),
        "SLACK_SUPPORT": ("Handles sending messages in Slack to customer inquiries", ["slack_messaging"]),
        "SHOPIFY": ("Handles Shopify tasks", ["shopify_tasks"]),
        "STATESET_AGENTIC": ("Handles general agentic tasks", ["general_tasks"])
    }

    for agent_name, (description, capabilities) in agent_definitions.items():
        config = load_config(agent_name, description, capabilities)
        if config:
            configs[agent_name] = config
        else:
            logger.warning(f"Configuration for {agent_name} not found in environment variables. Agent will be unavailable.")

    if not configs:
        logger.error("No agent configurations loaded. Please set environment variables for at least one agent.")
        raise ValueError("No agent configurations available. Check your .env file.")

    return configs


_INSTRUCTION_RULES: Dict[str, List[Tuple[Tuple[str, ...], Tuple[str, ...], Tuple[str, ...]]] = {
    "SOCIAL_MEDIA": [
        (("social", "media"), (), ("moderate", "moderation", "comment", "hide", "hidden", "post")),
        (("social",), (), ("instagram", "facebook", "twitter", "tiktok")),
    ],
    "AUTO_CLOSE": [
        (("auto", "close"), (), ("ticket", "resolved")),
        (("autoclose",), (), ("ticket",)),
        (("close", "ticket"), (), ()),
        (("resolve", "ticket"), (), ()),
    ],
    "ONBOARDING": [
        (("onboard",), (), ("user",)),
        (("new", "user"), (), ()),
        (("setup",), (), ("account", "user")),
    ],
    "LINKEDIN_MESSENGER": [
        (("linkedin",), (), ()),
        (("inmail",), (), ()),
        (("direct", "message"), (), ("linkedin",)),
        (("outreach",), (), ("message", "invite")),
    ],
    "SLACK_SUPPORT": [
        (("slack",), (), ("customer", "support", "inquiry", "ticket")),
        (("customer", "support"), (), ()),
        (("help", "desk"), (), ()),
    ],
    "SHOPIFY": [
        (("shopify",), (), ()),
        (("inventory",), (), ()),
        (("order", "product"), (), ()),
    ],
    "STATESET_AGENTIC": [
        (("agentic",), (), ()),
        (("general",), (), ("agent",)),
        (("workflow",), (), ()),
    ],
}

_INSTRUCTION_PHRASES: Dict[str, Tuple[str, ...]] = {
    "SOCIAL_MEDIA": (
        "social media",
        "moderate comment",
        "moderate comments",
        "hide comment",
        "hide post",
    ),
    "AUTO_CLOSE": (
        "auto close",
        "autoclose",
        "close ticket",
        "resolve ticket",
        "ticket resolved",
        "mark ticket",
    ),
    "ONBOARDING": (
        "onboarding",
        "new user",
        "on board",
        "set up account",
        "create user",
    ),
    "LINKEDIN_MESSENGER": (
        "linkedin",
        "linkedin message",
        "linkedin messages",
        "send linkedin",
        "inmail",
        "direct message",
    ),
    "SLACK_SUPPORT": (
        "slack",
        "customer support",
        "help desk",
        "support ticket",
        "send slack",
    ),
    "SHOPIFY": (
        "shopify",
        "shopify order",
        "shopify inventory",
        "shopify product",
        "order product",
    ),
    "STATESET_AGENTIC": (
        "agentic",
        "general workflow",
        "general task",
        "run agentic",
        "workflow",
    ),
}


def _normalize_text(text: str) -> str:
    """Lowercase and normalize instruction text for resilient matching."""
    lowered = text.lower()
    lowered = re.sub(r"[^a-z0-9]+", " ", lowered)
    return " ".join(lowered.split())


def _matches_rule(
    instruction: str,
    required: Tuple[str, ...],
    optional_any: Tuple[str, ...],
    context: Tuple[str, ...],
) -> bool:
    """
    Evaluate a routing rule.

    required: tokens that must all appear.
    optional_any: tokens where one match is enough (can be empty).
    context: additional tokens that add confidence; one must appear when required
        and optional_any are not sufficient by themselves.
    """
    if not required:
        return False

    tokens = set(instruction.split())

    if not required.issubset(tokens):
        # Fast path: phrase-matching tokens are not all present.
        return False

    if optional_any and not any(token in tokens for token in optional_any):
        # Weak match without contextual follow-up words.
        return False

    if context and not any(token in tokens for token in context):
        # Rule too generic; avoid mapping to unrelated commands.
        return False

    return True


def _contains_phrase(instruction: str, phrase: str) -> bool:
    """Return whether a normalized phrase appears as a token-safe substring."""
    if not phrase:
        return False
    phrase = " ".join(phrase.strip().split())
    if not phrase:
        return False
    return f" {phrase} " in f" {instruction} "


def _instruction_matches_agent(instruction: str, agent_name: str) -> bool:
    for phrase in _INSTRUCTION_PHRASES.get(agent_name, ()):
        if _contains_phrase(instruction, phrase):
            return True

    for required, optional_any, context in _INSTRUCTION_RULES.get(agent_name, []):
        if _matches_rule(instruction, required, optional_any, context):
            return True
    return False


def get_active_agents(
    instruction: str,
    agent_configs: Dict[str, AgentConfig],
    fallback_to_general: bool = False,
) -> List[AgentConfig]:
    """Determine which agents should handle the instruction."""
    active_agents = []
    normalized_instruction = _normalize_text(instruction)

    routing_order = [
        "AUTO_CLOSE",
        "LINKEDIN_MESSENGER",
        "SLACK_SUPPORT",
        "SOCIAL_MEDIA",
        "SHOPIFY",
        "ONBOARDING",
        "STATESET_AGENTIC",
    ]

    for agent_name in routing_order:
        if _instruction_matches_agent(normalized_instruction, agent_name):
            if agent_name not in agent_configs:
                raise KeyError(agent_name)
            active_agents.append(agent_configs[agent_name])

    # Fallback to onboarding only for explicitly-onboarding instructions.
    if (
        "onboarding" in normalized_instruction
        or (
            "new user" in normalized_instruction
            and "agentic" not in normalized_instruction
        )
    ):
        agent_config = agent_configs.get("ONBOARDING")
        if agent_config and agent_config not in active_agents:
            active_agents.append(agent_config)

    if not active_agents and fallback_to_general:
        logger.warning(
            f"No specific agent matched instruction '{instruction}', "
            "falling back to the general agent."
        )
        fallback_agent = agent_configs.get("STATESET_AGENTIC")
        if fallback_agent is None and len(agent_configs) == 1:
            fallback_agent = next(iter(agent_configs.values()), None)
        if fallback_agent is None and agent_configs:
            logger.warning(
                "No general fallback configured; using first available agent as a last resort."
            )
            fallback_agent = next(iter(agent_configs.values()), None)
        if fallback_agent:
            active_agents = [fallback_agent]

    return active_agents
