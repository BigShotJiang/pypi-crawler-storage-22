"""
API fetch utilities with retry logic and exponential backoff.

Extracted from agent/loop.py for better modularity.
"""

import asyncio
import json
import logging

import httpx
from anthropic import APIError, APIResponseValidationError

logger = logging.getLogger(__name__)


def _get_retry_settings():
    """Load API retry/timeout settings from config."""
    try:
        from agent.config import get_config
        cfg = get_config().api
        return getattr(cfg, 'max_retries', 3), getattr(cfg, 'retry_base_delay', 1.0)
    except (ImportError, AttributeError):
        return 3, 1.0


_MAX_RETRIES, _RETRY_BASE_DELAY = _get_retry_settings()


async def _retry_fetch(func, max_retries=_MAX_RETRIES, base_delay=_RETRY_BASE_DELAY):
    """
    Retry mechanism for API calls with exponential backoff.
    Handles different error types appropriately (rate limiting, network errors, etc.)
    """
    for attempt in range(max_retries):
        try:
            return await func()
        except httpx.HTTPStatusError as e:
            # Don't retry on client errors (except rate limiting)
            if 400 <= e.response.status_code < 500 and e.response.status_code != 429:
                logger.error(f"Client error {e.response.status_code}, not retrying: {str(e)}")
                raise

            # For rate limiting (429), use longer delay
            if e.response.status_code == 429:
                retry_after = e.response.headers.get('retry-after', '')
                try:
                    delay = float(retry_after)
                except (ValueError, TypeError):
                    delay = base_delay * 2
                logger.warning(f"Rate limited (429), retrying after {delay}s")
            else:
                delay = base_delay * (2 ** attempt)
                logger.warning(f"Server error {e.response.status_code}, retrying in {delay}s")

            if attempt == max_retries - 1:
                logger.error(f"Failed after {max_retries} attempts: {str(e)}")
                raise

            await asyncio.sleep(delay)

        except (httpx.NetworkError, httpx.TimeoutException) as e:
            # Network errors are retryable
            if attempt == max_retries - 1:
                logger.error(f"Network error after {max_retries} attempts: {str(e)}")
                raise
            delay = base_delay * (2 ** attempt)
            logger.warning(f"Network error on attempt {attempt + 1}, retrying in {delay}s: {str(e)}")
            await asyncio.sleep(delay)

        except (APIError, APIResponseValidationError) as e:
            # Anthropic API errors - retry server-side issues
            if attempt == max_retries - 1:
                logger.error(f"API error after {max_retries} attempts: {str(e)}")
                raise
            delay = base_delay * (2 ** attempt)
            logger.warning(f"API error on attempt {attempt + 1}, retrying in {delay}s: {str(e)}")
            await asyncio.sleep(delay)

        except (OSError, ConnectionError) as e:
            # OS-level / connection errors - retryable
            if attempt == max_retries - 1:
                logger.error(f"Connection error after {max_retries} attempts: {str(e)}")
                raise
            delay = base_delay * (2 ** attempt)
            logger.warning(f"Connection error on attempt {attempt + 1}, retrying in {delay}s: {str(e)}")
            await asyncio.sleep(delay)


async def _fetch_api_data(client: httpx.AsyncClient, url: str, payload: dict) -> dict:
    """Helper function to fetch data from API with retry logic.

    Preserves exception context for proper error handling and debugging.
    """
    async def _fetch() -> dict:
        try:
            response = await client.post(
                url,
                headers={'Content-Type': 'application/json'},
                json=payload,
                timeout=10.0
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            # Preserve original exception for retry logic to determine if retryable
            logger.error(f"HTTP status error {e.response.status_code}: {str(e)}")
            raise  # Re-raise original exception with full context
        except httpx.HTTPError as e:
            # Network-level errors (connection, timeout, etc.)
            logger.error(f"HTTP error occurred: {str(e)}")
            raise  # Re-raise to preserve exception type for retry logic
        except json.JSONDecodeError as e:
            # Response parsing error - not retryable
            logger.error(f"Invalid JSON response: {str(e)}")
            raise ValueError(f"Invalid JSON response from {url}") from e

    return await _retry_fetch(_fetch)
