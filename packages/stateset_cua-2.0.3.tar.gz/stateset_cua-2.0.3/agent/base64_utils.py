"""Shared helpers for robust base64 handling across the codebase."""

from __future__ import annotations

import base64
from typing import Any


def normalize_base64_data(value: Any) -> str:
    """Normalize base64-ish input into a strict base64 payload string."""
    if value is None:
        return ""

    if not isinstance(value, str):
        value = str(value)

    data = value.strip()
    if not data:
        return ""

    if data.startswith("data:") and "," in data:
        _, data = data.split(",", 1)

    # Remove whitespace/newline characters that can break strict decoders.
    data = "".join(data.split())

    if not data:
        return ""

    padding = (-len(data)) % 4
    if padding:
        data = f"{data}{'=' * padding}"

    return data


def safe_base64_decode(value: Any, strict: bool = False) -> bytes:
    """Decode base64 with a safe fallback path for malformed payloads.

    Args:
        value: Raw base64 string or compatible value.
        strict: If True, re-raise decode failures instead of returning empty bytes.

    Returns:
        Decoded bytes (empty when strict=False and input cannot be decoded).
    """
    data = normalize_base64_data(value)
    if not data:
        if strict:
            raise ValueError("Base64 input is empty or missing")
        return b""

    try:
        return base64.b64decode(data, validate=True)
    except Exception:
        try:
            return base64.b64decode(data)
        except Exception as exc:
            if strict:
                raise ValueError(f"Invalid base64 data: {exc}") from exc
            return b""
