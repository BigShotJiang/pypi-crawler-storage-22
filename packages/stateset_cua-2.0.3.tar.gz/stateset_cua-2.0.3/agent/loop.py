"""
Agentic sampling loop that calls the Anthropic API and local implementation of anthropic-defined computer use tools.

This module integrates with the unified observability system for:
- Structured logging with request correlation
- Distributed tracing (OpenTelemetry)
- Prometheus metrics
- Real-time event streaming
"""

import platform
import types
from collections.abc import Callable
from datetime import datetime
from enum import Enum
from typing import Any, Literal, Sequence, cast
from pathlib import Path
from textwrap import shorten
import time

import asyncio
import httpx
import json
import logging
from typing import Optional, NamedTuple, Tuple, Dict, List, Any, cast, Sequence
import os

# Use unified observability system
from agent.observability import (
    get_observability,
    get_metrics_collector,
    MetricsStatus,
)
from agent.logging_config import get_logger, request_context
from agent.health import CircuitBreaker, CircuitBreakerOpen

# Get structured logger
logger = get_logger(__name__)

from anthropic import (
    Anthropic,
    AnthropicBedrock,
    AnthropicVertex,
    APIError,
    APIResponseValidationError,
    APIStatusError,
)
from anthropic.types.beta import (
    BetaCacheControlEphemeralParam,
    BetaContentBlockParam,
    BetaImageBlockParam,
    BetaMessage,
    BetaMessageParam,
    BetaTextBlock,
    BetaTextBlockParam,
    BetaToolResultBlockParam,
    BetaToolUseBlockParam,
)

from .tools import (
    TOOL_GROUPS_BY_VERSION,
    ToolCollection,
    ToolResult,
    ToolVersion,
)
from .tools.groups import get_subagent_tool, SUBAGENT_TOOL_AVAILABLE
from agent.tool_guard import ToolExecutionGuard

# Optional imports for new features
try:
    from agent.mcp_client import MCPManager, get_mcp_manager
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False

try:
    from agent.structured_output import OutputSchema, StructuredOutputParser, build_structured_prompt
    STRUCTURED_OUTPUT_AVAILABLE = True
except ImportError:
    STRUCTURED_OUTPUT_AVAILABLE = False

class SamplingLoopResult(NamedTuple):
    """Result type for sampling loop including messages and usage"""
    messages: list[BetaMessageParam]
    input_tokens: int
    output_tokens: int

class APIProvider(str, Enum):
    """Supported API providers for the agent."""
    ANTHROPIC = "anthropic"
    BEDROCK = "bedrock"
    VERTEX = "vertex"

PROMPT_CACHING_BETA_FLAG = "prompt-caching-2024-07-31"
CONTEXT_MANAGEMENT_BETA_FLAG = "context-management-2025-06-27"
WEB_FETCH_BETA_FLAG = "web-fetch-2025-09-10"
CODE_EXECUTION_BETA_FLAG = "code-execution-2025-08-25"
FILES_API_BETA_FLAG = "files-api-2025-04-14"
TOOL_SEARCH_BETA_FLAG = "advanced-tool-use-2025-11-20"
EFFORT_BETA_FLAG = "effort-2025-11-24"

# Load API settings from config with safe fallback
def _get_api_settings():
    """Load API retry/timeout settings from config, with safe fallback to defaults."""
    try:
        from agent.config import get_config
        cfg = get_config().api
        return cfg
    except (ImportError, AttributeError, TypeError):
        from types import SimpleNamespace
        return SimpleNamespace(max_retries=3, retry_base_delay=1.0, api_timeout=120.0)

_api_settings = _get_api_settings()
MAX_RETRIES = getattr(_api_settings, 'max_retries', 3)
RETRY_BASE_DELAY = getattr(_api_settings, 'retry_base_delay', 1)
_RETRY_MAX_DELAY = getattr(_api_settings, 'retry_max_delay', 60.0)
_API_TIMEOUT = getattr(_api_settings, 'api_timeout', 120.0)


PROVIDER_TO_DEFAULT_MODEL_NAME: types.MappingProxyType[APIProvider, str] = types.MappingProxyType({
    APIProvider.ANTHROPIC: "claude-opus-4-6",
    APIProvider.BEDROCK: "anthropic.claude-opus-4-6-20260131-v1:0",
    APIProvider.VERTEX: "claude-opus-4-6-20260131",
})

ToolSearchVariant = Literal["regex", "bm25"]
EffortLevel = Literal["low", "medium", "high"]

TOOL_SEARCH_VARIANT_PARAMS: types.MappingProxyType[ToolSearchVariant, dict[str, str]] = types.MappingProxyType({
    "regex": {
        "type": "tool_search_tool_regex_20251119",
        "name": "tool_search_tool_regex",
    },
    "bm25": {
        "type": "tool_search_tool_bm25_20251119",
        "name": "tool_search_tool_bm25",
    },
})

from agent.api_fetch import _retry_fetch, _fetch_api_data  # noqa: F401 — re-exported

from agent.prompt_manager import (  # noqa: F401 — re-exported
    initialize_system_prompt,
    get_default_system_prompt,
    _system_prompt_cache,
    _agent_data_dir,
    _cache_ttl,
)

async def sampling_loop(
    *,
    model: str,
    provider: APIProvider,
    system_prompt_suffix: str,
    messages: list[BetaMessageParam],
    output_callback: Callable[[BetaContentBlockParam], None],
    tool_output_callback: Callable[[ToolResult, str], None],
    api_response_callback: Callable[
        [httpx.Request, httpx.Response | object | None, Exception | None], None
    ],
    api_key: str,
    org_id: str,
    agent_id: str,
    agent_type: str,
    only_n_most_recent_images: Optional[int] = None,
    max_tokens: int = 4096,
    tool_version: ToolVersion,
    thinking_budget: int | None = None,
    token_efficient_tools_beta: bool = True,
    max_messages: int = 1000,
    width: int = None,
    height: int = None,
    skill_container: Sequence[Dict[str, str]] | None = None,
    enable_context_management: bool = True,  # Enable automatic context management
    enable_web_search: bool = True,  # Enable web search tool
    web_search_max_uses: int = 5,  # Maximum web searches per request
    enable_web_fetch: bool = True,  # Enable web fetch tool
    web_fetch_max_uses: int = 10,  # Maximum web fetches per request
    web_fetch_max_content_tokens: int = 100000,  # Max tokens per fetched document
    enable_code_execution: bool = True,  # Enable code execution tool
    enable_files_api: bool = True,  # Enable Files API for file uploads/downloads
    enable_tool_search: bool = False,  # Enable Anthropic tool search beta
    tool_search_variant: ToolSearchVariant = "regex",
    deferred_tool_names: Sequence[str] | None = None,
    effort_level: EffortLevel | None = None,
    # New features
    enable_subagents: bool = True,  # Enable subagent spawning
    mcp_servers: Dict[str, Dict[str, Any]] | None = None,  # MCP server configurations
    output_schema: Dict[str, Any] | None = None,  # JSON schema for structured output
) -> SamplingLoopResult:
    """
    Main sampling loop that drives an agent-API conversation.

    Runs an iterative loop: send messages to Claude, execute any tool calls
    in the response, append results, and repeat until the model stops
    requesting tools or ``max_messages`` is reached.

    Args:
        model: Claude model identifier (e.g. ``"claude-opus-4-6"``).
        provider: API provider — ANTHROPIC, BEDROCK, or VERTEX.
        system_prompt_suffix: Text appended to the auto-generated system prompt.
        messages: Mutable list of conversation messages (modified in place).
        output_callback: Called for each content block in the response.
        tool_output_callback: Called with ``(ToolResult, tool_id)`` after execution.
        api_response_callback: Called with ``(request, response, error)`` for logging.
        api_key: Authentication key for the selected provider.
        org_id: StateSet organization ID for API rule/attribute fetching.
        agent_id: Agent ID for memory isolation and billing.
        agent_type: Agent type string (e.g. ``"AUTO_CLOSE"``) for completion detection.
        only_n_most_recent_images: Keep only the N most recent screenshots in context.
        max_tokens: Maximum tokens per API response (default 4096).
        tool_version: Tool bundle version string from ``TOOL_GROUPS_BY_VERSION``.
        thinking_budget: Token budget for extended thinking (``None`` = disabled).
        token_efficient_tools_beta: Use compact tool representations to save tokens.
        max_messages: Maximum conversation turns before stopping.
        width: Screen width in pixels (required for computer-use tools).
        height: Screen height in pixels (required for computer-use tools).
        skill_container: Optional skill definitions to inject into the prompt.
        enable_context_management: Enable automatic context compaction.
        enable_web_search: Enable server-side web search tool.
        web_search_max_uses: Maximum web searches per session.
        enable_web_fetch: Enable server-side web fetch tool.
        web_fetch_max_uses: Maximum web fetches per session.
        web_fetch_max_content_tokens: Maximum tokens per fetched document.
        enable_code_execution: Enable server-side code execution.
        enable_files_api: Enable Files API for uploads/downloads.
        enable_tool_search: Enable Anthropic tool search beta.
        tool_search_variant: Tool search method (``"regex"`` or ``"bm25"``).
        deferred_tool_names: Tool names to defer loading via tool search.
        effort_level: Opus 4.6 effort level (``"low"``, ``"medium"``, ``"high"``).
        enable_subagents: Enable subagent spawning tool.
        mcp_servers: MCP server configurations ``{name: {command, args, env}}``.
        output_schema: JSON Schema for structured output enforcement.

    Returns:
        SamplingLoopResult: Named tuple of ``(messages, input_tokens, output_tokens)``.

    Raises:
        ValueError: If ``width`` or ``height`` is ``None``.
        APIError: On unrecoverable API failures after retries.
    """
    # Check if width and height are set
    if width is None or height is None:
        raise ValueError("WIDTH, HEIGHT must be set")

    # Initialize variables used in except/finally blocks to avoid UnboundLocalError
    obs = get_observability()
    mcp_manager = None

    try:
        logger.info(f"Initializing agent", extra={'agent_type': agent_type})
        
        # Set the environment variables directly
        os.environ["WIDTH"] = str(width)
        os.environ["HEIGHT"] = str(height)
        
        tool_group = TOOL_GROUPS_BY_VERSION[tool_version]

        # Initialize tools, passing agent_id to MemoryTool for agent-specific storage
        tools = []
        for ToolCls in tool_group.tools:
            if ToolCls.__name__ == 'MemoryTool':
                # Agent-specific memory directory
                memory_dir = f"{_agent_data_dir}/agent_memories/{agent_id}"
                tools.append(ToolCls(memory_base_dir=memory_dir))
            else:
                tools.append(ToolCls())

        # Add SubagentTool if enabled and available
        if enable_subagents and SUBAGENT_TOOL_AVAILABLE:
            subagent_tool = get_subagent_tool(api_key)
            if subagent_tool:
                tools.append(subagent_tool)
                logger.info(
                    "Subagent spawning enabled",
                    extra={'agent_type': agent_type}
                )

        # Initialize MCP servers if configured
        mcp_manager = None
        mcp_tools = []
        if mcp_servers and MCP_AVAILABLE:
            mcp_manager = get_mcp_manager()
            for server_name, server_config in mcp_servers.items():
                try:
                    success = await mcp_manager.add_server(server_name, server_config)
                    if success:
                        logger.info(
                            f"Connected to MCP server '{server_name}' | tools={len(mcp_manager.get_server_tools(server_name))}",
                            extra={'agent_type': agent_type}
                        )
                except Exception as e:
                    logger.warning(
                        f"Failed to connect to MCP server '{server_name}': {e}",
                        extra={'agent_type': agent_type}
                    )
            # Get MCP tools in Anthropic format
            mcp_tools = mcp_manager.get_tools_as_anthropic_format()
            if mcp_tools:
                logger.info(
                    f"Loaded {len(mcp_tools)} MCP tools from {len(mcp_servers)} servers",
                    extra={'agent_type': agent_type}
                )

        tool_collection = ToolCollection(*tools)
        execution_guard = ToolExecutionGuard(agent_type=agent_type)

        deferred_tool_names = tuple(deferred_tool_names or ())
        tool_search_tool = None
        if enable_tool_search:
            variant_key: ToolSearchVariant = (
                tool_search_variant
                if tool_search_variant in TOOL_SEARCH_VARIANT_PARAMS
                else "regex"
            )
            tool_search_tool = TOOL_SEARCH_VARIANT_PARAMS[variant_key].copy()
            if deferred_tool_names:
                applied, missing = tool_collection.set_deferred_tools(
                    deferred_tool_names
                )
                if applied:
                    logger.info(
                        "Deferring tool definitions: %s",
                        ", ".join(applied),
                        extra={"agent_type": agent_type},
                    )
                if missing:
                    logger.warning(
                        "Could not defer unknown tools: %s",
                        ", ".join(missing),
                        extra={"agent_type": agent_type},
                    )
            else:
                logger.info(
                    "Tool search enabled without any deferred tool names; "
                    "all tool definitions will be loaded eagerly",
                    extra={"agent_type": agent_type},
                )
        elif deferred_tool_names:
            logger.warning(
                "Deferred tool names specified but tool search disabled; ignoring: %s",
                ", ".join(deferred_tool_names),
                extra={"agent_type": agent_type},
            )

        if skill_container:
            skill_ids = ", ".join(skill.get("skill_id", "?") for skill in skill_container)
            logger.info(
                "Attaching skill container(s): %s",
                skill_ids,
                extra={'agent_type': agent_type}
            )
        
        # Add web search tool if enabled (server-side tool)
        web_search_tool = None
        if enable_web_search:
            web_search_tool = {
                "type": "web_search_20250305",
                "name": "web_search",
                "max_uses": web_search_max_uses
            }
        
        # Add web fetch tool if enabled (server-side tool)
        web_fetch_tool = None
        if enable_web_fetch:
            web_fetch_tool = {
                "type": "web_fetch_20250910",
                "name": "web_fetch",
                "max_uses": web_fetch_max_uses,
                "max_content_tokens": web_fetch_max_content_tokens,
                "citations": {"enabled": True}
            }
        
        # Add code execution tool if enabled (server-side tool)
        code_execution_tool = None
        if enable_code_execution:
            code_execution_tool = {
                "type": "code_execution_20250825",
                "name": "code_execution"
            }

        # Initialize system prompt once
        system_prompt = await initialize_system_prompt(org_id, agent_id)
        system = BetaTextBlockParam(
            type="text",
            text=f"{system_prompt}{' ' + system_prompt_suffix if system_prompt_suffix else ''}",
        )

        def _check_task_completion():
            """Return completion status when the analyzer identifies task completion."""
            try:
                from agent.task_completion import analyze_task_completion_sync
                return analyze_task_completion_sync(messages=messages, agent_type=agent_type)
            except Exception as e:
                obs.log_warning(
                    "Skipping task-completion analysis due analyzer error",
                    error=str(e),
                    iteration=iteration,
                )
                return None

        total_input_tokens = 0
        total_output_tokens = 0
        iteration = 0

        # Get observability instance for metrics/events
        obs = get_observability()

        # Circuit breaker protects against cascading failures from API outages
        api_circuit_breaker = CircuitBreaker(
            name="anthropic_api",
            failure_threshold=5,
            timeout_seconds=60.0,
            expected_exception=(APIError, APIStatusError),
        )

        # Create API client once (reused across all loop iterations)
        enable_prompt_caching = False
        if provider == APIProvider.ANTHROPIC:
            client = Anthropic(
                api_key=api_key,
                timeout=_API_TIMEOUT,
                max_retries=MAX_RETRIES
            )
            enable_prompt_caching = True
        elif provider == APIProvider.VERTEX:
            client = AnthropicVertex(
                timeout=_API_TIMEOUT,
                max_retries=MAX_RETRIES
            )
        elif provider == APIProvider.BEDROCK:
            client = AnthropicBedrock(
                timeout=_API_TIMEOUT,
                max_retries=MAX_RETRIES
            )
        else:
            raise ValueError(f"Unknown provider: {provider}")

        while iteration < max_messages:
            try:
                iteration += 1
                iteration_start = time.perf_counter()
                iteration_input_tokens = 0
                iteration_output_tokens = 0

                # Use observability for structured logging
                obs.log_info(
                    f"Loop iteration {iteration} started",
                    iteration=iteration,
                    message_count=len(messages),
                )
                betas = []
                if tool_group.beta_flag:
                    betas.append(tool_group.beta_flag)
                if enable_tool_search:
                    betas.append(TOOL_SEARCH_BETA_FLAG)
                if token_efficient_tools_beta:
                    betas.append("token-efficient-tools-2025-02-19")
                image_truncation_threshold = only_n_most_recent_images or 0

                if enable_prompt_caching:
                    betas.append(PROMPT_CACHING_BETA_FLAG)
                    _inject_prompt_caching(messages)
                    only_n_most_recent_images = 0
                    # Use type ignore to bypass TypedDict check until SDK types are updated
                    system["cache_control"] = {"type": "ephemeral"}  # type: ignore
                
                # Add context management beta flag if enabled
                if enable_context_management:
                    betas.append(CONTEXT_MANAGEMENT_BETA_FLAG)
                
                # Add web fetch beta flag if enabled
                if enable_web_fetch:
                    betas.append(WEB_FETCH_BETA_FLAG)
                
                # Add code execution beta flag if enabled
                if enable_code_execution:
                    betas.append(CODE_EXECUTION_BETA_FLAG)
                
                # Add files API beta flag if enabled (needed for file uploads with code execution)
                if enable_files_api:
                    betas.append(FILES_API_BETA_FLAG)

                output_config: dict[str, str] | None = None
                if effort_level:
                    if "opus-4-6" in model:
                        if EFFORT_BETA_FLAG not in betas:
                            betas.append(EFFORT_BETA_FLAG)
                        output_config = {"effort": effort_level}
                        logger.info(
                            "Applying effort=%s for model %s",
                            effort_level,
                            model,
                            extra={'agent_type': agent_type}
                        )
                    else:
                        logger.warning(
                            "Effort parameter requested but model %s does not support it; skipping",
                            model,
                            extra={'agent_type': agent_type}
                        )

                if only_n_most_recent_images:
                    _maybe_filter_to_n_most_recent_images(
                        messages,
                        only_n_most_recent_images,
                        min_removal_threshold=image_truncation_threshold,
                        max_messages=max_messages
                    )
                
                # Apply message history compression only when context is getting large
                # Avoid compressing every iteration to prevent progressive context loss
                if len(messages) > 20:
                    _compress_message_history(messages, max_tokens_estimate=80000, keep_recent=10)
                extra_body: dict[str, Any] = {}

                # Configure context management to automatically clear old tool results
                # Dynamic configuration based on Anthropic's context engineering research
                context_management = None
                if enable_context_management:
                    from agent.context_optimizer import get_context_optimizer
                    
                    optimizer = get_context_optimizer()
                    compaction_strategy = optimizer.get_compaction_strategy(agent_type)
                    
                    context_management = {
                        "edits": [
                            {
                                "type": "clear_tool_uses_20250919",
                                # Dynamic trigger based on current context usage
                                "trigger": {
                                    "type": "input_tokens",
                                    "value": compaction_strategy['trigger']['value']
                                },
                                # Dynamic retention based on attention budget
                                "keep": {
                                    "type": "tool_uses",
                                    "value": compaction_strategy['keep']['value']
                                },
                                # Dynamic clearing threshold
                                "clear_at_least": {
                                    "type": "input_tokens",
                                    "value": compaction_strategy['clear_at_least']['value']
                                },
                                # Keep tool inputs visible, only clear results
                                "clear_tool_inputs": False
                            }
                        ]
                    }

                # Build tools list (client-side tools + server-side tools + MCP tools)
                tools_list = []
                if tool_search_tool:
                    tools_list.append(tool_search_tool)
                tools_list.extend(tool_collection.to_params())
                if web_search_tool:
                    tools_list.append(web_search_tool)
                if web_fetch_tool:
                    tools_list.append(web_fetch_tool)
                if code_execution_tool:
                    tools_list.append(code_execution_tool)
                # Add MCP tools
                if mcp_tools:
                    tools_list.extend(mcp_tools)
                
                # Create the message with context management
                api_params = {
                    "max_tokens": max_tokens,
                    "messages": messages,
                    "model": model,
                    "system": [system],
                    "tools": tools_list,
                    "betas": betas,
                }

                if thinking_budget is not None:
                    api_params["thinking"] = {"type": "enabled", "budget_tokens": thinking_budget}

                if skill_container:
                    api_params["container"] = {"skills": list(skill_container)}

                if context_management:
                    extra_body["context_management"] = context_management

                if extra_body:
                    api_params["extra_body"] = extra_body

                if output_config:
                    api_params["output_config"] = output_config

                # Rate limit API calls to avoid overloading the provider
                try:
                    from agent.performance.rate_limiter import get_rate_limiter
                    _rate_limiter = get_rate_limiter()
                    acquired = await _rate_limiter.acquire(
                        key=f"{provider.value}:{model}",
                        timeout=30.0,
                    )
                    if not acquired:
                        obs.log_warning(
                            "Rate limiter timeout — proceeding without token",
                            provider=provider.value,
                            model=model,
                        )
                except Exception:
                    pass  # Rate limiting is best-effort; never block the agent

                api_attempt = 0
                max_api_attempts = max(1, int(MAX_RETRIES) + 1)
                while True:
                    try:
                        api_attempt += 1
                        response = await api_circuit_breaker.call(
                            client.beta.messages.create, **api_params
                        )
                        break
                    except (APIStatusError, APIError, asyncio.TimeoutError) as api_error:
                        status_code = getattr(api_error, "status_code", None)
                        if isinstance(api_error, asyncio.TimeoutError):
                            status_code = 0
                        if status_code is None:
                            status_code = getattr(
                                getattr(api_error, "response", None),
                                "status_code",
                                None,
                            )
                        retryable_status = (
                            status_code is None
                            or status_code in {0, 408, 409, 425, 429, 500, 502, 503, 504}
                        )
                        if api_attempt < max_api_attempts and retryable_status:
                            delay = RETRY_BASE_DELAY * (2 ** (api_attempt - 1))
                            delay = min(delay, _RETRY_MAX_DELAY)
                            obs.log_warning(
                                "Retryable API error, retrying API call",
                                iteration=iteration,
                                attempt=api_attempt,
                                max_attempts=max_api_attempts,
                                status_code=status_code,
                                delay_seconds=delay,
                            )
                            await asyncio.sleep(delay)
                            continue
                        raise
                    except CircuitBreakerOpen:
                        obs.log_error(
                            "API circuit breaker is OPEN — too many consecutive failures. "
                            "Waiting for recovery before retrying.",
                            circuit_state=api_circuit_breaker.get_state(),
                        )
                        raise

                # Track token usage and update context optimizer
                api_latency = time.perf_counter() - iteration_start
                if hasattr(response, 'usage'):
                    iteration_input_tokens = response.usage.input_tokens
                    iteration_output_tokens = response.usage.output_tokens
                    total_input_tokens += response.usage.input_tokens
                    total_output_tokens += response.usage.output_tokens
                    cached_tokens = getattr(response.usage, 'cache_read_input_tokens', 0)
                    cache_creation_tokens = getattr(response.usage, 'cache_creation_input_tokens', 0)

                    # Record API call metrics via observability
                    # Include both cache read and creation tokens for accurate cost tracking
                    obs.record_api_call(
                        provider="anthropic",
                        model=model,
                        latency=api_latency,
                        input_tokens=iteration_input_tokens,
                        output_tokens=iteration_output_tokens,
                        cached_tokens=cached_tokens + cache_creation_tokens,
                        success=True,
                    )

                    # Update context optimizer budget (Anthropic pattern)
                    if enable_context_management:
                        optimizer.update_budget({
                            'input_tokens': response.usage.input_tokens,
                            'output_tokens': response.usage.output_tokens,
                            'cache_creation_input_tokens': getattr(response.usage, 'cache_creation_input_tokens', 0),
                        })

                        # Log token budget warnings for cost awareness via observability
                        status = optimizer.budget.get_status()
                        if status['quality'] == 'CRITICAL':
                            obs.record_budget_warning(
                                warning_type="token_budget_critical",
                                current_value=status['tokens'],
                                threshold=200000,
                                unit="tokens",
                            )
                        elif status['quality'] == 'WARNING':
                            obs.record_budget_warning(
                                warning_type="token_budget_warning",
                                current_value=status['tokens'],
                                threshold=150000,
                                unit="tokens",
                            )
                        elif status['quality'] == 'DEGRADED':
                            obs.log_info(
                                f"Token usage: {status['utilization']} - attention quality degrading",
                                tokens=status['tokens'],
                                quality=status['quality'],
                            )

                    # Log web search usage if present
                    if hasattr(response.usage, 'server_tool_use'):
                        server_tool_use = response.usage.server_tool_use
                        if hasattr(server_tool_use, 'web_search_requests'):
                            searches = server_tool_use.web_search_requests
                            obs.log_info(
                                f"Web search: {searches} search{'es' if searches != 1 else ''} performed",
                                web_searches=searches,
                            )
                        if hasattr(server_tool_use, 'web_fetch_requests'):
                            fetches = server_tool_use.web_fetch_requests
                            obs.log_info(
                                f"Web fetch: {fetches} page{'s' if fetches != 1 else ''} fetched",
                                web_fetches=fetches,
                            )
                        if hasattr(server_tool_use, 'code_execution_sessions'):
                            sessions = server_tool_use.code_execution_sessions
                            obs.log_info(
                                f"Code execution: {sessions} session{'s' if sessions != 1 else ''} used",
                                code_execution_sessions=sessions,
                            )
                        if hasattr(server_tool_use, 'tool_search_requests'):
                            lookups = server_tool_use.tool_search_requests
                            obs.log_info(
                                f"Tool search: {lookups} lookup{'s' if lookups != 1 else ''} performed",
                                tool_search_requests=lookups,
                            )
                
                # Log context management info if applied via observability
                if hasattr(response, 'context_management') and response.context_management:
                    cm = response.context_management
                    if hasattr(cm, 'applied_edits') and cm.applied_edits:
                        for edit in cm.applied_edits:
                            if hasattr(edit, 'cleared_tool_uses') and hasattr(edit, 'cleared_input_tokens'):
                                obs.record_context_compaction(
                                    cleared_tool_uses=edit.cleared_tool_uses,
                                    cleared_tokens=edit.cleared_input_tokens,
                                )

                api_response_callback(None, response, None)

                response_params = _response_to_params(response)
                messages.append({"role": "assistant", "content": response_params})

                tool_result_content = []
                
                # Collect all tool calls first for parallel execution
                tool_calls = []
                tool_call_blocks = []
                for content_block in response_params:
                    output_callback(content_block)
                    if content_block["type"] == "tool_use":
                        tool_calls.append({
                            'name': content_block["name"],
                            'input': cast(dict[str, Any], content_block["input"]),
                            'id': content_block["id"]
                        })
                        tool_call_blocks.append(content_block)
                
                # Execute tools with automatic parallelization
                pending_interventions: list[str] = []
                obs.log_info(
                    f"Iteration {iteration}: assistant produced {len(tool_calls)} tool call(s)",
                    iteration=iteration,
                    tool_call_count=len(tool_calls),
                    tool_names=[c['name'] for c in tool_calls],
                )

                if tool_calls:
                    from agent.parallel_executor import get_parallel_executor

                    # Separate MCP tools from regular tools
                    mcp_calls = []
                    regular_calls = []
                    for call in tool_calls:
                        if call['name'].startswith('mcp__'):
                            mcp_calls.append(call)
                        else:
                            regular_calls.append(call)

                    results_map = {}  # Map tool_id -> result
                    tool_durations = {}  # Map tool_id -> duration_seconds

                    # Execute regular tools with automatic parallelization
                    if regular_calls:
                        parallel_executor = get_parallel_executor()
                        regular_results = await parallel_executor.execute_batch(
                            regular_calls,
                            tool_collection,
                            agent_type,
                            guard=execution_guard,
                            tool_durations=tool_durations,
                        )
                        for call, result in zip(regular_calls, regular_results):
                            results_map[call['id']] = result

                    # Execute placeholder failure results for any unresolved regular tools.
                    unresolved_regular_ids = {
                        call["id"] for call in regular_calls
                        if call["id"] not in results_map
                    }
                    for unresolved_id in unresolved_regular_ids:
                        obs.log_warning(
                            "Regular tool call completed without result",
                            tool_id=unresolved_id,
                            agent_type=agent_type,
                        )
                        results_map[unresolved_id] = ToolResult(error="Tool execution produced no result")

                    # Execute MCP tools
                    if mcp_calls and mcp_manager:
                        for call in mcp_calls:
                            mcp_start = time.perf_counter()
                            try:
                                mcp_result = await mcp_manager.call_tool_by_full_name(
                                    call['name'],
                                    call['input']
                                )
                                # Convert MCP result to ToolResult
                                content = mcp_result.get('content', [])
                                if isinstance(content, list):
                                    output_text = '\n'.join(
                                        item.get('text', str(item))
                                        for item in content
                                        if isinstance(item, dict)
                                    )
                                else:
                                    output_text = str(content)
                                results_map[call['id']] = ToolResult(output=output_text)
                            except Exception as e:
                                results_map[call['id']] = ToolResult(error=f"MCP tool error: {str(e)}")
                            tool_durations[str(call['id'])] = time.perf_counter() - mcp_start

                    # Execute placeholder failure results for MCP calls with no result.
                    unresolved_mcp_ids = {
                        call["id"] for call in mcp_calls
                        if call["id"] not in results_map
                    }
                    for unresolved_id in unresolved_mcp_ids:
                        obs.log_warning(
                            "MCP tool call completed without result",
                            tool_id=unresolved_id,
                            agent_type=agent_type,
                        )
                        results_map[unresolved_id] = ToolResult(error="MCP tool execution produced no result")

                    # Process results in original order
                    for call in tool_calls:
                        result = results_map.get(call['id'], ToolResult(error="Tool execution failed"))
                        status = 'error' if result.error else 'ok'
                        success = not result.error

                        # Record tool execution via observability
                        obs.record_tool_execution_simple(
                            tool_name=call['name'],
                            duration=tool_durations.get(str(call['id']), 0.0),
                            success=success,
                        )

                        obs.log_info(
                            f"Iteration {iteration}: tool '{call['name']}' completed with status={status}",
                            iteration=iteration,
                            tool_name=call['name'],
                            tool_id=call['id'],
                            success=success,
                        )
                        tool_result_content.append(
                            _make_api_tool_result(result, call['id'])
                        )
                        tool_output_callback(result, call['id'])

                    pending_interventions.extend(execution_guard.pop_interventions())

                if not tool_result_content:
                    duration = time.perf_counter() - iteration_start
                    completion_status = _check_task_completion()
                    obs.log_info(
                        f"Iteration {iteration} completed with no tool results",
                        iteration=iteration,
                        duration_seconds=duration,
                        total_input_tokens=total_input_tokens,
                        total_output_tokens=total_output_tokens,
                        completion_detected=bool(completion_status and completion_status.completed),
                        completion_details=getattr(completion_status, "details", "n/a"),
                    )
                    if completion_status and completion_status.completed:
                        obs.log_info(
                            "Sampling loop stopped by completion detection",
                            iteration=iteration,
                            trigger="no_tool_results",
                            completion_details=completion_status.details,
                        )
                    return SamplingLoopResult(
                        messages=messages,
                        input_tokens=total_input_tokens,
                        output_tokens=total_output_tokens
                    )

                messages.append({"content": tool_result_content, "role": "user"})
                completion_status = _check_task_completion()
                if completion_status and completion_status.completed:
                    obs.log_info(
                        "Sampling loop stopped by completion detection",
                        iteration=iteration,
                        trigger="tool_result_received",
                        completion_details=completion_status.details,
                    )
                    return SamplingLoopResult(
                        messages=messages,
                        input_tokens=total_input_tokens,
                        output_tokens=total_output_tokens
                    )

                for notice in pending_interventions:
                    obs.log_warning(
                        f"Iteration {iteration}: intervention injected",
                        iteration=iteration,
                        notice=shorten(notice, width=160, placeholder='...'),
                    )
                    messages.append({"role": "user", "content": [{"type": "text", "text": notice}]})

                iteration_duration = time.perf_counter() - iteration_start
                obs.log_info(
                    f"Iteration {iteration} complete",
                    iteration=iteration,
                    duration_seconds=iteration_duration,
                    tool_calls=len(tool_calls),
                    interventions=len(pending_interventions),
                    iteration_input_tokens=iteration_input_tokens,
                    iteration_output_tokens=iteration_output_tokens,
                )

            except (APIStatusError, APIResponseValidationError) as e:
                obs.log_error(f"API error: {str(e)}", e, error_type="api_status_error")
                api_response_callback(e.request, e.response, e)

                # Record failed API call
                obs.record_api_call(
                    provider="anthropic",
                    model=model,
                    latency=time.perf_counter() - iteration_start,
                    input_tokens=0,
                    output_tokens=0,
                    success=False,
                )

                return SamplingLoopResult(
                    messages=messages,
                    input_tokens=total_input_tokens,
                    output_tokens=total_output_tokens
                )
            except asyncio.TimeoutError as e:
                obs.log_error(f"API timeout error: {str(e)}", e, error_type="api_timeout")
                api_response_callback(None, None, e)

                # Record failed API call
                obs.record_api_call(
                    provider="anthropic",
                    model=model,
                    latency=time.perf_counter() - iteration_start,
                    input_tokens=0,
                    output_tokens=0,
                    success=False,
                )

                return SamplingLoopResult(
                    messages=messages,
                    input_tokens=total_input_tokens,
                    output_tokens=total_output_tokens
                )
            except APIError as e:
                obs.log_error(f"API error: {str(e)}", e, error_type="api_error")
                api_response_callback(e.request, e.body, e)

                # Record failed API call
                obs.record_api_call(
                    provider="anthropic",
                    model=model,
                    latency=time.perf_counter() - iteration_start,
                    input_tokens=0,
                    output_tokens=0,
                    success=False,
                )

                return SamplingLoopResult(
                    messages=messages,
                    input_tokens=total_input_tokens,
                    output_tokens=total_output_tokens
                )
            except Exception as e:
                obs.log_error(f"Unexpected error: {str(e)}", e, error_type="unexpected_error")
                api_response_callback(None, None, e)
                return SamplingLoopResult(
                    messages=messages,
                    input_tokens=total_input_tokens,
                    output_tokens=total_output_tokens
                )

        obs.log_warning(
            "Sampling loop reached max_messages limit without explicit completion",
            max_messages=max_messages,
            iteration=iteration,
            agent_type=agent_type,
        )
        return SamplingLoopResult(
            messages=messages,
            input_tokens=total_input_tokens,
            output_tokens=total_output_tokens
        )

    except Exception as e:
        obs.log_error(f"Critical error in sampling loop: {str(e)}", e, error_type="critical_error")
        raise
    finally:
        # Cleanup MCP connections if they were created for this session
        if mcp_manager and mcp_servers:
            try:
                await mcp_manager.close_all()
                logger.info("Closed all MCP server connections", extra={'agent_type': agent_type})
            except Exception as cleanup_error:
                logger.warning(f"Error closing MCP connections: {cleanup_error}", extra={'agent_type': agent_type})


from agent.message_utils import (  # noqa: F401 — re-exported
    _maybe_filter_to_n_most_recent_images,
    _compress_message_history,
    _inject_prompt_caching,
    _compress_assistant_text,
    _response_to_params,
    _truncate_tool_output,
    _is_duplicate_screenshot,
    _make_api_tool_result,
    _maybe_prepend_system_tool_result,
    _recent_screenshot_hashes,
    _MAX_ASSISTANT_TEXT_CHARS,
    _MAX_TOOL_OUTPUT_CHARS,
    _MAX_ERROR_CHARS,
    _MAX_SCREENSHOT_CACHE,
)


# ── Config-driven entry point ────────────────────────────────────────────


async def sampling_loop_from_config(
    *,
    config: "SamplingLoopConfig",
    messages: list[BetaMessageParam],
    output_callback: Callable[[BetaContentBlockParam], None],
    tool_output_callback: Callable[[ToolResult, str], None],
    api_response_callback: Callable[
        [httpx.Request, httpx.Response | object | None, Exception | None], None
    ],
) -> SamplingLoopResult:
    """Thin wrapper around :func:`sampling_loop` that accepts a
    :class:`~agent.loop_config.SamplingLoopConfig` dataclass.

    Usage::

        from agent.loop_config import SamplingLoopConfig
        from agent.loop import sampling_loop_from_config

        result = await sampling_loop_from_config(
            config=config,
            messages=messages,
            output_callback=...,
            tool_output_callback=...,
            api_response_callback=...,
        )
    """
    from agent.loop_config import SamplingLoopConfig  # deferred to avoid circular

    return await sampling_loop(
        **config.to_kwargs(),
        messages=messages,
        output_callback=output_callback,
        tool_output_callback=tool_output_callback,
        api_response_callback=api_response_callback,
    )
