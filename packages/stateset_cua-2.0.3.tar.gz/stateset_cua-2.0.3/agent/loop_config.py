"""
Configuration dataclass for the sampling loop.

Captures all non-callback parameters of ``sampling_loop()`` so they can be
constructed, validated, and serialised independently of the loop itself.

Usage::

    from agent.loop_config import SamplingLoopConfig

    config = SamplingLoopConfig(
        model="claude-opus-4-6",
        provider=APIProvider.ANTHROPIC,
        system_prompt_suffix="",
        api_key="sk-ant-...",
        org_id="org_...",
        agent_id="agent_...",
        agent_type="AUTO_CLOSE",
        tool_version="computer_use_20251124",
        width=1920,
        height=1080,
    )

    # Later, unpack into sampling_loop():
    # await sampling_loop(**config.to_kwargs(), messages=messages, ...)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional, Sequence

from agent.loop import APIProvider, ToolSearchVariant, EffortLevel
from agent.tools import ToolVersion


@dataclass
class SamplingLoopConfig:
    """Non-callback configuration for :func:`agent.loop.sampling_loop`.

    Every field mirrors a keyword argument of ``sampling_loop`` except for
    the three callback parameters (``output_callback``, ``tool_output_callback``,
    ``api_response_callback``) and the mutable ``messages`` list, which are
    supplied separately at call time.
    """

    # ── Required ─────────────────────────────────────────────────────────
    model: str
    provider: APIProvider
    system_prompt_suffix: str
    api_key: str
    org_id: str
    agent_id: str
    agent_type: str
    tool_version: ToolVersion
    width: int
    height: int

    # ── Optional / defaulted ─────────────────────────────────────────────
    only_n_most_recent_images: Optional[int] = None
    max_tokens: int = 4096
    thinking_budget: Optional[int] = None
    token_efficient_tools_beta: bool = True
    max_messages: int = 1000

    # Skill system
    skill_container: Optional[Sequence[Dict[str, str]]] = None

    # Context management
    enable_context_management: bool = True

    # Server-side tools
    enable_web_search: bool = True
    web_search_max_uses: int = 5
    enable_web_fetch: bool = True
    web_fetch_max_uses: int = 10
    web_fetch_max_content_tokens: int = 100000
    enable_code_execution: bool = True
    enable_files_api: bool = True

    # Tool search (beta)
    enable_tool_search: bool = False
    tool_search_variant: ToolSearchVariant = "regex"
    deferred_tool_names: Optional[Sequence[str]] = None

    # Effort (Opus 4.6 beta)
    effort_level: Optional[EffortLevel] = None

    # New features (December 2025)
    enable_subagents: bool = True
    mcp_servers: Optional[Dict[str, Dict[str, Any]]] = None
    output_schema: Optional[Dict[str, Any]] = None

    # ── Helpers ───────────────────────────────────────────────────────────

    def to_kwargs(self) -> Dict[str, Any]:
        """Return a dict suitable for ``sampling_loop(**config.to_kwargs(), ...)``.

        The caller still needs to supply ``messages``, ``output_callback``,
        ``tool_output_callback``, and ``api_response_callback``.
        """
        return {
            "model": self.model,
            "provider": self.provider,
            "system_prompt_suffix": self.system_prompt_suffix,
            "api_key": self.api_key,
            "org_id": self.org_id,
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "tool_version": self.tool_version,
            "width": self.width,
            "height": self.height,
            "only_n_most_recent_images": self.only_n_most_recent_images,
            "max_tokens": self.max_tokens,
            "thinking_budget": self.thinking_budget,
            "token_efficient_tools_beta": self.token_efficient_tools_beta,
            "max_messages": self.max_messages,
            "skill_container": self.skill_container,
            "enable_context_management": self.enable_context_management,
            "enable_web_search": self.enable_web_search,
            "web_search_max_uses": self.web_search_max_uses,
            "enable_web_fetch": self.enable_web_fetch,
            "web_fetch_max_uses": self.web_fetch_max_uses,
            "web_fetch_max_content_tokens": self.web_fetch_max_content_tokens,
            "enable_code_execution": self.enable_code_execution,
            "enable_files_api": self.enable_files_api,
            "enable_tool_search": self.enable_tool_search,
            "tool_search_variant": self.tool_search_variant,
            "deferred_tool_names": self.deferred_tool_names,
            "effort_level": self.effort_level,
            "enable_subagents": self.enable_subagents,
            "mcp_servers": self.mcp_servers,
            "output_schema": self.output_schema,
        }
