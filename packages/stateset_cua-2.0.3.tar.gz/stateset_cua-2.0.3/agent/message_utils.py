"""
Message processing utilities for the sampling loop.

Extracted from agent/loop.py for better modularity.
Handles image filtering, message compression, prompt caching,
response conversion, and tool result formatting.
"""

import hashlib
import json
from typing import Any, Dict, Sequence, cast

from anthropic.types.beta import (
    BetaCacheControlEphemeralParam,
    BetaContentBlockParam,
    BetaImageBlockParam,
    BetaMessage,
    BetaMessageParam,
    BetaTextBlock,
    BetaTextBlockParam,
    BetaToolResultBlockParam,
    BetaToolUseBlockParam,
)

from .tools.base import ToolResult


# ── Constants ────────────────────────────────────────────────────────────

_MAX_ASSISTANT_TEXT_CHARS = 800  # Limit verbose assistant narration
_MAX_TOOL_OUTPUT_CHARS = 1500  # Truncate verbose outputs
_MAX_ERROR_CHARS = 500  # Truncate error messages

# Screenshot deduplication cache
_recent_screenshot_hashes: list[str] = []
_MAX_SCREENSHOT_CACHE = 5


# ── Image / message filtering ───────────────────────────────────────────


def _maybe_filter_to_n_most_recent_images(
    messages: list[BetaMessageParam],
    images_to_keep: int,
    min_removal_threshold: int,
    max_messages: int = 20
):
    """
    Manages the context window by:
    1. Keeping only the N most recent messages (excluding system prompt)
    2. Removing older images while preserving cache behavior
    3. Truncating verbose tool outputs to prevent context bloat

    Args:
        messages: List of message parameters
        images_to_keep: Number of most recent images to retain
        min_removal_threshold: Minimum chunk size for image removal (cache optimization)
        max_messages: Maximum number of messages to keep (default: 20)
    """
    if len(messages) > max_messages:
        # Keep only the most recent messages
        messages[:] = messages[-max_messages:]

    if images_to_keep is None:
        return

    tool_result_blocks = cast(
        list[BetaToolResultBlockParam],
        [
            item
            for message in messages
            for item in (
                message["content"] if isinstance(message["content"], list) else []
            )
            if isinstance(item, dict) and item.get("type") == "tool_result"
        ],
    )

    total_images = sum(
        1
        for tool_result in tool_result_blocks
        for content in tool_result.get("content", [])
        if isinstance(content, dict) and content.get("type") == "image"
    )

    images_to_remove = total_images - images_to_keep
    # Optimize cache behavior by removing in chunks
    if min_removal_threshold > 0:
        images_to_remove -= images_to_remove % min_removal_threshold

    for tool_result in tool_result_blocks:
        if isinstance(tool_result.get("content"), list):
            new_content = []
            for content in tool_result.get("content", []):
                if isinstance(content, dict) and content.get("type") == "image":
                    if images_to_remove > 0:
                        images_to_remove -= 1
                        continue
                # Truncate verbose text outputs to save tokens
                if isinstance(content, dict) and content.get("type") == "text":
                    text = content.get("text", "")
                    if text is None:
                        text = ""
                    if len(text) > 2000:
                        content["text"] = text[:1500] + "\n...[truncated]...\n" + text[-300:]
                new_content.append(content)
            tool_result["content"] = new_content


# ── Message compression ──────────────────────────────────────────────────


def _compress_message_history(
    messages: list[BetaMessageParam],
    max_tokens_estimate: int = 80000,
    keep_recent: int = 10
) -> None:
    """
    Compress older messages to reduce token usage.

    Token Budget Strategy (Anthropic Research):
    - Attention degrades exponentially with context size
    - Keep recent messages intact for continuity
    - Summarize/truncate older messages aggressively

    Args:
        messages: List of messages to compress (modified in-place)
        max_tokens_estimate: Target token budget (rough estimate: 4 chars = 1 token)
        keep_recent: Number of recent messages to keep intact
    """
    if len(messages) <= keep_recent:
        return

    # Estimate current token usage (rough: 4 chars = 1 token)
    total_chars = sum(
        len(json.dumps(msg.get("content", "")))
        for msg in messages
    )
    estimated_tokens = total_chars // 4

    if estimated_tokens <= max_tokens_estimate:
        return

    # Compress older messages (keep recent ones intact)
    older_messages = messages[:-keep_recent]

    for msg in older_messages:
        content = msg.get("content", [])
        if not isinstance(content, list):
            continue

        new_content = []
        for block in content:
            if not isinstance(block, dict):
                new_content.append(block)
                continue

            block_type = block.get("type", "")

            # Truncate text blocks aggressively
            if block_type == "text":
                text = block.get("text", "")
                if len(text) > 500:
                    block["text"] = text[:200] + "\n[...compressed...]\n" + text[-100:]

            # Remove images from older messages entirely
            elif block_type == "image":
                continue  # Skip old images

            # Truncate tool results
            elif block_type == "tool_result":
                tool_content = block.get("content", [])
                if isinstance(tool_content, list):
                    compressed_content = []
                    for tc in tool_content:
                        if isinstance(tc, dict):
                            if tc.get("type") == "image":
                                continue  # Remove old images
                            if tc.get("type") == "text":
                                text = tc.get("text", "")
                                if len(text) > 300:
                                    tc["text"] = text[:150] + "...[truncated]"
                        compressed_content.append(tc)
                    block["content"] = compressed_content

            new_content.append(block)

        msg["content"] = new_content


# ── Prompt caching ───────────────────────────────────────────────────────


def _inject_prompt_caching(
    messages: list[BetaMessageParam],
):
    """
    Set cache breakpoints for the 3 most recent turns
    one cache breakpoint is left for tools/system prompt, to be shared across sessions
    """

    breakpoints_assigned = 0

    for message in reversed(messages):
        if message.get("role") != "user":
            continue

        content = message.get("content")
        if not isinstance(content, list):
            continue

        # Remove any existing cache_control entries to avoid exceeding limits
        for block in content:
            if isinstance(block, dict):
                block.pop("cache_control", None)

        if breakpoints_assigned >= 3:
            continue

        # Identify candidate text blocks (prefer the last text block)
        text_blocks = [
            block for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        ]
        if not text_blocks:
            continue

        text_block = text_blocks[-1]
        text_block["cache_control"] = BetaCacheControlEphemeralParam(  # type: ignore
            {"type": "ephemeral"}
        )
        breakpoints_assigned += 1


# ── Text compression ────────────────────────────────────────────────────


def _compress_assistant_text(
    text: Any,
    max_chars: int = _MAX_ASSISTANT_TEXT_CHARS
) -> str:
    """
    Compress verbose assistant narration to save tokens.

    Claude often produces repetitive explanations like:
    "I see the ticket is now closed. The checkmark shows it's resolved.
     Let me take a screenshot to confirm and move to the next ticket..."

    This adds up across iterations. Compress to essentials.
    """
    if text is None:
        return ""

    if not isinstance(text, str):
        text = str(text)

    if len(text) <= max_chars:
        return text

    # Keep first part (intent) and last part (next action)
    head_size = int(max_chars * 0.6)
    tail_size = int(max_chars * 0.3)

    return (
        text[:head_size].rstrip() +
        " [...] " +
        text[-tail_size:].lstrip()
    )


# ── Response conversion ─────────────────────────────────────────────────


def _response_to_params(
    response: BetaMessage,
) -> list[BetaTextBlockParam | BetaToolUseBlockParam]:
    """Convert API response to parameter format with token optimization."""
    res: list[BetaTextBlockParam | BetaToolUseBlockParam] = []
    for block in response.content:
        if isinstance(block, BetaTextBlock):
            # Compress verbose assistant text to save tokens
            compressed_text = _compress_assistant_text(
                getattr(block, "text", "")
            )
            res.append({"type": "text", "text": compressed_text})
        else:
            tool_block = block.model_dump()
            tool_block.pop("caller", None)
            res.append(cast(BetaToolUseBlockParam, tool_block))
    return res


# ── Tool result formatting ──────────────────────────────────────────────


def _truncate_tool_output(text: str, max_chars: int = _MAX_TOOL_OUTPUT_CHARS) -> str:
    """Truncate verbose tool output to save tokens.

    Preserves head, tail, and any lines containing error/warning indicators
    from the middle section to avoid losing critical diagnostic context.
    """
    if len(text) <= max_chars:
        return text

    head_size = int(max_chars * 0.6)
    tail_size = int(max_chars * 0.15)
    middle_budget = int(max_chars * 0.15)

    head = text[:head_size]
    tail = text[-tail_size:]

    # Extract error/warning lines from the middle to preserve diagnostic context
    middle = text[head_size:-tail_size] if tail_size > 0 else text[head_size:]
    error_indicators = ('error', 'Error', 'ERROR', 'exception', 'Exception',
                        'warning', 'Warning', 'WARN', 'failed', 'Failed', 'FAILED',
                        'traceback', 'Traceback')
    important_lines = [
        line for line in middle.split('\n')
        if any(indicator in line for indicator in error_indicators)
    ]

    middle_excerpt = ""
    if important_lines:
        middle_excerpt = '\n'.join(important_lines)
        if len(middle_excerpt) > middle_budget:
            middle_excerpt = middle_excerpt[:middle_budget]
        middle_excerpt = f"\n...[key lines from truncated section]...\n{middle_excerpt}\n"

    truncated_chars = len(text) - head_size - tail_size
    return (
        head +
        f"\n\n...[truncated {truncated_chars} chars]...\n" +
        middle_excerpt +
        f"\n" +
        tail
    )


def _is_duplicate_screenshot(base64_image: str) -> bool:
    """Check if screenshot is a duplicate of recent ones."""
    # Hash evenly-spaced samples across the full image for reliable dedup
    # This catches changes anywhere in the image, not just the header
    sample_size = min(len(base64_image), 8000)
    if len(base64_image) <= sample_size:
        sample = base64_image
    else:
        sample = base64_image[:1000] + base64_image[len(base64_image)//4:len(base64_image)//4+1000] + base64_image[len(base64_image)//2:len(base64_image)//2+1000] + base64_image[-1000:]
    img_hash = hashlib.sha256(sample.encode()).hexdigest()

    if img_hash in _recent_screenshot_hashes:
        return True

    # Add to cache, maintain max size
    _recent_screenshot_hashes.append(img_hash)
    if len(_recent_screenshot_hashes) > _MAX_SCREENSHOT_CACHE:
        _recent_screenshot_hashes.pop(0)

    return False


def _make_api_tool_result(
    result: ToolResult, tool_use_id: str
) -> BetaToolResultBlockParam:
    """Convert an agent ToolResult to an API ToolResultBlockParam.

    Token Optimization:
    - Truncates verbose outputs to save context space
    - Deduplicates consecutive identical screenshots
    - Keeps errors concise
    """
    tool_result_content: list[BetaTextBlockParam | BetaImageBlockParam] | str = []
    is_error = False

    if result.error:
        is_error = True
        # Truncate error messages
        error_text = _truncate_tool_output(result.error, _MAX_ERROR_CHARS)
        tool_result_content = _maybe_prepend_system_tool_result(result, error_text)
    else:
        if result.output:
            # Truncate verbose outputs
            truncated_output = _truncate_tool_output(result.output)
            tool_result_content.append(
                {
                    "type": "text",
                    "text": _maybe_prepend_system_tool_result(result, truncated_output),
                }
            )
        if result.base64_image:
            # Skip duplicate screenshots to save tokens
            if not _is_duplicate_screenshot(result.base64_image):
                # Detect actual image format from base64 data
                # JPEG starts with /9j/ in base64, PNG starts with iVBOR
                media_type = "image/jpeg" if result.base64_image.startswith("/9j/") else "image/png"
                tool_result_content.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": result.base64_image,
                        },
                    }
                )
            else:
                # Add note instead of duplicate image
                tool_result_content.append(
                    {
                        "type": "text",
                        "text": "[Screenshot unchanged from previous - skipped for efficiency]",
                    }
                )

    return {
        "type": "tool_result",
        "content": tool_result_content,
        "tool_use_id": tool_use_id,
        "is_error": is_error,
    }


def _maybe_prepend_system_tool_result(result: ToolResult, result_text: str):
    if result.system:
        result_text = f"<system>{result.system}</system>\n{result_text}"
    return result_text
