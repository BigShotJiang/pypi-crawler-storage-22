"""
Model routing: policy-driven selection between Claude models per agent type.

Extracted from main.py.
"""

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Optional, Set

from agent.logging_config import get_logger
from agent.types import AgentConfig

logger = get_logger(__name__)

# ── Model constants ──────────────────────────────────────────────────────────

MODEL_CLAUDE_OPUS = "claude-opus-4-6"
MODEL_CLAUDE_HAIKU = "claude-haiku-4-5-20251001"

# Heuristics for model selection
HAIKU_COMPLEXITY_THRESHOLD = 0.35  # AdaptiveConfig complexity score cut-off
HAIKU_MAX_THINKING_BUDGET = 2048
HAIKU_MAX_WORD_COUNT = 120

SIMPLE_ACTION_KEYWORDS = {
    "click",
    "open",
    "close",
    "type",
    "press",
    "scroll",
    "screenshot",
    "copy",
    "paste",
    "navigate",
    "select",
    "submit",
}

HIGH_REASONING_KEYWORDS = {
    "analyz",
    "investig",
    "debug",
    "strategy",
    "root cause",
    "comprehensive",
    "report",
    "summary",
    "assessment",
    "audit",
    "optimiz",
}


# ── Policy dataclass ─────────────────────────────────────────────────────────

@dataclass
class ModelRoutingPolicy:
    """Policy-driven routing between Haiku and Opus per agent type."""
    default_model: str = MODEL_CLAUDE_OPUS
    lightweight_model: Optional[str] = MODEL_CLAUDE_HAIKU
    lightweight_capabilities: Set[str] = field(default_factory=set)
    keyword_overrides: Dict[str, str] = field(default_factory=dict)
    complexity_threshold: float = HAIKU_COMPLEXITY_THRESHOLD
    thinking_budget_threshold: int = HAIKU_MAX_THINKING_BUDGET
    word_count_threshold: int = HAIKU_MAX_WORD_COUNT
    simple_keywords: Set[str] = field(default_factory=lambda: set(SIMPLE_ACTION_KEYWORDS))
    force_default_keywords: Set[str] = field(default_factory=lambda: set(HIGH_REASONING_KEYWORDS))

    def clone(self) -> "ModelRoutingPolicy":
        return ModelRoutingPolicy(**asdict(self))

    def with_overrides(self, overrides: Dict[str, Any]) -> "ModelRoutingPolicy":
        policy_dict = asdict(self)
        for key, value in overrides.items():
            if key in {"lightweight_capabilities", "simple_keywords", "force_default_keywords"}:
                policy_dict[key] = set(value)
            elif key == "keyword_overrides":
                policy_dict[key] = {k: v for k, v in value.items()}
            else:
                policy_dict[key] = value
        return ModelRoutingPolicy(**policy_dict)


DEFAULT_MODEL_POLICY = ModelRoutingPolicy()


# ── Selection function ────────────────────────────────────────────────────────

def select_model_for_task(
    instruction: str,
    agent_type: str,
    adaptive_config: Dict[str, Any],
    agent_config: AgentConfig,
) -> tuple[str, str]:
    """
    Select the most appropriate Anthropic model for a task using dynamic policies.
    """
    policy = MODEL_ROUTING_POLICIES.get(agent_type, DEFAULT_MODEL_POLICY)
    instruction_lower = instruction.lower()
    word_count = len(instruction.split())
    complexity = adaptive_config.get("complexity_score", 0.5)
    thinking_budget = adaptive_config.get("thinking_budget", 2048)

    for keyword, override_model in policy.keyword_overrides.items():
        if keyword in instruction_lower:
            return (
                override_model,
                f"{agent_type} keyword override '{keyword}' matched; routing to {override_model}",
            )

    simple_intent = any(keyword in instruction_lower for keyword in policy.simple_keywords)
    requires_deep_reasoning = any(keyword in instruction_lower for keyword in policy.force_default_keywords)
    capabilities_are_lightweight = (
        bool(policy.lightweight_capabilities)
        and set(agent_config.capabilities).issubset(policy.lightweight_capabilities)
    )

    if (
        policy.lightweight_model
        and not requires_deep_reasoning
        and (simple_intent or capabilities_are_lightweight)
        and complexity <= policy.complexity_threshold
        and thinking_budget <= policy.thinking_budget_threshold
        and word_count <= policy.word_count_threshold
    ):
        return (
            policy.lightweight_model,
            (
                f"{agent_type} policy routed to {policy.lightweight_model} "
                f"(simple_intent={simple_intent}, capabilities_lightweight={capabilities_are_lightweight}, "
                f"complexity={complexity:.2f}, thinking_budget={thinking_budget}, words={word_count})"
            ),
        )

    return (
        policy.default_model,
        (
            f"{agent_type} policy defaulted to {policy.default_model} "
            f"(simple_intent={simple_intent}, requires_deep_reasoning={requires_deep_reasoning}, "
            f"complexity={complexity:.2f})"
        ),
    )


# ── Default template ──────────────────────────────────────────────────────────

DEFAULT_MODEL_ROUTING_TEMPLATE: Dict[str, ModelRoutingPolicy] = {
    "SOCIAL_MEDIA": ModelRoutingPolicy(
        default_model=MODEL_CLAUDE_HAIKU,
        lightweight_model=MODEL_CLAUDE_HAIKU,
        lightweight_capabilities={"hiding_comments"},
        keyword_overrides={
            "escalat": MODEL_CLAUDE_OPUS,
            "investig": MODEL_CLAUDE_OPUS,
        },
        force_default_keywords=set(HIGH_REASONING_KEYWORDS) | {"escalat", "investig"},
    ),
    "AUTO_CLOSE": ModelRoutingPolicy(
        default_model=MODEL_CLAUDE_OPUS,
        lightweight_model=MODEL_CLAUDE_HAIKU,
        keyword_overrides={
            "routine": MODEL_CLAUDE_HAIKU,
            "standard": MODEL_CLAUDE_HAIKU,
            "bulk close": MODEL_CLAUDE_HAIKU,
        },
        simple_keywords=set(SIMPLE_ACTION_KEYWORDS) | {"close ticket", "resolve"},
    ),
    "ONBOARDING": ModelRoutingPolicy(
        default_model=MODEL_CLAUDE_OPUS,
        lightweight_model=MODEL_CLAUDE_HAIKU,
        simple_keywords=set(SIMPLE_ACTION_KEYWORDS) | {"invite", "setup account", "create user"},
        force_default_keywords=set(HIGH_REASONING_KEYWORDS) | {"migration", "compliance"},
    ),
    "LINKEDIN_MESSENGER": ModelRoutingPolicy(
        default_model=MODEL_CLAUDE_OPUS,
        lightweight_model=MODEL_CLAUDE_HAIKU,
        keyword_overrides={
            "simple follow up": MODEL_CLAUDE_HAIKU,
            "reminder": MODEL_CLAUDE_HAIKU,
        },
        force_default_keywords=set(HIGH_REASONING_KEYWORDS) | {"strategy", "personalize"},
    ),
    "SLACK_SUPPORT": ModelRoutingPolicy(
        default_model=MODEL_CLAUDE_OPUS,
        lightweight_model=MODEL_CLAUDE_HAIKU,
        keyword_overrides={
            "acknowledge": MODEL_CLAUDE_HAIKU,
            "status update": MODEL_CLAUDE_HAIKU,
        },
    ),
    "SHOPIFY": ModelRoutingPolicy(
        default_model=MODEL_CLAUDE_OPUS,
        lightweight_model=MODEL_CLAUDE_HAIKU,
        keyword_overrides={
            "update inventory": MODEL_CLAUDE_HAIKU,
            "price change": MODEL_CLAUDE_HAIKU,
        },
    ),
    "STATESET_AGENTIC": ModelRoutingPolicy(
        default_model=MODEL_CLAUDE_OPUS,
        lightweight_model=None,
        force_default_keywords=set(HIGH_REASONING_KEYWORDS) | {"investigation", "deep dive"},
    ),
}


# ── Policy loading ────────────────────────────────────────────────────────────

def _build_default_model_policies(agent_configs: Dict[str, AgentConfig]) -> Dict[str, ModelRoutingPolicy]:
    policies: Dict[str, ModelRoutingPolicy] = {}
    for agent_name in agent_configs.keys():
        template = DEFAULT_MODEL_ROUTING_TEMPLATE.get(agent_name, DEFAULT_MODEL_POLICY)
        policies[agent_name] = template.clone()
    return policies


def load_model_routing_policies(agent_configs: Dict[str, AgentConfig]) -> Dict[str, ModelRoutingPolicy]:
    """
    Load model routing policies from configuration file with sensible defaults.
    """
    policies = _build_default_model_policies(agent_configs)
    config_path = Path(os.environ.get("MODEL_ROUTING_CONFIG", "config/model_routing.json"))

    if config_path.exists():
        try:
            with config_path.open("r", encoding="utf-8") as fh:
                overrides = json.load(fh)
            if not isinstance(overrides, dict):
                raise ValueError("Root of model routing config must be an object")
            for agent_name, override in overrides.items():
                if not isinstance(override, dict):
                    logger.warning(
                        f"Ignoring model routing override for {agent_name}: expected object, got {type(override).__name__}",
                        extra={'agent_type': 'system'}
                    )
                    continue
                base = policies.get(agent_name, DEFAULT_MODEL_POLICY.clone())
                policies[agent_name] = base.with_overrides(override)
        except Exception as exc:
            logger.warning(
                f"Failed to load model routing config from '{config_path}': {exc}",
                extra={'agent_type': 'system'}
            )

    return policies


def reload_model_routing_policies(agent_configs: Dict[str, AgentConfig]) -> None:
    """Reload routing policies from configuration source."""
    global MODEL_ROUTING_POLICIES
    MODEL_ROUTING_POLICIES = load_model_routing_policies(agent_configs)


# Module-level mutable that gets populated by main.py on startup
MODEL_ROUTING_POLICIES: Dict[str, ModelRoutingPolicy] = {}
