"""
Parallel Tool Executor for StateSet Computer Use Agent.
Executes independent tool calls concurrently for better performance.

Key Features:
- Automatic dependency analysis
- Safe parallelization of read-only operations
- Preserves execution order for dependent operations
- 30-50% speed improvement on multi-tool tasks
"""

import asyncio
import logging
import threading
from typing import List, Dict, Any, Set, Optional, TYPE_CHECKING
from dataclasses import dataclass
import time
import re

from agent.tool_traits import is_read_only_tool_call, is_cacheable_tool_call
from agent.tools.base import ToolResult

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from agent.tool_guard import ToolExecutionGuard


@dataclass
class ToolCallGroup:
    """Group of tool calls that can execute in parallel"""
    calls: List[Dict[str, Any]]
    can_parallelize: bool
    reason: str


class DependencyAnalyzer:
    """Analyze dependencies between tool calls"""

    @classmethod
    def analyze_dependencies(cls, tool_uses: List[Dict[str, Any]]) -> List[Set[int]]:
        """Return a dependency set for each tool call index.

        Dependency rule of thumb:
        - Computer tool actions must be sequential (each depends on previous computer call).
        - Tool calls that reference the same `path` are treated as dependent (safe default).
        """

        deps: List[Set[int]] = [set() for _ in tool_uses]
        last_computer_index: Optional[int] = None
        last_path_index: Dict[str, int] = {}

        for idx, call in enumerate(tool_uses):
            name = call.get("name", "")
            tool_input = call.get("input", {}) or {}

            if name == "computer":
                if last_computer_index is not None:
                    deps[idx].add(last_computer_index)
                last_computer_index = idx

            path = tool_input.get("path")
            if isinstance(path, str) and path:
                previous_index = last_path_index.get(path)
                if previous_index is not None:
                    deps[idx].add(previous_index)
                last_path_index[path] = idx

        return deps
    
    @classmethod
    def is_read_only(cls, tool_call: Dict[str, Any]) -> bool:
        """Determine if a tool call is read-only"""

        tool_name = tool_call.get('name', '')
        tool_input = tool_call.get('input', {})
        return is_read_only_tool_call(tool_name, tool_input)

    @classmethod
    def is_cacheable(cls, tool_call: Dict[str, Any]) -> bool:
        """Determine if tool call result can be cached."""

        tool_name = tool_call.get('name', '')
        tool_input = tool_call.get('input', {})
        return is_cacheable_tool_call(tool_name, tool_input)
    
    @classmethod
    def has_dependency(cls, call1: Dict[str, Any], call2: Dict[str, Any]) -> bool:
        """Check if call2 depends on call1"""
        
        # If call1 writes and call2 reads the same resource, there's a dependency
        
        # File dependencies
        if (
            call1.get("name") == "str_replace_based_edit_tool"
            and call2.get("name") == "str_replace_based_edit_tool"
        ):
            # Both modify files - check if same file
            path1 = call1.get('input', {}).get('path', '')
            path2 = call2.get('input', {}).get('path', '')
            if path1 and path2 and path1 == path2:
                return True  # Can't modify same file in parallel
        
        # Memory dependencies
        if call1.get("name") == "memory" and call2.get("name") == "memory":
            # Check if same path
            cmd1 = call1.get('input', {}).get('command', '')
            cmd2 = call2.get('input', {}).get('command', '')
            path1 = call1.get('input', {}).get('path', '')
            path2 = call2.get('input', {}).get('path', '')
            
            # If writing to same path, there's a dependency
            if cmd1 in ['create', 'str_replace'] and path1 == path2:
                return True
        
        # Computer tool dependencies
        # If call1 clicks/types, call2 screenshot needs to wait
        if call1.get('name') == 'computer' and call2.get('name') == 'computer':
            action1 = call1.get('input', {}).get('action', '')
            action2 = call2.get('input', {}).get('action', '')

            # Writes followed by reads need ordering
            writes = {'left_click', 'right_click', 'double_click', 'type', 'key', 'mouse_move'}
            reads = {'screenshot'}

            if action1 in writes and action2 in reads:
                return True  # Screenshot needs to wait for action to complete

        # Cross-tool dependencies: Bash → Computer
        # If bash modifies files, computer screenshot should wait to see changes
        if call1.get('name') == 'bash' and call2.get('name') == 'computer':
            bash_cmd = call1.get('input', {}).get('command', '')
            # Check for file write operations
            write_patterns = ['>', '>>', 'echo', 'cat', 'tee', 'mv', 'cp', 'touch']
            if any(pattern in bash_cmd for pattern in write_patterns):
                return True

        # Cross-tool dependencies: Memory → Any other tool
        # Memory updates should complete before other tools read state
        if call1.get("name") == "memory":
            memory_cmd = call1.get('input', {}).get('command', '')
            if memory_cmd in ['create', 'update']:  # Write operations
                return True  # Any subsequent operation should wait

        # Cross-tool dependencies: Bash → Edit tool
        # If bash modifies files, edit tool should wait for consistency
        if call1.get("name") == "bash" and call2.get("name") == "str_replace_based_edit_tool":
            bash_cmd = call1.get('input', {}).get('command', '')
            write_patterns = ['>', '>>', 'echo', 'cat', 'tee', 'mv', 'cp', 'touch']
            if any(pattern in bash_cmd for pattern in write_patterns):
                return True

        # Cross-tool dependencies: Edit → Computer
        # If edit creates/modifies files that might be visible in GUI, computer should wait
        if (
            call1.get("name") == "str_replace_based_edit_tool"
            and call2.get("name") == "computer"
        ):
            edit_cmd = call1.get('input', {}).get('command', '')
            if edit_cmd in ['create', 'str_replace', 'write']:
                action2 = call2.get('input', {}).get('action', '')
                if action2 == 'screenshot':
                    return True

        return False
    
    @classmethod
    def group_by_dependencies(cls, tool_calls: List[Dict[str, Any]]) -> List[ToolCallGroup]:
        """
        Group tool calls into batches that can execute in parallel.
        
        Strategy:
        1. Scan for consecutive read-only calls → can parallelize
        2. Write operations → must be sequential
        3. Calls depending on writes → must be sequential
        
        Returns:
            List of ToolCallGroup, each representing a batch.
            Groups are ordered - execute group 0, then group 1, etc.
        """
        
        if not tool_calls:
            return []
        
        groups = []
        i = 0
        
        while i < len(tool_calls):
            current_call = tool_calls[i]
            
            # If this is read-only, collect consecutive read-only calls
            if cls.is_read_only(current_call):
                batch = [current_call]
                j = i + 1
                
                # Collect consecutive read-only calls with no dependencies
                while j < len(tool_calls) and cls.is_read_only(tool_calls[j]):
                    # Check if this call depends on anything in current batch
                    has_dep = any(
                        cls.has_dependency(existing, tool_calls[j]) or 
                        cls.has_dependency(tool_calls[j], existing)
                        for existing in batch
                    )
                    
                    if not has_dep:
                        batch.append(tool_calls[j])
                        j += 1
                    else:
                        break  # Dependency found, stop collecting
                
                # Create parallel group if multiple calls
                if len(batch) > 1:
                    groups.append(ToolCallGroup(
                        calls=batch,
                        can_parallelize=True,
                        reason=f"All {len(batch)} calls are read-only and independent"
                    ))
                    i = i + len(batch)
                else:
                    # Single read-only call
                    groups.append(ToolCallGroup(
                        calls=[current_call],
                        can_parallelize=False,
                        reason="Single call - no parallelization needed"
                    ))
                    i += 1
            else:
                # Write operation - must be sequential
                groups.append(ToolCallGroup(
                    calls=[current_call],
                    can_parallelize=False,
                    reason="Write operation - must be sequential"
                ))
                i += 1
        
        return groups


class ParallelToolExecutor:
    """Execute tool calls with automatic parallelization"""
    
    def __init__(self):
        self.dependency_analyzer = DependencyAnalyzer()
        self.max_parallel_tools = self._load_max_parallel_tools()
        self._parallel_semaphore = asyncio.Semaphore(self.max_parallel_tools)
        self.execution_stats = {
            'parallel_executions': 0,
            'sequential_executions': 0,
            'total_time_saved': 0.0,
            'calls_parallelized': 0
        }

    @staticmethod
    def _load_max_parallel_tools() -> int:
        """Load the configured maximum parallel tool executions with safety bounds."""
        try:
            from agent.config import get_config
            max_tools = getattr(get_config().performance, "max_parallel_tools", 5)
            max_tools = int(max_tools)
            if max_tools < 1:
                return 1
            if max_tools > 20:
                return 20
            return max_tools
        except Exception:
            return 5
    
    async def execute_batch(
        self,
        tool_calls: List[Dict[str, Any]],
        tool_collection,
        agent_type: str = "",
        guard: 'ToolExecutionGuard | None' = None,
        tool_durations: Dict[str, float] | None = None,
    ) -> List[Any]:
        """
        Execute tool calls with automatic parallelization.
        
        Args:
            tool_calls: List of tool calls from Claude's response
            tool_collection: ToolCollection instance
            agent_type: Agent type for logging
            guard: Optional ToolExecutionGuard
            tool_durations: Optional map of tool_call_id -> elapsed seconds
            
        Returns:
            List of tool results in same order as input
        """
        
        if not tool_calls:
            return []
        
        # Analyze dependencies and group
        groups = self.dependency_analyzer.group_by_dependencies(tool_calls)
        
        logger.info(
            f"Parallel execution analysis: {len(tool_calls)} tools → {len(groups)} groups",
            extra={'agent_type': agent_type}
        )
        
        all_results = []
        total_start = time.time()
        
        for i, group in enumerate(groups):
            group_start = time.time()
            
            if group.can_parallelize:
                # Execute in parallel
                logger.info(
                    f"Executing group {i+1}/{len(groups)} in PARALLEL: "
                    f"{len(group.calls)} tools ({group.reason})",
                    extra={'agent_type': agent_type}
                )
                
                results = await self._execute_parallel(
                    group.calls,
                    tool_collection,
                    guard,
                    tool_durations=tool_durations,
                )
                self.execution_stats['parallel_executions'] += 1
                self.execution_stats['calls_parallelized'] += len(group.calls)
            else:
                # Execute sequentially
                logger.info(
                    f"Executing group {i+1}/{len(groups)} SEQUENTIALLY: "
                    f"{len(group.calls)} tools ({group.reason})",
                    extra={'agent_type': agent_type}
                )
                
                results = await self._execute_sequential(
                    group.calls,
                    tool_collection,
                    guard,
                    tool_durations=tool_durations,
                )
                self.execution_stats['sequential_executions'] += 1
            
            all_results.extend(results)
            
            group_duration = time.time() - group_start
            if group.can_parallelize and len(group.calls) > 1:
                # Estimate time saved (assuming sequential would take sum of durations)
                estimated_sequential = group_duration * len(group.calls)
                time_saved = estimated_sequential - group_duration
                self.execution_stats['total_time_saved'] += time_saved
                
                logger.info(
                    f"Parallel execution saved ~{time_saved:.2f}s "
                    f"(sequential: ~{estimated_sequential:.1f}s, parallel: {group_duration:.1f}s)",
                    extra={'agent_type': agent_type}
                )
        
        total_duration = time.time() - total_start
        logger.info(
            f"Batch execution complete: {len(tool_calls)} tools in {total_duration:.2f}s",
            extra={'agent_type': agent_type}
        )
        
        return all_results
    
    async def _execute_parallel(
        self,
        calls: List[Dict[str, Any]],
        tool_collection,
        guard: 'ToolExecutionGuard | None' = None,
        tool_durations: Dict[str, float] | None = None,
    ) -> List[Any]:
        """Execute calls in parallel"""

        async def _run_call(call: Dict[str, Any]) -> "ToolResult":
            tool_id = call.get("id")
            start = time.perf_counter()
            try:
                async with self._parallel_semaphore:
                    if guard:
                        result = await guard.execute(call, tool_collection)
                    else:
                        result = await tool_collection.run(
                            name=call['name'],
                            tool_input=call.get('input', {})
                        )
            except Exception as result_error:
                if tool_durations is not None and tool_id is not None:
                    tool_durations[str(tool_id)] = time.perf_counter() - start
                tool_name = call.get('name', 'unknown')
                logger.error(
                    f"Parallel tool '{tool_name}' failed: {type(result_error).__name__}: {result_error}",
                    exc_info=result_error,
                )
                return ToolResult(error=str(result_error))
            else:
                if tool_durations is not None and tool_id is not None:
                    tool_durations[str(tool_id)] = time.perf_counter() - start
                if isinstance(result, ToolResult):
                    return result
                return ToolResult(output=str(result))

        # Optional: enforce maximum parallel execution concurrency.
        if self.max_parallel_tools <= 1:
            results = [await _run_call(call) for call in calls]
            return results

        tasks = [asyncio.create_task(_run_call(call)) for call in calls]
        
        # Execute all in parallel
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle exceptions — convert to ToolResult but track failure count
        processed_results = []
        error_count = 0
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                error_count += 1
                tool_name = calls[i].get('name', 'unknown') if i < len(calls) else 'unknown'
                logger.error(
                    f"Parallel tool '{tool_name}' failed: {type(result).__name__}: {result}",
                    exc_info=result,
                )
                processed_results.append(ToolResult(error=str(result)))
            else:
                processed_results.append(result)

        if error_count > 0:
            logger.warning(f"{error_count}/{len(results)} parallel tool executions failed")

        return processed_results
    
    async def _execute_sequential(
        self,
        calls: List[Dict[str, Any]],
        tool_collection,
        guard: 'ToolExecutionGuard | None' = None,
        tool_durations: Dict[str, float] | None = None,
    ) -> List[Any]:
        """Execute calls sequentially"""
        
        results = []
        for call in calls:
            tool_id = call.get("id")
            start = time.perf_counter()
            try:
                if guard:
                    result = await guard.execute(call, tool_collection)
                else:
                    result = await tool_collection.run(
                        name=call['name'],
                        tool_input=call.get('input', {})
                    )
                if tool_durations is not None and tool_id is not None:
                    tool_durations[str(tool_id)] = time.perf_counter() - start
                results.append(result)
            except Exception as e:
                if tool_durations is not None and tool_id is not None:
                    tool_durations[str(tool_id)] = time.perf_counter() - start
                logger.error(f"Sequential tool execution failed: {e}")
                results.append(ToolResult(error=str(e)))
        
        return results
    
    def get_stats(self) -> Dict[str, Any]:
        """Get execution statistics"""
        return {
            'parallel_executions': self.execution_stats['parallel_executions'],
            'sequential_executions': self.execution_stats['sequential_executions'],
            'calls_parallelized': self.execution_stats['calls_parallelized'],
            'total_time_saved': self.execution_stats['total_time_saved'],
            'avg_time_saved': (
                self.execution_stats['total_time_saved'] / self.execution_stats['parallel_executions']
                if self.execution_stats['parallel_executions'] > 0
                else 0
            )
        }
    
    def print_stats(self, use_logger: bool = False):
        """
        Output execution statistics.

        Args:
            use_logger: If True, outputs via logger.info. If False, prints to stdout.
        """
        stats = self.get_stats()

        lines = [
            "\n" + "="*70,
            "PARALLEL EXECUTION STATISTICS",
            "="*70,
            f"  Parallel executions: {stats['parallel_executions']}",
            f"  Sequential executions: {stats['sequential_executions']}",
            f"  Calls parallelized: {stats['calls_parallelized']}",
            f"  Total time saved: {stats['total_time_saved']:.2f}s",
            f"  Avg time saved per parallel batch: {stats['avg_time_saved']:.2f}s",
            "="*70 + "\n"
        ]
        output = "\n".join(lines)

        if use_logger:
            logger.info("Parallel execution statistics:\n%s", output)
        else:
            print(output)


# Global instance
_executor_instance: Optional[ParallelToolExecutor] = None
_executor_lock = threading.Lock()


def get_parallel_executor() -> ParallelToolExecutor:
    """Get global parallel executor instance (thread-safe)."""
    global _executor_instance
    if _executor_instance is None:
        with _executor_lock:
            if _executor_instance is None:
                _executor_instance = ParallelToolExecutor()
    return _executor_instance


def reset_parallel_executor():
    """Reset executor (for testing)"""
    global _executor_instance
    with _executor_lock:
        _executor_instance = None


class ParallelExecutor:
    """Minimal parallel executor used by unit tests."""

    def __init__(self, tools: Dict[str, Any]):
        self.tools = tools
        self.analyzer = DependencyAnalyzer()

    async def execute_parallel(self, tool_uses: List[Dict[str, Any]]) -> List[ToolResult]:
        deps = self.analyzer.analyze_dependencies(tool_uses)
        results: List[ToolResult] = [ToolResult(output="", error=None) for _ in tool_uses]

        started: Set[int] = set()
        completed: Set[int] = set()

        async def run_call(index: int) -> ToolResult:
            call = tool_uses[index]
            name = call.get("name", "")
            tool_input = call.get("input", {}) or {}
            tool = self.tools.get(name)
            if tool is None:
                return ToolResult(error=f"Unknown tool: {name}")
            try:
                result = await tool(**tool_input)
                if isinstance(result, ToolResult):
                    return result
                if isinstance(result, dict):
                    return ToolResult(
                        output=result.get("output"),
                        error=result.get("error"),
                        base64_image=result.get("base64_image"),
                        system=result.get("system"),
                    )
                return ToolResult(output=str(result))
            except Exception as exc:
                return ToolResult(error=str(exc))

        while len(completed) < len(tool_uses):
            ready = [
                index
                for index in range(len(tool_uses))
                if index not in started and deps[index].issubset(completed)
            ]
            if not ready:
                # Dependency cycle or missing prerequisites.
                for index in range(len(tool_uses)):
                    if index not in completed:
                        results[index] = ToolResult(error="Unresolvable dependency graph")
                break

            tasks = [asyncio.create_task(run_call(index)) for index in ready]
            started.update(ready)
            batch_results = await asyncio.gather(*tasks)
            for index, result in zip(ready, batch_results):
                results[index] = result
                completed.add(index)

        return results
