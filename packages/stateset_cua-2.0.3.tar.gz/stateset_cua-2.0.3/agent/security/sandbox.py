"""
Tool execution sandboxing using Docker containers.

Provides isolated execution environments for:
- Bash commands
- File operations
- External tool execution

Features:
- Resource limits (CPU, memory)
- Network isolation
- Filesystem isolation
- Timeout enforcement
"""

import asyncio
import logging
import contextlib
import shlex
from typing import Optional, Dict, Any, List
from pathlib import Path
from dataclasses import dataclass

from .validator import (
    ToolInputValidator,
    ValidationError,
    get_configured_allowed_commands,
)

logger = logging.getLogger(__name__)


@dataclass
class SandboxConfig:
    """Configuration for sandbox execution."""
    cpu_limit: float = 1.0  # CPU cores
    memory_limit: str = "512m"  # Memory limit
    timeout: int = 60  # Seconds
    network_disabled: bool = True
    read_only_root: bool = True
    allowed_mounts: List[str] = None


class SandboxManager:
    """Manages sandboxed execution of tools."""

    def __init__(self, enabled: bool = False, config: Optional[SandboxConfig] = None):
        self.enabled = enabled
        self.config = config or SandboxConfig()
        self._docker_available = self._check_docker()

        if self.enabled and not self._docker_available:
            logger.warning("Docker not available. Sandboxing disabled.")
            self.enabled = False

    def _check_docker(self) -> bool:
        """Check if Docker is available."""
        try:
            import subprocess
            result = subprocess.run(
                ["docker", "version"],
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except Exception:
            return False

    async def execute_bash(
        self,
        command: str,
        work_dir: Optional[str] = None,
        env: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Execute bash command in sandbox.

        Args:
            command: Command to execute
            work_dir: Working directory
            env: Environment variables

        Returns:
            Dict with stdout, stderr, exit_code
        """
        valid, reason = self.validate_command(command)
        if not valid:
            return {
                "stdout": "",
                "stderr": f"Command blocked: {reason}",
                "exit_code": -1,
                "sandboxed": bool(self.enabled),
            }

        if not self.enabled:
            # Fallback to direct execution (not sandboxed)
            return await self._execute_direct(command, work_dir, env)

        # Execute in Docker container
        return await self._execute_sandboxed(command, work_dir, env)

    async def _execute_direct(
        self,
        command: str,
        work_dir: Optional[str] = None,
        env: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Execute command directly without sandbox."""
        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=work_dir,
                env=env
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=self.config.timeout
                )

                return {
                    "stdout": stdout.decode('utf-8', errors='replace'),
                    "stderr": stderr.decode('utf-8', errors='replace'),
                    "exit_code": proc.returncode,
                    "sandboxed": False
                }
            except asyncio.TimeoutError:
                await self._terminate_process(proc)
                return {
                    "stdout": "",
                    "stderr": f"Command timed out after {self.config.timeout} seconds",
                    "exit_code": -1,
                    "sandboxed": False
                }

        except Exception as e:
            return {
                "stdout": "",
                "stderr": f"Execution error: {str(e)}",
                "exit_code": -1,
                "sandboxed": False
            }

    async def _execute_sandboxed(
        self,
        command: str,
        work_dir: Optional[str] = None,
        env: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Execute command in Docker sandbox."""
        # Build Docker run command
        docker_cmd = self._build_docker_command(command, work_dir, env)

        try:
            proc = await asyncio.create_subprocess_shell(
                docker_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=self.config.timeout + 5  # Extra buffer for Docker overhead
                )

                return {
                    "stdout": stdout.decode('utf-8', errors='replace'),
                    "stderr": stderr.decode('utf-8', errors='replace'),
                    "exit_code": proc.returncode,
                    "sandboxed": True
                }
            except asyncio.TimeoutError:
                await self._terminate_process(proc)
                # Cleanup Docker container
                await self._cleanup_container()
                return {
                    "stdout": "",
                    "stderr": (
                        f"Sandboxed command timed out after {self.config.timeout + 5} seconds"
                    ),
                    "exit_code": -1,
                    "sandboxed": True
                }

        except Exception as e:
            return {
                "stdout": "",
                "stderr": f"Sandbox execution error: {str(e)}",
                "exit_code": -1,
                "sandboxed": True
            }

    def _build_docker_command(
        self,
        command: str,
        work_dir: Optional[str] = None,
        env: Optional[Dict[str, str]] = None
    ) -> str:
        """Build Docker run command with all constraints."""
        docker_args = [
            "docker", "run",
            "--rm",  # Remove container after execution
            f"--cpus={self.config.cpu_limit}",
            f"--memory={self.config.memory_limit}",
            f"--ulimit", f"nofile=1024:1024",  # Limit file descriptors
        ]

        # Network isolation
        if self.config.network_disabled:
            docker_args.append("--network=none")

        # Read-only root filesystem
        if self.config.read_only_root:
            docker_args.append("--read-only")
            docker_args.extend(["--tmpfs", "/tmp:rw,noexec,nosuid,size=100m"])

        # Environment variables
        if env:
            for key, value in env.items():
                docker_args.extend(["-e", f"{key}={value}"])

        # Working directory mount
        if work_dir:
            work_path = Path(work_dir).resolve()
            docker_args.extend(["-v", f"{work_path}:/workspace:rw"])
            docker_args.extend(["-w", "/workspace"])

        # Additional mounts
        for mount in self.config.allowed_mounts or []:
            if not isinstance(mount, str):
                logger.debug("Skipping invalid sandbox mount: %r", mount)
                continue
            mount = mount.strip()
            if not mount or ":" not in mount:
                logger.debug("Skipping mount with invalid format: %r", mount)
                continue
            docker_args.extend(["-v", mount])

        # Use Alpine Linux for minimal attack surface
        docker_args.append("alpine:latest")
        docker_args.extend(["sh", "-c", command])

        return " ".join(shlex.quote(str(arg)) for arg in docker_args)

    async def _cleanup_container(self):
        """Cleanup any dangling containers."""
        try:
            proc = await asyncio.create_subprocess_shell(
                "docker ps -aq --filter 'status=exited' | xargs -r docker rm",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            await proc.wait()
        except Exception:
            pass  # Best effort cleanup

    def validate_command(self, command: str) -> tuple[bool, Optional[str]]:
        """
        Validate command for security concerns.

        Returns:
            (is_valid, error_message)
        """
        if not isinstance(command, str):
            return False, "Command must be a string"
        try:
            from agent.config import get_config

            security_config = getattr(get_config(), "security", None)
            enforce_allowed_commands = bool(
                getattr(security_config, "enforce_command_allowlist", False)
            )
            ToolInputValidator().validate_command(
                command,
                allowed_commands=get_configured_allowed_commands(),
                enforce_allowed_commands=enforce_allowed_commands,
            )
        except ValidationError as exc:
            return False, str(exc)
        except Exception as exc:
            return False, f"Command validation failed: {exc}"
        return True, None

    async def _terminate_process(self, proc: asyncio.subprocess.Process, timeout: float = 5.0):
        """Terminate a subprocess and force-kill on timeout."""
        returncode = proc.returncode
        if isinstance(returncode, int):
            return

        try:
            proc.terminate()
        except ProcessLookupError:
            return
        except Exception as exc:
            logger.warning("Process terminate failed: %s", exc, extra={"module": "sandbox"})

        try:
            await asyncio.wait_for(proc.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(proc.wait(), timeout=1.0)


# Global sandbox manager
_sandbox_manager: Optional[SandboxManager] = None


def get_sandbox_manager(enabled: bool = False, config: Optional[SandboxConfig] = None) -> SandboxManager:
    """Get the global sandbox manager instance."""
    global _sandbox_manager

    if _sandbox_manager is None:
        _sandbox_manager = SandboxManager(enabled, config)
        return _sandbox_manager

    if _sandbox_manager.enabled != enabled:
        _sandbox_manager = SandboxManager(enabled, config)
    elif config is not None and _sandbox_manager.config != config:
        _sandbox_manager = SandboxManager(enabled, config)

    return _sandbox_manager


def initialize_sandbox(enabled: bool = False, config: Optional[SandboxConfig] = None):
    """Initialize the sandbox manager."""
    global _sandbox_manager
    _sandbox_manager = SandboxManager(enabled, config)
