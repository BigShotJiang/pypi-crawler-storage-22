"""
Input validation for tool execution.

Validates:
- File paths (no traversal)
- Command safety
- Input size limits
- Data types
- Prompt injection detection
- Environment variable safety

This module provides comprehensive input validation for all tool executions
to prevent security vulnerabilities like command injection, path traversal,
and prompt injection attacks.
"""

import logging
import re
import os
import shlex
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, List, Set
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

COMPUTER_TOOL_ACTIONS_BY_TOOL_VERSION = {
    "computer_use_20241022": {
        "screenshot",
        "mouse_move",
        "left_click",
        "right_click",
        "middle_click",
        "double_click",
        "cursor_position",
        "key",
        "type",
        "left_click_drag",
    },
    "computer_use_20250124": {
        "screenshot",
        "mouse_move",
        "left_click",
        "right_click",
        "middle_click",
        "double_click",
        "triple_click",
        "left_click_drag",
        "cursor_position",
        "key",
        "type",
        "left_mouse_down",
        "left_mouse_up",
        "scroll",
        "hold_key",
        "wait",
    },
    "computer_use_20251124": {
        "screenshot",
        "mouse_move",
        "left_click",
        "right_click",
        "middle_click",
        "double_click",
        "triple_click",
        "left_click_drag",
        "cursor_position",
        "key",
        "type",
        "left_mouse_down",
        "left_mouse_up",
        "scroll",
        "hold_key",
        "wait",
        "zoom",
    },
}

COMPUTER_TOOL_ACTIONS = set().union(*COMPUTER_TOOL_ACTIONS_BY_TOOL_VERSION.values())


def get_computer_actions_for_tool_version(tool_version: Optional[str]) -> Optional[set[str]]:
    """
    Return supported computer actions for a given tool version.

    Args:
        tool_version: The configured computer tool version (for example,
            "computer_use_20251124").

    Returns:
        A set of allowed actions, or None for unknown versions.
    """
    if not tool_version or not isinstance(tool_version, str):
        return None
    tool_version = tool_version.strip()
    if not tool_version:
        return None
    if tool_version in COMPUTER_TOOL_ACTIONS_BY_TOOL_VERSION:
        return set(COMPUTER_TOOL_ACTIONS_BY_TOOL_VERSION[tool_version])

    # Backward-compatible form used by tool APIs: "computer_20241022" vs
    # configured versions like "computer_use_20241022".
    if tool_version.startswith("computer_") and "computer_use_" not in tool_version:
        normalized_tool_version = f"computer_use_{tool_version.removeprefix('computer_')}"
        normalized_actions = COMPUTER_TOOL_ACTIONS_BY_TOOL_VERSION.get(normalized_tool_version)
        return set(normalized_actions) if normalized_actions is not None else None

    return None


def get_configured_allowed_commands(
    allowed_commands: Optional[Iterable[str]] = None,
) -> list[str]:
    """Resolve command allowlist from config or provided value.

    Args:
        allowed_commands: Optional explicit allowlist override.

    Returns:
        A normalized list of allowed command names.

    Raises:
        ValidationError: If configuration provides an invalid allowlist shape.
    """
    if allowed_commands is not None:
        if not isinstance(allowed_commands, (list, tuple, set, frozenset)):
            raise ValidationError("Invalid allowed_commands configuration")
        return normalize_allowed_commands(allowed_commands)

    try:
        from agent.config import get_config
    except Exception:
        return []

    security_config = getattr(get_config(), "security", None)
    if security_config is None:
        return []

    raw_allowed_commands = getattr(security_config, "allowed_commands", None)
    if raw_allowed_commands is None:
        return []

    if not isinstance(raw_allowed_commands, (list, tuple, set, frozenset)):
        raise ValidationError("Invalid allowed_commands configuration")

    return normalize_allowed_commands(raw_allowed_commands)


class ValidationSeverity(Enum):
    """Severity levels for validation issues."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class ValidationResult:
    """Result of a validation check."""
    is_valid: bool
    severity: ValidationSeverity = ValidationSeverity.INFO
    message: str = ""
    field: str = ""
    sanitized_value: Optional[Any] = None

    def __bool__(self) -> bool:
        return self.is_valid


@dataclass
class ValidationConfig:
    """Configuration for input validation."""
    max_file_size: int = 10485760  # 10MB
    max_command_length: int = 10000
    max_string_length: int = 100000
    max_path_depth: int = 20
    allow_sudo: bool = False
    allowed_env_vars: Set[str] = field(default_factory=lambda: {
        "PATH", "HOME", "USER", "DISPLAY", "TERM", "LANG", "LC_ALL"
    })
    blocked_env_prefixes: Set[str] = field(default_factory=lambda: {
        "AWS_", "ANTHROPIC_", "STRIPE_", "SECRET_", "API_KEY", "TOKEN_"
    })


class ValidationError(Exception):
    """Raised when validation fails."""

    def __init__(
        self,
        message: str,
        severity: ValidationSeverity = ValidationSeverity.ERROR,
        field: str = "",
        value: Any = None
    ):
        super().__init__(message)
        self.severity = severity
        self.field = field
        self.value = value


def normalize_allowed_commands(raw_allowed_commands) -> list[str]:
    """Normalize configured allowed commands into a stable list of non-empty strings."""
    if not isinstance(raw_allowed_commands, (list, tuple, set, frozenset)):
        return []

    return [
        cmd.strip()
        for cmd in raw_allowed_commands
        if isinstance(cmd, str) and cmd.strip()
    ]


class ToolInputValidator:
    """
    Validates tool inputs for security and correctness.

    This class provides comprehensive validation for all tool inputs,
    including file paths, shell commands, and arbitrary string inputs.
    It implements multiple security checks to prevent common attacks.

    Attributes:
        config: ValidationConfig instance with validation settings.

    Example:
        validator = ToolInputValidator()
        try:
            safe_path = validator.validate_file_path("/etc/passwd")
        except ValidationError as e:
            logger.error(f"Validation failed: {e}")
    """

    # Patterns that indicate potential prompt injection
    PROMPT_INJECTION_PATTERNS = [
        r"ignore\s+(previous|all|above)\s+instructions?",
        r"disregard\s+(previous|all|above)",
        r"forget\s+(everything|previous|all)",
        r"new\s+instructions?:",
        r"system\s*prompt:",
        r"<\|.*\|>",  # Special tokens
        r"\[INST\]|\[\/INST\]",  # Instruction markers
        r"<<SYS>>|<</SYS>>",  # System markers
        r"Human:|Assistant:|User:|AI:",  # Role markers
    ]

    # Dangerous shell patterns (pattern, human-readable reason)
    DANGEROUS_SHELL_PATTERNS = [
        (r"\brm\s+(-[a-zA-Z]*r[a-zA-Z]*\s+)?(/|~|\$HOME)", "critical path deletion"),
        (r"\brm\s+-[a-zA-Z]*f[a-zA-Z]*\s+-[a-zA-Z]*r", "recursive delete"),
        (r"\brm\s+-[a-zA-Z]*r[a-zA-Z]*\s+-[a-zA-Z]*f", "recursive delete"),
        (r"\bdd\s+.*\bof=/dev/", "device write"),
        (r"\bdd\s+.*\bif=/dev/(zero|random|urandom)", "device read"),
        (r"\bdd\s+.*\bif=/dev/(?!zero|random|urandom)\S+", "device read"),
        (r">\s*/dev/[hs]d[a-z]", "disk device overwrite"),
        (r"\bmkfs\b", "filesystem formatting"),
        (r"\bfdisk\b", "disk partitioning"),
        (r"\bparted\b", "disk partitioning"),
        (r":\(\)\s*\{", "fork bomb"),
        (r"\bwhile\s+true\s*;.*&", "infinite process spawning"),
        (r"\bchmod\s+(-[a-zA-Z]*R[a-zA-Z]*\s+)?[0-7]*\s+(/|~|\$HOME)", "permission change"),
        (r"\bchown\s+(-[a-zA-Z]*R[a-zA-Z]*\s+)?.*\s+(/|~|\$HOME)", "ownership change"),
        (r"\b(shutdown|reboot|poweroff|init\s+[0-6])\b", "system shutdown"),
        (r"\bsystemctl\s+(stop|disable|mask)\s+(ssh|sshd|network)", "critical services"),
        (r">\s*/etc/", "system configuration"),
        (r">\s*/boot/", "boot file overwrite"),
        (r"\bcurl\s+.*\|\s*bash", "remote code execution"),
        (r"\bwget\s+.*\|\s*bash", "remote code execution"),
        (r"\|\s*bash(\s|$|;|&|\|)", "shell execution via pipe"),
        (r"\|\s*sh(\s|$|;|&|\|)", "shell execution via pipe"),
        (r"\bnc\b[^\n]*\s-e\b", "netcat execute"),
        (r"\bhistory\s+-[cd]", "history manipulation"),
        (r"\bunset\s+HISTFILE\b", "history manipulation"),
        (r">\s*~/.bash_history", "history manipulation"),
        (r"\$\(", "command substitution"),
        (r"`[^`]+`", "backtick substitution"),
    ]

    # Syntax-level operators that materially alter execution flow.
    _FORBIDDEN_CONTROL_OPERATORS = {
        "&&": "command chaining",
        "||": "command branching",
    }

    _SHELL_PIPE_TARGETS = {"bash", "sh", "dash", "ash", "zsh", "ksh"}

    # Dangerous file paths
    DANGEROUS_PATHS = [
        "/etc/passwd",
        "/etc/shadow",
        "/etc/sudoers",
        "/root",
        "/sys",
        "/proc",
        "/.ssh",
        "/boot",
        "/dev",
    ]

    _VAR_EXPANSION_COMMANDS = {
        "rm",
        "dd",
        "mkfs",
        "mkfs.ext4",
        "chmod",
        "chown",
        "fdisk",
        "parted",
        "shutdown",
        "reboot",
        "poweroff",
        "init",
    }

    def __init__(self, config: Optional[ValidationConfig] = None):
        """
        Initialize the validator with optional configuration.

        Args:
            config: Optional ValidationConfig instance. Uses defaults if not provided.
        """
        self.config = config or ValidationConfig()
        self._compiled_injection_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.PROMPT_INJECTION_PATTERNS
        ]
        self._compiled_shell_patterns = [
            (re.compile(p, re.IGNORECASE), reason)
            for p, reason in self.DANGEROUS_SHELL_PATTERNS
        ]

    def validate_file_path(self, path: str, base_dir: Optional[str] = None) -> str:
        """
        Validate file path for security concerns.

        Args:
            path: File path to validate
            base_dir: Base directory to restrict to

        Returns:
            Validated absolute path

        Raises:
            ValidationError: If path is invalid or dangerous
        """
        if not isinstance(path, str):
            raise ValidationError("Path must be a string")

        if "\x00" in path:
            raise ValidationError("Path contains invalid null byte")

        raw_path = Path(path).expanduser()
        if not raw_path.is_absolute():
            raise ValidationError("Path must be an absolute path")

        if ".." in raw_path.parts:
            raise ValidationError("Path traversal detected")

        # Convert to normalized absolute path
        file_path = raw_path.resolve()

        if self.config.max_path_depth and len(file_path.parts) - 1 > self.config.max_path_depth:
            raise ValidationError("Path depth exceeds maximum allowed limit")

        # Check if within base directory
        if base_dir:
            base_path = Path(base_dir).expanduser().resolve()
            try:
                file_path.relative_to(base_path)
            except ValueError:
                raise ValidationError(f"Path {path} is outside base directory {base_dir}")

        # Check for dangerous paths
        for dangerous in self.DANGEROUS_PATHS:
            if str(file_path).startswith(dangerous):
                raise ValidationError(f"Access to {dangerous} is prohibited")

        return str(file_path)

    def validate_command(
        self,
        command: str,
        allowed_commands: Optional[List[str]] = None,
        enforce_allowed_commands: bool = False,
    ) -> str:
        """
        Validate bash command for safety.

        Args:
            command: Command to validate
            allowed_commands: Optional whitelist of allowed commands

        Returns:
            Validated command

        Raises:
            ValidationError: If command is dangerous
        """
        if not isinstance(command, str):
            raise ValidationError("Command must be a string")

        if not command.strip():
            raise ValidationError("Command cannot be empty")

        if "\x00" in command:
            raise ValidationError("Command contains invalid null byte")

        if len(command) > self.config.max_command_length:
            raise ValidationError("Command too long")

        # Check for unsafe control characters and command separators.
        if re.search(r"[\x01-\x08\x0b-\x1f\x7f]", command):
            raise ValidationError("Command contains control characters")

        if "\r" in command or "\n" in command:
            raise ValidationError("Command contains newline or carriage-return control characters")

        if "$(" in command or "`" in command:
            raise ValidationError("Command substitution is disabled for security")

        normalized = command.strip()

        # Parse control operators at lexical level before semantic checks.
        try:
            lexer = shlex.shlex(normalized, posix=True)
            lexer.whitespace_split = True
            lexer.commenters = ""
            try:
                lexer.punctuation_chars = "|&;<>"
            except (AttributeError, TypeError):
                # Some Python/shlex versions expose punctuation_chars as read-only.
                pass
            tokens = list(lexer)
        except ValueError as e:
            raise ValidationError(f"Command parse error: {e}")

        for idx, token in enumerate(tokens):
            token = token.lower()
            next_token = tokens[idx + 1].lower() if idx + 1 < len(tokens) else ""

            if token == ";":
                raise ValidationError("Dangerous control operator detected: command separator")

            if token == "&":
                if next_token == "&":
                    raise ValidationError("Dangerous control operator detected: command chaining")
                raise ValidationError("Dangerous control operator detected: background execution")

            if token == "|":
                if next_token == "|":
                    raise ValidationError("Dangerous control operator detected: command branching")
                if next_token == "&":
                    raise ValidationError("Dangerous control operator detected: combined stdout/stderr pipe")
                if next_token and (
                    next_token in self._SHELL_PIPE_TARGETS
                    or next_token.endswith("/bash")
                    or next_token.endswith("/sh")
                ):
                    if re.search(r"\b(?:curl|wget)\b", normalized, flags=re.IGNORECASE):
                        raise ValidationError("Dangerous control operator detected: remote code execution")
                    raise ValidationError("Dangerous control operator detected: shell execution via pipe")

            if token in self._FORBIDDEN_CONTROL_OPERATORS:
                raise ValidationError(
                    f"Dangerous control operator detected: "
                    f"{self._FORBIDDEN_CONTROL_OPERATORS[token]}"
                )

            if token == "|&":
                raise ValidationError("Dangerous control operator detected: combined stdout/stderr pipe")
            if token in {"<", "<<", "<<-", "<<<"}:
                raise ValidationError("Dangerous control operator detected: heredoc")
            if token.startswith(">") or token == ">>" or token.startswith("2>"):
                target = next_token
                lowered_target = target.lower()
                if lowered_target.startswith("/etc/") or lowered_target == "/etc":
                    raise ValidationError(
                        "Dangerous control operator detected: system configuration overwrite"
                    )
                if lowered_target.startswith("/boot/") or lowered_target == "/boot":
                    raise ValidationError(
                        "Dangerous control operator detected: boot file overwrite"
                    )
                if lowered_target.startswith("/dev/") or lowered_target == "/dev":
                    raise ValidationError(
                        "Dangerous control operator detected: disk device overwrite"
                    )
                if (
                    lowered_target == "~/.bash_history"
                    or lowered_target == ".bash_history"
                    or lowered_target.endswith("/.bash_history")
                ):
                    raise ValidationError(
                        "Dangerous control operator detected: history manipulation"
                    )
                raise ValidationError("Dangerous control operator detected: output redirection")

        # Check sudo usage if disabled by policy.
        if not self.config.allow_sudo and re.search(r"\bsudo\b", normalized, re.IGNORECASE):
            raise ValidationError("Sudo usage is disabled")

        try:
            command_tokens = shlex.split(normalized, posix=True)
        except ValueError as e:
            raise ValidationError(f"Invalid command syntax: {e}")

        command_name = command_tokens[0] if command_tokens else ""
        if command_name in self._VAR_EXPANSION_COMMANDS and any(
            "$" in arg for arg in command_tokens[1:]
        ):
            raise ValidationError("Variable expansion detected")

        # Check dangerous shell patterns.
        for pattern, reason in self._compiled_shell_patterns:
            if pattern.search(normalized):
                raise ValidationError(f"Dangerous pattern detected: {reason}")

        # Guard against command substitution to prevent nested shell execution.
        for inner in re.findall(r"\$\(([^)]+)\)", normalized):
            raise ValidationError(f"command substitution blocked: {inner!r}")
        for inner in re.findall(r"`([^`]+)`", normalized):
            raise ValidationError(f"backtick substitution blocked: {inner!r}")

        # Optional allowlist check by command name (supports bare names and absolute paths).
        if allowed_commands is not None:
            command_candidates = {command_name}
            if command_name:
                try:
                    command_candidates.add(Path(command_name).name)
                except Exception:
                    pass

            allowed_command_names = set()
            for allowed in allowed_commands:
                if not isinstance(allowed, str):
                    continue
                allowed = allowed.strip()
                if not allowed:
                    continue
                allowed_command_names.add(allowed)
                try:
                    allowed_command_names.add(Path(allowed).name)
                except Exception:
                    pass

            if not allowed_command_names:
                if enforce_allowed_commands:
                    raise ValidationError("Command allowlist is empty; no commands are allowed")
                if allowed_commands:
                    raise ValidationError("No valid allowed commands configured")
                return normalized

            if not command_candidates.intersection(allowed_command_names):
                raise ValidationError(f"Command '{command_name}' not in allowed list")

        return normalized

    def validate_string_input(
        self,
        value: str,
        max_length: Optional[int] = None,
        pattern: Optional[str] = None
    ) -> str:
        """
        Validate string input.

        Args:
            value: String to validate
            max_length: Maximum allowed length
            pattern: Regex pattern to match

        Returns:
            Validated string

        Raises:
            ValidationError: If validation fails
        """
        if max_length and len(value) > max_length:
            raise ValidationError(f"String exceeds maximum length of {max_length}")

        if pattern and not re.match(pattern, value):
            raise ValidationError(f"String does not match required pattern")

        return value

    def validate_tool_input(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        allowed_commands: Optional[List[str]] = None,
        allowed_actions: Optional[Iterable[str]] = None,
        enforce_allowed_commands: bool = False,
    ) -> Dict[str, Any]:
        """
        Validate complete tool input based on tool type.

        Args:
            tool_name: Name of the tool
            tool_input: Tool input dictionary

        Returns:
            Validated tool input

        Raises:
            ValidationError: If validation fails
        """
        if not isinstance(tool_name, str) or not tool_name:
            raise ValidationError("Tool name must be a non-empty string")

        if not isinstance(tool_input, dict):
            raise ValidationError("Tool input must be a mapping")

        for key, value in tool_input.items():
            if isinstance(value, str) and len(value) > self.config.max_string_length:
                raise ValidationError(f"Tool input field '{key}' exceeds max string length")

        if self.config.max_file_size and any(
            isinstance(v, str) and len(v) > self.config.max_file_size for v in tool_input.values()
        ):
            raise ValidationError("Tool input contains a value that exceeds max_file_size")

        if tool_name == "bash":
            if "command" in tool_input:
                tool_input["command"] = self.validate_command(
                    tool_input["command"],
                    allowed_commands=allowed_commands,
                    enforce_allowed_commands=enforce_allowed_commands,
                )

        elif tool_name == "str_replace_based_edit_tool":
            command = tool_input.get("command")
            if not isinstance(command, str):
                raise ValidationError(
                    "Tool input field 'command' for str_replace_based_edit_tool must be a string"
                )
            if command not in {"view", "create", "str_replace", "insert", "undo_edit"}:
                raise ValidationError(
                    f"Invalid edit command: {tool_input['command']}"
                )
            workspace_root = self._get_file_tool_workspace_root()
            if "path" in tool_input:
                tool_input["path"] = self.validate_file_path(
                    tool_input["path"],
                    base_dir=workspace_root,
                )

        elif tool_name == "memory":
            command = tool_input.get("command")
            if not isinstance(command, str):
                raise ValidationError("Tool input field 'command' for memory must be a string")
            if command not in {
                "view",
                "list",
                "search",
                "create",
                "append",
                "replace",
                "update",
                "str_replace",
                "insert",
                "delete",
                "rename",
            }:
                raise ValidationError(f"Invalid memory command: {command}")
            for key in ("path", "old_path", "new_path"):
                if key in tool_input:
                    if not isinstance(tool_input[key], str):
                        raise ValidationError(
                            f"Tool input field '{key}' for memory must be a string path"
                        )
                    self._validate_memory_tool_path(tool_input[key], field=key)
                    tool_input[key] = self.validate_file_path(tool_input[key])

        elif tool_name == "computer":
            if "action" in tool_input:
                action = tool_input["action"]
                if not isinstance(action, str):
                    raise ValidationError("Tool input field 'action' must be a string")

                if allowed_actions is not None:
                    if isinstance(allowed_actions, str):
                        raise ValidationError("allowed_actions must be an iterable of strings")
                    try:
                        allowed_action_set = set(allowed_actions)
                    except TypeError as exc:
                        raise ValidationError(
                            "allowed_actions must be an iterable of strings"
                        ) from exc
                    if not all(
                        isinstance(action_name, str) for action_name in allowed_action_set
                    ):
                        raise ValidationError(
                            "allowed_actions must be an iterable of strings"
                        )
                else:
                    allowed_action_set = COMPUTER_TOOL_ACTIONS
                if action not in allowed_action_set:
                    raise ValidationError(f"Invalid computer action: {tool_input['action']}")

        return tool_input

    @staticmethod
    def _get_file_tool_workspace_root() -> str:
        """Resolve the file-edit workspace root used for path validation."""
        def _normalize_root(raw_root: str) -> str:
            return str(Path(raw_root).expanduser().resolve())

        try:
            from agent.config import get_config
            workspace_env = os.environ.get("WORKSPACE_PATH")
            if workspace_env:
                return _normalize_root(workspace_env)

            agent_data_dir = os.environ.get("AGENT_DATA_DIR")
            if agent_data_dir:
                return _normalize_root(agent_data_dir)

            configured_root = getattr(get_config(), "agent", None)
            if configured_root is not None and getattr(configured_root, "workspace_path", None):
                return _normalize_root(configured_root.workspace_path)
        except Exception:
            pass

        return _normalize_root(
            os.environ.get("WORKSPACE_PATH")
            or os.environ.get("AGENT_DATA_DIR")
            or "/tmp/stateset-workspace"
        )

    @staticmethod
    def _validate_memory_tool_path(path: str, *, field: str) -> None:
        if not (path == "/memories" or path.startswith("/memories/")):
            raise ValidationError(
                f"Tool input field '{field}' for memory must start with /memories"
            )

    def check_prompt_injection(self, text: str) -> ValidationResult:
        """
        Check text for potential prompt injection attempts.

        Args:
            text: Text to check for injection patterns.

        Returns:
            ValidationResult with detection status.
        """
        if not text:
            return ValidationResult(is_valid=True)

        for pattern in self._compiled_injection_patterns:
            match = pattern.search(text)
            if match:
                logger.warning(
                    "Potential prompt injection detected: %s",
                    match.group()[:50]
                )
                return ValidationResult(
                    is_valid=False,
                    severity=ValidationSeverity.CRITICAL,
                    message=f"Potential prompt injection detected",
                    field="text",
                )

        return ValidationResult(is_valid=True)

    def validate_environment_access(self, var_name: str) -> ValidationResult:
        """
        Validate that an environment variable access is safe.

        Args:
            var_name: Name of the environment variable.

        Returns:
            ValidationResult indicating if access is allowed.
        """
        # Check if explicitly allowed
        if var_name in self.config.allowed_env_vars:
            return ValidationResult(is_valid=True)

        # Check blocked prefixes
        for prefix in self.config.blocked_env_prefixes:
            if var_name.startswith(prefix):
                return ValidationResult(
                    is_valid=False,
                    severity=ValidationSeverity.ERROR,
                    message=f"Access to {prefix}* environment variables is blocked",
                    field="env_var",
                )

        return ValidationResult(is_valid=True)

    def sanitize_output(self, output: str, max_length: int = 10000) -> str:
        """
        Sanitize output to prevent sensitive data leakage.

        Args:
            output: Output string to sanitize.
            max_length: Maximum allowed length.

        Returns:
            Sanitized output string.
        """
        if not output:
            return output

        # Truncate if too long
        if len(output) > max_length:
            output = output[:max_length] + "... [truncated]"

        # Redact potential secrets
        secret_patterns = [
            (r'sk-ant-[a-zA-Z0-9-]+', '[REDACTED_API_KEY]'),
            (r'sk_live_[a-zA-Z0-9]+', '[REDACTED_STRIPE_KEY]'),
            (r'sk_test_[a-zA-Z0-9]+', '[REDACTED_STRIPE_KEY]'),
            (r'Bearer\s+[a-zA-Z0-9._-]+', 'Bearer [REDACTED]'),
            (r'password["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'password=[REDACTED]'),
            (r'api[_-]?key["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'api_key=[REDACTED]'),
        ]

        for pattern, replacement in secret_patterns:
            output = re.sub(pattern, replacement, output, flags=re.IGNORECASE)

        return output

    def validate_url(self, url: str) -> ValidationResult:
        """
        Validate a URL for safety.

        Args:
            url: URL to validate.

        Returns:
            ValidationResult with validation status.
        """
        import urllib.parse

        try:
            parsed = urllib.parse.urlparse(url)
        except Exception:
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message="Invalid URL format",
                field="url",
            )

        # Check scheme
        if parsed.scheme not in ("http", "https"):
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message=f"URL scheme must be http or https, got {parsed.scheme}",
                field="url",
            )

        # Check for internal/private networks
        blocked_hosts = [
            "localhost",
            "127.0.0.1",
            "0.0.0.0",
            "169.254.",  # Link-local
            "10.",  # Private
            "172.16.", "172.17.", "172.18.", "172.19.",  # Private
            "172.20.", "172.21.", "172.22.", "172.23.",
            "172.24.", "172.25.", "172.26.", "172.27.",
            "172.28.", "172.29.", "172.30.", "172.31.",
            "192.168.",  # Private
        ]

        host = parsed.hostname or ""
        for blocked in blocked_hosts:
            if host == blocked or host.startswith(blocked):
                return ValidationResult(
                    is_valid=False,
                    severity=ValidationSeverity.CRITICAL,
                    message="Access to internal/private networks is blocked",
                    field="url",
                )

        return ValidationResult(is_valid=True, sanitized_value=url)

    def validate_json_input(self, data: Dict[str, Any], schema: Optional[Dict] = None) -> ValidationResult:
        """
        Validate JSON input data.

        Args:
            data: Dictionary to validate.
            schema: Optional schema for validation.

        Returns:
            ValidationResult with validation status.
        """
        if not isinstance(data, dict):
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message="Input must be a dictionary",
                field="data",
            )

        # Check for nested depth (prevent DoS via deeply nested JSON)
        def check_depth(obj: Any, current_depth: int = 0, max_depth: int = 20) -> bool:
            if current_depth > max_depth:
                return False
            if isinstance(obj, dict):
                return all(check_depth(v, current_depth + 1, max_depth) for v in obj.values())
            if isinstance(obj, list):
                return all(check_depth(v, current_depth + 1, max_depth) for v in obj)
            return True

        if not check_depth(data):
            return ValidationResult(
                is_valid=False,
                severity=ValidationSeverity.ERROR,
                message="JSON nesting depth exceeds maximum allowed",
                field="data",
            )

        return ValidationResult(is_valid=True)


# Global validator instance
_validator: Optional[ToolInputValidator] = None


def get_validator(config: Optional[ValidationConfig] = None) -> ToolInputValidator:
    """
    Get the global validator instance.

    Args:
        config: Optional configuration for the validator.

    Returns:
        ToolInputValidator instance.
    """
    global _validator
    if _validator is None:
        _validator = ToolInputValidator(config)
    return _validator


def validate_tool_input(
    tool_name: str,
    tool_input: Dict[str, Any],
    allowed_commands: Optional[List[str]] = None,
    allowed_actions: Optional[Iterable[str]] = None,
    enforce_allowed_commands: bool = False,
) -> Dict[str, Any]:
    """
    Convenience function to validate tool input.

    Args:
        tool_name: Name of the tool.
        tool_input: Input dictionary for the tool.

    Returns:
        Validated and potentially sanitized input.

    Raises:
        ValidationError: If validation fails.
    """
    return get_validator().validate_tool_input(
        tool_name,
        tool_input,
        allowed_commands=allowed_commands,
        allowed_actions=allowed_actions,
        enforce_allowed_commands=enforce_allowed_commands,
    )
