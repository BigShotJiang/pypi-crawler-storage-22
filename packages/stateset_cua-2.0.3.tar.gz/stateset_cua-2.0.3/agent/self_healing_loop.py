"""
Self-Healing Agent Loop for StateSet Computer Use Agent.

This module provides a robust agent loop with automatic recovery:

1. Stuck Detection & Recovery
   - Pattern-based stuck detection
   - Automatic intervention injection
   - Recovery strategy selection

2. Automatic Checkpointing
   - Progress state persistence
   - Resume from last checkpoint on failure
   - Incremental state saving

3. Error Recovery
   - Automatic retry with backoff
   - Error pattern learning
   - Graceful degradation

4. Health Monitoring
   - Real-time loop health metrics
   - Anomaly detection
   - Proactive intervention

Based on Anthropic's production patterns for 24/7 autonomous operation.
"""

import asyncio
import logging
import time
import json
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import (
    Any, Callable, Coroutine, Dict, List, Optional,
    Set, Tuple, TypeVar
)
from collections import deque
from pathlib import Path

from agent.stuck_detection import StuckDetector, ActionRecord
from agent.checkpoint import (
    CheckpointManager, TaskProgress, ProgressTracker,
    HeartbeatMonitor
)
from agent.adaptive_context import (
    AdaptiveContextManager, AttentionQuality,
    get_adaptive_context_manager
)
from agent.resilience_engine import (
    ResilienceEngine, get_resilience_engine,
    TaskState, TaskMetadata
)
from agent.task_completion import analyze_task_completion_sync
from agent.logging_config import get_logger

logger = get_logger(__name__)

T = TypeVar('T')


class LoopState(Enum):
    """Agent loop states"""
    INITIALIZING = "initializing"
    RUNNING = "running"
    STUCK = "stuck"
    RECOVERING = "recovering"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


class RecoveryStrategy(Enum):
    """Strategies for recovering from stuck states"""
    RETRY = "retry"              # Simple retry
    ALTERNATIVE = "alternative"  # Try different approach
    CONTEXT_CLEAR = "context_clear"  # Clear context and restart
    SUBAGENT = "subagent"        # Delegate to subagent
    HUMAN_ESCALATE = "human"     # Escalate to human
    RESTART = "restart"          # Full restart


@dataclass
class LoopMetrics:
    """Metrics for loop health monitoring"""
    iterations: int = 0
    successful_iterations: int = 0
    failed_iterations: int = 0
    stuck_detections: int = 0
    recoveries_attempted: int = 0
    recoveries_successful: int = 0
    checkpoints_saved: int = 0
    total_duration_seconds: float = 0.0
    avg_iteration_seconds: float = 0.0
    last_iteration_time: Optional[datetime] = None

    # Health indicators
    consecutive_successes: int = 0
    consecutive_failures: int = 0
    health_score: float = 1.0

    def record_iteration(self, success: bool, duration: float):
        """Record iteration result"""
        self.iterations += 1
        self.total_duration_seconds += duration
        self.avg_iteration_seconds = self.total_duration_seconds / self.iterations
        self.last_iteration_time = datetime.utcnow()

        if success:
            self.successful_iterations += 1
            self.consecutive_successes += 1
            self.consecutive_failures = 0
        else:
            self.failed_iterations += 1
            self.consecutive_failures += 1
            self.consecutive_successes = 0

        # Update health score
        self._update_health_score()

    def _update_health_score(self):
        """Calculate health score (0.0 - 1.0)"""
        if self.iterations == 0:
            self.health_score = 1.0
            return

        success_rate = self.successful_iterations / self.iterations
        failure_penalty = min(self.consecutive_failures * 0.1, 0.5)
        stuck_penalty = min(self.stuck_detections * 0.05, 0.3)

        self.health_score = max(0.0, success_rate - failure_penalty - stuck_penalty)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'iterations': self.iterations,
            'successful': self.successful_iterations,
            'failed': self.failed_iterations,
            'stuck_detections': self.stuck_detections,
            'recoveries_attempted': self.recoveries_attempted,
            'recoveries_successful': self.recoveries_successful,
            'checkpoints_saved': self.checkpoints_saved,
            'total_duration_seconds': self.total_duration_seconds,
            'avg_iteration_seconds': round(self.avg_iteration_seconds, 2),
            'health_score': round(self.health_score, 3),
            'consecutive_successes': self.consecutive_successes,
            'consecutive_failures': self.consecutive_failures
        }


@dataclass
class LoopCheckpoint:
    """Checkpoint for loop state"""
    task_id: str
    agent_type: str
    iteration: int
    messages: List[Dict[str, Any]]
    context_state: Dict[str, Any]
    metrics: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'agent_type': self.agent_type,
            'iteration': self.iteration,
            'messages': self.messages,
            'context_state': self.context_state,
            'metrics': self.metrics,
            'timestamp': self.timestamp.isoformat()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LoopCheckpoint':
        return cls(
            task_id=data['task_id'],
            agent_type=data['agent_type'],
            iteration=data['iteration'],
            messages=data['messages'],
            context_state=data.get('context_state', {}),
            metrics=data.get('metrics', {}),
            timestamp=datetime.fromisoformat(data['timestamp'])
        )


class RecoveryManager:
    """Manage recovery strategies for stuck/failed states"""

    def __init__(self, agent_type: str):
        self.agent_type = agent_type
        self._recovery_history: deque = deque(maxlen=50)
        self._strategy_success_rates: Dict[RecoveryStrategy, Tuple[int, int]] = {
            strategy: (0, 0) for strategy in RecoveryStrategy
        }

    def select_strategy(
        self,
        stuck_type: str,
        consecutive_failures: int,
        context_quality: AttentionQuality
    ) -> RecoveryStrategy:
        """Select best recovery strategy based on situation"""

        # Critical context - must clear
        if context_quality in (AttentionQuality.CRITICAL, AttentionQuality.WARNING):
            return RecoveryStrategy.CONTEXT_CLEAR

        # Many consecutive failures - escalate
        if consecutive_failures >= 5:
            return RecoveryStrategy.HUMAN_ESCALATE

        # Based on stuck type
        strategies_by_type = {
            'repeat': RecoveryStrategy.ALTERNATIVE,
            'no_visual': RecoveryStrategy.RETRY,
            'cycle': RecoveryStrategy.SUBAGENT,
            'slow': RecoveryStrategy.ALTERNATIVE
        }

        suggested = strategies_by_type.get(stuck_type, RecoveryStrategy.RETRY)

        # Check if suggested strategy has been failing
        success, total = self._strategy_success_rates[suggested]
        if total > 3 and success / total < 0.3:
            # Try a different strategy
            alternatives = [s for s in RecoveryStrategy
                          if s != suggested and s != RecoveryStrategy.HUMAN_ESCALATE]
            if alternatives:
                return alternatives[0]

        return suggested

    def get_recovery_prompt(
        self,
        strategy: RecoveryStrategy,
        stuck_reason: str
    ) -> str:
        """Generate recovery prompt for the agent"""

        base_prompt = f"""
<RECOVERY_INTERVENTION>
The system detected you may be stuck: {stuck_reason}

"""

        strategies = {
            RecoveryStrategy.RETRY: """
Recovery Strategy: RETRY
- Take a fresh screenshot to assess current state
- Try the same action again, but more carefully
- If it fails again, consider a different approach
""",
            RecoveryStrategy.ALTERNATIVE: """
Recovery Strategy: ALTERNATIVE APPROACH
- STOP what you're currently doing
- Consider a completely different method to achieve the goal
- If using GUI, try bash commands instead (or vice versa)
- Look for keyboard shortcuts or alternative paths
""",
            RecoveryStrategy.CONTEXT_CLEAR: """
Recovery Strategy: CONTEXT OPTIMIZATION
- Your context window is full, affecting performance
- Summarize key findings to memory using memory tool
- Complete current action, then we'll clear old context
- Be very concise in responses
""",
            RecoveryStrategy.SUBAGENT: """
Recovery Strategy: TASK DECOMPOSITION
- Break this task into smaller sub-tasks
- Focus on completing one small step at a time
- Verify each step before moving to the next
""",
            RecoveryStrategy.RESTART: """
Recovery Strategy: FRESH START
- Save any important progress to memory
- We will restart from the beginning
- Focus on the core objective only
""",
            RecoveryStrategy.HUMAN_ESCALATE: """
Recovery Strategy: HUMAN ASSISTANCE NEEDED
- Multiple recovery attempts have failed
- Please wait for human intervention
- Document what you've tried in memory
"""
        }

        return base_prompt + strategies.get(strategy, strategies[RecoveryStrategy.RETRY]) + "\n</RECOVERY_INTERVENTION>"

    def record_recovery_result(self, strategy: RecoveryStrategy, success: bool):
        """Record recovery attempt result"""
        current = self._strategy_success_rates[strategy]
        self._strategy_success_rates[strategy] = (
            current[0] + (1 if success else 0),
            current[1] + 1
        )

        self._recovery_history.append({
            'strategy': strategy.value,
            'success': success,
            'timestamp': datetime.utcnow().isoformat()
        })


class SelfHealingLoop:
    """
    Self-healing agent loop with automatic recovery.

    Features:
    - Stuck detection and automatic intervention
    - Checkpoint-based recovery
    - Adaptive context management
    - Health monitoring and metrics
    """

    def __init__(
        self,
        task_id: str,
        agent_type: str,
        agent_id: str,
        checkpoint_dir: Optional[str] = None,
        max_iterations: int = 1000,
        stuck_threshold: int = 3,
        checkpoint_interval: int = 10,  # Every N iterations
        enable_auto_recovery: bool = True
    ):
        self.task_id = task_id
        self.agent_type = agent_type
        self.agent_id = agent_id
        self.max_iterations = max_iterations
        self.stuck_threshold = stuck_threshold
        self.checkpoint_interval = checkpoint_interval
        self.enable_auto_recovery = enable_auto_recovery

        # State
        self.state = LoopState.INITIALIZING
        self.current_iteration = 0

        # Components
        self.stuck_detector = StuckDetector(
            window_size=10,
            stuck_threshold=stuck_threshold
        )
        self.recovery_manager = RecoveryManager(agent_type)
        self.context_manager = get_adaptive_context_manager(agent_id)
        self.metrics = LoopMetrics()

        # Checkpoint management
        self.checkpoint_dir = Path(checkpoint_dir or f"/tmp/agent_checkpoints/{agent_type}")
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self._last_checkpoint: Optional[LoopCheckpoint] = None

        # Recovery state
        self._recovery_in_progress = False
        self._pending_intervention: Optional[str] = None

        # Message history for checkpointing
        self._message_snapshot: List[Dict[str, Any]] = []

    async def initialize(self) -> bool:
        """Initialize the loop, potentially resuming from checkpoint"""
        logger.info(f"Initializing self-healing loop for task '{self.task_id}'")

        # Try to load existing checkpoint
        checkpoint = await self._load_checkpoint()

        if checkpoint:
            logger.info(
                f"Resuming from checkpoint: iteration {checkpoint.iteration}, "
                f"messages: {len(checkpoint.messages)}"
            )
            self.current_iteration = checkpoint.iteration
            self._message_snapshot = checkpoint.messages
            self.metrics = LoopMetrics(**checkpoint.metrics) if checkpoint.metrics else LoopMetrics()
            self.state = LoopState.RUNNING
            return True

        # Fresh start
        self.state = LoopState.RUNNING
        return False

    async def run_iteration(
        self,
        iteration_func: Callable[..., Coroutine[Any, Any, Any]],
        messages: List[Dict[str, Any]],
        **kwargs
    ) -> Tuple[Any, List[Dict[str, Any]], bool]:
        """
        Run a single loop iteration with self-healing.

        Returns:
            (result, updated_messages, should_continue)
        """
        self.current_iteration += 1
        iteration_start = time.time()

        # Check for pending intervention
        if self._pending_intervention:
            # Inject intervention into messages
            messages = self._inject_intervention(messages)
            self._pending_intervention = None

        try:
            # Pre-iteration checks
            await self._pre_iteration_checks()

            # Execute iteration
            result = await iteration_func(messages=messages, **kwargs)

            # Post-iteration processing
            duration = time.time() - iteration_start
            self.metrics.record_iteration(success=True, duration=duration)

            # Update message snapshot for checkpointing
            self._message_snapshot = messages.copy()

            # Record action for stuck detection
            self._record_action(result)

            # Periodic checkpoint
            if self.current_iteration % self.checkpoint_interval == 0:
                await self._save_checkpoint()

            # Check if we should continue
            should_continue = self._should_continue(result)

            return result, messages, should_continue

        except Exception as e:
            duration = time.time() - iteration_start
            self.metrics.record_iteration(success=False, duration=duration)

            logger.error(f"Iteration {self.current_iteration} failed: {e}")

            if self.enable_auto_recovery:
                recovered = await self._attempt_recovery(str(e))
                if recovered:
                    # Return signal to retry
                    return None, messages, True

            raise

    async def _pre_iteration_checks(self):
        """Perform pre-iteration health checks"""

        # Check for stuck state
        is_stuck, reason, suggestion = self.stuck_detector.check_if_stuck()

        if is_stuck and self.stuck_detector.should_intervene():
            logger.warning(f"Stuck detected: {reason}")
            self.metrics.stuck_detections += 1
            self.state = LoopState.STUCK

            if self.enable_auto_recovery:
                await self._handle_stuck(reason, suggestion)

        # Check context health
        context_quality = self.context_manager.get_attention_quality()
        if context_quality in (AttentionQuality.CRITICAL, AttentionQuality.WARNING):
            logger.warning(f"Context quality degraded: {context_quality.value}")

            # Trigger context compression
            if self._message_snapshot:
                compressed = await self.context_manager.compress_messages(
                    self._message_snapshot,
                    force=True
                )
                self._message_snapshot = compressed

        # Check iteration limit
        if self.current_iteration >= self.max_iterations:
            logger.warning(f"Approaching max iterations ({self.max_iterations})")

    async def _handle_stuck(self, reason: str, suggestion: str):
        """Handle stuck state with recovery"""
        self.metrics.recoveries_attempted += 1

        # Select recovery strategy
        strategy = self.recovery_manager.select_strategy(
            stuck_type=reason.split(':')[0].lower() if ':' in reason else 'unknown',
            consecutive_failures=self.metrics.consecutive_failures,
            context_quality=self.context_manager.get_attention_quality()
        )

        logger.info(f"Selected recovery strategy: {strategy.value}")

        # Generate intervention
        self._pending_intervention = self.recovery_manager.get_recovery_prompt(
            strategy, reason
        )

        # Execute strategy-specific actions
        if strategy == RecoveryStrategy.CONTEXT_CLEAR:
            # Force context compression
            if self._message_snapshot:
                compressed = await self.context_manager.compress_messages(
                    self._message_snapshot,
                    force=True
                )
                self._message_snapshot = compressed

        elif strategy == RecoveryStrategy.RESTART:
            # Save checkpoint before restart
            await self._save_checkpoint()
            self.current_iteration = 0
            self._message_snapshot = []

        self.state = LoopState.RECOVERING

    async def _attempt_recovery(self, error: str) -> bool:
        """Attempt to recover from an error"""
        logger.info(f"Attempting recovery from error: {error}")
        self.metrics.recoveries_attempted += 1

        # Check for recoverable error patterns
        recoverable_patterns = [
            'timeout', 'rate limit', 'connection', 'network',
            'temporary', 'retry', '429', '503', '504'
        ]

        is_recoverable = any(p in error.lower() for p in recoverable_patterns)

        if is_recoverable:
            # Wait and retry
            await asyncio.sleep(5.0)
            self.metrics.recoveries_successful += 1
            self.state = LoopState.RUNNING
            return True

        # Try loading from checkpoint
        if self._last_checkpoint:
            logger.info("Attempting to restore from checkpoint")
            self.current_iteration = self._last_checkpoint.iteration
            self._message_snapshot = self._last_checkpoint.messages
            self.state = LoopState.RUNNING
            self.metrics.recoveries_successful += 1
            return True

        return False

    def _inject_intervention(
        self,
        messages: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Inject intervention message"""
        if not self._pending_intervention:
            return messages

        intervention_message = {
            'role': 'user',
            'content': [
                {'type': 'text', 'text': self._pending_intervention}
            ]
        }

        return messages + [intervention_message]

    def _record_action(self, result: Any):
        """Record action for stuck detection"""
        # Extract action details from result
        action_details = ""
        tool_name = "unknown"

        if isinstance(result, dict):
            tool_name = result.get('tool_name', 'unknown')
            action_details = json.dumps(result.get('input', {}))[:100]
        elif hasattr(result, 'output'):
            action_details = str(result.output)[:100]

        self.stuck_detector.record_action(
            tool_name=tool_name,
            action_details=action_details
        )

    def _should_continue(self, result: Any) -> bool:
        """Determine if loop should continue"""
        if result is not None and hasattr(result, "messages"):
            completion = analyze_task_completion_sync(
                messages=getattr(result, "messages"),
                agent_type=self.agent_type
            )
            if completion.completed:
                logger.info(
                    f"Task marked complete for loop '{self.task_id}': {completion.details}"
                )
                return False

        # Check iteration limit
        if self.current_iteration >= self.max_iterations:
            logger.info("Reached max iterations")
            return False

        # Check health score
        if self.metrics.health_score < 0.1:
            logger.warning("Health score critically low")
            return False

        # Check for explicit stop signals
        if isinstance(result, dict):
            if result.get('should_stop', False):
                return False
            if result.get('task_complete', False):
                return False

        return True

    async def _save_checkpoint(self):
        """Save current state checkpoint"""
        checkpoint = LoopCheckpoint(
            task_id=self.task_id,
            agent_type=self.agent_type,
            iteration=self.current_iteration,
            messages=self._message_snapshot,
            context_state=self.context_manager.get_status(),
            metrics=self.metrics.to_dict()
        )

        checkpoint_path = self.checkpoint_dir / f"{self.task_id}.json"

        try:
            checkpoint_path.write_text(json.dumps(checkpoint.to_dict(), indent=2))
            self._last_checkpoint = checkpoint
            self.metrics.checkpoints_saved += 1
            logger.debug(f"Saved checkpoint at iteration {self.current_iteration}")
        except Exception as e:
            logger.error(f"Failed to save checkpoint: {e}")

    async def _load_checkpoint(self) -> Optional[LoopCheckpoint]:
        """Load checkpoint if exists"""
        checkpoint_path = self.checkpoint_dir / f"{self.task_id}.json"

        if not checkpoint_path.exists():
            return None

        try:
            data = json.loads(checkpoint_path.read_text())
            return LoopCheckpoint.from_dict(data)
        except Exception as e:
            logger.warning(f"Failed to load checkpoint: {e}")
            return None

    async def cleanup(self):
        """Cleanup after loop completion"""
        # Save final checkpoint
        await self._save_checkpoint()

        # Log final metrics
        logger.info(
            f"Loop completed: {self.metrics.iterations} iterations, "
            f"health score: {self.metrics.health_score:.2f}"
        )

        self.state = LoopState.STOPPED

    def get_status(self) -> Dict[str, Any]:
        """Get loop status"""
        return {
            'task_id': self.task_id,
            'agent_type': self.agent_type,
            'state': self.state.value,
            'current_iteration': self.current_iteration,
            'max_iterations': self.max_iterations,
            'metrics': self.metrics.to_dict(),
            'context_quality': self.context_manager.get_attention_quality().value,
            'stuck_detector': self.stuck_detector.get_statistics(),
            'has_checkpoint': self._last_checkpoint is not None
        }


class SelfHealingLoopFactory:
    """Factory for creating self-healing loops"""

    _instances: Dict[str, SelfHealingLoop] = {}

    @classmethod
    def create(
        cls,
        task_id: str,
        agent_type: str,
        agent_id: str,
        **kwargs
    ) -> SelfHealingLoop:
        """Create or get existing self-healing loop"""
        key = f"{agent_type}:{task_id}"

        if key not in cls._instances:
            cls._instances[key] = SelfHealingLoop(
                task_id=task_id,
                agent_type=agent_type,
                agent_id=agent_id,
                **kwargs
            )

        return cls._instances[key]

    @classmethod
    def get(cls, task_id: str, agent_type: str) -> Optional[SelfHealingLoop]:
        """Get existing loop"""
        key = f"{agent_type}:{task_id}"
        return cls._instances.get(key)

    @classmethod
    async def cleanup(cls, task_id: str, agent_type: str):
        """Cleanup a loop"""
        key = f"{agent_type}:{task_id}"
        if key in cls._instances:
            await cls._instances[key].cleanup()
            del cls._instances[key]

    @classmethod
    async def cleanup_all(cls):
        """Cleanup all loops"""
        for loop in cls._instances.values():
            await loop.cleanup()
        cls._instances.clear()


# Convenience functions
def get_self_healing_loop(
    task_id: str,
    agent_type: str,
    agent_id: str,
    **kwargs
) -> SelfHealingLoop:
    """Get or create self-healing loop"""
    return SelfHealingLoopFactory.create(
        task_id=task_id,
        agent_type=agent_type,
        agent_id=agent_id,
        **kwargs
    )


async def run_with_self_healing(
    task_id: str,
    agent_type: str,
    agent_id: str,
    iteration_func: Callable[..., Coroutine[Any, Any, Any]],
    initial_messages: Optional[List[Dict[str, Any]]] = None,
    max_iterations: int = 1000,
    **kwargs
) -> Tuple[Any, LoopMetrics]:
    """
    Convenience function to run a task with self-healing loop.

    Returns:
        (final_result, metrics)
    """
    loop = get_self_healing_loop(
        task_id=task_id,
        agent_type=agent_type,
        agent_id=agent_id,
        max_iterations=max_iterations
    )

    await loop.initialize()

    messages = initial_messages or []
    result = None

    try:
        while loop.state in (LoopState.RUNNING, LoopState.RECOVERING):
            result, messages, should_continue = await loop.run_iteration(
                iteration_func=iteration_func,
                messages=messages,
                **kwargs
            )

            if not should_continue:
                break

        return result, loop.metrics

    finally:
        await loop.cleanup()
