"""
Global state management and shutdown coordination.

Extracted from main.py. Provides thread-safe async state for the multi-agent
system including task tracking and graceful shutdown.

Note: ``main.py`` defines its own ``cancel_all_tasks``, ``shutdown``, and
``signal_handler`` wrappers that resolve the ``state`` variable through the
``main`` module namespace so that tests can monkey-patch ``main.state``.
The versions here use the module-level ``state`` directly and are suitable
for standalone use or from code that patches ``agent.state.state``.
"""

import asyncio
import sys
from contextlib import suppress
from typing import Set

from agent.logging_config import get_logger

logger = get_logger(__name__)


class GlobalState:
    def __init__(self):
        self.running = True
        self.tasks: Set[asyncio.Task] = set()
        self.shutdown_event = asyncio.Event()
        self._lock = asyncio.Lock()
        self._shutdown_started = False

    async def start_shutdown(self) -> bool:
        async with self._lock:
            if self._shutdown_started:
                return False
            self._shutdown_started = True
            self.running = False
            self.shutdown_event.set()
            return True

    @property
    def is_shutting_down(self) -> bool:
        # Property access for shutdown state (no lock needed for reads)
        return self._shutdown_started

    async def add_task(self, task: asyncio.Task):
        async with self._lock:
            if not self._shutdown_started:
                self.tasks.add(task)

    async def remove_task(self, task: asyncio.Task):
        async with self._lock:
            self.tasks.discard(task)

    async def get_all_tasks(self) -> Set[asyncio.Task]:
        async with self._lock:
            return self.tasks.copy()


# Module-level singleton
state = GlobalState()


async def cancel_all_tasks():
    """Cancel all running tasks"""
    tasks = await state.get_all_tasks()
    if not tasks:
        return

    logger.info(f"Cancelling {len(tasks)} running tasks...",
                extra={'agent_type': 'system'})

    running_tasks = [task for task in tasks if not task.done()]
    for task in running_tasks:
        task.cancel()

    try:
        await asyncio.wait_for(
            asyncio.gather(*running_tasks, return_exceptions=True),
            timeout=10.0,
        )
    except asyncio.TimeoutError:
        logger.warning(
            "Task cancellation timed out after 10s, forcing cleanup",
            extra={'agent_type': 'system'},
        )

        for task in running_tasks:
            if task.done():
                continue
            task.cancel()

        with suppress(asyncio.TimeoutError):
            await asyncio.wait_for(
                asyncio.gather(*running_tasks, return_exceptions=True),
                timeout=2.0,
            )

        lingering = [task for task in running_tasks if not task.done()]
        if lingering:
            logger.error(
                "Some tasks did not terminate after forced shutdown",
                extra={'agent_type': 'system', 'pending_tasks': len(lingering)},
            )

    for task in tasks:
        await state.remove_task(task)


async def shutdown():
    """Graceful shutdown sequence"""
    if not await state.start_shutdown():
        # Another shutdown already in progress
        return

    logger.info("Initiating shutdown sequence...", extra={'agent_type': 'system'})

    try:
        await cancel_all_tasks()
        logger.info("All tasks cancelled successfully", extra={'agent_type': 'system'})
    except Exception as e:
        logger.error(f"Error during shutdown: {str(e)}", extra={'agent_type': 'system'})
    finally:
        try:
            loop = asyncio.get_running_loop()
            should_stop = loop.is_running()
        except RuntimeError:
            loop = asyncio.get_event_loop_policy().get_event_loop()
            should_stop = getattr(loop, "is_running", lambda: False)()

        if should_stop:
            try:
                # Stop accepting new tasks
                loop.stop()
            except Exception as e:
                logger.error(
                    f"Error stopping event loop: {str(e)}",
                    extra={'agent_type': 'system'},
                )


def _schedule_shutdown_or_exit(shutdown_coro) -> None:
    """Run shutdown via the active loop when available, otherwise perform best-effort."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            logger.error(
                "No event loop available for shutdown callback",
                extra={"agent_type": "system"},
            )
            try:
                asyncio.run(shutdown_coro)
            except RuntimeError as exc:
                logger.error(
                    f"Could not execute fallback shutdown: {exc}",
                    extra={"agent_type": "system"},
                )
            return

    if getattr(loop, "is_running", lambda: False)():
        try:
            loop.create_task(shutdown_coro)
        except RuntimeError as exc:
            logger.error(
                f"Could not schedule shutdown on running loop: {exc}",
                extra={"agent_type": "system"},
            )
            try:
                asyncio.run(shutdown_coro)
            except RuntimeError as second_exc:
                logger.error(
                    f"Fallback shutdown execution failed: {second_exc}",
                    extra={"agent_type": "system"},
                )
        return

    try:
        loop.run_until_complete(shutdown_coro)
    except RuntimeError as exc:
        logger.error(
            f"Could not run synchronous shutdown: {exc}",
            extra={"agent_type": "system"},
        )
        try:
            asyncio.run(shutdown_coro)
        except RuntimeError as second_exc:
            logger.error(
                f"Fallback shutdown execution failed: {second_exc}",
                extra={"agent_type": "system"},
            )


def signal_handler(sig, frame):
    """Handle interrupt signals"""
    if state.is_shutting_down:
        logger.info("Forced shutdown...", extra={'agent_type': 'system'})
        sys.exit(1)

    _schedule_shutdown_or_exit(shutdown())
