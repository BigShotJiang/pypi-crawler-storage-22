"""
Task completion analysis for agent workflows.

Extracted from main.py. Analyses message history to determine whether an
agent task has been completed successfully.
"""

from anthropic.types.beta import BetaMessageParam
import json
import re
from typing import Any

from agent.logging_config import get_logger
from agent.types import TaskStatus

logger = get_logger(__name__)

COMPLETION_INDICATORS: dict[str, list[str]] = {
    "AUTO_CLOSE": [
        "ticket closed", "successfully closed", "marked as resolved",
        "completed the task", "task finished", "ticket resolved",
        "closure complete", "all tickets closed"
    ],
    "SOCIAL_MEDIA": [
        "comment hidden", "content removed", "content has been removed",
        "moderation complete", "post hidden", "comment deleted",
        "content moderated", "task completed", "moderation finished"
    ],
    "LINKEDIN_MESSENGER": [
        "message sent", "connection request sent", "invite sent",
        "linkedin message delivered", "outreach complete",
        "messages sent successfully", "task completed"
    ],
    "SLACK_SUPPORT": [
        "response sent", "message sent", "replied to customer",
        "support ticket updated", "customer inquiry handled",
        "slack message delivered", "task completed"
    ],
    "SHOPIFY": [
        "product updated", "inventory changed", "order processed",
        "store updated", "changes saved", "shopify task complete",
        "task finished", "update successful"
    ],
    "ONBOARDING": [
        "user created", "setup complete", "onboarding finished",
        "user onboarded", "configuration complete", "setup successful",
        "onboarding task complete"
    ],
    "STATESET_AGENTIC": [
        "task completed", "task finished", "successfully completed",
        "completed successfully", "workflow completed"
    ]
}

AGENT_TOOL_COMPLETION_OVERRIDES: dict[str, set[str]] = {
    "AUTO_CLOSE": {"close", "resolve"},
    "SOCIAL_MEDIA": {"hide", "remove", "delete", "moderate", "comment", "content"},
    "LINKEDIN_MESSENGER": {"send", "invite", "connection"},
    "SLACK_SUPPORT": {"send", "reply", "message"},
    "SHOPIFY": {"update", "process", "submit", "product", "order"},
    "ONBOARDING": {"setup", "onboard", "create", "send", "user"},
    "STATESET_AGENTIC": {"finish", "complete", "done", "submit", "task"},
}

COMPLETION_STATUS_TOKENS = {
    "done", "completed", "complete", "finished", "success", "successful",
    "sent", "send", "resolved", "resolve", "closed", "close", "hidden",
    "removed", "archived", "created", "updated", "installed", "applied",
}

COMPLETION_VALUE_KEYS = {
    "command",
    "action",
    "status",
    "result",
    "event",
    "outcome",
    "operation",
    "summary",
    "success",
    "ok",
    "completed"
}

TOOL_COMPLETION_ACTIONS = {
    "close", "close_ticket", "resolved", "resolve",
    "submit", "submitted", "send", "sent",
    "applied", "installed", "archived", "removed", "hidden"
}

COMPLETION_SUCCESS_FLAGS = {"success", "ok", "completed", "done", "true", "1"}

KNOWN_AGENT_TYPES = frozenset(
    set(COMPLETION_INDICATORS) | set(AGENT_TOOL_COMPLETION_OVERRIDES)
)

TOOL_COMPLETION_VERBS = {
    "done", "complete", "completed", "finished", "finish", "submit", "send",
    "close", "resolved", "resolve", "hidden", "remove", "delete", "archive",
    "created", "updated", "applied"
}

NEGATIVE_COMPLETION_PATTERNS = {
    "failed", "failure", "error", "denied", "rejected", "blocked",
    "timed out", "timeout", "not completed", "not complete",
    "couldn't", "could not", "unable", "unsuccessful", "incomplete",
}

NEGATION_COMPLETION_CONTEXT = {"not", "no", "can't", "cannot", "unable", "failed"}


def analyze_task_completion_sync(messages: list[BetaMessageParam], agent_type: str) -> TaskStatus:
    """Synchronous implementation used by loop/scheduler hot-paths."""
    try:
        normalized_agent_type = str(agent_type).strip().upper() if agent_type is not None else ""
        indicators = COMPLETION_INDICATORS.get(normalized_agent_type, [])
        display_agent_type = normalized_agent_type or "UNKNOWN"
        latest_assistant_text: str | None = None

        # Check recent messages for completion indicators
        recent_messages = list(reversed(messages[-10:]))  # Check last 10 messages

        for message in recent_messages:
            role = str(message.get("role", "")).strip().lower()
            content = message.get("content", [])
            if not isinstance(content, list):
                continue

            for block in content:
                # Check tool usage for completion patterns
                if block.get("type") == "tool_use":
                    tool_name = block.get("name", "")
                    tool_input = block.get("input", {})
                    if _tool_use_indicates_completion(
                        tool_name, tool_input, indicators, normalized_agent_type
                    ):
                        return TaskStatus(
                            completed=True,
                            tokens_used=0,
                            details=f"{display_agent_type}: Completion action detected in tool usage"
                        )

                # Check tool result blocks for explicit completion signals.
                if block.get("type") == "tool_result":
                    if _tool_result_indicates_completion(
                        block, indicators, normalized_agent_type
                    ):
                        return TaskStatus(
                            completed=True,
                            tokens_used=0,
                            details=f"{display_agent_type}: Completion action detected in tool result"
                        )

                # Check text responses for completion indicators
                elif block.get("type") == "text":
                    text = block.get("text")
                    if isinstance(text, str):
                        text_lower = text.lower()
                        if _contains_negated_completion_signal(text_lower):
                            continue
                        if role == "assistant":
                            latest_assistant_text = text_lower

                        # Check against agent-specific indicators
                        for indicator in indicators:
                            if _contains_whole_word(text_lower, indicator):
                                return TaskStatus(
                                    completed=True,
                                    tokens_used=0,
                                    details=f"{display_agent_type}: Found completion indicator '{indicator}'"
                                )

        if latest_assistant_text and _contains_whole_word(
            latest_assistant_text,
            "task completed",
        ):
            return TaskStatus(
                completed=True,
                tokens_used=0,
                details=f"{display_agent_type}: Assistant text indicates completion"
            )

        # Check for stuck/looping behavior (repeated actions)
        if len(messages) >= 8:
            recent_actions = []
            for msg in messages[-8:]:
                content = msg.get("content", [])
                if isinstance(content, list):
                    for block in content:
                        if block.get("type") == "tool_use":
                            action = f"{block.get('name')}:{str(block.get('input', {}))[:50]}"
                            recent_actions.append(action)

            # If same action repeated 4+ times, likely stuck
            if recent_actions:
                action_counts = {}
                for action in recent_actions[-6:]:
                    action_counts[action] = action_counts.get(action, 0) + 1

                if any(count >= 4 for count in action_counts.values()):
                    return TaskStatus(
                        completed=False,
                        tokens_used=0,
                        details=f"{display_agent_type}: Agent appears stuck in loop"
                    )

        return TaskStatus(
            completed=False,
            tokens_used=0,
            details=f"{display_agent_type}: No completion indicators found"
        )

    except Exception as e:
        logger.error(f"Error analyzing task completion: {str(e)}",
                    extra={'agent_type': agent_type})
        return TaskStatus(
            completed=False,
            tokens_used=0,
            details=f"Error analyzing completion: {str(e)}"
        )


async def analyze_task_completion(messages: list[BetaMessageParam], agent_type: str) -> TaskStatus:
    """Backward-compatible async wrapper for the synchronous analyzer."""
    return analyze_task_completion_sync(messages, agent_type)


def _tool_use_indicates_completion(
    tool_name: str, tool_input, indicators: list[str], agent_type: str
) -> bool:
    """Return True only for high-confidence completion signals from tool inputs."""
    if not isinstance(tool_name, str) or not isinstance(tool_input, dict):
        return False
    return _payload_completion_signal(
        payload=tool_input,
        indicators=indicators,
        agent_type=agent_type,
        tool_name=tool_name,
    )


def _tool_result_indicates_completion(
    tool_result: dict[str, Any], indicators: list[str], agent_type: str
) -> bool:
    """Return True when tool result payload indicates successful completion."""
    if not isinstance(tool_result, dict):
        return False
    if tool_result.get("is_error"):
        return False

    content = tool_result.get("content")
    if content is None:
        return False

    if isinstance(content, str):
        normalized_content = content.lower()
        if _contains_negated_completion_signal(normalized_content):
            return False
        return any(
            _contains_whole_word(normalized_content, indicator)
            for indicator in indicators
        )

    if _payload_completion_signal(
        payload=content,
        indicators=indicators,
        agent_type=agent_type,
    ):
        return True

    if isinstance(content, list):
        for item in content:
            if not isinstance(item, dict):
                continue
            item_text = item.get("text")
            if isinstance(item_text, str):
                if _contains_negated_completion_signal(item_text.lower()):
                    continue
                if any(
                    _contains_whole_word(item_text.lower(), indicator)
                    for indicator in indicators
                ):
                    return True

    return False


def _payload_completion_signal(
    payload: Any,
    indicators: list[str],
    agent_type: str,
    tool_name: str | None = None,
) -> bool:
    if payload is None:
        return False

    raw_input = str(payload).lower()
    try:
        normalized_input = json.dumps(payload, sort_keys=True).lower()
    except Exception:
        normalized_input = raw_input

    if tool_name:
        combined = f"{tool_name} {raw_input} {normalized_input}"
    else:
        combined = f"{raw_input} {normalized_input}"

    # Extra safety: require completion-oriented signals in known action-bearing fields.
    completion_values = list(_iter_completion_values(payload, COMPLETION_VALUE_KEYS))
    candidate_texts = []
    failure_signal_seen = False
    failure_from_boolean = False

    for _, value in completion_values:
        if isinstance(value, bool):
            if value:
                return True
            failure_from_boolean = True
            continue
        if isinstance(value, (str, int)):
            value_text = str(value).lower()
            if _contains_negated_completion_signal(value_text):
                failure_signal_seen = True
                continue
            if value_text in COMPLETION_SUCCESS_FLAGS:
                return True
            candidate_texts.append(value_text)

    if not candidate_texts and (failure_signal_seen or failure_from_boolean):
        return False

    # If the tool name strongly indicates completion, accept it only when there
    # is no visible error signal and no explicit failure signal in the payload.
    if (
        tool_name is not None
        and agent_type in KNOWN_AGENT_TYPES
        and _tool_name_indicates_completion(tool_name, agent_type)
        and not completion_values
    ):
        if (
            _contains_negated_completion_signal(normalized_input)
            or failure_signal_seen
            or failure_from_boolean
        ):
            return False
        return True

    combined_values = " ".join(candidate_texts)
    for action in TOOL_COMPLETION_ACTIONS:
        if _contains_whole_word(combined_values, action):
            return True

    for value in candidate_texts:
        if _contains_any_action_token(value, COMPLETION_STATUS_TOKENS):
            return True

    if isinstance(payload, dict) and any(
        payload.get(key) in (True, "true", "True", "1", 1)
        for key in ("success", "ok", "completed")
    ):
        return True

    # Also allow agent-defined completion phrases in tool metadata.
    for indicator in indicators:
        if indicator and _contains_whole_word(combined, indicator):
            return True

    return False


def _contains_whole_word(text: str, term: str) -> bool:
    """Case-insensitive whole-word matching to avoid substring false positives."""
    return bool(re.search(rf"(?<![\\w-]){re.escape(term)}(?![\\w-])", text))


def _contains_any_action_token(text: str, tokens: set[str]) -> bool:
    """Check for any completion-style token anywhere in structured text fields."""
    normalized = re.sub(r"[^a-z0-9]+", " ", text.lower())
    return any(token in normalized.split() for token in tokens)


def _contains_negated_completion_signal(text: str) -> bool:
    normalized = re.sub(r"[^a-z0-9']+", " ", text.lower())
    if not normalized:
        return False

    words = normalized.split()
    for pattern in NEGATIVE_COMPLETION_PATTERNS:
        if " " in pattern:
            if pattern in normalized:
                return True
        elif pattern in words:
            return True

    for index, word in enumerate(words):
        if word in NEGATION_COMPLETION_CONTEXT and index + 1 < len(words):
            if words[index + 1] in COMPLETION_STATUS_TOKENS:
                return True
    return False


def _tool_name_indicates_completion(tool_name: str, agent_type: str) -> bool:
    """Infer completion intent from tool names with an explicit contract."""
    tool_name_tokens = _tokenize_completion_terms(tool_name)

    completion_verbs = set(TOOL_COMPLETION_VERBS)
    completion_verbs.update(AGENT_TOOL_COMPLETION_OVERRIDES.get(agent_type, set()))

    return any(token in completion_verbs for token in tool_name_tokens)


def _tokenize_completion_terms(value: str) -> set[str]:
    return {
        token
        for token in re.split(r"[^a-z0-9]+", value.lower())
        if token
    }


def _iter_completion_values(value, completion_value_keys: set[str]):
    """Yield values for completion-related keys, including nested dictionaries."""
    if isinstance(value, dict):
        for key, nested in value.items():
            if not isinstance(key, str):
                continue
            if key.lower() in completion_value_keys:
                yield key, nested
            yield from _iter_completion_values(nested, completion_value_keys)
    elif isinstance(value, (list, tuple)):
        for item in value:
            yield from _iter_completion_values(item, completion_value_keys)
