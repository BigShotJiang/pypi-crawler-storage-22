"""
Intelligent Task Orchestrator for StateSet Computer Use Agent.

This module provides advanced task orchestration for 24/7 operation:

1. Intelligent Task Routing
   - Automatic complexity analysis
   - Model selection based on task requirements
   - Cost-optimized routing (Haiku for simple, Opus for complex)

2. Parallel Execution
   - Automatic parallelization of independent tasks
   - Dependency graph management
   - Resource-aware scheduling

3. Subagent Delegation
   - Automatic task decomposition
   - Specialized subagent spawning
   - Result aggregation and compression

4. Task Queue Management
   - Priority-based scheduling
   - Rate limiting and backpressure
   - Dead letter queue for failed tasks

Based on Anthropic's production patterns and multi-agent orchestration research.
"""

import asyncio
import logging
import time
import uuid
import heapq
import inspect
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import (
    Any, Callable, Coroutine, Dict, List, Optional,
    Set, Tuple, TypeVar, Union
)
from collections import defaultdict
import json

from agent.parallel_executor import (
    ParallelToolExecutor, DependencyAnalyzer, ToolCallGroup,
    get_parallel_executor
)
from agent.subagent import SubagentManager, SubagentType, SubagentResult
from agent.logging_config import get_logger

logger = get_logger(__name__)

T = TypeVar('T')


class TaskPriority(Enum):
    """Task priority levels"""
    CRITICAL = 0    # Immediate execution
    HIGH = 1        # Execute before normal tasks
    NORMAL = 2      # Standard priority
    LOW = 3         # Execute when resources available
    BACKGROUND = 4  # Execute only when idle


class TaskComplexity(Enum):
    """Task complexity levels for model routing"""
    TRIVIAL = "trivial"      # Simple lookups, basic operations
    SIMPLE = "simple"        # Straightforward tasks
    MODERATE = "moderate"    # Multi-step tasks
    COMPLEX = "complex"      # Reasoning-heavy tasks
    EXPERT = "expert"        # Most complex, requires Opus


class ModelTier(Enum):
    """Model tiers for task routing"""
    HAIKU = "claude-haiku-4-5-20251001"
    SONNET = "claude-sonnet-4-20250514"
    OPUS = "claude-opus-4-6"


@dataclass(order=True)
class PrioritizedTask:
    """Task with priority for queue ordering"""
    priority: int
    created_at: float = field(compare=False)
    task_id: str = field(compare=False)
    instruction: str = field(compare=False)
    agent_type: str = field(compare=False)
    metadata: Dict[str, Any] = field(default_factory=dict, compare=False)
    dependencies: Set[str] = field(default_factory=set, compare=False)
    complexity: TaskComplexity = field(default=TaskComplexity.MODERATE, compare=False)


@dataclass
class TaskResult:
    """Result of task execution"""
    task_id: str
    success: bool
    result: Any = None
    error: Optional[str] = None
    duration_seconds: float = 0.0
    tokens_used: int = 0
    cost: float = 0.0
    model_used: str = ""
    subagent_results: List[Dict[str, Any]] = field(default_factory=list)


class TaskNotSuitableForDecompositionError(ValueError):
    """Raised when decomposition heuristics cannot produce meaningful subtasks."""


class TaskComplexityAnalyzer:
    """Analyze task complexity for model routing"""

    # Keywords indicating complexity levels
    TRIVIAL_KEYWORDS = {
        'check', 'verify', 'confirm', 'status', 'list', 'show', 'display'
    }

    SIMPLE_KEYWORDS = {
        'click', 'type', 'open', 'close', 'navigate', 'scroll', 'find'
    }

    MODERATE_KEYWORDS = {
        'create', 'update', 'modify', 'edit', 'change', 'configure', 'setup'
    }

    COMPLEX_KEYWORDS = {
        'analyze', 'debug', 'investigate', 'research', 'optimize', 'refactor',
        'design', 'plan', 'implement', 'integrate', 'migrate'
    }

    EXPERT_KEYWORDS = {
        'architect', 'strategy', 'complex', 'multi-step', 'coordinate',
        'autonomous', 'long-running', 'critical', 'production'
    }

    @classmethod
    def analyze(cls, instruction: str, agent_type: str = "") -> TaskComplexity:
        """Analyze task complexity from instruction"""
        instruction_lower = instruction.lower()

        # Check for expert keywords first
        if any(kw in instruction_lower for kw in cls.EXPERT_KEYWORDS):
            return TaskComplexity.EXPERT

        # Count keyword matches at each level
        scores = {
            TaskComplexity.TRIVIAL: sum(1 for kw in cls.TRIVIAL_KEYWORDS if kw in instruction_lower),
            TaskComplexity.SIMPLE: sum(1 for kw in cls.SIMPLE_KEYWORDS if kw in instruction_lower),
            TaskComplexity.MODERATE: sum(1 for kw in cls.MODERATE_KEYWORDS if kw in instruction_lower),
            TaskComplexity.COMPLEX: sum(1 for kw in cls.COMPLEX_KEYWORDS if kw in instruction_lower),
        }

        # Additional factors
        word_count = len(instruction.split())
        if word_count > 50:
            scores[TaskComplexity.COMPLEX] += 2
        elif word_count > 20:
            scores[TaskComplexity.MODERATE] += 1

        # Multi-step indicators
        if any(marker in instruction_lower for marker in ['then', 'after', 'next', 'finally', 'and']):
            scores[TaskComplexity.MODERATE] += 1
            scores[TaskComplexity.COMPLEX] += 1

        # Agent type adjustments
        if agent_type in ('AUTO_CLOSE', 'SOCIAL_MEDIA'):
            # These are typically simpler, repetitive tasks
            scores[TaskComplexity.SIMPLE] += 2
        elif agent_type in ('ONBOARDING', 'GENERAL'):
            # These can be more complex
            scores[TaskComplexity.COMPLEX] += 1

        # Find highest scoring complexity
        max_score = max(scores.values())
        if max_score == 0:
            return TaskComplexity.MODERATE  # Default

        for complexity in [TaskComplexity.COMPLEX, TaskComplexity.MODERATE,
                          TaskComplexity.SIMPLE, TaskComplexity.TRIVIAL]:
            if scores[complexity] == max_score:
                return complexity

        return TaskComplexity.MODERATE

    @classmethod
    def get_recommended_model(cls, complexity: TaskComplexity) -> ModelTier:
        """Get recommended model tier for complexity"""
        return {
            TaskComplexity.TRIVIAL: ModelTier.HAIKU,
            TaskComplexity.SIMPLE: ModelTier.HAIKU,
            TaskComplexity.MODERATE: ModelTier.SONNET,
            TaskComplexity.COMPLEX: ModelTier.SONNET,
            TaskComplexity.EXPERT: ModelTier.OPUS,
        }.get(complexity, ModelTier.SONNET)


class TaskDecomposer:
    """Decompose complex tasks into subtasks"""

    @staticmethod
    def should_decompose(instruction: str, complexity: TaskComplexity) -> bool:
        """Determine if task should be decomposed"""
        # Only decompose complex+ tasks
        if complexity not in (TaskComplexity.COMPLEX, TaskComplexity.EXPERT):
            return False

        # Check for explicit multi-task indicators
        multi_task_indicators = [
            ' and ', ' then ', ' after ', ' also ',
            '1.', '2.', '- ', '• ',
            'first', 'second', 'finally'
        ]

        return any(ind in instruction.lower() for ind in multi_task_indicators)

    @staticmethod
    def decompose(instruction: str) -> List[str]:
        """Decompose instruction into subtasks"""
        subtasks = []

        # Try numbered list parsing
        if any(f'{i}.' in instruction for i in range(1, 10)):
            parts = instruction.split('\n')
            for part in parts:
                part = part.strip()
                if part and any(part.startswith(f'{i}.') for i in range(1, 10)):
                    subtasks.append(part[2:].strip())

        # Try bullet point parsing
        elif any(marker in instruction for marker in ['- ', '• ', '* ']):
            parts = instruction.split('\n')
            for part in parts:
                part = part.strip()
                if part.startswith(('-', '•', '*')):
                    subtasks.append(part[1:].strip())

        # Try conjunction splitting
        elif ' then ' in instruction.lower():
            parts = instruction.lower().split(' then ')
            subtasks = [p.strip().capitalize() for p in parts if p.strip()]

        elif ' and ' in instruction.lower():
            # Be careful with 'and' - only split on clear task boundaries
            parts = instruction.split(' and ')
            if len(parts) <= 3:  # Reasonable number of subtasks
                subtasks = [p.strip() for p in parts if p.strip()]

        # If no decomposition possible, return original
        if not subtasks:
            return [instruction]

        return subtasks


class SubagentRouter:
    """Route subtasks to appropriate subagent types"""

    @staticmethod
    def get_subagent_type(subtask: str) -> SubagentType:
        """Determine best subagent type for subtask"""
        subtask_lower = subtask.lower()

        # Research tasks - check first because "research" contains "search"
        if any(kw in subtask_lower for kw in ['research', 'learn', 'understand', 'study']):
            return SubagentType.RESEARCH

        # Analysis tasks
        if any(kw in subtask_lower for kw in ['analyze', 'investigate', 'examine', 'review', 'audit']):
            return SubagentType.ANALYZE

        # Exploration tasks
        if any(kw in subtask_lower for kw in ['find', 'search', 'locate', 'discover', 'explore']):
            return SubagentType.EXPLORE

        # Code tasks
        if any(kw in subtask_lower for kw in ['code', 'implement', 'write', 'create', 'build', 'develop']):
            return SubagentType.CODE

        # Execution tasks
        if any(kw in subtask_lower for kw in ['execute', 'run', 'perform', 'do', 'complete']):
            return SubagentType.EXECUTE

        # Default to execute
        return SubagentType.EXECUTE


class TaskQueue:
    """Priority queue for task management"""

    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self._queue: List[PrioritizedTask] = []
        self._task_ids: Set[str] = set()
        self._lock = asyncio.Lock()

        # Dead letter queue for failed tasks
        self._dead_letter: List[Tuple[PrioritizedTask, str]] = []

    async def push(
        self,
        instruction: str,
        agent_type: str,
        priority: TaskPriority = TaskPriority.NORMAL,
        dependencies: Optional[Set[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Add task to queue"""
        async with self._lock:
            if len(self._queue) >= self.max_size:
                raise RuntimeError("Task queue is full")

            task_id = str(uuid.uuid4())[:8]

            # Analyze complexity
            complexity = TaskComplexityAnalyzer.analyze(instruction, agent_type)

            task = PrioritizedTask(
                priority=priority.value,
                created_at=time.time(),
                task_id=task_id,
                instruction=instruction,
                agent_type=agent_type,
                metadata=metadata or {},
                dependencies=dependencies or set(),
                complexity=complexity
            )

            heapq.heappush(self._queue, task)
            self._task_ids.add(task_id)

            logger.info(
                f"Queued task '{task_id}' with priority {priority.name}, "
                f"complexity {complexity.value}"
            )

            return task_id

    async def pop(self) -> Optional[PrioritizedTask]:
        """Get next task from queue"""
        async with self._lock:
            if not self._queue:
                return None

            blocked_tasks: List[PrioritizedTask] = []
            queue_size = len(self._queue)

            # Scan queue once per call so dependency deadlock cannot block all queue
            # operations indefinitely.
            for _ in range(queue_size):
                task = heapq.heappop(self._queue)

                # Check if dependencies are satisfied
                if task.dependencies and task.dependencies.intersection(self._task_ids):
                    blocked_tasks.append(task)
                    continue

                # Restore blocked tasks before returning a ready task.
                for blocked_task in blocked_tasks:
                    heapq.heappush(self._queue, blocked_task)
                return task

            # All tasks are dependency-blocked; restore and report empty.
            for blocked_task in blocked_tasks:
                heapq.heappush(self._queue, blocked_task)

            return None

    async def peek(self) -> Optional[PrioritizedTask]:
        """View next task without removing"""
        async with self._lock:
            return self._queue[0] if self._queue else None

    async def remove(self, task_id: str) -> bool:
        """Remove a task from queue"""
        async with self._lock:
            for i, task in enumerate(self._queue):
                if task.task_id == task_id:
                    self._queue.pop(i)
                    self._task_ids.discard(task_id)
                    heapq.heapify(self._queue)
                    return True
            return False

    async def mark_complete(self, task_id: str):
        """Mark a task as complete (for dependency tracking)"""
        async with self._lock:
            self._task_ids.discard(task_id)

    async def add_to_dead_letter(self, task: PrioritizedTask, reason: str):
        """Add failed task to dead letter queue"""
        async with self._lock:
            self._dead_letter.append((task, reason))
            if len(self._dead_letter) > 100:
                self._dead_letter.pop(0)

    def get_stats(self) -> Dict[str, Any]:
        """Get queue statistics"""
        return {
            'queue_size': len(self._queue),
            'max_size': self.max_size,
            'pending_task_ids': len(self._task_ids),
            'dead_letter_count': len(self._dead_letter)
        }


class TaskOrchestrator:
    """
    Main task orchestrator for intelligent execution.

    Features:
    - Automatic complexity analysis
    - Model routing optimization
    - Parallel execution of independent tasks
    - Subagent delegation for complex tasks
    - Resource-aware scheduling
    """

    def __init__(
        self,
        api_key: str,
        max_concurrent: int = 5,
        enable_subagents: bool = True,
        enable_parallel: bool = True
    ):
        self.api_key = api_key
        self.max_concurrent = max_concurrent
        self.enable_subagents = enable_subagents
        self.enable_parallel = enable_parallel

        # Components
        self.task_queue = TaskQueue()
        self.complexity_analyzer = TaskComplexityAnalyzer()
        self.decomposer = TaskDecomposer()
        self.subagent_router = SubagentRouter()
        self.parallel_executor = get_parallel_executor()

        # Subagent manager (lazy initialization)
        self._subagent_manager: Optional[SubagentManager] = None

        # State tracking
        self._active_tasks: Dict[str, asyncio.Task] = {}
        self._completed_tasks: Dict[str, TaskResult] = {}
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._shutdown = False
        self._worker_lock = asyncio.Lock()

        # Metrics
        self._metrics = {
            'tasks_executed': 0,
            'tasks_succeeded': 0,
            'tasks_failed': 0,
            'subagents_spawned': 0,
            'total_tokens': 0,
            'total_cost': 0.0
        }

    @property
    def subagent_manager(self) -> SubagentManager:
        """Lazy initialization of subagent manager"""
        if self._subagent_manager is None:
            self._subagent_manager = SubagentManager(self.api_key)
        return self._subagent_manager

    async def submit_task(
        self,
        instruction: str,
        agent_type: str,
        priority: TaskPriority = TaskPriority.NORMAL,
        callback: Optional[Callable[[TaskResult], Any]] = None,
        *,
        task_func: Optional[Callable[..., Coroutine[Any, Any, Any]]] = None,
        dependencies: Optional[Set[str]] = None,
        **metadata
    ) -> str:
        """Submit a task for execution"""

        # Queue the task
        task_id = await self.task_queue.push(
            instruction=instruction,
            agent_type=agent_type,
            priority=priority,
            dependencies=dependencies,
            metadata={'callback': callback, 'task_func': task_func, **metadata}
        )

        # Start processing workers if at capacity and orchestrator is running
        async with self._worker_lock:
            if (
                not self._shutdown
                and len(self._active_tasks) < self.max_concurrent
            ):
                self._start_queue_worker()

        return task_id

    def _start_queue_worker(self) -> str:
        """Start a queue worker and track it as an active task."""
        worker_id = f"worker-{uuid.uuid4().hex[:8]}"
        worker_task = asyncio.create_task(self._process_queue())
        self._active_tasks[worker_id] = worker_task

        def _on_worker_done(task: asyncio.Task, _worker_id: str = worker_id) -> None:
            if self._active_tasks.pop(_worker_id, None) is None:
                return

            try:
                exc = task.exception()
            except asyncio.CancelledError:
                return
            except Exception:
                return

            if exc is not None:
                logger.error(
                    "Queue worker %s crashed while processing tasks: %s",
                    _worker_id,
                    exc
                )
                if not self._shutdown:
                    asyncio.create_task(self._ensure_worker_if_needed())

        worker_task.add_done_callback(_on_worker_done)
        return worker_id

    async def _ensure_worker_if_needed(self) -> None:
        """Start a worker when tasks are queued and no capacity is available."""
        if self._shutdown:
            return

        if await self.task_queue.peek() is None:
            return

        async with self._worker_lock:
            if self._shutdown:
                return
            if len(self._active_tasks) >= self.max_concurrent:
                return
            self._start_queue_worker()

    async def execute_task(
        self,
        instruction: str,
        agent_type: str,
        task_func: Callable[..., Coroutine[Any, Any, Any]],
        **kwargs
    ) -> TaskResult:
        """Execute a task with intelligent orchestration"""
        task_id = str(uuid.uuid4())[:8]
        start_time = time.time()

        # Analyze complexity
        complexity = self.complexity_analyzer.analyze(instruction, agent_type)
        model = self.complexity_analyzer.get_recommended_model(complexity)

        logger.info(
            f"Executing task '{task_id}': complexity={complexity.value}, "
            f"model={model.value}"
        )

        try:
            # Check if task should be decomposed
            if self.enable_subagents and self.decomposer.should_decompose(instruction, complexity):
                try:
                    result = await self._execute_with_decomposition(
                        task_id, instruction, agent_type, complexity
                    )
                except TaskNotSuitableForDecompositionError:
                    logger.warning(
                        "Task '%s' is not suitable for decomposition, "
                        "falling back to direct execution",
                        task_id
                    )
                    result = await self._execute_direct(
                        task_id=task_id,
                        instruction=instruction,
                        agent_type=agent_type,
                        task_func=task_func,
                        model=model,
                        **kwargs
                    )
            else:
                # Direct execution
                result = await self._execute_direct(
                    task_id, instruction, agent_type, task_func, model, **kwargs
                )

            # Success
            self._metrics['tasks_executed'] += 1
            self._metrics['tasks_succeeded'] += 1

            return TaskResult(
                task_id=task_id,
                success=True,
                result=result,
                duration_seconds=time.time() - start_time,
                model_used=model.value
            )

        except Exception as e:
            logger.error(f"Task '{task_id}' failed: {e}")
            self._metrics['tasks_executed'] += 1
            self._metrics['tasks_failed'] += 1

            return TaskResult(
                task_id=task_id,
                success=False,
                error=str(e),
                duration_seconds=time.time() - start_time,
                model_used=model.value
            )

    async def _execute_direct(
        self,
        task_id: str,
        instruction: str,
        agent_type: str,
        task_func: Callable[..., Coroutine[Any, Any, Any]],
        model: ModelTier,
        **kwargs
    ) -> Any:
        """Execute task directly without decomposition"""

        async with self._semaphore:
            return await task_func(
                instruction=instruction,
                agent_type=agent_type,
                model=model.value,
                **kwargs
            )

    async def _execute_with_decomposition(
        self,
        task_id: str,
        instruction: str,
        agent_type: str,
        complexity: TaskComplexity
    ) -> Dict[str, Any]:
        """Execute task with subagent decomposition"""

        logger.info(f"Decomposing task '{task_id}' into subtasks")

        # Decompose task
        subtasks = self.decomposer.decompose(instruction)
        logger.info(f"Decomposed into {len(subtasks)} subtasks")

        if len(subtasks) <= 1:
            # No meaningful decomposition, fall back to direct execution
            logger.info("No meaningful decomposition, using direct execution")
            raise TaskNotSuitableForDecompositionError("Task not suitable for decomposition")

        # Route subtasks to subagents
        subagent_results = []

        for i, subtask in enumerate(subtasks):
            subagent_type = self.subagent_router.get_subagent_type(subtask)

            logger.info(
                f"Spawning subagent {i+1}/{len(subtasks)}: "
                f"type={subagent_type.value}, task='{subtask[:50]}...'"
            )

            try:
                result = await self.subagent_manager.spawn(
                    task=subtask,
                    subagent_type=subagent_type
                )

                self._metrics['subagents_spawned'] += 1
                self._metrics['total_tokens'] += result.tokens_used

                subagent_results.append({
                    'subtask': subtask,
                    'type': subagent_type.value,
                    'success': result.success,
                    'result': result.result if result.success else None,
                    'error': result.error if not result.success else None,
                    'tokens_used': result.tokens_used
                })

            except Exception as e:
                logger.error(f"Subagent failed for subtask: {e}")
                subagent_results.append({
                    'subtask': subtask,
                    'type': subagent_type.value,
                    'success': False,
                    'error': str(e)
                })

        # Aggregate results
        successful = [r for r in subagent_results if r.get('success')]

        return {
            'task_id': task_id,
            'instruction': instruction,
            'subtask_count': len(subtasks),
            'successful_count': len(successful),
            'results': subagent_results,
            'aggregated_result': self._aggregate_results(subagent_results)
        }

    def _aggregate_results(self, results: List[Dict[str, Any]]) -> str:
        """Aggregate subagent results into summary"""
        successful = [r for r in results if r.get('success')]

        if not successful:
            return "All subtasks failed"

        summary_parts = [f"Completed {len(successful)}/{len(results)} subtasks:"]

        for r in successful:
            result_text = r.get('result', '')
            if len(result_text) > 100:
                result_text = result_text[:100] + '...'
            summary_parts.append(f"- [{r['type']}]: {result_text}")

        return '\n'.join(summary_parts)

    async def _process_queue(self):
        """Process tasks from queue"""
        while not self._shutdown:
            task = await self.task_queue.pop()

            if not task:
                await asyncio.sleep(0.1)
                continue

            # Execute task
            try:
                # Get task function from metadata or use default
                task_func = task.metadata.get('task_func')
                callback = task.metadata.get('callback')

                if task_func:
                    result = await self.execute_task(
                        instruction=task.instruction,
                        agent_type=task.agent_type,
                        task_func=task_func
                    )
                else:
                    # No task function, just record as completed
                    result = TaskResult(
                        task_id=task.task_id,
                        success=True,
                        result="Task processed (no execution function provided)"
                    )

                self._completed_tasks[task.task_id] = result

                # Execute callback if provided
                if callback:
                    try:
                        callback_result = callback(result)
                        if inspect.isawaitable(callback_result):
                            await callback_result
                    except Exception as e:
                        logger.error(f"Callback error: {e}")

            except Exception as e:
                logger.error(f"Queue processing error for task '{task.task_id}': {e}")
                await self.task_queue.add_to_dead_letter(task, str(e))

            finally:
                await self.task_queue.mark_complete(task.task_id)

    async def execute_parallel(
        self,
        tasks: List[Dict[str, Any]],
        task_func: Callable[..., Coroutine[Any, Any, Any]]
    ) -> List[TaskResult]:
        """Execute multiple independent tasks in parallel"""

        if not self.enable_parallel:
            # Sequential fallback
            results = []
            for task in tasks:
                result = await self.execute_task(
                    instruction=task['instruction'],
                    agent_type=task.get('agent_type', 'GENERAL'),
                    task_func=task_func
                )
                results.append(result)
            return results

        # Parallel execution
        async def execute_one(task: Dict[str, Any]) -> TaskResult:
            return await self.execute_task(
                instruction=task['instruction'],
                agent_type=task.get('agent_type', 'GENERAL'),
                task_func=task_func
            )

        results = await asyncio.gather(
            *[execute_one(task) for task in tasks],
            return_exceptions=True
        )

        # Convert exceptions to TaskResults
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed_results.append(TaskResult(
                    task_id=f"parallel-{i}",
                    success=False,
                    error=str(result)
                ))
            else:
                processed_results.append(result)

        return processed_results

    def get_task_result(self, task_id: str) -> Optional[TaskResult]:
        """Get result for a completed task"""
        return self._completed_tasks.get(task_id)

    def get_metrics(self) -> Dict[str, Any]:
        """Get orchestrator metrics"""
        return {
            **self._metrics,
            'active_tasks': len(self._active_tasks),
            'queue_stats': self.task_queue.get_stats(),
            'parallel_stats': self.parallel_executor.get_stats()
        }

    async def shutdown(self):
        """Shutdown orchestrator"""
        logger.info("Shutting down task orchestrator")
        self._shutdown = True

        # Cancel active tasks
        for task_id, task in list(self._active_tasks.items()):
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # Cleanup subagent manager
        if self._subagent_manager:
            close_all = getattr(self._subagent_manager, "close_all", None)
            if close_all is not None:
                close_result = close_all()
                if inspect.isawaitable(close_result):
                    await close_result
            else:
                self._subagent_manager.close()

        logger.info("Task orchestrator shutdown complete")


# Global instance
_orchestrator_instance: Optional[TaskOrchestrator] = None


def get_task_orchestrator(
    api_key: Optional[str] = None,
    **kwargs
) -> TaskOrchestrator:
    """Get or create global task orchestrator"""
    global _orchestrator_instance

    if _orchestrator_instance is None:
        if api_key is None:
            import os
            api_key = os.environ.get('ANTHROPIC_API_KEY')

        if not api_key:
            raise ValueError("API key required for task orchestrator")

        _orchestrator_instance = TaskOrchestrator(api_key, **kwargs)

    return _orchestrator_instance


async def shutdown_orchestrator():
    """Shutdown global orchestrator"""
    global _orchestrator_instance

    if _orchestrator_instance:
        await _orchestrator_instance.shutdown()
        _orchestrator_instance = None
