"""
Centralized settings loader for tool modules.

Eliminates duplicated config-loading boilerplate in bash.py and computer.py.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


def load_tool_settings(section: str, defaults: dict[str, Any]) -> dict[str, Any]:
    """Load tool settings from agent config with safe fallback.

    Args:
        section: Config section name (e.g. "bash", "computer").
        defaults: Default values returned when config is unavailable.

    Returns:
        Settings dict from config, or *defaults* if config cannot be loaded.
    """
    try:
        from agent.config import get_config
        settings = getattr(get_config().tools, section, None)
        if settings is not None:
            return settings
        return defaults
    except (ImportError, AttributeError, TypeError):
        return defaults
