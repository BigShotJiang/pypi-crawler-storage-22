import asyncio
import contextlib
import logging
import os
import signal
from agent.security.validator import get_configured_allowed_commands
from uuid import uuid4
from typing import Any, Literal

from .base import BaseAnthropicTool, CLIResult, ToolError, ToolResult

logger = logging.getLogger(__name__)


def _get_bash_settings() -> dict:
    """Load bash tool settings from config, with safe fallback to defaults."""
    from ._settings import load_tool_settings
    return load_tool_settings("bash", {"timeout": 60.0, "output_delay": 0.05})


class _BashSession:
    """A session of a bash shell."""

    _started: bool
    _process: asyncio.subprocess.Process
    command: str = "/bin/bash"

    def __init__(self):
        settings = _get_bash_settings()
        self._output_delay: float = settings.get("output_delay", 0.05)
        self._timeout: float = settings.get("timeout", 60.0)
        self._started = False
        self._timed_out = False

    async def start(self):
        if self._started:
            return

        logger.debug("Starting bash session (timeout=%.1fs)", self._timeout)
        self._process = await asyncio.create_subprocess_exec(
            self.command,
            start_new_session=True,
            bufsize=0,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        self._started = True
        self._timed_out = False  # Reset timeout flag on restart

    async def _terminate_process_group(self, timeout: float = 5.0):
        """Terminate the bash process group safely."""
        if self._process.returncode is not None:
            return

        pid = self._process.pid
        if pid is None:
            return

        if hasattr(os, "killpg"):
            with contextlib.suppress(ProcessLookupError):
                os.killpg(pid, signal.SIGTERM)
        else:
            with contextlib.suppress(ProcessLookupError):
                self._process.terminate()

        try:
            await asyncio.wait_for(self._process.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            if hasattr(os, "killpg"):
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(pid, signal.SIGKILL)
            else:
                with contextlib.suppress(ProcessLookupError):
                    self._process.kill()
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(self._process.wait(), timeout=1.0)

    async def stop(self):
        """Terminate the bash shell with graceful shutdown and kill fallback."""
        if not self._started:
            raise ToolError("Session has not started.")
        await self._terminate_process_group()
        self._started = False

    def _validate_command(self, command: str) -> tuple[bool, str]:
        """
        Validate command safety. Returns (is_safe, reason).

        Security approach:
        1. Block known dangerous patterns and commands
        2. Detect obfuscation attempts (variable expansion, command substitution)
        3. Check for path traversal in arguments
        """
        if not isinstance(command, str):
            return False, "Command must be a string"

        if not command.strip():
            return False, "Command cannot be empty"

        try:
            from agent.config import get_config
            from agent.security.validator import ValidationError, validate_tool_input

            security_config = getattr(get_config(), "security", None)
            enforce_allowed_commands = bool(
                getattr(security_config, "enforce_command_allowlist", False)
            )

            validate_tool_input(
                "bash",
                {"command": command},
                allowed_commands=get_configured_allowed_commands(),
                enforce_allowed_commands=enforce_allowed_commands,
            )
        except ValidationError as e:
            return False, str(e)
        except Exception as e:
            return False, f"Command validation failed: {e}"

        return True, ""

    async def _read_stdout_until_sentinel(
        self,
        sentinel: str,
    ) -> tuple[str, bool]:
        """Read stdout until the command sentinel is observed."""
        if self._process.stdout is None:
            raise ToolError("bash stdout stream is not available")

        chunks: list[str] = []

        while True:
            line = await self._process.stdout.readline()
            if not line:
                return "".join(chunks), False

            text = line.decode(errors="replace")
            if sentinel in text:
                chunks.append(text[: text.index(sentinel)])
                return "".join(chunks), True
            chunks.append(text)

    async def _read_stderr_until_event(self, stop_event: asyncio.Event) -> str:
        """Read stderr while waiting for stdout sentinel completion."""
        if self._process.stderr is None:
            raise ToolError("bash stderr stream is not available")

        chunks: list[str] = []
        poll_interval = max(0.001, self._output_delay)

        while True:
            try:
                line = await asyncio.wait_for(
                    self._process.stderr.readline(),
                    timeout=poll_interval,
                )
            except asyncio.TimeoutError:
                if stop_event.is_set():
                    break
                continue

            if not line:
                break
            chunks.append(line.decode(errors="replace"))

        return "".join(chunks)

    async def run(self, command: str):
        """Execute a command in the bash shell."""
        if not self._started:
            raise ToolError("Session has not started.")
        if self._process.returncode is not None:
            return ToolResult(
                system="tool must be restarted",
                error=f"bash has exited with returncode {self._process.returncode}",
            )
        if self._timed_out:
            raise ToolError(
                f"timed out: bash has not returned in {self._timeout} seconds and must be restarted",
            )

        # Validate command safety
        is_safe, reason = self._validate_command(command)
        if not is_safe:
            logger.warning("Command blocked: %s (reason: %s)", command[:80], reason)
            return ToolResult(
                error=f"Command blocked for safety: {reason}. If you need to run this command, please ask the user for confirmation.",
                system="dangerous_command_blocked"
            )

        if self._process.stdin is None or self._process.stdout is None or self._process.stderr is None:
            raise ToolError("bash session streams are not available")

        sentinel = f"__STATESET_BASH_DONE_{uuid4().hex}__"

        # send command to the process
        self._process.stdin.write(
            command.encode() + f"; echo '{sentinel}'\n".encode()
        )
        await self._process.stdin.drain()

        stdout_done = asyncio.Event()
        read_stdout_task = asyncio.create_task(self._read_stdout_until_sentinel(sentinel))
        read_stderr_task = asyncio.create_task(
            self._read_stderr_until_event(stdout_done)
        )

        output = ""
        error = ""
        try:
            output, found_sentinel = await asyncio.wait_for(
                read_stdout_task,
                timeout=self._timeout,
            )
            if not found_sentinel:
                raise ToolError("bash command failed before completion (missing completion marker)")
            stdout_done.set()
            error = await read_stderr_task
        except asyncio.TimeoutError:
            self._timed_out = True
            await self._terminate_process_group()
            self._started = False
            logger.error("Bash command timed out after %.1fs: %s", self._timeout, command[:120])
            raise ToolError(
                f"timed out: bash has not returned in {self._timeout} seconds and must be restarted",
            ) from None
        else:
            if output.endswith("\n"):
                output = output[:-1]
            if error.endswith("\n"):
                error = error[:-1]
        finally:
            stdout_done.set()
            if not read_stdout_task.done():
                read_stdout_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await read_stdout_task
            if not read_stderr_task.done():
                read_stderr_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await read_stderr_task

        return CLIResult(output=output, error=error)


class BashTool20250124(BaseAnthropicTool):
    """
    A tool that allows the agent to run bash commands.
    The tool parameters are defined by Anthropic and are not editable.
    """

    _session: _BashSession | None

    api_type: Literal["bash_20250124"] = "bash_20250124"
    name: Literal["bash"] = "bash"

    def __init__(self):
        self._session = None
        super().__init__()

    def to_params(self) -> Any:
        return {
            "type": self.api_type,
            "name": self.name,
        }

    async def __call__(
        self, command: str | None = None, restart: bool = False, **kwargs
    ):
        if restart:
            if self._session:
                await self._session.stop()
            self._session = _BashSession()
            await self._session.start()

            return ToolResult(system="tool has been restarted.")

        if self._session is None:
            self._session = _BashSession()
            await self._session.start()

        if command is not None:
            return await self._session.run(command)

        raise ToolError("no command provided.")


class BashTool20241022(BashTool20250124):
    api_type: Literal["bash_20241022"] = "bash_20241022"  # pyright: ignore[reportIncompatibleVariableOverride]
