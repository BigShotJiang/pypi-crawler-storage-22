"""Collection classes for managing multiple tools."""

import logging
from typing import Any, Iterable

from anthropic.types.beta import BetaToolUnionParam
from agent.config import get_config

from agent.security.validator import get_configured_allowed_commands

from .base import (
    BaseAnthropicTool,
    ToolError,
    ToolFailure,
    ToolResult,
)

logger = logging.getLogger(__name__)
_SANDBOX_DISABLED_WARNING = False
_SANDBOX_FALLBACK_WARNING = False


class ToolCollection:
    """A collection of anthropic-defined tools."""

    def __init__(self, *tools: BaseAnthropicTool):
        self.tools = tools
        self.tool_map: dict[str, BaseAnthropicTool] = {}
        for tool in tools:
            params = dict(tool.to_params())
            name = params.get("name")
            if not isinstance(name, str) or not name:
                raise ValueError(
                    "All tools must provide a string name in to_params() output"
                )
            self.tool_map[name] = tool

    def to_params(
        self,
    ) -> list[BetaToolUnionParam]:
        params_list: list[BetaToolUnionParam] = []
        for tool in self.tools:
            params = dict(tool.to_params())
            if getattr(tool, "_defer_loading_override", False):
                params["defer_loading"] = True
            params_list.append(params)
        return params_list

    def set_deferred_tools(
        self, tool_names: Iterable[str]
    ) -> tuple[list[str], list[str]]:
        """
        Flag specific tools so their definitions are marked with defer_loading.

        Returns:
            applied: Tools found in the collection and marked as deferred.
            missing: Requested tool names that are not present.
        """
        applied: list[str] = []
        missing: list[str] = []
        seen: set[str] = set()

        for name in tool_names:
            if not name:
                continue
            if name in seen:
                continue
            seen.add(name)
            tool = self.tool_map.get(name)
            if tool:
                setattr(tool, "_defer_loading_override", True)
                applied.append(name)
            else:
                missing.append(name)

        return applied, missing

    async def run(self, *, name: str, tool_input: dict[str, Any]) -> ToolResult:
        tool = self.tool_map.get(name)
        if not tool:
            return ToolFailure(error=f"Tool {name} is invalid")

        if not isinstance(tool_input, dict):
            return ToolFailure(error=f"Tool input for '{name}' must be a mapping")

        # Copy to avoid mutating caller-owned dictionaries.
        tool_input = dict(tool_input)
        if any(not isinstance(key, str) for key in tool_input.keys()):
            return ToolFailure(
                error=f"Tool input for '{name}' must use string keys"
            )

        # Apply global tool input validation and optional sandboxing.
        config = get_config()
        if config.security.validate_tool_inputs:
            try:
                from agent.security.validator import (
                    ValidationError as ToolInputValidationError,
                    validate_tool_input,
                    get_computer_actions_for_tool_version,
                )

                security_config = getattr(config, "security", None)
                enforce_allowed_commands = bool(
                    getattr(security_config, "enforce_command_allowlist", False)
                )
                allowed_commands = get_configured_allowed_commands(
                    getattr(security_config, "allowed_commands", None),
                )
                allowed_actions = None
                if name == "computer":
                    tool_version = getattr(tool, "api_type", None)
                    if not isinstance(tool_version, str):
                        tool_version = None

                    allowed_actions = get_computer_actions_for_tool_version(
                        tool_version
                    )
                    if allowed_actions is None:
                        tool_version = dict(tool.to_params()).get("type")
                        allowed_actions = get_computer_actions_for_tool_version(
                            tool_version if isinstance(tool_version, str) else None
                        )
                    if allowed_actions is None:
                        allowed_actions = get_computer_actions_for_tool_version(
                            getattr(getattr(config, "tools", None), "version", None)
                        )
                    if allowed_actions is None:
                        tool_supported_actions = getattr(tool, "SUPPORTED_ACTIONS", None)
                        if tool_supported_actions is not None:
                            allowed_actions = set(tool_supported_actions)
                        else:
                            allowed_actions = frozenset()

                tool_input = validate_tool_input(
                    name,
                    tool_input,
                    allowed_commands=allowed_commands,
                    allowed_actions=allowed_actions,
                    enforce_allowed_commands=enforce_allowed_commands,
                )
                if not isinstance(tool_input, dict):
                    return ToolFailure(
                        error=f"Tool input validation produced invalid result for '{name}'"
                    )
            except ToolInputValidationError as e:
                return ToolFailure(
                    error=f"Tool input validation failed for '{name}': {e}"
                )
            except Exception as e:
                logger.warning(
                    "Tool input validation failed with unexpected validator error: %s",
                    e,
                )
                return ToolFailure(
                    error=f"Tool input validation failed for '{name}': {e}"
                )

        # Optional sandbox execution for shell-backed tools.
        sandbox_enabled = getattr(config.security, "enable_sandbox", True)
        if name == "bash" and not sandbox_enabled:
            global _SANDBOX_DISABLED_WARNING
            if not _SANDBOX_DISABLED_WARNING:
                logger.warning(
                    "Bash sandboxing is disabled: commands will execute on the host."
                )
                _SANDBOX_DISABLED_WARNING = True

        if sandbox_enabled and name == "bash":
            command = tool_input.get("command")
            if not isinstance(command, str) or not command.strip():
                return ToolFailure(error="Bash command must be a non-empty string")

            try:
                from agent.security.sandbox import get_sandbox_manager

                result = await get_sandbox_manager(enabled=True).execute_bash(command)
                if not result.get("sandboxed", True):
                    global _SANDBOX_FALLBACK_WARNING
                    if not _SANDBOX_FALLBACK_WARNING:
                        logger.warning(
                            "Requested bash sandboxing but command executed without sandbox."
                        )
                        _SANDBOX_FALLBACK_WARNING = True
                if not isinstance(result, dict):
                    return ToolFailure(error="Sandbox execution returned an invalid response")

                stderr = result.get("stderr") or ""
                if result.get("exit_code") not in (None, 0):
                    if not stderr:
                        stderr = f"Command failed with exit code {result.get('exit_code')}"
                    return ToolResult(
                        output=result.get("stdout") or "",
                        error=stderr,
                    )

                return ToolResult(
                    output=result.get("stdout") or "",
                    error=result.get("stderr") or "",
                )
            except Exception as e:
                return ToolFailure(error=f"Sandbox execution failed: {e}")

        try:
            return await tool(**tool_input)
        except ToolError as e:
            return ToolFailure(error=e.message)
        except Exception as e:
            logger.warning("Tool execution failed for '%s': %s", name, e)
            return ToolFailure(error=f"Tool execution failed for '{name}': {e}")
