from dataclasses import dataclass
from typing import Literal, Optional, Callable

from .base import BaseAnthropicTool
from .bash import BashTool20241022, BashTool20250124
from .computer import ComputerTool20241022, ComputerTool20250124, ComputerTool20251124
from .edit import EditTool20241022, EditTool20250124
from .memory import MemoryTool
from .agi import AGITool
from .stateset_cli import StateSetCLITool
from .ask_user import AskUserTool

# Enhanced computer tools with retry logic and performance tracking
try:
    from .computer_enhanced import (
        EnhancedComputerTool20241022,
        EnhancedComputerTool20250124,
        EnhancedComputerTool20251124,
    )
    ENHANCED_TOOLS_AVAILABLE = True
except ImportError:
    ENHANCED_TOOLS_AVAILABLE = False

# Subagent tool - loaded lazily to avoid circular imports
SUBAGENT_TOOL_AVAILABLE = False
_SubagentTool: Optional[type] = None

def _load_subagent_tool():
    """Lazily load SubagentTool to avoid circular imports."""
    global SUBAGENT_TOOL_AVAILABLE, _SubagentTool
    try:
        from agent.subagent import get_subagent_tool_class
        _SubagentTool = get_subagent_tool_class()
        SUBAGENT_TOOL_AVAILABLE = _SubagentTool is not None
    except ImportError:
        SUBAGENT_TOOL_AVAILABLE = False
    except Exception:
        # Handle any errors during class creation
        SUBAGENT_TOOL_AVAILABLE = False

# Don't try to load at module init - load lazily to avoid circular imports

ToolVersion = Literal[
    "computer_use_20251124",
    "computer_use_20250124",
    "computer_use_20241022",
    "cli_20250124",
]
BetaFlag = Literal[
    "computer-use-2024-10-22",
    "computer-use-2025-01-24",
    "computer-use-2025-11-24",
]


@dataclass(frozen=True, kw_only=True)
class ToolGroup:
    version: ToolVersion
    tools: list[type[BaseAnthropicTool]]
    beta_flag: BetaFlag | None = None
    requires_display: bool = True


TOOL_GROUPS: list[ToolGroup] = [
    ToolGroup(
        version="computer_use_20251124",
        tools=[
            ComputerTool20251124,
            EditTool20250124,
            BashTool20250124,
            MemoryTool,
            AGITool,
            StateSetCLITool,
            AskUserTool,
        ],
        beta_flag="computer-use-2025-11-24",
        requires_display=True,
    ),
    ToolGroup(
        version="computer_use_20241022",
        tools=[ComputerTool20241022, EditTool20241022, BashTool20241022],
        beta_flag="computer-use-2024-10-22",
        requires_display=True,
    ),
    ToolGroup(
        version="computer_use_20250124",
        tools=[
            ComputerTool20250124,
            EditTool20250124,
            BashTool20250124,
            MemoryTool,
            AGITool,
            StateSetCLITool,
            AskUserTool,
        ],
        beta_flag="computer-use-2025-01-24",
        requires_display=True,
    ),
    ToolGroup(
        version="cli_20250124",
        tools=[BashTool20250124, EditTool20250124, MemoryTool, AGITool, StateSetCLITool, AskUserTool],
        beta_flag=None,
        requires_display=False,
    ),
]

TOOL_GROUPS_BY_VERSION = {tool_group.version: tool_group for tool_group in TOOL_GROUPS}


def get_subagent_tool(api_key: str):
    """
    Get an instance of SubagentTool.

    The SubagentTool requires an API key at instantiation, so it's created
    dynamically rather than being part of the static tool groups.

    Args:
        api_key: Anthropic API key for subagent API calls

    Returns:
        SubagentTool instance or None if not available
    """
    global SUBAGENT_TOOL_AVAILABLE, _SubagentTool

    # Lazy load the tool class
    if _SubagentTool is None:
        _load_subagent_tool()

    if not SUBAGENT_TOOL_AVAILABLE or _SubagentTool is None:
        return None
    return _SubagentTool(api_key=api_key)


def get_tools_with_subagent(tool_version: "ToolVersion", api_key: str) -> list:
    """
    Get all tools for a version including SubagentTool.

    This creates tool instances (rather than classes) because SubagentTool
    requires runtime configuration.

    Args:
        tool_version: The tool version to use
        api_key: Anthropic API key

    Returns:
        List of tool instances
    """
    tool_group = TOOL_GROUPS_BY_VERSION.get(tool_version)
    if not tool_group:
        raise ValueError(f"Unknown tool version: {tool_version}")

    tools = []
    for ToolCls in tool_group.tools:
        tools.append(ToolCls())

    # Add subagent tool if available
    subagent_tool = get_subagent_tool(api_key)
    if subagent_tool:
        tools.append(subagent_tool)

    return tools


# Enhanced tool groups with retry logic and performance tracking
# Use these for faster, more accurate, and more effective computer use
if ENHANCED_TOOLS_AVAILABLE:
    ENHANCED_TOOL_GROUPS: list[ToolGroup] = [
        ToolGroup(
            version="computer_use_20251124",
            tools=[EnhancedComputerTool20251124, EditTool20250124, BashTool20250124, MemoryTool, AGITool, StateSetCLITool, AskUserTool],
            beta_flag="computer-use-2025-11-24",
            requires_display=True,
        ),
        ToolGroup(
            version="computer_use_20241022",
            tools=[EnhancedComputerTool20241022, EditTool20241022, BashTool20241022, AskUserTool],
            beta_flag="computer-use-2024-10-22",
            requires_display=True,
        ),
        ToolGroup(
            version="computer_use_20250124",
            tools=[EnhancedComputerTool20250124, EditTool20250124, BashTool20250124, MemoryTool, AGITool, StateSetCLITool, AskUserTool],
            beta_flag="computer-use-2025-01-24",
            requires_display=True,
        ),
    ]
    ENHANCED_TOOL_GROUPS_BY_VERSION = {tool_group.version: tool_group for tool_group in ENHANCED_TOOL_GROUPS}
else:
    ENHANCED_TOOL_GROUPS = []
    ENHANCED_TOOL_GROUPS_BY_VERSION = {}
