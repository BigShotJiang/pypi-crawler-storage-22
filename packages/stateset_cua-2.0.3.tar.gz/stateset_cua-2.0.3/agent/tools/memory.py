"""
Memory tool for Claude to store and retrieve information across conversations.
Implements the memory_20250818 tool with full command support.
"""

import os
import shutil
import re
import logging
from pathlib import Path
from typing import Literal, Any

from .base import BaseAnthropicTool, ToolError, ToolResult

logger = logging.getLogger('agent.memory')

# Memory directory base path
MEMORY_DIR = Path("/tmp/agent_memories")

# Supported commands
Command = Literal[
    "view",
    "create",
    "str_replace",
    "insert",
    "delete",
    "rename",
    "list",
    "search",
    "append",
    "replace",
    "update",
]


class MemoryContentSanitizer:
    """
    Sanitize memory content to prevent prompt injection attacks.
    
    Critical Security: Memory files are read back into Claude's context,
    making them a potential vector for prompt injection. This class
    detects and neutralizes dangerous patterns.
    """
    
    # Patterns that could be prompt injection attempts  
    # Note: All patterns use IGNORECASE flag when searched
    DANGEROUS_PATTERNS = [
        (r'<\s*system\s*>', 'System tag injection'),
        (r'<\s*/\s*system\s*>', 'System tag close'),
        (r'Human\s*:', 'Role manipulation (Human)'),
        (r'Assistant\s*:', 'Role manipulation (Assistant)'),
        (r'ignore\s+.*(previous|all).*instructions?', 'Instruction override'),  # More flexible
        (r'your\s+new\s+instructions?\s+are', 'Instruction replacement'),
        (r'disregard\s+(previous|all|everything)', 'Disregard command'),
        (r'\[INST\]', 'Instruction marker'),
        (r'\[/INST\]', 'Instruction marker close'),
        (r'<\s*user\s*>', 'User tag injection'),
        (r'<\s*/\s*user\s*>', 'User tag close'),
    ]
    
    @classmethod
    def sanitize(cls, content: str, strict: bool = False) -> str:
        """
        Sanitize content before storing in memory.
        
        Args:
            content: Content to sanitize
            strict: If True, raise error on dangerous patterns. If False, neutralize them.
        
        Returns:
            Sanitized content
        
        Raises:
            ToolError: If strict=True and dangerous pattern found
        """
        found_patterns = []
        
        for pattern, description in cls.DANGEROUS_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                found_patterns.append(description)
                
                if strict:
                    raise ToolError(
                        f"Content contains potentially dangerous pattern: {description}. "
                        f"Memory storage blocked for security."
                    )
                else:
                    # Neutralize by replacing with safe text
                    logger.warning(f"Sanitizing memory content: {description}")
                    content = re.sub(pattern, '[SANITIZED]', content, flags=re.IGNORECASE)
        
        if found_patterns and not strict:
            logger.info(f"Sanitized {len(found_patterns)} potentially dangerous patterns from memory content")
        
        return content
    
    @classmethod
    def is_safe(cls, content: str) -> bool:
        """Check if content is safe to store without modification"""
        for pattern, _ in cls.DANGEROUS_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                return False
        return True
    
    @classmethod
    def check_and_warn(cls, content: str) -> list:
        """Check content and return list of warnings (non-blocking)"""
        warnings = []
        
        for pattern, description in cls.DANGEROUS_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                warnings.append(description)
        
        return warnings


class MemoryTool(BaseAnthropicTool):
    """
    Memory tool that allows Claude to persist information across conversations.
    Stores data in a local directory with security protections.
    """
    
    api_type: Literal["memory_20250818"] = "memory_20250818"
    name: Literal["memory"] = "memory"
    
    COMMAND_METADATA: dict[str, dict[str, bool]] = {
        'view': {'read_only': True},
        'list': {'read_only': True},
        'search': {'read_only': True},
        'create': {'read_only': False},
        'append': {'read_only': False},
        'replace': {'read_only': False},
        'update': {'read_only': False},
        'str_replace': {'read_only': False},
        'insert': {'read_only': False},
        'delete': {'read_only': False},
        'rename': {'read_only': False},
    }

    _COMMAND_ALIASES: dict[str, str] = {
        "list": "view",
        "search": "view",
        "replace": "str_replace",
        "update": "str_replace",
        "append": "insert",
    }
    
    def __init__(self, memory_base_dir: str = None):
        """Initialize memory tool with a base directory."""
        super().__init__()
        
        if memory_base_dir:
            self.memory_dir = Path(memory_base_dir)
        else:
            self.memory_dir = MEMORY_DIR
        
        # Ensure memory directory exists
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize memories subdirectory
        self.memories_dir = self.memory_dir / "memories"
        self.memories_dir.mkdir(exist_ok=True)
    
    def to_params(self) -> Any:
        """Return tool parameters for API."""
        return {
            "type": self.api_type,
            "name": self.name,
        }
    
    async def __call__(
        self,
        *,
        command: Command,
        path: str = None,
        old_path: str = None,
        new_path: str = None,
        file_text: str = None,
        view_range: list[int] = None,
        old_str: str = None,
        new_str: str = None,
        insert_line: int = None,
        insert_text: str = None,
        search_query: str = None,
        **kwargs
    ) -> ToolResult:
        """Execute memory tool command."""

        command_key = command.lower()
        normalized_command = self._normalize_command(command_key)
        query = search_query or kwargs.get("query") or kwargs.get("searchQuery")
        
        try:
            if normalized_command == "view":
                if command_key == "search":
                    return await self._search(path, query)
                return await self._view(path, view_range)
            elif normalized_command == "create":
                return await self._create(path, file_text)
            elif normalized_command == "str_replace":
                return await self._str_replace(path, old_str, new_str)
            elif normalized_command == "insert":
                if command_key == "append":
                    if insert_text is not None:
                        append_text = insert_text
                    elif file_text is not None:
                        append_text = file_text
                    else:
                        append_text = kwargs.get("append_text")
                    return await self._append(path, append_text)
                return await self._insert(path, insert_line, insert_text)
            elif normalized_command == "delete":
                return await self._delete(path)
            elif normalized_command == "rename":
                return await self._rename(old_path, new_path)
            else:
                raise ToolError(f"Unknown command: {command}")
        
        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"Memory tool error: {str(e)}")
    
    def _validate_path(self, path_str: str) -> Path:
        """
        Validate and sanitize path to prevent directory traversal attacks.

        Security measures:
        - Ensures path starts with /memories
        - Resolves to canonical form (following symlinks)
        - Verifies resolved path stays within memories directory
        - Rejects traversal patterns in input
        - Blocks symlinks that point outside the allowed directory
        """
        if not path_str:
            raise ToolError("Path is required")

        if "\x00" in path_str:
            raise ToolError("Path contains invalid null byte")

        # Ensure path starts with /memories
        if not (path_str == "/memories" or path_str.startswith("/memories/")):
            raise ToolError("All paths must start with /memories")

        # Remove /memories prefix for local resolution
        relative_path = path_str[len("/memories"):].lstrip("/")

        # Build full path
        if relative_path:
            full_path = self.memories_dir / relative_path
        else:
            full_path = self.memories_dir

        # Additional security: check for suspicious patterns BEFORE resolution
        suspicious_patterns = ["../", "..\\", "%2e%2e", "\\..\\", "/..\\", "%00"]
        for pattern in suspicious_patterns:
            if pattern in path_str.lower():
                raise ToolError(f"Invalid path: contains suspicious pattern '{pattern}'")

        # Resolve to canonical form and check it's within memories_dir
        # This follows ALL symlinks to get the true destination
        resolved_memories_dir = self.memories_dir.resolve()
        try:
            # Use resolve(strict=False) to resolve even if path doesn't exist yet
            # This is safe because we'll check it stays within bounds
            resolved_path = full_path.resolve()

            # Check the resolved path stays within the allowed directory
            resolved_path.relative_to(resolved_memories_dir)
        except (ValueError, RuntimeError):
            raise ToolError(f"Invalid path: {path_str} (directory traversal attempt)")

        # Additional symlink check: if path exists, ensure it's not a symlink
        # pointing outside the allowed directory
        if full_path.exists():
            # Check if this is a symlink
            if full_path.is_symlink():
                # Get the symlink target (resolves the symlink)
                symlink_target = full_path.resolve()
                try:
                    symlink_target.relative_to(resolved_memories_dir)
                except ValueError:
                    raise ToolError(
                        f"Invalid path: {path_str} (symlink points outside allowed directory)"
                    )

            # For directories, also check for symlinks within
            if full_path.is_dir():
                # Check immediate children only (not recursive to avoid performance issues)
                try:
                    for child in full_path.iterdir():
                        if child.is_symlink():
                            try:
                                child.resolve().relative_to(resolved_memories_dir)
                            except ValueError:
                                logger.warning(
                                    "Found symlink pointing outside memory directory: %s",
                                    child
                                )
                except PermissionError:
                    pass  # Can't read directory, path validation still passes

        return resolved_path

    @staticmethod
    def _normalize_command(command: str) -> str:
        """Translate legacy command aliases to supported canonical commands."""
        canonical = command.lower()
        return MemoryTool._COMMAND_ALIASES.get(canonical, canonical)

    async def _search(self, path: str, query: str) -> ToolResult:
        """Search for a query across one file or directory subtree."""
        if not isinstance(query, str) or not query.strip():
            raise ToolError("search_query is required for search command")

        resolved_path = self._validate_path(path)

        if not resolved_path.exists():
            raise ToolError(f"Path does not exist: {path}")

        normalized_query = query.strip()
        matches = []
        search_limit = 200

        def _search_in_file(file_path: Path, file_matches: list[str]):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    for i, line in enumerate(f, 1):
                        if normalized_query.lower() in line.lower():
                            file_matches.append(f"{file_path.relative_to(self.memories_dir)}:{i}:{line.rstrip()}")
                            if len(matches) >= search_limit:
                                return True
            except UnicodeDecodeError:
                return False
            return False

        if resolved_path.is_file():
            _search_in_file(resolved_path, matches)
        else:
            for root, dirnames, filenames in os.walk(resolved_path, followlinks=False):
                if len(matches) >= search_limit:
                    break

                root_path = Path(root)

                # Defensive: don't descend into symlinked dirs even if walker behavior changes.
                dirnames[:] = [
                    dirname for dirname in dirnames
                    if not (root_path / dirname).is_symlink()
                ]

                for filename in filenames:
                    item = root_path / filename
                    if item.is_symlink():
                        continue

                    if item.is_file() and len(matches) < search_limit:
                        if _search_in_file(item, matches):
                            break

        if not matches:
            return ToolResult(output=f"No matches for query '{normalized_query}' under: {path}")

        return ToolResult(output="\n".join(matches))

    async def _append(self, path: str, append_text: str) -> ToolResult:
        """Append text to an existing file with security sanitization."""
        if append_text is None:
            raise ToolError("append_text is required for append command")

        resolved_path = self._validate_path(path)

        if not resolved_path.exists():
            raise ToolError(f"Path does not exist: {path}")

        if resolved_path.is_dir():
            raise ToolError(f"Cannot perform append on directory: {path}")

        sanitized_text = MemoryContentSanitizer.sanitize(append_text, strict=False)
        if sanitized_text != append_text:
            logger.info(f"Memory content sanitized before storage: {path}")

        try:
            with open(resolved_path, 'a', encoding='utf-8') as f:
                f.write(sanitized_text)
            return ToolResult(output=f"Text appended successfully to: {path}")
        except Exception as e:
            raise ToolError(f"Error appending text: {str(e)}")
    
    async def _view(self, path: str, view_range: list[int] = None) -> ToolResult:
        """View directory contents or file contents."""
        resolved_path = self._validate_path(path)

        if not resolved_path.exists():
            return ToolResult(error=f"Path does not exist: {path}")
        
        if resolved_path.is_dir():
            # List directory contents
            try:
                items = []
                for item in sorted(resolved_path.iterdir()):
                    if item.is_dir():
                        items.append(f"[DIR]  {item.name}")
                    else:
                        size = item.stat().st_size
                        items.append(f"[FILE] {item.name} ({size} bytes)")
                
                if items:
                    content = f"Directory: {path}\n" + "\n".join(items)
                else:
                    content = f"Directory: {path}\n(empty)"
                
                return ToolResult(output=content)
            except Exception as e:
                raise ToolError(f"Error reading directory: {str(e)}")
        
        else:
            # Read file contents
            try:
                with open(resolved_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()

                # Apply view range if specified
                if view_range:
                    if len(view_range) != 2:
                        raise ToolError("view_range must be a list of two integers [start, end]")

                    start, end = view_range
                    if start < 1 or start > len(lines):
                        raise ToolError(f"Invalid start line: {start} (file has {len(lines)} lines)")
                    if end > len(lines):
                        raise ToolError(f"Invalid end line: {end} (file has {len(lines)} lines)")

                    # Convert to 0-indexed
                    lines = lines[start-1:end]
                    file_content = ''.join(lines)
                    header = f"File: {path} (lines {start}-{end})\n"
                else:
                    file_content = ''.join(lines)
                    header = f"File: {path}\n"

                # Security: Check for dangerous patterns on read
                # This catches cases where content was injected through external means
                warnings = MemoryContentSanitizer.check_and_warn(file_content)
                if warnings:
                    logger.warning(
                        "Memory file contains potentially dangerous patterns on read: %s - %s",
                        path, warnings
                    )
                    # Add warning header to content so Claude is aware
                    warning_text = "[SECURITY WARNING: This file contains potentially suspicious patterns. Exercise caution.]\n"
                    content = header + warning_text + file_content
                else:
                    content = header + file_content

                return ToolResult(output=content)

            except UnicodeDecodeError:
                return ToolResult(error=f"Cannot read file (not text): {path}")
            except Exception as e:
                raise ToolError(f"Error reading file: {str(e)}")
    
    async def _create(self, path: str, file_text: str) -> ToolResult:
        """Create or overwrite a file with security sanitization."""
        if file_text is None:
            raise ToolError("file_text is required for create command")
        
        resolved_path = self._validate_path(path)
        
        # Security: Sanitize content to prevent prompt injection
        sanitized_text = MemoryContentSanitizer.sanitize(file_text, strict=False)
        
        # Log if content was modified
        if sanitized_text != file_text:
            logger.info(f"Memory content sanitized before storage: {path}")
        
        # Create parent directories if needed
        resolved_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            with open(resolved_path, 'w', encoding='utf-8') as f:
                f.write(sanitized_text)
            
            return ToolResult(output=f"File created successfully: {path}")
        except Exception as e:
            raise ToolError(f"Error creating file: {str(e)}")
    
    async def _str_replace(self, path: str, old_str: str, new_str: str) -> ToolResult:
        """Replace text in a file with security sanitization."""
        if old_str is None:
            raise ToolError("old_str is required for str_replace command")
        if new_str is None:
            new_str = ""  # Allow empty string for deletion
        
        resolved_path = self._validate_path(path)
        
        if not resolved_path.exists():
            raise ToolError(f"File does not exist: {path}")
        
        if resolved_path.is_dir():
            raise ToolError(f"Cannot perform str_replace on directory: {path}")
        
        try:
            # Read file
            with open(resolved_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check if old_str exists
            if old_str not in content:
                raise ToolError(f"String not found in file: {old_str[:50]}...")
            
            # Check for multiple occurrences
            count = content.count(old_str)
            if count > 1:
                raise ToolError(
                    f"String appears {count} times in file. "
                    "Please provide a more specific string that appears only once."
                )
            
            # Security: Sanitize new_str before replacing
            sanitized_new_str = MemoryContentSanitizer.sanitize(new_str, strict=False)
            
            if sanitized_new_str != new_str:
                logger.info(f"Memory replacement content sanitized: {path}")
            
            # Replace with sanitized content
            new_content = content.replace(old_str, sanitized_new_str)
            
            # Write back
            with open(resolved_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            return ToolResult(output=f"Successfully replaced text in: {path}")
        
        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"Error replacing text: {str(e)}")
    
    async def _insert(self, path: str, insert_line: int, insert_text: str) -> ToolResult:
        """Insert text at a specific line."""
        if insert_line is None:
            raise ToolError("insert_line is required for insert command")
        if insert_text is None:
            raise ToolError("insert_text is required for insert command")
        
        resolved_path = self._validate_path(path)
        
        if not resolved_path.exists():
            raise ToolError(f"File does not exist: {path}")
        
        if resolved_path.is_dir():
            raise ToolError(f"Cannot perform insert on directory: {path}")
        
        try:
            # Read file
            with open(resolved_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Validate line number
            if insert_line < 0 or insert_line > len(lines):
                raise ToolError(
                    f"Invalid insert_line: {insert_line} (file has {len(lines)} lines)"
                )
            
            # Insert text
            lines.insert(insert_line, insert_text)
            
            # Write back
            with open(resolved_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
            
            return ToolResult(output=f"Successfully inserted text at line {insert_line} in: {path}")
        
        except ToolError:
            raise
        except Exception as e:
            raise ToolError(f"Error inserting text: {str(e)}")
    
    async def _delete(self, path: str) -> ToolResult:
        """Delete a file or directory."""
        resolved_path = self._validate_path(path)
        
        if not resolved_path.exists():
            raise ToolError(f"Path does not exist: {path}")
        
        # Don't allow deleting the root memories directory
        if resolved_path == self.memories_dir:
            raise ToolError("Cannot delete the root /memories directory")
        
        try:
            if resolved_path.is_dir():
                shutil.rmtree(resolved_path)
                return ToolResult(output=f"Directory deleted successfully: {path}")
            else:
                resolved_path.unlink()
                return ToolResult(output=f"File deleted successfully: {path}")
        
        except Exception as e:
            raise ToolError(f"Error deleting: {str(e)}")
    
    async def _rename(self, old_path: str, new_path: str) -> ToolResult:
        """Rename or move a file/directory."""
        if old_path is None:
            raise ToolError("old_path is required for rename command")
        if new_path is None:
            raise ToolError("new_path is required for rename command")
        
        old_resolved = self._validate_path(old_path)
        new_resolved = self._validate_path(new_path)
        
        if not old_resolved.exists():
            raise ToolError(f"Source path does not exist: {old_path}")
        
        if new_resolved.exists():
            raise ToolError(f"Destination path already exists: {new_path}")
        
        # Don't allow renaming the root memories directory
        if old_resolved == self.memories_dir:
            raise ToolError("Cannot rename the root /memories directory")
        
        try:
            # Create parent directories if needed
            new_resolved.parent.mkdir(parents=True, exist_ok=True)
            
            # Rename/move
            old_resolved.rename(new_resolved)
            
            return ToolResult(output=f"Successfully renamed: {old_path} → {new_path}")
        
        except Exception as e:
            raise ToolError(f"Error renaming: {str(e)}") 
