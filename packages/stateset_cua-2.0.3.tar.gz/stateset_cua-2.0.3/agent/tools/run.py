"""Utility to run shell commands asynchronously with a timeout."""

import asyncio
import contextlib

from agent.security.validator import (
    ToolInputValidator,
    ValidationError,
    get_configured_allowed_commands,
)

TRUNCATED_MESSAGE: str = "<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>"
MAX_RESPONSE_LEN: int = 16000


def maybe_truncate(content: str, truncate_after: int | None = MAX_RESPONSE_LEN):
    """Truncate content and append a notice if content exceeds the specified length."""
    return (
        content
        if not truncate_after or len(content) <= truncate_after
        else content[:truncate_after] + TRUNCATED_MESSAGE
    )


async def run(
    cmd: str,
    timeout: float | None = 120.0,  # seconds
    truncate_after: int | None = MAX_RESPONSE_LEN,
):
    """Run a shell command asynchronously with a timeout."""
    from agent.config import get_config

    validator = ToolInputValidator()
    security_config = getattr(get_config(), "security", None)
    enforce_allowed_commands = bool(
        getattr(security_config, "enforce_command_allowlist", False)
    )
    try:
        validator.validate_command(
            cmd,
            allowed_commands=get_configured_allowed_commands(),
            enforce_allowed_commands=enforce_allowed_commands,
        )
    except ValidationError as exc:
        return (
            1,
            "",
            f"Command blocked: {exc}",
        )
    except Exception as exc:
        return (
            1,
            "",
            f"Invalid command input: {exc}",
        )

    process = await asyncio.create_subprocess_shell(
        cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )

    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
        stdout_text = stdout.decode("utf-8", errors="replace")
        stderr_text = stderr.decode("utf-8", errors="replace")
        return (
            process.returncode or 0,
            maybe_truncate(stdout_text, truncate_after=truncate_after),
            maybe_truncate(stderr_text, truncate_after=truncate_after),
        )
    except asyncio.TimeoutError as exc:
        with contextlib.suppress(ProcessLookupError):
            process.terminate()
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(process.wait(), timeout=1.0)
        with contextlib.suppress(ProcessLookupError, asyncio.TimeoutError):
            process.kill()
            await asyncio.wait_for(process.wait(), timeout=1.0)
        raise TimeoutError(
            f"Command '{cmd}' timed out after {timeout} seconds"
        ) from exc
