"""
Screenshot Optimization Module

Provides advanced screenshot caching, compression, and processing strategies
to significantly improve computer use agent performance.

Key Features:
1. Multi-level caching (memory + disk)
2. Intelligent compression strategies
3. Parallel screenshot processing
4. Differential screenshot analysis
5. Adaptive quality settings
"""

import asyncio
import base64
import hashlib
import io
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Dict, Tuple
from enum import Enum
from agent.base64_utils import safe_base64_decode

logger = logging.getLogger(__name__)

# Attempt to import PIL for advanced processing
try:
    from PIL import Image, ImageChops
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    logger.warning("PIL not available - screenshot optimization features limited")


class CompressionStrategy(Enum):
    """Screenshot compression strategies"""
    HIGH_QUALITY = "high_quality"  # Quality 90, for detailed UI
    BALANCED = "balanced"          # Quality 75, general purpose
    FAST = "fast"                  # Quality 60, for rapid iterations
    MINIMAL = "minimal"            # Quality 40, for text-only interfaces


@dataclass
class ScreenshotMetadata:
    """Metadata for cached screenshots"""
    hash: str
    base64_data: str
    width: int
    height: int
    timestamp: float
    compression_strategy: CompressionStrategy
    size_bytes: int
    hit_count: int = 0


@dataclass
class CacheStatistics:
    """Track cache performance"""
    total_requests: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    total_bytes_saved: int = 0
    total_processing_time_ms: float = 0.0

    @property
    def hit_rate(self) -> float:
        """Calculate cache hit rate"""
        if self.total_requests == 0:
            return 0.0
        return self.cache_hits / self.total_requests

    @property
    def average_processing_time_ms(self) -> float:
        """Calculate average processing time"""
        if self.total_requests == 0:
            return 0.0
        return self.total_processing_time_ms / self.total_requests


class ScreenshotCache:
    """
    Advanced screenshot caching with multiple strategies

    Features:
    - Memory cache with LRU eviction
    - Hash-based deduplication
    - Compression-aware caching
    - Performance metrics
    """

    def __init__(
        self,
        max_memory_items: int = 50,
        max_age_seconds: float = 300.0,
        enable_disk_cache: bool = False,
        disk_cache_dir: Optional[Path] = None
    ):
        self.max_memory_items = max_memory_items
        self.max_age_seconds = max_age_seconds
        self.enable_disk_cache = enable_disk_cache
        self.disk_cache_dir = disk_cache_dir or Path("/tmp/screenshot_cache")

        self._memory_cache: Dict[str, ScreenshotMetadata] = {}
        self._access_order: list[str] = []
        self._statistics = CacheStatistics()

        if self.enable_disk_cache:
            self.disk_cache_dir.mkdir(parents=True, exist_ok=True)

    def get(self, screenshot_hash: str) -> Optional[str]:
        """
        Get screenshot from cache

        Args:
            screenshot_hash: MD5 hash of screenshot

        Returns:
            Base64 encoded screenshot data or None if not found
        """
        start_time = time.time()
        self._statistics.total_requests += 1

        # Check memory cache
        metadata = self._memory_cache.get(screenshot_hash)
        if metadata:
            # Check if expired
            age = time.time() - metadata.timestamp
            if age > self.max_age_seconds:
                self._evict(screenshot_hash)
                self._statistics.cache_misses += 1
                return None

            # Update access order
            if screenshot_hash in self._access_order:
                self._access_order.remove(screenshot_hash)
            self._access_order.append(screenshot_hash)

            metadata.hit_count += 1
            self._statistics.cache_hits += 1
            self._statistics.total_bytes_saved += metadata.size_bytes

            processing_time_ms = (time.time() - start_time) * 1000
            self._statistics.total_processing_time_ms += processing_time_ms

            logger.debug(
                f"Cache HIT: {screenshot_hash[:8]}... "
                f"(hit #{metadata.hit_count}, saved {metadata.size_bytes} bytes)"
            )

            return metadata.base64_data

        # Check disk cache if enabled
        if self.enable_disk_cache:
            disk_path = self.disk_cache_dir / f"{screenshot_hash}.jpg"
            if disk_path.exists():
                try:
                    base64_data = base64.b64encode(disk_path.read_bytes()).decode()
                    # Promote to memory cache
                    self._add_to_memory_cache(
                        screenshot_hash,
                        base64_data,
                        0, 0,  # Width/height unknown from disk
                        CompressionStrategy.BALANCED
                    )
                    self._statistics.cache_hits += 1
                    logger.debug(f"Cache HIT (disk): {screenshot_hash[:8]}...")
                    return base64_data
                except Exception as e:
                    logger.warning(f"Error loading from disk cache: {e}")

        self._statistics.cache_misses += 1
        processing_time_ms = (time.time() - start_time) * 1000
        self._statistics.total_processing_time_ms += processing_time_ms

        logger.debug(f"Cache MISS: {screenshot_hash[:8]}...")
        return None

    def put(
        self,
        screenshot_hash: str,
        base64_data: str,
        width: int,
        height: int,
        strategy: CompressionStrategy = CompressionStrategy.BALANCED
    ):
        """Add screenshot to cache"""
        size_bytes = len(base64_data)

        # Add to memory cache
        self._add_to_memory_cache(screenshot_hash, base64_data, width, height, strategy)

        # Add to disk cache if enabled
        if self.enable_disk_cache:
            try:
                disk_path = self.disk_cache_dir / f"{screenshot_hash}.jpg"
                image_bytes = safe_base64_decode(base64_data)
                if not image_bytes:
                    raise ValueError("Screenshot data could not be decoded")
                disk_path.write_bytes(image_bytes)
            except Exception as e:
                logger.warning(f"Error writing to disk cache: {e}")

        logger.debug(
            f"Cached screenshot: {screenshot_hash[:8]}... "
            f"({size_bytes} bytes, {strategy.value})"
        )

    def _add_to_memory_cache(
        self,
        screenshot_hash: str,
        base64_data: str,
        width: int,
        height: int,
        strategy: CompressionStrategy
    ):
        """Add item to memory cache with LRU eviction"""
        # Evict if at capacity
        while len(self._memory_cache) >= self.max_memory_items:
            if not self._access_order:
                break
            oldest = self._access_order.pop(0)
            self._evict(oldest)

        metadata = ScreenshotMetadata(
            hash=screenshot_hash,
            base64_data=base64_data,
            width=width,
            height=height,
            timestamp=time.time(),
            compression_strategy=strategy,
            size_bytes=len(base64_data)
        )

        self._memory_cache[screenshot_hash] = metadata
        self._access_order.append(screenshot_hash)

    def _evict(self, screenshot_hash: str):
        """Evict item from cache"""
        if screenshot_hash in self._memory_cache:
            del self._memory_cache[screenshot_hash]
        if screenshot_hash in self._access_order:
            self._access_order.remove(screenshot_hash)

    def clear(self):
        """Clear all caches"""
        self._memory_cache.clear()
        self._access_order.clear()

        if self.enable_disk_cache and self.disk_cache_dir.exists():
            for file in self.disk_cache_dir.glob("*.jpg"):
                file.unlink()

    def get_statistics(self) -> Dict:
        """Get cache statistics"""
        return {
            "total_requests": self._statistics.total_requests,
            "cache_hits": self._statistics.cache_hits,
            "cache_misses": self._statistics.cache_misses,
            "hit_rate": f"{self._statistics.hit_rate:.1%}",
            "total_bytes_saved": self._statistics.total_bytes_saved,
            "average_processing_time_ms": f"{self._statistics.average_processing_time_ms:.2f}",
            "memory_cache_size": len(self._memory_cache),
            "total_cached_bytes": sum(m.size_bytes for m in self._memory_cache.values())
        }


class ScreenshotOptimizer:
    """
    Advanced screenshot optimization

    Features:
    - Adaptive compression based on content
    - Parallel processing
    - Differential analysis
    - Smart caching
    """

    def __init__(self, cache: Optional[ScreenshotCache] = None):
        self.cache = cache or ScreenshotCache()

    def get_compression_quality(self, strategy: CompressionStrategy) -> int:
        """Get JPEG quality for compression strategy"""
        quality_map = {
            CompressionStrategy.HIGH_QUALITY: 90,
            CompressionStrategy.BALANCED: 75,
            CompressionStrategy.FAST: 60,
            CompressionStrategy.MINIMAL: 40
        }
        return quality_map[strategy]

    async def process_screenshot(
        self,
        screenshot_bytes: bytes,
        strategy: CompressionStrategy = CompressionStrategy.BALANCED,
        target_width: Optional[int] = None,
        target_height: Optional[int] = None
    ) -> Tuple[str, str]:
        """
        Process screenshot with optimizations

        Args:
            screenshot_bytes: Raw screenshot bytes
            strategy: Compression strategy
            target_width: Optional target width for scaling
            target_height: Optional target height for scaling

        Returns:
            Tuple of (hash, base64_encoded_data)
        """
        # Calculate hash
        screenshot_hash = hashlib.md5(screenshot_bytes).hexdigest()

        # Check cache
        cached = self.cache.get(screenshot_hash)
        if cached:
            return (screenshot_hash, cached)

        # Process screenshot
        if not PIL_AVAILABLE:
            # Fallback: just encode
            encoded = base64.b64encode(screenshot_bytes).decode()
            self.cache.put(screenshot_hash, encoded, 0, 0, strategy)
            return (screenshot_hash, encoded)

        # Use PIL for optimization
        img = Image.open(io.BytesIO(screenshot_bytes))
        width, height = img.size

        # Resize if needed
        if target_width and target_height:
            if width != target_width or height != target_height:
                img = img.resize((target_width, target_height), Image.Resampling.LANCZOS)
                width, height = target_width, target_height

        # Compress
        buffer = io.BytesIO()
        quality = self.get_compression_quality(strategy)
        img.convert("RGB").save(buffer, "JPEG", quality=quality, optimize=True)
        encoded = base64.b64encode(buffer.getvalue()).decode()

        # Cache
        self.cache.put(screenshot_hash, encoded, width, height, strategy)

        return (screenshot_hash, encoded)

    def detect_content_type(self, img: 'Image.Image') -> CompressionStrategy:
        """
        Detect optimal compression strategy based on content

        Analyzes screenshot to determine if it's:
        - Text-heavy (use minimal compression)
        - Detailed UI (use high quality)
        - General purpose (use balanced)
        """
        if not PIL_AVAILABLE:
            return CompressionStrategy.BALANCED

        # Convert to grayscale for analysis
        gray = img.convert('L')

        # Calculate edge density (high = detailed UI)
        # Simple edge detection using standard deviation
        import statistics
        pixels = list(gray.getdata())
        std_dev = statistics.stdev(pixels) if len(pixels) > 1 else 0

        # High variance = detailed UI, use high quality
        if std_dev > 60:
            return CompressionStrategy.HIGH_QUALITY
        # Low variance = text/simple UI, can use minimal
        elif std_dev < 30:
            return CompressionStrategy.MINIMAL
        else:
            return CompressionStrategy.BALANCED


# Global screenshot optimizer instance
_global_optimizer: Optional[ScreenshotOptimizer] = None


def get_screenshot_optimizer() -> ScreenshotOptimizer:
    """Get global screenshot optimizer instance"""
    global _global_optimizer
    if _global_optimizer is None:
        _global_optimizer = ScreenshotOptimizer()
    return _global_optimizer
