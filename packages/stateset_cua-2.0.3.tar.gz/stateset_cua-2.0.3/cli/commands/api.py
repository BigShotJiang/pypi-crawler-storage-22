"""API command group - direct Claude API access."""

from __future__ import annotations

import json
import os
from typing import Optional

import typer

from cli._console import get_console, is_json_mode
from cli._errors import print_error
from cli._output import format_cost, format_tokens, output, rich_table

api_app = typer.Typer(name="api", help="Direct Claude API access")


def _get_api_key() -> str:
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        print_error("ANTHROPIC_API_KEY not set.")
        raise typer.Exit(1)
    return key


@api_app.command("messages")
def api_messages(
    prompt: str = typer.Argument(..., help="Message to send"),
    model: str = typer.Option("claude-opus-4-6", "--model", "-m", help="Model ID"),
    max_tokens: int = typer.Option(1024, "--max-tokens", help="Max output tokens"),
    system: Optional[str] = typer.Option(None, "--system", "-s", help="System prompt"),
) -> None:
    """Send a message to the Claude API."""
    try:
        import anthropic
    except ImportError:
        print_error("anthropic package not installed", details="pip install anthropic")
        raise typer.Exit(1)

    console = get_console()
    client = anthropic.Anthropic(api_key=_get_api_key())

    kwargs = {
        "model": model,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    }
    if system:
        kwargs["system"] = system

    if not is_json_mode():
        console.print(f"[dim]Sending to {model}...[/dim]")

    try:
        response = client.messages.create(**kwargs)
        text = response.content[0].text if response.content else ""
        result = {
            "model": response.model,
            "text": text,
            "input_tokens": response.usage.input_tokens,
            "output_tokens": response.usage.output_tokens,
            "stop_reason": response.stop_reason,
        }

        if is_json_mode():
            output(result)
        else:
            from rich.panel import Panel
            from rich.markdown import Markdown
            console.print(Panel(Markdown(text), title=f"Response ({response.model})", border_style="cyan"))
            console.print(f"[dim]Tokens: {response.usage.input_tokens} in / {response.usage.output_tokens} out[/dim]")

    except Exception as e:
        print_error(f"API call failed: {e}")
        raise typer.Exit(1)


@api_app.command("models")
def api_models() -> None:
    """List available Claude models."""
    models = [
        {"id": "claude-opus-4-6", "name": "Claude Opus 4.6", "tier": "flagship"},
        {"id": "claude-sonnet-4-5-20241022", "name": "Claude Sonnet 4.5", "tier": "balanced"},
        {"id": "claude-haiku-4-5-20241022", "name": "Claude Haiku 4.5", "tier": "fast"},
    ]

    if is_json_mode():
        output(models)
        return

    headers = ["Model ID", "Name", "Tier"]
    rows = [[m["id"], m["name"], m["tier"]] for m in models]
    rich_table(headers, rows, title="Available Models")


@api_app.command("usage")
def api_usage() -> None:
    """Show API usage summary from local metrics."""
    from cli._config import get_state_dir

    metrics_path = get_state_dir() / "metrics.json"
    if not metrics_path.exists():
        output({"message": "No usage data."}, human_format="[dim]No usage data found.[/dim]")
        return

    try:
        data = json.loads(metrics_path.read_text())
    except (json.JSONDecodeError, IOError):
        data = {}

    total_in = data.get("total_input_tokens", 0)
    total_out = data.get("total_output_tokens", 0)
    cost = data.get("total_cost", 0.0)

    result = {
        "input_tokens": total_in,
        "output_tokens": total_out,
        "total_tokens": total_in + total_out,
        "estimated_cost": cost,
    }

    if is_json_mode():
        output(result)
        return

    from rich.panel import Panel
    lines = [
        f"[bold]Input tokens:[/bold] {format_tokens(total_in)}",
        f"[bold]Output tokens:[/bold] {format_tokens(total_out)}",
        f"[bold]Total tokens:[/bold] {format_tokens(total_in + total_out)}",
        f"[bold]Estimated cost:[/bold] {format_cost(cost)}",
    ]
    get_console().print(Panel("\n".join(lines), title="API Usage", border_style="cyan"))


@api_app.command("limits")
def api_limits() -> None:
    """Show API rate limits and pricing."""
    limits = {
        "models": {
            "claude-opus-4-6": {"input_per_1m": "$3.00", "output_per_1m": "$15.00", "cached_per_1m": "$0.30", "context_window": "200K"},
            "claude-sonnet-4-5": {"input_per_1m": "$3.00", "output_per_1m": "$15.00", "cached_per_1m": "$0.30", "context_window": "200K"},
            "claude-haiku-4-5": {"input_per_1m": "$0.80", "output_per_1m": "$4.00", "cached_per_1m": "$0.08", "context_window": "200K"},
        },
    }

    if is_json_mode():
        output(limits)
        return

    headers = ["Model", "Input/1M", "Output/1M", "Cached/1M", "Context"]
    rows = []
    for model, info in limits["models"].items():
        rows.append([model, info["input_per_1m"], info["output_per_1m"], info["cached_per_1m"], info["context_window"]])
    rich_table(headers, rows, title="API Pricing & Limits")
