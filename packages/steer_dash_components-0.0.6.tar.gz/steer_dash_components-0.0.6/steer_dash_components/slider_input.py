# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component, _explicitize_args

ComponentType = typing.Union[
    str,
    int,
    float,
    Component,
    None,
    typing.Sequence[typing.Union[str, int, float, Component, None]],
]

NumberType = typing.Union[
    typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex
]


class slider_input(Component):
    """A slider_input component.
SliderInput is a component that combines a slider and number input.
They share the same value and stay synchronized.
It takes properties for value, min, max, step, and markers.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- action_button (boolean; default False):
    If True, displays an action button next to the number input.

- action_button_text (string; default 'Apply'):
    Text to display on the action button (only used when action_button
    is True).

- drag_value (number; default 0):
    The value during slider dragging (updates in real-time). Use this
    for live feedback while the user drags the slider.

- in_row (boolean; default False):
    If True, arranges title, slider, and input in a single row. If
    False, arranges them vertically (default layout).

- max (number; default 100):
    The maximum value of the slider.

- message (string; optional):
    Optional message text to display between title and slider.

- min (number; default 0):
    The minimum value of the slider.

- n_clicks (number; default 0):
    Number of times the action button has been clicked. This
    increments each time the button is clicked.

- step (number; optional):
    The step size for the slider and input. If not provided, will be
    calculated automatically based on the range: - Ranges < 100: step
    = 0.01 - Ranges 100-999: step = 0.1 - Ranges 1000+: step = 1.0.

- title (string; optional):
    Title text to display above the slider (left-aligned).

- value (number; default 0):
    The current value of the slider and input."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'steer_dash_components'
    _type = 'slider_input'


    def __init__(
        self,
        id: typing.Optional[typing.Union[str, dict]] = None,
        value: typing.Optional[NumberType] = None,
        drag_value: typing.Optional[NumberType] = None,
        min: typing.Optional[NumberType] = None,
        max: typing.Optional[NumberType] = None,
        step: typing.Optional[NumberType] = None,
        title: typing.Optional[str] = None,
        message: typing.Optional[str] = None,
        in_row: typing.Optional[bool] = None,
        action_button: typing.Optional[bool] = None,
        action_button_text: typing.Optional[str] = None,
        n_clicks: typing.Optional[NumberType] = None,
        style: typing.Optional[typing.Any] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'action_button', 'action_button_text', 'drag_value', 'in_row', 'max', 'message', 'min', 'n_clicks', 'step', 'style', 'title', 'value']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'action_button', 'action_button_text', 'drag_value', 'in_row', 'max', 'message', 'min', 'n_clicks', 'step', 'style', 'title', 'value']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(slider_input, self).__init__(**args)

setattr(slider_input, "__init__", _explicitize_args(slider_input.__init__))
