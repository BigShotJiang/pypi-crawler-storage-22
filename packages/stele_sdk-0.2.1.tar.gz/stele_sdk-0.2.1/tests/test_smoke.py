import json
import os
import sys
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from stele_sdk import APIError, SteleClient


class RecordingHandler(BaseHTTPRequestHandler):
    last_health = None
    last_query = None
    last_protect = None
    last_supersede = None
    last_forget = None
    last_stats = None
    last_bulk_forget_auth = None
    last_export_auth = None
    last_token_mint_auth = None
    last_token_revoke_auth = None
    last_token_mint = None
    last_token_revoke = None
    last_suggest = None
    suggest_payloads = []
    last_watch_query = None

    def log_message(self, format, *args):
        return

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length == 0:
            return None
        raw = self.rfile.read(length)
        if not raw:
            return None
        return json.loads(raw.decode("utf-8"))

    def _send_json(self, status_code, payload):
        encoded = json.dumps(payload).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/memory.health":
            payload = self._read_json()
            RecordingHandler.last_health = payload
            response = {
                "meta": {
                    "api_version": "v1",
                    "request_id": "req-test",
                    "timestamp_ms": int(time.time() * 1000),
                },
                "status": "HEALTH_STATUS_SERVING",
            }
            self._send_json(200, response)
            return
        if parsed.path == "/memory.stats":
            payload = self._read_json()
            RecordingHandler.last_stats = payload
            meta = (payload or {}).get("meta") or {}
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                },
                "stats": {"total_memories": 0},
            }
            self._send_json(200, response)
            return
        if parsed.path == "/v1/stream":
            RecordingHandler.last_watch_query = parse_qs(parsed.query)
            body = "\n".join(
                [
                    "id: 11",
                    "event: MEMORY_EVENT_WRITE",
                    'data: {"timestamp_ms":1010,"memory_id":"mem-1"}',
                    "",
                    "id: 12",
                    "event: MEMORY_EVENT_HEARTBEAT",
                    'data: {"timestamp_ms":1011}',
                    "",
                    "id: 13",
                    "event: MEMORY_EVENT_UPDATE",
                    'data: {"timestamp_ms":1012,"memory_id":"mem-2"}',
                    "",
                ]
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        payload = self._read_json()
        meta = (payload or {}).get("meta") or {}
        if self.path == "/memory.query":
            RecordingHandler.last_query = payload
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                },
                "memories": [],
                "abstain_reason": "",
            }
            self._send_json(200, response)
            return
        if self.path == "/memory.suggest":
            RecordingHandler.last_suggest = payload
            RecordingHandler.suggest_payloads.append(payload)
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                },
                "suggestions": [],
            }
            self._send_json(200, response)
            return
        if self.path == "/memory.protect":
            RecordingHandler.last_protect = payload
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                }
            }
            self._send_json(200, response)
            return
        if self.path == "/memory.supersede":
            RecordingHandler.last_supersede = payload
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                }
            }
            self._send_json(200, response)
            return
        if self.path == "/memory.forget":
            RecordingHandler.last_forget = payload
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                },
                "deleted": True,
            }
            self._send_json(200, response)
            return
        if self.path == "/memory.bulk.forget":
            RecordingHandler.last_bulk_forget_auth = self.headers.get("Authorization")
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                },
                "result": {
                    "timestamp_ms": int(time.time() * 1000),
                    "dry_run": False,
                    "items": [],
                    "summary": {"deleted": 0, "failed": 0},
                },
            }
            self._send_json(200, response)
            return
        if self.path == "/memory.export":
            RecordingHandler.last_export_auth = self.headers.get("Authorization")
            body = (
                '{"kind":"stele_export","schema_version":"v1","exported_at_ms":1,"include_deleted":false,"counts":{"memories":0,"edges":0},"meta":{"api_version":"v1","request_id":"req-test","timestamp_ms":1}}\n'
            )
            encoded = body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)
            return
        if self.path == "/memory.auth.token.mint":
            if not self.headers.get("Authorization"):
                self._send_json(
                    401,
                    {
                        "code": "ERROR_CODE_AUTH_REQUIRED",
                        "message": "ops auth required",
                    },
                )
                return
            RecordingHandler.last_token_mint_auth = self.headers.get("Authorization")
            RecordingHandler.last_token_mint = payload
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                },
                "token": "managed-token",
            }
            self._send_json(200, response)
            return
        if self.path == "/memory.auth.token.revoke":
            if not self.headers.get("Authorization"):
                self._send_json(
                    401,
                    {
                        "code": "ERROR_CODE_AUTH_REQUIRED",
                        "message": "ops auth required",
                    },
                )
                return
            RecordingHandler.last_token_revoke_auth = self.headers.get("Authorization")
            RecordingHandler.last_token_revoke = payload
            response = {
                "meta": {
                    "api_version": meta.get("api_version", "v1"),
                    "request_id": meta.get("request_id", "req-test"),
                    "timestamp_ms": int(time.time() * 1000),
                },
                "revoked": True,
            }
            self._send_json(200, response)
            return
        self.send_response(404)
        self.end_headers()


class StelePythonSmokeTest(unittest.TestCase):
    def test_health_and_query(self):
        server = HTTPServer(("127.0.0.1", 0), RecordingHandler)
        thread = threading.Thread(target=server.serve_forever)
        thread.daemon = True
        thread.start()

        try:
            base_url = f"http://127.0.0.1:{server.server_port}"
            client = SteleClient(base_url=base_url, agent_id="agent-1", session_id="sess-1")
            health = client.health()
            self.assertEqual(health["status"], "HEALTH_STATUS_SERVING")

            query = client.query(
                {
                    "query_text": "hello",
                    "budget_tokens": 10,
                    "scope_order": ["SCOPE_AGENT"],
                }
            )
            self.assertEqual(query["abstain_reason"], "")

            suggest = client.suggest(
                {
                    "active_files": ["/repo/src/auth/handler.go"],
                    "scope_ref": "team-1",
                    "limit": 5,
                }
            )
            self.assertIsInstance(suggest.get("suggestions"), list)
            self.assertIsNotNone(RecordingHandler.last_suggest)
            self.assertEqual(RecordingHandler.last_suggest.get("limit"), 5)

            now_ms = 1700000000000

            def now_provider():
                return now_ms

            suggestor = client.create_proactive_suggestor(now_ms=now_provider)
            proactive_first = suggestor.trigger(
                "context_shift",
                {
                    "active_files": [" /repo/src/auth/handler.go ", "/repo/src/AUTH/HANDLER.go "],
                    "active_symbols": ["AuthHandler", "authhandler"],
                    "recent_commands": ["plan:review", "PLAN:REVIEW"],
                    "scope_order": ["SCOPE_AGENT", "scope_agent"],
                    "scope_ref": " Team-1 ",
                },
            )
            self.assertTrue(proactive_first.get("triggered"))
            self.assertEqual(proactive_first.get("reason"), "triggered")
            self.assertEqual((proactive_first.get("payload") or {}).get("agent_id"), "agent-1")
            self.assertEqual((proactive_first.get("payload") or {}).get("session_id"), "sess-1")

            now_ms += 21000
            proactive_same_context = suggestor.trigger(
                "context_shift",
                {
                    "active_files": ["/repo/src/auth/handler.go"],
                    "active_symbols": ["authhandler"],
                    "recent_commands": ["plan:review"],
                    "scope_order": ["scope_agent"],
                    "scope_ref": "team-1",
                },
            )
            self.assertFalse(proactive_same_context.get("triggered"))
            self.assertEqual(proactive_same_context.get("reason"), "unchanged_context")

            now_ms += 21000
            proactive_bootstrap = suggestor.trigger("bootstrap", {"active_files": ["/repo/src/new/file.go"]})
            self.assertTrue(proactive_bootstrap.get("triggered"))
            self.assertIn(
                "bootstrap:health-capabilities-context-get",
                (proactive_bootstrap.get("payload") or {}).get("recent_commands") or [],
            )

            watch = client.watch({"scope": "SCOPE_AGENT", "limit": 2, "timeout_ms": 1000})
            self.assertIsInstance(watch.get("events"), list)
            self.assertEqual(len(watch.get("events") or []), 2)
            self.assertEqual(watch["events"][0]["event"], "MEMORY_EVENT_WRITE")
            self.assertEqual(watch.get("next_cursor_id"), 13)
            self.assertEqual(watch.get("next_cursor_timestamp_ms"), 1012)

            protect = client.protect({"memory_id": "mem-1", "protected_flag": True})
            self.assertIn("meta", protect)

            supersede = client.supersede(
                {
                    "supersedes_id": "mem-1",
                    "superseding_id": "mem-2",
                    "reason": "cleanup",
                }
            )
            self.assertIn("meta", supersede)

            forget = client.forget({"memory_id": "mem-1", "hard_delete": False})
            self.assertTrue(forget.get("deleted"))

            stats = client.stats({"limit": 5, "include_recent": True})
            self.assertIn("stats", stats)

            with self.assertRaisesRegex(APIError, "ops auth required"):
                client.auth_token_mint({"agent_id": "agent-1", "session_id": "sess-1"})
            with self.assertRaisesRegex(APIError, "ops auth required"):
                client.auth_token_revoke({"token": "managed-token"})

            # Ops-auth header should be attached when token is configured.
            ops_client = SteleClient(
                base_url=base_url,
                agent_id="agent-1",
                session_id="sess-1",
                ops_auth_token="ops-secret",
            )
            minted = ops_client.auth_token_mint(
                {
                    "agent_id": "agent-1",
                    "session_id": "sess-1",
                    "tenant_id": "tenant-a",
                }
            )
            self.assertEqual(minted.get("token"), "managed-token")
            revoked = ops_client.auth_token_revoke({"token": minted.get("token")})
            self.assertTrue(revoked.get("revoked"))
            ops_client.bulk_forget({"ids": ["mem-1"]})
            self.assertEqual(RecordingHandler.last_bulk_forget_auth, "Bearer ops-secret")

            exported = ops_client.export_ndjson({})
            self.assertIn('"kind":"stele_export"', exported)
            self.assertEqual(RecordingHandler.last_export_auth, "Bearer ops-secret")

            self.assertIsNotNone(RecordingHandler.last_query)
            self.assertIsNone(RecordingHandler.last_health)
            self.assertEqual(RecordingHandler.last_query["query_text"], "hello")
            self.assertGreaterEqual(len(RecordingHandler.suggest_payloads), 3)
            self.assertIsNotNone(RecordingHandler.last_watch_query)
            self.assertEqual(RecordingHandler.last_watch_query.get("agent_id"), ["agent-1"])
            self.assertEqual(RecordingHandler.last_watch_query.get("scope"), ["SCOPE_AGENT"])
            self.assertIsNotNone(RecordingHandler.last_protect)
            self.assertIsNotNone(RecordingHandler.last_supersede)
            self.assertIsNotNone(RecordingHandler.last_forget)
            self.assertIsNotNone(RecordingHandler.last_stats)
            self.assertEqual(RecordingHandler.last_token_mint_auth, "Bearer ops-secret")
            self.assertEqual(RecordingHandler.last_token_revoke_auth, "Bearer ops-secret")
            self.assertIsNotNone(RecordingHandler.last_token_mint)
            self.assertEqual(RecordingHandler.last_token_mint.get("agent_id"), "agent-1")
            self.assertEqual(RecordingHandler.last_token_mint.get("session_id"), "sess-1")
            self.assertEqual(RecordingHandler.last_token_mint.get("tenant_id"), "tenant-a")
            self.assertIsNotNone(RecordingHandler.last_token_revoke)
            self.assertEqual(RecordingHandler.last_token_revoke.get("token"), "managed-token")
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_watch_validates_required_params(self):
        client = SteleClient(base_url="http://127.0.0.1:65535")
        with self.assertRaisesRegex(ValueError, "agent_id is required"):
            client.watch({"scope": "SCOPE_AGENT"})
        with self.assertRaisesRegex(ValueError, "scope_ref must match scope count"):
            client.watch(
                {
                    "agent_id": "agent-1",
                    "scopes": ["SCOPE_AGENT", "SCOPE_TEAM"],
                    "scope_refs": ["team-1"],
                }
            )
        with self.assertRaisesRegex(ValueError, "scope_ref must match scope count"):
            client.watch(
                {
                    "agent_id": "agent-1",
                    "scopes": ["SCOPE_AGENT", "SCOPE_TEAM"],
                    "scope_ref": "team-1",
                }
            )
        with self.assertRaisesRegex(ValueError, "invalid start_from"):
            client.watch({"agent_id": "agent-1", "scope": "SCOPE_AGENT", "start_from": "invalid"})


if __name__ == "__main__":
    unittest.main()
