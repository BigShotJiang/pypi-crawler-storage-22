"""Internal packaging utilities for AWS Lambda."""
