"""
CLI: Test AVI-based reconstruction by splitting a raw stereo AVI into left/right AVI
and running caliscope reconstruction on the resulting recording directory.
"""
from __future__ import annotations

import argparse
import logging
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from .calibration_ui import CalibConfig
from .config import load_yaml_config

logger = logging.getLogger(__name__)


def _resolve_config(path: Optional[str]) -> CalibConfig:
    if path:
        p = Path(path)
        if not p.is_absolute():
            p = Path.cwd() / p
        return CalibConfig.from_yaml(p)
    from .paths import resolve_default_config
    return CalibConfig.from_yaml(resolve_default_config())


def _find_latest_avi(raw_output_dir: Path) -> Optional[Path]:
    if not raw_output_dir.exists():
        return None
    avis = sorted(raw_output_dir.glob("*.avi"), key=lambda p: p.stat().st_mtime, reverse=True)
    return avis[0] if avis else None


def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    ap = argparse.ArgumentParser(description="Test AVI-based reconstruction")
    ap.add_argument("--project-dir", type=str, required=False, help="Path to project dir (must contain camera_array.toml)")
    ap.add_argument("--raw-avi", type=str, default=None, help="Path to raw AVI (default: latest in project/raw_output)")
    ap.add_argument("--recording-name", type=str, default=None, help="Recording name under recordings/ (default: avi_test_YYYYMMDD_HHMMSS)")
    ap.add_argument("--config", type=str, default=None, help="Path to config YAML (for split params)")
    ap.add_argument("--ffmpeg", type=str, default=None, help="Override ffmpeg executable path")
    ap.add_argument("--tracker", type=str, default="HOLISTIC", help="Tracker name (HOLISTIC/POSE/HAND/YOLOV8_POSE)")
    ap.add_argument("--fps-target", type=int, default=10, help="Target FPS for detection")
    ap.add_argument("--model-size", type=str, default="n", help="YOLOv8 model size (n/s/m) if using YOLOV8_POSE")
    ap.add_argument("--imgsz", type=int, default=480, help="YOLOv8 inference size if using YOLOV8_POSE")
    args = ap.parse_args()

    raw_avi = Path(args.raw_avi) if args.raw_avi else None
    if raw_avi and not raw_avi.exists():
        raise SystemExit(f"raw AVI not found: {raw_avi}")

    def _infer_project_dir(p: Path) -> Optional[Path]:
        cur = p.resolve()
        for _ in range(6):
            if (cur / "camera_array.toml").exists():
                return cur
            cur = cur.parent
        return None

    if args.project_dir:
        project_dir = Path(args.project_dir)
    elif raw_avi:
        project_dir = _infer_project_dir(raw_avi.parent)
    else:
        raise SystemExit("Provide --project-dir or --raw-avi.")

    if not project_dir or not project_dir.exists():
        raise SystemExit(f"Project dir not found: {project_dir}")
    if not (project_dir / "camera_array.toml").exists():
        raise SystemExit("camera_array.toml not found. Run calibration first.")

    cfg = _resolve_config(args.config)
    if args.ffmpeg:
        cfg.ffmpeg_exe = args.ffmpeg

    if raw_avi is None:
        raw_avi = _find_latest_avi(project_dir / "raw_output")
    if not raw_avi or not raw_avi.exists():
        raise SystemExit("raw AVI not found. Provide --raw-avi or place one in project/raw_output.")

    rec_name = args.recording_name or f"avi_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    rec_dir = project_dir / "recordings" / rec_name
    rec_dir.mkdir(parents=True, exist_ok=True)

    left_avi = rec_dir / "port_1.avi"
    right_avi = rec_dir / "port_2.avi"

    # Split raw AVI into left/right AVI (MJPEG)
    left_crop = f"crop={cfg.xsplit}:{cfg.full_h}:0:0"
    right_crop = f"crop={cfg.full_w - cfg.xsplit}:{cfg.full_h}:{cfg.xsplit}:0"

    ffmpeg = cfg.ffmpeg_exe or "ffmpeg"

    cmd_left = [
        ffmpeg, "-hide_banner", "-y",
        "-i", str(raw_avi),
        "-vf", left_crop,
        "-c:v", "mjpeg",
        str(left_avi),
    ]
    cmd_right = [
        ffmpeg, "-hide_banner", "-y",
        "-i", str(raw_avi),
        "-vf", right_crop,
        "-c:v", "mjpeg",
        str(right_avi),
    ]

    logger.info("Splitting raw AVI into left/right AVI...")
    subprocess.check_call(cmd_left)
    subprocess.check_call(cmd_right)

    # Run reconstruction
    # NOTE: caliscope expects port_*.mp4 by default; for AVI-only testing,
    # redirect mp4 lookups to existing avi files.
    import caliscope.recording.video_utils as video_utils
    _orig_read_video_properties = video_utils.read_video_properties

    def _read_video_properties_avi_only(source_path):
        if str(source_path).lower().endswith(".mp4"):
            alt = Path(str(source_path)).with_suffix(".avi")
            if alt.exists():
                source_path = alt
        return _orig_read_video_properties(source_path)

    video_utils.read_video_properties = _read_video_properties_avi_only

    from .auto_calibrate import run_auto_reconstruction

    logger.info("Running reconstruction from AVI inputs...")
    out = run_auto_reconstruction(
        project_dir=project_dir,
        recording_name=rec_name,
        tracker_name=args.tracker,
        fps_target=args.fps_target,
        model_size=args.model_size,
        imgsz=args.imgsz,
    )

    logger.info("Reconstruction complete: %s", out)


if __name__ == "__main__":
    main()
