from .core import StickersDownloader

__version__ = "0.2.0"
__all__ = ["StickersDownloader"]