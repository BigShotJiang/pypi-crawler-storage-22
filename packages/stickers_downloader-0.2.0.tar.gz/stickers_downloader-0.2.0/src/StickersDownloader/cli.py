import argparse
import asyncio
from .core import StickersDownloader
from .utils import console


def main():
    parser = argparse.ArgumentParser(description="Telegram Sticker Pack Downloader")
    parser.add_argument("token", help="Bot token")
    parser.add_argument("link", help="Sticker pack link")
    parser.add_argument("type", choices=["static", "animated"], help="static (webp) / animated (tgs+gif)")
    parser.add_argument("--fps", type=int, default=30, help="FPS for GIF conversion (default: 30)")
    parser.add_argument("--indexes", type=str, help="Comma-separated sticker indexes (e.g. 0,2,5)")

    args = parser.parse_args()

    selected = None
    if args.indexes:
        selected = [int(i.strip()) for i in args.indexes.split(",") if i.strip().isdigit()]

    downloader = StickersDownloader(
        token=args.token,
        pack_link=args.link,
        sticker_type=args.type,
        fps=args.fps
    )

    asyncio.run(downloader.run(selected_indexes=selected))


if __name__ == "__main__":
    main()