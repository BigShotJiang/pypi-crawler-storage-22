from .utils import load_lottie_auto, console
import asyncio


class TgsToGifConverter:
    def __init__(self, fps: int = 30):
        self.fps = fps

    async def convert(self, tgs_path: str, gif_path: str):
        try:
            anim = load_lottie_auto(tgs_path)
            anim.save_animation(gif_path, self.fps)
        except Exception as e:
            console.print(f"[red]❌ Convert failed {tgs_path}: {e}[/red]")