import gzip
from rich.console import Console
from rlottie_python import LottieAnimation

console = Console()


def load_lottie_auto(path: str):
    with open(path, "rb") as f:
        data = f.read()

    if data[:2] == b"\x1f\x8b":
        return LottieAnimation.from_tgs(path)

    try:
        return LottieAnimation.from_json(data.decode("utf-8"))
    except:
        pass

    try:
        txt = gzip.decompress(data).decode("utf-8")
        return LottieAnimation.from_json(txt)
    except:
        pass

    try:
        idx = data.find(b"{")
        if idx != -1:
            txt = data[idx:].decode("utf-8")
            return LottieAnimation.from_json(txt)
    except Exception as e:
        raise Exception(f"Fallback failed: {e}")

    raise Exception(f"Invalid TGS/JSON: {path}")