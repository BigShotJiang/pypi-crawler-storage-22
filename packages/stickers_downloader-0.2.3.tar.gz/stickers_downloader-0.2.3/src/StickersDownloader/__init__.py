from .core import StickersDownloader

__version__ = "0.2.2"
__all__ = ["StickersDownloader"]