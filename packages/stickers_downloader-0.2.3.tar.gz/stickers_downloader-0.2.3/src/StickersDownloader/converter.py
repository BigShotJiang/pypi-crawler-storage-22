import os
from .utils import load_lottie_auto, is_rlottie_available, console, get_available_methods
import asyncio
import traceback


class TgsToGifConverter:
    def __init__(self, fps: int = 30):
        self.fps = fps
        self.available = is_rlottie_available()
        
        if not self.available:
            console.print("[yellow]⚠️ TGS to GIF conversion disabled (rlottie-python not installed)[/yellow]")
        else:
            methods = get_available_methods()
            if methods:
                console.print(f"[dim]Available rlottie methods: {', '.join(methods)}[/dim]")

    async def convert(self, tgs_path: str, gif_path: str):
        if not self.available:
            console.print(f"[yellow]⚠️ Skipping conversion (rlottie not available): {os.path.basename(tgs_path)}[/yellow]")
            return False
        
        try:
            # Try to load and convert
            anim = load_lottie_auto(tgs_path)
            
            # Check which save method is available
            if hasattr(anim, 'save_animation'):
                anim.save_animation(gif_path, self.fps)
            elif hasattr(anim, 'save_gif'):
                anim.save_gif(gif_path, self.fps)
            else:
                # Try to find any save method
                save_methods = [m for m in dir(anim) if 'save' in m.lower() and 'gif' in m.lower()]
                if save_methods:
                    method = getattr(anim, save_methods[0])
                    method(gif_path, self.fps)
                else:
                    raise Exception("No save method found in animation object")
            
            console.print(f"[green]✓ Converted: {os.path.basename(tgs_path)} -> {os.path.basename(gif_path)}[/green]")
            return True
            
        except Exception as e:
            console.print(f"[red]❌ Convert failed {os.path.basename(tgs_path)}: {e}[/red]")
            return False