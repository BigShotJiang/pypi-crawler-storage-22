import gzip
import json
from rich.console import Console

console = Console()

# Try to import rlottie with different possible names and methods
try:
    from rlottie_python import LottieAnimation
    RLOTTIE_AVAILABLE = True
except ImportError:
    try:
        from rlottie import LottieAnimation
        RLOTTIE_AVAILABLE = True
    except ImportError:
        RLOTTIE_AVAILABLE = False
        console.print("[yellow]⚠️ rlottie-python not installed. TGS to GIF conversion will be disabled.[/yellow]")
        LottieAnimation = None


def _get_available_methods():
    if not RLOTTIE_AVAILABLE or LottieAnimation is None:
        return []
    
    methods = []
    
    possible_methods = [
        'from_tgs', 'from_data', 'from_string', 'from_json', 
        'from_file', 'from_dict', 'lottie_animation_from_data',
        'lottie_animation_from_file', 'load', 'load_from_data'
    ]
    
    for method_name in possible_methods:
        if hasattr(LottieAnimation, method_name):
            methods.append(method_name)
    
    return methods


def load_lottie_auto(path: str):
    if not RLOTTIE_AVAILABLE or LottieAnimation is None:
        raise ImportError("rlottie-python is not installed")
    
    with open(path, "rb") as f:
        data = f.read()
    
    is_gzipped = data[:2] == b"\x1f\x8b"
    
    available_methods = _get_available_methods()
    
    if is_gzipped and 'from_tgs' in available_methods:
        try:
            return LottieAnimation.from_tgs(path)
        except Exception as e:
            console.print(f"[dim]from_tgs failed: {e}[/dim]")
    
    if 'from_file' in available_methods:
        try:
            return LottieAnimation.from_file(path)
        except:
            pass
    
    if 'lottie_animation_from_file' in available_methods:
        try:
            return LottieAnimation.lottie_animation_from_file(path)
        except:
            pass
    
    if is_gzipped:
        try:
            data = gzip.decompress(data)
        except:
            pass
    
    try:
        json_str = data.decode('utf-8')
        
        for method_name in ['from_data', 'from_string', 'from_json', 'lottie_animation_from_data', 'load_from_data']:
            if method_name in available_methods:
                try:
                    method = getattr(LottieAnimation, method_name)
                    if method_name == 'lottie_animation_from_data':
                        return method(json_str)
                    else:
                        return method(json_str)
                except:
                    continue
        
        try:
            json_obj = json.loads(json_str)
            if 'from_dict' in available_methods:
                try:
                    return LottieAnimation.from_dict(json_obj)
                except:
                    pass
        except:
            pass
            
    except UnicodeDecodeError:
        pass
    
    try:
        idx = data.find(b"{")
        if idx != -1:
            json_str = data[idx:].decode("utf-8", errors="ignore")
            end_idx = json_str.rfind("}")
            if end_idx != -1:
                json_str = json_str[:end_idx + 1]
                
                for method_name in ['from_data', 'from_string', 'from_json', 'lottie_animation_from_data']:
                    if method_name in available_methods:
                        try:
                            method = getattr(LottieAnimation, method_name)
                            if method_name == 'lottie_animation_from_data':
                                return method(json_str)
                            else:
                                return method(json_str)
                        except:
                            continue
    except:
        pass
    
    raise Exception(f"Could not load animation with any method: {path}")


def is_rlottie_available():
    return RLOTTIE_AVAILABLE


def get_available_methods():
    return _get_available_methods()