# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from datetime import datetime
from typing_extensions import Literal

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ....types.v1 import (
    subscription_list_params,
    subscription_cancel_params,
    subscription_import_params,
    subscription_update_params,
    subscription_migrate_params,
    subscription_preview_params,
    subscription_delegate_params,
    subscription_transfer_params,
    subscription_provision_params,
)
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ....pagination import SyncMyCursorIDPage, AsyncMyCursorIDPage
from .future_update import (
    FutureUpdateResource,
    AsyncFutureUpdateResource,
    FutureUpdateResourceWithRawResponse,
    AsyncFutureUpdateResourceWithRawResponse,
    FutureUpdateResourceWithStreamingResponse,
    AsyncFutureUpdateResourceWithStreamingResponse,
)
from ...._base_client import AsyncPaginator, make_request_options
from ....types.v1.subscription import Subscription
from ....types.v1.subscription_list_response import SubscriptionListResponse
from ....types.v1.subscription_import_response import SubscriptionImportResponse
from ....types.v1.subscription_preview_response import SubscriptionPreviewResponse
from ....types.v1.subscription_provision_response import SubscriptionProvisionResponse

__all__ = ["SubscriptionsResource", "AsyncSubscriptionsResource"]


class SubscriptionsResource(SyncAPIResource):
    @cached_property
    def future_update(self) -> FutureUpdateResource:
        return FutureUpdateResource(self._client)

    @cached_property
    def with_raw_response(self) -> SubscriptionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/stiggio/stigg-python#accessing-raw-response-data-eg-headers
        """
        return SubscriptionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SubscriptionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/stiggio/stigg-python#with_streaming_response
        """
        return SubscriptionsResourceWithStreamingResponse(self)

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Get a single subscription by ID

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/api/v1/subscriptions/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    def update(
        self,
        id: str,
        *,
        addons: Iterable[subscription_update_params.Addon] | Omit = omit,
        applied_coupon: subscription_update_params.AppliedCoupon | Omit = omit,
        await_payment_confirmation: bool | Omit = omit,
        billing_information: subscription_update_params.BillingInformation | Omit = omit,
        billing_period: Literal["MONTHLY", "ANNUALLY"] | Omit = omit,
        budget: Optional[subscription_update_params.Budget] | Omit = omit,
        charges: Iterable[subscription_update_params.Charge] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        minimum_spend: Optional[subscription_update_params.MinimumSpend] | Omit = omit,
        price_overrides: Iterable[subscription_update_params.PriceOverride] | Omit = omit,
        promotion_code: str | Omit = omit,
        schedule_strategy: Literal["END_OF_BILLING_PERIOD", "END_OF_BILLING_MONTH", "IMMEDIATE"] | Omit = omit,
        subscription_entitlements: Iterable[subscription_update_params.SubscriptionEntitlement] | Omit = omit,
        trial_end_date: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Update a subscription

        Args:
          metadata: Additional metadata for the subscription

          trial_end_date: Subscription trial end date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._patch(
            f"/api/v1/subscriptions/{id}",
            body=maybe_transform(
                {
                    "addons": addons,
                    "applied_coupon": applied_coupon,
                    "await_payment_confirmation": await_payment_confirmation,
                    "billing_information": billing_information,
                    "billing_period": billing_period,
                    "budget": budget,
                    "charges": charges,
                    "metadata": metadata,
                    "minimum_spend": minimum_spend,
                    "price_overrides": price_overrides,
                    "promotion_code": promotion_code,
                    "schedule_strategy": schedule_strategy,
                    "subscription_entitlements": subscription_entitlements,
                    "trial_end_date": trial_end_date,
                },
                subscription_update_params.SubscriptionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        customer_id: str | Omit = omit,
        limit: int | Omit = omit,
        status: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncMyCursorIDPage[SubscriptionListResponse]:
        """
        Get a list of subscriptions

        Args:
          after: Return items that come after this cursor

          before: Return items that come before this cursor

          customer_id: Filter by customer ID

          limit: Maximum number of items to return

          status: Filter by status (comma-separated)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/api/v1/subscriptions",
            page=SyncMyCursorIDPage[SubscriptionListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "customer_id": customer_id,
                        "limit": limit,
                        "status": status,
                    },
                    subscription_list_params.SubscriptionListParams,
                ),
            ),
            model=SubscriptionListResponse,
        )

    def cancel(
        self,
        id: str,
        *,
        cancellation_action: Literal["DEFAULT", "REVOKE_ENTITLEMENTS"] | Omit = omit,
        cancellation_time: Literal["END_OF_BILLING_PERIOD", "IMMEDIATE", "SPECIFIC_DATE"] | Omit = omit,
        end_date: Union[str, datetime] | Omit = omit,
        prorate: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Cancel subscription

        Args:
          cancellation_action: Action on cancellation (downgrade or revoke)

          cancellation_time: When to cancel (immediate, period end, or date)

          end_date: Subscription end date

          prorate: If set, enables or disables prorating of credits on subscription cancellation.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/api/v1/subscriptions/{id}/cancel",
            body=maybe_transform(
                {
                    "cancellation_action": cancellation_action,
                    "cancellation_time": cancellation_time,
                    "end_date": end_date,
                    "prorate": prorate,
                },
                subscription_cancel_params.SubscriptionCancelParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    def delegate(
        self,
        id: str,
        *,
        target_customer_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Delegate subscription payment to customer

        Args:
          target_customer_id: The unique identifier of the customer who will assume payment responsibility for
              this subscription. This customer must already exist in your Stigg account and
              have a valid payment method if the subscription requires payment.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/api/v1/subscriptions/{id}/delegate",
            body=maybe_transform(
                {"target_customer_id": target_customer_id}, subscription_delegate_params.SubscriptionDelegateParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    def import_(
        self,
        *,
        subscriptions: Iterable[subscription_import_params.Subscription],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SubscriptionImportResponse:
        """
        Bulk import subscriptions

        Args:
          subscriptions: List of subscription objects to import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/subscriptions/import",
            body=maybe_transform({"subscriptions": subscriptions}, subscription_import_params.SubscriptionImportParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SubscriptionImportResponse,
        )

    def migrate(
        self,
        id: str,
        *,
        subscription_migration_time: Literal["END_OF_BILLING_PERIOD", "IMMEDIATE"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Migrate subscription to latest plan version

        Args:
          subscription_migration_time: When to migrate (immediate or period end)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/api/v1/subscriptions/{id}/migrate",
            body=maybe_transform(
                {"subscription_migration_time": subscription_migration_time},
                subscription_migrate_params.SubscriptionMigrateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    def preview(
        self,
        *,
        customer_id: str,
        plan_id: str,
        addons: Iterable[subscription_preview_params.Addon] | Omit = omit,
        applied_coupon: subscription_preview_params.AppliedCoupon | Omit = omit,
        billable_features: Iterable[subscription_preview_params.BillableFeature] | Omit = omit,
        billing_country_code: str | Omit = omit,
        billing_information: subscription_preview_params.BillingInformation | Omit = omit,
        billing_period: Literal["MONTHLY", "ANNUALLY"] | Omit = omit,
        charges: Iterable[subscription_preview_params.Charge] | Omit = omit,
        paying_customer_id: str | Omit = omit,
        resource_id: str | Omit = omit,
        schedule_strategy: Literal["END_OF_BILLING_PERIOD", "END_OF_BILLING_MONTH", "IMMEDIATE"] | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        trial_override_configuration: subscription_preview_params.TrialOverrideConfiguration | Omit = omit,
        unit_quantity: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SubscriptionPreviewResponse:
        """
        Preview subscription

        Args:
          customer_id: Customer ID

          plan_id: Plan ID

          addons: Addons to include

          applied_coupon: Coupon or discount to apply

          billable_features: Billable features with quantities

          billing_country_code: ISO 3166-1 country code for localization

          billing_information: Billing and tax configuration

          billing_period: Billing period (MONTHLY or ANNUALLY)

          charges: One-time or recurring charges

          paying_customer_id: Paying customer ID for delegated billing

          resource_id: Resource ID for multi-instance subscriptions

          schedule_strategy: When to apply subscription changes

          start_date: Subscription start date

          trial_override_configuration: Trial period override settings

          unit_quantity: Unit quantity for per-unit pricing

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/subscriptions/preview",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "plan_id": plan_id,
                    "addons": addons,
                    "applied_coupon": applied_coupon,
                    "billable_features": billable_features,
                    "billing_country_code": billing_country_code,
                    "billing_information": billing_information,
                    "billing_period": billing_period,
                    "charges": charges,
                    "paying_customer_id": paying_customer_id,
                    "resource_id": resource_id,
                    "schedule_strategy": schedule_strategy,
                    "start_date": start_date,
                    "trial_override_configuration": trial_override_configuration,
                    "unit_quantity": unit_quantity,
                },
                subscription_preview_params.SubscriptionPreviewParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SubscriptionPreviewResponse,
        )

    def provision(
        self,
        *,
        customer_id: str,
        plan_id: str,
        id: str | Omit = omit,
        addons: Iterable[subscription_provision_params.Addon] | Omit = omit,
        applied_coupon: subscription_provision_params.AppliedCoupon | Omit = omit,
        await_payment_confirmation: bool | Omit = omit,
        billing_country_code: Optional[str] | Omit = omit,
        billing_id: Optional[str] | Omit = omit,
        billing_information: subscription_provision_params.BillingInformation | Omit = omit,
        billing_period: Literal["MONTHLY", "ANNUALLY"] | Omit = omit,
        budget: Optional[subscription_provision_params.Budget] | Omit = omit,
        charges: Iterable[subscription_provision_params.Charge] | Omit = omit,
        checkout_options: subscription_provision_params.CheckoutOptions | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        minimum_spend: Optional[subscription_provision_params.MinimumSpend] | Omit = omit,
        paying_customer_id: Optional[str] | Omit = omit,
        payment_collection_method: Literal["CHARGE", "INVOICE", "NONE"] | Omit = omit,
        price_overrides: Iterable[subscription_provision_params.PriceOverride] | Omit = omit,
        resource_id: Optional[str] | Omit = omit,
        salesforce_id: Optional[str] | Omit = omit,
        schedule_strategy: Literal["END_OF_BILLING_PERIOD", "END_OF_BILLING_MONTH", "IMMEDIATE"] | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        subscription_entitlements: Iterable[subscription_provision_params.SubscriptionEntitlement] | Omit = omit,
        trial_override_configuration: subscription_provision_params.TrialOverrideConfiguration | Omit = omit,
        unit_quantity: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SubscriptionProvisionResponse:
        """
        Provision subscription

        Args:
          customer_id: Customer ID to provision the subscription for

          plan_id: Plan ID to provision

          id: Unique identifier for the subscription

          applied_coupon: Coupon configuration

          await_payment_confirmation: Whether to wait for payment confirmation before returning the subscription

          billing_country_code: The ISO 3166-1 alpha-2 country code for billing

          billing_id: External billing system identifier

          billing_period: Billing period (MONTHLY or ANNUALLY)

          checkout_options: Checkout page configuration for payment collection

          metadata: Additional metadata for the subscription

          paying_customer_id: Optional paying customer ID for split billing scenarios

          payment_collection_method: How payments should be collected for this subscription

          resource_id: Optional resource ID for multi-instance subscriptions

          salesforce_id: Salesforce ID

          schedule_strategy: Strategy for scheduling subscription changes

          start_date: Subscription start date

          trial_override_configuration: Trial period override settings

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/subscriptions",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "plan_id": plan_id,
                    "id": id,
                    "addons": addons,
                    "applied_coupon": applied_coupon,
                    "await_payment_confirmation": await_payment_confirmation,
                    "billing_country_code": billing_country_code,
                    "billing_id": billing_id,
                    "billing_information": billing_information,
                    "billing_period": billing_period,
                    "budget": budget,
                    "charges": charges,
                    "checkout_options": checkout_options,
                    "metadata": metadata,
                    "minimum_spend": minimum_spend,
                    "paying_customer_id": paying_customer_id,
                    "payment_collection_method": payment_collection_method,
                    "price_overrides": price_overrides,
                    "resource_id": resource_id,
                    "salesforce_id": salesforce_id,
                    "schedule_strategy": schedule_strategy,
                    "start_date": start_date,
                    "subscription_entitlements": subscription_entitlements,
                    "trial_override_configuration": trial_override_configuration,
                    "unit_quantity": unit_quantity,
                },
                subscription_provision_params.SubscriptionProvisionParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SubscriptionProvisionResponse,
        )

    def transfer(
        self,
        id: str,
        *,
        destination_resource_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Transfer subscription to resource

        Args:
          destination_resource_id: Resource ID to transfer the subscription to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/api/v1/subscriptions/{id}/transfer",
            body=maybe_transform(
                {"destination_resource_id": destination_resource_id},
                subscription_transfer_params.SubscriptionTransferParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )


class AsyncSubscriptionsResource(AsyncAPIResource):
    @cached_property
    def future_update(self) -> AsyncFutureUpdateResource:
        return AsyncFutureUpdateResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSubscriptionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/stiggio/stigg-python#accessing-raw-response-data-eg-headers
        """
        return AsyncSubscriptionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSubscriptionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/stiggio/stigg-python#with_streaming_response
        """
        return AsyncSubscriptionsResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Get a single subscription by ID

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/api/v1/subscriptions/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    async def update(
        self,
        id: str,
        *,
        addons: Iterable[subscription_update_params.Addon] | Omit = omit,
        applied_coupon: subscription_update_params.AppliedCoupon | Omit = omit,
        await_payment_confirmation: bool | Omit = omit,
        billing_information: subscription_update_params.BillingInformation | Omit = omit,
        billing_period: Literal["MONTHLY", "ANNUALLY"] | Omit = omit,
        budget: Optional[subscription_update_params.Budget] | Omit = omit,
        charges: Iterable[subscription_update_params.Charge] | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        minimum_spend: Optional[subscription_update_params.MinimumSpend] | Omit = omit,
        price_overrides: Iterable[subscription_update_params.PriceOverride] | Omit = omit,
        promotion_code: str | Omit = omit,
        schedule_strategy: Literal["END_OF_BILLING_PERIOD", "END_OF_BILLING_MONTH", "IMMEDIATE"] | Omit = omit,
        subscription_entitlements: Iterable[subscription_update_params.SubscriptionEntitlement] | Omit = omit,
        trial_end_date: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Update a subscription

        Args:
          metadata: Additional metadata for the subscription

          trial_end_date: Subscription trial end date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._patch(
            f"/api/v1/subscriptions/{id}",
            body=await async_maybe_transform(
                {
                    "addons": addons,
                    "applied_coupon": applied_coupon,
                    "await_payment_confirmation": await_payment_confirmation,
                    "billing_information": billing_information,
                    "billing_period": billing_period,
                    "budget": budget,
                    "charges": charges,
                    "metadata": metadata,
                    "minimum_spend": minimum_spend,
                    "price_overrides": price_overrides,
                    "promotion_code": promotion_code,
                    "schedule_strategy": schedule_strategy,
                    "subscription_entitlements": subscription_entitlements,
                    "trial_end_date": trial_end_date,
                },
                subscription_update_params.SubscriptionUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    def list(
        self,
        *,
        after: str | Omit = omit,
        before: str | Omit = omit,
        customer_id: str | Omit = omit,
        limit: int | Omit = omit,
        status: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[SubscriptionListResponse, AsyncMyCursorIDPage[SubscriptionListResponse]]:
        """
        Get a list of subscriptions

        Args:
          after: Return items that come after this cursor

          before: Return items that come before this cursor

          customer_id: Filter by customer ID

          limit: Maximum number of items to return

          status: Filter by status (comma-separated)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/api/v1/subscriptions",
            page=AsyncMyCursorIDPage[SubscriptionListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "customer_id": customer_id,
                        "limit": limit,
                        "status": status,
                    },
                    subscription_list_params.SubscriptionListParams,
                ),
            ),
            model=SubscriptionListResponse,
        )

    async def cancel(
        self,
        id: str,
        *,
        cancellation_action: Literal["DEFAULT", "REVOKE_ENTITLEMENTS"] | Omit = omit,
        cancellation_time: Literal["END_OF_BILLING_PERIOD", "IMMEDIATE", "SPECIFIC_DATE"] | Omit = omit,
        end_date: Union[str, datetime] | Omit = omit,
        prorate: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Cancel subscription

        Args:
          cancellation_action: Action on cancellation (downgrade or revoke)

          cancellation_time: When to cancel (immediate, period end, or date)

          end_date: Subscription end date

          prorate: If set, enables or disables prorating of credits on subscription cancellation.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/api/v1/subscriptions/{id}/cancel",
            body=await async_maybe_transform(
                {
                    "cancellation_action": cancellation_action,
                    "cancellation_time": cancellation_time,
                    "end_date": end_date,
                    "prorate": prorate,
                },
                subscription_cancel_params.SubscriptionCancelParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    async def delegate(
        self,
        id: str,
        *,
        target_customer_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Delegate subscription payment to customer

        Args:
          target_customer_id: The unique identifier of the customer who will assume payment responsibility for
              this subscription. This customer must already exist in your Stigg account and
              have a valid payment method if the subscription requires payment.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/api/v1/subscriptions/{id}/delegate",
            body=await async_maybe_transform(
                {"target_customer_id": target_customer_id}, subscription_delegate_params.SubscriptionDelegateParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    async def import_(
        self,
        *,
        subscriptions: Iterable[subscription_import_params.Subscription],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SubscriptionImportResponse:
        """
        Bulk import subscriptions

        Args:
          subscriptions: List of subscription objects to import

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/subscriptions/import",
            body=await async_maybe_transform(
                {"subscriptions": subscriptions}, subscription_import_params.SubscriptionImportParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SubscriptionImportResponse,
        )

    async def migrate(
        self,
        id: str,
        *,
        subscription_migration_time: Literal["END_OF_BILLING_PERIOD", "IMMEDIATE"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Migrate subscription to latest plan version

        Args:
          subscription_migration_time: When to migrate (immediate or period end)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/api/v1/subscriptions/{id}/migrate",
            body=await async_maybe_transform(
                {"subscription_migration_time": subscription_migration_time},
                subscription_migrate_params.SubscriptionMigrateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )

    async def preview(
        self,
        *,
        customer_id: str,
        plan_id: str,
        addons: Iterable[subscription_preview_params.Addon] | Omit = omit,
        applied_coupon: subscription_preview_params.AppliedCoupon | Omit = omit,
        billable_features: Iterable[subscription_preview_params.BillableFeature] | Omit = omit,
        billing_country_code: str | Omit = omit,
        billing_information: subscription_preview_params.BillingInformation | Omit = omit,
        billing_period: Literal["MONTHLY", "ANNUALLY"] | Omit = omit,
        charges: Iterable[subscription_preview_params.Charge] | Omit = omit,
        paying_customer_id: str | Omit = omit,
        resource_id: str | Omit = omit,
        schedule_strategy: Literal["END_OF_BILLING_PERIOD", "END_OF_BILLING_MONTH", "IMMEDIATE"] | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        trial_override_configuration: subscription_preview_params.TrialOverrideConfiguration | Omit = omit,
        unit_quantity: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SubscriptionPreviewResponse:
        """
        Preview subscription

        Args:
          customer_id: Customer ID

          plan_id: Plan ID

          addons: Addons to include

          applied_coupon: Coupon or discount to apply

          billable_features: Billable features with quantities

          billing_country_code: ISO 3166-1 country code for localization

          billing_information: Billing and tax configuration

          billing_period: Billing period (MONTHLY or ANNUALLY)

          charges: One-time or recurring charges

          paying_customer_id: Paying customer ID for delegated billing

          resource_id: Resource ID for multi-instance subscriptions

          schedule_strategy: When to apply subscription changes

          start_date: Subscription start date

          trial_override_configuration: Trial period override settings

          unit_quantity: Unit quantity for per-unit pricing

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/subscriptions/preview",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "plan_id": plan_id,
                    "addons": addons,
                    "applied_coupon": applied_coupon,
                    "billable_features": billable_features,
                    "billing_country_code": billing_country_code,
                    "billing_information": billing_information,
                    "billing_period": billing_period,
                    "charges": charges,
                    "paying_customer_id": paying_customer_id,
                    "resource_id": resource_id,
                    "schedule_strategy": schedule_strategy,
                    "start_date": start_date,
                    "trial_override_configuration": trial_override_configuration,
                    "unit_quantity": unit_quantity,
                },
                subscription_preview_params.SubscriptionPreviewParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SubscriptionPreviewResponse,
        )

    async def provision(
        self,
        *,
        customer_id: str,
        plan_id: str,
        id: str | Omit = omit,
        addons: Iterable[subscription_provision_params.Addon] | Omit = omit,
        applied_coupon: subscription_provision_params.AppliedCoupon | Omit = omit,
        await_payment_confirmation: bool | Omit = omit,
        billing_country_code: Optional[str] | Omit = omit,
        billing_id: Optional[str] | Omit = omit,
        billing_information: subscription_provision_params.BillingInformation | Omit = omit,
        billing_period: Literal["MONTHLY", "ANNUALLY"] | Omit = omit,
        budget: Optional[subscription_provision_params.Budget] | Omit = omit,
        charges: Iterable[subscription_provision_params.Charge] | Omit = omit,
        checkout_options: subscription_provision_params.CheckoutOptions | Omit = omit,
        metadata: Dict[str, str] | Omit = omit,
        minimum_spend: Optional[subscription_provision_params.MinimumSpend] | Omit = omit,
        paying_customer_id: Optional[str] | Omit = omit,
        payment_collection_method: Literal["CHARGE", "INVOICE", "NONE"] | Omit = omit,
        price_overrides: Iterable[subscription_provision_params.PriceOverride] | Omit = omit,
        resource_id: Optional[str] | Omit = omit,
        salesforce_id: Optional[str] | Omit = omit,
        schedule_strategy: Literal["END_OF_BILLING_PERIOD", "END_OF_BILLING_MONTH", "IMMEDIATE"] | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        subscription_entitlements: Iterable[subscription_provision_params.SubscriptionEntitlement] | Omit = omit,
        trial_override_configuration: subscription_provision_params.TrialOverrideConfiguration | Omit = omit,
        unit_quantity: float | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SubscriptionProvisionResponse:
        """
        Provision subscription

        Args:
          customer_id: Customer ID to provision the subscription for

          plan_id: Plan ID to provision

          id: Unique identifier for the subscription

          applied_coupon: Coupon configuration

          await_payment_confirmation: Whether to wait for payment confirmation before returning the subscription

          billing_country_code: The ISO 3166-1 alpha-2 country code for billing

          billing_id: External billing system identifier

          billing_period: Billing period (MONTHLY or ANNUALLY)

          checkout_options: Checkout page configuration for payment collection

          metadata: Additional metadata for the subscription

          paying_customer_id: Optional paying customer ID for split billing scenarios

          payment_collection_method: How payments should be collected for this subscription

          resource_id: Optional resource ID for multi-instance subscriptions

          salesforce_id: Salesforce ID

          schedule_strategy: Strategy for scheduling subscription changes

          start_date: Subscription start date

          trial_override_configuration: Trial period override settings

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/subscriptions",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "plan_id": plan_id,
                    "id": id,
                    "addons": addons,
                    "applied_coupon": applied_coupon,
                    "await_payment_confirmation": await_payment_confirmation,
                    "billing_country_code": billing_country_code,
                    "billing_id": billing_id,
                    "billing_information": billing_information,
                    "billing_period": billing_period,
                    "budget": budget,
                    "charges": charges,
                    "checkout_options": checkout_options,
                    "metadata": metadata,
                    "minimum_spend": minimum_spend,
                    "paying_customer_id": paying_customer_id,
                    "payment_collection_method": payment_collection_method,
                    "price_overrides": price_overrides,
                    "resource_id": resource_id,
                    "salesforce_id": salesforce_id,
                    "schedule_strategy": schedule_strategy,
                    "start_date": start_date,
                    "subscription_entitlements": subscription_entitlements,
                    "trial_override_configuration": trial_override_configuration,
                    "unit_quantity": unit_quantity,
                },
                subscription_provision_params.SubscriptionProvisionParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SubscriptionProvisionResponse,
        )

    async def transfer(
        self,
        id: str,
        *,
        destination_resource_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Subscription:
        """
        Transfer subscription to resource

        Args:
          destination_resource_id: Resource ID to transfer the subscription to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/api/v1/subscriptions/{id}/transfer",
            body=await async_maybe_transform(
                {"destination_resource_id": destination_resource_id},
                subscription_transfer_params.SubscriptionTransferParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Subscription,
        )


class SubscriptionsResourceWithRawResponse:
    def __init__(self, subscriptions: SubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.retrieve = to_raw_response_wrapper(
            subscriptions.retrieve,
        )
        self.update = to_raw_response_wrapper(
            subscriptions.update,
        )
        self.list = to_raw_response_wrapper(
            subscriptions.list,
        )
        self.cancel = to_raw_response_wrapper(
            subscriptions.cancel,
        )
        self.delegate = to_raw_response_wrapper(
            subscriptions.delegate,
        )
        self.import_ = to_raw_response_wrapper(
            subscriptions.import_,
        )
        self.migrate = to_raw_response_wrapper(
            subscriptions.migrate,
        )
        self.preview = to_raw_response_wrapper(
            subscriptions.preview,
        )
        self.provision = to_raw_response_wrapper(
            subscriptions.provision,
        )
        self.transfer = to_raw_response_wrapper(
            subscriptions.transfer,
        )

    @cached_property
    def future_update(self) -> FutureUpdateResourceWithRawResponse:
        return FutureUpdateResourceWithRawResponse(self._subscriptions.future_update)


class AsyncSubscriptionsResourceWithRawResponse:
    def __init__(self, subscriptions: AsyncSubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.retrieve = async_to_raw_response_wrapper(
            subscriptions.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            subscriptions.update,
        )
        self.list = async_to_raw_response_wrapper(
            subscriptions.list,
        )
        self.cancel = async_to_raw_response_wrapper(
            subscriptions.cancel,
        )
        self.delegate = async_to_raw_response_wrapper(
            subscriptions.delegate,
        )
        self.import_ = async_to_raw_response_wrapper(
            subscriptions.import_,
        )
        self.migrate = async_to_raw_response_wrapper(
            subscriptions.migrate,
        )
        self.preview = async_to_raw_response_wrapper(
            subscriptions.preview,
        )
        self.provision = async_to_raw_response_wrapper(
            subscriptions.provision,
        )
        self.transfer = async_to_raw_response_wrapper(
            subscriptions.transfer,
        )

    @cached_property
    def future_update(self) -> AsyncFutureUpdateResourceWithRawResponse:
        return AsyncFutureUpdateResourceWithRawResponse(self._subscriptions.future_update)


class SubscriptionsResourceWithStreamingResponse:
    def __init__(self, subscriptions: SubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.retrieve = to_streamed_response_wrapper(
            subscriptions.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            subscriptions.update,
        )
        self.list = to_streamed_response_wrapper(
            subscriptions.list,
        )
        self.cancel = to_streamed_response_wrapper(
            subscriptions.cancel,
        )
        self.delegate = to_streamed_response_wrapper(
            subscriptions.delegate,
        )
        self.import_ = to_streamed_response_wrapper(
            subscriptions.import_,
        )
        self.migrate = to_streamed_response_wrapper(
            subscriptions.migrate,
        )
        self.preview = to_streamed_response_wrapper(
            subscriptions.preview,
        )
        self.provision = to_streamed_response_wrapper(
            subscriptions.provision,
        )
        self.transfer = to_streamed_response_wrapper(
            subscriptions.transfer,
        )

    @cached_property
    def future_update(self) -> FutureUpdateResourceWithStreamingResponse:
        return FutureUpdateResourceWithStreamingResponse(self._subscriptions.future_update)


class AsyncSubscriptionsResourceWithStreamingResponse:
    def __init__(self, subscriptions: AsyncSubscriptionsResource) -> None:
        self._subscriptions = subscriptions

        self.retrieve = async_to_streamed_response_wrapper(
            subscriptions.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            subscriptions.update,
        )
        self.list = async_to_streamed_response_wrapper(
            subscriptions.list,
        )
        self.cancel = async_to_streamed_response_wrapper(
            subscriptions.cancel,
        )
        self.delegate = async_to_streamed_response_wrapper(
            subscriptions.delegate,
        )
        self.import_ = async_to_streamed_response_wrapper(
            subscriptions.import_,
        )
        self.migrate = async_to_streamed_response_wrapper(
            subscriptions.migrate,
        )
        self.preview = async_to_streamed_response_wrapper(
            subscriptions.preview,
        )
        self.provision = async_to_streamed_response_wrapper(
            subscriptions.provision,
        )
        self.transfer = async_to_streamed_response_wrapper(
            subscriptions.transfer,
        )

    @cached_property
    def future_update(self) -> AsyncFutureUpdateResourceWithStreamingResponse:
        return AsyncFutureUpdateResourceWithStreamingResponse(self._subscriptions.future_update)
