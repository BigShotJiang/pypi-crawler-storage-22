# History

## 0.0.1 (2025-10-26)

* First release on PyPI.
