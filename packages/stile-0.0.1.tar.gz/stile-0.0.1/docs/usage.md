# Usage

To use TMA de-arraying for ST data in a project:

```python
import stile
```
