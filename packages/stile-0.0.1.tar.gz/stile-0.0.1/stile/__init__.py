"""Top-level package for TMA de-arraying for ST data."""

__author__ = """Harsh Sinha"""
__email__ = 'mail.sinha.harsh@gmail.com'
