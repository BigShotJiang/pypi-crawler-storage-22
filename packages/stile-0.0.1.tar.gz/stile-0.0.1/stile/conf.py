DATASET_DIR = '/ihome/yufeihuang/has197/ix3harsh/11-100.github/14-spatial-ai/05-tma-dearraying/data/'
SIMULATED_DATASET_DIR = DATASET_DIR + 'simulated/'


