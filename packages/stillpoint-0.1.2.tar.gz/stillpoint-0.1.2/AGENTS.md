# Repository Guidelines

## Project Structure & Module Organization
- `src/stillpoint/` holds the FastAPI app, CLI entrypoint, and support modules.
- `src/stillpoint/ui/` contains static HTML/CSS/JS served by the app and packaged into the wheel.
- `tests/` contains pytest tests (currently an import smoke test).
- `dist/` is generated build output; do not edit by hand.
- `pyproject.toml` defines packaging metadata and the `stillpoint` console script.

## Build, Test, and Development Commands
- `python -m pip install -U pip` updates pip.
- `python -m pip install -e .` installs an editable dev build.
- `stillpoint` runs the service (env: `OBS_HOST`, `OBS_PORT`, `OBS_RELOAD`, `OBS_LOG_LEVEL`).
- `uvicorn stillpoint.collector_app:app --host 127.0.0.1 --port 7000` runs directly.
- `python -m build` creates sdist/wheel (requires the `build` package).
- `python -m pip install dist/*.whl` installs a built wheel for verification.

## Coding Style & Naming Conventions
- Python uses 4-space indentation, type hints where helpful, `snake_case` functions, and `UPPER_SNAKE` constants.
- UI assets use 2-space indentation and prefer `const`/`let` in JS.
- Keep new API routes in `src/stillpoint/collector_app.py` and UI changes in `src/stillpoint/ui/`.

## Testing Guidelines
- Place tests in `tests/` with `test_*.py` names.
- Run with `python -m pytest` (install `pytest` if needed).
- Add coverage for ingest/metrics changes; keep tests fast and deterministic.

## Commit & Pull Request Guidelines
- No Git history is present in this checkout; follow any team convention if provided.
- Default to short, imperative commit subjects (<= 72 chars) and add a body when behavior changes.
- PRs should include: purpose, how to verify, and UI screenshots when `src/stillpoint/ui/` changes.

## Security & Configuration Tips
- `/ingest` requires `Authorization: Bearer <OBS_TOKEN>`; set `OBS_TOKEN` for non-local use.
- Log tailing uses `OBS_LOG_FILES` (for example `serviceA=/path/access.log`) and `OBS_TAIL_FROM_START=1`.
- Do not commit secrets or log files.
