7) Local install check (before publishing)

From repo root:

python -m pip install -U pip
python -m pip install -e .[dev]
stillpoint


Open:

http://127.0.0.1:7000/

Also test a built wheel:

python -m pip install -U build
python -m build
python -m pip uninstall -y stillpoint
python -m pip install dist/stillpoint-0.1.0-py3-none-any.whl
stillpoint


If the UI loads after wheel install, you’re golden.

8) Publish to PyPI

Install tooling:

python -m pip install -U twine build


Build:

python -m build


Upload to TestPyPI:

twine upload -r testpypi dist/*


Then real PyPI:

twine upload dist/*
