uvicorn your_app:app --host 127.0.0.1 --port 9000 --access-log > /tmp/serviceA_access.log 2>&1

export OBS_TOKEN=dev-secret
uvicorn collector_app:app --host 127.0.0.1 --port 7000


export OBS_TOKEN=dev-secret
export OBS_LOG_FILES="serviceA=/tmp/serviceA_access.log"
uvicorn collector_app:app --host 127.0.0.1 --port 7000

****

**from fastapi import FastAPI
from timed_access_log_middleware import TimedAccessLogMiddleware

app = FastAPI()
app.add_middleware(TimedAccessLogMiddleware, service="serviceA:9000", path="/tmp/serviceA_timed.jsonl")
**