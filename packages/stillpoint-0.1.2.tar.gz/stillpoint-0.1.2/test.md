# Local Service Run Instructions

## Prerequisites
- Python 3.10+
- `pip` available in your environment

## Install (editable)
```bash
python -m pip install -U pip
python -m pip install -e .
```

## Run the service
```bash
stillpoint
```

By default it serves on `http://127.0.0.1:7000/`.

## Run with environment overrides
```bash
$env:OBS_HOST = "127.0.0.1"
$env:OBS_PORT = "7000"
$env:OBS_RELOAD = "1"
$env:OBS_LOG_LEVEL = "info"
stillpoint
```

## Run directly with Uvicorn
```bash
uvicorn stillpoint.collector_app:app --host 127.0.0.1 --port 7000
```



 python -m pip install -U build twine
  python -m build

  3) Verify artifacts

  python -m twine check dist/*

  4) Upload to TestPyPI (recommended)

  python -m twine upload -r testpypi dist/*

  Test install from TestPyPI:

  python -m pip install -i https://test.pypi.org/simple/ stillpoint==0.1.1

  5) Upload to PyPI

  python -m twine upload dist/*


python -m pip uninstall -y stillpoint
  python -m pip install dist/*.whl