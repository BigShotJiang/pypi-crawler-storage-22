def test_imports():
    import stillpoint
    from stillpoint import agent, collector_app
    assert stillpoint.__version__
