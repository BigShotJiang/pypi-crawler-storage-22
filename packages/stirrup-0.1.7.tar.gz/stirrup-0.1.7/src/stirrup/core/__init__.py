"""Core agent framework components."""
