---
name: Bug Report
about: Report a bug in stix2tabular
title: "[BUG] "
labels: bug
---

**Describe the bug**
A clear description of what went wrong.

**To reproduce**
Steps or minimal code example that triggers the bug.

**STIX input**
If possible, include the STIX bundle (or a minimal subset) that caused the issue.
Paste inline or attach as a file.

**Expected behavior**
What you expected to happen.

**Environment**
- Python version:
- stix2tabular version:
- stix2 version:
- pandas version:
- OS:
