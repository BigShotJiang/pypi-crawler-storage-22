# Changelog

## [0.1.0] - 2026-02-16

### Added
- Initial release
- `stix_to_tables()` function converting STIX bundles to dict of Pandas DataFrames
- `save_tables()` and `load_tables()` for lossless Parquet round-tripping
- Support for STIX 2.0 and 2.1
- Separate DataFrames per STIX object type
- Relationships as lean edge table
- Sightings as dedicated DataFrame
- SCO inclusion/exclusion toggle
- File, directory, JSON string, and dict input support
- Multiple bundle merging with deduplication
- MITRE ATT&CK integration test
