# CLAUDE.md — Build Instructions for stix2tabular

## Project Overview

Build `stix2tabular`, a lightweight Python library that converts STIX (Structured Threat Information eXpression) JSON bundles into Pandas DataFrames. The library should be production-ready for public release on GitHub and PyPI.

STIX is the standard format for cyber threat intelligence. It represents threats as JSON "bundles" containing typed objects (threat actors, malware, vulnerabilities, etc.) and relationships between them. Analysts and ML engineers frequently need this data in tabular form for aggregation, filtering, feature engineering, and model training. This library bridges that gap — no boilerplate, no custom ETL.

This is a sibling project to `stix2nx` (STIX → NetworkX graphs). The two libraries share the same input API but are fully independent — no cross-dependency. Users install whichever they need (or both).

---

## Core API Design

### Main Entry Point

A single function: `stix_to_tables()`

```python
from stix2tabular import stix_to_tables

tables = stix_to_tables(
    source,                    # str (file path or directory) OR list[str] (JSON strings) OR list[dict] (parsed dicts)
    include_scos=True,         # Whether SCOs get their own DataFrames (default True) or are skipped
)
```

**Input formats supported:**
- A file path (str ending in `.json`) → reads and parses the file
- A directory path (str) → globs for all `*.json` files in the directory (non-recursive), parses each as a STIX bundle, merges results
- A list of JSON strings → each is parsed as a STIX bundle
- A list of Python dicts → each is treated as a parsed STIX bundle
- Multiple bundles (from directory or list inputs) are merged: rows with same STIX ID are deduplicated (last-write-wins), edge rows are accumulated

**How source type is detected:**
- If `source` is a `str` and it's a path to an existing directory → directory mode
- If `source` is a `str` and it ends with `.json` or is a path to an existing file → single file mode
- If `source` is a `list` where elements are `str` → JSON strings mode (each string is a full JSON bundle)
- If `source` is a `list` where elements are `dict` → parsed dicts mode

**Output:** A `dict[str, pd.DataFrame]` where:
- Each STIX object type gets its own key → DataFrame. For example: `tables["malware"]`, `tables["threat-actor"]`, `tables["indicator"]`, `tables["attack-pattern"]`, etc.
- Relationships get a special key: `tables["relationships"]` — a single DataFrame with all relationship objects flattened into rows.
- Sightings get a special key: `tables["sightings"]` — a single DataFrame with all sighting objects flattened into rows.
- SCO types each get their own key when `include_scos=True`: `tables["ipv4-addr"]`, `tables["domain-name"]`, `tables["file"]`, etc.
- Only types that actually exist in the input bundle(s) appear as keys. An empty bundle returns `{}`.

### DataFrame Column Conventions

Each DataFrame has columns corresponding to the STIX properties of that object type. The `id` column is always present and serves as the logical primary key (though the library does not enforce uniqueness — if duplicates appear from multi-bundle merging, last-write-wins).

**Common columns across all type DataFrames:**
- `id` (str): STIX identifier, e.g. `"malware--abc123"`
- `type` (str): STIX type, e.g. `"malware"`
- `created` (str): ISO 8601 timestamp
- `modified` (str): ISO 8601 timestamp
- `spec_version` (str, may be absent in 2.0 bundles)
- `created_by_ref` (str or NaN): reference to identity object

**Type-specific columns** are whatever properties exist on those objects. The library does NOT impose a fixed schema — columns are determined by what's in the data (union of all properties across all objects of that type). Missing values become `NaN`.

**List-valued fields** (e.g., `aliases`, `kill_chain_phases`, `external_references`, `labels`, `threat_actor_types`) are kept as Python lists in the DataFrame cells. This means:
- Works perfectly for programmatic analysis in pandas (filtering, exploding, etc.)
- Does NOT round-trip cleanly to CSV (lists become string repr). This is intentional — CSV export is not a design goal. Users who need CSV can serialize lists themselves.
- Users can call `df.explode("aliases")` to get one row per alias when needed.

**Dict-valued fields** (e.g., `hashes` on file objects, `extensions`) are kept as Python dicts in the DataFrame cells. Same rationale — works for analysis, not for CSV.

### Relationships DataFrame

The `tables["relationships"]` DataFrame has these columns (plus any other properties on the relationship objects):
- `id`: the relationship object's STIX ID
- `type`: always "relationship"
- `relationship_type`: e.g., "uses", "targets", "exploits", "indicates"
- `source_ref`: STIX ID of the source object
- `target_ref`: STIX ID of the target object
- `start_time`: if present (NaN otherwise)
- `stop_time`: if present (NaN otherwise)
- `confidence`: if present (NaN otherwise)
- `created`, `modified`, etc.

This is a lean edge table. Users who want denormalized edges (with source/target names joined in) can do so with a standard pandas merge against the relevant type tables.

### Sightings DataFrame

The `tables["sightings"]` DataFrame has these columns (plus any other properties):
- `id`: the sighting object's STIX ID
- `type`: always "sighting"
- `sighting_of_ref`: STIX ID of what was sighted
- `where_sighted_refs`: Python list of identity STIX IDs (or NaN)
- `observed_data_refs`: Python list of observed-data STIX IDs (or NaN)
- `first_seen`, `last_seen`: timestamps if present
- `count`: integer if present
- `created`, `modified`, etc.

### Persistence Functions

Two additional functions for round-tripping through Parquet:

```python
from stix2tabular import save_tables, load_tables

# Save all DataFrames to a directory as Parquet files
save_tables(tables, "/path/to/output/")

# Load them back
tables = load_tables("/path/to/output/")
```

#### `save_tables(tables, directory)`

```python
def save_tables(tables: dict[str, pd.DataFrame], directory: str) -> None:
```

- `tables`: the dict returned by `stix_to_tables()`
- `directory`: path to output directory. Created if it doesn't exist (including parents, like `mkdir -p`).
- Writes one `.parquet` file per key, named `{key}.parquet`. Examples:
  - `tables["malware"]` → `malware.parquet`
  - `tables["threat-actor"]` → `threat-actor.parquet`
  - `tables["attack-pattern"]` → `attack-pattern.parquet`
  - `tables["relationships"]` → `relationships.parquet`
  - `tables["sightings"]` → `sightings.parquet`
  - `tables["ipv4-addr"]` → `ipv4-addr.parquet`
- Overwrites existing files with the same name. Does NOT delete other files in the directory.
- Empty DataFrames are still saved (preserves the schema/column info).
- Raises `ValueError` if `tables` is not a dict or contains non-DataFrame values.

#### `load_tables(directory)`

```python
def load_tables(directory: str) -> dict[str, pd.DataFrame]:
```

- `directory`: path to a directory containing `.parquet` files previously written by `save_tables()`
- Globs for all `*.parquet` files in the directory (non-recursive)
- The dict key is the filename stem: `malware.parquet` → `tables["malware"]`, `threat-actor.parquet` → `tables["threat-actor"]`
- Returns `{}` if the directory contains no `.parquet` files
- Raises `FileNotFoundError` if the directory doesn't exist

#### Naming Convention

The file naming is deterministic and based on the STIX type string:
- Filename = `{stix_type}.parquet` (e.g., `attack-pattern.parquet`, `intrusion-set.parquet`)
- The two special keys use their exact names: `relationships.parquet`, `sightings.parquet`
- This means the dict keys, STIX type names, and filenames are all the same string — no mapping table needed

#### Parquet Engine

Use `pandas.DataFrame.to_parquet()` and `pandas.read_parquet()` with the pyarrow engine (the default). pyarrow is an explicit dependency of this library since Parquet persistence is a first-class feature.

### How Objects Map to Tables

**SDOs (STIX Domain Objects) → One DataFrame per type**
All 18 SDO types that appear in the bundle get their own DataFrame. Every STIX property on the object becomes a column.

**SCOs (STIX Cyber-observable Objects) → One DataFrame per type (when `include_scos=True`)**
Observable types (ipv4-addr, domain-name, file, url, email-addr, etc.) each get their own DataFrame. When `include_scos=False`, SCO types are omitted entirely from the output dict.

**Relationship Objects → `tables["relationships"]`**
All relationship objects go into a single DataFrame (not split by `relationship_type`). Users who want only "uses" relationships can filter: `tables["relationships"].query("relationship_type == 'uses'")`.

**Sighting Objects → `tables["sightings"]`**
All sighting objects go into a single DataFrame.

**Marking Definitions and Language Content → Skipped**
`marking-definition` and `language-content` objects are metadata, not threat intelligence entities. They are not included in the output.

### Handling Multiple Bundles

When multiple bundles are provided (list of JSON strings, list of dicts, or directory):
- Type DataFrames are concatenated then deduplicated by `id` (last occurrence wins, matching pandas `drop_duplicates(subset="id", keep="last")` semantics)
- Relationship and sighting DataFrames are concatenated (accumulated, not deduplicated — it's valid for the same relationship to appear in multiple bundles)

### STIX Version Handling

Same rules as stix2nx:
- Handle both STIX 2.0 and STIX 2.1 bundles gracefully
- STIX 2.0: `spec_version` on bundle; 2.1: `spec_version` on individual objects
- STIX 2.0 `observed-data` with embedded `objects` dict: when `include_scos=True`, extract embedded observables into their respective type DataFrames with synthetic IDs (prefixed with observed-data ID for uniqueness). When `include_scos=False`, skip them.
- Never crash on version differences — parse what's there, skip what isn't.

---

## Project Structure

```
stix2tabular/
├── src/
│   └── stix2tabular/
│       ├── __init__.py          # Exports stix_to_tables, save_tables, load_tables
│       ├── converter.py         # Core conversion logic
│       ├── parsers.py           # Input parsing (file, directory, JSON strings, dicts)
│       ├── persistence.py       # save_tables, load_tables (Parquet round-trip)
│       └── utils.py             # Helper functions
├── tests/
│   ├── __init__.py
│   ├── test_basic.py            # Unit tests with small hand-crafted bundles
│   ├── test_sco.py              # Tests for SCO inclusion/exclusion
│   ├── test_sightings.py        # Tests for sighting DataFrame
│   ├── test_relationships.py    # Tests for relationships DataFrame
│   ├── test_stix20.py           # Tests specific to STIX 2.0 bundles
│   ├── test_stix21.py           # Tests specific to STIX 2.1 bundles
│   ├── test_merge.py            # Tests for merging multiple bundles
│   ├── test_directory.py        # Tests for directory input
│   ├── test_persistence.py      # Tests for save_tables / load_tables round-trip
│   ├── test_attack.py           # Integration test against MITRE ATT&CK curated subset
│   ├── conftest.py              # Shared fixtures (sample bundles, etc.)
│   └── data/
│       ├── attack-subset.json   # Curated ~1MB ATT&CK subset (checked in — same file as stix2nx)
│       └── build_subset.py      # Script to regenerate subset from full ATT&CK bundle
├── examples/
│   └── analyze_attack.py        # Script demonstrating DataFrame analysis for the README
├── README.md
├── CLAUDE.md                    # This file
├── LICENSE                      # MIT License
├── CHANGELOG.md
├── pyproject.toml
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   └── workflows/
│       └── ci.yml               # GitHub Actions: test on Python 3.10, 3.11, 3.12, 3.13
└── .gitignore
```

---

## Dependencies

**Runtime dependencies (and ONLY these):**
- `stix2` (>=3.0.0) — official OASIS STIX 2 Python library
- `pandas` (>=2.0)
- `pyarrow` (>=12.0) — Parquet engine for `save_tables()` / `load_tables()`

**Test dependencies (dev only):**
- `pytest`
- `requests` (only used in test_attack.py to download the live ATT&CK bundle)

**Python version:** >=3.10

---

## Package Configuration (pyproject.toml)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "stix2tabular"
version = "0.1.0"
description = "Convert STIX cyber threat intelligence bundles to Pandas DataFrames"
readme = "README.md"
license = "MIT"
requires-python = ">=3.10"
authors = [
    { name = "Marlon Abayan", email = "mabayan@users.noreply.github.com" }
]
keywords = ["stix", "stix2", "pandas", "threat-intelligence", "cybersecurity", "mitre-attack", "cti", "dataframe"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Security",
    "Topic :: Scientific/Engineering :: Information Analysis",
]
dependencies = [
    "stix2>=3.0.0",
    "pandas>=2.0",
    "pyarrow>=12.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "requests>=2.28",
]

[project.urls]
Homepage = "https://github.com/mabayan/stix2tabular"
Repository = "https://github.com/mabayan/stix2tabular"
Issues = "https://github.com/mabayan/stix2tabular/issues"
```

---

## Test Suite Design

All tests should be runnable with a single command: `pytest`

### Unit Tests

Use hand-crafted minimal STIX bundles as fixtures in conftest.py. Each test should be fast and deterministic (no network calls).

**test_basic.py:**
- Test that each SDO type gets its own key in the output dict
- Test that the DataFrame for a type has the correct columns matching STIX properties
- Test that `id` column is present and matches STIX IDs
- Test that list-valued properties remain Python lists in DataFrame cells
- Test that dict-valued properties remain Python dicts in DataFrame cells
- Test that all properties are preserved as columns (not just a subset)
- Test that marking-definitions and language-content are excluded from output
- Test with empty bundle → returns `{}`
- Test with bundle containing only SDOs and no relationships → `"relationships"` key absent from output
- Test that column types are sensible (strings are str, lists are list, NaN for missing)
- Test that a bundle with 3 malware objects produces `tables["malware"]` with 3 rows

**test_relationships.py:**
- Test that relationship objects go into `tables["relationships"]`
- Test that `source_ref`, `target_ref`, `relationship_type` columns are present
- Test that optional fields (`start_time`, `stop_time`, `confidence`) appear as columns when present, NaN when absent
- Test with multiple relationship types (uses, targets, exploits) → all in same DataFrame
- Test that relationship object's own `id` is preserved
- Test that non-relationship properties on the relationship object become columns

**test_sco.py:**
- Test that SCO types each get their own DataFrame key when `include_scos=True`
- Test that SCOs are excluded entirely when `include_scos=False`
- Test that SCO properties are correctly mapped to DataFrame columns
- Test observable types: ipv4-addr (`value` column), domain-name (`value` column), file (with `hashes` dict kept as dict), url (`value` column), email-addr (`value` column)
- Test that a bundle with 2 ipv4-addr and 3 domain-name objects produces separate DataFrames with correct row counts

**test_sightings.py:**
- Test that sighting objects go into `tables["sightings"]`
- Test that `sighting_of_ref` column is present
- Test that `where_sighted_refs` is a Python list in the cell
- Test that `observed_data_refs` is a Python list in the cell
- Test that `first_seen`, `last_seen`, `count` appear when present
- Test sighting with all ref types present
- Test sighting with only `sighting_of_ref` (minimal case) — other ref columns should be NaN

**test_stix20.py:**
- Test with a STIX 2.0 bundle (spec_version on bundle, not objects)
- Test that STIX 2.0 `observed-data` with embedded `objects` dict extracts SCOs into correct type DataFrames when `include_scos=True`
- Test that synthetic IDs for extracted embedded SCOs are unique and prefixed with the observed-data ID

**test_stix21.py:**
- Test with a STIX 2.1 bundle (spec_version on individual objects)
- Test STIX 2.1-specific types: infrastructure, malware-analysis, location, note, opinion, grouping — each gets its own DataFrame
- Test that standalone SCOs are handled correctly

**test_merge.py:**
- Test merging two bundles with no overlap → all rows from both present
- Test merging two bundles with overlapping node IDs → deduplicated by `id`, last-write-wins
- Test merging two bundles with overlapping relationship IDs → both rows preserved (relationships are accumulated)
- Test providing 3+ bundles
- Test that column sets are the union across all bundles for a given type (missing fields become NaN)

**test_directory.py:**
- Test with a temp directory containing 2-3 `.json` files → all merged
- Test that non-`.json` files in the directory are ignored
- Test with empty directory → returns `{}`
- Test with directory containing one file → same as single file input

**test_persistence.py:**
- Test round-trip: `stix_to_tables()` → `save_tables()` → `load_tables()` → compare all DataFrames match originals
- Test that list-valued columns survive the round-trip as actual Python lists (not strings)
- Test that dict-valued columns survive the round-trip as actual Python dicts
- Test that NaN values survive the round-trip
- Test file naming: `save_tables()` produces files named `{type}.parquet` (e.g., `malware.parquet`, `relationships.parquet`)
- Test that `load_tables()` reconstructs the correct dict keys from filenames
- Test that `save_tables()` creates the directory if it doesn't exist (including nested parents)
- Test that `save_tables()` overwrites existing files without error
- Test that `save_tables()` does not delete other files already in the directory
- Test that `load_tables()` on a non-existent directory raises `FileNotFoundError`
- Test that `load_tables()` on an empty directory returns `{}`
- Test that `save_tables()` raises `ValueError` if tables is not a dict or contains non-DataFrame values
- Test with empty DataFrames (0 rows) — should save and load correctly, preserving column schema

### Integration Test (test_attack.py)

Uses the same curated ~1MB ATT&CK subset as stix2nx (`tests/data/attack-subset.json`). Copy the identical file and `build_subset.py` script. By default, tests download the full live ATT&CK bundle; if that fails, they fall back to the curated subset. Set `STIX2TABULAR_OFFLINE=true` to skip the live download entirely.

```python
import pytest
import os

OFFLINE_FLAG = os.environ.get("STIX2TABULAR_OFFLINE", "false").lower() == "true"
ATTACK_URL = "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json"
SUBSET_PATH = os.path.join(os.path.dirname(__file__), "data", "attack-subset.json")

@pytest.fixture
def attack_bundle_path(tmp_path):
    """Get ATT&CK bundle. Default: live download. Failover: curated subset.
    Set STIX2TABULAR_OFFLINE=true to skip live download entirely."""
    if not OFFLINE_FLAG:
        try:
            import requests
            print(f"\nDownloading live ATT&CK bundle from {ATTACK_URL}...")
            resp = requests.get(ATTACK_URL, timeout=120)
            resp.raise_for_status()
            live_path = tmp_path / "enterprise-attack.json"
            live_path.write_text(resp.text)
            print(f"Using live ATT&CK bundle ({len(resp.text) // 1024 // 1024}MB)")
            return str(live_path)
        except Exception as e:
            print(f"\nLive ATT&CK download failed ({e}), falling back to curated subset")
            return SUBSET_PATH
    print("\nOffline mode: using curated ATT&CK subset")
    return SUBSET_PATH


def test_attack_loads(attack_bundle_path):
    """ATT&CK bundle converts to tables without error."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    assert isinstance(tables, dict)
    assert len(tables) > 0

def test_attack_has_expected_types(attack_bundle_path):
    """ATT&CK tables contain the core type keys."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    assert "attack-pattern" in tables
    assert "intrusion-set" in tables
    assert "malware" in tables
    assert "tool" in tables
    assert "relationships" in tables

def test_attack_row_counts(attack_bundle_path):
    """ATT&CK tables have meaningful row counts."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # The curated subset has ~30 attack patterns, ~8 intrusion sets, etc.
    assert len(tables["attack-pattern"]) >= 10
    assert len(tables["intrusion-set"]) >= 3
    assert len(tables["relationships"]) >= 50

def test_attack_columns(attack_bundle_path):
    """ATT&CK DataFrames have expected columns."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # Every type table should have id, type, created, modified
    for key, df in tables.items():
        assert "id" in df.columns, f"Missing 'id' column in {key}"
        assert "type" in df.columns, f"Missing 'type' column in {key}"
    # attack-patterns should have name
    assert "name" in tables["attack-pattern"].columns
    # relationships should have the edge columns
    rel = tables["relationships"]
    assert "source_ref" in rel.columns
    assert "target_ref" in rel.columns
    assert "relationship_type" in rel.columns

def test_attack_relationship_types(attack_bundle_path):
    """ATT&CK relationships include expected types."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    rel_types = set(tables["relationships"]["relationship_type"].unique())
    assert "uses" in rel_types

def test_attack_list_fields(attack_bundle_path):
    """List-valued fields are actual Python lists, not strings."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # external_references is a common list field on attack-patterns
    if "external_references" in tables["attack-pattern"].columns:
        first_valid = tables["attack-pattern"]["external_references"].dropna().iloc[0]
        assert isinstance(first_valid, list), f"Expected list, got {type(first_valid)}"

def test_attack_no_scos(attack_bundle_path):
    """include_scos=False excludes SCO type tables."""
    from stix2tabular import stix_to_tables
    tables_with = stix_to_tables(attack_bundle_path, include_scos=True)
    tables_without = stix_to_tables(attack_bundle_path, include_scos=False)
    assert len(tables_with) >= len(tables_without)
    # SCO types should be absent
    sco_types = {"ipv4-addr", "domain-name", "file", "url", "email-addr",
                 "ipv6-addr", "mac-addr", "mutex", "process", "software",
                 "user-account", "windows-registry-key", "network-traffic",
                 "artifact", "directory", "autonomous-system", "email-message"}
    for sco_type in sco_types:
        assert sco_type not in tables_without

def test_attack_sightings(attack_bundle_path):
    """Sighting objects in the subset go into tables['sightings']."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # The curated subset includes synthetic sightings
    assert "sightings" in tables
    assert len(tables["sightings"]) >= 1
    assert "sighting_of_ref" in tables["sightings"].columns

def test_attack_no_marking_definitions(attack_bundle_path):
    """Marking definitions are excluded from output."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    assert "marking-definition" not in tables
```

To run with live ATT&CK data (default): `pytest tests/test_attack.py -v`
To run with curated subset only (offline/CI): `STIX2TABULAR_OFFLINE=true pytest tests/test_attack.py -v`

---

## README.md Structure

The README should be purely technical. No company pitch, no lengthy STIX background. Structure:

### 1. Title + One-Line Description

```
# stix2tabular

Convert STIX cyber threat intelligence bundles to Pandas DataFrames.
```

### 2. Installation

```
pip install stix2tabular
```

### 3. Quick Start (5-line example)

```python
from stix2tabular import stix_to_tables, save_tables

tables = stix_to_tables("enterprise-attack.json")

print(tables.keys())
# → dict_keys(['attack-pattern', 'intrusion-set', 'malware', 'tool', 'relationships', ...])

print(tables["malware"].head())
#                              id       type            name  ...
# 0  malware--abc123             malware     CHOPSTICK  ...
# 1  malware--def456             malware     X-Agent    ...

# Save to Parquet for later use
save_tables(tables, "attack_tables/")
```

### 4. Before/After Comparison

Show two side-by-side code blocks:

**Before (without stix2tabular):** ~30-40 lines of boilerplate: `json.load`, manual iteration over objects, building dicts keyed by type, converting to DataFrames, handling missing fields, handling relationships separately, flattening nested objects, etc.

**After (with stix2tabular):** 3 lines.

Make the contrast visceral.

### 5. What You Get

Show the structure of the output dict with a concrete example:

```python
tables = stix_to_tables("enterprise-attack.json")

# One DataFrame per STIX type
tables["attack-pattern"]     # 680 rows × 15 columns
tables["intrusion-set"]      # 138 rows × 12 columns
tables["malware"]            # 490 rows × 14 columns
tables["tool"]               # 78 rows × 11 columns
tables["campaign"]           # 23 rows × 10 columns

# Relationships as a lean edge table
tables["relationships"]      # 18,400 rows × 9 columns

# Sightings
tables["sightings"]          # 42 rows × 8 columns

# SCO types (when include_scos=True)
tables["ipv4-addr"]          # 12 rows × 4 columns
```

(Use actual numbers from an ATT&CK conversion or approximate.)

### 6. API Reference

Document all three functions:

**`stix_to_tables(source, include_scos=True)`**
- `source`: str (file path or directory path) | list[str] (JSON strings) | list[dict] (parsed bundles)
  - File path: reads and parses a single `.json` file
  - Directory path: globs all `*.json` files in the directory, merges into one set of tables
  - list[str]: each string is parsed as a full STIX bundle JSON
  - list[dict]: each dict is treated as a parsed STIX bundle
- `include_scos`: bool (default True)
  - When True, STIX Cyber-observable Objects (IP addresses, domain names, file hashes, etc.) get their own DataFrames. When False, only SDOs, relationships, and sightings are included.
- Returns: `dict[str, pd.DataFrame]`

**`save_tables(tables, directory)`**
- `tables`: dict returned by `stix_to_tables()`
- `directory`: path to output directory (created if it doesn't exist)
- Writes one `{type}.parquet` file per key (e.g., `malware.parquet`, `relationships.parquet`)

**`load_tables(directory)`**
- `directory`: path to directory containing `.parquet` files from `save_tables()`
- Returns: `dict[str, pd.DataFrame]` — dict keys derived from filenames

### 7. Working with the Data

Show 4-5 practical examples:

```python
# All techniques used by APT28
rels = tables["relationships"]
apt28_id = tables["intrusion-set"].query("name == 'APT28'")["id"].iloc[0]
technique_ids = rels.query(
    "source_ref == @apt28_id and relationship_type == 'uses'"
)["target_ref"]
techniques = tables["attack-pattern"][
    tables["attack-pattern"]["id"].isin(technique_ids)
]["name"]
```

```python
# Most common relationship types
tables["relationships"]["relationship_type"].value_counts()
```

```python
# Explode aliases to find all names for threat actors
tables["intrusion-set"].explode("aliases")[["name", "aliases"]]
```

```python
# Merge bundles from a directory of STIX feeds
tables = stix_to_tables("/path/to/stix_feeds/")
```

```python
# Join source names onto relationships for a denormalized view
rels = tables["relationships"].copy()
names = pd.concat([df[["id", "name"]] for df in tables.values() if "name" in df.columns])
rels = rels.merge(names, left_on="source_ref", right_on="id", suffixes=("", "_source"))
rels = rels.merge(names, left_on="target_ref", right_on="id", suffixes=("", "_target"))
```

### 8. Saving and Loading

The library includes built-in Parquet persistence for lossless round-tripping:

```python
from stix2tabular import stix_to_tables, save_tables, load_tables

tables = stix_to_tables("enterprise-attack.json")

# Save all DataFrames to a directory (one .parquet file per type)
save_tables(tables, "output/attack_tables/")
# Creates: attack-pattern.parquet, intrusion-set.parquet, malware.parquet,
#          relationships.parquet, sightings.parquet, ...

# Load them back — identical DataFrames, including list/dict columns
tables = load_tables("output/attack_tables/")
```

Parquet preserves Python lists and dicts natively — no serialization needed, no data loss.

**CSV note:** If you need CSV, you'll need to serialize list/dict columns yourself before exporting:
```python
import json
df = tables["malware"].copy()
for col in df.columns:
    df[col] = df[col].apply(lambda x: json.dumps(x) if isinstance(x, (list, dict)) else x)
df.to_csv("malware.csv", index=False)
```

### 9. Comparison with stix2nx

Brief note:

```
| Need                        | Use           |
|-----------------------------|---------------|
| Graph traversal, centrality | stix2nx       |
| Filtering, aggregation, ML  | stix2tabular  |
| Both                        | Install both  |
```

Same input API. Same STIX version support. Independent libraries — no cross-dependency.

### 10. Running Tests

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run all tests (integration test downloads live ATT&CK data, falls back to curated subset if offline)
pytest

# Run in offline mode (uses curated ~1MB ATT&CK subset only, no network needed)
STIX2TABULAR_OFFLINE=true pytest

# Regenerate the curated subset from latest ATT&CK (requires network)
python tests/data/build_subset.py
```

### 11. STIX Version Support

Note: supports both STIX 2.0 and STIX 2.1 bundles.

### 12. License

MIT

---

## GitHub Issue Templates

### .github/ISSUE_TEMPLATE/bug_report.md

```markdown
---
name: Bug Report
about: Report a bug in stix2tabular
title: "[BUG] "
labels: bug
---

**Describe the bug**
A clear description of what went wrong.

**To reproduce**
Steps or minimal code example that triggers the bug.

**STIX input**
If possible, include the STIX bundle (or a minimal subset) that caused the issue.
Paste inline or attach as a file.

**Expected behavior**
What you expected to happen.

**Environment**
- Python version:
- stix2tabular version:
- stix2 version:
- pandas version:
- OS:
```

### .github/ISSUE_TEMPLATE/feature_request.md

```markdown
---
name: Feature Request
about: Suggest an enhancement
title: "[FEATURE] "
labels: enhancement
---

**What are you trying to do?**
Describe the task or workflow.

**Why doesn't current functionality cover this?**
What's missing or inconvenient.

**Proposed solution**
If you have one in mind.
```

---

## GitHub Actions CI (.github/workflows/ci.yml)

```yaml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.10", "3.11", "3.12", "3.13"]

    steps:
      - uses: actions/checkout@v4
      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - name: Install dependencies
        run: |
          pip install -e ".[dev]"
      - name: Run tests
        run: pytest -v
        env:
          STIX2TABULAR_OFFLINE: "true"
```

---

## CHANGELOG.md

```markdown
# Changelog

## [0.1.0] - YYYY-MM-DD

### Added
- Initial release
- `stix_to_tables()` function converting STIX bundles to dict of Pandas DataFrames
- `save_tables()` and `load_tables()` for lossless Parquet round-tripping
- Support for STIX 2.0 and 2.1
- Separate DataFrames per STIX object type
- Relationships as lean edge table
- Sightings as dedicated DataFrame
- SCO inclusion/exclusion toggle
- File, directory, JSON string, and dict input support
- Multiple bundle merging with deduplication
- MITRE ATT&CK integration test
```

---

## .gitignore

Standard Python .gitignore. Include:
```
__pycache__/
*.py[cod]
*.egg-info/
dist/
build/
.eggs/
*.egg
.pytest_cache/
.tox/
venv/
.venv/
*.so
.DS_Store
```

---

## Implementation Notes

### Error Handling
- If a relationship's `source_ref` or `target_ref` refers to an object not in the bundle, still include the relationship row (the ref columns are just strings — they don't need to resolve to a row in another DataFrame). Log a debug message but don't crash. This is common in real-world STIX data where bundles are incomplete.
- If JSON parsing fails, raise a clear `ValueError` with the position/content that failed.
- If an object has no `type` field, skip it with a warning.
- If an object has no `id` field, skip it with a warning.
- If a directory contains no `.json` files, return `{}` (not an error).

### Performance Considerations
- The ATT&CK Enterprise bundle is ~30MB / ~14,000+ objects. The conversion should complete in under 10 seconds on a modern machine.
- Build DataFrames efficiently: collect all dicts for a type into a list, then call `pd.DataFrame(list_of_dicts)` once per type — do NOT append rows one at a time.
- Use `json.load()` directly for parsing, not the `stix2` library's parsing/validation (which is slow). The `stix2` dependency is listed for ecosystem compatibility, but core parsing should be raw JSON dict processing for speed.

### Code Style
- Type hints on all public functions
- Docstrings on all public functions (Google style)
- Keep it simple — no metaclasses, no abstract base classes, no over-engineering. This is a utility library.

### Persistence / Saving DataFrames

The library includes `save_tables()` and `load_tables()` for lossless Parquet round-tripping (see API Design section above). The README should show this as the primary way to persist data, with a brief CSV caveat note for users who need CSV.

The `stix_to_tables()` docstring should mention that list/dict columns are native Python objects and reference `save_tables()` for persistence.

### Key Design Decisions and Rationale

**Why dict of DataFrames, not one big DataFrame?**
STIX types have different schemas. A single DataFrame would have the union of all columns across all types, with most cells NaN. That's wasteful and confusing. Separate DataFrames per type give clean, dense tables that match how analysts actually work ("show me all malware", "show me all threat actors").

**Why Python lists in cells instead of JSON strings?**
JSON strings require `json.loads()` every time you want to work with the data. Python lists work natively with pandas operations like `.explode()`, list comprehensions, and `.apply()`. The tradeoff is CSV export doesn't work cleanly, but that's not the primary use case — the primary use case is in-memory analysis and ML feature engineering.

**Why a separate relationships DataFrame instead of one per relationship_type?**
Most analysis workflows filter relationships by type anyway (`rels.query("relationship_type == 'uses'")`). Having one table makes cross-type queries easy (e.g., "all relationships involving this threat actor"). Users who want per-type DataFrames can `groupby("relationship_type")` trivially.

**Why independent from stix2nx?**
Different users need different things. Graph people shouldn't need pandas. Tabular people shouldn't need networkx. Keeping them independent means lighter installs, simpler dependency trees, and no coordination overhead between the two projects.
