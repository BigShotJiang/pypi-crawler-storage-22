#!/usr/bin/env python3
"""Demonstrate stix2tabular with the ATT&CK curated subset.

Usage:
    python examples/analyze_attack.py
"""

import os

from stix2tabular import load_tables, save_tables, stix_to_tables

SUBSET_PATH = os.path.join(
    os.path.dirname(__file__), "..", "tests", "data", "attack-subset.json"
)


def main():
    print("Loading ATT&CK subset...")
    tables = stix_to_tables(SUBSET_PATH)

    # Print table keys and shapes
    print(f"\nTables: {len(tables)} types")
    print("-" * 40)
    for key, df in sorted(tables.items()):
        print(f"  {key:25s} {len(df):5d} rows x {len(df.columns):2d} cols")

    # Query techniques used by a specific actor
    if "intrusion-set" in tables and "relationships" in tables:
        rels = tables["relationships"]
        actors = tables["intrusion-set"]
        if len(actors) > 0:
            actor = actors.iloc[0]
            actor_id = actor["id"]
            actor_name = actor["name"]
            technique_ids = rels.query(
                "source_ref == @actor_id and relationship_type == 'uses'"
            )["target_ref"]

            if "attack-pattern" in tables:
                techniques = tables["attack-pattern"][
                    tables["attack-pattern"]["id"].isin(technique_ids)
                ]["name"]
                print(f"\nTechniques used by {actor_name}:")
                for t in techniques:
                    print(f"  - {t}")

    # Relationship type counts
    if "relationships" in tables:
        print("\nRelationship type counts:")
        counts = tables["relationships"]["relationship_type"].value_counts()
        for rel_type, count in counts.items():
            print(f"  {rel_type}: {count}")

    # Demo save/load round-trip
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        out_dir = os.path.join(tmpdir, "attack_tables")
        save_tables(tables, out_dir)
        print(f"\nSaved {len(tables)} tables to Parquet")

        loaded = load_tables(out_dir)
        print(f"Loaded {len(loaded)} tables back from Parquet")
        for key in sorted(loaded.keys()):
            assert len(loaded[key]) == len(tables[key])
        print("Round-trip verified: all row counts match!")


if __name__ == "__main__":
    main()
