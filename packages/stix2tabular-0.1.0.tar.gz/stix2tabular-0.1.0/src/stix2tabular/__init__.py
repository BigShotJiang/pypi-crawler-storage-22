"""stix2tabular — Convert STIX cyber threat intelligence bundles to Pandas DataFrames."""

from typing import Union

import pandas as pd

from .converter import convert_bundles
from .parsers import parse_source
from .persistence import load_tables, save_tables

__version__ = "0.1.0"


def stix_to_tables(
    source: Union[str, list[str], list[dict]],
    include_scos: bool = True,
) -> dict[str, pd.DataFrame]:
    """Convert STIX bundles into a dict of Pandas DataFrames.

    Args:
        source: One of:
            - str: file path (.json) or directory path
            - list[str]: list of JSON strings, each a full STIX bundle
            - list[dict]: list of already-parsed STIX bundle dicts
        include_scos: Whether to include STIX Cyber-observable Objects (SCOs)
            as their own DataFrames. Default True.

    Returns:
        Dict mapping STIX type names to DataFrames. Special keys:
        - "relationships": all relationship objects as a lean edge table
        - "sightings": all sighting objects
        Each SDO type gets its own key (e.g., "malware", "threat-actor").
        When include_scos=True, each SCO type also gets its own key
        (e.g., "ipv4-addr", "domain-name").

        List-valued fields (aliases, kill_chain_phases, external_references, etc.)
        are kept as Python lists in DataFrame cells. Dict-valued fields (hashes,
        extensions, etc.) are kept as Python dicts. Use save_tables() for lossless
        Parquet persistence.
    """
    bundles = parse_source(source)
    return convert_bundles(bundles, include_scos=include_scos)


__all__ = [
    "stix_to_tables",
    "save_tables",
    "load_tables",
    "__version__",
]
