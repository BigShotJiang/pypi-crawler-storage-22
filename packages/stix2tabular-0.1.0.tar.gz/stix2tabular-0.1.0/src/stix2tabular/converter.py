"""Core conversion logic: STIX bundle dicts to dict of Pandas DataFrames."""

import logging
from collections import defaultdict

import pandas as pd

from .utils import (
    extract_stix20_embedded_scos,
    is_relationship,
    is_sco,
    is_sdo,
    is_sighting,
    is_skippable,
)

logger = logging.getLogger(__name__)


def convert_bundles(
    bundles: list[dict], include_scos: bool = True
) -> dict[str, pd.DataFrame]:
    """Convert a list of parsed STIX bundle dicts into a dict of DataFrames.

    Args:
        bundles: List of parsed STIX bundle dicts (each with a top-level "objects" key).
        include_scos: Whether to include STIX Cyber-observable Objects in the output.

    Returns:
        Dict mapping STIX type names to DataFrames. Special keys:
        - "relationships": all relationship objects
        - "sightings": all sighting objects
        Each SDO/SCO type gets its own key (e.g., "malware", "ipv4-addr").
    """
    type_buckets: dict[str, list[dict]] = defaultdict(list)
    relationship_rows: list[dict] = []
    sighting_rows: list[dict] = []

    for bundle in bundles:
        _process_bundle(
            bundle, type_buckets, relationship_rows, sighting_rows, include_scos
        )

    result: dict[str, pd.DataFrame] = {}

    # Build DataFrames for each type bucket (SDOs and optionally SCOs)
    for obj_type, rows in type_buckets.items():
        df = pd.DataFrame(rows)
        # Deduplicate by id, last-write-wins
        if "id" in df.columns:
            df = df.drop_duplicates(subset="id", keep="last")
            df = df.reset_index(drop=True)
        result[obj_type] = df

    # Build relationships DataFrame (accumulated, not deduplicated)
    if relationship_rows:
        result["relationships"] = pd.DataFrame(relationship_rows).reset_index(
            drop=True
        )

    # Build sightings DataFrame (accumulated, not deduplicated)
    if sighting_rows:
        result["sightings"] = pd.DataFrame(sighting_rows).reset_index(drop=True)

    return result


def _process_bundle(
    bundle: dict,
    type_buckets: dict[str, list[dict]],
    relationship_rows: list[dict],
    sighting_rows: list[dict],
    include_scos: bool,
) -> None:
    """Process a single STIX bundle, appending objects to the appropriate buckets.

    Args:
        bundle: A parsed STIX bundle dict.
        type_buckets: Dict of type name -> list of object dicts (mutated in place).
        relationship_rows: List of relationship object dicts (mutated in place).
        sighting_rows: List of sighting object dicts (mutated in place).
        include_scos: Whether to include SCO objects.
    """
    objects = bundle.get("objects", [])
    if not isinstance(objects, list):
        logger.warning("Bundle 'objects' is not a list, skipping")
        return

    for obj in objects:
        if not isinstance(obj, dict):
            continue

        obj_type = obj.get("type")
        if not obj_type:
            logger.warning("Object missing 'type' field, skipping: %s", obj)
            continue

        obj_id = obj.get("id")
        if not obj_id:
            # marking-definitions and some metadata may lack id in edge cases
            if not is_skippable(obj):
                logger.warning(
                    "Object missing 'id' field, skipping: type=%s", obj_type
                )
            continue

        # Skip marking-definition and language-content
        if is_skippable(obj):
            continue

        # Relationships → accumulated
        if is_relationship(obj):
            relationship_rows.append(dict(obj))
            continue

        # Sightings → accumulated
        if is_sighting(obj):
            sighting_rows.append(dict(obj))
            continue

        # SCOs
        if is_sco(obj):
            if include_scos:
                type_buckets[obj_type].append(dict(obj))
            continue

        # SDOs (including custom x-mitre-* types)
        if is_sdo(obj):
            type_buckets[obj_type].append(dict(obj))

            # STIX 2.0 observed-data with embedded SCOs
            if obj_type == "observed-data" and "objects" in obj and include_scos:
                embedded_scos = extract_stix20_embedded_scos(obj)
                for sco in embedded_scos:
                    sco_type = sco.get("type", "")
                    if sco_type:
                        type_buckets[sco_type].append(sco)
            continue

        # Unknown type — still bucket it (might be a custom type)
        logger.debug("Unknown STIX type '%s', including as-is", obj_type)
        type_buckets[obj_type].append(dict(obj))
