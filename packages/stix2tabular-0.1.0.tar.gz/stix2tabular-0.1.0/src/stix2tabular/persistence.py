"""Parquet persistence for STIX table round-tripping."""

import logging
import os
from glob import glob
from pathlib import Path

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def save_tables(tables: dict[str, pd.DataFrame], directory: str) -> None:
    """Save all DataFrames to a directory as Parquet files.

    Args:
        tables: Dict returned by stix_to_tables(), mapping type names to DataFrames.
        directory: Path to output directory. Created if it doesn't exist (including parents).

    Raises:
        ValueError: If tables is not a dict or contains non-DataFrame values.
    """
    if not isinstance(tables, dict):
        raise ValueError(
            f"tables must be a dict, got {type(tables).__name__}"
        )
    for key, value in tables.items():
        if not isinstance(value, pd.DataFrame):
            raise ValueError(
                f"tables[{key!r}] must be a pandas DataFrame, got {type(value).__name__}"
            )

    Path(directory).mkdir(parents=True, exist_ok=True)

    for key, df in tables.items():
        file_path = os.path.join(directory, f"{key}.parquet")
        df.to_parquet(file_path, engine="pyarrow", index=False)


def load_tables(directory: str) -> dict[str, pd.DataFrame]:
    """Load DataFrames from a directory of Parquet files.

    Args:
        directory: Path to a directory containing .parquet files previously
            written by save_tables().

    Returns:
        Dict mapping type names (derived from filenames) to DataFrames.
        Returns {} if the directory contains no .parquet files.

    Raises:
        FileNotFoundError: If the directory doesn't exist.
    """
    if not os.path.isdir(directory):
        raise FileNotFoundError(f"Directory not found: {directory}")

    pattern = os.path.join(directory, "*.parquet")
    files = sorted(glob(pattern))

    if not files:
        return {}

    tables: dict[str, pd.DataFrame] = {}
    for file_path in files:
        key = Path(file_path).stem
        df = pd.read_parquet(file_path, engine="pyarrow")
        _restore_python_types(df)
        tables[key] = df

    return tables


def _restore_python_types(df: pd.DataFrame) -> None:
    """Convert numpy arrays back to Python lists after Parquet round-trip.

    Pyarrow stores Python lists as Arrow list arrays. When read back,
    they may be returned as numpy arrays. This function converts them
    back to native Python lists for API consistency.
    """
    for col in df.columns:
        if len(df) == 0:
            continue
        sample = df[col].dropna()
        if len(sample) == 0:
            continue
        first = sample.iloc[0]
        if isinstance(first, np.ndarray):
            df[col] = df[col].apply(
                lambda x: x.tolist() if isinstance(x, np.ndarray) else x
            )
