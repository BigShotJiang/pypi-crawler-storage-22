"""Integration test against MITRE ATT&CK curated subset."""

import os

import pytest

OFFLINE_FLAG = os.environ.get("STIX2TABULAR_OFFLINE", "false").lower() == "true"
ATTACK_URL = "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json"
SUBSET_PATH = os.path.join(os.path.dirname(__file__), "data", "attack-subset.json")


@pytest.fixture
def attack_bundle_path(tmp_path):
    """Get ATT&CK bundle. Default: live download. Failover: curated subset.
    Set STIX2TABULAR_OFFLINE=true to skip live download entirely."""
    if not OFFLINE_FLAG:
        try:
            import requests
            print(f"\nDownloading live ATT&CK bundle from {ATTACK_URL}...")
            resp = requests.get(ATTACK_URL, timeout=120)
            resp.raise_for_status()
            live_path = tmp_path / "enterprise-attack.json"
            live_path.write_text(resp.text)
            print(f"Using live ATT&CK bundle ({len(resp.text) // 1024 // 1024}MB)")
            return str(live_path)
        except Exception as e:
            print(f"\nLive ATT&CK download failed ({e}), falling back to curated subset")
            return SUBSET_PATH
    print("\nOffline mode: using curated ATT&CK subset")
    return SUBSET_PATH


def test_attack_loads(attack_bundle_path):
    """ATT&CK bundle converts to tables without error."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    assert isinstance(tables, dict)
    assert len(tables) > 0


def test_attack_has_expected_types(attack_bundle_path):
    """ATT&CK tables contain the core type keys."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    assert "attack-pattern" in tables
    assert "intrusion-set" in tables
    assert "malware" in tables
    assert "tool" in tables
    assert "relationships" in tables


def test_attack_row_counts(attack_bundle_path):
    """ATT&CK tables have meaningful row counts."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # The curated subset has ~30 attack patterns, ~8 intrusion sets, etc.
    assert len(tables["attack-pattern"]) >= 10
    assert len(tables["intrusion-set"]) >= 3
    assert len(tables["relationships"]) >= 50


def test_attack_columns(attack_bundle_path):
    """ATT&CK DataFrames have expected columns."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # Every type table should have id, type, created, modified
    for key, df in tables.items():
        assert "id" in df.columns, f"Missing 'id' column in {key}"
        assert "type" in df.columns, f"Missing 'type' column in {key}"
    # attack-patterns should have name
    assert "name" in tables["attack-pattern"].columns
    # relationships should have the edge columns
    rel = tables["relationships"]
    assert "source_ref" in rel.columns
    assert "target_ref" in rel.columns
    assert "relationship_type" in rel.columns


def test_attack_relationship_types(attack_bundle_path):
    """ATT&CK relationships include expected types."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    rel_types = set(tables["relationships"]["relationship_type"].unique())
    assert "uses" in rel_types


def test_attack_list_fields(attack_bundle_path):
    """List-valued fields are actual Python lists, not strings."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # external_references is a common list field on attack-patterns
    if "external_references" in tables["attack-pattern"].columns:
        first_valid = tables["attack-pattern"]["external_references"].dropna().iloc[0]
        assert isinstance(first_valid, list), f"Expected list, got {type(first_valid)}"


def test_attack_no_scos(attack_bundle_path):
    """include_scos=False excludes SCO type tables."""
    from stix2tabular import stix_to_tables
    tables_with = stix_to_tables(attack_bundle_path, include_scos=True)
    tables_without = stix_to_tables(attack_bundle_path, include_scos=False)
    assert len(tables_with) >= len(tables_without)
    # SCO types should be absent
    sco_types = {"ipv4-addr", "domain-name", "file", "url", "email-addr",
                 "ipv6-addr", "mac-addr", "mutex", "process", "software",
                 "user-account", "windows-registry-key", "network-traffic",
                 "artifact", "directory", "autonomous-system", "email-message"}
    for sco_type in sco_types:
        assert sco_type not in tables_without


def test_attack_sightings(attack_bundle_path):
    """Sighting objects in the subset go into tables['sightings']."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    # The curated subset includes synthetic sightings; the live ATT&CK bundle does not
    if "sightings" not in tables:
        pytest.skip("Live ATT&CK bundle contains no sighting objects")
    assert len(tables["sightings"]) >= 1
    assert "sighting_of_ref" in tables["sightings"].columns


def test_attack_no_marking_definitions(attack_bundle_path):
    """Marking definitions are excluded from output."""
    from stix2tabular import stix_to_tables
    tables = stix_to_tables(attack_bundle_path)
    assert "marking-definition" not in tables
