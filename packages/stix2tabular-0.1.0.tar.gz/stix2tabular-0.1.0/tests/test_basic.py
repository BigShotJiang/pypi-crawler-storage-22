"""Unit tests with small hand-crafted bundles."""

import json
import math

import pandas as pd
import pytest

from stix2tabular import stix_to_tables


def test_sdo_types_get_own_keys(basic_bundle):
    """Each SDO type gets its own key in the output dict."""
    tables = stix_to_tables([basic_bundle])
    assert "threat-actor" in tables
    assert "malware" in tables
    assert "attack-pattern" in tables


def test_dataframe_columns_match_properties(basic_bundle):
    """DataFrame columns match the STIX properties of that type."""
    tables = stix_to_tables([basic_bundle])
    ta = tables["threat-actor"]
    assert "id" in ta.columns
    assert "type" in ta.columns
    assert "name" in ta.columns
    assert "aliases" in ta.columns
    assert "threat_actor_types" in ta.columns
    assert "sophistication" in ta.columns


def test_id_column_present_and_correct(basic_bundle):
    """The id column is present and matches STIX IDs."""
    tables = stix_to_tables([basic_bundle])
    assert tables["threat-actor"]["id"].iloc[0] == "threat-actor--1"
    assert tables["malware"]["id"].iloc[0] == "malware--1"


def test_list_valued_properties_are_lists(basic_bundle):
    """List-valued properties remain Python lists in DataFrame cells."""
    tables = stix_to_tables([basic_bundle])
    aliases = tables["threat-actor"]["aliases"].iloc[0]
    assert isinstance(aliases, list)
    assert aliases == ["BadGuys", "Villains"]

    malware_types = tables["malware"]["malware_types"].iloc[0]
    assert isinstance(malware_types, list)
    assert malware_types == ["trojan", "downloader"]


def test_dict_valued_properties_are_dicts(sco_bundle):
    """Dict-valued properties remain Python dicts in DataFrame cells."""
    tables = stix_to_tables([sco_bundle])
    hashes = tables["file"]["hashes"].iloc[0]
    assert isinstance(hashes, dict)
    assert "SHA-256" in hashes


def test_all_properties_preserved(basic_bundle):
    """All properties are preserved as columns."""
    tables = stix_to_tables([basic_bundle])
    ap = tables["attack-pattern"]
    assert "kill_chain_phases" in ap.columns
    kcp = ap["kill_chain_phases"].iloc[0]
    assert isinstance(kcp, list)
    assert kcp[0]["kill_chain_name"] == "mitre-attack"


def test_marking_definitions_excluded(marking_bundle):
    """Marking definitions and language content are excluded from output."""
    tables = stix_to_tables([marking_bundle])
    assert "marking-definition" not in tables
    assert "language-content" not in tables
    # But the threat-actor should still be there
    assert "threat-actor" in tables


def test_empty_bundle_returns_empty_dict(empty_bundle):
    """Empty bundle returns {}."""
    tables = stix_to_tables([empty_bundle])
    assert tables == {}


def test_no_relationships_key_when_absent(nodes_only_bundle):
    """Bundle with only SDOs and no relationships has no 'relationships' key."""
    tables = stix_to_tables([nodes_only_bundle])
    assert "relationships" not in tables
    assert "threat-actor" in tables
    assert "malware" in tables


def test_nan_for_missing_values(three_malware_bundle):
    """Missing values become NaN."""
    tables = stix_to_tables([three_malware_bundle])
    df = tables["malware"]
    assert len(df) == 3
    # malware--tm2 has no malware_types or aliases
    tm2 = df[df["id"] == "malware--tm2"].iloc[0]
    assert pd.isna(tm2.get("malware_types")) or tm2.get("malware_types") is None
    assert pd.isna(tm2.get("aliases")) or tm2.get("aliases") is None


def test_three_malware_row_count(three_malware_bundle):
    """A bundle with 3 malware objects produces 3 rows."""
    tables = stix_to_tables([three_malware_bundle])
    assert len(tables["malware"]) == 3


def test_column_types_sensible(basic_bundle):
    """Column types are sensible (strings are str, lists are list)."""
    tables = stix_to_tables([basic_bundle])
    ta = tables["threat-actor"]
    assert isinstance(ta["name"].iloc[0], str)
    assert isinstance(ta["id"].iloc[0], str)
    assert isinstance(ta["aliases"].iloc[0], list)


def test_json_string_input(basic_bundle_json):
    """A list of JSON strings is parsed correctly."""
    tables = stix_to_tables([basic_bundle_json])
    assert "threat-actor" in tables
    assert "malware" in tables
    assert "relationships" in tables


def test_file_input(basic_bundle, tmp_path):
    """A file path input is parsed correctly."""
    file_path = tmp_path / "bundle.json"
    file_path.write_text(json.dumps(basic_bundle))
    tables = stix_to_tables(str(file_path))
    assert "threat-actor" in tables
    assert "malware" in tables


def test_dict_list_input(basic_bundle):
    """A list of dicts is parsed correctly."""
    tables = stix_to_tables([basic_bundle])
    assert "threat-actor" in tables
    assert len(tables["threat-actor"]) == 1
