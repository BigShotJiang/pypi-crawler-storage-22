"""Tests for directory input."""

import json

import pytest

from stix2tabular import stix_to_tables


def test_directory_multiple_files(tmp_path, merge_bundle_a, merge_bundle_b):
    """Multiple JSON files in a directory are merged."""
    (tmp_path / "bundle_a.json").write_text(json.dumps(merge_bundle_a))
    (tmp_path / "bundle_b.json").write_text(json.dumps(merge_bundle_b))

    tables = stix_to_tables(str(tmp_path))
    assert "threat-actor" in tables
    assert len(tables["threat-actor"]) == 2
    assert "relationships" in tables
    assert len(tables["relationships"]) == 2


def test_directory_non_json_ignored(tmp_path, basic_bundle):
    """Non-.json files in the directory are ignored."""
    (tmp_path / "bundle.json").write_text(json.dumps(basic_bundle))
    (tmp_path / "readme.txt").write_text("not a bundle")
    (tmp_path / "data.csv").write_text("a,b,c")

    tables = stix_to_tables(str(tmp_path))
    assert "threat-actor" in tables


def test_directory_empty(tmp_path):
    """Empty directory returns {}."""
    tables = stix_to_tables(str(tmp_path))
    assert tables == {}


def test_directory_single_file(tmp_path, basic_bundle):
    """Directory with one file is the same as single file input."""
    (tmp_path / "single.json").write_text(json.dumps(basic_bundle))

    tables = stix_to_tables(str(tmp_path))
    assert "threat-actor" in tables
    assert "malware" in tables
    assert "attack-pattern" in tables
    assert "relationships" in tables
