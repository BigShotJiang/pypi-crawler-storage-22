"""Tests for merging multiple bundles."""

import json

import pandas as pd
import pytest

from stix2tabular import stix_to_tables


def test_merge_no_overlap(merge_bundle_a, merge_bundle_c):
    """Merging two bundles with no overlap includes all rows."""
    tables = stix_to_tables([merge_bundle_a, merge_bundle_c])
    assert "threat-actor" in tables
    assert "malware" in tables
    assert "tool" in tables
    assert len(tables["threat-actor"]) == 1
    assert len(tables["tool"]) == 1


def test_merge_overlapping_ids_last_wins(merge_bundle_a, merge_bundle_b):
    """Overlapping node IDs are deduplicated, last-write-wins."""
    tables = stix_to_tables([merge_bundle_a, merge_bundle_b])
    malware_df = tables["malware"]
    # malware--shared appears in both bundles, bundle_b is last
    assert len(malware_df) == 1
    assert malware_df["name"].iloc[0] == "Shared Malware v2"
    assert malware_df["is_family"].iloc[0] == False


def test_merge_relationships_accumulated(merge_bundle_a, merge_bundle_b):
    """Relationships are accumulated, not deduplicated."""
    tables = stix_to_tables([merge_bundle_a, merge_bundle_b])
    rel = tables["relationships"]
    assert len(rel) == 2
    ids = set(rel["id"])
    assert "relationship--merge-a" in ids
    assert "relationship--merge-b" in ids


def test_merge_three_bundles(merge_bundle_a, merge_bundle_b, merge_bundle_c):
    """Merging 3+ bundles works correctly."""
    tables = stix_to_tables([merge_bundle_a, merge_bundle_b, merge_bundle_c])
    # 2 unique threat-actors + 1 malware (deduped) + 1 tool
    assert len(tables["threat-actor"]) == 2
    assert len(tables["malware"]) == 1
    assert len(tables["tool"]) == 1
    assert len(tables["relationships"]) == 2


def test_merge_column_union():
    """Column sets are the union across all bundles for a given type."""
    bundle_a = {
        "type": "bundle",
        "id": "bundle--col-a",
        "objects": [
            {
                "type": "malware",
                "id": "malware--col-a",
                "spec_version": "2.1",
                "created": "2023-01-01T00:00:00.000Z",
                "modified": "2023-01-01T00:00:00.000Z",
                "name": "Malware A",
                "is_family": True,
            }
        ],
    }
    bundle_b = {
        "type": "bundle",
        "id": "bundle--col-b",
        "objects": [
            {
                "type": "malware",
                "id": "malware--col-b",
                "spec_version": "2.1",
                "created": "2023-01-01T00:00:00.000Z",
                "modified": "2023-01-01T00:00:00.000Z",
                "name": "Malware B",
                "is_family": False,
                "description": "A description",
            }
        ],
    }
    tables = stix_to_tables([bundle_a, bundle_b])
    malware_df = tables["malware"]
    assert "description" in malware_df.columns
    assert "is_family" in malware_df.columns
    # Malware A should have NaN for description
    a_row = malware_df[malware_df["id"] == "malware--col-a"].iloc[0]
    assert pd.isna(a_row["description"])


def test_merge_json_strings():
    """Merging via JSON string input works."""
    bundle_a = json.dumps({
        "type": "bundle",
        "id": "bundle--js-a",
        "objects": [
            {
                "type": "malware",
                "id": "malware--js-a",
                "spec_version": "2.1",
                "created": "2023-01-01T00:00:00.000Z",
                "modified": "2023-01-01T00:00:00.000Z",
                "name": "JS Malware",
                "is_family": True,
            }
        ],
    })
    bundle_b = json.dumps({
        "type": "bundle",
        "id": "bundle--js-b",
        "objects": [
            {
                "type": "tool",
                "id": "tool--js-b",
                "spec_version": "2.1",
                "created": "2023-01-01T00:00:00.000Z",
                "modified": "2023-01-01T00:00:00.000Z",
                "name": "JS Tool",
            }
        ],
    })
    tables = stix_to_tables([bundle_a, bundle_b])
    assert "malware" in tables
    assert "tool" in tables
