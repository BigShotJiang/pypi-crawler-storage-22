"""Tests for save_tables / load_tables round-trip."""

import os

import pandas as pd
import pytest

from stix2tabular import load_tables, save_tables, stix_to_tables


def test_round_trip(basic_bundle, tmp_path):
    """Round-trip: stix_to_tables -> save_tables -> load_tables matches."""
    tables = stix_to_tables([basic_bundle])
    out_dir = str(tmp_path / "output")
    save_tables(tables, out_dir)
    loaded = load_tables(out_dir)

    assert set(tables.keys()) == set(loaded.keys())
    for key in tables:
        pd.testing.assert_frame_equal(
            tables[key].reset_index(drop=True),
            loaded[key].reset_index(drop=True),
        )


def test_list_columns_survive_round_trip(basic_bundle, tmp_path):
    """List-valued columns survive Parquet round-trip as actual Python lists."""
    tables = stix_to_tables([basic_bundle])
    out_dir = str(tmp_path / "output")
    save_tables(tables, out_dir)
    loaded = load_tables(out_dir)

    aliases = loaded["threat-actor"]["aliases"].iloc[0]
    assert isinstance(aliases, list)
    assert aliases == ["BadGuys", "Villains"]


def test_dict_columns_survive_round_trip(sco_bundle, tmp_path):
    """Dict-valued columns survive Parquet round-trip as actual Python dicts."""
    tables = stix_to_tables([sco_bundle])
    out_dir = str(tmp_path / "output")
    save_tables(tables, out_dir)
    loaded = load_tables(out_dir)

    hashes = loaded["file"]["hashes"].iloc[0]
    assert isinstance(hashes, dict)
    assert "SHA-256" in hashes


def test_nan_survives_round_trip(three_malware_bundle, tmp_path):
    """NaN values survive Parquet round-trip."""
    tables = stix_to_tables([three_malware_bundle])
    out_dir = str(tmp_path / "output")
    save_tables(tables, out_dir)
    loaded = load_tables(out_dir)

    tm2 = loaded["malware"][loaded["malware"]["id"] == "malware--tm2"].iloc[0]
    assert pd.isna(tm2.get("aliases")) or tm2.get("aliases") is None


def test_file_naming(basic_bundle, tmp_path):
    """save_tables produces files named {type}.parquet."""
    tables = stix_to_tables([basic_bundle])
    out_dir = str(tmp_path / "output")
    save_tables(tables, out_dir)

    assert os.path.isfile(os.path.join(out_dir, "threat-actor.parquet"))
    assert os.path.isfile(os.path.join(out_dir, "malware.parquet"))
    assert os.path.isfile(os.path.join(out_dir, "attack-pattern.parquet"))
    assert os.path.isfile(os.path.join(out_dir, "relationships.parquet"))


def test_load_tables_correct_keys(basic_bundle, tmp_path):
    """load_tables reconstructs correct dict keys from filenames."""
    tables = stix_to_tables([basic_bundle])
    out_dir = str(tmp_path / "output")
    save_tables(tables, out_dir)
    loaded = load_tables(out_dir)

    assert "threat-actor" in loaded
    assert "malware" in loaded
    assert "attack-pattern" in loaded
    assert "relationships" in loaded


def test_save_creates_directory(tmp_path):
    """save_tables creates the directory if it doesn't exist."""
    tables = {"test": pd.DataFrame({"id": ["a", "b"], "value": [1, 2]})}
    nested_dir = str(tmp_path / "deep" / "nested" / "dir")
    save_tables(tables, nested_dir)

    assert os.path.isdir(nested_dir)
    assert os.path.isfile(os.path.join(nested_dir, "test.parquet"))


def test_save_overwrites_existing(tmp_path):
    """save_tables overwrites existing files without error."""
    out_dir = str(tmp_path / "output")
    tables_v1 = {"test": pd.DataFrame({"id": ["a"], "value": [1]})}
    tables_v2 = {"test": pd.DataFrame({"id": ["b"], "value": [2]})}

    save_tables(tables_v1, out_dir)
    save_tables(tables_v2, out_dir)

    loaded = load_tables(out_dir)
    assert loaded["test"]["id"].iloc[0] == "b"


def test_save_does_not_delete_other_files(tmp_path):
    """save_tables does not delete other files in the directory."""
    out_dir = str(tmp_path / "output")
    os.makedirs(out_dir)
    other_file = os.path.join(out_dir, "other.txt")
    with open(other_file, "w") as f:
        f.write("keep me")

    tables = {"test": pd.DataFrame({"id": ["a"]})}
    save_tables(tables, out_dir)

    assert os.path.isfile(other_file)


def test_load_nonexistent_directory_raises():
    """load_tables on a non-existent directory raises FileNotFoundError."""
    with pytest.raises(FileNotFoundError):
        load_tables("/nonexistent/path/that/does/not/exist")


def test_load_empty_directory(tmp_path):
    """load_tables on an empty directory returns {}."""
    result = load_tables(str(tmp_path))
    assert result == {}


def test_save_validates_input():
    """save_tables raises ValueError if tables is not a dict or contains non-DataFrame."""
    with pytest.raises(ValueError):
        save_tables("not a dict", "/tmp/test")

    with pytest.raises(ValueError):
        save_tables({"key": "not a dataframe"}, "/tmp/test")


def test_empty_dataframe_round_trip(tmp_path):
    """Empty DataFrames (0 rows) save and load correctly, preserving columns."""
    tables = {"empty": pd.DataFrame({"id": pd.Series(dtype="str"), "name": pd.Series(dtype="str")})}
    out_dir = str(tmp_path / "output")
    save_tables(tables, out_dir)
    loaded = load_tables(out_dir)

    assert "empty" in loaded
    assert len(loaded["empty"]) == 0
    assert "id" in loaded["empty"].columns
    assert "name" in loaded["empty"].columns
