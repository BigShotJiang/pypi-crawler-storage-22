"""Tests for relationships DataFrame."""

import math

import pandas as pd
import pytest

from stix2tabular import stix_to_tables


def test_relationships_in_output(basic_bundle):
    """Relationship objects go into tables['relationships']."""
    tables = stix_to_tables([basic_bundle])
    assert "relationships" in tables
    assert isinstance(tables["relationships"], pd.DataFrame)


def test_required_columns(basic_bundle):
    """Required columns are present on relationships."""
    tables = stix_to_tables([basic_bundle])
    rel = tables["relationships"]
    assert "id" in rel.columns
    assert "type" in rel.columns
    assert "source_ref" in rel.columns
    assert "target_ref" in rel.columns
    assert "relationship_type" in rel.columns


def test_optional_fields_present(relationship_rich_bundle):
    """Optional fields (start_time, stop_time, confidence) appear when present."""
    tables = stix_to_tables([relationship_rich_bundle])
    rel = tables["relationships"]
    assert "start_time" in rel.columns
    assert "stop_time" in rel.columns
    assert "confidence" in rel.columns
    # The uses relationship has all three
    uses = rel[rel["relationship_type"] == "uses"].iloc[0]
    assert uses["start_time"] == "2023-01-01T00:00:00.000Z"
    assert uses["confidence"] == 85


def test_optional_fields_nan_when_absent(relationship_rich_bundle):
    """Optional fields are NaN when absent on specific rows."""
    tables = stix_to_tables([relationship_rich_bundle])
    rel = tables["relationships"]
    targets = rel[rel["relationship_type"] == "targets"].iloc[0]
    assert pd.isna(targets.get("start_time")) or targets.get("start_time") is None
    assert pd.isna(targets.get("stop_time")) or targets.get("stop_time") is None


def test_multiple_relationship_types(relationship_rich_bundle):
    """Multiple relationship types all in same DataFrame."""
    tables = stix_to_tables([relationship_rich_bundle])
    rel = tables["relationships"]
    rel_types = set(rel["relationship_type"].unique())
    assert "uses" in rel_types
    assert "targets" in rel_types
    assert "exploits" in rel_types


def test_relationship_id_preserved(basic_bundle):
    """Relationship object's own id is preserved."""
    tables = stix_to_tables([basic_bundle])
    rel = tables["relationships"]
    ids = set(rel["id"])
    assert "relationship--1" in ids
    assert "relationship--2" in ids


def test_relationship_extra_properties(relationship_rich_bundle):
    """Non-standard properties on relationship objects become columns."""
    tables = stix_to_tables([relationship_rich_bundle])
    rel = tables["relationships"]
    # confidence is an extra property
    assert "confidence" in rel.columns
