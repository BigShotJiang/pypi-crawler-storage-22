"""Tests for SCO inclusion/exclusion."""

import pandas as pd
import pytest

from stix2tabular import stix_to_tables


def test_sco_types_get_own_keys(sco_bundle):
    """SCO types each get their own DataFrame key when include_scos=True."""
    tables = stix_to_tables([sco_bundle], include_scos=True)
    assert "ipv4-addr" in tables
    assert "domain-name" in tables
    assert "file" in tables
    assert "url" in tables
    assert "email-addr" in tables


def test_scos_excluded_when_false(sco_bundle):
    """SCOs are excluded entirely when include_scos=False."""
    tables = stix_to_tables([sco_bundle], include_scos=False)
    assert "ipv4-addr" not in tables
    assert "domain-name" not in tables
    assert "file" not in tables
    assert "url" not in tables
    assert "email-addr" not in tables
    # SDOs and relationships should still be present
    assert "indicator" in tables
    assert "relationships" in tables


def test_sco_properties_mapped(sco_bundle):
    """SCO properties are correctly mapped to DataFrame columns."""
    tables = stix_to_tables([sco_bundle])
    ip = tables["ipv4-addr"]
    assert "value" in ip.columns
    assert ip["value"].iloc[0] == "198.51.100.1"

    domain = tables["domain-name"]
    assert "value" in domain.columns
    assert domain["value"].iloc[0] == "evil.example.com"


def test_file_hashes_as_dict(sco_bundle):
    """File hashes dict is kept as a Python dict in the cell."""
    tables = stix_to_tables([sco_bundle])
    file_df = tables["file"]
    assert "hashes" in file_df.columns
    hashes = file_df["hashes"].iloc[0]
    assert isinstance(hashes, dict)
    assert "SHA-256" in hashes
    assert "MD5" in hashes


def test_multi_sco_row_counts(multi_sco_bundle):
    """Multiple SCOs of the same type produce correct row counts."""
    tables = stix_to_tables([multi_sco_bundle])
    assert len(tables["ipv4-addr"]) == 2
    assert len(tables["domain-name"]) == 3


def test_url_and_email_scos(sco_bundle):
    """URL and email-addr SCOs have value columns."""
    tables = stix_to_tables([sco_bundle])
    assert tables["url"]["value"].iloc[0] == "https://evil.example.com/payload"
    assert tables["email-addr"]["value"].iloc[0] == "attacker@evil.example.com"
