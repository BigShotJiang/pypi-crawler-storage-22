"""Tests for sighting DataFrame."""

import pandas as pd
import pytest

from stix2tabular import stix_to_tables


def test_sightings_in_output(sighting_bundle):
    """Sighting objects go into tables['sightings']."""
    tables = stix_to_tables([sighting_bundle])
    assert "sightings" in tables
    assert isinstance(tables["sightings"], pd.DataFrame)


def test_sighting_of_ref_present(sighting_bundle):
    """sighting_of_ref column is present."""
    tables = stix_to_tables([sighting_bundle])
    sightings = tables["sightings"]
    assert "sighting_of_ref" in sightings.columns


def test_where_sighted_refs_is_list(sighting_bundle):
    """where_sighted_refs is a Python list in the cell."""
    tables = stix_to_tables([sighting_bundle])
    sightings = tables["sightings"]
    full = sightings[sightings["id"] == "sighting--full"].iloc[0]
    assert isinstance(full["where_sighted_refs"], list)
    assert full["where_sighted_refs"] == ["identity--org1"]


def test_observed_data_refs_is_list(sighting_bundle):
    """observed_data_refs is a Python list in the cell."""
    tables = stix_to_tables([sighting_bundle])
    sightings = tables["sightings"]
    full = sightings[sightings["id"] == "sighting--full"].iloc[0]
    assert isinstance(full["observed_data_refs"], list)
    assert full["observed_data_refs"] == ["observed-data--1"]


def test_temporal_fields_present(sighting_bundle):
    """first_seen, last_seen, count appear when present."""
    tables = stix_to_tables([sighting_bundle])
    sightings = tables["sightings"]
    full = sightings[sightings["id"] == "sighting--full"].iloc[0]
    assert full["first_seen"] == "2023-06-01T00:00:00.000Z"
    assert full["last_seen"] == "2023-06-15T00:00:00.000Z"
    assert full["count"] == 3


def test_full_sighting_all_refs(sighting_bundle):
    """Full sighting has all ref types present."""
    tables = stix_to_tables([sighting_bundle])
    sightings = tables["sightings"]
    full = sightings[sightings["id"] == "sighting--full"].iloc[0]
    assert full["sighting_of_ref"] == "indicator--sighted"
    assert isinstance(full["where_sighted_refs"], list)
    assert isinstance(full["observed_data_refs"], list)


def test_minimal_sighting_nan_refs(sighting_bundle):
    """Minimal sighting has NaN for optional ref columns."""
    tables = stix_to_tables([sighting_bundle])
    sightings = tables["sightings"]
    minimal = sightings[sightings["id"] == "sighting--minimal"].iloc[0]
    assert minimal["sighting_of_ref"] == "intrusion-set--sighted"
    # Optional fields should be NaN
    where = minimal.get("where_sighted_refs")
    assert pd.isna(where) or where is None
    obs = minimal.get("observed_data_refs")
    assert pd.isna(obs) or obs is None
