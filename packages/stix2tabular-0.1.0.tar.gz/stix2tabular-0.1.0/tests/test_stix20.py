"""Tests specific to STIX 2.0 bundles."""

import pandas as pd
import pytest

from stix2tabular import stix_to_tables


def test_stix20_loads(stix20_bundle):
    """STIX 2.0 bundle loads without error."""
    tables = stix_to_tables([stix20_bundle])
    assert isinstance(tables, dict)
    assert len(tables) > 0


def test_stix20_sdos_present(stix20_bundle):
    """STIX 2.0 SDOs are present in output."""
    tables = stix_to_tables([stix20_bundle])
    assert "threat-actor" in tables
    assert "malware" in tables
    assert tables["threat-actor"]["name"].iloc[0] == "Legacy Actor"


def test_stix20_relationship_present(stix20_bundle):
    """STIX 2.0 relationships are present."""
    tables = stix_to_tables([stix20_bundle])
    assert "relationships" in tables
    assert len(tables["relationships"]) == 1


def test_stix20_embedded_scos_extracted(stix20_bundle):
    """STIX 2.0 embedded SCOs are extracted into type DataFrames."""
    tables = stix_to_tables([stix20_bundle], include_scos=True)
    assert "ipv4-addr" in tables
    assert "domain-name" in tables
    assert tables["ipv4-addr"]["value"].iloc[0] == "203.0.113.50"
    assert tables["domain-name"]["value"].iloc[0] == "legacy.example.com"


def test_stix20_embedded_scos_have_synthetic_ids(stix20_bundle):
    """Synthetic IDs for extracted embedded SCOs are unique and prefixed."""
    tables = stix_to_tables([stix20_bundle], include_scos=True)
    ip_id = tables["ipv4-addr"]["id"].iloc[0]
    assert ip_id.startswith("observed-data--20--embedded-")
    domain_id = tables["domain-name"]["id"].iloc[0]
    assert domain_id.startswith("observed-data--20--embedded-")
    assert ip_id != domain_id


def test_stix20_embedded_scos_excluded_when_false(stix20_bundle):
    """Embedded SCOs are excluded when include_scos=False."""
    tables = stix_to_tables([stix20_bundle], include_scos=False)
    assert "ipv4-addr" not in tables
    assert "domain-name" not in tables
    # observed-data SDO should still be present
    assert "observed-data" in tables
