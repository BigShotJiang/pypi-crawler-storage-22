"""Tests specific to STIX 2.1 bundles."""

import pandas as pd
import pytest

from stix2tabular import stix_to_tables


def test_infrastructure_has_own_df(stix21_bundle):
    """Infrastructure type gets its own DataFrame."""
    tables = stix_to_tables([stix21_bundle])
    assert "infrastructure" in tables
    assert tables["infrastructure"]["name"].iloc[0] == "C2 Server"


def test_location_has_own_df(stix21_bundle):
    """Location type gets its own DataFrame."""
    tables = stix_to_tables([stix21_bundle])
    assert "location" in tables
    assert tables["location"]["name"].iloc[0] == "Eastern Europe"
    assert tables["location"]["region"].iloc[0] == "eastern-europe"


def test_malware_analysis_has_own_df(stix21_bundle):
    """Malware-analysis type gets its own DataFrame."""
    tables = stix_to_tables([stix21_bundle])
    assert "malware-analysis" in tables
    assert tables["malware-analysis"]["product"].iloc[0] == "CuckooSandbox"


def test_note_has_own_df(stix21_bundle):
    """Note type gets its own DataFrame."""
    tables = stix_to_tables([stix21_bundle])
    assert "note" in tables
    assert "content" in tables["note"].columns


def test_opinion_has_own_df(stix21_bundle):
    """Opinion type gets its own DataFrame."""
    tables = stix_to_tables([stix21_bundle])
    assert "opinion" in tables
    assert tables["opinion"]["opinion"].iloc[0] == "strongly-agree"


def test_grouping_has_own_df(stix21_bundle):
    """Grouping type gets its own DataFrame."""
    tables = stix_to_tables([stix21_bundle])
    assert "grouping" in tables
    assert tables["grouping"]["name"].iloc[0] == "Threat Cluster Alpha"
    assert tables["grouping"]["context"].iloc[0] == "suspicious-activity"


def test_object_refs_are_lists(stix21_bundle):
    """object_refs fields are Python lists."""
    tables = stix_to_tables([stix21_bundle])
    obj_refs = tables["grouping"]["object_refs"].iloc[0]
    assert isinstance(obj_refs, list)
    assert "infrastructure--1" in obj_refs


def test_stix21_relationship_present(stix21_bundle):
    """STIX 2.1 relationships are present."""
    tables = stix_to_tables([stix21_bundle])
    assert "relationships" in tables
    rel = tables["relationships"]
    assert rel["relationship_type"].iloc[0] == "located-at"


def test_standalone_scos():
    """Standalone SCOs in a STIX 2.1 bundle are handled correctly."""
    bundle = {
        "type": "bundle",
        "id": "bundle--standalone-sco",
        "objects": [
            {
                "type": "ipv4-addr",
                "id": "ipv4-addr--standalone",
                "spec_version": "2.1",
                "value": "192.168.1.1",
            },
            {
                "type": "domain-name",
                "id": "domain-name--standalone",
                "spec_version": "2.1",
                "value": "standalone.example.com",
            },
        ],
    }
    tables = stix_to_tables([bundle])
    assert "ipv4-addr" in tables
    assert "domain-name" in tables
    assert tables["ipv4-addr"]["value"].iloc[0] == "192.168.1.1"
