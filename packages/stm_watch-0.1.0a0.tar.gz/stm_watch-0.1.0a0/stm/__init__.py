"""File watching utility package."""

__version__ = "0.1.0"
