"""
Docstring for for the client CLI
This module provides a command-line interface for configuring file watchers,
handling user authentication, and submitting file modifications to a server.
It supports commands for configuring directories to watch, logging in and out, and starting the watcher to monitor file changes.
"""

from pathlib import Path
from typing import Optional, Tuple
import time
import sys
from datetime import datetime, timezone
import argparse
import requests
import uuid
from shared.schemas import EndSessionRequest, FileModification, AuthStatus, AuthStatusRequest, LoginRequest, LoginResponse
from stm import config
from stm.watcher import Watcher, WatchConfiguration, SOURCE_FILE_EXTENSIONS

def report_configured_watchers(
        watchers: list[WatchConfiguration],
        show_watched_files: bool = False,
        truncate: bool = True
    ) -> None:
    """Print configured watchers."""
    if not watchers:
        return

    print(f"Configured watchers ({len(watchers)}):")
    for watcher in watchers:
        patterns = ", ".join(watcher.watched_extensions) or "(none)"
        ignores = ", ".join(watcher.ignored_patterns) or "(none)"
        print(f"{watcher.directory}")
        print(f"Patterns: {patterns} | Ignore: {ignores}")
        if show_watched_files:
            files = watcher.collect_watched_files()
            for f in files[:(truncate and 10 or len(files))]:
                print(f"    - {f}")
            if len(files) > 10 and truncate:
                print(f"    - ... and {len(files) - 10} more files")
        print("")

def wait_for_auth(server_url, request_id, timeout=300) -> Tuple[str, str] | None:
    """Poll server for authenticated session token and username."""
    import time
    start = time.time()
    while time.time() - start < timeout:
        response = requests.get(
            f"{server_url}/api/auth/status",
            json=AuthStatusRequest(id=request_id).model_dump(),
            timeout=5
        )
        response.raise_for_status()
        data = response.json()
        if data.get("status") == AuthStatus.AUTHORIZED:
            return data["session_token"], data["username"]
        if data.get("status") == AuthStatus.UNAUTHORIZED:
            return None
        time.sleep(2)
    raise TimeoutError("Authentication timed out")

def browser_auth(server_url) -> Tuple[str, str]:
    """Open browser for user authentication and return session token and netid."""
    # initiate browser based login for user
    # The WebAuth endpoint has the user login then redirects to our server with a ticket
    request_id = str(uuid.uuid4())
    login_url = f"{server_url}/login?id={request_id}"
    print(f"Please sign in: {login_url}")

    # Wait for server side validation of login
    token_and_name = wait_for_auth(server_url, request_id)
    if not token_and_name:
        print("Authentication failed or was unauthorized.")
        sys.exit(1)
    print("✓ Authentication successful for user:", token_and_name[1])
    return token_and_name

def prompt_email() -> str:
    """Prompt user for email."""
    email = None
    while not email:
        email = input("Email: ").strip()
        if not email:
            print("Email cannot be empty.")
    return email

def prompt_password() -> str:
    """Prompt user for password."""
    import getpass
    return getpass.getpass("Password: ")

def login(server_url, in_browser=False, email=None, password=None) -> str:
    """Login to server and return session token.
    """
    try:
        if not in_browser:
            email = email or prompt_email()
            password = password or prompt_password()
            response = requests.post(
                f"{server_url}/login",
                json=LoginRequest(email=email, password=password).model_dump(),
                timeout=5
            )
            response.raise_for_status()
            # TODO use model_validate elsewhere in codebase for parsing responses, should be more robust than manually accessing json
            data = LoginResponse.model_validate(response.json())
            if data.verified and data.session_token:
                config.save_session(data.session_token, email, server_url)
                return data.session_token
            elif data.verified and not data.session_token:
                print("✗ Login failed: No session token received")
                sys.exit(1)
            else:
                print("✗ Login failed: Unauthorized")
                sys.exit(1)
        else:
            # TODO this should take the user to the login page of the website
            token, netid = browser_auth(server_url)
            # We don't know the username yet from browser_auth, server should return it
            # For now, save with a placeholder
            config.save_session(token, netid, server_url)
            return token
    except requests.exceptions.RequestException as e:
        print(f"✗ Login failed: {e}")
        sys.exit(1)

def end_session(server_url, session_token):
    """End session on server and clear cached session."""
    try:
        response = requests.post(
            f"{server_url}/api/sessions/end",
            json=EndSessionRequest(session_token=session_token).model_dump(),
            timeout=5
        )
        response.raise_for_status()
        print("✓ Session ended")
        return True
    except requests.exceptions.RequestException as e:
        print(f"✗ Failed to end session: {e}")
        return False

def submit(
    modification: FileModification,
    server_url: str,
) -> bool:
    """Submit file content to server."""
    
    try:
        response = requests.post(
            f"{server_url.rstrip('/')}/api/event",
            json=modification.model_dump(),
            timeout=5
        )
        response.raise_for_status()
        print(f"  ✓ Submitted: {modification.filename}")
        print(response.json())
        return True
    except requests.exceptions.RequestException as e:
        print(f"  ✗ Submission failed: {e}")
        return False

def on_change_callback(session_token: str = "", server_url: str = "", offline: bool = False):
    """Returns a callback function that can be passed to the Watcher to handle file changes.
    The callback will print the modified file and its contents, and if not in offline mode, submit the changes to the server."""
    def callback(filepath: Path, content: str, prev_content: Optional[str]):
        import difflib
        now = datetime.now(timezone.utc)
        print(f"\n[{now.strftime('%Y-%m-%d-%H:%M:%S.%f')}] [Modified] {filepath}")
        # If there is no previous content recorded, print snippet of current content
        if prev_content is None:
            print("--- File Contents ---")
            lines = content.splitlines(keepends=True)
            print("".join(lines[:15]), "\n..." if len(lines) > 15 else "")
        else:
            # If there is previous content, print a diff of the changes
            diff = difflib.unified_diff(
                prev_content.splitlines(keepends=True),
                content.splitlines(keepends=True),
                fromfile="previous",
                tofile="current",
            )
            print("".join(diff).rstrip("\n"))
        
        if not offline:
            if not session_token or not server_url:
                print("  ✗ No session token or server URL provided, cannot submit.")
                return
            modification = FileModification(
                filename=filepath.name,
                fullpath=str(filepath.resolve()),
                content=content,
                modified_at=now.timestamp(),
                session_token=session_token,
            )
            submit(modification, server_url)
    return callback

def main():
    session_data = config.load_session()
    server_url = "http://localhost:8000" if not session_data else session_data.server_url
    
    # Create parent parser with common arguments
    parent_parser = argparse.ArgumentParser(add_help=False)
    parent_parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    
    parser = argparse.ArgumentParser(description="Watch files for changes and submit modifications.", parents=[parent_parser])
    
    # Create subparsers for commands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Watch command
    watch_parser = subparsers.add_parser(
        "watch",
        parents=[parent_parser],
        help="Configure a directory to watch",
        usage="stm watch DIRECTORY PATTERN [PATTERN ...] [-i IGNORE [IGNORE ...]] [-v]",
        formatter_class=argparse.RawDescriptionHelpFormatter, # This is so the epilog displays correctly
        epilog="""
Examples:
  stm watch . .py                                   Watch all .py files in current directory tree
  stm watch . .py .java                             Watch .py and .java files
  stm watch /path/to/project .py -i "__*__.py"      Watch .py files, ignore __*__.py
  stm watch . .c .h -i "testspace/*"                Watch .c and .h files, ignore all files in testspace/ file tree
"""
    )
    watch_parser.add_argument("directory", help="Directory path to watch for changes")
    watch_parser.add_argument(
        "patterns",
        nargs="*",
        help="File extensions to watch (e.g., .py .txt). If not provided, defaults to common source code extensions."
    )
    watch_parser.add_argument(
        "-i", "--ignore",
        nargs="+",
        default=[],
        help="file patterns to ignore ( e.g., dir_to_ignore/* or test_*.py) NOTE: UNSTABLE, idk exactly what the semantics of these patterns ought to be yet"
        # TODO How should these ignore patterns work? I like being able to ignore entire directories with dir/*, but should I also support ignoring specific files with patterns like test_*.py?
        # What about ignoring specific files regardless of directory with patterns like __*__.py?
        # Right now the implementation is a bit inconsistent and hacky, need to clean it up and make the semantics clear
        # For now, I'm thinking the pattern will be matched against both the path relative to the watched directory and the filename,
        # and if either match, then it is ignored
        # should we use * to match anything besides a separator and ** to match anything including separators, like in .gitignore? That might be more intuitive
    )

    # Unwatch command
    unwatch_parser = subparsers.add_parser("unwatch", parents=[parent_parser], help="Remove a configured watcher")
    unwatch_parser.add_argument("directory", help="Directory path to stop watching")

    # Login command
    login_parser = subparsers.add_parser("login", parents=[parent_parser], help="Login and cache session")
    login_parser.add_argument("server_url", default=server_url, help=f"Server URL (default: {server_url})")
    login_parser.add_argument("-u", "--user", help="Email for login (give browser link to login if not provided)")

    # Logout command
    logout_parser = subparsers.add_parser("logout", parents=[parent_parser], help="Logout and clear cached session")
    # logout_parser.add_argument("server_url", nargs="?", default=server_url, help=f"Server URL (default: {server_url})")
    
    # Whoami command
    whoami_parser = subparsers.add_parser("whoami", parents=[parent_parser], help="Show current cached session info")
    
    # Start command
    start_parser = subparsers.add_parser("start", parents=[parent_parser], help="Start watching files")
    start_parser.add_argument("--offline", action="store_true", help="Run watcher in offline mode (no submissions)")

    # Parse args, but allow no command (defaults to files with positional args)
    args = parser.parse_args()
    
    # Handle commands
    if args.command == "login":
        server_url = args.server_url.rstrip('/')
        session_token = login(server_url, in_browser=not args.user, email=args.user)
        print("✓ Logged in successfully")
    
    elif args.command == "logout":
        if not session_data:
            print("No active session found")
        else:
            # TODO make request to end session on server
            config.clear_session()
            print("✓ Logged out and cleared cached session")
    
    elif args.command == "whoami":
        if not session_data:
            print("No active session")
            return
        print("You are", session_data.username)
        print("You like stopping the madness by sending file changes to", session_data.server_url)
    
    elif args.command == "watch":
        directory = Path(args.directory).resolve()
        if not directory.exists():
            print(f"✗ Directory does not exist: {directory}")
            sys.exit(1)
        if not directory.is_dir():
            print(f"✗ Path is not a directory: {directory}")
            sys.exit(1)

        print(f"Configuring watcher for {directory}...")
        watch_config = WatchConfiguration(
            directory=directory,
            watched_extensions=args.patterns if args.patterns else SOURCE_FILE_EXTENSIONS,
            ignored_patterns=args.ignore,
        )
        config.add_configuration(watch_config)
        report_configured_watchers([watch_config], show_watched_files=True, truncate=not args.verbose)
    
    # Remove the watch configuration specified by the user, matching by directory path given
    elif args.command == "unwatch":
        directory = Path(args.directory).resolve()
        if not directory.exists():
            print("That directory does not exist")
            sys.exit(1)
        if not directory.is_dir():
            print("That path is not a directory")
            sys.exit(1)

        watched_dirs = [c.directory for c in config.load_watch_configurations()]
        watched_ancestors = [a for a in watched_dirs if directory.is_relative_to(a) and a != directory]
        dir_has_configuration = directory in watched_dirs
        dir_is_watched_thru_ancestor = bool(watched_ancestors)

        if not dir_has_configuration:
            print(f"A watch configuration is not rooted at {directory}")
            if dir_is_watched_thru_ancestor:
                print("However, that directory is a descendant of the following watched directories:")
                for ancestor in watched_ancestors:
                    print(f"  - {ancestor}")
            sys.exit(1)

        config.delete_configuration(directory)
        print(f"Removed watcher configuration for {directory}")
        if dir_is_watched_thru_ancestor:
            print("Note: That directory might still be watched as a descendant of the following watched directories:")
            for ancestor in watched_ancestors:
                print(f"  - {ancestor}")

    elif args.command == "start":
        if session_data is None and not args.offline:
            print("✗ Please login first using 'stm login' command.")
            sys.exit(1)
        
        session_token = "" if session_data is None else session_data.session_token
        server_url = "" if session_data is None else session_data.server_url

        configurations = config.load_watch_configurations()
        if not configurations:
            print("No configured watchers. Run 'stm watch' to configure one.")
            sys.exit(1)
        
        print("Starting watcher...")
        watcher = Watcher(
            configurations=configurations,
            on_change=on_change_callback(
                session_token=session_token,
                server_url=server_url,
                offline=args.offline)
        )
        print("On startup, there are {} files being watched.".format(len(watcher.collect_watched_files())))
        watcher.start()
        print("Watcher started. Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Stopping watcher...")
            watcher.stop()
            watcher.join()
            print("Watcher stopped.")
    else:
        # default behavior if no command is given, just report configured watchers
        configurations = config.load_watch_configurations()
        if not configurations:
            print("No configured watchers. Run 'stm watch' to configure one.")
        else:
            report_configured_watchers(configurations, show_watched_files=True, truncate=not args.verbose)
        print("Use 'stm -h' for help on commands.")



if __name__ == "__main__":
    main()
