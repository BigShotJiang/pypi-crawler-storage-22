"""Configuration and token caching for the watch CLI."""
from pathlib import Path
import json
from typing import Optional
from datetime import datetime, timezone
import requests
import platformdirs
from pydantic import BaseModel
from stm.watcher import WatchConfiguration

class SessionData(BaseModel):
    session_token: str
    username: str
    server_url: str
    created_at: datetime

def get_config_dir() -> Path:
    """Get the user's config directory for storing session tokens."""
    config_home = Path(platformdirs.user_config_dir("watch", appauthor="stop the madness"))
    config_home.mkdir(parents=True, exist_ok=True)
    return config_home

def get_session_file() -> Path:
    """Get the path to the session file."""
    return get_config_dir() / "session.json"

def get_watchers_file() -> Path:
    """Get the path to the watchers file."""
    return get_config_dir() / "watchers.json"

def load_watch_configurations() -> list[WatchConfiguration]:
    """Load the projects configuration from file."""
    watchers_file = get_watchers_file()

    if not watchers_file.exists():
        return []

    try:
        raw_data = json.loads(watchers_file.read_text())
        if not isinstance(raw_data, list):
            raise ValueError("Watchers file must contain a list")
        return [WatchConfiguration(**watcher_settings) for watcher_settings in raw_data]
    except (ValueError, TypeError) as e:
        print(f"⚠ Corrupted watchers file, removing: {e}")
        watchers_file.unlink(missing_ok=True)
        return []

def save_watch_configurations(watchers: list[WatchConfiguration]) -> None:
    """Save the list of watchers to the watchers file."""
    watchers_file = get_watchers_file()
    watchers_file.write_text(json.dumps([w.model_dump(mode='json') for w in watchers], indent=2))

def add_configuration(settings: WatchConfiguration) -> None:
    """Add a new watcher to the watchers file."""
    watchers = load_watch_configurations()
    settings.directory = settings.directory.resolve()

    updated_configurations: list[WatchConfiguration] = []
    replaced = False
    for watcher in watchers:
        # if the directory is already being watched, replace its settings
        if watcher.directory == settings.directory:
            updated_configurations.append(settings)
            replaced = True
        else:
            updated_configurations.append(watcher)

    if not replaced:
        updated_configurations.append(settings)

    save_watch_configurations(updated_configurations)

def delete_configuration(directory: Path) -> None:
    """Delete a watcher configuration from the watchers file."""
    configurations = load_watch_configurations()
    target_dir = directory.resolve()
    remaining = [w for w in configurations if w.directory.resolve() != target_dir]

    watchers_file = get_watchers_file()
    if not remaining:
        watchers_file.unlink(missing_ok=True)
        return

    save_watch_configurations(remaining)

def save_session(session_token: str, username: str, server_url: str) -> None:
    """Save session token to local config file."""
    session_file = get_session_file()
    session_data = {
        "session_token": session_token,
        "username": username,
        "server_url": server_url,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    
    # Set restrictive permissions (user read/write only)
    session_file.touch(mode=0o600, exist_ok=True)
    session_file.write_text(json.dumps(session_data, indent=2))

def load_session() -> Optional[SessionData]:
    """Load cached session from local config file."""
    session_file = get_session_file()
    
    if not session_file.exists():
        return None
    
    try:
        session_data = SessionData.model_validate_json(session_file.read_text())
        return session_data
    except (json.JSONDecodeError, KeyError) as e:
        # Corrupted session file, remove it
        print(f"⚠ Corrupted session file, removing: {e}")
        session_file.unlink(missing_ok=True)
        return None

def clear_session() -> None:
    """Remove cached session from local config file."""
    session_file = get_session_file()
    session_file.unlink(missing_ok=True)

def clear_watchers() -> None:
    """Remove all watchers from local config file."""
    watchers_file = get_watchers_file()
    watchers_file.unlink(missing_ok=True)

def validate_session(server_url: str, session_token: str) -> bool:
    """Validate session token with server."""
    try:
        response = requests.post(
            f"{server_url}/api/auth/validate",
            json={"session_token": session_token},
            timeout=5
        )
        if response.status_code == 200 and response.json().get("valid", False):
            new_token = response.json().get("refreshed_token")
            data = load_session()
            if data:
                data.session_token = new_token
                save_session(data.session_token, data.username, data.server_url)
                return True
        return False
    except requests.exceptions.RequestException:
        return False
    except (json.JSONDecodeError, KeyError) as e:
        # Corrupted session file, remove it
        print(f"⚠ Something went wrong validating session: {e}")
        session_file = get_session_file()
        session_file.unlink(missing_ok=True)
        return False
