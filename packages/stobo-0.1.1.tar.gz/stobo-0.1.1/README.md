# Stobo CLI

AI-powered SEO/AEO audit tool for the terminal.

## Install

```bash
pip install stobo
```

## Quick Start

```bash
# Authenticate
stobo auth login sk_your_api_key

# Run a full audit
stobo audit run https://example.com

# SEO only
stobo audit run https://example.com --seo-only

# JSON output
stobo audit run https://example.com --json

# Extract brand voice
stobo tone extract https://blog.example.com

# Full optimization pipeline
stobo optimize run https://example.com
```

## Commands

| Command | Description |
|---------|-------------|
| `stobo auth login <key>` | Save and validate API key |
| `stobo auth status` | Show current auth status |
| `stobo audit run <url>` | Run SEO+AEO audit |
| `stobo audit list` | List recent audits |
| `stobo tone extract <blog>` | Extract brand voice |
| `stobo tone list` | List profiles |
| `stobo optimize run <url>` | Full audit+tone+rewrite |
| `stobo freshness run <sitemap>` | Sitemap schema audit |
| `stobo export run <cid> <type>` | Generate markdown report |

## Global Options

- `--api-key` — Override stored API key
- `--base-url` — Override API base URL
- `--json` — Raw JSON output
- `--version` — Show version
