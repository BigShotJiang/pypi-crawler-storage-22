"""Sample response data for CLI tests."""

SAMPLE_AUDIT = {
    "id": "aaaa-bbbb-cccc",
    "url": "https://example.com/blog/test",
    "domain": "example.com",
    "article_title": "Test Article",
    "status": "completed",
    "overall_score": 240,
    "max_points": 335,
    "percentage": 71.6,
    "grade": "C",
    "seo_audit": {"category_scores": {"content": 80, "links": 60, "technical": 55}},
    "aeo_audit": {},
    "recommendations": ["Add meta description", "Improve heading hierarchy"],
    "created_at": "2026-02-08T12:00:00Z",
    "completed_at": "2026-02-08T12:00:30Z",
}

SAMPLE_TONE = {
    "customer_id": "example-com",
    "profile": {
        "brand_personality": {"archetype": "The Sage", "voice_summary": "Professional yet approachable"},
        "writing_style": {"formality": "semi-formal", "sentence_length": "medium"},
        "tone_descriptors": ["professional", "conversational", "data-driven"],
    },
    "articles_analyzed": 8,
    "message": "Brand voice extracted.",
}

SAMPLE_JOB = {
    "job_id": "dddd-eeee-ffff",
    "url": "https://example.com/blog/test",
    "status": "completed",
    "rewrite_result": {
        "tone_alignment_score": 0.92,
        "issues_addressed": ["meta_description", "h1"],
        "issues_skipped": [],
    },
    "started_at": "2026-02-08T12:00:00Z",
    "completed_at": "2026-02-08T12:02:00Z",
}

SAMPLE_VALIDATE_KEY = {"valid": True, "key_name": "CLI Key", "user_id": 1}

SAMPLE_ME = {"email": "user@example.com", "full_name": "Test User"}
