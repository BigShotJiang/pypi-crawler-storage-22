# AKShare MCP Server

An MCP stdio server for A-share market technical analysis powered by AkShare.

## Features

- Real-time A-share quotes with multi-source fallback and in-memory cache.
- A-share historical K-line data (daily/weekly/monthly) with local cache.
- A-share intraday minute K-line data (1/5/15/30/60).
- Technical indicators (Bollinger, RSI, MACD, KDJ, ADX, EMA).
- Index analysis, index/ETF spot, sector fund flow, northbound fund flow.
- Market calendar and market status.
- Export to CSV/Parquet in any user-specified directory.

## Install

```bash
pip install stock-trading-mcp
```

## Run

```bash
stock-trading-mcp
```

## Cache directory

Historical K-line data is cached to a local directory. By default the cache is
created under the current working directory as `.akshare_cache`. You can
override this by setting `AKSHARE_MCP_CACHE_DIR` to any path you want.

## Example tool calls

### Intraday minutes (with export)

```json
{
  "tool": "stock_intraday",
  "arguments": {
    "symbol": "601138",
    "period": "15",
    "raw_only": true,
    "save_dir": "./data",
    "save_format": "csv"
  }
}
```

### Market calendar / market status

```json
{
  "tool": "market_calendar",
  "arguments": {
    "start_date": "20260202",
    "end_date": "20260209"
  }
}
```

```json
{
  "tool": "market_status",
  "arguments": {}
}
```

Note: `market_calendar`/`market_status` use Sina calendar by default and fall back
to a cached calendar. If both are unavailable, a weekday-based heuristic is
used and responses include `"approximate": true`.

### ETF list / ETF spot

```json
{
  "tool": "etf_list",
  "arguments": {
    "category": "ETF基金",
    "keyword": "软件",
    "limit": 20
  }
}
```

```json
{
  "tool": "etf_spot",
  "arguments": {
    "keyword": "软件",
    "limit": 20
  }
}
```

Note: `etf_spot` uses Eastmoney by default and falls back to Sina ETF list data
if Eastmoney is unavailable (e.g., proxy/network issues).

### ETF intraday (15-minute) with export

```json
{
  "tool": "etf_intraday",
  "arguments": {
    "symbol": "159707",
    "period": "15",
    "start_date": "20260209",
    "end_date": "20260209",
    "save_dir": "./data",
    "save_format": "csv",
    "raw_only": true
  }
}
```

### ETF history

```json
{
  "tool": "etf_history",
  "arguments": {
    "symbol": "159xxx",
    "period": "daily",
    "start_date": "20260202",
    "end_date": "20260209"
  }
}
```

### Index spot

```json
{
  "tool": "index_spot",
  "arguments": {
    "category": "沪深重要指数",
    "limit": 20
  }
}
```

### Stock analysis (with export)

```json
{
  "tool": "stock_analysis",
  "arguments": {
    "symbol": "601138",
    "period": "daily",
    "days": 365,
    "raw_only": false,
    "save_dir": "./data",
    "save_format": "parquet"
  }
}
```

### Index analysis (raw only, with export)

```json
{
  "tool": "index_analysis",
  "arguments": {
    "symbol": "000001",
    "period": "daily",
    "raw_only": true,
    "save_dir": "./data",
    "save_format": "csv"
  }
}
```
