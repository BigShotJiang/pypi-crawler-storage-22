# StockAPIs

Python SDK for StockAPIs - access cryptocurrency historical data (trades, klines) from Binance, Bybit, and OKX.

## Installation

```bash
pip install stockapis
```

## Quick Start

### Async (recommended for high performance)

```python
from stockapis import StockAPIs, Exchange, DataType

async with StockAPIs(api_key="your-api-key") as api:
    df = await api.exports.export_to_dataframe(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.KLINES,
        from_date="2025-01-01",
        to_date="2025-01-07",
        interval="1m",
    )
    print(f"Loaded {len(df)} rows")
```

### Sync (simpler usage)

```python
from stockapis import StockAPIsSync, Exchange, DataType

with StockAPIsSync(api_key="your-api-key") as api:
    df = api.exports.export_to_dataframe(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.KLINES,
        from_date="2025-01-01",
        to_date="2025-01-07",
        interval="1m",
    )
    print(f"Loaded {len(df)} rows")
```

### CLI

```bash
# Set API key
export STOCKAPIS_API_KEY=your-api-key

# Export to file
stockapis export BTCUSDT -e binance --from 2025-01-01 --to 2025-01-07 -i 1m -o data.csv

# Download to QuestDB
stockapis download BTCUSDT -e binance --from 2025-01-01 --to 2025-01-31 --type trades

# List recent jobs
stockapis list downloads

# Check status
stockapis status 123
```

## API Keys

Two types of API keys are supported:

| Type | Prefix | Usage |
|------|--------|-------|
| Demo | `demo_` | Testing and development |
| Production | `sk_` | Production usage (hashed) |

```python
api = StockAPIs(api_key="sk_live_your_key_here")
```

## Configuration

```python
from stockapis import StockAPIs

# Production (default)
api = StockAPIs(api_key="your-api-key")

# Development (localhost:8000)
api = StockAPIs(api_key="your-api-key", mode="dev")

# Custom URL
api = StockAPIs(api_key="your-api-key", base_url="http://custom:9000")
```

## CLI Reference

```bash
# Download data to QuestDB
stockapis download BTCUSDT -e binance --from 2025-01-01 --to 2025-01-31
stockapis download BTCUSDT -e binance --from 2025-01-01 --to 2025-01-31 --type klines -i 1m
stockapis download BTCUSDT -e binance --from 2025-01-01 --to 2025-01-31 --no-wait

# Export to file
stockapis export BTCUSDT -e binance --from 2025-01-01 --to 2025-01-07 -i 1m -o btcusdt.csv
stockapis export BTCUSDT -e binance --from 2025-01-01 --to 2025-01-07 -i 1h -o data.parquet --format parquet
stockapis export BTCUSDT -e binance --from 2025-01-01 --to 2025-01-07 --type trades -o trades.csv

# Check job status
stockapis status 123
stockapis status 456 --type export

# List recent jobs
stockapis list downloads
stockapis list exports -n 20

# Check data availability
stockapis availability BTCUSDT -e binance --from 2024-01-01 --to 2024-12-31

# Cancel job
stockapis cancel 123
stockapis cancel 456 --type export
```

Options:
- `--api-key, -k` - API key (or set `STOCKAPIS_API_KEY`)
- `--base-url, -u` - Custom API URL
- `--exchange, -e` - Exchange: `binance`, `bybit`, `okx`
- `--market` - Market type: `spot`, `linear`, `inverse`
- `--type` - Data type: `trades`, `klines`
- `--interval, -i` - Kline interval: `1m`, `5m`, `1h`, `1d`, etc.
- `--format` - File format: `csv`, `parquet`, `json`

## High-Level API (Recommended)

### Export to DataFrame

```python
from stockapis import StockAPIs, Exchange, DataType, MarketType

async with StockAPIs(api_key="your-key") as api:
    # Klines data
    df = await api.exports.export_to_dataframe(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.KLINES,
        from_date="2025-01-01",
        to_date="2025-01-07",
        interval="1m",
        on_progress=lambda p: print(f"Progress: {p}%"),
    )

    # Trades data
    df = await api.exports.export_to_dataframe(
        symbol="ETHUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.TRADES,
        from_date="2025-01-01",
        to_date="2025-01-02",
    )

    # Futures/Perpetuals
    df = await api.exports.export_to_dataframe(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        market_type=MarketType.LINEAR,
        data_type=DataType.KLINES,
        from_date="2025-01-01",
        to_date="2025-01-07",
        interval="1h",
    )
```

### Export to File

```python
path = await api.exports.export_to_file(
    symbol="BTCUSDT",
    exchange=Exchange.BINANCE,
    data_type=DataType.KLINES,
    from_date="2025-01-01",
    to_date="2025-01-07",
    interval="1m",
    output_path="btcusdt_klines.csv",
    on_progress=lambda p: print(f"Progress: {p}%"),
)
print(f"Saved to {path}")
```

### Download and Wait (for QuestDB ingestion)

```python
# Download data to QuestDB in one call
request = await api.downloads.download_and_wait(
    symbol="BTCUSDT",
    exchange=Exchange.BINANCE,
    data_type=DataType.KLINES,
    from_date="2025-01-01",
    to_date="2025-01-31",
    interval="1m",
    on_progress=lambda p: print(f"Progress: {p}%"),
)
print(f"Downloaded: {request.status}")

# Get summary dict
result = await api.downloads.download_to_questdb(
    symbol="ETHUSDT",
    exchange=Exchange.BINANCE,
    data_type=DataType.TRADES,
    from_date="2025-01-01",
    to_date="2025-01-02",
)
print(f"Records: {result['total_records']}, Days: {result['total_days']}")
```

## Sync API

All async methods are available in sync version via `StockAPIsSync`:

```python
from stockapis import StockAPIsSync, Exchange, DataType

with StockAPIsSync(api_key="your-key") as api:
    # Export to DataFrame
    df = api.exports.export_to_dataframe(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.KLINES,
        from_date="2025-01-01",
        to_date="2025-01-07",
        interval="1m",
    )

    # Export to file
    path = api.exports.export_to_file(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.KLINES,
        from_date="2025-01-01",
        to_date="2025-01-07",
        interval="1m",
        output_path="data.csv",
    )

    # Download to QuestDB
    result = api.downloads.download_to_questdb(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.TRADES,
        from_date="2025-01-01",
        to_date="2025-01-02",
    )

    # Check availability
    avail = api.downloads.check_availability(
        symbol="BTCUSDT",
        exchange=Exchange.BINANCE,
        data_type=DataType.KLINES,
        from_date="2024-01-01",
        to_date="2024-12-31",
    )
    print(f"Coverage: {avail.coverage_percent}%")

    # List downloads
    result = api.downloads.list(page_size=10)
    for req in result.results:
        print(f"{req.id}: {req.status}")
```

## Low-Level API

### Downloads Service

```python
from stockapis import Exchange, MarketType, DataType, Granularity

# Create download request
request = await api.downloads.create(
    symbol="BTCUSDT",
    exchange=Exchange.BINANCE,
    market_type=MarketType.SPOT,
    data_type=DataType.TRADES,
    from_date="2024-01-01",
    to_date="2024-01-31",
    granularity=Granularity.DAILY,
)

# Wait for completion
request = await api.downloads.wait_for_completion(
    request.id,
    poll_interval=5.0,
    timeout=3600,
)

# Poll with progress updates
async for req in api.downloads.poll_progress(request.id):
    print(f"Progress: {req.progress_percent}%")
```

### Exports Service

```python
from stockapis import FileFormat, Compression

# Create export job
job = await api.exports.create(
    symbol="BTCUSDT",
    exchange=Exchange.BINANCE,
    data_type=DataType.KLINES,
    from_date="2024-01-01",
    to_date="2024-01-31",
    interval="1h",
    file_format=FileFormat.PARQUET,
    compression=Compression.GZIP,
)

# Wait and download
job = await api.exports.wait_for_completion(job.id)
path = await api.exports.download_file(job.id, "data.parquet")

# Or download as DataFrame
df = await api.exports.download_to_dataframe(job.id)
```

### Auto-Download Missing Data

```python
# Automatically downloads missing data before exporting
job = await api.exports.create_with_download(
    symbol="BTCUSDT",
    exchange=Exchange.BINANCE,
    data_type=DataType.KLINES,
    from_date="2024-01-01",
    to_date="2024-01-31",
    interval="1h",
)
# Job status will be WAITING_FOR_DATA if downloads were triggered
```

### Check Data Availability

```python
# Check coverage
availability = await api.downloads.check_availability(
    symbol="BTCUSDT",
    exchange=Exchange.BINANCE,
    data_type=DataType.KLINES,
    from_date="2024-01-01",
    to_date="2024-12-31",
)
print(f"Coverage: {availability.coverage_percent}%")

# Get monthly availability grid
grid = await api.downloads.get_availability_grid(
    symbol="BTCUSDT",
    exchange=Exchange.BINANCE,
    data_type=DataType.KLINES,
    interval="1h",
    year=2024,
)
for month in grid.months:
    print(f"{month.month}/{month.year}: {month.status}")

# Get symbols with data
response = await api.downloads.get_symbols_with_data(
    exchange=Exchange.BINANCE,
    data_type=DataType.KLINES,
)
for symbol in response.symbols:
    print(f"{symbol.symbol}: {symbol.klines_days} days")
```

### Control Operations

```python
# Cancel
await api.downloads.cancel(request_id)
await api.exports.cancel(job_id)

# Retry failed segments
await api.downloads.retry_failed(request_id)
```

## Type Reference

### Enums

```python
from stockapis import (
    Exchange,           # BINANCE, BYBIT, OKX
    MarketType,         # SPOT, LINEAR, INVERSE
    DataType,           # KLINES, TRADES
    Granularity,        # DAILY, MONTHLY
    DownloadStatus,     # PENDING, PROCESSING, COMPLETED, FAILED, SKIPPED, CANCELLED
    ExportJobStatus,    # WAITING_FOR_DATA, PENDING, PROCESSING, COMPLETED, FAILED, EXPIRED, CANCELLED
    AvailabilityStatus, # COMPLETE, PARTIAL, EMPTY, IN_PROGRESS
    FileFormat,         # CSV, PARQUET, JSON
    Compression,        # NONE, GZIP, ZIP
)

# Kline intervals
KlineInterval = "1m" | "3m" | "5m" | "15m" | "30m" | "1h" | "2h" | "4h" | "6h" | "8h" | "12h" | "1d" | "3d" | "1w" | "1M"
```

### Terminal Status Sets

```python
from stockapis import TERMINAL_DOWNLOAD_STATUSES, TERMINAL_EXPORT_STATUSES

# Check if job is done
if DownloadStatus(request.status) in TERMINAL_DOWNLOAD_STATUSES:
    print("Download finished")

if ExportJobStatus(job.status) in TERMINAL_EXPORT_STATUSES:
    print("Export finished")
```

### Response Models

```python
from stockapis import (
    # Downloads
    DownloadRequest,
    DownloadSegment,
    DataAvailabilityResponse,
    AvailabilityGridResponse,
    AvailabilityHeatmapResponse,
    SymbolsWithDataResponse,
    PaginatedDownloadRequestList,
    # Exports
    ExportJob,
    PaginatedExportJobList,
)
```

## Error Handling

```python
import httpx

try:
    df = await api.exports.export_to_dataframe(...)
except httpx.HTTPStatusError as e:
    print(f"API error {e.response.status_code}: {e.response.json()}")
except ValueError as e:
    print(f"Validation error: {e}")
except TimeoutError as e:
    print(f"Timeout: {e}")
except ImportError as e:
    print(f"Missing dependency: {e}")  # polars not installed
```

## License

MIT
