# StockSDK Examples

Interactive Jupyter notebooks demonstrating StockSDK usage.

## Notebooks

| Notebook | Description |
|----------|-------------|
| [01_quickstart.ipynb](01_quickstart.ipynb) | Getting started with downloads |
| [02_data_availability.ipynb](02_data_availability.ipynb) | Checking data availability |
| [03_exports.ipynb](03_exports.ipynb) | Exporting data to files |

## Setup

1. Install dependencies:
```bash
pip install stockapis jupyter polars
```

2. Start Jupyter:
```bash
cd examples
jupyter notebook
```

3. Configure your token in each notebook:
```python
TOKEN = "your-jwt-token-here"
api = CryptoDataAPI(token=TOKEN, mode="dev")
```

## Topics Covered

### 01_quickstart.ipynb
- Setting up the SDK client
- Creating download requests (trades, klines)
- Checking download status
- Viewing segments
- Waiting for completion
- Monthly granularity

### 02_data_availability.ipynb
- Checking data availability before downloading
- Viewing availability grids (monthly)
- Full availability heatmaps
- Finding symbols with data
- Smart download decisions

### 03_exports.ipynb
- Creating exports (CSV, Parquet, JSON)
- Compression options
- Waiting for export completion
- Downloading files
- Loading as DataFrame
- Auto-download with exports
- Listing exports

## Development Mode

For local development, use `mode="dev"`:
```python
api = CryptoDataAPI(token=TOKEN, mode="dev")  # localhost:8000
```

For production:
```python
api = CryptoDataAPI(token=TOKEN, mode="prod")  # api.stockapis.com
```
