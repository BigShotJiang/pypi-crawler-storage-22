"""
StockSDK - Python SDK for StockAPIS.

Provides access to cryptocurrency historical data (trades, klines)
from Binance and Bybit.

Quick Start:
    from stockapis import StockAPIs, Exchange, DataType

    async with StockAPIs(api_key="demo_stockapis_2024") as api:
        # === EASIEST: One-liner to get data ===
        df = await api.exports.export_to_dataframe(
            symbol="BTCUSDT",
            exchange=Exchange.BINANCE,
            data_type=DataType.KLINES,
            from_date="2025-01-01",
            to_date="2025-01-07",
            interval="1m",
        )
        print(f"Loaded {len(df)} rows")

        # Or save to file
        path = await api.exports.export_to_file(
            symbol="BTCUSDT",
            exchange=Exchange.BINANCE,
            data_type=DataType.KLINES,
            from_date="2025-01-01",
            to_date="2025-01-07",
            interval="1m",
            output_path="btcusdt.csv",
        )

    # === DOWNLOADS (for data ingestion) ===
    async with StockAPIs(api_key="demo_stockapis_2024") as api:
        request = await api.downloads.create(
            symbol="BTCUSDT",
            exchange=Exchange.BINANCE,
            data_type=DataType.TRADES,
            from_date="2024-01-01",
            to_date="2024-01-31",
        )
        request = await api.downloads.wait_for_completion(request.id)

    # === LOW-LEVEL EXPORTS (for more control) ===
    async with StockAPIs(api_key="demo_stockapis_2024") as api:
        job = await api.exports.create(
            symbol="BTCUSDT",
            exchange=Exchange.BINANCE,
            data_type=DataType.KLINES,
            from_date="2025-01-01",
            to_date="2025-01-07",
            interval="1m",
        )
        job = await api.exports.wait_for_completion(job.id)
        df = await api.exports.download_to_dataframe(job.id)
"""

from stockapis._api import (
    # Constants
    TERMINAL_DOWNLOAD_STATUSES,
    TERMINAL_EXPORT_STATUSES,
    AsyncStockAPIs,
    AvailabilityGridResponse,
    AvailabilityHeatmapResponse,
    AvailabilityStatus,
    Compression,
    DataAvailabilityResponse,
    DataType,
    # Download models
    DownloadRequest,
    DownloadSegment,
    # Services
    DownloadsService,
    # Status enums
    DownloadStatus,
    # Type aliases
    Exchange,
    # Export models
    ExportJob,
    ExportJobStatus,
    ExportsService,
    FileFormat,
    Granularity,
    KlineInterval,
    MarketType,
    PaginatedDownloadRequestList,
    PaginatedExportJobList,
    # Main client
    StockAPIs,
    StockAPIsSync,
    SymbolStatus,
    SymbolsWithDataResponse,
)

__version__ = "0.1.5"

__all__ = [
    # Main client
    "StockAPIs",
    "StockAPIsSync",
    "AsyncStockAPIs",
    # Services
    "DownloadsService",
    "ExportsService",
    # Type aliases
    "Exchange",
    "MarketType",
    "DataType",
    "Granularity",
    "KlineInterval",
    "FileFormat",
    "Compression",
    # Status enums
    "DownloadStatus",
    "ExportJobStatus",
    "AvailabilityStatus",
    "SymbolStatus",
    # Constants
    "TERMINAL_DOWNLOAD_STATUSES",
    "TERMINAL_EXPORT_STATUSES",
    # Download models
    "DownloadRequest",
    "DownloadSegment",
    "DataAvailabilityResponse",
    "AvailabilityGridResponse",
    "AvailabilityHeatmapResponse",
    "SymbolsWithDataResponse",
    "PaginatedDownloadRequestList",
    # Export models
    "ExportJob",
    "PaginatedExportJobList",
    # Version
    "__version__",
]
