"""
High-level CryptoData API client.

Provides a unified interface for cryptocurrency data operations:
- Downloads: Request historical data downloads from exchanges
- Exports: Export downloaded data to files (CSV, Parquet, JSON)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import httpx

from .config import get_base_url
from .generated.cryptodb_driver import API
from .services.downloads import DownloadsService
from .services.exports import ExportsService

if TYPE_CHECKING:
    pass

# Default HTTP timeout (30s to match Traefik proxy defaults)
DEFAULT_TIMEOUT = httpx.Timeout(30.0)


class StockAPIs:
    """
    High-level API client for CryptoDB data.

    Provides access to:
    - `downloads`: Service for managing data downloads
    - `exports`: Service for exporting data to files

    Usage:
        # Using API key (recommended)
        async with StockAPIs(api_key="demo_stockapis_2024") as api:
            # Create download request
            request = await api.downloads.create(
                symbol="BTCUSDT",
                exchange="binance",
                market_type="spot",
                data_type="trades",
                from_date="2024-01-01",
                to_date="2024-01-31",
            )

            # Wait for completion
            request = await api.downloads.wait_for_completion(request.id)

            # Check data availability
            availability = await api.downloads.check_availability(
                symbol="BTCUSDT",
                exchange="binance",
                data_type="klines",
                from_date="2024-01-01",
                to_date="2024-12-31",
            )

            # Create export
            job = await api.exports.create(
                symbol="BTCUSDT",
                exchange="binance",
                data_type="trades",
                from_date="2024-01-01",
                to_date="2024-01-31",
                file_format="parquet",
            )

            # Wait and download
            job = await api.exports.wait_for_completion(job.id)
            df = await api.exports.download_to_dataframe(job.id)
    """

    def __init__(
        self,
        token: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        mode: Literal["dev", "prod"] | None = None,
    ):
        """
        Initialize CryptoData API client.

        Args:
            token: JWT authentication token (deprecated, use api_key)
            api_key: API key for authentication (e.g., "demo_stockapis_2024" or "sk_xxx")
            base_url: API base URL. If not provided, uses mode to determine URL.
            mode: "dev" for localhost:8000, "prod" for api.stockapis.com

        Examples:
            # Using API key (recommended)
            api = StockAPIs(api_key="demo_stockapis_2024")

            # Using JWT token
            api = StockAPIs(token="eyJ...")

            # Legacy: token parameter also accepts API keys
            api = StockAPIs(token="demo_stockapis_2024")
        """
        # Support both token and api_key parameters
        self._token = api_key or token
        if not self._token:
            raise ValueError("Either 'api_key' or 'token' must be provided")
        self._base_url = base_url or get_base_url(mode)
        self._api: API | None = None
        self._downloads: DownloadsService | None = None
        self._exports: ExportsService | None = None

    def _get_api(self) -> API:
        """Get or create the underlying API client."""
        if self._api is None:
            self._api = API(self._base_url, timeout=DEFAULT_TIMEOUT)
            self._api.set_token(self._token)
        return self._api

    @property
    def downloads(self) -> DownloadsService:
        """
        Access downloads service.

        Provides methods for:
        - Creating download requests
        - Checking download status
        - Waiting for completion
        - Checking data availability
        - Getting availability grids/heatmaps
        - Listing symbols with data
        """
        if self._downloads is None:
            self._downloads = DownloadsService(self._get_api())
        return self._downloads

    @property
    def exports(self) -> ExportsService:
        """
        Access exports service.

        Provides methods for:
        - Creating export jobs
        - Checking export status
        - Waiting for completion
        - Downloading exported files
        - Loading exports as DataFrames
        """
        if self._exports is None:
            self._exports = ExportsService(self._get_api())
        return self._exports

    @property
    def token(self) -> str | None:
        """Get current authentication token (API key or JWT)."""
        return self._token

    @property
    def base_url(self) -> str:
        """Get API base URL."""
        return self._base_url

    def set_token(self, token: str) -> None:
        """
        Update JWT token.

        Args:
            token: New JWT token
        """
        self._token = token
        if self._api:
            self._api.set_token(token)

    async def close(self) -> None:
        """Close the API client and release resources."""
        if self._api:
            await self._api.close()
            self._api = None
        self._downloads = None
        self._exports = None

    async def __aenter__(self) -> StockAPIs:
        """Async context manager entry."""
        # Initialize the API client
        api = self._get_api()
        await api.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        """Async context manager exit."""
        await self.close()


# Alias for backward compatibility
AsyncStockAPIs = StockAPIs
