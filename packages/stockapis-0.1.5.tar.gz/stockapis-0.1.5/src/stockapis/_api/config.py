"""
Configuration for StockSDK API client.

Re-exports from core for backwards compatibility.
"""

from stockapis.core.config import URLS, get_base_url

__all__ = ["get_base_url", "URLS"]
