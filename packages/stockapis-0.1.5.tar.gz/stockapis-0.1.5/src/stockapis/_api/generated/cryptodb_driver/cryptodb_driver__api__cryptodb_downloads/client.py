from __future__ import annotations

import httpx

from .models import (
    AvailabilityGridRequestRequest,
    AvailabilityGridResponse,
    AvailabilityHeatmapRequestRequest,
    AvailabilityHeatmapResponse,
    DataAvailabilityCheckRequest,
    DataAvailabilityResponse,
    DownloadRequest,
    DownloadRequestCreateRequest,
    DownloadSegment,
    PaginatedDownloadRequestList,
    SymbolsWithDataResponse,
)


class CryptodbDriverCryptodbDownloadsAPI:
    """API endpoints for CryptoDB Downloads."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def cryptodb_driver_downloads_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedDownloadRequestList]:
        """
        List download requests

        ViewSet for managing CryptoDB download requests. **Workflow:** 1. POST
        /downloads/ - Create download request 2. GET /downloads/{id}/ - Check
        status 3. GET /downloads/{id}/segments/ - View daily segments **Create
        Request Options:** - By symbol_id: `{"symbol_id": 123, "data_type":
        "klines", ...}` - By lookup: `{"symbol": "BTCUSDT", "exchange":
        "binance", "market_type": "linear", ...}`
        """
        url = "/api/cryptodb_driver/downloads/"
        _params = {
            "ordering": ordering if ordering is not None else None,
            "page": page if page is not None else None,
            "page_size": page_size if page_size is not None else None,
            "search": search if search is not None else None,
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedDownloadRequestList.model_validate(response.json())


    async def cryptodb_driver_downloads_create(
        self,
        data: DownloadRequestCreateRequest,
    ) -> DownloadRequest:
        """
        Create download request

        ViewSet for managing CryptoDB download requests. **Workflow:** 1. POST
        /downloads/ - Create download request 2. GET /downloads/{id}/ - Check
        status 3. GET /downloads/{id}/segments/ - View daily segments **Create
        Request Options:** - By symbol_id: `{"symbol_id": 123, "data_type":
        "klines", ...}` - By lookup: `{"symbol": "BTCUSDT", "exchange":
        "binance", "market_type": "linear", ...}`
        """
        url = "/api/cryptodb_driver/downloads/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return DownloadRequest.model_validate(response.json())


    async def cryptodb_driver_downloads_retrieve(self, id: int) -> DownloadRequest:
        """
        Get download request details

        ViewSet for managing CryptoDB download requests. **Workflow:** 1. POST
        /downloads/ - Create download request 2. GET /downloads/{id}/ - Check
        status 3. GET /downloads/{id}/segments/ - View daily segments **Create
        Request Options:** - By symbol_id: `{"symbol_id": 123, "data_type":
        "klines", ...}` - By lookup: `{"symbol": "BTCUSDT", "exchange":
        "binance", "market_type": "linear", ...}`
        """
        url = f"/api/cryptodb_driver/downloads/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return DownloadRequest.model_validate(response.json())


    async def cryptodb_driver_downloads_update(self, id: int) -> DownloadRequest:
        """
        ViewSet for managing CryptoDB download requests. **Workflow:** 1. POST
        /downloads/ - Create download request 2. GET /downloads/{id}/ - Check
        status 3. GET /downloads/{id}/segments/ - View daily segments **Create
        Request Options:** - By symbol_id: `{"symbol_id": 123, "data_type":
        "klines", ...}` - By lookup: `{"symbol": "BTCUSDT", "exchange":
        "binance", "market_type": "linear", ...}`
        """
        url = f"/api/cryptodb_driver/downloads/{id}/"
        response = await self._client.put(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return DownloadRequest.model_validate(response.json())


    async def cryptodb_driver_downloads_partial_update(self, id: int) -> DownloadRequest:
        """
        ViewSet for managing CryptoDB download requests. **Workflow:** 1. POST
        /downloads/ - Create download request 2. GET /downloads/{id}/ - Check
        status 3. GET /downloads/{id}/segments/ - View daily segments **Create
        Request Options:** - By symbol_id: `{"symbol_id": 123, "data_type":
        "klines", ...}` - By lookup: `{"symbol": "BTCUSDT", "exchange":
        "binance", "market_type": "linear", ...}`
        """
        url = f"/api/cryptodb_driver/downloads/{id}/"
        response = await self._client.patch(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return DownloadRequest.model_validate(response.json())


    async def cryptodb_driver_downloads_destroy(self, id: int) -> None:
        """
        ViewSet for managing CryptoDB download requests. **Workflow:** 1. POST
        /downloads/ - Create download request 2. GET /downloads/{id}/ - Check
        status 3. GET /downloads/{id}/segments/ - View daily segments **Create
        Request Options:** - By symbol_id: `{"symbol_id": 123, "data_type":
        "klines", ...}` - By lookup: `{"symbol": "BTCUSDT", "exchange":
        "binance", "market_type": "linear", ...}`
        """
        url = f"/api/cryptodb_driver/downloads/{id}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def cryptodb_driver_downloads_cancel_create(self, id: int) -> None:
        """
        Cancel pending request

        Cancel all pending/running segments and their RQ jobs.
        """
        url = f"/api/cryptodb_driver/downloads/{id}/cancel/"
        response = await self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def cryptodb_driver_downloads_retry_failed_create(self, id: int) -> None:
        """
        Retry failed segments

        Retry all failed segments for this request.
        """
        url = f"/api/cryptodb_driver/downloads/{id}/retry_failed/"
        response = await self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def cryptodb_driver_downloads_segments_list(
        self,
        id: int,
        ordering: str | None = None,
        search: str | None = None,
    ) -> list[DownloadSegment]:
        """
        Get download segments

        Get all segments for download request.
        """
        url = f"/api/cryptodb_driver/downloads/{id}/segments/"
        response = await self._client.get(url, params={"ordering": ordering if ordering is not None else None, "search": search if search is not None else None})
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return [DownloadSegment.model_validate(item) for item in response.json()]


    async def cryptodb_driver_downloads_status_retrieve(self, id: int) -> DownloadRequest:
        """
        Get download request status

        Get detailed status of download request.
        """
        url = f"/api/cryptodb_driver/downloads/{id}/status/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return DownloadRequest.model_validate(response.json())


    async def cryptodb_driver_downloads_availability_grid_create(
        self,
        data: AvailabilityGridRequestRequest,
    ) -> AvailabilityGridResponse:
        """
        Get availability grid by months

        Returns monthly availability grid for a symbol showing which months have
        data downloaded. Useful for visualizing data coverage. Status values: -
        `complete`: All days in month are downloaded (100%) - `partial`: Some
        days downloaded (1-99%) - `empty`: No data downloaded (0%) -
        `in_progress`: Download in progress for some days
        """
        url = "/api/cryptodb_driver/downloads/availability-grid/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return AvailabilityGridResponse.model_validate(response.json())


    async def cryptodb_driver_downloads_availability_heatmap_create(
        self,
        data: AvailabilityHeatmapRequestRequest,
    ) -> AvailabilityHeatmapResponse:
        """
        Get availability heatmap for all data types

        Returns full availability heatmap for a symbol showing coverage for ALL
        data types and intervals in one response. Rows include: - Klines for
        each interval (1m, 5m, 15m, 30m, 1h, 4h, 1d) - Trades Each row contains
        12 months with coverage percentage and status. This is optimized for
        displaying a complete data availability matrix.
        """
        url = "/api/cryptodb_driver/downloads/availability-heatmap/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return AvailabilityHeatmapResponse.model_validate(response.json())


    async def cryptodb_driver_downloads_check_availability_create(
        self,
        data: DataAvailabilityCheckRequest,
    ) -> DataAvailabilityResponse:
        """
        Check data availability

        Check if data already exists in QuestDB before downloading. Returns
        availability status and missing dates.
        """
        url = "/api/cryptodb_driver/downloads/check_availability/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return DataAvailabilityResponse.model_validate(response.json())


    async def cryptodb_driver_downloads_symbols_with_data_retrieve(
        self,
        data_type: str | None = None,
        exchange: str | None = None,
        market_type: str | None = None,
        search: str | None = None,
    ) -> SymbolsWithDataResponse:
        """
        Get symbols with downloaded data

        Returns list of symbols that have downloaded data in the database.
        Useful for showing which trading pairs have available historical data.
        """
        url = "/api/cryptodb_driver/downloads/symbols-with-data/"
        _params = {
            "data_type": data_type if data_type is not None else None,
            "exchange": exchange if exchange is not None else None,
            "market_type": market_type if market_type is not None else None,
            "search": search if search is not None else None,
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return SymbolsWithDataResponse.model_validate(response.json())


