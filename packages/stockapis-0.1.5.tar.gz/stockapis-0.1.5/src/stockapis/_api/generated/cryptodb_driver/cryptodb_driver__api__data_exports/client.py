from __future__ import annotations

import httpx

from .models import (
    ExportJob,
    ExportJobCreateRequest,
    PaginatedExportJobList,
)


class CryptodbDriverDataExportsAPI:
    """API endpoints for Data Exports."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def cryptodb_driver_exports_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedExportJobList]:
        """
        List my export jobs

        ViewSet for data exports from QuestDB. **Workflow:** 1. POST /exports/ -
        Create export request 2. GET /exports/{id}/ - Check status 3. GET
        /exports/{id}/download/ - Download file when ready **Supported
        formats:** - CSV (default) - Universal, Excel-friendly - Parquet - For
        data science (requires pyarrow) - JSON Lines - API-friendly, streamable
        **Compression:** - none (default) - gzip - zip **Expiration:** Completed
        exports expire after 7 days.
        """
        url = "/api/cryptodb_driver/exports/"
        _params = {
            "ordering": ordering if ordering is not None else None,
            "page": page if page is not None else None,
            "page_size": page_size if page_size is not None else None,
            "search": search if search is not None else None,
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedExportJobList.model_validate(response.json())


    async def cryptodb_driver_exports_create(
        self,
        data: ExportJobCreateRequest,
    ) -> ExportJob:
        """
        Create export job

        ViewSet for data exports from QuestDB. **Workflow:** 1. POST /exports/ -
        Create export request 2. GET /exports/{id}/ - Check status 3. GET
        /exports/{id}/download/ - Download file when ready **Supported
        formats:** - CSV (default) - Universal, Excel-friendly - Parquet - For
        data science (requires pyarrow) - JSON Lines - API-friendly, streamable
        **Compression:** - none (default) - gzip - zip **Expiration:** Completed
        exports expire after 7 days.
        """
        url = "/api/cryptodb_driver/exports/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ExportJob.model_validate(response.json())


    async def cryptodb_driver_exports_retrieve(self, id: int) -> ExportJob:
        """
        Get export job details

        ViewSet for data exports from QuestDB. **Workflow:** 1. POST /exports/ -
        Create export request 2. GET /exports/{id}/ - Check status 3. GET
        /exports/{id}/download/ - Download file when ready **Supported
        formats:** - CSV (default) - Universal, Excel-friendly - Parquet - For
        data science (requires pyarrow) - JSON Lines - API-friendly, streamable
        **Compression:** - none (default) - gzip - zip **Expiration:** Completed
        exports expire after 7 days.
        """
        url = f"/api/cryptodb_driver/exports/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ExportJob.model_validate(response.json())


    async def cryptodb_driver_exports_cancel_create(self, id: int) -> None:
        """
        Cancel export job

        Cancel a pending or processing export job.
        """
        url = f"/api/cryptodb_driver/exports/{id}/cancel/"
        response = await self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def cryptodb_driver_exports_download_retrieve(self, id: int) -> None:
        """
        Download export file

        Download the exported file.
        """
        url = f"/api/cryptodb_driver/exports/{id}/download/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def cryptodb_driver_exports_create_with_download_create(self) -> ExportJob:
        """
        Create export with auto-download of missing data

        Create export job, automatically triggering downloads for missing data.
        **Workflow:** 1. Check data availability for requested range 2. If data
        missing → create DownloadRequest(s) with optimal granularity 3. Create
        ExportJob with status=WAITING_FOR_DATA 4. When downloads complete →
        export starts automatically **Smart Granularity:** - Full months within
        range → monthly download (faster) - Partial months at edges → daily
        download
        """
        url = "/api/cryptodb_driver/exports/create-with-download/"
        response = await self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return ExportJob.model_validate(response.json())


