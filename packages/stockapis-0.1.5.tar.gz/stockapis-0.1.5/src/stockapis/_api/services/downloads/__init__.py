"""
Downloads service for StockAPIs SDK.

Provides high-level methods for managing data downloads.
"""

from .service import DownloadsService

__all__ = ["DownloadsService"]
