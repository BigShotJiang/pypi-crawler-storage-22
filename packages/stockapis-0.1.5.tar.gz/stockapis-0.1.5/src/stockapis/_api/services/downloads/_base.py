"""Base class for downloads service mixins."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...generated.cryptodb_driver import API


class DownloadsBase:
    """Base class providing API access for mixins."""

    _api: API

    @property
    def _client(self):
        """Get downloads API client."""
        return self._api.cryptodb_driver_cryptodb_downloads
