"""Availability checking methods for downloads service."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING

from ...types import DataType, Exchange, KlineInterval, MarketType
from ._base import DownloadsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
        AvailabilityGridResponse,
        AvailabilityHeatmapResponse,
        DataAvailabilityResponse,
        SymbolsWithDataResponse,
    )


class DownloadsAvailabilityMixin(DownloadsBase):
    """Availability checking methods for downloads."""

    async def check_availability(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        *,
        symbol_id: int | None = None,
    ) -> DataAvailabilityResponse:
        """
        Check data availability before downloading.

        Args:
            symbol: Trading pair symbol
            exchange: Exchange name
            data_type: Type of data
            from_date: Start date
            to_date: End date
            market_type: Market type
            symbol_id: Direct symbol ID (alternative to symbol lookup)

        Returns:
            DataAvailabilityResponse with coverage info
        """
        from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
            DataAvailabilityCheckRequest,
        )

        # Convert dates
        if isinstance(from_date, date):
            from_date = from_date.isoformat()
        if isinstance(to_date, date):
            to_date = to_date.isoformat()

        request = DataAvailabilityCheckRequest(
            symbol_id=symbol_id,
            symbol=symbol if symbol_id is None else None,
            exchange=exchange if symbol_id is None else None,  # type: ignore
            market_type=market_type if symbol_id is None else None,  # type: ignore
            data_type=data_type,  # type: ignore
            from_date=from_date,  # type: ignore
            to_date=to_date,  # type: ignore
        )

        return await self._client.cryptodb_driver_downloads_check_availability_create(data=request)

    async def get_availability_grid(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        market_type: MarketType = MarketType.SPOT,
        year: int | None = None,
        interval: KlineInterval | None = None,
        *,
        symbol_id: int | None = None,
    ) -> AvailabilityGridResponse:
        """
        Get monthly availability grid for a symbol.

        Args:
            symbol: Trading pair symbol
            exchange: Exchange name
            data_type: Type of data
            market_type: Market type
            year: Year to check (default: current year)
            interval: Kline interval (for klines)
            symbol_id: Direct symbol ID

        Returns:
            AvailabilityGridResponse with 12 months
        """
        from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
            AvailabilityGridRequestRequest,
        )

        request = AvailabilityGridRequestRequest(
            symbol_id=symbol_id,
            symbol=symbol if symbol_id is None else None,
            exchange=exchange if symbol_id is None else None,  # type: ignore
            market_type=market_type if symbol_id is None else None,  # type: ignore
            data_type=data_type,  # type: ignore
            year=year,
            interval=interval,
        )

        return await self._client.cryptodb_driver_downloads_availability_grid_create(data=request)

    async def get_availability_heatmap(
        self,
        symbol: str,
        exchange: Exchange,
        market_type: MarketType = MarketType.SPOT,
        year: int | None = None,
        *,
        symbol_id: int | None = None,
    ) -> AvailabilityHeatmapResponse:
        """
        Get full availability heatmap for all data types.

        Shows coverage for all kline intervals + trades.

        Args:
            symbol: Trading pair symbol
            exchange: Exchange name
            market_type: Market type
            year: Year to check
            symbol_id: Direct symbol ID

        Returns:
            AvailabilityHeatmapResponse with multiple rows
        """
        from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
            AvailabilityHeatmapRequestRequest,
        )

        request = AvailabilityHeatmapRequestRequest(
            symbol_id=symbol_id,
            symbol=symbol if symbol_id is None else None,
            exchange=exchange if symbol_id is None else None,  # type: ignore
            market_type=market_type if symbol_id is None else None,  # type: ignore
            year=year,
        )

        return await self._client.cryptodb_driver_downloads_availability_heatmap_create(data=request)

    async def get_symbols_with_data(
        self,
        exchange: Exchange | None = None,
        market_type: MarketType | None = None,
        data_type: DataType | None = None,
        search: str | None = None,
    ) -> SymbolsWithDataResponse:
        """
        Get symbols that have downloaded data.

        Args:
            exchange: Filter by exchange
            market_type: Filter by market type
            data_type: Filter by data type
            search: Search term

        Returns:
            SymbolsWithDataResponse with list of symbols
        """
        return await self._client.cryptodb_driver_downloads_symbols_with_data_retrieve(
            exchange=exchange,
            market_type=market_type,
            data_type=data_type,
            search=search,
        )
