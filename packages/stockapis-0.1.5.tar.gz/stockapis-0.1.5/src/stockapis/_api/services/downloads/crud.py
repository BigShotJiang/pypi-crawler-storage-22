"""CRUD operations for downloads service."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING

from ...types import (
    DataType,
    Exchange,
    Granularity,
    KlineInterval,
    MarketType,
)
from ._base import DownloadsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
        DownloadRequest,
        DownloadSegment,
        PaginatedDownloadRequestList,
    )


class DownloadsCRUDMixin(DownloadsBase):
    """CRUD operations for download requests."""

    async def create(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        granularity: Granularity = Granularity.DAILY,
        interval: KlineInterval | None = None,
        *,
        symbol_id: int | None = None,
    ) -> DownloadRequest:
        """
        Create a download request.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            data_type: Type of data to download
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            market_type: Market type (default: spot)
            granularity: Download granularity (default: daily)
            interval: Kline interval (required for klines)
            symbol_id: Direct symbol ID (alternative to symbol lookup)

        Returns:
            Created DownloadRequest

        Raises:
            httpx.HTTPStatusError: If request fails
            ValueError: If klines requested without interval
        """
        from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
            DownloadRequestCreateRequest,
        )

        if data_type == DataType.KLINES and interval is None:
            raise ValueError("interval is required for klines data type")

        # Convert dates
        if isinstance(from_date, date):
            from_date = from_date.isoformat()
        if isinstance(to_date, date):
            to_date = to_date.isoformat()

        request = DownloadRequestCreateRequest(
            symbol_id=symbol_id,
            symbol=symbol if symbol_id is None else None,
            exchange=exchange if symbol_id is None else None,  # type: ignore
            market_type=market_type if symbol_id is None else None,  # type: ignore
            data_type=data_type,  # type: ignore
            granularity=granularity,  # type: ignore
            from_date=from_date,  # type: ignore
            to_date=to_date,  # type: ignore
            interval=interval,
        )

        return await self._client.cryptodb_driver_downloads_create(data=request)

    async def get(self, request_id: int) -> DownloadRequest:
        """
        Get download request by ID.

        Args:
            request_id: Download request ID

        Returns:
            DownloadRequest with full details
        """
        return await self._client.cryptodb_driver_downloads_retrieve(id=request_id)

    async def get_status(self, request_id: int) -> DownloadRequest:
        """
        Get download request status.

        Args:
            request_id: Download request ID

        Returns:
            DownloadRequest with current status
        """
        return await self._client.cryptodb_driver_downloads_status_retrieve(id=request_id)

    async def list(
        self,
        page: int = 1,
        page_size: int = 20,
        ordering: str | None = None,
        search: str | None = None,
    ) -> PaginatedDownloadRequestList:
        """
        List download requests.

        Args:
            page: Page number (1-based)
            page_size: Items per page
            ordering: Sort order (e.g., "-created_at")
            search: Search term

        Returns:
            Paginated list of download requests
        """
        return await self._client.cryptodb_driver_downloads_list(
            page=page,
            page_size=page_size,
            ordering=ordering,
            search=search,
        )

    async def get_segments(
        self,
        request_id: int,
        ordering: str | None = None,
    ) -> list[DownloadSegment]:
        """
        Get segments for a download request.

        Args:
            request_id: Download request ID
            ordering: Sort order

        Returns:
            List of download segments
        """
        return await self._client.cryptodb_driver_downloads_segments_list(
            id=request_id,
            ordering=ordering,
        )

    async def cancel(self, request_id: int) -> None:
        """
        Cancel a pending download request.

        Args:
            request_id: Download request ID
        """
        await self._client.cryptodb_driver_downloads_cancel_create(id=request_id)

    async def retry_failed(self, request_id: int) -> None:
        """
        Retry failed segments of a download request.

        Args:
            request_id: Download request ID
        """
        await self._client.cryptodb_driver_downloads_retry_failed_create(id=request_id)
