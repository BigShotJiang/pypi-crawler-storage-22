"""High-level convenience methods for downloads service."""

from __future__ import annotations

from collections.abc import Callable
from datetime import date
from typing import TYPE_CHECKING

from ...polling import wait_with_progress_callback
from ...types import (
    TERMINAL_DOWNLOAD_STATUSES,
    DataType,
    DownloadStatus,
    Exchange,
    Granularity,
    KlineInterval,
    MarketType,
)
from ._base import DownloadsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
        DownloadRequest,
    )


# Terminal status values as strings for polling utilities
_TERMINAL_DOWNLOAD_STATUS_VALUES = {s.value for s in TERMINAL_DOWNLOAD_STATUSES}


class DownloadsHighLevelMixin(DownloadsBase):
    """High-level convenience methods for downloads."""

    async def create(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        granularity: Granularity = Granularity.DAILY,
        interval: KlineInterval | None = None,
        *,
        symbol_id: int | None = None,
    ) -> DownloadRequest:
        """Create download request (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with DownloadsCRUDMixin")

    async def get_status(self, request_id: int) -> DownloadRequest:
        """Get download request status (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with DownloadsCRUDMixin")

    async def download_and_wait(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        *,
        market_type: MarketType = MarketType.SPOT,
        granularity: Granularity = Granularity.DAILY,
        interval: KlineInterval | None = None,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> DownloadRequest:
        """
        Create download request and wait for completion in one call.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            data_type: Type of data to download
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            market_type: Market type (default: spot)
            granularity: Download granularity (default: daily)
            interval: Kline interval (required for klines)
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds
            on_progress: Callback function called with progress percentage

        Returns:
            Completed DownloadRequest

        Raises:
            ValueError: If download fails
            TimeoutError: If timeout exceeded

        Example:
            request = await api.downloads.download_and_wait(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                data_type=DataType.KLINES,
                from_date="2025-01-01",
                to_date="2025-01-07",
                interval="1m",
                on_progress=lambda p: print(f"Progress: {p}%"),
            )
            print(f"Downloaded {request.total_records_ingested} records")
        """
        # Create request
        request = await self.create(
            symbol=symbol,
            exchange=exchange,
            data_type=data_type,
            from_date=from_date,
            to_date=to_date,
            market_type=market_type,
            granularity=granularity,
            interval=interval,
        )

        # Wait for completion
        result = await wait_with_progress_callback(
            get_item=self.get_status,
            item_id=request.id,
            get_status=lambda r: r.status,
            terminal_statuses=_TERMINAL_DOWNLOAD_STATUS_VALUES,
            on_progress=on_progress,
            poll_interval=poll_interval,
            timeout=timeout,
            item_name="download",
        )

        # Check for failure
        status = DownloadStatus(result.status)
        if status == DownloadStatus.FAILED:
            raise ValueError(
                f"Download failed. Check segments for details: "
                f"api.downloads.get_segments({request.id})"
            )

        return result

    async def download_to_questdb(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        *,
        market_type: MarketType = MarketType.SPOT,
        granularity: Granularity = Granularity.DAILY,
        interval: KlineInterval | None = None,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> dict:
        """
        Download data to QuestDB and return summary.

        Creates download request, waits for completion, and returns
        a summary of ingested data.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            data_type: Type of data to download
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            market_type: Market type (default: spot)
            granularity: Download granularity (default: daily)
            interval: Kline interval (required for klines)
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds
            on_progress: Callback function called with progress percentage

        Returns:
            Summary dict with keys:
            - request_id: Download request ID
            - status: Final status
            - total_records: Total records ingested
            - total_days: Number of days processed
            - file_size_mb: Total file size in MB

        Example:
            result = await api.downloads.download_to_questdb(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                data_type=DataType.TRADES,
                from_date="2025-01-01",
                to_date="2025-01-07",
            )
            print(f"Ingested {result['total_records']:,} records")
        """
        request = await self.download_and_wait(
            symbol=symbol,
            exchange=exchange,
            data_type=data_type,
            from_date=from_date,
            to_date=to_date,
            market_type=market_type,
            granularity=granularity,
            interval=interval,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

        return {
            "request_id": request.id,
            "status": request.status,
            "total_records": request.total_records_ingested,
            "total_days": request.total_days,
            "file_size_mb": request.total_file_size_bytes / 1024 / 1024 if request.total_file_size_bytes else 0,
        }
