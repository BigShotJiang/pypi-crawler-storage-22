"""
Downloads service for StockAPIs SDK.

Provides high-level methods for managing data downloads.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .availability import DownloadsAvailabilityMixin
from .crud import DownloadsCRUDMixin
from .highlevel import DownloadsHighLevelMixin
from .polling import DownloadsPollingMixin

if TYPE_CHECKING:
    from ...generated.cryptodb_driver import API


class DownloadsService(
    DownloadsCRUDMixin,
    DownloadsPollingMixin,
    DownloadsHighLevelMixin,
    DownloadsAvailabilityMixin,
):
    """
    Service for managing data downloads.

    Provides methods to:
    - Create download requests
    - Check download status
    - Wait for completion
    - Check data availability
    - List symbols with data

    High-level convenience methods:
    - download_and_wait(): Create request and wait for completion
    - download_to_questdb(): Download with summary dict
    """

    def __init__(self, api: API):
        """
        Initialize downloads service.

        Args:
            api: Configured API client instance
        """
        self._api = api
