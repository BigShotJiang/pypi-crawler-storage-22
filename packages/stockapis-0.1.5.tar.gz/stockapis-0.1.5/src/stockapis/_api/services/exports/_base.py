"""Base class for exports service mixins."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...generated.cryptodb_driver import API


class ExportsBase:
    """Base class providing API access for mixins."""

    _api: API

    @property
    def _client(self):
        """Get exports API client."""
        return self._api.cryptodb_driver_data_exports
