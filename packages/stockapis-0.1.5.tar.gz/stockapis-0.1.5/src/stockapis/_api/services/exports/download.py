"""Download operations for exports service."""

from __future__ import annotations

import tempfile
import warnings
from pathlib import Path
from typing import TYPE_CHECKING

import httpx

from ...types import ExportJobStatus
from ._base import ExportsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
        ExportJob,
    )

# Check for polars availability at module level
try:
    import polars as pl
    HAS_POLARS = True
except ImportError:
    pl = None  # type: ignore
    HAS_POLARS = False


class ExportsDownloadMixin(ExportsBase):
    """Download operations for export jobs."""

    async def get(self, job_id: int) -> ExportJob:
        """Get export job by ID (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with ExportsCRUDMixin")

    async def download_file(
        self,
        job_id: int,
        output_path: str | Path | None = None,
    ) -> Path:
        """
        Download exported file.

        Args:
            job_id: Export job ID
            output_path: Destination path (default: current dir with auto-name)

        Returns:
            Path to downloaded file

        Raises:
            ValueError: If export not completed or expired
        """
        job = await self.get(job_id)

        if ExportJobStatus(job.status) != ExportJobStatus.COMPLETED:
            raise ValueError(f"Export job {job_id} is not completed. Status: {job.status}")

        if job.is_expired:
            raise ValueError(f"Export job {job_id} has expired")

        if not job.download_url:
            raise ValueError(f"Export job {job_id} has no download URL")

        # Use the /download/ endpoint instead of direct media URL
        # This avoids issues with special characters in paths
        download_url = f"{self._api.base_url}/api/cryptodb_driver/exports/{job_id}/download/"

        # Determine output path
        if output_path is None:
            # Extract filename from URL or generate one
            url_path = job.download_url.split("/")[-1]
            output_path = Path(url_path) if url_path else Path(f"export_{job_id}.csv")
        else:
            output_path = Path(output_path)

        # Download file
        headers = {}
        token = self._api.get_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        async with httpx.AsyncClient() as client:
            response = await client.get(download_url, headers=headers, follow_redirects=True)
            response.raise_for_status()

            # Write to file
            output_path.write_bytes(response.content)

        return output_path

    async def download_to_dataframe(self, job_id: int):
        """
        Download exported file and load as DataFrame.

        Requires polars to be installed.

        Args:
            job_id: Export job ID

        Returns:
            polars.DataFrame with exported data

        Raises:
            ImportError: If polars not installed
            ValueError: If export not completed or expired
        """
        if not HAS_POLARS:
            raise ImportError(
                "polars is required for download_to_dataframe(). "
                "Install with: pip install polars"
            )

        job = await self.get(job_id)

        # Download to temp file
        with tempfile.NamedTemporaryFile(suffix=f".{job.file_format}", delete=False) as tmp:
            tmp_path = Path(tmp.name)

        try:
            await self.download_file(job_id, tmp_path)

            # Load based on format
            if job.file_format == "parquet":
                df = pl.read_parquet(tmp_path)
            elif job.file_format == "csv":
                df = pl.read_csv(tmp_path)
            elif job.file_format == "json":
                df = pl.read_ndjson(tmp_path)
            else:
                raise ValueError(f"Unsupported format: {job.file_format}")

            # Warn if no data returned
            if len(df) == 0:
                warnings.warn(
                    f"Export job {job_id} returned 0 rows. "
                    f"Data for interval '{job.interval}' may not be available in QuestDB. "
                    f"Available intervals are typically: 1m, 1d. "
                    f"Use create_with_download() to fetch missing data first.",
                    UserWarning,
                    stacklevel=2,
                )

            return df
        finally:
            # Cleanup temp file
            tmp_path.unlink(missing_ok=True)
