"""Polling operations for exports service."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from ...polling import poll_with_progress, wait_for_terminal_status
from ...types import TERMINAL_EXPORT_STATUSES
from ._base import ExportsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
        ExportJob,
    )


# Terminal status values as strings for polling utilities
_TERMINAL_EXPORT_STATUS_VALUES = {s.value for s in TERMINAL_EXPORT_STATUSES}


class ExportsPollingMixin(ExportsBase):
    """Polling operations for export jobs."""

    async def get(self, job_id: int) -> ExportJob:
        """Get export job by ID (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with ExportsCRUDMixin")

    async def wait_for_completion(
        self,
        job_id: int,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> ExportJob:
        """
        Wait for export job to complete.

        Args:
            job_id: Export job ID
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds (None for no timeout)

        Returns:
            Completed ExportJob

        Raises:
            TimeoutError: If timeout exceeded
        """
        return await wait_for_terminal_status(
            get_item=self.get,
            item_id=job_id,
            get_status=lambda j: j.status,
            terminal_statuses=_TERMINAL_EXPORT_STATUS_VALUES,
            poll_interval=poll_interval,
            timeout=timeout,
            item_name="export job",
        )

    async def poll_progress(
        self,
        job_id: int,
        poll_interval: float = 2.0,
        timeout: float | None = None,
    ) -> AsyncIterator[ExportJob]:
        """
        Poll export progress, yielding updates.

        Args:
            job_id: Export job ID
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds

        Yields:
            ExportJob on each poll

        Example:
            async for job in exports.poll_progress(123):
                print(f"Progress: {job.progress_percent}%")
                if ExportJobStatus(job.status) == ExportJobStatus.COMPLETED:
                    break
        """
        async for item in poll_with_progress(
            get_item=self.get,
            item_id=job_id,
            get_status=lambda j: j.status,
            terminal_statuses=_TERMINAL_EXPORT_STATUS_VALUES,
            poll_interval=poll_interval,
            timeout=timeout,
        ):
            yield item
