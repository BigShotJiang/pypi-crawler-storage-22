"""
Exports service for StockAPIs SDK.

Provides methods for exporting data to files.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .crud import ExportsCRUDMixin
from .download import ExportsDownloadMixin
from .highlevel import ExportsHighLevelMixin
from .polling import ExportsPollingMixin

if TYPE_CHECKING:
    from ...generated.cryptodb_driver import API


class ExportsService(
    ExportsCRUDMixin,
    ExportsPollingMixin,
    ExportsDownloadMixin,
    ExportsHighLevelMixin,
):
    """
    Service for exporting data to files.

    Provides methods to:
    - Create export jobs
    - Check export status
    - Wait for completion
    - Download exported files

    High-level convenience methods:
    - export_to_file(): Export and download in one call
    - export_to_dataframe(): Export directly to DataFrame
    """

    def __init__(self, api: API):
        """
        Initialize exports service.

        Args:
            api: Configured API client instance
        """
        self._api = api
