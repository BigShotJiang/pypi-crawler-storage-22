"""
Synchronous wrapper for StockAPIs client.

Provides a sync interface for users who don't want to deal with async/await.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Iterator
from datetime import date
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from .client import StockAPIs
from .types import (
    Compression,
    DataType,
    Exchange,
    FileFormat,
    Granularity,
    KlineInterval,
    MarketType,
)

if TYPE_CHECKING:
    from .generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
        AvailabilityGridResponse,
        AvailabilityHeatmapResponse,
        DataAvailabilityResponse,
        DownloadRequest,
        DownloadSegment,
        PaginatedDownloadRequestList,
        SymbolsWithDataResponse,
    )
    from .generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
        ExportJob,
        PaginatedExportJobList,
    )


def _run_async(coro):
    """Run async coroutine in sync context."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None:
        # Already in async context - create new loop in thread
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(asyncio.run, coro)
            return future.result()
    else:
        return asyncio.run(coro)


class SyncDownloadsService:
    """Synchronous wrapper for DownloadsService."""

    def __init__(self, async_client: StockAPIs):
        self._async = async_client

    def create(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        granularity: Granularity = Granularity.DAILY,
        interval: KlineInterval | None = None,
        *,
        symbol_id: int | None = None,
    ) -> DownloadRequest:
        """Create a download request."""
        return _run_async(
            self._async.downloads.create(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                granularity=granularity,
                interval=interval,
                symbol_id=symbol_id,
            )
        )

    def get(self, request_id: int) -> DownloadRequest:
        """Get download request by ID."""
        return _run_async(self._async.downloads.get(request_id))

    def get_status(self, request_id: int) -> DownloadRequest:
        """Get download request status."""
        return _run_async(self._async.downloads.get_status(request_id))

    def list(
        self,
        page: int = 1,
        page_size: int = 20,
        ordering: str | None = None,
        search: str | None = None,
    ) -> PaginatedDownloadRequestList:
        """List download requests."""
        return _run_async(
            self._async.downloads.list(
                page=page,
                page_size=page_size,
                ordering=ordering,
                search=search,
            )
        )

    def get_segments(
        self,
        request_id: int,
        ordering: str | None = None,
    ) -> list[DownloadSegment]:
        """Get segments for a download request."""
        return _run_async(
            self._async.downloads.get_segments(request_id, ordering=ordering)
        )

    def cancel(self, request_id: int) -> None:
        """Cancel a pending download request."""
        return _run_async(self._async.downloads.cancel(request_id))

    def retry_failed(self, request_id: int) -> None:
        """Retry failed segments."""
        return _run_async(self._async.downloads.retry_failed(request_id))

    def wait_for_completion(
        self,
        request_id: int,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> DownloadRequest:
        """Wait for download to complete."""
        return _run_async(
            self._async.downloads.wait_for_completion(
                request_id,
                poll_interval=poll_interval,
                timeout=timeout,
            )
        )

    def poll_progress(
        self,
        request_id: int,
        poll_interval: float = 2.0,
        timeout: float | None = None,
    ) -> Iterator[DownloadRequest]:
        """Poll download progress, yielding updates."""
        async def _collect():
            results = []
            async for item in self._async.downloads.poll_progress(
                request_id,
                poll_interval=poll_interval,
                timeout=timeout,
            ):
                results.append(item)
            return results

        yield from _run_async(_collect())

    def download_and_wait(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        *,
        market_type: MarketType = MarketType.SPOT,
        granularity: Granularity = Granularity.DAILY,
        interval: KlineInterval | None = None,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> DownloadRequest:
        """Create download and wait for completion."""
        return _run_async(
            self._async.downloads.download_and_wait(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                granularity=granularity,
                interval=interval,
                poll_interval=poll_interval,
                timeout=timeout,
                on_progress=on_progress,
            )
        )

    def download_to_questdb(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        *,
        market_type: MarketType = MarketType.SPOT,
        granularity: Granularity = Granularity.DAILY,
        interval: KlineInterval | None = None,
        poll_interval: float = 5.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> dict:
        """Download to QuestDB and return summary."""
        return _run_async(
            self._async.downloads.download_to_questdb(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                granularity=granularity,
                interval=interval,
                poll_interval=poll_interval,
                timeout=timeout,
                on_progress=on_progress,
            )
        )

    def check_availability(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        *,
        symbol_id: int | None = None,
    ) -> DataAvailabilityResponse:
        """Check data availability."""
        return _run_async(
            self._async.downloads.check_availability(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                symbol_id=symbol_id,
            )
        )

    def get_availability_grid(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        market_type: MarketType = MarketType.SPOT,
        year: int | None = None,
        interval: KlineInterval | None = None,
        *,
        symbol_id: int | None = None,
    ) -> AvailabilityGridResponse:
        """Get monthly availability grid."""
        return _run_async(
            self._async.downloads.get_availability_grid(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                market_type=market_type,
                year=year,
                interval=interval,
                symbol_id=symbol_id,
            )
        )

    def get_availability_heatmap(
        self,
        symbol: str,
        exchange: Exchange,
        market_type: MarketType = MarketType.SPOT,
        year: int | None = None,
        *,
        symbol_id: int | None = None,
    ) -> AvailabilityHeatmapResponse:
        """Get full availability heatmap."""
        return _run_async(
            self._async.downloads.get_availability_heatmap(
                symbol=symbol,
                exchange=exchange,
                market_type=market_type,
                year=year,
                symbol_id=symbol_id,
            )
        )

    def get_symbols_with_data(
        self,
        exchange: Exchange | None = None,
        market_type: MarketType | None = None,
        data_type: DataType | None = None,
        search: str | None = None,
    ) -> SymbolsWithDataResponse:
        """Get symbols with downloaded data."""
        return _run_async(
            self._async.downloads.get_symbols_with_data(
                exchange=exchange,
                market_type=market_type,
                data_type=data_type,
                search=search,
            )
        )


class SyncExportsService:
    """Synchronous wrapper for ExportsService."""

    def __init__(self, async_client: StockAPIs):
        self._async = async_client

    def create(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        *,
        symbol_id: int | None = None,
    ) -> ExportJob:
        """Create an export job."""
        return _run_async(
            self._async.exports.create(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                interval=interval,
                file_format=file_format,
                compression=compression,
                symbol_id=symbol_id,
            )
        )

    def create_with_download(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        *,
        symbol_id: int | None = None,
    ) -> ExportJob:
        """Create export with auto-download."""
        return _run_async(
            self._async.exports.create_with_download(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                interval=interval,
                file_format=file_format,
                compression=compression,
                symbol_id=symbol_id,
            )
        )

    def get(self, job_id: int) -> ExportJob:
        """Get export job by ID."""
        return _run_async(self._async.exports.get(job_id))

    def list(
        self,
        page: int = 1,
        page_size: int = 20,
        ordering: str | None = None,
        search: str | None = None,
    ) -> PaginatedExportJobList:
        """List export jobs."""
        return _run_async(
            self._async.exports.list(
                page=page,
                page_size=page_size,
                ordering=ordering,
                search=search,
            )
        )

    def cancel(self, job_id: int) -> None:
        """Cancel a pending export job."""
        return _run_async(self._async.exports.cancel(job_id))

    def wait_for_completion(
        self,
        job_id: int,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> ExportJob:
        """Wait for export to complete."""
        return _run_async(
            self._async.exports.wait_for_completion(
                job_id,
                poll_interval=poll_interval,
                timeout=timeout,
            )
        )

    def poll_progress(
        self,
        job_id: int,
        poll_interval: float = 2.0,
        timeout: float | None = None,
    ) -> Iterator[ExportJob]:
        """Poll export progress, yielding updates."""
        async def _collect():
            results = []
            async for item in self._async.exports.poll_progress(
                job_id,
                poll_interval=poll_interval,
                timeout=timeout,
            ):
                results.append(item)
            return results

        yield from _run_async(_collect())

    def download_file(
        self,
        job_id: int,
        output_path: str | Path | None = None,
    ) -> Path:
        """Download exported file."""
        return _run_async(
            self._async.exports.download_file(job_id, output_path)
        )

    def download_to_dataframe(self, job_id: int):
        """Download and load as DataFrame."""
        return _run_async(self._async.exports.download_to_dataframe(job_id))

    def export_to_file(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        output_path: str | Path,
        *,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        auto_download: bool = False,
        poll_interval: float = 2.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> Path:
        """Export data to file in one call."""
        return _run_async(
            self._async.exports.export_to_file(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                output_path=output_path,
                market_type=market_type,
                interval=interval,
                file_format=file_format,
                compression=compression,
                auto_download=auto_download,
                poll_interval=poll_interval,
                timeout=timeout,
                on_progress=on_progress,
            )
        )

    def export_to_dataframe(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        *,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        auto_download: bool = False,
        poll_interval: float = 2.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ):
        """Export data to DataFrame in one call."""
        return _run_async(
            self._async.exports.export_to_dataframe(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                interval=interval,
                auto_download=auto_download,
                poll_interval=poll_interval,
                timeout=timeout,
                on_progress=on_progress,
            )
        )


class StockAPIsSync:
    """
    Synchronous API client for StockAPIs.

    Wraps the async client for sync usage.

    Usage:
        with StockAPIsSync(api_key="your-key") as api:
            # Export to DataFrame
            df = api.exports.export_to_dataframe(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                data_type=DataType.KLINES,
                from_date="2025-01-01",
                to_date="2025-01-07",
                interval="1m",
            )

            # Download to QuestDB
            result = api.downloads.download_to_questdb(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                data_type=DataType.TRADES,
                from_date="2025-01-01",
                to_date="2025-01-02",
            )
    """

    def __init__(
        self,
        token: str | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        mode: Literal["dev", "prod"] | None = None,
    ):
        """
        Initialize sync API client.

        Args:
            token: JWT token (deprecated, use api_key)
            api_key: API key for authentication
            base_url: API base URL
            mode: "dev" for localhost, "prod" for production
        """
        self._async_client = StockAPIs(
            token=token,
            api_key=api_key,
            base_url=base_url,
            mode=mode,
        )
        self._downloads: SyncDownloadsService | None = None
        self._exports: SyncExportsService | None = None

    @property
    def downloads(self) -> SyncDownloadsService:
        """Access downloads service."""
        if self._downloads is None:
            self._downloads = SyncDownloadsService(self._async_client)
        return self._downloads

    @property
    def exports(self) -> SyncExportsService:
        """Access exports service."""
        if self._exports is None:
            self._exports = SyncExportsService(self._async_client)
        return self._exports

    @property
    def token(self) -> str | None:
        """Get current token."""
        return self._async_client.token

    @property
    def base_url(self) -> str:
        """Get API base URL."""
        return self._async_client.base_url

    def set_token(self, token: str) -> None:
        """Update token."""
        self._async_client.set_token(token)

    def close(self) -> None:
        """Close the client."""
        # Don't close async client in sync wrapper - it can cause event loop issues
        # The client will be garbage collected anyway
        pass

    def __enter__(self) -> StockAPIsSync:
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        """Context manager exit."""
        self.close()
