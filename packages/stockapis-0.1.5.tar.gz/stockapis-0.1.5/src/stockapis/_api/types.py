"""
Type definitions for StockSDK.

Re-exports enums and types from generated clients with cleaner names.
"""

from __future__ import annotations

from typing import Literal

from .generated.cryptodb_driver.enums import (
    AvailabilityGridRequestRequestDataType as DataType,
)

# Re-export generated enums with cleaner aliases
from .generated.cryptodb_driver.enums import (
    # Exchange/Market types
    AvailabilityGridRequestRequestExchange as Exchange,
)
from .generated.cryptodb_driver.enums import (
    AvailabilityGridRequestRequestMarketType as MarketType,
)
from .generated.cryptodb_driver.enums import (
    # Download
    DownloadRequestGranularity as Granularity,
)
from .generated.cryptodb_driver.enums import (
    DownloadSegmentStatus as DownloadStatus,
)
from .generated.cryptodb_driver.enums import (
    ExportJobCompression as Compression,
)
from .generated.cryptodb_driver.enums import (
    ExportJobFileFormat as FileFormat,
)
from .generated.cryptodb_driver.enums import (
    # Export
    ExportJobStatus,
)
from .generated.cryptodb_driver.enums import (
    # Availability
    HeatmapMonthCellStatus as AvailabilityStatus,
)
from .generated.cryptodb_driver.enums import (
    # Symbol
    SymbolNestedStatus as SymbolStatus,
)

# Kline intervals (not generated, define as Literal)
KlineInterval = Literal["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"]

# Terminal statuses (for polling)
TERMINAL_DOWNLOAD_STATUSES = {
    DownloadStatus.COMPLETED,
    DownloadStatus.FAILED,
    DownloadStatus.SKIPPED,
    DownloadStatus.CANCELLED,
}

TERMINAL_EXPORT_STATUSES = {
    ExportJobStatus.COMPLETED,
    ExportJobStatus.FAILED,
    ExportJobStatus.EXPIRED,
    ExportJobStatus.CANCELLED,
}

__all__ = [
    # Enums
    "Exchange",
    "MarketType",
    "DataType",
    "Granularity",
    "DownloadStatus",
    "ExportJobStatus",
    "FileFormat",
    "Compression",
    "AvailabilityStatus",
    "SymbolStatus",
    # Types
    "KlineInterval",
    # Constants
    "TERMINAL_DOWNLOAD_STATUSES",
    "TERMINAL_EXPORT_STATUSES",
]
