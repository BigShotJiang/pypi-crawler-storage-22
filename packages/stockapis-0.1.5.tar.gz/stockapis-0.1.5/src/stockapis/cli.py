"""
StockAPIs CLI.

Command-line interface for StockAPIs SDK.

Usage:
    stockapis download BTCUSDT --exchange binance --from 2025-01-01 --to 2025-01-31
    stockapis export BTCUSDT -o data.csv --exchange binance --from 2025-01-01 --to 2025-01-07
    stockapis status 123
    stockapis list downloads
"""

from __future__ import annotations

import os
import sys

import click
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
from rich.table import Table

from stockapis import (
    DataType,
    Exchange,
    FileFormat,
    Granularity,
    MarketType,
    StockAPIsSync,
)

console = Console()

# Get API key from environment or use placeholder
API_KEY_ENV = "STOCKAPIS_API_KEY"


def get_api_key(ctx: click.Context) -> str:
    """Get API key from option or environment."""
    api_key = ctx.obj.get("api_key") if ctx.obj else None
    if not api_key:
        api_key = os.environ.get(API_KEY_ENV)
    if not api_key:
        console.print(f"[red]Error:[/red] API key required. Set {API_KEY_ENV} or use --api-key")
        sys.exit(1)
    return api_key


def parse_exchange(value: str) -> Exchange:
    """Parse exchange string to enum."""
    try:
        return Exchange(value.lower())
    except ValueError:
        console.print(f"[red]Error:[/red] Invalid exchange: {value}. Use: binance, bybit")
        sys.exit(1)


def parse_market_type(value: str) -> MarketType:
    """Parse market type string to enum."""
    try:
        return MarketType(value.lower())
    except ValueError:
        console.print(f"[red]Error:[/red] Invalid market type: {value}. Use: spot, linear, inverse")
        sys.exit(1)


def parse_data_type(value: str) -> DataType:
    """Parse data type string to enum."""
    try:
        return DataType(value.lower())
    except ValueError:
        console.print(f"[red]Error:[/red] Invalid data type: {value}. Use: klines, trades")
        sys.exit(1)


def format_status(status: str) -> str:
    """Format status with color."""
    colors = {
        "completed": "green",
        "processing": "yellow",
        "pending": "blue",
        "failed": "red",
        "cancelled": "dim",
        "skipped": "dim",
        "expired": "red",
        "waiting_for_data": "cyan",
    }
    color = colors.get(status.lower(), "white")
    return f"[{color}]{status}[/{color}]"


def format_number(n: int | None) -> str:
    """Format number with commas."""
    if n is None:
        return "-"
    return f"{n:,}"


def format_size(bytes_: int | None) -> str:
    """Format bytes as human-readable size."""
    if not bytes_:
        return "-"
    for unit in ["B", "KB", "MB", "GB"]:
        if bytes_ < 1024:
            return f"{bytes_:.1f} {unit}"
        bytes_ /= 1024
    return f"{bytes_:.1f} TB"


@click.group()
@click.option("--api-key", "-k", envvar=API_KEY_ENV, help="API key (or set STOCKAPIS_API_KEY)")
@click.option("--base-url", "-u", help="API base URL (default: production)")
@click.version_option()
@click.pass_context
def cli(ctx: click.Context, api_key: str | None, base_url: str | None) -> None:
    """StockAPIs - Cryptocurrency historical data CLI."""
    ctx.ensure_object(dict)
    ctx.obj["api_key"] = api_key
    ctx.obj["base_url"] = base_url


@cli.command()
@click.argument("symbol")
@click.option("--exchange", "-e", required=True, help="Exchange: binance, bybit")
@click.option("--from", "from_date", required=True, help="Start date (YYYY-MM-DD)")
@click.option("--to", "to_date", required=True, help="End date (YYYY-MM-DD)")
@click.option("--type", "data_type", default="trades", help="Data type: trades, klines (default: trades)")
@click.option("--market", default="spot", help="Market type: spot, linear, inverse (default: spot)")
@click.option("--interval", "-i", help="Kline interval (required for klines): 1m, 5m, 1h, 1d, etc.")
@click.option("--granularity", "-g", default="daily", help="Granularity: daily, monthly (default: daily)")
@click.option("--wait/--no-wait", default=True, help="Wait for completion (default: wait)")
@click.pass_context
def download(
    ctx: click.Context,
    symbol: str,
    exchange: str,
    from_date: str,
    to_date: str,
    data_type: str,
    market: str,
    interval: str | None,
    granularity: str,
    wait: bool,
) -> None:
    """Download data to QuestDB.

    Example:
        stockapis download BTCUSDT -e binance --from 2025-01-01 --to 2025-01-31
    """
    api_key = get_api_key(ctx)
    base_url = ctx.obj.get("base_url")

    exchange_enum = parse_exchange(exchange)
    market_enum = parse_market_type(market)
    data_type_enum = parse_data_type(data_type)
    granularity_enum = Granularity(granularity.lower())

    if data_type_enum == DataType.KLINES and not interval:
        console.print("[red]Error:[/red] --interval required for klines data type")
        sys.exit(1)

    with StockAPIsSync(api_key=api_key, base_url=base_url) as api:
        console.print(f"Creating download request for [bold]{symbol}[/bold]...")

        if wait:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                console=console,
            ) as progress:
                task = progress.add_task("Downloading...", total=100)

                def on_progress(pct: int) -> None:
                    progress.update(task, completed=pct)

                try:
                    result = api.downloads.download_to_questdb(
                        symbol=symbol.upper(),
                        exchange=exchange_enum,
                        data_type=data_type_enum,
                        from_date=from_date,
                        to_date=to_date,
                        market_type=market_enum,
                        granularity=granularity_enum,
                        interval=interval,
                        on_progress=on_progress,
                    )
                except Exception as e:
                    console.print(f"[red]Error:[/red] {e}")
                    sys.exit(1)

            console.print()
            console.print("[green]Download completed![/green]")
            console.print(f"  Request ID: {result['request_id']}")
            console.print(f"  Status: {format_status(result['status'])}")
            console.print(f"  Records: {format_number(result['total_records'])}")
            console.print(f"  Days: {result['total_days']}")
            console.print(f"  Size: {format_size(int(result['file_size_mb'] * 1024 * 1024))}")
        else:
            try:
                request = api.downloads.create(
                    symbol=symbol.upper(),
                    exchange=exchange_enum,
                    data_type=data_type_enum,
                    from_date=from_date,
                    to_date=to_date,
                    market_type=market_enum,
                    granularity=granularity_enum,
                    interval=interval,
                )
            except Exception as e:
                console.print(f"[red]Error:[/red] {e}")
                sys.exit(1)

            console.print("[green]Download request created![/green]")
            console.print(f"  Request ID: {request.id}")
            console.print(f"  Status: {format_status(request.status)}")
            console.print()
            console.print(f"Check status: [cyan]stockapis status {request.id} --type download[/cyan]")


@cli.command()
@click.argument("symbol")
@click.option("--exchange", "-e", required=True, help="Exchange: binance, bybit")
@click.option("--from", "from_date", required=True, help="Start date (YYYY-MM-DD)")
@click.option("--to", "to_date", required=True, help="End date (YYYY-MM-DD)")
@click.option("--output", "-o", required=True, help="Output file path")
@click.option("--type", "data_type", default="klines", help="Data type: trades, klines (default: klines)")
@click.option("--market", default="spot", help="Market type: spot, linear, inverse (default: spot)")
@click.option("--interval", "-i", help="Kline interval (required for klines): 1m, 5m, 1h, 1d, etc.")
@click.option("--format", "file_format", default="csv", help="File format: csv, parquet, json (default: csv)")
@click.option("--auto-download", is_flag=True, help="Auto-download missing data from exchange")
@click.pass_context
def export(
    ctx: click.Context,
    symbol: str,
    exchange: str,
    from_date: str,
    to_date: str,
    output: str,
    data_type: str,
    market: str,
    interval: str | None,
    file_format: str,
    auto_download: bool,
) -> None:
    """Export data to file.

    Example:
        stockapis export BTCUSDT -e binance --from 2025-01-01 --to 2025-01-07 -i 1m -o btcusdt.csv
    """
    api_key = get_api_key(ctx)
    base_url = ctx.obj.get("base_url")

    exchange_enum = parse_exchange(exchange)
    market_enum = parse_market_type(market)
    data_type_enum = parse_data_type(data_type)
    format_enum = FileFormat(file_format.lower())

    if data_type_enum == DataType.KLINES and not interval:
        console.print("[red]Error:[/red] --interval required for klines data type")
        sys.exit(1)

    with StockAPIsSync(api_key=api_key, base_url=base_url) as api:
        console.print(f"Exporting [bold]{symbol}[/bold] to [bold]{output}[/bold]...")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Exporting...", total=100)

            def on_progress(pct: int) -> None:
                progress.update(task, completed=pct)

            try:
                path = api.exports.export_to_file(
                    symbol=symbol.upper(),
                    exchange=exchange_enum,
                    data_type=data_type_enum,
                    from_date=from_date,
                    to_date=to_date,
                    output_path=output,
                    market_type=market_enum,
                    interval=interval,
                    file_format=format_enum,
                    auto_download=auto_download,
                    on_progress=on_progress,
                )
            except Exception as e:
                console.print(f"[red]Error:[/red] {e}")
                sys.exit(1)

        console.print()
        console.print("[green]Export completed![/green]")
        console.print(f"  File: {path}")
        console.print(f"  Size: {format_size(path.stat().st_size)}")


@cli.command()
@click.argument("request_id", type=int)
@click.option("--type", "job_type", default="download", help="Job type: download, export (default: download)")
@click.pass_context
def status(ctx: click.Context, request_id: int, job_type: str) -> None:
    """Check status of a download or export job.

    Example:
        stockapis status 123
        stockapis status 456 --type export
    """
    api_key = get_api_key(ctx)
    base_url = ctx.obj.get("base_url")

    with StockAPIsSync(api_key=api_key, base_url=base_url) as api:
        try:
            if job_type == "download":
                req = api.downloads.get(request_id)
                console.print(f"[bold]Download Request #{req.id}[/bold]")
                console.print(f"  Symbol: {req.symbol.symbol if req.symbol else 'N/A'}")
                console.print(f"  Status: {format_status(req.status)}")
                console.print(f"  Progress: {req.progress_percent:.1f}%")
                console.print(f"  Records: {format_number(req.total_records_ingested)}")
                console.print(f"  Days: {req.total_days or '-'}")
                console.print(f"  Size: {format_size(req.total_file_size_bytes)}")
                console.print(f"  Created: {req.created_at}")
            else:
                job = api.exports.get(request_id)
                console.print(f"[bold]Export Job #{job.id}[/bold]")
                console.print(f"  Symbol: {job.symbol.symbol if job.symbol else 'N/A'}")
                console.print(f"  Status: {format_status(job.status)}")
                console.print(f"  Format: {job.file_format}")
                console.print(f"  Rows: {format_number(job.row_count)}")
                console.print(f"  Size: {format_size(job.file_size)}")
                console.print(f"  Created: {job.created_at}")
                if job.download_url:
                    console.print(f"  URL: {job.download_url}")
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(1)


@cli.command("list")
@click.argument("job_type", type=click.Choice(["downloads", "exports"]))
@click.option("--limit", "-n", default=10, help="Number of items to show (default: 10)")
@click.pass_context
def list_jobs(ctx: click.Context, job_type: str, limit: int) -> None:
    """List recent downloads or exports.

    Example:
        stockapis list downloads
        stockapis list exports -n 20
    """
    api_key = get_api_key(ctx)
    base_url = ctx.obj.get("base_url")

    with StockAPIsSync(api_key=api_key, base_url=base_url) as api:
        try:
            if job_type == "downloads":
                result = api.downloads.list(page_size=limit, ordering="-created_at")
                table = Table(title="Recent Downloads")
                table.add_column("ID", style="cyan")
                table.add_column("Symbol")
                table.add_column("Status")
                table.add_column("Progress")
                table.add_column("Records", justify="right")
                table.add_column("Created")

                for req in result.results:
                    table.add_row(
                        str(req.id),
                        req.symbol.symbol if req.symbol else "-",
                        format_status(req.status),
                        f"{req.progress_percent:.0f}%",
                        format_number(req.total_records_ingested),
                        str(req.created_at)[:19] if req.created_at else "-",
                    )

                console.print(table)
                console.print(f"Total: {result.count}")
            else:
                result = api.exports.list(page_size=limit, ordering="-created_at")
                table = Table(title="Recent Exports")
                table.add_column("ID", style="cyan")
                table.add_column("Symbol")
                table.add_column("Status")
                table.add_column("Format")
                table.add_column("Rows", justify="right")
                table.add_column("Size", justify="right")
                table.add_column("Created")

                for job in result.results:
                    table.add_row(
                        str(job.id),
                        job.symbol.symbol if job.symbol else "-",
                        format_status(job.status),
                        job.file_format or "-",
                        format_number(job.row_count),
                        format_size(job.file_size),
                        str(job.created_at)[:19] if job.created_at else "-",
                    )

                console.print(table)
                console.print(f"Total: {result.count}")
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(1)


@cli.command()
@click.argument("request_id", type=int)
@click.option("--type", "job_type", default="download", help="Job type: download, export (default: download)")
@click.pass_context
def cancel(ctx: click.Context, request_id: int, job_type: str) -> None:
    """Cancel a pending download or export job.

    Example:
        stockapis cancel 123
        stockapis cancel 456 --type export
    """
    api_key = get_api_key(ctx)
    base_url = ctx.obj.get("base_url")

    with StockAPIsSync(api_key=api_key, base_url=base_url) as api:
        try:
            if job_type == "download":
                api.downloads.cancel(request_id)
            else:
                api.exports.cancel(request_id)
            console.print(f"[green]Cancelled {job_type} #{request_id}[/green]")
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(1)


@cli.command()
@click.argument("symbol")
@click.option("--exchange", "-e", required=True, help="Exchange: binance, bybit")
@click.option("--from", "from_date", required=True, help="Start date (YYYY-MM-DD)")
@click.option("--to", "to_date", required=True, help="End date (YYYY-MM-DD)")
@click.option("--type", "data_type", default="klines", help="Data type: trades, klines (default: klines)")
@click.option("--market", default="spot", help="Market type: spot, linear, inverse (default: spot)")
@click.pass_context
def availability(
    ctx: click.Context,
    symbol: str,
    exchange: str,
    from_date: str,
    to_date: str,
    data_type: str,
    market: str,
) -> None:
    """Check data availability.

    Example:
        stockapis availability BTCUSDT -e binance --from 2024-01-01 --to 2024-12-31
    """
    api_key = get_api_key(ctx)
    base_url = ctx.obj.get("base_url")

    exchange_enum = parse_exchange(exchange)
    market_enum = parse_market_type(market)
    data_type_enum = parse_data_type(data_type)

    with StockAPIsSync(api_key=api_key, base_url=base_url) as api:
        try:
            result = api.downloads.check_availability(
                symbol=symbol.upper(),
                exchange=exchange_enum,
                data_type=data_type_enum,
                from_date=from_date,
                to_date=to_date,
                market_type=market_enum,
            )

            status = "complete" if result.available else "partial" if result.coverage_percent > 0 else "empty"
            console.print(f"[bold]Data Availability for {symbol}[/bold]")
            console.print(f"  Coverage: {result.coverage_percent:.1f}%")
            console.print(f"  Status: {format_status(status)}")
            console.print(f"  Available days: {result.available_days}")
            console.print(f"  Total days: {result.total_days}")

            if result.missing_days:
                console.print(f"  Missing days: {len(result.missing_days)}")
                if len(result.missing_days) <= 10:
                    for day in result.missing_days:
                        console.print(f"    - {day}")
                else:
                    for day in result.missing_days[:5]:
                        console.print(f"    - {day}")
                    console.print(f"    ... and {len(result.missing_days) - 5} more")
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(1)


def main() -> None:
    """Main entry point."""
    cli()


if __name__ == "__main__":
    main()
