"""
StockSDK Core module.

Contains shared configuration and utilities used across the SDK.
Types are in stockapis._api.types to avoid circular imports.
"""

from .config import URLS, get_base_url
from .polling import (
    poll_with_progress,
    wait_for_terminal_status,
    wait_with_progress_callback,
)

__all__ = [
    # Config
    "get_base_url",
    "URLS",
    # Polling
    "wait_for_terminal_status",
    "poll_with_progress",
    "wait_with_progress_callback",
]
