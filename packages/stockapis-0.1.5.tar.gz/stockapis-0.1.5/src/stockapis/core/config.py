"""
Configuration for StockSDK.

Environment-specific URLs and settings.
"""

from __future__ import annotations

import os
from typing import Literal

# Environment URLs
URLS = {
    "dev": "http://localhost:8000",
    "prod": "https://api.stockapis.com",
}


def get_base_url(mode: Literal["dev", "prod"] | None = None) -> str:
    """
    Get base URL for API.

    Args:
        mode: "dev" or "prod". If not provided, uses ENVIRONMENT env var.

    Returns:
        Base URL string
    """
    if mode is None:
        mode = os.getenv("ENVIRONMENT", "prod").lower()  # type: ignore

    if mode not in URLS:
        mode = "prod"

    return URLS[mode]  # type: ignore
