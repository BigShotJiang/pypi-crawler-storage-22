"""
Shared polling utilities for StockAPIs SDK.

Provides reusable async polling logic for waiting on job completion.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Callable
from typing import Any, TypeVar

import httpx

T = TypeVar("T")

logger = logging.getLogger(__name__)

# Max retries for transient network errors during polling
MAX_POLL_RETRIES = 3


async def _safe_get_item(
    get_item: Callable[[int], Any],
    item_id: int,
    max_retries: int = MAX_POLL_RETRIES,
) -> Any:
    """
    Fetch item with retry on transient network errors.

    Args:
        get_item: Async function to fetch the item by ID
        item_id: ID of the item to fetch
        max_retries: Maximum retry attempts

    Returns:
        The fetched item

    Raises:
        The last exception if all retries fail
    """
    last_error: Exception | None = None

    for attempt in range(max_retries):
        try:
            return await get_item(item_id)
        except (
            httpx.TimeoutException,
            httpx.ConnectError,
            httpx.ReadError,
            httpx.WriteError,
        ) as e:
            last_error = e
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff: 1s, 2s, 4s
                logger.warning(
                    f"Polling error (attempt {attempt + 1}/{max_retries}): {e}. "
                    f"Retrying in {wait_time}s..."
                )
                await asyncio.sleep(wait_time)
            else:
                logger.error(f"Polling failed after {max_retries} attempts: {e}")

    raise last_error  # type: ignore


async def wait_for_terminal_status(
    get_item: Callable[[int], Any],
    item_id: int,
    get_status: Callable[[Any], str],
    terminal_statuses: set[str],
    poll_interval: float = 5.0,
    timeout: float | None = None,
    item_name: str = "job",
) -> Any:
    """
    Wait for an item to reach a terminal status.

    Args:
        get_item: Async function to fetch the item by ID
        item_id: ID of the item to poll
        get_status: Function to extract status string from item
        terminal_statuses: Set of status values that indicate completion
        poll_interval: Seconds between status checks
        timeout: Maximum wait time in seconds (None for no timeout)
        item_name: Name of item for error messages

    Returns:
        The item once it reaches a terminal status

    Raises:
        TimeoutError: If timeout exceeded before reaching terminal status
    """
    elapsed = 0.0

    while True:
        item = await _safe_get_item(get_item, item_id)
        status = get_status(item)

        if status in terminal_statuses:
            return item

        if timeout is not None and elapsed >= timeout:
            # Try to get progress if available
            progress = getattr(item, "progress_percent", None)
            progress_str = f", progress: {progress}%" if progress is not None else ""
            raise TimeoutError(
                f"{item_name.capitalize()} {item_id} did not complete within {timeout}s. "
                f"Current status: {status}{progress_str}"
            )

        await asyncio.sleep(poll_interval)
        elapsed += poll_interval


async def poll_with_progress(
    get_item: Callable[[int], Any],
    item_id: int,
    get_status: Callable[[Any], str],
    terminal_statuses: set[str],
    poll_interval: float = 2.0,
    timeout: float | None = None,
) -> AsyncIterator[Any]:
    """
    Poll an item's status, yielding updates.

    Args:
        get_item: Async function to fetch the item by ID
        item_id: ID of the item to poll
        get_status: Function to extract status string from item
        terminal_statuses: Set of status values that indicate completion
        poll_interval: Seconds between status checks
        timeout: Maximum wait time in seconds

    Yields:
        The item on each poll until terminal status or timeout
    """
    elapsed = 0.0

    while True:
        item = await _safe_get_item(get_item, item_id)
        yield item

        status = get_status(item)
        if status in terminal_statuses:
            return

        if timeout is not None and elapsed >= timeout:
            return

        await asyncio.sleep(poll_interval)
        elapsed += poll_interval


async def wait_with_progress_callback(
    get_item: Callable[[int], Any],
    item_id: int,
    get_status: Callable[[Any], str],
    terminal_statuses: set[str],
    on_progress: Callable[[int], None] | None = None,
    poll_interval: float = 2.0,
    timeout: float | None = None,
    item_name: str = "job",
) -> Any:
    """
    Wait for terminal status with optional progress callback.

    Args:
        get_item: Async function to fetch the item by ID
        item_id: ID of the item to poll
        get_status: Function to extract status string from item
        terminal_statuses: Set of status values that indicate completion
        on_progress: Callback function called with progress percentage
        poll_interval: Seconds between status checks
        timeout: Maximum wait time in seconds
        item_name: Name of item for error messages

    Returns:
        The item once it reaches a terminal status

    Raises:
        TimeoutError: If timeout exceeded
        ValueError: If item fails
    """
    elapsed = 0.0

    while True:
        item = await _safe_get_item(get_item, item_id)
        status = get_status(item)

        if on_progress:
            progress = getattr(item, "progress_percent", 0)
            on_progress(progress)

        if status in terminal_statuses:
            return item

        if timeout is not None and elapsed >= timeout:
            progress = getattr(item, "progress_percent", None)
            progress_str = f", progress: {progress}%" if progress is not None else ""
            raise TimeoutError(
                f"{item_name.capitalize()} did not complete within {timeout}s. "
                f"Status: {status}{progress_str}"
            )

        await asyncio.sleep(poll_interval)
        elapsed += poll_interval
