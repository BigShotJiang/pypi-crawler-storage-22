"""
StockSDK - Python SDK for StockAPIS.

Provides access to cryptocurrency historical data (trades, klines)
from Binance and Bybit.

Quick Start:
    from stockapis import StockAPIs, Exchange, OHLCV

    async with StockAPIs(api_key="demo_stockapis_2024") as api:
        # === TYPED OHLCV DATA (recommended) ===
        ohlcv = await api.exports.export_to_ohlcv(
            symbol="BTCUSDT",
            exchange=Exchange.BINANCE,
            from_date="2025-01-01",
            to_date="2025-01-07",
            interval="1h",
        )
        print(f"Latest close: {ohlcv.close[-1]}")
        print(f"Volatility: {ohlcv.volatility:.2%}")

        # === RAW DATAFRAME ===
        df = await api.exports.export_to_dataframe(
            symbol="BTCUSDT",
            exchange=Exchange.BINANCE,
            data_type=DataType.KLINES,
            from_date="2025-01-01",
            to_date="2025-01-07",
            interval="1m",
        )

        # === SAVE TO FILE ===
        path = await api.exports.export_to_file(
            symbol="BTCUSDT",
            exchange=Exchange.BINANCE,
            data_type=DataType.KLINES,
            from_date="2025-01-01",
            to_date="2025-01-07",
            interval="1m",
            output_path="btcusdt.csv",
        )
"""

from stockapis._api import (
    OHLCV,
    TERMINAL_DOWNLOAD_STATUSES,
    TERMINAL_EXPORT_STATUSES,
    AsyncStockAPIs,
    AvailabilityGridResponse,
    AvailabilityHeatmapResponse,
    AvailabilityStatus,
    Compression,
    DataAvailabilityResponse,
    DataType,
    DownloadRequest,
    DownloadSegment,
    DownloadsService,
    DownloadStatus,
    Exchange,
    ExportJob,
    ExportJobStatus,
    ExportsService,
    FileFormat,
    Granularity,
    KlineInterval,
    MarketType,
    PaginatedDownloadRequestList,
    PaginatedExportJobList,
    StockAPIs,
    StockAPIsSync,
    SymbolStatus,
    SymbolsWithDataResponse,
    Trade,
)
from stockapis._api.cache import configure_cache, get_cache

__version__ = "0.1.8"

__all__ = [
    # Main client
    "StockAPIs",
    "StockAPIsSync",
    "AsyncStockAPIs",
    # Services
    "DownloadsService",
    "ExportsService",
    # Type aliases
    "Exchange",
    "MarketType",
    "DataType",
    "Granularity",
    "KlineInterval",
    "FileFormat",
    "Compression",
    # Status enums
    "DownloadStatus",
    "ExportJobStatus",
    "AvailabilityStatus",
    "SymbolStatus",
    # Constants
    "TERMINAL_DOWNLOAD_STATUSES",
    "TERMINAL_EXPORT_STATUSES",
    # Download models
    "DownloadRequest",
    "DownloadSegment",
    "DataAvailabilityResponse",
    "AvailabilityGridResponse",
    "AvailabilityHeatmapResponse",
    "SymbolsWithDataResponse",
    "PaginatedDownloadRequestList",
    # Export models
    "ExportJob",
    "PaginatedExportJobList",
    # Typed data models
    "OHLCV",
    "Trade",
    # Cache
    "configure_cache",
    "get_cache",
    # Version
    "__version__",
]
