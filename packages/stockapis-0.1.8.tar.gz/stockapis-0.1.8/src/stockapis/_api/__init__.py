"""
StockSDK API Client.

Usage:
    from stockapis import StockAPIs

    async with StockAPIs(token="your-jwt-token") as api:
        # Downloads
        request = await api.downloads.create(
            symbol="BTCUSDT",
            exchange="binance",
            data_type="trades",
            from_date="2024-01-01",
            to_date="2024-01-31",
        )

        # Wait for completion
        request = await api.downloads.wait_for_completion(request.id)

        # Exports
        job = await api.exports.create(
            symbol="BTCUSDT",
            exchange="binance",
            data_type="trades",
            from_date="2024-01-01",
            to_date="2024-01-31",
            file_format="parquet",
        )

        # Download as DataFrame
        df = await api.exports.download_to_dataframe(job.id)
"""

from .client import AsyncStockAPIs, StockAPIs
from .generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
    AvailabilityGridResponse,
    AvailabilityHeatmapResponse,
    DataAvailabilityResponse,
    DownloadRequest,
    DownloadSegment,
    PaginatedDownloadRequestList,
    SymbolsWithDataResponse,
)
from .generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
    ExportJob,
    PaginatedExportJobList,
)
from .models import OHLCV, Trade
from .services import DownloadsService, ExportsService
from .sync_client import StockAPIsSync
from .types import (
    TERMINAL_DOWNLOAD_STATUSES,
    TERMINAL_EXPORT_STATUSES,
    AvailabilityStatus,
    Compression,
    DataType,
    DownloadStatus,
    Exchange,
    ExportJobStatus,
    FileFormat,
    Granularity,
    KlineInterval,
    MarketType,
    SymbolStatus,
)

__all__ = [
    # Main client
    "StockAPIs",
    "StockAPIsSync",
    "AsyncStockAPIs",
    # Services
    "DownloadsService",
    "ExportsService",
    # Type aliases
    "Exchange",
    "MarketType",
    "DataType",
    "Granularity",
    "KlineInterval",
    "FileFormat",
    "Compression",
    # Status enums
    "DownloadStatus",
    "ExportJobStatus",
    "AvailabilityStatus",
    "SymbolStatus",
    # Constants
    "TERMINAL_DOWNLOAD_STATUSES",
    "TERMINAL_EXPORT_STATUSES",
    # Download models
    "DownloadRequest",
    "DownloadSegment",
    "DataAvailabilityResponse",
    "AvailabilityGridResponse",
    "AvailabilityHeatmapResponse",
    "SymbolsWithDataResponse",
    "PaginatedDownloadRequestList",
    # Export models
    "ExportJob",
    "PaginatedExportJobList",
    # Typed data models
    "OHLCV",
    "Trade",
]
