"""Disk cache for OHLCV and trade data.

Caches exported data to avoid redundant API calls and downloads.
Historical data doesn't change, so long TTLs are safe.
"""

from __future__ import annotations

import hashlib
import logging
import pickle
import shutil
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .models import OHLCV, Trade

logger = logging.getLogger(__name__)


@dataclass
class CacheConfig:
    """Cache configuration."""

    enabled: bool = True
    cache_dir: Path | None = None  # None = use default (~/.stockapis/cache)
    ttl_days: int = 30  # How long to keep cached data
    max_size_gb: float = 10.0  # Maximum cache size in GB

    @property
    def resolved_cache_dir(self) -> Path:
        """Get the actual cache directory."""
        if self.cache_dir:
            return self.cache_dir
        return Path.home() / ".stockapis" / "cache"


class DiskCache:
    """Simple disk cache for OHLCV and Trade data."""

    def __init__(self, config: CacheConfig | None = None):
        self.config = config or CacheConfig()
        self._cache_dir = self.config.resolved_cache_dir
        self._ohlcv_dir = self._cache_dir / "ohlcv"
        self._trades_dir = self._cache_dir / "trades"
        self._metadata_file = self._cache_dir / "metadata.json"

        if self.config.enabled:
            self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        """Create cache directories if they don't exist."""
        self._ohlcv_dir.mkdir(parents=True, exist_ok=True)
        self._trades_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _make_cache_key(
        symbol: str,
        exchange: str,
        from_date: str | date,
        to_date: str | date,
        interval: str | None = None,
    ) -> str:
        """Generate a unique cache key."""
        from_str = from_date if isinstance(from_date, str) else from_date.isoformat()
        to_str = to_date if isinstance(to_date, str) else to_date.isoformat()

        key_parts = [
            symbol.upper(),
            exchange.lower(),
            from_str,
            to_str,
        ]
        if interval:
            key_parts.append(interval)

        key_string = "_".join(key_parts)
        # Use hash for filesystem-safe filename
        key_hash = hashlib.md5(key_string.encode()).hexdigest()[:16]
        return f"{symbol.lower()}_{exchange.lower()}_{key_hash}"

    def _get_ohlcv_path(self, cache_key: str) -> Path:
        """Get path for OHLCV cache file."""
        return self._ohlcv_dir / f"{cache_key}.pkl"

    def _get_trades_path(self, cache_key: str) -> Path:
        """Get path for trades cache file."""
        return self._trades_dir / f"{cache_key}.pkl"

    def _is_expired(self, file_path: Path) -> bool:
        """Check if cache file is expired."""
        if not file_path.exists():
            return True
        mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
        age = datetime.now() - mtime
        return age > timedelta(days=self.config.ttl_days)

    def get_ohlcv(
        self,
        symbol: str,
        exchange: str,
        from_date: str | date,
        to_date: str | date,
        interval: str,
    ) -> OHLCV | None:
        """Get cached OHLCV data if available and not expired."""
        if not self.config.enabled:
            return None

        cache_key = self._make_cache_key(symbol, exchange, from_date, to_date, interval)
        cache_path = self._get_ohlcv_path(cache_key)

        if not cache_path.exists():
            logger.debug(f"Cache miss: {cache_key}")
            return None

        if self._is_expired(cache_path):
            logger.debug(f"Cache expired: {cache_key}")
            cache_path.unlink(missing_ok=True)
            return None

        try:
            with open(cache_path, "rb") as f:
                data = pickle.load(f)
            logger.info(f"Cache hit: {cache_key}")
            return data
        except Exception as e:
            logger.warning(f"Cache read error: {e}")
            cache_path.unlink(missing_ok=True)
            return None

    def set_ohlcv(
        self,
        ohlcv: OHLCV,
        from_date: str | date,
        to_date: str | date,
    ) -> None:
        """Cache OHLCV data."""
        if not self.config.enabled:
            return

        cache_key = self._make_cache_key(
            ohlcv.symbol,
            ohlcv.exchange,
            from_date,
            to_date,
            ohlcv.interval,
        )
        cache_path = self._get_ohlcv_path(cache_key)

        try:
            with open(cache_path, "wb") as f:
                pickle.dump(ohlcv, f)
            logger.debug(f"Cached: {cache_key}")
        except Exception as e:
            logger.warning(f"Cache write error: {e}")

    def get_trades(
        self,
        symbol: str,
        exchange: str,
        from_date: str | date,
        to_date: str | date,
    ) -> Trade | None:
        """Get cached trade data if available and not expired."""
        if not self.config.enabled:
            return None

        cache_key = self._make_cache_key(symbol, exchange, from_date, to_date)
        cache_path = self._get_trades_path(cache_key)

        if not cache_path.exists():
            return None

        if self._is_expired(cache_path):
            cache_path.unlink(missing_ok=True)
            return None

        try:
            with open(cache_path, "rb") as f:
                return pickle.load(f)
        except Exception:
            cache_path.unlink(missing_ok=True)
            return None

    def set_trades(
        self,
        trades: Trade,
        from_date: str | date,
        to_date: str | date,
    ) -> None:
        """Cache trade data."""
        if not self.config.enabled:
            return

        cache_key = self._make_cache_key(
            trades.symbol,
            trades.exchange,
            from_date,
            to_date,
        )
        cache_path = self._get_trades_path(cache_key)

        try:
            with open(cache_path, "wb") as f:
                pickle.dump(trades, f)
        except Exception as e:
            logger.warning(f"Cache write error: {e}")

    def clear(self) -> None:
        """Clear all cached data."""
        if self._cache_dir.exists():
            shutil.rmtree(self._cache_dir)
            self._ensure_dirs()
            logger.info("Cache cleared")

    def prune_expired(self) -> int:
        """Remove expired cache entries. Returns number of files removed."""
        if not self.config.enabled:
            return 0

        removed = 0
        for cache_dir in [self._ohlcv_dir, self._trades_dir]:
            if not cache_dir.exists():
                continue
            for file_path in cache_dir.glob("*.pkl"):
                if self._is_expired(file_path):
                    file_path.unlink()
                    removed += 1

        if removed > 0:
            logger.info(f"Pruned {removed} expired cache entries")
        return removed

    def get_stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        ohlcv_count = len(list(self._ohlcv_dir.glob("*.pkl"))) if self._ohlcv_dir.exists() else 0
        trades_count = len(list(self._trades_dir.glob("*.pkl"))) if self._trades_dir.exists() else 0

        total_size = 0
        for cache_dir in [self._ohlcv_dir, self._trades_dir]:
            if cache_dir.exists():
                for f in cache_dir.glob("*.pkl"):
                    total_size += f.stat().st_size

        return {
            "enabled": self.config.enabled,
            "cache_dir": str(self._cache_dir),
            "ohlcv_entries": ohlcv_count,
            "trades_entries": trades_count,
            "total_entries": ohlcv_count + trades_count,
            "total_size_mb": total_size / (1024 * 1024),
            "ttl_days": self.config.ttl_days,
        }


# Global cache instance (initialized lazily)
_cache: DiskCache | None = None


def get_cache(config: CacheConfig | None = None) -> DiskCache:
    """Get or create the global cache instance."""
    global _cache
    if _cache is None:
        _cache = DiskCache(config)
    return _cache


def configure_cache(
    enabled: bool = True,
    cache_dir: str | Path | None = None,
    ttl_days: int = 30,
    max_size_gb: float = 10.0,
) -> DiskCache:
    """Configure the global cache.

    Call this before using the SDK to customize caching behavior.

    Args:
        enabled: Whether caching is enabled
        cache_dir: Custom cache directory (default: ~/.stockapis/cache)
        ttl_days: Days to keep cached data (default: 30)
        max_size_gb: Maximum cache size in GB (default: 10)

    Returns:
        The configured cache instance

    Example:
        from stockapis import configure_cache

        # Disable caching
        configure_cache(enabled=False)

        # Custom cache directory
        configure_cache(cache_dir="/tmp/stockapis_cache")

        # Short TTL for testing
        configure_cache(ttl_days=1)
    """
    global _cache
    config = CacheConfig(
        enabled=enabled,
        cache_dir=Path(cache_dir) if cache_dir else None,
        ttl_days=ttl_days,
        max_size_gb=max_size_gb,
    )
    _cache = DiskCache(config)
    return _cache
