"""
Typed data models for StockAPIs.

Provides structured, typed access to market data.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    import polars as pl


@dataclass
class OHLCV:
    """
    OHLCV (candlestick) data with typed arrays.

    All arrays have the same length and are aligned by index.

    Attributes:
        timestamp: Unix timestamps in milliseconds
        datetime: Python datetime objects (UTC)
        open: Opening prices
        high: High prices
        low: Low prices
        close: Closing prices
        volume: Trading volumes

    Example:
        ohlcv = await api.exports.export_to_ohlcv(...)
        print(f"Latest close: {ohlcv.close[-1]}")
        print(f"Latest time: {ohlcv.datetime[-1]}")
    """

    timestamp: NDArray[np.int64]
    datetime: list[datetime]
    open: NDArray[np.float64]
    high: NDArray[np.float64]
    low: NDArray[np.float64]
    close: NDArray[np.float64]
    volume: NDArray[np.float64]

    # Metadata
    symbol: str
    exchange: str
    interval: str

    def __len__(self) -> int:
        return len(self.close)

    def __repr__(self) -> str:
        if len(self) == 0:
            return f"OHLCV({self.symbol}, {self.exchange}, {self.interval}, empty)"
        return (
            f"OHLCV({self.symbol}, {self.exchange}, {self.interval}, "
            f"n={len(self)}, "
            f"from={self.datetime[0].isoformat()}, "
            f"to={self.datetime[-1].isoformat()})"
        )

    @property
    def returns(self) -> NDArray[np.float64]:
        """Compute log returns from close prices."""
        return np.diff(np.log(self.close))

    @property
    def volatility(self) -> float:
        """Compute annualized volatility from returns."""
        if len(self) < 2:
            return 0.0
        returns = self.returns
        # Estimate observations per day from interval
        obs_per_day = _interval_to_obs_per_day(self.interval)
        return float(np.std(returns) * np.sqrt(252 * obs_per_day))

    @classmethod
    def from_dataframe(
        cls,
        df: pl.DataFrame,
        symbol: str,
        exchange: str,
        interval: str,
    ) -> OHLCV:
        """
        Create OHLCV from polars DataFrame.

        Automatically detects column names and parses timestamps.
        """
        # Detect column names (case-insensitive)
        cols = {c.lower(): c for c in df.columns}

        # Required columns
        close_col = cols.get("close")
        if close_col is None:
            raise ValueError(f"Missing 'close' column. Available: {df.columns}")

        # Optional columns with fallbacks
        open_col = cols.get("open", close_col)
        high_col = cols.get("high", close_col)
        low_col = cols.get("low", close_col)
        volume_col = cols.get("volume", cols.get("vol"))

        # Timestamp column
        time_col = None
        for name in ["open_time", "opentime", "timestamp", "time", "date"]:
            if name in cols:
                time_col = cols[name]
                break

        # Extract arrays
        close = df[close_col].to_numpy().astype(np.float64)
        open_ = df[open_col].to_numpy().astype(np.float64)
        high = df[high_col].to_numpy().astype(np.float64)
        low = df[low_col].to_numpy().astype(np.float64)

        if volume_col:
            volume = df[volume_col].to_numpy().astype(np.float64)
        else:
            volume = np.zeros(len(close), dtype=np.float64)

        # Parse timestamps
        if time_col:
            raw_time = df[time_col].to_list()
            timestamp, datetimes = _parse_timestamps(raw_time)
        else:
            # Generate synthetic timestamps
            n = len(close)
            now = datetime.now()
            interval_seconds = _interval_to_seconds(interval)
            timestamp = np.array(
                [int((now.timestamp() - (n - i) * interval_seconds) * 1000) for i in range(n)],
                dtype=np.int64,
            )
            datetimes = [datetime.fromtimestamp(ts / 1000) for ts in timestamp]

        return cls(
            timestamp=timestamp,
            datetime=datetimes,
            open=open_,
            high=high,
            low=low,
            close=close,
            volume=volume,
            symbol=symbol,
            exchange=exchange,
            interval=interval,
        )


@dataclass
class Trade:
    """
    Trade data with typed arrays.

    Attributes:
        timestamp: Unix timestamps in milliseconds
        datetime: Python datetime objects (UTC)
        price: Trade prices
        quantity: Trade quantities
        is_buyer_maker: True if buyer was maker
    """

    timestamp: NDArray[np.int64]
    datetime: list[datetime]
    price: NDArray[np.float64]
    quantity: NDArray[np.float64]
    is_buyer_maker: NDArray[np.bool_]

    # Metadata
    symbol: str
    exchange: str

    def __len__(self) -> int:
        return len(self.price)

    def __repr__(self) -> str:
        if len(self) == 0:
            return f"Trade({self.symbol}, {self.exchange}, empty)"
        return (
            f"Trade({self.symbol}, {self.exchange}, "
            f"n={len(self)}, "
            f"from={self.datetime[0].isoformat()}, "
            f"to={self.datetime[-1].isoformat()})"
        )

    @classmethod
    def from_dataframe(
        cls,
        df: pl.DataFrame,
        symbol: str,
        exchange: str,
    ) -> Trade:
        """Create Trade from polars DataFrame."""
        cols = {c.lower(): c for c in df.columns}

        price_col = cols.get("price")
        qty_col = cols.get("quantity", cols.get("qty", cols.get("amount")))

        if price_col is None:
            raise ValueError(f"Missing 'price' column. Available: {df.columns}")
        if qty_col is None:
            raise ValueError(f"Missing 'quantity' column. Available: {df.columns}")

        price = df[price_col].to_numpy().astype(np.float64)
        quantity = df[qty_col].to_numpy().astype(np.float64)

        # Timestamp
        time_col = None
        for name in ["timestamp", "time", "trade_time", "tradetime"]:
            if name in cols:
                time_col = cols[name]
                break

        if time_col:
            raw_time = df[time_col].to_list()
            timestamp, datetimes = _parse_timestamps(raw_time)
        else:
            timestamp = np.zeros(len(price), dtype=np.int64)
            datetimes = [datetime.now()] * len(price)

        # is_buyer_maker
        maker_col = cols.get("is_buyer_maker", cols.get("isbuyermaker", cols.get("side")))
        if maker_col:
            raw = df[maker_col].to_list()
            if isinstance(raw[0], bool):
                is_buyer_maker = np.array(raw, dtype=np.bool_)
            else:
                # Assume "buy"/"sell" or similar
                is_buyer_maker = np.array([str(v).lower() in ("true", "1", "buy") for v in raw], dtype=np.bool_)
        else:
            is_buyer_maker = np.zeros(len(price), dtype=np.bool_)

        return cls(
            timestamp=timestamp,
            datetime=datetimes,
            price=price,
            quantity=quantity,
            is_buyer_maker=is_buyer_maker,
            symbol=symbol,
            exchange=exchange,
        )


def _parse_timestamps(raw: list) -> tuple[NDArray[np.int64], list[datetime]]:
    """Parse timestamps from various formats."""
    if len(raw) == 0:
        return np.array([], dtype=np.int64), []

    sample = raw[0]

    # Already integer (milliseconds)
    if isinstance(sample, int):
        timestamp = np.array(raw, dtype=np.int64)
        datetimes = [datetime.fromtimestamp(ts / 1000) for ts in timestamp]
        return timestamp, datetimes

    # Float (seconds or milliseconds)
    if isinstance(sample, float):
        arr = np.array(raw, dtype=np.float64)
        # If values are small, assume seconds
        if arr[0] < 1e12:
            timestamp = (arr * 1000).astype(np.int64)
        else:
            timestamp = arr.astype(np.int64)
        datetimes = [datetime.fromtimestamp(ts / 1000) for ts in timestamp]
        return timestamp, datetimes

    # String (ISO format or similar)
    if isinstance(sample, str):
        datetimes = []
        for s in raw:
            try:
                # Try ISO format first
                dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            except ValueError:
                # Try parsing as timestamp
                try:
                    dt = datetime.fromtimestamp(float(s) / 1000)
                except ValueError:
                    dt = datetime.now()
            datetimes.append(dt)
        timestamp = np.array([int(dt.timestamp() * 1000) for dt in datetimes], dtype=np.int64)
        return timestamp, datetimes

    # datetime object
    if isinstance(sample, datetime):
        datetimes = list(raw)
        timestamp = np.array([int(dt.timestamp() * 1000) for dt in datetimes], dtype=np.int64)
        return timestamp, datetimes

    # Unknown format, try conversion
    timestamp = np.array([int(x) for x in raw], dtype=np.int64)
    datetimes = [datetime.fromtimestamp(ts / 1000) for ts in timestamp]
    return timestamp, datetimes


def _interval_to_seconds(interval: str) -> int:
    """Convert interval string to seconds."""
    multipliers = {
        "m": 60,
        "h": 3600,
        "d": 86400,
        "w": 604800,
        "M": 2592000,
    }
    unit = interval[-1]
    value = int(interval[:-1])
    return value * multipliers.get(unit, 60)


def _interval_to_obs_per_day(interval: str) -> float:
    """Convert interval to observations per day."""
    seconds = _interval_to_seconds(interval)
    return 86400 / seconds


__all__ = [
    "OHLCV",
    "Trade",
]
