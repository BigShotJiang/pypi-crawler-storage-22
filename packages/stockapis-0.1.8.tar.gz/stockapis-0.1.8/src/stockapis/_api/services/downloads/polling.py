"""Polling operations for downloads service."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from ...polling import poll_with_progress, wait_for_terminal_status
from ...types import TERMINAL_REQUEST_STATUSES
from ._base import DownloadsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__cryptodb_downloads.models import (
        DownloadRequest,
    )


# Terminal status values as strings for polling utilities
_TERMINAL_REQUEST_STATUS_VALUES = {s.value for s in TERMINAL_REQUEST_STATUSES}


class DownloadsPollingMixin(DownloadsBase):
    """Polling operations for download requests."""

    async def get_status(self, request_id: int) -> DownloadRequest:
        """Get download request status (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with DownloadsCRUDMixin")

    async def wait_for_completion(
        self,
        request_id: int,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> DownloadRequest:
        """
        Wait for download request to complete.

        Args:
            request_id: Download request ID
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds (None for no timeout)

        Returns:
            Completed DownloadRequest

        Raises:
            TimeoutError: If timeout exceeded
        """
        return await wait_for_terminal_status(
            get_item=self.get_status,
            item_id=request_id,
            get_status=lambda r: r.status,
            terminal_statuses=_TERMINAL_REQUEST_STATUS_VALUES,
            poll_interval=poll_interval,
            timeout=timeout,
            item_name="download request",
        )

    async def poll_progress(
        self,
        request_id: int,
        poll_interval: float = 2.0,
        timeout: float | None = None,
    ) -> AsyncIterator[DownloadRequest]:
        """
        Poll download progress, yielding updates.

        Args:
            request_id: Download request ID
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds

        Yields:
            DownloadRequest on each poll

        Example:
            async for request in downloads.poll_progress(123):
                print(f"Progress: {request.progress_percent}%")
                if DownloadStatus(request.status) == DownloadStatus.COMPLETED:
                    break
        """
        async for item in poll_with_progress(
            get_item=self.get_status,
            item_id=request_id,
            get_status=lambda r: r.status,
            terminal_statuses=_TERMINAL_REQUEST_STATUS_VALUES,
            poll_interval=poll_interval,
            timeout=timeout,
        ):
            yield item
