"""CRUD operations for exports service."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING

import httpx

from ...types import (
    Compression,
    DataType,
    Exchange,
    FileFormat,
    KlineInterval,
    MarketType,
)
from ._base import ExportsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
        ExportJob,
        PaginatedExportJobList,
    )


class ExportsCRUDMixin(ExportsBase):
    """CRUD operations for export jobs."""

    async def create(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        *,
        symbol_id: int | None = None,
    ) -> ExportJob:
        """
        Create an export job.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            data_type: Type of data to export
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            market_type: Market type (default: spot)
            interval: Kline interval (required for klines)
            file_format: Output format (default: csv)
            compression: Compression type (default: none)
            symbol_id: Direct symbol ID (alternative to symbol lookup)

        Returns:
            Created ExportJob

        Raises:
            httpx.HTTPStatusError: If request fails
            ValueError: If klines requested without interval
        """
        from ...generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
            ExportJobCreateRequest,
        )

        if data_type == DataType.KLINES and interval is None:
            raise ValueError("interval is required for klines data type")

        # Convert dates
        if isinstance(from_date, date):
            from_date = from_date.isoformat()
        if isinstance(to_date, date):
            to_date = to_date.isoformat()

        request = ExportJobCreateRequest(
            symbol_id=symbol_id,
            symbol=symbol if symbol_id is None else None,
            exchange=exchange if symbol_id is None else None,  # type: ignore
            market_type=market_type if symbol_id is None else None,  # type: ignore
            data_type=data_type,  # type: ignore
            from_date=from_date,  # type: ignore
            to_date=to_date,  # type: ignore
            interval=interval,
            file_format=file_format,  # type: ignore
            compression=compression,  # type: ignore
        )

        return await self._client.cryptodb_driver_exports_create(data=request)

    async def create_with_download(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        *,
        symbol_id: int | None = None,
    ) -> ExportJob:
        """
        Create export with auto-download of missing data.

        If data is not available, automatically triggers downloads
        and waits for them to complete.

        Args:
            symbol: Trading pair symbol
            exchange: Exchange name
            data_type: Type of data
            from_date: Start date
            to_date: End date
            market_type: Market type
            interval: Kline interval (for klines)
            file_format: Output format
            compression: Compression type
            symbol_id: Direct symbol ID

        Returns:
            ExportJob (may have status WAITING_FOR_DATA if downloads triggered)
        """
        from ...generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
            ExportJob,
            ExportJobCreateRequest,
        )

        if data_type == DataType.KLINES and interval is None:
            raise ValueError("interval is required for klines data type")

        # Convert dates
        if isinstance(from_date, date):
            from_date = from_date.isoformat()
        if isinstance(to_date, date):
            to_date = to_date.isoformat()

        # Build request - only include symbol_id if provided
        if symbol_id is not None:
            request = ExportJobCreateRequest(
                symbol_id=symbol_id,
                data_type=data_type,  # type: ignore
                from_date=from_date,  # type: ignore
                to_date=to_date,  # type: ignore
                interval=interval,
                file_format=file_format,  # type: ignore
                compression=compression,  # type: ignore
            )
        else:
            request = ExportJobCreateRequest(
                symbol=symbol,
                exchange=exchange,  # type: ignore
                market_type=market_type,  # type: ignore
                data_type=data_type,  # type: ignore
                from_date=from_date,  # type: ignore
                to_date=to_date,  # type: ignore
                interval=interval,
                file_format=file_format,  # type: ignore
                compression=compression,  # type: ignore
            )

        # Call endpoint manually since generated client doesn't accept body
        url = "/api/cryptodb_driver/exports/create-with-download/"
        response = await self._api._client._client.post(
            url, json=request.model_dump(mode="json", exclude_unset=True, exclude_none=True)
        )
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )

        data = response.json()
        # Response can be either ExportJob directly (201) or wrapped with metadata (202)
        if "export_job" in data:
            return ExportJob.model_validate(data["export_job"])
        return ExportJob.model_validate(data)

    async def get(self, job_id: int) -> ExportJob:
        """
        Get export job by ID.

        Args:
            job_id: Export job ID

        Returns:
            ExportJob with full details
        """
        return await self._client.cryptodb_driver_exports_retrieve(id=job_id)

    async def list(
        self,
        page: int = 1,
        page_size: int = 20,
        ordering: str | None = None,
        search: str | None = None,
    ) -> PaginatedExportJobList:
        """
        List export jobs.

        Args:
            page: Page number (1-based)
            page_size: Items per page
            ordering: Sort order (e.g., "-created_at")
            search: Search term

        Returns:
            Paginated list of export jobs
        """
        return await self._client.cryptodb_driver_exports_list(
            page=page,
            page_size=page_size,
            ordering=ordering,
            search=search,
        )

    async def cancel(self, job_id: int) -> None:
        """
        Cancel a pending export job.

        Args:
            job_id: Export job ID
        """
        await self._client.cryptodb_driver_exports_cancel_create(id=job_id)
