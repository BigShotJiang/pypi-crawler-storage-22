"""High-level convenience methods for exports service."""

from __future__ import annotations

import tempfile
import warnings
from collections.abc import Callable
from datetime import date
from pathlib import Path
from typing import TYPE_CHECKING

from ...cache import get_cache
from ...models import OHLCV, Trade
from ...polling import wait_with_progress_callback
from ...types import (
    TERMINAL_EXPORT_STATUSES,
    Compression,
    DataType,
    Exchange,
    ExportJobStatus,
    FileFormat,
    KlineInterval,
    MarketType,
)
from ._base import ExportsBase

if TYPE_CHECKING:
    from ...generated.cryptodb_driver.cryptodb_driver__api__data_exports.models import (
        ExportJob,
    )

# Check for polars availability at module level
try:
    import polars as pl
    HAS_POLARS = True
except ImportError:
    pl = None  # type: ignore
    HAS_POLARS = False


# Terminal status values as strings for polling utilities
_TERMINAL_EXPORT_STATUS_VALUES = {s.value for s in TERMINAL_EXPORT_STATUSES}


class ExportsHighLevelMixin(ExportsBase):
    """High-level convenience methods for exports."""

    async def create(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        *,
        symbol_id: int | None = None,
    ) -> ExportJob:
        """Create export job (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with ExportsCRUDMixin")

    async def create_with_download(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        *,
        symbol_id: int | None = None,
    ) -> ExportJob:
        """Create export with auto-download (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with ExportsCRUDMixin")

    async def get(self, job_id: int) -> ExportJob:
        """Get export job by ID (implemented in CRUD mixin)."""
        raise NotImplementedError("Must be mixed with ExportsCRUDMixin")

    async def download_file(
        self,
        job_id: int,
        output_path: str | Path | None = None,
    ) -> Path:
        """Download exported file (implemented in download mixin)."""
        raise NotImplementedError("Must be mixed with ExportsDownloadMixin")

    async def export_to_file(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        output_path: str | Path,
        *,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        file_format: FileFormat = FileFormat.CSV,
        compression: Compression = Compression.NONE,
        auto_download: bool = False,
        poll_interval: float = 2.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> Path:
        """
        Export data to file in one call.

        Creates export job, waits for completion, and downloads the file.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            data_type: Type of data to export ("klines" or "trades")
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            output_path: Destination file path
            market_type: Market type (default: spot)
            interval: Kline interval (required for klines)
            file_format: Output format (default: csv)
            compression: Compression type (default: none)
            auto_download: If True, auto-download missing data from exchange
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds (None for no timeout)
            on_progress: Callback function called with progress percentage

        Returns:
            Path to downloaded file

        Raises:
            ValueError: If export fails or times out
            TimeoutError: If timeout exceeded

        Example:
            path = await api.exports.export_to_file(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                data_type=DataType.KLINES,
                from_date="2025-01-01",
                to_date="2025-01-07",
                interval="1m",
                output_path="btcusdt_klines.csv",
                on_progress=lambda p: print(f"Progress: {p}%"),
            )
        """
        # Create job
        if auto_download:
            job = await self.create_with_download(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                interval=interval,
                file_format=file_format,
                compression=compression,
            )
        else:
            job = await self.create(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                interval=interval,
                file_format=file_format,
                compression=compression,
            )

        # Wait for completion with progress callback
        completed_job = await self._wait_for_export_completion(
            job.id,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

        # Download file
        return await self.download_file(completed_job.id, output_path)

    async def export_to_dataframe(
        self,
        symbol: str,
        exchange: Exchange,
        data_type: DataType,
        from_date: str | date,
        to_date: str | date,
        *,
        market_type: MarketType = MarketType.SPOT,
        interval: KlineInterval | None = None,
        auto_download: bool = False,
        poll_interval: float = 2.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ):
        """
        Export data directly to DataFrame in one call.

        Creates export job, waits for completion, downloads and loads as DataFrame.
        Uses CSV format internally for best compatibility.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            data_type: Type of data to export ("klines" or "trades")
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            market_type: Market type (default: spot)
            interval: Kline interval (required for klines)
            auto_download: If True, auto-download missing data from exchange
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds (None for no timeout)
            on_progress: Callback function called with progress percentage

        Returns:
            polars.DataFrame with exported data

        Raises:
            ImportError: If polars not installed
            ValueError: If export fails
            TimeoutError: If timeout exceeded

        Example:
            df = await api.exports.export_to_dataframe(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                data_type=DataType.KLINES,
                from_date="2025-01-01",
                to_date="2025-01-07",
                interval="1m",
            )
            print(f"Loaded {len(df)} rows")
        """
        if not HAS_POLARS:
            raise ImportError(
                "polars is required for export_to_dataframe(). "
                "Install with: pip install polars"
            )

        # Create job (use csv for best compatibility)
        if auto_download:
            job = await self.create_with_download(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                interval=interval,
                file_format=FileFormat.CSV,
                compression=Compression.GZIP,  # Faster download
            )
        else:
            job = await self.create(
                symbol=symbol,
                exchange=exchange,
                data_type=data_type,
                from_date=from_date,
                to_date=to_date,
                market_type=market_type,
                interval=interval,
                file_format=FileFormat.CSV,
                compression=Compression.GZIP,
            )

        # Wait for completion
        completed_job = await self._wait_for_export_completion(
            job.id,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

        # Download to temp file and load
        with tempfile.NamedTemporaryFile(suffix=".csv.gz", delete=False) as tmp:
            tmp_path = Path(tmp.name)

        try:
            await self.download_file(completed_job.id, tmp_path)
            df = pl.read_csv(tmp_path)

            if len(df) == 0:
                warnings.warn(
                    f"Export returned 0 rows. "
                    f"Data for interval '{interval}' may not be available. "
                    f"Available intervals are typically: 1m, 1d. "
                    f"Use auto_download=True to fetch missing data first.",
                    UserWarning,
                    stacklevel=2,
                )

            return df
        finally:
            tmp_path.unlink(missing_ok=True)

    async def export_to_ohlcv(
        self,
        symbol: str,
        exchange: Exchange,
        from_date: str | date,
        to_date: str | date,
        interval: KlineInterval = "1h",
        *,
        market_type: MarketType = MarketType.SPOT,
        auto_download: bool = False,
        poll_interval: float = 2.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
        use_cache: bool = True,
    ) -> OHLCV:
        """
        Export kline data as typed OHLCV object.

        Returns a structured OHLCV object with numpy arrays for efficient
        numerical operations and datetime objects for time handling.

        Uses disk caching by default - historical data is cached locally
        to avoid redundant API calls and downloads.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            interval: Kline interval (default: "1h")
            market_type: Market type (default: spot)
            auto_download: If True, auto-download missing data from exchange
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds (None for no timeout)
            on_progress: Callback function called with progress percentage
            use_cache: If True, use disk cache (default: True)

        Returns:
            OHLCV object with typed arrays

        Raises:
            ImportError: If polars not installed
            ValueError: If export fails

        Example:
            ohlcv = await api.exports.export_to_ohlcv(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                from_date="2025-01-01",
                to_date="2025-01-07",
                interval="1h",
            )
            print(f"Latest close: {ohlcv.close[-1]}")
            print(f"Volatility: {ohlcv.volatility:.2%}")
        """
        exchange_str = exchange.value if hasattr(exchange, "value") else str(exchange)

        # Try cache first
        if use_cache:
            cache = get_cache()
            cached = cache.get_ohlcv(symbol, exchange_str, from_date, to_date, interval)
            if cached is not None:
                return cached

        # Fetch from API
        df = await self.export_to_dataframe(
            symbol=symbol,
            exchange=exchange,
            data_type=DataType.KLINES,
            from_date=from_date,
            to_date=to_date,
            market_type=market_type,
            interval=interval,
            auto_download=auto_download,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

        ohlcv = OHLCV.from_dataframe(
            df,
            symbol=symbol,
            exchange=exchange_str,
            interval=interval,
        )

        # Cache the result
        if use_cache:
            cache = get_cache()
            cache.set_ohlcv(ohlcv, from_date, to_date)

        return ohlcv

    async def export_to_trades(
        self,
        symbol: str,
        exchange: Exchange,
        from_date: str | date,
        to_date: str | date,
        *,
        market_type: MarketType = MarketType.SPOT,
        auto_download: bool = False,
        poll_interval: float = 2.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
        use_cache: bool = True,
    ) -> Trade:
        """
        Export trade data as typed Trade object.

        Returns a structured Trade object with numpy arrays.
        Uses disk caching by default.

        Args:
            symbol: Trading pair symbol (e.g., "BTCUSDT")
            exchange: Exchange name
            from_date: Start date (inclusive)
            to_date: End date (inclusive)
            market_type: Market type (default: spot)
            auto_download: If True, auto-download missing data from exchange
            poll_interval: Seconds between status checks
            timeout: Maximum wait time in seconds (None for no timeout)
            on_progress: Callback function called with progress percentage
            use_cache: If True, use disk cache (default: True)

        Returns:
            Trade object with typed arrays

        Example:
            trades = await api.exports.export_to_trades(
                symbol="BTCUSDT",
                exchange=Exchange.BINANCE,
                from_date="2025-01-01",
                to_date="2025-01-02",
            )
            print(f"Total trades: {len(trades)}")
        """
        exchange_str = exchange.value if hasattr(exchange, "value") else str(exchange)

        # Try cache first
        if use_cache:
            cache = get_cache()
            cached = cache.get_trades(symbol, exchange_str, from_date, to_date)
            if cached is not None:
                return cached

        # Fetch from API
        df = await self.export_to_dataframe(
            symbol=symbol,
            exchange=exchange,
            data_type=DataType.TRADES,
            from_date=from_date,
            to_date=to_date,
            market_type=market_type,
            auto_download=auto_download,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

        trades = Trade.from_dataframe(
            df,
            symbol=symbol,
            exchange=exchange_str,
        )

        # Cache the result
        if use_cache:
            cache = get_cache()
            cache.set_trades(trades, from_date, to_date)

        return trades

    async def _wait_for_export_completion(
        self,
        job_id: int,
        poll_interval: float = 2.0,
        timeout: float | None = None,
        on_progress: Callable[[int], None] | None = None,
    ) -> ExportJob:
        """
        Wait for export completion with progress callback.

        Handles FAILED status specially by raising ValueError.
        """
        job = await wait_with_progress_callback(
            get_item=self.get,
            item_id=job_id,
            get_status=lambda j: j.status,
            terminal_statuses=_TERMINAL_EXPORT_STATUS_VALUES,
            on_progress=on_progress,
            poll_interval=poll_interval,
            timeout=timeout,
            item_name="export",
        )

        # Check for failure
        status = ExportJobStatus(job.status)
        if status == ExportJobStatus.FAILED:
            raise ValueError(f"Export failed: {job.error_message}")
        elif status != ExportJobStatus.COMPLETED:
            raise ValueError(f"Export ended with status: {status.value}")

        return job
