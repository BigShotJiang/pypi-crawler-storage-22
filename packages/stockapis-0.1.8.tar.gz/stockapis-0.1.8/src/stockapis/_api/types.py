"""
Type definitions for StockSDK.

Re-exports enums and types from generated clients with cleaner names.
"""

from __future__ import annotations

from typing import Literal

from .generated.cryptodb_driver.enums import (
    AvailabilityGridRequestRequestDataType as DataType,
)
from .generated.cryptodb_driver.enums import (
    AvailabilityGridRequestRequestExchange as Exchange,
)
from .generated.cryptodb_driver.enums import (
    AvailabilityGridRequestRequestMarketType as MarketType,
)
from .generated.cryptodb_driver.enums import (
    DownloadRequestGranularity as Granularity,
)
from .generated.cryptodb_driver.enums import (
    DownloadRequestStatus,
    DownloadSegmentStatus,
    ExportJobStatus,
)
from .generated.cryptodb_driver.enums import (
    ExportJobCompression as Compression,
)
from .generated.cryptodb_driver.enums import (
    ExportJobFileFormat as FileFormat,
)
from .generated.cryptodb_driver.enums import (
    HeatmapMonthCellStatus as AvailabilityStatus,
)
from .generated.cryptodb_driver.enums import (
    SymbolNestedStatus as SymbolStatus,
)

# Alias for backwards compatibility
DownloadStatus = DownloadSegmentStatus

# Kline intervals (not generated, define as Literal)
KlineInterval = Literal["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"]

# Terminal statuses (for polling)
# These are statuses where polling should stop - no more progress expected
TERMINAL_DOWNLOAD_STATUSES = {
    DownloadStatus.COMPLETED,
    DownloadStatus.FAILED,
    DownloadStatus.SKIPPED,
    DownloadStatus.CANCELLED,
    DownloadStatus.DEFERRED,  # Data not yet available from exchange
}

# Request-level terminal statuses (computed from segments)
TERMINAL_REQUEST_STATUSES = {
    DownloadRequestStatus.COMPLETED,
    DownloadRequestStatus.SKIPPED,
    DownloadRequestStatus.PARTIAL,   # Some segments completed, some deferred/failed
    DownloadRequestStatus.DEFERRED,  # All segments waiting for data
    DownloadRequestStatus.FAILED,
}

# Success statuses (data was at least partially downloaded)
SUCCESS_DOWNLOAD_STATUSES = {
    DownloadRequestStatus.COMPLETED,
    DownloadRequestStatus.SKIPPED,
    DownloadRequestStatus.PARTIAL,  # Partial success is still success
}

TERMINAL_EXPORT_STATUSES = {
    ExportJobStatus.COMPLETED,
    ExportJobStatus.FAILED,
    ExportJobStatus.EXPIRED,
    ExportJobStatus.CANCELLED,
}

__all__ = [
    # Enums
    "Exchange",
    "MarketType",
    "DataType",
    "Granularity",
    "DownloadStatus",
    "DownloadSegmentStatus",
    "DownloadRequestStatus",
    "ExportJobStatus",
    "FileFormat",
    "Compression",
    "AvailabilityStatus",
    "SymbolStatus",
    # Types
    "KlineInterval",
    # Constants
    "TERMINAL_DOWNLOAD_STATUSES",
    "TERMINAL_REQUEST_STATUSES",
    "SUCCESS_DOWNLOAD_STATUSES",
    "TERMINAL_EXPORT_STATUSES",
]
