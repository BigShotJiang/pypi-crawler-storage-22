"""StocksStrategy - Stock selection and backtesting CLI tool"""

from stocksstrategy.cli import cli

__all__ = ["cli"]
__version__ = "0.1.0"
