"""支持 python -m stocksstrategy 运行"""

from stocksstrategy.cli import cli

if __name__ == "__main__":
    cli()
