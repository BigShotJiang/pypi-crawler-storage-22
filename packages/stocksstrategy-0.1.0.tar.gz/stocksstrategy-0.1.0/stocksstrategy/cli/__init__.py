"""CLI - Command Line Interface"""

import click

from stocksstrategy.cli.commands import backtest, config, fetch
from stocksstrategy.cli.commands.list import list_stocks
from stocksstrategy.logging_config import setup_logging


@click.group()
def cli():
    """StocksStrategy - Stock selection and backtesting tool"""
    # Initialize logging when CLI starts
    setup_logging()


# Register commands
cli.add_command(fetch)
cli.add_command(backtest)
cli.add_command(list_stocks)
cli.add_command(config, name="config")


__all__ = ["cli", "fetch", "backtest", "list_stocks"]
