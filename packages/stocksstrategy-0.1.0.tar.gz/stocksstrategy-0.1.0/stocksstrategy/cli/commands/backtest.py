"""Backtest command implementation"""

import click

from stocksstrategy.logging_config import cli_info


@click.command()
@click.option(
    "--stock",
    required=True,
    help="Stock code, supports comma-separated multiple stocks",
)
@click.option("--strategy", required=True, help="Strategy name")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD)")
@click.option("--end", default=None, help="End date (YYYY-MM-DD), default is today")
@click.option("--capital", default=100000.0, help="Initial capital")
def backtest(stock: str, strategy: str, start: str, end: str | None, capital: float):
    """Run backtest"""
    cli_info("Backtest command is not yet implemented.")
    cli_info(f"  Stock: {stock}")
    cli_info(f"  Strategy: {strategy}")
    cli_info(f"  Start date: {start}")
    cli_info(f"  End date: {end or 'today'}")
    cli_info(f"  Initial capital: {capital}")
