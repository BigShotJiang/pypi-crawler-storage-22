"""Config command implementation"""

import os
from pathlib import Path

import click

from stocksstrategy.logging_config import cli_error, cli_info, cli_success


def _get_shell_config_file() -> Path:
    """Get the shell configuration file path."""
    home = Path.home()
    shell = os.environ.get("SHELL", "")

    if "zsh" in shell:
        return home / ".zshrc"
    elif "bash" in shell:
        return home / ".bashrc"
    else:
        # Default to .bashrc
        return home / ".bashrc"


def _get_token_from_env() -> str | None:
    """Get token from environment variable."""
    return os.environ.get("TUSHARE_TOKEN")


def _get_config_file_token() -> str | None:
    """Get token from shell config file."""
    config_file = _get_shell_config_file()
    if not config_file.exists():
        return None

    try:
        content = config_file.read_text()
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("export TUSHARE_TOKEN="):
                # Extract token value (may be quoted)
                token = line.split("=", 1)[1].strip()
                # Remove surrounding quotes if present
                if token.startswith('"') and token.endswith('"'):
                    token = token[1:-1]
                elif token.startswith("'") and token.endswith("'"):
                    token = token[1:-1]
                return token
    except Exception:
        pass

    return None


def _is_token_in_config_file() -> bool:
    """Check if token is already in config file."""
    return _get_config_file_token() is not None


@click.group()
def config():
    """Manage configuration"""
    pass


@config.command()
@click.argument("token")
def set_token(token: str):
    """Set Tushare token"""
    config_file = _get_shell_config_file()

    # Check if token already exists in config file
    if _is_token_in_config_file():
        cli_error(f"Token already configured in {config_file}")
        cli_info("Use 'stocksstrategy config clear' first to remove existing token")
        raise click.Abort()

    # Add token to config file
    export_line = f'export TUSHARE_TOKEN="{token}"\n'

    try:
        with open(config_file, "a") as f:
            f.write("\n# StocksStrategy Tushare Token\n")
            f.write(export_line)

        cli_success(f"Token saved to {config_file}")
        cli_info("Please run 'source {config_file}' or restart your terminal to apply changes")
    except PermissionError:
        cli_error(f"Permission denied: {config_file}")
        raise click.Abort()
    except Exception as e:
        cli_error(f"Failed to write to {config_file}: {e}")
        raise click.Abort()


@config.command()
def show():
    """Show current configuration"""
    cli_info("Configuration:")

    # Check token
    env_token = _get_token_from_env()
    file_token = _get_config_file_token()

    if env_token:
        masked = f"***{env_token[-4:]}" if len(env_token) >= 4 else "****"
        cli_info(f"  token: {masked} (environment)")
    elif file_token:
        masked = f"***{file_token[-4:]}" if len(file_token) >= 4 else "****"
        cli_info(f"  token: {masked} (config file)")
    else:
        cli_info("  token: not configured")

    # Show default paths
    home = Path.home()
    default_data_dir = home / ".stocksstrategy" / "data"
    cli_info(f"  data-dir: {default_data_dir} (default)")


@config.command()
def clear():
    """Clear configuration"""
    config_file = _get_shell_config_file()

    if not config_file.exists():
        cli_info("No configuration file found")
        return

    try:
        content = config_file.read_text()

        # Remove StocksStrategy related lines
        new_lines: list[str] = []
        skip_block = False
        for line in content.splitlines():
            if "# StocksStrategy Tushare Token" in line:
                skip_block = True
                continue
            if skip_block and line.strip().startswith("export TUSHARE_TOKEN="):
                continue
            if skip_block and line.strip() == "":
                skip_block = False
                continue
            if skip_block and not line.strip().startswith("export"):
                skip_block = False
            new_lines.append(line)

        # Write back
        config_file.write_text("\n".join(new_lines) + "\n")

        cli_success(f"Configuration cleared from {config_file}")
        cli_info("Please run 'source {config_file}' or restart your terminal")

    except Exception as e:
        cli_error(f"Failed to clear configuration: {e}")
        raise click.Abort()
