"""Fetch command implementation"""

import click
from pydantic import ValidationError

from stocksstrategy.cli.commands.utils import (
    sleep_interval,
    validate_date_range,
)
from stocksstrategy.cli.params import (
    FetchParams,
    validate_date_optional,
    validate_date_str,
    validate_stock_list,
)
from stocksstrategy.data import create_stock_repository
from stocksstrategy.logging_config import (
    cli_detail,
    cli_error,
    cli_info,
    cli_success,
)


@click.command()
@click.option("--stock", required=True, help="Stock code, supports comma-separated")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD)")
@click.option("--end", default=None, help="End date (YYYY-MM-DD), default is today")
@click.option("--refresh", is_flag=True, help="Force refresh cache")
def fetch(stock: str, start: str, end: str | None, refresh: bool):
    """Fetch stock data"""
    try:
        params = FetchParams(
            stock=validate_stock_list(stock),
            start=validate_date_str(start),
            end=validate_date_optional(end),
            refresh=refresh,
        )
    except ValidationError as e:
        for error in e.errors():
            cli_error(f"Validation error: {error['msg']}")
        raise click.Abort()
    except ValueError as e:
        cli_error(f"Validation error: {e}")
        raise click.Abort()

    # Validate date range
    try:
        validate_date_range(params.start, params.end)
    except ValueError as e:
        cli_error(f"Validation error: {e}")
        raise click.Abort()

    # Parse stock codes
    stock_codes = [code.strip() for code in params.stock.split(",") if code.strip()]

    cli_info("Fetching data...")
    cli_info(f"  Stock: {params.stock}")
    cli_info(f"  Start date: {params.start}")
    cli_info(f"  End date: {params.end or 'today'}")
    cli_info(f"  Force refresh: {params.refresh}")
    cli_info("")

    # Create repository
    stock_repo = create_stock_repository()

    success_count = 0
    error_count = 0

    for code in stock_codes:
        try:
            cli_detail(f"Processing stock: {code}")

            # Check if already cached (for display purposes)
            if not params.refresh:
                cached_start, cached_end = stock_repo.get_date_range(code)
                if cached_start and cached_end:
                    cli_success(
                        f"[{code}] Using cache ({cached_start} to {cached_end})"
                    )

            # Fetch data (auto handles caching/incremental updates)
            if params.refresh:
                cli_success(f"[{code}] Refreshing data from Tushare...")
                cli_detail(f"Calling refresh for {code}")
                df = stock_repo.refresh(code, params.start, params.end)
            else:
                cli_success(f"[{code}] Fetching data...")
                cli_detail(f"Calling get for {code}")
                df = stock_repo.get(code, params.start, params.end)

            if df.empty:
                cli_error(f"[{code}] No data returned")
                error_count += 1
                continue

            # Get date range from fetched data
            start_date = df["trade_date"].min().isoformat()
            end_date = df["trade_date"].max().isoformat()
            row_count = len(df)

            cli_success(
                f"[{code}] Got {row_count} records ({start_date} to {end_date})"
            )
            cli_detail(f"Successfully fetched {row_count} records for {code}")
            success_count += 1

            # Request interval to avoid rate limiting
            sleep_interval(stock_codes, code)

        except ValueError as e:
            cli_error(f"[{code}] Error: {e}")
            cli_detail(f"ValueError for {code}: {e}")
            error_count += 1
        except OSError as e:
            # Network related errors
            cli_error(f"[{code}] Network error: {e}")
            cli_detail(f"OSError for {code}: {e}")
            error_count += 1
        except Exception as e:
            cli_error(f"[{code}] Unexpected error: {type(e).__name__}: {e}")
            cli_detail(f"Exception for {code}: {type(e).__name__}: {e}")
            error_count += 1

    cli_info("")
    cli_info(f"Summary: {success_count} fetched, {error_count} errors")
