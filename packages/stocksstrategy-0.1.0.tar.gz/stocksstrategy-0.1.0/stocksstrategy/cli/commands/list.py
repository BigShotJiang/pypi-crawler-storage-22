"""List command implementation"""

from datetime import date, timedelta

import click
from pydantic import ValidationError

from stocksstrategy.cli.commands.utils import (
    sleep_interval,
)
from stocksstrategy.cli.params import SyncParams, validate_date_optional
from stocksstrategy.data import create_stock_repository
from stocksstrategy.logging_config import (
    cli_detail,
    cli_error,
    cli_info,
    cli_success,
)


@click.command(name="list")
@click.option(
    "--sync", "do_sync", is_flag=True, help="Sync all cached stocks from Tushare"
)
@click.option(
    "--since", default=None, help="Only sync data since this date (YYYY-MM-DD)"
)
def list_stocks(do_sync: bool, since: str | None):
    """
    List cached stock data.

    Without --sync, lists all cached stocks.
    With --sync, updates all cached stocks from Tushare.
    """
    try:
        params = SyncParams(
            refresh=do_sync,
            since=validate_date_optional(since),
        )
    except ValidationError as e:
        for error in e.errors():
            cli_error(f"Validation error: {error['msg']}")
        raise click.Abort()

    # Create repository
    stock_repo = create_stock_repository()

    # Get all cached stocks
    all_stocks = stock_repo.list_all_stocks()

    if not all_stocks:
        cli_info("No cached stocks found.")
        cli_info(
            "Use 'stocksstrategy fetch --stock <code> --start <date>' to fetch data."
        )
        return

    cli_info(f"Found {len(all_stocks)} cached stocks:")
    cli_info("")

    # Show each stock with its date range
    for code in sorted(all_stocks):
        cached_start, cached_end = stock_repo.get_date_range(code)
        if cached_start and cached_end:
            cli_info(f"  {code}: {cached_start} to {cached_end}")
        else:
            cli_info(f"  {code}: (no date range)")

    # If sync flag is set, refresh all cached stocks
    if params.refresh:
        cli_info("")
        cli_info("Syncing all cached stocks from Tushare...")

        success_count = 0
        error_count = 0
        stock_codes = sorted(all_stocks)

        for code in stock_codes:
            try:
                # Print without newline for progress indication
                click.echo(f"  [{code}] Syncing...", nl=False)

                # Get current cached date range
                cached_start, cached_end = stock_repo.get_date_range(code)

                # Determine start date for sync
                # If --since is specified, use that; otherwise use original cached start
                if params.since:
                    start_date = params.since
                elif cached_start:
                    start_date = cached_start
                else:
                    # Fallback: use a reasonable default (1 year ago)
                    start_date = date.today() - timedelta(days=365)

                cli_detail(f"Syncing {code} from {start_date}")

                # Refresh data
                df = stock_repo.refresh(code, start_date)

                if df.empty:
                    cli_error(f"  [{code}] No data returned")
                    error_count += 1
                    continue

                # Get date range from refreshed data
                new_start = df["trade_date"].min().isoformat()
                new_end = df["trade_date"].max().isoformat()
                row_count = len(df)

                cli_success(
                    f"\r  [{code}] Updated {row_count} records ({new_start} to {new_end})"
                )
                cli_detail(f"Successfully synced {code}: {row_count} records")
                success_count += 1

                # Request interval to avoid rate limiting
                sleep_interval(stock_codes, code)

            except ValueError as e:
                cli_error(f"  [{code}] Error: {e}")
                cli_detail(f"ValueError for {code}: {e}")
                error_count += 1
            except OSError as e:
                # Network related errors
                cli_error(f"  [{code}] Network error: {e}")
                cli_detail(f"OSError for {code}: {e}")
                error_count += 1
            except Exception as e:
                cli_error(f"  [{code}] Unexpected error: {type(e).__name__}: {e}")
                cli_detail(f"Exception for {code}: {type(e).__name__}: {e}")
                error_count += 1

        cli_info("")
        cli_info(f"Summary: {success_count} synced, {error_count} errors")
