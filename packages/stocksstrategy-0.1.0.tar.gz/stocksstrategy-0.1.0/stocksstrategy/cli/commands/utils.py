"""CLI command utilities"""

from dataclasses import dataclass
from datetime import date
import time


# Tushare API 请求间隔（秒），避免触发频率限制
REQUEST_INTERVAL = 0.5


@dataclass
class CommandResult:
    """Command execution result"""

    success_count: int
    error_count: int

    def __str__(self) -> str:
        return f"Summary: {self.success_count} succeeded, {self.error_count} errors"


def print_error(code: str, message: str, err: bool = True) -> None:
    """Print error message for a stock code"""
    import click

    click.echo(f"  [{code}] {message}", err=err)


def print_success(code: str, message: str) -> None:
    """Print success message for a stock code"""
    import click

    click.echo(f"  [{code}] {message}")


def should_sleep(current: str, items: list[str]) -> bool:
    """Check if should sleep between API requests"""
    return current != items[-1]


def sleep_interval(items: list[str], current: str) -> None:
    """Sleep with interval to avoid rate limiting"""
    if should_sleep(current, items):
        time.sleep(REQUEST_INTERVAL)


def validate_date_range(start: date | None, end: date | None, allow_equal: bool = False) -> None:
    """Validate that end date is after or equal to start date

    Args:
        start: Start date
        end: End date (can be None)
        allow_equal: If True, end == start is valid

    Raises:
        ValueError: If end date is before start date
    """
    if end is None:
        return

    # Type guard: after this, end is known to be date
    assert start is not None, "start must not be None"

    if allow_equal:
        if end < start:
            raise ValueError(f"End date must be on or after start date: {end} < {start}")
    else:
        if end <= start:
            raise ValueError(f"End date must be after start date: {end} <= {start}")
