"""CLI parameter validation models"""

from datetime import date
from typing import Annotated

from pydantic import BaseModel, BeforeValidator


def validate_stock_code(v: str) -> str:
    """Validate stock code is 6 digits"""
    if not v.isdigit():
        raise ValueError(f"Stock code must be 6 digits, got: {v}")
    if len(v) != 6:
        raise ValueError(f"Stock code must be 6 digits, got: {v}")
    return v


def validate_stock_list(v: str) -> str:
    """Validate stock code list (comma-separated)"""
    codes = [code.strip() for code in v.split(",") if code.strip()]
    if not codes:
        raise ValueError("Stock code cannot be empty")

    for code in codes:
        if not code.isdigit():
            raise ValueError(f"Stock code must be 6 digits, got: {code}")
        if len(code) != 6:
            raise ValueError(f"Stock code must be 6 digits, got: {code}")
    return v


def validate_date_str(v: str) -> date:
    """Validate and convert date string to date object"""
    try:
        d = date.fromisoformat(v)
    except ValueError:
        raise ValueError(f"Date must be in YYYY-MM-DD format, got: {v}")
    return d


def validate_date_optional(v: str | None) -> date | None:
    """Validate and convert optional date string to date object"""
    if v is None:
        return None
    try:
        return date.fromisoformat(v)
    except ValueError:
        raise ValueError(f"Date must be in YYYY-MM-DD format, got: {v}")


def validate_positive_capital(v: float) -> float:
    """Validate capital is positive"""
    if v <= 0:
        raise ValueError("Initial capital must be positive")
    return v


# Type aliases with validators
StockCode = Annotated[str, BeforeValidator(validate_stock_code)]
StockList = Annotated[str, BeforeValidator(validate_stock_list)]
DateStr = Annotated[date, BeforeValidator(validate_date_str)]
DateStrOptional = Annotated[date | None, BeforeValidator(validate_date_optional)]
PositiveFloat = Annotated[float, BeforeValidator(validate_positive_capital)]


class BacktestParams(BaseModel):
    """Backtest command parameters"""

    stock: str
    strategy: str
    start: date
    end: date | None = None
    capital: float = 100000.0


class FetchParams(BaseModel):
    """Fetch command parameters"""

    stock: str
    start: date
    end: date | None = None
    refresh: bool = False


class SyncParams(BaseModel):
    """Sync command parameters"""

    refresh: bool = False
    since: date | None = None
