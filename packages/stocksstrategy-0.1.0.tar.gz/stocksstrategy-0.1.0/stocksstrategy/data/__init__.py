"""Data module for stock data management with three-layer architecture.

Architecture:
    Repository (Domain Layer)
        |
    DataCoordinator (Orchestration Layer)
        |
    Strategy + Storage + MetadataStorage + DataSource (Infrastructure Layer)
"""

# Core types
# Configuration
from stocksstrategy.data.config import DataConfig

# Coordinator layer
from stocksstrategy.data.coordinator import DataCoordinator, StockDataCoordinator

# Repository layer
from stocksstrategy.data.repositories import StockRepository, StockRepositoryImpl

# Schema and validated type
from stocksstrategy.data.schemas import ValidatedStockData

# Data source layer
from stocksstrategy.data.sources import DataSource, TushareDataSource

# Storage layer
from stocksstrategy.data.storage import (
    DataStorage,
    MetadataStorage,
    ParquetStorage,
    SqliteMetadataStorage,
)

# Strategy layer
from stocksstrategy.data.strategy import (
    DataAcquisitionStrategy,
    DefaultAcquisitionStrategy,
)
from stocksstrategy.data.types import (
    DataParams,
    DataResult,
    DatasetMetadata,
    DateRange,
)


def create_stock_repository() -> StockRepository:
    """
    Create a StockRepository instance with default configuration.

    Returns:
        StockRepository instance using DataCoordinator pattern
    """
    data_config = DataConfig.default()

    data_storage = ParquetStorage(data_config.data_dir)
    metadata_storage = SqliteMetadataStorage(data_config.db_path)
    strategy = DefaultAcquisitionStrategy(validity_days=7, max_gap_days=30)
    data_source = TushareDataSource()

    coordinator = StockDataCoordinator(
        strategy=strategy,
        data_storage=data_storage,
        metadata_storage=metadata_storage,
        data_source=data_source,
    )

    return StockRepositoryImpl(data_coordinator=coordinator)


__all__ = [
    # Core Types
    "DataParams",
    "DataResult",
    "DateRange",
    "DatasetMetadata",
    "ValidatedStockData",
    # Coordinator Layer
    "DataCoordinator",
    "StockDataCoordinator",
    # Repository Layer
    "StockRepository",
    "StockRepositoryImpl",
    # Strategy Layer
    "DataAcquisitionStrategy",
    "DefaultAcquisitionStrategy",
    # Storage Layer
    "DataStorage",
    "MetadataStorage",
    "ParquetStorage",
    "SqliteMetadataStorage",
    # Data Source Layer
    "DataSource",
    "TushareDataSource",
    # Configuration
    "DataConfig",
    # Factory
    "create_stock_repository",
]
