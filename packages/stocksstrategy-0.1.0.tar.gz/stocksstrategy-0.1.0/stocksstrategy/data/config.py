"""Data layer configuration"""

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class DataConfig:
    """Data layer configuration (immutable)"""

    data_dir: Path  # Directory for parquet files
    db_path: Path  # Path to SQLite index database

    @classmethod
    def default(cls) -> "DataConfig":
        """Create default configuration"""
        home = Path.home() / ".stocksstrategy"
        data_dir = home / "data"
        data_dir.mkdir(parents=True, exist_ok=True)
        return cls(
            data_dir=data_dir,
            db_path=home / "index.db",
        )

    @classmethod
    def from_env(cls) -> "DataConfig":
        """Create configuration from environment variables"""
        home_str = os.environ.get("STOCKSSTRATEGY_HOME", str(Path.home() / ".stocksstrategy"))
        home = Path(home_str)
        data_dir_str = os.environ.get("STOCKSSTRATEGY_DATA_DIR")
        db_path_str = os.environ.get("STOCKSSTRATEGY_DB_PATH")

        if data_dir_str:
            data_dir = Path(data_dir_str)
        else:
            data_dir = home / "data"

        if db_path_str:
            db_path = Path(db_path_str)
        else:
            db_path = home / "index.db"

        data_dir.mkdir(parents=True, exist_ok=True)
        return cls(data_dir=data_dir, db_path=db_path)
