"""Data coordinator module."""

from stocksstrategy.data.coordinator.protocols import DataCoordinator
from stocksstrategy.data.coordinator.stock import StockDataCoordinator

__all__ = ["DataCoordinator", "StockDataCoordinator"]
