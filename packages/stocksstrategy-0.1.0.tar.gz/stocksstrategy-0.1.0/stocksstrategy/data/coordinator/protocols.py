"""Protocol definitions for data coordinators."""

from datetime import date
from typing import Protocol

from stocksstrategy.data.types import DataResult, DatasetMetadata


class DataCoordinator(Protocol):
    """Protocol for data orchestration layer."""

    def get(self, key: str, start_date: date, end_date: date) -> DataResult:
        """
        Get data with transparent acquisition.

        Args:
            key: Storage key (e.g., "600519.SH")
            start_date: Start date
            end_date: End date

        Returns:
            DataResult with data, source indicator, and metadata
        """
        ...

    def refresh(self, key: str, start_date: date, end_date: date) -> DataResult:
        """
        Force refresh from DataSource.

        Args:
            key: Storage key
            start_date: Start date
            end_date: End date

        Returns:
            DataResult with refreshed data
        """
        ...

    def invalidate(self, key: str) -> None:
        """
        Invalidate local dataset.

        Args:
            key: Storage key
        """
        ...

    def get_metadata(self, key: str) -> DatasetMetadata | None:
        """
        Get dataset metadata.

        Args:
            key: Storage key

        Returns:
            Dataset metadata or None
        """
        ...

    def list_all_keys(self) -> list[str]:
        """
        List all cached dataset keys.

        Returns:
            List of storage keys (e.g., ["600519.SH", "000001.SZ"])
        """
        ...
