"""Stock data coordinator implementation."""

from __future__ import annotations

import logging
from datetime import date
from typing import TYPE_CHECKING, cast

import pandas as pd

from stocksstrategy.data.coordinator.protocols import DataCoordinator
from stocksstrategy.data.schemas import create_empty_stock_dataframe
from stocksstrategy.data.sources.base import DataSource
from stocksstrategy.data.storage.protocols import DataStorage, MetadataStorage
from stocksstrategy.data.strategy.protocols import DataAcquisitionStrategy
from stocksstrategy.data.types import DataResult, DatasetMetadata, DateRange

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


logger = logging.getLogger(__name__)


class StockDataCoordinator(DataCoordinator):
    """Coordinates stock data acquisition across Strategy, Storage, and DataSource."""

    def __init__(
        self,
        strategy: DataAcquisitionStrategy,
        data_storage: DataStorage,
        metadata_storage: MetadataStorage,
        data_source: DataSource,
    ):
        """
        Initialize the data coordinator.

        Args:
            strategy: Data acquisition strategy
            data_storage: Data storage implementation
            metadata_storage: Metadata storage implementation
            data_source: External data source
        """
        self._strategy = strategy
        self._data_storage = data_storage
        self._metadata_storage = metadata_storage
        self._data_source = data_source

    def _load_all_local_data(self, key: str) -> ValidatedStockData:
        """Load all local data across all partitions."""
        partitions = self._data_storage.list_partitions(key)
        if partitions:
            return self._data_storage.load(key, partition_keys=partitions)
        return self._data_storage.load(key)

    def get(self, key: str, start_date: date, end_date: date) -> DataResult:
        """
        Orchestrate data acquisition workflow:
        1. Auto-adjust start_date to listing date if earlier
        2. Load metadata
        3. Ask Strategy: is local data valid?
        4. If valid -> load from storage + filter
        5. If not -> ask Strategy: should_use_incremental_update?
        6. If incremental -> calculate fetch ranges, fetch missing
        7. If full refresh -> fetch entire requested range
        8. Ask Strategy: merge data
        9. Atomic update (data + metadata, partitioned by year)
        10. Return filtered result
        """
        # Step 1: Auto-adjust start_date to listing date if user specified earlier date
        # Key is now "600519.SH", we need to extract "600519"
        stock_code_with_exchange = key  # Already in format "600519.SH"
        # Extract just the numeric part (remove .SH or .SZ)
        stock_code = (
            stock_code_with_exchange.split(".")[0]
            if "." in stock_code_with_exchange
            else stock_code_with_exchange
        )
        listing_date = self._data_source.get_listing_date(stock_code)
        if listing_date and start_date < listing_date:
            logger.warning(
                f"User requested start date {start_date} is before listing date "
                f"{listing_date} for {stock_code}, adjusting to listing date"
            )
            start_date = listing_date

        requested_range = DateRange(start_date, end_date)

        # Step 2: Load metadata
        metadata = self._metadata_storage.get_metadata(key)

        # Step 3: Check if local data is valid
        if self._strategy.is_local_data_valid(metadata, requested_range):
            # Load from storage and filter
            local_data = self._load_all_local_data(key)
            filtered_data = self._strategy.filter_by_range(
                local_data, start_date, end_date
            )
            return DataResult(data=filtered_data, source="cache", metadata=metadata)

        # Step 4: Determine update strategy
        local_range = metadata.date_range if metadata else None

        # Calculate gap days for incremental vs full decision
        gap_days = 0
        if local_range:
            if requested_range.start_date > local_range.end_date:
                gap_days = (requested_range.start_date - local_range.end_date).days
            elif requested_range.end_date < local_range.start_date:
                gap_days = (local_range.start_date - requested_range.end_date).days

        use_incremental = self._strategy.should_use_incremental_update(
            local_range, requested_range, gap_days
        )

        if use_incremental:
            # Step 5a: Incremental update — fetch only missing ranges
            fetch_ranges = self._strategy.calculate_fetch_ranges(
                local_range, requested_range
            )
        else:
            # Step 5b: Full refresh — fetch entire requested range
            fetch_ranges = [requested_range]

        if not fetch_ranges:
            # No fetch needed, return local data
            local_data = self._load_all_local_data(key)
            filtered_data = self._strategy.filter_by_range(
                local_data, start_date, end_date
            )
            return DataResult(data=filtered_data, source="cache", metadata=metadata)

        # Step 6: Fetch missing data
        new_data_frames: list[ValidatedStockData] = []
        for fetch_range in fetch_ranges:
            # Key is now "600519.SH", extract "600519"
            stock_code = key.split(".")[0] if "." in key else key
            fetched = self._data_source.fetch(
                stock_code=stock_code,
                start_date=fetch_range.start_date,
                end_date=fetch_range.end_date,
            )
            if not fetched.empty:
                new_data_frames.append(fetched)

        if not new_data_frames:
            # Fetch returned no data, return local data if available
            local_data = self._load_all_local_data(key)
            return DataResult(data=local_data, source="cache", metadata=metadata)

        new_data = cast(
            "ValidatedStockData", pd.concat(new_data_frames, ignore_index=True)
        )

        # Step 7: Merge with local data
        if use_incremental and metadata:
            local_data = self._load_all_local_data(key)
        else:
            local_data = create_empty_stock_dataframe()
        merged_data = self._strategy.merge_data(local_data, new_data)

        # Step 8: Atomic update (data first, then metadata) — partitioned by year
        self._save_with_metadata(key, merged_data)

        # Step 9: Filter and return
        filtered_data = self._strategy.filter_by_range(
            merged_data, start_date, end_date
        )
        new_metadata = self._metadata_storage.get_metadata(key)

        return DataResult(data=filtered_data, source="partial", metadata=new_metadata)

    def refresh(self, key: str, start_date: date, end_date: date) -> DataResult:
        """Force refresh from DataSource, optimized to only fetch missing ranges."""
        # Key is now "600519.SH", extract "600519"
        stock_code = key.split(".")[0] if "." in key else key

        # Get local metadata to optimize fetch range
        metadata = self._metadata_storage.get_metadata(key)
        local_range = metadata.date_range if metadata else None

        # Optimization: if requested end_date is before or equal to local end_date,
        # we already have all the data, skip API call
        if local_range and end_date <= local_range.end_date:
            local_data = self._load_all_local_data(key)
            return DataResult(
                data=self._strategy.filter_by_range(local_data, start_date, end_date),
                source="cache",
                metadata=metadata,
            )

        requested_range = DateRange(start_date, end_date)

        # Calculate actual fetch ranges (only missing data)
        fetch_ranges = self._strategy.calculate_fetch_ranges(
            local_range, requested_range
        )

        if not fetch_ranges:
            # No missing data, return local data
            local_data = self._load_all_local_data(key)
            return DataResult(
                data=self._strategy.filter_by_range(local_data, start_date, end_date),
                source="cache",
                metadata=metadata,
            )

        # Fetch only missing data
        new_data_frames: list[ValidatedStockData] = []
        for fetch_range in fetch_ranges:
            fetched = self._data_source.fetch(
                stock_code=stock_code,
                start_date=fetch_range.start_date,
                end_date=fetch_range.end_date,
            )
            if not fetched.empty:
                new_data_frames.append(fetched)

        if not new_data_frames:
            # No new data fetched (e.g., requested date is today with no trading)
            # Return local data without saving to avoid unnecessary I/O
            if metadata:
                local_data = self._load_all_local_data(key)
                return DataResult(
                    data=self._strategy.filter_by_range(
                        local_data, start_date, end_date
                    ),
                    source="cache",
                    metadata=metadata,
                )
            # No local data and no new data
            return DataResult(
                data=create_empty_stock_dataframe(),
                source="cache",
                metadata=None,
            )

        new_data = cast(
            "ValidatedStockData", pd.concat(new_data_frames, ignore_index=True)
        )

        # Merge with local data (only if local data exists)
        if metadata and local_range:
            local_data = self._load_all_local_data(key)
            merged_data = self._strategy.merge_data(local_data, new_data)
        else:
            merged_data = new_data

        # Save to storage
        self._save_with_metadata(key, merged_data)

        # Filter and return
        filtered_data = self._strategy.filter_by_range(
            merged_data, start_date, end_date
        )
        new_metadata = self._metadata_storage.get_metadata(key)

        return DataResult(data=filtered_data, source="partial", metadata=new_metadata)

    def invalidate(self, key: str) -> None:
        """Invalidate local dataset."""
        partitions = self._data_storage.list_partitions(key)
        for partition in partitions:
            self._data_storage.delete(key, partition)
        self._metadata_storage.delete_metadata(key)

    def get_metadata(self, key: str) -> DatasetMetadata | None:
        """Get dataset metadata."""
        return self._metadata_storage.get_metadata(key)

    def list_all_keys(self) -> list[str]:
        """List all cached stock keys."""
        return self._metadata_storage.list_all_keys()

    def _save_with_metadata(self, key: str, data: "ValidatedStockData") -> None:
        """Atomic update: save data first, then metadata."""
        if data.empty:
            return

        # Determine partition key (year)
        # Convert to datetime if needed for .dt accessor
        trade_dates = data["trade_date"]
        if trade_dates.dtype == "object":
            trade_dates = pd.to_datetime(trade_dates)
        years = trade_dates.dt.year.unique().tolist()  # type: ignore[union-attr]
        for year in years:  # type: ignore[assignment]
            year_data = data[trade_dates.dt.year == year]  # type: ignore[union-attr]
            partition_key = str(year)  # type: ignore[arg-type]
            self._data_storage.save(key, year_data, partition_key)  # type: ignore[arg-type]

        # Update metadata
        start_date = trade_dates.min()
        end_date = trade_dates.max()
        metadata = DatasetMetadata(
            key=key,
            date_range=DateRange(start_date=start_date, end_date=end_date),
            row_count=len(data),
            last_updated=date.today(),
            version=1,
        )
        self._metadata_storage.save_metadata(key, metadata)
