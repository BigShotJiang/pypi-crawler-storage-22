"""SQLAlchemy ORM models for database layer.

This module defines database models using SQLAlchemy ORM.
All models use MappedAsDataclass for type safety and convenience.
"""

from datetime import date

from sqlalchemy import Date, Integer, String
from sqlalchemy.orm import DeclarativeBase, Mapped, MappedAsDataclass, mapped_column


class Base(DeclarativeBase):
    """Base class for all ORM models."""

    pass


class StockIndex(MappedAsDataclass, Base):
    """
    Stock data index metadata stored in SQLite.

    This class uses MappedAsDataclass to be both:
    - A SQLAlchemy ORM model (for database mapping)
    - A Python dataclass (for type safety and serialization)

    Attributes:
        ts_code: Stock code in Tushare format (e.g., 600519.SH)
        start_date: Start date of cached data
        end_date: End date of cached data
        updated_at: Last update timestamp
        row_count: Number of data rows in the cache
    """

    __tablename__ = "stock_index"

    ts_code: Mapped[str] = mapped_column(String, primary_key=True, init=True)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    updated_at: Mapped[date] = mapped_column(Date, nullable=False)
    row_count: Mapped[int] = mapped_column(Integer, nullable=False)
