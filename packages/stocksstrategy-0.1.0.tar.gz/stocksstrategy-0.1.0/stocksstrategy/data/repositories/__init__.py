"""Repository layer for data access."""

from stocksstrategy.data.repositories.base import StockRepository
from stocksstrategy.data.repositories.stock import StockRepositoryImpl

__all__ = [
    "StockRepository",
    "StockRepositoryImpl",
]
