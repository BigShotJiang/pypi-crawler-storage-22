"""Repository protocol interfaces."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING, Protocol

from stocksstrategy.data.types import DatasetMetadata

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


class StockRepository(Protocol):
    """Protocol interface for stock data repository."""

    def get(
        self,
        stock_code: str,
        start_date: date,
        end_date: date | None = None,
    ) -> ValidatedStockData:
        """
        Get stock data (auto handles caching).

        Args:
            stock_code: Stock code (e.g., 600519)
            start_date: Start date
            end_date: End date, default is today

        Returns:
            DataFrame with stock data
        """
        ...

    def refresh(
        self,
        stock_code: str,
        start_date: date,
        end_date: date | None = None,
    ) -> ValidatedStockData:
        """
        Force refresh from data source.

        Args:
            stock_code: Stock code
            start_date: Start date
            end_date: End date

        Returns:
            DataFrame with stock data
        """
        ...

    def get_multiple(
        self,
        stock_codes: list[str],
        start_date: date,
        end_date: date | None = None,
    ) -> dict[str, ValidatedStockData]:
        """
        Batch query for multiple stocks (sequential execution).

        Args:
            stock_codes: List of stock codes
            start_date: Start date
            end_date: End date, default is today

        Returns:
            Dict mapping stock_code to DataFrame
        """
        ...

    def get_latest(self, stock_code: str, days: int = 30) -> ValidatedStockData:
        """
        Get recent N days of data.

        Args:
            stock_code: Stock code
            days: Number of recent days

        Returns:
            DataFrame with recent stock data
        """
        ...

    def get_dataset_info(self, stock_code: str) -> DatasetMetadata | None:
        """
        Get dataset metadata for a stock.

        Args:
            stock_code: Stock code

        Returns:
            DatasetMetadata or None if not found
        """
        ...

    def clear_local_data(self, stock_code: str) -> None:
        """
        Clear local dataset for a specific stock.

        Args:
            stock_code: Stock code
        """
        ...

    def exists(self, stock_code: str) -> bool:
        """
        Check if data exists in storage.

        Args:
            stock_code: Stock code

        Returns:
            True if data exists
        """
        ...

    def get_date_range(
        self,
        stock_code: str,
    ) -> tuple[date | None, date | None]:
        """
        Get cached date range for a stock.

        Args:
            stock_code: Stock code

        Returns:
            Tuple of (start_date, end_date) or (None, None)
        """
        ...

    def list_all_stocks(self) -> list[str]:
        """
        List all cached stock codes.

        Returns:
            List of stock codes (e.g., ["600519", "000001"])
        """
        ...
