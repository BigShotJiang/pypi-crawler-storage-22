"""Stock repository implementation."""

from __future__ import annotations

from datetime import date, timedelta
from typing import TYPE_CHECKING

from stocksstrategy.data.coordinator.protocols import DataCoordinator
from stocksstrategy.data.types import DatasetMetadata
from stocksstrategy.data.utils.date import parse_date
from stocksstrategy.data.utils.stock import format_ts_code

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


class StockRepositoryImpl:
    """Implementation of StockRepository with DataCoordinator delegation."""

    def __init__(self, data_coordinator: DataCoordinator):
        """
        Initialize with DataCoordinator instead of Cache + DataSource.

        Args:
            data_coordinator: Data coordinator for orchestration
        """
        self._coordinator = data_coordinator

    def get(
        self,
        stock_code: str,
        start_date: date,
        end_date: date | None = None,
    ) -> ValidatedStockData:
        """
        Get stock data with automatic caching.

        Args:
            stock_code: Stock code (e.g., 600519)
            start_date: Start date
            end_date: End date, default is today

        Returns:
            DataFrame with stock data
        """
        key, req_start, req_end = self._parse_request(stock_code, start_date, end_date)

        # Simple delegation to coordinator
        result = self._coordinator.get(key, req_start, req_end)
        return result.data

    def refresh(
        self,
        stock_code: str,
        start_date: date,
        end_date: date | None = None,
    ) -> ValidatedStockData:
        """
        Force refresh from data source.

        Args:
            stock_code: Stock code
            start_date: Start date
            end_date: End date

        Returns:
            DataFrame with stock data
        """
        key, req_start, req_end = self._parse_request(stock_code, start_date, end_date)

        result = self._coordinator.refresh(key, req_start, req_end)
        return result.data

    def get_multiple(
        self,
        stock_codes: list[str],
        start_date: date,
        end_date: date | None = None,
    ) -> dict[str, ValidatedStockData]:
        """
        Batch query for multiple stocks (sequential execution).

        Args:
            stock_codes: List of stock codes
            start_date: Start date
            end_date: End date, default is today

        Returns:
            Dict mapping stock_code to DataFrame
        """
        results: dict[str, ValidatedStockData] = {}
        for code in stock_codes:
            results[code] = self.get(code, start_date, end_date)
        return results

    def get_latest(self, stock_code: str, days: int = 30) -> ValidatedStockData:
        """
        Get recent N days of data.

        Args:
            stock_code: Stock code
            days: Number of recent days

        Returns:
            DataFrame with recent stock data
        """
        end_date = date.today()
        # Add buffer for non-trading days (weekends, holidays)
        start_date = end_date - timedelta(days=int(days * 1.8))
        df = self.get(stock_code, start_date, end_date)

        # Return only the last N rows (actual trading days)
        if len(df) > days:
            return df.tail(days).reset_index(drop=True)
        return df

    def get_dataset_info(self, stock_code: str) -> DatasetMetadata | None:
        """
        Get dataset metadata for a stock.

        Args:
            stock_code: Stock code

        Returns:
            DatasetMetadata or None if not found
        """
        ts_code = format_ts_code(stock_code)
        key = ts_code  # 直接使用 ts_code，如 "600519.SH"
        return self._coordinator.get_metadata(key)

    def clear_local_data(self, stock_code: str) -> None:
        """
        Clear local dataset for a specific stock.

        Args:
            stock_code: Stock code
        """
        ts_code = format_ts_code(stock_code)
        key = ts_code  # 直接使用 ts_code，如 "600519.SH"
        self._coordinator.invalidate(key)

    def exists(self, stock_code: str) -> bool:
        """
        Check if data exists in storage.

        Args:
            stock_code: Stock code

        Returns:
            True if data exists
        """
        ts_code = format_ts_code(stock_code)
        key = ts_code  # 直接使用 ts_code，如 "600519.SH"
        metadata = self._coordinator.get_metadata(key)
        return metadata is not None

    def get_date_range(self, stock_code: str) -> tuple[date | None, date | None]:
        """
        Get cached date range for a stock.

        Args:
            stock_code: Stock code

        Returns:
            Tuple of (start_date, end_date) or (None, None)
        """
        ts_code = format_ts_code(stock_code)
        key = ts_code  # 直接使用 ts_code，如 "600519.SH"
        metadata = self._coordinator.get_metadata(key)

        if not metadata or not metadata.date_range:
            return (None, None)

        return (metadata.date_range.start_date, metadata.date_range.end_date)

    def list_all_stocks(self) -> list[str]:
        """
        List all cached stock codes (user-friendly format).

        Returns:
            List of stock codes (e.g., ["600519", "000001"]) sorted
        """
        from stocksstrategy.data.utils.stock import parse_ts_code

        # Get all keys (format: "600519.SH")
        all_keys = self._coordinator.list_all_keys()

        # Convert to user format (600519)
        stock_codes: list[str] = []
        for key in all_keys:
            # Already in format "600519.SH", just need to parse to "600519"
            stock_code = parse_ts_code(key)  # "600519.SH" -> "600519"
            stock_codes.append(stock_code)

        return sorted(stock_codes)

    def _parse_request(
        self,
        stock_code: str,
        start_date: date,
        end_date: date | None = None,
    ) -> tuple[str, date, date]:
        """Parse and normalize request parameters."""
        req_start = parse_date(start_date)
        req_end = parse_date(end_date) if end_date else date.today()
        ts_code = format_ts_code(stock_code)

        # Convert to coordinator key format
        key = ts_code  # 直接使用 ts_code，如 "600519.SH"

        return key, req_start, req_end
