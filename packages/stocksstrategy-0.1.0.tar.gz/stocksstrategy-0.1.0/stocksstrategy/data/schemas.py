"""DataFrame schemas for stock data validation and documentation.

This module defines the expected structure of DataFrames used throughout
the application, providing:
- Type safety through schema validation
- Documentation of expected columns
- Runtime validation of data integrity
- Automatic type coercion
"""

from typing import cast

import pandas as pd
import pandera.pandas as pa
from pandera.typing.pandas import DataFrame, Series


class StockDataSchema(pa.DataFrameModel):
    """
    Schema for stock OHLCV (Open-High-Low-Close-Volume) data.

    This schema validates DataFrames containing historical stock trading data.
    All price and volume data from data sources should conform to this schema.

    Attributes:
        ts_code: Stock code in Tushare format (e.g., 600519.SH)
        trade_date: Trading date
        open: Opening price
        high: Highest price of the day
        low: Lowest price of the day
        close: Closing price
        pre_close: Previous day's closing price
        volume: Trading volume in lots (1 lot = 100 shares)
        amount: Trading amount in thousand CNY
        pct_chg: Percentage change (%)
        change: Absolute price change

    Example:
        >>> import pandas as pd
        >>> from datetime import date
        >>> from stocksstrategy.data.schemas import StockDataSchema
        >>>
        >>> df = pd.DataFrame({
        ...     'ts_code': ['600519.SH'],
        ...     'trade_date': [date(2024, 1, 1)],
        ...     'open': [1800.0],
        ...     'high': [1850.0],
        ...     'low': [1790.0],
        ...     'close': [1830.0],
        ...     'pre_close': [1795.0],
        ...     'volume': [12500.0],
        ...     'amount': [228750.0],
        ...     'pct_chg': [1.95],
        ...     'change': [35.0]
        ... })
        >>>
        >>> # Validate the DataFrame
        >>> validated_df = StockDataSchema.validate(df)
    """

    # Stock identifier (Tushare format: XXXXXX.SH or XXXXXX.SZ)
    ts_code: Series[str] = pa.Field(
        description="Stock code in Tushare format (e.g., 600519.SH)",
        str_matches=r"^\d{6}\.(SH|SZ)$",  # Raw string to avoid escape sequence warning
    )

    # Trading date (will be coerced to date objects)
    trade_date: Series[pa.Date] = pa.Field(  # type: ignore[valid-type]
        description="Trading date",
        coerce=True,
    )

    # OHLC prices (must be positive or zero)
    open: Series[float] = pa.Field(
        description="Opening price",
        ge=0,
        nullable=False,
    )

    high: Series[float] = pa.Field(
        description="Highest price of the day",
        ge=0,
        nullable=False,
    )

    low: Series[float] = pa.Field(
        description="Lowest price of the day",
        ge=0,
        nullable=False,
    )

    close: Series[float] = pa.Field(
        description="Closing price",
        ge=0,
        nullable=False,
    )

    pre_close: Series[float] = pa.Field(
        description="Previous day's closing price",
        ge=0,
        nullable=False,
    )

    # Volume and amount (must be non-negative)
    volume: Series[float] = pa.Field(
        description="Trading volume in lots (1 lot = 100 shares)",
        ge=0,
        nullable=False,
    )

    amount: Series[float] = pa.Field(
        description="Trading amount in thousand CNY",
        ge=0,
        nullable=False,
    )

    # Price changes (can be negative)
    pct_chg: Series[float] = pa.Field(
        description="Percentage change (%)",
        nullable=False,
    )

    change: Series[float] = pa.Field(
        description="Absolute price change",
        nullable=False,
    )

    class Config:  # type: ignore[misc]
        """Pandera model configuration."""

        strict = True  # Reject DataFrames with extra columns
        coerce = True  # Automatically coerce data types
        ordered = False  # Column order doesn't matter

    @pa.dataframe_check  # type: ignore[misc]
    def check_high_low_consistency(cls, df: pd.DataFrame) -> pd.Series:  # type: ignore[type-arg]
        """Validate that high >= low for all rows."""
        return df["high"] >= df["low"]

    @pa.dataframe_check  # type: ignore[misc]
    def check_high_includes_open_close(cls, df: pd.DataFrame) -> pd.Series:  # type: ignore[type-arg]
        """Validate that high >= max(open, close)."""
        return (df["high"] >= df["open"]) & (df["high"] >= df["close"])

    @pa.dataframe_check  # type: ignore[misc]
    def check_low_includes_open_close(cls, df: pd.DataFrame) -> pd.Series:  # type: ignore[type-arg]
        """Validate that low <= min(open, close)."""
        return (df["low"] <= df["open"]) & (df["low"] <= df["close"])


# Type alias for validated DataFrames
ValidatedStockData = DataFrame[StockDataSchema]


def validate_stock_data(
    df: pd.DataFrame,
    *,
    lazy: bool = False,
    inplace: bool = False,
) -> ValidatedStockData:
    """
    Validate stock data DataFrame against StockDataSchema.

    This function validates the DataFrame structure, types, and business rules.
    It will automatically coerce compatible types (e.g., strings to dates).

    Args:
        df: DataFrame to validate
        lazy: If True, collect all errors before raising. If False, raise on first error.
        inplace: If True, modify the DataFrame in place during type coercion

    Returns:
        Validated DataFrame with types coerced to match schema

    Raises:
        pandera.errors.SchemaError: If validation fails
        pandera.errors.SchemaErrors: If validation fails in lazy mode (contains multiple errors)

    Example:
        >>> import pandas as pd
        >>> from stocksstrategy.data.schemas import validate_stock_data
        >>>
        >>> # DataFrame with string dates (will be auto-converted)
        >>> df = pd.DataFrame({
        ...     'ts_code': ['600519.SH'],
        ...     'trade_date': ['2024-01-01'],  # String will be converted to date
        ...     'open': [1800.0],
        ...     # ... other columns
        ... })
        >>>
        >>> validated_df = validate_stock_data(df)
        >>> type(validated_df['trade_date'].iloc[0])
        <class 'datetime.date'>
    """
    return StockDataSchema.validate(df, lazy=lazy, inplace=inplace)


def get_stock_data_columns() -> list[str]:
    """
    Get the list of expected column names for stock data.

    Returns:
        List of column names in schema order

    Example:
        >>> from stocksstrategy.data.schemas import get_stock_data_columns
        >>> columns = get_stock_data_columns()
        >>> print(columns)
        ['ts_code', 'trade_date', 'open', 'high', 'low', 'close', 'pre_close', 'volume', 'amount', 'pct_chg', 'change']
    """
    return list(StockDataSchema.to_schema().columns.keys())


def create_empty_stock_dataframe() -> ValidatedStockData:
    """
    Create an empty DataFrame with the correct schema.

    Returns:
        Empty DataFrame with correct column types

    Example:
        >>> from stocksstrategy.data.schemas import create_empty_stock_dataframe
        >>> df = create_empty_stock_dataframe()
        >>> print(df.dtypes)
        ts_code        object
        trade_date     object
        open          float64
        high          float64
        low           float64
        close         float64
        pre_close     float64
        volume        float64
        amount        float64
        pct_chg       float64
        change        float64
        dtype: object
    """
    return cast(
        ValidatedStockData,
        pd.DataFrame(
            {
                "ts_code": pd.Series(dtype="str"),
                "trade_date": pd.Series(dtype="object"),  # Will hold date objects
                "open": pd.Series(dtype="float64"),
                "high": pd.Series(dtype="float64"),
                "low": pd.Series(dtype="float64"),
                "close": pd.Series(dtype="float64"),
                "pre_close": pd.Series(dtype="float64"),
                "volume": pd.Series(dtype="float64"),
                "amount": pd.Series(dtype="float64"),
                "pct_chg": pd.Series(dtype="float64"),
                "change": pd.Series(dtype="float64"),
            }
        ),
    )


def print_schema_info():
    """
    Print detailed schema information for documentation.

    Example:
        >>> from stocksstrategy.data.schemas import print_schema_info
        >>> print_schema_info()
        StockDataSchema Documentation
        ================================================================================

        Column: ts_code
          Type: str
          Nullable: True
          Checks: str_matches(^\\d{6}\\.(SH|SZ)$)
          Description: Stock code in Tushare format (e.g., 600519.SH)
        ...
    """
    print("StockDataSchema Documentation")
    print("=" * 80)
    print()

    schema = StockDataSchema.to_schema()
    for column_name, column_schema in schema.columns.items():
        print(f"Column: {column_name}")
        print(f"  Type: {column_schema.dtype}")
        print(f"  Nullable: {column_schema.nullable}")

        if column_schema.checks:
            # Avoid escape sequence warnings by converting checks to string representation
            for check in column_schema.checks:
                print(f"  Checks: {check!r}")

        if hasattr(column_schema, "description") and column_schema.description:
            print(f"  Description: {column_schema.description}")

        print()
