"""Data source protocol interfaces"""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING, Any, Protocol

import pandas as pd

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


class APIClient(Protocol):
    """Protocol interface for API clients"""

    def get_api(self) -> Any:
        """
        Get the underlying API instance with retry and error checking capabilities.

        Returns:
            The API instance (may be wrapped for automatic retry/error handling)
        """
        ...


class DataSource(Protocol):
    """Protocol interface for data sources"""

    def fetch(
        self,
        stock_code: str,
        start_date: date,
        end_date: date | None = None,
    ) -> ValidatedStockData:
        """
        Fetch stock data from data source.

        Args:
            stock_code: Stock code (e.g., 600519)
            start_date: Start date
            end_date: End date, default is today

        Returns:
            Validated DataFrame with stock data
        """
        ...

    def validate(self, data: pd.DataFrame) -> ValidatedStockData:
        """
        Validate data schema at system boundary.

        Args:
            data: Raw DataFrame from API

        Returns:
            Validated DataFrame

        Raises:
            ValidationError: If data doesn't match expected schema
        """
        ...

    def is_available(self) -> bool:
        """
        Check if the data source is available.

        Returns:
            True if the data source is reachable and ready
        """
        ...

    def get_listing_date(self, stock_code: str) -> date | None:
        """
        Get the listing date for a stock.

        Args:
            stock_code: Stock code (e.g., 600519)

        Returns:
            Listing date, or None if not found
        """
        ...
