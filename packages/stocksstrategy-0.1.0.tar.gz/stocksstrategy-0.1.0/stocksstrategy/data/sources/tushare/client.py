"""Tushare API client with retry mechanism"""

import os
from typing import Any, Callable

import pandas as pd
import tushare as ts  # type: ignore

from stocksstrategy.data.sources.tushare.constants import (
    DEFAULT_BASE_DELAY,
    DEFAULT_MAX_RETRIES,
)
from stocksstrategy.data.sources.tushare.exceptions import (
    TushareAPIError,
    TushareRateLimitError,
)
from stocksstrategy.data.sources.tushare.retry import with_retry


class TushareClient:
    """Tushare Pro API client with retry mechanism"""

    def __init__(
        self,
        token: str | None = None,
        max_retries: int | None = None,
        base_delay: float | None = None,
    ):
        """
        Initialize Tushare client.

        Args:
            token: Tushare Pro API token. If not provided, will be loaded from environment.
            max_retries: Maximum number of retry attempts (default: 3)
            base_delay: Base delay in seconds for exponential backoff (default: 1.0)
        """
        self._token = token
        self._api: Any = None
        self._max_retries = max_retries or DEFAULT_MAX_RETRIES
        self._base_delay = base_delay or DEFAULT_BASE_DELAY

    def _ensure_token(self) -> str:
        """Ensure token is available, load from env if needed."""
        if not self._token:
            self._token = os.environ.get("TUSHARE_TOKEN")
            if not self._token:
                raise ValueError(
                    "Tushare token not found. Please set TUSHARE_TOKEN environment variable. "
                    "You can get your token from https://tushare.pro/"
                )
        return self._token

    def get_api(self) -> Any:
        """
        Get or create Tushare Pro API instance with automatic retry and error checking.

        Returns:
            Wrapped Tushare Pro API instance with retry mechanism
        """
        if self._api is None:
            raw_api = ts.pro_api(self._ensure_token())
            self._api = self._wrap_api_with_retry(raw_api)
        return self._api

    def _wrap_api_with_retry(self, api: Any) -> Any:
        """
        Wrap API object so all method calls automatically include retry and error checking.

        Args:
            api: Raw Tushare Pro API instance

        Returns:
            Wrapped API instance
        """
        # Capture outer self to avoid scope confusion in nested class
        client = self

        class RetryWrapper:
            """Wrapper that adds retry logic to all API method calls"""

            def __getattr__(self, name: str) -> Callable[..., pd.DataFrame | None]:
                original_method = getattr(api, name)

                @with_retry(
                    max_retries=client._max_retries,
                    base_delay=client._base_delay,
                )
                def wrapped(*args: Any, **kwargs: Any) -> pd.DataFrame | None:
                    df = original_method(*args, **kwargs)
                    client._check_response(df)
                    return df

                return wrapped

        return RetryWrapper()

    def _check_response(self, df: pd.DataFrame | None) -> None:
        """
        Check if Tushare response contains an error.

        Tushare returns error as a DataFrame with 'code' and 'msg' columns
        instead of raising an exception.
        """
        if df is None or df.empty:
            return

        if "code" in df.columns and len(df) == 1:
            error_code = df.iloc[0].get("code")
            error_msg = df.iloc[0].get("msg", "")

            if error_code != 0 and error_code is not None:
                error_msg = f"Tushare API error {error_code}: {error_msg}"

                if error_code == 40003 or error_code == 40008:
                    raise TushareRateLimitError(error_msg)

                raise TushareAPIError(error_msg)

    def get_listing_date(self, stock_code: str) -> str | None:
        """
        Get the listing date for a stock.

        Args:
            stock_code: Stock code (e.g., "600519" or "600519.SH")

        Returns:
            Listing date as string (YYYYMMDD), or None if not found
        """
        # Format stock code
        if "." not in stock_code:
            ts_code = f"{stock_code}.SH"
        else:
            ts_code = stock_code

        api = self.get_api()
        df = api.stock_basic(ts_code=ts_code, fields="list_date")

        if df is None or df.empty:
            return None

        if "list_date" in df.columns and len(df) > 0:
            return df.iloc[0].get("list_date")

        return None
