"""Tushare API constants"""

# Tushare daily API maximum records per request
TUSHARE_MAX_RECORDS = 5000

# Delay between API requests to avoid rate limiting (seconds)
REQUEST_DELAY = 0.1

# Number of years per chunk when pagination is needed
YEAR_CHUNK = 10

# Retry configuration
DEFAULT_MAX_RETRIES = 3
DEFAULT_BASE_DELAY = 1.0  # seconds
