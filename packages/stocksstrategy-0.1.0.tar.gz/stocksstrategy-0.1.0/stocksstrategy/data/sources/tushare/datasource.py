"""Tushare data source implementation"""

from __future__ import annotations

import logging
from datetime import date
from typing import TYPE_CHECKING

import pandas as pd

from stocksstrategy.data.schemas import (
    create_empty_stock_dataframe,
    validate_stock_data,
)
from stocksstrategy.data.sources.tushare.client import TushareClient
from stocksstrategy.data.sources.tushare.fetcher import TushareFetcher
from stocksstrategy.data.utils.date import parse_date
from stocksstrategy.data.utils.stock import format_ts_code as _format_ts_code

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData

logger = logging.getLogger(__name__)


class TushareDataSource:
    """Tushare Pro API data source"""

    def __init__(
        self,
        token: str | None = None,
        max_retries: int | None = None,
        base_delay: float | None = None,
    ):
        """
        Initialize Tushare data source.

        Args:
            token: Tushare Pro API token. If not provided, will be loaded from environment.
            max_retries: Maximum number of retry attempts (default: 3)
            base_delay: Base delay in seconds for exponential backoff (default: 1.0)
        """
        self._client = TushareClient(
            token=token,
            max_retries=max_retries,
            base_delay=base_delay,
        )
        self._fetcher = TushareFetcher(self._client)

    def fetch(
        self,
        stock_code: str,
        start_date: date,
        end_date: date | None = None,
    ) -> ValidatedStockData:
        """
        Fetch stock data from Tushare with retry mechanism and automatic pagination.

        Args:
            stock_code: Stock code (e.g., 600519)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD), default is today

        Returns:
            Validated DataFrame with stock data
        """
        # 1. Parse parameters
        start = parse_date(start_date)
        if end_date:
            end = parse_date(end_date)
        else:
            end = date.today()

        # 2. Fetch raw data from API
        ts_code = self._format_stock_code(stock_code)
        raw_data = self._fetcher.fetch(ts_code, start, end)

        # 3. Validate at system boundary
        return self.validate(raw_data)

    def validate(self, data: pd.DataFrame) -> ValidatedStockData:
        """
        Validate data schema at system boundary.

        Args:
            data: Raw DataFrame from API

        Returns:
            Validated DataFrame

        Raises:
            pandera.errors.SchemaError: If data doesn't match expected schema
        """
        if data.empty:
            return create_empty_stock_dataframe()

        # Filter out rows with null or empty ts_code as defensive measure
        # (Tushare may return invalid data for delisted stocks)
        if "ts_code" in data.columns:
            original_len = len(data)
            data = data.copy()
            data = data[
                data["ts_code"].notna()
                & (data["ts_code"].astype(str).str.strip() != "")
                & (data["ts_code"].astype(str).str.lower() != "nan")
            ]
            if len(data) < original_len:
                logger.warning(
                    f"Filtered {original_len - len(data)} rows with null/empty ts_code"
                )

        return validate_stock_data(data)

    def is_available(self) -> bool:
        """
        Check if Tushare data source is available.

        Returns:
            True if the API client can be initialized and token is valid
        """
        try:
            self._client.get_api()
            return True
        except Exception:
            return False

    def _format_stock_code(self, stock_code: str) -> str:
        """
        Format stock code to Tushare format (internal method).

        Args:
            stock_code: Stock code (e.g., 600519)

        Returns:
            Formatted stock code (e.g., 600519.SH)
        """
        return _format_ts_code(stock_code)

    def get_listing_date(self, stock_code: str) -> date | None:
        """
        Get the listing date for a stock from Tushare.

        Args:
            stock_code: Stock code (e.g., 600519)

        Returns:
            Listing date, or None if not found
        """
        ts_code = self._format_stock_code(stock_code)
        list_date_str = self._client.get_listing_date(ts_code)

        if not list_date_str:
            return None

        # Convert from YYYYMMDD to date
        return date(
            year=int(list_date_str[:4]),
            month=int(list_date_str[4:6]),
            day=int(list_date_str[6:8]),
        )
