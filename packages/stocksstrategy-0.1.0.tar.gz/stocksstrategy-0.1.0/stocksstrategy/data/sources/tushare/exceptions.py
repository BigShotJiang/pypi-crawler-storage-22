"""Tushare API exceptions"""


class TushareAPIError(Exception):
    """Tushare API error"""

    pass


class TushareRateLimitError(TushareAPIError):
    """Tushare API rate limit exceeded"""

    pass
