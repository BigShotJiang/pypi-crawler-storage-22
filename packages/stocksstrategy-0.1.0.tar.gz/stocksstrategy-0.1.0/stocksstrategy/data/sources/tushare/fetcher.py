"""Tushare data fetcher with pagination support"""

import logging
import time
from datetime import date

import pandas as pd

from stocksstrategy.data.sources.base import APIClient
from stocksstrategy.data.sources.tushare.constants import REQUEST_DELAY, YEAR_CHUNK

logger = logging.getLogger(__name__)


def _split_date_range(
    start: date, end: date, chunk_years: int
) -> list[tuple[date, date]]:
    """
    Split date range into year chunks.

    Args:
        start: Start date
        end: End date
        chunk_years: Number of years per chunk

    Returns:
        List of (chunk_start, chunk_end) tuples
    """
    chunks: list[tuple[date, date]] = []
    current = start

    while current <= end:
        # Calculate chunk end: either chunk_years later or the final end date
        chunk_end = date(min(current.year + chunk_years - 1, end.year), 12, 31)
        chunk_end = min(chunk_end, end)

        chunks.append((current, chunk_end))

        # Move to next chunk: first day of the year after chunk_years
        next_year = current.year + chunk_years
        if next_year > end.year:
            break
        current = date(next_year, 1, 1)

    return chunks


class TushareFetcher:
    """Tushare data fetcher with pagination support"""

    def __init__(self, client: APIClient):
        """
        Initialize Tushare fetcher.

        Args:
            client: API client instance
        """
        self._client = client

    def fetch(
        self,
        ts_code: str,
        start_date: date,
        end_date: date,
    ) -> pd.DataFrame:
        """
        Fetch stock data from Tushare with automatic pagination.

        Args:
            ts_code: Formatted stock code (e.g., 600519.SH)
            start_date: Start date
            end_date: End date

        Returns:
            Raw DataFrame with stock data (validation done by DataSource layer)
        """
        df = self._fetch_by_chunk(ts_code, start_date, end_date)

        if df is None or df.empty:
            return pd.DataFrame()

        # Normalize column names: Tushare uses 'vol', we use 'volume'
        if "vol" in df.columns:
            df = df.rename(columns={"vol": "volume"})

        # Filter out rows with null or empty ts_code (Tushare may return invalid data for delisted stocks)
        if "ts_code" in df.columns:
            original_len = len(df)
            # Filter out both NaN (None) and string "nan"/"NaN"
            df = df[
                df["ts_code"].notna()
                & (df["ts_code"].str.lower() != "nan")
                & (df["ts_code"].str.strip() != "")
            ]
            if len(df) < original_len:
                logger.warning(
                    f"Filtered {original_len - len(df)} rows with null/empty ts_code for {ts_code}"
                )

        df["trade_date"] = pd.to_datetime(df["trade_date"]).dt.date

        return df

    def _fetch_single_page(
        self,
        ts_code: str,
        start: date,
        end: date,
    ) -> pd.DataFrame | None:
        """Fetch a single page of data (with automatic retry and error checking)."""
        pro = self._client.get_api()
        return pro.daily(
            ts_code=ts_code,
            start_date=start.isoformat().replace("-", ""),
            end_date=end.isoformat().replace("-", ""),
        )

    def _fetch_by_chunk(
        self,
        ts_code: str,
        start: date,
        end: date,
    ) -> pd.DataFrame | None:
        """Fetch data in year chunks."""
        all_dfs: list[pd.DataFrame] = []

        logger.info(
            f"Fetching {ts_code} from {start} to {end} in {YEAR_CHUNK}-year chunks..."
        )

        chunks = _split_date_range(start, end, YEAR_CHUNK)

        for chunk_start, chunk_end in chunks:
            logger.debug(
                f"Fetching {ts_code} for {chunk_start.year}-{chunk_end.year}..."
            )

            df = self._fetch_single_page(ts_code, chunk_start, chunk_end)

            if df is not None and not df.empty:
                all_dfs.append(df)
            else:
                logger.debug(
                    f"No data returned for {ts_code} from {chunk_start} to {chunk_end}"
                )

            time.sleep(REQUEST_DELAY)

        if not all_dfs:
            logger.warning(
                f"No data available for {ts_code} from {start} to {end} "
                f"(stock may not be listed during this period)"
            )
            return pd.DataFrame()

        combined = pd.concat(all_dfs, ignore_index=True)
        combined = combined.drop_duplicates(subset=["trade_date"], keep="last")
        combined = combined.sort_values("trade_date").reset_index(drop=True)

        return combined
