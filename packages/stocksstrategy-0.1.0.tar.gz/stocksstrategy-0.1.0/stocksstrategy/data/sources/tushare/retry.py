"""Retry utilities for API calls using tenacity"""

import logging
from typing import Callable, TypeVar

from requests.exceptions import RequestException
from tenacity import (
    after_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from stocksstrategy.data.sources.tushare.exceptions import TushareRateLimitError

logger = logging.getLogger(__name__)

T = TypeVar("T")


def with_retry(
    max_retries: int = 3,
    base_delay: float = 1.0,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator to add retry logic with exponential backoff using tenacity.

    Uses exponential backoff: base_delay * 2^(attempt - 1)
    Wait time is clamped between 1 and 10 seconds.

    Args:
        max_retries: Maximum number of retry attempts (default: 3)
        base_delay: Base delay in seconds for exponential backoff (default: 1.0)

    Returns:
        Decorated function with retry logic

    Example:
        @with_retry(max_retries=3, base_delay=1.0)
        def fetch_data():
            # Retries on TushareRateLimitError, RequestException, OSError
            # Wait times: 1s, 2s, 4s (clamped at 10s max)
            ...
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        return retry(
            retry=retry_if_exception_type(
                (TushareRateLimitError, RequestException, OSError)
            ),
            stop=stop_after_attempt(max_retries),
            wait=wait_exponential(multiplier=base_delay, min=1, max=10),
            after=after_log(logger, logging.WARNING),
            reraise=True,
        )(func)

    return decorator
