"""Parquet storage for stock data with partitioning support."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, cast

import pandas as pd

from stocksstrategy.data.schemas import (
    create_empty_stock_dataframe,
    validate_stock_data,
)
from stocksstrategy.data.storage.protocols import DataStorage

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData

logger = logging.getLogger(__name__)


class ParquetStorage(DataStorage):
    """Storage for stock data in Parquet format with year-based partitioning."""

    def __init__(self, data_dir: Path):
        """
        Initialize Parquet storage.

        Args:
            data_dir: Directory to store parquet files
        """
        self._data_dir = data_dir
        self._data_dir.mkdir(parents=True, exist_ok=True)

    def _get_path(self, key: str, partition_key: str | None = None) -> Path:
        """
        Get parquet file path with optional partitioning.

        Args:
            key: Storage key (e.g., "600519.SH")
            partition_key: Optional partition key (e.g., "2024")

        Returns:
            Path to parquet file
        """
        if partition_key:
            # Partitioned: data/600519.SH/2024.parquet
            return self._data_dir / key / f"{partition_key}.parquet"
        else:
            # Non-partitioned: data/600519.SH/data.parquet
            return self._data_dir / key / "data.parquet"

    def save(
        self, key: str, data: ValidatedStockData, partition_key: str | None = None
    ) -> None:
        """
        Save stock data to parquet file with schema validation.

        Args:
            key: Storage key
            data: DataFrame with stock data
            partition_key: Optional partition key for year-based partitioning

        Raises:
            pandera.errors.SchemaError: If data doesn't match expected schema
        """
        if data.empty:
            return

        # Defensive: filter out rows with null ts_code before validation
        # This handles cases where local data may have been corrupted
        if "ts_code" in data.columns:
            original_len = len(data)
            data = data[
                data["ts_code"].notna()
                & (data["ts_code"].astype(str).str.strip() != "")
            ]
            if len(data) < original_len:
                logger.warning(
                    f"Filtered {original_len - len(data)} rows with null ts_code before saving {key}"
                )

        if data.empty:
            return

        # Validate data before saving
        logger.debug(f"Validating data before saving {key}")
        validated_data = validate_stock_data(data)

        # Extract stock code from key (e.g., "600519.SH")
        # Fill ts_code temporarily for schema validation, then remove it
        validated_data["ts_code"] = key
        validated_data = validate_stock_data(validated_data)

        # Remove ts_code column - it's redundant since directory name contains the stock code
        if "ts_code" in validated_data.columns:
            validated_data = validated_data.drop(columns=["ts_code"])

        parquet_path = self._get_path(key, partition_key)
        parquet_path.parent.mkdir(parents=True, exist_ok=True)

        validated_data.to_parquet(parquet_path, index=False)
        logger.debug(f"Saved {len(validated_data)} rows to {parquet_path}")

    def load(
        self, key: str, partition_keys: list[str] | None = None
    ) -> ValidatedStockData:
        """
        Load stock data from parquet files.

        Args:
            key: Storage key
            partition_keys: Optional list of partition keys to load

        Returns:
            DataFrame with stock data, empty DataFrame if not found
        """
        if partition_keys:
            # Load from specific partitions and merge
            dfs: list[pd.DataFrame] = []
            for pk in partition_keys:
                path = self._get_path(key, pk)
                if path.exists():
                    logger.debug(f"Loading data from partition {pk}: {path}")
                    dfs.append(pd.read_parquet(path))  # type: ignore[misc]

            if dfs:
                return cast("ValidatedStockData", pd.concat(dfs, ignore_index=True))
            else:
                logger.debug(f"No partitions found for {key}")
                return create_empty_stock_dataframe()
        else:
            # Load from default location (non-partitioned)
            parquet_path = self._get_path(key)
            if not parquet_path.exists():
                logger.debug(f"Parquet file not found: {parquet_path}")
                return create_empty_stock_dataframe()

            logger.debug(f"Loading data from {parquet_path}")
            return pd.read_parquet(parquet_path)  # type: ignore[misc]

    def list_partitions(self, key: str) -> list[str]:
        """
        List available year partitions for a key.

        Args:
            key: Storage key

        Returns:
            List of partition keys (e.g., ["2024", "2025"])
        """
        stock_dir = self._data_dir / key
        if not stock_dir.exists():
            return []

        partitions: list[str] = []
        for item in stock_dir.iterdir():
            # Check if it's a .parquet file (e.g., "2024.parquet")
            if item.is_file() and item.suffix == ".parquet":
                # Extract year from filename (e.g., "2024.parquet" -> "2024")
                partitions.append(item.stem)

        return sorted(partitions)

    def exists(self, key: str, partition_key: str | None = None) -> bool:
        """
        Check if parquet file exists.

        Args:
            key: Storage key
            partition_key: Optional partition key

        Returns:
            True if file exists
        """
        return self._get_path(key, partition_key).exists()

    def delete(self, key: str, partition_key: str | None = None) -> None:
        """
        Delete parquet file or entire stock directory.

        Args:
            key: Storage key
            partition_key: Optional partition key (if None, delete all)
        """
        if partition_key:
            # Delete specific partition
            partition_path = self._get_path(key, partition_key)
            if partition_path.exists():
                partition_path.unlink()
                # Clean up empty directories
                partition_path.parent.rmdir()
        else:
            # Delete entire stock directory
            stock_dir = self._data_dir / key
            if stock_dir.exists():
                import shutil

                shutil.rmtree(stock_dir)
