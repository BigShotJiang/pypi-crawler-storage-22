"""Storage layer protocol definitions."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

from stocksstrategy.data.types import DatasetMetadata

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


class DataStorage(Protocol):
    """Protocol for stock data persistence with partitioning support."""

    def save(
        self, key: str, data: ValidatedStockData, partition_key: str | None = None
    ) -> None:
        """
        Save data to specific partition.

        Args:
            key: Storage key (e.g., "600519.SH")
            data: DataFrame to save
            partition_key: Optional partition key (e.g., "2024" for year)
        """
        ...

    def load(
        self, key: str, partition_keys: list[str] | None = None
    ) -> ValidatedStockData:
        """
        Load data from partitions.

        Args:
            key: Storage key
            partition_keys: Optional list of partition keys to load

        Returns:
            DataFrame with data from specified partitions
        """
        ...

    def list_partitions(self, key: str) -> list[str]:
        """
        List available partitions for a key.

        Args:
            key: Storage key

        Returns:
            List of partition keys
        """
        ...

    def exists(self, key: str, partition_key: str | None = None) -> bool:
        """
        Check if partition exists.

        Args:
            key: Storage key
            partition_key: Optional partition key

        Returns:
            True if data exists
        """
        ...

    def delete(self, key: str, partition_key: str | None = None) -> None:
        """
        Delete specific partition or all data.

        Args:
            key: Storage key
            partition_key: Optional partition key (if None, delete all)
        """
        ...


class MetadataStorage(Protocol):
    """Protocol for dataset metadata persistence."""

    def save_metadata(self, key: str, metadata: DatasetMetadata) -> None:
        """
        Atomically save metadata.

        Args:
            key: Storage key
            metadata: Dataset metadata to save
        """
        ...

    def get_metadata(self, key: str) -> DatasetMetadata | None:
        """
        Get dataset metadata.

        Args:
            key: Storage key

        Returns:
            Dataset metadata or None if not found
        """
        ...

    def exists(self, key: str) -> bool:
        """
        Check if metadata exists.

        Args:
            key: Storage key

        Returns:
            True if metadata exists
        """
        ...

    def delete_metadata(self, key: str) -> None:
        """
        Delete metadata.

        Args:
            key: Storage key
        """
        ...

    def list_all_keys(self) -> list[str]:
        """
        List all dataset keys that have metadata.

        Returns:
            List of storage keys (e.g., ["600519.SH", "000001.SZ"])
            sorted by ts_code
        """
        ...
