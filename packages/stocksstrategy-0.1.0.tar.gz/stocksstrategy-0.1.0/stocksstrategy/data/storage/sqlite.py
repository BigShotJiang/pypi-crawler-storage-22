"""SQLite storage for dataset metadata.

This module manages the conversion between two representations:
1. ORM Model (StockIndex): SQLAlchemy model for database persistence
2. Domain Type (DatasetMetadata): Business logic dataclass

Type Mapping:
    StockIndex (ORM)              <->  DatasetMetadata (Domain)
    ─────────────────────────────────────────────────────────────
    ts_code: str                  <->  key: str
    start_date: date              <->  date_range.start_date: date
    end_date: date                <->  date_range.end_date: date
    row_count: int                <->  row_count: int
    updated_at: date              <->  last_updated: date
"""

from contextlib import contextmanager
from datetime import date
from pathlib import Path
from typing import Generator

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session, sessionmaker

from stocksstrategy.data.orm import Base, StockIndex
from stocksstrategy.data.storage.protocols import MetadataStorage
from stocksstrategy.data.types import DatasetMetadata, DateRange


class SqliteMetadataStorage(MetadataStorage):
    """Storage for dataset metadata in SQLite.

    Handles bidirectional conversion between:
    - StockIndex (SQLAlchemy ORM model for database)
    - DatasetMetadata (domain dataclass for business logic)
    """

    def __init__(self, db_path: Path):
        """
        Initialize SQLite metadata storage.

        Args:
            db_path: Path to SQLite database file
        """
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._engine = create_engine(f"sqlite:///{self._db_path}")
        self._session_factory = sessionmaker(bind=self._engine)
        Base.metadata.create_all(self._engine)

    @property
    def engine(self):
        """Get SQLAlchemy engine."""
        return self._engine

    @contextmanager
    def _session(self) -> Generator[Session, None, None]:
        """Get a database session with automatic cleanup."""
        session = self._session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def save_metadata(self, key: str, metadata: DatasetMetadata) -> None:
        """
        Atomically save dataset metadata.

        Converts DatasetMetadata -> StockIndex for database storage.

        Args:
            key: Storage key (e.g., "600519.SH")
            metadata: Dataset metadata to save
        """
        with self._session() as session:
            index = session.query(StockIndex).filter(StockIndex.ts_code == key).first()

            if index:
                # Update existing
                index.start_date = (
                    metadata.date_range.start_date
                    if metadata.date_range
                    else date.today()
                )
                index.end_date = (
                    metadata.date_range.end_date
                    if metadata.date_range
                    else date.today()
                )
                index.updated_at = metadata.last_updated
                index.row_count = metadata.row_count
            else:
                # Insert new
                index = StockIndex(
                    ts_code=key,
                    start_date=(
                        metadata.date_range.start_date
                        if metadata.date_range
                        else date.today()
                    ),
                    end_date=(
                        metadata.date_range.end_date
                        if metadata.date_range
                        else date.today()
                    ),
                    updated_at=metadata.last_updated,
                    row_count=metadata.row_count,
                )
                session.add(index)

    def get_metadata(self, key: str) -> DatasetMetadata | None:
        """
        Get dataset metadata.

        Converts StockIndex -> DatasetMetadata for business logic.

        Args:
            key: Storage key

        Returns:
            Dataset metadata or None if not found
        """
        with self._session() as session:
            index = session.query(StockIndex).filter(StockIndex.ts_code == key).first()
            if not index:
                return None

            # Convert ORM model to domain type
            return DatasetMetadata(
                key=key,
                date_range=DateRange(
                    start_date=index.start_date, end_date=index.end_date
                ),
                row_count=index.row_count,
                last_updated=index.updated_at,
            )

    def exists(self, key: str) -> bool:
        """
        Check if metadata exists.

        Args:
            key: Storage key

        Returns:
            True if metadata exists
        """
        with self._session() as session:
            stmt = select(StockIndex.ts_code).where(StockIndex.ts_code == key)
            return session.execute(stmt).first() is not None

    def delete_metadata(self, key: str) -> None:
        """
        Delete metadata.

        Args:
            key: Storage key
        """
        with self._session() as session:
            index = session.query(StockIndex).filter(StockIndex.ts_code == key).first()
            if index:
                session.delete(index)

    def list_all_keys(self) -> list[str]:
        """
        List all dataset keys that have metadata.

        Returns:
            List of storage keys sorted by ts_code
        """
        with self._session() as session:
            stmt = select(StockIndex.ts_code).order_by(StockIndex.ts_code)
            result = session.execute(stmt).scalars().all()
            return list(result)
