"""Data acquisition strategy module."""

from stocksstrategy.data.strategy.default import DefaultAcquisitionStrategy
from stocksstrategy.data.strategy.protocols import DataAcquisitionStrategy

__all__ = ["DataAcquisitionStrategy", "DefaultAcquisitionStrategy"]
