"""Default data acquisition strategy implementation."""

from __future__ import annotations

from datetime import date, timedelta
from typing import TYPE_CHECKING, cast

import pandas as pd

from stocksstrategy.data.strategy.protocols import DataAcquisitionStrategy
from stocksstrategy.data.types import DatasetMetadata, DateRange

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


class DefaultAcquisitionStrategy(DataAcquisitionStrategy):
    """Default strategy with validity-based caching and incremental updates."""

    def __init__(self, validity_days: int = 7, max_gap_days: int = 30):
        """
        Initialize the default acquisition strategy.

        Args:
            validity_days: Number of days local data is considered valid
            max_gap_days: Maximum gap for incremental update (vs full refresh)
        """
        self.validity_days = validity_days
        self.max_gap_days = max_gap_days

    def is_local_data_valid(
        self,
        metadata: DatasetMetadata | None,
        requested_range: DateRange,
    ) -> bool:
        """Local data is valid if it fully covers requested range and is not stale.

        Validity criteria:
        1. Local data exists
        2. Local data fully covers the requested range
        3. Local data is not stale (updated within validity_days)
        """
        if not metadata or not metadata.date_range:
            return False

        # Check if data is stale
        days_since_update = (date.today() - metadata.last_updated).days
        if days_since_update > self.validity_days:
            return False

        # Check if local range covers requested range
        local_range = metadata.date_range
        return (
            local_range.start_date <= requested_range.start_date
            and local_range.end_date >= requested_range.end_date
        )

    def calculate_fetch_ranges(
        self,
        local_range: DateRange | None,
        requested_range: DateRange,
    ) -> list[DateRange]:
        """Calculate missing ranges (before start or after end)."""
        if not local_range:
            return [requested_range]

        ranges: list[DateRange] = []

        # Need data before local range
        if requested_range.start_date < local_range.start_date:
            ranges.append(
                DateRange(
                    start_date=requested_range.start_date,
                    end_date=local_range.start_date - timedelta(days=1),
                )
            )

        # Need data after local range
        if requested_range.end_date > local_range.end_date:
            ranges.append(
                DateRange(
                    start_date=local_range.end_date + timedelta(days=1),
                    end_date=requested_range.end_date,
                )
            )

        return ranges

    def should_use_incremental_update(
        self,
        local_range: DateRange | None,
        requested_range: DateRange,
        gap_days: int,
    ) -> bool:
        """Use incremental if gap is small, full refresh if gap is large."""
        if not local_range:
            return False

        return gap_days <= self.max_gap_days

    def merge_data(
        self,
        local_data: ValidatedStockData,
        new_data: ValidatedStockData,
    ) -> ValidatedStockData:
        """Merge and deduplicate data (logic from cache/utils.py)."""
        if local_data.empty:
            return new_data.copy()
        if new_data.empty:
            return local_data.copy()

        # Create copies to avoid modifying originals
        new_df = new_data.copy()
        existing_df = local_data.copy()

        # Ensure datetime type for proper comparison
        if new_df["trade_date"].dtype == "object":
            new_df["trade_date"] = pd.to_datetime(new_df["trade_date"])
        if existing_df["trade_date"].dtype == "object":
            existing_df["trade_date"] = pd.to_datetime(existing_df["trade_date"])

        # Concatenate and remove duplicates
        merged = pd.concat([existing_df, new_df], ignore_index=True)
        merged = merged.drop_duplicates(subset=["trade_date"], keep="last")
        merged = merged.sort_values("trade_date").reset_index(drop=True)

        return cast("ValidatedStockData", merged)

    def filter_by_range(
        self,
        data: ValidatedStockData,
        start_date: date,
        end_date: date,
    ) -> ValidatedStockData:
        """Filter data by date range (logic from cache/utils.py)."""
        if data.empty:
            return data

        # Create copy and ensure proper date type
        df = data.copy()
        if df["trade_date"].dtype == "object":
            df["trade_date"] = pd.to_datetime(df["trade_date"]).dt.date

        # Filter by date range
        mask = (df["trade_date"] >= start_date) & (df["trade_date"] <= end_date)
        return df[mask].reset_index(drop=True)
