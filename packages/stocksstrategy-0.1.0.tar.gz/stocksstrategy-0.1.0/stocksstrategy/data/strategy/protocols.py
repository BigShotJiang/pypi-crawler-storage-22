"""Protocol definitions for data acquisition strategies."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING, Protocol

from stocksstrategy.data.types import DatasetMetadata, DateRange

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


class DataAcquisitionStrategy(Protocol):
    """Protocol for data acquisition decision logic."""

    def is_local_data_valid(
        self,
        metadata: DatasetMetadata | None,
        requested_range: DateRange,
    ) -> bool:
        """
        Determine if local data is valid for the request.

        Args:
            metadata: Metadata of locally stored data
            requested_range: Date range being requested

        Returns:
            True if local data fully covers the requested range
        """
        ...

    def calculate_fetch_ranges(
        self,
        local_range: DateRange | None,
        requested_range: DateRange,
    ) -> list[DateRange]:
        """
        Calculate missing date ranges to fetch.

        Args:
            local_range: Date range of local data (None if no local data)
            requested_range: Date range being requested

        Returns:
            List of date ranges that need to be fetched
        """
        ...

    def should_use_incremental_update(
        self,
        local_range: DateRange | None,
        requested_range: DateRange,
        gap_days: int,
    ) -> bool:
        """
        Decide between incremental update vs full refresh.

        Args:
            local_range: Date range of local data
            requested_range: Date range being requested
            gap_days: Number of days gap between local and requested

        Returns:
            True to use incremental update, False for full refresh
        """
        ...

    def merge_data(
        self,
        local_data: ValidatedStockData,
        new_data: ValidatedStockData,
    ) -> ValidatedStockData:
        """
        Merge local and new data with deduplication.

        Args:
            local_data: Existing local data
            new_data: Newly fetched data

        Returns:
            Merged and deduplicated DataFrame
        """
        ...

    def filter_by_range(
        self,
        data: ValidatedStockData,
        start_date: date,
        end_date: date,
    ) -> ValidatedStockData:
        """
        Filter data by date range.

        Args:
            data: DataFrame to filter
            start_date: Start date (inclusive)
            end_date: End date (inclusive)

        Returns:
            Filtered DataFrame
        """
        ...
