"""Core type definitions for the data layer architecture."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from stocksstrategy.data.schemas import ValidatedStockData


@dataclass
class DateRange:
    """Represents a date range with start and end dates."""

    start_date: date
    end_date: date


@dataclass
class DataParams:
    """Parameters for data queries."""

    stock_code: str
    start_date: date
    end_date: date
    fields: list[str] | None = None


@dataclass
class DatasetMetadata:
    """Metadata about a cached dataset."""

    key: str
    date_range: DateRange | None
    row_count: int
    last_updated: date
    version: int = 1


@dataclass
class DataResult:
    """Result of a data query with source indicator."""

    data: ValidatedStockData
    source: Literal["cache", "partial", "remote"]
    """Source of the data:
    - cache: 100% from local storage
    - partial: Merged from local + remote
    - remote: 100% fetched from external source
    """
    metadata: DatasetMetadata | None = None
