"""Date utility functions"""

from datetime import date


def parse_date(date_input: str | date) -> date:
    """
    Parse date from string or date object.

    Args:
        date_input: Date string (YYYY-MM-DD) or date object

    Returns:
        date object

    Raises:
        ValueError: If date string format is invalid
    """
    if isinstance(date_input, date):
        return date_input
    return date.fromisoformat(date_input)
