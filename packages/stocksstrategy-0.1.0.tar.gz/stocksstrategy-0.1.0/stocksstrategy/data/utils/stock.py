"""Stock code utility functions"""


def format_ts_code(stock_code: str) -> str:
    """
    Format stock code to Tushare format (e.g., 600519 -> 600519.SH).

    Args:
        stock_code: Stock code (e.g., 600519)

    Returns:
        Formatted stock code with exchange suffix (e.g., 600519.SH)
    """
    stock_code = stock_code.strip()
    # 上海证券交易所: 6, 5, 9 开头
    # 深圳证券交易所: 0, 3 开头
    # 北京证券交易所: 430, 830, 838 开头
    # 注意: 4, 8 开头是三板/退市整理板，不是北京交易所
    if stock_code.startswith(("6", "5", "9")):
        return f"{stock_code}.SH"  # 上海
    elif stock_code.startswith(("0", "3")):
        return f"{stock_code}.SZ"  # 深圳
    elif stock_code.startswith(("430", "830", "838")):
        return f"{stock_code}.BJ"  # 北京
    else:
        # 默认当作上海
        return f"{stock_code}.SH"


def parse_ts_code(ts_code: str) -> str:
    """
    Parse Tushare code to get raw stock code (e.g., 600519.SH -> 600519).

    Args:
        ts_code: Tushare formatted stock code (e.g., 600519.SH)

    Returns:
        Raw stock code without exchange suffix
    """
    if "." in ts_code:
        return ts_code.split(".")[0]
    return ts_code
