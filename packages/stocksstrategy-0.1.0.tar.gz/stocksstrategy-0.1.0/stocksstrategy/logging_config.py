"""Logging configuration for StocksStrategy.

Console output (WARNING+) + File output (DEBUG+) with hourly rotation.
"""

import logging
import logging.handlers
from pathlib import Path
from typing import Any

# Log directory
LOG_DIR = Path.home() / ".stocksstrategy" / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

# Log file settings
LOG_FILE = LOG_DIR / "stocksstrategy.log"
LOG_FORMAT_CONSOLE = "%(message)s"
LOG_FORMAT_FILE = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Log levels
CONSOLE_LEVEL = logging.WARNING
FILE_LEVEL = logging.DEBUG

# Global logger instance
_loggers: dict[str, logging.Logger] = {}

# Track if logging has been initialized
_logging_initialized: bool = False


class ClickEchoHandler(logging.Handler):
    """Custom handler that outputs via click.echo for consistent CLI formatting."""

    def __init__(self, level: int = logging.NOTSET) -> None:
        super().__init__(level)
        self._use_err = False

    def set_err_mode(self, is_error: bool) -> None:
        """Set whether to output to stderr."""
        self._use_err = is_error

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record via click.echo."""
        try:
            msg = self.format(record)
            click = __import__("click")
            click.echo(msg, err=self._use_err)
        except Exception:  # noqa: BLE001
            self.handleError(record)


def setup_logging(
    name: str = "stocksstrategy",
    level: int = FILE_LEVEL,
    log_file: Path | None = None,
) -> logging.Logger:
    """Setup logging with console and file handlers.

    Args:
        name: Logger name
        level: File handler logging level
        log_file: Custom log file path (default: ~/.stocksstrategy/logs/stocksstrategy.log)

    Returns:
        Configured logger instance
    """
    global _logging_initialized
    if _logging_initialized:
        return logging.getLogger(name)

    # Configure root logger to capture all stocksstrategy.* loggers
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.handlers.clear()

    # File handler: DEBUG+, hourly rotation
    file_path = log_file or LOG_FILE
    file_handler = logging.handlers.TimedRotatingFileHandler(
        filename=file_path,
        when="h",  # Hourly rotation
        interval=1,
        backupCount=24 * 7,  # Keep 7 days of hourly logs
        encoding="utf-8",
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(logging.Formatter(LOG_FORMAT_FILE, datefmt=DATE_FORMAT))
    root_logger.addHandler(file_handler)

    # Console handler: WARNING+, click.echo style
    console_handler = ClickEchoHandler(CONSOLE_LEVEL)
    console_handler.setFormatter(logging.Formatter(LOG_FORMAT_CONSOLE))
    root_logger.addHandler(console_handler)

    # Return the stocksstrategy logger
    logger = logging.getLogger(name)
    _loggers[name] = logger
    _logging_initialized = True
    return logger


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Logger instance
    """
    if name not in _loggers:
        _loggers[name] = logging.getLogger(name)
    return _loggers[name]


def log_exception(logger: logging.Logger, msg: str, *args: Any, **kwargs: Any) -> None:
    """Log an exception with traceback."""
    logger.exception(msg, *args, **kwargs)


# ============================================================================
# CLI Logging Helpers - Output to both console and file
# ============================================================================


def cli_info(message: str) -> None:
    """Log info message to console and file."""
    click = __import__("click")
    click.echo(message)
    # Also log to file
    logging.getLogger("stocksstrategy.cli").info(message)


def cli_success(message: str) -> None:
    """Log success message to console and file."""
    cli_info(message)


def cli_warning(message: str) -> None:
    """Log warning message to console (stderr) and file."""
    click = __import__("click")
    click.echo(message, err=True)
    logging.getLogger("stocksstrategy.cli").warning(message)


def cli_error(message: str) -> None:
    """Log error message to console (stderr) and file."""
    click = __import__("click")
    click.echo(message, err=True)
    logging.getLogger("stocksstrategy.cli").error(message)


def cli_detail(message: str) -> None:
    """Log detail message to file only (not console)."""
    logging.getLogger("stocksstrategy.cli").debug(message)
