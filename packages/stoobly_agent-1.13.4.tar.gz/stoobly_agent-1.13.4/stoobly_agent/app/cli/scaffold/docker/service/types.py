from typing import TypedDict

class BuildDecoratorOptions(TypedDict):
  build_args: list