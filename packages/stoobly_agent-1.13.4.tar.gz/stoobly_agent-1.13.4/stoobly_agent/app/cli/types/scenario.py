from .test import TestOptions

class ScenarioTestOptions(TestOptions):
  key: str