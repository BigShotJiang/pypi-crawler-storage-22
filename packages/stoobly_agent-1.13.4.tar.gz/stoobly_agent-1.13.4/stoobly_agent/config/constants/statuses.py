REQUESTS_MODIFIED = 'requests-modified'
SETTINGS_MODIFIED = 'settings-modified'