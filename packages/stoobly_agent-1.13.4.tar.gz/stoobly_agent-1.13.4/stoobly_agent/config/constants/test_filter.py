from typing import Literal

ALL = 'all'
ALIAS = 'alias'
LINK = 'link'

TestFilter = Literal[ALL, ALIAS, LINK]