from typing import TypedDict

class ResponseColumns(TypedDict):
  raw: bytes
  request_id: int