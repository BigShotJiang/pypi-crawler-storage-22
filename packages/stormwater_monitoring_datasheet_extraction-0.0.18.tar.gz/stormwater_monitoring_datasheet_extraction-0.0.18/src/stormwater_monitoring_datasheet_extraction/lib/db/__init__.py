"""DB module for CRUD operations."""
