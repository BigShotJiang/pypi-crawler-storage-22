from ..decorators.measure_time import measure_time as measure_time
from ..io.path import clean_path as clean_path, relative_path as relative_path
from ..print.message import error as error, info as info, warning as warning
from .utils import test_module_with_progress as test_module_with_progress
from doctest import TestResults as TestResults

def launch_tests(root_dir: str, strict: bool = True, pattern: str = '*') -> int:
    ''' Main function to launch tests for all modules in the given directory.

\tArgs:
\t\troot_dir\t(str):\t\tRoot directory to search for modules
\t\tstrict\t\t(bool):\t\tModify the FORCE_RAISE_EXCEPTION configuration to True
\t\tpattern\t\t(str):\t\tPattern to filter module names (fnmatch style, e.g., \'*typ*\', \'io\', etc.)

\tReturns:
\t\tint: The number of failed tests

\tExamples:
\t\t>>> launch_tests("unknown_dir")
\t\tTraceback (most recent call last):
\t\t\t...
\t\tValueError: No modules found in \'unknown_dir\'

\t.. code-block:: python

\t\t> if launch_tests("/path/to/source") > 0:
\t\t\tsys.exit(1)
\t\t[PROGRESS HH:MM:SS] Importing module \'module1\'\ttook 0.001s
\t\t[PROGRESS HH:MM:SS] Importing module \'module2\'\ttook 0.002s
\t\t[PROGRESS HH:MM:SS] Importing module \'module3\'\ttook 0.003s
\t\t[PROGRESS HH:MM:SS] Importing module \'module4\'\ttook 0.004s
\t\t[INFO HH:MM:SS] Testing 4 modules...
\t\t[PROGRESS HH:MM:SS] Testing module \'module1\'\ttook 0.005s
\t\t[PROGRESS HH:MM:SS] Testing module \'module2\'\ttook 0.006s
\t\t[PROGRESS HH:MM:SS] Testing module \'module3\'\ttook 0.007s
\t\t[PROGRESS HH:MM:SS] Testing module \'module4\'\ttook 0.008s
\t'''
