from ..decorators.handle_error import handle_error as handle_error

@handle_error
def repair_zip_file(file_path: str, destination: str) -> bool:
    ''' Try to repair a corrupted zip file by ignoring some of the errors

\tThis function manually parses the ZIP file structure to extract files
\teven when the ZIP file is corrupted. It reads the central directory
\tentries and attempts to decompress each file individually.

\tArgs:
\t\tfile_path\t\t(str):\tPath of the zip file to repair
\t\tdestination\t\t(str):\tDestination of the new file
\tReturns:
\t\tbool: Always returns True unless any strong error

\tExamples:

\t.. code-block:: python

\t\t> repair_zip_file("/path/to/source.zip", "/path/to/destination.zip")
\t'''
