from .common import AbstractBothContextManager as AbstractBothContextManager
from typing import Any, IO

class Muffle(AbstractBothContextManager['Muffle']):
    ''' Context manager that temporarily silences output.
\t(No thread-safety guaranteed)

\tAlternative to :py:deco:`~stouputils.decorators.silent`

\tExamples:
\t\t>>> with Muffle():
\t\t...     print("This will not be printed")
\t'''
    mute_stderr: bool
    original_stdout: IO[Any]
    original_stderr: IO[Any]
    def __init__(self, mute_stderr: bool = False) -> None: ...
    def __enter__(self) -> Muffle:
        """ Enter context manager which redirects stdout and stderr to devnull """
    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any | None) -> None:
        """ Exit context manager which restores original stdout and stderr """
    async def __aenter__(self) -> Muffle:
        """ Enter async context manager which redirects stdout and stderr to devnull """
    async def __aexit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any | None) -> None:
        """ Exit async context manager which restores original stdout and stderr """
