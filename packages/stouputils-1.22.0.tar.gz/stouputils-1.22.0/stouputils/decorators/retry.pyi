from ..print.message import warning as warning
from .common import get_function_name as get_function_name, get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from collections.abc import Callable as Callable
from typing import Any, overload

@overload
def retry[T](func: Callable[..., T], *, exceptions: tuple[type[BaseException], ...] | type[BaseException] = ..., max_attempts: int | None = 10, delay: float = 1.0, backoff: float = 1.0, message: str = '', on_each_failure: Callable[[BaseException, int], Any] | None = None) -> Callable[..., T]: ...
@overload
def retry[T](func: None = None, *, exceptions: tuple[type[BaseException], ...] | type[BaseException] = ..., max_attempts: int | None = 10, delay: float = 1.0, backoff: float = 1.0, message: str = '', on_each_failure: Callable[[BaseException, int], Any] | None = None) -> Callable[[Callable[..., T]], Callable[..., T]]: ...
