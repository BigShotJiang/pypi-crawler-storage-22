from ..typing import JsonList as JsonList
from .common import get_function_name as get_function_name, get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from collections.abc import Callable as Callable
from typing import overload

@overload
def timeout[T](func: Callable[..., T], *, seconds: float = 60.0, message: str = '') -> Callable[..., T]: ...
@overload
def timeout[T](func: None = None, *, seconds: float = 60.0, message: str = '') -> Callable[[Callable[..., T]], Callable[..., T]]: ...
