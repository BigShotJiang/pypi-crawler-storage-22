import numpy as np
from PIL import Image
from collections.abc import Callable
from numpy.typing import NDArray as NDArray
from typing import Any

def auto_crop[T: Image.Image | NDArray[np.number]](image: T, mask: NDArray[np.bool_] | None = None, threshold: int | float | Callable[[NDArray[np.number]], int | float] | None = None, return_type: type[T] | str = 'same', contiguous: bool = True) -> Any:
    ''' Automatically crop an image to remove zero or uniform regions.

\tThis function crops the image to keep only the region where pixels are non-zero
\t(or above a threshold). It can work with a mask or directly analyze the image.

\tArgs:
\t\timage       (Image.Image | NDArray):\t  The image to crop.
\t\tmask        (NDArray[bool] | None):       Optional binary mask indicating regions to keep.
\t\tthreshold   (int | float | Callable):     Threshold value or function (default: np.min).
\t\treturn_type (type | str):                 Type of the return value (Image.Image, NDArray[np.number], or "same" to match input type).
\t\tcontiguous  (bool):                       If True (default), crop to bounding box. If False, remove entire rows/columns with no content.
\tReturns:
\t\tImage.Image | NDArray[np.number]: The cropped image.

\tExamples:
\t\t>>> # Test with numpy array with zeros on edges
\t\t>>> import numpy as np
\t\t>>> array = np.zeros((100, 100, 3), dtype=np.uint8)
\t\t>>> array[20:80, 30:70] = 255  # White rectangle in center
\t\t>>> cropped = auto_crop(array, return_type=np.ndarray)
\t\t>>> cropped.shape
\t\t(60, 40, 3)

\t\t>>> # Test with custom mask
\t\t>>> mask = np.zeros((100, 100), dtype=bool)
\t\t>>> mask[10:90, 10:90] = True
\t\t>>> cropped_with_mask = auto_crop(array, mask=mask, return_type=np.ndarray)
\t\t>>> cropped_with_mask.shape
\t\t(80, 80, 3)

\t\t>>> # Test with PIL Image
\t\t>>> from PIL import Image
\t\t>>> pil_image = Image.new(\'RGB\', (100, 100), (0, 0, 0))
\t\t>>> from PIL import ImageDraw
\t\t>>> draw = ImageDraw.Draw(pil_image)
\t\t>>> draw.rectangle([25, 25, 75, 75], fill=(255, 255, 255))
\t\t>>> cropped_pil = auto_crop(pil_image)
\t\t>>> cropped_pil.size
\t\t(51, 51)

\t\t>>> # Test with threshold
\t\t>>> array_gray = np.ones((100, 100), dtype=np.uint8) * 10
\t\t>>> array_gray[20:80, 30:70] = 255
\t\t>>> cropped_threshold = auto_crop(array_gray, threshold=50, return_type=np.ndarray)
\t\t>>> cropped_threshold.shape
\t\t(60, 40)

\t\t>>> # Test with callable threshold (using lambda to avoid min value)
\t\t>>> array_gray2 = np.ones((100, 100), dtype=np.uint8) * 10
\t\t>>> array_gray2[20:80, 30:70] = 255
\t\t>>> cropped_max = auto_crop(array_gray2, threshold=lambda x: 50, return_type=np.ndarray)
\t\t>>> cropped_max.shape
\t\t(60, 40)

\t>>> # Test with non-contiguous crop
\t>>> array_sparse = np.zeros((100, 100, 3), dtype=np.uint8)
\t>>> array_sparse[10, 10] = 255
\t>>> array_sparse[50, 50] = 255
\t>>> array_sparse[90, 90] = 255
\t>>> cropped_contiguous = auto_crop(array_sparse, contiguous=True, return_type=np.ndarray)
\t>>> cropped_contiguous.shape  # Bounding box from (10,10) to (90,90)
\t(81, 81, 3)
\t>>> cropped_non_contiguous = auto_crop(array_sparse, contiguous=False, return_type=np.ndarray)
\t>>> cropped_non_contiguous.shape  # Only rows/cols 10, 50, 90
\t(3, 3, 3)

\t>>> # Test with 3D crop on depth dimension
\t>>> array_3d = np.zeros((50, 50, 10), dtype=np.uint8)
\t>>> array_3d[10:40, 10:40, 2:8] = 255  # Content only in depth slices 2-7
\t>>> cropped_3d = auto_crop(array_3d, contiguous=True, return_type=np.ndarray)
\t>>> cropped_3d.shape  # Should crop all 3 dimensions
\t(30, 30, 6)
\t'''
