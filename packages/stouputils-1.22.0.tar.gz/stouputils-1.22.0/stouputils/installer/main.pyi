from .common import *
from .linux import *
from .windows import *
from ..decorators import LogLevels as LogLevels, handle_error as handle_error
from ..print.message import info as info, warning as warning
from collections.abc import Callable as Callable

def extract_archive(extraction_path: str, temp_dir: str, extract_func: Callable[[str], None], get_file_list_func: Callable[[], list[str]]) -> None:
    """ Helper function to extract archive files with consistent handling.

\tArgs:
\t\textraction_path     (str): Path where files should be extracted
\t\ttemp_dir            (str): Temporary directory for intermediate extraction
\t\textract_func        (Callable[[str], None]): Function to extract the archive
\t\tget_file_list_func  (Callable[[], list[str]]): Function to get the list of files in the archive
\t"""
def get_install_path(program_name: str, platform_str: str = ..., ask_global: int = 0, add_path: bool = True, append_to_path: str = '') -> str:
    ''' Get the installation path for the program on the current platform.

\tArgs:
\t\tprogram_name  (str):  The name of the program to install.
\t\tplatform_str  (str):  The platform to get the installation path for.
\t\task_global    (int):  Whether to ask the user for a path, 0 = ask, 1 = install globally, 2 = install locally.
\t\tadd_path      (bool): Whether to add the program to the PATH environment variable.
\t\tappend_to_path (str):  String to append to the installation path when adding to PATH.
\t\t\t(ex: "bin" if executables are in the bin folder)

\tReturns:
\t\tstr: The installation path for the program.

\tExamples:
\t\t.. code-block:: python

\t\t\t> # Get install path, ask user if they want global or local
\t\t\t> path = get_install_path("waifu2x-ncnn-vulkan", ask_global=0)
\t\t\t> # User will be prompted to choose between global and local installation

\t\t\t> # Force local installation
\t\t\t> path = get_install_path("my-tool", ask_global=2)
\t\t\t> # Returns a local path like "/home/user/my-tool" or "C:/Users/user/my-tool"

\t\t\t> # Force global installation
\t\t\t> path = get_install_path("my-tool", ask_global=1)
\t\t\t> # Returns a global path like "/usr/local/bin/my-tool" or "C:/Program Files/my-tool"
\t'''
def add_to_path(install_path: str, platform_str: str = ...) -> bool:
    ''' Add the program to the PATH environment variable.

\tArgs:
\t\tinstall_path  (str):  The path to the program to add to the PATH environment variable.
\t\tplatform_str  (str):  The platform you are running on (ex: "Windows", "Linux", "Darwin", ...),
\t\t\twe use this to determine the installation path if not provided.

\tReturns:
\t\tbool: True if add to PATH was successful, False otherwise.

\tExamples:
\t\t.. code-block:: python

\t\t\t> # Add a directory to PATH on the current platform
\t\t\t> success = add_to_path("/usr/local/bin/my-program")
\t\t\t> print(success)
\t\t\tTrue

\t\t\t> # Add a Windows path (when running on Windows)
\t\t\t> add_to_path("C:/Program Files/MyApp/bin", platform_str="Windows")
\t\t\tTrue
\t'''
def install_program(input_path: str, install_path: str = '', platform_str: str = ..., program_name: str = '', add_path: bool = True, append_to_path: str = '') -> bool:
    ''' Install a program to a specific path from a local zip file or URL.

\tArgs:
\t\tinput_path     (str):  Path to a zip file or a download URL.
\t\tinstall_path   (str):  The directory to extract the program into, we ask user for a path if not provided.
\t\tplatform_str   (str):  The platform you are running on (ex: "Windows", "Linux", "Darwin", ...),
\t\t\twe use this to determine the installation path if not provided.
\t\tadd_path       (bool): Whether to add the program to the PATH environment variable.
\t\tprogram_name   (str):  Override the program name, we get it from the input path if not provided.
\t\tappend_to_path (str):  String to append to the installation path when adding to PATH.
\t\t\t(ex: "bin" if executables are in the bin folder)

\tReturns:
\t\tbool: True if installation was successful, False otherwise.

\tExamples:
\t\t.. code-block:: python

\t\t\t> # Install from a URL
\t\t\t> success = install_program(
\t\t\t>     "https://github.com/example/tool/releases/download/v1.0/tool.zip",
\t\t\t>     install_path="/usr/local/bin/tool",
\t\t\t>     program_name="tool",
\t\t\t>     add_path=True
\t\t\t> )
\t\t\t> print(success)
\t\t\tTrue

\t\t\t> # Install from a local file
\t\t\t> install_program(
\t\t\t>     "/downloads/program.zip",
\t\t\t>     install_path="C:/Program Files/MyProgram",
\t\t\t>     add_path=False
\t\t\t> )
\t\t\tTrue

\t\t\t> # Install with executables in a subdirectory
\t\t\t> install_program(
\t\t\t>     "https://example.com/ffmpeg.zip",
\t\t\t>     program_name="ffmpeg",
\t\t\t>     append_to_path="bin"  # Adds /path/to/ffmpeg/bin to PATH
\t\t\t> )
\t\t\tTrue
\t'''
