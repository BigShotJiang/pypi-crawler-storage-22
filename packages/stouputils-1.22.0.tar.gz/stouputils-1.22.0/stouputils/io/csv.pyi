from .path import super_open as super_open
from typing import Any, IO

def csv_dump(data: Any, file: IO[Any] | str | None = None, delimiter: str = ',', has_header: bool = True, index: bool = False, *args: Any, **kwargs: Any) -> str:
    ''' Writes data to a CSV file with customizable options and returns the CSV content as a string.

\tArgs:
\t\tdata\t\t(list[list[Any]] | list[dict[str, Any]] | pd.DataFrame | pl.DataFrame):
\t\t\t\t\t\tThe data to write, either a list of lists, list of dicts, pandas DataFrame, or Polars DataFrame
\t\tfile\t\t(IO[Any] | str): The file object or path to dump the data to
\t\tdelimiter\t(str): The delimiter to use (default: \',\')
\t\thas_header\t(bool): Whether to include headers (default: True, applies to dict and DataFrame data)
\t\tindex\t\t(bool): Whether to include the index (default: False, only applies to pandas DataFrame)
\t\t*args\t\t(Any): Additional positional arguments to pass to the underlying CSV writer or DataFrame method
\t\t**kwargs\t(Any): Additional keyword arguments to pass to the underlying CSV writer or DataFrame method
\tReturns:
\t\tstr: The CSV content as a string

\tExamples:

\t\t>>> csv_dump([["a", "b", "c"], [1, 2, 3], [4, 5, 6]])
\t\t\'a,b,c\\r\\n1,2,3\\r\\n4,5,6\\r\\n\'

\t\t>>> csv_dump([{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}])
\t\t\'name,age\\r\\nAlice,30\\r\\nBob,25\\r\\n\'
\t'''
def csv_load(file_path: str, delimiter: str = ',', has_header: bool = True, as_dict: bool = False, as_dataframe: bool = False, use_polars: bool = False, *args: Any, **kwargs: Any) -> Any:
    ''' Load a CSV file from the given path

\tArgs:
\t\tfile_path (str): The path to the CSV file
\t\tdelimiter (str): The delimiter used in the CSV (default: \',\')
\t\thas_header (bool): Whether the CSV has a header row (default: True)
\t\tas_dict (bool): Whether to return data as list of dicts (default: False)
\t\tas_dataframe (bool): Whether to return data as a DataFrame (default: False)
\t\tuse_polars (bool): Whether to use Polars instead of pandas for DataFrame (default: False, requires polars)
\t\t*args: Additional positional arguments to pass to the underlying CSV reader or DataFrame method
\t\t**kwargs: Additional keyword arguments to pass to the underlying CSV reader or DataFrame method
\tReturns:
\t\tlist[list[str]] | list[dict[str, str]] | pd.DataFrame | pl.DataFrame: The content of the CSV file

\tExamples:

\t\t.. code-block:: python

\t\t\t> Assuming "test.csv" contains: a,b,c\\n1,2,3\\n4,5,6
\t\t\t> csv_load("test.csv")
\t\t\t[[\'1\', \'2\', \'3\'], [\'4\', \'5\', \'6\']]

\t\t\t> csv_load("test.csv", as_dict=True)
\t\t\t[{\'a\': \'1\', \'b\': \'2\', \'c\': \'3\'}, {\'a\': \'4\', \'b\': \'5\', \'c\': \'6\'}]

\t\t\t> csv_load("test.csv", as_dataframe=True)
\t\t\t   a  b  c
\t\t\t0  1  2  3
\t\t\t1  4  5  6

\t\t.. code-block:: console

\t\t\t> csv_load("test.csv", as_dataframe=True, use_polars=True)
\t\t\tshape: (2, 3)
\t\t\t┌─────┬─────┬─────┐
\t\t\t│ a   ┆ b   ┆ c   │
\t\t\t│ --- ┆ --- ┆ --- │
\t\t\t│ i64 ┆ i64 ┆ i64 │
\t\t\t╞═════╪═════╪═════╡
\t\t\t│ 1   ┆ 2   ┆ 3   │
\t\t\t│ 4   ┆ 5   ┆ 6   │
\t\t\t└─────┴─────┴─────┘
\t'''
