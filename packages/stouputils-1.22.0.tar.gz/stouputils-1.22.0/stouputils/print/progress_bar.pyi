from collections.abc import Iterable, Iterator
from typing import Any

def colored_for_loop[T](iterable: Iterable[T], desc: str = 'Processing', color: str = ..., bar_format: str = ..., ascii: bool = False, smooth_tqdm: bool = True, **kwargs: Any) -> Iterator[T]:
    ''' Function to iterate over a list with a colored TQDM progress bar like the other functions in this module.

\tArgs:
\t\titerable\t(Iterable):\t\t\tList to iterate over
\t\tdesc\t\t(str):\t\t\t\tDescription of the function execution displayed in the progress bar
\t\tcolor\t\t(str):\t\t\t\tColor of the progress bar (Defaults to ::attr::MAGENTA)
\t\tbar_format\t(str):\t\t\t\tFormat of the progress bar (Defaults to ::attr::BAR_FORMAT)
\t\tascii\t\t(bool):\t\t\t\tWhether to use ASCII or Unicode characters for the progress bar (Defaults to False)
\t\tsmooth_tqdm\t(bool):\t\t\t\tWhether to enable smooth progress bar updates by setting miniters=1 and mininterval=0.0 (Defaults to True)
\t\t**kwargs:\t\t\t\t\t\tAdditional arguments to pass to the TQDM progress bar

\tYields:
\t\tT: Each item of the iterable

\tExamples:
\t\t>>> import time
\t\t>>> for i in colored_for_loop(range(10), desc="Time sleeping loop"):
\t\t...     time.sleep(0.01)  # doctest: +SKIP
\t\t>>> # Time sleeping loop: 100%|██████████████████| 10/10 [ 95.72it/s, 00:00<00:00]
\t'''
