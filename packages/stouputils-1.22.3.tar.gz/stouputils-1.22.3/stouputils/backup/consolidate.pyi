from ..decorators import measure_time as measure_time
from ..io.path import clean_path as clean_path
from ..print.message import info as info, warning as warning
from ..print.progress_bar import colored_for_loop as colored_for_loop
from .retrieve import get_all_previous_backups as get_all_previous_backups

def consolidate_backups(zip_path: str, destination_zip: str) -> None:
    ''' Consolidates the files from the given backup and all previous ones into a new ZIP file,
\tensuring that the most recent version of each file is kept and deleted files are not restored.

\tArgs:
\t\tzip_path (str): Path to the latest backup ZIP file (If endswith "/latest.zip" or "/", the latest backup will be used)
\t\tdestination_zip (str): Path to the destination ZIP file where the consolidated backup will be saved
\tExamples:

\t.. code-block:: python

\t\t> consolidate_backups("/path/to/backups/latest.zip", "/path/to/consolidated.zip")
\t\t[INFO HH:MM:SS] Consolidating backups
\t\t[INFO HH:MM:SS] Consolidated backup created: \'/path/to/consolidated.zip\'
\t'''
