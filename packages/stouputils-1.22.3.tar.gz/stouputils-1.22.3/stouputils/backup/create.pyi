from ..decorators import handle_error as handle_error, measure_time as measure_time
from ..io.path import clean_path as clean_path
from ..print.message import info as info, warning as warning
from .hash import get_file_hash as get_file_hash
from .retrieve import get_all_previous_backups as get_all_previous_backups, is_file_in_any_previous_backup as is_file_in_any_previous_backup

@handle_error
def create_delta_backup(source_path: str, destination_folder: str, exclude_patterns: list[str] | None = None) -> None:
    ''' Creates a ZIP delta backup, saving only modified or new files while tracking deleted files.

\tArgs:
\t\tsource_path (str): Path to the source file or directory to back up
\t\tdestination_folder (str): Path to the folder where the backup will be saved
\t\texclude_patterns (list[str] | None): List of glob patterns to exclude from backup
\tExamples:

\t.. code-block:: python

\t\t> create_delta_backup("/path/to/source", "/path/to/backups", exclude_patterns=["libraries/*", "cache/*"])
\t\t[INFO HH:MM:SS] Creating ZIP backup
\t\t[INFO HH:MM:SS] Backup created: \'/path/to/backups/backup_2025_02_18-10_00_00.zip\'
\t'''
