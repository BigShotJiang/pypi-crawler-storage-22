from ..decorators import handle_error as handle_error, measure_time as measure_time
from ..io.path import clean_path as clean_path
from ..print.message import info as info, warning as warning
from .consolidate import consolidate_backups as consolidate_backups

@handle_error
def limit_backups(max_backups: int, backup_folder: str, keep_oldest: bool = True) -> None:
    ''' Limits the number of delta backups by consolidating the oldest ones.

\tIf the number of backups exceeds max_backups, the oldest backups are consolidated
\tinto a single backup file, then deleted, until the count is within the limit.

\tArgs:
\t\tmax_backups (int): Maximum number of delta backups to keep
\t\tbackup_folder (str): Path to the folder containing backups
\t\tkeep_oldest (bool): If True, never delete the oldest backup (default: True)
\tExamples:

\t.. code-block:: python

\t\t> limit_backups(5, "/path/to/backups")
\t\t[INFO HH:MM:SS] Limiting backups
\t\t[INFO HH:MM:SS] Consolidated 3 oldest backups into \'/path/to/backups/consolidated_YYYY_MM_DD-HH_MM_SS.zip\'
\t\t[INFO HH:MM:SS] Deleted 3 old backups
\t'''
