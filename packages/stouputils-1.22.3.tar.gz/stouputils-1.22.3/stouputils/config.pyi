from typing import ClassVar

class StouputilsConfig:
    """ Global configuration class for stouputils. """
    VERBOSE_READING_ENV: bool
    RESET: str
    RED: str
    GREEN: str
    YELLOW: str
    BLUE: str
    MAGENTA: str
    CYAN: str
    LINE_UP: str
    BOLD: str
    BAR_FORMAT: str
    FORCE_RAISE_EXCEPTION: bool
    CPU_COUNT: int
    PROCESS_TITLE_PER_WORKER: bool
    CHUNK_SIZE: int
    LARGE_CHUNK_SIZE: int
    GITHUB_API_URL: str
    COMMIT_TYPES: ClassVar[dict[str, str]]
    AUTO_DOCS_REQUIREMENTS: tuple[str, ...]

def handle_config_from_env(var: str, expected_type: str) -> None: ...

type_str: str
