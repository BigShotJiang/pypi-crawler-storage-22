from .common import AbstractBothContextManager as AbstractBothContextManager
from typing import Any

class DoNothing(AbstractBothContextManager['DoNothing']):
    ''' Context manager that does nothing.

\tThis is a no-op context manager that can be used as a placeholder
\tor for conditional context management.

\tDifferent from contextlib.nullcontext because it handles args and kwargs,
\talong with **async** context management.

\tExamples:
\t\t>>> with DoNothing():
\t\t...     print("This will be printed normally")
\t\tThis will be printed normally

\t\t>>> # Conditional context management
\t\t>>> some_condition = True
\t\t>>> ctx = DoNothing() if some_condition else Muffle()
\t\t>>> with ctx:
\t\t...     print("May or may not be printed depending on condition")
\t\tMay or may not be printed depending on condition
\t'''
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """ No initialization needed, this is a no-op context manager """
    def __enter__(self) -> DoNothing:
        """ Enter context manager (does nothing) """
    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """ Exit context manager (does nothing) """
    async def __aenter__(self) -> DoNothing:
        """ Enter async context manager (does nothing) """
    async def __aexit__(self, *excinfo: Any) -> None:
        """ Exit async context manager (does nothing) """
NullContextManager = DoNothing
