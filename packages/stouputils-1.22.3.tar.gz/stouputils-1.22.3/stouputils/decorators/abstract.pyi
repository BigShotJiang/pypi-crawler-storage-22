from .common import get_function_name as get_function_name, get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from .handle_error import LogLevels as LogLevels, handle_error as handle_error
from collections.abc import Callable as Callable
from typing import overload

@overload
def abstract[T](func: Callable[..., T], *, error_log: LogLevels = ...) -> Callable[..., T]: ...
@overload
def abstract[T](func: None = None, *, error_log: LogLevels = ...) -> Callable[[Callable[..., T]], Callable[..., T]]: ...
