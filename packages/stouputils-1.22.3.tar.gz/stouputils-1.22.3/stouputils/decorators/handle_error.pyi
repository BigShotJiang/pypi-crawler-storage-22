from ..print.message import error as error, warning as warning
from .common import get_function_name as get_function_name, get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from collections.abc import Callable as Callable
from enum import Enum
from typing import overload

class LogLevels(Enum):
    """ Log level for the errors in the decorator handle_error """
    NONE = 0
    WARNING = 1
    WARNING_TRACEBACK = 2
    ERROR_TRACEBACK = 3
    RAISE_EXCEPTION = 4

@overload
def handle_error[T](func: Callable[..., T], *, exceptions: tuple[type[BaseException], ...] | type[BaseException] = ..., message: str = '', error_log: LogLevels = ..., sleep_time: float = 0.0) -> Callable[..., T]: ...
@overload
def handle_error[T](func: None = None, *, exceptions: tuple[type[BaseException], ...] | type[BaseException] = ..., message: str = '', error_log: LogLevels = ..., sleep_time: float = 0.0) -> Callable[[Callable[..., T]], Callable[..., T]]: ...
