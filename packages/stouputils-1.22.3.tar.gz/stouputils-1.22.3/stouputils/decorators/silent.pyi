from ..ctx.muffle import Muffle as Muffle
from .common import get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from collections.abc import Callable as Callable
from typing import overload

@overload
def silent[T](func: Callable[..., T], *, mute_stderr: bool = False) -> Callable[..., T]: ...
@overload
def silent[T](func: None = None, *, mute_stderr: bool = False) -> Callable[[Callable[..., T]], Callable[..., T]]: ...
