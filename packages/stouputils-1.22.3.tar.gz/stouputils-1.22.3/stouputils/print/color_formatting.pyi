from typing import Any, TextIO

def format_colored(*values: Any) -> str:
    ''' Format text with Python 3.14 style colored formatting.

\tDynamically colors text by analyzing each word:
\t- File paths in magenta
\t- Numbers in magenta
\t- Function names (built-in and callable objects) in magenta
\t- Exception names in bold magenta

\tArgs:
\t\tvalues\t(Any):\tValues to format (like the print function)

\tReturns:
\t\tstr: The formatted text with ANSI color codes

\tExamples:
\t\t>>> # Test function names with parentheses
\t\t>>> result = format_colored("Call print() with 42 items")
\t\t>>> result.count(Cfg.MAGENTA)  # print and 42
\t\t2

\t\t>>> # Test function names without parentheses
\t\t>>> result = format_colored("Use len and sum functions")
\t\t>>> result.count(Cfg.MAGENTA)  # len and sum
\t\t2

\t\t>>> # Test exceptions (bold magenta)
\t\t>>> result = format_colored("Got ValueError when parsing")
\t\t>>> result.count(Cfg.MAGENTA), result.count(Cfg.BOLD)  # ValueError in bold magenta
\t\t(1, 1)

\t\t>>> # Test file paths
\t\t>>> result = format_colored("Processing ./data.csv file")
\t\t>>> result.count(Cfg.MAGENTA)  # ./data.csv
\t\t1

\t\t>>> # Test file paths with quotes
\t\t>>> result = format_colored(\'File "/path/to/script.py" line 42\')
\t\t>>> result.count(Cfg.MAGENTA)  # /path/to/script.py and 42
\t\t2

\t\t>>> # Test numbers
\t\t>>> result = format_colored("Found 100 items and 3.14 value, 3.0e+10 is big")
\t\t>>> result.count(Cfg.MAGENTA)  # 100 and 3.14
\t\t3

\t\t>>> # Test mixed content
\t\t>>> result = format_colored("Call sum() got IndexError at line 256 in utils.py")
\t\t>>> result.count(Cfg.MAGENTA)  # sum, IndexError (bold), and 256
\t\t3
\t\t>>> result.count(Cfg.BOLD)  # IndexError is bold
\t\t1

\t\t>>> # Test keywords always colored
\t\t>>> result = format_colored("Check class dtype type")
\t\t>>> result.count(Cfg.MAGENTA)  # class, dtype, type
\t\t3

\t\t>>> # Test plain text (no coloring)
\t\t>>> result = format_colored("This is plain text")
\t\t>>> result.count(Cfg.MAGENTA) == 0 and result == "This is plain text"
\t\tTrue

\t\t>>> # Affix punctuation should not be colored (assert exact coloring, punctuation uncolored)
\t\t>>> result = format_colored("<class")
\t\t>>> result == "<" + Cfg.MAGENTA + "class" + Cfg.RESET
\t\tTrue
\t\t>>> result = format_colored("(dtype:")
\t\t>>> result == "(" + Cfg.MAGENTA + "dtype" + Cfg.RESET + ":"
\t\tTrue
\t\t>>> result = format_colored("[1.")
\t\t>>> result == "[" + Cfg.MAGENTA + "1" + Cfg.RESET + "."
\t\tTrue

\t\t>>> # Test complex
\t\t>>> text = "<class \'numpy.ndarray\'>, <id 140357548266896>: (dtype: float32, shape: (6,), min: 0.0, max: 1.0) [1. 0. 0. 0. 1. 0.]"
\t\t>>> result = format_colored(text)
\t\t>>> result.count(Cfg.MAGENTA)  # class, numpy, ndarray, float32, 6, 0.0, 1.0, 1. 0.
\t\t16
\t'''
def colored(*values: Any, file: TextIO | None = None, **print_kwargs: Any) -> None:
    ''' Print with Python 3.14 style colored formatting.

\tDynamically colors text by analyzing each word:
\t- File paths in magenta
\t- Numbers in magenta
\t- Function names (built-in and callable objects) in magenta
\t- Exception names in bold magenta

\tArgs:
\t\tvalues\t\t\t(Any):\t\tValues to print (like the print function)
\t\tfile\t\t\t(TextIO):\tFile to write the message to (default: sys.stdout)
\t\tprint_kwargs\t(dict):\t\tKeyword arguments to pass to the print function

\tExamples:
\t\t>>> colored("File \'/path/to/file.py\', line 42, in function_name")  # doctest: +SKIP
\t\t>>> colored("KeyboardInterrupt")  # doctest: +SKIP
\t\t>>> colored("Processing data.csv with 100 items")  # doctest: +SKIP
\t\t>>> colored("Using print and len functions")  # doctest: +SKIP
\t'''
