from typing import Any

RESET: str
RED: str
GREEN: str
YELLOW: str
BLUE: str
MAGENTA: str
CYAN: str
LINE_UP: str
BOLD: str
BAR_FORMAT: str

class PrintMemory:
    """ Class to store shared variables for print functions. """
    previous_args_kwards: tuple[Any, Any]
    nb_values: int
    import_time: float
