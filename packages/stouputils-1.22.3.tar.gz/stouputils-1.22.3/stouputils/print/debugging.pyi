from .message import debug as debug, warning as warning
from collections.abc import Callable as Callable
from typing import Any

def whatisit(*values: Any, print_function: Callable[..., None] = ..., flush: bool = True, max_length: int = 250, color: str = ..., text: str = 'What is it?', **print_kwargs: Any) -> None:
    ''' Print the type of each value and the value itself, with its id and length/shape.

\tThe output format is: "type, <id id_number>:\t(length/shape) value"

\tArgs:
\t\tvalues\t\t\t(Any):\t\tValues to print
\t\tprint_function\t(Callable):\tFunction to use to print the values (default: debug())
\t\tmax_length\t\t(int):\t\tMaximum length of the value string to print (default: 250)
\t\tcolor\t\t\t(str):\t\tColor of the message (default: CYAN)
\t\ttext\t\t\t(str):\t\tText in the message (replaces "DEBUG")
\t\tprint_kwargs\t(dict):\t\tKeyword arguments to pass to the print function
\t'''
def breakpoint(*values: Any, print_function: Callable[..., None] = ..., flush: bool = True, text: str = 'BREAKPOINT (press Enter)', **print_kwargs: Any) -> None:
    ''' Breakpoint function, pause the program and print the values.

\tArgs:
\t\tvalues\t\t\t(Any):\t\tValues to print
\t\tprint_function\t(Callable):\tFunction to use to print the values (default: warning())
\t\ttext\t\t\t(str):\t\tText in the message (replaces "WARNING")
\t\tprint_kwargs\t(dict):\t\tKeyword arguments to pass to the print function
\t'''
def whatisitc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
def breakpointc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
