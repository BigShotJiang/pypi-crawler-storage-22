__version__ = '5.0.5430'
__author__ = 'MetaQuotes Ltd.'
