# strava-cli

CLI tool for interacting with the Strava API.

## Install

```bash
uv pip install -e .
```

## Setup

1. Create a Strava API app at https://www.strava.com/settings/api
2. Set callback URL to `http://localhost`
3. Run `strava auth` and follow the prompts

## Commands

| Command | Description |
|---------|-------------|
| `strava auth` | OAuth2 setup flow |
| `strava profile` | Show athlete profile |
| `strava stats` | Athlete stats summary |
| `strava activities` | List recent activities |
| `strava activity <id>` | Detailed activity view |
| `strava export` | Bulk export activities |

## Usage

```bash
# List last 10 activities
strava activities --limit 10

# Filter by type and date
strava activities --type Run --after 2024-01-01

# View a specific activity
strava activity 12345678

# Export activities to JSON
strava export --output ./export --format json --after 2024-01-01
```

## Token Management

Tokens are stored in `~/.config/strava-cli/tokens.json` and automatically refreshed when expired (every 6 hours).
