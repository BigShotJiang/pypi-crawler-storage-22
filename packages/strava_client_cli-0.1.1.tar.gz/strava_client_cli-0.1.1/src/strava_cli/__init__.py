"""Strava CLI — interact with the Strava API from the command line."""
