"""Strava CLI — interact with Strava from the command line."""

from __future__ import annotations

import json
import webbrowser
from pathlib import Path
from typing import Optional
from urllib.parse import urlencode

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from strava_cli.config import (
    STRAVA_AUTH_URL,
    StravaClient,
    StravaConfig,
)
from strava_cli.formatting import (
    format_date,
    format_date_short,
    format_distance,
    format_duration,
    format_elevation,
    format_pace,
    format_speed,
    parse_date_to_epoch,
)

app = typer.Typer(
    name="strava",
    help="Interact with the Strava API from the command line.",
    no_args_is_help=True,
)
console = Console()
err_console = Console(stderr=True)


def _get_client() -> StravaClient:
    return StravaClient()


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------

@app.command()
def auth() -> None:
    """Authenticate with Strava via OAuth2."""
    config = StravaConfig()
    loaded = config.load()

    if not loaded:
        console.print("[bold]Strava OAuth Setup[/bold]\n")
        console.print("Create an app at https://www.strava.com/settings/api")
        console.print("Use [cyan]http://localhost[/cyan] as the callback URL.\n")
        config.client_id = typer.prompt("Client ID")
        config.client_secret = typer.prompt("Client Secret")
        config.save()
        console.print("[green]✓ Config saved[/green]\n")
    else:
        console.print(f"[dim]Using existing config (client_id: {config.client_id})[/dim]\n")

    params = urlencode({
        "client_id": config.client_id,
        "response_type": "code",
        "redirect_uri": "http://localhost",
        "approval_prompt": "force",
        "scope": "activity:read_all,profile:read_all",
    })
    auth_url = f"{STRAVA_AUTH_URL}?{params}"

    console.print("Open this URL in your browser:\n")
    console.print(f"[cyan]{auth_url}[/cyan]\n")

    try:
        webbrowser.open(auth_url)
    except Exception:
        pass

    console.print(
        "After authorizing, you'll be redirected to localhost with a [bold]code[/bold] parameter."
    )
    console.print("Copy the code from the URL (e.g. http://localhost/?code=XXXXX)\n")

    code = typer.prompt("Paste the authorization code")

    client = StravaClient()
    data = client.exchange_code(code)

    athlete = data.get("athlete", {})
    name = f"{athlete.get('firstname', '')} {athlete.get('lastname', '')}".strip()
    console.print(f"\n[green]✓ Authenticated as {name}[/green]")
    console.print("[dim]Tokens saved to ~/.config/strava-cli/tokens.json[/dim]")


# ---------------------------------------------------------------------------
# profile
# ---------------------------------------------------------------------------

@app.command()
def profile() -> None:
    """Show your Strava athlete profile."""
    client = _get_client()
    data = client.get("/athlete")

    table = Table(title="Athlete Profile")
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    name = f"{data.get('firstname', '')} {data.get('lastname', '')}".strip()
    table.add_row("Name", name)
    table.add_row("Username", data.get("username", "—"))
    table.add_row("City", data.get("city", "—") or "—")
    table.add_row("State", data.get("state", "—") or "—")
    table.add_row("Country", data.get("country", "—") or "—")
    table.add_row("Sex", data.get("sex", "—") or "—")
    table.add_row("Weight", f"{data.get('weight', 0):.1f} kg" if data.get("weight") else "—")
    table.add_row("FTP", str(data.get("ftp", "—")) if data.get("ftp") else "—")
    table.add_row("Follower Count", str(data.get("follower_count", 0)))
    table.add_row("Friend Count", str(data.get("friend_count", 0)))

    console.print(table)


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------

@app.command()
def stats() -> None:
    """Show your athlete stats summary."""
    client = _get_client()
    athlete_id = client.athlete_id

    if not athlete_id:
        # Fetch profile to get ID
        profile_data = client.get("/athlete")
        athlete_id = profile_data["id"]

    data = client.get(f"/athletes/{athlete_id}/stats")

    def _add_stat_section(table: Table, label: str, totals: dict) -> None:
        count = totals.get("count", 0)
        if count == 0:
            table.add_row(label, "No activities", "", "", "")
            return
        table.add_row(
            label,
            str(count),
            format_distance(totals.get("distance", 0)),
            format_duration(totals.get("moving_time", 0)),
            format_elevation(totals.get("elevation_gain", 0)),
        )

    for sport, key_prefix in [("Run", "run"), ("Ride", "ride"), ("Swim", "swim")]:
        table = Table(title=f"{sport} Stats")
        table.add_column("Period", style="cyan")
        table.add_column("Count")
        table.add_column("Distance")
        table.add_column("Time")
        table.add_column("Elevation")

        _add_stat_section(table, "Recent", data.get(f"recent_{key_prefix}_totals", {}))
        _add_stat_section(table, "YTD", data.get(f"ytd_{key_prefix}_totals", {}))
        _add_stat_section(table, "All Time", data.get(f"all_{key_prefix}_totals", {}))

        console.print(table)
        console.print()


# ---------------------------------------------------------------------------
# activities
# ---------------------------------------------------------------------------

@app.command()
def activities(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of activities to show."),
    after: Optional[str] = typer.Option(None, help="Show activities after this date (YYYY-MM-DD)."),
    before: Optional[str] = typer.Option(None, help="Show activities before this date (YYYY-MM-DD)."),
    activity_type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type (Run, Ride, Swim, etc.)."),
) -> None:
    """List recent activities."""
    client = _get_client()

    params: dict = {"per_page": min(limit, 200)}
    if after:
        params["after"] = parse_date_to_epoch(after)
    if before:
        params["before"] = parse_date_to_epoch(before)

    data = client.get("/athlete/activities", params=params)

    if activity_type:
        normalized = activity_type.lower()
        data = [a for a in data if a.get("type", "").lower() == normalized]

    if not data:
        console.print("[yellow]No activities found.[/yellow]")
        return

    table = Table(title="Activities")
    table.add_column("ID", style="dim")
    table.add_column("Date", style="cyan")
    table.add_column("Type")
    table.add_column("Name")
    table.add_column("Distance", justify="right")
    table.add_column("Time", justify="right")
    table.add_column("Elevation", justify="right")

    for a in data[:limit]:
        table.add_row(
            str(a["id"]),
            format_date_short(a["start_date"]),
            a.get("type", "—"),
            a.get("name", "—"),
            format_distance(a.get("distance", 0)),
            format_duration(a.get("moving_time", 0)),
            format_elevation(a.get("total_elevation_gain", 0)),
        )

    console.print(table)


# ---------------------------------------------------------------------------
# activity
# ---------------------------------------------------------------------------

@app.command()
def activity(
    activity_id: int = typer.Argument(help="Strava activity ID."),
) -> None:
    """Show detailed view of a single activity."""
    client = _get_client()
    data = client.get(f"/activities/{activity_id}")

    title = data.get("name", "Activity")
    activity_type = data.get("type", "Unknown")
    date = format_date(data.get("start_date", ""))

    table = Table(title=f"{title} ({activity_type})")
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("Date", date)
    table.add_row("Distance", format_distance(data.get("distance", 0)))
    table.add_row("Moving Time", format_duration(data.get("moving_time", 0)))
    table.add_row("Elapsed Time", format_duration(data.get("elapsed_time", 0)))
    table.add_row("Elevation Gain", format_elevation(data.get("total_elevation_gain", 0)))
    table.add_row("Max Elevation", format_elevation(data.get("elev_high", 0)))
    table.add_row("Min Elevation", format_elevation(data.get("elev_low", 0)))

    avg_speed = data.get("average_speed", 0)
    max_speed = data.get("max_speed", 0)
    table.add_row("Avg Speed", format_speed(avg_speed))
    table.add_row("Max Speed", format_speed(max_speed))

    if data.get("type") in ("Run", "Walk", "Hike"):
        table.add_row("Avg Pace", format_pace(data.get("distance", 0), data.get("moving_time", 0)))

    if data.get("average_heartrate"):
        table.add_row("Avg HR", f"{data['average_heartrate']:.0f} bpm")
    if data.get("max_heartrate"):
        table.add_row("Max HR", f"{data['max_heartrate']:.0f} bpm")
    if data.get("average_cadence"):
        table.add_row("Avg Cadence", f"{data['average_cadence']:.0f} rpm")
    if data.get("average_watts"):
        table.add_row("Avg Power", f"{data['average_watts']:.0f} W")
    if data.get("calories"):
        table.add_row("Calories", f"{data['calories']:.0f}")

    table.add_row("Kudos", str(data.get("kudos_count", 0)))
    table.add_row("Description", data.get("description", "—") or "—")

    console.print(table)


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------

@app.command()
def export(
    output: Path = typer.Option(Path("./strava-export"), "--output", "-o", help="Output directory."),
    fmt: str = typer.Option("json", "--format", "-f", help="Export format: json or gpx."),
    after: Optional[str] = typer.Option(None, help="Export activities after this date (YYYY-MM-DD)."),
    before: Optional[str] = typer.Option(None, help="Export activities before this date (YYYY-MM-DD)."),
    limit: int = typer.Option(100, "--limit", "-n", help="Max activities to export."),
) -> None:
    """Bulk export activities to JSON or GPX files."""
    client = _get_client()

    params: dict = {"per_page": min(limit, 200)}
    if after:
        params["after"] = parse_date_to_epoch(after)
    if before:
        params["before"] = parse_date_to_epoch(before)

    console.print(f"[dim]Fetching activities...[/dim]")
    activity_list = client.get("/athlete/activities", params=params)

    if not activity_list:
        console.print("[yellow]No activities found.[/yellow]")
        return

    output.mkdir(parents=True, exist_ok=True)
    exported = 0

    for summary in activity_list[:limit]:
        aid = summary["id"]

        if fmt == "json":
            detail = client.get(f"/activities/{aid}")
            filepath = output / f"{aid}.json"
            filepath.write_text(json.dumps(detail, indent=2) + "\n")
            exported += 1
        elif fmt == "gpx":
            # Strava API v3 doesn't provide GPX directly; export streams as JSON
            # and note this limitation
            try:
                streams = client.get(
                    f"/activities/{aid}/streams",
                    params={"keys": "latlng,altitude,time", "key_type": "stream"},
                )
                filepath = output / f"{aid}_streams.json"
                filepath.write_text(json.dumps(streams, indent=2) + "\n")
                exported += 1
            except Exception as exc:
                err_console.print(f"[red]Failed to export {aid}: {exc}[/red]")

        name = summary.get("name", "")
        console.print(f"  [green]✓[/green] {aid} — {name}")

    console.print(f"\n[green]Exported {exported} activities to {output}[/green]")
    if fmt == "gpx":
        console.print("[dim]Note: Strava API v3 doesn't serve GPX directly. Exported stream data as JSON.[/dim]")


if __name__ == "__main__":
    app()
