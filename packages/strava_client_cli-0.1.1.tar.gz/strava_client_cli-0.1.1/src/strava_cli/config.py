"""Configuration and token management for Strava CLI."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

import httpx

CONFIG_DIR = Path.home() / ".config" / "strava-cli"
TOKENS_PATH = CONFIG_DIR / "tokens.json"
CONFIG_PATH = CONFIG_DIR / "config.json"

STRAVA_AUTH_URL = "https://www.strava.com/oauth/authorize"
STRAVA_TOKEN_URL = "https://www.strava.com/oauth/token"
STRAVA_API_BASE = "https://www.strava.com/api/v3"


class StravaConfig:
    """Manages client credentials stored in config.json."""

    def __init__(self) -> None:
        self.client_id: str = ""
        self.client_secret: str = ""

    def load(self) -> bool:
        if not CONFIG_PATH.exists():
            return False
        data = json.loads(CONFIG_PATH.read_text())
        self.client_id = data.get("client_id", "")
        self.client_secret = data.get("client_secret", "")
        return bool(self.client_id and self.client_secret)

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(json.dumps({
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }, indent=2) + "\n")


class TokenStore:
    """Manages OAuth tokens stored in tokens.json with auto-refresh."""

    def __init__(self) -> None:
        self.access_token: str = ""
        self.refresh_token: str = ""
        self.expires_at: int = 0
        self.athlete_id: int = 0

    def load(self) -> bool:
        if not TOKENS_PATH.exists():
            return False
        data = json.loads(TOKENS_PATH.read_text())
        self.access_token = data.get("access_token", "")
        self.refresh_token = data.get("refresh_token", "")
        self.expires_at = data.get("expires_at", 0)
        self.athlete_id = data.get("athlete_id", 0)
        return bool(self.access_token)

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        TOKENS_PATH.write_text(json.dumps({
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "expires_at": self.expires_at,
            "athlete_id": self.athlete_id,
        }, indent=2) + "\n")

    def is_expired(self) -> bool:
        return time.time() >= self.expires_at

    def update_from_response(self, data: dict) -> None:
        self.access_token = data["access_token"]
        self.refresh_token = data["refresh_token"]
        self.expires_at = data["expires_at"]
        if "athlete" in data:
            self.athlete_id = data["athlete"]["id"]
        self.save()


class StravaClient:
    """HTTP client for Strava API with automatic token refresh."""

    def __init__(self) -> None:
        self._config = StravaConfig()
        self._tokens = TokenStore()
        self._http: Optional[httpx.Client] = None

    def _ensure_config(self) -> None:
        if not self._config.load():
            raise SystemExit(
                "No Strava config found. Run 'strava auth' first."
            )

    def _ensure_tokens(self) -> None:
        if not self._tokens.load():
            raise SystemExit(
                "No tokens found. Run 'strava auth' first."
            )

    def _refresh_if_needed(self) -> None:
        if not self._tokens.is_expired():
            return
        self._ensure_config()
        response = httpx.post(STRAVA_TOKEN_URL, data={
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
            "grant_type": "refresh_token",
            "refresh_token": self._tokens.refresh_token,
        })
        response.raise_for_status()
        self._tokens.update_from_response(response.json())

    @property
    def athlete_id(self) -> int:
        self._ensure_tokens()
        return self._tokens.athlete_id

    @property
    def config(self) -> StravaConfig:
        self._ensure_config()
        return self._config

    @property
    def tokens(self) -> TokenStore:
        self._ensure_tokens()
        return self._tokens

    def get(self, path: str, params: Optional[dict] = None) -> dict | list:
        self._ensure_tokens()
        self._refresh_if_needed()
        response = httpx.get(
            f"{STRAVA_API_BASE}{path}",
            headers={"Authorization": f"Bearer {self._tokens.access_token}"},
            params=params,
            timeout=30,
        )
        response.raise_for_status()
        return response.json()

    def exchange_code(self, code: str) -> dict:
        self._ensure_config()
        response = httpx.post(STRAVA_TOKEN_URL, data={
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
            "code": code,
            "grant_type": "authorization_code",
        })
        response.raise_for_status()
        data = response.json()
        self._tokens.update_from_response(data)
        return data
