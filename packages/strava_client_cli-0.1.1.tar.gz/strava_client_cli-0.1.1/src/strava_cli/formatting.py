"""Formatting helpers for Strava data display."""

from __future__ import annotations

from datetime import datetime, timezone


def format_distance(meters: float) -> str:
    """Format distance in meters to km."""
    km = meters / 1000.0
    return f"{km:.2f} km"


def format_distance_miles(meters: float) -> str:
    """Format distance in meters to miles."""
    miles = meters / 1609.34
    return f"{miles:.2f} mi"


def format_duration(seconds: int) -> str:
    """Format seconds into human readable duration."""
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    if hours > 0:
        return f"{int(hours)}h {int(minutes):02d}m {int(secs):02d}s"
    return f"{int(minutes)}m {int(secs):02d}s"


def format_pace(meters: float, seconds: int) -> str:
    """Format pace as min/km."""
    if meters <= 0 or seconds <= 0:
        return "—"
    pace_seconds = seconds / (meters / 1000.0)
    minutes = int(pace_seconds // 60)
    secs = int(pace_seconds % 60)
    return f"{minutes}:{secs:02d} /km"


def format_speed(meters_per_second: float) -> str:
    """Format speed in km/h."""
    kmh = meters_per_second * 3.6
    return f"{kmh:.1f} km/h"


def format_elevation(meters: float) -> str:
    """Format elevation in meters."""
    return f"{meters:.0f} m"


def format_date(iso_string: str) -> str:
    """Format ISO date string to human readable."""
    dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
    return dt.strftime("%Y-%m-%d %H:%M")


def format_date_short(iso_string: str) -> str:
    """Format ISO date to short form."""
    dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
    return dt.strftime("%b %d")


def parse_date_to_epoch(date_str: str) -> int:
    """Parse YYYY-MM-DD to Unix timestamp."""
    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return int(dt.timestamp())
