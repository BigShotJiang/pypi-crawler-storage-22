# StreamCheck

A lightweight, O(1) memory validator for large CSV files.

## Why?
Validating a 10GB CSV file shouldn't require a 32GB RAM server. StreamCheck uses Python generators to validate files line-by-line.

## Usage

```python
from streamcheck import StreamValidator

# 1. Define simple checks
schema = {
    "age": lambda x: x.isdigit(),
    "email": lambda x: "@" in x
}

# 2. Run
validator = StreamValidator(schema)
for error in validator.validate("large_file.csv"):
    print(error)