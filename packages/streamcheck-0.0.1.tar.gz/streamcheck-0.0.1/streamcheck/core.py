import csv
from typing import Dict, Any, Generator, List, Callable

class StreamValidator:
    def __init__(self, schema: Dict[str, Callable[[str], bool]], delimiter: str = ','):
        """
        schema: Dict where key is column name, value is a validation function (returns True/False)
        """
        self.schema = schema
        self.delimiter = delimiter

    def validate(self, filepath: str) -> Generator[Dict[str, Any], None, None]:
        """
        Yields errors one by one as they are found.
        """
        with open(filepath, mode='r', encoding='utf-8', newline='') as f:
            reader = csv.DictReader(f, delimiter=self.delimiter)
            
            # 1. Validate Headers
            if not self._validate_headers(reader.fieldnames):
                yield {"row": 0, "error": "HeaderMismatch", "details": f"Expected {list(self.schema.keys())}"}
                return # Stop if headers are wrong

            # 2. Stream Rows
            for row_num, row in enumerate(reader, start=1):
                for col, validator_func in self.schema.items():
                    value = row.get(col)
                    
                    # Check if value exists and passes the validation function
                    if value is None or not validator_func(value):
                        yield {
                            "row": row_num,
                            "column": col,
                            "value": value,
                            "error": "ValidationError"
                        }

    def _validate_headers(self, headers: List[str]) -> bool:
        # Simple check: do the expected schema keys exist in the file headers?
        return all(key in headers for key in self.schema.keys())