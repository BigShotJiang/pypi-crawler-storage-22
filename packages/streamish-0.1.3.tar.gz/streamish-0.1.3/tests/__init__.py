"""Tests for streamish."""
