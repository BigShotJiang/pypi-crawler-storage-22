"""
streamlit-flexnav
-----------------
A navigation toolkit, menu schema, and Streamlit integration layer.
"""
from .ui.navigator import render_navigation

__all__ = [
    "render_navigation",
]
