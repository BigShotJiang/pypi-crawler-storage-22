def main():
    print("FlexNav CLI is running")