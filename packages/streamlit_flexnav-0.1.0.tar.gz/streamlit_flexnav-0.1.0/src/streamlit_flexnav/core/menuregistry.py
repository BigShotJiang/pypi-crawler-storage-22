from __future__ import annotations

import structlog
from streamlit_flexnav.core.loader import load_menupages
from streamlit_flexnav.ui.converter import MenuStruct

log = structlog.get_logger().bind(component="menuregistry")


class MenuRegistry:
    """
    Holds the loaded MenuStruct objects.
    Reloadable, but not manually mutable.
    """

    def __init__(self):
        self._items: list[MenuStruct] = []
        self.reload()

    def reload(self):
        self._items = load_menupages()
        log.info("menuregistry_reloaded", count=len(self._items))

    def all(self) -> list[MenuStruct]:
        return self._items


# Singleton
menuregistry = MenuRegistry()
