from typing import List
from pydantic import BaseModel, Field, model_validator
from .rolemode import RoleMode

class AccessControl(BaseModel):
    """
    Role-based access control for a menu item.
    Ensures no overlap between allowed and denied roles.
    """

    allowed_roles: List[RoleMode] = Field(
        default_factory=list,
        description="Roles that may see/use this menu item."
    )
    denied_roles: List[RoleMode] = Field(
        default_factory=list,
        description="Roles that must never see/use this menu item."
    )

    @model_validator(mode="after")
    def validate_no_overlap(self):
        overlap = set(self.allowed_roles) & set(self.denied_roles)
        if overlap:
            names = ", ".join(r.display_name() for r in overlap)
            raise ValueError(f"Role(s) cannot be both allowed and denied: {names}")
        return self

    def is_allowed(self, role: RoleMode) -> bool:
        """
        Returns True if the given role is permitted.
        Denied roles always override allowed roles.
        """
        if role in self.denied_roles:
            return False
        if self.allowed_roles and role not in self.allowed_roles:
            return False
        return True