from enum import Enum

class LinkTarget(str, Enum):
    self_ = "_self"
    blank = "_blank"
    parent = "_parent"
    top = "_top"
