from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional, List


class MenuGroup(BaseModel):
    """
    Represents a styled menu/submenu section.
    This is NOT a page. It is a visual grouping.
    """

    key: str = Field(..., description="Unique group identifier")
    label: str = Field(..., description="Displayed group label")

    order: int = Field(
        default=100,
        ge=-10_000,
        le=10_000,
        description="Ordering in of menu",
    )

    # Styling
    icon: Optional[str] = None
    color: Optional[str] = None
    bold: bool = False
    italic: bool = False
    size: Optional[int] = None  # 1–3 simulated sizes

    # Pages inside this group
    pages: List[object] = Field(default_factory=list)
