from __future__ import annotations

from typing import List, Optional, Dict, Any, Annotated
from pathlib import Path
import re

from pydantic import BaseModel, Field, HttpUrl, ConfigDict, field_validator
from annotated_types import MinLen, MaxLen


class MenuStruct(BaseModel):
    """
    Strict Pydantic v2 model for FlexNav 2.0 navigation entries.
    Loader injects an absolute filesystem path into `.path`.
    """

    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
        validate_assignment=True,
        arbitrary_types_allowed=True,
        frozen=False,   # loader injects .path
    )

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    key: Annotated[str, MinLen(2), MaxLen(64)] = Field(
        ...,
        pattern=r"^[a-z0-9][a-z0-9_-]{1,63}$",
        description="Stable, unique key used as URL path",
    )

    label: Annotated[str, MinLen(1), MaxLen(80)] = Field(
        ...,
        description="Human-readable label for the sidebar",
    )

    group: Optional[Annotated[str, MinLen(1), MaxLen(64)]] = Field(
        default=None,
        description="Folder-based grouping injected by loader",
    )
    file: Path
    order: int = Field(
        default=100,
        ge=-10_000,
        le=10_000,
        description="Ordering in the menu",
    )

    session_keys: Dict[str, object] = Field(
        default_factory=dict,
        description="Default session state keys for this page",
    )

    # ------------------------------------------------------------------
    # Copy / UX
    # ------------------------------------------------------------------

    description: Optional[Annotated[str, MaxLen(280)]] = None
    tooltip: Optional[Annotated[str, MaxLen(140)]] = None

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    path: Optional[str] = Field(
        default=None,
        description="Absolute filesystem path injected by loader",
    )

    url: Optional[HttpUrl] = None
    is_default: bool = False

    # ------------------------------------------------------------------
    # State
    # ------------------------------------------------------------------

    enabled: bool = True
    visible: bool = True
    feature_flag: Optional[Annotated[str, MinLen(1), MaxLen(64)]] = None

    # ------------------------------------------------------------------
    # RBAC
    # ------------------------------------------------------------------

    required_role: str = Field(
        default="none",
        description="Role required to access this page",
    )

    # ------------------------------------------------------------------
    # Presentation
    # ------------------------------------------------------------------

    icon: Optional[Annotated[str, MinLen(1), MaxLen(64)]] = None

    tags: List[Annotated[str, MinLen(1), MaxLen(32)]] = Field(
        default_factory=list,
        description="Tags for search, filtering, or grouping",
    )

    shortcut: Optional[Annotated[str, MinLen(1), MaxLen(40)]] = None

    # ------------------------------------------------------------------
    # Hierarchy
    # ------------------------------------------------------------------

    children: List["MenuStruct"] = Field(default_factory=list)
    parent: Optional[Annotated[str, MinLen(1), MaxLen(64)]] = None

    # ------------------------------------------------------------------
    # Extra metadata
    # ------------------------------------------------------------------

    telemetry: Dict[str, Any] = Field(default_factory=dict)
    extra: Dict[str, Any] = Field(default_factory=dict)

    # ------------------------------------------------------------------
    # Validators
    # ------------------------------------------------------------------

    @field_validator("path")
    @classmethod
    def validate_absolute_path(cls, v: Optional[str]):
        if v is None:
            return v
        p = Path(v)
        if not p.is_absolute():
            raise ValueError("path must be an absolute filesystem path")
        return v

    @field_validator("tags")
    @classmethod
    def dedupe_and_trim_tags(cls, v: List[str]):
        out, seen = [], set()
        for item in v:
            t = item.strip()
            if t and t not in seen:
                out.append(t)
                seen.add(t)
        return out

    @field_validator("key")
    @classmethod
    def enforce_key_format(cls, v: str):
        if not re.match(r"^[a-z0-9_-]+$", v):
            raise ValueError("key must match ^[a-z0-9_-]+$")
        return v


MenuStruct.model_rebuild()
