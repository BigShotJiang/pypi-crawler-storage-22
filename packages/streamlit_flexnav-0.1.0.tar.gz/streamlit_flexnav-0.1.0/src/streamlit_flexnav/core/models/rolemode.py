from enum import IntEnum

class RoleMode(IntEnum):
    NONE = 0
    VIEWER = 1
    EDITOR = 2
    KEYUSER = 3
    ADMIN = 4  # highest privilege

    def display_name(self) -> str:
        return {
            RoleMode.NONE: "None",
            RoleMode.VIEWER: "Viewer",
            RoleMode.EDITOR: "Editor",
            RoleMode.KEYUSER: "Key User",
            RoleMode.ADMIN: "Admin",
        }[self]

    @classmethod
    def from_label(cls, label: str) -> "RoleMode":
        normalized = label.strip().lower()
        for role in cls:
            if role.display_name().lower() == normalized:
                return role
        raise ValueError(f"Unknown role label: {label}")
