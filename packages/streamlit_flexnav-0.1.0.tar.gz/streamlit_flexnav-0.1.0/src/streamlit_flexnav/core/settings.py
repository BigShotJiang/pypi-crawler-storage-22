from __future__ import annotations

import os
import yaml
from pathlib import Path
import structlog

log = structlog.get_logger().bind(component="settings")


# -------------------------------------------------------------------
# ENVIRONMENT
# -------------------------------------------------------------------

ENV = os.getenv("FLEXNAV_ENV", "dev")
CONFIG_FILE = Path(f"settings.{ENV}.yaml")


# -------------------------------------------------------------------
# CONFIG LOADING (OPTIONAL)
# -------------------------------------------------------------------

def _load_yaml_config(path: Path) -> dict:
    """
    Load YAML config if it exists.
    If missing, return {} and log a warning.
    """
    if not path.exists():
        log.warning("config_file_missing", path=str(path))
        return {}

    try:
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        log.error("config_load_failed", path=str(path), error=str(e))
        return {}


RAW_CONFIG = _load_yaml_config(CONFIG_FILE)
CONFIG = RAW_CONFIG.get("flexnav", {})


# -------------------------------------------------------------------
# SAFE DEFAULTS
# -------------------------------------------------------------------

# Default menupages root (library-safe)
DEFAULT_MENUPAGES_ROOT = Path("app/menupages")

# Allow override from YAML config
MENUPAGES_ROOT = Path(CONFIG.get("menupages_root", DEFAULT_MENUPAGES_ROOT)).resolve()


# -------------------------------------------------------------------
# LOGGING
# -------------------------------------------------------------------

log.info(
    "settings_loaded",
    env=ENV,
    config_file=str(CONFIG_FILE),
    menupages_root=str(MENUPAGES_ROOT),
)
