import logging
import sys
from pathlib import Path
import structlog

from streamlit_flexnav.core.configs.admin_app_settings import load_admin_settings


def configure_logging():
    """
    Configure structlog with optional file logging.
    """

    settings = load_admin_settings()
    log_cfg = settings.flexnav.logging

    handlers = []

    # Console handler (always enabled)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(logging.Formatter("%(message)s"))
    handlers.append(console_handler)

    # Optional file handler
    if log_cfg.to_file:
        file_path = Path(log_cfg.file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(file_path, encoding="utf-8")
        file_handler.setFormatter(logging.Formatter("%(message)s"))
        handlers.append(file_handler)

    logging.basicConfig(
        level=getattr(logging, log_cfg.level.upper(), logging.INFO),
        handlers=handlers,
        format="%(message)s",
    )

    # Choose renderer
    if sys.stdout.isatty():
        renderer = structlog.dev.ConsoleRenderer()
    else:
        renderer = structlog.processors.JSONRenderer()

    structlog.configure(
        processors=[
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            renderer,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, log_cfg.level.upper(), logging.INFO)
        ),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
