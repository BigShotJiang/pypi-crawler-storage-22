from streamlit_flexnav.core.models.menugroup import MenuGroup

MENU = MenuGroup(
    key="settings_settings_user",
    label="Settings user",
    order=0,
    icon="📄",
    color = "blue",
    bold = False
    italic = False,
)    