from pathlib import Path
from streamlit_flexnav.core.models.menustruct import MenuStruct
import streamlit as st

PAGE = MenuStruct(
    key="settings_settings_admin",
    label="Settings admin",
    icon="📄",
    order=0,
    file=Path(__file__),
    group=None,
)

def render():
    st.title("Settings admin")
    st.write("This page uses render() instead of main().")
