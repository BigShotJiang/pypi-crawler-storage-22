from __future__ import annotations

import ast
import importlib.util
from pathlib import Path
import structlog

from streamlit_flexnav.core.models.menustruct import MenuStruct
from streamlit_flexnav.core.settings import MENUPAGES_ROOT

log = structlog.get_logger().bind(component="linter")


def run_linter() -> int:
    """
    Streamlit FlexNav Linter:
    - Import modules
    - Validate MenuStruct fields
    - Check for duplicate keys
    - Check for invalid paths
    - Check AST for bad patterns
    """

    print("\n=== STREAMLIT-FLEXNAV LINTER ===")
    print(f"Scanning: {MENUPAGES_ROOT.resolve()}")

    issues = 0
    keys_seen: set[str] = set()

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if file.name.startswith("_"):
            continue

        print(f"\n--- {file} ---")

        module = _import_module(file)
        if module is None:
            print("❌ Import failed")
            issues += 1
            continue

        items = _extract_menu_items(module)

        if not items:
            print("❌ No MenuStruct definitions found")
            issues += 1
            continue

        for item in items:
            # Unique key check
            if item.key in keys_seen:
                print(f"❌ Duplicate key '{item.key}'")
                issues += 1
            keys_seen.add(item.key)

            # Label check
            if not item.label.strip():
                print(f"❌ MenuStruct '{item.key}' missing label")
                issues += 1

            # Absolute path check
            if not item.path:
                print(f"❌ MenuStruct '{item.key}' missing injected path")
                issues += 1
            else:
                p = Path(item.path)
                if not p.is_absolute():
                    print(f"❌ MenuStruct '{item.key}' path is not absolute: {item.path}")
                    issues += 1
                elif not p.exists():
                    print(f"❌ MenuStruct '{item.key}' file does not exist: {item.path}")
                    issues += 1

        # main() check
        if not hasattr(module, "render"):
            print("❌ Missing render() function")
            issues += 1

        # AST checks
        issues += _lint_ast(file)

    print("\n=== SUMMARY ===")
    if issues == 0:
        print("✅ All checks passed")
    else:
        print(f"❌ {issues} issues found")

    print("=== END LINTER ===\n")
    return 0 if issues == 0 else 1


# -------------------------------------------------------------------
# Internal helpers
# -------------------------------------------------------------------

def _import_module(path: Path):
    """
    Import a menupage module safely under a unique namespace.
    """
    module_name = f"streamlit_flexnav_lint_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)

    try:
        spec.loader.exec_module(module)  # type: ignore
        log.debug("module_imported", file=str(path), module=module_name)
    except Exception as e:
        log.error("module_import_failed", file=str(path), error=str(e))
        return None

    return module


def _extract_menu_items(module):
    """
    Extract all MenuStruct instances from a module.
    """
    items = []
    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if isinstance(attr, MenuStruct):
            items.append(attr)
    return items


def _lint_ast(path: Path) -> int:
    """
    AST-level static checks:
    - No top-level Streamlit calls
    - No relative imports
    """

    issues = 0
    tree = ast.parse(path.read_text(encoding="utf-8"))

    for node in ast.walk(tree):

        # Disallow top-level Streamlit calls
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            func = node.value.func
            if isinstance(func, ast.Attribute) and func.attr in ("write", "title", "markdown"):
                print("❌ Top-level Streamlit call detected")
                issues += 1

        # Disallow relative imports
        if isinstance(node, ast.ImportFrom) and node.level > 0:
            print("❌ Relative import detected")
            issues += 1

    return issues
