from __future__ import annotations

from pathlib import Path
import structlog

from streamlit_flexnav.core.menuregistry import menuregistry

log = structlog.get_logger().bind(component="startup_checks")


def verify_menu_files_exist() -> None:
    """
    Verify that every MenuStruct with a path points to an existing file.
    Raises FileNotFoundError on first failure.
    """

    for item in menuregistry.all():
        if not item.path:
            continue

        # item.path is already an absolute path injected by the loader
        fs_path = Path(item.path)

        if not fs_path.is_absolute():
            log.error(
                "startup_path_not_absolute",
                key=item.key,
                raw_path=item.path,
                resolved=str(fs_path),
            )
            raise FileNotFoundError(
                f"MenuStruct '{item.key}' has non-absolute path: {fs_path}"
            )

        if not fs_path.exists():
            log.error(
                "startup_missing_file",
                key=item.key,
                raw_path=item.path,
                resolved=str(fs_path),
            )
            raise FileNotFoundError(
                f"Menu file missing for key '{item.key}': {fs_path}"
            )

    log.info("startup_verify_menu_files_ok", count=len(menuregistry.all()))
