from __future__ import annotations

import importlib.util
from pathlib import Path
import streamlit as st

from streamlit_flexnav.core.models.menustruct import MenuStruct


# -------------------------------------------------------------------
# Module loader
# -------------------------------------------------------------------

def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# -------------------------------------------------------------------
# Convert MenuStruct → st.Page
# -------------------------------------------------------------------

def menu_item_to_page(item: MenuStruct) -> st.Page:
    module = _load_module(Path(item.path))

    # Prefer render(), fallback to main()
    if hasattr(module, "render"):
        fn = module.render
    elif hasattr(module, "main"):
        fn = module.main
    else:
        raise RuntimeError(f"{item.file} has no render() or main() function")

    # Wrap to give Streamlit a unique callable name
    def wrapper():
        return fn()

    wrapper.__name__ = item.key  # unique URL path

    return st.Page(
        wrapper,
        title=item.label,
        icon=item.icon or ":material/description:",
    )
