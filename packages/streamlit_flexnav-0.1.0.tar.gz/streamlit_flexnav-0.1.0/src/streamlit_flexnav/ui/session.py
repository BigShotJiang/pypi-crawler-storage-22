import streamlit as st

def ensure_keys(**defaults):
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)
