from __future__ import annotations

import yaml
import structlog

from pathlib import Path

log = structlog.get_logger().bind(component="settings")

APP_ROOT = Path.cwd()
CONFIG_ROOT = APP_ROOT / "configs"
ADMIN_CONFIG_ROOT = CONFIG_ROOT / "admin"
USER_CONFIG_ROOT = CONFIG_ROOT / "user"
SETTINGS_FILE = ADMIN_CONFIG_ROOT / "settings.yaml"

DEFAULT_SETTINGS = {
    "flexnav": {
        "menupages": "menupages",
        "env": "dev",
    },
    "logging": {
        "to_file": False,
        "file_path": "logs",
        "level": "INFO",
    },
}

def ensure_settings_file() -> None:
    """
    Ensure configs/admin/settings.yaml exists.
    If missing, create folder structure and write default settings.
    """
    if SETTINGS_FILE.exists():
        return

    ADMIN_CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    USER_CONFIG_ROOT.mkdir(parents=True, exist_ok=True)

    with open(SETTINGS_FILE, "w") as f:
        yaml.dump(DEFAULT_SETTINGS, f, sort_keys=False)


def load_settings() -> dict:
    """
    Load settings.yaml, creating it if missing.
    """
    # ensure_settings_file()
    try:
        with open(SETTINGS_FILE, "r") as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        log.error("config_load_failed", path=str(SETTINGS_FILE), error=str(e))
        return {}

# -------------------------------------------------------------------
# ENVIRONMENT
# -------------------------------------------------------------------
_settings = load_settings()
_flexnav = _settings.get("flexnav", {})
log.info(
    "settings_loaded",
    config_file=str(SETTINGS_FILE),
)

# -------------------------------------------------------------------
# SAFE DEFAULTS
# -------------------------------------------------------------------
MENUPAGES_DIRNAME = _flexnav.get("menupages", "menupages")
MENUPAGES_ROOT = APP_ROOT / MENUPAGES_DIRNAME

ENV = _flexnav.get("env", "dev")

# -------------------------------------------------------------------
# LOGGING
# -------------------------------------------------------------------
log.info(
    "settings_loaded",
    env=ENV,
    config_file=str(SETTINGS_FILE),
    menupages_root=str(MENUPAGES_ROOT),
)