from __future__ import annotations

from pathlib import Path
import structlog

from streamlit_flexnav.core.menuregistry import menuregistry
from streamlit_flexnav.core.settings import MENUPAGES_ROOT

log = structlog.get_logger().bind(component="debug_paths")


def collect_path_info() -> list[dict]:
    """
    Collect resolved filesystem paths for all registered MenuStruct items.
    """
    rows = []

    for item in menuregistry.all():
        raw_path = item.path or ""
        if raw_path:
            resolved = (MENUPAGES_ROOT / raw_path.lstrip("/")).resolve()
            exists = resolved.exists()
        else:
            resolved = ""
            exists = False

        rows.append(
            {
                "key": item.key,
                "label": item.label,
                "raw_path": raw_path,
                "resolved_path": str(resolved),
                "exists": exists,
            }
        )

    log.info("debug_paths_collected", count=len(rows))
    return rows


def run_debug_paths() -> None:
    """
    Print a simple console table of resolved paths.
    """
    rows = collect_path_info()

    print("\nStreamlit FlexNav Path Debugger")
    print("-" * 80)
    for r in rows:
        print(
            f"{r['key']:20} | {r['resolved_path']:50} | "
            f"{'OK' if r['exists'] else 'MISSING'}"
        )
    print("-" * 80)
