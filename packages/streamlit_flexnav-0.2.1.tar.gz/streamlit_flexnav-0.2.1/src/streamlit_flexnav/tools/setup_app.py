from __future__ import annotations

import typer
from pathlib import Path
import yaml
import os

app = typer.Typer(help="FlexNav project scaffolding")


# ---------------------------------------------------------
# INTERNAL HELPERS
# ---------------------------------------------------------

def is_shadowing_streamlit_flexnav(path: Path) -> bool:
    return (
        (path / "streamlit_flexnav").exists() or
        (path / "streamlit_flexnav.py").exists()
    )


def is_home_directory(path: Path) -> bool:
    return path.resolve() == Path.home().resolve()


def compute_safe_root(app_name: str) -> Path:
    safe_base = Path.home() / "flexnav_apps"
    safe_base.mkdir(parents=True, exist_ok=True)
    return safe_base / app_name


# ---------------------------------------------------------
# PURE PYTHON ENTRYPOINT (callable from cli.py)
# ---------------------------------------------------------

def run_setup_app(app_name: str, folder_name: str | None) -> int:
    """
    Pure Python entrypoint used by cli.py.
    Does NOT use Typer options.
    """
    if not app_name.strip():
        app_name = "testapp"

    cwd = Path.cwd()

    if folder_name:
        intended_root = cwd / folder_name / app_name
    else:
        intended_root = cwd / app_name

    relocation_required = False
    warnings = []

    if is_home_directory(cwd):
        relocation_required = True
        warnings.append("You are running the CLI from your HOME directory.")

    if is_shadowing_streamlit_flexnav(cwd):
        relocation_required = True
        warnings.append("Your current directory contains 'streamlit_flexnav' which shadows the real package.")

    if is_shadowing_streamlit_flexnav(intended_root.parent):
        relocation_required = True
        warnings.append("The target folder contains a 'streamlit_flexnav' entry that would break imports.")

    if relocation_required:
        typer.echo("\n⚠ SAFETY WARNING:")
        for w in warnings:
            typer.echo(f" - {w}")

        root = compute_safe_root(app_name)
        typer.echo(f"\n➡ Automatically relocating project to safe location:\n   {root}\n")
    else:
        root = intended_root

    # Create folders
    root.mkdir(parents=True, exist_ok=True)

    menupages = root / "menupages"
    menupages_admin = menupages / "admin"
    admin_configs = root / "configs" / "admin"
    user_configs = root / "configs" / "user"
    logs = root / "logs"

    menupages.mkdir(parents=True, exist_ok=True)
    menupages_admin.mkdir(parents=True, exist_ok=True)
    admin_configs.mkdir(parents=True, exist_ok=True)
    user_configs.mkdir(parents=True, exist_ok=True)
    logs.mkdir(parents=True, exist_ok=True)

    # Files
    main_py = root / "main.py"
    settings_yaml = admin_configs / "settings.yaml"
    home_py = menupages / "home.py"
    sales_py = menupages / "sales.py"
    admin_menu = menupages_admin / "__menu__.py"
    admin_py = menupages_admin / "admin.py"

    if not main_py.exists():
        main_py.write_text(
            f"""from streamlit_flexnav.ui.navigator import render_navigation
from streamlit_flexnav.core.menuregistry import menuregistry
import streamlit as st

st.set_page_config(page_title="{app_name}", layout="wide")

menuregistry.reload()
render_navigation()
"""
        )

    if not home_py.exists():
        home_py.write_text(
            """from pathlib import Path
from streamlit_flexnav.core.models.menustruct import MenuStruct
import streamlit as st

PAGE = MenuStruct(
    key="home",
    label="Home",
    icon="📄",
    order=0,
    file=Path(__file__),
    group=None,
)

def render():
    st.title("Home")
    st.write("This page is the Home.")
"""
        )

    if not admin_py.exists():
        admin_py.write_text(
            """from pathlib import Path
from streamlit_flexnav.core.models.menustruct import MenuStruct
import streamlit as st

PAGE = MenuStruct(
    key="admin_dashboard",
    label="Admin Dashboard",
    icon="⚙️",
    order=0,
    file=Path(__file__),
    group="settings_admin",
)

def render():
    st.title("Admin Dashboard")
    st.write("This is the admin area.")
""")

    if not sales_py.exists():
        sales_py.write_text(
            """from pathlib import Path
from streamlit_flexnav.core.models.menustruct import MenuStruct
import streamlit as st

PAGE = MenuStruct(
    key="report_sales",
    label="Sales",
    icon="⚙️",
    order=0,
    file=Path(__file__),
    group="reporting",
)

def render():
    st.title("Report sales")
    st.write("This the report sales area")
""")

    if not admin_menu.exists():
        admin_menu.write_text(
            """from streamlit_flexnav.core.models.menugroup import MenuGroup

MENU = MenuGroup(
    key="settings_admin",
    label="Admin",
    order=9000,
    icon="⚙️",
    color="blue",
    bold=True,
    italic=False,
)
"""
        )

    if not settings_yaml.exists():
        settings_yaml.write_text(
            yaml.dump(
                {
                    "flexnav": {
                        "menupages": "menupages",
                        "env": "dev",
                        "app_name": app_name,
                    },
                    "logging": {
                        "to_file": False,
                        "file_path": "logs",
                        "level": "INFO",
                    },
                },
                sort_keys=False,
            )
        )

    typer.echo(f"✔ FlexNav project initialized in:\n  {root}")
    return 0


# ---------------------------------------------------------
# TYPER COMMAND (CLI-facing)
# ---------------------------------------------------------

@app.command("setup_app")
def setup_app_cmd(
    app_name: str = typer.Option("FlexNav App", "--app-name", "-a"),
    folder_name: str = typer.Option(None, "--folder-name", "-f"),
):
    """
    Typer command wrapper that forwards arguments to run_setup_app().
    """
    code = run_setup_app(app_name, folder_name)
    raise typer.Exit(code=code)

