# streamlit-flexnav

THE PROJECT IS STILL UNDERGOING CHANGES
FIRST RELEASE WILL BE 1.0.0
We are currently testing

A modular, schema‑driven navigation framework for Streamlit applications.  
`streamlit-flexnav` provides a clean, extensible way to define menus, pages, roles, and navigation behavior using YAML/JSON schemas — with automatic UI rendering,
access control, and a powerful plugin‑ready architecture.
The python modules (*.py) are placed in a folder and a menu is automaticaly generated.
You can change icon and colors on the fly, streamlit-flexnav takes care.

- [streamlit-flexnav](#streamlit-flexnav)
  - [✨ Features](#-features)
  - [📦 Installation](#-installation)
  - [🚀 Quick Start](#-quick-start)
  - [🧭 Navigation Behavior](#-navigation-behavior)
  - [⚙️ Configuration](#️-configuration)
  - [🛠 CLI Tools](#-cli-tools)
  - [📁 Project Structure](#-project-structure)
  - [🧪 Development](#-development)
  - [📄 License](#-license)
  - [⭐ Acknowledgements](#-acknowledgements)
  - [](#)

---

## ✨ Features

- **Schema‑driven navigation** (YAML/JSON)
- **Automatic Streamlit UI rendering**
- **Role‑based access control**
- **Menu groups, pages, icons, and metadata**
- **Configurable sidebar behavior**
- **CLI tools for debugging, linting, and fixing schemas**
- **Plugin‑friendly architecture**
- **Fast, reproducible builds using uv**

---

## 📦 Installation

Install from PyPI:
```
pip install streamlit-flexnav
```
Or using uv:
```
uv add streamlit-flexnav
```

---
## 🚀 Quick Start 

[](QUICKSTART.md)

## 🧭 Navigation Behavior
Navigator automatically:<br>
    - Renders menu groups and pages<br>
    - Applies role‑based access control<br>
    - Highlights the active page<br>
    - Supports icons, dividers, and collapsible groups<br>
    - Integrates seamlessly with Streamlit’s session state

---
## ⚙️ Configuration

```
TODO
menu settings
Page settings
```

## 🛠 CLI Tools
After installation, the CLI becomes available:<br>
streamlit-flexnav --help
```
Command   	Description
doctor	    Diagnose common configuration issues
fix-keys    Normalize schema keys
debug-paths	Show resolved paths
linter	    Validate schema structure
startup-checks	Run environment checks
```

## 📁 Project Structure
```
src/streamlit_flexnav/
  core/          # Loaders, registries, settings, schema logic
  ui/            # Streamlit UI components
  tools/         # CLI tools
  configs/       # Default configuration files
  images/        # Icons and static assets
  menupages/     # Built-in menu pages
```
TODO See API_REFERENCE.md for full details.

## 🧪 Development
Clone the repository:
```
git clone https://github.com/informatie/streamlit-flexnav
cd streamlit-flexnav
```
Set up the environment:
```
uv venv
uv sync
source .venv/bin/activate
```
## 📄 License
MIT License — see LICENSE for details.

## ⭐ Acknowledgements

UPDATE DOCU

If you want, I can also do/make
- check correctness of foldernames
- page where you can modify:
  - the menu settings
  - the page settings
- drag/drop folders 
- drag/drop pages
- an init setup with an example application

Just tell me which one you want next.
- rbac must be integrated
- a watcher to monitor
- user defined settings for a menu.
- protect admin settings
- implement SSO and others

## 