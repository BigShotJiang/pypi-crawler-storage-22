from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
import structlog

from streamlit_flexnav.core.settings import MENUPAGES_ROOT
from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.models.menugroup import MenuGroup

log = structlog.get_logger().bind(component="loader")


def _load_module_from_path(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[path.stem] = module
    spec.loader.exec_module(module)
    return module


def load_menupages() -> list[PageStruct]:
    """
    Scan MENUPAGES_ROOT for .py files and extract PAGE = PageStruct(...) definitions.
    Folder structure is flattened into a single group name:
        folder1/folder2/folder3 → "folder1_folder2_folder3"
    """
    results: list[PageStruct] = []

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if file.name.startswith("_"):
            continue

        try:
            module = _load_module_from_path(file)

            if not hasattr(module, "PAGE"):
                log.warning("missing_PAGE_struct", file=str(file))
                continue

            page_struct = module.PAGE

            if not isinstance(page_struct, PageStruct):
                log.error("invalid_PAGE_type", file=str(file))
                continue

            # Inject absolute path
            page_struct.path = str(file.resolve())

            # Compute flattened group name
            relative = file.relative_to(MENUPAGES_ROOT)
            parts = relative.parts[:-1]  # folders only

            group = "_".join(parts) if parts else None
            page_struct.group = group

            results.append(page_struct)

        except Exception as e:
            log.exception("failed_loading_page", file=str(file), error=str(e))

    log.info("menupages_loaded", count=len(results))
    return results



def load_menugroups() -> list[MenuGroup]:
    """
    Discover all MenuGroup definitions under MENUPAGES_ROOT.

    Expected pattern inside each module:
        MENU = MenuGroup(...)
    """
    results: list[MenuGroup] = []

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if not file.name.startswith("__menu__"):
            continue

        try:
            module = _load_module_from_path(file)

            menu_struct = getattr(module, "MENU", None)
            if menu_struct is None:
                continue

            if not isinstance(menu_struct, MenuGroup):
                log.error("invalid_MENU_type", file=str(file))
                continue

            # Inject provenance
            menu_struct.path = str(file.resolve())

            results.append(menu_struct)

        except Exception as e:
            log.exception(
                "failed_loading_menugroup",
                file=str(file),
                error=str(e),
            )

    log.info("menugroups_loaded", count=len(results))
    return results

