from __future__ import annotations

from pydantic import BaseModel, Field


# -------------------------------------------------------------------
# FLEXNAV SETTINGS
# -------------------------------------------------------------------

class FlexnavSettings(BaseModel):
    """
    Schema for the [flexnav] section of settings.yaml.
    Controls navigation behavior and environment mode.
    """

    menupages: str = Field(
        default="menupages",
        description="Folder name containing page modules.",
    )

    env: str = Field(
        default="dev",
        description="Environment identifier (dev/staging/prod).",
    )


# -------------------------------------------------------------------
# LOGGING SETTINGS
# -------------------------------------------------------------------

class LoggingSettings(BaseModel):
    """
    Schema for the [logging] section of settings.yaml.
    Controls log output behavior.
    """

    to_file: bool = Field(
        default=False,
        description="Whether to write logs to a file.",
    )

    file_path: str = Field(
        default="logs",
        description="Directory where log files are stored.",
    )

    level: str = Field(
        default="INFO",
        description="Logging level (DEBUG/INFO/WARNING/ERROR).",
    )


# -------------------------------------------------------------------
# ROOT SETTINGS OBJECT
# -------------------------------------------------------------------

class Settings(BaseModel):
    """
    Top-level schema for settings.yaml.
    """

    flexnav: FlexnavSettings = Field(
        default_factory=FlexnavSettings,
        description="FlexNav configuration.",
    )

    logging: LoggingSettings = Field(
        default_factory=LoggingSettings,
        description="Logging configuration.",
    )
