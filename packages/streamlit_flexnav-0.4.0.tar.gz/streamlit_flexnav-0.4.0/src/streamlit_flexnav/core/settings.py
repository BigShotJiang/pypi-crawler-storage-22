from __future__ import annotations

import yaml
import structlog
from pathlib import Path
from pydantic import ValidationError

from streamlit_flexnav.core.models.settingsstruct import Settings

log = structlog.get_logger().bind(component="settings")

# -------------------------------------------------------------------
# CONSTANTS (pure, no I/O)
# -------------------------------------------------------------------

APP_ROOT = Path.cwd()
CONFIG_ROOT = APP_ROOT / "configs"
ADMIN_CONFIG_ROOT = CONFIG_ROOT / "admin"
USER_CONFIG_ROOT = CONFIG_ROOT / "user"
SETTINGS_FILE = ADMIN_CONFIG_ROOT / "settings.yaml"

DEFAULT_SETTINGS = {
    "flexnav": {
        "menupages": "menupages",
        "env": "dev",
    },
    "logging": {
        "to_file": False,
        "file_path": "logs",
        "level": "INFO",
    },
}

# -------------------------------------------------------------------
# FILE OPERATIONS (pure functions)
# -------------------------------------------------------------------

def ensure_settings_file(path: Path | None = None) -> None:
    """
    Ensure configs/admin/settings.yaml exists.
    """
    if path is None:
        path = SETTINGS_FILE

    if path.exists():
        return

    admin_root = path.parent
    user_root = admin_root.parent / "user"

    admin_root.mkdir(parents=True, exist_ok=True)
    user_root.mkdir(parents=True, exist_ok=True)

    with open(path, "w") as f:
        yaml.dump(DEFAULT_SETTINGS, f, sort_keys=False)

def load_settings(path: Path | None = None) -> Settings:
    """
    Load and validate settings.yaml.
    Returns a Settings object with defaults applied.
    """
    if path is None:
        path = SETTINGS_FILE

    try:
        with open(path, "r") as f:
            raw = yaml.safe_load(f) or {}
    except Exception as e:
        log.error("config_load_failed", path=str(path), error=str(e))
        return Settings()  # safe fallback

    try:
        return Settings(**raw)
    except ValidationError as e:
        log.error("config_schema_invalid", errors=e.errors())
        return Settings()  # safe fallback
    
# -------------------------------------------------------------------
# INITIALIZATION LOGIC (pure, testable)
# -------------------------------------------------------------------

def compute_runtime_settings(
    app_root: Path = APP_ROOT,
    settings_path: Path = SETTINGS_FILE,
) -> dict:
    """
    Compute ENV, MENUPAGES_DIRNAME, MENUPAGES_ROOT from the settings file.
    Pure function: no side effects, no global state.
    """
    settings = load_settings(settings_path)
    flexnav = settings.flexnav

    return {
        "ENV": flexnav.env,
        "MENUPAGES_DIRNAME": flexnav.menupages,
        "MENUPAGES_ROOT": app_root / flexnav.menupages,
    }

# -------------------------------------------------------------------
# PUBLIC API (mutable, but controlled)
# -------------------------------------------------------------------

def reload_settings() -> None:
    """
    Recompute runtime settings and update module-level globals.
    """
    global ENV, MENUPAGES_DIRNAME, MENUPAGES_ROOT

    values = compute_runtime_settings(APP_ROOT, SETTINGS_FILE)
    ENV = values["ENV"]
    MENUPAGES_DIRNAME = values["MENUPAGES_DIRNAME"]
    MENUPAGES_ROOT = values["MENUPAGES_ROOT"]

    log.info(
        "settings_loaded",
        env=ENV,
        config_file=str(SETTINGS_FILE),
        menupages_root=str(MENUPAGES_ROOT),
    )

# Initialize once
reload_settings()
