from __future__ import annotations

import os
import json
import re
from pathlib import Path
from typing import List, Optional

import typer
import yaml
import structlog

from streamlit_flexnav.core.settings import (
    MENUPAGES_ROOT,
    ENV,
)
APP_ROOT = Path.cwd()
CONFIG_ROOT = APP_ROOT / "configs"
ADMIN_CONFIG_ROOT = CONFIG_ROOT / "admin"
USER_CONFIG_ROOT = CONFIG_ROOT / "user"
SETTINGS_FILE = ADMIN_CONFIG_ROOT / "settings.yaml"

from streamlit_flexnav.core.loader import load_menupages
from streamlit_flexnav.core.models.pagestruct import PageStruct

from streamlit_flexnav.tools.linter import run_linter
from streamlit_flexnav.tools.doctor import run_doctor
from streamlit_flexnav.tools.fix_keys import run_fix_keys
# from streamlit_flexnav.tools.fix_streamlit_pages import run_fix_pages
from streamlit_flexnav.tools.debug_paths import run_debug_paths
from streamlit_flexnav.tools.startup_checks import verify_menu_files_exist
from streamlit_flexnav.tools.setup_app import run_setup_app


log = structlog.get_logger().bind(component="cli")

app = typer.Typer(help="Streamlit FlexNav CLI")
page_app = typer.Typer(help="Menupage operations")
config_app = typer.Typer(help="FlexNav configuration tools")

app.add_typer(page_app, name="page")
app.add_typer(config_app, name="config")


# -------------------------------------------------------------------
# INTERNAL HELPERS
# -------------------------------------------------------------------

STRICT_TEMPLATE = '''\
from __future__ import annotations
from streamlit_flexnav.core.models.pagestruct import PageStruct


page = PageStruct(
    key="{key}",
    label="{label}",
    icon="{icon}",
    order={order},
    session_keys={},
)


def main():
    import streamlit as st
    st.title("{label}")
    st.write("Page content goes here.")
'''


def _sanitize_key_from_path(rel_path: Path) -> str:
    base = rel_path.stem.lower()
    base = re.sub(r"[^a-z0-9]+", "_", base)
    base = re.sub(r"_+", "_", base).strip("_")
    return base[:64] or "page"


def _import_module(path: Path):
    module_name = f"streamlit_flexnav_cli_{path.stem}"
    spec = __import__("importlib").util.spec_from_file_location(module_name, path)
    module = __import__("importlib").util.module_from_spec(spec)

    try:
        spec.loader.exec_module(module)  # type: ignore
    except Exception as e:
        log.error("module_import_failed", file=str(path), error=str(e))
        return None

    return module


def _extract_menu_items(module) -> List[PageStruct]:
    items: List[PageStruct] = []
    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if isinstance(attr, PageStruct):
            items.append(attr)
    return items


def _run_validate() -> None:
    typer.echo("\n=== STREAMLIT-FLEXNAV VALIDATE ===")
    run_linter()
    run_doctor()
    typer.echo("=== END VALIDATE ===\n")


# -------------------------------------------------------------------
# PAGE COMMANDS
# -------------------------------------------------------------------

@page_app.command("create")
def page_create(
    path: str = typer.Argument(..., help="Path under menupages/, e.g. reports/sales"),
    label: str = typer.Option(..., "--label", help="Sidebar label"),
    icon: str = typer.Option("📄", "--icon", help="Sidebar icon"),
    order: int = typer.Option(100, "--order", help="Menu order"),
) -> None:
    """
    Create a new menupage file with a strict PageStruct template.
    """
    rel_path = Path(path.strip("/"))
    file_path = MENUPAGES_ROOT / rel_path.with_suffix(".py")

    file_path.parent.mkdir(parents=True, exist_ok=True)

    if file_path.exists():
        typer.echo(f"❌ File already exists: {file_path}")
        raise typer.Exit(code=1)

    key = _sanitize_key_from_path(rel_path)

    content = STRICT_TEMPLATE.format(
        key=key,
        label=label,
        icon=icon,
        order=order,
    )

    file_path.write_text(content, encoding="utf-8")

    typer.echo(f"✅ Created menupage: {file_path}")
    typer.echo("\nRunning linter...")
    run_linter()


@page_app.command("list")
def page_list() -> None:
    """
    List all menupages with key, label, icon, and file path.
    """
    typer.echo("\n=== STREAMLIT-FLEXNAV PAGES ===")

    pages: list[tuple[str, str, Optional[str], Path]] = []

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if file.name.startswith("_"):
            continue

        module = _import_module(file)
        if module is None:
            continue

        items = _extract_menu_items(module)
        for item in items:
            pages.append((item.key, item.label, item.icon, file.resolve()))

    if not pages:
        typer.echo("❌ No pages found")
        return

    pages.sort(key=lambda x: x[0])

    for key, label, icon, file in pages:
        typer.echo(f"{icon or '•'}  {key:<20}  {label:<30}  {file}")

    typer.echo(f"\nTotal: {len(pages)}")
    typer.echo("=== END LIST ===\n")


@page_app.command("delete")
def page_delete(
    path: str = typer.Argument(..., help="Path under menupages/, e.g. reports/sales"),
) -> None:
    """
    Delete a menupage file.
    """
    rel_path = Path(path.strip("/"))
    file_path = MENUPAGES_ROOT / rel_path.with_suffix(".py")

    if not file_path.exists():
        typer.echo(f"❌ Page not found: {file_path}")
        raise typer.Exit(code=1)

    file_path.unlink()
    typer.echo(f"🗑️  Deleted: {file_path}")

    typer.echo("\nRunning doctor...")
    run_doctor()


@page_app.command("rename")
def page_rename(
    old: str = typer.Argument(..., help="Old path"),
    new: str = typer.Argument(..., help="New path"),
) -> None:
    """
    Rename a menupage file.
    """
    old_path = MENUPAGES_ROOT / Path(old.strip("/")).with_suffix(".py")
    new_path = MENUPAGES_ROOT / Path(new.strip("/")).with_suffix(".py")

    if not old_path.exists():
        typer.echo(f"❌ Page not found: {old_path}")
        raise typer.Exit(code=1)

    if new_path.exists():
        typer.echo(f"❌ Target already exists: {new_path}")
        raise typer.Exit(code=1)

    new_path.parent.mkdir(parents=True, exist_ok=True)
    old_path.rename(new_path)

    typer.echo(f"🔄 Renamed:\n  {old_path}\n→ {new_path}")

    typer.echo("\nRunning validate...")
    _run_validate()


@page_app.command("move")
def page_move(
    old: str = typer.Argument(..., help="Old path"),
    new: str = typer.Argument(..., help="New path"),
) -> None:
    """
    Move a menupage file (alias for rename).
    """
    page_rename(old, new)


@page_app.command("export")
def page_export() -> None:
    """
    Export all menupages as JSON.
    """
    typer.echo("\n=== STREAMLIT-FLEXNAV EXPORT-PAGES ===")

    pages: list[dict[str, object]] = []

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if file.name.startswith("_"):
            continue

        module = _import_module(file)
        if module is None:
            continue

        items = _extract_menu_items(module)
        for item in items:
            pages.append(
                {
                    "key": item.key,
                    "label": item.label,
                    "icon": item.icon,
                    "order": item.order,
                    "path": str(file.resolve()),
                }
            )

    pages.sort(key=lambda x: x["key"])

    typer.echo(json.dumps(pages, indent=2, ensure_ascii=False))

    typer.echo("\n=== END EXPORT-PAGES ===\n")


@page_app.command("tree")
def page_tree() -> None:
    """
    Print a simple menu tree (flat + children).
    """
    typer.echo("\n=== STREAMLIT-FLEXNAV TREE ===")

    pages = load_menupages()
    pages.sort(key=lambda p: p.order)

    for page in pages:
        typer.echo(f"{page.icon or '•'} {page.key}  —  {page.label}")
        if page.children:
            for child in page.children:
                typer.echo(f"   └─ {child.icon or '•'} {child.key}  —  {child.label}")

    typer.echo("=== END TREE ===\n")


@page_app.command("fix-keys")
def page_fix_keys() -> None:
    """
    Scan menupages and suggest sanitized PageStruct.key values.
    """
    run_fix_keys()


@page_app.command("validate")
def page_validate() -> None:
    """
    Run linter + doctor.
    """
    _run_validate()


# -------------------------------------------------------------------
# CONFIG COMMANDS
# -------------------------------------------------------------------

@config_app.command("show")
def config_show() -> None:
    """
    Show the active FlexNav configuration.
    """
    typer.echo("\n=== STREAMLIT-FLEXNAV CONFIG ===")

    typer.echo(f"Environment:        {ENV}")
    typer.echo(f"Config file:        {SETTINGS_FILE}")

    if SETTINGS_FILE:
        typer.echo("\nYAML contents:")
        typer.echo(yaml.safe_dump(SETTINGS_FILE, sort_keys=False))
    else:
        typer.echo("\nYAML contents:      <none> (using defaults)")

    typer.echo("\nResolved settings:")
    typer.echo(f"  menupages:   {MENUPAGES_ROOT}")

    typer.echo("\n=== END CONFIG ===\n")


@config_app.command("edit")
def config_edit() -> None:
    """
    Open the active YAML config file in $EDITOR.
    If missing, create a starter config first.
    """
    if not SETTINGS_FILE.exists():
        typer.echo(f"Config file does not exist, creating: {SETTINGS_FILE}")
        starter = {"flexnav": {"menupages": "menupages","env": "dev"}}
        SETTINGS_FILE.write_text(yaml.safe_dump(starter, sort_keys=False), encoding="utf-8")

    editor = os.getenv("EDITOR", "nano")
    typer.echo(f"Opening {SETTINGS_FILE} in {editor}")
    os.system(f"{editor} {SETTINGS_FILE}")

@config_app.command("validate")
def config_validate() -> None:
    """
    Validate the YAML config structure.
    """
    typer.echo(f"Validating config: {SETTINGS_FILE}")

    if not SETTINGS_FILE:
        typer.echo("⚠️  No YAML config found — using defaults.")
        raise typer.Exit(code=0)

    if "flexnav" not in SETTINGS_FILE:
        typer.echo("❌ Missing top-level 'flexnav' key")
        raise typer.Exit(code=1)

    if "menupages" not in SETTINGS_FILE["flexnav"]:
        typer.echo("❌ Missing 'menupages' under flexnav")
        raise typer.Exit(code=1)

    if "env" not in SETTINGS_FILE["flexnav"]:
        typer.echo("❌ Missing 'env' under flexnav")
        raise typer.Exit(code=1)

    typer.echo("✅ Config structure is valid")


@config_app.command("explain")
def config_explain() -> None:
    """
    Explain how the final configuration was computed.
    """
    typer.echo("\n=== STREAMLIT-FLEXNAV CONFIG EXPLAIN ===")

    typer.echo(f"Environment:        {ENV}")
    typer.echo(f"Config file:        {CONFIG_FILE}")

    if SETTINGS_FILE:
        typer.echo("\nYAML loaded:")
        typer.echo(yaml.safe_dump(SETTINGS_FILE, sort_keys=False))
    else:
        typer.echo("\nYAML loaded:        <none> (using defaults)")

    typer.echo("\nFinal resolved settings:")
    typer.echo(f"  menupages:   {MENUPAGES_ROOT}")

    typer.echo("\nSource breakdown:")
    if SETTINGS_FILE and "menupages" in CONFIG:
        typer.echo(f"  menupages:   from YAML → {CONFIG['menupages']}")
    else:
        typer.echo(f"  menupages:   default → {MENUPAGES_ROOT}")

    typer.echo("\n=== END CONFIG EXPLAIN ===\n")


# -------------------------------------------------------------------
# TOP-LEVEL COMMANDS
# -------------------------------------------------------------------
from streamlit_flexnav.tools.setup_app import run_setup_app

@app.command("setup_app")
def setup_app_cmd(
    app_name: str = typer.Option("FlexNav App", "--app-name", "-a"),
    folder_name: str = typer.Option(None, "--folder-name", "-f"),
):
    """
    Typer command wrapper that forwards arguments to run_setup_app().
    """
    code = run_setup_app(app_name, folder_name)
    raise typer.Exit(code=code)


@app.command("debug-paths")
def cmd_debug_paths() -> None:
    code = run_debug_paths()
    raise typer.Exit(code=code)

@app.command("doctor")
def cmd_doctor() -> None:
    code = run_doctor()
    raise typer.Exit(code=code)

@app.command("linter")
def cmd_linter() -> None:
    code = run_linter()
    raise typer.Exit(code=code)

#@app.command("fix-pages")
#def cmd_run_fix_pages() -> None:
#    run_fix_pages()


@app.command("startup-check")
def cmd_startup_check() -> None:
    try:
        verify_menu_files_exist()
        typer.echo("Startup check passed. All menu files exist.")
    except Exception as e:
        typer.echo(f"Startup check failed: {e}")
        raise typer.Exit(code=1)

@app.command("show-completion")
def show_completion() -> None:
    """
    Show the autocompletion script for your shell.
    """
    typer.echo("To view the autocompletion script, run:")
    typer.echo("\n  streamlit-flexnav --show-completion\n")


# -------------------------------------------------------------------
# ENTRYPOINT
# -------------------------------------------------------------------

def main() -> None:
    app()


if __name__ == "__main__":
    main()
