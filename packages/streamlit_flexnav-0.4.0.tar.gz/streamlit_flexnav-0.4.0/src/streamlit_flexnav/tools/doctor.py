from __future__ import annotations

from pathlib import Path
import importlib.util
import structlog

from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.settings import MENUPAGES_ROOT

log = structlog.get_logger().bind(component="doctor")


def run_doctor() -> int:
    """
    Streamlit FlexNav Doctor:
    - Import each menupage module
    - Validate PageStruct definitions
    - Check resolved absolute paths
    - Check for missing main()
    - Report structural issues

    Returns:
        0 if all checks pass, >0 if issues found.
    """

    print("\n=== STREAMLIT-FLEXNAV DOCTOR ===")
    print(f"Scanning: {MENUPAGES_ROOT.resolve()}")

    issues = 0

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if file.name.startswith("_"):
            continue

        print(f"\n--- {file} ---")

        module = _import_module(file)
        if module is None:
            print("❌ Import failed")
            issues += 1
            continue

        items = _extract_menu_items(module)

        if not items:
            print("❌ No PageStruct definitions found")
            issues += 1
            continue

        for item in items:
            # Validate injected path
            if not item.path:
                print(f"❌ PageStruct '{item.key}' missing injected path")
                issues += 1
                continue

            resolved = Path(item.path)

            if not resolved.is_absolute():
                print(f"❌ PageStruct '{item.key}' path is not absolute: {item.path}")
                issues += 1
            elif not resolved.exists():
                print(f"❌ PageStruct '{item.key}' file does not exist: {item.path}")
                issues += 1

            # Validate label
            if not item.label.strip():
                print(f"❌ PageStruct '{item.key}' has empty label")
                issues += 1

        # Check for main()
        if not hasattr(module, "main"):
            print("⚠️  No main() function defined")

    print("\n=== SUMMARY ===")
    if issues == 0:
        print("✅ All checks passed")
    else:
        print(f"❌ {issues} issues found")

    print("=== END DOCTOR ===\n")
    return 0 if issues == 0 else 1


# -------------------------------------------------------------------
# Internal helpers
# -------------------------------------------------------------------

def _import_module(path: Path):
    """
    Import a menupage module safely under a unique namespace.
    """
    module_name = f"streamlit_flexnav_doctor_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)

    try:
        spec.loader.exec_module(module)  # type: ignore
        log.debug("module_imported", file=str(path), module=module_name)
    except Exception as e:
        log.error("module_import_failed", file=str(path), error=str(e))
        return None

    return module


def _extract_menu_items(module):
    """
    Extract all PageStruct instances from a module.
    """
    items = []
    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if isinstance(attr, PageStruct):
            items.append(attr)
    return items
