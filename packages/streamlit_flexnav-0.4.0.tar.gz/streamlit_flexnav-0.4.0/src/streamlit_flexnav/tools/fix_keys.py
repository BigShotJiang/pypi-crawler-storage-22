from __future__ import annotations

import re
from pathlib import Path
import importlib.util

import structlog

from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.settings import MENUPAGES_ROOT

log = structlog.get_logger().bind(component="fix_keys")


_KEY_PATTERN = re.compile(r"^[a-z0-9_]+$")


def _sanitize_key(label: str) -> str:
    """
    Convert a label into a safe PageStruct.key value.
    """
    base = label.strip().lower()
    base = re.sub(r"[^a-z0-9]+", "_", base)
    base = re.sub(r"_+", "_", base).strip("_")
    if not base:
        base = "page"
    return base[:64]


def run_fix_keys() -> int:
    """
    Scan menupages, detect invalid PageStruct.key values,
    and propose sanitized replacements.

    This tool prints suggestions; it does not modify files.
    """

    print("\n=== STREAMLIT-FLEXNAV FIX-KEYS ===")
    print(f"Scanning: {MENUPAGES_ROOT.resolve()}")

    issues = 0

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if file.name.startswith("_"):
            continue

        print(f"\n--- {file} ---")

        module = _import_module(file)
        if module is None:
            print("❌ Import failed")
            issues += 1
            continue

        items = _extract_menu_items(module)

        if not items:
            print("❌ No PageStruct definitions found")
            issues += 1
            continue

        for item in items:
            if not _KEY_PATTERN.match(item.key):
                suggested = _sanitize_key(item.label or item.key)
                print(
                    f"❌ Invalid key '{item.key}' "
                    f"→ suggested: '{suggested}'"
                )
                issues += 1
            else:
                print(f"✅ Key OK: {item.key}")

    print("\n=== SUMMARY ===")
    if issues == 0:
        print("✅ All keys valid")
    else:
        print(f"❌ {issues} invalid keys found (see suggestions above)")

    print("=== END FIX-KEYS ===\n")
    return 0 if issues == 0 else 1


# -------------------------------------------------------------------
# Internal helpers
# -------------------------------------------------------------------

def _import_module(path: Path):
    """
    Import a menupage module safely under a unique namespace.
    """
    module_name = f"streamlit_flexnav_fixkeys_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)

    try:
        spec.loader.exec_module(module)  # type: ignore
        log.debug("module_imported", file=str(path), module=module_name)
    except Exception as e:
        log.error("module_import_failed", file=str(path), error=str(e))
        return None

    return module


def _extract_menu_items(module):
    """
    Extract all PageStruct instances from a module.
    """
    items = []
    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if isinstance(attr, PageStruct):
            items.append(attr)
    return items
