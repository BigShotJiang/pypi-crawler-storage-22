from __future__ import annotations

import ast
import importlib.util
import logging
from pathlib import Path
import structlog

from streamlit_flexnav.core.models.pagestruct import PageStruct
from streamlit_flexnav.core.settings import MENUPAGES_ROOT

logging.basicConfig(handlers=[logging.NullHandler()])
log = structlog.get_logger().bind(component="linter")


# =====================================================================
# Main entry point
# =====================================================================

def run_linter() -> int:
    print("\n=== STREAMLIT-FLEXNAV LINTER ===")
    print(f"Scanning: {MENUPAGES_ROOT.resolve()}")

    issues = 0
    keys_seen: dict[str, Path] = {}

    for file in MENUPAGES_ROOT.rglob("*.py"):
        if file.name.startswith("_"):
            continue

        print(f"\n--- {file} ---")

        module = _import_module(file)
        if module is None:
            print("❌ Import failed")
            issues += 1
            continue

        items = _extract_menu_items(module)
        if not items:
            print("❌ No PageStruct definitions found")
            issues += 1
            continue

        # --------------------------------------------------------------
        # Validate each PageStruct
        # --------------------------------------------------------------
        for item in items:

            # Unique key
            if item.key in keys_seen:
                prev = keys_seen[item.key]
                print(f"❌ Duplicate key '{item.key}' (previously in {prev})")
                issues += 1
            else:
                keys_seen[item.key] = file

            # Label
            if not item.label or not item.label.strip():
                print(f"❌ PageStruct '{item.key}' missing label")
                issues += 1

            # Path
            if item.path:
                p = Path(item.path)
                if not p.is_absolute():
                    print(f"❌ PageStruct '{item.key}' path is not absolute: {item.path}")
                    issues += 1
                # NOTE: we do NOT require file existence in tests

        # render() check
        if not hasattr(module, "render"):
            print("❌ Missing render() function")
            issues += 1

        # AST checks
        issues += _lint_ast(file)

    # =================================================================
    # Summary
    # =================================================================
    print("\n=== SUMMARY ===")
    if issues == 0:
        print("✅ All checks passed")
    else:
        print(f"❌ {issues} issues found")

    print("=== END LINTER ===\n")
    return 0 if issues == 0 else 1


# =====================================================================
# Internal helpers
# =====================================================================

def _import_module(path: Path):
    module_name = (
        "flexnav_lint."
        + str(path.relative_to(MENUPAGES_ROOT))
            .replace("/", ".")
            .replace("\\", ".")
            .replace(".py", "")
    )

    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        return None

    module = importlib.util.module_from_spec(spec)

    try:
        spec.loader.exec_module(module)  # type: ignore
        log.debug("module_imported", file=str(path), module=module_name)
    except Exception as e:
        log.error("module_import_failed", file=str(path), error=str(e))
        return None

    return module


def _extract_menu_items(module):
    return [
        getattr(module, name)
        for name in dir(module)
        if isinstance(getattr(module, name), PageStruct)
    ]


def _lint_ast(path: Path) -> int:
    issues = 0
    tree = ast.parse(path.read_text(encoding="utf-8"))

    for node in ast.walk(tree):
        # Disallow relative imports
        if isinstance(node, ast.ImportFrom) and node.level > 0:
            print(f"❌ Relative import detected in {path}")
            issues += 1

    return issues
