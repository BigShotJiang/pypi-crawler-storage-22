from __future__ import annotations

import sys
import structlog

from streamlit_flexnav.tools.debug_paths import print_debug_paths
from streamlit_flexnav.tools.startup_checks import verify_menu_files_exist
from streamlit_flexnav.tools.doctor import run_doctor
from streamlit_flexnav.tools.fix_streamlit_pages import run_fix_pages
from streamlit_flexnav.tools.linter import run_linter
from streamlit_flexnav.tools.setup_init import app

# Page operations come from the CLI module
from streamlit_flexnav.tools.cli import (
    create_page,
    list_pages,
    delete_page,
    rename_page,
    move_page,
    fix_keys,
    print_tree,
    export_pages,
    run_validate,
)

log = structlog.get_logger().bind(component="tools_main")


HELP_TEXT = """
Streamlit FlexNav Developer Tools
=================================

Usage:
  python -m streamlit_flexnav.tools <command>

Commands:
  debug-paths        Show resolved menupage paths
  startup-check      Verify that all required menu files exist
  doctor             Run structural diagnostics on menupages
  linter             Run static analysis on menupages
  run-fix-pages      Fix Streamlit page structure issues
  init               basic setup of running app

Page Commands:
  page create        Create a new menupage
  page list          List all menupages
  page delete        Delete a menupage
  page rename        Rename a menupage
  page move          Move a menupage
  page fix-keys      Auto-fix invalid PageStruct keys
  page tree          Print navigation tree
  page export        Export all pages as JSON
  page validate      Run linter + doctor

Examples:
  python -m streamlit_flexnav.tools debug-paths
  python -m streamlit_flexnav.tools page create reports/sales --label "Sales" --icon "📊"
  python -m streamlit_flexnav.tools page list
  python -m streamlit_flexnav.tools page fix-keys
"""


def main():
    if len(sys.argv) == 1:
        print(HELP_TEXT)
        return

    cmd = sys.argv[1]

    # -------------------------
    # PAGE SUBCOMMANDS
    # -------------------------
    if cmd == "page":
        if len(sys.argv) < 3:
            print("Missing page subcommand. Try: page list, page create, page delete")
            return

        sub = sys.argv[2]

        if sub == "create":
            if len(sys.argv) < 4:
                print("Usage: page create <path> --label \"Label\" [--icon \"📄\"] [--order 100]")
                return
            path = sys.argv[3]
            label = _get_flag("--label")
            icon = _get_flag("--icon", default="📄")
            order = int(_get_flag("--order", default="100"))
            create_page(path, label, icon, order)
            return

        if sub == "list":
            list_pages()
            return

        if sub == "delete":
            delete_page(sys.argv[3])
            return

        if sub == "rename":
            rename_page(sys.argv[3], sys.argv[4])
            return

        if sub == "move":
            move_page(sys.argv[3], sys.argv[4])
            return

        if sub == "fix-keys":
            fix_keys()
            return

        if sub == "tree":
            print_tree()
            return

        if sub == "export":
            export_pages()
            return

        if sub == "validate":
            run_validate()
            return

        print(f"Unknown page subcommand: {sub}")
        return

    # -------------------------
    # TOP-LEVEL COMMANDS
    # -------------------------

    if cmd == "debug-paths":
        print_debug_paths()
        return

    if cmd == "init":
        app()
        return


    if cmd == "run-fix-pages":
        run_fix_pages()
        return

    if cmd == "linter":
        run_linter()
        return

    if cmd == "doctor":
        code = run_doctor()
        sys.exit(code)

    if cmd == "startup-check":
        try:
            verify_menu_files_exist()
            print("Startup check passed. All menu files exist.")
        except Exception as e:
            print(f"Startup check failed: {e}")
        return

    print(f"Unknown command: {cmd}")
    print(HELP_TEXT)


def _get_flag(name: str, default=None):
    if name in sys.argv:
        idx = sys.argv.index(name)
        return sys.argv[idx + 1]
    return default


if __name__ == "__main__":
    main()
