from __future__ import annotations

import streamlit as st
import structlog

from streamlit_flexnav.core.menuregistry import menuregistry
from streamlit_flexnav.core.models.menugroup import MenuGroup
from streamlit_flexnav.ui.converter import menu_item_to_page

log = structlog.get_logger().bind(component="navigator")


# -------------------------------------------------------------------
# Styling helper for group labels
# -------------------------------------------------------------------

def _styled_label(group: MenuGroup) -> str:
    label = group.label

    # icon
    if group.icon:
        label = f"{group.icon} {label}"

    # color simulation using emoji dots
    if group.color:
        color_map = {
            "red": "🔴",
            "green": "🟢",
            "blue": "🔵",
            "yellow": "🟡",
            "purple": "🟣",
            "orange": "🟠",
        }
        dot = color_map.get(group.color.lower(), "⚪")
        label = f"{dot} {label}"

    # bold / italic
    if group.bold:
        label = f"**{label}**"
    if group.italic:
        label = f"*{label}*"

    # simulated size
    if group.size:
        if group.size == 1:
            label = f"▪ {label}"
        elif group.size == 2:
            label = f"◼ {label}"
        elif group.size == 3:
            label = f"⬛ {label}"

    return label


# -------------------------------------------------------------------
# Build MenuGroup objects from PageStruct items
# -------------------------------------------------------------------

def _build_groups(items):
    groups: dict[str, MenuGroup] = {}

    for item in items:
        group_key = item.group or "Root"

        if group_key not in groups:
            groups[group_key] = MenuGroup(
                key=group_key,
                label=group_key.replace("_", " ").title(),
                icon="📁" if group_key != "Root" else "🏠",
                bold=(group_key == "Root"),
                # order=group_key.order() if group_key != "Root" else -1000,
                pages=[],
            )

        groups[group_key].pages.append(item)

    return groups


# -------------------------------------------------------------------
# Debug tree
# -------------------------------------------------------------------

def _debug_tree(nav):
    print("\n=== NAV TREE DEBUG ===")
    for section, pages in nav.items():
        print(f"[SECTION] {section}")
        for p in pages:
            print(f"   - {p}")
    print("=== END NAV TREE DEBUG ===\n")


# -------------------------------------------------------------------
# Render navigation
# -------------------------------------------------------------------

def render_navigation():
    items = menuregistry.all()

    if not items:
        log.error("no_menupages_found")
        st.error("No pages available. Check menupages directory.")
        return

    groups = _build_groups(items)

    nav = {}

    for key, group in groups.items():
        nav[_styled_label(group)] = [
            menu_item_to_page(p)
            for p in sorted(group.pages, key=lambda x: (x.order, x.label.lower()))
        ]

    log.info("render_navigation", section_count=len(nav))

    _debug_tree(nav)

    pg = st.navigation(nav)
    pg.run()
