class t{setStatus(s){return new t(this.name,this.size,this.id,s,this.file)}constructor(s,i,e,h,a){this.name=s,this.size=i,this.id=e,this.status=h,this.file=a}}export{t as U};
