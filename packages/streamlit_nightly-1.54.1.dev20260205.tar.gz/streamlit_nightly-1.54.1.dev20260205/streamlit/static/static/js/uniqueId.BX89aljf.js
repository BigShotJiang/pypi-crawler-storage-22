import{J as i}from"./index.B1jj3RFQ.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
