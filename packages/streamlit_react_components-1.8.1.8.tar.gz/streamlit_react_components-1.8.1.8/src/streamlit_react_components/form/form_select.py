"""FormSelect component - A styled dropdown select input."""

import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Callable

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def form_select(
    label: str,
    options: List[Union[str, Dict[str, str]]],
    value: str = "",
    groups: Optional[List[Dict[str, Any]]] = None,
    on_change: Optional[Callable] = None,
    args: Optional[tuple] = None,
    kwargs: Optional[Dict[str, Any]] = None,
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    theme: Optional[Dict[str, Any]] = None,
    defer_update: bool = False,
    key: Optional[str] = None,
) -> str:
    """
    Display a styled dropdown select input.

    Args:
        label: Label text for the select
        options: List of options, either strings or dicts with {value, label}
        value: Currently selected value
        groups: Optional list of option groups, each with:
                - label: Group header text
                - options: List of options in this group
        on_change: Optional callback function called when value changes
        args: Optional tuple of args to pass to on_change callback
        kwargs: Optional dict of kwargs to pass to on_change callback
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        theme: Optional theme dictionary. If None, uses active global theme.
               Set to False to disable theming for this component.
        defer_update: If True, don't trigger Streamlit rerun on change.
                      Value is stored locally and sent on next rerun (e.g., Apply button).
                      Requires 'key' to be set.
        key: Unique key for the component (required if on_change or defer_update is used)

    Returns:
        The currently selected value

    Example:
        # Simple string options
        site = form_select(
            label="Site",
            options=["AML_14", "ADL", "Devens"],
            value="AML_14"
        )

        # With on_change callback
        def handle_change():
            st.write("Selection changed!")

        site = form_select(
            label="Site",
            options=["AML_14", "ADL", "Devens"],
            on_change=handle_change,
            key="site_select"
        )

        # With on_change and args
        def handle_change(component_name):
            st.write(f"{component_name} changed!")

        site = form_select(
            label="Site",
            options=["AML_14", "ADL", "Devens"],
            on_change=handle_change,
            args=("site_select",),
            key="site_select"
        )
    """
    # Resolve theme (None = use global, False = disable)
    from ..themes import get_active_theme
    resolved_theme = None
    if theme is not False:
        resolved_theme = theme if theme is not None else get_active_theme()

    result = _component(
        component="form_select",
        label=label,
        options=options,
        value=value,
        groups=groups,
        style=style,
        className=class_name,
        theme=resolved_theme,
        deferUpdate=defer_update,
        componentKey=key,
        key=key,
        default=value,
    )

    final_result = result if result is not None else value

    # Execute on_change callback if value changed
    if on_change and key:
        prev_key = f"_form_select_prev_{key}"
        prev_value = st.session_state.get(prev_key)

        # Only fire callback if value actually changed (not on first render)
        if prev_value is not None and final_result != prev_value:
            on_change(*(args or ()), **(kwargs or {}))

        # Always update previous value
        st.session_state[prev_key] = final_result

    return final_result
