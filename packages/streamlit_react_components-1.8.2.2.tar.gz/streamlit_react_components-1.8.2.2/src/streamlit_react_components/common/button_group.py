"""ButtonGroup component - A group of action buttons."""

import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def button_group(
    buttons: List[Dict[str, Any]],
    on_click: Optional[Callable] = None,
    on_change: Optional[Callable] = None,
    args: Optional[tuple] = None,
    kwargs: Optional[Dict[str, Any]] = None,
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    theme: Optional[Dict[str, Any]] = None,
    key: Optional[str] = None,
) -> Optional[str]:
    """
    Display a group of action buttons.

    Args:
        buttons: List of button configs, each with:
                 - id: Unique identifier
                 - label: Button text (optional)
                 - icon: Button icon/emoji (optional)
                 - color: Preset name ("blue", "green", "red", "yellow", "purple",
                   "slate") or hex value like "#94a3b8" (optional)
                 - disabled: Whether button is disabled (optional)
                 - style: Inline CSS styles dict for this button (optional)
                 - className: Tailwind CSS classes for this button (optional)
        on_click: Optional callback fired on every click. Receives (button_id, *args, **kwargs)
        on_change: Optional callback fired only when a different button is clicked.
                   Receives (*args, **kwargs)
        args: Optional tuple of args to pass to callbacks
        kwargs: Optional dict of kwargs to pass to callbacks
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        theme: Optional theme dictionary. If None, uses active global theme.
               Set to False to disable theming for this component.
        key: Unique key for the component (required if callbacks are used)

    Returns:
        The ID of the clicked button, or None if no click

    Example:
        def handle_click(button_id):
            st.write(f"Clicked: {button_id}")

        clicked = button_group(
            buttons=[
                {"id": "approve", "icon": "✓", "color": "green"},
                {"id": "reject", "icon": "✕", "color": "red"}
            ],
            on_click=handle_click,
            key="my_buttons"
        )
    """
    # Resolve theme (None = use global, False = disable)
    from ..themes import get_active_theme
    resolved_theme = None
    if theme is not False:
        resolved_theme = theme if theme is not None else get_active_theme()

    result = _component(
        component="button_group",
        buttons=buttons,
        style=style,
        className=class_name,
        theme=resolved_theme,
        key=key,
        default=None,
    )

    # Execute callbacks if a button was clicked
    if key and result is not None:
        prev_key = f"_button_group_prev_{key}"
        prev_value = st.session_state.get(prev_key)

        # on_click fires on every click, with button_id as first arg
        if on_click:
            on_click(result, *(args or ()), **(kwargs or {}))

        # on_change fires only when a different button is clicked
        if on_change and result != prev_value:
            on_change(*(args or ()), **(kwargs or {}))

        # Always update previous value
        st.session_state[prev_key] = result

    return result
