"""DataTable component - A styled data table with click support."""

import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def data_table(
    columns: List[Dict[str, Any]],
    rows: List[Dict[str, Any]],
    show_header: bool = True,
    on_change: Optional[Callable] = None,
    args: Optional[tuple] = None,
    kwargs: Optional[Dict[str, Any]] = None,
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    theme: Optional[Dict[str, Any]] = None,
    key: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    Display a styled data table with row click support.

    Args:
        columns: List of column definitions, each with:
                 - key: Data key in each row
                 - label: Column header text
                 - align: "left", "center", or "right" (optional)
                 - format: "number" or "percent" (optional)
                 - colorByValue: True to color based on status values (optional)
        rows: List of row data dictionaries
        show_header: Whether to show the header row (default True)
        on_change: Optional callback function called when a row is clicked
        args: Optional tuple of args to pass to on_change callback
        kwargs: Optional dict of kwargs to pass to on_change callback
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        theme: Optional theme dictionary. If None, uses active global theme.
               Set to False to disable theming for this component.
        key: Unique key for the component (required if on_change is used)

    Returns:
        Dictionary with rowIndex and rowData when a row is clicked, None otherwise

    Example:
        columns = [
            {"key": "city", "label": "City"},
            {"key": "temp", "label": "Temperature", "align": "right"},
            {"key": "status", "label": "Status", "colorByValue": True}
        ]
        rows = [
            {"city": "Portland", "temp": 72, "status": "warm"},
            {"city": "Seattle", "temp": 58, "status": "cool"}
        ]
        clicked = data_table(columns=columns, rows=rows)
        if clicked:
            st.write(f"Clicked row: {clicked['rowData']}")
    """
    # Resolve theme (None = use global, False = disable)
    from ..themes import get_active_theme
    resolved_theme = None
    if theme is not False:
        resolved_theme = theme if theme is not None else get_active_theme()

    result = _component(
        component="data_table",
        columns=columns,
        rows=rows,
        showHeader=show_header,
        style=style,
        className=class_name,
        theme=resolved_theme,
        key=key,
        default=None,
    )

    # Execute on_change callback if a row was clicked
    if on_change and key:
        prev_key = f"_data_table_prev_{key}"
        prev_value = st.session_state.get(prev_key)

        # Only fire callback if a row was clicked (result not None) and it's different from previous
        if result is not None and result != prev_value:
            on_change(*(args or ()), **(kwargs or {}))

        # Always update previous value
        st.session_state[prev_key] = result

    return result
