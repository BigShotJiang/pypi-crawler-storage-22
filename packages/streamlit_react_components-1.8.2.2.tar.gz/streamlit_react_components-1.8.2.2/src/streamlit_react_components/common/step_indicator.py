"""StepIndicator component - A multi-step wizard progress indicator."""

import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def step_indicator(
    steps: List[str],
    current_step: int,
    on_change: Optional[Callable] = None,
    args: Optional[tuple] = None,
    kwargs: Optional[Dict[str, Any]] = None,
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    theme: Optional[Dict[str, Any]] = None,
    key: Optional[str] = None,
) -> Optional[int]:
    """
    Display a multi-step wizard progress indicator.

    Args:
        steps: List of step labels (e.g., ["Supply Plan", "Levers", "Review"])
        current_step: Current active step (1-indexed)
        on_change: Optional callback function called when a step is clicked
        args: Optional tuple of args to pass to on_change callback
        kwargs: Optional dict of kwargs to pass to on_change callback
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        theme: Optional theme dictionary. If None, uses active global theme.
               Set to False to disable theming for this component.
        key: Unique key for the component (required if on_change is used)

    Returns:
        The step number that was clicked, or None if no click

    Example:
        step = step_indicator(
            steps=["Supply Plan", "Levers", "Review"],
            current_step=2
        )
        if step:
            st.session_state.step = step
    """
    # Resolve theme (None = use global, False = disable)
    from ..themes import get_active_theme
    resolved_theme = None
    if theme is not False:
        resolved_theme = theme if theme is not None else get_active_theme()

    result = _component(
        component="step_indicator",
        steps=steps,
        currentStep=current_step,
        style=style,
        className=class_name,
        theme=resolved_theme,
        key=key,
        default=None,
    )

    # Execute on_change callback if a step was clicked
    if on_change and key:
        prev_key = f"_step_indicator_prev_{key}"
        prev_value = st.session_state.get(prev_key)

        # Only fire callback if a step was clicked (result not None) and it's different from previous
        if result is not None and result != prev_value:
            on_change(*(args or ()), **(kwargs or {}))

        # Always update previous value
        st.session_state[prev_key] = result

    return result
