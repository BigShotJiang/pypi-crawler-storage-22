"""STRIGIVAL Python SDK - Trading Strategies Marketplace.

SDK officiel pour interagir avec le protocole STRIGIVAL.
Permet aux traders algorithmiques d'exécuter des trades via l'API.

Installation:
    pip install strigival

Usage:
    from strigival import StrigivalClient
    
    client = StrigivalClient(
        api_url="https://api.strigival.io",
        private_key="0x..."
    )
    
    # Get quote
    quote = client.get_quote(
        vault_address="0x...",
        token_in="USDC",
        token_out="WETH",
        amount=1000
    )
    
    # Execute trade
    tx = client.execute_trade(quote)
"""

__version__ = "1.2.0"  # V12 Sepolia support
__author__ = "STRIGIVAL Protocol"

from .client import StrigivalClient
from .types import (
    Quote,
    Trade,
    VaultStatus,
    KPIs,
    Protocol,
    TradeAction,
)
from .exceptions import (
    StrigivalError,
    AuthenticationError,
    QuoteError,
    TradeError,
    RateLimitError,
)

__all__ = [
    "StrigivalClient",
    "Quote",
    "Trade",
    "VaultStatus",
    "KPIs",
    "Protocol",
    "TradeAction",
    "StrigivalError",
    "AuthenticationError",
    "QuoteError",
    "TradeError",
    "RateLimitError",
]
