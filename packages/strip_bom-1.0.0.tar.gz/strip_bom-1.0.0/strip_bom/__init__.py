from strip_bom.core import (
    strip_bom,
    strip_bom_buffer,
    strip_bom_stream,
    strip_bom_file,
)

__all__ = [
    'strip_bom',
    'strip_bom_buffer',
    'strip_bom_stream',
    'strip_bom_file',
]
