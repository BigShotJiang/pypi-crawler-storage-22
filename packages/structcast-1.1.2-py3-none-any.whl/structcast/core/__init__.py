"""Core module for StructCast."""
