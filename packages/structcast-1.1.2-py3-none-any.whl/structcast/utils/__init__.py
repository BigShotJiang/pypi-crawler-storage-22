"""Utility functions for StructCast."""
