---
schema_version: "2.4"
title: "Standard Update Playbook"
description: "How to evolve `.agents/` documentation standards with minimal repo-wide churn."
category: "runbook"
status: "active"
version: "1.0.1"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-02-06"
last_verified: "2026-02-06"
owner: "Aleksandr Pavlov (ckidoz@gmail.com)"
agents_md_compatible: true
agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: false
---

# Standard Update Playbook

This playbook is a **process doc** for maintainers. Its goal is to let you ship new standard features (new doc types, provenance, RAG hints, protocol metadata, etc.) without forcing a painful repo-wide migration every time.

## Guiding principles

1. **Stabilize the “core contract”**
   - Keep the *required* frontmatter fields small and stable.
   - Prefer defaults over new required fields.

2. **Ship new ideas as optional extensions first**
   - Add fields as **optional**.
   - If important, make them **recommended (WARNING)** first.
   - Only make fields **required** in a new **major** schema version.

3. **Separate “validation” from “style”**
   - Validation answers: “Is this safe/usable?”
   - Style/lint answers: “Is this consistent/pretty?”
   - This prevents stylistic changes from forcing migrations.

4. **Keep changes localized**
   - Domain-specific rules (API vs Spec vs Research) should live in domain modules/templates, not in a single giant monolith.

## Versioning model

### Schema version (`schema_version`)
- Uses **MAJOR.MINOR** only.
- Bump MAJOR only for breaking changes.

### Patch version (`version`)
- Patch versions can ship:
  - clarification
  - new templates
  - new optional fields
  - new directories
  - improved guidance

## Release types

### Patch release (ex: 2.4.2 → 2.4.3)
**Goal:** ship improvements with **zero required doc migrations**.

Checklist:
- Update `STANDARDS.md`:
  - bump `version`
  - update `last_updated` / `last_verified`
  - add a short “What’s New” bullet list
- Update `SCHEMA.yaml` only if you are adding optional fields / new categories.
- Update templates (add new template files rather than changing required fields).
- Do **not** add new required fields.

### Minor release (ex: 2.4 → 2.5)
**Goal:** ship new capabilities while remaining backward compatible.

Checklist:
- Update `schema_version` to the new minor.
- Add new fields as optional; add them to templates.
- Add new validation rules as WARNING/INFO first.
- Ensure agents ignore unknown fields gracefully.

### Major release (ex: 2.x → 3.0)
**Goal:** allow breaking changes, but provide a smooth migration.

Checklist:
- Provide an automated migrator (codemod) and run it in CI.
- Provide a mapping table “old → new”.
- Keep a compatibility window if possible:
  - validator can accept previous major in “compat mode”
  - but agents should prefer current major

## Modularization pattern

To avoid editing the core standard for every new domain:

- Keep `STANDARDS.md` as the **core contract + table of contents**.
- Put domain rules in separate docs:
  - `.agents/standards/specification.md`
  - `.agents/standards/api.md`
  - `.agents/standards/research.md`

Each module should include:
- category-specific recommended sections
- examples
- optional metadata blocks

## “Profiles” pattern (optional)

If you don’t want more files, add a `profile` concept:

- Either implicit via `category` (preferred)
- Or explicit: `doc_profile: api | specification | research`

Then validation can apply profile-specific rules without changing core requirements.

## Automation hooks that reduce churn

### 1) Auto-fix frontmatter style
Add a `--fix` mode to your validator:
- quote dates
- convert flow YAML to block YAML where possible
- sort keys to canonical order

### 2) Migration packs
Store migrations as data, not code when possible:

```yaml
# .agents/migrations/2.4.2_to_2.4.3.yaml
rename:
  old_field: new_field
add_if_missing:
  agents_md_compatible: true
```

Your migrator applies them idempotently.

### 3) Templates are the product
Treat templates as the easiest way to “roll out” new standard features:
- Add templates for each new doc class.
- Only migrate existing docs when the benefit is high.



## Snapshot packaging and deduplication

When publishing a **zip snapshot** of this standard (for bootstrapping new repos), keep the package small and avoid conflicting duplicates.

**Goal:** `.agents/` is the only source of truth; everything else is a thin entrypoint or pointer.

### Checklist (recommended)

- **Single source of truth**
  - Include **only one** copy of standards, schema, templates, contexts, skills, runbooks, and research: **`.agents/**`**.
  - Do **not** ship mirrored directories (for example a full `agents/` copy of `.agents/`).
  - If you need non-hidden visibility on Windows/macOS file explorers, include only `agents/README.md` as a pointer to `.agents/`.

- **Root entrypoints only**
  - Include `AGENTS.md` plus optional aliases (`CLAUDE.md`, `GEMINI.md`, `AGENT.md`).
  - Prefer **symlinks** in real repos; in zip snapshots, keep aliases **tiny** and identical to `AGENTS.md`.

- **No versioned duplicates**
  - Prefer stable filenames (`STANDARDS.md`, `SCHEMA.yaml`, `RESEARCH_TEMPLATE.md`, etc.).
  - Put the patch version inside file content/frontmatter (not the filename).

- **RAG ingestion safety**
  - Ensure `rag.manifest.yaml` allowlists only `.agents/**` so duplicates are not indexed.

- **Sanity checks**
  - Grep for accidental duplicates: `find . -type f -name '*_v*'` (should usually be empty).
  - Confirm the package contains `.agents/STANDARDS.md`, `.agents/SCHEMA.yaml`, and root `AGENTS.md`.

## Review gate

Before releasing a new version:
- run validation on `.agents/**.md`
- ensure docs with `status: active` have `last_verified` within your defined window
- ensure no documents with `contains_secrets: true` are eligible for RAG ingestion
