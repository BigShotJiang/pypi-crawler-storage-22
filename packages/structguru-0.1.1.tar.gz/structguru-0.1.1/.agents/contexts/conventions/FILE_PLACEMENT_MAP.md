---
schema_version: "2.4"
title: "structguru File Placement Map"
description: "Deterministic rules for where new code, tests, configs, and docs belong in the structguru repo."
category: "specification"
status: "active"
version: "1.0.0"
retrieval_priority: "critical"
retrieval_scope: "global"
last_updated: "2026-02-17"
last_verified: "2026-02-17"
owner: "Aleksandr Pavlov"
agents_md_compatible: true

doc_id: "structguru-file-placement-map"
tags:
  - "conventions"
  - "layout"
keywords:
  - "where to put"
  - "folder structure"
  - "tests"
  - "src layout"

conventions_provenance:
  source: "manual"
  reviewed_by: "Aleksandr Pavlov"
  reviewed_date: "2026-02-17"

retrieval_hints:
  chunk_size: 700
  chunk_overlap: 70
  semantic_anchors:
    - "where to put"
    - "tests"
    - "src/"
    - "config"
    - "docs"

agent_notes:
  confidence: "high"
  safe_for_codegen: true
  requires_human_review: false
---

# structguru File Placement Map

This document answers: **"Where should this new/changed thing live?"**

## Golden rules

1. **Prefer existing patterns**: find the closest existing module and mirror its structure.
2. **Do not invent new top-level folders** without updating this map.
3. **Tests mirror production structure** in the `tests/` directory.
4. If uncertain, propose **2-3 candidate locations** + rationale and ask for confirmation.

## Project layout

```
structguru/
├── src/
│   └── structguru/           # Library source (importable package)
│       ├── __init__.py       # Public API exports
│       ├── core.py           # Logger facade (Logger dataclass)
│       ├── config.py         # configure_structlog(), setup_structlog()
│       └── processors.py     # Custom structlog processors
├── tests/                    # All tests
│   ├── conftest.py           # Shared fixtures
│   ├── test_core.py          # Tests for core.py
│   ├── test_config.py        # Tests for config.py
│   └── test_processors.py    # Tests for processors.py
├── pyproject.toml            # Build config, deps, tool settings
├── AGENTS.md                 # Agent entry point
├── .aiexclude                # AI context exclusions
├── .agents/                  # Agent documentation (this standard)
└── agents/                   # Visible pointer to .agents/
```

## Placement by change type

| If you are adding/changing...      | Put it in...                     | Example to copy             |
|------------------------------------|----------------------------------|-----------------------------|
| New library module                 | `src/structguru/<module>.py`     | `src/structguru/core.py`    |
| Custom structlog processor         | `src/structguru/processors.py`   | existing processors         |
| Configuration / setup functions    | `src/structguru/config.py`       | `configure_structlog()`     |
| Public API export                  | `src/structguru/__init__.py`     | existing exports            |
| Unit tests                         | `tests/test_<module>.py`         | `tests/test_core.py`        |
| Shared test fixtures               | `tests/conftest.py`              | existing conftest            |
| Build / tool config                | `pyproject.toml`                 | existing sections           |
| Agent docs / contexts              | `.agents/contexts/`              | existing context files       |
| Agent runbooks                     | `.agents/runbooks/`              | existing runbooks            |
| Research artifacts                 | `.agents/research/`              | existing research files      |

## Common repo paths

- Production code: `src/structguru/`
- Tests: `tests/`
- Build config: `pyproject.toml`
- Agent documentation: `.agents/`
