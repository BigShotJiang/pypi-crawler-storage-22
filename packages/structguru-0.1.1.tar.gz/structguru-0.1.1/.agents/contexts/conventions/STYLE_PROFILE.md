---
schema_version: "2.4"
title: "structguru Style Profile"
description: "House style rules for the structguru repo: naming, patterns, formatting, and testing expectations."
category: "specification"
status: "active"
version: "1.0.0"
retrieval_priority: "critical"
retrieval_scope: "global"
last_updated: "2026-02-17"
last_verified: "2026-02-17"
owner: "Aleksandr Pavlov"
agents_md_compatible: true

doc_id: "structguru-style-profile"
tags:
  - "conventions"
  - "style"
keywords:
  - "formatting"
  - "naming"
  - "tests"
  - "python"
  - "ruff"

conventions_provenance:
  source: "manual"
  reviewed_by: "Aleksandr Pavlov"
  reviewed_date: "2026-02-17"

retrieval_hints:
  chunk_size: 600
  chunk_overlap: 60
  semantic_anchors:
    - "format"
    - "lint"
    - "naming"
    - "tests"
    - "error handling"
    - "ruff"
    - "mypy"
    - "pytest"

agent_notes:
  confidence: "high"
  safe_for_codegen: true
  requires_human_review: false
---

# structguru Style Profile

This document defines **project style** (code and docs). The goal is consistent output and low-diff reviews.

**Do not impersonate a person**. Follow the repo's patterns, not an individual's "voice".

## Non-negotiables

- **Formatter**: `uv run ruff format .`
- **Linter**: `uv run ruff check .`
- **Typecheck**: `uv run mypy src/`
- **Tests**: `uv run pytest`

If tools disagree with this doc, **tool config wins** (formatters/linters are the source of truth).

## Python version

- Target: Python 3.10+
- Use PEP 695 type aliases (`type Foo = ...`) where supported (3.12+), fall back to `TypeAlias` for 3.10/3.11 compat.

## Naming conventions

- Files: `snake_case.py`
- Modules/packages: `snake_case`
- Types/classes: `PascalCase`
- Functions/methods: `snake_case`
- Constants: `UPPER_SNAKE_CASE`
- Private members: `_leading_underscore`
- Test files: `test_<module>.py`

## Code patterns

### Error handling

- Prefer: specific exception types; custom exception classes in `structguru.exceptions` if needed
- Avoid: bare `except:`, catching `BaseException` (except for uncaught exception hooks)
- Use `msg = "..."; raise TypeError(msg)` pattern (ruff-friendly, avoids long raise lines)

### Logging / telemetry

- This library **is** the logging tool. For internal debugging, use `structlog.get_logger(__name__)` directly.
- Do not use `print()` for any output.

### API boundaries / layering

- Public API surface: `src/structguru/__init__.py` (exports `logger`, `Logger`, `configure_structlog`, `setup_structlog`)
- Internal modules: prefixed descriptions in docstrings, not `_` prefixed files
- Processors: `src/structguru/processors.py`
- Configuration: `src/structguru/config.py`
- Logger facade: `src/structguru/core.py`

### Imports

- Use `from __future__ import annotations` for all modules (PEP 604 union syntax on 3.10+).
- Group: stdlib, third-party, local. Let ruff handle sorting.

### Docstrings

- Use Google-style or NumPy-style docstrings (be consistent within a module).
- All public functions/classes must have docstrings.
- Keep examples copy/paste safe.

## Testing conventions

- Framework: `pytest`
- Arrange/Act/Assert: yes
- Mocking approach: `unittest.mock` or `pytest-mock`
- Fixtures: prefer `conftest.py` for shared fixtures
- Where tests live: see `FILE_PLACEMENT_MAP.md`

## Documentation style

- Use short headings
- Prefer bullet lists for steps/checklists
- Keep examples copy/paste safe

## Exemplars

Agents SHOULD copy patterns from the reference implementation in `PROMPT_STRUCTGURU.md` (source files section).
