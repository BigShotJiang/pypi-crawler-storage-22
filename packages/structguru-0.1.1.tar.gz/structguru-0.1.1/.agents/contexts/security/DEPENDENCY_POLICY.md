---
schema_version: "2.4"
title: "Dependency and supply-chain policy"
description: "Rules for dependency changes, SBOM expectations, and supply-chain integrity posture for agent-assisted work."
category: "security"
status: "active"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-02-17"
last_verified: "2026-02-17"
owner: "Aleksandr Pavlov"
doc_id: "dependency-policy-agentic"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: true
---

# Dependency and supply-chain policy

Agent-assisted changes make it easy to modify dependencies and build pipelines. Treat these as **security-sensitive** changes.

## Rules (MUST)
- Major dependency upgrades and new dependencies require human review.
- Prefer pinned versions and lockfiles.
- Do not add new package registries or “install scripts” without maintainer approval.
- Changes to CI/CD and release pipelines require elevated review.

## SBOM (SHOULD for releases)
For production releases, generate an SBOM and keep it with the release artifacts.

References:
- NTIA SBOM Minimum Elements (2021): https://www.ntia.gov/report/2021/minimum-elements-software-bill-materials-sbom
- CISA SBOM program resources: https://www.cisa.gov/sbom

## Provenance / integrity (SHOULD)
Adopt a supply-chain integrity posture (e.g., SLSA-style provenance) where applicable:
- https://slsa.dev/

## Safe workflow for dependency changes
1) Explain why the dependency is needed/updated.
2) Check license and maintenance status.
3) Run security scans (SCA) if available.
4) Run tests and CI locally where possible.
5) Keep the diff minimal and reviewable.
