---
schema_version: "2.4"
title: "Secrets policy for agentic workflows"
description: "Rules for handling secrets/credentials in agent contexts, docs, and tool outputs."
category: "security"
status: "active"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-02-17"
last_verified: "2026-02-17"
owner: "Aleksandr Pavlov"
doc_id: "secrets-policy-agentic"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: false
---

# Secrets policy

## What counts as a secret
- API keys, tokens, passwords, private keys, client secrets
- session cookies, bearer tokens, refresh tokens
- database connection strings (if they include credentials)
- signing keys, KMS exports, encryption keys
- `.env` files and any “real” credentials in config files

## Rules (MUST)
- Do **not** paste secrets into chat, issues, logs, or `.agents/` docs.
- If a secret is detected in a file or output:
  1) stop
  2) redact the value
  3) alert a maintainer
  4) rotate/revoke via the secret manager
- Use `.aiexclude` to keep secrets out of agent context windows.
- When documenting configuration, reference **secret names/locations**, never values.

## How to reference secrets safely
Use patterns like:
- `SECRET_NAME` (in env var form), plus the secret manager path/location (no value)
- “stored in <secret manager> under <path>” (keep it generic for templates)

## RAG safety
If any document contains secrets, set:
- `data_handling.contains_secrets: true`
- `data_handling.rag_allowed: false`
and ensure your ingest pipeline excludes it.
