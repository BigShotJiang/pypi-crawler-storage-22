---
schema_version: "2.4"
title: "Agent runtime features: Codex, Claude Code, Gemini Code Assist"
description: "Comparison of modern coding-agent runtime primitives (permissions, context exclusion, skills/subagents, hooks, MCP, structured outputs) and how to encode them in this repo’s agent-docs standard."
category: "research-report"
status: "active"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-01-31"
last_verified: "2026-01-31"
owner: "Project Maintainers"
doc_id: "agent-runtime-features-codex-claude-gemini"

tags:
  - "research"
  - "agent-runtimes"
keywords:
  - "codex"
  - "claude code"
  - "gemini code assist"
  - "agent mode"
  - "aiexclude"
  - "skills"
  - "subagents"
  - "hooks"
  - "mcp"
  - "structured outputs"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

sources:
  - source_id: "src:claude-code-overview"
    title: "Claude Code documentation: Overview"
    kind: "web"
    url: "https://code.claude.com/docs/en/overview"
    publisher: "Anthropic"

  - source_id: "src:openai-codex-docs"
    title: "OpenAI Codex documentation"
    kind: "web"
    url: "https://developers.openai.com/codex"
    publisher: "OpenAI"

  - source_id: "src:gemini-code-assist-overview"
    title: "Gemini Code Assist documentation: Overview"
    kind: "web"
    url: "https://developers.google.com/gemini-code-assist/docs/overview"
    publisher: "Google"

---

# Summary

- Coding-agent runtimes converge on the same primitives: **execution policy**, **context exclusion**, **progressive disclosure**, **context isolation**, **deterministic automation**, **tool extension**, and **structured outputs**.
- These primitives should be documented explicitly so agent behavior is consistent across tools and over time.
- Some environments (notably **Gemini agent mode**) do **not** provide citations/recitations, so repos must preserve provenance in `.agents/research/`.

# Key findings

## 1) Execution policy and permissions
**Pattern:** a declarative posture for sandboxing, approvals, and network access.

- Codex emphasizes sandboxing + approvals (including network/web search posture).
- Claude Code offers permission modes and tooling around allowing specific command patterns.
- Gemini agent mode requires confirmation for mutating operations and supports plan approval.

**Standard implication:** include a tool-agnostic `execution_policy` block in `AGENTS.md` and allow deeper overrides per service context.

## 2) Context exclusion and sensitive-file hygiene
**Pattern:** explicit denylist to stop the agent from reading secrets/noise automatically.

- Gemini Code Assist uses `.aiexclude` and respects `.gitignore` patterns (with defined precedence).
- This is broadly useful even outside Gemini: the same file can be reused as a human-readable “do not load into context” contract.

**Standard implication:** ship a root `.aiexclude` template and reference it from `AGENTS.md`.

## 3) Skills and progressive disclosure
**Pattern:** small always-on instruction + on-demand skills.

- Codex skills are explicitly designed for progressive disclosure (only name/description loaded initially; full instructions when invoked).
- Claude Code supports “skills” and loads them on demand to reduce context load.

**Standard implication:** encourage teams to keep `AGENTS.md` short and implement deeper workflows as skill packages (tool-specific directories) with an index doc in `.agents/contexts/`.

## 4) Subagents and context isolation
**Pattern:** delegate wide scans/research to isolated workers; return a compact summary.

- Claude Code supports subagents that run with their own context and return results to the main thread.

**Standard implication:** document “when to use subagents” and require compact summaries + saving durable findings in `.agents/research/`.

## 5) Hooks and deterministic automation
**Pattern:** enforce invariants with deterministic scripts rather than “best-effort” instructions.

- Claude Code exposes hooks that run at defined points in the workflow.

**Standard implication:** store hook design docs and invariants in `.agents/runbooks/` (and keep hook scripts small and auditable).

## 6) MCP tool extensions
**Pattern:** register external tools via MCP, then govern tool surface area with allow/deny lists.

**Standard implication:** keep an inventory of MCP servers and tool governance docs in `.agents/contexts/integrations/`.

## 7) Structured outputs for CI
**Pattern:** scripted/CI runs need machine-readable output (JSON/JSONL) + schemas for validation.

- Codex supports non-interactive runs and structured output controls.

**Standard implication:** store JSON Schemas in `.agents/schemas/` and reference them in runbooks.

# Open questions / next steps
- Define a minimal “MCP server record” doc format for `.agents/contexts/integrations/`.
- Provide example JSON Schemas for common artifacts (test reports, release notes, dependency audits).
