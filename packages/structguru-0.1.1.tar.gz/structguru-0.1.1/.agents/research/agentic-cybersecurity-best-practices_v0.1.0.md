---
schema_version: "2.4"
title: "Agentic cyber security best practices (OWASP/NIST/SBOM/SLSA)"
description: "Research summary of practical security controls for AI coding agents: prompt injection defense, least privilege tools, output validation, memory safety, and supply-chain integrity."
category: "research-report"
status: "active"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-02-04"
last_verified: "2026-02-04"
owner: "Project Maintainers"

doc_id: "agentic-cybersecurity-best-practices"

tags:
  - "research"
  - "security"
  - "agentic"
keywords:
  - "prompt injection"
  - "least privilege"
  - "sbom"
  - "slsa"
  - "ssdf"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

sources:
  - source_id: "src:owasp-top10-llm-apps"
    title: "OWASP Top 10 for Large Language Model Applications"
    kind: "web"
    url: "https://owasp.org/www-project-top-10-for-large-language-model-applications/"
    publisher: "OWASP Foundation"
    authors: []
    accessed_date: "2026-02-04"
    notes: "Baseline risk taxonomy for LLM-powered systems."

  - source_id: "src:owasp-llm-prompt-injection"
    title: "OWASP LLM Prompt Injection Prevention Cheat Sheet"
    kind: "web"
    url: "https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html"
    publisher: "OWASP Cheat Sheet Series"
    authors: []
    accessed_date: "2026-02-04"
    notes: "Practical mitigations and framing: instructions/data are processed together."

  - source_id: "src:owasp-ai-agent-security"
    title: "OWASP AI Agent Security Cheat Sheet"
    kind: "web"
    url: "https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html"
    publisher: "OWASP Cheat Sheet Series"
    authors: []
    accessed_date: "2026-02-04"
    notes: "Agent-specific controls: tool least privilege, memory isolation, monitoring."

  - source_id: "src:nist-ssdf-800-218"
    title: "NIST SP 800-218 Secure Software Development Framework (SSDF)"
    kind: "web"
    url: "https://csrc.nist.gov/pubs/sp/800/218/final"
    publisher: "NIST CSRC"
    authors: []
    accessed_date: "2026-02-04"
    notes: "Secure software development practice framework to align agent-assisted development."

  - source_id: "src:ntia-sbom-min-elements"
    title: "NTIA - The Minimum Elements for a Software Bill of Materials (SBOM)"
    kind: "web"
    url: "https://www.ntia.gov/report/2021/minimum-elements-software-bill-materials-sbom"
    publisher: "NTIA"
    authors: []
    accessed_date: "2026-02-04"
    notes: "Baseline SBOM expectations for software supply-chain transparency."

  - source_id: "src:slsa"
    title: "SLSA (Supply-chain Levels for Software Artifacts)"
    kind: "web"
    url: "https://slsa.dev/"
    publisher: "OpenSSF / community"
    authors: []
    accessed_date: "2026-02-04"
    notes: "Supply-chain integrity framework; provenance and build controls."

research:
  question: "What cyber security best practices should be encoded in an AI agent documentation standard to make agent work safer and more reliable?"
  scope: "Agentic software development workflows: prompt injection, tool use, memory/context, output handling, and supply chain. Excludes model training security and red-team methodology."
  method:
    - "Read OWASP LLM and AI agent security guidance"
    - "Map controls into standard-level MUST/SHOULD rules"
    - "Draft schema hooks for machine-readable security posture"
  findings:
    - finding: "Prompt injection is a primary risk for LLM/agent systems; treat external content as untrusted and separate instructions from data."
      confidence: "high"
      evidence:
        - source_id: "src:owasp-llm-prompt-injection"
          locator: "Introduction"
          quote: "instructions and data are processed together without clear separation"
    - finding: "Agent security requires tool least privilege, allowlists, and human-in-the-loop approvals for high-risk actions."
      confidence: "high"
      evidence:
        - source_id: "src:owasp-ai-agent-security"
          locator: "Best Practices"
          quote: "Apply least privilege to all agent tools and permissions"
    - finding: "Insecure output handling is a common failure mode; constrain and validate outputs (prefer structured outputs + schema validation) before executing or integrating into systems."
      confidence: "high"
      evidence:
        - source_id: "src:owasp-top10-llm-apps"
          locator: "LLM02"
          quote: "Neglecting to validate LLM outputs may lead to downstream security exploits"
    - finding: "Supply-chain controls (SBOM + provenance) reduce risk from compromised dependencies and builds, which is amplified by agent-driven rapid changes."
      confidence: "medium"
      evidence:
        - source_id: "src:ntia-sbom-min-elements"
          locator: "Summary"
          quote: "formal record containing the details and supply chain relationships"
        - source_id: "src:slsa"
          locator: "What is SLSA?"
          quote: "check-list of standards and controls to prevent tampering"
  open_questions:
    - "Which paths and actions should be treated as protected by default for this repo?"
    - "What level of provenance (SLSA track/level) is appropriate for our release process?"
  next_steps:
    - "Add `.agents/contexts/security/` docs (threat model, secrets policy, dependency policy)"
    - "Adopt structured outputs + schema validation for any automation outputs"
    - "Define a minimal protected-paths allowlist and approval workflow"
    - "Add SBOM generation for releases if not already present"

retrieval_hints:
  chunk_size: 700
  chunk_overlap: 70
  key_sections:
    - "Summary"
    - "Key findings"
    - "Implications for implementation"

agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: false
---

# Summary

- Use OWASP Top 10 for LLM Applications as a baseline risk taxonomy.
- Encode agent-specific security controls: tool least privilege, approvals, memory isolation, and output validation.
- Treat model outputs and retrieved content as untrusted; validate and constrain before use.
- Strengthen supply-chain integrity with SBOM + provenance where applicable.

# Implications for implementation

- Keep `AGENTS.md` thin but include approval gates and a pointer to security docs.
- Store security policies and threat models under `.agents/contexts/security/`.
- Add optional `security_posture:` metadata to relevant contexts/runbooks to make gates machine-readable.
