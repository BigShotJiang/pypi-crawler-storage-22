---
schema_version: "2.4"
title: "Token Compression Techniques for AI Agent Contexts"
description: "Research-backed techniques to reduce prompt/context token usage for tool-using and coding agents while preserving answer quality."
category: "research-report"
status: "active"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-01-31"
last_verified: "2026-01-31"
owner: "Project Maintainers"

doc_id: "token-compression-techniques"

tags:
  - "research"
  - "context-engineering"
  - "prompt-compression"
  - "rag"
keywords:
  - "token compression"
  - "prompt compression"
  - "context summarization"
  - "contextual compression"
  - "RAPTOR"
  - "LLMLingua"
  - "ReSum"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

sources:
  - source_id: "src:anthropic-context-engineering-2025"
    title: "Effective context engineering for AI agents (Compaction)"
    kind: "web"
    url: "https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents"
    publisher: "Anthropic"
    authors: []
    accessed_date: "2026-01-31"
    notes: "Defines compaction: summarizing near window limits; mentions discarding redundant tool outputs."

  - source_id: "src:langchain-contextual-compression-2023"
    title: "Improving Document Retrieval with Contextual Compression"
    kind: "web"
    url: "https://www.blog.langchain.com/improving-document-retrieval-with-contextual-compression/"
    publisher: "LangChain"
    authors: []
    accessed_date: "2026-01-31"
    notes: "Describes ContextualCompressionRetriever and example compressors."

  - source_id: "src:langchain-llmlingua-compressor-docs"
    title: "LLMLingua Document Compressor (LangChain docs)"
    kind: "web"
    url: "https://docs.langchain.com/oss/python/integrations/retrievers/llmlingua"
    publisher: "LangChain"
    authors: []
    accessed_date: "2026-01-31"
    notes: "Shows how to wrap retrieval with LLMLinguaCompressor."

  - source_id: "src:llmlingua-emnlp-2023"
    title: "LLMLingua: Compressing Prompts for Accelerated Inference of Large Language Models"
    kind: "paper"
    url: "https://aclanthology.org/2023.emnlp-main.825/"
    publisher: "ACL Anthology"
    authors:
      - "Huiqiang Jiang"
      - "Qianhui Wu"
      - "Chin-Yew Lin"
      - "Yuqing Yang"
      - "Lili Qiu"
    published_date: "2023-10-09"
    accessed_date: "2026-01-31"
    notes: "Coarse-to-fine, budget-controlled token-level prompt compression."

  - source_id: "src:llmlingua2-arxiv-2024"
    title: "LLMLingua-2: Data Distillation for Efficient and Faithful Task-Agnostic Prompt Compression"
    kind: "paper"
    url: "https://arxiv.org/abs/2403.12968"
    publisher: "arXiv"
    authors:
      - "Zhuoshi Pan"
      - "Qianhui Wu"
      - "Huiqiang Jiang"
      - "Menglin Xia"
      - "Xufang Luo"
      - "Jue Zhang"
      - "Qingwei Lin"
      - "Victor Rühle"
      - "Yuqing Yang"
      - "Chin-Yew Lin"
      - "H. Vicky Zhao"
      - "Lili Qiu"
      - "Dongmei Zhang"
    published_date: "2024-03-19"
    accessed_date: "2026-01-31"
    notes: "Task-agnostic prompt compression; critiques entropy-only metrics."

  - source_id: "src:prompt-compression-limits-neurips-2024"
    title: "Fundamental Limits of Prompt Compression: A Rate-Distortion Framework for Black-Box Language Models"
    kind: "paper"
    url: "https://proceedings.neurips.cc/paper_files/paper/2024/file/ac8fbba029dadca99d6b8c3f913d3ed6-Paper-Conference.pdf"
    publisher: "NeurIPS"
    authors:
      - "Alliot Nagle"
      - "Adway Girish"
      - "Marco Bondaschi"
      - "Michael Gastpar"
      - "Ashok Vardhan Makkuva"
      - "Hyeji Kim"
    published_date: "2024-12-01"
    accessed_date: "2026-01-31"
    notes: "Formalizes compression as rate-distortion; emphasizes query-aware compression."

  - source_id: "src:raptor-arxiv-2024"
    title: "RAPTOR: Recursive Abstractive Processing for Tree-Organized Retrieval"
    kind: "paper"
    url: "https://arxiv.org/abs/2401.18059"
    publisher: "arXiv"
    authors:
      - "Parth Sarthi"
      - "Others"
    published_date: "2024-01-31"
    accessed_date: "2026-01-31"
    notes: "Builds hierarchical summaries for multi-level retrieval."

  - source_id: "src:resum-arxiv-2025"
    title: "ReSum: Unlocking Long-Horizon Search Intelligence via Context Summarization"
    kind: "paper"
    url: "https://arxiv.org/abs/2509.13313"
    publisher: "arXiv"
    authors:
      - "X. Wu"
      - "Others"
    published_date: "2025-09-16"
    accessed_date: "2026-01-31"
    notes: "Periodic summarization into compact reasoning state for long-horizon agents."

  - source_id: "src:jetbrains-context-management-2025"
    title: "Cutting Through the Noise: Smarter Context Management for LLM-Powered Agents"
    kind: "web"
    url: "https://blog.jetbrains.com/research/2025/12/efficient-context-management/"
    publisher: "JetBrains"
    authors: []
    published_date: "2025-12-01"
    accessed_date: "2026-01-31"
    notes: "Discusses trajectory summarization and observation masking for SE agents."

  - source_id: "src:prompt-compression-survey-2024"
    title: "Prompt Compression for Large Language Models: A Survey"
    kind: "paper"
    url: "https://arxiv.org/html/2410.12388"
    publisher: "arXiv"
    authors:
      - "Zongqian Li"
      - "Yinhong Liu"
      - "Yixuan Su"
      - "Nigel Collier"
    published_date: "2024-10-16"
    accessed_date: "2026-01-31"
    notes: "Survey of hard vs soft prompt compression methods; challenges and future work."

  - source_id: "src:empirical-study-prompt-compression-2025"
    title: "An Empirical Study on Prompt Compression"
    kind: "paper"
    url: "https://openreview.net/pdf?id=lbFVTPv4s6"
    publisher: "OpenReview"
    authors:
      - "Zheng et al."
    accessed_date: "2026-01-31"
    notes: "Evaluates multiple compression methods; analyzes hallucinations and omissions."

research:
  question: "What techniques reliably compress token usage in AI-agent contexts (instructions, retrieved knowledge, and interaction history) while preserving task performance?"
  scope: "Focus on: prompt compression methods, retrieval-time contextual compression, hierarchical summarization for RAG corpora, and agent history compaction. Excludes: model quantization/pruning (model-side), proprietary vendor optimizations."
  method:
    - "Web search for recent agent context engineering and prompt compression literature"
    - "Reading primary sources (papers, vendor docs)"
    - "Synthesis into actionable engineering patterns"
  findings:
    - finding: "Query-aware compression is a key determinant of quality; compressors should know the downstream question/task."
      confidence: "high"
      evidence:
        - source_id: "src:prompt-compression-limits-neurips-2024"
          locator: "Abstract (mentions query-aware compression criticality)"
          quote: "Our empirical analysis demonstrates the criticality of query-aware prompt compression."
    - finding: "Compaction (summarize + restart with a distilled state) is a practical first lever for long-running agents."
      confidence: "high"
      evidence:
        - source_id: "src:anthropic-context-engineering-2025"
          locator: "Compaction section"
          quote: "Compaction is the practice of ... summarizing ... and reinitiating a new context window with the summary."
    - finding: "Contextual compression retrievers can reduce RAG prompt size by extracting only query-relevant statements."
      confidence: "high"
      evidence:
        - source_id: "src:langchain-contextual-compression-2023"
          locator: "Features section"
          quote: "ContextualCompressionRetriever ... automatically compresses the retrieved documents."
    - finding: "Hierarchical summarization + retrieval (RAPTOR) supports retrieval at different levels of abstraction, reducing tokens when only a high-level view is needed."
      confidence: "high"
      evidence:
        - source_id: "src:raptor-arxiv-2024"
          locator: "Abstract"
          quote: "constructing a tree with differing levels of summarization"
    - finding: "Prompt-centric compression methods like LLMLingua can remove low-importance tokens under a budget controller; newer variants aim to be more task-agnostic."
      confidence: "medium"
      evidence:
        - source_id: "src:llmlingua-emnlp-2023"
          locator: "Paper summary"
          quote: "coarse-to-fine prompt compression ... budget controller"
        - source_id: "src:llmlingua2-arxiv-2024"
          locator: "Abstract"
          quote: "task-agnostic prompt compression"
    - finding: "For software agents, most wasted tokens often come from tool observations; observation masking targets that specifically."
      confidence: "medium"
      evidence:
        - source_id: "src:jetbrains-context-management-2025"
          locator: "Observation masking discussion"
          quote: "observation masking targets the environment observation only"
    - finding: "Long-horizon agents can periodically compress interaction history into a structured summary state (ReSum), enabling continued exploration under context limits."
      confidence: "medium"
      evidence:
        - source_id: "src:resum-arxiv-2025"
          locator: "Abstract"
          quote: "periodic context summarization ... into compact reasoning states"
  open_questions:
    - "Best objective metrics for 'distortion' in engineering-agent contexts (missed constraints, wrong edits, security regressions)."
    - "When to prefer extractive compression vs abstractive summaries for code and configs."
    - "Optimal compression cadence triggers (token threshold vs task phase changes)."
  next_steps:
    - "Add a small benchmark: run the same agent task with/without contextual compression and measure token savings + pass rate."
    - "Define a standardized 'Working Memory Summary' format (goals/constraints/decisions/next actions) for compaction steps."
    - "Optionally test LLMLingua as a retrieval-stage compressor, not as a general instruction compressor."

retrieval_hints:
  chunk_size: 600
  chunk_overlap: 60
  key_sections:
    - "Summary"
    - "Key findings"
    - "Implications for implementation"
  exclude_from_retrieval:
    - "Appendix"

agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: false
---

# Summary

This research identifies four practical layers for token compression in agent workflows:

1) **Interaction-history compaction** (summarize + continue)  
2) **Tool-output pruning / observation masking**  
3) **Retrieval-time contextual compression** (extract query-relevant statements)  
4) **Prompt compression models** (token-level compressors like LLMLingua)

**Most reliable win for engineering agents:** aggressively reduce tool outputs + add periodic compaction summaries before hitting the context limit.

# Question and scope

**Question:** What techniques reliably compress token usage in AI-agent contexts while preserving task performance?

**Scope:** Methods applicable to repo agents and RAG systems. Excludes model-side optimizations.

# Key findings

## 1) Compaction for long-running agents

- Use a deterministic summary format and restart/continue with that summary plus the minimal set of active files.
- Preserve: goals, constraints, architectural decisions, open issues, next actions.
- Drop: redundant logs/tool output, repeated instructions.

## 2) Observation masking / log hygiene

- Treat tool observations as *append-only raw data* and keep only the deltas/facts in the agent context.
- Store full logs in files/artifacts; put only a short digest in the prompt.

## 3) Contextual compression in RAG

- Retrieve broadly, then compress to query-specific statements (extractive is often safer than abstractive for code/ops).

## 4) Hierarchical summaries (RAPTOR-style)

- Maintain multiple representations: fine-grained chunks + paragraph summaries + section summaries.
- Retrieve the smallest representation that satisfies the query.

## 5) Prompt compression models (LLMLingua family)

- Consider as an optional final stage when prompts are still too long.
- Validate carefully: compression is lossy; use tests to detect missing constraints.

# Implications for implementation

## Suggested compression stack (practical)

1. **Budgeting**: enforce a max token budget per request.
2. **RAG**: retrieve (k=20) → rerank (k=6) → contextual compress (k=4) → final prompt.
3. **History**: compaction summary every N turns or when token estimate exceeds threshold.
4. **Optional**: LLMLingua compression when still above budget.

## Deterministic "Working Memory Summary" (recommended schema)

- Goal:
- Constraints:
- Decisions made:
- Files changed:
- Evidence/results:
- Open questions:
- Next actions:

# Appendix (optional)

## Notes on tradeoffs

- Compression is always a rate–distortion tradeoff: lower tokens usually means losing some detail.
- Query-aware compression reduces distortion compared to query-agnostic compression.
