---
schema_version: "2.4"
title: "Bootstrap this standard in a new repository"
description: "Step-by-step procedure to install the `.agents/` standard in a fresh repo and set up thin adapters for common agent tools (Codex/Claude/Gemini/Cursor)."
category: "runbook"
status: "active"
version: "1.0.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-02-06"
last_verified: "2026-02-06"
owner: "Aleksandr Pavlov (ckidoz@gmail.com)"
agents_md_compatible: true

doc_id: "bootstrap-empty-repo"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: false
---

# Bootstrap this standard in a new repository

This runbook installs a **working baseline** of the `.agents/` standard into an empty project and sets up **thin, tool-specific adapters**.

## 0) Decide your posture (recommended defaults)

- Start **read-only / plan-first**.
- Keep **network access off** by default.
- Require human approval for:
  - destructive commands
  - writes outside the workspace
  - CI/workflow changes
  - secrets / credentials

## 1) Copy the standard snapshot into the repo

Place these at the repo root:

- `AGENTS.md` (thin entrypoint)
- `.agents/` (canonical standard directory)
- `.aiexclude` (context exclusion rules)

If your environment hides dot-folders, you may also keep a visible mirror folder named `agents/` (optional).

## 2) Fill in `AGENTS.md` for your repo

Update the placeholders:

- what the repo is
- install/build/test/lint commands
- any critical constraints (OS, versions, env vars)

Keep `AGENTS.md` **short**. Put deep details into `.agents/contexts/**` and `.agents/runbooks/**`.

## 3) Create the “minimum viable contexts” (so agents stop guessing)

Create or update:

- `.agents/contexts/conventions/STYLE_PROFILE.md`
- `.agents/contexts/conventions/FILE_PLACEMENT_MAP.md`
- `.agents/contexts/security/SECURITY_OVERVIEW.md`
- `.agents/contexts/security/SECRETS_POLICY.md`

Even a small first draft is better than nothing. Improve iteratively.

## 4) Add tool adapters (thin wrappers)

### 4.1 Codex / AGENTS.md-based tools

- Ensure `AGENTS.md` exists at repo root.
- Keep entrypoints small; move deep rules into `.agents/contexts/**`.
- Skills live under `.agents/skills/**/SKILL.md` (must include `name` + `description` in YAML frontmatter).

### 4.2 Claude Code (optional)

If you use Claude Code, keep it thin:

- `CLAUDE.md` can be a symlink/copy of `AGENTS.md`
- Optional `.claude/` can contain Claude-specific settings/hooks, but keep canonical rules in `.agents/`

### 4.3 Gemini (optional)

If you use Gemini tooling:

- `GEMINI.md` can be a symlink/copy of `AGENTS.md`
- If both `AGENTS.md` and `GEMINI.md` exist, Gemini environments may prefer `GEMINI.md` in the same directory; keep them consistent.

### 4.4 Cursor (recommended if your team uses Cursor)

Cursor does not always preload `AGENTS.md` automatically. The most reliable pattern is:

- Keep Cursor rules as a **thin adapter** that forces reading `AGENTS.md` + `.agents/**`.

Create:

- `.cursor/rules/global.mdc`

You can start from the template:

- `.agents/templates/CURSOR_GLOBAL_RULE_TEMPLATE.mdc`

Example (copy/paste):

```md
---
description: ALWAYS apply. Before doing any work, open and follow AGENTS.md. Treat .agents/contexts/** as the source of truth.
globs:
alwaysApply: true
---

# Global Cursor Agent Rule

## Mandatory startup
- Open `AGENTS.md` and follow it.
- If relevant, open:
  - `.agents/contexts/conventions/STYLE_PROFILE.md`
  - `.agents/contexts/conventions/FILE_PLACEMENT_MAP.md`
  - `.agents/contexts/security/SECURITY_OVERVIEW.md`

## Safety
- Never print or exfiltrate secrets.
- Ask before destructive actions.
```

Optional (defense in depth):
- `.cursorignore` (attempt to exclude secrets/noise from AI features)
- `.cursorindexingignore` (exclude from indexing/search)

Templates exist under:
- `.agents/templates/CURSORIGNORE_TEMPLATE`
- `.agents/templates/CURSORINDEXINGIGNORE_TEMPLATE`

## 5) Verify the setup

- Run your formatter / linter / tests.
- Confirm agents can find:
  - `AGENTS.md`
  - `.agents/contexts/conventions/*`
  - `.agents/contexts/security/*`

## 6) Ongoing maintenance (recommended cadence)

- Update conventions intentionally:
  - `.agents/runbooks/update_project_conventions_from_git.md`
- Track security posture:
  - update threat model and dependency policy as the project evolves
