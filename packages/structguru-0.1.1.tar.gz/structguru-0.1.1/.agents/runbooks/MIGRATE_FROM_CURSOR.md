---
schema_version: "2.4"
title: "Migrate an existing Cursor-configured repository to this standard"
description: "Procedure to consolidate existing Cursor rules into `.agents/` canonical docs and keep Cursor as a thin adapter (no duplicated rule text)."
category: "runbook"
status: "active"
version: "1.0.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-02-06"
last_verified: "2026-02-06"
owner: "Aleksandr Pavlov (ckidoz@gmail.com)"
agents_md_compatible: true

doc_id: "migrate-from-cursor"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: false
---

# Migrate from Cursor rules to `.agents/` (canonical standard)

Goal: keep **one source of truth** in `.agents/` and turn Cursor configuration into a **thin adapter**.

## 1) Inventory existing agent configuration

Look for:

- `.cursorrules` (legacy)
- `.cursor/rules/*.mdc`
- `.cursorignore` and/or `.cursorindexingignore`
- any custom “agent instruction files” already present (`AGENTS.md`, `GEMINI.md`, etc.)

## 2) Decide the canonical docs

Canonical (recommended):

- `AGENTS.md` (thin entrypoint)
- `.agents/contexts/**` (rules, conventions, architecture, security)
- `.agents/skills/**` (reusable skills)
- `.agents/runbooks/**` (deterministic procedures)

Cursor becomes an adapter:

- `.cursor/rules/global.mdc` should **instruct the agent to open `AGENTS.md` first** and follow `.agents/**`.

## 3) Move rules out of Cursor and into `.agents/contexts/**`

A practical mapping:

### 3.1 Style rules (naming, patterns, testing)
Move to:

- `.agents/contexts/conventions/STYLE_PROFILE.md`

### 3.2 “Where files go” rules (layout/module boundaries)
Move to:

- `.agents/contexts/conventions/FILE_PLACEMENT_MAP.md`

### 3.3 Security rules (secrets, unsafe commands, protected paths)
Move to:

- `.agents/contexts/security/SECURITY_OVERVIEW.md`
- `.agents/contexts/security/SECRETS_POLICY.md`
- `.agents/contexts/security/DEPENDENCY_POLICY.md`

## 4) Replace Cursor rules with a thin adapter rule

Create or rewrite:

- `.cursor/rules/global.mdc`

Start from:

- `.agents/templates/CURSOR_GLOBAL_RULE_TEMPLATE.mdc`

The global rule should:
- always apply
- require reading `AGENTS.md`
- point to the canonical `.agents/contexts/**` docs
- avoid duplicating large bodies of rule text (to prevent drift)

## 5) Align ignore / exclusion policies

Security reminder:

- Do not store secrets in the repo.
- Treat ignore files as **defense in depth**, not a guarantee.

Recommended layers:

- `.aiexclude` (agent context exclusion for supported tools)
- RAG ingestion policy (`.agents/rag.manifest.yaml`) to deny secrets
- Cursor:
  - `.cursorignore` (attempt to exclude files)
  - `.cursorindexingignore` (indexing/search exclusions)

## 6) Validate and “lock in” the new standard

- Ensure the Cursor agent follows `AGENTS.md` (test with a trivial task).
- Ensure conventions and placement rules are being applied in generated changes.
- Add a short note in your repo `README.md` (optional):
  - “Agent rules live in AGENTS.md and .agents/”

## 7) Maintenance pattern (recommended)

- Keep Cursor rule stable and minimal.
- Update conventions via the conventions runbook:
  - `.agents/runbooks/update_project_conventions_from_git.md`
- Update security contexts when you add new integrations, workflows, or dependencies.
