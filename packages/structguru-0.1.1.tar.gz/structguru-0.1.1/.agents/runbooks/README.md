---
schema_version: "2.4"
title: "Runbooks index"
description: "Operational procedures and deterministic checklists for agents and humans."
category: "runbook"
status: "active"
version: "0.1.0"
retrieval_priority: "medium"
retrieval_scope: "global"
last_updated: "2026-02-06"
last_verified: "2026-02-06"
owner: "Project Maintainers"
doc_id: "runbooks-index"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true
---

# Runbooks

Put **step-by-step**, deterministic procedures here.

Recommended runbooks:
- Bootstrap an empty repo (`BOOTSTRAP_EMPTY_REPO.md`)
- Migrate from Cursor (`MIGRATE_FROM_CURSOR.md`)
- Update project conventions from git (`update_project_conventions_from_git.md`)
- Release procedure
- CI troubleshooting
- Dependency upgrade playbook
- Incident response checklists

When a runbook requires secrets, **do not include them here**. Reference the secret name and the secret manager location instead.
