---
schema_version: "2.4"
title: "Update Project Conventions From Git"
description: "Maintainer runbook: derive/refresh STYLE_PROFILE and FILE_PLACEMENT_MAP from git history and exemplar files."
category: "runbook"
status: "active"
version: "1.0.0"
retrieval_priority: "medium"
retrieval_scope: "global"
last_updated: "2026-02-04"
last_verified: "2026-02-04"
owner: "Project Maintainers"
agents_md_compatible: true

doc_id: "runbook-update-conventions-from-git"
tags:
  - "runbook"
  - "conventions"
  - "git"

agent_notes:
  confidence: "high"
  safe_for_codegen: false
  requires_human_review: false
---

# Update Project Conventions From Git

This runbook describes a **repeatable** way to refresh:

- `.agents/contexts/conventions/STYLE_PROFILE.md`
- `.agents/contexts/conventions/FILE_PLACEMENT_MAP.md`

## Inputs

Choose a scope that reflects *current* practices:

- Commit range (preferred): `A..B` or `HEAD~N..HEAD`
- Time window: `--since="6 months ago"`
- Optional author filter: `--author="<team alias>"` (avoid personal identifiers where possible)
- Include/exclude paths to avoid vendor/generated code

## 1) Extract file placement patterns

Show added files and where they typically land:

```bash
git log --name-status --diff-filter=A --pretty=format: -- <PATHS...>
```

Useful variants:

```bash
git log --name-status --diff-filter=A --since="6 months ago" --pretty=format: -- src tests
git log --name-status --diff-filter=AM --pretty=format: -- src tests | sed -n 's/^[AM]	//p'
```

Summarize into `FILE_PLACEMENT_MAP.md`:

- “If adding X, put it in Y”
- Provide 2–5 exemplar paths per major rule

## 2) Extract style patterns (don’t guess)

1) **Trust tool configs first**
   - formatter configs (Prettier/Black/etc)
   - linter configs (ESLint/Ruff/etc)
   - editor configs (`.editorconfig`)

2) Pick **exemplar files** that represent current style:
   - frequently changed core modules
   - maintainer-reviewed areas
   - high-signal tests

Summarize into `STYLE_PROFILE.md`:

- naming rules
- error handling patterns
- test structure patterns
- logging/telemetry expectations

## 3) Record provenance

In both convention docs, update `conventions_provenance:`:

- `source: git-history` or `mixed`
- commit range / time window
- include/exclude paths
- notes about how exemplars were chosen

## 4) Verify and publish

- Update `last_verified` and `reviewed_date`
- Ensure the convention docs match reality (format/lint/test commands)
- Announce changes (optional) in internal docs/Slack

## Safety note

The goal is **project consistency**, not personal imitation.

- Do not encode or encourage “write like <person>”.
- Avoid embedding personal identifiers in long-lived docs.
