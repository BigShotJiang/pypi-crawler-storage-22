---
schema_version: "2.4"
title: "Automation schemas index"
description: "JSON Schemas for structured outputs and automation artifacts."
category: "agent-config"
status: "active"
version: "0.1.0"
retrieval_priority: "low"
retrieval_scope: "global"
last_updated: "2026-01-31"
last_verified: "2026-01-31"
owner: "Project Maintainers"
doc_id: "automation-schemas-index"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true
---

# Automation schemas

Store JSON Schemas used by automation or CI here.

Examples:
- `release-metadata.schema.json`
- `test-report.schema.json`
- `migration-plan.schema.json`

Agents running in CI can validate their output against these schemas to make results deterministic.
