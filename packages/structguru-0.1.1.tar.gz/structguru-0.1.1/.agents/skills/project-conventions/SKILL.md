---
name: "project-conventions"
schema_version: "2.4"
title: "Project Conventions"
description: "Skill: apply STYLE_PROFILE + FILE_PLACEMENT_MAP to keep changes consistent and correctly located."
category: "skill"
status: "active"
version: "1.0.0"
retrieval_priority: "high"
retrieval_scope: "skill"
last_updated: "2026-02-04"
last_verified: "2026-02-04"
owner: "Project Maintainers"
agents_md_compatible: true

doc_id: "skill-project-conventions"
tags:
  - "skill"
  - "conventions"
  - "style"
  - "layout"

oasf_skills:
  - "code_generation/source_code_generation"
  - "code_generation/code_review"

project_conventions:
  style_profile_ref: ".agents/contexts/conventions/STYLE_PROFILE.md"
  file_placement_map_ref: ".agents/contexts/conventions/FILE_PLACEMENT_MAP.md"
  enforcement: "required"

retrieval_hints:
  chunk_size: 650
  chunk_overlap: 65
  key_sections:
    - "workflow"
    - "outputs"

agent_notes:
  confidence: "high"
  safe_for_codegen: true
  requires_human_review: false
---

# Project Conventions (Skill)

Use this skill whenever you create or modify code.

## Workflow (required)

1. **Determine placement**
   - Read `.agents/contexts/conventions/FILE_PLACEMENT_MAP.md`.
   - Choose exact paths before creating new files.

2. **Match house style**
   - Read `.agents/contexts/conventions/STYLE_PROFILE.md`.
   - Find 1–2 exemplar files and copy patterns (imports, naming, error handling, tests).

3. **Implement with minimal diff**
   - Make the smallest change that satisfies requirements.
   - Avoid refactors unless explicitly requested.

4. **Run quality gates**
   - Run formatter/linter/tests (or provide exact commands if you cannot run them).
   - If commands fail, fix or clearly report failures.

5. **Summarize**
   - Files changed (paths)
   - Commands run (and results)
   - Any deviations from conventions (with justification)
   - If conventions were unclear, propose a minimal update to the convention docs

## Constraints

- **No persona mimicry**: do not imitate a developer’s writing “voice”. Follow repo conventions only.
- If conventions conflict with formatter/linter configs, **tools win** (update docs to match reality).
