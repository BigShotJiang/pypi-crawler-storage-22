---
name: "senior-python-developer"
schema_version: "2.4"
title: "Senior Python Developer"
description: "Skill: deliver senior-level Python implementation and review quality with clear architecture, strict typing, robust tests, and production-safe decisions; use for Python feature work, refactors, bug fixes, and code review."
category: "skill"
status: "active"
version: "1.1.0"
retrieval_priority: "high"
retrieval_scope: "skill"
last_updated: "2026-02-17"
last_verified: "2026-02-17"
owner: "Project Maintainers"
agents_md_compatible: true

doc_id: "skill-senior-python-developer"
tags:
  - "skill"
  - "python"
  - "architecture"
  - "testing"
  - "code-review"

oasf_skills:
  - "code_generation/source_code_generation"
  - "code_generation/code_review"

project_conventions:
  style_profile_ref: ".agents/contexts/conventions/STYLE_PROFILE.md"
  file_placement_map_ref: ".agents/contexts/conventions/FILE_PLACEMENT_MAP.md"
  enforcement: "required"

retrieval_hints:
  chunk_size: 650
  chunk_overlap: 65
  key_sections:
    - "workflow"
    - "review-checklist"
    - "outputs"

agent_notes:
  confidence: "high"
  safe_for_codegen: true
  requires_human_review: false
---

# Senior Python Developer (Skill)

Use this skill to execute Python work with a senior engineering bar while staying compliant with repo standards.

## Workflow (required)

1. **Load governing context first**
   - Read `AGENTS.md`.
   - Read `.agents/STANDARDS.md` and apply all MUST-level constraints.
   - Read `.agents/contexts/conventions/FILE_PLACEMENT_MAP.md` and `.agents/contexts/conventions/STYLE_PROFILE.md`.

2. **Define the change contract**
   - State expected behavior, compatibility requirements, and explicit non-goals.
   - Identify affected public APIs, state transitions, and operational side effects.
   - Choose the smallest reviewable diff that satisfies the contract.

3. **Implement with senior-quality design**
   - **Strict Typing:** Use Python 3.10+ type hints (`list[str]`, `str | int`, `TypeAlias`). Avoid `Any` unless strictly justified. All public methods must be typed.
   - **Modern Syntax:** Prefer modern Python idioms (e.g., `match/case`, f-strings, walrus operator `:=`) where they improve readability.
   - **Error Handling:** Use specific exceptions (inherit from project base exceptions if available) and chain them (`raise ... from e`). Ensure error messages are actionable.
   - **Modularity:** Keep module boundaries explicit: isolate pure logic from I/O orchestration.
   - **Performance:** Be mindful of algorithmic complexity and memory usage, especially in loops or high-throughput paths.
   - **Logging:** Use structured logging (via `structlog` or project-specific logger) for observability. Ensure log levels are appropriate.

4. **Verify behavior with targeted evidence**
   - **Testing:** Add or update `pytest` tests for success paths, edge cases, and failure paths. Use `pytest` fixtures for setup/teardown and parametrization for data-driven tests.
   - **Async Support:** If working with async code, ensure tests are marked properly (`@pytest.mark.asyncio`) and cover async execution paths.
   - **Regression Testing:** For bug fixes, add a regression test that fails without the fix.
   - **Quality Gates:** Run `uv run ruff check .` (linting), `uv run mypy src/` (type checking), and `uv run pytest` (testing) to ensure compliance.

5. **Run a review checklist before finalizing**
   - **Correctness:** No behavior regressions, no hidden coupling.
   - **Maintainability:** Clear naming, bounded complexity, predictable control flow.
   - **Documentation:** Public APIs have accurate docstrings (Google style or project standard).
   - **Type Contracts:** Call sites and return types remain coherent and strictly typed.
   - **Operational Safety:** Logging/metrics/error paths remain debuggable.
   - **Security:** No secret leakage, unsafe command execution, or trust in unvalidated external input.

6. **Report outcomes clearly**
   - What changed and why.
   - Files touched.
   - Commands run and key results (e.g., "All 45 tests passed").
   - Remaining risks, assumptions, and TODOs.

## Constraints

- Prioritize repository standards in `.agents/STANDARDS.md` when guidance conflicts.
- **Strictly Adhere to Python 3.10+ Standards:** Use modern typing syntax and features.
- **Dependency Management:** Use `uv` for dependency operations. Prefer existing dependencies over introducing new ones.
- **Tooling Compliance:** Code must pass `ruff` (lint/format) and `mypy` (strict mode) checks.
- Escalate to the user before destructive actions, network enablement, or actions outside workspace boundaries.
