---
schema_version: "2.4"
title: "<Document title>"
description: "<1–3 sentence summary>"
category: "service-context"          # service-context | runbook | specification | integration | security | ...
status: "draft"                      # draft | active | deprecated | sunset
version: "0.1.0"
retrieval_priority: "medium"         # critical | high | medium | low
retrieval_scope: "service"           # global | service | skill
last_updated: "2026-01-31"
last_verified: "2026-01-31"
owner: "<Team or owner>"

# Optional but recommended

doc_id: "<stable-slug>"              # e.g., "payments-service-overview"

tags:
  - "<domain-tag>"
keywords:
  - "<keyword>"

data_handling:
  classification: "internal"         # public | internal | confidential | restricted
  pii: "none"                        # none | low | high
  contains_secrets: false
  rag_allowed: true

# Optional: runtime posture (tool-agnostic)

execution_policy:
  default_mode: "read-only"          # read-only | workspace-write | full-auto
  network:
    default: "off"                   # off | allowlist | on
    allowlist_domains: []
  approvals:
    for_workspace_writes: "on-request"
    for_network: "on-request"
    for_outside_workspace: "always"
  web_search:
    mode: "cached"                   # disabled | cached | live

context_exclusion:
  aiexclude_file: ".aiexclude"
  notes: "<what must never be read>"

# Optional: security posture (review gates)

security_posture:
  risk_profile: "medium"          # low | medium | high | critical
  threat_model_ref: ""            # e.g., ".agents/contexts/security/THREAT_MODEL.md"
  secrets_policy_ref: ""          # e.g., ".agents/contexts/security/SECRETS_POLICY.md"
  dependency_policy_ref: ""       # e.g., ".agents/contexts/security/DEPENDENCY_POLICY.md"
  protected_paths: []             # patterns requiring human review


automation:
  output_schema_paths: []
  event_log:
    format: "jsonl"
    path: ""

# Optional: RAG hints

retrieval_hints:
  chunk_size: 500
  chunk_overlap: 50
  key_sections: []
  exclude_from_retrieval: []
---

# <Document title>

## Summary
- <3–8 bullets>

## Scope and assumptions
- …

## Key details
- …

## Interfaces and dependencies
- …

## Risks / gotchas
- …

## References
- …
