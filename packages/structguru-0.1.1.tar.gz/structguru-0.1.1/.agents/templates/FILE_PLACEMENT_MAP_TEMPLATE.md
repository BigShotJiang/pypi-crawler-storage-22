---
schema_version: "2.4"
title: "<File Placement Map>"
description: "Deterministic rules for where new code, tests, configs, and docs belong in this repo."
category: "specification"
status: "active"
version: "1.0.0"
retrieval_priority: "critical"
retrieval_scope: "global"
last_updated: "2026-02-04"
last_verified: "2026-02-04"
owner: "Project Maintainers"
agents_md_compatible: true

doc_id: "<stable-slug>"
tags:
  - "conventions"
  - "layout"
keywords:
  - "where to put"
  - "folder structure"
  - "tests"

conventions_provenance:
  source: "manual"   # manual | git-history | mixed
  git:
    range: "<optional: e.g. HEAD~200..HEAD>"
    since: "<optional: e.g. 6 months ago>"
    author: "<optional: avoid personal identifiers>"
    include_paths:
      - "<optional: e.g. src/**>"
    exclude_paths:
      - "<optional: e.g. vendor/**>"
    notes: "<how this was derived>"
  reviewed_by: "<team/person>"
  reviewed_date: "2026-02-04"

retrieval_hints:
  chunk_size: 700
  chunk_overlap: 70
  semantic_anchors:
    - "where to put"
    - "tests"
    - "src/"
    - "config"
    - "docs"

agent_notes:
  confidence: "high"
  safe_for_codegen: true
  requires_human_review: false
---

# <File Placement Map>

This document answers: **“Where should this new/changed thing live?”**

## Golden rules

1. **Prefer existing patterns**: find the closest existing feature/module and mirror its structure.
2. **Do not invent new top-level folders** without updating this map.
3. **Tests mirror production structure** unless the repo explicitly centralizes tests.
4. If uncertain, propose **2–3 candidate locations** + rationale and ask for confirmation.

## Placement by change type

| If you are adding/changing… | Put it in… | Example to copy |
|---|---|---|
| New feature module | `<path>` | `<path>` |
| API endpoint / handler | `<path>` | `<path>` |
| Domain logic / core rules | `<path>` | `<path>` |
| Database migrations | `<path>` | `<path>` |
| Config / env templates | `<path>` | `<path>` |
| Unit tests | `<path>` | `<path>` |
| Integration tests | `<path>` | `<path>` |
| Docs / runbooks | `.agents/contexts/` or `.agents/runbooks/` | `<path>` |

## Common repo paths

- Production code: `<src/>` or `<packages/>`
- Tests: `<tests/>` or `<src/**/__tests__/>`
- Shared utilities: `<path>`
- Scripts/tools: `<path>`
