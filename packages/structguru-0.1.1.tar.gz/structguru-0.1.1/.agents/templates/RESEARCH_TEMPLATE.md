---
schema_version: "2.4"
title: "<Research title>"
description: "<1–3 sentence summary of the research outcome and why it matters>"
category: "research-report"
status: "draft"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-01-31"
last_verified: "2026-01-31"
owner: "<Team or owner>"

# Optional but recommended for RAG + reuse

doc_id: "<stable-slug>"  # e.g., "rag-chunking-best-practices"

tags:
  - "research"
  - "<domain-tag>"
keywords:
  - "<keyword>"

# Safety: keep secrets out of research docs

data_handling:
  classification: "internal"      # public | internal | confidential | restricted
  pii: "none"                     # none | low | high
  contains_secrets: false
  rag_allowed: true

# Sources used (MUST for research-report)

sources:
  - source_id: "src:<id>"         # e.g., "src:openai-rag-help"
    title: "<Source title>"
    kind: "web"                   # web | pdf | paper | book | repo | issue | dataset | internal | other
    url: "<https://...>"          # optional if internal
    path: ".agents/sources/<...>.md"  # optional local snapshot/notes
    publisher: "<Publisher>"
    authors:
      - "<Author>"
    published_date: "<YYYY-MM-DD>"    # optional
    accessed_date: "<YYYY-MM-DD>"     # optional
    license: "<license/usage note>"   # optional
    checksum_sha256: "<sha256>"       # optional
    notes: "<why this source matters>"

research:
  question: "<Primary research question>"
  scope: "<What is covered, what is excluded>"
  method:
    - "<method>"                  # e.g., "web search", "read spec", "experiment"
  findings:
    - finding: "<Finding 1>"
      confidence: "medium"         # high | medium | low
      evidence:
        - source_id: "src:<id>"
          locator: "<section/page/paragraph>"
          quote: "<short excerpt (keep brief)>"
  open_questions:
    - "<Open question>"
  next_steps:
    - "<Next step>"

retrieval_hints:
  chunk_size: 500
  chunk_overlap: 50
  key_sections:
    - "summary"
    - "key findings"
  exclude_from_retrieval:
    - "appendix"

agent_notes:
  confidence: "medium"
  safe_for_codegen: false
  requires_human_review: true
---

# Summary

- <Key point 1>
- <Key point 2>

# Question and scope

**Question:** <…>

**Scope:** <…>

# Key findings

## Finding 1

- Statement: <…>
- Evidence: `src:<id>` (see frontmatter)
- Notes: <…>

# Implications for implementation

- <What should change in code/config/docs?>

# Open questions

- <…>

# Appendix (optional)

## Extra notes

<…>
