---
schema_version: "2.4"
title: "<Runbook title>"
description: "<What this runbook achieves and when to use it>"
category: "runbook"
status: "draft"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "service"
last_updated: "2026-01-31"
last_verified: "2026-01-31"
owner: "<Team or owner>"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

automation:
  output_schema_paths:
    - "<optional: .agents/schemas/...>"
---

# <Runbook title>

## When to use
- …

## Preconditions
- …

## Steps
1. …
2. …

## Verification
- …

## Rollback
- …

## Escalation
- …
