---
schema_version: "2.4"
title: "<Security doc title>"
description: "<What this security policy/threat model covers and why it matters>"
category: "security"
status: "draft"
version: "0.1.0"
retrieval_priority: "high"
retrieval_scope: "global"
last_updated: "2026-02-04"
last_verified: "2026-02-04"
owner: "<Team or owner>"

doc_id: "<stable-slug>"  # e.g., "secrets-policy", "threat-model-agentic"

data_handling:
  classification: "internal"      # public | internal | confidential | restricted
  pii: "none"                     # none | low | high
  contains_secrets: false
  rag_allowed: true

agent_notes:
  confidence: "medium"
  safe_for_codegen: false
  requires_human_review: true
---

# Purpose

- <What decision/policy this document encodes>

# Scope

- In scope: <...>
- Out of scope: <...>

# Requirements (MUST)

- <Non-negotiable rule 1>
- <Non-negotiable rule 2>

# Recommendations (SHOULD)

- <Best practice 1>
- <Best practice 2>

# Approval gates / Protected paths (optional)

- <Patterns that require human review>

# References (optional)

- <Links to OWASP/NIST/CISA/etc>
