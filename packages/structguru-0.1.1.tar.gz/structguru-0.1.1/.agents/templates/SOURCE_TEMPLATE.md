---
schema_version: "2.4"
title: "<Source title>"
description: "<What this source is and why it matters>"
category: "source-document"
status: "active"
version: "1.0.0"
retrieval_priority: "medium"
retrieval_scope: "global"
last_updated: "2026-01-31"
last_verified: "2026-01-31"
owner: "<Team or owner>"

doc_id: "<stable-source-slug>"  # e.g., "openai-rag-help"

data_handling:
  classification: "internal"
  pii: "none"
  contains_secrets: false
  rag_allowed: true

# Single-entry sources list (recommended)

sources:
  - source_id: "src:<id>"  # e.g., "src:openai-rag-help"
    title: "<Source title>"
    kind: "web"
    url: "<https://...>"
    publisher: "<Publisher>"
    authors:
      - "<Author>"
    published_date: "<YYYY-MM-DD>"
    accessed_date: "<YYYY-MM-DD>"
    license: "<license/usage note>"
    checksum_sha256: "<sha256>"    # if snapshot stored

retrieval_hints:
  chunk_size: 800
  chunk_overlap: 80
  exclude_from_retrieval:
    - "copyright"

agent_notes:
  confidence: "medium"
  safe_for_codegen: false
  requires_human_review: false
---

# Source metadata

- Canonical URL: <…>
- Accessed: <…>
- License/usage notes: <…>

# Extract / snapshot (optional)

> Keep excerpts short unless you have permission to store full content.

<Extracted text or summary here>

# Notes

- <What claims this source supports>
