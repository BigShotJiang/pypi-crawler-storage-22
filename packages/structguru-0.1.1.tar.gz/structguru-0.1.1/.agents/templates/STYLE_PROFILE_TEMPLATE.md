---
schema_version: "2.4"
title: "<Project Style Profile>"
description: "<House style rules for this repo...>"
category: "specification"
status: "active"
version: "1.0.0"
retrieval_priority: "critical"
retrieval_scope: "global"
last_updated: "2026-02-04"
last_verified: "2026-02-04"
owner: "Project Maintainers"
agents_md_compatible: true

doc_id: "<stable-slug>"
tags:
  - "conventions"
  - "style"
keywords:
  - "formatting"
  - "naming"
  - "tests"

conventions_provenance:
  source: "manual"   # manual | git-history | mixed
  git:
    range: "<optional: e.g. HEAD~200..HEAD>"
    since: "<optional: e.g. 6 months ago>"
    author: "<optional: avoid personal identifiers>"
    include_paths:
      - "<optional: e.g. src/**>"
    exclude_paths:
      - "<optional: e.g. vendor/**>"
    notes: "<how this was derived>"
  reviewed_by: "<team/person>"
  reviewed_date: "2026-02-04"

retrieval_hints:
  chunk_size: 600
  chunk_overlap: 60
  semantic_anchors:
    - "format"
    - "lint"
    - "naming"
    - "tests"
    - "error handling"

agent_notes:
  confidence: "high"
  safe_for_codegen: true
  requires_human_review: false
---

# <Project Style Profile>

This document defines **project style** (code and docs). The goal is consistent output and low-diff reviews.

**Do not impersonate a person**. Follow the repo’s patterns, not an individual’s “voice”.

## Non-negotiables

- **Formatter**: <command>
- **Linter**: <command>
- **Typecheck** (if applicable): <command>
- **Tests**: <command>

If tools disagree with this doc, **tool config wins** (formatters/linters are the source of truth).

## Naming conventions

- Files: <kebab-case | snake_case | PascalCase>
- Types/classes: <PascalCase>
- Functions: <camelCase>
- Constants: <UPPER_SNAKE_CASE>
- Test files: <pattern>

## Code patterns

### Error handling

- Prefer: <pattern>
- Avoid: <pattern>

### Logging / telemetry

- Prefer: <pattern>
- Fields to include: <...>

### API boundaries / layering

- Put domain logic in: <path>
- Keep I/O in: <path>

## Testing conventions

- Framework: <jest | pytest | ...>
- Arrange/Act/Assert: <yes/no>
- Mocking approach: <...>
- Where tests live: see `FILE_PLACEMENT_MAP.md`

## Documentation style

- Use short headings
- Prefer bullet lists for steps/checklists
- Keep examples copy/paste safe

## Exemplars

Agents SHOULD copy patterns from these exemplar files:

- `<path/to/good_example_1>`
- `<path/to/good_example_2>`
