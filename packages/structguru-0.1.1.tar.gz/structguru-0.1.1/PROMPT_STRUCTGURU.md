# Prompt for AI Agent: Creating `structguru`

**Role:** You are a Senior Python Architect and Library Maintainer.

**Objective:** Create a standalone, production-grade Python library named **`structguru`**.

**Description:**
`structguru` is a wrapper around **`structlog`** that implements the ergonomic, developer-friendly API of **`loguru`**. It combines `structlog`'s powerful structured logging, performance, and processor chain with `loguru`'s ease of use (brace formatting, `bind`, `contextualize`, `opt`, and sink management).

**Core Requirements:**
1.  **API Compatibility:** The main `logger` object must support `loguru` methods: `debug("msg {}", var)`, `bind(key=val)`, `contextualize(key=val)`, `opt(exception=True)`, `add()`, `remove()`.
2.  **Structured Backend:** It must use `structlog` for the actual processing and rendering.
3.  **JSON & Console:**
    *   **Production:** structured JSON output (via `orjson` for speed).
    *   **Development:** pretty-printed colored console output.
4.  **Sentry Integration:** It must preserve `exc_info` in `logging.LogRecord` so Sentry's standard logging integration works correctly (i.e., capturing stack traces properly before they are rendered to JSON).
5.  **Standard Library Interop:** It must intercept standard `logging` calls so third-party libraries (like `requests` or `django`) utilize the same JSON formatting.

**Reference Implementation:**
Use the following existing code as the "Golden Source" for the logic. Refine it into a proper package structure (e.g., separate `config.py`, `core.py`, `processors.py`).

**Source File 1: `vulners_django/utils/logger/structlog_logger.py` (The Facade)**
```python
"""Loguru-like wrapper for structlog.

Provides a :class:`Logger` dataclass that mirrors Loguru's ergonomic API
(``bind``, ``contextualize``, ``opt``, level methods) while delegating all
actual log processing to :mod:`structlog`.

A global ``logger`` instance is exported for convenience::

    from utils.logger.structlog_logger import logger

    logger.info("Hello {name}", name="world")
"""

import logging
import sys
import threading
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

import structlog
from structlog.contextvars import bound_contextvars

from utils.logger.structlog_setup import _to_logging_level

# ---------------------------------------------------------------------------
#  Type aliases (PEP 695)
# ---------------------------------------------------------------------------

type HandlerId = int
type Sink = str | Path | Any | logging.Handler | Callable[[str], None]


# ---------------------------------------------------------------------------
#  Internal helpers
# ---------------------------------------------------------------------------


def _caller_module_name() -> str:
    """Walk the call stack to find the first frame outside this module."""
    frame = sys._getframe(0)
    while frame is not None:
        name = frame.f_globals.get("__name__", "")
        if name != __name__:
            return name
        frame = frame.f_back
    return "unknown"


class _CallableHandler(logging.Handler):
    """A :class:`logging.Handler` that delegates to a plain callable."""

    def __init__(self, fn: Callable[[str], None]) -> None:
        super().__init__()
        self._fn = fn

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            self._fn(msg)
        except Exception:
            self.handleError(record)


def _make_handler(sink: Sink) -> logging.Handler:
    """Create a :class:`logging.Handler` from various *sink* types."""
    if isinstance(sink, logging.Handler):
        return sink
    if isinstance(sink, str | Path):
        return logging.FileHandler(str(sink), encoding="utf-8")
    if hasattr(sink, "write"):  # file-like objects
        return logging.StreamHandler(sink)  # type: ignore[arg-type]
    if callable(sink):  # callable sinks
        return _CallableHandler(sink)
    msg = f"Unsupported sink type: {type(sink)!r}"
    raise TypeError(msg)


def _safe_format(
    message: Any,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> tuple[str, bool]:
    """Safely format *message* with ``str.format``, imitating Loguru style.

    Returns a tuple of (formatted_message, consumed). If formatting fails
    or no placeholders are found, *consumed* is False.
    """
    msg = str(message)
    if not (args or kwargs) or "{" not in msg:
        return msg, False

    try:
        return msg.format(*args, **kwargs), True
    except KeyError, IndexError, ValueError:
        return msg, False


# ---------------------------------------------------------------------------
#  Logger facade
# ---------------------------------------------------------------------------


@dataclass
class Logger:
    """A Loguru-like facade for :mod:`structlog`.

    *   ``trace``, ``debug``, ``info``, ``success``, ``warning``, ``error``, ``critical``, ``exception`` methods.
    *   ``bind()`` — create child loggers with persistent context.
    *   ``contextualize()`` — add request-scoped context via *contextvars*.
    *   ``add()`` / ``remove()`` — manage logging handlers (sinks).
    *   ``opt()`` — include exception info or stack traces for one call.
    """

    name: str | None = None
    _bound: dict[str, Any] = field(default_factory=dict)
    _opt_exc_info: Any = None
    _opt_stack_info: bool = False

    # Thread-safe handler management
    _handlers: dict[HandlerId, logging.Handler] = field(default_factory=dict)
    _next_id: int = 1
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    # -- structlog bridge ---------------------------------------------------

    def _get_structlog_logger(self) -> Any:
        """Return a structlog logger, applying any bound context.

        When :attr:`name` is ``None`` (the default for the global logger),
        the caller's module ``__name__`` is resolved via stack introspection
        so that ``add_logger_name`` outputs the actual calling module instead
        of ``"root"``.
        """
        name = self.name if self.name is not None else _caller_module_name()
        log = structlog.get_logger(name)
        if self._bound:
            log = log.bind(**self._bound)
        return log

    # -- context helpers ----------------------------------------------------

    def bind(self, **kwargs: Any) -> Logger:
        """Return a *new* logger with permanently bound context."""
        merged = {**self._bound, **kwargs}
        return replace(self, _bound=merged)

    @contextmanager
    def contextualize(self, **kwargs: Any) -> Iterator[Logger]:
        """Apply context for the duration of a ``with`` block.

        The context is automatically included in all logs via
        :func:`structlog.contextvars.merge_contextvars`.
        """
        with bound_contextvars(**kwargs):
            yield self

    def opt(
        self,
        *,
        exception: Any = None,
        stack_info: bool = False,
    ) -> Logger:
        """Configure one-time options for the next log call.

        Example::

            logger.opt(exception=True).error("Something went wrong")
        """
        exc_info = exception if exception is not None else self._opt_exc_info
        return replace(self, _opt_exc_info=exc_info, _opt_stack_info=stack_info)

    # -- logging methods ----------------------------------------------------

    def trace(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self._log("debug", message, args, kwargs)

    def debug(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self._log("debug", message, args, kwargs)

    def info(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self._log("info", message, args, kwargs)

    def success(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self._log("info", message, args, kwargs)

    def warning(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self._log("warning", message, args, kwargs)

    def warn(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self.warning(message, *args, **kwargs)

    def error(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self._log("error", message, args, kwargs)

    def critical(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self._log("critical", message, args, kwargs)

    def fatal(self, message: Any, *args: Any, **kwargs: Any) -> None:
        self.critical(message, *args, **kwargs)

    def exception(self, message: Any, *args: Any, **kwargs: Any) -> None:
        """Log at ``ERROR`` level with exception information."""
        kwargs.setdefault("exc_info", True)
        self._log("error", message, args, kwargs)

    def _log(
        self,
        method: str,
        message: Any,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> None:
        """Internal dispatch.

        *kwargs* serve a dual purpose: they are used **both** for
        ``str.format`` interpolation *and* as structured fields in the
        JSON output.  This replicates Loguru's behaviour::

            logger.info("Hello {name}", name="world")
            # → message: "Hello world", name: "world"
        """
        structlog_logger = self._get_structlog_logger()
        formatted_msg, consumed = _safe_format(message, args, kwargs)

        if self._opt_exc_info is not None:
            kwargs.setdefault("exc_info", self._opt_exc_info)
        if self._opt_stack_info:
            kwargs.setdefault("stack_info", True)

        if not consumed and args:
            getattr(structlog_logger, method)(formatted_msg, *args, **kwargs)
        else:
            getattr(structlog_logger, method)(formatted_msg, **kwargs)

    # -- sink (handler) management ------------------------------------------

    def add(self, sink: Sink, *, level: str | None = None) -> HandlerId:
        """Add a new logging handler (*sink*).

        Parameters
        ----------
        sink:
            A file path, ``stdout``/``stderr``, a :class:`logging.Handler`,
            or a callable accepting a single string.
        level:
            Minimum level for this handler.  Inherits from the root logger
            when *None*.

        Returns
        -------
        HandlerId
            An identifier that can be passed to :meth:`remove`.
        """
        handler = _make_handler(sink)
        log_level = _to_logging_level(level) if level else logging.getLogger().level
        handler.setLevel(log_level)
        handler.setFormatter(logging.Formatter("%(message)s"))

        root = logging.getLogger()
        root.addHandler(handler)

        with self._lock:
            handler_id = self._next_id
            self._handlers[handler_id] = handler
            self._next_id += 1
        return handler_id

    def remove(self, handler_id: HandlerId | None = None) -> None:
        """Remove a handler by its *handler_id*.

        If *handler_id* is ``None``, all handlers added via this logger
        instance are removed.
        """
        root = logging.getLogger()
        with self._lock:
            if handler_id is None:
                for h in self._handlers.values():
                    root.removeHandler(h)
                self._handlers.clear()
                return

            handler_to_remove = self._handlers.pop(handler_id, None)

        if handler_to_remove:
            root.removeHandler(handler_to_remove)


# Global logger instance, matching Loguru's convention.
logger = Logger()
```

**Source File 2: `vulners_django/utils/logger/structlog_setup.py` (The Configuration)**

```python
"""Structlog configuration for structured JSON logging.

Configures structlog to produce JSON logs with standardized fields:
- ``timestamp``: ISO 8601 / RFC 3339 in UTC (``Z`` suffix).
- ``service``: application name.
- ``level``: one of ``CRITICAL``, ``ERROR``, ``WARN``, ``INFO``, ``DEBUG``.
- ``severity``: RFC 5424 syslog severity code (``2``–``7``).
- ``message``: the log message as a string.
"""

import logging
import os
import sys
from collections.abc import Callable
from logging.handlers import RotatingFileHandler
from typing import Any

import orjson
import structlog
from structlog.contextvars import merge_contextvars

# ---------------------------------------------------------------------------
#  Helper functions
# ---------------------------------------------------------------------------

_LEVEL_MAP: dict[str, str] = {
    "trace": "DEBUG",
    "debug": "DEBUG",
    "info": "INFO",
    "success": "INFO",
    "warning": "WARN",
    "warn": "WARN",
    "error": "ERROR",
    "critical": "CRITICAL",
    "fatal": "CRITICAL",
    "exception": "ERROR",
}


# RFC 5424 syslog severity codes (§6.2.1)
# https://datatracker.ietf.org/doc/html/rfc5424#section-6.2.1
_SEVERITY_MAP: dict[str, int] = {
    "DEBUG": 7,  # Debug-level messages
    "INFO": 6,  # Informational messages
    "WARN": 4,  # Warning conditions
    "ERROR": 3,  # Error conditions
    "CRITICAL": 2,  # Critical conditions
}


def _to_logging_level(level_name: str) -> int:
    """Convert a human-readable level name to its :mod:`logging` constant."""
    upper_level = level_name.upper()
    if upper_level == "WARN":
        return logging.WARNING
    return getattr(logging, upper_level, logging.INFO)


# ---------------------------------------------------------------------------
#  Structlog processors
# ---------------------------------------------------------------------------


def add_service(
    service_name: str,
) -> Callable[[Any, str, dict[str, Any]], dict[str, Any]]:
    """Return a processor that adds a ``service`` field to every log record."""

    def _processor(
        _logger: Any,
        _method_name: str,
        event_dict: dict[str, Any],
    ) -> dict[str, Any]:
        event_dict.setdefault("service", service_name)
        return event_dict

    return _processor


def normalize_level(
    _logger: Any,
    method_name: str,
    event_dict: dict[str, Any],
) -> dict[str, Any]:
    """Normalize the log level to one of: ``CRITICAL``, ``ERROR``, ``WARN``, ``INFO``, ``DEBUG``."""
    raw_level = event_dict.get("level", method_name)
    raw_level_str = str(raw_level).lower()
    event_dict["level"] = _LEVEL_MAP.get(raw_level_str, raw_level_str.upper())
    return event_dict


def add_syslog_severity(
    _logger: Any,
    _method_name: str,
    event_dict: dict[str, Any],
) -> dict[str, Any]:
    """Add RFC 5424 syslog ``severity`` code (numeric) to the event.

    Must run **after** :func:`normalize_level` so that ``event_dict["level"]``
    is already one of the canonical strings (``CRITICAL``, ``ERROR``, etc.).
    Defaults to ``6`` (Informational) for unknown levels.
    """
    level = event_dict.get("level", "INFO")
    event_dict["severity"] = _SEVERITY_MAP.get(level, 6)
    return event_dict


def ensure_event_is_str(
    _logger: Any,
    _method_name: str,
    event_dict: dict[str, Any],
) -> dict[str, Any]:
    """Ensure the main log message (``event``) is a string."""
    event = event_dict.get("event")
    if event is not None and not isinstance(event, str):
        event_dict["event"] = str(event)
    return event_dict


# ---------------------------------------------------------------------------
#  Public API
# ---------------------------------------------------------------------------


class _StructlogMsgFixer(logging.Handler):
    """Normalize ``record.msg`` from a structlog event dict to a plain string.

    ``wrap_for_formatter`` stores the whole event dict as ``record.msg``.
    ``ProcessorFormatter`` renders on a **shallow copy** of the record, so
    the original ``record.msg`` stays a ``dict``.  Any handler that runs
    *after* ``ProcessorFormatter`` (notably Sentry's ``EventHandler`` in the
    ``finally`` block of ``callHandlers``) would see the raw dict and call
    ``str(dict)`` — producing an ugly repr.

    This handler is added to the root logger **after** the stream handler.
    By the time it runs, ``ProcessorFormatter`` has already finished with
    its copy, so mutating ``record.msg`` here is safe.  Sentry then sees a
    clean string for events, breadcrumbs, and structured logs alike.
    """

    def emit(self, record: logging.LogRecord) -> None:
        if isinstance(record.msg, dict):
            # EventRenamer("message") puts the text under "message";
            # fall back to structlog's default "event" key.
            record.msg = record.msg.get("message") or record.msg.get("event") or str(record.msg)


def _install_exc_info_record_factory() -> None:
    """Patch the ``LogRecord`` factory to propagate ``exc_info`` from structlog.

    ``wrap_for_formatter`` passes the event dict as ``record.msg`` but does
    **not** set ``record.exc_info``.  Sentry's ``LoggingIntegration`` reads
    ``record.exc_info`` before ``ProcessorFormatter`` runs, so it would miss
    structured exception data.

    This factory extracts ``exc_info`` from the event dict and passes it to
    the original factory so the ``LogRecord`` is created with ``exc_info``
    intact.
    """
    original = logging.getLogRecordFactory()
    if getattr(original, "_structlog_exc_info_patched", False):
        return  # already installed — idempotent

    def factory(
        name: str,
        level: int,
        fn: str,
        lno: int,
        msg: Any,
        args: Any,
        exc_info: Any,
        func: str | None = None,
        sinfo: str | None = None,
    ) -> logging.LogRecord:
        if exc_info is None and isinstance(msg, dict):
            ei = msg.get("exc_info")
            if ei is True:
                exc_info = sys.exc_info()
            elif isinstance(ei, BaseException):
                exc_info = (type(ei), ei, ei.__traceback__)
            elif isinstance(ei, tuple):
                exc_info = ei
        return original(name, level, fn, lno, msg, args, exc_info, func, sinfo)

    factory._structlog_exc_info_patched = True  # type: ignore[attr-defined]
    logging.setLogRecordFactory(factory)


def _stream_isatty(stream: Any) -> bool:
    """Check if *stream* is connected to a terminal."""
    try:
        return stream.isatty()
    except AttributeError, ValueError:
        return False


def _build_shared_processors(
    service: str,
) -> list[structlog.types.Processor]:
    """Build the shared processor chain used by both structlog and stdlib records.

    These processors enrich the event dict with metadata but intentionally
    do **not** format ``exc_info`` — that is deferred to the
    ``ProcessorFormatter`` so Sentry sees the raw ``LogRecord.exc_info``.
    """
    return [  # type: ignore[return-value]
        merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        normalize_level,
        add_syslog_severity,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso", utc=True, key="timestamp"),
        add_service(service),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
        ensure_event_is_str,
        structlog.processors.EventRenamer("message"),
    ]


def _build_formatter_processors(
    renderer: structlog.types.Processor,
    *,
    json_mode: bool = True,
) -> list[structlog.types.Processor]:
    """Build the ``ProcessorFormatter`` processor chain (final rendering stage).

    ``format_exc_info`` runs here — *after* Sentry has already captured the
    ``LogRecord`` with the original ``exc_info`` tuple intact.

    In console mode, ``format_exc_info`` is omitted because
    ``ConsoleRenderer`` handles exception rendering natively with
    pretty formatting.
    """
    processors: list[structlog.types.Processor] = [
        structlog.stdlib.ProcessorFormatter.remove_processors_meta,
    ]
    # JSONRenderer needs exc_info pre-formatted to a string;
    # ConsoleRenderer handles exc_info natively with pretty output.
    if json_mode:
        processors.append(structlog.processors.format_exc_info)
    processors.append(renderer)
    return processors


def configure_structlog(
    *,
    service: str,
    level: str = "INFO",
    json_logs: bool = True,
    stream: Any = sys.stdout,
) -> None:
    """Configure structlog with ``ProcessorFormatter`` for stdlib integration.

    Uses :class:`structlog.stdlib.ProcessorFormatter` so that ``exc_info``
    is preserved on :class:`logging.LogRecord` objects.  This allows Sentry's
    ``LoggingIntegration`` (and any other stdlib-based consumer) to capture
    structured exception data *before* the traceback is rendered to text.

    Standard output keys: ``timestamp``, ``service``, ``level``, ``severity``,
    ``message``.  Additional fields from *kwargs* and *contextvars* are included.

    .. warning::

       ``root.handlers.clear()`` removes **all** existing handlers.  This is
       intentional to ensure full control over log output, but may interfere
       with logging configurations set up by third-party libraries.
    """
    _install_exc_info_record_factory()

    shared_processors = _build_shared_processors(service)

    structlog.configure(
        processors=shared_processors + [structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.make_filtering_bound_logger(
            _to_logging_level(level),
        ),
        cache_logger_on_first_use=True,
    )

    # Select the renderer: JSON for production, ConsoleRenderer for dev.
    renderer: structlog.types.Processor = (
        structlog.processors.JSONRenderer(
            serializer=lambda obj, **_kw: orjson.dumps(obj).decode(),
        )
        if json_logs
        else structlog.dev.ConsoleRenderer(
            colors=_stream_isatty(stream),
            event_key="message",
        )
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processors=_build_formatter_processors(renderer, json_mode=json_logs),
        foreign_pre_chain=shared_processors,
    )

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(_to_logging_level(level))

    handler = logging.StreamHandler(stream)
    handler.setFormatter(formatter)
    root.addHandler(handler)

    # Must be added *after* the stream handler so ProcessorFormatter runs
    # first (on its copy).  This normalizes record.msg from a structlog
    # event dict to a plain string before Sentry's EventHandler sees it.
    root.addHandler(_StructlogMsgFixer())


def setup_structlog() -> None:
    """Application-level logging setup — drop-in replacement for ``setup_logging()``.

    Reads environment variables for backward compatibility:

    - ``LOG_LEVEL`` (default: ``"INFO"``)
    - ``JSON_LOGS`` (``"0"`` = console, default: ``"1"`` = JSON)
    - ``LOG_PATH`` (optional file sink with 50 MB rotation)
    """
    level = os.environ.get("LOG_LEVEL", "INFO")
    json_logs = os.environ.get("JSON_LOGS", "1") != "0"

    configure_structlog(service="vulners", level=level, json_logs=json_logs)

    # Suppress noisy third-party loggers (same as old setup_logging)
    for name in ("elasticsearch", "elastic_transport"):
        lib_logger = logging.getLogger(name)
        lib_logger.setLevel(logging.WARNING)

    # Optional file handler with rotation (mirrors loguru's rotation="50 MB").
    # File output always uses JSON for machine-parseable logs.
    log_path = os.environ.get("LOG_PATH")
    if log_path:
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=50 * 1024 * 1024,  # 50 MB
            backupCount=5,
            encoding="utf-8",
        )
        json_renderer = structlog.processors.JSONRenderer(
            serializer=lambda obj, **_kw: orjson.dumps(obj).decode(),
        )
        file_formatter = structlog.stdlib.ProcessorFormatter(
            processors=_build_formatter_processors(json_renderer),
            foreign_pre_chain=_build_shared_processors("vulners"),
        )
        file_handler.setFormatter(file_formatter)
        logging.getLogger().addHandler(file_handler)

    # Uncaught exception handler
    def _log_exception(
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_traceback: Any,
    ) -> None:
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logging.getLogger().error(
            "Uncaught exception",
            exc_info=(exc_type, exc_value, exc_traceback),
        )

    sys.excepthook = _log_exception
```

**Deliverables:**

1.  **Project Structure:** A modern `src/` layout.
2.  **`pyproject.toml`:** Configuration using `uv` or `poetry`. Dependencies: `structlog`, `orjson`. Support Python 3.10+.
3.  **Library Code:** Refactored and clean code split into logical modules (e.g., `structguru.logger`, `structguru.config`).
4.  **Usage Examples:** Show how to:
    *   Install it.
    *   Configure it for JSON logs.
    *   Use `logger.info("User {id} logged in", id=123)`.
    *   Use `with logger.contextualize(request_id="abc"): ...`.

**Tone:** Professional, clean, and ready for PyPI publication.
