# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ChatTemplateCreateParams"]


class ChatTemplateCreateParams(TypedDict, total=False):
    chat_session_id: Required[str]

    description: Required[str]

    display_order: Required[int]

    image_url: Required[str]

    is_active: Required[bool]

    title: Required[str]
