# strx-bnm (Initium Brand New Module)

Herramienta oficial de **Initium Services** para la creación estandarizada de nuevos módulos en **Odoo 20**.

## 🚀 Propósito

`strx-bnm` automatiza la creación de la estructura base de un módulo de Odoo siguiendo las mejores prácticas y estándares internos de Initium. Asegura que cada nuevo módulo nazca con los directorios obligatorios, configuraciones de versión correctas y placeholders listos para el desarrollo.

## ✨ Características

- **Estructura Odoo 20 Ready**: Genera el esqueleto completo con modelos, vistas, controladores, reportes y wizards.
- **Personalización Automática**: Reemplaza placeholders técnicos por el nombre de tu nuevo módulo.
- **Cumplimiento de Estándares**: Crea automáticamente las carpetas `tests/` y `static/readme/` necesarias para pasar las validaciones de pre-commit.
- **Changelog Inicial**: Genera un archivo `CHANGELOG.md` con la versión inicial `20.0.1.0.0`.
- **Plantilla Integrada**: Utiliza un esqueleto base optimizado y actualizado.

## 📦 Instalación

Puedes instalarlo directamente desde PyPI:

```bash
pip install strx-bnm
```

O desde el código fuente:

```bash
cd strx_bnm_tool
pip install .
```

## 🛠️ Uso

### 1. Configuración Inicial
La primera vez que lo ejecutes, te pedirá el directorio por defecto donde guardas tus módulos de Odoo:

```bash
strx-bnm
```

### 2. Crear un Módulo
Simplemente sigue el asistente interactivo:

```bash
strx-bnm
```

**Pasos:**
1. Introduce el nombre técnico (ej: `strx_mi_modulo`).
2. Confirma o cambia el directorio de creación.
3. ¡Listo! Tu módulo ha sido creado.

### 3. Reconfiguración
Si deseas cambiar el directorio por defecto de Odoo:

```bash
strx-bnm --config
```

## 📂 Estructura Generada

El módulo creado tendrá la siguiente estructura mínima:

```
mi_modulo/
├── CHANGELOG.md
├── README.rst (dentro de static/readme)
├── __init__.py
├── __manifest__.py
├── controllers/
├── data/
├── demo/
├── models/
├── report/
├── security/
├── static/
│   └── readme/
├── tests/
├── views/
└── wizard/
```

## 🛡️ Licencia

Propiedad de **STRACONX S.A.** - Licencia OPL-1.
