
from setuptools import setup, find_packages
import os
import shutil

# La plantilla (esqueleto) se encuentra en el directorio 'template/'

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="strx-bnm",
    version="0.2.1",
    py_modules=["strx_bnm_tool"],
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "strx_bnm_tool": ["template/*", "template/**/*"],
    },
    entry_points={
        "console_scripts": [
            "strx-bnm=strx_bnm_tool:main",
        ],
    },
    author="Initium Services",
    author_email="sistemas@straconx.com",
    description="Herramienta para crear nuevos módulos Odoo 20 siguiendo estándares de Initium",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/straconxsa/strx_tools",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
