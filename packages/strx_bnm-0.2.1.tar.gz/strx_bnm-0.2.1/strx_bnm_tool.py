
import os
import sys
import shutil
import json
from pathlib import Path

CONFIG_FILE = Path.home() / ".strx_bnm_config"

def get_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f)

def setup_config():
    print("--- Configuración inicial de strx-bnm ---")
    default_path = input("Introduce el directorio por defecto de tus módulos de Odoo: ").strip()
    if not os.path.isabs(default_path):
        default_path = os.path.abspath(default_path)
    
    config = {"odoo_path": default_path}
    save_config(config)
    print(f"Configuración guardada en {CONFIG_FILE}")

def main():
    config = get_config()
    if not config or "--config" in sys.argv:
        setup_config()
        config = get_config()

    print("\n🚀 Creación de Nuevo Módulo Odoo 20 (Initium Standard)")
    
    module_name = input("Nombre del técnico del módulo (ej: strx_mi_modulo): ").strip()
    if not module_name:
        print("Error: El nombre del módulo es obligatorio.")
        sys.exit(1)

    target_dir = input(f"Directorio de creación [{config['odoo_path']}]: ").strip()
    if not target_dir:
        target_dir = config['odoo_path']

    full_path = os.path.join(target_dir, module_name)

    if os.path.exists(full_path):
        confirm = input(f"⚠️ El directorio {full_path} ya existe. ¿Sobrescribir? (s/N): ").lower()
        if confirm != 's':
            print("Operación cancelada.")
            sys.exit(0)
        shutil.rmtree(full_path)

    # Ruta de la plantilla (donde está instalado el paquete)
    template_path = os.path.join(os.path.dirname(__file__), "template")
    
    shutil.copytree(template_path, full_path)

    # Reemplazar placeholders en nombres de archivos y contenido
    for root, dirs, files in os.walk(full_path):
        for name in files:
            file_path = os.path.join(root, name)
            
            # Leer contenido
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Reemplazos Odoo 20 Ready
            content = content.replace("strx_bnm", module_name)
            content = content.replace("16.0.0.1.0", "20.0.1.0.0")
            content = content.replace('"installable": False', '"installable": True')
            
            # Escribir contenido actualizado
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)

    # Crear CHANGELOG.md inicial
    with open(os.path.join(full_path, "CHANGELOG.md"), "w") as f:
        f.write(f"# Changelog {module_name}\n\n## [20.0.1.0.0] - {module_name}\n- Estructura inicial del módulo.\n")

    # Crear directorios obligatorios para migración (tests y doc)
    os.makedirs(os.path.join(full_path, "tests"), exist_ok=True)
    os.makedirs(os.path.join(full_path, "static/readme"), exist_ok=True)
    
    with open(os.path.join(full_path, "tests/__init__.py"), "w") as f:
        f.write("# Tests\n")

    print(f"\n✅ Módulo '{module_name}' creado exitosamente en {full_path}")
    print("💡 Recuerda añadir la documentación inicial en static/readme/ y tests en tests/ para pasar el pre-commit.")

if __name__ == "__main__":
    main()
