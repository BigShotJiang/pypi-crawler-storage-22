{
    # Always check if python objects must be called
    "name": "Use this module base for create new modules",
    "summary": """
        Short (1 phrase/line) summary of the module"s purpose, used as
        subtitle on modules listing or apps.openerp.com""",
    "author": "Add your name, STRACONX S.A.",
    "website": "http://start.initium.cloud",
    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    "category": "Hidden",
    "version": "20.0.1.0.0",
    "license": "OPL-1",
    "installable": True,
    "development_status": "New",
    # any module necessary for this one to work correctly
    "depends": ["base"],
    # always loaded. Activate before install the module
    "data": [
        # "security/ir.model.access.csv",
        # "data/strx_data_add_new_model.xml",
        # "views/strx_templates_add_name.xml",
        # "views/strx_views_add_name.xml",
        # "views/strx_menu.xml",
        # "report/strx_report_add_name.xml",
        # "report/strx_report_add_definition.xml",
    ],
    # only loaded in demonstration mode
    "demo": [
        "demo/strx_demo_add_name.xml",
    ],
    # add this fields if is necessary
    # "country": "Add name of country",
    # "price": "0.00",
    # "currency": "USD",
    # "image": [],
    # "css":
}
