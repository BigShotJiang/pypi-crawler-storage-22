# -*- coding: utf-8 -*-
# from odoo import http


# class /odoo14/initium/strxModulesMaintenance/strxFsEquipment(http.Controller):
#     @http.route('/add_name/add_name/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/add_name/add_name/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('add_name.listing', {
#             'root': '/add_name/add_name',
#             'objects': http.request.env['add_name.add_name'].search([]),
#         })

#     @http.route('/add_name/add_name/objects/<model("add_name.add_name"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('add_name.object', {
#             'object': obj
#         })
