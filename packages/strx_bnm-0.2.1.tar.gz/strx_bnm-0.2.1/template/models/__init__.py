# -*- coding: utf-8 -*-

from . import strx_models_add_name