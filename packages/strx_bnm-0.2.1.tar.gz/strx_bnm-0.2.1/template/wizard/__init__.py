# -*- coding: utf-8 -*-

from . import strx_wizard_add_name