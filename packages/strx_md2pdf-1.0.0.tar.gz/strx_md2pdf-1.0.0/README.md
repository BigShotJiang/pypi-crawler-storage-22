# STRX Markdown to PDF Converter

Herramienta para convertir archivos Markdown a PDF con estilos profesionales.

## Características

- ✅ Conversión de Markdown a PDF con formato profesional.
- ✅ Soporte para checkboxes `[ ]` y `[x]`.
- ✅ Soporte para tablas, listas, código y más.
- ✅ Estilos CSS personalizados y profesionales.
- ✅ Numeración automática de páginas y diseño optimizado para A4.
- ✅ Resaltado de sintaxis para bloques de código.
- ✅ Tabla de contenidos automática.

## Instalación

Puedes instalar esta herramienta directamente desde el código fuente o como un paquete de Python.

### Desde el código fuente (para desarrollo)

```bash
cd /odoo20/strx_tools/strx_md2pdf
pip install -e .
```

### Instalación normal

```bash
pip install /odoo20/strx_tools/strx_md2pdf
```

## Uso

Una vez instalado, el comando `strx_md2pdf` estará disponible en tu terminal.

### Uso básico

```bash
# Genera archivo.pdf en el mismo directorio
strx_md2pdf archivo.md
```

### Especificar archivo de salida

```bash
strx_md2pdf archivo.md /ruta/al/destino/salida.pdf
```

### Usar como módulo de Python

```bash
python3 -m strx_md2pdf archivo.md
```

## Requisitos del sistema

Para que `weasyprint` funcione correctamente, es posible que necesites instalar algunas dependencias del sistema dependiendo de tu OS.

En Ubuntu/Debian:
```bash
sudo apt-get install python3-pip python3-cffi python3-brotli libpango-1.0-0 libharfbuzz0b libpangoft2-1.0-0
```

## Autor

Straconx - Equipo de Initium 20

## Licencia

MIT
