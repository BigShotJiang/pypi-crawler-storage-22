#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRX Markdown to PDF Converter
===============================

Script para convertir archivos Markdown a PDF usando WeasyPrint.
Soporta checkboxes de Markdown y genera un PDF con estilos profesionales.

Uso:
    strx_md2pdf <archivo.md> [salida.pdf]
    python3 -m strx_md2pdf <archivo.md> [salida.pdf]
"""

import argparse
import sys
import re
from pathlib import Path
import markdown
try:
    from weasyprint import HTML, CSS
except ImportError:
    print("❌ Error: WeasyPrint no está instalado. Instálalo con 'pip install weasyprint'")
    sys.exit(1)


def markdown_to_html(md_content):
    """
    Convierte contenido Markdown a HTML con extensiones.
    """
    md = markdown.Markdown(extensions=[
        'extra',           # Tablas, atributos, etc.
        'nl2br',           # Convierte saltos de línea en <br>
        'sane_lists',      # Mejora el manejo de listas
        'codehilite',      # Resaltado de código
        'toc',             # Tabla de contenidos
    ])
    return md.convert(md_content)


def process_checkboxes(html_content):
    """
    Procesa checkboxes de Markdown [ ] y [x] para mostrarlos en el PDF.
    """
    # Reemplazar [ ] con ☐ seguido de espacio
    html_content = html_content.replace('[ ]', '☐&nbsp;')
    # Reemplazar [x] o [X] con ☑ seguido de espacio
    html_content = html_content.replace('[x]', '☑&nbsp;')
    html_content = html_content.replace('[X]', '☑&nbsp;')

    # Agregar clase task-item a los <li> que contienen checkboxes
    html_content = re.sub(
        r'<li>([☐☑]&nbsp;)',
        r'<li class="task-item">\1',
        html_content
    )

    # También manejar casos donde hay un <p> dentro del <li>
    html_content = re.sub(
        r'<li><p>([☐☑]&nbsp;)',
        r'<li class="task-item"><p>\1',
        html_content
    )

    return html_content


def create_styled_html(title, body_html):
    """
    Crea un documento HTML completo con estilos CSS profesionales.
    """
    return f"""
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        @page {{
            size: A4;
            margin: 2cm;
            @bottom-right {{
                content: "Página " counter(page) " de " counter(pages);
                font-size: 10px;
                color: #666;
            }}
        }}

        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 100%;
            font-size: 11pt;
        }}

        h1 {{
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            margin-top: 30px;
            font-size: 28pt;
            page-break-after: avoid;
        }}

        h2 {{
            color: #34495e;
            border-bottom: 2px solid #95a5a6;
            padding-bottom: 8px;
            margin-top: 25px;
            font-size: 20pt;
            page-break-after: avoid;
        }}

        h3 {{
            color: #555;
            margin-top: 20px;
            font-size: 16pt;
            page-break-after: avoid;
        }}

        h4, h5, h6 {{
            color: #666;
            margin-top: 15px;
            page-break-after: avoid;
        }}

        ul, ol {{
            margin: 10px 0;
            padding-left: 30px;
        }}

        li {{
            margin: 5px 0;
            padding-left: 8px;
            page-break-inside: avoid;
        }}

        /* Remover viñetas solo de items de tareas (checkboxes) */
        li.task-item {{
            list-style-type: none;
            margin-left: -25px;
            padding-left: 0;
            text-indent: 0;
        }}

        code {{
            background-color: #f4f4f4;
            border: 1px solid #ddd;
            border-radius: 3px;
            padding: 2px 6px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 10pt;
        }}

        pre {{
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            overflow-x: auto;
            page-break-inside: avoid;
        }}

        pre code {{
            background: none;
            border: none;
            padding: 0;
        }}

        blockquote {{
            border-left: 4px solid #3498db;
            margin: 15px 0;
            padding: 10px 20px;
            background-color: #f9f9f9;
            font-style: italic;
        }}

        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
            page-break-inside: avoid;
        }}

        th, td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }}

        th {{
            background-color: #3498db;
            color: white;
            font-weight: bold;
        }}

        tr:nth-child(even) {{
            background-color: #f2f2f2;
        }}

        a {{
            color: #3498db;
            text-decoration: none;
        }}

        a:hover {{
            text-decoration: underline;
        }}

        .checkbox {{
            font-size: 14pt;
            margin-right: 5px;
        }}

        hr {{
            border: none;
            border-top: 2px solid #ddd;
            margin: 30px 0;
        }}
    </style>
</head>
<body>
{body_html}
</body>
</html>
"""


def convert_md_to_pdf(input_file, output_file=None):
    """
    Convierte un archivo Markdown a PDF.
    """
    input_path = Path(input_file)

    if not input_path.exists():
        raise FileNotFoundError(f"El archivo '{input_file}' no existe.")

    if not input_path.is_file():
        raise ValueError(f"'{input_file}' no es un archivo válido.")

    # Determinar el archivo de salida
    if output_file is None:
        output_path = input_path.with_suffix('.pdf')
    else:
        output_path = Path(output_file)
        # Crear directorios si no existen
        output_path.parent.mkdir(parents=True, exist_ok=True)

    # Leer el contenido del archivo Markdown
    print(f"📖 Leyendo archivo: {input_path}")
    with open(input_path, 'r', encoding='utf-8') as f:
        md_content = f.read()

    # Convertir Markdown a HTML
    print("🔄 Convirtiendo Markdown a HTML...")
    html_body = markdown_to_html(md_content)

    # Procesar checkboxes
    html_body = process_checkboxes(html_body)

    # Crear HTML completo con estilos
    title = input_path.stem
    full_html = create_styled_html(title, html_body)

    # Convertir HTML a PDF
    print(f"📄 Generando PDF: {output_path}")
    HTML(string=full_html).write_pdf(output_path)

    print(f"✅ PDF generado exitosamente: {output_path}")
    return str(output_path)


def main():
    """Función principal del script."""
    parser = argparse.ArgumentParser(
        description='Convierte archivos Markdown a PDF con estilos profesionales.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  strx_md2pdf README.md
  strx_md2pdf docs/manual.md output/manual.pdf
        """
    )

    parser.add_argument(
        'input',
        help='Archivo Markdown de entrada (.md)'
    )

    parser.add_argument(
        'output',
        nargs='?',
        default=None,
        help='Archivo PDF de salida (opcional, por defecto usa el mismo nombre con .pdf)'
    )

    parser.add_argument(
        '-v', '--version',
        action='version',
        version='strx_md2pdf 1.0.0'
    )

    args = parser.parse_args()

    try:
        convert_md_to_pdf(args.input, args.output)
        return 0
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
