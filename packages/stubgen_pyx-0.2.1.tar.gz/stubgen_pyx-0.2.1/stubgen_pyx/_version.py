import importlib.metadata

__version__: str = importlib.metadata.version(__package__)  # type: ignore
