## Summary

<!-- Brief description of what this PR does -->

## Type of Change

<!-- Check the relevant box -->

- [ ] Bug fix (patch: 0.0.x)
- [ ] New feature (minor: 0.x.0)
- [ ] Breaking change (major: x.0.0)
- [ ] Documentation update
- [ ] Chore/maintenance
- [ ] Refactor
- [ ] Performance improvement

## Changes

<!-- List the key changes made in this PR -->

-
-
-

## Related Issues

<!-- Link to related issues using #issue-number -->

Closes #
Relates to #

## Testing

<!-- Describe how this was tested -->

- [ ] All existing tests pass
- [ ] Added new tests for changes
- [ ] Tested on Windows
- [ ] Tested on macOS
- [ ] Tested on Linux

**Test commands:**
```bash
# Commands used to test
```

## Checklist

<!-- Ensure all items are completed before requesting review -->

- [ ] Branch follows naming convention (`feature/`, `fix/`, etc.)
- [ ] Commits follow [Conventional Commits](https://www.conventionalcommits.org/) format
- [ ] Tests pass locally (`make test`)
- [ ] Code passes lint checks (`ruff check`)
- [ ] Code is formatted (`ruff format`)
- [ ] Type checks pass (`mypy src/`)
- [ ] CHANGELOG.md updated (if user-facing change)
- [ ] Documentation updated (if API/behavior change)
- [ ] No hardcoded paths or platform-specific assumptions
- [ ] Error messages are clear and actionable

## Breaking Changes

<!-- If this is a breaking change, describe the migration path -->

**Before:**
```python
# Old API
```

**After:**
```python
# New API
```

**Migration:**
- Step 1: ...
- Step 2: ...

## Screenshots/Output

<!-- If applicable, add screenshots or command output -->

```
# Command output or logs
```

## Additional Context

<!-- Any other context, concerns, or notes for reviewers -->

---

**Reviewer Notes:**
- [ ] Code review completed
- [ ] Tested locally
- [ ] Documentation reviewed
- [ ] CHANGELOG entry appropriate
