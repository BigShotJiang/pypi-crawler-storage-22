# Basic Usage Examples

This directory contains working examples of CALF files demonstrating basic Cleave usage.

## Simple Directive

**File**: `simple-directive.calf`

A straightforward task that likely won't require splitting. This demonstrates:
- Clear, focused objective
- Single system (web UI + backend)
- Minimal modifiers (basic file upload)
- Expected complexity: ~2.0 (below typical threshold)

**Expected Assessment**:
```
Systems: 2 (UI, API)
Modifiers: 0 (straightforward CRUD)
Complexity: 2.0
Decision: Execute directly (no cleaving needed)
```

**Usage**:
```bash
# Assess the directive
cleave assess --directive "$(cat simple-directive.calf)"

# If cleave is invoked anyway, it will execute directly
/cleave
$(cat simple-directive.calf)
```

## Complex Directive

**File**: `complex-directive.calf`

A multi-system task that will trigger cleaving. This demonstrates:
- Multiple systems (UI, API, DB, WebSocket infrastructure)
- Multiple modifiers (state coordination, migration, backwards compatibility)
- Expected complexity: ~7.0+ (above threshold)

**Expected Assessment**:
```
Systems: 4 (UI, API, DB, WebSocket)
Modifiers: 3 (state coordination, migration, backwards compatibility)
Complexity: 7.5
Decision: Cleave into 2-3 children
```

**Likely Splitting Strategy**:
```
Parent: Real-time notification system
├── Child 0: WebSocket infrastructure + backend handlers
├── Child 1: UI integration + browser notifications
└── Child 2: Database migration + preferences management
```

**Usage**:
```bash
# Assess the directive
cleave assess --directive "$(cat complex-directive.calf)"

# Match against patterns
cleave match --directive "$(cat complex-directive.calf)"

# Invoke via Claude Code skill
/cleave
$(cat complex-directive.calf)
```

## Key Takeaways

1. **Simple tasks**: Cleave recognizes atomic tasks and executes directly
2. **Complex tasks**: Multiple systems + modifiers trigger decomposition
3. **Natural boundaries**: Split along architectural seams (infrastructure, UI, data)
4. **Assessment first**: Always assess before committing to decomposition strategy
