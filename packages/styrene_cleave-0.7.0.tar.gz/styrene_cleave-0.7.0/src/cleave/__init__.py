"""Cleave - Task decomposition library for complex directive management.

This library provides the core algorithms for the Cleave skill:
- Complexity assessment and pattern matching
- Workspace generation and task file management
- Conflict detection during reunification
- Permission inference for fire-and-forget execution

Usage:
    from cleave import assess_directive, init_workspace, reunify_workspace
    from cleave.core.assessment import match_pattern, calculate_complexity
    from cleave.core.conflicts import detect_conflicts
"""

from cleave.core.assessment import (
    AssessmentResult,
    PatternMatch,
    assess_directive,
    calculate_complexity,
    detect_modifiers,
    effective_complexity,
    match_pattern,
)
from cleave.core.conflicts import Conflict, detect_conflicts
from cleave.core.permissions import (
    check_missing_permissions,
    format_settings_snippet,
    infer_permissions,
    load_current_permissions,
)
from cleave.core.reunify import (
    aggregate_results,
    generate_merge_md,
    generate_review_md,
    parse_task_result,
    reunify_workspace,
)
from cleave.core.workspace import (
    generate_manifest,
    generate_siblings_yaml,
    generate_task_file,
    init_workspace,
    reconstruct_context,
)
from cleave.core.settings import (
    BackendSettings,
    CleaveSettings,
    detect_available_backends,
    generate_cloven_filename,
    get_active_backend,
    get_backend_setting,
    get_setting,
    load_settings,
    save_settings,
    set_active_backend,
    set_backend_setting,
    set_setting,
)

__version__ = "0.7.0"

__all__ = [
    # Assessment
    "AssessmentResult",
    "PatternMatch",
    "assess_directive",
    "calculate_complexity",
    "detect_modifiers",
    "effective_complexity",
    "match_pattern",
    # Conflicts
    "Conflict",
    "detect_conflicts",
    # Permissions
    "check_missing_permissions",
    "format_settings_snippet",
    "infer_permissions",
    "load_current_permissions",
    # Reunify
    "aggregate_results",
    "generate_merge_md",
    "generate_review_md",
    "parse_task_result",
    "reunify_workspace",
    # Workspace
    "generate_manifest",
    "generate_siblings_yaml",
    "generate_task_file",
    "init_workspace",
    "reconstruct_context",
    # Settings
    "BackendSettings",
    "CleaveSettings",
    "detect_available_backends",
    "generate_cloven_filename",
    "get_active_backend",
    "get_backend_setting",
    "get_setting",
    "load_settings",
    "save_settings",
    "set_active_backend",
    "set_backend_setting",
    "set_setting",
]
