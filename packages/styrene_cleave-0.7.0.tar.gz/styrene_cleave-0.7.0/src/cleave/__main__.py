"""Entry point for running cleave as a module.

Allows execution via:
    python -m cleave [args]
"""

from cleave.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
