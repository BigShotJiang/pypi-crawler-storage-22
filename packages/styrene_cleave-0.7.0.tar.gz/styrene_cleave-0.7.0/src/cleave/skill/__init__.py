"""Cleave skill loader for Claude Code skill discovery.

This module provides the skill instructions (SKILL.md) for Claude Code
to discover and use when the /cleave command is invoked.
"""

from pathlib import Path

SKILL_PATH = Path(__file__).parent / "SKILL.md"


def get_skill_instructions() -> str:
    """Load and return the SKILL.md content."""
    return SKILL_PATH.read_text()


def check_mcp_dependency() -> dict[str, bool | str | None]:
    """Check if required MCP servers are available.

    The Sequential Thinking MCP server is required for complex task assessments.
    This function provides guidance for Claude to verify and install the dependency.

    Returns:
        dict with:
        - available: None (must be checked at runtime by Claude)
        - required: bool indicating this is a required dependency
        - message: Human-readable status message
        - check_command: MCP tool name to verify availability
        - install_instructions: Step-by-step installation guide

    Note:
        This function cannot directly check MCP availability because MCP tools
        are only accessible to Claude at runtime, not to Python code. The caller
        (Claude) must invoke check_command to verify availability before proceeding.
    """
    return {
        "available": None,  # Must be verified at runtime by Claude
        "required": True,
        "message": (
            "Sequential Thinking MCP server is REQUIRED for complex assessments. "
            "Without it, cleave cannot perform thorough task decomposition analysis. "
            "Please verify availability before invoking /cleave on complex tasks."
        ),
        "check_command": "mcp__MCP_DOCKER__sequentialthinking",
        "fallback_behavior": (
            "If MCP is unavailable, cleave will fall back to fast-path pattern matching only, "
            "which may produce less accurate assessments for novel or complex directives."
        ),
        "install_instructions": """
# Step 1: Verify Sequential Thinking MCP is available
Try calling: mcp__MCP_DOCKER__sequentialthinking

# Step 2: If not available, search for it
mcp__MCP_DOCKER__mcp-find query="sequential thinking"

# Step 3: Install and activate
mcp__MCP_DOCKER__mcp-add name="sequentialthinking" activate=true

# Step 4: Verify installation succeeded
mcp__MCP_DOCKER__sequentialthinking with a test thought
""",
    }
