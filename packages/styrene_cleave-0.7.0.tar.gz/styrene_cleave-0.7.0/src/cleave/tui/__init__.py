"""Cleave TUI - Interactive terminal interface for task decomposition.

Requires optional dependencies: pip install styrene-cleave[tui]

The backends subpackage can be imported without textual installed.
The main TUI components require textual.
"""

# Lazy imports for components that require textual
def __getattr__(name: str):
    """Lazy import TUI components that require textual."""
    if name == "CleaveTUI":
        from cleave.tui.app import CleaveTUI
        return CleaveTUI
    elif name == "main":
        from cleave.tui.app import main
        return main
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = ["CleaveTUI", "main"]
