"""Progress panel widget for execution status display."""

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.reactive import reactive
from textual.widgets import ProgressBar, Static


class ProgressPanel(Vertical):
    """Shows execution progress with bar and current task label.

    Hidden when idle - only shows during active operations.

    Interface for sibling integration:
        set_progress(current: int, total: int, label: str) - Update progress display
        hide() - Hide the progress panel
        show() - Show the progress panel
    """

    DEFAULT_CSS = """
    ProgressPanel {
        height: auto;
        padding: 0 1;
    }

    ProgressPanel ProgressBar {
        margin-bottom: 1;
    }

    ProgressPanel .progress-label {
        color: $text-muted;
        text-style: italic;
    }
    """

    current: reactive[int] = reactive(0)
    total: reactive[int] = reactive(0)
    label: reactive[str] = reactive("")
    _active: reactive[bool] = reactive(False)

    def compose(self) -> ComposeResult:
        """Compose the progress bar and label."""
        yield ProgressBar(id="progress-bar", show_eta=False)
        yield Static(self.label, id="progress-label", classes="progress-label")

    def on_mount(self) -> None:
        """Hide by default on mount."""
        self._update_visibility()

    def watch__active(self, value: bool) -> None:
        """Update visibility when active state changes."""
        self._update_visibility()

    def _update_visibility(self) -> None:
        """Show/hide based on active state."""
        self.display = self._active

    def watch_current(self, value: int) -> None:
        """Update progress bar when current changes."""
        if self.is_mounted:
            self._update_progress()

    def watch_total(self, value: int) -> None:
        """Update progress bar when total changes."""
        if self.is_mounted:
            self._update_progress()

    def watch_label(self, value: str) -> None:
        """Update label text when label changes."""
        if self.is_mounted:
            label_widget = self.query_one("#progress-label", Static)
            label_widget.update(value)

    def _update_progress(self) -> None:
        """Update the progress bar display."""
        bar = self.query_one("#progress-bar", ProgressBar)
        if self.total > 0:
            bar.update(total=self.total, progress=self.current)
        else:
            bar.update(total=100, progress=0)

    def set_progress(self, current: int, total: int, label: str) -> None:
        """Update progress display and show the panel.

        Args:
            current: Current step number
            total: Total number of steps
            label: Description of current task
        """
        self._active = True
        self.current = current
        self.total = total
        self.label = f"{label} ({current}/{total})" if total > 0 else label

    def hide(self) -> None:
        """Hide the progress panel."""
        self._active = False

    def show(self) -> None:
        """Show the progress panel."""
        self._active = True
