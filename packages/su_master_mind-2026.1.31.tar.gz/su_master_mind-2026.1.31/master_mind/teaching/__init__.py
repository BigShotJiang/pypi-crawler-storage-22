"""Teaching utilities for master-mind practicals."""
