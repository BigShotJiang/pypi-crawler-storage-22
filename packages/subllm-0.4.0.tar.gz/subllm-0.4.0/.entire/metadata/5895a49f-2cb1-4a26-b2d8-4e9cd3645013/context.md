# Session Context

**Session ID:** 5895a49f-2cb1-4a26-b2d8-4e9cd3645013

**Commit Message:** Great. Update the README.md file.

## Prompt

Great. Update the README.md file.

## Summary

Updated two sections:

1. **Install block** — removed `subllm[sdk]` line, updated core comment to reflect SDK is included by default.
2. **Architecture diagram** — replaced the dual-path `claude --print (subprocess) or claude-agent-sdk (async)` with single `claude-agent-sdk (persistent client)`.

## Key Actions

- - **Read**: /Users/druk/WorkSpace/AetherForge/SubLLM/README.md
- - **Edit**: /Users/druk/WorkSpace/AetherForge/SubLLM/README.md
- - **Edit**: /Users/druk/WorkSpace/AetherForge/SubLLM/README.md
