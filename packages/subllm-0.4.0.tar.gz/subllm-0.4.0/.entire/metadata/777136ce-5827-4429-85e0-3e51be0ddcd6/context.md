# Session Context

**Session ID:** 777136ce-5827-4429-85e0-3e51be0ddcd6

**Commit Message:** I ran the benchmarking script manually. Here are the results:

$ uv run

## Prompt

I ran the benchmarking script manually. Here are the results:

$ uv run --extra sdk python benchmarks/sdk_vs_cli.py

```
SubLLM SDK vs CLI Benchmark
Model: sonnet-4-5 | Iterations: 3

1. Cold start latency
  cold start iteration 1/3
  cold start iteration 2/3
  cold start iteration 3/3

2. Warm call latency
  warming SDK client...
  warm call iteration 1/3
  warm call iteration 2/3
  warm call iteration 3/3

3. Streaming TTFB
  warming SDK client...
  stream TTFB iteration 1/3
  stream TTFB iteration 2/3
  stream TTFB iteration 3/3

4. Batch throughput
  CLI batch (5 parallel)...
  SDK batch (5 sequential through persistent client)...

5. Multi-turn overhead
  CLI multi-turn...
  SDK multi-turn...

                         SDK vs CLI Benchmark Results                          
┏━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━┳━━━━━━━━┳━━━━━━━━┳━━━━━━━━┳━━━━━━━┳━━━┳━━━━━━━━┓
┃ Benchmark            ┃ Path ┃   Mean ┃    p50 ┃    p95 ┃ Stdev ┃ N ┃  Delta ┃
┡━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━╇━━━━━━━━╇━━━━━━━━╇━━━━━━━━╇━━━━━━━╇━━━╇━━━━━━━━┩
│ Cold start           │ CLI  │ 13.90s │ 13.94s │ 14.79s │ 904ms │ 3 │        │
│                      │ SDK  │  4.61s │  4.53s │  4.78s │ 147ms │ 3 │ -66.8% │
├──────────────────────┼──────┼────────┼────────┼────────┼───────┼───┼────────┤
│ Warm call            │ CLI  │ 13.22s │ 12.64s │ 14.71s │ 1.30s │ 3 │        │
│                      │ SDK  │  3.22s │  3.24s │  3.29s │  77ms │ 3 │ -75.6% │
├──────────────────────┼──────┼────────┼────────┼────────┼───────┼───┼────────┤
│ Stream TTFB          │ CLI  │  9.14s │  8.68s │ 10.24s │ 956ms │ 3 │        │
│                      │ SDK  │  5.23s │  5.30s │  5.82s │ 630ms │ 3 │ -42.8% │
├──────────────────────┼──────┼────────┼────────┼────────┼───────┼───┼────────┤
│ Batch (5 parallel)   │ CLI  │ 16.92s │ 16.92s │ 16.92s │   0ms │ 1 │        │
│                      │ SDK  │ 18.96s │ 18.96s │ 18.96s │   0ms │ 1 │ +12.1% │
├──────────────────────┼──────┼────────┼────────┼────────┼───────┼───┼────────┤
│ Multi-turn (3 turns) │ CLI  │ 47.11s │ 47.11s │ 47.11s │   0ms │ 1 │        │
│                      │ SDK  │ 16.71s │ 16.71s │ 16.71s │   0ms │ 1 │ -64.5% │
└──────────────────────┴──────┴────────┴────────┴────────┴───────┴───┴────────┘
```

## Summary

Results recorded at `benchmarks/RESULTS.md`. 

Summary: The SDK path delivers **75.6% faster warm calls**, **66.8% faster cold starts**, and **64.5% faster multi-turn** with dramatically lower variance. The only regression is batch (+12.1%) due to single-client serialization — addressable with client pooling in a follow-up. Per the plan's decision criteria (>20% warm call improvement → make SDK default), the data supports promoting the SDK path.

## Key Actions

- - **Write**: /Users/druk/WorkSpace/AetherForge/SubLLM/benchmarks/RESULTS.md
