from importlib.metadata import version

substrait_version = version("substrait-protobuf")
