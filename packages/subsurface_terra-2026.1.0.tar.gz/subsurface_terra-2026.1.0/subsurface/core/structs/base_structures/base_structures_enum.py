import enum


class SpecialCellCase(enum.Enum):
    POINTS = "points"
    LINES = "lines"
