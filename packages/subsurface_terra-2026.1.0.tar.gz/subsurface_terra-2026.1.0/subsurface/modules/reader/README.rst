Input/Output parsers
====================

This submodule should be the gateway between the **python subsurface stack** and
the rest of the software used on common work flows.

