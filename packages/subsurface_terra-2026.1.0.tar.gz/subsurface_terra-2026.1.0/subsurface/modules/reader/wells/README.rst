- [ ] @(miguel April 24) Pandas v2 is also breaking multiple thinks. We deprecate everything until someone has
 time to look into well importing.

- [ ] (@miguel April 24) We are moving towards removing welly, stiplog dependencies since 
 they are not very actively maintained (incompatible with latest versions of numpy and pandas) and
 since we are using just a tiny fraction of their functionality. 