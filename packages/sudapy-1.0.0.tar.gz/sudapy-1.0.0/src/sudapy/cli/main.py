"""SudaPy command-line interface.

Built with Typer for clean help text and autocompletion support.
"""

from __future__ import annotations

import platform
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

import sudapy

console = Console()

# ---------------------------------------------------------------------------
# Root app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="sudapy",
    help="SudaPy: Sudan-focused Python toolkit for Geomatics.",
    add_completion=False,
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# ---------------------------------------------------------------------------
# Sub-command groups
# ---------------------------------------------------------------------------

crs_app = typer.Typer(help="Coordinate Reference System utilities.")
vector_app = typer.Typer(help="Vector geoprocessing operations.")
raster_app = typer.Typer(help="Raster geoprocessing operations.")
map_app = typer.Typer(help="Quick map visualization.")

app.add_typer(crs_app, name="crs")
app.add_typer(vector_app, name="vector")
app.add_typer(raster_app, name="raster")
app.add_typer(map_app, name="map")


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _handle_error(exc: Exception) -> None:
    """Print a rich-formatted error and exit."""
    console.print(f"[bold red]Error:[/bold red] {exc}")
    raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# sudapy info
# ---------------------------------------------------------------------------

@app.command()
def info() -> None:
    """Show SudaPy version, environment, and key dependency info."""
    table = Table(title="SudaPy Environment", show_lines=True)
    table.add_column("Component", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("SudaPy version", sudapy.__version__)
    table.add_row("Python", sys.version.split()[0])
    table.add_row("Platform", platform.platform())

    # Check key geospatial deps
    for mod_name in ("geopandas", "shapely", "fiona", "pyproj", "rasterio", "numpy", "pandas"):
        try:
            mod = __import__(mod_name)
            ver = getattr(mod, "__version__", "installed")
        except ImportError:
            ver = "[red]not installed[/red]"
        table.add_row(mod_name, ver)

    # GDAL info via rasterio
    try:
        import rasterio
        table.add_row("GDAL (via rasterio)", rasterio.gdal_version())
    except Exception:
        table.add_row("GDAL", "[red]unavailable[/red]")

    console.print(table)


# ---------------------------------------------------------------------------
# sudapy crs list
# ---------------------------------------------------------------------------

@crs_app.command("list")
def crs_list() -> None:
    """Show common CRS presets used in Sudan."""
    from sudapy.crs.registry import list_presets

    table = Table(title="Sudan CRS Presets")
    table.add_column("EPSG", style="cyan", justify="right")
    table.add_column("Name", style="green")
    table.add_column("Region", style="yellow")
    table.add_column("Description")

    for p in list_presets():
        table.add_row(str(p.epsg), p.name, p.region, p.description)

    console.print(table)


# ---------------------------------------------------------------------------
# sudapy crs suggest
# ---------------------------------------------------------------------------

@crs_app.command("suggest")
def crs_suggest(
    lon: float = typer.Option(..., "--lon", help="Longitude in decimal degrees."),
    lat: float = typer.Option(..., "--lat", help="Latitude in decimal degrees."),
) -> None:
    """Suggest the most likely UTM zone / EPSG for a coordinate."""
    from sudapy.crs.registry import suggest_utm_zone

    try:
        suggestions = suggest_utm_zone(lon, lat)
    except ValueError as exc:
        _handle_error(exc)
        return

    table = Table(title=f"CRS Suggestions for ({lon}, {lat})")
    table.add_column("EPSG", style="cyan", justify="right")
    table.add_column("Name", style="green")
    table.add_column("Datum")

    for s in suggestions:
        table.add_row(str(s["epsg"]), s["name"], s["datum"])

    console.print(table)


# ---------------------------------------------------------------------------
# sudapy vector reproject
# ---------------------------------------------------------------------------

@vector_app.command("reproject")
def vector_reproject(
    input_path: Path = typer.Option(..., "--in", help="Input vector file."),
    output_path: Path = typer.Option(..., "--out", help="Output vector file."),
    to: int = typer.Option(..., "--to", help="Target EPSG code."),
) -> None:
    """Reproject a vector dataset to a new CRS."""
    from sudapy.vector.ops import reproject

    try:
        reproject(input_path, to_epsg=to, out=output_path)
        console.print(f"[green]Reprojected to EPSG:{to} -> {output_path}[/green]")
    except Exception as exc:
        _handle_error(exc)


# ---------------------------------------------------------------------------
# sudapy vector clip
# ---------------------------------------------------------------------------

@vector_app.command("clip")
def vector_clip(
    input_path: Path = typer.Option(..., "--in", help="Input vector file."),
    clip_path: Path = typer.Option(..., "--clip", help="Clipping geometry file."),
    output_path: Path = typer.Option(..., "--out", help="Output vector file."),
) -> None:
    """Clip a vector dataset by another geometry."""
    from sudapy.vector.ops import clip

    try:
        clip(input_path, clip_path, out=output_path)
        console.print(f"[green]Clipped -> {output_path}[/green]")
    except Exception as exc:
        _handle_error(exc)


# ---------------------------------------------------------------------------
# sudapy vector dissolve
# ---------------------------------------------------------------------------

@vector_app.command("dissolve")
def vector_dissolve(
    input_path: Path = typer.Option(..., "--in", help="Input vector file."),
    by: str = typer.Option(..., "--by", help="Field name to dissolve on."),
    output_path: Path = typer.Option(..., "--out", help="Output vector file."),
) -> None:
    """Dissolve geometries by an attribute field."""
    from sudapy.vector.ops import dissolve

    try:
        dissolve(input_path, by=by, out=output_path)
        console.print(f"[green]Dissolved by '{by}' -> {output_path}[/green]")
    except Exception as exc:
        _handle_error(exc)


# ---------------------------------------------------------------------------
# sudapy vector area
# ---------------------------------------------------------------------------

@vector_app.command("area")
def vector_area(
    input_path: Path = typer.Option(..., "--in", help="Input vector file."),
    field: str = typer.Option("area_m2", "--field", help="Name for the new area column."),
    output_path: Path = typer.Option(..., "--out", help="Output vector file."),
) -> None:
    """Calculate geometry area in square meters."""
    from sudapy.vector.ops import calculate_area

    try:
        calculate_area(input_path, field=field, out=output_path)
        console.print(f"[green]Area calculated (column '{field}') -> {output_path}[/green]")
    except Exception as exc:
        _handle_error(exc)


# ---------------------------------------------------------------------------
# sudapy raster clip
# ---------------------------------------------------------------------------

@raster_app.command("clip")
def raster_clip(
    input_path: Path = typer.Option(..., "--in", help="Input raster file."),
    clip_path: Path = typer.Option(..., "--clip", help="Clipping vector file."),
    output_path: Path = typer.Option(..., "--out", help="Output raster file."),
) -> None:
    """Clip a raster by vector geometries."""
    from sudapy.raster.ops import clip

    try:
        clip(input_path, clip_path, out=output_path)
        console.print(f"[green]Raster clipped -> {output_path}[/green]")
    except Exception as exc:
        _handle_error(exc)


# ---------------------------------------------------------------------------
# sudapy raster reproject
# ---------------------------------------------------------------------------

@raster_app.command("reproject")
def raster_reproject(
    input_path: Path = typer.Option(..., "--in", help="Input raster file."),
    output_path: Path = typer.Option(..., "--out", help="Output raster file."),
    to: int = typer.Option(..., "--to", help="Target EPSG code."),
) -> None:
    """Reproject a raster to a new CRS."""
    from sudapy.raster.ops import reproject_raster

    try:
        reproject_raster(input_path, output_path, to_epsg=to)
        console.print(f"[green]Raster reprojected to EPSG:{to} -> {output_path}[/green]")
    except Exception as exc:
        _handle_error(exc)


# ---------------------------------------------------------------------------
# sudapy map quick
# ---------------------------------------------------------------------------

@map_app.command("quick")
def map_quick(
    input_path: Path = typer.Option(..., "--in", help="Input vector or raster file."),
    output_path: Path = typer.Option(..., "--out", help="Output .png or .html file."),
) -> None:
    """Generate a quick visualization of a dataset."""
    from sudapy.viz.maps import quick_map

    try:
        quick_map(input_path, output_path)
        console.print(f"[green]Map exported -> {output_path}[/green]")
    except Exception as exc:
        _handle_error(exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()
