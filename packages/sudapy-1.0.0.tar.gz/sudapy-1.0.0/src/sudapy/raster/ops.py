"""Raster geoprocessing operations.

Functions wrap :mod:`rasterio` to provide high-level raster clip and
reproject capabilities.
"""

from __future__ import annotations

from pathlib import Path
from typing import Union

import geopandas as gpd
import numpy as np
import rasterio
import rasterio.mask
from rasterio.warp import Resampling, calculate_default_transform, reproject

from sudapy.core.errors import FileFormatError, SudaPyError
from sudapy.core.logging import get_logger
from sudapy.crs.registry import validate_epsg
from sudapy.vector.ops import _read as read_vector

logger = get_logger(__name__)

PathLike = Union[str, Path]


def clip(
    src: PathLike,
    clip_vector: PathLike,
    out: PathLike,
    *,
    crop: bool = True,
    nodata: float | None = None,
) -> Path:
    """Clip a raster by vector geometries.

    Args:
        src: Input raster path.
        clip_vector: Vector file whose geometries define the clip extent.
        out: Output raster path.
        crop: Whether to crop the raster extent to the vector bounds.
        nodata: NoData value for masked pixels. Defaults to the source nodata.

    Returns:
        Path to the output raster.
    """
    src = Path(src)
    out = Path(out)
    if not src.exists():
        raise FileFormatError(f"Raster not found: {src}")

    mask_gdf = read_vector(clip_vector)

    with rasterio.open(src) as ds:
        # Reproject mask to raster CRS if needed
        if mask_gdf.crs and mask_gdf.crs != ds.crs:
            logger.info("Reprojecting clip vector to raster CRS (%s)", ds.crs)
            mask_gdf = mask_gdf.to_crs(ds.crs)

        geometries = mask_gdf.geometry.values
        nd = nodata if nodata is not None else ds.nodata

        out_image, out_transform = rasterio.mask.mask(
            ds,
            geometries,
            crop=crop,
            nodata=nd,
        )
        out_meta = ds.meta.copy()
        out_meta.update(
            {
                "driver": "GTiff",
                "height": out_image.shape[1],
                "width": out_image.shape[2],
                "transform": out_transform,
                "nodata": nd,
            }
        )

    out.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(out, "w", **out_meta) as dst:
        dst.write(out_image)

    logger.info("Clipped raster written to %s", out)
    return out


def reproject_raster(
    src: PathLike,
    out: PathLike,
    to_epsg: int,
    *,
    resampling: Resampling = Resampling.nearest,
) -> Path:
    """Reproject a raster to a new CRS.

    Args:
        src: Input raster path.
        out: Output raster path.
        to_epsg: Target EPSG code.
        resampling: Resampling method.

    Returns:
        Path to the output raster.
    """
    src = Path(src)
    out = Path(out)
    if not src.exists():
        raise FileFormatError(f"Raster not found: {src}")

    dst_crs = validate_epsg(to_epsg)

    with rasterio.open(src) as ds:
        transform, width, height = calculate_default_transform(
            ds.crs, dst_crs, ds.width, ds.height, *ds.bounds
        )
        kwargs = ds.meta.copy()
        kwargs.update(
            {
                "crs": dst_crs,
                "transform": transform,
                "width": width,
                "height": height,
                "driver": "GTiff",
            }
        )

        out.parent.mkdir(parents=True, exist_ok=True)
        with rasterio.open(out, "w", **kwargs) as dst:
            for i in range(1, ds.count + 1):
                reproject(
                    source=rasterio.band(ds, i),
                    destination=rasterio.band(dst, i),
                    src_transform=ds.transform,
                    src_crs=ds.crs,
                    dst_transform=transform,
                    dst_crs=dst_crs,
                    resampling=resampling,
                )

    logger.info("Reprojected raster written to %s", out)
    return out
