"""Vector geoprocessing operations.

All functions accept and return :class:`geopandas.GeoDataFrame` objects and
support GeoPackage, GeoJSON, and Shapefile formats on disk.
"""

from __future__ import annotations

import warnings
from pathlib import Path
from typing import Union

import geopandas as gpd
from pyproj import CRS

from sudapy.core.errors import CRSError, FileFormatError, SudaPyError
from sudapy.core.logging import get_logger
from sudapy.crs.registry import validate_epsg

logger = get_logger(__name__)

PathLike = Union[str, Path]

# Supported write drivers keyed by suffix.
_DRIVERS: dict[str, str] = {
    ".gpkg": "GPKG",
    ".geojson": "GeoJSON",
    ".json": "GeoJSON",
    ".shp": "ESRI Shapefile",
}


def _read(path: PathLike) -> gpd.GeoDataFrame:
    path = Path(path)
    if not path.exists():
        raise FileFormatError(f"File not found: {path}")
    try:
        return gpd.read_file(path)
    except Exception as exc:
        raise FileFormatError(
            f"Cannot read vector file: {path}",
            hint="Supported formats: GeoPackage (.gpkg), GeoJSON, Shapefile (.shp).",
        ) from exc


def _write(gdf: gpd.GeoDataFrame, path: PathLike) -> Path:
    path = Path(path)
    suffix = path.suffix.lower()
    driver = _DRIVERS.get(suffix)
    if driver is None:
        raise FileFormatError(
            f"Unsupported output format '{suffix}'",
            hint=f"Use one of: {', '.join(_DRIVERS.keys())}",
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(path, driver=driver)
    logger.info("Wrote %d features to %s", len(gdf), path)
    return path


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def reproject(
    src: PathLike | gpd.GeoDataFrame,
    to_epsg: int,
    out: PathLike | None = None,
) -> gpd.GeoDataFrame:
    """Reproject a vector dataset to a new CRS.

    Args:
        src: Input file path or GeoDataFrame.
        to_epsg: Target EPSG code.
        out: Optional output file path. If given the result is also saved.

    Returns:
        Reprojected GeoDataFrame.
    """
    gdf = _read(src) if not isinstance(src, gpd.GeoDataFrame) else src
    target_crs = validate_epsg(to_epsg)
    result = gdf.to_crs(target_crs)
    if out is not None:
        _write(result, out)
    return result


def clip(
    src: PathLike | gpd.GeoDataFrame,
    clip_src: PathLike | gpd.GeoDataFrame,
    out: PathLike | None = None,
) -> gpd.GeoDataFrame:
    """Clip a vector dataset by another vector geometry.

    Args:
        src: Input file or GeoDataFrame.
        clip_src: Clipping geometry file or GeoDataFrame.
        out: Optional output path.

    Returns:
        Clipped GeoDataFrame.
    """
    gdf = _read(src) if not isinstance(src, gpd.GeoDataFrame) else src
    mask = _read(clip_src) if not isinstance(clip_src, gpd.GeoDataFrame) else clip_src

    # Ensure same CRS
    if gdf.crs and mask.crs and gdf.crs != mask.crs:
        logger.info("Reprojecting clip geometry to match input CRS (%s)", gdf.crs)
        mask = mask.to_crs(gdf.crs)

    result = gpd.clip(gdf, mask)
    if out is not None:
        _write(result, out)
    return result


def dissolve(
    src: PathLike | gpd.GeoDataFrame,
    by: str,
    out: PathLike | None = None,
) -> gpd.GeoDataFrame:
    """Dissolve geometries by an attribute field.

    Args:
        src: Input file or GeoDataFrame.
        by: Column name to dissolve on.
        out: Optional output path.

    Returns:
        Dissolved GeoDataFrame.
    """
    gdf = _read(src) if not isinstance(src, gpd.GeoDataFrame) else src
    if by not in gdf.columns:
        raise SudaPyError(
            f"Column '{by}' not found in dataset.",
            hint=f"Available columns: {', '.join(gdf.columns.tolist())}",
        )
    result = gdf.dissolve(by=by).reset_index()
    if out is not None:
        _write(result, out)
    return result


def calculate_area(
    src: PathLike | gpd.GeoDataFrame,
    field: str = "area_m2",
    out: PathLike | None = None,
) -> gpd.GeoDataFrame:
    """Calculate geometry area in square meters.

    If the CRS is geographic (lat/lon) a warning is emitted and geometries
    are temporarily projected to the appropriate UTM zone for accurate
    area calculation.

    Args:
        src: Input file or GeoDataFrame.
        field: Name of the new area column.
        out: Optional output path.

    Returns:
        GeoDataFrame with a new area column.
    """
    gdf = _read(src) if not isinstance(src, gpd.GeoDataFrame) else src.copy()

    if gdf.crs is None:
        raise CRSError(
            "Input dataset has no CRS.",
            hint="Set a CRS first, e.g. 'sudapy vector reproject --in file --out file --to 32635'.",
        )

    if gdf.crs.is_geographic:
        warnings.warn(
            "Input CRS is geographic (lat/lon). Area will be computed by "
            "temporarily projecting to the estimated UTM zone. For best "
            "accuracy, reproject your data to a projected CRS first.",
            UserWarning,
            stacklevel=2,
        )
        projected = gdf.to_crs(gdf.estimate_utm_crs())
        gdf[field] = projected.geometry.area
    else:
        gdf[field] = gdf.geometry.area

    if out is not None:
        _write(gdf, out)
    return gdf
