"""Tests for vector operations."""

from __future__ import annotations

import warnings

import geopandas as gpd
import pytest
from shapely.geometry import box

from sudapy.vector.ops import calculate_area, reproject


def _make_gdf(epsg: int = 32635) -> gpd.GeoDataFrame:
    """Create a tiny GeoDataFrame with a 1km x 1km box near Khartoum."""
    # In UTM 35N meters, a box near Khartoum
    geom = box(500_000, 1_700_000, 501_000, 1_701_000)
    return gpd.GeoDataFrame({"name": ["test"]}, geometry=[geom], crs=f"EPSG:{epsg}")


class TestReproject:
    def test_reproject_changes_crs(self):
        gdf = _make_gdf(32635)
        result = reproject(gdf, to_epsg=4326)
        assert result.crs.to_epsg() == 4326

    def test_reproject_preserves_rows(self):
        gdf = _make_gdf(32635)
        result = reproject(gdf, to_epsg=32636)
        assert len(result) == len(gdf)


class TestCalculateArea:
    def test_area_projected_crs(self):
        gdf = _make_gdf(32635)
        result = calculate_area(gdf, field="area_m2")
        assert "area_m2" in result.columns
        # 1km x 1km = 1,000,000 m^2
        area = result["area_m2"].iloc[0]
        assert abs(area - 1_000_000) < 1.0  # within 1 m^2

    def test_area_geographic_crs_warns(self):
        gdf = _make_gdf(32635).to_crs(4326)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = calculate_area(gdf, field="area_m2")
            assert len(w) == 1
            assert "geographic" in str(w[0].message).lower()
        assert "area_m2" in result.columns
        # Should still give a reasonable area (within 10% of 1km^2)
        area = result["area_m2"].iloc[0]
        assert 900_000 < area < 1_100_000

    def test_area_no_crs_raises(self):
        from sudapy.core.errors import CRSError

        gdf = _make_gdf(32635)
        gdf.crs = None
        with pytest.raises(CRSError):
            calculate_area(gdf)
