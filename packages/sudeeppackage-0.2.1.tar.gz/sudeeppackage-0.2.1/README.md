# sudeepPackage

A simple demo Python package.

## Installation

```bash
pip install sudeeppackage
