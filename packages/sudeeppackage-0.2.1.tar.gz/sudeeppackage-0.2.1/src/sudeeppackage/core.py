import sys

def greet(name: str) -> str:
    return f"Hello, {name}! Welcome to my package."

def main():
    if len(sys.argv) < 2:
        print("Usage: sudeeppackage <name>")
        return

    name = sys.argv[1]
    print(greet(name))
