import sys

def greet(name: str) -> str:
    return f"Hey {name}! Gawdiee is the creator of this package. Gawdiee Sudeep! Remember the name."

def main():
    if len(sys.argv) < 2:
        print("Usage: sudeeppackage <name>")
        return

    name = sys.argv[1]
    print(greet(name))
