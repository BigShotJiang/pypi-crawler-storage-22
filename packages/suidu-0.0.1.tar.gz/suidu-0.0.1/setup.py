﻿from setuptools import setup
setup(
    name='suidu',
    version='0.0.1',
    description='Reserved by Xiaorui Lu (Lux/Rain).',
    author='Xiaorui Lu',
    author_email='rainrain2007@gmail.com',
    packages=[],
)
