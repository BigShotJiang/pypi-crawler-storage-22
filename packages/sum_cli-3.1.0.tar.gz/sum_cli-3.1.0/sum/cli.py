"""Command-line entrypoint wiring for the SUM platform CLI."""

from __future__ import annotations

import importlib.metadata

import click
from sum.commands.backup import backup
from sum.commands.check import check
from sum.commands.init import init
from sum.commands.promote import promote
from sum.commands.setup import setup
from sum.commands.themes import themes
from sum.commands.update import update


def _get_version() -> str:
    try:
        return importlib.metadata.version("sum-cli")
    except importlib.metadata.PackageNotFoundError:
        return "0.0.0"


@click.group()
@click.version_option(
    version=_get_version(), prog_name="sum-platform", message="%(prog)s %(version)s"
)
def cli() -> None:
    """SUM Platform CLI - Deploy and manage client sites."""


cli.add_command(backup)
cli.add_command(check)
cli.add_command(init)
cli.add_command(promote)
cli.add_command(setup)
cli.add_command(themes)
cli.add_command(update)


if __name__ == "__main__":
    cli()
