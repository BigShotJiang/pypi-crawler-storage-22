# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Backup command implementation.

Creates backups of site database and optionally media files.
"""

from __future__ import annotations

import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from types import ModuleType

from sum.exceptions import SetupError
from sum.system_config import ConfigurationError, SystemConfig, get_system_config
from sum.utils.output import OutputFormatter

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _generate_backup_filename(site_slug: str, suffix: str = "sql") -> str:
    """Generate a timestamped backup filename."""
    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    return f"{site_slug}_{timestamp}.{suffix}.gz"


def _backup_database(
    site_slug: str,
    backup_dir: Path,
    config: SystemConfig,
) -> Path:
    """Create a compressed database backup using pg_dump."""
    # Fail fast if backup directory is not writable
    if not os.access(backup_dir, os.W_OK):
        raise SetupError(f"Backup directory is not writable: {backup_dir}")

    db_name = config.get_db_name(site_slug)
    backup_filename = _generate_backup_filename(site_slug, "sql")
    backup_path = backup_dir / backup_filename

    try:
        # pg_dump | gzip > backup_file
        with open(backup_path, "wb") as f:
            pg_dump = subprocess.Popen(
                ["sudo", "-u", "postgres", "pg_dump", db_name],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            gzip = subprocess.Popen(
                ["gzip"],
                stdin=pg_dump.stdout,
                stdout=f,
                stderr=subprocess.PIPE,
            )
            if pg_dump.stdout:
                pg_dump.stdout.close()

            gzip.communicate()
            pg_dump.wait()

            if pg_dump.returncode != 0:
                stderr = pg_dump.stderr.read() if pg_dump.stderr else b""
                raise SetupError(f"pg_dump failed: {stderr.decode()}")

            if gzip.returncode != 0:
                raise SetupError("gzip compression failed")

    except OSError as exc:
        raise SetupError(f"Failed to create backup: {exc}") from exc

    return backup_path


def _backup_media(
    site_slug: str,
    site_dir: Path,
    backup_dir: Path,
) -> Path:
    """Create a compressed tarball of the media directory."""
    media_dir = site_dir / "media"
    backup_filename = _generate_backup_filename(site_slug, "media.tar")
    backup_path = backup_dir / backup_filename

    if not media_dir.exists():
        raise SetupError(f"Media directory not found: {media_dir}")

    try:
        # tar czf backup_file -C media_dir .
        with open(backup_path, "wb") as f:
            tar = subprocess.Popen(
                ["tar", "czf", "-", "-C", str(media_dir), "."],
                stdout=f,
                stderr=subprocess.PIPE,
            )
            _, stderr = tar.communicate()

            if tar.returncode != 0:
                raise SetupError(f"tar failed: {stderr.decode()}")

    except OSError as exc:
        raise SetupError(f"Failed to create media backup: {exc}") from exc

    return backup_path


def _run_remote_backup(
    site_slug: str,
    config: SystemConfig,
    include_media: bool = False,
) -> list[str]:
    """Run backup on a remote (production) server via SSH."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    backup_dir = site_dir / "backups"
    db_name = config.get_db_name(site_slug)
    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")

    backup_files: list[str] = []

    # Database backup command
    db_backup = f"{site_slug}_{timestamp}.sql.gz"
    db_cmd = f"sudo -u postgres pg_dump {db_name} | gzip > {backup_dir}/{db_backup}"

    OutputFormatter.info("Creating database backup...")
    try:
        subprocess.run(
            ["ssh", ssh_host, db_cmd],
            check=True,
            capture_output=True,
            text=True,
        )
        backup_files.append(f"{backup_dir}/{db_backup}")
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Remote database backup failed: {exc.stderr}") from exc

    # Media backup (optional)
    if include_media:
        media_backup = f"{site_slug}_{timestamp}.media.tar.gz"
        media_cmd = f"tar czf {backup_dir}/{media_backup} -C {site_dir}/media ."

        OutputFormatter.info("Creating media backup...")
        try:
            subprocess.run(
                ["ssh", ssh_host, media_cmd],
                check=True,
                capture_output=True,
                text=True,
            )
            backup_files.append(f"{backup_dir}/{media_backup}")
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Remote media backup failed: {exc.stderr}") from exc

    return backup_files


def run_backup(
    site_name: str,
    *,
    target: str = "staging",
    include_media: bool = False,
) -> int:
    """Create a backup of site database and optionally media.

    Args:
        site_name: Name/slug of the site to backup.
        target: 'staging' or 'prod'.
        include_media: Also backup the media directory.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    site_dir = config.get_site_dir(site_name, target=target)

    # For production, delegate to remote execution
    if target == "prod":
        OutputFormatter.header(f"Backing up {site_name} on production")
        print()
        try:
            backup_files = _run_remote_backup(site_name, config, include_media)
        except SetupError as exc:
            OutputFormatter.error(str(exc))
            return 1

        print()
        OutputFormatter.success("Backup completed:")
        for path in backup_files:
            print(f"  - {path}")
        return 0

    # For staging, run locally
    backup_dir = site_dir / "backups"

    # Validate site exists
    if not site_dir.exists():
        OutputFormatter.error(f"Site not found: {site_dir}")
        return 1

    # Ensure backup directory exists
    backup_dir.mkdir(parents=True, exist_ok=True)

    OutputFormatter.header(f"Backing up {site_name} on staging")
    print()

    backup_files: list[Path] = []

    try:
        # Database backup
        OutputFormatter.info("Creating database backup...")
        db_backup = _backup_database(site_name, backup_dir, config)
        backup_files.append(db_backup)
        OutputFormatter.success(f"Database backup: {db_backup.name}")

        # Media backup (optional)
        if include_media:
            OutputFormatter.info("Creating media backup...")
            media_backup = _backup_media(site_name, site_dir, backup_dir)
            backup_files.append(media_backup)
            OutputFormatter.success(f"Media backup: {media_backup.name}")

    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    print()
    OutputFormatter.success("Backup completed:")
    for path in backup_files:
        size_mb = path.stat().st_size / (1024 * 1024)
        print(f"  - {path} ({size_mb:.1f} MB)")

    return 0


def _backup_command(
    site_name: str,
    target: str,
    include_media: bool,
) -> None:
    """Create a backup of an existing site."""
    result = run_backup(
        site_name,
        target=target,
        include_media=include_media,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the backup command")


if click is None:
    backup = _missing_click
else:

    @click.command(name="backup")
    @click.argument("site_name")
    @click.option(
        "--target",
        type=click.Choice(["staging", "prod"], case_sensitive=False),
        default="staging",
        show_default=True,
        help="Target environment to backup.",
    )
    @click.option(
        "--include-media",
        is_flag=True,
        help="Also backup the media directory.",
    )
    def _click_backup(
        site_name: str,
        target: str,
        include_media: bool,
    ) -> None:
        """Create a backup of site database and media.

        Creates a compressed backup of the PostgreSQL database.
        Optionally includes the media directory.

        Backups are stored in /srv/sum/<site>/backups/

        \b
        Examples:
          sum-platform backup acme
          sum-platform backup acme --include-media
          sum-platform backup acme --target prod
        """
        _backup_command(
            site_name,
            target=target,
            include_media=include_media,
        )

    backup = _click_backup
