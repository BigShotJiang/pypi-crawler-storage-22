# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Init command implementation.

Creates a working site on staging at /srv/sum/<name>/ with:
- Postgres database
- External venv
- Systemd service
- Caddy configuration
- Git repository (optional, specify provider with --git-provider)
"""

from __future__ import annotations

from types import ModuleType

from sum.exceptions import SetupError
from sum.setup.infrastructure import check_infrastructure
from sum.setup.site_orchestrator import SiteOrchestrator, SiteSetupConfig
from sum.site_config import GitConfig
from sum.system_config import ConfigurationError, get_system_config
from sum.utils.output import OutputFormatter
from sum.utils.project import validate_project_name

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover - click is expected in the CLI runtime
    click_module = None

click: ModuleType | None = click_module


def run_init(
    site_name: str,
    *,
    theme: str = "theme_a",
    profile: str = "starter",
    content_path: str | None = None,
    no_git: bool = False,
    git_provider: str | None = None,
    git_org: str | None = None,
    gitea_url: str | None = None,
    gitea_ssh_port: int = 22,
    gitea_token_env: str = "GITEA_TOKEN",
    skip_systemd: bool = False,
    skip_caddy: bool = False,
    superuser_username: str = "admin",
) -> int:
    """Initialize a new site on staging.

    Creates a fully working site at /srv/sum/<name>/ with all infrastructure
    configured and ready to serve traffic.

    Args:
        site_name: Name/slug for the site.
        theme: Theme slug to use.
        profile: Content profile name to seed.
        content_path: Optional path to custom content directory.
        no_git: Skip git repository creation.
        git_provider: Git provider ("github" or "gitea").
        git_org: Git organization/namespace.
        gitea_url: Gitea instance URL (required if git_provider=gitea).
        gitea_ssh_port: SSH port for Gitea.
        gitea_token_env: Env var name for Gitea API token.
        skip_systemd: Skip systemd service installation.
        skip_caddy: Skip Caddy configuration.
        superuser_username: Username for Django superuser.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    # Validate site name
    try:
        naming = validate_project_name(site_name)
    except ValueError as exc:
        OutputFormatter.error(str(exc))
        return 1

    site_slug = naming.slug

    # Check infrastructure prerequisites
    infra = check_infrastructure()
    if not infra.has_sudo:
        OutputFormatter.error(
            "This command requires root privileges.\n"
            "Run with: sudo sum-platform init ..."
        )
        return 1

    if infra.errors:
        OutputFormatter.error("Infrastructure prerequisites not met:")
        for error in infra.errors:
            OutputFormatter.error(f"  - {error}")
        return 1

    # Load system config
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Check if site already exists
    site_dir = config.get_site_dir(site_slug)
    if site_dir.exists():
        OutputFormatter.error(f"Site already exists at {site_dir}")
        return 1

    # Build git config from flags
    git_config: GitConfig | None = None
    if not no_git:
        # Validate required git flags
        if not git_provider:
            OutputFormatter.error(
                "Git provider required. Use --git-provider github or --git-provider gitea.\n"
                "Or use --no-git to skip git setup."
            )
            return 1
        if not git_org:
            OutputFormatter.error(
                "Git organization required. Use --git-org <org>.\n"
                "Or use --no-git to skip git setup."
            )
            return 1
        if git_provider == "gitea" and not gitea_url:
            OutputFormatter.error("Gitea URL required. Use --gitea-url <url>.")
            return 1

        git_config = GitConfig(
            provider=git_provider,
            org=git_org,
            url=gitea_url,
            ssh_port=gitea_ssh_port,
            token_env=gitea_token_env,
        )

    # Build setup config
    setup_config = SiteSetupConfig(
        site_slug=site_slug,
        theme_slug=theme,
        seed_profile=profile,
        content_path=content_path,
        superuser_username=superuser_username,
        skip_systemd=skip_systemd,
        skip_caddy=skip_caddy,
        git_config=git_config,
    )

    # Run setup
    OutputFormatter.header(f"Creating site: {site_slug}")
    print()

    orchestrator = SiteOrchestrator(config)
    try:
        result = orchestrator.setup_site(setup_config)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Output summary
    print()
    OutputFormatter.success("Site created successfully!")
    print()
    print(f"  URL:          https://{result.domain}")
    print(f"  Admin:        {result.admin_url}")
    print(f"  Username:     {result.superuser_username}")
    # Intentional: Display generated password to user (also saved to credentials file)
    print(f"  Password:     {result.superuser_password}")  # nosec B105
    print()
    print(f"  Site dir:     {result.site_dir}")
    print(f"  App dir:      {result.app_dir}")
    if result.repo_url:
        print(f"  Repository:   {result.repo_url}")
    print()
    print(f"  Credentials saved to: {result.credentials_path}")
    print()

    return 0


def _init_command(
    site_name: str,
    theme: str,
    profile: str,
    content_path: str | None,
    no_git: bool,
    git_provider: str | None,
    git_org: str | None,
    gitea_url: str | None,
    gitea_ssh_port: int,
    gitea_token_env: str,
    skip_systemd: bool,
    skip_caddy: bool,
    superuser_username: str,
) -> None:
    """Initialize a new site on staging."""
    result = run_init(
        site_name,
        theme=theme,
        profile=profile,
        content_path=content_path,
        no_git=no_git,
        git_provider=git_provider,
        git_org=git_org,
        gitea_url=gitea_url,
        gitea_ssh_port=gitea_ssh_port,
        gitea_token_env=gitea_token_env,
        skip_systemd=skip_systemd,
        skip_caddy=skip_caddy,
        superuser_username=superuser_username,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the init command")


if click is None:
    init = _missing_click
else:

    @click.command(name="init")
    @click.argument("site_name")
    @click.option(
        "--theme",
        default="theme_a",
        show_default=True,
        help="Theme slug to use for the site.",
    )
    @click.option(
        "--profile",
        default="starter",
        show_default=True,
        help="Content profile to seed (e.g., starter, sage-stone).",
    )
    @click.option(
        "--content-path",
        default=None,
        help="Path to custom content directory for seeding.",
    )
    @click.option(
        "--no-git",
        is_flag=True,
        help="Skip git repository creation (local git init only).",
    )
    @click.option(
        "--git-provider",
        type=click.Choice(["github", "gitea"]),
        default=None,
        help="Git provider: github or gitea. Required unless --no-git.",
    )
    @click.option(
        "--git-org",
        default=None,
        help="Git organization/namespace. Required unless --no-git.",
    )
    @click.option(
        "--gitea-url",
        default=None,
        help="Gitea instance URL. Required if --git-provider=gitea.",
    )
    @click.option(
        "--gitea-ssh-port",
        type=int,
        default=22,
        show_default=True,
        help="SSH port for Gitea.",
    )
    @click.option(
        "--gitea-token-env",
        default="GITEA_TOKEN",
        show_default=True,
        help="Environment variable for Gitea API token.",
    )
    @click.option(
        "--skip-systemd",
        is_flag=True,
        help="Skip systemd service installation.",
    )
    @click.option(
        "--skip-caddy",
        is_flag=True,
        help="Skip Caddy reverse proxy configuration.",
    )
    @click.option(
        "--superuser",
        "superuser_username",
        default="admin",
        show_default=True,
        help="Username for Django superuser.",
    )
    def _click_init(
        site_name: str,
        theme: str,
        profile: str,
        content_path: str | None,
        no_git: bool,
        git_provider: str | None,
        git_org: str | None,
        gitea_url: str | None,
        gitea_ssh_port: int,
        gitea_token_env: str,
        skip_systemd: bool,
        skip_caddy: bool,
        superuser_username: str,
    ) -> None:
        """Initialize a new site on staging.

        Creates a working site at /srv/sum/<SITE_NAME>/ with:

        \b
        - PostgreSQL database
        - Django project with selected theme
        - External virtualenv
        - Systemd service
        - Caddy reverse proxy
        - Git repository (optional, specify provider with --git-provider)

        \b
        Examples:
          sudo sum-platform init acme --no-git
          sudo sum-platform init acme --git-provider github --git-org acme-corp
          sudo sum-platform init acme --git-provider gitea --git-org clients \\
              --gitea-url https://git.agency.com
          sudo sum-platform init acme --git-provider gitea --git-org clients \\
              --gitea-url https://git.agency.com --gitea-ssh-port 2222
        """
        _init_command(
            site_name,
            theme=theme,
            profile=profile,
            content_path=content_path,
            no_git=no_git,
            git_provider=git_provider,
            git_org=git_org,
            gitea_url=gitea_url,
            gitea_ssh_port=gitea_ssh_port,
            gitea_token_env=gitea_token_env,
            skip_systemd=skip_systemd,
            skip_caddy=skip_caddy,
            superuser_username=superuser_username,
        )

    init = _click_init
