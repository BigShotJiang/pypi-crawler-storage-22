# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Promote command implementation.

Promotes a staging site to production:
- Backup staging DB
- Copy backup to production
- Provision infrastructure on production
- Clone repo, restore DB, sync media
- Start service and verify
"""

from __future__ import annotations

import shlex
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from types import ModuleType

from sum.exceptions import SetupError
from sum.setup.git_ops import get_git_provider_from_config
from sum.setup.infrastructure import generate_password, generate_secret_key
from sum.site_config import GitConfig, SiteConfig, SiteConfigError
from sum.system_config import ConfigurationError, SystemConfig, get_system_config
from sum.utils.output import OutputFormatter

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _backup_staging_db(site_slug: str, staging_dir: Path, config: SystemConfig) -> Path:
    """Create a backup of the staging database."""
    db_name = config.get_db_name(site_slug)
    backup_dir = staging_dir / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    backup_filename = f"{site_slug}_{timestamp}_promote.sql.gz"
    backup_path = backup_dir / backup_filename

    try:
        with open(backup_path, "wb") as f:
            pg_dump = subprocess.Popen(
                ["sudo", "-u", "postgres", "pg_dump", db_name],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            gzip = subprocess.Popen(
                ["gzip"],
                stdin=pg_dump.stdout,
                stdout=f,
                stderr=subprocess.PIPE,
            )
            if pg_dump.stdout:
                pg_dump.stdout.close()

            gzip.communicate()
            pg_dump.wait()

            if pg_dump.returncode != 0:
                stderr = pg_dump.stderr.read() if pg_dump.stderr else b""
                raise SetupError(f"pg_dump failed: {stderr.decode()}")

    except OSError as exc:
        raise SetupError(f"Failed to create backup: {exc}") from exc

    return backup_path


def _copy_backup_to_prod(backup_path: Path, config: SystemConfig) -> str:
    """Copy backup file to production server."""
    ssh_host = config.production.ssh_host
    remote_path = f"/tmp/{backup_path.name}"

    try:
        subprocess.run(
            ["scp", str(backup_path), f"{ssh_host}:{remote_path}"],
            check=True,
            capture_output=True,
            timeout=300,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to copy backup to production: {exc.stderr}") from exc

    return remote_path


def _provision_prod_infrastructure(
    site_slug: str,
    domain: str,
    config: SystemConfig,
) -> dict[str, str]:
    """Provision infrastructure on production server via SSH."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    db_name = config.get_db_name(site_slug)
    db_user = config.get_db_user(site_slug)
    db_password = generate_password()
    secret_key = generate_secret_key()
    python_package = site_slug.replace("-", "_")

    credentials = {
        "db_name": db_name,
        "db_user": db_user,
        "db_password": db_password,
        "secret_key": secret_key,
    }

    # Create directories
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"mkdir -p {shlex.quote(str(site_dir))}/{{app,venv,static,media,backups}}",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to create directories: {exc.stderr}") from exc

    # Create database user and database using psql variable substitution
    # Variables must be passed via stdin for psql to interpret them correctly
    # (psql -v only works with stdin input, not with -c flag)
    sql_commands = [
        ("CREATE USER :\"db_user\" WITH PASSWORD :'db_password';", "create user"),
        ('CREATE DATABASE :"db_name" OWNER :"db_user";', "create database"),
        (
            'GRANT ALL PRIVILEGES ON DATABASE :"db_name" TO :"db_user";',
            "grant privileges",
        ),
    ]

    for sql, description in sql_commands:
        try:
            # Pass SQL via stdin for variable substitution to work
            # Build the remote command as a single string for SSH
            psql_cmd = (
                f"sudo -u postgres psql "
                f"-v db_user={shlex.quote(db_user)} "
                f"-v db_name={shlex.quote(db_name)} "
                f"-v db_password={shlex.quote(db_password)}"
            )
            subprocess.run(
                ["ssh", ssh_host, psql_cmd],
                input=sql,
                check=True,
                capture_output=True,
                text=True,
                timeout=60,
            )
        except subprocess.CalledProcessError as exc:
            # Ignore "already exists" errors
            if "already exists" not in (exc.stderr or ""):
                raise SetupError(f"Failed to {description}: {exc.stderr}") from exc

    # Write .env file
    env_content = f"""# SUM Platform Site Configuration
# Generated by sum-platform promote

DJANGO_SECRET_KEY={secret_key}
DJANGO_SETTINGS_MODULE={python_package}.settings.production
DJANGO_DEBUG=False

DJANGO_DB_NAME={db_name}
DJANGO_DB_USER={db_user}
DJANGO_DB_PASSWORD={db_password}
DJANGO_DB_HOST=localhost
DJANGO_DB_PORT=5432

DJANGO_STATIC_ROOT={site_dir}/static
DJANGO_MEDIA_ROOT={site_dir}/media

ALLOWED_HOSTS={domain}
WAGTAILADMIN_BASE_URL=https://{domain}
"""

    # Write env file via SSH using tee to avoid shell interpretation
    env_path = shlex.quote(f"{site_dir}/.env")
    try:
        subprocess.run(
            ["ssh", ssh_host, "tee", env_path],
            check=True,
            capture_output=True,
            text=True,
            input=env_content,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "chmod", "600", env_path],
            check=True,
            capture_output=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to write .env: {exc.stderr}") from exc

    return credentials


def _clone_repo_on_prod(
    site_slug: str, config: SystemConfig, git_config: GitConfig
) -> None:
    """Clone the site repository on production.

    Uses HTTPS with token to avoid SSH key requirements on production.
    Falls back to SSH if token is not available.
    """
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    provider = get_git_provider_from_config(git_config)
    org = git_config.org

    q_app_dir = shlex.quote(f"{site_dir}/app")
    q_site_env = shlex.quote(f"{site_dir}/.env")
    q_app_env = shlex.quote(f"{site_dir}/app/.env")

    # Get clone URL from provider (SSH format)
    ssh_clone_url = provider.get_clone_url(org, site_slug)

    # Try to get token for HTTPS clone (avoids SSH key setup on prod)
    repo_url = ssh_clone_url  # Default to SSH
    if git_config.provider == "github":
        # Try GitHub CLI token
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                gh_token = result.stdout.strip()
                repo_url = f"https://{gh_token}@github.com/{org}/{site_slug}.git"
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
    elif git_config.provider == "gitea":
        # Try Gitea token from environment
        import os
        from urllib.parse import urlparse

        gitea_token = os.environ.get(git_config.token_env)
        if gitea_token and git_config.url:
            parsed = urlparse(git_config.url)
            repo_url = f"https://{gitea_token}@{parsed.netloc}/{org}/{site_slug}.git"

    cmd = f"git clone {shlex.quote(repo_url)} {q_app_dir}"

    try:
        subprocess.run(
            ["ssh", ssh_host, cmd],
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to clone repository: {exc.stderr}") from exc

    # Copy production .env to app directory (overwrite staging .env from repo)
    try:
        subprocess.run(
            ["ssh", ssh_host, f"cp {q_site_env} {q_app_env}"],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to copy .env to app: {exc.stderr}") from exc


def _setup_venv_on_prod(site_slug: str, config: SystemConfig) -> None:
    """Create venv and install dependencies on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")

    q_venv = shlex.quote(f"{site_dir}/venv")
    q_pip = shlex.quote(f"{site_dir}/venv/bin/pip")
    q_requirements = shlex.quote(f"{site_dir}/app/requirements.txt")
    commands = [
        f"python3 -m venv {q_venv}",
        f"{q_pip} install -r {q_requirements} -q",
    ]

    for cmd in commands:
        try:
            subprocess.run(
                ["ssh", ssh_host, cmd],
                check=True,
                capture_output=True,
                text=True,
                timeout=600,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Failed to setup venv: {exc.stderr}") from exc


def _restore_db_on_prod(
    site_slug: str,
    remote_backup_path: str,
    config: SystemConfig,
) -> None:
    """Restore database from backup on production."""
    ssh_host = config.production.ssh_host
    db_name = config.get_db_name(site_slug)

    # Quote paths to prevent shell injection
    q_backup_path = shlex.quote(remote_backup_path)
    q_db_name = shlex.quote(db_name)
    cmd = f"gunzip -c {q_backup_path} | sudo -u postgres psql {q_db_name}"

    try:
        subprocess.run(
            ["ssh", ssh_host, cmd],
            check=True,
            capture_output=True,
            text=True,
            timeout=600,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to restore database: {exc.stderr}") from exc


def _sync_media_to_prod(site_slug: str, config: SystemConfig) -> None:
    """Sync media files from staging to production."""
    ssh_host = config.production.ssh_host
    staging_dir = config.get_site_dir(site_slug, target="staging")
    prod_dir = config.get_site_dir(site_slug, target="prod")

    staging_media = staging_dir / "media"
    if not staging_media.exists():
        OutputFormatter.warning("No media directory on staging, skipping sync")
        return

    try:
        subprocess.run(
            [
                "rsync",
                "-avz",
                "--delete",
                f"{staging_media}/",
                f"{ssh_host}:{prod_dir}/media/",
            ],
            check=True,
            capture_output=True,
            timeout=600,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to sync media: {exc.stderr}") from exc


def _run_django_setup_on_prod(site_slug: str, config: SystemConfig) -> None:
    """Run Django migrations and collectstatic on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")

    q_app_dir = shlex.quote(f"{site_dir}/app")
    q_venv_python = shlex.quote(f"{site_dir}/venv/bin/python")
    commands = [
        f"cd {q_app_dir} && {q_venv_python} manage.py migrate --noinput",
        f"cd {q_app_dir} && {q_venv_python} manage.py collectstatic --noinput",
    ]

    for cmd in commands:
        try:
            subprocess.run(
                ["ssh", ssh_host, cmd],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Django setup failed: {exc.stderr}") from exc


def _install_systemd_on_prod(site_slug: str, domain: str, config: SystemConfig) -> None:
    """Install systemd service on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    service_name = config.get_systemd_service_name(site_slug)
    python_package = site_slug.replace("-", "_")
    deploy_user = config.defaults.deploy_user

    # Read local template and substitute
    template_path = config.templates.systemd_path
    if not template_path.exists():
        raise SetupError(f"Systemd template not found: {template_path}")

    template_content = template_path.read_text()
    service_content = template_content.replace("__SITE_SLUG__", site_slug)
    service_content = service_content.replace("__DEPLOY_USER__", deploy_user)
    service_content = service_content.replace("__PROJECT_MODULE__", python_package)
    service_content = service_content.replace("__SITE_DIR__", str(site_dir))

    # Write service file via SSH using sudo tee to avoid shell interpretation
    service_path = f"/etc/systemd/system/{service_name}.service"
    try:
        subprocess.run(
            ["ssh", ssh_host, "sudo", "tee", service_path],
            check=True,
            capture_output=True,
            text=True,
            input=service_content,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "daemon-reload"],
            check=True,
            capture_output=True,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "enable", service_name],
            check=True,
            capture_output=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to install systemd service: {exc.stderr}") from exc


def _configure_caddy_on_prod(site_slug: str, domain: str, config: SystemConfig) -> None:
    """Configure Caddy on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    config_name = config.get_caddy_config_name(site_slug)

    # Read local template and substitute
    template_path = config.templates.caddy_path
    if not template_path.exists():
        raise SetupError(f"Caddy template not found: {template_path}")

    template_content = template_path.read_text()
    caddy_content = template_content.replace("__SITE_SLUG__", site_slug)
    caddy_content = caddy_content.replace("__DOMAIN__", domain)
    caddy_content = caddy_content.replace("__SITE_DIR__", str(site_dir))

    # Write Caddy config via SSH using sudo tee to avoid shell interpretation
    caddy_path = f"/etc/caddy/sites-enabled/{config_name}"
    try:
        subprocess.run(
            ["ssh", ssh_host, "sudo", "mkdir", "-p", "/etc/caddy/sites-enabled"],
            check=True,
            capture_output=True,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "sudo", "tee", caddy_path],
            check=True,
            capture_output=True,
            text=True,
            input=caddy_content,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "reload", "caddy"],
            check=True,
            capture_output=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to configure Caddy: {exc.stderr}") from exc


def _start_service_on_prod(site_slug: str, config: SystemConfig) -> None:
    """Start the site service on production."""
    ssh_host = config.production.ssh_host
    service_name = config.get_systemd_service_name(site_slug)

    try:
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "start", service_name],
            check=True,
            capture_output=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to start service: {exc.stderr}") from exc


def _classify_health_failure(
    domain: str,
    returncode: int | None,
    stderr: str | None,
) -> str:
    """Return a human-readable reason for a failed health check."""
    stderr = (stderr or "").strip().lower()

    if "could not resolve host" in stderr or "name or service not known" in stderr:
        return f"DNS resolution failed for {domain}"
    if "connection refused" in stderr:
        return "Connection refused (service may not be listening)"
    if "ssl certificate problem" in stderr or "tls" in stderr:
        return "SSL/TLS error"
    if "operation timed out" in stderr or "timed out" in stderr:
        return "Timeout after 10 seconds"
    if "server returned nothing" in stderr:
        return "Server returned no data"
    if stderr:
        return f"curl error: {stderr[:100]}"
    return f"Unknown error (exit code {returncode})"


def _verify_health(domain: str) -> bool:
    """Verify the site is responding on production.

    Returns True if healthy, False otherwise. Logs failure reason.
    """
    try:
        result = subprocess.run(
            ["curl", "-fsS", f"https://{domain}/health/", "--max-time", "10"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return True

        reason = _classify_health_failure(domain, result.returncode, result.stderr)
        OutputFormatter.warning(f"Health check failed: {reason}")
        return False
    except subprocess.SubprocessError as exc:
        OutputFormatter.warning(f"Health check failed: {exc}")
        return False


def run_promote(
    site_name: str,
    *,
    domain: str,
) -> int:
    """Promote a staging site to production.

    Args:
        site_name: Name/slug of the site to promote.
        domain: Production domain for the site.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    staging_dir = config.get_site_dir(site_name, target="staging")

    # Validate staging site exists
    if not staging_dir.exists():
        OutputFormatter.error(f"Staging site not found: {staging_dir}")
        return 1

    # Load site config to get git settings
    try:
        site_config = SiteConfig.load(staging_dir)
    except SiteConfigError as exc:
        OutputFormatter.error(str(exc))
        return 1

    if site_config.git is None:
        OutputFormatter.error(
            f"Site '{site_name}' was created with --no-git. "
            "Cannot promote without git repository."
        )
        return 1

    git_config = site_config.git

    OutputFormatter.header(f"Promoting {site_name} to production")
    print(f"  Domain: {domain}")
    print()

    total_steps = 11
    current_step = 0

    try:
        # Step 1: Backup staging DB
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Backing up staging database", "⏳"
        )
        backup_path = _backup_staging_db(site_name, staging_dir, config)
        OutputFormatter.progress(
            current_step, total_steps, f"Backup created: {backup_path.name}", "✅"
        )

        # Step 2: Copy backup to production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Copying backup to production", "⏳"
        )
        remote_backup = _copy_backup_to_prod(backup_path, config)
        OutputFormatter.progress(
            current_step, total_steps, "Backup copied to production", "✅"
        )

        # Step 3: Provision infrastructure on production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Provisioning production infrastructure", "⏳"
        )
        _provision_prod_infrastructure(site_name, domain, config)
        OutputFormatter.progress(
            current_step, total_steps, "Infrastructure provisioned", "✅"
        )

        # Step 4: Clone repository on production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Cloning repository on production", "⏳"
        )
        _clone_repo_on_prod(site_name, config, git_config)
        OutputFormatter.progress(current_step, total_steps, "Repository cloned", "✅")

        # Step 5: Setup venv on production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Setting up virtualenv on production", "⏳"
        )
        _setup_venv_on_prod(site_name, config)
        OutputFormatter.progress(
            current_step, total_steps, "Virtualenv configured", "✅"
        )

        # Step 6: Restore database
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Restoring database on production", "⏳"
        )
        _restore_db_on_prod(site_name, remote_backup, config)
        OutputFormatter.progress(current_step, total_steps, "Database restored", "✅")

        # Step 7: Sync media
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Syncing media files", "⏳")
        _sync_media_to_prod(site_name, config)
        OutputFormatter.progress(current_step, total_steps, "Media synced", "✅")

        # Step 8: Run Django setup
        current_step += 1
        OutputFormatter.progress(
            current_step,
            total_steps,
            "Running Django migrations and collectstatic",
            "⏳",
        )
        _run_django_setup_on_prod(site_name, config)
        OutputFormatter.progress(
            current_step, total_steps, "Django setup complete", "✅"
        )

        # Step 9: Install systemd service
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Installing systemd service", "⏳"
        )
        _install_systemd_on_prod(site_name, domain, config)
        OutputFormatter.progress(
            current_step, total_steps, "Systemd service installed", "✅"
        )

        # Step 10: Configure Caddy
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Configuring Caddy", "⏳")
        _configure_caddy_on_prod(site_name, domain, config)
        OutputFormatter.progress(current_step, total_steps, "Caddy configured", "✅")

        # Step 11: Start service
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Starting service", "⏳")
        _start_service_on_prod(site_name, config)
        OutputFormatter.progress(current_step, total_steps, "Service started", "✅")

    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    print()

    # Verify health (optional, non-fatal)
    OutputFormatter.info("Verifying site health...")
    if _verify_health(domain):
        OutputFormatter.success(f"Site responding at https://{domain}")
    else:
        OutputFormatter.warning(
            f"Site not yet responding at https://{domain}/health/\n"
            "This may be normal if DNS is not yet configured."
        )

    print()
    OutputFormatter.success("Site promoted to production!")
    print()
    print(f"  Production URL:  https://{domain}")
    print(f"  Admin:           https://{domain}/admin/")
    print()
    staging_domain = config.get_site_domain(site_name)
    print(f"  Staging still available at: https://{staging_domain}")
    print()
    print(f"  Next: Ensure DNS for {domain} points to {config.production.ssh_host}")
    print()

    return 0


def _promote_command(
    site_name: str,
    domain: str,
) -> None:
    """Promote a staging site to production."""
    result = run_promote(
        site_name,
        domain=domain,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the promote command")


if click is None:
    promote = _missing_click
else:

    @click.command(name="promote")
    @click.argument("site_name")
    @click.option(
        "--domain",
        required=True,
        help="Production domain for the site (e.g., acme-client.com).",
    )
    def _click_promote(
        site_name: str,
        domain: str,
    ) -> None:
        """Promote a staging site to production.

        Takes a working staging site and deploys it to production with
        a custom domain. Handles database migration, media sync, and
        all infrastructure configuration.

        \b
        Steps performed:
        1. Backup staging database
        2. Copy backup to production
        3. Provision production infrastructure (DB, dirs, .env)
        4. Clone repository on production
        5. Setup venv and install dependencies
        6. Restore database
        7. Sync media files
        8. Run migrations and collectstatic
        9. Install systemd service
        10. Configure Caddy reverse proxy
        11. Start service

        \b
        Examples:
          sum-platform promote acme --domain acme-client.com
        """
        _promote_command(
            site_name,
            domain=domain,
        )

    promote = _click_promote
