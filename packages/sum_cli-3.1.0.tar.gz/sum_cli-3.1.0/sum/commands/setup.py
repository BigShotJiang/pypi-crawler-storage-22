"""Setup command for initializing /etc/sum/config.yml."""

from __future__ import annotations

import os
from pathlib import Path
from types import ModuleType

import yaml
from sum.system_config import DEFAULT_CONFIG_PATH
from sum.utils.output import OutputFormatter

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the setup command")


if click is None:
    setup = _missing_click
else:

    @click.command()
    def setup() -> None:
        """Initialize system configuration interactively.

        Creates /etc/sum/config.yml with infrastructure settings.
        Requires sudo.

        \b
        The configuration file stores:
        - Agency information
        - Staging server settings
        - Production server settings
        - Infrastructure template paths
        - Default values

        \b
        Git settings are NOT stored here - they are per-site,
        specified when running 'sum-platform init'.
        """
        if os.geteuid() != 0:
            raise click.ClickException(
                "Setup requires root privileges. Run with: sudo sum-platform setup"
            )

        if DEFAULT_CONFIG_PATH.exists():
            if not click.confirm(f"{DEFAULT_CONFIG_PATH} exists. Overwrite?"):
                raise SystemExit(0)

        click.echo("SUM Platform Setup")
        click.echo("=" * 40)
        click.echo()

        # Agency
        click.echo("Agency Information:")
        agency_name = click.prompt("  Agency name", type=str)

        click.echo()

        # Staging
        click.echo("Staging Server Configuration:")
        staging_server = click.prompt("  Hostname", type=str)
        staging_domain_pattern = click.prompt(
            "  Domain pattern (use {slug} placeholder)",
            default="{slug}." + staging_server,
        )
        staging_base_dir = click.prompt("  Base directory", default="/srv/sum")

        click.echo()

        # Production
        click.echo("Production Server Configuration:")
        prod_server = click.prompt("  Hostname", type=str)
        prod_ssh_host = click.prompt("  SSH host (IP or hostname)", default=prod_server)
        prod_base_dir = click.prompt("  Base directory", default="/srv/sum")

        click.echo()

        # Templates
        click.echo("Infrastructure Templates:")
        templates_dir = click.prompt("  Templates directory", type=str)
        systemd_template = click.prompt(
            "  Systemd template (relative path)",
            default="systemd/sum-site-gunicorn.service.template",
        )
        caddy_template = click.prompt(
            "  Caddy template (relative path)",
            default="caddy/Caddyfile.template",
        )

        click.echo()

        # Defaults
        click.echo("Defaults:")
        default_theme = click.prompt("  Default theme", default="theme_a")
        seed_profile = click.prompt("  Seed profile", default="starter")
        deploy_user = click.prompt("  Deploy user", default="deploy")
        postgres_port = click.prompt("  Postgres port", default=5432, type=int)

        # Build config
        config = {
            "agency": {
                "name": agency_name,
            },
            "staging": {
                "server": staging_server,
                "domain_pattern": staging_domain_pattern,
                "base_dir": staging_base_dir,
            },
            "production": {
                "server": prod_server,
                "ssh_host": prod_ssh_host,
                "base_dir": prod_base_dir,
            },
            "templates": {
                "dir": templates_dir,
                "systemd": systemd_template,
                "caddy": caddy_template,
            },
            "defaults": {
                "theme": default_theme,
                "seed_profile": seed_profile,
                "deploy_user": deploy_user,
                "postgres_port": postgres_port,
            },
        }

        # Write config
        config_path = Path(DEFAULT_CONFIG_PATH)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, "w") as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)

        click.echo()
        OutputFormatter.success(f"Configuration saved to {DEFAULT_CONFIG_PATH}")
