"""Themes command for listing available themes."""

from __future__ import annotations

import sys

from sum.themes_registry import list_themes


def run_themes_list() -> int:
    """
    List all available themes.

    Returns:
        0 on success, 1 on failure
    """
    try:
        themes = list_themes()

        if not themes:
            print("No themes available.")
            return 0

        print("Available themes:")
        print()
        for theme in themes:
            print(f"  {theme.slug}")
            print(f"    Name: {theme.name}")
            print(f"    Description: {theme.description}")
            print(f"    Version: {theme.version}")
            print()

        return 0
    except Exception as e:
        print(f"[FAIL] Failed to list themes: {e}", file=sys.stderr)
        return 1


# Click command wrapper
_missing_click: bool = False
try:
    import click

    @click.command(name="themes")
    def themes() -> None:
        """List available themes."""
        result = run_themes_list()
        if result != 0:
            raise SystemExit(result)

except ImportError:
    _missing_click = True

    def themes() -> None:  # type: ignore[misc]
        """Fallback when click is not installed."""
        raise RuntimeError("Click is required for CLI commands")
