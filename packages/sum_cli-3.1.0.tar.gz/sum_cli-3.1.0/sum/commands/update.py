# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Update command implementation.

Updates an existing site with latest code changes:
- Git pull
- Pip install requirements
- Run migrations
- Collect static files
- Restart service
"""

from __future__ import annotations

import shlex
import subprocess
from pathlib import Path
from types import ModuleType

from sum.exceptions import SetupError
from sum.setup.database import DatabaseManager
from sum.setup.deps import DependencyManager
from sum.setup.venv import VenvManager
from sum.system_config import ConfigurationError, SystemConfig, get_system_config
from sum.utils.django import DjangoCommandExecutor
from sum.utils.environment import ExecutionMode
from sum.utils.output import OutputFormatter

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _run_git_pull(app_dir: Path, config: SystemConfig) -> None:
    """Pull latest changes from git remote.

    Runs git as the deploy user to handle safe.directory permissions.
    """
    deploy_user = config.defaults.deploy_user
    try:
        result = subprocess.run(
            ["sudo", "-u", deploy_user, "git", "pull", "--ff-only"],
            cwd=app_dir,
            check=True,
            capture_output=True,
            text=True,
        )
        if result.stdout:
            OutputFormatter.info(result.stdout.strip())
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Git pull failed: {exc.stderr}") from exc


def _restart_service(site_slug: str, config: SystemConfig) -> None:
    """Restart the systemd service for the site."""
    service_name = config.get_systemd_service_name(site_slug)
    try:
        subprocess.run(
            ["systemctl", "restart", service_name],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to restart service: {exc.stderr}") from exc


def _run_remote_update(
    site_slug: str,
    config: SystemConfig,
    skip_migrations: bool = False,
) -> None:
    """Run update on a remote (production) server via SSH."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    app_dir = site_dir / "app"
    venv_python = site_dir / "venv" / "bin" / "python"
    service_name = config.get_systemd_service_name(site_slug)

    # Quote paths for safe shell interpolation
    q_app_dir = shlex.quote(str(app_dir))
    q_venv_python = shlex.quote(str(venv_python))

    # Build remote commands
    commands = [
        f"cd {q_app_dir} && git pull --ff-only",
        f"{q_venv_python} -m pip install -r {q_app_dir}/requirements.txt -q",
    ]

    if not skip_migrations:
        commands.append(
            f"cd {q_app_dir} && {q_venv_python} manage.py migrate --noinput"
        )

    commands.extend(
        [
            f"cd {q_app_dir} && {q_venv_python} manage.py collectstatic --noinput",
            f"sudo systemctl restart {service_name}",
        ]
    )

    # Execute each command via SSH with timeout
    for cmd in commands:
        OutputFormatter.info(f"Running: {cmd[:60]}...")
        try:
            subprocess.run(
                ["ssh", ssh_host, cmd],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout for long operations
            )
        except subprocess.TimeoutExpired as exc:
            raise SetupError(
                f"Remote command timed out after 5 minutes: {cmd[:60]}..."
            ) from exc
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Remote command failed: {exc.stderr}") from exc


def run_update(
    site_name: str,
    *,
    target: str = "staging",
    skip_migrations: bool = False,
) -> int:
    """Update an existing site with latest code.

    Args:
        site_name: Name/slug of the site to update.
        target: 'staging' or 'prod'.
        skip_migrations: Skip running database migrations.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    site_dir = config.get_site_dir(site_name, target=target)

    # For production, delegate to remote execution
    if target == "prod":
        OutputFormatter.header(f"Updating {site_name} on production")
        print()
        try:
            _run_remote_update(site_name, config, skip_migrations)
        except SetupError as exc:
            OutputFormatter.error(str(exc))
            return 1
        OutputFormatter.success(f"Site {site_name} updated on production")
        return 0

    # For staging, run locally
    app_dir = site_dir / "app"
    venv_path = site_dir / "venv"

    # Validate site exists
    if not site_dir.exists():
        OutputFormatter.error(f"Site not found: {site_dir}")
        return 1

    if not app_dir.exists():
        OutputFormatter.error(f"App directory not found: {app_dir}")
        return 1

    OutputFormatter.header(f"Updating {site_name} on staging")
    print()

    total_steps = 5 if not skip_migrations else 4
    current_step = 0

    try:
        # Step 1: Git pull
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Pulling latest code", "⏳")
        _run_git_pull(app_dir, config)
        OutputFormatter.progress(current_step, total_steps, "Code updated", "✅")

        # Step 2: Install dependencies
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Installing dependencies", "⏳"
        )
        venv_manager = VenvManager(venv_path=venv_path)
        deps_manager = DependencyManager(venv_manager=venv_manager)
        deps_manager.install(app_dir)
        OutputFormatter.progress(
            current_step, total_steps, "Dependencies installed", "✅"
        )

        # Create Django executor
        django_executor = DjangoCommandExecutor(
            app_dir,
            ExecutionMode.STANDALONE,
            python_path=venv_manager.get_python_executable(app_dir),
        )

        # Step 3: Run migrations (optional)
        if not skip_migrations:
            current_step += 1
            OutputFormatter.progress(
                current_step, total_steps, "Running migrations", "⏳"
            )
            db_manager = DatabaseManager(django_executor)
            db_manager.migrate()
            OutputFormatter.progress(
                current_step, total_steps, "Migrations complete", "✅"
            )

        # Step 4: Collect static
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Collecting static files", "⏳"
        )
        django_executor.run_command(["collectstatic", "--noinput"])
        OutputFormatter.progress(
            current_step, total_steps, "Static files collected", "✅"
        )

        # Step 5: Restart service
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Restarting service", "⏳")
        _restart_service(site_name, config)
        OutputFormatter.progress(current_step, total_steps, "Service restarted", "✅")

    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    print()
    OutputFormatter.success(f"Site {site_name} updated successfully")
    return 0


def _update_command(
    site_name: str,
    target: str,
    skip_migrations: bool,
) -> None:
    """Update an existing site."""
    result = run_update(
        site_name,
        target=target,
        skip_migrations=skip_migrations,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the update command")


if click is None:
    update = _missing_click
else:

    @click.command(name="update")
    @click.argument("site_name")
    @click.option(
        "--target",
        type=click.Choice(["staging", "prod"], case_sensitive=False),
        default="staging",
        show_default=True,
        help="Target environment to update.",
    )
    @click.option(
        "--skip-migrations",
        is_flag=True,
        help="Skip running database migrations.",
    )
    def _click_update(
        site_name: str,
        target: str,
        skip_migrations: bool,
    ) -> None:
        """Update an existing site with latest code.

        Pulls latest code from git, installs dependencies, runs migrations,
        collects static files, and restarts the service.

        \b
        Examples:
          sum-platform update acme
          sum-platform update acme --target prod
          sum-platform update acme --skip-migrations
        """
        _update_command(
            site_name,
            target=target,
            skip_migrations=skip_migrations,
        )

    update = _click_update
