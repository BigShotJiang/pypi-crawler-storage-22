"""System configuration for SUM Platform CLI.

Reads agency-specific settings from /etc/sum/config.yml.
All values MUST be provided in the config file - no defaults.
"""

from __future__ import annotations

import dataclasses
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from sum.exceptions import SumCliError

# Default config file location
DEFAULT_CONFIG_PATH = Path("/etc/sum/config.yml")

# Environment variable override for config path (useful for testing/dev)
CONFIG_PATH_ENV_VAR = "SUM_CONFIG_PATH"


class ConfigurationError(SumCliError):
    """Configuration file is missing or invalid."""

    pass


@dataclass
class AgencyConfig:
    """Agency identification settings."""

    name: str


@dataclass
class StagingConfig:
    """Staging server configuration."""

    server: str
    domain_pattern: str  # e.g., "{slug}.example.com"
    base_dir: str


@dataclass
class ProductionConfig:
    """Production server configuration."""

    server: str
    ssh_host: str
    base_dir: str


@dataclass
class TemplatesConfig:
    """Infrastructure template paths."""

    dir: str
    systemd: str
    caddy: str

    @property
    def systemd_path(self) -> Path:
        """Full path to systemd template."""
        return Path(self.dir) / self.systemd

    @property
    def caddy_path(self) -> Path:
        """Full path to Caddy template."""
        return Path(self.dir) / self.caddy


@dataclass
class DefaultsConfig:
    """Default values for CLI operations."""

    theme: str
    deploy_user: str
    seed_profile: str
    postgres_port: int = 5432  # Default port, can be overridden in config


@dataclass
class SystemConfig:
    """Complete system configuration.

    Loaded from /etc/sum/config.yml. All values must be provided.
    """

    agency: AgencyConfig
    staging: StagingConfig
    production: ProductionConfig
    templates: TemplatesConfig
    defaults: DefaultsConfig

    _config_path: Path | None = None

    @classmethod
    def load(cls, config_path: Path | str | None = None) -> SystemConfig:
        """Load configuration from file.

        Args:
            config_path: Optional explicit path to config file.
                         If not provided, checks SUM_CONFIG_PATH env var,
                         then falls back to /etc/sum/config.yml.

        Returns:
            SystemConfig instance with loaded values.

        Raises:
            ConfigurationError: If config file is missing or invalid.
        """
        # Determine config path
        if config_path is None:
            env_path = os.environ.get(CONFIG_PATH_ENV_VAR)
            if env_path:
                config_path = Path(env_path)
            else:
                config_path = DEFAULT_CONFIG_PATH
        else:
            config_path = Path(config_path)

        # Config file is required
        if not config_path.exists():
            raise ConfigurationError(
                f"Configuration file not found: {config_path}\n\n"
                f"The SUM CLI requires a configuration file.\n"
                f"Create {config_path} with your agency settings.\n\n"
                f"See docs/dev/cli/USER_GUIDE.md for the required format."
            )

        return cls._load_from_file(config_path)

    @classmethod
    def _load_from_file(cls, config_path: Path) -> SystemConfig:
        """Load configuration from YAML file."""
        try:
            with open(config_path) as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise ConfigurationError(
                f"Invalid YAML in configuration file {config_path}: {exc}"
            ) from exc

        if not data:
            raise ConfigurationError(f"Configuration file is empty: {config_path}")

        # Validate required sections
        required_sections = ["agency", "staging", "production", "templates", "defaults"]
        missing_sections = [s for s in required_sections if s not in data]
        if missing_sections:
            raise ConfigurationError(
                f"Missing required sections in {config_path}: {', '.join(missing_sections)}"
            )

        try:
            return cls(
                agency=cls._load_section(data["agency"], AgencyConfig, "agency"),
                staging=cls._load_section(data["staging"], StagingConfig, "staging"),
                production=cls._load_section(
                    data["production"], ProductionConfig, "production"
                ),
                templates=cls._load_section(
                    data["templates"], TemplatesConfig, "templates"
                ),
                defaults=cls._load_section(
                    data["defaults"], DefaultsConfig, "defaults"
                ),
                _config_path=config_path,
            )
        except ConfigurationError:
            raise
        except Exception as exc:
            raise ConfigurationError(
                f"Error loading configuration from {config_path}: {exc}"
            ) from exc

    @staticmethod
    def _load_section(
        data: dict[str, Any], config_class: type, section_name: str
    ) -> Any:
        """Load a config section, validating all required fields are present."""
        if not isinstance(data, dict):
            raise ConfigurationError(
                f"Section '{section_name}' must be a mapping, got {type(data).__name__}"
            )

        # For dataclasses without default_factory, check which fields have no default
        all_fields = []
        for field_name, field_info in config_class.__dataclass_fields__.items():
            if field_name.startswith("_"):
                continue
            # Field is required if it has no default and no default_factory
            if (
                field_info.default is dataclasses.MISSING
                and field_info.default_factory is dataclasses.MISSING
            ):
                all_fields.append(field_name)

        missing_fields = [f for f in all_fields if f not in data]
        if missing_fields:
            raise ConfigurationError(
                f"Missing required fields in '{section_name}': {', '.join(missing_fields)}"
            )

        # Build kwargs from data
        kwargs = {}
        for field_name in config_class.__dataclass_fields__:
            if field_name.startswith("_"):
                continue
            if field_name in data:
                kwargs[field_name] = data[field_name]

        return config_class(**kwargs)

    def get_site_dir(self, site_slug: str, target: str = "staging") -> Path:
        """Get the base directory for a site.

        Args:
            site_slug: The site slug (e.g., 'acme')
            target: 'staging' or 'prod'

        Returns:
            Path to site directory
        """
        if target == "prod":
            base = self.production.base_dir
        else:
            base = self.staging.base_dir
        return Path(base) / site_slug

    def get_site_domain(self, site_slug: str, target: str = "staging") -> str:
        """Get the domain for a site.

        Args:
            site_slug: The site slug (e.g., 'acme')
            target: 'staging' or 'prod' (prod requires explicit domain)

        Returns:
            Domain string

        Raises:
            ValueError: If target is 'prod' (production requires explicit domain)
        """
        if target == "prod":
            raise ValueError("Production domain must be explicitly specified")
        return self.staging.domain_pattern.format(slug=site_slug)

    def get_db_name(self, site_slug: str) -> str:
        """Get the Postgres database name for a site."""
        return f"sum_{site_slug}"

    def get_db_user(self, site_slug: str) -> str:
        """Get the Postgres database user for a site."""
        return f"sum_{site_slug}_user"

    def get_systemd_service_name(self, site_slug: str) -> str:
        """Get the systemd service name for a site."""
        return f"sum-{site_slug}-gunicorn"

    def get_caddy_config_name(self, site_slug: str) -> str:
        """Get the Caddy config file name for a site."""
        return f"sum-{site_slug}.caddy"


# Module-level singleton for convenience
_system_config: SystemConfig | None = None


def get_system_config(reload: bool = False) -> SystemConfig:
    """Get the system configuration singleton.

    Args:
        reload: Force reload from file even if already loaded.

    Returns:
        SystemConfig instance.

    Raises:
        ConfigurationError: If config file is missing or invalid.
    """
    global _system_config
    if _system_config is None or reload:
        _system_config = SystemConfig.load()
    return _system_config


def reset_system_config() -> None:
    """Reset the config singleton (primarily for testing)."""
    global _system_config
    _system_config = None
