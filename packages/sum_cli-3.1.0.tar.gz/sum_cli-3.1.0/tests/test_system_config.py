"""Tests for system configuration module."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from sum.system_config import (
    AgencyConfig,
    ConfigurationError,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
    get_system_config,
    reset_system_config,
)


# Fixture for a complete valid config
@pytest.fixture
def valid_config_data():
    """Return a complete valid configuration dict.

    Note: Git settings are now per-site, not in system config.
    """
    return {
        "agency": {
            "name": "testco",
        },
        "staging": {
            "server": "staging-server",
            "domain_pattern": "{slug}.test.site",
            "base_dir": "/srv/test",
        },
        "production": {
            "server": "prod-server",
            "ssh_host": "192.168.1.1",
            "base_dir": "/srv/prod",
        },
        "templates": {
            "dir": "/opt/infra",
            "systemd": "systemd/test.service",
            "caddy": "caddy/test.caddy",
        },
        "defaults": {
            "theme": "theme_test",
            "deploy_user": "testuser",
            "seed_profile": "test-profile",
        },
    }


@pytest.fixture
def valid_config_file(tmp_path, valid_config_data):
    """Create a valid config file and return its path."""
    config_file = tmp_path / "config.yml"
    config_file.write_text(yaml.dump(valid_config_data))
    return config_file


@pytest.fixture(autouse=True)
def reset_config_singleton():
    """Reset the config singleton before each test."""
    reset_system_config()
    yield
    reset_system_config()


class TestAgencyConfig:
    """Tests for AgencyConfig dataclass."""

    def test_requires_name(self):
        with pytest.raises(TypeError):
            AgencyConfig()

    def test_with_name(self):
        config = AgencyConfig(name="acme")
        assert config.name == "acme"


class TestStagingConfig:
    """Tests for StagingConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            StagingConfig()

    def test_with_all_fields(self):
        config = StagingConfig(
            server="staging",
            domain_pattern="{slug}.example.com",
            base_dir="/srv/sites",
        )
        assert config.server == "staging"
        assert config.domain_pattern == "{slug}.example.com"
        assert config.base_dir == "/srv/sites"


class TestProductionConfig:
    """Tests for ProductionConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            ProductionConfig()

    def test_with_all_fields(self):
        config = ProductionConfig(
            server="prod-01",
            ssh_host="10.0.0.1",
            base_dir="/srv/sites",
        )
        assert config.server == "prod-01"
        assert config.ssh_host == "10.0.0.1"
        assert config.base_dir == "/srv/sites"


class TestTemplatesConfig:
    """Tests for TemplatesConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            TemplatesConfig()

    def test_with_all_fields(self):
        config = TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/gunicorn.service",
            caddy="caddy/site.caddy",
        )
        assert config.dir == "/opt/infra"
        assert config.systemd == "systemd/gunicorn.service"
        assert config.caddy == "caddy/site.caddy"

    def test_systemd_path_property(self):
        config = TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/gunicorn.service",
            caddy="caddy/site.caddy",
        )
        expected = Path("/opt/infra/systemd/gunicorn.service")
        assert config.systemd_path == expected

    def test_caddy_path_property(self):
        config = TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/gunicorn.service",
            caddy="caddy/site.caddy",
        )
        expected = Path("/opt/infra/caddy/site.caddy")
        assert config.caddy_path == expected


class TestDefaultsConfig:
    """Tests for DefaultsConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            DefaultsConfig()

    def test_with_all_fields(self):
        config = DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        )
        assert config.theme == "theme_a"
        assert config.deploy_user == "deploy"
        assert config.seed_profile == "sage-stone"


class TestSystemConfig:
    """Tests for SystemConfig dataclass."""

    def test_get_site_dir_staging(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        path = config.get_site_dir("acme", target="staging")
        assert path == Path("/srv/test/acme")

    def test_get_site_dir_prod(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        path = config.get_site_dir("acme", target="prod")
        assert path == Path("/srv/prod/acme")

    def test_get_site_domain_staging(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        domain = config.get_site_domain("acme", target="staging")
        assert domain == "acme.test.site"

    def test_get_site_domain_prod_raises(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        with pytest.raises(
            ValueError, match="Production domain must be explicitly specified"
        ):
            config.get_site_domain("acme", target="prod")

    def test_get_db_name(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_db_name("acme") == "sum_acme"

    def test_get_db_user(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_db_user("acme") == "sum_acme_user"

    def test_get_systemd_service_name(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_systemd_service_name("acme") == "sum-acme-gunicorn"

    def test_get_caddy_config_name(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_caddy_config_name("acme") == "sum-acme.caddy"


class TestSystemConfigLoad:
    """Tests for SystemConfig.load() method."""

    def test_load_raises_when_no_file(self, tmp_path):
        with pytest.raises(ConfigurationError, match="Configuration file not found"):
            SystemConfig.load(tmp_path / "nonexistent.yml")

    def test_load_from_file(self, valid_config_file, valid_config_data):
        config = SystemConfig.load(valid_config_file)

        assert config._config_path == valid_config_file
        assert config.agency.name == "testco"
        assert config.staging.domain_pattern == "{slug}.test.site"
        assert config.staging.server == "staging-server"
        assert config.defaults.theme == "theme_test"

    def test_load_from_env_var(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config = SystemConfig.load()
        assert config.agency.name == "testco"

    def test_load_empty_file_raises(self, tmp_path):
        config_file = tmp_path / "empty.yml"
        config_file.write_text("")

        with pytest.raises(ConfigurationError, match="Configuration file is empty"):
            SystemConfig.load(config_file)

    def test_load_missing_section_raises(self, tmp_path):
        config_file = tmp_path / "partial.yml"
        config_data = {
            "agency": {"name": "test"},
            # Missing: staging, production, templates, defaults
        }
        config_file.write_text(yaml.dump(config_data))

        with pytest.raises(ConfigurationError, match="Missing required sections"):
            SystemConfig.load(config_file)

    def test_load_invalid_yaml_raises(self, tmp_path):
        config_file = tmp_path / "invalid.yml"
        config_file.write_text("invalid: yaml: content:")

        with pytest.raises(ConfigurationError, match="Invalid YAML"):
            SystemConfig.load(config_file)


class TestGetSystemConfig:
    """Tests for get_system_config() singleton function."""

    def test_raises_without_config_file(self, tmp_path, monkeypatch):
        # Point to non-existent location
        monkeypatch.setenv("SUM_CONFIG_PATH", str(tmp_path / "nonexistent.yml"))

        with pytest.raises(ConfigurationError, match="Configuration file not found"):
            get_system_config()

    def test_returns_same_instance(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config1 = get_system_config()
        config2 = get_system_config()
        assert config1 is config2

    def test_reload_returns_new_instance(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config1 = get_system_config()
        config2 = get_system_config(reload=True)
        assert config1 is not config2

    def test_reset_clears_singleton(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config1 = get_system_config()
        reset_system_config()
        config2 = get_system_config()
        assert config1 is not config2
