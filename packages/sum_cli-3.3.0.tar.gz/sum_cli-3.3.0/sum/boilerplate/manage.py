#!/usr/bin/env python
"""
Django management command entry point.

Replace 'project_name' with your actual project name after copying.
"""

from __future__ import annotations

import os
import sys

from dotenv import load_dotenv

# Load environment variables from .env file before Django initialization
load_dotenv()


def main() -> None:
    """Run administrative tasks."""
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "project_name.settings.local")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
