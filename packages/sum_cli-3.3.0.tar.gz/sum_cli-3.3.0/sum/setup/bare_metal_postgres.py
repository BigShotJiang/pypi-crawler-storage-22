"""Bare metal PostgreSQL provisioning with WAL archiving.

Creates per-site PostgreSQL clusters using pg_createcluster with pgBackRest
for continuous WAL archiving to Hetzner Storage Box.

Each site gets its own PostgreSQL instance (cluster) for isolation:
- Data: /var/lib/postgresql/<version>/<slug>/
- Config: /etc/postgresql/<version>/<slug>/
- Port: Allocated from ports.py (5433-5532 range)

Templates are read from paths configured in /etc/sum/config.yml (templates section)
and use __PLACEHOLDER__ style substitution.
"""

from __future__ import annotations

import re
import subprocess
import time
from pathlib import Path

from sum.exceptions import SetupError
from sum.setup.infrastructure import SiteCredentials
from sum.setup.ports import allocate_port, deallocate_port
from sum.system_config import SystemConfig
from sum.utils.output import OutputFormatter

# Valid site_slug pattern: alphanumeric, hyphens, underscores only
# Used to prevent command injection in archive_command and other shell contexts
SITE_SLUG_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")

# Valid SQL identifier pattern: alphanumeric and underscores only
SQL_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z0-9_]+$")

# Safe path characters for use in shell-embedded strings (e.g. archive_command)
_SAFE_PATH_RE = re.compile(r"^[a-zA-Z0-9/_.-]+$")


def _validate_site_slug(site_slug: str) -> None:
    """Validate site_slug contains only safe characters.

    Args:
        site_slug: Site identifier to validate

    Raises:
        SetupError: If site_slug contains invalid characters
    """
    if not SITE_SLUG_PATTERN.match(site_slug):
        raise SetupError(
            f"Invalid site_slug '{site_slug}': must contain only "
            "alphanumeric characters, hyphens, and underscores"
        )


def _validate_sql_identifier(value: str, name: str) -> None:
    """Validate a SQL identifier contains only safe characters.

    Args:
        value: Identifier value to validate
        name: Name of the field (for error messages)

    Raises:
        SetupError: If identifier contains unsafe characters
    """
    if not SQL_IDENTIFIER_PATTERN.match(value):
        raise SetupError(
            f"Invalid {name} '{value}': must contain only "
            "alphanumeric characters and underscores"
        )


def _render_template(template_path: Path, replacements: dict[str, str]) -> str:
    """Render a template file with __PLACEHOLDER__ substitutions.

    Args:
        template_path: Path to template file
        replacements: Dict mapping placeholder names to values
                      (without the __ prefix/suffix)

    Returns:
        Rendered template content

    Raises:
        SetupError: If template file doesn't exist
    """
    if not template_path.exists():
        raise SetupError(f"Template not found: {template_path}")

    content = template_path.read_text()

    for key, value in replacements.items():
        placeholder = f"__{key}__"
        content = content.replace(placeholder, str(value))

    return content


def setup_bare_metal_postgres(
    site_slug: str,
    credentials: SiteCredentials,
    config: SystemConfig,
) -> int:
    """Provision a bare metal PostgreSQL cluster with WAL archiving.

    Creates an isolated PostgreSQL cluster for the site using pg_createcluster,
    configures WAL archiving via pgBackRest, and runs an initial backup.

    Args:
        site_slug: Site identifier (e.g., 'acme')
        credentials: Database credentials
        config: System configuration

    Returns:
        Allocated port number for the PostgreSQL cluster.

    Raises:
        SetupError: If provisioning fails.
    """
    # Validate site_slug to prevent command injection in archive_command
    _validate_site_slug(site_slug)

    out = OutputFormatter()
    out.info(f"Setting up bare metal PostgreSQL for {site_slug}")

    # Get PostgreSQL version from config
    postgres_version = "18"  # Default
    if config.infrastructure:
        postgres_version = config.infrastructure.postgres_version

    # Allocate unique port
    port = allocate_port(site_slug, config)
    out.success(f"Allocated port {port} for PostgreSQL")

    try:
        # Create PostgreSQL cluster
        _create_postgres_cluster(site_slug, port, postgres_version)
        out.success(f"Created PostgreSQL cluster {postgres_version}/{site_slug}")

        # Configure WAL archiving in postgresql.conf
        if config.backups:
            _configure_wal_archiving(site_slug, postgres_version, config)
            out.success("Configured WAL archiving")

        # Start the cluster
        _start_cluster(site_slug, postgres_version)
        out.success("Started PostgreSQL cluster")

        # Wait for PostgreSQL to be ready
        _wait_for_postgres(port)
        out.success("PostgreSQL is ready")

        # Create database and user
        _create_database_and_user(site_slug, port, credentials)
        out.success("Created database and user")

        # Configure pgBackRest if backups are enabled
        if config.backups:
            # Verify SSH key exists
            _verify_backup_ssh_key(config)
            out.success("Verified backup SSH key")

            # Generate pgBackRest stanza config
            _generate_pgbackrest_stanza_config(site_slug, port, credentials, config)
            out.success("Generated pgBackRest stanza config")

            # Initialize pgBackRest stanza
            _init_pgbackrest_stanza(site_slug, config)
            out.success("Initialized pgBackRest stanza")

            # Run initial full backup
            _run_initial_backup(site_slug, config)
            out.success("Completed initial backup")

        return port

    except Exception as exc:
        out.error(f"Bare metal PostgreSQL setup failed: {exc}")
        cleanup_bare_metal_postgres(site_slug, postgres_version, config)
        raise SetupError(f"Failed to setup bare metal PostgreSQL: {exc}") from exc


def _create_postgres_cluster(site_slug: str, port: int, postgres_version: str) -> None:
    """Create a PostgreSQL cluster using pg_createcluster.

    Uses Debian/Ubuntu pg_createcluster command to create an isolated
    PostgreSQL instance with its own data directory and configuration.

    Args:
        site_slug: Site identifier (becomes cluster name)
        port: Port number for the cluster
        postgres_version: PostgreSQL version (e.g., "18")

    Raises:
        SetupError: If cluster creation fails.
    """
    try:
        subprocess.run(
            [
                "pg_createcluster",
                postgres_version,
                site_slug,
                "-p",
                str(port),
                "--start-conf=manual",  # Don't auto-start on boot
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to create PostgreSQL cluster:\n{exc.stderr or exc.stdout}"
        ) from exc


def _configure_wal_archiving(
    site_slug: str, postgres_version: str, config: SystemConfig
) -> None:
    """Configure WAL archiving in postgresql.conf.

    Adds the required settings for pgBackRest WAL archiving:
    - wal_level = replica (REQUIRED for WAL archiving)
    - archive_mode = on
    - archive_command = pgbackrest archive-push
    - archive_timeout = 300

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version
        config: System configuration (for pgBackRest config directory path)

    Raises:
        SetupError: If configuration fails.
    """
    conf_path = Path(f"/etc/postgresql/{postgres_version}/{site_slug}/postgresql.conf")

    if not conf_path.exists():
        raise SetupError(f"PostgreSQL config not found: {conf_path}")

    try:
        # Read existing config
        content = conf_path.read_text()

        # Append WAL archiving configuration
        # --config-include-path is required on the command line for pgBackRest 2.50+
        # because it cannot be set in the config file itself
        config_include_path = str(config.get_pgbackrest_config_dir())
        if not _SAFE_PATH_RE.match(config_include_path):
            raise SetupError(
                f"Unsafe characters in pgbackrest config path: {config_include_path}"
            )
        wal_config = f"""

# WAL archiving for pgBackRest (added by SUM Platform)
wal_level = replica
archive_mode = on
archive_command = 'pgbackrest --config-include-path={config_include_path} --stanza={site_slug} archive-push %p'
archive_timeout = 300
"""
        content += wal_config
        conf_path.write_text(content)

    except OSError as exc:
        raise SetupError(f"Failed to configure WAL archiving: {exc}") from exc


def _start_cluster(site_slug: str, postgres_version: str) -> None:
    """Start a PostgreSQL cluster using pg_ctlcluster.

    Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    for cluster names containing dashes (e.g., testsite-a).

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version

    Raises:
        SetupError: If cluster fails to start.
    """
    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                postgres_version,
                site_slug,
                "start",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to start PostgreSQL cluster:\n{exc.stderr or exc.stdout}"
        ) from exc


def _wait_for_postgres(port: int, timeout: int = 60) -> None:
    """Wait for PostgreSQL to be ready using pg_isready.

    Args:
        port: PostgreSQL port number
        timeout: Maximum wait time in seconds

    Raises:
        SetupError: If PostgreSQL doesn't become ready within timeout.
    """
    out = OutputFormatter()
    out.info(f"Waiting for PostgreSQL to be ready (timeout: {timeout}s)")

    start_time = time.time()

    while time.time() - start_time < timeout:
        try:
            result = subprocess.run(
                ["pg_isready", "-p", str(port)],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return
        except subprocess.TimeoutExpired:
            # pg_isready timed out; will retry after sleep
            pass
        except FileNotFoundError as exc:
            raise SetupError(
                "pg_isready not found. Is PostgreSQL client installed?"
            ) from exc
        except subprocess.SubprocessError as exc:
            raise SetupError(
                f"Failed while waiting for PostgreSQL to become ready: {exc}"
            ) from exc

        time.sleep(2)

    raise SetupError(
        f"PostgreSQL did not become ready within {timeout} seconds. "
        f"Check cluster logs with: pg_lsclusters"
    )


def _create_database_and_user(
    site_slug: str, port: int, credentials: SiteCredentials
) -> None:
    """Create database and user for the site.

    Runs as postgres user via sudo to create the database and user
    with appropriate permissions.

    Args:
        site_slug: Site identifier
        port: PostgreSQL port number
        credentials: Database credentials

    Raises:
        SetupError: If database/user creation fails.
    """
    # Validate identifiers contain only safe characters (defense-in-depth)
    # These are generated from validated slugs, but verify to prevent injection
    # if the generation logic ever changes
    _validate_sql_identifier(credentials.db_user, "db_user")
    _validate_sql_identifier(credentials.db_name, "db_name")

    # Use psql variable substitution via stdin to avoid password in command args
    create_user_sql = "CREATE USER :\"db_user\" WITH PASSWORD :'db_password';"
    create_db_sql = 'CREATE DATABASE :"db_name" OWNER :"db_user";'

    psql_base = ["sudo", "-u", "postgres", "psql", "-p", str(port)]
    psql_vars = [
        "-v",
        f"db_user={credentials.db_user}",
        "-v",
        f"db_name={credentials.db_name}",
    ]

    # Password set via stdin to avoid /proc exposure
    password_escaped = credentials.db_password.replace("'", "''")
    password_preamble = f"\\set db_password '{password_escaped}'\n"

    try:
        for sql in [create_user_sql, create_db_sql]:
            subprocess.run(
                psql_base + psql_vars,
                input=password_preamble + sql,
                check=True,
                capture_output=True,
                text=True,
            )

    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to create database/user:\n{exc.stderr or exc.stdout}"
        ) from exc


def _verify_backup_ssh_key(config: SystemConfig) -> None:
    """Verify backup SSH key exists at configured location.

    Args:
        config: System configuration

    Raises:
        SetupError: If SSH key doesn't exist.
    """
    if not config.backups:
        return

    ssh_key_path = Path(config.backups.storage_box.ssh_key)
    if not ssh_key_path.exists():
        raise SetupError(
            f"Backup SSH key not found: {ssh_key_path}\n"
            f"Ensure the key exists at the configured location."
        )


def _generate_pgbackrest_stanza_config(
    site_slug: str,
    port: int,
    credentials: SiteCredentials,
    config: SystemConfig,
) -> None:
    """Generate pgBackRest stanza configuration file.

    Creates a per-site config at /etc/pgbackrest/conf.d/<slug>.conf
    using the template from lintel-ops.

    Args:
        site_slug: Site identifier
        port: PostgreSQL port number
        credentials: Database credentials
        config: System configuration

    Raises:
        SetupError: If config generation fails.
    """
    if not config.backups:
        return

    if not config.templates.pgbackrest_stanza_path:
        raise SetupError(
            "pgBackRest stanza template not configured in /etc/sum/config.yml\n"
            "Add templates.pgbackrest_stanza path."
        )

    # Get infrastructure settings
    infra = config.infrastructure
    postgres_version = "18"
    if infra:
        postgres_version = infra.postgres_version

    # Get pgbackrest settings
    if infra and infra.pgbackrest:
        compress_type = infra.pgbackrest.compress_type
        compress_level = infra.pgbackrest.compress_level
        process_max = infra.pgbackrest.process_max
    else:
        compress_type = "zst"
        compress_level = 3
        process_max = 2

    replacements = {
        "SITE_SLUG": site_slug,
        "POSTGRES_VERSION": postgres_version,
        "POSTGRES_PORT": str(port),
        "DB_USER": credentials.db_user,
        "BACKUP_KEY_PATH": config.backups.storage_box.ssh_key,
        "CIPHER_PASS": Path(config.backups.cipher_pass_file).read_text().strip(),
        "STORAGE_BOX_HOST": config.backups.storage_box.host,
        "STORAGE_BOX_USER": config.backups.storage_box.user,
        "STORAGE_BOX_PORT": str(config.backups.storage_box.port),
        "STORAGE_BOX_FINGERPRINT": config.backups.storage_box.fingerprint,
        "STORAGE_BOX_BASE_PATH": config.backups.storage_box.base_path,
        "RETENTION_FULL": str(config.backups.retention.full_backups),
        "RETENTION_DIFF": str(config.backups.retention.diff_backups),
        "COMPRESS_TYPE": compress_type,
        "COMPRESS_LEVEL": str(compress_level),
        "PROCESS_MAX": str(process_max),
    }

    content = _render_template(config.templates.pgbackrest_stanza_path, replacements)

    # Write stanza config to configured directory
    stanza_dir = config.get_pgbackrest_config_dir()
    stanza_dir.mkdir(parents=True, exist_ok=True)

    stanza_file = stanza_dir / f"{site_slug}.conf"
    try:
        stanza_file.write_text(content)
        # Set ownership to postgres user
        subprocess.run(
            ["chown", "postgres:postgres", str(stanza_file)],
            check=True,
            capture_output=True,
        )
        stanza_file.chmod(0o640)
    except (OSError, subprocess.CalledProcessError) as exc:
        raise SetupError(f"Failed to write pgBackRest stanza config: {exc}") from exc


def _init_pgbackrest_stanza(site_slug: str, config: SystemConfig) -> None:
    """Initialize pgBackRest stanza.

    Runs stanza-create as postgres user to initialize the backup repository.

    Args:
        site_slug: Site identifier
        config: System configuration for paths

    Raises:
        SetupError: If stanza creation fails.
    """
    config_include_path = str(config.get_pgbackrest_config_dir())
    try:
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                "pgbackrest",
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "stanza-create",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        # pgbackrest writes errors to stdout with log prefixes, not stderr
        error_output = exc.stdout or exc.stderr or "No error output"
        raise SetupError(
            f"Failed to initialize pgBackRest stanza:\n{error_output}"
        ) from exc


def _run_initial_backup(site_slug: str, config: SystemConfig) -> None:
    """Run initial full backup.

    Runs a full backup as postgres user to establish the first restore point.

    Args:
        site_slug: Site identifier
        config: System configuration for paths

    Raises:
        SetupError: If backup fails.
    """
    config_include_path = str(config.get_pgbackrest_config_dir())
    try:
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                "pgbackrest",
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "--type=full",
                "backup",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        # pgbackrest writes errors to stdout with log prefixes, not stderr
        error_output = exc.stdout or exc.stderr or "No error output"
        raise SetupError(f"Failed to run initial backup:\n{error_output}") from exc


def stop_bare_metal_postgres(site_slug: str, postgres_version: str) -> None:
    """Stop a PostgreSQL cluster.

    Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    for cluster names containing dashes.

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version

    Raises:
        SetupError: If cluster fails to stop.
    """
    out = OutputFormatter()
    out.info(f"Stopping PostgreSQL cluster for {site_slug}")

    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                postgres_version,
                site_slug,
                "stop",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        out.success("Stopped PostgreSQL cluster")
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to stop PostgreSQL cluster:\n{exc.stderr or exc.stdout}"
        ) from exc


def cleanup_pgbackrest_remote_state(
    site_slug: str, config: SystemConfig | None = None
) -> None:
    """Clean up remote pgBackRest stanza state to prevent retry blockers.

    Stops the stanza and runs stanza-delete --force to remove both local and
    remote backup metadata. This prevents the [028] error when retrying init
    after a failed run that left remote state behind.

    Best-effort: logs warnings on failure but does not raise.

    Args:
        site_slug: Site identifier
        config: Optional system configuration for paths
    """
    out = OutputFormatter()

    config_include_path = (
        str(config.get_pgbackrest_config_dir()) if config else "/etc/pgbackrest/conf.d"
    )

    # Stop stanza (create stop marker to allow stanza-delete)
    try:
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                "pgbackrest",
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "stop",
            ],
            capture_output=True,
            text=True,
        )
    except (subprocess.SubprocessError, OSError):
        pass  # Stanza may not exist or already be stopped

    # Delete stanza (removes remote and local metadata)
    try:
        result = subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                "pgbackrest",
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "stanza-delete",
                "--force",
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            out.info("Cleaned up pgBackRest stanza metadata")
        else:
            out.warning(
                f"pgBackRest stanza-delete returned {result.returncode}: "
                f"{result.stderr}"
            )
    except (subprocess.SubprocessError, OSError) as exc:
        out.warning(f"Could not delete pgBackRest stanza (may not exist): {exc}")


def cleanup_bare_metal_postgres(
    site_slug: str,
    postgres_version: str,
    config: SystemConfig | None = None,
    *,
    purge_remote_backups: bool = True,
) -> None:
    """Completely remove PostgreSQL cluster and cleanup resources.

    Stops the cluster, optionally cleans up pgBackRest remote state,
    drops the cluster via pg_dropcluster, deallocates the port,
    and removes the pgBackRest stanza config file.

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version
        config: Optional system configuration for custom paths
        purge_remote_backups: If True (default) and backups are configured,
            also purge remote pgBackRest stanza data. This prevents the
            [028] retry blocker after failed inits. Set to False when
            deliberate destroy should preserve remote backup data.
    """
    out = OutputFormatter()
    out.info(f"Cleaning up PostgreSQL cluster for {site_slug}")

    # Try to stop cluster first (may already be stopped or not exist)
    # Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    # for cluster names containing dashes.
    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                postgres_version,
                site_slug,
                "stop",
            ],
            capture_output=True,
            text=True,
        )
    except subprocess.SubprocessError:
        pass  # Cluster may not be running or may not exist

    # Clean up pgBackRest remote state before dropping the cluster.
    # stanza-delete requires the stanza config file to still exist, so
    # this must happen before we remove the local stanza config.
    if purge_remote_backups and config and config.backups:
        cleanup_pgbackrest_remote_state(site_slug, config)

    # Drop the cluster
    try:
        subprocess.run(
            ["pg_dropcluster", postgres_version, site_slug],
            check=True,
            capture_output=True,
            text=True,
        )
        out.info("Dropped PostgreSQL cluster")
    except subprocess.CalledProcessError as exc:
        # Cluster may not exist
        out.warning(
            f"Could not drop cluster (may not exist): {exc.stderr or exc.stdout}"
        )

    # Deallocate port
    deallocate_port(site_slug, config)
    out.info("Deallocated port")

    # Remove pgBackRest stanza config file (local)
    stanza_dir = (
        config.get_pgbackrest_config_dir() if config else Path("/etc/pgbackrest/conf.d")
    )
    stanza_file = stanza_dir / f"{site_slug}.conf"
    if stanza_file.exists():
        try:
            stanza_file.unlink()
            out.info("Removed pgBackRest stanza config")
        except OSError as exc:
            out.warning(f"Could not remove stanza config: {exc}")
