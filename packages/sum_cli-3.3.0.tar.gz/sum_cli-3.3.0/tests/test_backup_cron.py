"""Tests for backup cron schedule management."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from sum.setup.backup_cron import (
    _get_staggered_minute,
    install_backup_cron,
    remove_backup_cron,
)


@pytest.fixture
def temp_cron_file(tmp_path):
    """Create a temporary cron file."""
    cron_file = tmp_path / "sum-backups"
    with patch("sum.setup.backup_cron.CRON_FILE", cron_file):
        yield cron_file


class TestGetStaggeredMinute:
    """Tests for the staggered minute calculation."""

    def test_returns_int_between_0_and_59(self):
        """Minute is always in valid cron range."""
        for slug in ["acme", "beta", "gamma", "delta", "test-site-123"]:
            minute = _get_staggered_minute(slug)
            assert 0 <= minute <= 59

    def test_same_slug_same_minute(self):
        """Same site slug always gets same minute."""
        assert _get_staggered_minute("acme") == _get_staggered_minute("acme")

    def test_different_slugs_likely_different(self):
        """Different slugs likely get different minutes."""
        # Not guaranteed but very unlikely to be all the same
        minutes = {_get_staggered_minute(f"site{i}") for i in range(10)}
        assert len(minutes) > 1  # At least some variation


class TestInstallBackupCron:
    """Tests for installing backup cron entries."""

    def test_creates_cron_file_if_missing(self, temp_cron_file):
        """Creates cron file if it doesn't exist."""
        assert not temp_cron_file.exists()
        install_backup_cron("acme")
        assert temp_cron_file.exists()

    def test_adds_marker_comment(self, temp_cron_file):
        """Adds site marker comment."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "# acme" in content

    def test_adds_full_backup_entry(self, temp_cron_file):
        """Adds Sunday full backup entry."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "--stanza='acme'" in content or "--stanza=acme" in content
        assert "--type=full" in content
        assert "* * 0 root sudo -u postgres pgbackrest" in content

    def test_adds_diff_backup_entry(self, temp_cron_file):
        """Adds Mon-Sat differential backup entry."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "--stanza='acme'" in content or "--stanza=acme" in content
        assert "--type=diff" in content
        assert "* * 1-6 root sudo -u postgres pgbackrest" in content

    def test_idempotent(self, temp_cron_file):
        """Installing twice doesn't duplicate entries."""
        install_backup_cron("acme")
        content1 = temp_cron_file.read_text()
        install_backup_cron("acme")
        content2 = temp_cron_file.read_text()
        assert content1 == content2

    def test_multiple_sites(self, temp_cron_file):
        """Can install entries for multiple sites."""
        install_backup_cron("acme")
        install_backup_cron("beta")
        content = temp_cron_file.read_text()
        assert "# acme" in content
        assert "# beta" in content
        assert "acme" in content
        assert "beta" in content

    def test_uses_site_dir_for_marker_file(self, temp_cron_file):
        """Uses provided site_dir for backup status marker."""
        install_backup_cron("acme", site_dir="/custom/path")
        content = temp_cron_file.read_text()
        assert "/custom/path/backup_status" in content

    def test_updates_marker_on_success(self, temp_cron_file):
        """Cron entry updates marker file on successful backup."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "date +%s > " in content
        assert "backup_status" in content


class TestRemoveBackupCron:
    """Tests for removing backup cron entries."""

    def test_removes_site_entries(self, temp_cron_file):
        """Removes all entries for a site."""
        install_backup_cron("acme")
        install_backup_cron("beta")
        remove_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "# acme" not in content
        assert "# beta" in content

    def test_removes_file_when_empty(self, temp_cron_file):
        """Removes cron file when last site is removed."""
        install_backup_cron("acme")
        remove_backup_cron("acme")
        assert not temp_cron_file.exists()

    def test_noop_if_file_missing(self, temp_cron_file):
        """No error if cron file doesn't exist."""
        remove_backup_cron("acme")  # Should not raise

    def test_noop_if_site_not_in_file(self, temp_cron_file):
        """No error if site not in cron file."""
        install_backup_cron("acme")
        content_before = temp_cron_file.read_text()
        remove_backup_cron("nonexistent")
        content_after = temp_cron_file.read_text()
        assert content_before == content_after
