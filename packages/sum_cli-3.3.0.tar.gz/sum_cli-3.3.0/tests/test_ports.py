"""Tests for port allocation manager."""

import socket
from unittest.mock import patch

import pytest
from sum.setup.ports import (
    _is_port_in_use,
    allocate_port,
    deallocate_port,
    get_site_port,
)


@pytest.fixture
def temp_ports_file(tmp_path):
    """Create a temporary ports file and lock file, mocking system port check."""
    ports_file = tmp_path / "ports.json"
    lock_file = tmp_path / "ports.lock"
    with (
        patch("sum.setup.ports.DEFAULT_PORTS_FILE", ports_file),
        patch("sum.setup.ports.DEFAULT_LOCK_FILE", lock_file),
        # Mock _is_port_in_use to always return False (port available)
        # so tests don't depend on actual system port state
        patch("sum.setup.ports._is_port_in_use", return_value=False),
    ):
        yield ports_file


def test_allocate_port_first_site(temp_ports_file):
    """First site gets port 5433."""
    port = allocate_port("acme")
    assert port == 5433


def test_allocate_port_increments(temp_ports_file):
    """Subsequent sites get incrementing ports."""
    allocate_port("acme")
    port2 = allocate_port("beta")
    assert port2 == 5434


def test_allocate_port_idempotent(temp_ports_file):
    """Same site always gets same port."""
    port1 = allocate_port("acme")
    port2 = allocate_port("acme")
    assert port1 == port2 == 5433


def test_deallocate_port(temp_ports_file):
    """Deallocating removes the port."""
    allocate_port("acme")
    deallocate_port("acme")
    assert get_site_port("acme") is None


def test_get_site_port_not_found(temp_ports_file):
    """Returns None for unallocated site."""
    assert get_site_port("nonexistent") is None


def test_allocate_port_exhaustion(temp_ports_file):
    """Raises error when all ports in range are allocated."""
    from sum.exceptions import SetupError
    from sum.setup.ports import DEFAULT_MAX_PORT as MAX_PORT
    from sum.setup.ports import DEFAULT_MIN_PORT as MIN_PORT

    # Allocate all ports in range
    for i in range(MAX_PORT - MIN_PORT + 1):
        allocate_port(f"site{i}")

    # Next allocation should fail
    with pytest.raises(SetupError, match="No available ports"):
        allocate_port("one_too_many")


class TestIsPortInUse:
    """Tests for _is_port_in_use system port checker."""

    def test_available_port(self):
        """Returns False for a port that is not in use."""
        # Use a high ephemeral port unlikely to be in use
        assert _is_port_in_use(59999) is False

    def test_port_in_use(self):
        """Returns True for a port that is in use."""
        # Bind a port and verify it's detected as in use
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", 0))  # Bind to any available port
            port = sock.getsockname()[1]
            sock.listen(1)
            assert _is_port_in_use(port) is True


class TestAllocatePortWithSystemCheck:
    """Tests for port allocation with system port checking."""

    def test_skips_system_occupied_port(self, tmp_path):
        """Allocation skips ports that are in use on the system."""
        ports_file = tmp_path / "ports.json"
        lock_file = tmp_path / "ports.lock"

        # Mock _is_port_in_use to say 5433 is in use (like system postgres)
        def mock_port_check(port):
            return port == 5433  # Only 5433 is "in use"

        with (
            patch("sum.setup.ports.DEFAULT_PORTS_FILE", ports_file),
            patch("sum.setup.ports.DEFAULT_LOCK_FILE", lock_file),
            patch("sum.setup.ports._is_port_in_use", side_effect=mock_port_check),
        ):
            port = allocate_port("test-site")
            # Should skip 5433 and allocate 5434
            assert port == 5434
