"""Tests for the promote command.

Tests cover:
- Dry-run mode previews steps
- Confirmation prompt behavior
- Domain validation rejects invalid input
- Site slug validation rejects invalid input
- Root privilege escalation is enforced
- Secure temp dir for backup transfer
- Git token sanitization after clone
- Click command flags (--dry-run, --confirm, --domain)
"""

from __future__ import annotations

import subprocess
from importlib import import_module
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.commands.promote import run_promote
from sum.system_config import (
    AgencyConfig,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
    reset_system_config,
)

promote_module = import_module("sum.commands.promote")


@pytest.fixture(autouse=True)
def mock_privilege_escalation(monkeypatch):
    """Mock privilege escalation to always succeed for tests."""
    monkeypatch.setattr(
        promote_module, "require_root_or_escalate", lambda cmd, **kw: True
    )


@pytest.fixture(autouse=True)
def reset_config():
    """Reset config singleton before and after each test."""
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture
def mock_system_config(monkeypatch, tmp_path):
    """Mock system config with temp directories."""
    config = SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="test-staging",
            domain_pattern="{slug}.test.site",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="test-prod",
            ssh_host="192.168.1.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )

    monkeypatch.setattr(promote_module, "get_system_config", lambda: config)
    return config


def _create_staging_site(config: SystemConfig, slug: str) -> Path:
    """Helper: create a minimal staging site with git config."""
    site_dir = config.get_site_dir(slug, target="staging")
    site_dir.mkdir(parents=True, exist_ok=True)
    (site_dir / "app").mkdir(exist_ok=True)
    (site_dir / ".env").write_text("DJANGO_SECRET_KEY=test")

    # Create site config with git settings
    sum_dir = site_dir / ".sum"
    sum_dir.mkdir(exist_ok=True)
    (sum_dir / "config.yml").write_text(
        f"site:\n"
        f"  slug: {slug}\n"
        f"  theme: theme_a\n"
        f"  created: '2025-01-01T00:00:00'\n"
        f"git:\n"
        f"  provider: github\n"
        f"  org: testco\n"
        f"  token_env: GITHUB_TOKEN\n"
    )
    return site_dir


class TestPromoteValidation:
    """Tests for input validation in promote."""

    def test_rejects_invalid_domain(self, mock_system_config, capsys):
        """Invalid domain is rejected before any operations."""
        result = run_promote("acme", domain="not a domain!!!")
        assert result == 1

        captured = capsys.readouterr()
        assert "Invalid domain" in captured.out

    def test_rejects_empty_domain(self, mock_system_config, capsys):
        """Empty domain is rejected."""
        result = run_promote("acme", domain="")
        assert result == 1

        captured = capsys.readouterr()
        assert "must not be empty" in captured.out

    def test_rejects_invalid_site_slug(self, mock_system_config, capsys):
        """Invalid site slug is rejected before any operations."""
        result = run_promote("INVALID_SLUG!!!", domain="acme.example.com")
        assert result == 1

        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out

    def test_accepts_valid_domain(self, mock_system_config, capsys):
        """Valid domain passes validation (may fail later at staging check)."""
        result = run_promote("acme", domain="acme.example.com")
        # Will fail at "staging site not found" - but that means it passed validation
        assert result == 1
        captured = capsys.readouterr()
        assert "Staging site not found" in captured.out

    def test_nonexistent_staging_site(self, mock_system_config, capsys):
        """Non-existent staging site fails with clear error."""
        result = run_promote("acme", domain="acme.example.com")
        assert result == 1

        captured = capsys.readouterr()
        assert "Staging site not found" in captured.out


class TestPromoteDryRun:
    """Tests for --dry-run flag."""

    def test_dry_run_shows_preview(self, mock_system_config, tmp_path, capsys):
        """--dry-run shows planned steps without executing."""
        _create_staging_site(mock_system_config, "acme")

        result = run_promote("acme", domain="acme.example.com", dry_run=True)
        assert result == 0

        captured = capsys.readouterr()
        assert "Dry run" in captured.out
        assert "Backup staging database" in captured.out
        assert "No changes made" in captured.out

    def test_dry_run_does_not_execute(self, mock_system_config, tmp_path):
        """--dry-run does not call any subprocess commands."""
        _create_staging_site(mock_system_config, "acme")

        with patch("subprocess.run") as mock_run, patch("subprocess.Popen"):
            result = run_promote("acme", domain="acme.example.com", dry_run=True)

        assert result == 0
        # No subprocess calls should have been made
        mock_run.assert_not_called()

    def test_dry_run_lists_all_steps(self, mock_system_config, tmp_path, capsys):
        """--dry-run lists all 11 promote steps."""
        _create_staging_site(mock_system_config, "acme")

        run_promote("acme", domain="acme.example.com", dry_run=True)

        captured = capsys.readouterr()
        # Should list numbered steps
        assert " 1." in captured.out
        assert "11." in captured.out


class TestPromoteConfirmation:
    """Tests for confirmation prompt."""

    def test_prompts_for_confirmation(
        self, monkeypatch, mock_system_config, tmp_path, capsys
    ):
        """Promote prompts user to type the slug to confirm."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: "wrong-slug")

        result = run_promote("acme", domain="acme.example.com")
        assert result == 1

        captured = capsys.readouterr()
        assert "Confirmation did not match" in captured.out

    def test_correct_confirmation_proceeds(
        self, monkeypatch, mock_system_config, tmp_path
    ):
        """Correct confirmation allows promote to proceed."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: "acme")

        # Mock all the subprocess calls that happen during promote
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/tmp/sum-promote-abcd1234\n"
        mock_result.stderr = ""

        with (
            patch("subprocess.run", return_value=mock_result),
            patch("subprocess.Popen") as mock_popen,
            patch.object(promote_module, "generate_password", return_value="testpw"),
            patch.object(promote_module, "generate_secret_key", return_value="testsk"),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=MagicMock(
                    get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git"
                ),
            ),
        ):
            # Mock Popen for pg_dump piped to gzip
            mock_pg_dump = MagicMock()
            mock_pg_dump.returncode = 0
            mock_pg_dump.stdout = MagicMock()
            mock_pg_dump.stderr = MagicMock()
            mock_pg_dump.stderr.read.return_value = b""
            mock_gzip = MagicMock()
            mock_gzip.communicate.return_value = (b"", b"")
            mock_gzip.returncode = 0
            mock_popen.side_effect = [mock_pg_dump, mock_gzip]

            result = run_promote("acme", domain="acme.example.com")

        # May fail at later stages, but not at confirmation
        # Exit code 0 or 1 acceptable (testing that confirmation passed, not full success)
        assert result in (0, 1)

    def test_skip_confirm_flag(self, monkeypatch, mock_system_config, tmp_path):
        """--confirm flag skips confirmation prompt."""
        _create_staging_site(mock_system_config, "acme")

        # Should NOT call input()
        def fail_input(_prompt):
            raise AssertionError("Should not prompt for confirmation")

        monkeypatch.setattr("builtins.input", fail_input)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/tmp/sum-promote-abcd1234\n"
        mock_result.stderr = ""

        with (
            patch("subprocess.run", return_value=mock_result),
            patch("subprocess.Popen") as mock_popen,
            patch.object(promote_module, "generate_password", return_value="testpw"),
            patch.object(promote_module, "generate_secret_key", return_value="testsk"),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=MagicMock(
                    get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git"
                ),
            ),
        ):
            mock_pg_dump = MagicMock()
            mock_pg_dump.returncode = 0
            mock_pg_dump.stdout = MagicMock()
            mock_pg_dump.stderr = MagicMock()
            mock_pg_dump.stderr.read.return_value = b""
            mock_gzip = MagicMock()
            mock_gzip.communicate.return_value = (b"", b"")
            mock_gzip.returncode = 0
            mock_popen.side_effect = [mock_pg_dump, mock_gzip]

            result = run_promote("acme", domain="acme.example.com", skip_confirm=True)

        # May fail at later stages, but not at confirmation
        # Exit code 0 or 1 acceptable (testing that confirmation was skipped, not full success)
        assert result in (0, 1)

    def test_keyboard_interrupt_aborts(self, monkeypatch, mock_system_config, tmp_path):
        """Ctrl+C during confirmation aborts gracefully."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr(
            "builtins.input", lambda _: (_ for _ in ()).throw(KeyboardInterrupt)
        )

        result = run_promote("acme", domain="acme.example.com")
        assert result == 130

    def test_eof_aborts(self, monkeypatch, mock_system_config, tmp_path):
        """EOF during confirmation aborts gracefully."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: (_ for _ in ()).throw(EOFError))

        result = run_promote("acme", domain="acme.example.com")
        assert result == 130


class TestPromoteSecureTempDir:
    """Tests for secure temp directory in backup transfer (SEC-04)."""

    def test_copy_backup_uses_mktemp(self, mock_system_config):
        """_copy_backup_to_prod creates a secure temp dir via mktemp."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/tmp/sum-promote-abcd1234\n"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            result = promote_module._copy_backup_to_prod(
                Path("/staging/backups/test.sql.gz"), mock_system_config
            )

        # Should contain the mktemp-created directory
        assert "sum-promote-" in result
        assert result.endswith("test.sql.gz")

        # First call should be mktemp
        first_call = mock_run.call_args_list[0]
        assert "mktemp" in first_call[0][0]

        # Second call should be chmod 700
        second_call = mock_run.call_args_list[1]
        assert "chmod" in second_call[0][0]
        assert "700" in second_call[0][0]


class TestPromoteGitTokenSanitization:
    """Tests for git token sanitization after clone (SEC-05)."""

    def test_token_never_in_command_args(self, mock_system_config, tmp_path):
        """Token is piped via stdin, never appears in any process command args."""
        _create_staging_site(mock_system_config, "acme")

        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = (
                "ghp_faketoken123\n" if cmd == ["gh", "auth", "token"] else ""
            )
            return result

        mock_provider = MagicMock(
            get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
            get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
        )
        mock_git_config = MagicMock()
        mock_git_config.provider = "github"
        mock_git_config.org = "testco"

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=mock_provider,
            ),
        ):
            promote_module._clone_repo_on_prod(
                "acme", mock_system_config, mock_git_config
            )

        # Token must NEVER appear in any command args (only in stdin)
        for call in calls:
            cmd_str = str(call["cmd"])
            if call["cmd"] != ["gh", "auth", "token"]:
                assert (
                    "ghp_faketoken123" not in cmd_str
                ), f"Token leaked into command args: {cmd_str}"

        # Token should be sent via stdin (input kwarg) exactly once
        stdin_calls = [
            c
            for c in calls
            if c["kwargs"].get("input") and "ghp_faketoken123" in c["kwargs"]["input"]
        ]
        assert len(stdin_calls) == 1, "Token should be piped via stdin exactly once"

    def test_remote_script_has_trap_cleanup(self, mock_system_config, tmp_path):
        """Remote script uses trap EXIT for unconditional ASKPASS cleanup."""
        _create_staging_site(mock_system_config, "acme")

        ssh_commands = []

        def capture_run(cmd, *args, **kwargs):
            if isinstance(cmd, list) and cmd[0] == "ssh":
                ssh_commands.append(cmd[-1])  # The remote script string
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = (
                "ghp_faketoken123\n" if cmd == ["gh", "auth", "token"] else ""
            )
            return result

        mock_provider = MagicMock(
            get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
            get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
        )
        mock_git_config = MagicMock()
        mock_git_config.provider = "github"
        mock_git_config.org = "testco"

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=mock_provider,
            ),
        ):
            promote_module._clone_repo_on_prod(
                "acme", mock_system_config, mock_git_config
            )

        # First SSH command is the combined clone script
        assert len(ssh_commands) >= 1
        script = ssh_commands[0]

        # Script must include trap for unconditional cleanup
        assert "trap" in script, "Remote script must use trap for cleanup"
        assert "rm -f" in script, "Trap must remove ASKPASS file"
        assert "EXIT" in script, "Trap must fire on EXIT"

        # Script must include clone and set-url in the same call
        assert "git clone" in script
        assert "set-url" in script
        assert "git@github.com" in script

    def test_clone_failure_raises_setup_error(self, mock_system_config, tmp_path):
        """Clone failure raises SetupError with stderr details."""
        _create_staging_site(mock_system_config, "acme")

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            if cmd == ["gh", "auth", "token"]:
                result.stdout = "ghp_faketoken123\n"
                return result
            # SSH call with the remote script → fail
            if isinstance(cmd, list) and cmd[0] == "ssh":
                raise subprocess.CalledProcessError(
                    128, cmd, stderr="fatal: repo not found"
                )
            result.stdout = ""
            return result

        mock_provider = MagicMock(
            get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
            get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
        )
        mock_git_config = MagicMock()
        mock_git_config.provider = "github"
        mock_git_config.org = "testco"

        from sum.exceptions import SetupError

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=mock_provider,
            ),
            pytest.raises(SetupError, match="clone"),
        ):
            promote_module._clone_repo_on_prod(
                "acme", mock_system_config, mock_git_config
            )


class TestPromoteClickCommand:
    """Tests for the click command wiring."""

    def test_click_command_exists(self):
        """The promote click command is registered."""
        from sum.commands.promote import promote

        assert callable(promote)

    def test_click_command_has_dry_run_flag(self):
        """The promote command has --dry-run flag."""
        import click
        from sum.commands.promote import promote

        if isinstance(promote, click.BaseCommand):
            param_names = [p.name for p in promote.params]
            assert "dry_run" in param_names

    def test_click_command_has_confirm_flag(self):
        """The promote command has --confirm flag."""
        import click
        from sum.commands.promote import promote

        if isinstance(promote, click.BaseCommand):
            param_names = [p.name for p in promote.params]
            assert "skip_confirm" in param_names

    def test_click_command_has_domain_option(self):
        """The promote command has --domain option."""
        import click
        from sum.commands.promote import promote

        if isinstance(promote, click.BaseCommand):
            param_names = [p.name for p in promote.params]
            assert "domain" in param_names

    def test_promote_registered_in_cli(self):
        """Promote command is registered in main CLI group."""
        from sum.cli import cli

        command_names = list(cli.commands.keys())
        assert "promote" in command_names
