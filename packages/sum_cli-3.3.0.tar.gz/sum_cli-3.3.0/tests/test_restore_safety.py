"""Regression tests for restore command safety (DATA-01, H-06)."""

from __future__ import annotations

from importlib import import_module
from unittest.mock import MagicMock, patch

import pytest
from sum.exceptions import SetupError
from sum.system_config import reset_system_config

restore_module = import_module("sum.commands.restore")


@pytest.fixture(autouse=True)
def reset_config():
    reset_system_config()
    yield
    reset_system_config()


class TestPreRestoreProtection:
    """DATA-01: Protect pre-restore backup from destruction on retry."""

    def test_refuses_delete_when_main_data_missing(self, tmp_path):
        """If .pre-restore exists but main data doesn't, refuse to delete backup."""
        config = MagicMock()
        site_slug = "testsite"
        data_dir = tmp_path / site_slug
        backup_dir = tmp_path / f"{site_slug}.pre-restore"
        backup_dir.mkdir()
        # data_dir does NOT exist

        with patch.object(restore_module, "_get_data_dir", return_value=data_dir):
            with pytest.raises(SetupError, match="Pre-restore backup exists"):
                restore_module._backup_current_data(site_slug, config)

    def test_allows_delete_with_force_flag(self, tmp_path):
        """With --force, allows deleting pre-restore backup even without main data."""
        config = MagicMock()
        site_slug = "testsite"
        data_dir = tmp_path / site_slug
        backup_dir = tmp_path / f"{site_slug}.pre-restore"
        backup_dir.mkdir()
        # data_dir does NOT exist

        with (
            patch.object(restore_module, "_get_data_dir", return_value=data_dir),
            patch("subprocess.run") as mock_run,
        ):
            result = restore_module._backup_current_data(site_slug, config, force=True)
            assert result is None  # No data to back up
            assert not backup_dir.exists()  # Old backup was removed

            # Verify that the force flag allowed cleanup without data
            # chown command was called on the backup_dir before deletion
            assert mock_run.call_count >= 1
            chown_calls = [
                c for c in mock_run.call_args_list if "chown" in str(c[0][0])
            ]
            assert len(chown_calls) >= 1

    def test_safe_when_both_exist(self, tmp_path):
        """When both data and pre-restore exist, safe to remove old backup."""
        config = MagicMock()
        site_slug = "testsite"
        data_dir = tmp_path / site_slug
        data_dir.mkdir()
        (data_dir / "dummy").write_text("data")
        backup_dir = tmp_path / f"{site_slug}.pre-restore"
        backup_dir.mkdir()

        with (
            patch.object(restore_module, "_get_data_dir", return_value=data_dir),
            patch("subprocess.run"),
        ):
            result = restore_module._backup_current_data(site_slug, config)
            assert result == backup_dir
            # Data was moved to backup_dir, then an empty data_dir was recreated
            assert backup_dir.exists()  # Now contains the data
            assert (backup_dir / "dummy").exists()  # Moved file present


class TestRestoreSlugValidation:
    """SEC-03: validate_site_slug() is called in run_restore()."""

    def test_rejects_invalid_slug(self, capsys):
        result = restore_module.run_restore("../bad", use_latest=True)
        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out


class TestRestoreBackupVerification:
    """H-06: Verify backup exists before stopping cluster for restore."""

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_restore_fails_when_no_backups(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        capsys,
    ):
        """Restore returns error when no backups are available."""
        mock_config.return_value = MagicMock()
        mock_info.return_value = ""  # Empty output = no backups

        result = restore_module.run_restore("acme", use_latest=True, skip_confirm=True)
        assert result == 1
        captured = capsys.readouterr()
        assert "No backups available" in captured.out
