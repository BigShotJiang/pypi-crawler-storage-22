# TODO

- [] add relevant logs in the whole repo
- [] implement real tests for all scenarios (i.e. multiturn, tool calls...) for all models once before each release
