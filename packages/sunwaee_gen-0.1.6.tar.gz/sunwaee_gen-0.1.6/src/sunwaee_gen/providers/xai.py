# standard
# third party
# custom
from sunwaee_gen.provider import Provider


XAI = Provider(
    name="xai",
    url="https://api.x.ai/v1/chat/completions",
)
