# CHANGELOG

## 2026-02-01 - 0.1.7

- added: useful logs (`SUNWAEE_LOG_LEVEL=DEBUG`)
- added: actual test `run` folder (runs multiple scenarios for at least one agent per provider)
- added: reasoning_content for deepseek reasoner to pass back reasoning
- added: thoughtSignature for gemini models to pass back signatures
- added: thinking for claude models to pass back thinking + signature
- added: gemini summarized thinking for gemini 2.5 and 3 (includeThoughts=True)

- changed: big refactoring
- changed: requirements for sdk to be limited to (aiohttp, pydantic) and api to (+fastapi, +uvicorn)

- fixed: passing reasoning_content works for all providers
- fixed: system prompt only requests for gemini and claude

## 2026-01-28 - 0.1.6

- added: grok 4.1 fast non reasoning

## 2026-01-27 - 0.1.5

- changed: gpt 4.1 pricing

## 2026-01-20 - 0.1.4

- added: mocked completions with mock=True + coverage

- changed: mocked responses cost to be 0.0

- fixed: mocked throughput missing

## 2026-01-13 - 0.1.1

- fixed: anthropic completion tokens and throughput

## 2026-01-13 - 0.1.0

- fixed: imports to use sunwaee_gen
- fixed: version naming

## 2026-01-13 - 0.0.17

- added: `CHANGELOG.md` and `TODO.md` to track releases and changes

- changed: anthropic messages adapter to work with tool use and tool result

- fixed: use of src.sunwaee_gen rather than sunwaee_gen in imports of the whole repo

- removed: anthropic models reasoning as API for claude 4 and later with thinking + tool use is absolutely disgusting
