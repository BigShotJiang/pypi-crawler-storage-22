import json
import dotenv
import asyncio

dotenv.load_dotenv(dotenv.find_dotenv())

from sunwaee_gen import async_completion, Agent, Agents

streamings: list[bool] = [
    False,
    True,
]

agents: list[Agent] = [
    ## OK
    Agents.CLAUDE_4_5_HAIKU,  # NOTE thinking + signature
    Agents.DEEPSEEK_CHAT,
    Agents.DEEPSEEK_REASONER,  # NOTE reasoning_content
    Agents.GEMINI_3_FLASH_PREVIEW,  # NOTE thoughtSignature
    Agents.GEMINI_2_5_FLASH,  # NOTE thoughtSignature
    Agents.GPT_5_MINI,
    Agents.GROK_4_1_FAST_REASONING,
]

scenarios: dict[str, list[dict]] = {
    "ONLY_SYSTEM": [
        {
            "role": "system",
            "content": "Respond with 'ok'.",
        }
    ],
    "ONLY_USER": [
        {
            "role": "user",
            "content": "Respond with 'ok'.",
        }
    ],
    "COMPLEX": [
        {
            "role": "user",
            "content": "Tell me about nuclear fusion from your own knowledge.",
        }
    ],
    "SYSTEM_AND_USER": [
        {
            "role": "system",
            "content": "Start all your answers with <START>.",
        },
        {
            "role": "user",
            "content": "Respond with 'ok'",
        },
    ],
    "TOOL_CALL": [
        {
            "role": "user",
            "content": "update this chat name to 'Test Chat'",
        }
    ],
    "TOOL_CALL_RESULT": [
        {
            "role": "user",
            "content": "update this Chat name to 'Test Chat'",
        },
        {
            "role": "assistant",
            "content": "",
            # NOTE deepseek reasoner or OpenAI compatible models
            # "reasoning_content": "I will call the update_chat tool.",
            # NOTE gemini: reasoning_signature -> thoughtSignature
            # "reasoning_signature": "ErsBCrgBAXLI2nw1imFQKoOEAlzRczX4nxtNt8xBvj0wP6sqGut5m59PGDGqExrghHfqux9ZV/4EZ7GnR3z2s+dZDT7CEr0sPRnykmcsTrsqiRPqitZjNKDH4Wtqbb/UjIyxTZK3tXa43jcyKXyRSbWsooVdmECgTNy+7rJZ+oZ51kBwrvSv1ZfUX0jntfNXEEQot9Sxxc5XkXtRaow2DuCKvyGpBS6/C9UD5dfQWHUJz0EKlrZoXSaBYaDPiA==",
            # NOTE claude: reasoning_content -> thinking, reasoning_signature -> signature
            # "reasoning_content": "The user wants to update the chat name to 'Test Chat'. I have the `update_chat` function available which takes a `title` parameter. The user has provided the specific title they want: 'Test Chat'. I should use this exact value.\n\nI have all the required parameters, so I can proceed with the function call.",
            # "reasoning_signature": "EtoDCkYICxgCKkAK5CdwPz11XPu+QdxnaDZIP2/vnoLz5YdVzf4FK68A9Fk1bt7RQVtn5ba3o4tSUFsgB9AB+VogI3MPZO+C5BU9Egw1tb81X1wEDVcIK3EaDFEbxvHOfTxJFMO5VSIw/dAHMxnNdRA9fx77urY0aD7tFD2rHwr4zubEIwTqAvlMbxSTVlXSRioZvfT2e7qnKsECIgnuQXEJuWBjldkcDdTTr3JFfl5kDvFbcJPxFs9m9eDPRdvXOrgYiKzvbCoWHL7GiR3Gm0QWCV2oXVDMcO0C3+2ebmrSv5e7JjfBKtbq+k3DcazomHd8MuWouz0ojM55Aufy27iH+3rl1q/TrNKt4G431hPEz4BhrjipW2Qn157yi87GOqUKHWWefaKaPrQbZ0h2e5OMwVx932EtO7j3V4PznWd+E2U2Ah0zyZQBXQ/99pV0pv3px2gMRdQt6vH8P8Swa/du9SQ+WZHgGckc5EkFwXIF9DW8ib/Ec3lKFL97coqj35ZpJWP/z+fcbMsCS9efqQlSJST1Z4rsqB6qtzyntAQiDuPRHIRRKeENYG+iVHtuB4D8HaWCDs3ZygQZj6gEEKay1asqfLahc0XL3Tbcd7W1P4fOxmIN05SBVaaxGAE=",
            "tool_calls": [
                {
                    "id": "tc_1234567890",
                    "type": "function",
                    "function": {
                        "name": "update_chat",
                        "arguments": '{"title": "Test Chat"}',
                    },
                }
            ],
        },
        {
            "role": "tool",
            "content": '[{"before": "New Chat", "after": "Test Chat"}]',
            "tool_call_id": "tc_1234567890",
        },
    ],
}

tools = [
    {
        "type": "function",
        "function": {
            "name": "update_chat",
            "description": "Upchat the current chat title.",
            "parameters": {
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "The new chat title.",
                    }
                },
                "required": ["title"],
            },
        },
    }
]


async def run():

    for streaming in streamings:

        for agent in agents:

            for scenario_name, scenario_messages in scenarios.items():

                blocks = []
                async for block in async_completion(
                    agent=agent,
                    messages=scenario_messages,
                    streaming=streaming,
                    tools=tools,
                ):
                    blocks.append(block)

                with open(
                    f"run/{'streaming' if streaming else 'non-streaming'}/{agent.model.name}_{scenario_name}.json",
                    "w",
                ) as run:
                    run.write(json.dumps(blocks, indent=2))


if __name__ == "__main__":
    asyncio.run(run())
