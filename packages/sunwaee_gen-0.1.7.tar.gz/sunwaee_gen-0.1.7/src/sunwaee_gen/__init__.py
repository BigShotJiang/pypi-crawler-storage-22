# standard
import json

# third party
# custom
from sunwaee_gen.agents import Agents
from sunwaee_gen.models import Models
from sunwaee_gen.providers import Providers
from sunwaee_gen.tools import TOOLS

from sunwaee_gen.agent import Agent
from sunwaee_gen.message import Message
from sunwaee_gen.model import Model
from sunwaee_gen.provider import Provider
from sunwaee_gen.response import Response
from sunwaee_gen.tool import Tool, T
from sunwaee_gen.logger import logger


async def async_completion(
    agent: str | Agent,
    messages: list[dict],
    tools: list[dict] | None = None,
    streaming: bool = False,
    api_key: str | None = None,
    mock: bool = False,
):
    # check agent existence
    if isinstance(agent, str):
        agent_obj = Agents.get(key=agent)
    else:
        agent_obj = agent
    logger.debug(
        f"agent is:\n{json.dumps(agent_obj.model_dump(mode='json'), indent=2)}"
    )

    # validate messages, including roles, tool calls and tool results
    _ = Message.from_list(messages)

    # validate tools
    _ = Tool.from_list(tools) if tools else None

    async for block in agent_obj.async_completion(
        messages=messages,
        tools=tools,
        streaming=streaming,
        api_key=api_key,
        mock=mock,
    ):
        yield block
