# standard
import uuid
import json
import time
import asyncio

# third party
import aiohttp
import pydantic

# custom
from sunwaee_gen.dummy import dummy_response_content, dummy_response_reasoning
from sunwaee_gen.model import Model
from sunwaee_gen.provider import Provider
from sunwaee_gen.response import Cost, Error, Performance, Response, Usage
from sunwaee_gen.helpers import get_nested_dict_value
from sunwaee_gen.logger import logger


class AgentCost(pydantic.BaseModel):
    input_per_1m_token: float
    output_per_1m_token: float

    @pydantic.computed_field()
    def input_per_token(self) -> float:
        return self.input_per_1m_token / 1_000_000

    @pydantic.computed_field()
    def output_per_token(self) -> float:
        return self.output_per_1m_token / 1_000_000


class AgentFeatures(pydantic.BaseModel):
    supports_tools: bool = False
    supports_reasoning: bool = False
    reasoning_tokens_access: bool = False


class AgentSpecs(pydantic.BaseModel):
    max_input_tokens: int
    max_output_tokens: int


class Agent(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(
        arbitrary_types_allowed=True,  # Model and Provider custom
        extra="allow",  # allows testing/mocking
    )

    name: str
    model: Model
    provider: Provider

    cost: AgentCost
    features: AgentFeatures
    specs: AgentSpecs

    async def async_completion(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        streaming: bool = False,
        api_key: str | None = None,
        mock: bool = False,
    ):

        url: str = self.provider.url

        # NOTE google you weirdos..
        if "<|model_name|>" in url:
            url = url.replace("<|model_name|>", self.model.name)
        if "<|gen_method|>" in url:
            url = url.replace(
                "<|gen_method|>",
                "streamGenerateContent" if streaming else "generateContent",
            )
        logger.debug(f"url is: `{url}`")

        # --- HEADERS

        headers: dict = self.provider.headers_adapter(
            provider=self.provider.name,
            api_key=api_key,
        )

        # --- PAYLOAD

        model: str = self.model.name
        if self.model.version:
            model += f"-{self.model.version}"
        logger.debug(f"model id is: `{model}`")

        system_prompt: str | None = None
        if messages[0].get("role") == "system":
            system_prompt = messages[0].get("content")
            messages = messages[1:]
        logger.debug(f"system prompt is: `{system_prompt}`")

        messages = self.provider.messages_adapter(
            system_prompt=system_prompt,
            messages=messages,
        )
        logger.debug(f"messages are:\n{json.dumps(messages, indent=2, default=str)}")

        if self.features.supports_tools and tools:
            tools = self.provider.tools_adapter(tools=tools)
        logger.debug(f"tools are:\n{json.dumps(tools, indent=2, default=str)}")

        payload: dict = self.provider.payload_adapter(
            model=model,
            system_prompt=system_prompt,
            messages=messages,
            tools=tools,
            max_tokens=self.specs.max_output_tokens,
            streaming=streaming,
        )
        logger.debug(f"payload is:\n{json.dumps(payload, indent=2, default=str)}")
        logger.debug(f"mock is: `{mock}`")

        if streaming:

            if mock:  # pragma: no cover
                async for block in self._mock_async_stream_completion():
                    yield block
            else:
                async for block in self._async_stream_completion(url, headers, payload):
                    yield block
        else:

            if mock:  # pragma: no cover
                yield await self._mock_async_completion()
            else:
                yield await self._async_completion(url, headers, payload)

    # --- REGULAR

    async def _async_completion(self, url: str, headers: dict, payload: dict):

        # vars
        start: float = time.time()

        latency: float = 0.0
        reasoning_duration: float = 0.0
        content_duration: float = 0.0
        total_duration: float = 0.0
        throughput: int = 0

        raw: str = ""
        reasoning: str = ""
        reasoning_signature: str = ""
        content: str = ""
        tool_calls: list[dict] = []

        prompt_tokens: int = 0
        completion_tokens: int = 0
        total_tokens: int = 0

        prompt_cost: float = 0.0
        completion_cost: float = 0.0
        total_cost: float = 0.0

        adapter: dict = self.provider.response_adapter()

        tool_call_ids: list[str] = []
        tool_call_names: list[str] = []
        tool_call_arguments: list[dict] = []

        # NOTE timeout config
        timeout: aiohttp.ClientTimeout = aiohttp.ClientTimeout(
            total=None,
            sock_connect=10,  # only when we establish connection
            sock_read=None,
        )

        async with aiohttp.ClientSession(timeout=timeout) as session:
            try:
                async with session.post(
                    url,
                    headers=headers,
                    json=payload,
                ) as response:

                    # NOTE handle error
                    if response.status != 200:
                        error_message = await response.text()

                        return Response(
                            model=self.model,
                            provider=self.provider,
                            error=Error(
                                status_code=response.status, message=error_message
                            ),
                            streaming=False,
                        ).model_dump(mode="json")

                    data: dict = await response.json()
                    latency = time.time() - start

                    logger.debug(data)

                    # reasoning
                    if r := get_nested_dict_value(
                        data=data,
                        path=adapter.get("reasoning", ""),
                    ):
                        if isinstance(r, str):
                            reasoning = r
                        else:  # pragma: no cover
                            logger.warning(f"r of type {type(r)}: {r}")

                    # reasoning signature
                    if rs := get_nested_dict_value(
                        data=data,
                        path=adapter.get("reasoning_signature", ""),
                    ):
                        if isinstance(rs, str):
                            reasoning_signature = rs
                        else:
                            logger.warning(f"rs of type {type(rs)}: {r}")

                    # content
                    if c := get_nested_dict_value(
                        data=data,
                        path=adapter.get("content", ""),
                    ):
                        if isinstance(c, str):
                            content = c
                        else:  # pragma: no cover
                            logger.warning(f"c of type {type(c)}: {c}")

                    # tool call ids (optional as there is a uuid fallback)
                    if tcid := get_nested_dict_value(
                        data=data,
                        path=adapter.get("tool_call_id", ""),
                    ):
                        if isinstance(tcid, str):  # pragma: no cover
                            tool_call_ids = [tcid]
                        elif isinstance(tcid, list):
                            tool_call_ids = tcid
                        else:  # pragma: no cover
                            logger.warning(f"tcid of type {type(tcid)}: {tcid}")

                    # tool call names
                    if tcn := get_nested_dict_value(
                        data=data,
                        path=adapter.get("tool_call_name", ""),
                    ):
                        if isinstance(tcn, str):  # pragma: no cover
                            tool_call_names = [tcn]
                        elif isinstance(tcn, list):
                            tool_call_names = tcn
                        else:  # pragma: no cover
                            logger.warning(f"tcn of type {type(tcn)}: {tcn}")

                    # tool call arguments
                    if tca := get_nested_dict_value(
                        data=data,
                        path=adapter.get("tool_call_arguments", ""),
                    ):
                        if isinstance(tca, str):  # pragma: no cover
                            tool_call_arguments = [json.loads(tca)]
                        elif isinstance(tca, dict):  # pragma: no cover
                            tool_call_arguments = [tca]
                        elif isinstance(tca, list):
                            tool_call_arguments = [json.loads(t) for t in tca]
                        else:  # pragma: no cover
                            logger.warning(f"tca of type {type(tca)}: {tca}")

                    # prompt tokens
                    if pt := get_nested_dict_value(
                        data=data,
                        path=adapter.get("prompt_tokens", ""),
                    ):
                        if isinstance(pt, int):
                            prompt_tokens = pt
                        else:  # pragma: no cover
                            logger.warning(f"pt of type {type(pt)}: {pt}")

                    # completion tokens
                    if ct := get_nested_dict_value(
                        data=data,
                        path=adapter.get("completion_tokens", ""),
                    ):
                        if isinstance(ct, int):
                            completion_tokens = ct
                        else:  # pragma: no cover
                            logger.warning(f"ct of type {type(ct)}: {ct}")

                    # total tokens (optional as there is a sum fallback)
                    if tt := get_nested_dict_value(
                        data=data,
                        path=adapter.get("total_tokens", ""),
                    ):
                        if isinstance(tt, int):
                            total_tokens = tt
                        else:  # pragma: no cover
                            logger.warning(f"tt of type {type(tt)}: {tt}")

            except asyncio.TimeoutError:
                return Response(
                    model=self.model,
                    provider=self.provider,
                    error=Error(status_code=400, message="timeout"),
                    streaming=False,
                ).model_dump(mode="json")

        # tool calls
        if tool_call_names:
            for i, name in enumerate(tool_call_names):
                if name:
                    tool_call = {
                        "id": (
                            tool_call_ids[i]
                            if i < len(tool_call_ids)
                            else str(uuid.uuid4())  # NOTE uuid fallback
                        ),
                        "name": name,
                        "arguments": tool_call_arguments[i],
                    }
                    tool_calls.append(tool_call)

        # raw
        if reasoning:
            raw += f"<think>{reasoning}</think>"
        if content:
            raw += content
        if tool_calls:
            for tc in tool_calls:
                raw += f"<tool_call>{json.dumps(tc)}</tool_call>"

        # NOTE compute durations proportionnally to the output
        raw_length: int = len(raw)
        if raw_length > 0 and latency > 0:
            if reasoning:
                reasoning_duration = (len(reasoning) / raw_length) * latency
            if content:
                content_duration = (len(content) / raw_length) * latency

        # perf
        total_tokens = total_tokens or (prompt_tokens + completion_tokens)
        total_duration = latency
        if total_duration:
            throughput = int(completion_tokens / total_duration)

        # NOTE cannot use input_per_token() as it is a computed_field
        prompt_cost = prompt_tokens * self.cost.input_per_token
        completion_cost = completion_tokens * self.cost.output_per_token
        total_cost = prompt_cost + completion_cost

        return Response(
            model=self.model,
            provider=self.provider,
            streaming=False,
            reasoning=reasoning,
            reasoning_signature=reasoning_signature,
            content=content,
            tool_calls=tool_calls,
            raw=raw,
            usage=Usage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
            ),
            cost=Cost(
                prompt_cost=prompt_cost,
                completion_cost=completion_cost,
                total_cost=total_cost,
            ),
            performance=Performance(
                latency=latency,
                reasoning_duration=reasoning_duration,
                content_duration=content_duration,
                total_duration=total_duration,
                throughput=throughput,
            ),
        ).model_dump(mode="json")

    async def _mock_async_completion(self):  # pragma: no cover
        return Response(
            model=self.model,
            provider=self.provider,
            error=Error(),
            usage=Usage(
                prompt_tokens=314,
                completion_tokens=314,
                total_tokens=628,
            ),
            cost=Cost(
                prompt_cost=0.0,
                completion_cost=0.0,
                total_cost=0.0,
            ),
            performance=Performance(
                latency=3.14,
                reasoning_duration=3.14,
                content_duration=3.14,
                total_duration=6.28,
                throughput=314,
            ),
            reasoning=dummy_response_reasoning,
            content=dummy_response_content,
            tool_calls=[],
            raw=f"<think>{dummy_response_reasoning}</think>{dummy_response_content}",
            streaming=False,
        ).model_dump(mode="json")

    # --- STREAMING

    async def _async_stream_completion(self, url: str, headers: dict, payload: dict):

        # just making the main code easier to read
        async def sse_data(sse_stream, is_google_trash_format: bool = False):
            buffer: str = ""
            async for line in sse_stream.content:
                if line:
                    decoded_line: str = line.decode("utf-8")
                    # the folks from google doing garbage as usual...
                    # accumulate chars until we reach a json decodable str...
                    # not really resilient but hey google small indie company...
                    if is_google_trash_format:
                        if decoded_line.rstrip() == "[{":
                            buffer = "{"
                        elif decoded_line.rstrip() == ",":
                            buffer = ""
                        # NOTE not needed as json loading succeeds before
                        # elif decoded_line.rstrip() == "]":
                        #     buffer = ""
                        else:
                            buffer += decoded_line
                            try:
                                yield json.loads(buffer)
                            except json.JSONDecodeError:  # pragma: no cover
                                pass
                    else:
                        if decoded_line.startswith("data:"):
                            try:
                                yield json.loads(decoded_line[len("data:") :])
                            except json.JSONDecodeError:  # pragma: no cover
                                pass
                        else:  # NOTE can be errors etc
                            try:
                                yield json.loads(decoded_line)
                            except json.JSONDecodeError:  # pragma: no cover
                                pass

        start = time.time()

        # vars
        latency = 0.0
        reasoning_start = None
        reasoning_duration = None
        content_start = None
        content_duration = None
        total_duration: float = 0.0
        throughput: int = 0

        raw: str = ""
        reasoning: str = ""
        reasoning_signature: str = ""
        content: str = ""
        tool_calls: list[dict] = []

        prompt_tokens: int = 0
        completion_tokens: int = 0
        total_tokens: int = 0

        prompt_cost: float = 0.0
        completion_cost: float = 0.0
        total_cost: float = 0.0

        tool_call: dict[str, str] = {"id": "", "name": "", "arguments": ""}

        # NOTE for models without access to reasoning tokens, we start the timer
        # as the requests starts as we have no more accurate approach
        if (
            self.features.supports_reasoning
            and not self.features.reasoning_tokens_access
        ):
            reasoning_start = time.time()
            yield Response(
                model=self.model,
                provider=self.provider,
                streaming=True,
                reasoning="reasoning started, but reasoning tokens are not available for this model...",
            ).model_dump(mode="json")

        sse_adapter: dict = self.provider.sse_adapter()

        # NOTE timeout config
        timeout: aiohttp.ClientTimeout = aiohttp.ClientTimeout(
            total=None,
            sock_connect=10,  # only when we establish connection
            sock_read=None,
        )

        # make it async
        async with aiohttp.ClientSession(timeout=timeout) as session:

            try:

                async with session.post(
                    url,
                    headers=headers,
                    json=payload,
                ) as sse_stream:

                    async for data in sse_data(
                        sse_stream=sse_stream,
                        is_google_trash_format=(self.provider.name == "google"),
                    ):
                        logger.debug(
                            f"sse stream data is:\n{json.dumps(data, indent=2)}"
                        )

                        # latency at first fragment
                        if not latency:
                            latency = time.time() - start

                        # check for errors
                        if "error" in data:
                            error = data["error"]
                            status_code = (
                                error.get("code")
                                or error.get("status_code")
                                or error.get("status")
                                or 400
                            )
                            message = error.get("message") or "something went wrong"

                            yield Response(
                                model=self.model,
                                provider=self.provider,
                                streaming=True,
                                error=Error(
                                    status_code=status_code,
                                    message=message,
                                ),
                            ).model_dump(mode="json")

                            return

                        # reasoning
                        if r := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("reasoning", ""),
                        ):
                            if isinstance(r, str):
                                # start reasoning timer
                                if reasoning_start is None:
                                    reasoning_start = time.time()
                                reasoning += r
                                yield Response(
                                    model=self.model,
                                    provider=self.provider,
                                    streaming=True,
                                    reasoning=r,
                                ).model_dump(mode="json")
                            else:  # pragma: no cover
                                logger.warning(f"r of type {type(r)}: {r}")

                        # reasoning signature
                        if rs := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("reasoning_signature", ""),
                        ):
                            if isinstance(rs, str):
                                reasoning_signature = rs
                                yield Response(
                                    model=self.model,
                                    provider=self.provider,
                                    streaming=True,
                                    reasoning_signature=reasoning_signature,
                                ).model_dump(mode="json")
                            else:  # pragma: no cover
                                logger.warning(f"rs of type {type(rs)}: {rs}")

                        # content
                        if c := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("content", ""),
                        ):
                            if isinstance(c, str):
                                # start content timer
                                if content_start is None:
                                    content_start = time.time()
                                # end reasoning timer
                                if reasoning_start is not None:
                                    reasoning_duration = time.time() - reasoning_start
                                    reasoning_start = None
                                    yield Response(
                                        model=self.model,
                                        provider=self.provider,
                                        streaming=True,
                                        performance=Performance(
                                            reasoning_duration=reasoning_duration,
                                        ),
                                    ).model_dump(mode="json")
                                content += c
                                yield Response(
                                    model=self.model,
                                    provider=self.provider,
                                    streaming=True,
                                    content=c,
                                ).model_dump(mode="json")
                            else:  # pragma: no cover
                                logger.warning(f"c of type {type(c)}: {c}")

                        # tool call name
                        if tn := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("tool_call_name", ""),
                        ):
                            if isinstance(tn, str):
                                # end content timer
                                if content_start is not None:
                                    content_duration = time.time() - content_start
                                    content_start = None
                                    yield Response(
                                        model=self.model,
                                        provider=self.provider,
                                        streaming=True,
                                        performance=Performance(
                                            content_duration=content_duration,
                                        ),
                                    ).model_dump(mode="json")
                                # end reasoning timer
                                if reasoning_start is not None:
                                    reasoning_duration = time.time() - reasoning_start
                                    reasoning_start = None
                                    yield Response(
                                        model=self.model,
                                        provider=self.provider,
                                        streaming=True,
                                        performance=Performance(
                                            reasoning_duration=reasoning_duration,
                                        ),
                                    ).model_dump(mode="json")
                                tool_call = {"id": "", "name": "", "arguments": ""}
                                tool_call["name"] = tn
                            else:  # pragma: no cover
                                logger.warning(f"tn of type {type(tn)}: {tn}")

                        # tool call id
                        if tid := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("tool_call_id", ""),
                        ):
                            if isinstance(tid, str):
                                tool_call["id"] = tid
                            else:  # pragma: no cover
                                logger.warning(f"tid of type {type(tid)}: {tid}")

                        # tool call arguments
                        if ta := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("tool_call_arguments", ""),
                        ):
                            if isinstance(ta, str):
                                tool_call["arguments"] += ta

                                try:
                                    tool_call_final = {
                                        "id": (
                                            tool_call["id"]
                                            if tool_call["id"]
                                            else f"tc_{str(uuid.uuid4())}"
                                        ),
                                        "name": tool_call["name"],
                                        "arguments": json.loads(tool_call["arguments"]),
                                    }

                                    tool_calls.append(tool_call_final)
                                    yield Response(
                                        model=self.model,
                                        provider=self.provider,
                                        streaming=True,
                                        tool_calls=[tool_call_final],
                                    ).model_dump(mode="json")

                                    # reset after yield
                                    tool_call = {"id": "", "name": "", "arguments": ""}
                                except json.JSONDecodeError:  # pragma: no cover
                                    pass
                            elif isinstance(ta, dict):
                                tool_call_final = {
                                    "id": (
                                        tool_call["id"]
                                        if tool_call["id"]
                                        else f"tc_{str(uuid.uuid4())}"
                                    ),
                                    "name": tool_call["name"],
                                    "arguments": ta,
                                }

                                tool_calls.append(tool_call_final)
                                yield Response(
                                    model=self.model,
                                    provider=self.provider,
                                    streaming=True,
                                    tool_calls=[tool_call_final],
                                ).model_dump(mode="json")

                                # reset after yield
                                tool_call = {"id": "", "name": "", "arguments": ""}
                            else:  # pragma: no cover
                                logger.warning(f"ta of type {type(ta)}: {ta}")

                        # prompt tokens
                        if pt := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("prompt_tokens", ""),
                        ):
                            if isinstance(pt, int):
                                prompt_tokens = pt
                            else:  # pragma: no cover
                                logger.warning(f"pt of type {type(pt)}: {pt}")

                        # completion tokens
                        if ct := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("completion_tokens", ""),
                        ):
                            if isinstance(ct, int):
                                completion_tokens = ct
                            else:  # pragma: no cover
                                logger.warning(f"ct of type {type(ct)}: {ct}")

                        # total tokens
                        if tt := get_nested_dict_value(
                            data=data,
                            path=sse_adapter.get("total_tokens", ""),
                        ):
                            if isinstance(tt, int):
                                total_tokens = tt
                            else:  # pragma: no cover
                                logger.warning(f"tt of type {type(tt)}: {tt}")

            except asyncio.TimeoutError:
                yield Response(
                    model=self.model,
                    provider=self.provider,
                    error=Error(status_code=400, message="timeout"),
                    streaming=False,
                ).model_dump(mode="json")
                return

        # end content timer
        if content_start is not None:
            content_duration = time.time() - content_start
            content_start = None
            yield Response(
                model=self.model,
                provider=self.provider,
                streaming=True,
                performance=Performance(
                    content_duration=content_duration,
                ),
            ).model_dump(mode="json")
        # end reasoning timer
        if reasoning_start is not None:
            reasoning_duration = time.time() - reasoning_start
            reasoning_start = None
            yield Response(
                model=self.model,
                provider=self.provider,
                streaming=True,
                performance=Performance(
                    reasoning_duration=reasoning_duration,
                ),
            ).model_dump(mode="json")

        # build raw
        if reasoning:
            raw += f"<think>{reasoning}</think>"
        if content:
            raw += content
        if tool_calls:
            for tc in tool_calls:
                raw += f"<tool_call>{json.dumps(tc)}</tool_call>"

        # perf
        total_tokens = total_tokens or (prompt_tokens + completion_tokens)
        total_duration = (content_duration or 0.0) + (reasoning_duration or 0.0)
        if total_duration:
            throughput = int(completion_tokens / total_duration)

        # cost
        prompt_cost = prompt_tokens * self.cost.input_per_token
        completion_cost = completion_tokens * self.cost.output_per_token
        total_cost = prompt_cost + completion_cost

        yield Response(
            model=self.model,
            provider=self.provider,
            streaming=True,
            raw=raw,
            usage=Usage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
            ),
            cost=Cost(
                prompt_cost=prompt_cost,
                completion_cost=completion_cost,
                total_cost=total_cost,
            ),
            performance=Performance(
                latency=latency,
                reasoning_duration=reasoning_duration or 0.0,
                content_duration=content_duration or 0.0,
                total_duration=total_duration,
                throughput=throughput,
            ),
        ).model_dump(mode="json")

    async def _mock_async_stream_completion(self):  # pragma: no cover
        chunk_size: int = 20

        # chunks
        reasoning_chunks = [
            dummy_response_reasoning[i : i + chunk_size]
            for i in range(0, len(dummy_response_reasoning), chunk_size)
        ]
        content_chunks = [
            dummy_response_content[j : j + chunk_size]
            for j in range(0, len(dummy_response_content), chunk_size)
        ]

        # reasoning
        for rc in reasoning_chunks:
            yield Response(
                model=self.model,
                provider=self.provider,
                reasoning=rc,
                streaming=True,
            ).model_dump(mode="json")

        # reasoning_duration
        yield Response(
            model=self.model,
            provider=self.provider,
            performance=Performance(reasoning_duration=3.14),
            streaming=True,
        ).model_dump(mode="json")

        # content
        for cc in content_chunks:
            yield Response(
                model=self.model,
                provider=self.provider,
                content=cc,
                streaming=True,
            ).model_dump(mode="json")

            await asyncio.sleep(0.01)

        # final
        yield Response(
            model=self.model,
            provider=self.provider,
            error=Error(),
            usage=Usage(
                prompt_tokens=314,
                completion_tokens=314,
                total_tokens=628,
            ),
            cost=Cost(
                prompt_cost=0.0,
                completion_cost=0.0,
                total_cost=0.0,
            ),
            performance=Performance(
                latency=3.14,
                reasoning_duration=3.14,
                content_duration=3.14,
                total_duration=6.28,
                throughput=314,
            ),
            raw=f"<think>{dummy_response_reasoning}</think>{dummy_response_content}",
            streaming=True,
        ).model_dump(mode="json")
