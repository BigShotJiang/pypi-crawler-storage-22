# standard
# third party
# custom
from sunwaee_gen.agents.anthropic import *
from sunwaee_gen.agents.deepseek import *
from sunwaee_gen.agents.google import *
from sunwaee_gen.agents.openai import *
from sunwaee_gen.agents.xai import *


class Agents:  # pragma: no cover

    # --- ANTHROPIC

    CLAUDE_4_5_OPUS = CLAUDE_4_5_OPUS_AGENT
    CLAUDE_4_5_SONNET = CLAUDE_4_5_SONNET_AGENT
    CLAUDE_4_5_HAIKU = CLAUDE_4_5_HAIKU_AGENT

    CLAUDE_4_1_OPUS = CLAUDE_4_1_OPUS_AGENT

    CLAUDE_4_OPUS = CLAUDE_4_OPUS_AGENT

    CLAUDE_4_SONNET = CLAUDE_4_SONNET_AGENT

    CLAUDE_3_7_SONNET = CLAUDE_3_7_SONNET_AGENT

    # --- DEEPSEEK

    DEEPSEEK_REASONER = DEEPSEEK_REASONER_AGENT
    DEEPSEEK_CHAT = DEEPSEEK_CHAT_AGENT

    # --- GOOGLE

    GEMINI_3_PRO_PREVIEW = GEMINI_3_PRO_PREVIEW_AGENT
    GEMINI_3_FLASH_PREVIEW = GEMINI_3_FLASH_PREVIEW_AGENT

    GEMINI_2_5_PRO = GEMINI_2_5_PRO_AGENT
    GEMINI_2_5_FLASH = GEMINI_2_5_FLASH_AGENT
    GEMINI_2_5_FLASH_LITE = GEMINI_2_5_FLASH_LITE_AGENT

    # --- OPENAI

    GPT_5_2 = GPT_5_2_AGENT

    GPT_5_1 = GPT_5_1_AGENT

    GPT_5 = GPT_5_AGENT
    GPT_5_MINI = GPT_5_MINI_AGENT
    GPT_5_NANO = GPT_5_NANO_AGENT

    GPT_4_1 = GPT_4_1_AGENT
    GPT_4_1_MINI = GPT_4_1_MINI_AGENT
    GPT_4_1_NANO = GPT_4_1_NANO_AGENT

    # --- XAI

    GROK_4_1_FAST_REASONING = GROK_4_1_FAST_REASONING_AGENT
    GROK_4_1_FAST_NON_REASONING = GROK_4_1_FAST_NON_REASONING_AGENT

    GROK_4 = GROK_4_AGENT

    GROK_CODE_FAST_1 = GROK_CODE_FAST_1_AGENT

    GROK_3 = GROK_3_AGENT
    GROK_3_MINI = GROK_3_MINI_AGENT

    @classmethod
    def get(cls, key: str) -> Agent:
        for k, v in vars(cls).items():
            if not k.startswith("_") and not isinstance(v, classmethod):
                if v.name == key:
                    return v

        raise ValueError(f"Invalid agent {key}")

    @classmethod
    def values(cls) -> list[dict]:
        return [
            v.model_dump(mode="json")
            for k, v in vars(cls).items()
            if not k.startswith("_") and not isinstance(v, classmethod)
        ]

    @classmethod
    def names(cls) -> list[str]:
        return [
            v.name
            for k, v in vars(cls).items()
            if not k.startswith("_") and not isinstance(v, classmethod)
        ]
