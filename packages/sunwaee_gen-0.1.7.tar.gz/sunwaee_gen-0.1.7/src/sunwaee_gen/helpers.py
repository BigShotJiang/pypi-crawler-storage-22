# standard
# third party
# custom


def get_nested_dict_value(
    data: dict | list,
    path: str,
    sep: str = ".",
) -> str | list[str] | int | float | dict | None:
    """
    Optimized nested dictionary getter with array filtering support.

    Also handles:
    - content.[type=text].text
    - parts.[functionCall].name
    - a.[b].b.[c]
    """
    current = data
    keys = path.split(sep)

    for key in keys:
        if current is None:
            return None

        # 1. Handle Array Filtering: [key=value] or [key]
        if key.startswith("[") and key.endswith("]"):
            if not isinstance(current, list):  # pragma: no cover
                return None

            content = key[1:-1]

            # Filter logic using list comprehensions for speed
            if "=" in content:
                k, v = content.split("=", 1)
                # We cast to str() to handle int/float values in the data loosely
                current = [
                    item
                    for item in current
                    if isinstance(item, dict) and str(item.get(k)) == v
                ]
            else:
                current = [
                    item
                    for item in current
                    if isinstance(item, dict) and content in item
                ]

        # 2. Handle List Projection (Mapping a key over a list of items)
        # e.g., we have a list of filtered items, and want to extract ".name" from all of them
        elif isinstance(current, list):
            # Check for specific index access first (e.g., "choices.0")
            if key.isdigit():
                try:
                    current = current[int(key)]
                except IndexError:  # pragma: no cover
                    return None
            else:
                # Map the key extraction over the list
                current = [
                    item[key]
                    for item in current
                    if isinstance(item, dict) and key in item
                ]
                # If projection returns empty, return None (matching original behavior)
                if not current:
                    return None

        # 3. Standard Dictionary Access
        elif isinstance(current, dict):
            current = current.get(key)

        else:
            return None

    # Normalize Result: Return single value if list has 1 item, else return list or None
    if isinstance(current, list):
        if not current:  # pragma: no cover
            return None
        if len(current) == 1:
            return current[0]

    return current
