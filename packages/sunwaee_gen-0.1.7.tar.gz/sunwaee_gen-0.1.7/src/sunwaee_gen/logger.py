# standard
import os
import logging
import sys

# custom


def get_logger() -> logging.Logger:
    logger = logging.getLogger()

    if not logger.hasHandlers():
        log_level = os.getenv("SUNWAEE_LOG_LEVEL", "INFO").upper()
        logger.setLevel(log_level)

        handler = logging.StreamHandler(sys.stderr)

        formatter = logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] %(funcName)s() | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)

        logger.addHandler(handler)
        logger.propagate = False

    return logger


logger = get_logger()

# SAMPLES
# logger.debug("debug")
# logger.info("info")
# logger.warning("warning")
# logger.error("error")
