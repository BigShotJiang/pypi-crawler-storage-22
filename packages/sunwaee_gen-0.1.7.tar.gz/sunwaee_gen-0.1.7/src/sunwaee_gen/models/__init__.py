# standard
# third party
# custom
from sunwaee_gen.models.anthropic import *
from sunwaee_gen.models.deepseek import *
from sunwaee_gen.models.google import *
from sunwaee_gen.models.openai import *
from sunwaee_gen.models.xai import *


class Models:  #  pragma: no cover

    # --- ANTHROPIC

    CLAUDE_4_5_OPUS = CLAUDE_4_5_OPUS
    CLAUDE_4_5_SONNET = CLAUDE_4_5_SONNET
    CLAUDE_4_5_HAIKU = CLAUDE_4_5_HAIKU

    CLAUDE_4_1_OPUS = CLAUDE_4_1_OPUS

    CLAUDE_4_OPUS = CLAUDE_4_OPUS

    CLAUDE_4_SONNET = CLAUDE_4_SONNET

    CLAUDE_3_7_SONNET = CLAUDE_3_7_SONNET

    # --- DEEPSEEK

    DEEPSEEK_REASONER = DEEPSEEK_REASONER
    DEEPSEEK_CHAT = DEEPSEEK_CHAT

    # --- GOOGLE

    GEMINI_3_PRO_PREVIEW = GEMINI_3_PRO_PREVIEW
    GEMINI_3_FLASH_PREVIEW = GEMINI_3_FLASH_PREVIEW

    GEMINI_2_5_PRO = GEMINI_2_5_PRO
    GEMINI_2_5_FLASH = GEMINI_2_5_FLASH
    GEMINI_2_5_FLASH_LITE = GEMINI_2_5_FLASH_LITE

    # --- OPENAI

    GPT_5_2 = GPT_5_2

    GPT_5_1 = GPT_5_1

    GPT_5 = GPT_5
    GPT_5_MINI = GPT_5_MINI
    GPT_5_NANO = GPT_5_NANO

    GPT_4_1 = GPT_4_1
    GPT_4_1_MINI = GPT_4_1_MINI
    GPT_4_1_NANO = GPT_4_1_NANO

    # --- XAI

    GROK_4_1_FAST_REASONING = GROK_4_1_FAST_REASONING
    GROK_4_1_FAST_NON_REASONING = GROK_4_1_FAST_NON_REASONING

    GROK_4 = GROK_4

    GROK_CODE_FAST_1 = GROK_CODE_FAST_1

    GROK_3 = GROK_3
    GROK_3_MINI = GROK_3_MINI

    @classmethod
    def get(cls, key: str) -> Model:
        for k, v in vars(cls).items():
            if not k.startswith("_") and not isinstance(v, classmethod):
                if v.name == key:
                    return v

        raise ValueError(f"Invalid agent {key}")

    @classmethod
    def values(cls) -> list[dict]:
        return [
            v.model_dump(mode="json")
            for k, v in vars(cls).items()
            if not k.startswith("_") and not isinstance(v, classmethod)
        ]

    @classmethod
    def names(cls) -> list[str]:
        return [
            v.name
            for k, v in vars(cls).items()
            if not k.startswith("_") and not isinstance(v, classmethod)
        ]
