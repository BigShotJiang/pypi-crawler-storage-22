# standard
# third party
# custom
from sunwaee_gen.providers.anthropic import *
from sunwaee_gen.providers.deepseek import *
from sunwaee_gen.providers.google import *
from sunwaee_gen.providers.openai import *
from sunwaee_gen.providers.xai import *


class Providers:  # pragma: no cover

    ANTHROPIC = ANTHROPIC
    DEEPSEEK = DEEPSEEK
    GOOGLE = GOOGLE
    OPENAI = OPENAI
    XAI = XAI

    @classmethod
    def get(cls, key: str) -> Provider:
        for k, v in vars(cls).items():
            if not k.startswith("_") and not isinstance(v, classmethod):
                if v.name == key:
                    return v

        raise ValueError(f"Invalid agent {key}")

    @classmethod
    def values(cls) -> list[dict]:
        return [
            v.model_dump(mode="json")
            for k, v in vars(cls).items()
            if not k.startswith("_") and not isinstance(v, classmethod)
        ]

    @classmethod
    def names(cls) -> list[str]:
        return [
            v.name
            for k, v in vars(cls).items()
            if not k.startswith("_") and not isinstance(v, classmethod)
        ]
