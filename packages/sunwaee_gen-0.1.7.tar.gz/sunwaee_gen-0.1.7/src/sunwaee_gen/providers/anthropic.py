# standard
import os
import json

# third party
# custom
from sunwaee_gen.helpers import get_nested_dict_value
from sunwaee_gen.provider import Provider


# --- ANTHROPIC
# hi there we're the weirdos trying to establish a new standard


def anthropic_headers_adapter(**kwargs) -> dict:
    """
    {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
        "x-api-key": str,
    }
    """

    api_key = kwargs.get("api_key") or os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY is not set")

    return {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
        "x-api-key": api_key,
    }


def anthropic_messages_adapter(**kwargs) -> list[dict]:
    """
    [
        # --- MESSAGE
        {
            "role": literal["assistant", "user"],
            "content": [
                {
                    "type": "text",
                    "text": str,
                }
            ],
        },
        # --- TOOL CALL
        {
            "role": "assistant",
            "content": [
                {
                    "type": "text",
                    "text": str
                },
                {
                    "type": "tool_use",
                    "id": str,
                    "name": str,
                    "input": {
                        "arg1": "value1",
                        ...
                    }
                }
            ]
        },
        # --- TOOL CALL RESULT
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": str,
                    "content": str,
                }
            ]
        }
    ]
    """

    messages = kwargs.get("messages", [])

    formatted_messages = []
    for m in messages:
        base: dict = {
            "role": "assistant" if m["role"] == "assistant" else "user",
            "content": [],
        }

        # content
        if content := m.get("content"):
            base["content"].append({"type": "text", "text": content})

        # tool calls
        if tool_calls := m.get("tool_calls"):
            base["content"] = [
                {
                    "type": "thinking",
                    "thinking": m.get("reasoning_content"),
                    # NOTE add signature
                    "signature": m.get("reasoning_signature"),
                }
            ]

            for tc in tool_calls:
                base["content"].append(
                    {
                        "type": "tool_use",
                        "id": tc.get("id"),
                        "name": tc.get("function", {}).get("name"),
                        "input": json.loads(tc.get("function", {}).get("arguments")),
                    }
                )

        # tool call results
        if m.get("tool_call_id"):
            base["content"] = [
                {
                    "type": "tool_result",
                    "tool_use_id": m.get("tool_call_id"),
                    "content": m.get("content"),
                }
            ]

        formatted_messages.append(base)

    return formatted_messages


def anthropic_tools_adapter(**kwargs) -> list[dict]:
    """
    [
        {
            "name": str,
            "description": str,
            "input_schema": {
                "type": "object",
                "properties": dict,
                "required": list[str],
            },
        }, ...
    ]
    """

    tools = kwargs.get("tools", [])

    if not tools:
        raise ValueError("Tools are required for anthropic tools adapter")

    return [
        {
            "name": get_nested_dict_value(tool_dict, "function.name"),
            "description": get_nested_dict_value(tool_dict, "function.description"),
            "input_schema": get_nested_dict_value(tool_dict, "function.parameters"),
        }
        for tool_dict in tools
    ]


def anthropic_payload_adapter(**kwargs) -> dict:
    """
    {
        "model": str,
        "system": str, # extracted from system messages
        "messages": list[dict], # without system messages
        "stream": bool,
        "max_tokens": int, # only if max_tokens is supported
        "tools": list[dict], # only if tools are supported
        "thinking": {
            "type": str, # default is "enabled"
            "budget_tokens": int, # default is 8192
        },
    }
    """

    model = kwargs.get("model")
    system_prompt = kwargs.get("system_prompt")
    messages = kwargs.get("messages")
    tools = kwargs.get("tools")
    max_tokens = kwargs.get("max_tokens")
    streaming = kwargs.get("streaming")
    thinking = kwargs.get("thinking")

    if not model:
        raise ValueError("Model is required for anthropic payload adapter")
    if not messages and not system_prompt:
        raise ValueError(
            "One of ('messages', 'system_prompt') is required for anthropic payload adapter"
        )
    if not max_tokens:
        raise ValueError("Max tokens are required for anthropic payload adapter")

    # NOTE if there is **only** a system prompt (oneshot agents) we must pass as user as
    # anthropic does not support system prompt-only requests
    if system_prompt and not messages:
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": system_prompt,
                    }
                ],
            }
        ]

        # empty sys prompt
        system_prompt = None

    payload = {
        "model": model,
        "max_tokens": max_tokens,
        "messages": messages,
        "stream": streaming or False,
        "thinking": thinking
        or {
            "type": "enabled",
            "budget_tokens": 8192,
        },
    }

    if system_prompt:
        payload["system"] = system_prompt

    if tools:
        payload["tools"] = tools

    return payload


def anthropic_sse_adapter() -> dict:
    """
    {
        "reasoning": str,
        "reasoning_signature": str,
        "content": str,
        "tool_call_id": str,
        "tool_call_name": str,
        "tool_call_arguments": str,
        "prompt_tokens": str,
        "completion_tokens": str,
    }
    """

    return {
        "reasoning": "delta.thinking",
        "reasoning_signature": "delta.signature",
        "content": "delta.text",
        "tool_call_id": "content_block.id",
        "tool_call_name": "content_block.name",
        "tool_call_arguments": "delta.partial_json",
        "prompt_tokens": "usage.input_tokens",
        "completion_tokens": "usage.output_tokens",
        "total_tokens": "",  # will be computed
    }


def anthropic_response_adapter() -> dict:
    """
    {
        "reasoning": str,
        "reasoning_signature": str,
        "content": str,
        "tool_calls": str,
        "tool_call_id": str,
        "tool_call_name": str,
        "tool_call_arguments": str,
        "prompt_tokens": str,
        "completion_tokens": str,
        "total_tokens": str,
    }
    """

    return {
        "reasoning": "content.[type=thinking].thinking",
        "reasoning_signature": "content.[type=thinking].signature",
        "content": "content.[type=text].text",
        "tool_call_id": "content.[type=tool_use].id",
        "tool_call_name": "content.[type=tool_use].name",
        "tool_call_arguments": "content.[type=tool_use].input",
        "prompt_tokens": "usage.input_tokens",
        "completion_tokens": "usage.output_tokens",
        "total_tokens": "",  # will be computed
    }


ANTHROPIC = Provider(
    name="anthropic",
    url="https://api.anthropic.com/v1/messages",
    headers_adapter=anthropic_headers_adapter,
    messages_adapter=anthropic_messages_adapter,
    tools_adapter=anthropic_tools_adapter,
    payload_adapter=anthropic_payload_adapter,
    sse_adapter=anthropic_sse_adapter,
    response_adapter=anthropic_response_adapter,
)
