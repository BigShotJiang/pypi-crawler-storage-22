# standard
# third party
# custom
from sunwaee_gen.tools.execute_command import execute_command

TOOLS = {
    tool.function.name: tool
    for tool in [
        execute_command,
    ]
}
