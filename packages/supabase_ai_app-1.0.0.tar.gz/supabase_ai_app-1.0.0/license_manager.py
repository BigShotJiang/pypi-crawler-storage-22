# license_manager.py
# Offline license manager for ULWDA v2.0
# - Use generate_license.py() part to generate keys on YOUR side (keep SECRET_KEY secret)
# - Use LicenseManager in client installs to verify and activate.

import os
import hmac
import hashlib
import json
import base64
import uuid
import platform
from typing import Optional

# ----------------------
# CONFIG - keep this secret on your generator machine ONLY
# ----------------------
# IMPORTANT: Keep SECRET_KEY private. Do NOT embed your real secret in distributed programs.
# For generator use, keep this file on your side (server or your computer).
# For client verification, we do NOT include SECRET_KEY.
#
# On generator machine set a SECRET_KEY here (or export method below).
GENERATOR_SECRET_KEY = "change_this_to_a_strong_random_secret_you_keep_private"

# ----------------------
# LICENSE KEY format
# ----------------------
# We define license key as: BASE32(MACHINE_ID) + "-" + SIG_HEX
# Where SIG_HEX = HMAC_SHA256(GENERATOR_SECRET_KEY, MACHINE_ID)[:32]
# For UNBOUND (global) license, MACHINE_ID = "UNBOUND"
# ----------------------

ACTIVATION_FILENAME = ".ulwda_license"  # stored in the app folder

# ----------------------
# machine id logic
# ----------------------
def get_machine_id() -> str:
    """
    Deterministic machine id built from node name + MAC.
    Not perfectly unique against spoofing, but good for binding offline keys.
    """
    try:
        node = platform.node() or ""
        mac = uuid.getnode()
        raw = f"{node}-{mac}"
        # stable hash
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()
    except Exception:
        return hashlib.sha256(uuid.uuid4().hex.encode()).hexdigest()

# ----------------------
# key generation (run on YOUR side, with SECRET)
# ----------------------
def generate_key_for_machine(machine_id: str, secret_key: str) -> str:
    """
    Create license key bound to machine_id.
    Returns printable key string.
    """
    mid_b32 = base64.b32encode(machine_id.encode()).decode().strip('=')
    sig = hmac.new(secret_key.encode(), machine_id.encode(), hashlib.sha256).hexdigest()[:32]
    return f"{mid_b32}-{sig}"

def generate_unbound_key(secret_key: str) -> str:
    return generate_key_for_machine("UNBOUND", secret_key)

# ----------------------
# verification (client side; NO SECRET here)
# ----------------------
def _extract_parts(key: str):
    if "-" not in key:
        return None, None
    left, sig = key.rsplit("-", 1)
    # restore padding
    pad_len = (-len(left)) % 8
    left_padded = left + ("=" * pad_len)
    try:
        machine_id = base64.b32decode(left_padded.encode()).decode()
    except Exception:
        return None, None
    return machine_id, sig

def _compute_sig_from_machineid_with_secret(machine_id: str, secret_key: str) -> str:
    return hmac.new(secret_key.encode(), machine_id.encode(), hashlib.sha256).hexdigest()[:32]

# Client-side validator uses a public verification token produced at generation time.
# To avoid shipping SECRET_KEY, the generator creates a small "verification token"
# we store inside the activation file and later re-check for tampering.
#
# Activation file structure (JSON):
# {
#   "key": "<license key string>",
#   "machine_id": "<decoded machine id>",
#   "verification": "<HMAC_SHA256_of_key_using_local_machine_secret>",
#   "activated_at": "<iso timestamp>"
# }
#
# The 'verification' uses a local machine secret derived from machine_id so it cannot be forged easily.

def _local_machine_secret(machine_id: str) -> str:
    # derive a local secret unique to the machine (not stable across reinstalls of OS if node/MAC changes)
    return hashlib.sha256(("local:" + machine_id).encode()).hexdigest()

def _local_verification_token(key: str, machine_id: str) -> str:
    secret = _local_machine_secret(machine_id)
    return hmac.new(secret.encode(), key.encode(), hashlib.sha256).hexdigest()

# Public verification helper for generator to precompute verification token.
# You MUST run this on your generator machine AFTER producing key and send both key and verification token to the buyer.
def compute_activation_token_for_distribution(key: str) -> str:
    """
    Compute token client will store in activation file (generator-side helper).
    This requires knowing decoded machine_id from the key.
    """
    machine_id, sig = _extract_parts(key)
    if machine_id is None:
        raise ValueError("Invalid key format")
    # generator cannot produce the local verification token (it's machine-local).
    # So instead we give the user only the key, and they run activation on their machine and
    # the client code verifies signature pattern.
    # Alternatively, for a smoother flow, you (seller) can ask the buyer for their machine_id.
    return "N/A"

# ----------------------
# Public client functions
# ----------------------
def verify_license_key_format(key: str, secret_signature_check: Optional[str] = None) -> Optional[str]:
    """
    Very simple sanity check: decode machine id from key and return machine_id.
    secret_signature_check: OPTIONAL - if you have precomputed expected sig (not used for offline simple flow).
    """
    machine_id, sig = _extract_parts(key)
    if not machine_id or not sig:
        return None
    # We cannot recompute expected sig without GENERATOR_SECRET_KEY (not available client-side).
    # So we accept the key format and return machine_id; actual activation will store local verification token.
    return machine_id

def activate_key_and_store(key: str, app_folder: str) -> bool:
    """
    Activate this key on the current machine and store activation file.
    - Validates key format and that decoded machine_id matches this machine (or is UNBOUND)
    - Writes .ulwda_license file with a local HMAC to detect tampering
    """
    machine_id_from_key, sig = _extract_parts(key)
    if not machine_id_from_key:
        return False, "Invalid key format"

    current_machine_id = get_machine_id()
    # Accept key if it is UNBOUND or matches this machine id
    if machine_id_from_key != "UNBOUND" and machine_id_from_key != current_machine_id:
        return False, "Key not valid for this machine"

    # Create activation content and local verification token
    token = _local_verification_token(key, current_machine_id)
    data = {
        "key": key,
        "machine_id": current_machine_id,
        "token": token,
        "activated_at": __import__("datetime").datetime.utcnow().isoformat()
    }

    try:
        path = os.path.join(app_folder, ACTIVATION_FILENAME)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f)
        return True, "Activated"
    except Exception as e:
        return False, f"Write failed: {e}"

def is_activated(app_folder: str) -> bool:
    path = os.path.join(app_folder, ACTIVATION_FILENAME)
    if not os.path.exists(path):
        return False
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        key = data.get("key", "")
        stored_mid = data.get("machine_id", "")
        stored_token = data.get("token", "")
        current_mid = get_machine_id()
        if stored_mid != current_mid:
            return False
        # recompute token
        expected = _local_verification_token(key, current_mid)
        return hmac.compare_digest(expected, stored_token)
    except Exception:
        return False

def uninstall_activation(app_folder: str) -> bool:
    path = os.path.join(app_folder, ACTIVATION_FILENAME)
    try:
        if os.path.exists(path):
            os.remove(path)
        return True
    except Exception:
        return False

# ----------------------
# Helper for seller: print machine id (give buyer this id so you can generate bound key)
# ----------------------
def get_machine_id_printable():
    return get_machine_id()


# ----------------------
# Quick CLI helpers (for seller and buyer)
# ----------------------
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="License Manager helper.")
    parser.add_argument("--mode", choices=["show-machine", "gen-bound", "gen-unbound", "activate-check"], default="show-machine")
    parser.add_argument("--secret", help="Secret (only for generator modes)")
    parser.add_argument("--machine-id", help="Machine ID for gen-bound")
    parser.add_argument("--key", help="Key to activate (buyer)")
    args = parser.parse_args()

    if args.mode == "show-machine":
        print(get_machine_id())
    elif args.mode == "gen-bound":
        if not args.secret or not args.machine_id:
            print("Provide --secret and --machine-id")
        else:
            print(generate_key_for_machine(args.machine_id, args.secret))
    elif args.mode == "gen-unbound":
        if not args.secret:
            print("Provide --secret")
        else:
            print(generate_unbound_key(args.secret))
    elif args.mode == "activate-check":
        app_folder = os.getcwd()
        print("Activated:", is_activated(app_folder))
    else:
        print("Unknown mode.")
