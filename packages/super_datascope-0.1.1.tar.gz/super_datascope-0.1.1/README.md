# 📊 Super DataScope

通用数据集分析工具，支持 Parquet、SQLite、CSV 等格式。super 系列开源项目之一。

## 快速开始

### 安装

```bash
pip install super-datascope
```

### 使用

```bash
# 启动 Web UI
super-datascope

# 分析指定文件
super-datascope data.parquet

# 分析目录下所有数据文件（深度遍历）
super-datascope ./datasets/

# 分析 SQLite 数据库
super-datascope database.db
```

## 功能特性

- 📤 文件上传分析（开箱即用）
- 💻 命令行快速启动
- 📊 交互式数据可视化（8 种图表类型）
- 🔍 DuckDB SQL 查询
- 📋 JSON 数据深度分析（路径提取、通配符、正则）
- 💾 会话保存与恢复
- ☁️ MinIO 远程存储支持（可选）

## 数据接入方式

| 方式 | 描述 | 复杂度 |
|------|------|--------|
| 📤 文件上传 | Web UI 直接上传 parquet/csv/sqlite | 最简单 |
| 💻 命令行参数 | `super-datascope ./data/` | 简单 |
| ☁️ ObjStorage | 配置 MinIO 等对象存储浏览远程文件 | 高级 |

## 高级配置

### MinIO 远程存储

安装 MinIO 支持：

```bash
pip install super-datascope[minio]
```

创建配置文件 `~/.super-datascope/config.yaml`：

```yaml
storage:
  my_minio:
    type: minio
    connection:
      endpoint: localhost:9000
      access_key: minioadmin
      secret_key: minioadmin
      secure: false
    bucket_name: my-datasets
    bucket_root_path: data/
```

或通过环境变量配置：

```bash
export DATASCOPE_STORAGE_TYPE=minio
export DATASCOPE_STORAGE_ENDPOINT=localhost:9000
export DATASCOPE_STORAGE_ACCESS_KEY=minioadmin
export DATASCOPE_STORAGE_SECRET_KEY=minioadmin
export DATASCOPE_STORAGE_BUCKET=my-datasets
```

## 技术栈

- [Streamlit](https://streamlit.io/) — Web UI 框架
- [DuckDB](https://duckdb.org/) — 数据查询引擎
- [Pandas](https://pandas.pydata.org/) — 数据处理
- [Plotly](https://plotly.com/) — 交互式图表
- [smartlibs](https://github.com/huanghw1989/smartlibs) — 基础工具库

## License

MIT
