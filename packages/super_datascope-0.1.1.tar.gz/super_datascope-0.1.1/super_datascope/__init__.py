"""super-datascope - Universal Dataset Analysis Tool"""

from dotenv import load_dotenv
load_dotenv()

from smart.utils.log import auto_load_logging_config, set_default_logging_config
auto_load_logging_config() or set_default_logging_config()

import logging

__version__ = "0.1.0"

logger = logging.getLogger("datascope")
