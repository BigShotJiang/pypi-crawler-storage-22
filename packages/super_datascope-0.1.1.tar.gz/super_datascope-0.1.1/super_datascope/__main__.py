"""super-datascope CLI 入口"""

import sys
import os
import subprocess


def main():
    args = sys.argv[1:]

    if args:
        # 将路径参数通过环境变量传递给 Streamlit
        os.environ['DATASCOPE_INPUT_PATH'] = args[0]

    # 启动 Streamlit
    app_path = os.path.join(os.path.dirname(__file__), 'app.py')
    subprocess.run([
        sys.executable, '-m', 'streamlit', 'run', app_path,
        '--server.headless', 'true'
    ])


if __name__ == '__main__':
    main()
