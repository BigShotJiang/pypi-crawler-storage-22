import pandas as pd
import numpy as np


def is_not_empty(value):
    if isinstance(value, pd.DataFrame):
        return not value.empty
    elif isinstance(value, np.ndarray):
        return bool(len(value))
    elif isinstance(value, str):
        return bool(value.strip())
    return bool(value)


def convert_numpy_to_list(obj):
    """
    递归转换数据结构中的numpy数组为Python列表，确保数据可以正确序列化
    """
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {key: convert_numpy_to_list(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_to_list(item) for item in obj]
    elif isinstance(obj, tuple):
        return tuple(convert_numpy_to_list(item) for item in obj)
    else:
        return obj
