import streamlit as st
import pandas as pd


def render_basic_statistics(df):
    """渲染基础统计信息
    
    Args:
        df: 要分析的DataFrame
    """
    st.subheader("📋 基础统计信息")
    
    # 数据类型统计
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**数据类型分布**")
        dtype_counts = df.dtypes.value_counts()
        dtype_df = pd.DataFrame({
            '数据类型': dtype_counts.index.astype(str),
            '列数': dtype_counts.values
        })
        st.dataframe(dtype_df, width='stretch')
    
    with col2:
        st.write("**缺失值统计**")
        missing_counts = df.isnull().sum()
        missing_df = pd.DataFrame({
            '列名': missing_counts.index,
            '缺失值数量': missing_counts.values,
            '缺失率(%)': (missing_counts.values / len(df) * 100).round(2)
        })
        missing_df = missing_df[missing_df['缺失值数量'] > 0]
        
        if missing_df.empty:
            st.info("✅ 没有发现缺失值")
        else:
            st.dataframe(missing_df, width='stretch')
    
    # 数值列统计描述
    numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
    if numeric_cols:
        st.write("**数值列统计描述**")
        numeric_stats = df[numeric_cols].describe()
        st.dataframe(numeric_stats, width='stretch')
    
    # 分类列统计描述
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if categorical_cols:
        st.write("**分类列统计描述**")
        cat_stats = []
        
        for col in categorical_cols[:10]:  # 限制显示前10个分类列
            try:
                unique_count = df[col].nunique()
                most_frequent = df[col].mode().iloc[0] if not df[col].mode().empty else 'N/A'
                most_frequent_count = df[col].value_counts().iloc[0] if unique_count > 0 else 0
            except TypeError:
                # 处理包含不可哈希类型（如dict）的列
                unique_count = len(df[col].astype(str).unique())
                most_frequent = 'N/A (含复杂对象)'
                most_frequent_count = 0
            
            cat_stats.append({
                '列名': col,
                '唯一值数量': unique_count,
                '最频繁值': str(most_frequent)[:50] + ('...' if len(str(most_frequent)) > 50 else ''),
                '最频繁值次数': most_frequent_count
            })
        
        if cat_stats:
            cat_stats_df = pd.DataFrame(cat_stats)
            st.dataframe(cat_stats_df, width='stretch')