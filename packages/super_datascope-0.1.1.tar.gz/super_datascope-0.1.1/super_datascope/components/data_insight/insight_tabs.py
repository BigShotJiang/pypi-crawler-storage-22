import streamlit as st
from .quick_analysis import render_quick_analysis
from .basic_statistics import render_basic_statistics


def render_reusable_analysis_tabs(df, config=None, tab_prefix="query_result"):
    """可复用的数据分析Tab组件
    
    Args:
        df: 要分析的DataFrame
        config: 数据配置字典，可选（保留参数以保持接口兼容性）
        tab_prefix: Tab组件的key前缀，用于避免key冲突
    """
    if df is None or df.empty:
        st.warning("没有数据可供分析")
        return
    
    # 使用tab来组织不同的分析功能
    tab1, tab2 = st.tabs(["📈 快速分析", "📋 基础统计"])
    
    with tab1:
        render_quick_analysis(df, key_prefix=tab_prefix)
    
    with tab2:
        render_basic_statistics(df)