import streamlit as st
import pandas as pd
import plotly.express as px
import json

from super_datascope.components.json_path_extractor import JsonColumnAnalyzer
from .utils import (
    analyze_column_data_type,
    get_auto_analysis_panel,
    analyze_series_by_type
)

def render_quick_analysis(df, key_prefix="analysis"):
    """渲染快速分析功能
    
    Args:
        df: 要分析的DataFrame
        key_prefix: 组件key前缀，用于避免key冲突
    """
    st.subheader("⚡ 快速洞察")
    
    # 检查是否有时间相关列 - 并验证是否可转换为时间格式
    potential_time_columns = [col for col in df.columns if any(keyword in col.lower() for keyword in ['time', 'date', 'created', 'updated'])]
    valid_time_columns = []
    
    if potential_time_columns:
        # 验证哪些列可以转换为时间格式
        for col in potential_time_columns:
            if df[col].dtype == 'object':
                # 尝试转换样本数据
                sample_data = df[col].dropna().head(10)
                if len(sample_data) > 0:
                    try:
                        pd.to_datetime(sample_data.iloc[0])
                        # 如果第一个样本转换成功，再尝试更多样本
                        converted_sample = pd.to_datetime(sample_data, errors='coerce')
                        # 如果至少有50%的样本转换成功，认为是有效的时间列
                        success_rate = converted_sample.notna().sum() / len(converted_sample)
                        if success_rate >= 0.5:
                            valid_time_columns.append(col)
                    except:
                        continue
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                valid_time_columns.append(col)
    
    if valid_time_columns:
        st.write("**时间分布分析**")
        time_col = st.selectbox("选择时间列", valid_time_columns, key=f"{key_prefix}_quick_time_col")
        
        # 转换为时间类型
        temp_df = df.copy()
        if temp_df[time_col].dtype == 'object':
            try:
                temp_df[time_col] = pd.to_datetime(temp_df[time_col], errors='coerce')
                # 过滤掉转换失败的数据
                valid_count = temp_df[time_col].notna().sum()
                total_count = len(temp_df)
                if valid_count < total_count:
                    st.info(f"📊 成功转换 {valid_count}/{total_count} 条时间数据 ({valid_count/total_count*100:.1f}%)")
                    temp_df = temp_df[temp_df[time_col].notna()]
            except:
                st.warning(f"列 {time_col} 无法转换为时间格式")
                return
        
        if pd.api.types.is_datetime64_any_dtype(temp_df[time_col]) and len(temp_df) > 0:
            # 时间分布直方图
            fig = px.histogram(
                temp_df, 
                x=time_col, 
                title=f"时间分布 - {time_col}",
                nbins=50,
                labels={time_col: "时间", "count": "频次"}
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # 时间趋势分析
            if st.checkbox("显示时间趋势分析", key=f"{key_prefix}_time_trend"):
                # 按日期聚合
                temp_df['date'] = temp_df[time_col].dt.date
                daily_counts = temp_df.groupby('date').size().reset_index(name='count')
                
                fig_trend = px.line(
                    daily_counts,
                    x='date',
                    y='count',
                    title=f"每日数据量趋势 - {time_col}",
                    labels={'date': '日期', 'count': '数据量'}
                )
                st.plotly_chart(fig_trend, use_container_width=True)
    
    # 分类列快速分析 - 支持JSON列路径提取
    categorical_columns = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if categorical_columns:
        st.write("**分类数据快速分析**")
        cat_col = st.selectbox("选择分类列", categorical_columns, key=f"{key_prefix}_quick_cat_col")
        
        if cat_col:
            _render_categorical_analysis_with_advanced_options(df, cat_col, key_prefix)
    
    # 数值列快速分析
    numeric_columns = df.select_dtypes(include=['number']).columns.tolist()
    if numeric_columns:
        st.write("**数值数据快速分析**")
        num_col = st.selectbox("选择数值列", numeric_columns, key=f"{key_prefix}_quick_num_col")
        
        if num_col:
            col1, col2 = st.columns(2)
            
            with col1:
                # 直方图
                fig_hist = px.histogram(
                    df,
                    x=num_col,
                    title=f"{num_col} 分布直方图",
                    labels={num_col: num_col, "count": "频次"}
                )
                st.plotly_chart(fig_hist, use_container_width=True)
            
            with col2:
                # 箱线图
                fig_box = px.box(
                    df,
                    y=num_col,
                    title=f"{num_col} 箱线图",
                    labels={num_col: num_col}
                )
                st.plotly_chart(fig_box, use_container_width=True)
    
    # JSON列分析
    _render_json_column_analysis(df, key_prefix)


def _render_json_column_analysis(df, key_prefix="analysis"):
    """渲染JSON列分析功能"""
    # 检测可能的JSON列
    potential_json_columns = []
    
    for col in df.select_dtypes(include=['object']).columns:
        # 检查前几行是否包含JSON数据
        sample_data = df[col].dropna().head(5)
        json_count = 0
        
        for value in sample_data:
            try:
                if isinstance(value, str) and value.strip():
                    # 尝试解析JSON字符串
                    parsed = json.loads(value)
                    # 只有当解析结果是复杂对象（dict或包含dict的list）时才认为是JSON
                    if isinstance(parsed, dict) or (isinstance(parsed, list) and len(parsed) > 0 and isinstance(parsed[0], dict)):
                        json_count += 1
                elif isinstance(value, dict):
                    # 直接是字典对象
                    json_count += 1
                elif isinstance(value, list) and len(value) > 0:
                    # 列表对象，但需要检查是否包含复杂结构
                    if isinstance(value[0], dict):
                        json_count += 1
                    # 如果是简单的字符串列表，不认为是JSON列
            except (json.JSONDecodeError, TypeError, IndexError):
                continue
        
        # 如果至少有60%的样本是JSON，认为是JSON列
        if len(sample_data) > 0 and json_count / len(sample_data) >= 0.6:
            potential_json_columns.append(col)
    
    if potential_json_columns:
        st.write("**JSON列分析**")
        
        # 避免与分类分析重复，过滤已经在分类分析中选择的列
        available_json_columns = [col for col in potential_json_columns 
                                if col != st.session_state.get(f"{key_prefix}_quick_cat_col")]
        
        if available_json_columns:
            json_col = st.selectbox(
                "选择JSON列进行路径提取分析", 
                available_json_columns, 
                key=f"{key_prefix}_quick_json_col",
                help="这里只显示尚未在分类分析中选择的JSON列"
            )
            
            if json_col:
                analyzer = JsonColumnAnalyzer(df, json_col, f"{key_prefix}_quick_json_analysis")
                analysis_result = analyzer.render()
                
                # 如果有提取结果，可以进行进一步的可视化分析
                if analysis_result and analysis_result['success_count'] > 0:
                    extracted_df = analysis_result['analysis_df']
                    extracted_col = analysis_result['extracted_column']
                    
                    st.subheader("📊 提取数据可视化")
                    
                    # 分析提取的数据类型
                    extracted_data = extracted_df[extracted_col].dropna()
                    if len(extracted_data) > 0:
                        # 使用统一的分析函数，传递真实的列名和JSON路径用于SQL生成
                        analyze_series_by_type(
                            extracted_data, 
                            f"{json_col}[{analysis_result['path_used']}]", 
                            column_name=json_col,
                            json_path=analysis_result['path_used'],
                            is_list_expanded=False,
                            enable_json_extraction=True  # 允许进一步JSON提取
                        )
        else:
            st.info("💡 所有JSON列都已在分类分析中处理，可在上方高级设置中选择JSON分析面板")


def _render_categorical_analysis_with_advanced_options(df, cat_col, key_prefix="analysis"):
    """增强的分类分析功能 - 支持高级选项和智能分析面板选择"""
    
    # 分析列数据类型
    sample_data = df[cat_col].dropna().head(10)
    if sample_data.empty:
        st.warning(f"列 '{cat_col}' 中没有有效数据")
        return
    
    # 检测数据类型
    data_type_info = analyze_column_data_type(sample_data)
    
    # 显示数据类型信息
    st.info(f"🔍 检测到数据类型: {data_type_info['description']}")
    
    # 高级设置区域
    with st.expander("🔧 高级设置", expanded=False):
        col1, col2 = st.columns(2)
        
        with col1:
            # 列表展开选项 - 列表类型默认选中展开
            default_expand = data_type_info['is_list']  # 列表类型默认选中
            expand_lists = st.checkbox(
                "展开列表元素进行分析", 
                value=default_expand,
                key=f"{key_prefix}_expand_lists_{cat_col}",
                help="如果数据是列表格式，勾选此项将展开所有列表元素进行统计分析"
            )
        
        with col2:
            # 手动选择分析面板
            analysis_options = ["自动选择", "分类分析", "数值分析", "时间分析", "JSON分析", "字典键分析"]
            auto_panel = get_auto_analysis_panel(data_type_info, expand_lists)
            default_index = 0 if auto_panel == "auto" else analysis_options.index(auto_panel) if auto_panel in analysis_options else 0
            
            selected_panel = st.selectbox(
                "分析面板",
                analysis_options,
                index=default_index,
                key=f"{key_prefix}_analysis_panel_{cat_col}",
                help="可以手动选择分析面板，或使用自动选择根据数据类型智能选择"
            )
    
    # 根据设置执行分析 - 统一使用 analyze_series_by_type
    column_data = df[cat_col].dropna()
    if column_data.empty:
        st.warning(f"列 '{cat_col}' 中没有有效数据")
        return
    
    # 使用统一的分析函数
    analyze_series_by_type(
        data_series=column_data,
        title=cat_col,
        column_name=cat_col,
        analysis_type=selected_panel if selected_panel != "自动选择" else None,
        expand_lists=expand_lists,
        enable_json_extraction=True  # 启用JSON路径提取功能
    )