"""
super-datascope 配置模块
支持动态数据源注册，无硬编码数据源
"""

# 支持的文件格式
SUPPORTED_FILE_TYPES = {
    "parquet": [".parquet"],
    "sqlite": [".sqlite", ".db"],
    "csv": [".csv"],
}

# 所有支持的文件扩展名
SUPPORTED_EXTENSIONS = []
for exts in SUPPORTED_FILE_TYPES.values():
    SUPPORTED_EXTENSIONS.extend(exts)

# 动态数据源注册表（运行时填充）
DATA_SOURCES = {}


def register_data_source(name, config):
    """注册数据源"""
    DATA_SOURCES[name] = config


def get_data_sources():
    """获取所有已注册的数据源"""
    return DATA_SOURCES
