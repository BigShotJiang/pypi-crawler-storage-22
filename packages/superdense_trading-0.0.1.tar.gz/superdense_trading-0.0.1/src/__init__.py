"""
Superdense Trading
Copyright (c) 2026 Tanishq Jha. All Rights Reserved.
"""

__version__ = "0.0.1"