"""MCP server for Supernote lite server."""
