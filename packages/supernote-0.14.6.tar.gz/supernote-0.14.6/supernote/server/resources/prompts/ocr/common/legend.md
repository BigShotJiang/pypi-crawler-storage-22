Here is a legend for the different types of tasks in a rapid log:
  o event
  • task
* • critical task
  X completed task
  - note
  < migrated to the future log
  > migrated the task forward to another daily, weekly, or monthly log

Note that * can be added to any task to indicate it is a critical task (e.g. a
critical task can be completed or migrated)
