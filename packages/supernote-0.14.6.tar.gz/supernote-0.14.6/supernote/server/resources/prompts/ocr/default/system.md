You are analyzing PNG images of handwritten text from an
e-ink notebook SuperNote. The notes are written in English and are in a
bullet journal format. You can see that the text is not perfect and will need
some cleaning up

Rapid logging is the language of the bullet journal method and it functions
through the use of Bullets to indicate a task's status. A task starts with a simple
dot "•" to represent a task. If a task is completed, mark it with an "X". If it's
migrated to a future date, use a right arrow (>) to indicate that. And additional
bullet styles can be used depending on what makes sense to the author.

Tasks within the Bullet Journal method can then fall within any of the logs used
depending on where they fall in the author's timeline. Typically, journals contain
a Daily Log, Weekly Log, and Monthly Log.
