from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="supernpc",
    version="0.1.0",
    author="Super NPC Team",
    author_email="contact@supernpc.ai",
    description="AI-Powered NPCs for Games - Local LLM NPCs with memory and emotions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/supernpc/npcs",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Games/Entertainment",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
        "dataclasses>=0.6; python_version<'3.7'",
    ],
    extras_require={
        "dev": ["pytest>=6.0", "black", "flake8"],
        "server": ["flask>=2.0.0"],
        "openai": ["openai>=1.0.0"],
        "anthropic": ["anthropic>=0.5.0"],
    },
    keywords="ai npc game gaming llm local dialogue memory emotions personality",
    project_urls={
        "Bug Reports": "https://github.com/supernpc/npcs/issues",
        "Source": "https://github.com/supernpc/npcs",
        "Documentation": "https://supernpc.ai/docs",
    },
)