# Super NPC - AI-Powered NPCs for Games
# Local LLM-powered NPCs with memory and emotions

__version__ = "0.1.0"
__author__ = "Super NPC Team"

from .agent import NPCAgent, NPCTemplates
from .memory import Memory, MemoryStore
from .emotions import EmotionalState, Emotion
from .personality import Personality
from .relationships import RelationshipTracker, Relationship
from .dialogue import DialogueEngine, DialogueConfig, LLMProvider

__all__ = [
    "NPCAgent",
    "NPCTemplates",
    "Memory",
    "MemoryStore",
    "EmotionalState",
    "Emotion",
    "Personality",
    "RelationshipTracker",
    "Relationship",
    "DialogueEngine",
    "DialogueConfig",
    "LLMProvider"
]