"""
Super NPC Agent
Complete intelligent NPC with memory, emotions, personality, and dialogue
"""

from typing import Optional, List, Dict
import json
import os

from .memory import Memory, MemoryStore
from .emotions import EmotionalState, EmotionalStimuli, Emotion
from .personality import Personality
from .relationships import RelationshipTracker
from .dialogue import DialogueEngine, DialogueConfig


class NPCAgent:
    """
    Complete intelligent NPC agent
    Combines memory, emotions, personality, relationships, and dialogue
    """
    
    def __init__(self,
                 name: str,
                 role: str = "villager",
                 personality: Optional[Personality] = None,
                 backstory: Optional[List[str]] = None,
                 location: str = "the village",
                 dialogue_config: Optional[DialogueConfig] = None):
        
        self.name = name
        self.role = role
        self.location = location
        
        # Core systems
        self.personality = personality or Personality.villager()
        self.emotions = EmotionalState(
            happiness=0.5 + self.personality.get_friendliness() * 0.2,
            inertia=0.2 + self.personality.get_emotional_stability() * 0.3
        )
        self.memories = MemoryStore(max_memories=50)
        self.relationships = RelationshipTracker(
            default_trust=self.personality.get_friendliness() * 0.2
        )
        
        # Dialogue engine (shared across NPCs typically)
        self.dialogue = DialogueEngine(dialogue_config)
        
        # Add backstory memories
        if backstory:
            for memory in backstory:
                self.memories.add(memory, importance=6, memory_type="backstory")
    
    def chat(self, player_id: str, message: str) -> str:
        """
        Main interaction method - player talks to NPC
        Returns NPC's response
        """
        # Analyze player message sentiment
        sentiment = self.dialogue.analyze_sentiment(message)
        
        # Apply emotional effects
        self.emotions.apply_stimulus(
            happiness_delta=sentiment["happiness_delta"],
            anger_delta=sentiment["anger_delta"],
            fear_delta=sentiment["fear_delta"]
        )
        
        # Update relationship
        relationship = self.relationships.update(
            player_id, 
            trust_delta=sentiment["trust_delta"]
        )
        
        # Retrieve relevant memories
        memories = self.memories.retrieve(query=message, limit=5)
        
        # Generate response
        response = self.dialogue.generate(
            npc_name=self.name,
            npc_role=self.role,
            personality_context=self.personality.to_prompt_context(),
            emotional_context=self.emotions.to_prompt_context(),
            relationship_context=relationship.to_prompt_context(),
            memory_context=self.memories.format_for_prompt(memories),
            player_message=message,
            location=self.location
        )
        
        # Store this interaction as memory
        importance = 4 + int(abs(sentiment["trust_delta"]) * 10)
        self.memories.add_dialogue(
            speaker="Traveler",
            message=message,
            response=response,
            importance=min(9, importance)
        )
        
        return response
    
    def greet(self, player_id: str) -> str:
        """Generate a greeting based on relationship"""
        relationship = self.relationships.get(player_id)
        
        if relationship.familiarity < 0.1:
            return self.chat(player_id, "Hello there")
        elif relationship.trust > 0.5:
            return f"Ah, welcome back, friend! Good to see you again."
        elif relationship.trust < -0.3:
            return f"You again. What do you want?"
        else:
            return f"Hello again, traveler."
    
    def compliment(self, player_id: str) -> str:
        """Player compliments the NPC"""
        self.emotions.apply_stimulus(**EmotionalStimuli.COMPLIMENTED)
        self.relationships.update(player_id, trust_delta=0.1)
        return self.chat(player_id, "You're doing a great job!")
    
    def insult(self, player_id: str) -> str:
        """Player insults the NPC"""
        self.emotions.apply_stimulus(**EmotionalStimuli.INSULTED)
        self.relationships.update(player_id, trust_delta=-0.15)
        self.relationships.add_tag(player_id, "was_rude")
        return self.chat(player_id, "You're terrible at your job!")
    
    def threaten(self, player_id: str) -> str:
        """Player threatens the NPC"""
        self.emotions.apply_stimulus(**EmotionalStimuli.THREATENED)
        self.relationships.update(player_id, trust_delta=-0.25)
        self.relationships.add_tag(player_id, "threatened_me")
        return self.chat(player_id, "I'll make you pay for this!")
    
    def give_gift(self, player_id: str, item: str) -> str:
        """Player gives a gift"""
        self.emotions.apply_stimulus(**EmotionalStimuli.GIVEN_GIFT)
        self.relationships.update(player_id, trust_delta=0.15)
        self.relationships.add_tag(player_id, "gave_gift")
        self.memories.add(
            f"The traveler gave me a gift: {item}",
            importance=7,
            related_entity=player_id
        )
        return self.chat(player_id, f"I got you this {item}!")
    
    def update(self, delta_time: float = 1.0):
        """
        Update NPC state (call each frame or periodically)
        Handles emotion decay, etc.
        """
        baseline = 0.5 + self.personality.get_friendliness() * 0.1
        self.emotions.decay_to_baseline(baseline)
    
    def get_mood(self) -> str:
        """Get current mood description"""
        return self.emotions.get_mood_description()
    
    def get_dominant_emotion(self) -> Emotion:
        """Get dominant emotion"""
        return self.emotions.dominant_emotion()
    
    def get_trust(self, player_id: str) -> float:
        """Get trust level with player"""
        return self.relationships.get_trust(player_id)
    
    def get_status(self, player_id: str = "player") -> Dict:
        """Get full status for debugging/UI"""
        rel = self.relationships.get(player_id)
        return {
            "name": self.name,
            "role": self.role,
            "mood": self.get_mood(),
            "emotion": self.get_dominant_emotion().value,
            "happiness": f"{self.emotions.happiness:.0%}",
            "anger": f"{self.emotions.anger:.0%}",
            "fear": f"{self.emotions.fear:.0%}",
            "trust": f"{rel.trust:.0%}",
            "relationship": rel.get_relationship_level(),
            "interactions": rel.interactions,
            "memories": len(self.memories.memories)
        }
    
    def save(self, filepath: str):
        """Save NPC state to file"""
        data = {
            "name": self.name,
            "role": self.role,
            "location": self.location,
            "personality": self.personality.to_dict(),
            "emotions": self.emotions.to_dict(),
            "relationships": self.relationships.to_dict(),
            "memories": [m.to_dict() for m in self.memories.memories]
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    @classmethod
    def load(cls, filepath: str, dialogue_config: Optional[DialogueConfig] = None) -> 'NPCAgent':
        """Load NPC state from file"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        agent = cls(
            name=data["name"],
            role=data["role"],
            location=data.get("location", "the village"),
            personality=Personality.from_dict(data["personality"]),
            dialogue_config=dialogue_config
        )
        
        agent.emotions = EmotionalState.from_dict(data["emotions"])
        agent.relationships = RelationshipTracker.from_dict(data["relationships"])
        
        for mem_data in data.get("memories", []):
            mem = Memory.from_dict(mem_data)
            agent.memories.memories.append(mem)
        
        return agent


# Preset NPC templates
class NPCTemplates:
    """Pre-built NPC templates for common roles"""
    
    @staticmethod
    def merchant(name: str = "Marcus", location: str = "the market") -> NPCAgent:
        return NPCAgent(
            name=name,
            role="merchant",
            personality=Personality.merchant(),
            location=location,
            backstory=[
                "I run the best shop in town - fair prices, quality goods.",
                "Business has been good since the harvest festival.",
                "A thief tried to rob me last week. The guards caught him.",
                "My family has been trading here for three generations."
            ]
        )
    
    @staticmethod
    def guard(name: str = "Roland", location: str = "the gate") -> NPCAgent:
        return NPCAgent(
            name=name,
            role="guard",
            personality=Personality.guard(),
            location=location,
            backstory=[
                "I've protected this village for fifteen years.",
                "The roads have been dangerous lately - bandits and worse.",
                "I served in the king's army before retiring here.",
                "My duty is to keep everyone safe."
            ]
        )
    
    @staticmethod
    def innkeeper(name: str = "Martha", location: str = "the inn") -> NPCAgent:
        return NPCAgent(
            name=name,
            role="innkeeper",
            personality=Personality(
                openness=0.5,
                conscientiousness=0.6,
                extraversion=0.8,
                agreeableness=0.7,
                neuroticism=0.3
            ),
            location=location,
            backstory=[
                "I've run this inn for twenty years.",
                "Travelers bring the best stories from far lands.",
                "My stew is famous throughout the region.",
                "The room upstairs is always ready for weary travelers."
            ]
        )
    
    @staticmethod
    def scholar(name: str = "Aldric", location: str = "the library") -> NPCAgent:
        return NPCAgent(
            name=name,
            role="scholar",
            personality=Personality.scholar(),
            location=location,
            backstory=[
                "I've spent my life studying the ancient texts.",
                "There are secrets in these books that could change everything.",
                "Knowledge is the greatest treasure of all.",
                "The old tongue holds power most have forgotten."
            ]
        )
    
    @staticmethod
    def blacksmith(name: str = "Grimm", location: str = "the forge") -> NPCAgent:
        return NPCAgent(
            name=name,
            role="blacksmith",
            personality=Personality(
                openness=0.3,
                conscientiousness=0.8,
                extraversion=0.3,
                agreeableness=0.5,
                neuroticism=0.2
            ),
            location=location,
            backstory=[
                "My blades are the finest in the land.",
                "I learned my craft from a dwarven master.",
                "Good steel takes patience - like all things worth doing.",
                "The forge has been my life for thirty years."
            ]
        )
