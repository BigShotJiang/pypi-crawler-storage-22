"""
Super NPC Dialogue Engine
Multi-provider LLM-powered dialogue generation
Supports Ollama (local), OpenAI, and Anthropic
"""

import requests
import json
from typing import Optional, List, Dict, Literal
from dataclasses import dataclass
from enum import Enum


class LLMProvider(Enum):
    """Supported LLM providers"""
    OLLAMA = "ollama"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"


@dataclass
class DialogueConfig:
    """Configuration for dialogue generation"""
    provider: LLMProvider = LLMProvider.OLLAMA
    model: str = "qwen2.5:1.5b"

    # Ollama settings
    ollama_url: str = "http://localhost:11434"

    # OpenAI settings
    openai_api_key: Optional[str] = None
    openai_base_url: Optional[str] = None

    # Anthropic settings
    anthropic_api_key: Optional[str] = None

    # Common settings
    max_tokens: int = 150
    temperature: float = 0.8
    timeout: float = 30.0


class DialogueEngine:
    """
    Generates NPC dialogue using multiple LLM providers
    """

    def __init__(self, config: Optional[DialogueConfig] = None):
        self.config = config or DialogueConfig()
        self._connected = False

    def check_connection(self) -> bool:
        """Check if the configured LLM provider is available"""
        try:
            if self.config.provider == LLMProvider.OLLAMA:
                return self._check_ollama()
            elif self.config.provider == LLMProvider.OPENAI:
                return self._check_openai()
            elif self.config.provider == LLMProvider.ANTHROPIC:
                return self._check_anthropic()
            else:
                return False
        except Exception as e:
            print(f"Connection check failed: {e}")
            self._connected = False
            return False

    def _check_ollama(self) -> bool:
        """Check Ollama connection"""
        try:
            resp = requests.get(
                f"{self.config.ollama_url}/api/tags",
                timeout=5
            )
            self._connected = resp.status_code == 200
            return self._connected
        except:
            self._connected = False
            return False

    def _check_openai(self) -> bool:
        """Check OpenAI connection"""
        if not self.config.openai_api_key:
            return False
        try:
            headers = {"Authorization": f"Bearer {self.config.openai_api_key}"}
            url = f"{self.config.openai_base_url or 'https://api.openai.com'}/v1/models"
            resp = requests.get(url, headers=headers, timeout=5)
            self._connected = resp.status_code == 200
            return self._connected
        except:
            self._connected = False
            return False

    def _check_anthropic(self) -> bool:
        """Check Anthropic connection"""
        if not self.config.anthropic_api_key:
            return False
        try:
            headers = {
                "x-api-key": self.config.anthropic_api_key,
                "anthropic-version": "2023-06-01"
            }
            resp = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers=headers,
                json={"messages": [], "max_tokens": 1},
                timeout=5
            )
            # Anthropic returns 400 for empty messages, which means API is working
            self._connected = resp.status_code in [200, 400]
            return self._connected
        except:
            self._connected = False
            return False

    def generate(self, 
                 npc_name: str,
                 npc_role: str,
                 personality_context: str,
                 emotional_context: str,
                 relationship_context: str,
                 memory_context: str,
                 player_message: str,
                 location: str = "the village") -> str:
        """
        Generate NPC dialogue response using configured LLM provider
        """
        if not self._connected:
            if not self.check_connection():
                return self._fallback_response(npc_name, npc_role)

        # Build the prompt
        system_prompt = self._build_system_prompt(
            npc_name, npc_role, personality_context,
            emotional_context, relationship_context,
            memory_context, location
        )

        try:
            if self.config.provider == LLMProvider.OLLAMA:
                return self._generate_ollama(system_prompt, player_message, npc_name)
            elif self.config.provider == LLMProvider.OPENAI:
                return self._generate_openai(system_prompt, player_message, npc_name)
            elif self.config.provider == LLMProvider.ANTHROPIC:
                return self._generate_anthropic(system_prompt, player_message, npc_name)
            else:
                return self._fallback_response(npc_name, npc_role)
        except Exception as e:
            print(f"Dialogue generation error: {e}")
            return self._fallback_response(npc_name, npc_role)

    def _generate_ollama(self, system_prompt: str, player_message: str, npc_name: str) -> str:
        """Generate using Ollama"""
        user_prompt = f"The traveler says: \"{player_message}\"\n\nRespond as {npc_name} in 1-2 sentences:"

        response = requests.post(
            f"{self.config.ollama_url}/api/generate",
            json={
                "model": self.config.model,
                "prompt": user_prompt,
                "system": system_prompt,
                "stream": False,
                "options": {
                    "temperature": self.config.temperature,
                    "num_predict": self.config.max_tokens,
                }
            },
            timeout=self.config.timeout
        )

        if response.status_code == 200:
            result = response.json()
            text = result.get("response", "").strip()
            return self._clean_response(text, npc_name)
        else:
            return self._fallback_response(npc_name, "villager")

    def _generate_openai(self, system_prompt: str, player_message: str, npc_name: str) -> str:
        """Generate using OpenAI"""
        if not self.config.openai_api_key:
            return self._fallback_response(npc_name, "villager")

        headers = {"Authorization": f"Bearer {self.config.openai_api_key}"}
        base_url = self.config.openai_base_url or "https://api.openai.com"

        response = requests.post(
            f"{base_url}/v1/chat/completions",
            headers=headers,
            json={
                "model": self.config.model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"The traveler says: \"{player_message}\"\n\nRespond as {npc_name} in 1-2 sentences:"}
                ],
                "max_tokens": self.config.max_tokens,
                "temperature": self.config.temperature,
            },
            timeout=self.config.timeout
        )

        if response.status_code == 200:
            result = response.json()
            text = result["choices"][0]["message"]["content"].strip()
            return self._clean_response(text, npc_name)
        else:
            return self._fallback_response(npc_name, "villager")

    def _generate_anthropic(self, system_prompt: str, player_message: str, npc_name: str) -> str:
        """Generate using Anthropic"""
        if not self.config.anthropic_api_key:
            return self._fallback_response(npc_name, "villager")

        headers = {
            "x-api-key": self.config.anthropic_api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }

        prompt = f"{system_prompt}\n\nThe traveler says: \"{player_message}\"\n\nRespond as {npc_name} in 1-2 sentences:"

        response = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json={
                "model": self.config.model,
                "max_tokens": self.config.max_tokens,
                "temperature": self.config.temperature,
                "system": system_prompt,
                "messages": [
                    {"role": "user", "content": f"The traveler says: \"{player_message}\"\n\nRespond as {npc_name} in 1-2 sentences:"}
                ]
            },
            timeout=self.config.timeout
        )

        if response.status_code == 200:
            result = response.json()
            text = result["content"][0]["text"].strip()
            return self._clean_response(text, npc_name)
        else:
            return self._fallback_response(npc_name, "villager")

    def analyze_sentiment(self, message: str) -> Dict[str, float]:
        """
        Analyze sentiment of player message for emotional response
        Returns sentiment deltas for emotions and trust
        """
        message_lower = message.lower()
        
        # Simple sentiment analysis (can be enhanced with ML models later)
        sentiment_scores = {
            "happiness_delta": 0.0,
            "anger_delta": 0.0,
            "fear_delta": 0.0,
            "trust_delta": 0.0
        }
        
        # Positive indicators
        positive_words = ["hello", "hi", "thank", "thanks", "good", "great", "awesome", "nice", "help", "please"]
        if any(word in message_lower for word in positive_words):
            sentiment_scores["happiness_delta"] += 0.1
            sentiment_scores["trust_delta"] += 0.05
        
        # Negative indicators  
        negative_words = ["hate", "stupid", "idiot", "terrible", "awful", "bad", "angry", "mad"]
        if any(word in message_lower for word in negative_words):
            sentiment_scores["anger_delta"] += 0.2
            sentiment_scores["happiness_delta"] -= 0.1
            sentiment_scores["trust_delta"] -= 0.1
        
        # Fear indicators
        fear_words = ["scared", "afraid", "terrified", "danger", "threat", "monster"]
        if any(word in message_lower for word in fear_words):
            sentiment_scores["fear_delta"] += 0.15
        
        # Question indicators (curiosity = slight trust boost)
        if "?" in message or message_lower.startswith(("what", "how", "why", "when", "where", "who")):
            sentiment_scores["trust_delta"] += 0.02
        
        return sentiment_scores

    def _build_system_prompt(self,
                             npc_name: str,
                             npc_role: str,
                             personality: str,
                             emotion: str,
                             relationship: str,
                             memories: str,
                             location: str) -> str:
        """Build the system prompt for the LLM"""
        return f"""You are {npc_name}, a {npc_role} in a fantasy world.

PERSONALITY: {personality}
CURRENT MOOD: {emotion}
RELATIONSHIP WITH TRAVELER: {relationship}
LOCATION: {location}

RECENT MEMORIES:
{memories}

INSTRUCTIONS:
- Stay in character as {npc_name}
- Respond naturally based on your mood and relationship
- Keep responses brief (1-2 sentences)
- Reference memories when relevant
- If angry or distrustful, be curt or dismissive
- If happy and friendly, be warm and helpful
- Do NOT break character or mention being an AI"""

    def _clean_response(self, text: str, npc_name: str) -> str:
        """Clean up the LLM response"""
        # Remove common prefixes
        prefixes = [
            f"{npc_name}:",
            f"{npc_name} says:",
            f"*{npc_name}*",
            "Response:",
            "NPC:",
        ]

        for prefix in prefixes:
            if text.lower().startswith(prefix.lower()):
                text = text[len(prefix):].strip()

        # Remove asterisk actions at start
        if text.startswith("*"):
            # Find end of action
            end = text.find("*", 1)
            if end > 0:
                text = text[end+1:].strip()

        # Limit length
        if len(text) > 300:
            # Find a good break point
            for punct in [". ", "! ", "? "]:
                idx = text.rfind(punct, 0, 300)
                if idx > 0:
                    text = text[:idx+1]
                    break

        return text.strip()

    def _fallback_response(self, npc_name: str, npc_role: str) -> str:
        """Fallback response when LLM is unavailable"""
        fallbacks = {
            "merchant": [
                "Welcome to my shop! What can I help you with?",
                "Fine wares at fair prices, friend.",
                "Looking to buy or sell?"
            ],
            "guard": [
                "Move along, citizen.",
                "All is quiet in the village.",
                "State your business."
            ],
            "villager": [
                "Hello there, traveler!",
                "Lovely weather we're having.",
                "How can I help you?"
            ]
        }

        responses = fallbacks.get(npc_role, fallbacks["villager"])
        return responses[hash(npc_name + npc_role) % len(responses)]