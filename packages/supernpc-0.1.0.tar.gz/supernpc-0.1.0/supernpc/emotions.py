"""
Super NPC Emotional System
OCC-based emotion model with mood dynamics
"""

from enum import Enum
from dataclasses import dataclass
from typing import Dict, Optional
import time


class Emotion(Enum):
    """Primary emotions based on OCC model"""
    HAPPY = "happy"
    SAD = "sad"
    ANGRY = "angry"
    FEARFUL = "fearful"
    SURPRISED = "surprised"
    DISGUSTED = "disgusted"
    NEUTRAL = "neutral"


@dataclass
class EmotionalState:
    """
    Tracks NPC emotional state with multiple dimensions
    Values range from 0.0 to 1.0
    """
    happiness: float = 0.5
    anger: float = 0.0
    fear: float = 0.0
    sadness: float = 0.0
    surprise: float = 0.0
    
    # Mood inertia - how quickly emotions change
    inertia: float = 0.3
    
    # Last update time for decay
    last_update: float = 0.0
    
    def __post_init__(self):
        self.last_update = time.time()
    
    def dominant_emotion(self) -> Emotion:
        """Get the strongest current emotion"""
        emotions = {
            Emotion.HAPPY: self.happiness,
            Emotion.ANGRY: self.anger,
            Emotion.FEARFUL: self.fear,
            Emotion.SAD: self.sadness,
            Emotion.SURPRISED: self.surprise,
        }
        
        # Find max, but need threshold to not be neutral
        max_emotion = max(emotions.items(), key=lambda x: x[1])
        if max_emotion[1] < 0.3:
            return Emotion.NEUTRAL
        return max_emotion[0]
    
    def apply_stimulus(self, 
                       happiness_delta: float = 0.0,
                       anger_delta: float = 0.0,
                       fear_delta: float = 0.0,
                       sadness_delta: float = 0.0,
                       surprise_delta: float = 0.0):
        """
        Apply emotional stimulus with inertia
        Deltas are scaled by (1 - inertia)
        """
        scale = 1.0 - self.inertia
        
        self.happiness = self._clamp(self.happiness + happiness_delta * scale)
        self.anger = self._clamp(self.anger + anger_delta * scale)
        self.fear = self._clamp(self.fear + fear_delta * scale)
        self.sadness = self._clamp(self.sadness + sadness_delta * scale)
        self.surprise = self._clamp(self.surprise + surprise_delta * scale)
        
        self.last_update = time.time()
    
    def decay_to_baseline(self, baseline_happiness: float = 0.5):
        """
        Decay emotions toward baseline over time
        Call this periodically (e.g., each game tick)
        """
        now = time.time()
        elapsed = now - self.last_update
        
        # Decay rate per second
        decay = 0.02 * elapsed
        
        # Happiness decays toward baseline
        if self.happiness > baseline_happiness:
            self.happiness = max(baseline_happiness, self.happiness - decay)
        else:
            self.happiness = min(baseline_happiness, self.happiness + decay)
        
        # Negative emotions decay toward zero
        self.anger = max(0.0, self.anger - decay)
        self.fear = max(0.0, self.fear - decay)
        self.sadness = max(0.0, self.sadness - decay)
        self.surprise = max(0.0, self.surprise - decay * 2)  # Surprise fades faster
        
        self.last_update = now
    
    def _clamp(self, value: float) -> float:
        return max(0.0, min(1.0, value))
    
    def get_mood_description(self) -> str:
        """Get a text description of current mood"""
        emotion = self.dominant_emotion()
        intensity = self._get_intensity()
        
        descriptions = {
            Emotion.HAPPY: ["content", "happy", "joyful", "elated"],
            Emotion.ANGRY: ["annoyed", "irritated", "angry", "furious"],
            Emotion.FEARFUL: ["uneasy", "nervous", "afraid", "terrified"],
            Emotion.SAD: ["melancholy", "sad", "sorrowful", "devastated"],
            Emotion.SURPRISED: ["curious", "surprised", "shocked", "stunned"],
            Emotion.NEUTRAL: ["calm", "neutral", "composed", "indifferent"],
        }
        
        words = descriptions.get(emotion, ["neutral"])
        idx = min(int(intensity * len(words)), len(words) - 1)
        return words[idx]
    
    def _get_intensity(self) -> float:
        """Get intensity of dominant emotion"""
        values = [self.happiness, self.anger, self.fear, self.sadness, self.surprise]
        return max(values)
    
    def to_prompt_context(self) -> str:
        """Format emotional state for LLM prompt"""
        mood = self.get_mood_description()
        emotion = self.dominant_emotion().value
        
        details = []
        if self.anger > 0.2:
            details.append(f"somewhat irritated")
        if self.fear > 0.2:
            details.append(f"a bit nervous")
        if self.sadness > 0.2:
            details.append(f"feeling down")
        
        base = f"Currently feeling {mood}"
        if details:
            base += f" ({', '.join(details)})"
        
        return base
    
    def to_dict(self) -> Dict:
        return {
            "happiness": self.happiness,
            "anger": self.anger,
            "fear": self.fear,
            "sadness": self.sadness,
            "surprise": self.surprise,
            "inertia": self.inertia
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'EmotionalState':
        return cls(**data)


# Emotional stimulus presets for common events
class EmotionalStimuli:
    """Preset emotional responses to common events"""
    
    COMPLIMENTED = {"happiness_delta": 0.2, "anger_delta": -0.1}
    INSULTED = {"happiness_delta": -0.2, "anger_delta": 0.3}
    THREATENED = {"fear_delta": 0.4, "anger_delta": 0.2}
    GIVEN_GIFT = {"happiness_delta": 0.3, "surprise_delta": 0.1}
    ATTACKED = {"fear_delta": 0.3, "anger_delta": 0.4, "happiness_delta": -0.3}
    HELPED = {"happiness_delta": 0.2, "sadness_delta": -0.1}
    ROBBED = {"anger_delta": 0.5, "sadness_delta": 0.2, "happiness_delta": -0.4}
    GREETED = {"happiness_delta": 0.1}
    IGNORED = {"sadness_delta": 0.1, "happiness_delta": -0.05}
