"""
Super NPC Memory System
Generative agents-style memory with importance scoring and retrieval
"""

import time
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime
import json


@dataclass
class Memory:
    """A single memory with metadata"""
    content: str
    importance: int  # 1-10 scale
    timestamp: float = field(default_factory=time.time)
    memory_type: str = "observation"  # observation, reflection, dialogue
    related_entity: Optional[str] = None
    
    def age_hours(self) -> float:
        """How old is this memory in hours"""
        return (time.time() - self.timestamp) / 3600
    
    def recency_score(self) -> float:
        """Decay score based on age (exponential decay)"""
        decay_rate = 0.995
        hours = self.age_hours()
        return decay_rate ** hours
    
    def retrieval_score(self, relevance: float = 1.0) -> float:
        """Combined score for memory retrieval"""
        # Weighted combination: importance, recency, relevance
        norm_importance = self.importance / 10.0
        recency = self.recency_score()
        return (norm_importance * 0.4) + (recency * 0.3) + (relevance * 0.3)
    
    def to_dict(self) -> dict:
        return {
            "content": self.content,
            "importance": self.importance,
            "timestamp": self.timestamp,
            "memory_type": self.memory_type,
            "related_entity": self.related_entity
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Memory':
        return cls(**data)


class MemoryStore:
    """
    Memory storage and retrieval system
    Supports importance-based filtering and recency decay
    """
    
    def __init__(self, max_memories: int = 100):
        self.memories: List[Memory] = []
        self.max_memories = max_memories
        self.reflection_threshold = 5  # Trigger reflection after N new memories
        self.memories_since_reflection = 0
    
    def add(self, content: str, importance: int = 5, 
            memory_type: str = "observation", 
            related_entity: Optional[str] = None) -> Memory:
        """Add a new memory"""
        memory = Memory(
            content=content,
            importance=min(10, max(1, importance)),
            memory_type=memory_type,
            related_entity=related_entity
        )
        self.memories.append(memory)
        self.memories_since_reflection += 1
        
        # Prune if over limit (remove lowest scoring memories)
        if len(self.memories) > self.max_memories:
            self._prune()
        
        return memory
    
    def add_dialogue(self, speaker: str, message: str, 
                     response: str, importance: int = 5) -> Memory:
        """Add a dialogue memory"""
        content = f"{speaker} said: '{message}'. I replied: '{response}'."
        return self.add(content, importance, "dialogue", speaker)
    
    def retrieve(self, query: Optional[str] = None, 
                 limit: int = 5,
                 entity_filter: Optional[str] = None) -> List[Memory]:
        """
        Retrieve top memories by relevance
        For now uses simple keyword matching; could add embeddings later
        """
        candidates = self.memories
        
        # Filter by entity if specified
        if entity_filter:
            candidates = [m for m in candidates 
                         if m.related_entity == entity_filter or m.related_entity is None]
        
        # Score each memory
        scored = []
        for mem in candidates:
            # Simple keyword relevance (could upgrade to embeddings)
            relevance = 1.0
            if query:
                query_lower = query.lower()
                content_lower = mem.content.lower()
                # Count matching words
                query_words = set(query_lower.split())
                content_words = set(content_lower.split())
                overlap = len(query_words & content_words)
                relevance = min(1.0, overlap / max(len(query_words), 1) + 0.3)
            
            score = mem.retrieval_score(relevance)
            scored.append((score, mem))
        
        # Sort by score descending
        scored.sort(key=lambda x: x[0], reverse=True)
        return [mem for _, mem in scored[:limit]]
    
    def get_recent(self, limit: int = 5) -> List[Memory]:
        """Get most recent memories"""
        sorted_mems = sorted(self.memories, 
                            key=lambda m: m.timestamp, 
                            reverse=True)
        return sorted_mems[:limit]
    
    def should_reflect(self) -> bool:
        """Check if it's time to generate a reflection"""
        return self.memories_since_reflection >= self.reflection_threshold
    
    def add_reflection(self, reflection: str) -> Memory:
        """Add a reflection (higher base importance)"""
        self.memories_since_reflection = 0
        return self.add(reflection, importance=8, memory_type="reflection")
    
    def _prune(self):
        """Remove lowest-scoring memories to stay under limit"""
        scored = [(m.retrieval_score(), m) for m in self.memories]
        scored.sort(key=lambda x: x[0], reverse=True)
        self.memories = [m for _, m in scored[:self.max_memories]]
    
    def format_for_prompt(self, memories: List[Memory]) -> str:
        """Format memories for inclusion in LLM prompt"""
        if not memories:
            return "No relevant memories."
        
        lines = []
        for mem in memories:
            age = mem.age_hours()
            if age < 1:
                time_str = "just now"
            elif age < 24:
                time_str = f"{int(age)} hours ago"
            else:
                time_str = f"{int(age/24)} days ago"
            lines.append(f"- [{time_str}] {mem.content}")
        
        return "\n".join(lines)
    
    def save(self, filepath: str):
        """Save memories to JSON file"""
        data = [m.to_dict() for m in self.memories]
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load(self, filepath: str):
        """Load memories from JSON file"""
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            self.memories = [Memory.from_dict(d) for d in data]
        except FileNotFoundError:
            pass  # Start fresh
