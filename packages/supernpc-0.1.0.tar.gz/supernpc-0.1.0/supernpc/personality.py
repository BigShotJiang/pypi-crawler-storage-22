"""
Super NPC Personality System
Big Five personality traits affecting NPC behavior
"""

from dataclasses import dataclass
from typing import Dict
import random


@dataclass
class Personality:
    """
    Big Five personality model (OCEAN)
    All values range from 0.0 to 1.0
    """
    openness: float = 0.5        # Curiosity, creativity, preference for novelty
    conscientiousness: float = 0.5  # Organization, dependability, self-discipline
    extraversion: float = 0.5    # Sociability, assertiveness, positive emotions
    agreeableness: float = 0.5   # Cooperation, trust, helpfulness
    neuroticism: float = 0.5     # Emotional instability, anxiety, moodiness
    
    @classmethod
    def merchant(cls) -> 'Personality':
        """Typical merchant personality"""
        return cls(
            openness=0.5,
            conscientiousness=0.7,
            extraversion=0.7,
            agreeableness=0.6,
            neuroticism=0.3
        )
    
    @classmethod
    def guard(cls) -> 'Personality':
        """Typical guard personality"""
        return cls(
            openness=0.3,
            conscientiousness=0.8,
            extraversion=0.4,
            agreeableness=0.4,
            neuroticism=0.3
        )
    
    @classmethod
    def villager(cls) -> 'Personality':
        """Typical villager personality"""
        return cls(
            openness=0.4,
            conscientiousness=0.5,
            extraversion=0.5,
            agreeableness=0.7,
            neuroticism=0.4
        )
    
    @classmethod
    def scholar(cls) -> 'Personality':
        """Typical scholar personality"""
        return cls(
            openness=0.9,
            conscientiousness=0.7,
            extraversion=0.3,
            agreeableness=0.5,
            neuroticism=0.4
        )
    
    @classmethod
    def rogue(cls) -> 'Personality':
        """Typical rogue/thief personality"""
        return cls(
            openness=0.6,
            conscientiousness=0.3,
            extraversion=0.5,
            agreeableness=0.2,
            neuroticism=0.5
        )
    
    @classmethod
    def random(cls) -> 'Personality':
        """Generate a random personality"""
        return cls(
            openness=random.uniform(0.2, 0.8),
            conscientiousness=random.uniform(0.2, 0.8),
            extraversion=random.uniform(0.2, 0.8),
            agreeableness=random.uniform(0.2, 0.8),
            neuroticism=random.uniform(0.2, 0.8)
        )
    
    def get_chattiness(self) -> float:
        """How much the NPC talks (affects response length)"""
        return (self.extraversion * 0.6 + self.openness * 0.4)
    
    def get_friendliness(self) -> float:
        """How friendly the NPC is to strangers"""
        return (self.agreeableness * 0.5 + self.extraversion * 0.3 + 
                (1 - self.neuroticism) * 0.2)
    
    def get_trust_rate(self) -> float:
        """How quickly the NPC builds trust"""
        return self.agreeableness * 0.7 + (1 - self.neuroticism) * 0.3
    
    def get_emotional_stability(self) -> float:
        """How stable emotions are (affects inertia)"""
        return 1 - self.neuroticism
    
    def get_helpfulness(self) -> float:
        """How likely to help strangers"""
        return self.agreeableness * 0.6 + self.conscientiousness * 0.4
    
    def to_prompt_context(self) -> str:
        """Generate personality description for LLM prompt"""
        traits = []
        
        if self.openness > 0.7:
            traits.append("curious and imaginative")
        elif self.openness < 0.3:
            traits.append("practical and traditional")
        
        if self.conscientiousness > 0.7:
            traits.append("organized and reliable")
        elif self.conscientiousness < 0.3:
            traits.append("spontaneous and flexible")
        
        if self.extraversion > 0.7:
            traits.append("outgoing and talkative")
        elif self.extraversion < 0.3:
            traits.append("reserved and quiet")
        
        if self.agreeableness > 0.7:
            traits.append("friendly and trusting")
        elif self.agreeableness < 0.3:
            traits.append("skeptical and competitive")
        
        if self.neuroticism > 0.7:
            traits.append("easily stressed and emotional")
        elif self.neuroticism < 0.3:
            traits.append("calm and emotionally stable")
        
        if not traits:
            return "balanced and moderate personality"
        
        return ", ".join(traits)
    
    def to_dict(self) -> Dict:
        return {
            "openness": self.openness,
            "conscientiousness": self.conscientiousness,
            "extraversion": self.extraversion,
            "agreeableness": self.agreeableness,
            "neuroticism": self.neuroticism
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Personality':
        return cls(**data)
