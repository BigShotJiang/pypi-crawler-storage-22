"""
Super NPC Relationship System
Tracks trust, familiarity, and relationship history between NPCs and players
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
import time


@dataclass
class Relationship:
    """Relationship with a specific entity"""
    entity_id: str
    trust: float = 0.0          # -1.0 (enemy) to 1.0 (trusted friend)
    familiarity: float = 0.0    # 0.0 (stranger) to 1.0 (well known)
    interactions: int = 0
    last_interaction: float = field(default_factory=time.time)
    
    # Relationship tags
    tags: List[str] = field(default_factory=list)
    
    def update_interaction(self, trust_delta: float = 0.0):
        """Record an interaction"""
        self.interactions += 1
        self.last_interaction = time.time()
        
        # Familiarity grows with interactions (diminishing returns)
        familiarity_gain = 0.1 / (1 + self.familiarity * 2)
        self.familiarity = min(1.0, self.familiarity + familiarity_gain)
        
        # Trust changes based on interaction
        self.trust = max(-1.0, min(1.0, self.trust + trust_delta))
    
    def add_tag(self, tag: str):
        """Add a relationship tag"""
        if tag not in self.tags:
            self.tags.append(tag)
    
    def has_tag(self, tag: str) -> bool:
        return tag in self.tags
    
    def get_relationship_level(self) -> str:
        """Get a description of the relationship"""
        if self.trust < -0.5:
            return "enemy"
        elif self.trust < -0.2:
            return "disliked"
        elif self.trust < 0.2:
            if self.familiarity < 0.3:
                return "stranger"
            else:
                return "acquaintance"
        elif self.trust < 0.5:
            return "friendly"
        elif self.trust < 0.8:
            return "friend"
        else:
            return "trusted friend"
    
    def to_prompt_context(self) -> str:
        """Format for LLM prompt"""
        level = self.get_relationship_level()
        
        if self.familiarity < 0.1:
            met = "never met before"
        elif self.familiarity < 0.3:
            met = f"met {self.interactions} times"
        else:
            met = f"known well ({self.interactions} interactions)"
        
        context = f"{level} ({met})"
        
        if self.tags:
            context += f", notable: {', '.join(self.tags)}"
        
        return context


class RelationshipTracker:
    """Manages all relationships for an NPC"""
    
    def __init__(self, default_trust: float = 0.0):
        self.relationships: Dict[str, Relationship] = {}
        self.default_trust = default_trust
    
    def get(self, entity_id: str) -> Relationship:
        """Get or create relationship with entity"""
        if entity_id not in self.relationships:
            self.relationships[entity_id] = Relationship(
                entity_id=entity_id,
                trust=self.default_trust
            )
        return self.relationships[entity_id]
    
    def update(self, entity_id: str, trust_delta: float = 0.0) -> Relationship:
        """Update relationship after interaction"""
        rel = self.get(entity_id)
        rel.update_interaction(trust_delta)
        return rel
    
    def add_tag(self, entity_id: str, tag: str):
        """Add tag to relationship"""
        self.get(entity_id).add_tag(tag)
    
    def get_trust(self, entity_id: str) -> float:
        """Get trust level with entity"""
        return self.get(entity_id).trust
    
    def is_enemy(self, entity_id: str) -> bool:
        """Check if entity is considered an enemy"""
        return self.get(entity_id).trust < -0.5
    
    def is_friend(self, entity_id: str) -> bool:
        """Check if entity is considered a friend"""
        return self.get(entity_id).trust > 0.5
    
    def get_all_friends(self) -> List[Relationship]:
        """Get all friendly relationships"""
        return [r for r in self.relationships.values() if r.trust > 0.3]
    
    def get_all_enemies(self) -> List[Relationship]:
        """Get all hostile relationships"""
        return [r for r in self.relationships.values() if r.trust < -0.3]
    
    def to_dict(self) -> Dict:
        return {
            "default_trust": self.default_trust,
            "relationships": {
                k: {
                    "trust": v.trust,
                    "familiarity": v.familiarity,
                    "interactions": v.interactions,
                    "tags": v.tags
                }
                for k, v in self.relationships.items()
            }
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'RelationshipTracker':
        tracker = cls(default_trust=data.get("default_trust", 0.0))
        for entity_id, rel_data in data.get("relationships", {}).items():
            rel = Relationship(
                entity_id=entity_id,
                trust=rel_data["trust"],
                familiarity=rel_data["familiarity"],
                interactions=rel_data["interactions"],
                tags=rel_data.get("tags", [])
            )
            tracker.relationships[entity_id] = rel
        return tracker
