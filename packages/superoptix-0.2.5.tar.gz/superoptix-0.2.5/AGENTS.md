# Repository Guidelines

## Project Structure & Module Organization
- `superoptix/`: core framework code (CLI, agents, compiler, memory, tools).
- `tests/`: pytest suite.
- `docs/`: documentation sources (MkDocs).
- `pyproject.toml`, `ruff.toml`, `tox.ini`: tooling and config.

## Build, Test, and Development Commands
- `pip install -e .`: install in editable mode for local development.
- `super --help`: verify the CLI entry point (`super`) and available commands.
- `uv build`: build a wheel with uv.
- `uv run python -m build --wheel`: alternative if `uv build` is unavailable.
- `python -m pytest`: run tests in `tests/`.
- `tox`: run formatting (Black), linting (Flake8), and tests together.

## Coding Style & Naming Conventions
- Indentation: 4 spaces; line length 88 (Black/Ruff).
- Formatting: `black .` keeps code consistent.
- Linting: `flake8 .` in CI, with `ruff.toml` for local checks if preferred.
- Naming: `snake_case` for modules/functions, `PascalCase` for classes, constants in `UPPER_CASE`.

## Testing Guidelines
- Framework: `pytest` with markers (`unit`, `integration`, `slow`).
- Test location: `tests/` with `test_*.py` naming.
- Coverage: configured to measure `superoptix/` in `pyproject.toml`.

## Commit & Pull Request Guidelines
- Commits: short, imperative summaries (e.g., “Fix MCP issue”, “Bump Version”).
- PRs: include a clear description, link related issues, and note any API changes.
- Screenshots/logs: required for CLI UX changes or user-facing errors.

## Security & Configuration Tips
- Keep secrets in `.env` (loaded via `python-dotenv`); never commit credentials.
- Ensure Python 3.11+ and set required provider keys for LLM frameworks.

## Contribution Notes
- **Open Source**: This project is open source and welcomes contributions.
- Use GitHub issues for bugs or feature requests and include repro steps.
