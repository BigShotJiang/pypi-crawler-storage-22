---
title: Tutorials
description: Step-by-step tutorials for building AI agents with SuperOptiX
---

# 🎓 Tutorials

Welcome to the SuperOptiX tutorials! These step-by-step guides will take you from complete beginner to building sophisticated AI agents and orchestras.

## 🚀 Getting Started Tutorials

### 1. 🎯 [Create Your First Genies Agent](genies-agent)

**Perfect for beginners!** Build your first Genies-tier AI agent with tools and RAG capabilities.

**What you'll learn:**
- Initialize a SuperOptiX project
- Generate a Genies-tier developer agent with RAG & tools
- Compile and understand the agent pipeline
- Set up for evaluation and optimization

**Time:** 10-15 minutes  
**Difficulty:** Beginner  
**Prerequisites:** None

### 2. 🔧 [OpenAI SDK + GEPA Optimization](openai-sdk-gepa-optimization)

**Build custom agents with native OpenAI SDK!** Create a production-ready code reviewer using official OpenAI Agents SDK patterns and optimize it with GEPA.

**What you'll learn:**
- Write agents using official OpenAI SDK patterns
- Integrate native SDK agents with SuperOptiX
- Define BDD test scenarios for measurable metrics
- Run GEPA optimization to improve performance
- Implement automatic optimization loading

**Time:** 30-45 minutes
**Difficulty:** Intermediate
**Prerequisites:** Basic Python, Ollama installed

### 3. 🎭 [Multi-Agent Orchestra](first-orchestra)

**Advanced tutorial** - Coordinate multiple agents to solve complex problems.

**What you'll learn:**
- Design multi-agent workflows
- Implement agent communication
- Handle complex orchestration scenarios
- Deploy production-ready systems

**Time:** 30-45 minutes
**Difficulty:** Advanced
**Prerequisites:** First Agent Tutorial

## 🎯 Prerequisites

Before starting the tutorials, ensure you have:

1. **SuperOptix installed** - See our [Setup Guide](../setup)
2. **Python 3.8+** - Latest stable version recommended
3. **Basic Python knowledge** - Familiarity with functions and classes
4. **Text editor** - VS Code, PyCharm, or any code editor

## 🛠️ What You'll Build

### Tutorial 1: Genies Agent
- A Genies-tier developer agent
- Tool calling capabilities (web search, calculator, file operations)
- RAG system integration
- Memory and observability features

### Tutorial 2: OpenAI SDK Code Reviewer
- Production-ready code reviewer agent
- Native OpenAI Agents SDK implementation
- GEPA-optimized prompts (75% → 100% pass rate)
- BDD test scenarios for validation
- Automatic optimization loading

### Tutorial 3: Multi-Agent Orchestra
- Customer service workflow
- Multiple specialized agents
- Coordinated problem-solving

## 📚 Additional Resources

After completing the tutorials, explore:

- [Core Concepts](../guides/index) - Deep dive into SuperOptix fundamentals
- [Guides](../guides/index) - Techniques and integrations
- [Reference](../reference/index) - API documentation and CLI reference

## 🆘 Need Help?

- **Stuck?** Check our [Troubleshooting Guide](../troubleshooting)
- **Questions?** Visit our [FAQ](../faq)

---

Ready to build your first AI agent? Start with the [Genies Agent Tutorial](genies-agent) 🚀 