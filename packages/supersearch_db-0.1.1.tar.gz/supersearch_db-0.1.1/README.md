# SuperSearch Python SDK

A simple Python client for the SuperSearch Product API.

## Installation

```bash
pip install supersearch-db
```

## Quick Start

```python
from supersearch import SuperSearch

# Initialize client with your API key
client = SuperSearch(api_key="YOUR_API_KEY")

# Search for products
results = client.search("blue cotton hoodie under 2000 for men", limit=10)

for product in results:
    print(f"{product['title']} - ₹{product['price']}")
```

## API Reference

### `SuperSearch(api_key, base_url=None)`

Initialize the client.

- `api_key` (str): Your SuperSearch API key
- `base_url` (str, optional): Custom API base URL

### `search(query, limit=10)`

Search products using natural language.

- `query` (str): Natural language search query
- `limit` (int): Maximum results (default: 10, max: 250)
- Returns: List of product dictionaries

### `pdp_search(query, limit=10)`

AEO-optimized search for AI agents.

- `query` (str): Natural language search query  
- `limit` (int): Maximum results (default: 10, max: 250)
- Returns: List of detailed product dictionaries

### `suggestions()`

Get example search queries.

- Returns: List of example query strings

## Example Queries

```python
# Filter by attributes
results = client.search("red nike running shoes for women")

# Price filtering
results = client.search("cotton t-shirt under 1500")

# Material + gender
results = client.search("leather jacket for men")

# Get suggestions
suggestions = client.suggestions()
```

## Need an API Key?

Contact us at supersearch00@gmail.com to request access.

## Links

- **PyPI:** https://pypi.org/project/supersearch-db/
