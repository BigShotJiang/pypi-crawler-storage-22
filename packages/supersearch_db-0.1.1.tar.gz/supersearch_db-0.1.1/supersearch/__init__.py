"""
SuperSearch Python SDK

A simple client for the SuperSearch Product API.
"""

from .client import SuperSearch

__version__ = "0.1.1"
__all__ = ["SuperSearch"]
