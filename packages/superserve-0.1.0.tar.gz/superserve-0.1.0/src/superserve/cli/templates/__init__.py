"""CLI templates for agentic-ray."""
