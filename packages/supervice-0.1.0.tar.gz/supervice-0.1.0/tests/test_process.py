import asyncio
import os
import tempfile
import unittest

from supervice.events import EventBus
from supervice.models import ProgramConfig
from supervice.process import (
    BACKOFF,
    EXITED,
    FATAL,
    RUNNING,
    STOPPED,
    Process,
)


class TestProcessLifecycle(unittest.TestCase):
    def setUp(self) -> None:
        self.event_bus = EventBus()

    def test_spawn_success(self) -> None:
        """Test successful process spawn and exit."""

        async def run() -> None:
            self.event_bus.start()
            config = ProgramConfig(name="test", command="echo hello")
            process = Process(config, self.event_bus)

            await process.spawn()

            self.assertEqual(process.state, EXITED)
            self.assertIsNotNone(process.process)
            self.assertEqual(process.process.returncode, 0)

            await self.event_bus.stop()

        asyncio.run(run())

    def test_spawn_failure_command_not_found(self) -> None:
        """Test spawn with invalid command transitions to FATAL."""

        async def run() -> None:
            self.event_bus.start()
            config = ProgramConfig(name="test", command="nonexistent_cmd_xyz_12345")
            process = Process(config, self.event_bus)

            await process.spawn()

            self.assertEqual(process.state, FATAL)

            await self.event_bus.stop()

        asyncio.run(run())

    def test_kill_process(self) -> None:
        """Test killing a running process transitions to STOPPED."""

        async def run() -> None:
            self.event_bus.start()
            config = ProgramConfig(name="test", command="sleep 60")
            process = Process(config, self.event_bus)

            # Start spawn in background
            spawn_task = asyncio.create_task(process.spawn())
            await asyncio.sleep(0.3)  # Let it start

            self.assertEqual(process.state, RUNNING)

            await process.kill()

            self.assertEqual(process.state, STOPPED)

            # Clean up spawn task
            try:
                await asyncio.wait_for(spawn_task, timeout=1)
            except asyncio.TimeoutError:
                spawn_task.cancel()

            await self.event_bus.stop()

        asyncio.run(run())

    def test_kill_process_group(self) -> None:
        """Test that kill terminates child processes too."""

        async def run() -> None:
            self.event_bus.start()
            # Script that spawns a child process
            cmd = "sh -c 'sleep 60 & sleep 60'"
            config = ProgramConfig(name="test", command=cmd)
            process = Process(config, self.event_bus)

            spawn_task = asyncio.create_task(process.spawn())
            await asyncio.sleep(0.3)  # Let processes start

            self.assertEqual(process.state, RUNNING)
            pid = process.process.pid

            await process.kill()

            self.assertEqual(process.state, STOPPED)

            # Verify process group is gone - attempting to get pgid should fail
            await asyncio.sleep(0.1)  # Small delay for cleanup
            with self.assertRaises(ProcessLookupError):
                os.getpgid(pid)

            try:
                await asyncio.wait_for(spawn_task, timeout=1)
            except asyncio.TimeoutError:
                spawn_task.cancel()

            await self.event_bus.stop()

        asyncio.run(run())

    def test_restart_on_failure(self) -> None:
        """Test that process restarts after failure with autorestart=True."""

        async def run() -> None:
            self.event_bus.start()
            config = ProgramConfig(
                name="test",
                command="sh -c 'exit 1'",
                autorestart=True,
                startretries=3,
                startsecs=0,
            )
            process = Process(config, self.event_bus)
            process.should_run = True

            spawn_count = 0
            original_spawn = process.spawn

            async def counting_spawn() -> None:
                nonlocal spawn_count
                spawn_count += 1
                await original_spawn()

            process.spawn = counting_spawn

            # Run supervision loop briefly - enough for a few retries
            task = asyncio.create_task(process.supervise())
            await asyncio.sleep(2.5)
            process.stop_event.set()

            try:
                await asyncio.wait_for(task, timeout=2)
            except asyncio.TimeoutError:
                task.cancel()

            # Verify multiple spawn attempts occurred (autorestart working)
            self.assertGreaterEqual(spawn_count, 2)
            # Process should be in BACKOFF or EXITED state (retry loop)
            self.assertIn(process.state, (BACKOFF, EXITED, FATAL))

            await self.event_bus.stop()

        asyncio.run(run())

    def test_file_handles_closed_on_error(self) -> None:
        """Test file handles are closed even if spawn fails."""

        async def run() -> None:
            self.event_bus.start()

            with tempfile.TemporaryDirectory() as tmpdir:
                log_file = os.path.join(tmpdir, "test.log")
                config = ProgramConfig(
                    name="test",
                    command="nonexistent_cmd_xyz_12345",
                    stdout_logfile=log_file,
                )
                process = Process(config, self.event_bus)

                await process.spawn()

                self.assertEqual(process.state, FATAL)

                # File should be closed - we can open it again without issue
                with open(log_file, "a") as f:
                    f.write("test")

                # Verify file exists and has content
                with open(log_file) as f:
                    content = f.read()
                self.assertEqual(content, "test")

            await self.event_bus.stop()

        asyncio.run(run())

    def test_file_handles_closed_on_success(self) -> None:
        """Test file handles are closed after successful spawn."""

        async def run() -> None:
            self.event_bus.start()

            with tempfile.TemporaryDirectory() as tmpdir:
                stdout_log = os.path.join(tmpdir, "stdout.log")
                stderr_log = os.path.join(tmpdir, "stderr.log")
                config = ProgramConfig(
                    name="test",
                    command="sh -c 'echo out; echo err >&2'",
                    stdout_logfile=stdout_log,
                    stderr_logfile=stderr_log,
                )
                process = Process(config, self.event_bus)

                await process.spawn()

                self.assertEqual(process.state, EXITED)

                # Verify files can be opened and contain expected output
                with open(stdout_log) as f:
                    self.assertIn("out", f.read())
                with open(stderr_log) as f:
                    self.assertIn("err", f.read())

            await self.event_bus.stop()

        asyncio.run(run())

    def test_process_with_environment(self) -> None:
        """Test process runs with custom environment variables."""

        async def run() -> None:
            self.event_bus.start()

            with tempfile.TemporaryDirectory() as tmpdir:
                out_file = os.path.join(tmpdir, "out.txt")
                config = ProgramConfig(
                    name="test",
                    command=f"sh -c 'echo $MY_VAR > {out_file}'",
                    environment={"MY_VAR": "test_value"},
                )
                process = Process(config, self.event_bus)

                await process.spawn()

                self.assertEqual(process.state, EXITED)

                with open(out_file) as f:
                    content = f.read().strip()
                self.assertEqual(content, "test_value")

            await self.event_bus.stop()

        asyncio.run(run())

    def test_process_with_directory(self) -> None:
        """Test process runs in specified directory."""

        async def run() -> None:
            self.event_bus.start()

            with tempfile.TemporaryDirectory() as tmpdir:
                # Resolve symlinks (macOS: /var -> /private/var)
                tmpdir_resolved = os.path.realpath(tmpdir)
                out_file = os.path.join(tmpdir, "cwd.txt")
                config = ProgramConfig(
                    name="test",
                    command=f"sh -c 'pwd > {out_file}'",
                    directory=tmpdir,
                )
                process = Process(config, self.event_bus)

                await process.spawn()

                self.assertEqual(process.state, EXITED)

                with open(out_file) as f:
                    cwd = f.read().strip()
                self.assertEqual(cwd, tmpdir_resolved)

            await self.event_bus.stop()

        asyncio.run(run())

    def test_start_stop_process_rpc(self) -> None:
        """Test start_process and stop_process RPC methods."""

        async def run() -> None:
            self.event_bus.start()
            config = ProgramConfig(
                name="test",
                command="sleep 60",
                autostart=False,
            )
            process = Process(config, self.event_bus)

            # Start supervision loop
            task = asyncio.create_task(process.supervise())
            await asyncio.sleep(0.1)

            self.assertEqual(process.state, STOPPED)

            # Start process via RPC
            await process.start_process()
            self.assertEqual(process.state, RUNNING)

            # Stop process via RPC
            await process.stop_process()
            self.assertEqual(process.state, STOPPED)

            # Clean up
            process.stop_event.set()
            try:
                await asyncio.wait_for(task, timeout=2)
            except asyncio.TimeoutError:
                task.cancel()

            await self.event_bus.stop()

        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
