# Suprema BioStar MCP Server

MCP (Model Context Protocol) server for **Suprema BioStar X** - Next-generation access control platform integration for AI assistants.

> **🚀 One-Click Installation**: `uvx suprema-biostar-mcp`

## Features

- **129+ Tools**: Full BioStar X API coverage (users, doors, devices, access control, events, and more)
- **Lightweight**: No heavy ML dependencies (~50MB vs 900MB)
- **Live Documentation**: Real-time docs from docs.supremainc.com
- **Multi-language**: Korean and English support
- **Easy Setup**: Works with Claude Desktop, Claude Code, and any MCP client

## Quick Start

### 1. Add to Claude Desktop

Edit your Claude Desktop config file:

- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "suprema-biostar": {
      "command": "uvx",
      "args": ["suprema-biostar-mcp"],
      "env": {
        "BIOSTAR_URL": "https://your-biostar-server.com",
        "BIOSTAR_USERNAME": "admin",
        "BIOSTAR_PASSWORD": "your-password"
      }
    }
  }
}
```

### 2. Restart Claude Desktop

That's it! 🎉

## Configuration

| Environment Variable | Required | Description |
|---------------------|----------|-------------|
| `BIOSTAR_URL` | ✅ | BioStar X server URL (e.g., `https://192.168.1.100`) |
| `BIOSTAR_USERNAME` | ✅ | Login username |
| `BIOSTAR_PASSWORD` | ✅ | Login password |
| `VERIFY_SSL` | ❌ | SSL verification (default: `true`) |
| `API_TIMEOUT` | ❌ | API timeout in seconds (default: `30`) |

### Changing Credentials

1. Edit `claude_desktop_config.json`
2. Update the `env` values
3. Restart Claude Desktop

## Available Tools (129+)

| Category | Tools | Description |
|----------|-------|-------------|
| **auth** | 4 | Login, logout, session management |
| **users** | 23 | User CRUD, groups, CSV import/export |
| **doors** | 22 | Door control, groups, APB settings |
| **access** | 13 | Access groups and levels |
| **devices** | 38 | Device management, network config |
| **cards** | 5 | Card creation (CSN, Wiegand, QR) |
| **events** | 6 | Event search, logs, export |
| **audit** | 6 | Audit trail tracking |
| **occupancy** | 2 | Occupancy analysis |
| **logs** | 5 | Server log analysis |
| **files** | 1 | File reading (CSV, PDF) |
| **navigation** | 1 | UI navigation |
| **help** | 3 | Documentation search |

## Example Usage

Once connected to Claude:

```
"List all users"
"Create a user named John Smith"
"Open the main entrance door"
"Show access events from today"
"How do I configure anti-passback?"
```

## Alternative Installation

### Using pip

```bash
pip install suprema-biostar-mcp
suprema-biostar-mcp
```

### From source

```bash
git clone https://github.com/supremainc/suprema-biostar-mcp.git
cd suprema-biostar-mcp
pip install -e .
python -m biostar_x_mcp_server
```

## Requirements

- Python 3.10+
- BioStar X server with API access
- Network connectivity to BioStar server
- [uv](https://docs.astral.sh/uv/) for `uvx` command (recommended)

## Documentation

- **BioStar X Docs**: https://docs.supremainc.com/en/platform/biostar_x
- **MCP Protocol**: https://modelcontextprotocol.io

## Support

- **Suprema Support**: https://www.supremainc.com/support
- **Documentation**: https://docs.supremainc.com

---

Made with ❤️ by [Suprema Inc.](https://www.supremainc.com)
