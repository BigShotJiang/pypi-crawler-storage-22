"""
BioStar X MCP Server
Lightweight MCP server for BioStar X integration

Features:
- Full BioStar X API integration (138+ tools)
- Web-based documentation (no vector DB required)
- Dynamic tool category loading
- Session management with auto-refresh
- Multi-language support (Korean/English)
"""

__version__ = "1.0.0"
__author__ = "Suprema Inc."

from .config import Config
from .session import BioStarSession
from .tool_manager import ToolManager

__all__ = [
    "Config",
    "BioStarSession",
    "ToolManager",
    "__version__"
]
