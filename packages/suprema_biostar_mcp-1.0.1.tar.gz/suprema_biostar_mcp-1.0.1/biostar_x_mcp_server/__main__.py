"""
BioStar X MCP Server - Main Entry Point
Run with: python -m biostar_x_mcp_server
"""
import asyncio
import sys
from pathlib import Path

# Ensure the parent directory is in the path
sys.path.insert(0, str(Path(__file__).parent.parent))

from .server import main

if __name__ == "__main__":
    asyncio.run(main())
