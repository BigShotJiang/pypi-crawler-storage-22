"""
BioStar X MCP Server Configuration
Lightweight configuration without vector DB dependencies
"""
import os
from typing import Optional
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()


class Config(BaseModel):
    """Configuration for BioStar X MCP Server (Lightweight)."""

    # BioStar X API settings
    biostar_url: str = Field(
        default_factory=lambda: os.getenv("BIOSTAR_URL", "https://localhost"),
        description="BioStar X server URL"
    )
    biostar_username: str = Field(
        default_factory=lambda: os.getenv("BIOSTAR_USERNAME", ""),
        description="BioStar X username"
    )
    biostar_password: str = Field(
        default_factory=lambda: os.getenv("BIOSTAR_PASSWORD", ""),
        description="BioStar X password"
    )

    # API settings
    api_timeout: int = Field(
        default_factory=lambda: int(os.getenv("API_TIMEOUT", "30")),
        description="API request timeout in seconds"
    )
    verify_ssl: bool = Field(
        default_factory=lambda: os.getenv("VERIFY_SSL", "true").lower() == "true",
        description="Verify SSL certificates"
    )

    # Session settings
    session_refresh_interval: int = Field(
        default_factory=lambda: int(os.getenv("SESSION_REFRESH_INTERVAL", "3600")),
        description="Session refresh interval in seconds"
    )

    # Server settings
    debug: bool = Field(
        default_factory=lambda: os.getenv("DEBUG", "false").lower() == "true",
        description="Enable debug mode"
    )

    # Tool loading settings
    default_categories: list[str] = Field(
        default=["auth"],
        description="Categories to load by default"
    )
    max_active_categories: int = Field(
        default=15,
        description="Maximum number of active tool categories"
    )

    # Documentation settings (Web-based help)
    docs_base_url: str = Field(
        default_factory=lambda: os.getenv("DOCS_BASE_URL", "https://docs.supremainc.com"),
        description="Base URL for BioStar X documentation"
    )
    docs_cache_ttl: int = Field(
        default_factory=lambda: int(os.getenv("DOCS_CACHE_TTL", "3600")),
        description="Documentation cache TTL in seconds"
    )

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    def validate_required(self) -> list[str]:
        """Validate required configuration and return list of errors."""
        errors = []

        if not self.biostar_url:
            errors.append("BIOSTAR_URL is required")
        if not self.biostar_username:
            errors.append("BIOSTAR_USERNAME is required")
        if not self.biostar_password:
            errors.append("BIOSTAR_PASSWORD is required")

        return errors
