import logging
import csv
import io
import os
import platform
import shutil
import re
import uuid
from pathlib import Path
from typing import Sequence, Dict, Any
from mcp.types import TextContent
import httpx
from .base_handler import BaseHandler

logger = logging.getLogger(__name__)


class AuditHandler(BaseHandler):
    """Handler for audit-related operations."""
    
    async def audit_search(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Search audit logs with various filters."""
        try:
            self.check_auth()
            
            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }
            
            # Build search query
            search_query = {
                "Query": {
                    "limit": args.get("limit", 100),
                    "offset": args.get("offset", 0),
                    "conditions": []
                }
            }
            
            # Add filters
            if args.get("start_datetime"):
                search_query["Query"]["conditions"].append({
                    "column": "datetime",
                    "operator": 5,  # GREATER
                    "values": [args["start_datetime"]]
                })
            
            if args.get("end_datetime"):
                search_query["Query"]["conditions"].append({
                    "column": "datetime",
                    "operator": 6,  # LESS
                    "values": [args["end_datetime"]]
                })
            
            if args.get("operator_name"):
                search_query["Query"]["conditions"].append({
                    "column": "operator_id.name",
                    "operator": 2,  # CONTAINS
                    "values": [args["operator_name"]]
                })
            
            if args.get("target_type"):
                search_query["Query"]["conditions"].append({
                    "column": "target_type",
                    "operator": 0,  # EQUAL
                    "values": [args["target_type"]]
                })
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.post(
                    f"{self.session.config.biostar_url}/api/audit/search",
                    headers=headers,
                    json=search_query
                )
            
            if response.status_code != 200:
                return self.error_response(f"API call failed: {response.status_code} - {response.text}")
            
            data = response.json()
            audit_logs = data.get("AuditCollection", {}).get("rows", [])
            total = data.get("AuditCollection", {}).get("total", 0)
            
            return self.success_response({
                "message": f"Found {len(audit_logs)} audit logs",
                "total": total,
                "count": len(audit_logs),
                "audit_logs": audit_logs
            })
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def audit_search_user(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Search audit logs for specific user operations."""
        try:
            self.check_auth()
            
            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }
            
            user_name = args.get("user_name")
            if not user_name:
                return self.error_response("user_name parameter is required")
            
            # Build search query
            search_query = {
                "Query": {
                    "limit": args.get("limit", 100),
                    "offset": args.get("offset", 0),
                    "conditions": [
                        {
                            "column": "target_id.name",
                            "operator": 2,  # CONTAINS
                            "values": [user_name]
                        }
                    ]
                }
            }
            
            # Add time range if provided
            if args.get("start_datetime"):
                search_query["Query"]["conditions"].append({
                    "column": "datetime",
                    "operator": 5,  # GREATER
                    "values": [args["start_datetime"]]
                })
            
            if args.get("end_datetime"):
                search_query["Query"]["conditions"].append({
                    "column": "datetime",
                    "operator": 6,  # LESS
                    "values": [args["end_datetime"]]
                })
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.post(
                    f"{self.session.config.biostar_url}/api/audit/search",
                    headers=headers,
                    json=search_query
                )
            
            if response.status_code != 200:
                return self.error_response(f"API call failed: {response.status_code} - {response.text}")
            
            data = response.json()
            audit_logs = data.get("AuditCollection", {}).get("rows", [])
            
            return self.success_response({
                "message": f"Found {len(audit_logs)} audit logs for user '{user_name}'",
                "count": len(audit_logs),
                "audit_logs": audit_logs
            })
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def audit_search_operator_level(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Search audit logs by operator access level."""
        try:
            self.check_auth()
            
            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }
            
            operator_level = args.get("operator_level")
            if not operator_level:
                return self.error_response("operator_level parameter is required")
            
            # Build search query
            search_query = {
                "Query": {
                    "limit": args.get("limit", 100),
                    "offset": args.get("offset", 0),
                    "conditions": [
                        {
                            "column": "operator_id.access_level_id.name",
                            "operator": 0,  # EQUAL
                            "values": [operator_level]
                        }
                    ]
                }
            }
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.post(
                    f"{self.session.config.biostar_url}/api/audit/search",
                    headers=headers,
                    json=search_query
                )
            
            if response.status_code != 200:
                return self.error_response(f"API call failed: {response.status_code} - {response.text}")
            
            data = response.json()
            audit_logs = data.get("AuditCollection", {}).get("rows", [])
            
            return self.success_response({
                "message": f"Found {len(audit_logs)} audit logs for operator level '{operator_level}'",
                "count": len(audit_logs),
                "audit_logs": audit_logs
            })
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def audit_search_ip_list(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Search audit logs by IP address."""
        try:
            self.check_auth()
            
            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }
            
            ip_address = args.get("ip_address")
            if not ip_address:
                return self.error_response("ip_address parameter is required")
            
            # Build search query
            search_query = {
                "Query": {
                    "limit": args.get("limit", 100),
                    "offset": args.get("offset", 0),
                    "conditions": [
                        {
                            "column": "ip_address",
                            "operator": 0,  # EQUAL
                            "values": [ip_address]
                        }
                    ]
                }
            }
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.post(
                    f"{self.session.config.biostar_url}/api/audit/search",
                    headers=headers,
                    json=search_query
                )
            
            if response.status_code != 200:
                return self.error_response(f"API call failed: {response.status_code} - {response.text}")
            
            data = response.json()
            audit_logs = data.get("AuditCollection", {}).get("rows", [])
            
            return self.success_response({
                "message": f"Found {len(audit_logs)} audit logs for IP '{ip_address}'",
                "count": len(audit_logs),
                "audit_logs": audit_logs
            })
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def audit_search_target_list(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Search audit logs by target type."""
        try:
            self.check_auth()
            
            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }
            
            target_type = args.get("target_type")
            if not target_type:
                return self.error_response("target_type parameter is required")
            
            # Build search query
            search_query = {
                "Query": {
                    "limit": args.get("limit", 100),
                    "offset": args.get("offset", 0),
                    "conditions": [
                        {
                            "column": "target_type",
                            "operator": 0,  # EQUAL
                            "values": [target_type]
                        }
                    ]
                }
            }
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.post(
                    f"{self.session.config.biostar_url}/api/audit/search",
                    headers=headers,
                    json=search_query
                )
            
            if response.status_code != 200:
                return self.error_response(f"API call failed: {response.status_code} - {response.text}")
            
            data = response.json()
            audit_logs = data.get("AuditCollection", {}).get("rows", [])
            
            return self.success_response({
                "message": f"Found {len(audit_logs)} audit logs for target type '{target_type}'",
                "count": len(audit_logs),
                "audit_logs": audit_logs
            })
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def audit_csv_export(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """
        Export audit logs to CSV via POST /api/audit/export and copy to Windows Downloads.
        - Uses query param: time_offset (minutes)
        - Payload shape:
        {
            "Query": {
            "offset": <int>,
            "conditions": [...],  # e.g. [{"column":"DATE","operator":3,"values":[start,end]}]
            "columns": ["DATE","USRID","PERM","IP","MENU","TARGET","METHOD","CONTENT"],
            "headers": ["Datetime","User","Operator Level","IP","Category","Target","Action","Modification"]
            }
        }
        - After export, reads file from Nginx download dir and copies to user's Downloads.
        """
        try:
            self.check_auth()

            # ----- copy options -----
            copy_to_downloads: bool = bool(args.get("copy_to_downloads", True))
            dest_dir_arg: str = (args.get("dest_dir") or "").strip()
            target_username: str = (args.get("target_username") or "").strip()

            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }

            # ----- columns / headers (force UPPER columns per API spec) -----
            columns = args.get("columns") or ["DATE","USRID","PERM","IP","MENU","TARGET","METHOD","CONTENT"]
            columns = [str(c).upper() for c in columns]

            headers_csv = args.get("headers") or [
                "Datetime","User","Operator Level","IP","Category","Target","Action","Modification"
            ]
            if len(headers_csv) != len(columns):
                return self.error_response("Length of 'headers' must match 'columns'.")

            # ----- conditions -----
            conditions = args.get("conditions") or []
            # convenience: support start_datetime / end_datetime -> build DATE condition
            start_iso = args.get("start_datetime")
            end_iso = args.get("end_datetime")
            if not conditions and (start_iso or end_iso):
                if start_iso and end_iso:
                    conditions = [{"column": "DATE", "operator": 3, "values": [start_iso, end_iso]}]  # BETWEEN
                elif start_iso:
                    conditions = [{"column": "DATE", "operator": 5, "values": [start_iso]}]          # GREATER
                else:
                    conditions = [{"column": "DATE", "operator": 6, "values": [end_iso]}]            # LESS

            offset = int(args.get("offset", 0))
            time_offset = int(args.get("time_offset_minutes", args.get("time_offset", 0)))

            payload = {
                "Query": {
                    "offset": offset,
                    "conditions": conditions,
                    "columns": columns,
                    "headers": headers_csv
                }
            }

            # ----- call /api/audit/export (NOT /api/audit/search) -----
            async with httpx.AsyncClient(verify=False) as client:
                resp = await client.post(
                    f"{self.session.config.biostar_url}/api/audit/export",
                    headers=headers,
                    params={"time_offset": time_offset},
                    json=payload
                )

            if resp.status_code != 200:
                return self.error_response(f"Audit export failed: {resp.status_code} - {resp.text}")

            body = resp.json() or {}
            filename = (body.get("File") or {}).get("uri") or body.get("filename")
            if not filename:
                return self.error_response("Export succeeded but no filename returned", {"response": body})

            # ----- source path in Nginx download dir -----
            download_root = getattr(self.session.config, "download_dir", r"C:\Program Files\BioStar X\nginx\html\download")
            src_path = Path(download_root) / filename

            # Some systems need a short delay until the file appears
            for _ in range(30):
                if src_path.exists():
                    break
                await asyncio.sleep(0.1)

            # ----- copy to Windows Downloads -----
            copy_status = "skipped"
            copied_to = ""
            if copy_to_downloads:
                if platform.system().lower() == "windows":
                    if dest_dir_arg:
                        dest_dir = Path(dest_dir_arg)
                    elif target_username:
                        dest_dir = Path(f"C:\\Users\\{target_username}\\Downloads")
                    else:
                        userprofile = os.environ.get("USERPROFILE") or str(Path.home())
                        dest_dir = Path(userprofile) / "Downloads"

                    try:
                        dest_dir.mkdir(parents=True, exist_ok=True)
                        if not src_path.exists():
                            copy_status = "failed: source not found"
                        else:
                            dest_path = dest_dir / filename
                            shutil.copy2(src_path, dest_path)
                            copied_to = str(dest_path)
                            copy_status = "success"
                    except Exception as ce:
                        copy_status = f"failed: {ce}"
                else:
                    copy_status = "skipped: non-windows"

            return self.success_response({
                "message": "Audit CSV exported successfully",
                "filename": filename,
                "download_url": f"/download/{filename}",
                "source_path": str(src_path),
                "copy": {"enabled": copy_to_downloads, "status": copy_status, "destination": copied_to},
                "export_params": {"time_offset": time_offset, "offset": offset, "columns": columns, "headers": headers_csv, "conditions": conditions}
            })

        except Exception as e:
            return await self.handle_api_error(e)

    def _generate_audit_csv(self, audit_logs: list, columns: list, headers: list) -> str:
        r"""
        Build CSV text from audit logs using logical column tokens.

        Supported column tokens -> log field mapping:
        - "DATE"   -> log["datetime"]
        - "USRID"  -> log["operator_id"]["name"]
        - "PERM"   -> log["operator_id"]["access_level_id"]["name"]
        - "IP"     -> log["ip_address"]
        - "MENU"   -> log["menu"] or log["category"] (fallback empty)
        - "TARGET" -> log["target_id"]["name"]
        - "METHOD" -> log["action"]
        - "CONTENT"-> log["details"] or log["result"]

        If a field is missing, use empty string.
        """
        # header line
        out_lines = [",".join(f'"{h}"' for h in headers)]

        def get_value(token: str, log: Dict[str, Any]) -> str:
            t = (token or "").upper()
            try:
                if t == "DATE":
                    return str(log.get("datetime", ""))
                if t == "USRID":
                    return str((log.get("operator_id") or {}).get("name", ""))
                if t == "PERM":
                    return str(((log.get("operator_id") or {}).get("access_level_id") or {}).get("name", ""))
                if t == "IP":
                    return str(log.get("ip_address", ""))
                if t == "MENU":
                    return str(log.get("menu") or log.get("category") or "")
                if t == "TARGET":
                    return str((log.get("target_id") or {}).get("name", ""))
                if t == "METHOD":
                    return str(log.get("action", ""))
                if t == "CONTENT":
                    return str(log.get("details") or log.get("result") or "")
            except Exception:
                return ""
            return ""

        for log in audit_logs or []:
            row_vals = [get_value(tok, log) for tok in columns]
            # CSV escaping (wrap in quotes, replace inner quotes)
            escaped = ['"' + str(v).replace('"', '""') + '"' for v in row_vals]
            out_lines.append(",".join(escaped))

        return "\n".join(out_lines)
