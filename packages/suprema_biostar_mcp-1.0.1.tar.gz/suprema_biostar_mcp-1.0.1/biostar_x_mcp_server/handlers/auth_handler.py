import logging
from typing import Sequence, Dict, Any
from mcp.types import TextContent
import httpx
from .base_handler import BaseHandler
from ..utils import get_timezone_offset, get_timezone_string

logger = logging.getLogger(__name__)


class AuthHandler(BaseHandler):
    """Handle authentication-related operations."""
    
    async def login(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Login to BioStar 2."""
        try:
            # Get credentials from args or config
            username = args.get("username") or self.session.config.biostar_username
            password = args.get("password") or self.session.config.biostar_password
            
            if not username or not password:
                return self.error_response(
                    "Missing credentials",
                    {"message": "Username and password are required. Set them in .env or provide as arguments."}
                )
            
            # Make direct login API call
            logger.info(f"Attempting to login to BioStar at: {self.session.config.biostar_url}")
            
            # Create client with SSL settings
            transport = None
            if not self.session.config.verify_ssl:
                import ssl
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
                transport = httpx.AsyncHTTPTransport(verify=ssl_context)
            
            api_base = self.session.config.biostar_url
            # api_base = "https://127.0.0.1:443"
            async with httpx.AsyncClient(
                transport=transport,
                verify=False,
                follow_redirects=True
            ) as client:
                logger.info(f"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx Login with: {username} and {password} xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
                response = await client.post(
                    f"{api_base}/api/login",
                    json={
                        "User": {
                            "login_id": username,
                            "password": password
                        }
                    },
                    headers={
                        "Content-Type": "application/json"
                    },
                    timeout=self.session.config.api_timeout
                )
                
                if response.status_code != 200:
                    return self.error_response(
                        f"Login failed: {response.status_code}",
                        {"response": response.text}
                    )
                
                # Extract session ID and user info
                session_id = response.headers.get("bs-session-id")
                data = response.json()
                user_info = data.get("User", {})
                
                # Store session info
                self.session.session_id = session_id
                self.session.user_id = user_info.get("user_id")
                
                # Update the session client to be authenticated
                if not self.session.client:
                    await self.session.connect()
                if session_id:
                    self.session.client.headers["bs-session-id"] = session_id
                
                logger.info(f"Successfully logged in as user {self.session.user_id}")
                
                return self.success_response({
                    "user_id": user_info.get("user_id"),
                    "name": user_info.get("name"),
                    "email": user_info.get("email"),
                    "session_id": session_id,
                    "message": "Successfully logged in to BioStar 2"
                })
            
        except httpx.ConnectTimeout as e:
            return self.error_response(
                "Connection timeout",
                {
                    "message": f"Failed to connect to BioStar server at {self.session.config.biostar_url}",
                    "timeout": f"{self.session.config.api_timeout} seconds",
                    "suggestions": [
                        "1. Check if the BioStar server URL is correct in your .env file",
                        "2. Ensure the server is running and accessible",
                        "3. Check network connectivity to the server",
                        "4. Try increasing API_TIMEOUT in .env file",
                        "5. If using HTTPS with self-signed certificate, set VERIFY_SSL=false"
                    ]
                }
            )
        except httpx.ConnectError as e:
            return self.error_response(
                "Connection error", 
                {
                    "message": f"Cannot connect to {self.session.config.biostar_url}",
                    "error": str(e),
                    "verify_ssl": self.session.config.verify_ssl
                }
            )
        except Exception as e:
            return await self.handle_api_error(e)
            
    async def logout(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Logout from BioStar 2."""
        try:
            if not self.session.is_authenticated():
                return self.error_response("Not authenticated")
            
            # Make logout API call
            async with httpx.AsyncClient(verify=self.session.config.verify_ssl) as client:
                response = await client.post(
                    f"{self.session.config.biostar_url}/api/logout",
                    headers={"bs-session-id": self.session.session_id},
                    timeout=self.session.config.api_timeout
                )
            
            # Clear session info regardless of response
            self.session.session_id = None
            self.session.user_id = None
            if self.session.client:
                self.session.client.headers.pop("bs-session-id", None)
            
            return self.success_response({
                "message": "Successfully logged out from BioStar 2"
            })
            
        except Exception as e:
            return await self.handle_api_error(e)
            
    async def get_session_info(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Get current session information."""
        try:
            self.check_auth()
            
            headers = {"bs-session-id": self.get_session_id()}
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.get(
                    f"{self.session.config.biostar_url}/api/session",
                    headers=headers
                )
            
            if response.status_code == 200:
                self.session.session_id = None
                return self.success_response({
                    "message": "Session information retrieved successfully",
                    "session_data": response.json()
                })
            else:
                return self.error_response(f"Failed to get session info: {response.status_code}")
                
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def get_server_preferences(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Get BioStar server preferences including timezone."""
        try:
            self.check_auth()
            
            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.get(
                    f"{self.session.config.biostar_url}/api/preferences/1",
                    headers=headers
                )
            
            if response.status_code != 200:
                return self.error_response(f"Failed to get server preferences: {response.status_code} - {response.text}")
            
            data = response.json()
            preference = data.get("Preference", {})
            
            # Get timezone info
            timezone_id = preference.get("time_zone", "26")  # Default to UTC+9 (Seoul)
            timezone_offset_minutes = get_timezone_offset(timezone_id, default=540)  # Default to +540 minutes (UTC+9)
            timezone_offset_hours = timezone_offset_minutes / 60
            tz_str = get_timezone_string(timezone_id, default=540)
            
            return self.success_response({
                "message": "Server preferences retrieved successfully",
                "language": preference.get("language", "en"),
                "timezone_id": timezone_id,
                "timezone_offset_minutes": timezone_offset_minutes,
                "timezone_offset_hours": timezone_offset_hours,
                "timezone_string": tz_str,
                "date_format": preference.get("date_format", "yyyy/MM/dd"),
                "time_format": preference.get("time_format", "HH:mm"),
                "user": {
                    "user_id": preference.get("user_id", {}).get("user_id"),
                    "name": preference.get("user_id", {}).get("name")
                }
            })
                
        except Exception as e:
            logger.exception("get_server_preferences failed")
            return await self.handle_api_error(e)