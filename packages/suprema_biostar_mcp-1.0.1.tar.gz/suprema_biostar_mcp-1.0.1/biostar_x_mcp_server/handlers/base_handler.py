"""
Base Handler for BioStar X MCP Server
Provides common functionality for all API handlers
"""
import logging
import json
from typing import Sequence, Dict, Any, Optional
from mcp.types import TextContent
from pydantic import ValidationError
import httpx
from ..session import BioStarSession

logger = logging.getLogger(__name__)


class BaseHandler:
    """Base handler class with common functionality for all handlers."""

    def __init__(self, session: BioStarSession):
        self.session = session
        self.client_session_id = None

    def get_session_id(self) -> str:
        """Get the session ID to use for API calls."""
        if self.client_session_id:
            logger.info(f"Using client session ID: {self.client_session_id}")
            return self.client_session_id
        elif self.session.session_id:
            logger.info(f"Using internal session ID: {self.session.session_id}")
            return self.session.session_id
        else:
            raise RuntimeError("No session ID available")

    def check_auth(self) -> None:
        """Ensure session is authenticated."""
        if self.client_session_id:
            logger.info("Using client session ID, skipping internal auth check")
            return

        if not self.session.is_authenticated():
            raise RuntimeError("Not authenticated. Please login first.")

    @property
    def api_headers(self) -> Dict[str, str]:
        """Get standard API headers with session ID."""
        return {
            "bs-session-id": self.get_session_id(),
            "Content-Type": "application/json"
        }

    async def api_get(self, endpoint: str, params: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """Make GET request to BioStar API."""
        async with httpx.AsyncClient(verify=False) as client:
            response = await client.get(
                f"{self.session.config.biostar_url}{endpoint}",
                headers=self.api_headers,
                params=params,
                **kwargs
            )
            return response

    async def api_post(self, endpoint: str, json: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """Make POST request to BioStar API."""
        async with httpx.AsyncClient(verify=False) as client:
            response = await client.post(
                f"{self.session.config.biostar_url}{endpoint}",
                headers=self.api_headers,
                json=json,
                **kwargs
            )
            return response

    async def api_put(self, endpoint: str, json: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """Make PUT request to BioStar API."""
        async with httpx.AsyncClient(verify=False) as client:
            response = await client.put(
                f"{self.session.config.biostar_url}{endpoint}",
                headers=self.api_headers,
                json=json,
                **kwargs
            )
            return response

    async def api_delete(self, endpoint: str, **kwargs) -> httpx.Response:
        """Make DELETE request to BioStar API."""
        async with httpx.AsyncClient(verify=False) as client:
            response = await client.delete(
                f"{self.session.config.biostar_url}{endpoint}",
                headers=self.api_headers,
                **kwargs
            )
            return response

    def success_response(self, data: Any, message: Optional[str] = None) -> list[TextContent]:
        """Create a success response."""
        content = {
            "status": "success",
            "data": data
        }
        if message:
            content["message"] = message

        return [TextContent(
            type="text",
            text=json.dumps(content, ensure_ascii=False, indent=2)
        )]

    def error_response(self, error: str, details: Optional[Dict[str, Any]] = None) -> list[TextContent]:
        """Create an error response."""
        content = {
            "status": "error",
            "error": error
        }
        if details:
            content["details"] = details

        return [TextContent(
            type="text",
            text=json.dumps(content, ensure_ascii=False, indent=2)
        )]

    async def handle_api_error(self, error: Exception) -> list[TextContent]:
        """Handle API errors consistently."""
        logger.error(f"API error: {error}", exc_info=True)

        error_type = type(error).__name__

        if hasattr(error, 'response'):
            return self.error_response(
                f"API error: {error.response.status_code}",
                {"message": str(error), "response": error.response.text}
            )
        elif "TimeoutError" in str(error) or "ConnectTimeout" in str(error):
            return self.error_response(
                "Connection timeout",
                {
                    "message": "Failed to connect to BioStar server. Please check:",
                    "suggestions": [
                        "1. BioStar server URL in .env file (BIOSTAR_URL)",
                        "2. Server is running and accessible",
                        "3. Network connectivity",
                        "4. Firewall settings"
                    ],
                    "error_type": error_type,
                    "details": str(error)
                }
            )
        elif "ConnectionRefused" in str(error):
            return self.error_response(
                "Connection refused",
                {
                    "message": "BioStar server refused the connection",
                    "suggestions": [
                        "1. Check if BioStar server is running",
                        "2. Verify the server URL and port",
                        "3. Check server logs"
                    ],
                    "error_type": error_type,
                    "details": str(error)
                }
            )
        else:
            return self.error_response(
                f"Error: {error_type}",
                {"message": str(error), "type": error_type}
            )

    def handle_validation_error(self, error: ValidationError) -> list[TextContent]:
        """Handle Pydantic validation errors consistently."""
        errors = []
        for err in error.errors():
            field = ".".join(str(loc) for loc in err["loc"])
            errors.append({
                "field": field,
                "message": err["msg"],
                "type": err["type"]
            })

        return self.error_response(
            "Validation error",
            {"errors": errors}
        )

    def validate_required_params(self, params: Dict[str, Any], required: list[str]) -> Optional[list[TextContent]]:
        """Validate required parameters are present."""
        missing = [param for param in required if param not in params]
        if missing:
            return self.error_response(
                "Missing required parameters",
                {"missing": missing}
            )
        return None

    def format_user_info(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Format user information for display."""
        return {
            "user_id": user_data.get("user_id"),
            "name": user_data.get("name"),
            "email": user_data.get("email"),
            "phone_number": user_data.get("phone_number"),
            "user_group_id": user_data.get("user_group_id", {}).get("id"),
            "disabled": user_data.get("disabled", False),
            "start_datetime": user_data.get("start_datetime"),
            "expiry_datetime": user_data.get("expiry_datetime")
        }

    def format_door_info(self, door_data: Dict[str, Any]) -> Dict[str, Any]:
        """Format door information for display."""
        return {
            "id": door_data.get("id"),
            "name": door_data.get("name"),
            "description": door_data.get("description"),
            "open_duration": door_data.get("open_duration"),
            "open_status": door_data.get("open_status"),
            "lock_status": door_data.get("lock_status"),
            "unlocked": door_data.get("unlocked")
        }

    def format_device_info(self, device_data: Dict[str, Any]) -> Dict[str, Any]:
        """Format device information for display."""
        return {
            "id": device_data.get("id"),
            "name": device_data.get("name"),
            "device_type": device_data.get("device_type", {}).get("name"),
            "ip": device_data.get("ip"),
            "status": device_data.get("status", {}).get("online"),
            "enabled": device_data.get("enabled")
        }
