import logging
import json
import csv
import io
import asyncio
import platform
from datetime import datetime, timedelta
from typing import Sequence, Dict, Any, Optional, List
from mcp.types import TextContent
import httpx
from pydantic import ValidationError
from pathlib import Path
import os
import shutil

from .base_handler import BaseHandler
from ..utils import get_timezone_offset, convert_utc_to_local

logger = logging.getLogger(__name__)

# Alias for backward compatibility
convert_utc_to_server_time = convert_utc_to_local

# BioStar X Event Type Mapping - 이벤트 ID를 이벤트 이름으로 매핑
EVENT_TYPE_NAMES = {
    "3100": "Video recording space shortage",
    "3110": "Video recording space shortage",
    "3111": "Add NVR successful",
    "3113": "Add NVR",
    "3131": "NVR update successful",
    "3132": "NVR update failed",
    "3133": "Update NVR",
    "3141": "Remove NVR successful",
    "3142": "Remove NVR failed",
    "3143": "Remove NVR",
    "3211": "Add camera successful",
    "3212": "Add camera failed",
    "3213": "Add camera",
    "3231": "Update camera successful",
    "3232": "Update camera failed",
    "3233": "Update camera",
    "3241": "Remove camera successful",
    "3242": "Remove camera failed",
    "3243": "Remove camera",
    "3351": "Recording completed",
    "3352": "Recording failed",
    "3353": "Start recording",
    "3354": "Recording failed - End of Retry",
    "3355": "Recording - NVR connect failed",
    "3356": "Recording - NVR Busy",
    "3357": "Recording - No Data in NVR",
    "3461": "Snapshot completed",
    "3462": "Snapshot failed",
    "3463": "Start snapshot",
    "3464": "Snapshot failed - End of Retry",
    "3465": "Snapshot - NVR connect failed",
    "3466": "Snapshot - NVR Busy",
    "3467": "Snapshot - No Data in NVR",
    "4001": "Exceeded maximum login attempts",
    "4002": "BioStar X Core Service Abnormal Status",
    "4003": "BioStar X Core Service Normal Status Recovered",
    "4004": "BioStar X Device Service Abnormal Status",
    "4005": "BioStar X Device Service Normal Status Recovered",
    "4016": "VMS connected",
    "4017": "VMS disconnected",
    "4018": "Tailgating Detected (AI)",
    "4019": "Loitering Detected (AI)",
    "4020": "Intrusion Detected (AI)",
    "4021": "Fall Detected (AI)",
    "4022": "Tailgating Alarm Cleared (AI)",
    "4023": "Loitering Alarm Cleared (AI)",
    "4024": "Intrusion Alarm Cleared (AI)",
    "4025": "Fall Alarm Cleared (AI)",
    "4026": "Abandon Detected (AI)",
    "4027": "Abandon Alarm Cleared (AI)",
    "4088": "Access granted",
    "4089": "Roll Call Started",
    "4090": "Roll Call Ended",
    "4091": "User Sync Failed (No Compatible Face Template)",
    "4094": "Firmware Upgrade Required (Log Upload Failed Due to Device Database Corruption)",
    "4095": "Device Disconnection Detected",
    "4096": "1:1 authentication succeeded",
    "4097": "1:1 authentication succeeded (ID + PIN)",
    "4098": "1:1 authentication succeeded (ID + Fingerprint)",
    "4099": "1:1 authentication succeeded (ID + Fingerprint + PIN)",
    "4100": "1:1 authentication succeeded (ID + Face)",
    "4101": "1:1 authentication succeeded (ID + Face + PIN)",
    "4102": "1:1 authentication succeeded (Card)",
    "4103": "1:1 authentication succeeded (Card + PIN)",
    "4104": "1:1 authentication succeeded (Card + Fingerprint)",
    "4105": "1:1 authentication succeeded (Card + Fingerprint + PIN)",
    "4106": "1:1 authentication succeeded (Card + Face)",
    "4107": "1:1 authentication succeeded (Card + Face + PIN)",
    "4108": "1:1 authentication succeeded (Access-on-card)",
    "4109": "1:1 authentication succeeded (Access-on-card + PIN)",
    "4110": "1:1 authentication succeeded (Access-on-card + Fingerprint)",
    "4111": "1:1 authentication succeeded (Access-on-card + Fingerprint + PIN)",
    "4112": "1:1 authentication succeeded (Card + Face + Fingerprint)",
    "4113": "1:1 authentication succeeded (Card + Fingerprint + Face)",
    "4114": "1:1 authentication succeeded (ID + Face + Fingerprint)",
    "4115": "1:1 authentication succeeded (ID + Fingerprint + Face)",
    "4118": "1:1 authentication succeeded (Mobile Card)",
    "4119": "1:1 authentication succeeded (Mobile Card + PIN)",
    "4120": "1:1 authentication succeeded (Mobile Card + Fingerprint)",
    "4121": "1:1 authentication succeeded (Mobile Card + Fingerprint + PIN)",
    "4122": "1:1 authentication succeeded (Mobile Card + Face)",
    "4123": "1:1 authentication succeeded (Mobile Card + Face + PIN)",
    "4128": "1:1 authentication succeeded (Mobile Card + Face + Fingerprint)",
    "4129": "1:1 authentication succeeded (Mobile Card + Fingerprint  + Face)",
    "4133": "1:1 authentication succeeded (QR/Barcode)",
    "4134": "1:1 authentication succeeded (QR/Barcode + PIN)",
    "4135": "1:1 authentication succeeded (QR/Barcode + Fingerprint)",
    "4136": "1:1 authentication succeeded (QR/Barcode + Fingerprint + PIN)",
    "4137": "1:1 authentication succeeded (QR/Barcode + Face)",
    "4138": "1:1 authentication succeeded (QR/Barcode + Face + PIN)",
    "4139": "1:1 authentication succeeded (QR/Barcode + Face + Fingerprint)",
    "4140": "1:1 authentication succeeded (QR/Barcode + Fingerprint + Face)",
    "4145": "1:1 authentication succeeded (Lock Override)",
    "4352": "1:1 authentication failed",
    "4353": "1:1 authentication failed (ID)",
    "4354": "1:1 authentication failed (Card)",
    "4355": "1:1 authentication failed (PIN)",
    "4356": "1:1 authentication failed (Fingerprint)",
    "4357": "1:1 authentication failed (Face)",
    "4358": "1:1 authentication failed (Access-on-card + PIN)",
    "4359": "1:1 authentication failed (Access-on-card + Fingerprint)",
    "4360": "1:1 authentication failed (Mobile Card)",
    "4361": "1:1 authentication failed (Non-numeric Data)",
    "4362": "1:1 authentication failed (Unsupported character)",
    "4363": "1:1 authentication failed (Exceeded QR max size)",
    "4364": "1:1 authentication failed (QR/Barcode)",
    "4608": "1:1 duress authentication succeeded",
    "4609": "1:1 duress authentication succeeded (ID + PIN)",
    "4610": "1:1 duress authentication succeeded (ID + Fingerprint)",
    "4611": "1:1 duress authentication succeeded (ID + Fingerprint + PIN)",
    "4612": "1:1 duress authentication succeeded (ID + Face)",
    "4613": "1:1 duress authentication succeeded (ID + Face + PIN)",
    "4614": "1:1 duress authentication succeeded (Card)",
    "4615": "1:1 duress authentication succeeded (Card + PIN)",
    "4616": "1:1 duress authentication succeeded (Card + Fingerprint)",
    "4617": "1:1 duress authentication succeeded (Card + Fingerprint + PIN)",
    "4618": "1:1 duress authentication succeeded (Card + Face)",
    "4619": "1:1 duress authentication succeeded (Card + Face + PIN)",
    "4620": "1:1 duress authentication succeeded (Access-on-card)",
    "4621": "1:1 duress authentication succeeded (Access-on-card + PIN)",
    "4622": "1:1 duress authentication succeeded (Access-on-card + Fingerprint)",
    "4623": "1:1 duress authentication succeeded (Access-on-card + Fingerprint + PIN)",
    "4624": "1:1 duress authentication succeeded (Card + Face + Fingerprint)",
    "4625": "1:1 duress authentication succeeded (Card + Fingerprint + Face)",
    "4626": "1:1 duress authentication succeeded (ID + Face + Fingerprint)",
    "4627": "1:1 duress authentication succeeded (ID + Fingerprint + Face)",
    "4632": "1:1 duress authentication succeeded (Mobile Card + Fingerprint)",
    "4633": "1:1 duress authentication succeeded (Mobile Card + Fingerprint + PIN)",
    "4640": "1:1 duress authentication succeeded (Mobile Card + Face + Fingerprint)",
    "4641": "1:1 duress authentication succeeded (Mobile Card + Fingerprint + Face)",
    "4647": "1:1 duress authentication succeeded (QR/Barcode + Fingerprint)",
    "4648": "1:1 duress authentication succeeded (QR/Barcode + Fingerprint + PIN)",
    "4651": "1:1 duress authentication succeeded (QR/Barcode + Face + Fingerprint)",
    "4652": "1:1 duress authentication succeeded (QR/Barcode + Fingerprint + Face)",
    "4864": "1:N authentication succeeded",
    "4865": "1:N authentication succeeded (Fingerprint)",
    "4866": "1:N authentication succeeded (Fingerprint + PIN)",
    "4867": "1:N authentication succeeded (Face)",
    "4868": "1:N authentication succeeded (Face + PIN)",
    "4869": "1:N authentication succeeded (Face + Fingerprint)",
    "4870": "1:N authentication succeeded (Face + Fingerprint + PIN)",
    "4871": "1:N authentication succeeded (Fingerprint + Face)",
    "4872": "1:N authentication succeeded (Fingerprint + Face + PIN)",
    "5120": "1:N authentication failed",
    "5123": "1:N authentication failed (PIN)",
    "5124": "1:N authentication failed (Fingerprint)",
    "5125": "1:N authentication failed (Face)",
    "5126": "1:N authentication failed (Access-on-card + PIN)",
    "5127": "1:N authentication failed (Access-on-card + Fingerprint)",
    "5376": "1:N duress authentication succeeded",
    "5377": "1:N duress authentication succeeded (Fingerprint)",
    "5378": "1:N duress authentication succeeded (Fingerprint + PIN)",
    "5379": "1:N duress authentication succeeded (Face)",
    "5380": "1:N duress authentication succeeded (Face + PIN)",
    "5381": "1:N duress authentication succeeded (Face + Fingerprint)",
    "5382": "1:N duress authentication succeeded (Face + Fingerprint + PIN)",
    "5383": "1:N duress authentication succeeded (Fingerprint + Face)",
    "5384": "1:N duress authentication succeeded (Fingerprint + Face + PIN)",
    "5632": "Dual authentication succeeded",
    "5888": "Dual authentication failed",
    "5889": "Dual authentication failed (Timeout)",
    "5890": "Dual authentication failed (Invalid access group)",
    "6144": "Authentication failed",
    "6145": "Authentication failed (Invalid authentication mode)",
    "6146": "Authentication failed (Invalid credential)",
    "6147": "Authentication failed (Timeout)",
    "6148": "Authentication failed. (Server matching is off)",
    "6149": "3 consecutive authentication failed",
    "6400": "Access denied",
    "6401": "Access denied (Invalid access group)",
    "6402": "Access denied (Disabled user)",
    "6403": "Access denied(Invalid period)",
    "6404": "Access denied (Blacklist)",
    "6405": "Access denied (Hard Anti-passback)",
    "6406": "Access denied (Timed anti-passback)",
    "6407": "Access denied (Forced lock schedule)",
    "6408": "Access denied (Soft anti-passback)",
    "6409": "Access denied (Soft timed anti-passback)",
    "6410": "Access denied (Face detection failure)",
    "6411": "Access denied (Capture failure)",
    "6412": "Fake Fingerprint Detected",
    "6414": "Intrusion alarm access denied",
    "6415": "Access denied (Interlock)",
    "6418": "Access Denied (Anti-tailgating)",
    "6419": "Access denied (Exceeded threshold temp.)",
    "6420": "Access denied (Temp. not measured correctly)",
    "6421": "Access denied (Mask not detected)",
    "6422": "Access Denied (Occupancy Limit Violation)",
    "6423": "Access denied (Locked)",
    "6656": "Authentication failed (Bad fingerprint placement)",
    "6912": "Access granted (Check only)",
    "6913": "Access granted (Soft temp. violation on check only)",
    "6914": "Access granted (Soft mask violation on check only)",
    "6915": "Access granted (Soft temp. and mask violation on check only)",
    "7168": "Access denied (Exceeded threshold temp. on check only)",
    "7169": "Access denied (Temp. not measured correctly on check only)",
    "7170": "Access denied (Mask not detected on check only)",
    "7188": "Access denied (Temperature not measured properly)",
    "7424": "Abnormal temp. detected (Exceeded Threshold temp.)",
    "7425": "Abnormal temp. detected (Temp. not measured correctly)",
    "7680": "Mask not detected",
    "8192": "User enrollment succeeded",
    "8448": "User enrollment failed",
    "8449": "User enrollment failed (Face extraction failed)",
    "8450": "User enrollment failed (Different fingerprint template format)",
    "8451": "User enrollment failed (Exceeded max credential count)",
    "8457": "User enrollment failed (User data error)",
    "8704": "User update succeeded",
    "8960": "User update failed",
    "8961": "User update failed (Face extraction failed)",
    "8962": "User update failed (Different fingerprint template format)",
    "8969": "User update failed (User data error)",
    "9216": "User deletion succeeded",
    "9472": "User deletion failed",
    "9728": "All user deletion succeeded",
    "9984": "Access-on-card issue succeeded",
    "10240": "Duplicate Credential",
    "10242": "Duplicate Card",
    "10244": "Duplicate Fingerprint",
    "10245": "Duplicate Face",
    "10496": "User partial update succeeded",
    "10752": "User partial update failed",
    "10753": "User partial update failed (Face extraction failed)",
    "10754": "User partial update failed (Different fingerprint template format)",
    "10755": "User partial update failed (Exceeded max credential count)",
    "10756": "User partial update failed (User does not exist)",
    "10761": "User partial update failed (User data error)",
    "12288": "Device restarted",
    "12368": "Device restarted (System Reboot)",
    "12544": "Device started",
    "12800": "Device time changed",
    "12801": "Time-zone changed",
    "12802": "DST applied",
    "13056": "Network connected",
    "13312": "Network disconnected",
    "13568": "DHCP connected",
    "13824": "Administrator menu entered",
    "13825": "Administrator authentication failed",
    "13826": "Administrator authentication failed (Invalid credential)",
    "14080": "Device locked",
    "14336": "Device unlocked",
    "14592": "BioStar X communication locked",
    "14848": "BioStar X communication unlocked",
    "15104": "BioStar X connected",
    "15120": "RTSP connected",
    "15360": "BioStar X disconnected",
    "15376": "RTSP disconnected",
    "15616": "RS-485 connected",
    "15872": "RS-485 disconnected",
    "16128": "Input detected on",
    "16129": "Input detected off",
    "16384": "Tamper on",
    "16640": "Tamper off",
    "16896": "Event log cleared",
    "17152": "Firmware upgrade succeeded",
    "17408": "Resource upgrade succeeded",
    "17664": "Device reset",
    "17665": "Database Reset",
    "17666": "Factory Reset",
    "17667": "Restored to default without network settings",
    "17680": "License Activation Succeeded",
    "17681": "License Activation Failed",
    "17682": "License Deactivation Succeeded",
    "17683": "License Deactivation Failed",
    "17684": "License Expired",
    "17920": "Supervised Input (Short)",
    "18176": "Supervised Input (Open)",
    "18432": "AC Power Failure",
    "18688": "AC Power Success",
    "18944": "Door open request by exit button",
    "18945": "Door open request by exit button (Relay does not activate)",
    "19200": "Door open request by operator",
    "19456": "Door open request by Intercom door open button",
    "19712": "License Activation Succeeded",
    "19713": "License Activation Failed",
    "19714": "License Deactivation Succeeded",
    "19715": "License Deactivation Failed",
    "19716": "License Expired",
    "19969": "Low battery level",
    "19970": "Critical battery level",
    "19971": "Empty battery",
    "20480": "Door unlocked",
    "20736": "Door locked",
    "20992": "Door opened",
    "21248": "Door closed",
    "21504": "Forced door opened",
    "21760": "Held door opened",
    "22016": "Forced door open alarmed",
    "22017": "Lock Override Alarm Activated",
    "22272": "Forced door open cleared",
    "22274": "Lock Override Alarm Cleared",
    "22528": "Held door open alarmed",
    "22784": "Held door open cleared",
    "23040": "Anti-passback alarmed",
    "23296": "Anti-passback cleared",
    "23553": "Door release request by schedule",
    "23554": "Door release request by emergency",
    "23556": "Door release request by operator",
    "23809": "Door lock request by schedule",
    "23810": "Door lock request by emergency",
    "23812": "Door lock request by operator",
    "24065": "Door unlock request by schedule",
    "24066": "Door unlock request by emergency",
    "24068": "Door unlock request by operator",
    "24320": "Door open request sent",
    "24321": "Door unlock request sent",
    "24322": "Door lock request sent",
    "24323": "Door release request sent",
    "24324": "Aux input detected (Fire)",
    "24325": "Fire alarm detected",
    "24326": "Fire alarm cleared",
    "24327": "Door normalized",
    "24576": "Anti-passback violation detected",
    "24577": "Hard anti-passback violation detected",
    "24578": "Soft anti-passback violation detected",
    "24832": "Anti-passback zone alarm detected",
    "24833": "Occupancy Limit Zone Availability Recovered",
    "24834": "Access Denied (Occupancy Count Full)",
    "24835": "Exit Occurred While Count Zero",
    "24836": "Occupancy Limit zone Almost Full 1st Level Detected",
    "24837": "Occupancy Limit zone Almost Full 2nd Level Detected",
    "24838": "Occupancy Limit Zone Full Detected",
    "25088": "Anti-passback zone alarm cleared",
    "25344": "Timed anti-passback violation detected",
    "25345": "Timed anti-passback violation detected",
    "25346": "Soft Timed anti-passback violation detected",
    "25600": "Timed anti-passback alarm detected",
    "25856": "Timed anti-passback alarm cleared",
    "26112": "Fire alarm input detected.",
    "26368": "Fire alarm zone alarm detected",
    "26624": "Fire alarm zone alarm cleared",
    "26880": "Scheduled lock violation detected",
    "27094": "Scheduled unlock zone ended (Door)",
    "27136": "Scheduled lock zone started",
    "27392": "Scheduled lock zone ended",
    "27648": "Scheduled unlock zone started (Door)",
    "27904": "Scheduled unlock zone ended (Door)",
    "28160": "Scheduled lock zone alarm detected",
    "28416": "Scheduled lock zone alarm cleared",
    "28417": "Occupancy Full Detected",
    "28418": "Occupancy Availability Recovered",
    "28419": "Exit Occurred While Occupancy Count Zero",
    "28420": "Occupancy Count Alert 1 Detected",
    "28421": "Occupancy Count Alert 2 Detected",
    "28422": "Occupancy Limit Violation",
    "28423": "Occupancy Limit Violation (Network Failure)",
    "28672": "Floor Activated",
    "28928": "Floor Released",
    "29185": "Elevator release request by schedule",
    "29186": "Release by emergency",
    "29188": "Release by operator",
    "29192": "Release floor by alarm",
    "29441": "Elevator unlock request by schedule",
    "29442": "Unlock by emergency",
    "29444": "Unlock by operator",
    "29448": "Activate floor by alarm",
    "29697": "Lock by schedule",
    "29698": "Lock by emergency",
    "29700": "Lock by operator",
    "29952": "Elevator alarm input detected",
    "30208": "Elevator alarm",
    "30464": "Elevator alarm cleared",
    "30720": "Enable all floor relays",
    "30976": "Disable all floor relays",
    "32768": "BioStar X Event",
    "36864": "Access denied (Armed status)",
    "37120": "Arming auth success",
    "37376": "Armed",
    "37632": "Arming failed",
    "37888": "Disarming auth success",
    "38144": "Disarmed",
    "38656": "Intrusion alarm input",
    "38912": "Intrusion alarm detected",
    "39168": "Intrusion alarm cleared",
    "39424": "Arming auth failed",
    "39680": "Disarming auth failed",
    "40960": "Interlock fail",
    "40961": "Interlock door open denied",
    "40962": "Interlock door open denied (Occupied)",
    "41216": "Interlock zone alarm",
    "41472": "Interlock door open denied alarm",
    "41728": "Interlock door open denied alarm (Occupied)",
    "41984": "Interlock zone Alarm Clear",
    "42753": "Occupancy Limit Violation (Count Full)",
    "42754": "Occupancy Limit Violation (Network Failure)",
    "45056": "Muster zone time limit violation",
    "45312": "Muster zone alarm detected",
    "45568": "Muster zone alarm cleared",
    "47104": "Scheduled unlock zone started (Elevator)",
    "47360": "Scheduled unlock zone ended (Elevator)",
    "49152": "Fail to save to the server DB",
    "49920": "Relay Activated",
    "49921": "Relay Activated (Supervised Input Fault Short)",
    "49922": "Relay Activated (Supervised Input Fault Open)",
    "49923": "Relay Activated (Input Activated)",
    "49925": "Relay Activated (Tamper Activated)",
    "49928": "Relay Activated (RS-485 Disconnected)",
    "50176": "Relay Deactivated",
    "50177": "System Backup Started",
    "50178": "Relay Deactivated (Supervised Input Fault Open)",
    "50179": "System Backup Complete",
    "50180": "Relay Deactivated (Input Deactivated)",
    "50181": "System Backup Failed",
    "50182": "Relay Deactivated (Tamper Deactivated)",
    "50183": "Relay Deactivated (RS-485 Connected)",
    "50433": "Relay Retained (Supervised Input Short)",
    "50434": "Relay Retained (Supervised Input Fault Open)",
    "50435": "Relay Retained (Input Activated)",
    "50436": "Relay Retained (Input Deactivated)",
    "50437": "Relay Retained (Tamper Activated)",
    "50438": "Relay Retained (Tamper Deactivated)",
    "50439": "Relay Retained (RS-485 Connected)",
    "50440": "Relay Retained (RS-485 Disconnected)",
    "51001": "Active Directory User Sync Started",
    "51002": "Active Directory User Sync Complete",
    "51003": "Active Directory User Sync Failed",
    "51004": "Entra ID User Sync Started",
    "51005": "Entra ID User Sync Complete",
    "51006": "Entra ID User Sync Failed",
    "51007": "User Sync Failed (User Group Sync Error)",
    "53248": "ToM Face Enrollment Succeeded",
    "53504": "ToM Face Enrollment Failed",
    "53505": "ToM Face Enrollment Failed (Scan Canceled)",
    "53506": "ToM Face Enrollment Failed (Scan Timeout)",
    "53507": "ToM Face Enrollment Failed (Template Extraction Failed)",
    "53508": "ToM Face Enrollment Failed (Communication Failed)",
    "53513": "ToM Face Enrollment Failed (Unspecified Error)",
    "53760": "ToM Fingerprint Enrollment Succeeded",
    "54016": "ToM Fingerprint Enrollment Failed",
    "54017": "ToM Fingerprint Enrollment Failed (Scan Canceled)",
    "54018": "ToM Fingerprint Enrollment Failed (Scan Timeout)",
    "54019": "ToM Fingerprint Enrollment Failed (Template Extraction Failed)",
    "54020": "ToM Fingerprint Enrollment Failed (Communication Failed)",
    "54025": "ToM Fingerprint Enrollment Failed (Unspecified Error)",
    "54500": "Quick Action Activated",
    "54501": "Quick action",
    "etc": "etc",
}


def validate_datetime(date_string: str) -> bool:
    """Validate datetime format is ISO 8601 with timezone."""
    try:
        # Check if it matches the expected format
        if not date_string.endswith('Z') and not ('+' in date_string or date_string.count('-') > 2):
            return False
        # Try to parse it
        if date_string.endswith('Z'):
            datetime.fromisoformat(date_string.replace('Z', '+00:00'))
        else:
            datetime.fromisoformat(date_string)
        return True
    except ValueError:
        return False


class EventHandler(BaseHandler):
    """Handle event and log related operations."""
    
    async def _get_server_timezone_offset(self) -> int:
        """
        Get server timezone offset in minutes from preferences.
        Uses cached value if available, only fetches once per session.
        Returns 540 (UTC+9) as default if API call fails.
        """
        # 캐시된 값이 있으면 바로 반환
        if self.session.timezone_offset_minutes is not None:
            return self.session.timezone_offset_minutes
        
        try:
            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient(verify=False) as client:
                response = await client.get(
                    f"{self.session.config.biostar_url}/api/preferences/1",
                    headers=headers,
                    timeout=10
                )
            
            if response.status_code == 200:
                data = response.json()
                preference = data.get("Preference", {})
                timezone_id = preference.get("time_zone", "26")
                offset = get_timezone_offset(timezone_id, default=540)
                
                # Cache in session
                self.session.timezone_offset_minutes = offset
                logger.info(f"Server timezone cached: UTC{'+' if offset >= 0 else ''}{offset/60:.1f} (offset: {offset} minutes)")
                return offset
        except Exception as e:
            logger.warning(f"Failed to get server timezone, using default UTC+9: {e}")
        
        # Cache default value
        self.session.timezone_offset_minutes = 540
        return 540  # Default to UTC+9 (Seoul/Tokyo)
    
    def _convert_event_times(self, events: List[Dict[str, Any]], timezone_offset_minutes: int) -> List[Dict[str, Any]]:
        """
        Convert event times from UTC to server local time.
        Adds both original UTC time and converted local time.
        """
        converted_events = []
        for event in events:
            event_copy = event.copy()
            
            # Convert datetime field
            if "datetime" in event_copy and event_copy["datetime"]:
                utc_time = event_copy["datetime"]
                local_time = convert_utc_to_server_time(utc_time, timezone_offset_minutes)
                event_copy["datetime_utc"] = utc_time
                event_copy["datetime"] = local_time
            
            converted_events.append(event_copy)
        
        return converted_events
    
    def _map_event_type_id_to_name(self, event_type_id: Any) -> str:
        """
        이벤트 ID를 이벤트 이름으로 변환하는 내부 함수.
        사용자에게는 항상 이벤트 이름만 표시됩니다.
        """
        if event_type_id is None:
            return "Unknown Event"
        
        event_id_str = str(event_type_id)
        return EVENT_TYPE_NAMES.get(event_id_str, f"Unknown Event (ID: {event_id_str})")
    
    def _enrich_events_with_names(self, events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        이벤트 리스트의 각 이벤트에 event_type_name을 추가하고,
        사용자에게 보여줄 때는 ID 대신 이름만 표시되도록 합니다.
        event_type_id 필드는 완전히 이벤트 이름으로 교체합니다.
        """
        enriched_events = []
        for event in events:
            event_copy = event.copy()
            
            # event_type_id 필드 처리
            if "event_type_id" in event_copy:
                event_type_id_original = event_copy["event_type_id"]
                
                # 이미 딕셔너리 형태로 되어있는 경우 (예: {"code": "4096", "name": "..."})
                if isinstance(event_type_id_original, dict):
                    code = event_type_id_original.get("code")
                    event_type_name = self._map_event_type_id_to_name(code)
                else:
                    # 숫자나 문자열로 되어있는 경우
                    event_type_name = self._map_event_type_id_to_name(event_type_id_original)
                
                # event_type_id를 이벤트 이름으로 완전히 교체 (ID는 완전히 숨김)
                event_copy["event_type_id"] = event_type_name
                event_copy["event_type"] = event_type_name
                event_copy["event_type_name"] = event_type_name
            
            enriched_events.append(event_copy)
        
        return enriched_events
    
    async def get_event_types(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """
        GET /api/event_types?is_break_glass=<bool>&setting_alert=<bool>&setting_all=<bool>
        Server flags:
        - is_break_glass: if true, lists user-renamed (break-glass) event names. When true and the others are not given, setting_alert/setting_all default to false.
        - setting_alert: if true, lists alertable event types.
        - setting_all: if true, lists all event types.

        Client-side enhancements:
        - search: case-insensitive contains across code/name/description
        - codes: restrict to given event code(s)
        - only_alertable: keep only items with alertable == true
        - only_enable_alert: keep only items with enable_alert == true
        - sort_by: "code" | "name" (default "code")
        - sort_desc: boolean
        - limit, offset: slicing
        - group_by: "none" | "alertable" | "enable_alert" (default "none")
        """
        try:
            self.check_auth()

            # ---- Server query parameters ----
            is_break_glass = bool(args.get("is_break_glass", False))

            if "setting_alert" in args:
                setting_alert = bool(args.get("setting_alert"))
            else:
                setting_alert = False if is_break_glass else True

            if "setting_all" in args:
                setting_all = bool(args.get("setting_all"))
            else:
                setting_all = False if is_break_glass else True

            params = {
                "is_break_glass": str(is_break_glass).lower(),
                "setting_alert": str(setting_alert).lower(),
                "setting_all": str(setting_all).lower(),
            }

            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json",
            }

            async with httpx.AsyncClient(verify=False) as client:
                resp = await client.get(
                    f"{self.session.config.biostar_url}/api/event_types",
                    headers=headers,
                    params=params,
                )

            if resp.status_code != 200:
                return self.error_response(f"API call failed: {resp.status_code} - {resp.text}")

            payload = resp.json() or {}
            rows = (payload.get("EventTypeCollection") or {}).get("rows", []) or []

            # ---- Normalize booleans ----
            def _to_bool(v: Any) -> bool:
                if isinstance(v, bool):
                    return v
                if isinstance(v, str):
                    return v.strip().lower() == "true"
                return bool(v)

            normalized: List[Dict[str, Any]] = []
            for it in rows:
                normalized.append({
                    "code": str(it.get("code") or ""),
                    "name": it.get("name") or "",
                    "description": it.get("description") or "",
                    "alertable": _to_bool(it.get("alertable", False)),
                    "enable_alert": _to_bool(it.get("enable_alert", False)),
                })

            # ---- Client-side filters ----
            search = (args.get("search") or "").strip().lower()
            if search:
                normalized = [
                    x for x in normalized
                    if (search in x["code"].lower()
                        or search in x["name"].lower()
                        or search in (x["description"] or "").lower())
                ]

            codes_arg = args.get("codes") or []
            if codes_arg:
                code_set = {str(c) for c in codes_arg}
                normalized = [x for x in normalized if x["code"] in code_set]

            if bool(args.get("only_alertable", False)):
                normalized = [x for x in normalized if x["alertable"]]

            if bool(args.get("only_enable_alert", False)):
                normalized = [x for x in normalized if x["enable_alert"]]

            # ---- Sorting ----
            sort_by = (args.get("sort_by") or "code").lower()
            sort_desc = bool(args.get("sort_desc", False))

            def _code_key(v: Dict[str, Any]):
                c = v.get("code", "")
                try:
                    return int(c)
                except Exception:
                    return c

            if sort_by == "name":
                normalized.sort(key=lambda v: (v.get("name") or "").lower(), reverse=sort_desc)
            else:
                normalized.sort(key=_code_key, reverse=sort_desc)

            # ---- Slicing ----
            offset = int(args.get("offset", 0))
            limit = args.get("limit")
            if limit is not None:
                limit = int(limit)
                sliced = normalized[offset: offset + limit]
            else:
                sliced = normalized[offset:]

            # ---- Grouping ----
            group_by = (args.get("group_by") or "none").lower()
            if group_by == "alertable":
                grouped: Dict[str, List[Dict[str, Any]]] = {
                    "true": [x for x in sliced if x["alertable"]],
                    "false": [x for x in sliced if not x["alertable"]],
                }
                data_out: Dict[str, Any] = grouped
                returned_count = len(grouped["true"]) + len(grouped["false"])
            elif group_by == "enable_alert":
                grouped = {
                    "true": [x for x in sliced if x["enable_alert"]],
                    "false": [x for x in sliced if not x["enable_alert"]],
                }
                data_out = grouped
                returned_count = len(grouped["true"]) + len(grouped["false"])
            else:
                data_out = {"items": sliced}
                returned_count = len(sliced)

            # ---- Summary ----
            summary = {
                "total": len(normalized) if not search and not codes_arg and not args.get("only_alertable") and not args.get("only_enable_alert") else len(normalized),
                "returned": returned_count,
                "alertable_true_count": sum(1 for x in normalized if x["alertable"]),
                "enable_alert_true_count": sum(1 for x in normalized if x["enable_alert"]),
            }

            return self.success_response({
                "message": f"Found {summary['total']} event types",
                "summary": summary,
                "api_params": params,
                "filters": {
                    "search": search or None,
                    "codes": codes_arg or None,
                    "only_alertable": bool(args.get("only_alertable", False)),
                    "only_enable_alert": bool(args.get("only_enable_alert", False)),
                    "sort_by": sort_by,
                    "sort_desc": sort_desc,
                    "offset": offset,
                    "limit": limit,
                    "group_by": group_by,
                },
                "event_types": data_out,
            })

        except Exception as e:
            return await self.handle_api_error(e)

    
    def _convert_to_utc(self, datetime_str: str) -> str:
        """
        Convert local datetime string to UTC ISO format (BioStar API format).
        
        Args:
            datetime_str: Local datetime string (ISO 8601 format)
                         e.g., "2025-11-01T00:00:00", "2025-11-01T23:59:59+09:00"
        
        Returns:
            UTC datetime string in BioStar format
            e.g., "2025-10-31T15:00:00.000Z"
        """
        try:
            from datetime import timezone as tz
            
            # Parse the input datetime
            dt_str = datetime_str.strip()
            
            # Parse datetime with or without timezone
            if dt_str.endswith('Z'):
                # Already UTC
                dt_str = dt_str.replace('Z', '+00:00')
                dt = datetime.fromisoformat(dt_str)
                dt_utc = dt.replace(tzinfo=None)
            elif '+' in dt_str or (dt_str.count('-') > 2 and 'T' in dt_str):
                # Has timezone offset (e.g., "+09:00" or "-05:00")
                dt = datetime.fromisoformat(dt_str)
                # Convert to UTC
                if dt.tzinfo:
                    dt_utc = dt.astimezone(tz.utc).replace(tzinfo=None)
                else:
                    dt_utc = dt
            else:
                # No timezone info - assume server local time (KST = UTC+9)
                dt = datetime.fromisoformat(dt_str)
                # Treat as KST and convert to UTC
                dt_with_tz = dt.replace(tzinfo=tz(timedelta(hours=9)))
                dt_utc = dt_with_tz.astimezone(tz.utc).replace(tzinfo=None)
            
            # Format as BioStar expects: "2025-10-31T15:00:00.000Z"
            return dt_utc.strftime("%Y-%m-%dT%H:%M:%S.000Z")
            
        except Exception as e:
            logger.error(f"Failed to convert datetime '{datetime_str}' to UTC: {e}")
            # Return original string as fallback
            return datetime_str
    
    async def search_events(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Advanced search for events (accepts both 'value' and 'values' in conditions)."""
        try:
            self.check_auth()

            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json"
            }

            # ---- base pagination/sort ----
            limit = int(args.get("limit", 100))
            offset = int(args.get("offset", 0))
            order_by = args.get("order_by", "datetime")
            order_type = args.get("order_type", "desc")
            descending = (order_type == "desc")

            conds_in = list(args.get("conditions") or [])
            start_dt = args.get("start_datetime")
            end_dt = args.get("end_datetime")
            
            # datetime 조건이 없으면 start_dt/end_dt로 추가
            has_datetime = any(c.get("column") == "datetime" for c in conds_in)
            if not has_datetime and (start_dt or end_dt):
                # Convert to UTC for BioStar API
                if start_dt and end_dt:
                    start_dt_utc = self._convert_to_utc(start_dt)
                    end_dt_utc = self._convert_to_utc(end_dt)
                    logger.info(f" Date range: {start_dt} ~ {end_dt} → UTC: {start_dt_utc} ~ {end_dt_utc}")
                    conds_in.append({"column": "datetime", "operator": 3, "values": [start_dt_utc, end_dt_utc]})
                elif start_dt:
                    start_dt_utc = self._convert_to_utc(start_dt)
                    logger.info(f" Start date: {start_dt} → UTC: {start_dt_utc}")
                    conds_in.append({"column": "datetime", "operator": 5, "values": [start_dt_utc]})
                else:
                    end_dt_utc = self._convert_to_utc(end_dt)
                    logger.info(f" End date: {end_dt} → UTC: {end_dt_utc}")
                    conds_in.append({"column": "datetime", "operator": 6, "values": [end_dt_utc]})

            user_id = args.get("user_id")
            user_name = args.get("user_name")
            if user_name and not user_id:
                resolved_id = await self._resolve_user_id_by_name(user_name, headers)
                if not resolved_id:
                    return self.error_response(f"No user matched name '{user_name}'.")
                user_id = resolved_id
            if user_id:
                has_user = any(c.get("column") in ("user_id", "user_id.user_id") for c in conds_in)
                if not has_user:
                    # operator 2 사용 (웹페이지와 동일)
                    conds_in.append({"column": "user_id.user_id", "operator": 2, "values": [str(user_id)]})
                    logger.info(f" User filter: user_id={user_id}")

            norm_conds: List[Dict[str, Any]] = []
            for c in conds_in:
                column = c.get("column")
                operator = int(c.get("operator"))
                values = c.get("values", c.get("value"))

                if values is None:
                    return self.error_response("Each condition must include 'values' (or 'value').")

                if column == "datetime":
                    # Convert datetime values to UTC
                    utc_values = []
                    for v in values:
                        if isinstance(v, str):
                            if not validate_datetime(v):
                                return self.error_response(
                                    f"Invalid datetime format: {v}. Use ISO 8601 with timezone, e.g. 2025-08-01T00:00:00.000Z"
                                )
                            # Convert to UTC for BioStar API
                            utc_v = self._convert_to_utc(v)
                            utc_values.append(utc_v)
                        else:
                            utc_values.append(v)
                    values = utc_values
                    if len(values) == 2:
                        logger.info(f" Datetime condition converted to UTC: {utc_values[0]} ~ {utc_values[1]}")

                if column == "user_id":
                    column = "user_id.user_id"

                if column == "user_id.user_id" and operator not in (0, 1, 2):
                    operator = 0

                if not isinstance(values, list):
                    values = [values]
                values = [str(v) for v in values]

                norm_conds.append({"column": column, "operator": operator, "values": values})

            query = {
                "Query": {
                    "limit": limit,
                    "conditions": norm_conds,
                    "orders": [{"column": order_by, "descending": bool(descending)}]
                }
            }
            if offset:
                query["Query"]["offset"] = offset

            #  로그에 실제 쿼리 출력 (디버깅용)
            import json as json_module
            logger.info(f" BioStar API Query: {json_module.dumps(query, ensure_ascii=False)}")

            async with httpx.AsyncClient(verify=False) as client:
                response = await client.post(
                    f"{self.session.config.biostar_url}/api/events/search",
                    headers=headers,
                    json=query
                )

            if response.status_code != 200:
                return self.error_response(f"API call failed: {response.status_code} - {response.text}")

            data = response.json() or {}
            events = (data.get("EventCollection") or {}).get("rows", []) or []
            total = (data.get("EventCollection") or {}).get("total", 0)

            # 서버 타임존 가져오기
            timezone_offset = await self._get_server_timezone_offset()
            
            # 이벤트 ID를 이벤트 이름으로 자동 변환
            enriched_events = self._enrich_events_with_names(events)
            
            # 이벤트 시간을 서버 로컬 시간으로 변환
            enriched_events = self._convert_event_times(enriched_events, timezone_offset)

            return self.success_response({
                "message": f"Found {len(events)} events matching search criteria",
                "total": total,
                "count": len(enriched_events),
                "events": enriched_events,
                "request_query": query
            })

        except Exception as e:
            return await self.handle_api_error(e)

    async def get_realtime_events(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Connect to websocket for real-time events (simulation)."""
        try:
            self.check_auth()
            
            # Note: WebSocket implementation would require additional setup
            # This is a simulation of what the real-time monitoring would return
            
            duration = args.get("duration", 60)
            event_types = args.get("event_types", [])
            
            return self.success_response({
                "message": "Real-time event monitoring requires WebSocket connection",
                "note": "This feature requires additional WebSocket client setup",
                "configuration": {
                    "duration": f"{duration} seconds",
                    "event_types": event_types if event_types else "All events",
                    "websocket_url": f"wss://{self.session.config.biostar_url.replace('https://', '').replace('http://', '')}/wsapi/v1/events"
                }
            })
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def get_access_logs(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Get access control specific logs."""
        try:
            self.check_auth()
            
            # Build conditions for access-related events
            conditions = []
            
            # Time range filter
            if args.get("start_datetime"):
                conditions.append({
                    "column": "datetime",
                    "operator": 5,  # GREATER
                    "value": [args["start_datetime"]]
                })
            if args.get("end_datetime"):
                conditions.append({
                    "column": "datetime",
                    "operator": 6,  # LESS
                    "value": [args["end_datetime"]]
                })
            
            # User name filter
            if args.get("user_name"):
                conditions.append({
                    "column": "user_id.name",
                    "operator": 2,  # CONTAINS
                    "value": [args["user_name"]]
                })
            
            # Success only filter - filter by specific event types
            if args.get("success_only", False):
                conditions.append({
                    "column": "event_type_id",
                    "operator": 0,  # EQUAL
                    "value": ["4865"]  # Verify Success event type
                })
            
            # Use the search API for access logs
            search_args = {
                "conditions": conditions,
                "limit": args.get("limit", 100),
                "order_by": "datetime",
                "order_type": "desc"
            }
            
            return await self.search_events(search_args)
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    async def export_events_csv(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        r"""
        Export event logs to CSV via POST /api/events/export and copy to Windows Downloads.

        - Server saves CSV under Nginx download dir (e.g., C:\Program Files\BioStar X\nginx\html\download)
        - Then we copy it to:
            • dest_dir (if provided), or
            • C:\Users\<target_username>\Downloads (if provided), or
            • %USERPROFILE%\Downloads (default)
        - Query params:
            • time_offset (minutes, e.g., 480 for UTC+8)
            • use_centigrade (bool; default True)

        Payload to BioStar:
        {
        "Query": {
            "conditions": [{"column":"datetime","operator":3,"values":[start,end]}, ...],
            "offset": 0,
            "columns": [...],
            "headers": [...]
        }
        }
        """
        try:
            self.check_auth()

            # ---------- file copy options ----------
            copy_to_downloads: bool = bool(args.get("copy_to_downloads", True))
            dest_dir_arg: str = (args.get("dest_dir") or "").strip()
            target_username: str = (args.get("target_username") or "").strip()

            headers = {
                "bs-session-id": self.get_session_id(),
                "Content-Type": "application/json",
            }

            # ---------- columns / headers ----------
            default_columns = [
                "datetime",
                "door_id.name",
                "device_id.id",
                "device_id.name",
                "user_group_id",
                "user_id",
                "temperature",
                "event_type_id",
                "tna_key",
            ]
            default_headers = [
                "Date",
                "Door",
                "Device ID",
                "Device",
                "User Group",
                "User",
                "Temperature",
                "Event",
                "TNA Key",
            ]
            columns = args.get("columns") or default_columns
            headers_csv = args.get("headers") or default_headers
            if len(columns) != len(headers_csv):
                return self.error_response("Length of 'headers' must match 'columns'.")

            # ---------- build/normalize conditions ----------
            conditions = list(args.get("conditions") or [])
            start_dt = args.get("start_datetime")
            end_dt = args.get("end_datetime")
            if not conditions:
                if start_dt and end_dt:
                    conditions.append({"column": "datetime", "operator": 3, "values": [start_dt, end_dt]})
                elif start_dt:
                    conditions.append({"column": "datetime", "operator": 5, "values": [start_dt]})
                elif end_dt:
                    conditions.append({"column": "datetime", "operator": 6, "values": [end_dt]})

            # Convenience: user constraint (user_id or user_name)
            # - If user_name is provided, resolve to user_id via /api/v2/users/search
            user_id = args.get("user_id")
            user_name = args.get("user_name")
            if user_name and not user_id:
                resolved_id = await self._resolve_user_id_by_name(user_name, headers)
                if not resolved_id:
                    return self.error_response(f"No user matched name '{user_name}'.")
                user_id = resolved_id

            if user_id:
                # Only add if not already constrained
                has_user_filter = any(
                    (c.get("column") in ("user_id", "user_id.user_id")) for c in conditions
                )
                if not has_user_filter:
                    conditions.append({
                        "column": "user_id.user_id",  # normalized field path
                        "operator": 0,
                        "values": [str(user_id)],
                    })

            # Normalize any 'user_id' -> 'user_id.user_id'
            for c in conditions:
                col = c.get("column")
                if col == "user_id":
                    c["column"] = "user_id.user_id"
                # Ensure 'values' is a list of strings
                vals = c.get("values")
                if isinstance(vals, list):
                    c["values"] = [str(v) for v in vals]
                elif vals is not None:
                    c["values"] = [str(vals)]

            # Optional: event_types convenience
            event_types = args.get("event_types") or []
            if event_types:
                conditions.append({
                    "column": "event_type_id",
                    "operator": 0,
                    "values": [str(x) for x in event_types],
                })

            offset = int(args.get("offset", 0))
            time_offset = int(args.get("time_offset_minutes", args.get("time_offset", 0)))
            use_centigrade = bool(args.get("use_centigrade", True))

            payload = {
                "Query": {
                    "conditions": conditions,
                    "offset": offset,
                    "columns": columns,
                    "headers": headers_csv,
                }
            }

            # ---------- call /api/events/export ----------
            async with httpx.AsyncClient(verify=False) as client:
                resp = await client.post(
                    f"{self.session.config.biostar_url}/api/events/export",
                    headers=headers,
                    params={"time_offset": time_offset, "use_centigrade": str(use_centigrade).lower()},
                    json=payload,
                )

            if resp.status_code != 200:
                return self.error_response(f"Events export failed: {resp.status_code} - {resp.text}")

            body = resp.json() or {}
            filename = (body.get("File") or {}).get("uri") or body.get("filename")
            if not filename:
                return self.error_response("Export succeeded but no filename returned", {"response": body})

            # ---------- wait for file in Nginx download dir ----------
            download_root = getattr(
                self.session.config,
                "download_dir",
                r"C:\Program Files\BioStar X\nginx\html\download",
            )
            src_path = Path(download_root) / filename

            for _ in range(50):
                if src_path.exists():
                    break
                await asyncio.sleep(0.1)

            # ---------- copy to Windows Downloads ----------
            copy_status = "skipped"
            copied_to = ""
            if copy_to_downloads:
                if platform.system().lower() == "windows":
                    if dest_dir_arg:
                        dest_dir = Path(dest_dir_arg)
                    elif target_username:
                        dest_dir = Path(f"C:\\Users\\{target_username}\\Downloads")
                    else:
                        userprofile = os.environ.get("USERPROFILE") or str(Path.home())
                        dest_dir = Path(userprofile) / "Downloads"

                    try:
                        dest_dir.mkdir(parents=True, exist_ok=True)
                        if not src_path.exists():
                            copy_status = "failed: source not found"
                        else:
                            dest_path = dest_dir / filename
                            shutil.copy2(src_path, dest_path)
                            copied_to = str(dest_path)
                            copy_status = "success"
                    except Exception as ce:
                        copy_status = f"failed: {ce}"
                else:
                    copy_status = "skipped: non-windows"

            return self.success_response({
                "message": "Events CSV exported successfully",
                "filename": filename,
                "download_url": f"/download/{filename}",
                "source_path": str(src_path),
                "copy": {"enabled": copy_to_downloads, "status": copy_status, "destination": copied_to},
                "export_params": {
                    "time_offset": time_offset,
                    "use_centigrade": use_centigrade,
                    "offset": offset,
                    "columns": columns,
                    "headers": headers_csv,
                    "conditions": conditions,
                },
            })

        except Exception as e:
            return await self.handle_api_error(e)

    
    async def get_temperature_logs(self, args: Dict[str, Any]) -> Sequence[TextContent]:
        """Get temperature measurement logs from thermal cameras."""
        try:
            self.check_auth()
            
            conditions = [
                {
                    "column": "event_type_id",
                    "operator": 0,
                    "value": ["7168"]
                }
            ]
            
            if args.get("start_datetime"):
                conditions.append({
                    "column": "datetime",
                    "operator": 5,
                    "value": [args["start_datetime"]]
                })
            if args.get("end_datetime"):
                conditions.append({
                    "column": "datetime",
                    "operator": 6,
                    "value": [args["end_datetime"]]
                })
            if args.get("user_id"):
                conditions.append({
                    "column": "user_id",
                    "operator": 0,
                    "value": [args["user_id"]]
                })
            
            search_result = await self.search_events({
                "conditions": conditions,
                "limit": 100,
                "order_by": "datetime",
                "order_type": "desc"
            })
            
            # Filter by temperature threshold if specified
            if args.get("temperature_threshold") or args.get("abnormal_only"):
                # Would need to parse temperature from event data
                # This is a placeholder for the actual implementation
                return self.success_response({
                    "message": "Temperature log filtering requires parsing event metadata",
                    "note": "Temperature data is stored in event metadata field",
                    "search_performed": True,
                    "filters_applied": {
                        "abnormal_only": args.get("abnormal_only", False),
                        "threshold": args.get("temperature_threshold")
                    }
                })
            
            return search_result
            
        except Exception as e:
            return await self.handle_api_error(e)
    
    def format_access_log_info(self, log: Dict[str, Any]) -> Dict[str, Any]:
        """Format access log information for response."""
        # 이벤트 타입 ID를 이벤트 이름으로 변환
        event_type_id_obj = log.get("event_type_id")
        if isinstance(event_type_id_obj, dict):
            event_code = event_type_id_obj.get("code")
            event_type_name = self._map_event_type_id_to_name(event_code)
        else:
            event_type_name = self._map_event_type_id_to_name(event_type_id_obj)
        
        return {
            "id": log.get("id"),
            "datetime": log.get("datetime"),
            "user_id": log.get("user_id", {}).get("user_id") if isinstance(log.get("user_id"), dict) else log.get("user_id"),
            "user_name": log.get("user_id", {}).get("name") if isinstance(log.get("user_id"), dict) else None,
            "door_id": log.get("door_id", {}).get("id") if isinstance(log.get("door_id"), dict) else log.get("door_id"),
            "door_name": log.get("door_id", {}).get("name") if isinstance(log.get("door_id"), dict) else None,
            "event_type": event_type_name,  # 이벤트 이름으로 표시 (ID 아님)
            "result": log.get("result"),
            "message": log.get("message")
        }

    async def _resolve_user_id_by_name(self, name: str, headers: Dict[str, str]) -> Optional[str]:
        """
        Resolve a single user_id by user name (partial match allowed).
        Returns user_id as string, or None if not found/ambiguous.
        """
        try:
            payload = {"limit": 2, "search_text": name}
            async with httpx.AsyncClient(verify=False) as client:
                r = await client.post(f"{self.session.config.biostar_url}/api/v2/users/search",
                                    headers=headers, json=payload)
            if r.status_code != 200:
                return None
            users = (r.json() or {}).get("UserCollection", {}).get("rows", []) or []
            if len(users) == 1:
                return str(users[0].get("user_id"))
            # 완전일치 우선
            exact = [u for u in users if str(u.get("name") or "") == name]
            if len(exact) == 1:
                return str(exact[0].get("user_id"))
            return None
        except Exception:
            return None