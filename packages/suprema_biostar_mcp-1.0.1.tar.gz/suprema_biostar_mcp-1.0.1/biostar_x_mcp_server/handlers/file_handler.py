"""
File Handler - Handle uploaded files from requests
"""
import logging
import base64
import io
from typing import Dict, Any, List, Sequence
from mcp.types import TextContent
from biostar_x_mcp_server.handlers.base_handler import BaseHandler

# OCR imports
try:
    import pytesseract
    from PIL import Image
    import os
    
    # Windows에서 Tesseract 경로 설정
    if os.name == 'nt':  # Windows
        tesseract_paths = [
            r'C:\Program Files\Tesseract-OCR\tesseract.exe',
            r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
            r'C:\Users\{}\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'.format(os.getenv('USERNAME', ''))
        ]
        
        for path in tesseract_paths:
            if os.path.exists(path):
                pytesseract.pytesseract.tesseract_cmd = path
                # Tesseract path configured
                break
    
    # Test OCR library
    try:
        version = pytesseract.get_tesseract_version()
        # Tesseract OCR is available
        OCR_AVAILABLE = True
    except Exception:
        # Tesseract test failed
        OCR_AVAILABLE = False
    
except ImportError:
    # OCR library import failed
    OCR_AVAILABLE = False

logger = logging.getLogger(__name__)


class FileHandler(BaseHandler):
    """Handler for file operations on uploaded files"""
    
    def __init__(self):
        """Initialize FileHandler without session (no API calls needed)"""
        super().__init__(session=None)
        self.uploaded_files = {}  # Store uploaded files per session
        
    def set_uploaded_files(self, session_id: str, files: List[Dict[str, Any]]):
        """Store uploaded files for a session"""
        self.uploaded_files[session_id] = files
        logger.info(f" Stored {len(files)} files for session {session_id}")
    
    def _extract_text_from_image(self, base64_content: str) -> str:
        """Extract text from image using OCR"""
        logger.info(" OCR started")
        
        if not OCR_AVAILABLE:
            logger.error(" OCR library not available")
            return " OCR library is not installed. Please install pytesseract and Pillow."
        
        try:
            # Decode base64 to bytes
            image_bytes = base64.b64decode(base64_content)
            
            # Open image with PIL
            image = Image.open(io.BytesIO(image_bytes))
            
            # Extract text using pytesseract
            text = pytesseract.image_to_string(image, lang='eng')
            
            result = text.strip() if text.strip() else "No text found in image."
            logger.info(" OCR completed")
            return result
            
        except Exception as e:
            logger.error(f" OCR error: {e}")
            return f" Error occurred during OCR processing: {str(e)}"
        
    async def read_uploaded_file(self, args: dict) -> Sequence[TextContent]:
        """
        Read the content of an uploaded file
        
        Args:
            filename: Name of the uploaded file
        
        Returns:
            File content as text or base64
        """
        filename = args.get("filename", "").strip()
        logger.info(f" Reading file: {filename}")
        
        if not filename:
            return [TextContent(type="text", text=" filename parameter is required")]
        
        # Get session ID
        session_id = getattr(self, 'client_session_id', 'default')
        
        # Check if files exist for this session
        if session_id not in self.uploaded_files:
            return [TextContent(type="text", text=f" No uploaded files found for this session")]
        
        files = self.uploaded_files[session_id]
        
        # Find the file
        file_data = None
        for f in files:
            if f.get("filename", "").lower() == filename.lower():
                file_data = f
                break
        
        if not file_data:
            available = [f.get("filename") for f in files]
            return [TextContent(
                type="text",
                text=f" File '{filename}' not found.\n"
                     f"Available files: {', '.join(available)}"
            )]
        
        # Return file content based on type
        file_type = file_data.get("type")
        
        if file_type == "csv":
            content = file_data.get("content", "")
            base64_content = file_data.get("base64", "")
            original_format = file_data.get("original_format", "csv")
            
            file_type_label = "XLSX" if original_format == "xlsx" else "CSV"
            format_note = "(Converted from XLSX to CSV format)\n\n" if original_format == "xlsx" else ""
            
            return [TextContent(
                type="text",
                text=f" {file_type_label} file read successfully: {filename}\n\n"
                     f"File size: {file_data.get('size', 0)} bytes\n"
                     f"{format_note}"
                     f"Preview:\n```csv\n{file_data.get('preview', '')}\n```\n\n"
                     f"Full content:\n```csv\n{content}\n```\n\n"
                     f"Base64 (for import tools):\n{base64_content[:100]}... (total {len(base64_content)} chars)\n\n"
                     f" To add users, call import-users-csv-smart tool with:\n"
                     f"- file_text: (full content above)\n"
                     f"- original_file_name: {filename}"
            )]
            
        elif file_type == "pdf":
            base64_content = file_data.get("base64", "")
            return [TextContent(
                type="text",
                text=f" PDF file read successfully: {filename}\n\n"
                     f"File size: {file_data.get('size', 0)} bytes\n"
                     f"Base64 content:\n{base64_content[:100]}... (total {len(base64_content)} chars)\n\n"
                     f" PDF file requires text extraction."
            )]
            
        elif file_type == "image":
            base64_content = file_data.get("base64", "")
            
            # Extract text using OCR
            extracted_text = self._extract_text_from_image(base64_content)
            
            # Natural response based on OCR results
            if "No text found in image." in extracted_text:
                response_text = f" Image file confirmed: {filename}\n\n"
                response_text += f"File size: {file_data.get('size', 0)} bytes\n\n"
                response_text += f"This image appears to be primarily graphics or icons with unclear text.\n"
                response_text += f"Please describe the image content directly for more accurate assistance."
            elif "Error occurred during OCR processing" in extracted_text:
                response_text = f" Image file confirmed: {filename}\n\n"
                response_text += f"File size: {file_data.get('size', 0)} bytes\n\n"
                response_text += f"There was a temporary issue with image analysis.\n"
                response_text += f"Please briefly describe the main content of the image for assistance."
            else:
                response_text = f" Image analysis completed: {filename}\n\n"
                response_text += f"File size: {file_data.get('size', 0)} bytes\n\n"
                response_text += f" Extracted text:\n```\n{extracted_text}\n```\n\n"
                response_text += f" Please let me know what assistance you need based on the above content."
            
            return [TextContent(type="text", text=response_text)]
            
        elif file_type == "text":
            content = file_data.get("content", "")
            return [TextContent(
                type="text",
                text=f" Text file read successfully: {filename}\n\n"
                     f"File size: {file_data.get('size', 0)} bytes\n\n"
                     f"Content:\n```\n{content}\n```"
            )]
            
        elif file_type == "binary":
            base64_content = file_data.get("base64", "")
            return [TextContent(
                type="text",
                text=f" Binary file read successfully: {filename}\n\n"
                     f"File size: {file_data.get('size', 0)} bytes\n"
                     f"Base64 content:\n{base64_content[:100]}... (total {len(base64_content)} chars)"
            )]
            
        elif file_type == "error":
            error = file_data.get("error", "Unknown error")
            return [TextContent(
                type="text",
                text=f" File read error: {filename}\n\n"
                     f"Error: {error}"
            )]
        
        return [TextContent(type="text", text=f" Unknown file type: {file_type}")]

