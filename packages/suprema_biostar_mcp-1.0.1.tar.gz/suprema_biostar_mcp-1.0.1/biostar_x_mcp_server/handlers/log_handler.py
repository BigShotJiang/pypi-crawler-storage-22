"""
BioStar X 로그 분석 핸들러
"""
import os
import logging
import glob
import psutil
import platform
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from mcp.types import TextContent
from .base_handler import BaseHandler

logger = logging.getLogger(__name__)


class LogHandler(BaseHandler):
    """BioStar X 로그 분석을 위한 핸들러"""
    
    def __init__(self, session):
        super().__init__(session)
        self.default_log_path = r"C:\Program Files\BioStar X\logs"
        
    async def analyze_server_logs(
        self, 
        log_path: Optional[str] = None, 
        lines_to_read: int = 50,
        **kwargs  # 추가 파라미터 무시
    ) -> List[TextContent]:
        """BioStar X 서버 로그를 종합 분석합니다."""
        try:
            if not log_path:
                log_path = self.default_log_path
            
            logger.info(f"Checking log directory: {log_path}")
                
            # 로그 파일 경로 확인
            if not os.path.exists(log_path):
                logger.error(f"Log directory not found: {log_path}")
                return self.error_response(
                    "로그 디렉토리를 찾을 수 없습니다",
                    {"path": log_path, "suggestion": "BioStar X가 설치되어 있는지 확인하세요"}
                )
            
            # 오늘 날짜 기준으로 로그 파일 찾기
            today = datetime.now()
            log_files = self._find_today_log_files(log_path, today)
            
            logger.info(f"Found log files: {log_files}")
            
            if not log_files:
                logger.warning(f"No log files found for today: {today.strftime('%Y-%m-%d')}")
                return self.error_response(
                    "오늘 날짜의 로그 파일을 찾을 수 없습니다",
                    {"path": log_path, "date": today.strftime("%Y-%m-%d")}
                )
            
            # 각 로그 파일 분석
            analysis_results = {}
            for log_type, file_path in log_files.items():
                if os.path.exists(file_path):
                    analysis_results[log_type] = await self._analyze_log_file(file_path, lines_to_read)
                else:
                    analysis_results[log_type] = {"error": f"파일을 찾을 수 없습니다: {file_path}"}
            
            # 종합 분석 결과 생성
            summary = self._generate_log_summary(analysis_results, today)
            
            # 상세 분석에서 로그 라인은 제외하고 통계만 포함
            simplified_analysis = {}
            for log_type, result in analysis_results.items():
                if "error" in result:
                    simplified_analysis[log_type] = result
                else:
                    log_analysis = result.get("log_analysis", {})
                    simplified_analysis[log_type] = {
                        "file_info": result.get("file_info", {}),
                        "statistics": {
                            "total_lines": log_analysis.get("total_lines", 0),
                            "error_count": log_analysis.get("error_count", 0),
                            "warning_count": log_analysis.get("warning_count", 0),
                            "info_count": log_analysis.get("info_count", 0),
                            "server_status": log_analysis.get("server_status", "unknown")
                        },
                        "sample_errors": log_analysis.get("recent_errors", [])[:3],  # 최대 3개만
                        "sample_warnings": log_analysis.get("recent_warnings", [])[:3]  # 최대 3개만
                    }
            
            return self.success_response(
                {
                    "analysis_date": today.strftime("%Y-%m-%d %H:%M:%S"),
                    "log_directory": log_path,
                    "analyzed_files": log_files,
                    "summary": summary,
                    "detailed_analysis": simplified_analysis
                },
                "BioStar X 서버 로그 분석이 완료되었습니다"
            )
            
        except Exception as e:
            logger.error(f"Error during log analysis: {e}", exc_info=True)
            return self.error_response(
                "로그 분석 중 오류가 발생했습니다",
                {"error": str(e)}
            )
    
    async def get_log_file_info(self, log_path: Optional[str] = None) -> List[TextContent]:
        """로그 디렉토리의 파일 정보를 조회합니다."""
        try:
            if not log_path:
                log_path = self.default_log_path
                
            if not os.path.exists(log_path):
                return self.error_response(
                    "로그 디렉토리를 찾을 수 없습니다",
                    {"path": log_path}
                )
            
            # 로그 파일 목록 수집
            log_files = []
            for file_path in glob.glob(os.path.join(log_path, "*.log")):
                try:
                    stat = os.stat(file_path)
                    log_files.append({
                        "filename": os.path.basename(file_path),
                        "full_path": file_path,
                        "size_bytes": stat.st_size,
                        "size_mb": round(stat.st_size / (1024 * 1024), 2),
                        "modified_time": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                        "created_time": datetime.fromtimestamp(stat.st_ctime).strftime("%Y-%m-%d %H:%M:%S")
                    })
                except Exception as e:
                    logger.warning(f"Failed to get file info: {file_path}, error: {e}")
            
            # 파일 크기순으로 정렬
            log_files.sort(key=lambda x: x["size_bytes"], reverse=True)
            
            return self.success_response(
                {
                    "log_directory": log_path,
                    "total_files": len(log_files),
                    "files": log_files
                },
                f"로그 디렉토리 정보 조회 완료 ({len(log_files)}개 파일)"
            )
            
        except Exception as e:
            logger.error(f"Error getting log file info: {e}", exc_info=True)
            return self.error_response(
                "로그 파일 정보 조회 중 오류가 발생했습니다",
                {"error": str(e)}
            )
    
    async def read_specific_log(
        self, 
        log_file_path: str, 
        lines_to_read: int = 50, 
        from_end: bool = True
    ) -> List[TextContent]:
        """특정 로그 파일의 내용을 읽어 분석합니다."""
        try:
            if not os.path.exists(log_file_path):
                return self.error_response(
                    "로그 파일을 찾을 수 없습니다",
                    {"path": log_file_path}
                )
            
            # 로그 파일 분석
            analysis = await self._analyze_log_file(log_file_path, lines_to_read, from_end)
            
            return self.success_response(
                {
                    "file_path": log_file_path,
                    "lines_read": lines_to_read,
                    "from_end": from_end,
                    "analysis": analysis
                },
                f"로그 파일 분석 완료: {os.path.basename(log_file_path)}"
            )
            
        except Exception as e:
            logger.error(f"Error reading log file: {e}", exc_info=True)
            return self.error_response(
                "로그 파일 읽기 중 오류가 발생했습니다",
                {"error": str(e)}
            )
    
    def _find_today_log_files(self, log_path: str, today: datetime) -> Dict[str, str]:
        """오늘 날짜의 로그 파일들을 찾습니다."""
        log_files = {}
        date_str = today.strftime("%Y-%m-%d")
        
        # 각 로그 파일 패턴 확인
        patterns = {
            "main_server": f"biostar_{date_str}.log",
            "device": f"biostar_device_{date_str}.log", 
            "gateway": "serverGateway.log",
            "api_server": "acs.log"
        }
        
        for log_type, pattern in patterns.items():
            file_path = os.path.join(log_path, pattern)
            if os.path.exists(file_path):
                log_files[log_type] = file_path
            else:
                # 날짜가 다른 경우 최신 파일 찾기
                if log_type in ["main_server", "device"]:
                    # 날짜 패턴이 있는 파일들 중 최신 것 찾기
                    if log_type == "main_server":
                        search_pattern = os.path.join(log_path, "biostar_*.log")
                    else:
                        search_pattern = os.path.join(log_path, "biostar_device_*.log")
                    
                    matching_files = glob.glob(search_pattern)
                    if matching_files:
                        # 파일명에서 날짜 추출하여 최신 파일 선택
                        latest_file = max(matching_files, key=lambda f: self._extract_date_from_filename(f))
                        log_files[log_type] = latest_file
                else:
                    # 고정 파일명의 경우 그대로 시도
                    log_files[log_type] = file_path
        
        return log_files
    
    def _extract_date_from_filename(self, filepath: str) -> str:
        """파일명에서 날짜를 추출합니다."""
        filename = os.path.basename(filepath)
        # biostar_2025-01-15.log 형태에서 날짜 추출
        import re
        match = re.search(r'(\d{4}-\d{2}-\d{2})', filename)
        return match.group(1) if match else "0000-00-00"
    
    async def _analyze_log_file(self, file_path: str, lines_to_read: int, from_end: bool = True) -> Dict[str, Any]:
        """개별 로그 파일을 분석합니다."""
        try:
            # 파일 크기 확인
            file_size = os.path.getsize(file_path)
            
            # 로그 라인 읽기
            lines = self._read_log_lines(file_path, lines_to_read, from_end)
            
            if not lines:
                return {"error": "로그 파일이 비어있거나 읽을 수 없습니다"}
            
            # 로그 분석
            analysis = {
                "file_info": {
                    "path": file_path,
                    "size_bytes": file_size,
                    "size_mb": round(file_size / (1024 * 1024), 2),
                    "lines_analyzed": len(lines)
                },
                "log_analysis": self._analyze_log_content(lines, file_path)
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing log file: {file_path}, {e}")
            return {"error": f"Log file analysis failed: {str(e)}"}
    
    def _read_log_lines(self, file_path: str, lines_to_read: int, from_end: bool = True) -> List[str]:
        """로그 파일에서 지정된 수의 라인을 읽습니다."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                if from_end:
                    # 파일 끝에서부터 읽기
                    lines = []
                    # 파일을 뒤에서부터 읽기 위해 seek 사용
                    f.seek(0, 2)  # 파일 끝으로 이동
                    file_size = f.tell()
                    
                    # 뒤에서부터 읽기
                    buffer_size = min(8192, file_size)
                    position = file_size
                    buffer = ""
                    
                    while len(lines) < lines_to_read and position > 0:
                        # 읽을 위치 계산
                        read_size = min(buffer_size, position)
                        position -= read_size
                        
                        # 해당 위치로 이동하여 읽기
                        f.seek(position)
                        chunk = f.read(read_size)
                        buffer = chunk + buffer
                        
                        # 라인 단위로 분리
                        while '\n' in buffer and len(lines) < lines_to_read:
                            line, buffer = buffer.rsplit('\n', 1)
                            if line.strip():
                                lines.insert(0, line.strip())
                    
                    # 마지막 남은 버퍼 처리
                    if buffer.strip() and len(lines) < lines_to_read:
                        lines.insert(0, buffer.strip())
                        
                else:
                    # 파일 시작에서부터 읽기
                    lines = []
                    for i, line in enumerate(f):
                        if i >= lines_to_read:
                            break
                        if line.strip():
                            lines.append(line.strip())
            
            return lines
            
        except Exception as e:
            logger.error(f"Failed to read log file: {file_path}, {e}")
            return []
    
    def _analyze_log_content(self, lines: List[str], file_path: str) -> Dict[str, Any]:
        """로그 내용을 분석합니다."""
        analysis = {
            "total_lines": len(lines),
            "error_count": 0,
            "warning_count": 0,
            "info_count": 0,
            "recent_errors": [],
            "recent_warnings": [],
            "key_events": [],
            "server_status": "unknown"
        }
        
        # 멀티라인 오류 처리를 위한 버퍼
        current_error = []
        in_error_block = False
        
        # 로그 레벨별 분석
        for i, line in enumerate(lines):
            line_lower = line.lower()
            
            # 오류 블록 시작 감지
            if '[error]' in line_lower or 'exception' in line_lower:
                if current_error and in_error_block:
                    # 이전 오류 저장
                    error_text = '\n'.join(current_error)
                    parsed_error = self._parse_log_line(error_text, file_path)
                    if len(analysis["recent_errors"]) < 5:
                        analysis["recent_errors"].append(parsed_error)
                
                # 새 오류 블록 시작
                current_error = [line]
                in_error_block = True
                analysis["error_count"] += 1
                
            elif in_error_block:
                # 오류 블록 계속 (스택 트레이스 등)
                if line.strip().startswith(('at ', 'Caused by:', 'Suppressed:', '*__checkpoint')):
                    current_error.append(line)
                elif line.strip() == '':
                    # 빈 줄로 오류 블록 종료
                    error_text = '\n'.join(current_error)
                    parsed_error = self._parse_log_line(error_text, file_path)
                    if len(analysis["recent_errors"]) < 5:
                        analysis["recent_errors"].append(parsed_error)
                    current_error = []
                    in_error_block = False
                else:
                    # 새로운 로그 라인 시작
                    error_text = '\n'.join(current_error)
                    parsed_error = self._parse_log_line(error_text, file_path)
                    if len(analysis["recent_errors"]) < 5:
                        analysis["recent_errors"].append(parsed_error)
                    current_error = []
                    in_error_block = False
                    
                    # 현재 라인 처리
                    if '[warn]' in line_lower or 'warning' in line_lower:
                        analysis["warning_count"] += 1
                        parsed_warning = self._parse_log_line(line, file_path)
                        if len(analysis["recent_warnings"]) < 5:
                            analysis["recent_warnings"].append(parsed_warning)
                    elif any(keyword in line_lower for keyword in ['info', 'started', 'connected']):
                        analysis["info_count"] += 1
            
            elif '[warn]' in line_lower or 'warning' in line_lower:
                analysis["warning_count"] += 1
                parsed_warning = self._parse_log_line(line, file_path)
                if len(analysis["recent_warnings"]) < 5:
                    analysis["recent_warnings"].append(parsed_warning)
                    
            elif any(keyword in line_lower for keyword in ['info', 'started', 'connected']):
                analysis["info_count"] += 1
            
            # 주요 이벤트 추출
            if any(keyword in line_lower for keyword in [
                'started', 'stopped', 'connected', 'disconnected', 
                'login', 'logout', 'access', 'door', 'device'
            ]):
                if len(analysis["key_events"]) < 10:
                    parsed_event = self._parse_log_line(line, file_path)
                    analysis["key_events"].append(parsed_event)
        
        # 마지막 오류 블록 처리
        if current_error and in_error_block:
            error_text = '\n'.join(current_error)
            parsed_error = self._parse_log_line(error_text, file_path)
            if len(analysis["recent_errors"]) < 5:
                analysis["recent_errors"].append(parsed_error)
        
        # 서버 상태 판단
        if analysis["error_count"] == 0 and analysis["warning_count"] < 5:
            analysis["server_status"] = "healthy"
        elif analysis["error_count"] < 5:
            analysis["server_status"] = "warning"
        else:
            analysis["server_status"] = "error"
        
        return analysis
    
    def _parse_log_line(self, log_text: str, file_path: str) -> Dict[str, Any]:
        """로그 라인을 파싱하여 구조화된 정보를 추출합니다."""
        import re
        
        parsed = {
            "raw_message": log_text[:500] if len(log_text) > 500 else log_text,
            "timestamp": None,
            "level": None,
            "category": None,
            "thread": None,
            "source_file": None,
            "function": None,
            "message": None,
            "error_type": None,
            "device_id": None,
            "task_name": None,
            "error_code": None,
            "location": None,
            "port": None,
            "endpoint": None,
            "keywords": []
        }
        
        first_line = log_text.split('\n')[0]
        
        # BioStar X 로그 형식: 25/10/29 12:50:20.319445 I <SYS> [0x00005d94] [DevicePacketParser.c:3954(...)]
        biostar_match = re.match(r'(\d{2}/\d{2}/\d{2}\s+[\d:.]+)\s+([IWE])\s+<(\w+)>\s+\[([^\]]+)\]\s+\[([^\]]+)\](?:\s+-\s+(.+))?', first_line)
        
        if biostar_match:
            # BioStar X 형식
            parsed["timestamp"] = biostar_match.group(1)
            level_code = biostar_match.group(2)
            parsed["level"] = {"I": "INFO", "W": "WARN", "E": "ERROR"}.get(level_code, level_code)
            parsed["category"] = biostar_match.group(3)
            parsed["thread"] = biostar_match.group(4)
            
            # 소스 파일과 함수 파싱: DevicePacketParser.c:3954(DevicePacketParser::parseDevic)
            source_info = biostar_match.group(5)
            source_match = re.match(r'([^:]+):(\d+)\(([^)]+)\)', source_info)
            if source_match:
                parsed["source_file"] = f"{source_match.group(1)}:{source_match.group(2)}"
                parsed["function"] = source_match.group(3)
            
            # 메시지
            if biostar_match.group(6):
                parsed["message"] = biostar_match.group(6).strip()
        else:
            # Spring Gateway 형식: [ERROR] 10-29 10:54:38.921] [reactor-http-nio-2]
            gateway_match = re.search(r'\[(?:ERROR|WARN|INFO)\]\s+([\d-]+\s+[\d:.]+)\]\s+\[([^\]]+)\]\s+-\s+([^:]+):(\d+)\s+:\w+\s+-\s+(.+)', first_line)
            if gateway_match:
                parsed["timestamp"] = gateway_match.group(1)
                parsed["thread"] = gateway_match.group(2)
                parsed["source_file"] = f"{gateway_match.group(3)}:{gateway_match.group(4)}"
                parsed["message"] = gateway_match.group(5).strip()
                
                level_match = re.search(r'\[(ERROR|WARN|INFO)\]', first_line)
                if level_match:
                    parsed["level"] = level_match.group(1)
        
        # 장치 ID 추출: device=547840779, id:547840779, DEVID IN (547840779)
        device_patterns = [
            r'device[=:](\d+)',
            r'id[=:](\d+)',
            r'DEVID\s+IN\s+\((\d+)\)'
        ]
        for pattern in device_patterns:
            device_match = re.search(pattern, log_text)
            if device_match:
                parsed["device_id"] = device_match.group(1)
                break
        
        # 태스크 이름 추출: TASK_GET_CONFIG, TASK_RESTORE_CONNECTION
        task_match = re.search(r'TASK_([A-Z_]+)', log_text)
        if task_match:
            parsed["task_name"] = f"TASK_{task_match.group(1)}"
        
        # 오류 코드 추출: error code: 2012
        error_code_match = re.search(r'error\s+code:\s*(\d+)', log_text, re.IGNORECASE)
        if error_code_match:
            parsed["error_code"] = error_code_match.group(1)
        
        # 오류 유형 분석
        error_types = {
            'Connection refused': 'Connection refused',
            'ConnectException': 'Connection Exception',
            'WebSocket': 'WebSocket error',
            'License': 'License error',
            'Database': 'Database error',
            'ZooKeeper': 'ZooKeeper error',
            'allocate.*failed': 'Memory allocation error',
            'no devcaps': 'Device capability error',
            'Couldn\'t save': 'Save operation failed',
            'request not found': 'Request not found',
            'Cannot execute': 'Command execution failed',
            'Failed to initialize': 'Initialization failed',
            'tcp failed': 'TCP connection failed'
        }
        
        for pattern, error_type in error_types.items():
            if re.search(pattern, log_text, re.IGNORECASE):
                parsed["error_type"] = error_type
                break
        
        # IP:Port 추출
        location_match = re.search(r'(\d+\.\d+\.\d+\.\d+):(\d+)', log_text)
        if location_match:
            parsed["location"] = location_match.group(1)
            parsed["port"] = location_match.group(2)
        
        # HTTP 엔드포인트 추출
        endpoint_match = re.search(r'HTTP\s+\w+\s+"([^"]+)"', log_text)
        if endpoint_match:
            parsed["endpoint"] = endpoint_match.group(1)
        
        # 키워드 추출
        keywords = []
        keyword_patterns = [
            'Connection refused', 'getsockopt', 'WebSocket', 'session',
            'License', 'validation', 'failed', 'expired', 'timeout',
            'authentication', 'login', 'device', 'door', 'access',
            'database', 'memory', 'exception', 'error', 'ZooKeeper',
            'allocate', 'devcaps', 'tcp', 'upload', 'monitoring',
            'TASK_', 'retry', 'initialize', 'execute'
        ]
        for keyword in keyword_patterns:
            if keyword.lower() in log_text.lower():
                if keyword == 'TASK_' and parsed["task_name"]:
                    keywords.append(parsed["task_name"])
                elif keyword != 'TASK_':
                    keywords.append(keyword)
        
        # 중복 제거
        parsed["keywords"] = list(set(keywords))
        
        return parsed
    
    def _generate_log_summary(self, analysis_results: Dict[str, Any], today: datetime) -> Dict[str, Any]:
        """로그 분석 결과를 종합하여 요약을 생성합니다."""
        summary = {
            "analysis_timestamp": today.strftime("%Y-%m-%d %H:%M:%S"),
            "overall_status": "unknown",
            "total_errors": 0,
            "total_warnings": 0,
            "server_components": {},
            "critical_issues": [],
            "error_details": [],
            "warning_details": [],
            "recommendations": []
        }
        
        # 각 컴포넌트별 상태 분석
        for component, result in analysis_results.items():
            if "error" in result:
                summary["server_components"][component] = {
                    "status": "error",
                    "message": result["error"]
                }
                summary["critical_issues"].append(f"{component}: {result['error']}")
            else:
                log_analysis = result.get("log_analysis", {})
                status = log_analysis.get("server_status", "unknown")
                error_count = log_analysis.get("error_count", 0)
                warning_count = log_analysis.get("warning_count", 0)
                recent_errors = log_analysis.get("recent_errors", [])
                recent_warnings = log_analysis.get("recent_warnings", [])
                
                summary["server_components"][component] = {
                    "status": status,
                    "errors": error_count,
                    "warnings": warning_count,
                    "recent_errors": recent_errors,
                    "recent_warnings": recent_warnings
                }
                
                summary["total_errors"] += error_count
                summary["total_warnings"] += warning_count
                
                # 실제 오류 메시지를 error_details에 추가
                for error_data in recent_errors:
                    # error_data는 이제 딕셔너리 (parsed log)
                    if isinstance(error_data, dict):
                        error_msg = error_data.get("raw_message", "")
                        summary["error_details"].append({
                            "component": component,
                            "parsed_data": error_data,
                            "analysis": self._analyze_error_message(error_msg)
                        })
                    else:
                        # 이전 형식 호환성
                        summary["error_details"].append({
                            "component": component,
                            "message": error_data,
                            "analysis": self._analyze_error_message(error_data)
                        })
                
                # 실제 경고 메시지를 warning_details에 추가
                for warning_data in recent_warnings:
                    if isinstance(warning_data, dict):
                        summary["warning_details"].append({
                            "component": component,
                            "parsed_data": warning_data
                        })
                    else:
                        # 이전 형식 호환성
                        summary["warning_details"].append({
                            "component": component,
                            "message": warning_data
                        })
                
                # 심각한 오류가 있는 경우
                if error_count > 10:
                    summary["critical_issues"].append(f"{component}: {error_count}개의 오류 발생")
        
        # 전체 상태 판단
        if summary["total_errors"] == 0 and summary["total_warnings"] < 10:
            summary["overall_status"] = "healthy"
        elif summary["total_errors"] < 5:
            summary["overall_status"] = "warning"
        else:
            summary["overall_status"] = "critical"
        
        # 권장사항 생성
        if summary["overall_status"] == "critical":
            summary["recommendations"].append("서버 상태가 심각합니다. 즉시 점검이 필요합니다.")
        elif summary["overall_status"] == "warning":
            summary["recommendations"].append("일부 경고가 있습니다. 모니터링을 강화하세요.")
        else:
            summary["recommendations"].append("서버 상태가 양호합니다.")
        
        if summary["total_errors"] > 0:
            summary["recommendations"].append("오류 로그를 상세히 검토하여 원인을 파악하세요.")
        
        return summary
    
    def _analyze_error_message(self, error_msg: str) -> Dict[str, str]:
        """오류 메시지를 분석하여 원인과 해결 방법을 제안합니다."""
        error_lower = error_msg.lower()
        
        # 일반적인 오류 패턴 분석
        if "license" in error_lower or "라이센스" in error_lower:
            return {
                "type": "라이센스 오류",
                "cause": "BioStar X 라이센스가 만료되었거나 유효하지 않습니다",
                "solution": "1. 라이센스 파일 확인\n2. 라이센스 갱신 필요\n3. 라이센스 서버 연결 상태 확인"
            }
        elif "connection" in error_lower or "연결" in error_lower:
            return {
                "type": "연결 오류",
                "cause": "네트워크 연결 또는 서비스 간 통신 문제",
                "solution": "1. 네트워크 연결 상태 확인\n2. 방화벽 설정 확인\n3. 서비스 재시작 시도"
            }
        elif "database" in error_lower or "db" in error_lower or "데이터베이스" in error_lower:
            return {
                "type": "데이터베이스 오류",
                "cause": "데이터베이스 연결 또는 쿼리 실행 실패",
                "solution": "1. 데이터베이스 서비스 상태 확인\n2. 연결 문자열 확인\n3. 데이터베이스 로그 확인"
            }
        elif "websocket" in error_lower:
            return {
                "type": "WebSocket 오류",
                "cause": "실시간 통신 연결 문제",
                "solution": "1. 클라이언트 재연결 시도\n2. 서버 재시작 고려\n3. 네트워크 안정성 확인"
            }
        elif "memory" in error_lower or "메모리" in error_lower:
            return {
                "type": "메모리 오류",
                "cause": "시스템 메모리 부족 또는 메모리 누수",
                "solution": "1. 시스템 메모리 사용량 확인\n2. 불필요한 프로세스 종료\n3. 서버 재시작 고려"
            }
        elif "timeout" in error_lower or "시간초과" in error_lower:
            return {
                "type": "시간 초과 오류",
                "cause": "요청 처리 시간이 너무 오래 걸림",
                "solution": "1. 네트워크 지연 확인\n2. 서버 성능 확인\n3. 타임아웃 설정 조정 고려"
            }
        elif "authentication" in error_lower or "인증" in error_lower or "login" in error_lower:
            return {
                "type": "인증 오류",
                "cause": "사용자 인증 실패 또는 세션 만료",
                "solution": "1. 사용자 계정 확인\n2. 비밀번호 재설정\n3. 세션 타임아웃 설정 확인"
            }
        elif "device" in error_lower or "장치" in error_lower:
            return {
                "type": "장치 오류",
                "cause": "출입 제어 장치와의 통신 문제",
                "solution": "1. 장치 연결 상태 확인\n2. 장치 전원 확인\n3. 네트워크 케이블 확인"
            }
        elif "service" in error_lower or "서비스" in error_lower:
            return {
                "type": "서비스 오류",
                "cause": "BioStar 서비스 시작 또는 실행 실패",
                "solution": "1. 서비스 상태 확인\n2. 서비스 재시작\n3. 이벤트 로그 확인"
            }
        elif "configuration" in error_lower or "config" in error_lower or "설정" in error_lower:
            return {
                "type": "설정 오류",
                "cause": "잘못된 설정 또는 설정 파일 손상",
                "solution": "1. 설정 파일 확인\n2. 기본 설정으로 복원\n3. 설정 백업 복구"
            }
        else:
            return {
                "type": "일반 오류",
                "cause": "상세 분석 필요",
                "solution": "1. 전체 로그 메시지 확인\n2. 관련 문서 참조\n3. 기술 지원팀 문의"
            }
    
    async def get_system_resources(self, include_all_processes: bool = False) -> List[TextContent]:
        """시스템 리소스 사용량을 분석합니다."""
        try:
            # 시스템 정보 수집
            system_info = self._get_system_info()
            
            # BioStar 관련 프로세스 찾기
            biostar_processes = self._find_biostar_processes()
            
            # 전체 시스템 리소스 정보
            system_resources = self._get_system_resources()
            
            # 프로세스 정보 (BioStar 관련 또는 전체)
            if include_all_processes:
                all_processes = self._get_all_processes_info()
                process_info = {
                    "biostar_processes": biostar_processes,
                    "all_processes": all_processes
                }
            else:
                process_info = {
                    "biostar_processes": biostar_processes
                }
            
            # 종합 분석
            analysis = self._analyze_system_status(system_info, biostar_processes, system_resources)
            
            return self.success_response(
                {
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "system_info": system_info,
                    "system_resources": system_resources,
                    "process_info": process_info,
                    "analysis": analysis
                },
                "시스템 리소스 분석이 완료되었습니다"
            )
            
        except Exception as e:
            logger.error(f"Error analyzing system resources: {e}", exc_info=True)
            return self.error_response(
                "시스템 리소스 분석 중 오류가 발생했습니다",
                {"error": str(e)}
            )
    
    async def analyze_server_status(
        self, 
        log_path: Optional[str] = None, 
        lines_to_read: int = 50,
        include_system_resources: bool = True
    ) -> List[TextContent]:
        """BioStar X 서버의 종합적인 상태를 분석합니다."""
        try:
            # 로그 분석
            log_analysis = await self.analyze_server_logs(log_path, lines_to_read)
            
            # 시스템 리소스 분석
            system_analysis = None
            if include_system_resources:
                system_analysis = await self.get_system_resources(include_all_processes=False)
            
            # 종합 분석 결과 생성
            combined_analysis = self._combine_analysis_results(log_analysis, system_analysis)
            
            return self.success_response(
                combined_analysis,
                "BioStar X 서버 종합 상태 분석이 완료되었습니다"
            )
            
        except Exception as e:
            logger.error(f"Error analyzing server status: {e}", exc_info=True)
            return self.error_response(
                "서버 상태 분석 중 오류가 발생했습니다",
                {"error": str(e)}
            )
    
    def _get_system_info(self) -> Dict[str, Any]:
        """시스템 기본 정보를 수집합니다."""
        try:
            return {
                "platform": platform.platform(),
                "system": platform.system(),
                "release": platform.release(),
                "version": platform.version(),
                "machine": platform.machine(),
                "processor": platform.processor(),
                "hostname": platform.node(),
                "boot_time": datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
            }
        except Exception as e:
            logger.error(f"Failed to collect system info: {e}")
            return {"error": str(e)}
    
    def _find_biostar_processes(self) -> List[Dict[str, Any]]:
        """BioStar 관련 프로세스를 찾습니다."""
        biostar_processes = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'memory_info', 'cpu_percent', 'status', 'create_time']):
                try:
                    proc_info = proc.info
                    proc_name = proc_info['name'].lower()
                    
                    # BioStar 관련 프로세스 필터링
                    if any(keyword in proc_name for keyword in ['biostar', 'bio', 'star']):
                        memory_mb = round(proc_info['memory_info'].rss / (1024 * 1024), 2)
                        create_time = datetime.fromtimestamp(proc_info['create_time']).strftime("%Y-%m-%d %H:%M:%S")
                        
                        biostar_processes.append({
                            "pid": proc_info['pid'],
                            "name": proc_info['name'],
                            "memory_mb": memory_mb,
                            "cpu_percent": proc_info['cpu_percent'],
                            "status": proc_info['status'],
                            "create_time": create_time,
                            "memory_percent": round(proc.memory_percent(), 2)
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                    
        except Exception as e:
            logger.error(f"Failed to search BioStar processes: {e}")
            
        return biostar_processes
    
    def _get_system_resources(self) -> Dict[str, Any]:
        """시스템 리소스 사용량을 수집합니다."""
        try:
            # CPU 정보
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            cpu_freq = psutil.cpu_freq()
            
            # 메모리 정보
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            # 디스크 정보
            disk = psutil.disk_usage('/')
            
            # 네트워크 정보
            network = psutil.net_io_counters()
            
            return {
                "cpu": {
                    "usage_percent": cpu_percent,
                    "count": cpu_count,
                    "frequency_mhz": round(cpu_freq.current, 2) if cpu_freq else None,
                    "max_frequency_mhz": round(cpu_freq.max, 2) if cpu_freq else None
                },
                "memory": {
                    "total_gb": round(memory.total / (1024**3), 2),
                    "available_gb": round(memory.available / (1024**3), 2),
                    "used_gb": round(memory.used / (1024**3), 2),
                    "usage_percent": memory.percent,
                    "free_gb": round(memory.free / (1024**3), 2)
                },
                "swap": {
                    "total_gb": round(swap.total / (1024**3), 2),
                    "used_gb": round(swap.used / (1024**3), 2),
                    "free_gb": round(swap.free / (1024**3), 2),
                    "usage_percent": swap.percent
                },
                "disk": {
                    "total_gb": round(disk.total / (1024**3), 2),
                    "used_gb": round(disk.used / (1024**3), 2),
                    "free_gb": round(disk.free / (1024**3), 2),
                    "usage_percent": round((disk.used / disk.total) * 100, 2)
                },
                "network": {
                    "bytes_sent_mb": round(network.bytes_sent / (1024**2), 2),
                    "bytes_recv_mb": round(network.bytes_recv / (1024**2), 2),
                    "packets_sent": network.packets_sent,
                    "packets_recv": network.packets_recv
                }
            }
        except Exception as e:
            logger.error(f"Failed to collect system resources: {e}")
            return {"error": str(e)}
    
    def _get_all_processes_info(self) -> List[Dict[str, Any]]:
        """모든 프로세스 정보를 수집합니다 (메모리 사용량 상위 20개)."""
        processes = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'memory_info', 'cpu_percent', 'status']):
                try:
                    proc_info = proc.info
                    memory_mb = round(proc_info['memory_info'].rss / (1024 * 1024), 2)
                    
                    processes.append({
                        "pid": proc_info['pid'],
                        "name": proc_info['name'],
                        "memory_mb": memory_mb,
                        "cpu_percent": proc_info['cpu_percent'],
                        "status": proc_info['status']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
            
            # 메모리 사용량 순으로 정렬하고 상위 20개만 반환
            processes.sort(key=lambda x: x['memory_mb'], reverse=True)
            return processes[:20]
            
        except Exception as e:
            logger.error(f"Failed to collect all process info: {e}")
            return []
    
    def _analyze_system_status(
        self, 
        system_info: Dict[str, Any], 
        biostar_processes: List[Dict[str, Any]], 
        system_resources: Dict[str, Any]
    ) -> Dict[str, Any]:
        """시스템 상태를 종합 분석합니다."""
        analysis = {
            "overall_status": "unknown",
            "biostar_status": "unknown",
            "resource_status": "unknown",
            "recommendations": [],
            "alerts": []
        }
        
        try:
            # BioStar 프로세스 상태 분석
            if not biostar_processes:
                analysis["biostar_status"] = "not_running"
                analysis["alerts"].append("BioStar 관련 프로세스가 실행되지 않고 있습니다")
            else:
                total_biostar_memory = sum(proc['memory_mb'] for proc in biostar_processes)
                if total_biostar_memory > 1000:  # 1GB 이상
                    analysis["biostar_status"] = "high_memory_usage"
                    analysis["alerts"].append(f"BioStar 프로세스들의 메모리 사용량이 높습니다 ({total_biostar_memory:.1f}MB)")
                elif total_biostar_memory < 50:  # 50MB 미만
                    analysis["biostar_status"] = "low_memory_usage"
                    analysis["recommendations"].append("BioStar 프로세스들의 메모리 사용량이 낮습니다. 정상 작동 확인 필요")
                else:
                    analysis["biostar_status"] = "normal"
            
            # 시스템 리소스 상태 분석
            if "error" not in system_resources:
                memory_usage = system_resources.get("memory", {}).get("usage_percent", 0)
                cpu_usage = system_resources.get("cpu", {}).get("usage_percent", 0)
                disk_usage = system_resources.get("disk", {}).get("usage_percent", 0)
                
                if memory_usage > 90:
                    analysis["resource_status"] = "critical"
                    analysis["alerts"].append(f"메모리 사용량이 매우 높습니다 ({memory_usage:.1f}%)")
                elif memory_usage > 80:
                    analysis["resource_status"] = "warning"
                    analysis["alerts"].append(f"메모리 사용량이 높습니다 ({memory_usage:.1f}%)")
                elif cpu_usage > 90:
                    analysis["resource_status"] = "critical"
                    analysis["alerts"].append(f"CPU 사용량이 매우 높습니다 ({cpu_usage:.1f}%)")
                elif disk_usage > 90:
                    analysis["resource_status"] = "critical"
                    analysis["alerts"].append(f"디스크 사용량이 매우 높습니다 ({disk_usage:.1f}%)")
                else:
                    analysis["resource_status"] = "normal"
            
            # 전체 상태 판단
            if analysis["biostar_status"] == "not_running" or analysis["resource_status"] == "critical":
                analysis["overall_status"] = "critical"
            elif analysis["biostar_status"] in ["high_memory_usage", "low_memory_usage"] or analysis["resource_status"] == "warning":
                analysis["overall_status"] = "warning"
            else:
                analysis["overall_status"] = "healthy"
            
            # 권장사항 추가
            if analysis["overall_status"] == "healthy":
                analysis["recommendations"].append("시스템 상태가 양호합니다. 정기적인 모니터링을 계속하세요.")
            
        except Exception as e:
            logger.error(f"Failed to analyze system status: {e}")
            analysis["error"] = str(e)
        
        return analysis
    
    def _combine_analysis_results(
        self, 
        log_analysis: List[TextContent], 
        system_analysis: Optional[List[TextContent]]
    ) -> Dict[str, Any]:
        """로그 분석과 시스템 분석 결과를 결합합니다."""
        combined = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "log_analysis": None,
            "system_analysis": None,
            "combined_status": "unknown",
            "summary": {}
        }
        
        try:
            # 로그 분석 결과 추출
            if log_analysis and len(log_analysis) > 0:
                log_content = log_analysis[0].text
                import json
                log_data = json.loads(log_content)
                combined["log_analysis"] = log_data.get("data", {})
            
            # 시스템 분석 결과 추출
            if system_analysis and len(system_analysis) > 0:
                system_content = system_analysis[0].text
                import json
                system_data = json.loads(system_content)
                combined["system_analysis"] = system_data.get("data", {})
            
            # 종합 상태 판단
            log_status = combined["log_analysis"].get("summary", {}).get("overall_status", "unknown") if combined["log_analysis"] else "unknown"
            system_status = combined["system_analysis"].get("analysis", {}).get("overall_status", "unknown") if combined["system_analysis"] else "unknown"
            
            if log_status == "critical" or system_status == "critical":
                combined["combined_status"] = "critical"
            elif log_status == "warning" or system_status == "warning":
                combined["combined_status"] = "warning"
            elif log_status == "healthy" and system_status == "healthy":
                combined["combined_status"] = "healthy"
            else:
                combined["combined_status"] = "unknown"
            
            # 요약 정보 생성
            combined["summary"] = {
                "log_status": log_status,
                "system_status": system_status,
                "combined_status": combined["combined_status"],
                "biostar_processes_count": len(combined["system_analysis"].get("process_info", {}).get("biostar_processes", [])) if combined["system_analysis"] else 0
            }
            
        except Exception as e:
            logger.error(f"Failed to combine analysis results: {e}")
            combined["error"] = str(e)
        
        return combined
