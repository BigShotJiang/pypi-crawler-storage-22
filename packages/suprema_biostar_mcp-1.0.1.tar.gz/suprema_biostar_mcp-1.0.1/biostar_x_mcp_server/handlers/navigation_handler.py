"""
Navigation Handler
프론트엔드 페이지 이동 정보를 생성
"""
import json
import logging
from typing import Dict, Any, Optional
from .base_handler import BaseHandler

logger = logging.getLogger(__name__)


class NavigationHandler(BaseHandler):
    """Handle navigation requests"""
    
    def __init__(self, session=None):
        """Initialize without session (navigation doesn't need API calls)"""
        self.client_session_id = None
    
    async def navigate_to_page(self, args: dict):
        """
        Generate navigation information for frontend
        
        Args:
            args: {
                "page_type": "user_list" | "user_detail" | "door_list" | "door_detail" | 
                            "device_list" | "device_detail" | "monitoring" | "custom_url",
                "resource_id": "123" (optional, for detail pages),
                "custom_url": "/custom/path" (optional, for custom_url type),
                "action": {
                    "type": "click" | "scroll",
                    "ng_label_key": "common.information"
                } (optional),
                "reason": "Brief explanation" (optional)
            }
        
        Returns:
            Navigation metadata for frontend
        """
        page_type = args.get("page_type")
        resource_id = args.get("resource_id")
        custom_url = args.get("custom_url")
        action = args.get("action")
        reason = args.get("reason", "")
        
        # Build navigation object
        navigation = {
            "enabled": True,
            "page_type": page_type,
            "resource_id": resource_id,
            "custom_url": custom_url,
            "action": action,
            "reason": reason
        }
        
        # Generate user-friendly path
        path = self._generate_path(page_type, resource_id, custom_url)
        
        # Create response message
        message_parts = []
        
        if reason:
            message_parts.append(f" {reason}")
        
        message_parts.append(f" 페이지 이동: {path}")
        
        if action:
            action_type = action.get("type", "")
            if action_type == "click":
                message_parts.append(f"    클릭: {action.get('ng_label_key', '')}")
            elif action_type == "scroll":
                message_parts.append(f"    스크롤: {action.get('ng_label_key', '')}")
        
        message = "\n".join(message_parts)
        
        logger.info(f" Navigation: {page_type} → {path}")
        
        # Return as TextContent with navigation metadata
        return [{
            "type": "text",
            "text": json.dumps({
                "message": message,
                "navigation": navigation,
                "path": path
            }, ensure_ascii=False)
        }]
    
    def _generate_path(self, page_type: str, resource_id: Optional[str] = None, 
                      custom_url: Optional[str] = None) -> str:
        """Generate frontend path from navigation info"""
        
        if page_type == "custom_url" and custom_url:
            return custom_url
        
        path_map = {
            "user_list": "/team",
            "user_detail": f"/team/user/detail/{resource_id}" if resource_id else "/team",
            "door_list": "/settings/door",
            "door_detail": f"/settings/door/detail/{resource_id}" if resource_id else "/settings/door",
            "device_list": "/settings/device",
            "device_detail": f"/settings/device/detail/{resource_id}" if resource_id else "/settings/device",
            "access_control": "/settings/access-control",
            "access_group_list": "/settings/access-control",
            "access_group_detail": f"/settings/access-control/detail/{resource_id}" if resource_id else "/settings/access-control",
            "monitoring": "/arena"
        }
        
        return path_map.get(page_type, "/")

