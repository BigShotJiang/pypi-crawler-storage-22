from typing import Optional, Union, List, Dict, Any
from pydantic import BaseModel, Field, model_validator


# ============================================================================
# Access Group Schemas
# ============================================================================

class GetAccessGroupsInput(BaseModel):
    """Input schema for get-access-groups tool"""
    pass  # No required fields


class GetAccessGroupInput(BaseModel):
    """Input schema for get-access-group tool"""
    group_id: int = Field(..., description="ID of the access group to retrieve")


class CreateAccessGroupInput(BaseModel):
    """Input schema for create-access-group tool"""
    name: str = Field(..., description="Access group name")
    description: Optional[str] = Field(default="", description="Description for the access group")
    user_ids: Optional[List[Union[str, int]]] = Field(None, description="Explicit list of user ids to include. Do NOT auto-select.")
    access_level_ids: Optional[List[Union[str, int]]] = Field(None, description="Existing access level ids to assign to this group.")
    user_group_ids: Optional[List[Union[int, str]]] = Field(None, description="Explicit user group ids to include (validated against GET /api/user_groups)")
    user_group_search_text: Optional[str] = Field(None, description="Substring to search user group name (3-case resolution)")


class UpdateAccessGroupInput(BaseModel):
    """Input schema for update-access-group tool"""
    group_id: int = Field(..., description="ID of the access group to update")
    name: Optional[str] = Field(None, description="New name")
    description: Optional[str] = Field(None, description="New description")

    # Users
    user_ids: Optional[List[Union[str, int]]] = Field(None, description="Final set of user ids (replacement).")
    new_users: Optional[List[Union[str, int]]] = Field(None, description="User ids to add (delta).")
    delete_users: Optional[List[Union[str, int]]] = Field(None, description="User ids to remove (delta).")

    # Access Levels (replacement)
    access_level_ids: Optional[List[Union[str, int]]] = Field(None, description="Replace the group's access_levels with these ids.")

    # User Groups - Replacement
    user_group_ids: Optional[List[Union[int, str]]] = Field(None, description="Replace user_groups with these ids. If [], clears all.")
    user_group_search_text: Optional[str] = Field(None, description="(Legacy) Single-match replacement by name.")

    # User Groups - Delta
    add_user_group_ids: Optional[List[Union[int, str]]] = Field(None, description="Add these user group ids (delta).")
    remove_user_group_ids: Optional[List[Union[int, str]]] = Field(None, description="Remove these user group ids (delta).")
    add_user_group_search_text: Optional[str] = Field(None, description="Add by name (3-case resolution).")
    remove_user_group_search_text: Optional[str] = Field(None, description="Remove by name (3-case resolution).")


class DeleteAccessGroupInput(BaseModel):
    """Input schema for delete-access-group tool"""
    group_id: int = Field(..., description="ID of the access group to delete")


class SearchAccessGroupsInput(BaseModel):
    """Input schema for search-access-groups tool"""
    limit: int = Field(..., description="To limit result by n record(s), 0 to show all")
    order_by: str = Field(..., description="Order by string like 'id:false' or 'name:true'")


# ============================================================================
# Access Level Schemas
# ============================================================================

class GetAccessLevelsInput(BaseModel):
    """Input schema for get-access-levels tool"""
    limit: Optional[int] = Field(default=50, description="Limit number of records (0 to show all)")
    offset: Optional[int] = Field(default=0, description="Offset/skip records")
    order_by: Optional[str] = Field(default="id:false", description="Order by (e.g., 'id:false')")


class GetAccessLevelInput(BaseModel):
    """Input schema for get-access-level tool"""
    level_id: int = Field(..., description="ID of the access level to retrieve")


class AccessLevelItemInput(BaseModel):
    """Input schema for access_level_items array item"""
    doors: List[Union[int, str]] = Field(..., min_length=1, description="Door IDs or names; de-duplicated per item.")


class CreateAccessLevelInput(BaseModel):
    """Input schema for create-access-level tool"""
    name: str = Field(..., description="Unique Access Level name.")
    description: Optional[str] = Field(default="", description="Description for the Access Level.")
    confirm: Optional[bool] = Field(default=True, description="If true, create the Access Level; otherwise preview only. Defaults to True for automatic creation.")
    door_ids: Optional[List[int]] = Field(None, description="🆕 Simple mode: List of door IDs to include (e.g., [177, 178, 179]). Mutually exclusive with access_level_items.")
    door_names: Optional[List[str]] = Field(None, description="🆕 Simple mode: List of door names to include (e.g., ['Main Entrance', 'CEO Office']). Will be resolved to IDs. Mutually exclusive with access_level_items.")
    auto_update_on_exist: Optional[bool] = Field(default=True, description="🆕 If true (default), automatically update if Access Level with same name exists. If false, skip creation and return existing info.")
    access_level_items: Optional[List[AccessLevelItemInput]] = Field(None, min_length=1, description="Advanced mode: Array tying doors (1..n) to the enforced 'Always' schedule (applied internally). Each item must include `doors`. Mutually exclusive with door_ids/door_names.")

    @model_validator(mode="after")
    def validate_door_specification(self):
        """Ensure at least one door specification method is provided"""
        has_door_ids = self.door_ids is not None and len(self.door_ids) > 0
        has_door_names = self.door_names is not None and len(self.door_names) > 0
        has_access_level_items = self.access_level_items is not None and len(self.access_level_items) > 0

        if not (has_door_ids or has_door_names or has_access_level_items):
            raise ValueError("At least one of door_ids, door_names, or access_level_items must be provided")

        # Check mutual exclusivity
        provided = sum([has_door_ids, has_door_names, has_access_level_items])
        if provided > 1:
            raise ValueError("Only one of door_ids, door_names, or access_level_items can be provided")

        return self


class UpdateAccessLevelInput(BaseModel):
    """Input schema for update-access-level tool"""
    level_id: Optional[int] = Field(None, description="ID of the access level to update")
    level_name: Optional[str] = Field(None, description="Exact name of the access level to update")
    search_text: Optional[str] = Field(None, description="Fuzzy search text (name/description contains)")
    name: Optional[str] = Field(None, description="New name (optional)")
    description: Optional[str] = Field(None, description="New description (optional; empty string clears)")
    set_doors: Optional[List[Union[int, str]]] = Field(None, description="Full replacement of door ids (takes precedence over add/remove)")
    add_doors: Optional[List[Union[int, str]]] = Field(None, description="Door ids to add")
    remove_doors: Optional[List[Union[int, str]]] = Field(None, description="Door ids to remove (ignored if not currently assigned)")
    dry_run: Optional[bool] = Field(default=False, description="Preview changes without calling the API")


class DeleteAccessLevelInput(BaseModel):
    """Input schema for delete-access-level tool"""
    level_id: int = Field(..., description="ID of the access level to delete")


class AddAccessLevelToGroupInput(BaseModel):
    """Input schema for add-access-level-to-group tool"""
    access_group_id: int = Field(..., description="Target access group ID")
    access_level_id: Optional[int] = Field(None, description="An access level id to add (single)")
    access_level_ids: Optional[List[Union[int, str]]] = Field(None, description="Access level ids to add (one or many)")

    @model_validator(mode="after")
    def validate_access_level_specification(self):
        """Ensure at least one access level is specified"""
        if self.access_level_id is None and (self.access_level_ids is None or len(self.access_level_ids) == 0):
            raise ValueError("Either access_level_id or access_level_ids must be provided")
        return self


class RemoveAccessLevelFromGroupInput(BaseModel):
    """Input schema for remove-access-level-from-group tool"""
    access_group_id: int = Field(..., description="Target access group ID")
    access_level_id: Optional[int] = Field(None, description="An access level id to remove (single)")
    access_level_ids: Optional[List[Union[int, str]]] = Field(None, description="Access level ids to remove (one or many)")

    @model_validator(mode="after")
    def validate_access_level_specification(self):
        """Ensure at least one access level is specified"""
        if self.access_level_id is None and (self.access_level_ids is None or len(self.access_level_ids) == 0):
            raise ValueError("Either access_level_id or access_level_ids must be provided")
        return self

