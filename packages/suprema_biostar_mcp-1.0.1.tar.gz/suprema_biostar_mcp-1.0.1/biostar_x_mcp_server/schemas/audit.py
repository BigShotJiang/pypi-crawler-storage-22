from typing import Optional, List
from pydantic import BaseModel, Field


# ============================================================================
# Audit Condition Schemas (nested)
# ============================================================================

class AuditConditionInput(BaseModel):
    """Input schema for audit condition item"""
    column: str = Field(..., description="Column to search (e.g., 'datetime', 'user_id', 'target_type')")
    operator: int = Field(..., description="Search operator (0=EQUAL, 1=NOT_EQUAL, 2=CONTAINS, 3=BETWEEN, 5=GREATER, 6=LESS)")
    values: List[str] = Field(..., description="Values to search for")


# ============================================================================
# Audit Search Schemas
# ============================================================================

class AuditSearchInput(BaseModel):
    """Input schema for audit-search tool"""
    conditions: Optional[List[AuditConditionInput]] = Field(None, description="Search conditions for audit trail")
    limit: Optional[int] = Field(default=100, description="Maximum number of results")
    offset: Optional[int] = Field(default=0, description="Offset for pagination")


class AuditSearchUserInput(BaseModel):
    """Input schema for audit-search-user tool"""
    search: Optional[str] = Field(None, description="Search string for user name")
    limit: Optional[int] = Field(default=201, description="Maximum number of results")
    offset: Optional[int] = Field(default=0, description="Offset for pagination")


class AuditSearchOperatorLevelInput(BaseModel):
    """Input schema for audit-search-operator-level tool"""
    search: Optional[str] = Field(None, description="Search string for permission level")
    limit: Optional[int] = Field(default=201, description="Maximum number of results")
    offset: Optional[int] = Field(default=0, description="Offset for pagination")


class AuditSearchIPListInput(BaseModel):
    """Input schema for audit-search-ip-list tool"""
    search: Optional[str] = Field(None, description="Search string for IP address")
    limit: Optional[int] = Field(default=201, description="Maximum number of results")
    offset: Optional[int] = Field(default=0, description="Offset for pagination")


class AuditSearchTargetListInput(BaseModel):
    """Input schema for audit-search-target-list tool"""
    search: Optional[str] = Field(None, description="Search string for target")
    limit: Optional[int] = Field(default=201, description="Maximum number of results")
    offset: Optional[int] = Field(default=0, description="Offset for pagination")


class AuditCSVExportInput(BaseModel):
    """Input schema for audit-csv-export tool"""
    conditions: Optional[List[AuditConditionInput]] = Field(None, description="Filter conditions (use 'DATE' for time).")
    columns: Optional[List[str]] = Field(
        default=["DATE","USRID","PERM","IP","MENU","TARGET","METHOD","CONTENT"],
        description="CSV columns (UPPERCASE per API spec)."
    )
    headers: Optional[List[str]] = Field(
        default=["Datetime","User","Operator Level","IP","Category","Target","Action","Modification"],
        description="CSV header names (same length as columns)."
    )
    offset: Optional[int] = Field(default=0, description="Offset for export pagination.")
    time_offset_minutes: Optional[int] = Field(default=0, description="Timezone offset in minutes (e.g., UTC+8 => 480).")
    start_datetime: Optional[str] = Field(None, description="Convenience: start time (ISO). Builds a DATE condition if 'conditions' omitted.")
    end_datetime: Optional[str] = Field(None, description="Convenience: end time (ISO). Builds a DATE condition if 'conditions' omitted.")
    copy_to_downloads: Optional[bool] = Field(default=True, description="Copy exported CSV to Windows Downloads folder.")
    dest_dir: Optional[str] = Field(None, description="Optional absolute destination directory (overrides Downloads).")
    target_username: Optional[str] = Field(None, description="If provided, copies to C:\\Users\\<name>\\Downloads.")

