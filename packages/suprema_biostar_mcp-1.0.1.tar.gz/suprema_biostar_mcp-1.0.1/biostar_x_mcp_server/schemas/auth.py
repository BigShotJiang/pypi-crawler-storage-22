from typing import Optional
from pydantic import BaseModel, Field


class LoginInput(BaseModel):
    """Input schema for login tool"""
    username: Optional[str] = Field(None, description="Optional: BioStar 2 username (defaults to BIOSTAR_USERNAME from .env)")
    password: Optional[str] = Field(None, description="Optional: BioStar 2 password (defaults to BIOSTAR_PASSWORD from .env)")


class LogoutInput(BaseModel):
    """Input schema for logout tool"""
    pass  # No required fields


class GetSessionInfoInput(BaseModel):
    """Input schema for get-session-info tool"""
    pass  # No required fields


class GetServerPreferencesInput(BaseModel):
    """Input schema for get-server-preferences tool"""
    pass  # No required fields

