from typing import Optional, Union
from pydantic import BaseModel, Field, model_validator


# ============================================================================
# Card Creation Schemas
# ============================================================================

class CreateCardCSNInput(BaseModel):
    """Input schema for create-card-csn tool"""
    card_id: Union[str, int] = Field(..., description="Value shown/read when scanning the card")
    card_type_type: Optional[int] = Field(None, description="Type allocation of the card type; auto-resolved if omitted")
    assign_to_user_id: Optional[Union[str, int]] = Field(None, description="If provided, assign the created card to this user immediately")
    skip_availability_check: Optional[bool] = Field(default=False, description="Skip server-side availability check before create (default: false)")
    dry_run: Optional[bool] = Field(default=False, description="Return the request body without calling the API (default: false)")


class CreateCardWiegandInput(BaseModel):
    """Input schema for create-card-wiegand tool"""
    card_id: Union[str, int] = Field(..., description="Numeric required")
    facility_code: int = Field(..., description="Facility Code (required)")
    card_number: int = Field(..., description="Card Number (required)")
    wiegand_format_id: Optional[int] = Field(None, description="Format id (e.g., 0=26bit/H10301, 1=HID37/H10302)")
    wiegand_format: Optional[str] = Field(None, description="Format alias (e.g., '26bit', 'H10301', 'HID37')")
    display_card_id: Optional[str] = Field(None, description="Override display (must be 'FC-ID', e.g., '12-3456')")
    card_type_type: Optional[int] = None
    assign_to_user_id: Optional[Union[str, int]] = None
    skip_availability_check: Optional[bool] = None
    dry_run: Optional[bool] = None

    @model_validator(mode="after")
    def validate_wiegand_format(self):
        """Ensure either wiegand_format_id or wiegand_format is provided"""
        if self.wiegand_format_id is None and self.wiegand_format is None:
            raise ValueError("Either wiegand_format_id or wiegand_format must be provided")
        return self


class CreateCardSecureCredentialInput(BaseModel):
    """Input schema for create-card-secure-credential tool"""
    card_id: Union[str, int] = Field(..., description="Card ID")
    card_type_type: Optional[int] = None
    assign_to_user_id: Optional[Union[str, int]] = None
    skip_availability_check: Optional[bool] = None
    dry_run: Optional[bool] = None


class CreateCardAccessOnCardInput(BaseModel):
    """Input schema for create-card-access-on-card tool"""
    card_id: Union[str, int] = Field(..., description="Card ID")
    card_type_type: Optional[int] = None
    assign_to_user_id: Optional[Union[str, int]] = None
    skip_availability_check: Optional[bool] = None
    dry_run: Optional[bool] = None


class CreateCardMobileCSNInput(BaseModel):
    """Input schema for create-card-mobile-csn tool"""
    card_id: Union[str, int] = Field(..., description="Card ID")
    card_type_type: Optional[int] = None
    assign_to_user_id: Optional[Union[str, int]] = None
    isUserPhoto: Optional[bool] = None
    isDepartment: Optional[bool] = None
    isTitle: Optional[bool] = None
    start_datetime: Optional[str] = None
    expiry_datetime: Optional[str] = None
    display_card_id: Optional[str] = None
    skip_availability_check: Optional[bool] = None
    dry_run: Optional[bool] = None


class CreateCardWiegandMobileInput(BaseModel):
    """Input schema for create-card-wiegand-mobile tool"""
    card_id: Union[str, int] = Field(..., description="Card ID")
    facility_code: int = Field(..., description="Facility Code (required)")
    card_number: int = Field(..., description="Card Number (required)")
    wiegand_format_id: Optional[int] = Field(None, description="Format id")
    wiegand_format: Optional[str] = Field(None, description="Format alias")
    display_card_id: Optional[str] = None
    card_type_type: Optional[int] = None
    assign_to_user_id: Optional[Union[str, int]] = None
    skip_availability_check: Optional[bool] = None
    dry_run: Optional[bool] = None

    @model_validator(mode="after")
    def validate_wiegand_format(self):
        """Ensure either wiegand_format_id or wiegand_format is provided"""
        if self.wiegand_format_id is None and self.wiegand_format is None:
            raise ValueError("Either wiegand_format_id or wiegand_format must be provided")
        return self


class CreateCardQRBarcodeInput(BaseModel):
    """Input schema for create-card-qr-barcode tool"""
    card_id: Union[str, int] = Field(..., description="Card ID")
    card_type_type: Optional[int] = None
    assign_to_user_id: Optional[Union[str, int]] = None
    skip_availability_check: Optional[bool] = None
    dry_run: Optional[bool] = None


class CreateCardBioStar2QRInput(BaseModel):
    """Input schema for create-card-biostar2-qr tool"""
    card_id: Union[str, int] = Field(..., description="Card ID")
    card_type_type: Optional[int] = None
    assign_to_user_id: Optional[Union[str, int]] = None
    skip_availability_check: Optional[bool] = None
    dry_run: Optional[bool] = None


# ============================================================================
# Supporting Tool Schemas
# ============================================================================

class GetCardTypesInput(BaseModel):
    """Input schema for get-card-types tool"""
    pass  # No required fields


class CheckCardAvailabilityInput(BaseModel):
    """Input schema for check-card-availability tool"""
    card_id: Union[str, int] = Field(..., description="Card ID to check")


class GetWiegandFormatPresetsInput(BaseModel):
    """Input schema for get-wiegand-format-presets tool"""
    pass  # No required fields

