from typing import Optional, Union, List
from pydantic import BaseModel, Field, model_validator


# ============================================================================
# Door Schemas
# ============================================================================

class GetDoorsInput(BaseModel):
    """Input schema for get-doors tool"""
    limit: Optional[int] = Field(None, description="Number of records (0 = all). Default: 0.")
    order_by: Optional[str] = Field(None, description="Sort order, e.g., 'id:true' (asc) or 'id:false' (desc).")
    ids: Optional[List[int]] = Field(None, description="Filter by specific door IDs.")
    name: Optional[str] = Field(None, description="Exact door name match.")
    name_contains: Optional[str] = Field(None, description="Case-insensitive substring match for door name.")
    group_id: Optional[int] = Field(None, description="Filter by door group ID.")
    group_name: Optional[str] = Field(None, description="Case-insensitive substring match for door group name.")
    status: Optional[str] = Field(None, description="Filter by status value (as returned by API), e.g., '0'.")
    include_raw: Optional[bool] = Field(default=False, description="Attach raw API row for each door (debugging). Default: false.")
    minimal: Optional[bool] = Field(default=False, description="Return only id and name (for access level creation). Reduces response size from 13KB to <1KB. Default: false.")


class GetDoorInput(BaseModel):
    """Input schema for get-door tool"""
    door_id: Optional[int] = Field(None, description="ID of the door to retrieve. If provided, the tool skips search and fetches details.")
    search_text: Optional[str] = Field(None, description="Free-text query for door search (POST /api/v2/doors/search).")
    door_group_id: Optional[int] = Field(None, description="Filter by door group ID in search (POST /api/v2/doors/search).")
    limit: Optional[int] = Field(None, description="Max results for search (default: 50).")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure at least one identifier is provided"""
        if not any([self.door_id, self.search_text, self.door_group_id]):
            raise ValueError("At least one of door_id, search_text, or door_group_id must be provided")
        return self


class CreateDoorInput(BaseModel):
    """Input schema for create-door tool"""
    name: str = Field(..., description="Door name")
    entry_device_id: int = Field(..., description="Device id to control the lock (1:1 mapping enforced).")
    exit_device_id: int = Field(..., description="Exit device id")
    exit_input_index: int = Field(..., description="Exit input index")
    exit_input_type: int = Field(..., description="1=NC, 0=NO")
    sensor_device_id: int = Field(..., description="Sensor device id")
    sensor_input_index: int = Field(..., description="Sensor input index")
    sensor_input_type: int = Field(..., description="1=NC, 0=NO")
    apb_use_door_sensor: int = Field(..., description="APB use door sensor")
    confirm: Optional[bool] = Field(default=False, description="If true, actually create the door. If false, return a preview.")
    default_group_id: Optional[int] = Field(default=1, description="Fallback group id when door_group_id is not provided.")
    description: Optional[str] = Field(None, description="Door description")
    door_group_id: Optional[int] = Field(None, description="Optional group id at creation time. If omitted, default_group_id is used.")
    open_timeout: Optional[int] = Field(default=10, description="Open timeout")
    open_duration: Optional[int] = Field(default=5, description="Open duration")
    open_once: Optional[bool] = Field(default=True, description="Open once")
    unconditional_lock: Optional[bool] = Field(default=True, description="Unconditional lock")
    relay_index: Optional[int] = Field(None, description="Relay index on the entry device. If omitted, the tool returns relay list and exits.")


class UpdateDoorInput(BaseModel):
    """Input schema for update-door tool"""
    door_id: int = Field(..., description="ID of the door to update")
    name: Optional[str] = Field(None, description="New name for the door")
    open_duration: Optional[int] = Field(None, description="Door open duration in seconds")
    open_timeout: Optional[int] = Field(None, description="Door open timeout in seconds")
    dual_auth_required: Optional[bool] = Field(None, description="Whether dual authentication is required")


class DeleteDoorInput(BaseModel):
    """Input schema for delete-door tool"""
    door_id: int = Field(..., description="ID of the door to delete")


class ControlDoorInput(BaseModel):
    """Input schema for control-door tool"""
    action: str = Field(..., description="Action to perform. 'release' clears manual lock/unlock.", pattern="^(open|release|lock|unlock)$")
    door_ids: Optional[List[Union[int, str]]] = Field(None, description="Door IDs to control (validated against GET /api/doors).")
    door_names: Optional[List[str]] = Field(None, description="Door names to control (EXACT, case-sensitive). No autocorrect, no fuzzy.")


class GetDoorsStatusInput(BaseModel):
    """Input schema for get-doors-status tool"""
    monitoring_permission: Optional[bool] = Field(default=True, description="Pass-through flag for the status API. Default: true.")
    include_enrichment: Optional[bool] = Field(default=True, description="If true, joins names/groups from GET /api/doors and enables group/name filters. Default: true.")
    include_device_response: Optional[bool] = Field(default=True, description="Include normalized DeviceResponse with error summary. Default: true.")
    include_raw: Optional[bool] = Field(default=False, description="Attach raw status row for debugging. Default: false.")
    door_ids: Optional[List[int]] = Field(None, description="Filter to specific door IDs.")
    is_open: Optional[bool] = Field(None, description="Filter by open state.")
    is_unlocked: Optional[bool] = Field(None, description="Filter by unlocked state.")
    has_alarm: Optional[bool] = Field(None, description="Filter by alarm state.")
    status_in: Optional[List[str]] = Field(None, description="Filter by raw status code values (as strings).")
    group_id: Optional[int] = Field(None, description="Filter by door group ID (requires include_enrichment=true).")
    group_name: Optional[str] = Field(None, description="Substring match for group name (requires include_enrichment=true).")
    name_contains: Optional[str] = Field(None, description="Substring match for door name (requires include_enrichment=true).")
    sort_by: Optional[str] = Field(default="door_id", description="Client-side sort key. Default: 'door_id'.")
    sort_desc: Optional[bool] = Field(default=False, description="Sort descending when true. Default: false.")


# ============================================================================
# Door Group Schemas
# ============================================================================

class GetDoorGroupsInput(BaseModel):
    """Input schema for get-door-groups tool"""
    include_hierarchy: Optional[bool] = Field(default=True, description="Enrich with /api/v2/door_groups/only_permission_item/search (depth/parent/children/path). Default: true")
    include_doors_scan: Optional[bool] = Field(default=True, description="Enrich with /api/doors to fill door_ids and door_count when absent. Default: true")


class GetDoorGroupInput(BaseModel):
    """Input schema for get-door-group tool"""
    group_id: Optional[Union[int, str]] = Field(None, description="ID of the door group to retrieve")
    group_name: Optional[str] = Field(None, description="Name of the door group to resolve (supports exact/iexact/icontains via name_match_mode)")
    name_match_mode: Optional[str] = Field(default="auto", description="Name matching strategy when group_name is provided")
    include_hierarchy: Optional[bool] = Field(default=True, description="Include depth/parent/children/path if available")
    include_doors: Optional[bool] = Field(default=True, description="Include door_ids (scan /api/doors if missing)")
    include_doors_detail: Optional[bool] = Field(default=False, description="Also include brief door objects (id, name, description, group)")
    include_raw: Optional[bool] = Field(default=False, description="Attach raw DoorGroup payload")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure at least one identifier is provided"""
        if not any([self.group_id, self.group_name]):
            raise ValueError("Either group_id or group_name must be provided")
        return self


class CreateDoorGroupInput(BaseModel):
    """Input schema for create-door-group tool"""
    name: str = Field(..., description="Name of the door group (e.g., 'Ground Floor', '1st Floor', '2nd Floor')")
    parent_id: Optional[int] = Field(default=1, description="Parent door group ID (default: 1 for root group)")
    depth: Optional[int] = Field(default=1, ge=1, le=8, description="Depth level of the door group (1-8, default: 1)")


class UpdateDoorGroupInput(BaseModel):
    """Input schema for update-door-group tool"""
    group_id: int = Field(..., description="ID of the door group to update")
    name: Optional[str] = Field(None, description="New name for the door group")
    parent_id: Optional[int] = Field(None, description="New parent door group ID")


class DeleteDoorGroupInput(BaseModel):
    """Input schema for delete-door-group tool"""
    group_id: int = Field(..., description="ID of the door group to delete")


class AddDoorsToGroupInput(BaseModel):
    """Input schema for add-doors-to-group tool"""
    group_id: Optional[int] = Field(None, description="Target door group ID")
    group_name: Optional[str] = Field(None, description="Target door group name (used when group_id is not provided)")
    door_ids: Optional[List[int]] = Field(None, description="List of door IDs to assign")
    door_names: Optional[List[str]] = Field(None, description="List of door names to assign (exact match)")
    force: Optional[bool] = Field(default=False, description="Overwrite an existing single-group assignment if different.")


class RemoveDoorsFromGroupInput(BaseModel):
    """Input schema for remove-doors-from-group tool"""
    door_ids: Optional[List[int]] = Field(None, description="Door IDs")
    door_names: Optional[List[str]] = Field(None, description="Door names")
    group_id: Optional[int] = Field(None, description="Remove from this group id")
    group_name: Optional[str] = Field(None, description="Or remove from this group name")
    fallback_mode: Optional[str] = Field(default="auto", description="What to do if removal would leave no group")
    fallback_group_id: Optional[int] = Field(None, description="Required when fallback_mode='assign'")


class UpdateDoorDescriptionInput(BaseModel):
    """Input schema for update-door-description tool"""
    door_id: int = Field(..., description="ID of the door to update")
    description: str = Field(..., description="New description to set. Pass an empty string to clear.")


class SetDoorAutoModeInput(BaseModel):
    """Input schema for set-door-auto-mode tool"""
    door_id: Optional[int] = Field(None, description="Door ID")
    door_name: Optional[str] = Field(None, description="Exact door name (alternative to door_id)")
    enable: Optional[bool] = Field(None, description="true to enable, false to disable")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure door identifier and enable are provided"""
        if not any([self.door_id, self.door_name]):
            raise ValueError("Either door_id or door_name must be provided")
        if self.enable is None:
            raise ValueError("enable must be provided")
        return self


class SetDoorRelockOnCloseInput(BaseModel):
    """Input schema for set-door-relock-on-close tool"""
    door_id: Optional[int] = Field(None, description="Door ID")
    door_name: Optional[str] = Field(None, description="Exact door name (alternative to door_id)")
    enable: Optional[bool] = Field(None, description="true to enable, false to disable")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure door identifier and enable are provided"""
        if not any([self.door_id, self.door_name]):
            raise ValueError("Either door_id or door_name must be provided")
        if self.enable is None:
            raise ValueError("enable must be provided")
        return self


class SetDoorOpenDurationInput(BaseModel):
    """Input schema for set-door-open-duration tool"""
    door_id: Optional[int] = Field(None, description="ID of the door to update")
    door_name: Optional[str] = Field(None, description="Exact door name (alternative to door_id)")
    seconds: Optional[int] = Field(None, ge=1, le=900, description="New open duration in seconds (sent as string). Range: 1–900 (inclusive).")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure door identifier and seconds are provided"""
        if not any([self.door_id, self.door_name]):
            raise ValueError("Either door_id or door_name must be provided")
        if self.seconds is None:
            raise ValueError("seconds must be provided")
        return self


class SetDoorTimedAPBInput(BaseModel):
    """Input schema for set-door-timed-apb tool"""
    door_id: Optional[int] = Field(None, description="Door ID (optional). Either door_id or door_name is required.")
    door_name: Optional[str] = Field(None, description="Exact door name (optional). Either door_id or door_name is required.")
    mode: Optional[Union[str, int]] = Field(None, description="APB mode: off | entry | exit (also accepts 0/1/2).")
    reset_time: Optional[int] = Field(None, ge=0, le=60, description="APB reset time in minutes. 0..60 inclusive. Required when mode != off.")
    bypass_group_ids: Optional[List[int]] = Field(None, description="Optional: Access Group IDs for timed APB bypass. If omitted, preserves current.")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure door identifier and mode are provided"""
        if not any([self.door_id, self.door_name]):
            raise ValueError("Either door_id or door_name must be provided")
        if self.mode is None:
            raise ValueError("mode must be provided")
        return self


class SetDoorClassicAPBInput(BaseModel):
    """Input schema for set-door-classic-apb tool"""
    door_id: Optional[int] = Field(None, description="Door ID (optional). Either door_id or door_name is required.")
    door_name: Optional[str] = Field(None, description="Exact door name (optional). Either door_id or door_name is required.")
    apb_type: Optional[Union[str, int]] = Field(None, description="APB type: none | soft | hard (also accepts 0/1/2).")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure door identifier and apb_type are provided"""
        if not any([self.door_id, self.door_name]):
            raise ValueError("Either door_id or door_name must be provided")
        if self.apb_type is None:
            raise ValueError("apb_type must be provided")
        return self


class SetDoorIOInput(BaseModel):
    """Input schema for set-door-io tool"""
    door_id: Optional[int] = Field(None, description="ID of the door to update.")
    door_name: Optional[str] = Field(None, description="Exact door name to update.")
    entry_device_id: Optional[Union[int, None]] = Field(None, description="Device id for entry reader, or null to clear.")
    entry_device_name: Optional[Union[str, None]] = Field(None, description="Device name for entry reader; 'none' to clear.")
    relay_device_id: Optional[int] = Field(None, description="Device id hosting the relay.")
    relay_device_name: Optional[str] = Field(None, description="Device name hosting the relay.")
    relay_index: Optional[int] = Field(None, description="Relay index on the device.")
    exit_button_device_id: Optional[int] = Field(None, description="Device id for the exit button input.")
    exit_button_device_name: Optional[str] = Field(None, description="Device name for the exit button input.")
    exit_button_input_index: Optional[int] = Field(None, description="Input index (e.g., 0 or 1).")
    exit_button_input_type: Optional[int] = Field(None, description="Input type: 1=NC, 0=NO")
    sensor_device_id: Optional[int] = Field(None, description="Device id for the door sensor input.")
    sensor_device_name: Optional[str] = Field(None, description="Device name for the door sensor input.")
    sensor_input_index: Optional[int] = Field(None, description="Input index (e.g., 0 or 1).")
    sensor_input_type: Optional[int] = Field(None, description="Input type: 1=NC, 0=NO")
    sensor_apb_use: Optional[Union[bool, int, str]] = Field(None, description="Whether to use the door sensor for APB (apb_use_door_sensor). Accepts boolean or 0/1/'0'/'1'.")

    @model_validator(mode="after")
    def validate_identifier(self):
        """Ensure door identifier is provided"""
        if not any([self.door_id, self.door_name]):
            raise ValueError("Either door_id or door_name must be provided")
        return self


class BulkCreateDoorItemInput(BaseModel):
    """Input schema for bulk-create-doors door item"""
    name: str = Field(..., description="Door name")
    entry_device_id: int = Field(..., description="Device id to control the lock (1:1 mapping enforced).")
    exit_device_id: int = Field(..., description="Exit button device id.")
    exit_input_index: int = Field(..., description="Exit input index.")
    exit_input_type: int = Field(..., description="Exit input type.")
    sensor_device_id: int = Field(..., description="Door sensor device id.")
    sensor_input_index: int = Field(..., description="Sensor input index.")
    sensor_input_type: int = Field(..., description="Sensor input type.")
    apb_use_door_sensor: int = Field(..., description="Use door sensor for APB.")
    confirm: Optional[bool] = Field(default=False, description="If true and all required fields are valid, creation proceeds.")
    default_group_id: Optional[int] = Field(default=1, description="Fallback door group id when 'door_group_id' is not provided.")
    description: Optional[str] = Field(None, description="Door description")
    door_group_id: Optional[int] = Field(None, description="Door group id to assign at creation time")
    open_timeout: Optional[int] = Field(default=10, description="Door open timeout (sec).")
    open_duration: Optional[int] = Field(default=5, description="Door open duration (sec).")
    open_once: Optional[bool] = Field(default=True, description="Open once option.")
    unconditional_lock: Optional[bool] = Field(default=True, description="Unconditional lock option.")
    relay_index: Optional[int] = Field(None, description="Required to actually create. If missing, tool returns relay options and stops.")


class BulkCreateDoorsInput(BaseModel):
    """Input schema for bulk-create-doors tool"""
    doors: List[BulkCreateDoorItemInput] = Field(..., description="List of door payloads. Each item uses the same schema as 'create-door'.")
    continue_on_error: Optional[bool] = Field(default=True, description="If false, stop at the first failure. Default: true.")

