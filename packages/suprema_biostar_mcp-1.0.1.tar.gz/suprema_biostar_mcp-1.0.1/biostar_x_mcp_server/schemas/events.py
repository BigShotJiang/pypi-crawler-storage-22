from typing import Optional, List, Union
from pydantic import BaseModel, Field


# ============================================================================
# Event Condition Schemas (nested)
# ============================================================================

class EventConditionInput(BaseModel):
    """Input schema for event condition item"""
    column: str = Field(..., description="Column name")
    operator: int = Field(..., ge=0, le=6, description="Operator (0=EQUAL, 1=NOT_EQUAL, 2=CONTAINS, 3=BETWEEN, 5=GREATER, 6=LESS)")
    value: Optional[List[Union[str, int, float]]] = Field(None, description="Value array")
    values: Optional[List[Union[str, int, float]]] = Field(None, description="Values array")


# ============================================================================
# Event Search Schemas
# ============================================================================

class GetEventTypesInput(BaseModel):
    """Input schema for get-event-types tool"""
    is_break_glass: Optional[bool] = Field(default=False, description="If true, list user-renamed (break-glass) names. When true and others not specified, setting_alert/setting_all default to false.")
    setting_alert: Optional[bool] = Field(default=True, description="If true, list alertable event types (server-side filter).")
    setting_all: Optional[bool] = Field(default=True, description="If true, list all event types (server-side filter).")
    search: Optional[str] = Field(None, description="Case-insensitive contains across code, name, and description.")
    codes: Optional[List[Union[str, int]]] = Field(None, description="Restrict to specific event code(s).")
    only_alertable: Optional[bool] = Field(default=False, description="Keep only items with alertable == true.")
    only_enable_alert: Optional[bool] = Field(default=False, description="Keep only items with enable_alert == true.")
    sort_by: Optional[str] = Field(default="code", description="Sort field (default: code).")
    sort_desc: Optional[bool] = Field(default=False, description="Descending sort if true.")
    offset: Optional[int] = Field(default=0, description="Start index for slicing.")
    limit: Optional[int] = Field(None, description="Maximum number of items to return (client-side slicing).")
    group_by: Optional[str] = Field(default="none", description="Group the result by a boolean field.")


class SearchEventsInput(BaseModel):
    """Input schema for search-events tool"""
    conditions: Optional[List[EventConditionInput]] = Field(None, description="Array of search conditions (for advanced filters only, do NOT use for datetime or user_id)")
    user_id: Optional[Union[str, int]] = Field(None, description="User ID to filter events (e.g., '61061'). Use this instead of conditions array.")
    user_name: Optional[str] = Field(None, description="User name to filter events. Server will resolve name to user_id.")
    start_datetime: Optional[str] = Field(None, description="Start datetime: 'YYYY-MM-DDTHH:MM:SS' (e.g., '2025-11-07T00:00:00'). WITHOUT timezone. Server converts to UTC.")
    end_datetime: Optional[str] = Field(None, description="End datetime: 'YYYY-MM-DDTHH:MM:SS' (e.g., '2025-11-07T23:59:59'). WITHOUT timezone. Server converts to UTC.")
    limit: Optional[int] = Field(default=100, description="Limit")
    offset: Optional[int] = Field(default=0, description="Offset")
    order_by: Optional[str] = Field(default="datetime", description="Order by")
    order_type: Optional[str] = Field(default="desc", description="Order type")


class GetRealtimeEventsInput(BaseModel):
    """Input schema for get-realtime-events tool"""
    duration: Optional[int] = Field(default=60, le=300, description="Duration to monitor events in seconds (max: 300)")
    event_types: Optional[List[str]] = Field(None, description="Filter real-time events by specific event type IDs")


class GetAccessLogsInput(BaseModel):
    """Input schema for get-access-logs tool"""
    start_datetime: Optional[str] = Field(None, description="Start datetime in ISO 8601 format (e.g., \"2025-10-27T00:00:00.000Z\"). If not provided, defaults to 24 hours ago from NOW. NEVER use hardcoded dates.")
    end_datetime: Optional[str] = Field(None, description="End datetime in ISO 8601 format (e.g., \"2025-10-27T23:59:59.999Z\"). If not provided, defaults to NOW. NEVER use hardcoded dates.")
    user_name: Optional[str] = Field(None, description="Filter by user name (partial match)")
    success_only: Optional[bool] = Field(default=False, description="Show only successful access attempts")
    limit: Optional[int] = Field(default=100, description="Maximum number of logs to retrieve")


class EventExportConditionInput(BaseModel):
    """Input schema for export-events-csv condition item"""
    column: str = Field(..., description="Column name")
    operator: int = Field(..., description="Operator")
    values: List[Union[str, int, float]] = Field(..., description="Values array")


class ExportEventsCSVInput(BaseModel):
    """Input schema for export-events-csv tool"""
    start_datetime: str = Field(..., description="Start datetime (ISO 8601 with Z). If 'conditions' omitted, this and end_datetime build a BETWEEN.")
    end_datetime: str = Field(..., description="End datetime (ISO 8601 with Z).")
    conditions: Optional[List[EventExportConditionInput]] = Field(None, description="Custom conditions for the Query. If provided, takes precedence.")
    user_id: Optional[Union[str, int]] = Field(None, description="Convenience filter: constrains to this user_id (mapped to column 'user_id.user_id').")
    user_name: Optional[str] = Field(None, description="Convenience filter: resolve name → user_id and filter (exact match preferred).")
    event_types: Optional[List[Union[str, int]]] = Field(None, description="Convenience filter: adds EQUAL condition on event_type_id with provided values.")
    columns: Optional[List[str]] = Field(
        default=["datetime","door_id.name","device_id.id","device_id.name","user_group_id","user_id","temperature","event_type_id","tna_key"],
        description="Columns to export (default matches BioStar example)."
    )
    headers: Optional[List[str]] = Field(
        default=["Date","Door","Device ID","Device","User Group","User","Temperature","Event","TNA Key"],
        description="CSV headers (must match columns length)."
    )
    offset: Optional[int] = Field(default=0, description="Offset for pagination.")
    time_offset_minutes: Optional[int] = Field(default=0, description="Timezone offset in minutes, e.g., 480 for UTC+8.")
    use_centigrade: Optional[bool] = Field(default=True, description="Whether to export temperature in centigrade.")
    copy_to_downloads: Optional[bool] = Field(default=True, description="Copy exported CSV to Windows Downloads.")
    dest_dir: Optional[str] = Field(None, description="Optional absolute destination directory (overrides Downloads).")
    target_username: Optional[str] = Field(None, description="If provided, copies to C:\\Users\\<name>\\Downloads.")
    filename: Optional[str] = Field(default="events_export.csv", description="Legacy/unused: server decides filename. Returned as 'filename' in response.")


class GetTemperatureLogsInput(BaseModel):
    """Input schema for get-temperature-logs tool"""
    start_datetime: Optional[str] = Field(None, description="Start datetime for temperature log search in ISO 8601 format with Z suffix (e.g., \"2025-07-26T15:00:00.000Z\")")
    end_datetime: Optional[str] = Field(None, description="End datetime for temperature log search in ISO 8601 format with Z suffix (e.g., \"2025-08-02T14:59:59.000Z\")")
    user_id: Optional[str] = Field(None, description="Filter by specific user ID")
    abnormal_only: Optional[bool] = Field(default=False, description="Show only abnormal temperature readings")
    temperature_threshold: Optional[float] = Field(None, ge=35.0, le=42.0, description="Temperature threshold in Celsius (e.g., 37.5)")

