from pydantic import BaseModel, Field


class ReadUploadedFileInput(BaseModel):
    """Input schema for read-uploaded-file tool"""
    filename: str = Field(..., description="Name of the uploaded file to read (e.g., 'users.csv')")

