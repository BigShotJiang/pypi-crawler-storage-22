from typing import Optional
from pydantic import BaseModel, Field


class VectorSearchHelpInput(BaseModel):
    """Input schema for vector-search-help tool"""
    query: str = Field(..., description="Question or keyword to search (e.g., 'how to create user', 'door API usage')")
    tool_name: Optional[str] = Field(None, description="Specific tool name (optional, e.g., 'create-user')")
    language: Optional[str] = Field(default="ko", description="Language selection (default: ko)")


class VectorSearchAPIDocsInput(BaseModel):
    """Input schema for vector-search-api-docs tool"""
    query: str = Field(..., description="API-related question to search (e.g., 'list users', 'door unlock API')")
    limit: Optional[int] = Field(default=10, ge=1, le=20, description="Number of results to return (default: 10, increased for better LLM selection)")


class VectorSearchManualInput(BaseModel):
    """Input schema for vector-search-manual tool"""
    query: str = Field(..., description="Question to search (e.g., 'user management', 'access permission settings')")
    language: Optional[str] = Field(default="ko", description="Language selection (default: ko)")
    limit: Optional[int] = Field(default=10, ge=1, le=20, description="Number of results to return (default: 10, increased for better LLM selection)")


class VectorGetToolHelpInput(BaseModel):
    """Input schema for vector-get-tool-help tool"""
    tool_name: str = Field(..., description="Tool name (e.g., 'create-user', 'list-doors')")
    language: Optional[str] = Field(default="ko", description="Language selection (default: ko)")

