from typing import Optional
from pydantic import BaseModel, Field


class AnalyzeServerLogsInput(BaseModel):
    """Input schema for analyze_server_logs tool"""
    log_path: Optional[str] = Field(default="C:\\Program Files\\BioStar X\\logs", description="로그 파일 경로 (기본값: C:\\Program Files\\BioStar X\\logs)")
    lines_to_read: Optional[int] = Field(default=50, ge=20, le=100, description="각 로그 파일에서 읽을 줄 수 (기본값: 50)")


class GetLogFileInfoInput(BaseModel):
    """Input schema for get_log_file_info tool"""
    log_path: Optional[str] = Field(default="C:\\Program Files\\BioStar X\\logs", description="로그 파일 경로 (기본값: C:\\Program Files\\BioStar X\\logs)")


class ReadSpecificLogInput(BaseModel):
    """Input schema for read_specific_log tool"""
    log_file_path: str = Field(..., description="읽을 로그 파일의 전체 경로")
    lines_to_read: Optional[int] = Field(default=50, ge=20, le=100, description="읽을 줄 수 (기본값: 50)")
    from_end: Optional[bool] = Field(default=True, description="파일 끝에서부터 읽을지 여부 (기본값: true)")


class GetSystemResourcesInput(BaseModel):
    """Input schema for get_system_resources tool"""
    include_all_processes: Optional[bool] = Field(default=False, description="모든 프로세스 정보 포함 여부 (기본값: false, BioStar 관련만)")


class AnalyzeServerStatusInput(BaseModel):
    """Input schema for analyze_server_status tool"""
    log_path: Optional[str] = Field(default="C:\\Program Files\\BioStar X\\logs", description="로그 파일 경로 (기본값: C:\\Program Files\\BioStar X\\logs)")
    lines_to_read: Optional[int] = Field(default=50, ge=20, le=100, description="각 로그 파일에서 읽을 줄 수 (기본값: 50)")
    include_system_resources: Optional[bool] = Field(default=True, description="시스템 리소스 정보 포함 여부 (기본값: true)")

