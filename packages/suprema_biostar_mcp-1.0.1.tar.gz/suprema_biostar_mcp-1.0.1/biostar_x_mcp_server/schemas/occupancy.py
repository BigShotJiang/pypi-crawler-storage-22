from typing import Optional
from pydantic import BaseModel, Field


class GetOccupancyStatusInput(BaseModel):
    """Input schema for get-occupancy-status tool"""
    door_name: Optional[str] = Field(None, description="출입문 이름 (예: '12층 메인 출입문'). If not provided, will analyze all doors.")
    door_id: Optional[str] = Field(None, description="출입문 ID (door_name 대신 사용 가능)")
    hours: Optional[int] = Field(default=24, description="분석할 시간 범위 (시간 단위, 기본값: 24시간)")
    include_details: Optional[bool] = Field(default=True, description="상세 이벤트 정보 포함 여부 (기본값: true)")


class AnalyzeDoorTrafficInput(BaseModel):
    """Input schema for analyze-door-traffic tool"""
    door_name: Optional[str] = Field(None, description="출입문 이름")
    door_id: Optional[str] = Field(None, description="출입문 ID")
    start_date: Optional[str] = Field(None, description="시작 날짜 (YYYY-MM-DD)")
    end_date: Optional[str] = Field(None, description="종료 날짜 (YYYY-MM-DD)")

