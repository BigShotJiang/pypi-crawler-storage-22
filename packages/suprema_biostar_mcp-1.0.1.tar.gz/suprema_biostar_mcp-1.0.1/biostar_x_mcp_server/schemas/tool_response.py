from typing import Optional, List, Dict, Any
from pydantic import BaseModel


class NavigationAction(BaseModel):
    """Navigation action to perform on target page"""
    type: str  # "click" or "scroll"
    ng_label_key: str  # Angular label key to target


class NavigationInfo(BaseModel):
    """Frontend navigation information"""
    enabled: bool = True
    page_type: str  # user_list, user_detail, door_list, door_detail, device_list, device_detail, monitoring, custom_url
    resource_id: Optional[str] = None  # For detail pages: user_id, door_id, device_id
    custom_url: Optional[str] = None  # For custom_url page type
    action: Optional[NavigationAction] = None  # Optional action on target page
    reason: Optional[str] = None  # Why navigating to this page


class ToolResponse(BaseModel):
    message: str
    method: str
    navigate_to: Optional[str] = None  # Deprecated: use navigation instead
    navigation: Optional[NavigationInfo] = None  # New structured navigation
    query: Optional[Dict[str, Any]] = None
    users: Optional[List[Dict[str, Any]]] = None
    download_url: Optional[str] = None
    filename: Optional[str] = None
