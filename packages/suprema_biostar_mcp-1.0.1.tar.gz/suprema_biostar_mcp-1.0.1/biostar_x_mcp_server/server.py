"""
BioStar X MCP Server
Pure JSON-RPC STDIO server for MCP protocol

Compatible with:
- Claude Desktop
- Claude Code
- Any MCP-compatible client
"""
import asyncio
import json
import sys
import logging
from pathlib import Path

# Setup logging to stderr (MCP uses stdout for protocol)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger(__name__)

from .config import Config
from .session import BioStarSession
from .tool_manager import ToolManager
from .handlers import (
    AuthHandler,
    UserHandler,
    DoorHandler,
    AccessHandler,
    DeviceHandler,
    EventHandler,
    AuditHandler,
    CardsHandler,
    NavigationHandler,
    FileHandler,
    LogHandler,
    OccupancyHandler,
    HelpWebHandler
)


class BioStarMCPServer:
    """BioStar X MCP Server implementation."""

    def __init__(self):
        logger.info("Initializing Suprema BioStar MCP Server...")

        self.config = Config()

        # Validate required credentials at startup
        errors = self.config.validate_required()
        if errors:
            logger.error("=" * 60)
            logger.error("CONFIGURATION ERROR - Missing required settings")
            logger.error("=" * 60)
            for err in errors:
                logger.error(f"  ✗ {err}")
            logger.error("")
            logger.error("Set environment variables in Claude Desktop config:")
            logger.error("")
            logger.error('  "mcpServers": {')
            logger.error('    "suprema-biostar": {')
            logger.error('      "command": "uvx",')
            logger.error('      "args": ["suprema-biostar-mcp"],')
            logger.error('      "env": {')
            logger.error('        "BIOSTAR_URL": "https://your-biostar-server",')
            logger.error('        "BIOSTAR_USERNAME": "admin",')
            logger.error('        "BIOSTAR_PASSWORD": "your-password"')
            logger.error('      }')
            logger.error('    }')
            logger.error('  }')
            logger.error("")
            logger.error("Config file location:")
            logger.error("  Windows: %APPDATA%\\Claude\\claude_desktop_config.json")
            logger.error("  macOS: ~/Library/Application Support/Claude/claude_desktop_config.json")
            logger.error("=" * 60)
            raise RuntimeError(f"Missing required configuration: {', '.join(errors)}")

        self.session = BioStarSession(self.config)
        self.tool_manager = ToolManager()

        # Initialize all handlers
        self.handlers = {
            "auth": AuthHandler(self.session),
            "users": UserHandler(self.session),
            "doors": DoorHandler(self.session),
            "access": AccessHandler(self.session),
            "devices": DeviceHandler(self.session),
            "events": EventHandler(self.session),
            "audit": AuditHandler(self.session),
            "cards": CardsHandler(self.session),
            "navigation": NavigationHandler(),  # No session needed
            "files": FileHandler(),  # No session needed
            "logs": LogHandler(self.session),
            "occupancy": OccupancyHandler(self.session),
            "help": HelpWebHandler(cache_ttl=self.config.docs_cache_ttl),
        }

        # Load all tool categories
        categories = [
            "auth", "users", "doors", "access", "devices",
            "events", "audit", "cards", "navigation",
            "files", "logs", "occupancy", "help"
        ]

        for category in categories:
            success = self.tool_manager.load_category(category)
            logger.info(f"Loading category '{category}': {'OK' if success else 'FAILED'}")

        # Verify tools are loaded
        all_tools = self.tool_manager.get_active_tools()
        logger.info(f"Total tools loaded: {len(all_tools)}")
        logger.info(f"Connected to: {self.config.biostar_url}")
        logger.info("Suprema BioStar MCP Server initialized successfully")

    async def handle_initialize(self, request):
        """Handle MCP initialize request."""
        logger.info("Handling initialize request")

        response = {
            "jsonrpc": "2.0",
            "id": request.get("id", 0),
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {
                        "listChanged": True
                    }
                },
                "serverInfo": {
                    "name": "suprema-biostar-mcp",
                    "version": "1.0.0"
                }
            }
        }

        print(json.dumps(response), flush=True)
        logger.info("Sent initialize response")

        # Send tools/listChanged notification
        await asyncio.sleep(0.1)
        notification = {
            "jsonrpc": "2.0",
            "method": "notifications/tools/listChanged",
            "params": {}
        }
        print(json.dumps(notification), flush=True)

    async def handle_list_tools(self, request):
        """Handle MCP tools/list request."""
        logger.info("Handling tools/list request")

        tools = self.tool_manager.get_active_tools()
        tools_data = []

        for tool in tools:
            tools_data.append({
                "name": tool.name,
                "description": tool.description,
                "inputSchema": tool.inputSchema
            })

        response = {
            "jsonrpc": "2.0",
            "id": request.get("id", 0),
            "result": {
                "tools": tools_data
            }
        }

        print(json.dumps(response), flush=True)
        logger.info(f"Returned {len(tools_data)} tools")

    async def handle_call_tool(self, request):
        """Handle MCP tools/call request."""
        params = request.get("params", {})
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        logger.info(f"Handling tools/call for: {tool_name}")

        try:
            # Get the category for this tool
            category = self.tool_manager.get_tool_category(tool_name)
            handler = self.handlers.get(category)

            # Special handling for help tools
            help_tool_mapping = {
                "search-biostar-docs": ("help", "search_help"),
                "get-docs-page": ("help", "get_docs_page"),
                "get-tool-help": ("help", "get_tool_help"),
            }

            result = None

            if tool_name in help_tool_mapping:
                cat, method_name = help_tool_mapping[tool_name]
                handler = self.handlers.get(cat)
                if handler and hasattr(handler, method_name):
                    method_func = getattr(handler, method_name)
                    result = await method_func(arguments)
                else:
                    raise ValueError(f"Handler {cat} has no method: {method_name}")
            elif handler:
                # Convert tool-name to method_name (e.g., get-users -> get_users)
                method_name = tool_name.replace("-", "_")
                if hasattr(handler, method_name):
                    method_func = getattr(handler, method_name)
                    result = await method_func(arguments)
                else:
                    raise ValueError(f"Handler has no method: {method_name}")
            else:
                raise ValueError(f"No handler for tool: {tool_name}")

            # Convert result to proper MCP format
            if isinstance(result, list):
                content = []
                for item in result:
                    if hasattr(item, 'type') and hasattr(item, 'text'):
                        content.append({
                            "type": item.type,
                            "text": item.text
                        })
                    else:
                        content.append({"type": "text", "text": str(item)})
            elif hasattr(result, 'type') and hasattr(result, 'text'):
                content = [{"type": result.type, "text": result.text}]
            else:
                content = [{"type": "text", "text": str(result)}]

            response = {
                "jsonrpc": "2.0",
                "id": request.get("id", 0),
                "result": {
                    "content": content
                }
            }

            # Record tool usage
            self.tool_manager.record_tool_usage(tool_name)

        except Exception as e:
            logger.error(f"Error executing tool {tool_name}: {e}", exc_info=True)
            response = {
                "jsonrpc": "2.0",
                "id": request.get("id", 0),
                "error": {
                    "code": -32603,
                    "message": f"Internal error: {str(e)}"
                }
            }

        print(json.dumps(response), flush=True)

    async def run(self):
        """Main server loop - reads from stdin, writes to stdout."""
        logger.info("Starting BioStar X MCP Server...")

        while True:
            try:
                # Read input from stdin
                line = await asyncio.get_event_loop().run_in_executor(
                    None, sys.stdin.readline
                )
                if not line:
                    logger.info("Stdin closed, shutting down")
                    break

                # Parse JSON-RPC request
                request = json.loads(line.strip())
                method = request.get("method")

                logger.debug(f"Received request: {method}")

                # Handle different MCP methods
                if method == "initialize":
                    await self.handle_initialize(request)
                elif method == "tools/list":
                    await self.handle_list_tools(request)
                elif method == "tools/call":
                    await self.handle_call_tool(request)
                elif method == "notifications/initialized":
                    logger.info("Received notifications/initialized")
                    continue
                elif method == "notifications/cancelled":
                    logger.info("Received notifications/cancelled")
                    continue
                elif method == "resources/list":
                    response = {
                        "jsonrpc": "2.0",
                        "id": request.get("id", 0),
                        "result": {"resources": []}
                    }
                    print(json.dumps(response), flush=True)
                elif method == "prompts/list":
                    response = {
                        "jsonrpc": "2.0",
                        "id": request.get("id", 0),
                        "result": {"prompts": []}
                    }
                    print(json.dumps(response), flush=True)
                else:
                    response = {
                        "jsonrpc": "2.0",
                        "id": request.get("id", 0),
                        "error": {
                            "code": -32601,
                            "message": f"Method not found: {method}"
                        }
                    }
                    print(json.dumps(response), flush=True)

            except json.JSONDecodeError as e:
                logger.error(f"JSON decode error: {e}")
                continue
            except Exception as e:
                logger.error(f"Unexpected error: {e}", exc_info=True)
                continue


async def async_main():
    """Async main entry point."""
    server = BioStarMCPServer()
    await server.run()


def main():
    """Synchronous main entry point for CLI."""
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
