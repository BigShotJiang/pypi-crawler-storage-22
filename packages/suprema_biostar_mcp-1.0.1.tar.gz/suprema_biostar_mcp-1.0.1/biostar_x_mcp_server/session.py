"""
BioStar X Session Management
Handles API authentication and session lifecycle
"""
import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any
import httpx
from .config import Config

logger = logging.getLogger(__name__)


class BioStarSession:
    """Manages BioStar X API session and authentication."""

    def __init__(self, config: Config):
        self.config = config
        self.client: Optional[httpx.AsyncClient] = None
        self.session_id: Optional[str] = None
        self.user_id: Optional[str] = None
        self.last_refresh: Optional[datetime] = None
        self.timezone_offset_minutes: Optional[int] = None
        self._lock = asyncio.Lock()

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.disconnect()

    async def connect(self):
        """Initialize HTTP client."""
        if not self.client:
            logger.info(f"Connecting to BioStar server at: {self.config.biostar_url}")
            logger.info(f"SSL verification: {self.config.verify_ssl}, Timeout: {self.config.api_timeout}s")

            self.client = httpx.AsyncClient(
                base_url=self.config.biostar_url,
                timeout=httpx.Timeout(self.config.api_timeout),
                verify=self.config.verify_ssl,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                }
            )

    async def set_session_id_async(self, session_id: str):
        """Set session ID from external source (async version)."""
        logger.info(f"Setting external session ID: {session_id}")
        self.session_id = session_id
        self.last_refresh = datetime.now()

        if not self.client:
            await self.connect()
            logger.info("Client initialized for external session")

        if self.client and self.session_id:
            self.client.headers["bs-session-id"] = self.session_id
            logger.info(f"Updated client headers with session ID: {session_id[:8]}...")

    def set_session_id(self, session_id: str):
        """Set session ID from external source (sync version)."""
        logger.info(f"Setting external session ID: {session_id}")
        self.session_id = session_id
        self.last_refresh = datetime.now()

        if self.client and self.session_id:
            self.client.headers["bs-session-id"] = self.session_id
            logger.info("Updated client headers with session ID")

    async def disconnect(self):
        """Close HTTP client and logout."""
        if self.session_id:
            try:
                await self.logout()
            except Exception as e:
                logger.error(f"Error during logout: {e}")

        if self.client:
            await self.client.aclose()
            self.client = None

    async def login(self, username: Optional[str] = None, password: Optional[str] = None) -> Dict[str, Any]:
        """Login to BioStar X API."""
        async with self._lock:
            if not self.client:
                await self.connect()

            login_username = username or self.config.biostar_username
            login_password = password or self.config.biostar_password

            if not login_username or not login_password:
                raise ValueError("Username and password are required. Set them in .env or provide as arguments.")

            try:
                response = await self.client.post(
                    "/api/login",
                    json={
                        "User": {
                            "login_id": login_username,
                            "password": login_password
                        }
                    }
                )
                response.raise_for_status()

                data = response.json()
                self.session_id = response.headers.get("bs-session-id")
                self.user_id = data.get("User", {}).get("user_id")
                self.last_refresh = datetime.now()

                if self.session_id:
                    self.client.headers["bs-session-id"] = self.session_id

                logger.info(f"Successfully logged in as user {self.user_id}")
                return data

            except httpx.HTTPStatusError as e:
                logger.error(f"Login failed: {e.response.status_code} - {e.response.text}")
                raise
            except Exception as e:
                logger.error(f"Login error: {e}")
                raise

    async def logout(self) -> None:
        """Logout from BioStar X API."""
        if not self.session_id:
            return

        try:
            await self.client.post("/api/logout")
            logger.info("Successfully logged out")
        except Exception as e:
            logger.error(f"Logout error: {e}")
        finally:
            self.session_id = None
            self.user_id = None
            self.last_refresh = None
            self.timezone_offset_minutes = None
            if self.client:
                self.client.headers.pop("bs-session-id", None)

    async def refresh_session(self) -> None:
        """Refresh session if needed."""
        if not self.session_id:
            await self.login()
            return

        if self.last_refresh:
            elapsed = datetime.now() - self.last_refresh
            if elapsed.total_seconds() > self.config.session_refresh_interval:
                logger.info("Session refresh needed")
                await self.login()

    async def request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> httpx.Response:
        """Make authenticated request to BioStar X API."""
        if not self.client:
            await self.connect()
            logger.info("Client initialized on first request")

            if self.session_id:
                self.client.headers["bs-session-id"] = self.session_id
                logger.info(f"Session headers set on first request: {self.session_id[:8]}...")

        await self.refresh_session()

        try:
            response = await self.client.request(
                method=method,
                url=endpoint,
                json=json,
                params=params,
                **kwargs
            )
            response.raise_for_status()
            return response

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                logger.info("Session expired, re-authenticating")
                await self.login()
                response = await self.client.request(
                    method=method,
                    url=endpoint,
                    json=json,
                    params=params,
                    **kwargs
                )
                response.raise_for_status()
                return response
            raise

    async def get(self, endpoint: str, **kwargs) -> httpx.Response:
        """Make GET request."""
        return await self.request("GET", endpoint, **kwargs)

    async def post(self, endpoint: str, json: Dict[str, Any], **kwargs) -> httpx.Response:
        """Make POST request."""
        return await self.request("POST", endpoint, json=json, **kwargs)

    async def put(self, endpoint: str, json: Dict[str, Any], **kwargs) -> httpx.Response:
        """Make PUT request."""
        return await self.request("PUT", endpoint, json=json, **kwargs)

    async def delete(self, endpoint: str, **kwargs) -> httpx.Response:
        """Make DELETE request."""
        return await self.request("DELETE", endpoint, **kwargs)

    def is_authenticated(self) -> bool:
        """Check if session is authenticated."""
        return self.session_id is not None
