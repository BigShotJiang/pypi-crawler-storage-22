"""
BioStar X MCP Server Tool Manager
Dynamic loading and management of tool categories
"""
import logging
from typing import List, Set, Optional, Dict
from mcp.types import Tool

from .tools.categories import (
    get_tools_for_category,
    get_category_for_tool,
    get_all_categories,
    CATEGORY_DESCRIPTIONS
)
from .tools.auth import AUTH_TOOLS
from .tools.users import USER_TOOLS
from .tools.events import EVENT_TOOLS
from .tools.doors import DOOR_TOOLS
from .tools.devices import DEVICE_TOOLS
from .tools.access import ACCESS_TOOLS
from .tools.audit import AUDIT_TOOLS
from .tools.cards import CARD_TOOLS
from .tools.navigation import NAVIGATION_TOOLS
from .tools.occupancy import OCCUPANCY_TOOLS
from .tools.files import FILE_TOOLS
from .tools.logs import LOG_TOOLS
from .tools.help import HELP_TOOLS

logger = logging.getLogger(__name__)


class ToolManager:
    """Manages dynamic loading and unloading of tool categories."""

    def __init__(self, max_categories: int = 15):
        self.max_categories = max_categories
        self.active_categories: Set[str] = set()
        self.loaded_tools: Dict[str, List[Tool]] = {}
        self.usage_count: Dict[str, int] = {}

    def load_category(self, category: str) -> bool:
        """Load tools for a specific category."""
        logger.debug(f"Attempting to load category: {category}")

        if category in self.active_categories:
            logger.debug(f"Category {category} already loaded")
            return True

        if category not in get_all_categories():
            logger.warning(f"Unknown category: {category}")
            return False

        # Check if we need to unload a category
        if len(self.active_categories) >= self.max_categories:
            logger.debug(f"Max categories reached ({self.max_categories}), unloading least used")
            self._unload_least_used_category()

        # Load the tools for this category
        tools = self._get_tools_for_category(category)
        logger.debug(f"Retrieved {len(tools)} tools for category: {category}")

        if tools:
            self.loaded_tools[category] = tools
            self.active_categories.add(category)
            self.usage_count[category] = 0
            logger.info(f"Loaded category: {category} with {len(tools)} tools")
            return True
        else:
            logger.error(f"No tools found for category: {category}")
            return False

    def unload_category(self, category: str) -> bool:
        """Unload tools for a specific category."""
        if category not in self.active_categories:
            return False

        self.active_categories.remove(category)
        self.loaded_tools.pop(category, None)
        self.usage_count.pop(category, None)
        logger.info(f"Unloaded category: {category}")
        return True

    def get_active_tools(self) -> List[Tool]:
        """Get all currently loaded tools."""
        tools = []
        seen_names = set()

        for category in self.active_categories:
            category_tools = self.loaded_tools.get(category, [])
            for tool in category_tools:
                tool_name = tool.name
                if tool_name not in seen_names:
                    seen_names.add(tool_name)
                    tools.append(tool)
                else:
                    logger.warning(f"Duplicate tool name found: {tool_name} from category {category}, skipping")

        logger.info(f"Returning {len(tools)} unique tools from {len(self.active_categories)} categories")
        return tools

    def get_tool_category(self, tool_name: str) -> Optional[str]:
        """Get the category a tool belongs to."""
        return get_category_for_tool(tool_name)

    def record_tool_usage(self, tool_name: str) -> None:
        """Record that a tool was used."""
        category = self.get_tool_category(tool_name)
        if category and category in self.usage_count:
            self.usage_count[category] += 1

    def _unload_least_used_category(self) -> None:
        """Unload the least recently used category."""
        if not self.active_categories:
            return

        # Never unload auth category
        candidates = [c for c in self.active_categories if c != "auth"]
        if not candidates:
            return

        # Find least used category
        least_used = min(candidates, key=lambda c: self.usage_count.get(c, 0))
        self.unload_category(least_used)

    # Category to tools mapping (without vector_solis)
    _CATEGORY_TOOLS_MAP = {
        "auth": AUTH_TOOLS,
        "users": USER_TOOLS,
        "events": EVENT_TOOLS,
        "doors": DOOR_TOOLS,
        "access": ACCESS_TOOLS,
        "devices": DEVICE_TOOLS,
        "audit": AUDIT_TOOLS,
        "cards": CARD_TOOLS,
        "navigation": NAVIGATION_TOOLS,
        "occupancy": OCCUPANCY_TOOLS,
        "files": FILE_TOOLS,
        "logs": LOG_TOOLS,
        "help": HELP_TOOLS,
    }

    def _get_tools_for_category(self, category: str) -> List[Tool]:
        """Get tool definitions for a category."""
        logger.debug(f"Getting tools for category: {category}")

        tools = self._CATEGORY_TOOLS_MAP.get(category)

        if tools is None:
            logger.warning(f"Unknown category: {category}")
            return []

        return tools

    def get_category_info(self) -> Dict[str, Dict[str, any]]:
        """Get information about all categories."""
        info = {}
        for category in get_all_categories():
            info[category] = {
                "description": CATEGORY_DESCRIPTIONS.get(category, ""),
                "tools": get_tools_for_category(category),
                "loaded": category in self.active_categories,
                "usage_count": self.usage_count.get(category, 0)
            }
        return info

    def load_all_categories(self) -> int:
        """Load all available categories. Returns number of categories loaded."""
        count = 0
        for category in get_all_categories():
            if self.load_category(category):
                count += 1
        return count
