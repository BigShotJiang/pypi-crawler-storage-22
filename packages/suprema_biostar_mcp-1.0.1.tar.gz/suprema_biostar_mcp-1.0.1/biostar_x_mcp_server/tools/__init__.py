"""
BioStar X MCP Server - Tool Definitions
"""

from .auth import AUTH_TOOLS
from .users import USER_TOOLS
from .doors import DOOR_TOOLS
from .access import ACCESS_TOOLS
from .devices import DEVICE_TOOLS
from .events import EVENT_TOOLS
from .audit import AUDIT_TOOLS
from .cards import CARD_TOOLS
from .navigation import NAVIGATION_TOOLS
from .occupancy import OCCUPANCY_TOOLS
from .files import FILE_TOOLS
from .logs import LOG_TOOLS
from .categories import (
    TOOL_CATEGORIES,
    CATEGORY_DESCRIPTIONS,
    get_tools_for_category,
    get_category_for_tool,
    get_all_categories
)

__all__ = [
    # Tool lists
    "AUTH_TOOLS",
    "USER_TOOLS",
    "DOOR_TOOLS",
    "ACCESS_TOOLS",
    "DEVICE_TOOLS",
    "EVENT_TOOLS",
    "AUDIT_TOOLS",
    "CARD_TOOLS",
    "NAVIGATION_TOOLS",
    "OCCUPANCY_TOOLS",
    "FILE_TOOLS",
    "LOG_TOOLS",
    # Categories
    "TOOL_CATEGORIES",
    "CATEGORY_DESCRIPTIONS",
    "get_tools_for_category",
    "get_category_for_tool",
    "get_all_categories",
]
