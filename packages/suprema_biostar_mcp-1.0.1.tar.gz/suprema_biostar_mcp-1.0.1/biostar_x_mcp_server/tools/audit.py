from mcp.types import Tool

# Audit search tool
AUDIT_SEARCH_TOOL = Tool(
    name="audit-search",
    description="Search audit trail logs in the BioStar 2 system",
    inputSchema={
        "type": "object",
        "properties": {
            "conditions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "column": {
                            "type": "string",
                            "description": "Column to search (e.g., 'datetime', 'user_id', 'target_type')"
                        },
                        "operator": {
                            "type": "integer",
                            "description": "Search operator (0=EQUAL, 1=NOT_EQUAL, 2=CONTAINS, 3=BETWEEN, 5=GREATER, 6=LESS)"
                        },
                        "values": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Values to search for"
                        }
                    },
                    "required": ["column", "operator", "values"]
                },
                "description": "Search conditions for audit trail"
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of results",
                "default": 100
            },
            "offset": {
                "type": "integer",
                "description": "Offset for pagination",
                "default": 0
            }
        },
        "required": []
    }
)

# Audit search user tool
AUDIT_SEARCH_USER_TOOL = Tool(
    name="audit-search-user",
    description="Search for users by name",
    inputSchema={
        "type": "object",
        "properties": {
            "search": {
                "type": "string",
                "description": "Search string for user name"
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of results",
                "default": 201
            },
            "offset": {
                "type": "integer",
                "description": "Offset for pagination",
                "default": 0
            }
        },
        "required": []
    }
)

# Audit search operator level tool
AUDIT_SEARCH_OPERATOR_LEVEL_TOOL = Tool(
    name="audit-search-operator-level",
    description="Search for operator permission levels",
    inputSchema={
        "type": "object",
        "properties": {
            "search": {
                "type": "string",
                "description": "Search string for permission level"
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of results",
                "default": 201
            },
            "offset": {
                "type": "integer",
                "description": "Offset for pagination",
                "default": 0
            }
        },
        "required": []
    }
)

# Audit search IP list tool
AUDIT_SEARCH_IP_LIST_TOOL = Tool(
    name="audit-search-ip-list",
    description="Search for IP addresses",
    inputSchema={
        "type": "object",
        "properties": {
            "search": {
                "type": "string",
                "description": "Search string for IP address"
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of results",
                "default": 201
            },
            "offset": {
                "type": "integer",
                "description": "Offset for pagination",
                "default": 0
            }
        },
        "required": []
    }
)

# Audit search target list tool
AUDIT_SEARCH_TARGET_LIST_TOOL = Tool(
    name="audit-search-target-list",
    description="Search for audit targets",
    inputSchema={
        "type": "object",
        "properties": {
            "search": {
                "type": "string",
                "description": "Search string for target"
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of results",
                "default": 201
            },
            "offset": {
                "type": "integer",
                "description": "Offset for pagination",
                "default": 0
            }
        },
        "required": []
    }
)

AUDIT_CSV_EXPORT_TOOL = Tool(
    name="audit-csv-export",
    description="Export audit trail data to CSV via /api/audit/export and copy the file to the Windows Downloads folder.",
    inputSchema={
        "type": "object",
        "properties": {
            "conditions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "column": {"type": "string"},
                        "operator": {"type": "integer"},
                        "values": {"type": "array", "items": {"type": "string"}}
                    },
                    "required": ["column", "operator", "values"]
                },
                "description": "Filter conditions (use 'DATE' for time)."
            },
            "columns": {
                "type": "array",
                "items": {"type": "string"},
                "description": "CSV columns (UPPERCASE per API spec).",
                "default": ["DATE","USRID","PERM","IP","MENU","TARGET","METHOD","CONTENT"]
            },
            "headers": {
                "type": "array",
                "items": {"type": "string"},
                "description": "CSV header names (same length as columns).",
                "default": ["Datetime","User","Operator Level","IP","Category","Target","Action","Modification"]
            },
            "offset": {
                "type": "integer",
                "description": "Offset for export pagination.",
                "default": 0
            },
            "time_offset_minutes": {
                "type": "integer",
                "description": "Timezone offset in minutes (e.g., UTC+8 => 480).",
                "default": 0
            },
            "start_datetime": {
                "type": "string",
                "description": "Convenience: start time (ISO). Builds a DATE condition if 'conditions' omitted."
            },
            "end_datetime": {
                "type": "string",
                "description": "Convenience: end time (ISO). Builds a DATE condition if 'conditions' omitted."
            },
            "copy_to_downloads": {
                "type": "boolean",
                "description": "Copy exported CSV to Windows Downloads folder.",
                "default": True
            },
            "dest_dir": {
                "type": "string",
                "description": "Optional absolute destination directory (overrides Downloads)."
            },
            "target_username": {
                "type": "string",
                "description": "If provided, copies to C:\\Users\\<name>\\Downloads."
            }
        },
        "required": []
    }
)

# Export all audit tools
AUDIT_TOOLS = [
    AUDIT_SEARCH_TOOL,
    AUDIT_SEARCH_USER_TOOL,
    AUDIT_SEARCH_OPERATOR_LEVEL_TOOL,
    AUDIT_SEARCH_IP_LIST_TOOL,
    AUDIT_SEARCH_TARGET_LIST_TOOL,
    AUDIT_CSV_EXPORT_TOOL
]
