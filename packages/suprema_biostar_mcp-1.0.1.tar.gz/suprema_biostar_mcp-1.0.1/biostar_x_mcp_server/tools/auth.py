from mcp.types import Tool

# Authentication tools
LOGIN_TOOL = Tool(
    name="login",
    description="[ACTION TOOL - DEVELOPER USE ONLY] Perform actual login to BioStar X system via API. Use this ONLY when user explicitly asks to 'login now', 'authenticate now', 'connect now', or wants to perform actual system login operation. This is for programmatic API access, NOT for explaining how users login. For user login explanations, use vector-search-manual instead. By default uses credentials from .env file (developer configuration), but you can optionally provide different credentials.",
    inputSchema={
        "type": "object",
        "properties": {
            "username": {
                "type": "string",
                "description": "Optional: BioStar 2 username (defaults to BIOSTAR_USERNAME from .env)"
            },
            "password": {
                "type": "string",
                "description": "Optional: BioStar 2 password (defaults to BIOSTAR_PASSWORD from .env)"
            }
        },
        "required": []
    }
)

LOGOUT_TOOL = Tool(
    name="logout",
    description="[ACTION TOOL - DEVELOPER USE ONLY] Perform actual logout from BioStar X system via API. Use this ONLY when user explicitly asks to 'logout now' or wants to perform actual system logout operation. This is for programmatic API access, NOT for explaining how users logout. For user logout explanations, use vector-search-manual instead.",
    inputSchema={
        "type": "object",
        "properties": {},
        "required": []
    }
)

GET_SESSION_INFO_TOOL = Tool(
    name="get-session-info",
    description="[ACTION TOOL - DEVELOPER USE ONLY] Get current API session information including user details. Use this ONLY when user explicitly asks to 'check session', 'get session info', or wants to query actual session status. This is for programmatic API access, NOT for explaining session management to users. For user session explanations, use vector-search-manual instead.",
    inputSchema={
        "type": "object",
        "properties": {},
        "required": []
    }
)

GET_SERVER_PREFERENCES_TOOL = Tool(
    name="get-server-preferences",
    description="Get BioStar server preferences including timezone, language, date/time format. This is essential for displaying event times in the correct timezone.",
    inputSchema={
        "type": "object",
        "properties": {},
        "required": []
    }
)

# List of all auth tools
AUTH_TOOLS = [
    LOGIN_TOOL,
    LOGOUT_TOOL,
    GET_SESSION_INFO_TOOL,
    GET_SERVER_PREFERENCES_TOOL
]
