"""
BioStar X MCP Server Tool Categories
Defines tool-to-category mappings for dynamic loading
"""
from typing import Dict, List

TOOL_CATEGORIES: Dict[str, List[str]] = {
    "auth": [
        "login",
        "logout",
        "get-session-info",
        "get-server-preferences"
    ],
    "users": [
        "get-users",
        "get-user",
        "create-user",
        "update-user",
        "delete-user",
        "search-users",
        "advanced-search-users",
        "get-user-cards",
        "unassign-user-cards",
        "bulk-add-users",
        "create-user-group",
        "get-user-groups",
        "export-users-csv",
        "export-non-accessed-users-csv",
        "add-user-to-group",
        "remove-user-from-group",
        "bulk-edit-users",
        "import-users-csv",
        "import-users-csv-smart",
        "bulk-update-users-from-file",
    ],
    "cards": [
        "get-card-types",
        "check-card-availability",
        "create-card-csn",
        "create-card-wiegand",
        "get-wiegand-format-presets",
        "create-card-biostar2-qr"
    ],
    "doors": [
        "get-doors",
        "get-door",
        "create-door",
        "update-door",
        "delete-door",
        "control-door",
        "get-doors-status",
        "get-door-groups",
        "get-door-group",
        "create-door-group",
        "update-door-group",
        "delete-door-group",
        "add-doors-to-group",
        "remove-doors-from-group",
        "update-door-description",
        "set-door-auto-mode",
        "set-door-relock-on-close",
        "set-door-open-duration",
        "set-door-timed-apb",
        "set-door-classic-apb",
        "set-door-io",
        "bulk-create-doors"
    ],
    "access": [
        "get-access-groups",
        "get-access-group",
        "create-access-group",
        "update-access-group",
        "delete-access-group",
        "get-access-levels",
        "get-access-level",
        "search-access-groups",
        "create-access-level",
        "update-access-level",
        "delete-access-level",
        "add-access-level-to-group",
        "remove-access-level-from-group"
    ],
    "devices": [
        "list-devices",
        "get-device",
        "add-device",
        "update-device",
        "reboot-device",
        "get-device-status",
        "scan-devices",
        "tcp-search",
        "udp-search",
        "list-waiting-devices",
        "add-waiting-device",
        "bulk-add-waiting-devices",
        "disconnect-device",
        "remove-device",
        "sync-device-time",
        "clear-device-log",
        "lock-device",
        "unlock-device",
        "get-device-groups",
        "get-device-group",
        "create-device-group",
        "update-device-group",
        "delete-device-group",
        "move-device-to-group",
        "remove-device-from-group",
        "update-device-auth-mode",
        "update-device-face-distance",
        "update-device-date-type",
        "update-device-timezone",
        "factory-reset-device",
        "update-device-auth-and-display",
        "bulk-add-devices",
        "update-device-network",
        "update-device-serial-comm",
        "update-device-server-comm",
        "update-device-fingerprint",
        "update-device-face",
        "update-device-card-csn"
    ],
    "events": [
        "get-event-types",
        "search-events",
        "get-realtime-events",
        "export-events-csv",
        "get-temperature-logs",
        "get-access-logs"
    ],
    "audit": [
        "audit-search",
        "audit-search-user",
        "audit-search-operator-level",
        "audit-search-ip-list",
        "audit-search-target-list",
        "audit-csv-export"
    ],
    "navigation": [
        "navigate-to-page"
    ],
    "occupancy": [
        "get-occupancy-status",
        "analyze-door-traffic"
    ],
    "files": [
        "read-uploaded-file"
    ],
    "logs": [
        "analyze-server-logs",
        "get-log-file-info",
        "read-specific-log",
        "get-system-resources",
        "analyze-server-status"
    ],
    # Web-based help tools (no vector DB required)
    "help": [
        "search-biostar-docs",
        "get-docs-page",
        "get-tool-help"
    ]
}

# Tool descriptions for each category
CATEGORY_DESCRIPTIONS = {
    "auth": "Authentication and session management tools",
    "users": "User management tools for creating, updating, and managing users",
    "cards": "Create and manage cards (CSN, Wiegand, QR), card types lookup, and availability checks",
    "doors": "Door control tools for managing and operating doors",
    "access": "Access control tools for managing permissions and access groups/levels",
    "devices": "Device management tools for managing BioStar X devices",
    "events": "Event and log management tools for monitoring and retrieving system events",
    "audit": "Audit trail tools for tracking admin activities and system changes",
    "navigation": "Frontend navigation tools for guiding users to relevant pages after operations",
    "occupancy": "Occupancy status and traffic analysis tools",
    "files": "File handling tools for reading and processing uploaded files (CSV, PDF, etc.)",
    "logs": "BioStar X server log analysis and monitoring tools",
    "help": "Documentation search from docs.supremainc.com (web-based, always up-to-date)"
}


def get_tools_for_category(category: str) -> List[str]:
    """Get list of tools for a specific category."""
    return TOOL_CATEGORIES.get(category, [])


def get_category_for_tool(tool_name: str) -> str:
    """Get the category a tool belongs to."""
    for category, tools in TOOL_CATEGORIES.items():
        if tool_name in tools:
            return category
    return None


def get_all_categories() -> List[str]:
    """Get list of all available categories."""
    return list(TOOL_CATEGORIES.keys())
