from mcp.types import Tool

# Device management tools
LIST_DEVICES_TOOL = Tool(
    name="list-devices",
    description="Retrieve a list of all devices from the BioStar 2 system",
    inputSchema={
        "type": "object",
        "properties": {
            "group_id": {
                "type": "integer",
                "description": "Filter devices by device group ID"
            },
            "device_type": {
                "type": "string",
                "description": "Filter by device type (e.g., 'BioStation', 'BioEntry', 'FaceStation')"
            }
        },
        "required": []
    }
)

GET_DEVICE_TOOL = Tool(
    name="get-device",
    description="Get detailed information about a specific device",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to retrieve"
            }
        },
        "required": ["device_id"]
    }
)

ADD_DEVICE_TOOL = Tool(
    name="add-device",
    description="Add a new device to the BioStar 2 system. It's recommended to run 'udp-search' first to discover devices on the network",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "Unique device ID"
            },
            "name": {
                "type": "string",
                "description": "Name of the device"
            },
            "device_type_id": {
                "type": "integer",
                "description": "Device type ID (e.g., 8 for BioStation 2, 9 for BioStation A2, 10 for FaceStation 2, 35 for BioStation 3)"
            },
            "device_type_name": {
                "type": "string",
                "description": "Device type name (e.g., 'BioStation 2', 'BioStation A2', 'FaceStation 2')"
            },
            "ip_address": {
                "type": "string",
                "description": "IP address of the device"
            },
            "port": {
                "type": "integer",
                "description": "Port number (default: 51211)",
                "default": 51211
            },
            "use_ssl": {
                "type": "boolean",
                "description": "Whether to use SSL connection",
                "default": False
            },
            "device_group_id": {
                "type": "integer",
                "description": "ID of the device group to add this device to"
            }
        },
        "required": ["device_id", "name", "ip_address", "device_group_id"]
    }
)

UPDATE_DEVICE_TOOL = Tool(
    name="update-device",
    description="Update device configuration and settings",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to update"
            },
            "name": {
                "type": "string",
                "description": "New name for the device"
            },
            "description": {
                "type": "string",
                "description": "Device description"
            },
            "time_zone": {
                "type": "string",
                "description": "Time zone for the device (e.g., 'America/New_York')"
            },
            "volume": {
                "type": "integer",
                "description": "Device volume level (0-100)"
            }
        },
        "required": ["device_id"]
    }
)

REBOOT_DEVICE_TOOL = Tool(
    name="reboot-device",
    description=(
        "Restart one or more devices via POST /api/devices/reset.\n"
        "- Body: {\"DeviceCollection\":{\"rows\":[{\"id\":<num>}, ...], \"total\":<n>}}\n"
        "- Success when HTTP 200 AND (Response.code == \"0\" if present) AND each row code == \"0\".\n"
        "- STRICT NAME MODE: If 'device_names' is used, names must match EXACTLY (case-sensitive).\n"
        "  0 match -> no action; return full list and needs_selection.\n"
        "  >1 match (duplicate names) -> no action; return candidates and needs_selection.\n"
        "- If 'device_search_text' is provided (and no exact selection), returns candidates ONLY (no action).\n"
        "- If both 'device_ids' and 'device_names' are provided, they must resolve to the SAME set.\n"
        "- If more than one target, 'confirm_multi' must be true."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "device_ids": {
                "type": "array",
                "items": {"oneOf": [{"type": "integer"}, {"type": "string"}]},
                "description": "One or more device IDs to restart (existence validated)."
            },
            "device_id": {
                "type": "integer",
                "description": "Legacy single device id input."
            },
            "device_names": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Device names to restart (EXACT, case-sensitive; no fuzzy)."
            },
            "device_search_text": {
                "type": "string",
                "description": "Browse candidates by substring (case-insensitive). Returns candidates only; no action."
            },
            "confirm_multi": {
                "type": "boolean",
                "default": False,
                "description": "Must be true to act on more than one device."
            }
        },
        "required": []
    }
)

GET_DEVICE_STATUS_TOOL = Tool(
    name="get-device-status",
    description="Get the current status and health of a device",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to check status"
            }
        },
        "required": ["device_id"]
    }
)

SCAN_DEVICES_TOOL = Tool(
    name="scan-devices",
    description="Scan network for BioStar 2 compatible devices",
    inputSchema={
        "type": "object",
        "properties": {
            "network_range": {
                "type": "string",
                "description": "IP range to scan (e.g., '192.168.1.0/24')"
            },
            "port": {
                "type": "integer",
                "description": "Port to scan (default: 51211)",
                "default": 51211
            }
        },
        "required": []
    }
)

SYNC_DEVICE_TIME_TOOL = Tool(
    name="sync-device-time",
    description="Synchronize device time with server time",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to sync time"
            }
        },
        "required": ["device_id"]
    }
)

CLEAR_DEVICE_LOG_TOOL = Tool(
    name="clear-device-log",
    description=" CRITICAL: Clear logs from a specific device. THIS IS PERMANENT and CANNOT BE UNDONE! Logs are critical for audit and security. ALWAYS confirm with user before executing. For demo data, REQUIRE explicit 'delete confirm' or '삭제 확인' from user.",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device"
            },
            "log_type": {
                "type": "string",
                "description": "Type of logs to clear",
                "enum": ["all", "event", "image"],
                "default": "all"
            }
        },
        "required": ["device_id"]
    }
)

LOCK_DEVICE_TOOL = Tool(
    name="lock-device",
    description="Lock a device to prevent access",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to lock"
            }
        },
        "required": ["device_id"]
    }
)

UNLOCK_DEVICE_TOOL = Tool(
    name="unlock-device",
    description="Unlock a device to allow normal operation",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to unlock"
            }
        },
        "required": ["device_id"]
    }
)

TCP_SEARCH_TOOL = Tool(
    name="tcp-search",
    description="Search for a specific BioStar device using TCP connection. This is the PREFERRED method for adding devices when you know the IP address. Use this BEFORE udp-search.",
    inputSchema={
        "type": "object",
        "properties": {
            "ip_address": {
                "type": "string",
                "description": "IP address of the device to connect to"
            },
            "port": {
                "type": "integer",
                "description": "Port number (default: 51211)",
                "default": 51211
            },
            "timeout": {
                "type": "integer",
                "description": "Connection timeout in seconds (default: 10)",
                "default": 10
            },
            "retry_count": {
                "type": "integer",
                "description": "Number of retry attempts (default: 2)",
                "default": 2
            }
        },
        "required": ["ip_address"]
    }
)

UDP_SEARCH_TOOL = Tool(
    name="udp-search",
    description="Search for BioStar devices on the network using UDP broadcast. Returns only disconnected devices (server_connected.status = 'disconnected') that can be connected to the system. Use this ONLY when tcp-search fails.",
    inputSchema={
        "type": "object",
        "properties": {
            "timeout": {
                "type": "integer",
                "description": "Search timeout in seconds (default: 5)",
                "default": 5
            }
        },
        "required": []
    }
)

DISCONNECT_DEVICE_TOOL = Tool(
    name="disconnect-device",
    description="Disconnect a device from the BioStar 2 server",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to disconnect"
            }
        },
        "required": ["device_id"]
    }
)

REMOVE_DEVICE_TOOL = Tool(
    name="remove-device",
    description=" CRITICAL: Remove a device from the BioStar 2 system permanently. THIS IS PERMANENT and CANNOT BE UNDONE! ALWAYS confirm with user before executing. For demo data, REQUIRE explicit 'delete confirm' or '삭제 확인' from user.",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "type": "integer",
                "description": "ID of the device to remove"
            }
        },
        "required": ["device_id"]
    }
)

# Device Group management tools
GET_DEVICE_GROUPS_TOOL = Tool(
    name="get-device-groups",
    description=(
        "List all device groups using POST /api/v2/device_groups/search with payload "
        '{"order_by":"depth:false"}. Returns id, name, depth, parent_id, is_root, '
        "and is_top_level. Optionally filter by name substring."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "group_search_text": {
                "type": "string",
                "description": "Case-insensitive substring filter on group name"
            }
        },
        "required": []
    }
)


GET_DEVICE_GROUP_TOOL = Tool(
    name="get-device-group",
    description=(
        "Get a device group by STRICT selection and (if uniquely resolved) return full details via GET /api/device_groups/{id}.\n"
        "- Inputs:\n"
        "  - group_id (preferred), OR\n"
        "  - group_name (EXACT, case-sensitive), OR\n"
        "  - group_search_text (substring browse; returns candidates ONLY)\n"
        "- Branch behavior:\n"
        "  - 0 match  -> return all available groups (compact) and needs_selection=true.\n"
        "  - 1 match  -> fetch detail (devices, child groups, parent, is_top_level).\n"
        "  - >1 match -> return candidates (id/name/depth/parent) and needs_selection=true."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "group_id": {
                "type": "integer",
                "description": "Exact device group ID to fetch."
            },
            "group_name": {
                "type": "string",
                "description": "EXACT (case-sensitive) device group name."
            },
            "group_search_text": {
                "type": "string",
                "description": "Substring browse for group names. Returns candidates only."
            }
        },
        "required": []
    }
)

CREATE_DEVICE_GROUP_TOOL = Tool(
    name="create-device-group",
    description="Create a new device group",
    inputSchema={
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Name of the device group"
            },
            "description": {
                "type": "string",
                "description": "Description of the device group"
            },
            "parent_id": {
                "type": "integer",
                "description": "Parent device group ID (default: 1 for root group)",
                "default": 1
            },
            "device_ids": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "List of device IDs to include in the group"
            }
        },
        "required": ["name"]
    }
)

UPDATE_DEVICE_GROUP_TOOL = Tool(
    name="update-device-group",
    description="Update an existing device group",
    inputSchema={
        "type": "object",
        "properties": {
            "group_id": {
                "type": "integer",
                "description": "ID of the device group to update"
            },
            "name": {
                "type": "string",
                "description": "New name for the device group"
            },
            "description": {
                "type": "string",
                "description": "New description for the device group"
            },
            "device_ids": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "New list of device IDs for the group"
            }
        },
        "required": ["group_id"]
    }
)

DELETE_DEVICE_GROUP_TOOL = Tool(
    name="delete-device-group",
    description="Delete a device group",
    inputSchema={
        "type": "object",
        "properties": {
            "group_id": {
                "type": "integer",
                "description": "ID of the device group to delete"
            }
        },
        "required": ["group_id"]
    }
)

MOVE_DEVICE_TO_GROUP_TOOL = Tool(
    name="move-device-to-group",
    description="Move a device into a specific device group. Resolves device/group by id or name substring.",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {"type": "integer", "description": "Device ID (preferred if known)"},
            "device_name": {"type": "string", "description": "Device name (substring match)"},
            "device_search_text": {"type": "string", "description": "Alternate device query (substring)"},
            "target_group_id": {"type": "integer", "description": "Target device group ID"},
            "target_group_name": {"type": "string", "description": "Target device group name (substring match)"},
            "group_search_text": {"type": "string", "description": "Alternate group query (substring)"}
        },
        "anyOf": [
            {"required": ["device_id", "target_group_id"]},
            {"required": ["device_id", "target_group_name"]},
            {"required": ["device_name", "target_group_id"]},
            {"required": ["device_name", "target_group_name"]},
            {"required": ["device_search_text", "target_group_name"]},
            {"required": ["device_search_text", "target_group_id"]}
        ]
    }
)

REMOVE_DEVICE_FROM_GROUP_TOOL = Tool(
    name="remove-device-from-group",
    description="Move a device to the root device group (id=1). Resolves device by id or name substring.",
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {"type": "integer", "description": "Device ID (preferred if known)"},
            "device_name": {"type": "string", "description": "Device name (substring match)"},
            "device_search_text": {"type": "string", "description": "Alternate device query (substring)"}
        },
        "anyOf": [
            {"required": ["device_id"]},
            {"required": ["device_name"]},
            {"required": ["device_search_text"]}
        ]
    }
)

UPDATE_DEVICE_AUTH_MODE_TOOL = Tool(
    name="update-device-auth-mode",
    description=(
        "Set/append/remove authentication operation modes on a device. "
        "Resolve target by device_id/device_name/door_id/door_name. "
        "When both mode_codes and auth_specs are given, mode_codes take precedence."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {"type": "integer", "description": "Target device id to update"},
            "device_name": {"type": "string", "description": "Target device name"},
            "door_id": {"type": "integer", "description": "Door id; entry device will be used"},
            "door_name": {"type": "string", "description": "Door name; entry device will be used"},
            "mode_codes": {
                "type": "array",
                "items": {"type": "integer"},
                "description": "Extended auth mode codes (11..49). Takes precedence over 'auth_specs'."
            },
            "auth_specs": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Specs like 'card+face+fingerprint' or 'face+pin' (ASCII-only)."
            },
            "action": {
                "type": "string",
                "enum": ["set", "add", "remove"],
                "default": "set",
                "description": "How to apply target modes."
            },
            "conflict_policy": {
                "type": "string",
                "enum": ["overwrite", "abort", "merge"],
                "default": "overwrite",
                "description": "Policy when 'add' conflicts with business rules."
            },
            "schedule_id": {
                "type": "integer",
                "default": 1,
                "description": "Schedule id for each operation mode row."
            }
        },
        "anyOf": [
            {"required": ["device_id"]},
            {"required": ["device_name"]},
            {"required": ["door_id"]},
            {"required": ["door_name"]}
        ],
        "oneOf": [
            {"required": ["mode_codes"]},
            {"required": ["auth_specs"]}
        ]
    }
)

UPDATE_DEVICE_FACE_DISTANCE_TOOL = Tool(
    name="update-device-face-distance",
    description=(
        "Update face detection distance only (min fixed to 30cm). "
        "Max snaps to steps 30..130, or 255 when 'over_130' is requested. "
        "Resolve target by device_id/device_name/door_id/door_name."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {"type": "integer", "description": "Target device id to update"},
            "device_name": {"type": "string", "description": "Target device name"},
            "door_id": {"type": "integer", "description": "Door id; entry device will be used"},
            "door_name": {"type": "string", "description": "Door name; entry device will be used"},
            "max_cm": {
                "oneOf": [
                    {"type": "integer", "enum": [30,40,50,60,70,80,90,100,110,120,130]},
                    {"type": "string", "enum": ["over_130"]}
                ],
                "description": "One of 30,40,...,130 or 'over_130' (->255)."
            }
        },
        "anyOf": [
            {"required": ["device_id"]},
            {"required": ["device_name"]},
            {"required": ["door_id"]},
            {"required": ["door_name"]}
        ],
        "required": ["max_cm"]
    }
)

UPDATE_DEVICE_DATE_TYPE_TOOL = Tool(
    name="update-device-date-type",
    description=(
        "Update only the device's display date type via PUT /api/devices/{id}.\n"
        "- Accepts either 'date_type' (0|1|2) or 'date_format' "
        "(\"YYYY/MM/DD\" | \"MM/DD/YYYY\" | \"DD/MM/YYYY\").\n"
        "- Resolution: device_id OR device_name OR door_id OR door_name "
        "(also supports device_search_text via the handler's resolver).\n"
        "- Sends a minimal payload: {\"Device\": {\"display\": {\"date_type\": \"<code>\"}}}.\n"
        "- Does NOT modify any other fields."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            # ---- target resolution (same policy as other device update tools) ----
            "device_id": {"type": "integer", "description": "Target device id"},
            "device_name": {"type": "string", "description": "Target device name (exact or substring depending on resolver)"},
            "device_search_text": {"type": "string", "description": "Alternate device query (substring)"},
            "door_id": {"type": "integer", "description": "Door id; entry device will be used unless 'edge' says otherwise"},
            "door_name": {"type": "string", "description": "Door name (substring) -> entry/exit device"},
            "edge": {
                "type": "string",
                "enum": ["entry", "exit"],
                "description": "When resolving by door, choose entry or exit device (default: entry)"
            },

            # ---- date type selection ----
            "date_type": {
                "oneOf": [
                    {"type": "integer", "enum": [0, 1, 2]},
                    {"type": "string", "enum": ["0", "1", "2"]}
                ],
                "description": "Date type code: 0=YYYY/MM/DD, 1=MM/DD/YYYY, 2=DD/MM/YYYY"
            },
            "date_format": {
                "type": "string",
                "enum": ["YYYY/MM/DD", "MM/DD/YYYY", "DD/MM/YYYY"],
                "description": "Alternative to 'date_type'. Will be mapped to 0|1|2."
            }
        },
        "anyOf": [
            {"required": ["device_id"]},
            {"required": ["device_name"]},
            {"required": ["door_id"]},
            {"required": ["door_name"]},
            {"required": ["device_search_text"]}
        ],
        "oneOf": [
            {"required": ["date_type"]},
            {"required": ["date_format"]}
        ]
    }
)


UPDATE_DEVICE_TIMEZONE_TOOL = Tool(
    name="update-device-timezone",
    description=(
        "Update only Device.system.timezone with a fixed UTC offset (seconds). "
        "Accepts one of: offset_seconds (int), utc_offset string like '+09:00'/'-08:30', "
        "or tz_label (Korean dropdown label, city/abbr like '서울','테헤란','하와이','PST'). "
        "This tool fetches the current device, merges the timezone value, and PUTs back so all other settings remain intact."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            # --- Target resolution (strict) ---
            "device_id": {"type": "integer", "description": "Target device ID (preferred)"},
            "device_name": {"type": "string", "description": "Exact device name (strict match)"},
            "door_id": {"type": "integer", "description": "Resolve via door's entry device"},
            "door_name": {"type": "string", "description": "Resolve via door's entry device (exact)"},

            # --- Timezone spec (one-of) ---
            "offset_seconds": {
                "type": "integer",
                "description": "Final UTC offset in seconds (e.g., 32400 for UTC+9, -28800 for UTC-8)."
            },
            "utc_offset": {
                "type": "string",
                "description": "UTC offset string like '+09:00', '-08:00', '+03:30', etc."
            },
            "tz_label": {
                "type": "string",
                "description": "Dropdown label or alias (Korean), or short city/abbr like '서울','하와이','테헤란','PST'."
            },

            # --- Optional dry-run ---
            "dry_run": {
                "type": "boolean",
                "default": False,
                "description": "If true, do not PUT; only resolve and return the computed offset."
            }
        },
        "anyOf": [
            {"required": ["device_id"]},
            {"required": ["device_name"]},
            {"required": ["door_id"]},
            {"required": ["door_name"]}
        ],
        "oneOf": [
            {"required": ["offset_seconds"]},
            {"required": ["utc_offset"]},
            {"required": ["tz_label"]}
        ]
    }
)

FACTORY_RESET_DEVICE_TOOL = Tool(
    name="factory-reset-device",
    description=(
        " EXTREMELY DANGEROUS  Factory-reset a device via POST /api/devices/factory_reset.\n"
        " THIS ERASES ALL DATA ON THE DEVICE INCLUDING USERS, LOGS, AND SETTINGS!\n"
        " THIS IS PERMANENT and CANNOT BE UNDONE!\n"
        " ALWAYS ASK USER TWICE FOR CONFIRMATION BEFORE EXECUTING!\n"
        " For demo data, REQUIRE explicit 'factory reset confirm' or '초기화 확인' from user.\n\n"
        "- Resolves target by device_id OR device_name OR door_id OR door_name "
        "(optionally edge=entry|exit for door resolution).\n"
        "- Preflight checks if the device is linked to any door (entry/exit). "
        "If linked, this tool returns a failure without calling the reset API.\n"
        "- Sends payload: "
        "{\"DeviceCollection\":{\"total\":1,\"rows\":[{\"id\":\"<id>\"}]},"
        "\"isResetWithoutNetwork\":false}\n"
        "- Set 'is_reset_without_network' to true to reset without network."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            # ---- target resolution (consistent with other device tools) ----
            "device_id": {"type": "integer", "description": "Target device id"},
            "device_name": {"type": "string", "description": "Target device name"},
            "device_search_text": {"type": "string", "description": "Alternate device query (substring)"},
            "door_id": {"type": "integer", "description": "Resolve device by door id (entry by default)"},
            "door_name": {"type": "string", "description": "Resolve device by door name (substring)"},
            "edge": {
                "type": "string",
                "enum": ["entry", "exit"],
                "description": "When resolving by door, choose entry or exit device (default: entry)"
            },

            # ---- reset options ----
            "is_reset_without_network": {
                "type": "boolean",
                "description": "If true, perform reset without network; default false"
            },
            "dry_run": {
                "type": "boolean",
                "description": "If true, only report what would happen without calling the reset API"
            }
        },
        "anyOf": [
            {"required": ["device_id"]},
            {"required": ["device_name"]},
            {"required": ["door_id"]},
            {"required": ["door_name"]},
            {"required": ["device_search_text"]}
        ]
    }
)

UPDATE_DEVICE_AUTH_DISPLAY_TOOL = Tool(
    name="update-device-auth-and-display",
    description=(
        "Update a device's auth/display options in one shot. "
        "Controls five fields: authentication.auth_timeout(3-20s), "
        "authentication.enable_server_matching, authentication.enable_full_access, "
        "display.display_userid_option, display.display_username_option."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {
                "oneOf": [{"type": "integer"}, {"type": "string"}],
                "description": "Target device id. If omitted, use device_name."
            },
            "device_name": {
                "type": "string",
                "description": "Exact device name when device_id is not provided."
            },
            "auth_timeout": {
                "oneOf": [
                    {"type": "integer", "minimum": 3, "maximum": 20},
                    {"type": "string",  "pattern": "^(?:[3-9]|1[0-9]|20)$"}
                ],
                "description": "Authentication wait time in seconds (3-20)."
            },
            "enable_server_matching": {"type": "boolean"},
            "enable_full_access": {"type": "boolean"},
            "display_userid_option": {
                "oneOf": [
                    {"type": "integer", "enum": [0,1,2]},
                    {"type": "string",  "enum": ["all","first","none"]}
                ],
                "description": "User ID display: 0=all, 1=first-only, 2=hidden"
            },
            "display_username_option": {
                "oneOf": [
                    {"type": "integer", "enum": [0,1,2]},
                    {"type": "string",  "enum": ["all","first","none"]}
                ],
                "description": "User name display: 0=all, 1=first-only, 2=hidden"
            },
            "dry_run": {"type": "boolean"}
        },
        "required": [],
        "additionalProperties": False
    }
)

BULK_ADD_DEVICES_TOOL = Tool(
    name="bulk-add-devices",
    description=(
        "Add multiple devices by iterating the single 'add-device' logic sequentially.\n"
        "- Input 'devices': array of objects with the SAME schema as 'add-device'.\n"
        "- For each item, it calls the existing add-device implementation and aggregates results.\n"
        "- Set 'continue_on_error' (default: true) to keep going after a failure."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "devices": {
                "type": "array",
                "description": "List of device objects; each item uses the same fields as 'add-device'.",
                "items": {
                    "type": "object",
                    "properties": {
                        "device_id":      {"type": "integer", "description": "Unique device ID"},
                        "name":           {"type": "string",  "description": "Device name"},
                        "device_type_id": {"type": "integer", "description": "Optional device type id"},
                        "device_type_name": {"type": "string", "description": "Optional device type name"},
                        "ip_address":     {"type": "string",  "description": "IP address"},
                        "port":           {"type": "integer", "description": "Port (default 51211)"},
                        "use_ssl":        {"type": "boolean", "description": "Use SSL"},
                        "device_group_id":{"type": "integer", "description": "Target device group id"}
                    },
                    "required": ["device_id", "name", "ip_address", "device_group_id"]
                }
            },
            "continue_on_error": {
                "type": "boolean",
                "default": True,
                "description": "If false, stop at the first failure."
            }
        },
        "required": ["devices"]
    }
)

UPDATE_DEVICE_NETWORK_TOOL = Tool(
    name="update-device-network",
    description=(
        "Update TCP/IP network settings of a device. "
        "Maps the UI fields exactly: DHCP toggle, IP address, subnet mask, gateway, DNS server, and device port. "
        "If dhcp_enabled=true, static fields (ip/subnet/gateway/dns) are ignored."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            # ---- Target resolution (same policy as other device tools) ----
            "device_id": {"type": "integer", "description": "Target device id"},
            "device_name": {"type": "string", "description": "Target device name"},
            "device_search_text": {"type": "string", "description": "Alternate device query (substring)"},
            "door_id": {"type": "integer", "description": "Resolve via door id (entry by default)"},
            "door_name": {"type": "string", "description": "Resolve via door name (substring)"},
            "edge": {
                "type": "string",
                "enum": ["entry", "exit"],
                "description": "When resolving by door, choose entry or exit device (default: entry)"
            },

            # ---- Network fields (mapped from the screenshot) ----
            "dhcp_enabled": {"type": "boolean", "description": "When true, static fields are ignored and disabled."},
            "ip_address": {
                "type": "string",
                "description": "IPv4 address (required when dhcp_enabled=false)",
                "pattern": "^(?:(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)$"
            },
            "subnet_mask": {
                "type": "string",
                "description": "IPv4 subnet mask (required when dhcp_enabled=false)",
                "pattern": "^(?:(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)$"
            },
            "gateway": {
                "type": "string",
                "description": "IPv4 gateway (optional when dhcp_enabled=false)",
                "pattern": "^(?:(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)$"
            },
            "dns_server": {
                "type": "string",
                "description": "IPv4 DNS server (optional when dhcp_enabled=false)",
                "pattern": "^(?:(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)$"
            },
            "device_port": {
                "type": "integer",
                "description": "Device port (default 51211)",
                "minimum": 1,
                "maximum": 65535,
                "default": 51211
            }
        },
        "allOf": [
            # target resolution: require any one of the selectors
            {
                "anyOf": [
                    {"required": ["device_id"]},
                    {"required": ["device_name"]},
                    {"required": ["device_search_text"]},
                    {"required": ["door_id"]},
                    {"required": ["door_name"]}
                ]
            },
            # DHCP gating: if dhcp_enabled=false, ip_address+subnet_mask required
            {
                "if": {
                    "properties": {"dhcp_enabled": {"const": False}},
                    "required": ["dhcp_enabled"]
                },
                "then": {
                    "required": ["ip_address", "subnet_mask"]
                }
            }
        ],
        "required": ["dhcp_enabled"]
    }
)

UPDATE_DEVICE_SERIAL_COMM_TOOL = Tool(
    name="update-device-serial-comm",
    description=(
        "Update RS-485 serial communication settings of a device via PUT /api/devices/{id}.\n"
        "- Fields mirror the UI: rs485_mode (Master/Slave/DeviceDefault), baud_rate, show_osdp_result.\n"
        "- If rs485_mode is 'master', 'show_osdp_result' must NOT be provided (UI hides it).\n"
        "- If rs485_mode is 'slave' (and the model supports it), 'show_osdp_result' may be set:\n"
        "  - 0|'controller' -> Display controller's auth result\n"
        "  - 1|'device'     -> Display device's own auth result\n"
        "- All unspecified properties are preserved exactly as-is by the handler (merge patch)."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            # ---- Target resolution (consistent with other device tools) ----
            "device_id": {"type": "integer", "description": "Target device id"},
            "device_name": {"type": "string", "description": "Target device name (exact match or resolver policy)"},
            "device_search_text": {"type": "string", "description": "Alternate device query (substring)"},
            "door_id": {"type": "integer", "description": "Resolve via door id (entry by default)"},
            "door_name": {"type": "string", "description": "Resolve via door name (substring)"},
            "edge": {
                "type": "string",
                "enum": ["entry", "exit"],
                "description": "When resolving by door, choose entry or exit device (default: entry)"
            },

            # ---- Serial comm fields (mirroring the screenshots) ----
            "rs485_mode": {
                "oneOf": [
                    {"type": "integer", "enum": [1, 2, 3]},
                    {"type": "string",  "enum": ["master", "slave", "device_default"]}
                ],
                "description": "RS-485 role: 1|master, 2|slave, 3|device_default (follow device default)."
            },
            "baud_rate": {
                "type": "integer",
                "enum": [9600, 19200, 38400, 57600, 115200],
                "description": "RS-485 baud rate."
            },
            "show_osdp_result": {
                "oneOf": [
                    {"type": "integer", "enum": [0, 1]},
                    {"type": "string",  "enum": ["controller", "device"]}
                ],
                "description": (
                    "Only applicable when rs485_mode='slave'. "
                    "0|'controller' = show controller result, 1|'device' = show device result."
                )
            },

            # ---- Optional dry-run (no PUT; return computed payload preview) ----
            "dry_run": {
                "type": "boolean",
                "default": False,
                "description": "If true, do not PUT; only resolve and return the computed payload."
            }
        },
        # Require any one target selector
        "allOf": [
            {
                "anyOf": [
                    {"required": ["device_id"]},
                    {"required": ["device_name"]},
                    {"required": ["device_search_text"]},
                    {"required": ["door_id"]},
                    {"required": ["door_name"]}
                ]
            },
            # If rs485_mode is provided and indicates MASTER, 'show_osdp_result' must not be present
            {
                "if": {
                    "properties": {
                        "rs485_mode": {
                            "oneOf": [
                                {"const": 1},
                                {"const": "master"}
                            ]
                        }
                    },
                    "required": ["rs485_mode"]
                },
                "then": {
                    "not": {"required": ["show_osdp_result"]}
                }
            }
        ],
        "required": ["rs485_mode", "baud_rate"]
    }
)

UPDATE_DEVICE_SERVER_COMM_TOOL = Tool(
    name="update-device-server-comm",
    description=(
        "Update a device's Server Communication settings via PUT /api/devices/{id}. "
        "Fields map 1:1 to the UI: [Connect to server from device], [Server address], [Server port]. "
        "Resolves target by id/name/door, merges minimal fields, preserves other fields."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            # ---- Target resolution (same policy as other device tools) ----
            "device_id":          {"type": "integer", "description": "Target device id"},
            "device_name":        {"type": "string",  "description": "Target device name (exact/contains per handler policy)"},
            "device_search_text": {"type": "string",  "description": "Alternative substring search text"},
            "door_id":            {"type": "integer", "description": "Resolve via door id"},
            "door_name":          {"type": "string",  "description": "Resolve via door name"},
            "edge": {
                "type": "string", "enum": ["entry", "exit"],
                "description": "When resolving via door, choose entry or exit (default: entry)"
            },

            # ---- Server communication fields (UI mapping) ----
            "connect_from_device": {
                "type": "boolean",
                "description": "Checkbox 'Connect to server from device' (True=enable)"
            },
            "server_address": {
                "type": "string",
                "description": "Server address (IPv4 or hostname)"
            },
            "server_port": {
                "type": "integer",
                "minimum": 1, "maximum": 65535,
                "default": 51212,
                "description": "Server port (default 51212)"
            },

            # ---- Dry-run support ----
            "dry_run": {
                "type": "boolean",
                "default": False,
                "description": "If true, do not PUT; return payload preview only"
            }
        },
        "allOf": [
            {
                "anyOf": [
                    {"required": ["device_id"]},
                    {"required": ["device_name"]},
                    {"required": ["device_search_text"]},
                    {"required": ["door_id"]},
                    {"required": ["door_name"]}
                ]
            },
            {
                "anyOf": [
                    {"required": ["connect_from_device"]},
                    {"required": ["server_address"]},
                    {"required": ["server_port"]}
                ]
            }
        ],
        "required": []
    }
)

UPDATE_DEVICE_FINGERPRINT_TOOL = Tool(
    name="update-device-fingerprint",
    description=(
        "Update fingerprint-related settings via PUT /api/devices/{id}. "
        "Resolves target by device_id/device_name/device_search_text or door_id/door_name (edge=entry|exit). "
        "Accepts EN/KR enums, validates ranges, and sends a minimal merged payload for Device.fingerprint "
        "and Device.authentication.matching_timeout."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            # ---- target resolution ----
            "device_id": {
                "oneOf": [{"type": "integer"}, {"type": "string"}],
                "description": "Device id"
            },
            "device_name": {
                "type": "string",
                "description": "Device name (exact or substring depending on resolver)"
            },
            "device_search_text": {
                "type": "string",
                "description": "Alternate device query (substring)"
            },
            "door_id": {
                "type": "integer",
                "description": "Resolve by door id (entry by default unless edge is specified)"
            },
            "door_name": {
                "type": "string",
                "description": "Resolve by door name (substring)"
            },
            "edge": {
                "type": "string",
                "enum": ["entry", "exit"],
                "description": "Edge selector when resolving by door"
            },

            # ---- fingerprint options ----
            "security_level": {
                "oneOf": [
                    {"type": "integer", "enum": [0, 1, 2]},
                    {"type": "string", "enum": ["normal", "secure", "most secure", "high", "highest"]}
                ],
                "description": "Fingerprint 1:N security level (0=normal, 1=secure, 2=most secure) -> fingerprint.security_level"
            },
            "fast_mode": {
                "oneOf": [
                    {"type": "integer", "enum": [0, 1, 2, 3]},
                    {"type": "string", "enum": ["auto", "normal", "fast", "fastest"]}
                ],
                "description": "Fingerprint Fast Mode (0=auto, 1=normal, 2=fast, 3=fastest) -> fingerprint.fast_mode"
            },
            "sensitivity": {
                "type": "integer",
                "minimum": 1,
                "maximum": 7,
                "description": "Sensor sensitivity (1..7) -> fingerprint.sensitivity"
            },
            "scan_wait_time": {
                "type": "integer",
                "minimum": 1,
                "maximum": 20,
                "description": "Scan wait time in seconds (1..20) -> fingerprint.scan_timeout"
            },
            "matching_wait_time": {
                "type": "integer",
                "minimum": 1,
                "maximum": 20,
                "description": "Matching wait time in seconds (1..20) -> authentication.matching_timeout"
            },
            "show_image": {
                "type": "boolean",
                "description": "Display fingerprint image -> fingerprint.show_image"
            },
            "sensor_mode": {
                "oneOf": [
                    {"type": "integer", "enum": [0, 1]},
                    {"type": "string", "enum": ["auto on", "always on", "auto_on", "always_on", "auto", "always"]}
                ],
                "description": "Sensor Mode (0=Auto On, 1=Always On) -> fingerprint.sensor_mode"
            },
            "advanced_enrollment": {
                "type": "boolean",
                "description": "Enrollment quality check -> fingerprint.advanced_enrollment"
            },
            "lfd_level": {
                "oneOf": [
                    {"type": "integer", "enum": [0, 1, 2, 3]},
                    {"type": "string", "enum": ["off", "normal", "strong", "very strong", "very_strong"]}
                ],
                "description": "Fingerprint LFD level (0=Off, 1=Normal, 2=Strong, 3=Very Strong) -> fingerprint.lfd_level"
            },
            "duplicate_check": {
                "type": "boolean",
                "description": "Duplicate check -> fingerprint.duplicate_check"
            },

            "dry_run": {
                "type": "boolean",
                "default": False,
                "description": "If true, do not PUT; return payload preview only"
            }
        },
        "allOf": [
            {
                "anyOf": [
                    {"required": ["device_id"]},
                    {"required": ["device_name"]},
                    {"required": ["device_search_text"]},
                    {"required": ["door_id"]},
                    {"required": ["door_name"]}
                ]
            }
        ],
        "additionalProperties": False
    }
)

UPDATE_DEVICE_FACE_TOOL = Tool(
    name="update-device-face",
    description=(
        "Update face-related settings via PUT /api/devices/{id}.\n"
        "- Always resolve device_name/device_search_text to device_id first (never PUT by name).\n"
        "- English-only enums/toggles; booleans are real booleans; enums/values are integers.\n"
        "- Enrollment time is 10..20 seconds (step 1, no snapping).\n"
        "- Max head pose angle must be one of {15,30,45,60,75,90}.\n"
        "- Detection distances use 10-step values; max also accepts 'over_130' -> 255.\n"
        "- Sends a minimal payload: {\"Device\": {\"face\": { ... }}} only."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {"oneOf": [{"type": "integer"}, {"type": "string"}], "description": "Device id"},
            "device_name": {"type": "string", "description": "Device name (resolved to id internally)"},
            "device_search_text": {"type": "string", "description": "Alternate device query (resolved to id internally)"},
            "door_id": {"type": "integer", "description": "Optional: resolve by door (fallback uses generic resolver)"},
            "door_name": {"type": "string", "description": "Optional: resolve by door (fallback uses generic resolver)"},
            "edge": {"type": "string", "enum": ["entry","exit"], "description": "Edge selector for door resolution"},
            "security_level": {
                "oneOf": [
                    {"type": "integer", "enum": [0,1,2]},
                    {"type": "string",  "enum": ["normal","secure","most secure","most_secure"]}
                ],
                "description": "-> face.security_level"
            },
            "motion_sensor": {
                "oneOf": [
                    {"type": "integer", "enum": [0,1,2,3]},
                    {"type": "string",  "enum": ["off","low","medium","high"]}
                ],
                "description": "-> face.sensitivity"
            },
            "sensitivity": {  # alias
                "oneOf": [
                    {"type": "integer", "enum": [0,1,2,3]},
                    {"type": "string",  "enum": ["off","low","medium","high"]}
                ],
                "description": "[Alias of motion_sensor] -> face.sensitivity"
            },
            "lfd_level": {
                "oneOf": [
                    {"type": "integer", "enum": [0,1,2,3]},
                    {"type": "string",  "enum": ["normal","secure","more secure","most secure","more_secure","most_secure"]}
                ],
                "description": "-> face.lfd_level"
            },
            "enroll_timeout": {"type": "integer", "minimum": 10, "maximum": 20, "description": "-> face.scan_wait_time"},
            "max_rotation": {"type": "integer", "enum": [15,30,45,60,75,90], "description": "-> face.max_rotation"},
            "detect_distance_min": {"type": "integer", "enum": [30,40,50,60,70,80,90,100,110,120,130], "description": "-> face.detection_distance_min"},
            "detect_distance_max": {
                "oneOf": [
                    {"type": "integer", "enum": [30,40,50,60,70,80,90,100,110,120,130]},
                    {"type": "integer", "enum": [255]},
                    {"type": "string",  "enum": ["over_130","above_130","over-130","130_plus","130plus"]}
                ],
                "description": "-> face.detection_distance_max"
            },
            "face_width_min": {"type": "integer", "minimum": 0, "maximum": 100, "description": "-> face.face_width_min"},
            "face_width_max": {"type": "integer", "minimum": 0, "maximum": 100, "description": "-> face.face_width_max"},
            "operation_mode": {
                "oneOf": [
                    {"type": "integer", "enum": [0,1]},
                    {"type": "string",  "enum": ["normal","fusion"]}
                ],
                "description": "-> face.operation_mode"
            },
            "wide_search": {"type": "boolean", "description": "-> face.face_wide_search"},
            "fast_enroll": {"type": "boolean", "description": "-> face.quick_enrollment"},
            "save_image": {"type": "boolean", "description": "-> face.store_visual_face_image"},
            "duplicate_check": {"type": "boolean", "description": "-> face.duplicate_check"},
            "light_brightness": {
                "oneOf": [
                    {"type": "integer", "enum": [0,1,3]},
                    {"type": "string",  "enum": ["normal","high","off","not use","not_use"]}
                ],
                "description": "Mapped to face.proximity_level (0/1/3 only; 2 is unused)"
            },
            "dry_run": {"type": "boolean", "default": False, "description": "If true, do not PUT; return payload preview only"}
        },
        "allOf": [{
            "anyOf": [
                {"required": ["device_id"]},
                {"required": ["device_name"]},
                {"required": ["device_search_text"]},
                {"required": ["door_id"]},
                {"required": ["door_name"]}
            ]
        }],
        "additionalProperties": False
    }
)

WIEGAND_CSN_FORMATS = {
    "26 bit SIA Standard-H10301": "0",
    "HID 37 bit-H10302": "1",
    "HID 37 bit-H10304": "2",
    "HID Corporate 1000": "3",
    "HID Corporate 1000 48bit": "4",
    "MIFARE CSN 32bit": "5",
    "MIFARE CSN 34bit (Parity)": "6",
    "DESFire 56bit": "7",
    "DESFire 58bit (Parity)": "8",
    # ids 9..14 are empty in your capture (reserved/unused)
}


UPDATE_DEVICE_CARD_CSN_TOOL = Tool(
    name="update-device-card-csn",
    description=(
        "Update only the 'Card Type > CSN Card' fields via PUT /api/devices/{id}. "
        "Minimal payload: patches Device.card (and optionally Device.wiegand.wiegand_csn_id when format_type='wiegand'). "
        "Mappings: csn_enabled->card.use_csn, em4100_enabled->card.use_em, mifare_felica_enabled->card.use_mifare_felica, "
        "byte_order->card.byte_order (LSB='1', MSB='0'), format_type->card.use_wiegand_format ('wiegand'='true', 'normal'='false'). "
        "If a property is omitted, it will not be updated. "
        "Static Wiegand name->id map is embedded (e.g., 'DESFire 56bit' -> '7'). "
        "Runtime rule: If any CSN sub-option is enabled or a Wiegand format is selected, the tool will auto-set csn_enabled=true. "
        "Also, when csn_enabled=true and neither EM4100 nor MIFARE/Felica is chosen, both will be auto-enabled."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "device_id": {"type": "integer", "description": "Target device id"},
            "device_name": {"type": "string", "description": "Target device name (resolver-dependent)"},
            "device_search_text": {"type": "string", "description": "Alternate device query (substring)"},
            "door_id": {"type": "integer", "description": "Resolve via door id (entry by default)"},
            "door_name": {"type": "string", "description": "Resolve via door name (substring)"},
            "edge": {"type": "string", "enum": ["entry", "exit"], "description": "Door edge selector when resolving by door"},

            # CSN-only fields
            "csn_enabled": {"type": "boolean", "description": "Map to Device.card.use_csn (required)"},
            "em4100_enabled": {"type": "boolean", "description": "Map to Device.card.use_em"},
            "mifare_felica_enabled": {"type": "boolean", "description": "Map to Device.card.use_mifare_felica"},

            # Byte order: LSB -> '1', MSB -> '0'
            "byte_order": {
                "oneOf": [
                    {"type": "string", "enum": ["LSB", "MSB", "lsb", "msb", "0", "1"]},
                    {"type": "integer", "enum": [0, 1]}
                ],
                "description": "Map to Device.card.byte_order (LSB='1', MSB='0')."
            },

            # Format type toggle (does NOT pick a format id unless provided)
            "format_type": {
                "type": "string",
                "enum": ["normal", "wiegand"],
                "description": "Map to Device.card.use_wiegand_format"
            },

            # Human-friendly Wiegand name
            "wiegand_format": {
                "type": "string",
                "enum": [
                    "26 bit SIA Standard-H10301",
                    "HID 37 bit-H10302",
                    "HID 37 bit-H10304",
                    "HID Corporate 1000",
                    "HID Corporate 1000 48bit",
                    "MIFARE CSN 32bit",
                    "MIFARE CSN 34bit (Parity)",
                    "DESFire 56bit",
                    "DESFire 58bit (Parity)"
                ],
                "description": (
                    "Human-friendly Wiegand CSN name. Will be translated to id using a static map. "
                    "If both wiegand_format and wiegand_format_id are given, they must match."
                )
            },

            # Wiegand CSN format id
            "wiegand_format_id": {
                "oneOf": [
                    {"type": "integer"},
                    {"type": "string", "pattern": "^-?\\d+$"}
                ],
                "description": "Map to Device.wiegand.wiegand_csn_id.id (e.g., 7 for 'DESFire 56bit')."
            }
        },

        "required": ["csn_enabled"],

        "allOf": [
            # 1) Require at least one target selector (unchanged)
            {
                "anyOf": [
                    {"required": ["device_id"]},
                    {"required": ["device_name"]},
                    {"required": ["device_search_text"]},
                    {"required": ["door_id"]},
                    {"required": ["door_name"]}
                ]
            },

            # 2) If format_type='normal' -> do NOT allow Wiegand selection (unchanged)
            {
                "if": {"properties": {"format_type": {"const": "normal"}}, "required": ["format_type"]},
                "then": {
                    "not": {
                        "anyOf": [
                            {"required": ["wiegand_format_id"]},
                            {"required": ["wiegand_format"]}
                        ]
                    }
                }
            }
        ],

        "additionalProperties": False
    }
)

LIST_WAITING_DEVICES_TOOL = Tool(
    name="list-waiting-devices",
    description=(
        "List devices waiting to be added to BioStar 2 server. "
        "When devices connect directly to the server (not via TCP/UDP search), "
        "they appear in the waiting list. Use this to discover devices before adding them. "
        "GET /api/devices/waiting returns devices with connection_mode='1' (Server -> Device)."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "ip_filter": {
                "type": "string",
                "description": "Filter devices by IP address (substring match)"
            },
            "device_type_id": {
                "type": "integer",
                "description": "Filter by device type ID (e.g., 35 for BioStation 3)"
            }
        },
        "required": []
    }
)

ADD_WAITING_DEVICE_TOOL = Tool(
    name="add-waiting-device",
    description=(
        "Add a device from the waiting list to BioStar 2 server. "
        "This is an alternative to tcp-search/add-device. "
        "The device must already be in the waiting list (check with list-waiting-devices first). "
        "POST /api/devices with waiting device details."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "waiting_device_id": {
                "oneOf": [{"type": "integer"}, {"type": "string"}],
                "description": "Device ID from the waiting list (required)"
            },
            "name": {
                "type": "string",
                "description": "Name for the device. If not provided, auto-generates from device type and ID"
            },
            "device_type_id": {
                "type": "integer",
                "description": "Device type ID (usually obtained from waiting device info)"
            },
            "ip_address": {
                "type": "string",
                "description": "IP address (from waiting device info)"
            },
            "device_group_id": {
                "type": "integer",
                "description": "Device group ID to assign (default: 1 for root group)",
                "default": 1
            },
            "use_alphanumeric": {
                "type": "boolean",
                "description": "Enable alphanumeric user IDs",
                "default": True
            },
            "follower_server_id": {
                "oneOf": [{"type": "integer"}, {"type": "string"}],
                "description": "Follower server ID (default: 1)",
                "default": 1
            }
        },
        "required": ["waiting_device_id"]
    }
)

BULK_ADD_WAITING_DEVICES_TOOL = Tool(
    name="bulk-add-waiting-devices",
    description=(
        "Add multiple devices from the waiting list in bulk. "
        "Each device must be in the waiting list. Use list-waiting-devices first to get device IDs. "
        "Iterates through each device and calls add-waiting-device logic."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "waiting_device_ids": {
                "type": "array",
                "items": {"oneOf": [{"type": "integer"}, {"type": "string"}]},
                "description": "Array of waiting device IDs to add"
            },
            "device_group_id": {
                "type": "integer",
                "description": "Device group ID for all devices (default: 1)",
                "default": 1
            },
            "name_prefix": {
                "type": "string",
                "description": "Optional prefix for auto-generated device names"
            },
            "use_alphanumeric": {
                "type": "boolean",
                "description": "Enable alphanumeric user IDs for all devices",
                "default": True
            },
            "continue_on_error": {
                "type": "boolean",
                "description": "Continue adding remaining devices if one fails",
                "default": True
            }
        },
        "required": ["waiting_device_ids"]
    }
)

DEVICE_TOOLS = [
    LIST_DEVICES_TOOL,
    GET_DEVICE_TOOL,
    ADD_DEVICE_TOOL,
    UPDATE_DEVICE_TOOL,
    REBOOT_DEVICE_TOOL,
    GET_DEVICE_STATUS_TOOL,
    SCAN_DEVICES_TOOL,
    TCP_SEARCH_TOOL,
    UDP_SEARCH_TOOL,
    DISCONNECT_DEVICE_TOOL,
    REMOVE_DEVICE_TOOL,
    SYNC_DEVICE_TIME_TOOL,
    CLEAR_DEVICE_LOG_TOOL,
    LOCK_DEVICE_TOOL,
    UNLOCK_DEVICE_TOOL,
    GET_DEVICE_GROUPS_TOOL,
    GET_DEVICE_GROUP_TOOL,
    CREATE_DEVICE_GROUP_TOOL,
    UPDATE_DEVICE_GROUP_TOOL,
    DELETE_DEVICE_GROUP_TOOL,
    MOVE_DEVICE_TO_GROUP_TOOL,
    REMOVE_DEVICE_FROM_GROUP_TOOL,
    UPDATE_DEVICE_AUTH_MODE_TOOL,
    UPDATE_DEVICE_FACE_DISTANCE_TOOL,
    UPDATE_DEVICE_DATE_TYPE_TOOL,
    UPDATE_DEVICE_TIMEZONE_TOOL,
    FACTORY_RESET_DEVICE_TOOL,
    BULK_ADD_DEVICES_TOOL,
    UPDATE_DEVICE_AUTH_DISPLAY_TOOL,
    UPDATE_DEVICE_NETWORK_TOOL,
    UPDATE_DEVICE_SERIAL_COMM_TOOL,
    UPDATE_DEVICE_SERVER_COMM_TOOL,
    UPDATE_DEVICE_FINGERPRINT_TOOL,
    UPDATE_DEVICE_FACE_TOOL,
    UPDATE_DEVICE_CARD_CSN_TOOL,
    LIST_WAITING_DEVICES_TOOL,
    ADD_WAITING_DEVICE_TOOL,
    BULK_ADD_WAITING_DEVICES_TOOL
]
