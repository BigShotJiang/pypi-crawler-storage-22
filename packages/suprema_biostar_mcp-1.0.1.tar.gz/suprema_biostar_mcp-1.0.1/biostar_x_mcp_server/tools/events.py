from mcp.types import Tool

GET_EVENT_TYPES_TOOL = Tool(
    name="get-event-types",
    description=(
        "List event types from BioStar 2 via /api/event_types with useful filters. "
        "Server flags: is_break_glass, setting_alert, setting_all. "
        "Client-side filters: search, codes, only_alertable, only_enable_alert. "
        "Supports sorting, limit/offset, and grouping."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "is_break_glass": {
                "type": "boolean",
                "description": "If true, list user-renamed (break-glass) names. When true and others not specified, setting_alert/setting_all default to false.",
                "default": False
            },
            "setting_alert": {
                "type": "boolean",
                "description": "If true, list alertable event types (server-side filter).",
                "default": True
            },
            "setting_all": {
                "type": "boolean",
                "description": "If true, list all event types (server-side filter).",
                "default": True
            },
            "search": {
                "type": "string",
                "description": "Case-insensitive contains across code, name, and description."
            },
            "codes": {
                "type": "array",
                "items": {"type": ["string", "number"]},
                "description": "Restrict to specific event code(s)."
            },
            "only_alertable": {
                "type": "boolean",
                "description": "Keep only items with alertable == true.",
                "default": False
            },
            "only_enable_alert": {
                "type": "boolean",
                "description": "Keep only items with enable_alert == true.",
                "default": False
            },
            "sort_by": {
                "type": "string",
                "enum": ["code", "name"],
                "description": "Sort field (default: code).",
                "default": "code"
            },
            "sort_desc": {
                "type": "boolean",
                "description": "Descending sort if true.",
                "default": False
            },
            "offset": {
                "type": "integer",
                "description": "Start index for slicing.",
                "default": 0
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of items to return (client-side slicing)."
            },
            "group_by": {
                "type": "string",
                "enum": ["none", "alertable", "enable_alert"],
                "description": "Group the result by a boolean field.",
                "default": "none"
            }
        },
        "required": []
    }
)

SEARCH_EVENTS_TOOL = Tool(
    name="search-events",
    description="""Advanced search for events with multiple filter criteria.

    CRITICAL DATE/TIME RULES:
    - If no date specified by user, use CURRENT date/time (last 24 hours from NOW)
    - NEVER hardcode dates like 2024-XX-XX
    - Calculate dates dynamically from current system time
    - Format: "YYYY-MM-DDTHH:MM:SS" (without timezone, server will convert to UTC)
    - Example: "2025-11-07T00:00:00" (NOT "2025-11-07T00:00:00.000Z")

    USER SEARCH:
    - Use user_id parameter (NOT conditions array) for filtering by user ID
    - Use user_name parameter to search by name (will be resolved to user_id)
    """,
    inputSchema={
        "type": "object",
        "properties": {
            "conditions": {
                "type": "array",
                "description": "Array of search conditions (for advanced filters only, do NOT use for datetime or user_id)",
                "items": {
                    "type": "object",
                    "properties": {
                        "column": {"type": "string"},
                        "operator": {
                            "type": "integer",
                            "enum": [0, 1, 2, 3, 4, 5, 6]
                        },
                        "value": {
                            "type": "array",
                            "items": {"type": ["string","number"]}
                        },
                        "values": {
                            "type": "array",
                            "items": {"type": ["string","number"]}
                        }
                    },
                    "required": ["column", "operator"]
                }
            },
            "user_id": {
                "type": ["string","number"],
                "description": "User ID to filter events (e.g., '61061'). Use this instead of conditions array."
            },
            "user_name": {
                "type": "string",
                "description": "User name to filter events. Server will resolve name to user_id."
            },
            "start_datetime": {
                "type": "string",
                "description": "Start datetime: 'YYYY-MM-DDTHH:MM:SS' (e.g., '2025-11-07T00:00:00'). WITHOUT timezone. Server converts to UTC."
            },
            "end_datetime": {
                "type": "string",
                "description": "End datetime: 'YYYY-MM-DDTHH:MM:SS' (e.g., '2025-11-07T23:59:59'). WITHOUT timezone. Server converts to UTC."
            },
            "limit": {"type": "integer", "default": 100},
            "offset": {"type": "integer", "default": 0},
            "order_by": {"type": "string", "default": "datetime"},
            "order_type": {"type": "string", "enum": ["asc","desc"], "default": "desc"}
        },
        "required": []
    }
)


GET_REALTIME_EVENTS_TOOL = Tool(
    name="get-realtime-events",
    description="Connect to BioStar 2 websocket for real-time event monitoring",
    inputSchema={
        "type": "object",
        "properties": {
            "duration": {
                "type": "integer",
                "description": "Duration to monitor events in seconds (max: 300)",
                "maximum": 300,
                "default": 60
            },
            "event_types": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Filter real-time events by specific event type IDs"
            }
        },
        "required": []
    }
)

GET_ACCESS_LOGS_TOOL = Tool(
    name="get-access-logs",
    description="""Get access control specific logs (simplified event search focused on access).

    IMPORTANT: If no date specified, defaults to last 24 hours from current system time.
    NEVER use hardcoded dates like 2024-XX-XX. Always calculate from NOW.
    """,
    inputSchema={
        "type": "object",
        "properties": {
            "start_datetime": {
                "type": "string",
                "description": "Start datetime in ISO 8601 format (e.g., \"2025-10-27T00:00:00.000Z\"). If not provided, defaults to 24 hours ago from NOW. NEVER use hardcoded dates."
            },
            "end_datetime": {
                "type": "string",
                "description": "End datetime in ISO 8601 format (e.g., \"2025-10-27T23:59:59.999Z\"). If not provided, defaults to NOW. NEVER use hardcoded dates."
            },
            "user_name": {
                "type": "string",
                "description": "Filter by user name (partial match)"
            },
            "success_only": {
                "type": "boolean",
                "description": "Show only successful access attempts",
                "default": False
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of logs to retrieve",
                "default": 100
            }
        },
        "required": []
    }
)

EXPORT_EVENTS_CSV_TOOL = Tool(
    name="export-events-csv",
    description="Export event logs to CSV via /api/events/export and copy the file to the Windows Downloads folder.",
    inputSchema={
        "type": "object",
        "properties": {
            "start_datetime": {"type": "string", "description": "Start datetime (ISO 8601 with Z). If 'conditions' omitted, this and end_datetime build a BETWEEN."},
            "end_datetime": {"type": "string", "description": "End datetime (ISO 8601 with Z)."},
            "conditions": {
                "type": "array",
                "description": "Custom conditions for the Query. If provided, takes precedence.",
                "items": {
                    "type": "object",
                    "properties": {
                        "column": {"type": "string"},
                        "operator": {"type": "integer"},
                        "values": {"type": "array", "items": {"type": ["string","number"]}}
                    },
                    "required": ["column","operator","values"]
                }
            },
            "user_id": {
                "type": ["string","number"],
                "description": "Convenience filter: constrains to this user_id (mapped to column 'user_id.user_id')."
            },
            "user_name": {
                "type": "string",
                "description": "Convenience filter: resolve name -> user_id and filter (exact match preferred)."
            },
            "event_types": {
                "type": "array",
                "items": {"type": ["string","number"]},
                "description": "Convenience filter: adds EQUAL condition on event_type_id with provided values."
            },
            "columns": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Columns to export (default matches BioStar example).",
                "default": ["datetime","door_id.name","device_id.id","device_id.name","user_group_id","user_id","temperature","event_type_id","tna_key"]
            },
            "headers": {
                "type": "array",
                "items": {"type": "string"},
                "description": "CSV headers (must match columns length).",
                "default": ["Date","Door","Device ID","Device","User Group","User","Temperature","Event","TNA Key"]
            },
            "offset": {"type": "integer", "description": "Offset for pagination.", "default": 0},
            "time_offset_minutes": {"type": "integer", "description": "Timezone offset in minutes, e.g., 480 for UTC+8.", "default": 0},
            "use_centigrade": {"type": "boolean", "description": "Whether to export temperature in centigrade.", "default": True},
            "copy_to_downloads": {"type": "boolean", "description": "Copy exported CSV to Windows Downloads.", "default": True},
            "dest_dir": {"type": "string", "description": "Optional absolute destination directory (overrides Downloads)."},
            "target_username": {"type": "string", "description": "If provided, copies to C:\\Users\\<name>\\Downloads."},
            "filename": {"type": "string", "description": "Legacy/unused: server decides filename. Returned as 'filename' in response.", "default": "events_export.csv"}
        },
        "required": ["start_datetime", "end_datetime"]
    }
)

GET_TEMPERATURE_LOGS_TOOL = Tool(
    name="get-temperature-logs",
    description="Get temperature measurement logs from thermal cameras",
    inputSchema={
        "type": "object",
        "properties": {
            "start_datetime": {
                "type": "string",
                "description": "Start datetime for temperature log search in ISO 8601 format with Z suffix (e.g., \"2025-07-26T15:00:00.000Z\")"
            },
            "end_datetime": {
                "type": "string",
                "description": "End datetime for temperature log search in ISO 8601 format with Z suffix (e.g., \"2025-08-02T14:59:59.000Z\")"
            },
            "user_id": {
                "type": "string",
                "description": "Filter by specific user ID"
            },
            "abnormal_only": {
                "type": "boolean",
                "description": "Show only abnormal temperature readings",
                "default": False
            },
            "temperature_threshold": {
                "type": "number",
                "description": "Temperature threshold in Celsius (e.g., 37.5)",
                "minimum": 35.0,
                "maximum": 42.0
            }
        },
        "required": []
    }
)

# Export all tools
EVENT_TOOLS = [
    GET_EVENT_TYPES_TOOL,
    SEARCH_EVENTS_TOOL,
    GET_REALTIME_EVENTS_TOOL,
    GET_ACCESS_LOGS_TOOL,
    EXPORT_EVENTS_CSV_TOOL,
    GET_TEMPERATURE_LOGS_TOOL
]
