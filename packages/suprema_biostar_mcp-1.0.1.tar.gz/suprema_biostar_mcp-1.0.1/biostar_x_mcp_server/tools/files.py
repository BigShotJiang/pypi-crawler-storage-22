from mcp.types import Tool

# File handling tools for processing uploaded files
READ_UPLOADED_FILE_TOOL = Tool(
    name="read-uploaded-file",
    description=(
        "Read the content of an uploaded file from the current request context. "
        "Use this when the user has attached files (CSV, PDF, PNG, JPEG, JPG, etc.) to their message. "
        "Returns the file content as text (for CSV/text), OCR extracted text (for images), or base64 (for binary/PDF files). "
        "For image files (PNG, JPEG, JPG), automatically performs OCR to extract text content. "
        "This tool can be used to get file content before calling import-users-csv-smart or other tools."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Name of the uploaded file to read (e.g., 'users.csv')"
            }
        },
        "required": ["filename"]
    }
)

# List of all file tools
FILE_TOOLS = [
    READ_UPLOADED_FILE_TOOL
]
