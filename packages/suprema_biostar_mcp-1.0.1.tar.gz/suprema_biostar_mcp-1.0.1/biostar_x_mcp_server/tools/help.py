"""
Help Tool Definitions (Web-based)

Tools for searching documentation from docs.supremainc.com
No vector database required - fetches directly from web
"""
from mcp.types import Tool

# Help search tool (web-based)
HELP_SEARCH_TOOL = Tool(
    name="search-biostar-docs",
    description="[DOCUMENTATION] Search BioStar X documentation from docs.supremainc.com. Use this when user asks 'how to', 'what is', 'explain', or wants information about BioStar X features. Fetches live documentation - always up to date. Returns relevant pages with content. For actual system operations, use action tools (get-users, create-user, control-door, etc.) instead.",
    inputSchema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Question or keyword to search (e.g., 'how to create user', 'access group setup', 'door monitoring')"
            },
            "language": {
                "type": "string",
                "enum": ["ko", "en"],
                "description": "Language selection (default: auto-detect from query)",
                "default": "en"
            }
        },
        "required": ["query"]
    }
)

# Get specific docs page
GET_DOCS_PAGE_TOOL = Tool(
    name="get-docs-page",
    description="[DOCUMENTATION] Fetch a specific BioStar X documentation page by URL or path. Use when you need detailed information from a specific documentation section.",
    inputSchema={
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "Full URL or path (e.g., '/user/add-user', 'https://docs.supremainc.com/en/platform/biostar_x/user')"
            },
            "language": {
                "type": "string",
                "enum": ["ko", "en"],
                "description": "Language for path-based URLs (default: en)",
                "default": "en"
            }
        },
        "required": ["url"]
    }
)

# Tool help lookup
TOOL_HELP_TOOL = Tool(
    name="get-tool-help",
    description="Get usage information and documentation for a specific BioStar X MCP tool.",
    inputSchema={
        "type": "object",
        "properties": {
            "tool_name": {
                "type": "string",
                "description": "Tool name (e.g., 'create-user', 'control-door', 'search-events')"
            },
            "language": {
                "type": "string",
                "enum": ["ko", "en"],
                "description": "Language selection (default: en)",
                "default": "en"
            }
        },
        "required": ["tool_name"]
    }
)

# Export help tools
HELP_TOOLS = [
    HELP_SEARCH_TOOL,
    GET_DOCS_PAGE_TOOL,
    TOOL_HELP_TOOL
]
