"""
BioStar X 로그 분석 도구 정의
"""
from mcp.types import Tool
from typing import List

LOG_TOOLS: List[Tool] = [
    Tool(
        name="analyze_server_logs",
        description="BioStar X 서버 로그 파일을 분석하여 오류, 경고, 이벤트를 파악합니다. "
                   "메인서버, 장치, 게이트웨이, API 서버 로그의 최신 50줄을 분석합니다. "
                   "로그 기반 오류 분석, 문제 진단에 사용하세요. "
                   "인증 없이 로컬 로그 파일을 직접 읽어 분석합니다.",
        inputSchema={
            "type": "object",
            "properties": {
                "log_path": {
                    "type": "string",
                    "description": "로그 파일 경로 (기본값: C:\\Program Files\\BioStar X\\logs)",
                    "default": "C:\\Program Files\\BioStar X\\logs"
                },
                "lines_to_read": {
                    "type": "integer",
                    "description": "각 로그 파일에서 읽을 줄 수 (기본값: 50)",
                    "default": 50,
                    "minimum": 20,
                    "maximum": 100
                }
            },
            "required": []
        }
    ),
    Tool(
        name="get_log_file_info",
        description="BioStar X 로그 디렉토리의 파일 목록과 정보를 조회합니다.",
        inputSchema={
            "type": "object",
            "properties": {
                "log_path": {
                    "type": "string",
                    "description": "로그 파일 경로 (기본값: C:\\Program Files\\BioStar X\\logs)",
                    "default": "C:\\Program Files\\BioStar X\\logs"
                }
            },
            "required": []
        }
    ),
    Tool(
        name="read_specific_log",
        description="특정 로그 파일의 내용을 읽어 분석합니다.",
        inputSchema={
            "type": "object",
            "properties": {
                "log_file_path": {
                    "type": "string",
                    "description": "읽을 로그 파일의 전체 경로"
                },
                "lines_to_read": {
                    "type": "integer",
                    "description": "읽을 줄 수 (기본값: 50)",
                    "default": 50,
                    "minimum": 20,
                    "maximum": 100
                },
                "from_end": {
                    "type": "boolean",
                    "description": "파일 끝에서부터 읽을지 여부 (기본값: true)",
                    "default": True
                }
            },
            "required": ["log_file_path"]
        }
    ),
    Tool(
        name="get_system_resources",
        description="시스템 리소스 사용량을 실시간으로 모니터링합니다. "
                   "CPU, 메모리, 디스크 사용량과 BioStar 프로세스의 메모리 사용량을 확인합니다. "
                   "시스템 성능, 메모리 사용량, CPU 사용률 확인에 사용하세요. "
                   "로그 분석이 아닌 실시간 시스템 모니터링 도구입니다.",
        inputSchema={
            "type": "object",
            "properties": {
                "include_all_processes": {
                    "type": "boolean",
                    "description": "모든 프로세스 정보 포함 여부 (기본값: false, BioStar 관련만)",
                    "default": False
                }
            },
            "required": []
        }
    ),
    Tool(
        name="analyze_server_status",
        description="BioStar X 서버의 종합적인 상태를 분석합니다. "
                   "로그 분석(오류/경고)과 시스템 리소스(CPU/메모리) 모니터링을 결합하여 전체적인 서버 상태를 파악합니다. "
                   "사용자가 '서버 종합 분석', '서버 전체 상태', '서버 진단'을 요청하면 이 도구를 사용하세요. "
                   "단순 로그 분석이나 리소스 모니터링만 필요하면 각각의 전용 도구를 사용하세요. "
                   "인증 없이 로컬 로그와 시스템 정보를 직접 분석합니다.",
        inputSchema={
            "type": "object",
            "properties": {
                "log_path": {
                    "type": "string",
                    "description": "로그 파일 경로 (기본값: C:\\Program Files\\BioStar X\\logs)",
                    "default": "C:\\Program Files\\BioStar X\\logs"
                },
                "lines_to_read": {
                    "type": "integer",
                    "description": "각 로그 파일에서 읽을 줄 수 (기본값: 50)",
                    "default": 50,
                    "minimum": 20,
                    "maximum": 100
                },
                "include_system_resources": {
                    "type": "boolean",
                    "description": "시스템 리소스 정보 포함 여부 (기본값: true)",
                    "default": True
                }
            },
            "required": []
        }
    )
]
