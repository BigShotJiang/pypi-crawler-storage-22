"""
Navigation Tools for Frontend Page Routing
LLM이 작업 완료 후 적절한 페이지로 자동 이동을 제안
"""
from mcp.types import Tool

NAVIGATION_TOOLS = [
    Tool(
        name="navigate-to-page",
        description=""" MANDATORY: Call this tool at the END of every successful operation to navigate frontend to appropriate page.

 YOU MUST ALWAYS CALL THIS TOOL after any operation (list, create, update, search) completes successfully.

Navigation Rules (MANDATORY):
- List devices (장치 조회) -> navigate-to-page(page_type="device_list")
- List users (사용자 조회) -> navigate-to-page(page_type="user_list")
- List doors (도어 조회) -> navigate-to-page(page_type="door_list")
- Create user (사용자 생성) -> navigate-to-page(page_type="user_detail", resource_id="USER_ID")
- Update user (사용자 수정) -> navigate-to-page(page_type="user_detail", resource_id="USER_ID")
- Update door (도어 설정) -> navigate-to-page(page_type="door_detail", resource_id="DOOR_ID")
- Update device (장치 설정) -> navigate-to-page(page_type="device_detail", resource_id="DEVICE_ID")
- Search events (이벤트 조회) -> navigate-to-page(page_type="monitoring")

Example workflow:
```
User: "현재 사용가능한 장치들 알려줘"
Step 1: list-devices() <- Get device list
Step 2: navigate-to-page(page_type="device_list") <- MUST CALL THIS!
Step 3: Respond to user
```

```
User: "홍길동 사용자를 추가해줘"
Step 1: create-user(name="홍길동") <- Create user
Step 2: navigate-to-page(page_type="user_detail", resource_id="12345") <- MUST CALL THIS!
Step 3: Respond to user
```

 CRITICAL: If you see this tool in your tool list, you MUST call it at the end of your operation. Do NOT skip it.
""",
        inputSchema={
            "type": "object",
            "properties": {
                "page_type": {
                    "type": "string",
                    "enum": [
                        "user_list",
                        "user_detail",
                        "door_list",
                        "door_detail",
                        "device_list",
                        "device_detail",
                        "monitoring",
                        "custom_url"
                    ],
                    "description": "Type of page to navigate to"
                },
                "resource_id": {
                    "type": "string",
                    "description": "Resource ID (user_id, door_id, device_id) for detail pages. Required for *_detail page types."
                },
                "custom_url": {
                    "type": "string",
                    "description": "Custom URL path for custom_url page type. Example: /team/user/detail/123"
                },
                "action": {
                    "type": "object",
                    "description": "Optional action to perform on the page (click or scroll to element)",
                    "properties": {
                        "type": {
                            "type": "string",
                            "enum": ["click", "scroll"],
                            "description": "Action type"
                        },
                        "ng_label_key": {
                            "type": "string",
                            "description": "Angular label key to target (e.g., 'common.information')"
                        }
                    }
                },
                "reason": {
                    "type": "string",
                    "description": "Brief explanation of why navigating to this page (for user context)"
                }
            },
            "required": ["page_type"]
        }
    )
]
