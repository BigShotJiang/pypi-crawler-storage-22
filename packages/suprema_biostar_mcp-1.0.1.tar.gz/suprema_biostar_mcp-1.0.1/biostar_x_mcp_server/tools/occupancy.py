"""
Occupancy Analysis Tools
재실 현황 분석 도구
"""

from mcp.types import Tool

GET_OCCUPANCY_STATUS_TOOL = Tool(
    name="get-occupancy-status",
    description="""
    Analyze current occupancy status of a door by checking entry/exit events.
    출입문의 현재 재실 현황을 분석합니다 (입실/퇴실 이벤트 기반).

    This tool automatically:
    1. Finds the door and its entry/exit devices
    2. Retrieves recent access events
    3. Analyzes entry/exit patterns for each user
    4. Returns list of currently occupied users (입실 중인 사용자)

    Use this when user asks:
    - "ㅇㅇ출입문에 입실한 사용자 알려줘"
    - "현재 들어간 사람 찾아줘"
    - "재실 현황 분석해줘"
    - "누가 들어가 있는지 확인"
    """,
    inputSchema={
        "type": "object",
        "properties": {
            "door_name": {
                "type": "string",
                "description": "출입문 이름 (예: '12층 메인 출입문'). If not provided, will analyze all doors."
            },
            "door_id": {
                "type": "string",
                "description": "출입문 ID (door_name 대신 사용 가능)"
            },
            "hours": {
                "type": "integer",
                "description": "분석할 시간 범위 (시간 단위, 기본값: 24시간)",
                "default": 24
            },
            "include_details": {
                "type": "boolean",
                "description": "상세 이벤트 정보 포함 여부 (기본값: true)",
                "default": True
            }
        },
        "required": []
    }
)

ANALYZE_DOOR_TRAFFIC_TOOL = Tool(
    name="analyze-door-traffic",
    description="""
    Analyze door traffic patterns (entry/exit statistics).
    출입문의 출입 패턴을 분석합니다 (통계).

    Returns:
    - Total entries/exits
    - Peak hours
    - User traffic distribution
    """,
    inputSchema={
        "type": "object",
        "properties": {
            "door_name": {
                "type": "string",
                "description": "출입문 이름"
            },
            "door_id": {
                "type": "string",
                "description": "출입문 ID"
            },
            "start_date": {
                "type": "string",
                "description": "시작 날짜 (YYYY-MM-DD)"
            },
            "end_date": {
                "type": "string",
                "description": "종료 날짜 (YYYY-MM-DD)"
            }
        },
        "required": []
    }
)

# Export all tools
OCCUPANCY_TOOLS = [
    GET_OCCUPANCY_STATUS_TOOL,
    ANALYZE_DOOR_TRAFFIC_TOOL
]
