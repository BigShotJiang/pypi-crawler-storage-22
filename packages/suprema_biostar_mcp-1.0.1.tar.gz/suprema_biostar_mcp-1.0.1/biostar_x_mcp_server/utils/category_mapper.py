"""
Category Mapper Module

Maps documents and endpoints to BioStar MCP Server categories based on content and structure.
"""
import logging
import re
from typing import Dict, List, Optional, Set, Any
from pathlib import Path

logger = logging.getLogger(__name__)


class CategoryMapper:
    """Maps content to BioStar MCP Server categories"""

    # Category keywords mapping (Korean + English)
    CATEGORY_KEYWORDS: Dict[str, List[str]] = {
        "auth": [
            "authentication", "login", "logout", "session", "credential", "token",
            "인증", "로그인", "로그아웃", "세션", "토큰", "인증서"
        ],
        "users": [
            "user", "users", "person", "people", "employee", "staff", "member",
            "사용자", "유저", "직원", "인원", "멤버", "회원",
            "user group", "user management", "사용자 그룹", "사용자 관리"
        ],
        "cards": [
            "card", "cards", "credential", "credentials", "badge", "smartcard",
            "카드", "크리덴셜", "배지", "스마트카드",
            "card type", "wiegand", "csn", "카드 타입", "위간드"
        ],
        "doors": [
            "door", "doors", "gate", "gates", "entry", "entrance", "exit",
            "문", "도어", "출입문", "게이트", "입구", "출구",
            "door group", "door control", "도어 그룹", "도어 제어"
        ],
        "access": [
            "access", "permission", "authorization", "access level", "access group",
            "출입", "권한", "액세스", "접근", "권한 그룹", "접근 레벨",
            "access control", "permission management", "접근 제어", "권한 관리"
        ],
        "devices": [
            "device", "devices", "reader", "readers", "terminal", "controller",
            "장치", "디바이스", "리더", "터미널", "컨트롤러",
            "device group", "device management", "장치 그룹", "장치 관리"
        ],
        "events": [
            "event", "events", "log", "logs", "record", "records", "history",
            "이벤트", "로그", "기록", "이력", "히스토리",
            "access log", "event log", "출입 기록", "이벤트 로그"
        ],
        "audit": [
            "audit", "audits", "trail", "tracking", "change history",
            "감사", "추적", "변경 이력", "감사 추적",
            "audit log", "audit trail", "감사 로그"
        ],
        "navigation": [
            "navigation", "navigate", "page", "route",
            "네비게이션", "페이지", "이동"
        ],
        "occupancy": [
            "occupancy", "occupied", "entry", "exit", "inside", "present",
            "재실", "입실", "퇴실", "재실 현황", "재실자"
        ],
        "files": [
            "file", "files", "upload", "import", "export", "csv", "pdf",
            "파일", "업로드", "임포트", "내보내기"
        ],
        "logs": [
            "server log", "system log", "log file", "server status",
            "서버 로그", "시스템 로그", "로그 파일", "서버 상태"
        ],
    }

    # API endpoint path to category mapping
    ENDPOINT_CATEGORY_MAP: Dict[str, str] = {
        "/api/auth": "auth",
        "/api/users": "users",
        "/api/user-groups": "users",
        "/api/cards": "cards",
        "/api/card-types": "cards",
        "/api/doors": "doors",
        "/api/door-groups": "doors",
        "/api/access": "access",
        "/api/access-groups": "access",
        "/api/access-levels": "access",
        "/api/devices": "devices",
        "/api/device-groups": "devices",
        "/api/events": "events",
        "/api/audit": "audit",
    }

    def __init__(self):
        """Initialize CategoryMapper"""
        # Build reverse keyword index for faster lookup
        self._keyword_to_category: Dict[str, str] = {}
        for category, keywords in self.CATEGORY_KEYWORDS.items():
            for keyword in keywords:
                self._keyword_to_category[keyword.lower()] = category

    def map_endpoint_to_category(self, endpoint: Dict[str, Any]) -> Optional[str]:
        """
        Map API endpoint to category based on path and tags

        Args:
            endpoint: Endpoint information with path, method, tags, etc.

        Returns:
            Category name or None if not found
        """
        path = endpoint.get("path", "").lower()
        tags = endpoint.get("tags", [])

        # Check path mapping first
        for endpoint_pattern, category in self.ENDPOINT_CATEGORY_MAP.items():
            if path.startswith(endpoint_pattern.lower()):
                return category

        # Check tags
        for tag in tags:
            tag_lower = tag.lower()
            if tag_lower in self._keyword_to_category:
                return self._keyword_to_category[tag_lower]

        # Check path segments
        path_segments = [seg for seg in path.split("/") if seg and seg != "api"]
        if path_segments:
            first_segment = path_segments[0]
            if first_segment in self._keyword_to_category:
                return self._keyword_to_category[first_segment]

        # Default: try to infer from path
        for keyword, category in self._keyword_to_category.items():
            if keyword in path:
                return category

        return None

    def map_text_to_category(self, text: str, title: Optional[str] = None) -> Optional[str]:
        """
        Map text content to category based on keywords

        Args:
            text: Text content to analyze
            title: Optional title (has higher weight)

        Returns:
            Category name or None if not found
        """
        if not text:
            return None

        text_lower = text.lower()
        title_lower = title.lower() if title else ""

        # Score categories based on keyword matches
        category_scores: Dict[str, int] = {}

        for category, keywords in self.CATEGORY_KEYWORDS.items():
            score = 0
            for keyword in keywords:
                keyword_lower = keyword.lower()
                # Title matches have higher weight
                if title_lower and keyword_lower in title_lower:
                    score += 3
                # Text matches
                if keyword_lower in text_lower:
                    score += 1

            if score > 0:
                category_scores[category] = score

        if not category_scores:
            return None

        # Return category with highest score
        return max(category_scores.items(), key=lambda x: x[1])[0]

    def map_section_to_category(self, section: Dict[str, Any]) -> Optional[str]:
        """
        Map PDF section to category

        Args:
            section: Section information with title and content

        Returns:
            Category name or None if not found
        """
        title = section.get("title", "")
        content = section.get("content", "")

        # Try title first (more reliable)
        category = self.map_text_to_category(title, title=title)
        if category:
            return category

        # Try content (first 500 chars for performance)
        content_preview = content[:500] if content else ""
        category = self.map_text_to_category(content_preview, title=title)

        return category

    def get_all_categories(self) -> List[str]:
        """Get list of all available categories"""
        return list(self.CATEGORY_KEYWORDS.keys())
