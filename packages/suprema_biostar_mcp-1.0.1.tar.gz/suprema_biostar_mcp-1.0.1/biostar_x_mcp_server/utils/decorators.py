"""
Decorator utilities for BioStar X MCP Server handlers
Provides common decorators for error handling, authentication, and logging
"""
import logging
import functools
from typing import Callable, Any

logger = logging.getLogger(__name__)


def handle_api_errors(func: Callable) -> Callable:
    """
    Decorator to handle API errors consistently across all handler methods

    Usage:
        @handle_api_errors
        async def my_handler_method(self, args):
            # Your code here
            pass
    """
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            return await func(self, *args, **kwargs)
        except Exception as e:
            logger.error(f"Error in {func.__name__}: {e}", exc_info=True)
            return await self.handle_api_error(e)
    return wrapper


def require_auth(func: Callable) -> Callable:
    """
    Decorator to ensure authentication before executing handler method

    Usage:
        @require_auth
        @handle_api_errors
        async def my_handler_method(self, args):
            # Your code here (auth is guaranteed)
            pass
    """
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        self.check_auth()
        return await func(self, *args, **kwargs)
    return wrapper


def log_execution(func: Callable) -> Callable:
    """
    Decorator to log method execution start and end

    Usage:
        @log_execution
        @require_auth
        @handle_api_errors
        async def my_handler_method(self, args):
            # Your code here
            pass
    """
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        logger.debug(f"Starting execution: {func.__name__}")
        try:
            result = await func(self, *args, **kwargs)
            logger.debug(f"Completed execution: {func.__name__}")
            return result
        except Exception as e:
            logger.error(f"Failed execution: {func.__name__} - {e}")
            raise
    return wrapper


def validate_args(*required_keys: str):
    """
    Decorator to validate required arguments in args dict

    Usage:
        @validate_args("user_id", "name")
        @require_auth
        @handle_api_errors
        async def my_handler_method(self, args):
            # user_id and name are guaranteed to exist in args
            pass

    Args:
        required_keys: Keys that must exist in args dict
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(self, args: dict, *extra_args, **kwargs):
            missing = [key for key in required_keys if key not in args]
            if missing:
                return self.error_response(
                    "Missing required parameters",
                    {"missing": missing, "required": list(required_keys)}
                )
            return await func(self, args, *extra_args, **kwargs)
        return wrapper
    return decorator
