"""
Language detection utility for determining user's preferred language.
"""
import re
from typing import Literal


def detect_language(text: str) -> Literal["ko", "en"]:
    """
    Detect if text is primarily Korean or English.

    Args:
        text: Input text to analyze

    Returns:
        "ko" if Korean, "en" if English (default)
    """
    if not text or not isinstance(text, str):
        return "en"

    # Remove whitespace and common punctuation
    text = text.strip()
    if not text:
        return "en"

    # Check for Korean characters (Hangul)
    korean_pattern = re.compile(r'[가-힣]')
    korean_chars = len(korean_pattern.findall(text))

    # Check for English characters (Latin alphabet)
    english_pattern = re.compile(r'[a-zA-Z]')
    english_chars = len(english_pattern.findall(text))

    # Count total meaningful characters (excluding numbers, spaces, punctuation)
    total_chars = korean_chars + english_chars

    if total_chars == 0:
        return "en"  # Default to English if no meaningful characters

    # If Korean characters make up more than 20% of meaningful characters, consider it Korean
    korean_ratio = korean_chars / total_chars if total_chars > 0 else 0

    if korean_ratio > 0.2:
        return "ko"
    else:
        return "en"


def is_korean(text: str) -> bool:
    """Check if text is primarily Korean."""
    return detect_language(text) == "ko"
