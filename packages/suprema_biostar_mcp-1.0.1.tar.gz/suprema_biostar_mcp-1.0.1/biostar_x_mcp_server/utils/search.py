import httpx
from typing import List, Dict
import os

API_BASE = os.getenv("API_BASE", "https://192.168.120.114:443/api")


async def search_users_by_name(session_token: str, name: str) -> List[Dict]:
    """
    Search for users by name using the BioStar API.

    CRITICAL: BioStar API's name parameter seems unreliable, so we do client-side filtering
    to ensure exact or partial matches only.
    """
    headers = {
        "bs-session-id": session_token,
        "Content-Type": "application/json"
    }

    async with httpx.AsyncClient(verify=False) as client:
        response = await client.get(
            f"{API_BASE}/users",
            headers=headers,
            params={"name": name}
        )

        if response.status_code == 200:
            data = response.json()
            all_users = data.get("UserCollection", {}).get("rows", [])

            # Client-side filtering: only return users whose name contains the search term
            # (case-insensitive)
            search_lower = name.lower().strip()
            filtered_users = [
                {"user_id": u["user_id"], "name": u["name"]}
                for u in all_users
                if search_lower in u.get("name", "").lower()
            ]

            return filtered_users

        return []
