"""
Timezone utility functions
Convert BioStar X API timezone IDs to UTC offsets (in minutes)
"""
from typing import Optional
from datetime import datetime, timedelta


# BioStar Timezone ID to UTC offset mapping (in minutes)
TIMEZONE_OFFSETS = {
    "0": -720,   # (UTC -12:00) Eniwetok, Kwajalein
    "1": -660,   # (UTC -11:00) Midway Island, Samoa
    "2": -600,   # (UTC -10:00) Hawaii
    "3": -540,   # (UTC -9:00) Alaska
    "4": -480,   # (UTC -8:00) Pacific Time (US & Canada)
    "5": -420,   # (UTC -7:00) Mountain Time (US & Canada)
    "6": -360,   # (UTC -6:00) Central Time (US & Canada), Mexico City
    "7": -300,   # (UTC -5:00) Eastern Time (US & Canada), Bogota, Lima
    "8": -240,   # (UTC -4:00) Atlantic Time (Canada), Caracas, La Paz
    "9": -210,   # (UTC -3:30) Newfoundland
    "10": -180,  # (UTC -3:00) Brazil, Buenos Aires, Georgetown
    "11": -120,  # (UTC -2:00) Mid-Atlantic
    "12": -60,   # (UTC -1:00) Azores, Cape Verde Islands
    "13": 0,     # (UTC) Western Europe Time, London, Lisbon, Casablanca
    "14": 60,    # (UTC +1:00) Brussels, Copenhagen, Madrid, Paris
    "15": 120,   # (UTC +2:00) Kaliningrad, South Africa
    "16": 180,   # (UTC +3:00) Baghdad, Riyadh, Moscow, St. Petersburg
    "17": 210,   # (UTC +3:30) Tehran
    "18": 240,   # (UTC +4:00) Abu Dhabi, Muscat, Baku, Tbilisi
    "19": 270,   # (UTC +4:30) Kabul
    "20": 300,   # (UTC +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent
    "21": 330,   # (UTC +5:30) Bombay, Calcutta, Madras, New Delhi, Colombo
    "22": 345,   # (UTC +5:45) Kathmandu
    "23": 360,   # (UTC +6:00) Almaty, Dhaka
    "24": 420,   # (UTC +7:00) Bangkok, Hanoi, Jakarta
    "25": 480,   # (UTC +8:00) Beijing, Perth, Singapore, Hong Kong
    "26": 540,   # (UTC +9:00) Seoul, Tokyo, Osaka, Sapporo, Yakutsk
    "27": 570,   # (UTC +9:30) Adelaide, Darwin
    "28": 600,   # (UTC +10:00) Eastern Australia, Guam, Vladivostok
    "29": 660,   # (UTC +11:00) Magadan, Solomon Islands, New Caledonia
    "30": 720,   # (UTC +12:00) Auckland, Wellington, Fiji, Kamchatka
}


def get_timezone_offset(timezone_id: str, default: int = 540) -> int:
    """
    Convert BioStar timezone ID to UTC offset in minutes

    Args:
        timezone_id: BioStar timezone ID (string)
        default: Default offset to return if timezone_id not found (default: 540 = UTC+9 Seoul)

    Returns:
        UTC offset in minutes
    """
    return TIMEZONE_OFFSETS.get(str(timezone_id), default)


def get_timezone_string(timezone_id: str, default: int = 540) -> str:
    """
    Convert BioStar timezone ID to "UTC+9:00" format string

    Args:
        timezone_id: BioStar timezone ID (string)
        default: Default offset to use if timezone_id not found (in minutes)

    Returns:
        Timezone string in "UTC+9:00" format
    """
    offset_minutes = get_timezone_offset(timezone_id, default)
    offset_hours = offset_minutes / 60
    minutes = abs(offset_minutes % 60)

    if offset_minutes >= 0:
        return f"UTC+{int(offset_hours)}:{minutes:02d}"
    else:
        return f"UTC{int(offset_hours)}:{minutes:02d}"


def convert_utc_to_local(utc_time_str: str, timezone_offset_minutes: int) -> str:
    """
    Convert UTC time string to local time

    Args:
        utc_time_str: ISO 8601 UTC time string
                      (e.g., "2024-01-15T10:30:00.00Z" or "2025-01-20T00:00:08.00+00:00")
        timezone_offset_minutes: Timezone offset in minutes (e.g., 540 = UTC+9)

    Returns:
        Local time string in "2024-01-15 19:30:00 (UTC+9:00)" format
    """
    try:
        # Normalize time string
        time_str = utc_time_str.strip()

        # Handle UTC format
        if time_str.endswith('Z'):
            time_str = time_str.replace('Z', '+00:00')

        # Fix millisecond format: .00 -> .000 (Python requires 3 or 6 digits)
        if '.00+' in time_str or '.00-' in time_str:
            time_str = time_str.replace('.00+', '.000+').replace('.00-', '.000-')

        # Parse UTC time
        dt_utc = datetime.fromisoformat(time_str)

        # Apply timezone offset
        dt_local = dt_utc + timedelta(minutes=timezone_offset_minutes)

        # Generate timezone string
        hours = int(timezone_offset_minutes / 60)
        minutes = abs(timezone_offset_minutes % 60)
        if timezone_offset_minutes >= 0:
            tz_str = f"UTC+{hours}:{minutes:02d}"
        else:
            tz_str = f"UTC{hours}:{minutes:02d}"

        return f"{dt_local.strftime('%Y-%m-%d %H:%M:%S')} ({tz_str})"

    except Exception as e:
        # Return original on conversion failure
        return utc_time_str
