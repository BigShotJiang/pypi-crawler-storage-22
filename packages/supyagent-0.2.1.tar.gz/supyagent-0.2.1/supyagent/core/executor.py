"""
Execution runner for non-interactive agent execution.

Execution agents are stateless, input→output pipelines designed for automation.
"""

import json
import os
import re
from typing import Any

from supyagent.core.credentials import CredentialManager
from supyagent.core.llm import LLMClient
from supyagent.core.tools import (
    discover_tools,
    execute_tool,
    filter_tools,
    is_credential_request,
    supypowers_to_openai_tools,
)
from supyagent.models.agent_config import AgentConfig


class ExecutionRunner:
    """
    Runs agents in non-interactive execution mode.

    Key differences from interactive mode:
    - No session persistence
    - No credential prompting (must be pre-provided)
    - Single input → output execution
    - Designed for automation and pipelines
    """

    def __init__(
        self,
        config: AgentConfig,
        credential_manager: CredentialManager | None = None,
    ):
        """
        Initialize the execution runner.

        Args:
            config: Agent configuration
            credential_manager: Optional credential manager for stored credentials
        """
        self.config = config
        self.credential_manager = credential_manager or CredentialManager()

        # Initialize LLM client
        self.llm = LLMClient(
            model=config.model.provider,
            temperature=config.model.temperature,
            max_tokens=config.model.max_tokens,
        )

        # Load available tools (excluding credential request tool for execution mode)
        self.tools = self._load_tools()

    def _load_tools(self) -> list[dict[str, Any]]:
        """
        Load tools for execution mode.

        Note: Does NOT include request_credential tool since
        execution mode cannot prompt for credentials.
        """
        # If no tools allowed, return empty
        if not self.config.tools.allow:
            return []

        # Discover tools from supypowers
        sp_tools = discover_tools()
        openai_tools = supypowers_to_openai_tools(sp_tools)
        filtered = filter_tools(openai_tools, self.config.tools)

        return filtered

    def run(
        self,
        task: str | dict[str, Any],
        secrets: dict[str, str] | None = None,
        output_format: str = "raw",
    ) -> dict[str, Any]:
        """
        Execute a task and return the result.

        Args:
            task: Task description (string) or structured input (dict)
            secrets: Pre-provided credentials (KEY=VALUE)
            output_format: "raw" | "json" | "markdown"

        Returns:
            {"ok": True, "data": ...} or {"ok": False, "error": ...}
        """
        # Merge secrets: stored credentials + provided secrets
        all_secrets = self.credential_manager.get_all_for_tools(self.config.name)
        if secrets:
            all_secrets.update(secrets)

        # Inject secrets into environment for this execution
        for key, value in all_secrets.items():
            os.environ[key] = value

        try:
            # Build the prompt
            if isinstance(task, dict):
                user_content = self._format_structured_input(task)
            else:
                user_content = str(task)

            messages: list[dict[str, Any]] = [
                {"role": "system", "content": self.config.system_prompt},
                {"role": "user", "content": user_content},
            ]

            # Run with tool loop (max iterations for safety)
            max_iterations = self.config.limits.get("max_tool_calls_per_turn", 20)
            iterations = 0

            while iterations < max_iterations:
                iterations += 1

                response = self.llm.chat(
                    messages=messages,
                    tools=self.tools if self.tools else None,
                )
                assistant_msg = response.choices[0].message

                # Build message for history
                msg_dict: dict[str, Any] = {
                    "role": "assistant",
                    "content": assistant_msg.content,
                }

                if assistant_msg.tool_calls:
                    msg_dict["tool_calls"] = [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in assistant_msg.tool_calls
                    ]

                messages.append(msg_dict)

                # If no tool calls, we're done
                if not assistant_msg.tool_calls:
                    return self._format_output(assistant_msg.content or "", output_format)

                # Execute tools
                for tool_call in assistant_msg.tool_calls:
                    # Credential requests fail in execution mode
                    if is_credential_request(tool_call):
                        try:
                            args = json.loads(tool_call.function.arguments)
                            cred_name = args.get("name", "unknown")
                        except json.JSONDecodeError:
                            cred_name = "unknown"

                        return {
                            "ok": False,
                            "error": f"Credential '{cred_name}' required but not provided. "
                            f"Pass it via --secrets {cred_name}=<value>",
                        }

                    result = self._execute_tool(tool_call, all_secrets)
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(result),
                    })

            return {"ok": False, "error": "Max tool iterations exceeded"}

        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _format_structured_input(self, task: dict[str, Any]) -> str:
        """Format a structured input dict into a prompt."""
        return json.dumps(task, indent=2)

    def _format_output(self, content: str, output_format: str) -> dict[str, Any]:
        """Format the output according to requested format."""
        if output_format == "json":
            # Try to parse as JSON
            try:
                data = json.loads(content)
                return {"ok": True, "data": data}
            except json.JSONDecodeError:
                pass

            # Try to extract JSON from markdown code block
            match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", content)
            if match:
                try:
                    data = json.loads(match.group(1))
                    return {"ok": True, "data": data}
                except json.JSONDecodeError:
                    pass

            # Return as-is
            return {"ok": True, "data": content}

        elif output_format == "markdown":
            return {"ok": True, "data": content, "format": "markdown"}

        else:  # raw
            return {"ok": True, "data": content}

    def _execute_tool(
        self,
        tool_call: Any,
        secrets: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Execute a tool call."""
        name = tool_call.function.name
        arguments_str = tool_call.function.arguments

        try:
            args = json.loads(arguments_str)
        except json.JSONDecodeError:
            return {"ok": False, "error": f"Invalid JSON arguments: {arguments_str}"}

        if "__" not in name:
            return {"ok": False, "error": f"Invalid tool name format: {name}"}

        script, func = name.split("__", 1)
        return execute_tool(script, func, args, secrets=secrets)
