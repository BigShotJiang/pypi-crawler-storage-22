"""
Agent configuration models.
"""

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field


class ModelConfig(BaseModel):
    """LLM model configuration."""

    provider: str = Field(..., description="LiteLLM model identifier (e.g., 'anthropic/claude-3-5-sonnet-20241022')")
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: int = Field(default=4096, gt=0)


class ToolPermissions(BaseModel):
    """Tool permission settings."""

    allow: list[str] = Field(default_factory=list, description="Allowed tool patterns (e.g., 'web_search:*')")
    deny: list[str] = Field(default_factory=list, description="Denied tool patterns")


class CredentialSpec(BaseModel):
    """Credential specification."""

    name: str = Field(..., description="Environment variable name")
    description: str = Field(default="", description="Description of what this credential is for")
    required: bool = Field(default=False)


class AgentConfig(BaseModel):
    """
    Agent configuration loaded from YAML.
    """

    name: str = Field(..., min_length=1, max_length=50)
    description: str = Field(default="")
    version: str = Field(default="1.0")
    type: Literal["interactive", "execution"] = Field(default="interactive")
    model: ModelConfig
    system_prompt: str = Field(..., min_length=1)
    tools: ToolPermissions = Field(default_factory=ToolPermissions)
    delegates: list[str] = Field(default_factory=list)
    credentials: list[CredentialSpec] = Field(default_factory=list)
    limits: dict = Field(default_factory=dict)


class AgentNotFoundError(Exception):
    """Raised when an agent configuration is not found."""

    def __init__(self, name: str):
        self.name = name
        super().__init__(f"Agent '{name}' not found. Check agents/ directory.")


def load_agent_config(name: str, agents_dir: Path | None = None) -> AgentConfig:
    """
    Load and validate an agent configuration from YAML.

    Args:
        name: Agent name (without .yaml extension)
        agents_dir: Directory containing agent YAML files (default: ./agents)

    Returns:
        Validated AgentConfig

    Raises:
        AgentNotFoundError: If agent YAML doesn't exist
        ValidationError: If YAML is invalid
    """
    if agents_dir is None:
        agents_dir = Path("agents")

    config_path = agents_dir / f"{name}.yaml"

    if not config_path.exists():
        raise AgentNotFoundError(name)

    with open(config_path) as f:
        data = yaml.safe_load(f)

    return AgentConfig(**data)
