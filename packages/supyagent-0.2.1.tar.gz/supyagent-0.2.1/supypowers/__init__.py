"""
Supypowers tools for supyagent.

This directory contains Python functions that agents can use as tools.
Each function becomes a callable tool via the supypowers framework.
"""
