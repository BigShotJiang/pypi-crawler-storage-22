"""
LiteLLM wrapper for unified LLM access.
"""

import logging
import time
from typing import Any

import litellm
from litellm import completion
from litellm.exceptions import (
    APIConnectionError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ServiceUnavailableError,
)
from litellm.types.utils import ModelResponse

# Suppress LiteLLM debug messages (e.g., "Provider List: ...")
litellm.suppress_debug_info = True

logger = logging.getLogger(__name__)


# Map of provider prefixes to their expected API key env vars
_PROVIDER_KEY_HINTS: dict[str, str] = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "google": "GOOGLE_API_KEY",
    "gemini": "GOOGLE_API_KEY",
    "azure": "AZURE_API_KEY",
    "cohere": "COHERE_API_KEY",
    "mistral": "MISTRAL_API_KEY",
    "groq": "GROQ_API_KEY",
    "together": "TOGETHER_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
}


class LLMError(Exception):
    """User-friendly LLM error with actionable guidance."""

    def __init__(self, message: str, original: Exception | None = None):
        self.original = original
        super().__init__(message)


def _friendly_llm_error(model: str, error: Exception) -> LLMError:
    """Convert a LiteLLM exception to a user-friendly error message."""
    provider = model.split("/")[0].lower() if "/" in model else model.split("/")[0].lower()

    if isinstance(error, AuthenticationError):
        key_name = _PROVIDER_KEY_HINTS.get(provider, f"{provider.upper()}_API_KEY")
        return LLMError(
            f"Authentication failed for '{model}'. "
            f"Check that {key_name} is set correctly.\n"
            f"  Run: supyagent config set {key_name}",
            original=error,
        )

    if isinstance(error, NotFoundError):
        return LLMError(
            f"Model '{model}' not found. Check the model name and provider.\n"
            f"  LiteLLM format: provider/model (e.g., openai/gpt-4o, anthropic/claude-3-5-sonnet-20241022)\n"
            f"  See: https://docs.litellm.ai/docs/providers",
            original=error,
        )

    if isinstance(error, RateLimitError):
        return LLMError(
            f"Rate limit exceeded for '{model}'. Wait a moment and try again.\n"
            f"  If this persists, check your API plan limits.",
            original=error,
        )

    if isinstance(error, APIConnectionError):
        return LLMError(
            f"Cannot connect to {provider} API. Check your internet connection.\n"
            f"  If using a custom endpoint, verify the URL is correct.",
            original=error,
        )

    if isinstance(error, ServiceUnavailableError):
        return LLMError(
            f"The {provider} API is temporarily unavailable. Try again in a moment.",
            original=error,
        )

    # Generic fallback
    return LLMError(f"LLM error ({type(error).__name__}): {error}", original=error)


class LLMClient:
    """
    Wrapper around LiteLLM for consistent LLM access.

    Supports any provider that LiteLLM supports:
    - OpenAI: openai/gpt-4o
    - Anthropic: anthropic/claude-3-5-sonnet-20241022
    - Ollama: ollama/llama3
    - And 100+ more...
    """

    def __init__(
        self,
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        retry_backoff: float = 2.0,
    ):
        """
        Initialize the LLM client.

        Args:
            model: LiteLLM model identifier (e.g., 'anthropic/claude-3-5-sonnet-20241022')
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens in response
            max_retries: Maximum number of retries on transient errors
            retry_delay: Initial delay between retries (seconds)
            retry_backoff: Exponential backoff multiplier
        """
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.retry_backoff = retry_backoff

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        stream: bool = False,
    ) -> ModelResponse:
        """
        Send a chat completion request with automatic retry on transient errors.

        Args:
            messages: List of message dicts with 'role' and 'content'
            tools: Optional list of tool definitions (OpenAI format)
            stream: Whether to stream the response

        Returns:
            LiteLLM ModelResponse
        """
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": stream,
        }

        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        last_error: Exception | None = None
        delay = self.retry_delay

        for attempt in range(self.max_retries + 1):
            try:
                return completion(**kwargs)
            except (RateLimitError, ServiceUnavailableError, APIConnectionError) as e:
                last_error = e
                if attempt < self.max_retries:
                    logger.warning(
                        "LLM call failed (attempt %d/%d): %s. Retrying in %.1fs...",
                        attempt + 1,
                        self.max_retries + 1,
                        e,
                        delay,
                    )
                    time.sleep(delay)
                    delay *= self.retry_backoff
                else:
                    raise _friendly_llm_error(self.model, e) from e
            except (AuthenticationError, NotFoundError) as e:
                # Non-transient errors: don't retry, raise friendly error immediately
                raise _friendly_llm_error(self.model, e) from e

        raise last_error  # Should not reach here

    def change_model(self, model: str) -> None:
        """Change the model being used."""
        self.model = model
