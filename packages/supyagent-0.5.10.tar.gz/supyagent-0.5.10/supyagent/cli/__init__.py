"""CLI module for supyagent."""
