"""CLI module for Surek."""
