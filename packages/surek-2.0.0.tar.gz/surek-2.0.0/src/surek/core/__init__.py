"""Core functionality for Surek."""
