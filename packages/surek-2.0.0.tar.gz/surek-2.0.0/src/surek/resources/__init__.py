"""Bundled resources for Surek."""
