"""Core monitoring functionality."""

import contextlib
import json
import operator
import re
import subprocess  # noqa: S404
import time
from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
from pathlib import Path

import psutil

from surfmon.config import get_paths

# Monitoring thresholds
CMDLINE_TRUNCATE_LEN = 200
PATH_COMPONENTS_SHORT = 3
MAX_DISPLAY_ITEMS = 3
TELEMETRY_ERROR_THRESHOLD = 5
EXTENSION_ERROR_LINES_THRESHOLD = 10
SECONDS_PER_MINUTE = 60
SECONDS_PER_HOUR = 3600
SECONDS_PER_DAY = 86400
PTY_CRITICAL_COUNT = 200
PTY_WARNING_COUNT = 50
PTY_USAGE_CRITICAL_PERCENT = 80
LOG_TAIL_BYTES = 50000
SHARED_LOG_TAIL_BYTES = 30000


@dataclass
class ProcessInfo:
    """Information about a Windsurf process."""

    pid: int
    name: str
    cpu_percent: float
    memory_mb: float
    memory_percent: float
    num_threads: int
    runtime_seconds: float
    cmdline: str


@dataclass
class SystemInfo:
    """System-wide resource information."""

    total_memory_gb: float
    available_memory_gb: float
    memory_percent: float
    cpu_count: int
    swap_total_gb: float
    swap_used_gb: float


@dataclass
class WorkspaceInfo:
    """Information about a Windsurf workspace."""

    id: str
    path: str
    exists: bool
    loaded_at: str | None = None


@dataclass
class PtyInfo:
    """PTY usage information for Windsurf."""

    windsurf_pty_count: int
    system_pty_limit: int
    system_pty_used: int


@dataclass
class MonitoringReport:
    """Complete monitoring report."""

    timestamp: str
    system: SystemInfo
    windsurf_processes: list[ProcessInfo]
    total_windsurf_memory_mb: float
    total_windsurf_cpu_percent: float
    process_count: int
    language_servers: list[ProcessInfo]
    mcp_servers_enabled: list[str]
    extensions_count: int
    log_issues: list[str]
    active_workspaces: list[WorkspaceInfo]
    windsurf_launches_today: int
    pty_info: PtyInfo | None = None


def is_main_windsurf_process(name: str, exe: str, app_name: str) -> bool:
    """Check if a process is the main Windsurf/Electron process (not a helper/crashpad).

    This is the single source of truth for main-process detection, used by:
    - get_windsurf_processes() to filter orphaned crashpad handlers
    - _check_orphaned_crashpad_handlers() for issue reporting
    - cli.py _find_orphaned_crashpad_procs() for the cleanup command
    """
    return (
        (
            name.lower() in {"windsurf", "electron"}
            or f"{app_name}/Contents/MacOS/Windsurf" in exe
            or f"{app_name}/Contents/MacOS/Electron" in exe
        )
        and "Helper" not in name
        and "crashpad" not in name.lower()
    )


def get_windsurf_processes() -> list[psutil.Process]:
    """Find all Windsurf-related processes.

    Only matches processes from the configured Windsurf app, excluding:
    - This monitoring tool itself (surfmon)
    - Unrelated processes that happen to contain "windsurf" in their path
    - Orphaned crashpad handlers when the main Windsurf process isn't running
    """
    paths = get_paths()
    app_name = paths.app_name  # e.g., "Windsurf.app" or "Windsurf - Next.app"

    windsurf_procs = []
    main_windsurf_found = False

    # First pass: find all potential Windsurf processes and check for main process
    for proc in psutil.process_iter(["pid", "name", "cmdline", "exe"]):
        try:
            name = proc.info["name"] or ""
            cmdline = " ".join(proc.info["cmdline"] or [])
            exe = proc.info["exe"] or ""

            # Skip the monitoring tool itself
            if "surfmon" in cmdline.lower():
                continue

            # Only match processes from the configured Windsurf app
            if app_name in exe or app_name in cmdline:
                windsurf_procs.append(proc)

                if is_main_windsurf_process(name, exe, app_name):
                    main_windsurf_found = True

        except psutil.NoSuchProcess, psutil.AccessDenied:
            pass

    # If no main Windsurf process found, filter out crashpad handlers (they're orphaned)
    if not main_windsurf_found:
        filtered_procs = []
        for p in windsurf_procs:
            try:
                if "crashpad" not in p.name().lower():
                    filtered_procs.append(p)
            except psutil.NoSuchProcess, psutil.AccessDenied:
                pass  # Process terminated, skip it
        windsurf_procs = filtered_procs

    return windsurf_procs


def get_process_info(proc: psutil.Process, initial_cpu: float = 0.0) -> ProcessInfo | None:
    """Extract detailed information from a process.

    Args:
        proc: Process to extract info from
        initial_cpu: Pre-sampled CPU percentage (if available)
    """
    try:
        with proc.oneshot():
            cmdline = " ".join(proc.cmdline())
            memory_info = proc.memory_info()
            memory_mb = memory_info.rss / 1024 / 1024
            memory_percent = proc.memory_percent()
            num_threads = proc.num_threads()
            create_time = proc.create_time()
            runtime = datetime.now(tz=UTC).timestamp() - create_time

            return ProcessInfo(
                pid=proc.pid,
                name=proc.name(),
                cpu_percent=initial_cpu,
                memory_mb=memory_mb,
                memory_percent=memory_percent,
                num_threads=num_threads,
                runtime_seconds=runtime,
                cmdline=cmdline,
            )
    except psutil.NoSuchProcess, psutil.AccessDenied:
        return None


def get_system_info() -> SystemInfo:
    """Get system-wide resource information."""
    mem = psutil.virtual_memory()
    swap = psutil.swap_memory()

    return SystemInfo(
        total_memory_gb=mem.total / 1024 / 1024 / 1024,
        available_memory_gb=mem.available / 1024 / 1024 / 1024,
        memory_percent=mem.percent,
        cpu_count=psutil.cpu_count(),
        swap_total_gb=swap.total / 1024 / 1024 / 1024,
        swap_used_gb=swap.used / 1024 / 1024 / 1024,
    )


def _enhance_language_server_cmdline(p: ProcessInfo) -> str | None:
    """Build an enhanced cmdline description for a language server process."""
    cmdline = p.cmdline
    cmdline_lower = cmdline.lower()
    enhanced = None

    # Extract workspace ID for Codeium language server
    workspace_match = re.search(r"--workspace_id\s+(\S+)", cmdline)
    if workspace_match:
        workspace = workspace_match.group(1).replace("file_", "").replace("_", "/")
        parts = workspace.split("/")
        workspace_short = "/".join(parts[-PATH_COMPONENTS_SHORT:]) if len(parts) > PATH_COMPONENTS_SHORT else workspace
        enhanced = f"{p.name} [workspace: {workspace_short}]"

    # Extract language for JDT LS
    elif "jdtls" in cmdline_lower or "eclipse.jdt" in cmdline_lower:
        data_match = re.search(r"-data\s+(\S+)", cmdline)
        project = data_match.group(1).split("/")[-1] if data_match else None
        enhanced = f"{p.name} [Java: {project}]" if project else f"{p.name} [Java Language Server]"

    # Other language servers - identify by keyword
    elif "gopls" in cmdline_lower:
        enhanced = f"{p.name} [Go Language Server]"
    elif "pyright" in cmdline_lower or "pylance" in cmdline_lower:
        enhanced = f"{p.name} [Python Language Server]"
    elif "rust-analyzer" in cmdline_lower:
        enhanced = f"{p.name} [Rust Language Server]"

    # Truncate long cmdlines if no enhancement found
    elif len(cmdline) > CMDLINE_TRUNCATE_LEN:
        enhanced = cmdline[:CMDLINE_TRUNCATE_LEN] + "..."

    return enhanced


def find_language_servers(processes: list[ProcessInfo]) -> list[ProcessInfo]:
    """Identify language server processes from the process list."""
    keywords = [
        "language_server",
        "jdtls",
        "gopls",
        "pyright",
        "pylance",
        "basedpyright",
        "yaml-language-server",
        "json-language-server",
        "rust-analyzer",
        "eclipse.jdt",
    ]

    result = []
    for p in processes:
        if not any(kw in p.cmdline.lower() for kw in keywords):
            continue

        enhanced = _enhance_language_server_cmdline(p)
        if enhanced is not None:
            result.append(replace(p, cmdline=enhanced))
        else:
            result.append(p)

    return result


def get_mcp_config() -> list[str]:
    """Read MCP configuration and return enabled servers."""
    mcp_config_path = get_paths().mcp_config_path
    if not mcp_config_path.exists():
        return []

    try:
        with mcp_config_path.open(encoding="utf-8") as f:
            config = json.load(f)
            servers = config.get("mcpServers", {})
            return [name for name, cfg in servers.items() if not cfg.get("disabled", False)]
    except json.JSONDecodeError, KeyError:
        return []


def count_extensions() -> int:
    """Count installed Windsurf extensions."""
    ext_dir = get_paths().extensions_dir
    if not ext_dir.exists():
        return 0

    # Count directories that look like extensions (have version numbers)
    count = 0
    for item in ext_dir.iterdir():
        # Simple heuristic: directory with version-like pattern (has digits)
        if item.is_dir() and item.name != "logs" and any(char.isdigit() for char in item.name):
            count += 1
    return count


def _check_orphaned_workspace_proc(cmdline: str, proc: psutil.Process) -> str | None:
    """Check a single language server process for orphaned workspace indexing.

    Returns an issue string if the process is indexing a non-existent workspace, else None.
    """
    if "language_server_macos_arm" not in cmdline:
        return None

    workspace_match = re.search(r"--workspace_id\s+(\S+)", cmdline)
    database_match = re.search(r"--database_dir\s+(\S+)", cmdline)

    if not (workspace_match and database_match):
        return None

    workspace_id = workspace_match.group(1)
    database_dir = database_match.group(1)

    # Convert workspace_id to actual path
    workspace_path = workspace_id.replace("file_", "").replace("_", "/")
    workspace_path_obj = Path("/" + workspace_path)

    if workspace_path_obj.exists():
        return None

    # Get database size
    db_path = Path(database_dir)
    db_size_mb = 0
    if db_path.exists():
        db_size_mb = sum(f.stat().st_size for f in db_path.rglob("*") if f.is_file()) / 1024 / 1024

    # Get memory usage from the process
    mem_mb = 0
    with contextlib.suppress(psutil.NoSuchProcess, psutil.AccessDenied):
        mem_mb = proc.memory_info().rss / 1024 / 1024

    workspace_short = "/".join(workspace_path.split("/")[-3:]) if "/" in workspace_path else workspace_path
    return (
        f"🔴 CRITICAL: Language server indexing non-existent workspace '{workspace_short}' "
        f"(consuming {mem_mb:.0f} MB RAM, {db_size_mb:.0f} MB disk) - "
        f"Fix: Close Windsurf, run: rm -rf {database_dir}"
    )


def check_orphaned_workspaces() -> list[str]:
    """Check for orphaned workspace indexes consuming memory and disk space.

    Detects language servers indexing non-existent workspaces - a major bug
    that can waste 1+ GB of RAM and hundreds of MB of disk space.
    """
    issues = []

    try:
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                cmdline = " ".join(proc.info["cmdline"] or [])
                issue = _check_orphaned_workspace_proc(cmdline, proc)
                if issue:
                    issues.append(issue)
            except psutil.NoSuchProcess, psutil.AccessDenied:
                continue
    except psutil.Error, OSError, re.error:
        pass  # Silently fail if we can't detect processes or parse cmdline

    return issues


def check_pty_leak() -> PtyInfo:
    """Check for PTY (pseudo-terminal) leak by Windsurf.

    Windsurf (and other Electron-based IDEs) can leak PTYs by not closing
    them when terminal sessions end. This can exhaust the system PTY limit
    (macOS default: 511), preventing new terminals from being opened anywhere.

    Returns:
        PtyInfo with Windsurf PTY count, system limit, and total system usage.
    """
    windsurf_pty_count = 0
    system_pty_used = 0
    system_pty_limit = 511  # macOS default

    # Get system PTY limit
    try:
        result = subprocess.run(
            ["sysctl", "-n", "kern.tty.ptmx_max"],  # noqa: S607
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode == 0:
            system_pty_limit = int(result.stdout.strip())
    except subprocess.TimeoutExpired, ValueError, OSError:
        pass

    # Count PTYs using lsof
    app_name = get_paths().app_name
    try:
        result = subprocess.run(
            ["lsof", "/dev/ptmx"],  # noqa: S607
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")
            # Skip header line
            data_lines = lines[1:] if len(lines) > 1 else []
            system_pty_used = len(data_lines)

            # Count lines matching Windsurf process name
            # The app_name contains ".app" but lsof COMMAND column shows just the binary name
            # For "Windsurf.app" -> "Windsurf", for "Windsurf - Next.app" -> "Windsurf"
            windsurf_cmd = app_name.split(".")[0].strip()  # "Windsurf" or "Windsurf - Next"
            for line in data_lines:
                # lsof output: COMMAND PID USER FD TYPE DEVICE ...
                # COMMAND field is first, may be truncated
                parts = line.split()
                if parts and windsurf_cmd.split()[0] in parts[0]:
                    windsurf_pty_count += 1
    except subprocess.TimeoutExpired, OSError:
        pass

    return PtyInfo(
        windsurf_pty_count=windsurf_pty_count,
        system_pty_limit=system_pty_limit,
        system_pty_used=system_pty_used,
    )


def _format_age_str(days: float) -> str:
    """Format age in days to human-readable string."""
    if days >= 1:
        return f"{days:.1f} days"
    oldest_seconds = days * SECONDS_PER_DAY
    if oldest_seconds < SECONDS_PER_MINUTE:
        return f"{oldest_seconds:.0f}s"
    if oldest_seconds < SECONDS_PER_HOUR:
        return f"{oldest_seconds / SECONDS_PER_MINUTE:.0f}m"
    hours = int(oldest_seconds / SECONDS_PER_HOUR)
    minutes = int((oldest_seconds % SECONDS_PER_HOUR) / SECONDS_PER_MINUTE)
    return f"{hours}h {minutes}m"


def _read_log_tail(log_path: Path, tail_bytes: int) -> str | None:
    """Read the last tail_bytes of a log file, or None on failure."""
    if not log_path.exists():
        return None
    try:
        with log_path.open(encoding="utf-8") as f:
            f.seek(0, 2)
            file_size = f.tell()
            f.seek(max(0, file_size - tail_bytes))
            return f.read()
    except OSError, UnicodeDecodeError:
        return None


def _check_orphaned_crashpad_handlers() -> list[str]:
    """Check for orphaned crashpad handler processes."""
    orphaned = []
    main_windsurf_found = False
    app_name = get_paths().app_name

    for proc in psutil.process_iter(["pid", "name", "cmdline", "exe", "create_time"]):
        try:
            name = proc.info["name"] or ""
            exe = proc.info["exe"] or ""
            cmdline = " ".join(proc.info["cmdline"] or [])

            if app_name not in exe and app_name not in cmdline:
                continue

            if is_main_windsurf_process(name, exe, app_name):
                main_windsurf_found = True

            if "crashpad" in name.lower():
                create_time = proc.info["create_time"]
                age_days = (datetime.now(tz=UTC).timestamp() - create_time) / 86400
                orphaned.append((proc.info["pid"], age_days))

        except psutil.NoSuchProcess, psutil.AccessDenied:
            pass

    if main_windsurf_found or not orphaned:
        return []

    pids = [str(pid) for pid, _ in orphaned]
    oldest_days = max(age for _, age in orphaned)
    age_str = _format_age_str(oldest_days)
    pids_str = ", ".join(pids[:MAX_DISPLAY_ITEMS]) + (", ..." if len(pids) > MAX_DISPLAY_ITEMS else "")
    return [f"⚠️  {len(orphaned)} orphaned crash handler(s) (oldest: {age_str}, PIDs: {pids_str}) - Fix: surfmon cleanup --force"]


def _check_extension_logs_dir() -> list[str]:
    """Check for logs directory in extensions folder (package.json error)."""
    paths = get_paths()
    logs_dir = paths.extensions_dir / "logs"
    if not logs_dir.exists():
        return []

    culprit = "unknown extension"
    try:
        log_files = list(logs_dir.glob("*.log"))
        if log_files:
            culprit = log_files[0].stem
    except OSError:
        pass

    return [
        (
            f"⚠️  'logs' directory in extensions folder ({culprit} logging to wrong location) - "
            f"Fix: rm -rf ~/{paths.dotfile_dir}/extensions/logs"
        )
    ]


def _check_main_log_issues(latest_log: Path) -> list[str]:
    """Check main.log for extension host crashes, OOM, and renderer crashes."""
    content = _read_log_tail(latest_log / "main.log", LOG_TAIL_BYTES)
    if content is None:
        return []

    issues = []

    # Extension host crashes (non-zero exit codes only)
    crash_lines = re.findall(
        r"Extension host with pid (\d+) exited with code: (\d+)",
        content,
    )
    crashes = [pid for pid, code in crash_lines if code != "0"]
    if crashes:
        pids_str = ", ".join(crashes[:MAX_DISPLAY_ITEMS]) + (", ..." if len(crashes) > MAX_DISPLAY_ITEMS else "")
        issues.append(f"🔴 {len(crashes)} extension host crash(es) - PIDs: {pids_str}")

    if "UpdateService error" in content:
        issues.append("⚠️  Update service timeouts detected (check NextDNS)")

    if "out of memory" in content.lower() or "oom" in content.lower():
        issues.append("🔴 Out of memory errors detected")

    renderer_crashes = content.count("GPU process crashed")
    if renderer_crashes > 0:
        issues.append(f"⚠️  {renderer_crashes} GPU/renderer crashes detected")

    return issues


def _check_shared_process_log_issues(latest_log: Path) -> list[str]:
    """Check sharedprocess.log for extension errors."""
    content = _read_log_tail(latest_log / "sharedprocess.log", SHARED_LOG_TAIL_BYTES)
    if content is None:
        return []

    error_lines = [
        line
        for line in content.split("\n")
        if "[error]" in line.lower() and "ENOENT" not in line and "marketplace" not in line and "logs/package.json" not in line
    ]

    # Try to extract extension IDs from errors
    extension_errors: dict[str, int] = {}
    for line in error_lines:
        ext_match = re.search(r"([a-z0-9-]+\.[a-z0-9-]+)", line.lower())
        if ext_match:
            ext_id = ext_match.group(1)
            extension_errors[ext_id] = extension_errors.get(ext_id, 0) + 1

    if extension_errors:
        sorted_exts = sorted(extension_errors.items(), key=operator.itemgetter(1), reverse=True)
        ext_summary = ", ".join([f"{ext} ({count})" for ext, count in sorted_exts[:MAX_DISPLAY_ITEMS]])
        return [f"⚠️  Extension errors: {ext_summary}{' ...' if len(sorted_exts) > MAX_DISPLAY_ITEMS else ''}"]

    if len(error_lines) > EXTENSION_ERROR_LINES_THRESHOLD:
        return [f"⚠️  {len(error_lines)} extension errors in shared process"]

    return []


def _check_network_log_issues(latest_log: Path) -> list[str]:
    """Check network-shared.log for telemetry connection failures."""
    content = _read_log_tail(latest_log / "network-shared.log", SHARED_LOG_TAIL_BYTES)
    if content is None:
        return []

    telemetry_errors = content.count("windsurf-telemetry.codeium.com")
    if telemetry_errors > TELEMETRY_ERROR_THRESHOLD:
        return [f"⚠️  {telemetry_errors} telemetry connection failures (check NextDNS)"]
    return []


def check_log_issues() -> list[str]:
    """Check for common issues in Windsurf logs.

    Parses recent Windsurf logs to detect:
    - Orphaned workspace indexes (CRITICAL - can waste 1+ GB RAM)
    - Orphaned crash handlers
    - Extension host crashes
    - Network/telemetry errors
    - OOM (out of memory) errors
    - Renderer crashes
    - Extension errors
    """
    issues = []

    issues.extend(check_orphaned_workspaces())
    issues.extend(_check_orphaned_crashpad_handlers())
    issues.extend(_check_extension_logs_dir())

    # Check latest log directory
    log_base = get_paths().logs_dir
    if log_base.exists():
        log_dirs = sorted(log_base.iterdir(), reverse=True)
        if log_dirs:
            latest_log = log_dirs[0]
            issues.extend(_check_main_log_issues(latest_log))
            issues.extend(_check_shared_process_log_issues(latest_log))
            issues.extend(_check_network_log_issues(latest_log))

    return issues


def _parse_workspace_from_log_line(line: str) -> WorkspaceInfo | None:
    """Parse a workspace load event from a log line, or return None."""
    if "Window will load" not in line or "workspaceUri" not in line:
        return None

    id_match = re.search(r'"id":"([^"]+)"', line)
    path_match = re.search(r'"fsPath":"([^"]+)"', line)
    if not (id_match and path_match):
        return None

    time_match = re.match(r"^([^ ]+\s+[^ ]+)", line)
    return WorkspaceInfo(
        id=id_match.group(1),
        path=path_match.group(1),
        exists=Path(path_match.group(1)).exists(),
        loaded_at=time_match.group(1) if time_match else None,
    )


def get_active_workspaces() -> list[WorkspaceInfo]:
    """Detect currently loaded workspaces from logs and storage.

    Returns:
        List of WorkspaceInfo with ID, path, existence status, and load time.
    """
    workspaces: list[WorkspaceInfo] = []
    log_base = get_paths().logs_dir

    if not log_base.exists():
        return workspaces

    log_dirs = sorted(log_base.iterdir(), reverse=True)
    if not log_dirs:
        return workspaces

    main_log = log_dirs[0] / "main.log"
    if not main_log.exists():
        return workspaces

    try:
        with main_log.open(encoding="utf-8") as f:
            for line in f:
                ws = _parse_workspace_from_log_line(line)
                if ws and not any(w.id == ws.id for w in workspaces):
                    workspaces.append(ws)
    except OSError, UnicodeDecodeError:
        pass  # Can't read or parse main.log for workspaces

    return workspaces


def count_windsurf_launches_today() -> int:
    """Count how many times Windsurf was launched today.

    Counts unique log directories created today.
    """
    log_base = get_paths().logs_dir

    if not log_base.exists():
        return 0

    today = datetime.now(tz=UTC).date()
    launches = 0

    try:
        for log_dir in log_base.iterdir():
            if not log_dir.is_dir():
                continue

            # Log directories are named with timestamp: 20260204T151929
            try:
                # Parse directory name to get date
                dir_name = log_dir.name
                if "T" in dir_name:
                    date_str = dir_name.split("T")[0]  # Get YYYYMMDD part
                    dir_date = datetime.strptime(date_str, "%Y%m%d").replace(tzinfo=UTC).date()

                    if dir_date == today:
                        launches += 1
            except ValueError, IndexError:
                continue
    except OSError:
        pass  # Can't read logs directory

    return launches


def generate_report() -> MonitoringReport:
    """Generate complete monitoring report with optimized CPU sampling."""
    # Get processes
    procs = get_windsurf_processes()

    # Initialize CPU sampling (non-blocking)
    cpu_samples = {}
    for proc in procs:
        try:
            proc.cpu_percent()  # First call initializes, returns 0.0
            cpu_samples[proc.pid] = proc
        except psutil.NoSuchProcess, psutil.AccessDenied:
            pass

    # Sleep once for all processes (instead of once per process)
    if cpu_samples:
        time.sleep(0.5)  # 500ms is enough for reasonable CPU measurement

    # Get final CPU samples
    cpu_values = {}
    for pid, proc in cpu_samples.items():
        try:
            cpu_values[pid] = proc.cpu_percent()
        except psutil.NoSuchProcess, psutil.AccessDenied:
            cpu_values[pid] = 0.0

    # Build process info with pre-sampled CPU
    proc_infos = []
    for p in procs:
        cpu = cpu_values.get(p.pid, 0.0)
        if pi := get_process_info(p, initial_cpu=cpu):
            proc_infos.append(pi)

    total_memory = sum(p.memory_mb for p in proc_infos)
    total_cpu = sum(p.cpu_percent for p in proc_infos)

    # Check PTY usage
    pty_info = check_pty_leak()

    # Build log issues, including PTY leak detection
    log_issues = check_log_issues()

    # Report PTY leak as an issue
    if pty_info.windsurf_pty_count > 0:
        usage_pct = (pty_info.system_pty_used / pty_info.system_pty_limit) * 100 if pty_info.system_pty_limit > 0 else 0
        if pty_info.windsurf_pty_count >= PTY_CRITICAL_COUNT or usage_pct >= PTY_USAGE_CRITICAL_PERCENT:
            log_issues.append(
                f"🔴 CRITICAL: Windsurf is holding {pty_info.windsurf_pty_count} PTYs "
                f"(system: {pty_info.system_pty_used}/{pty_info.system_pty_limit}, {usage_pct:.0f}% used) "
                f"- Fix: Restart Windsurf to release leaked PTYs"
            )
        elif pty_info.windsurf_pty_count >= PTY_WARNING_COUNT:
            log_issues.append(
                f"⚠️  Windsurf PTY leak detected: {pty_info.windsurf_pty_count} PTYs held "
                f"(system: {pty_info.system_pty_used}/{pty_info.system_pty_limit}) "
                f"- Monitor closely, restart Windsurf if it keeps growing"
            )

    return MonitoringReport(
        timestamp=datetime.now(tz=UTC).isoformat(),
        system=get_system_info(),
        windsurf_processes=proc_infos,
        total_windsurf_memory_mb=total_memory,
        total_windsurf_cpu_percent=total_cpu,
        process_count=len(proc_infos),
        language_servers=find_language_servers(proc_infos),
        mcp_servers_enabled=get_mcp_config(),
        extensions_count=count_extensions(),
        log_issues=log_issues,
        active_workspaces=get_active_workspaces(),
        windsurf_launches_today=count_windsurf_launches_today(),
        pty_info=pty_info,
    )


def save_report_json(report: MonitoringReport, output_path: Path) -> None:
    """Save report as JSON."""
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(asdict(report), f, indent=2)
