fn main() {
    uniffi::generate_scaffolding("src/surgedb.udl").unwrap();
}
