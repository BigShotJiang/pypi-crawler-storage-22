fn main() {
    uniffi::uniffi_bindgen_main()
}
