"""
suxitunnel
A simple Python library to expose local servers using Cloudflare Tunnel
"""

from .suxitunnel import Tunnel, TunnelError, open_tunnel

__version__ = "0.1.0"
__all__ = ["Tunnel", "TunnelError", "open_tunnel"]
