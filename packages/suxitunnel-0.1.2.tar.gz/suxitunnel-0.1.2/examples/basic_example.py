#!/usr/bin/env python3
"""
Basic Example - Simplest way to expose a local server
"""

from suxitunnel import Tunnel
import http.server
import socketserver
import threading

PORT = 8000

def start_server():
    """Start a simple HTTP server"""
    Handler = http.server.SimpleHTTPRequestHandler
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"Local server running on http://localhost:{PORT}")
        httpd.serve_forever()

if __name__ == "__main__":
    # Start local server in background
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()
    
    # Create tunnel
    print("Creating tunnel...")
    tunnel = Tunnel(PORT)
    
    print(f"\n{'='*60}")
    print(f"✅ Tunnel is live!")
    print(f"🌐 Public URL: {tunnel.url}")
    print(f"{'='*60}\n")
    
    try:
        input("Press Enter to close tunnel...\n")
    except KeyboardInterrupt:
        print("\nClosing...")
    finally:
        tunnel.close()
        print("Tunnel closed.")
