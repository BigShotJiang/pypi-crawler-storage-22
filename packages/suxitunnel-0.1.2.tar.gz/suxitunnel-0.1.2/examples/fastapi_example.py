#!/usr/bin/env python3
"""
FastAPI Example - Expose a FastAPI app with Cloudflare Tunnel
"""

from fastapi import FastAPI, Request
from suxitunnel import Tunnel
import uvicorn

app = FastAPI(
    title="FastAPI with Cloudflare Tunnel",
    description="Example of exposing FastAPI via Cloudflare"
)

@app.get("/")
async def root():
    return {
        "message": "Hello from FastAPI!",
        "framework": "FastAPI",
        "tunnel": "Cloudflare"
    }

@app.get("/api/hello")
async def hello():
    return {"message": "Hello, World!"}

@app.get("/api/info")
async def info(request: Request):
    return {
        "server": "FastAPI",
        "tunnel": "Cloudflare",
        "client_ip": request.client.host,
        "user_agent": request.headers.get("user-agent")
    }

@app.post("/api/echo")
async def echo(data: dict):
    return {
        "received": data,
        "status": "success"
    }

if __name__ == "__main__":
    PORT = 8000
    
    # Create tunnel
    print("Creating tunnel...")
    tunnel = Tunnel(PORT)
    
    print(f"\n{'='*60}")
    print(f"✅ FastAPI is now public!")
    print(f"🌐 Public URL: {tunnel.url}")
    print(f"📚 API Docs: {tunnel.url}/docs")
    print(f"{'='*60}\n")
    
    # Start FastAPI
    try:
        uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="info")
    finally:
        tunnel.close()
