#!/usr/bin/env python3
"""
Flask Example - Expose a Flask app with Cloudflare Tunnel
"""

from flask import Flask, jsonify, request
from suxitunnel import Tunnel

app = Flask(__name__)

@app.route('/')
def index():
    return """
    <h1>Hello from Flask!</h1>
    <p>This Flask app is exposed via Cloudflare Tunnel.</p>
    <p>Try these endpoints:</p>
    <ul>
        <li><a href="/api/hello">/api/hello</a></li>
        <li><a href="/api/info">/api/info</a></li>
    </ul>
    """

@app.route('/api/hello')
def hello():
    return jsonify({
        "message": "Hello from Flask!",
        "status": "success"
    })

@app.route('/api/info')
def info():
    return jsonify({
        "server": "Flask",
        "tunnel": "Cloudflare",
        "remote_addr": request.remote_addr,
        "user_agent": request.headers.get('User-Agent')
    })

if __name__ == '__main__':
    PORT = 5000
    
    # Create tunnel first
    print("Creating tunnel...")
    tunnel = Tunnel(PORT)
    
    print(f"\n{'='*60}")
    print(f"✅ Flask app is now public!")
    print(f"🌐 Public URL: {tunnel.url}")
    print(f"{'='*60}\n")
    
    # Start Flask (this blocks)
    try:
        app.run(host='0.0.0.0', port=PORT)
    finally:
        tunnel.close()
