"""
svg_viewbox_repair package - SVG viewBox repair utility

Adds missing viewBox attributes to SVG files based on width/height.
"""

__version__ = "1.0.0"
