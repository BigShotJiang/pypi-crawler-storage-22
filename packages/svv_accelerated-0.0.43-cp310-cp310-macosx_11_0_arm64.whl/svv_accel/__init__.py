# Placeholder package for compiled accelerator modules.
# Wheels for 'svv-accelerated' ship extension modules under this namespace.

