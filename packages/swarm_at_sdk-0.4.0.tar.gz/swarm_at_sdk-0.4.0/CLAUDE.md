# CLAUDE.md

## Project

swarm.at — Git-native Information Settlement Protocol for agentic workflows.

## Commands

```bash
# Tests
pytest tests/ -v --tb=short

# Lint
ruff check swarm_at/ tests/

# Type check (strict)
mypy swarm_at/ --ignore-missing-imports

# Run API
uvicorn swarm_at.api.main:app --reload

# Run MCP server
python -m swarm_at.mcp
```

## Architecture

```
swarm_at/
  models.py          # Pydantic models: Proposal, Header, Payload, LedgerEntry
  settler.py         # Ledger: JSONL hash-chain, generate_hash(), GENESIS_HASH
  engine.py          # SwarmAtEngine: verify_and_settle() pipeline
  context.py         # Context Injector: keyword-filtered state slices
  dispatcher.py      # Model Arbitrage: route by complexity to tier
  auditor.py         # Shadow Auditor: cross-model divergence decorator
  consensus.py       # Consensus Engine: stake/verify/finalize rounds
  heartbeat.py       # Settlement Pulse: periodic drift detection
  agents.py          # Agent Identity: roles, trust levels, registry
  workflow.py        # Workflow Chaining: Bead → Molecule → Formula → Convoy
  gitplane.py        # Git-Native Ledger: branching/merging data plane
  openclaw.py        # Discovery generators: llms.txt, A2A card, robots.txt, JSON-LD, OpenAPI
  seed_blueprints.py # Canonical blueprint seeding (audit-chain, code-review, research)
  api/main.py        # FastAPI: settlement, agents, blueprints, whoami, discovery routes
  api/state.py       # Mutable API state: ledger, engine, agent_registry, blueprint_store
  mcp/server.py      # MCP server via FastMCP
  sdk/client.py      # Python SDK: SwarmClient
```

## Conventions

- **Tests**: datasette-enrichments style. Shared fixtures in `tests/conftest.py`. Factory functions (`make_proposal`, `make_settle_request`). `@pytest.mark.parametrize` with `ids=`. Assertion helpers (`assert_settled`, `assert_rejected`, `assert_escrowed`).
- **Hashes**: Always 64 chars. Use `"0" * 64` for test genesis hashes, never shorter strings.
- **API state**: Read from `swarm_at.api.state` module at call time, not import time. The autouse `_reset_api_state` fixture swaps it per test (including `blueprint_store`).
- **OpenClaw**: Pure functions in `openclaw.py` — no side effects, lazy-imported from routes. Discovery URLs come from `SWARM_API_URL`/`SWARM_SITE_URL` env vars.
- **GitLedger**: Uses subprocess for git ops. Fixtures use lazy imports to avoid import-time git operations.
- **Types**: mypy strict mode. Parameterize all generics. MCP decorators need `# type: ignore[misc,untyped-decorator]`.

## Related Repos

- **Public Ledger**: [Mediaeater/swarm-at-ledger](https://github.com/Mediaeater/swarm-at-ledger) — the public settlement record. When changing settlement types, ledger format, or verification endpoints here, check if the ledger repo's README needs updating too.

## Commit Style

- Imperative subject, ~50 chars
- Body explains why, not what
- No co-author tags
