"""Framework adapters for swarm.at settlement protocol."""
