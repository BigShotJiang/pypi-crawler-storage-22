"""FastAPI service exposing the swarm.at settlement protocol."""

from __future__ import annotations

import os

import swarm_at.api.state as state
from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, ValidationError
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address

from swarm_at.context import get_context_slice
from swarm_at.models import (
    SettleRequest,
    SettlementResult,
)

app = FastAPI(
    title="swarm.at",
    description="Stateless Swarm-as-a-Service Information Settlement Protocol",
    version="0.3.0",
)

# CORS — allow the frontend and local dev
_allowed_origins = os.environ.get(
    "SWARM_CORS_ORIGINS", "https://swarm.at,http://localhost:3000"
).split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting
limiter = Limiter(key_func=get_remote_address, headers_enabled=True)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)  # type: ignore[arg-type]
app.add_middleware(SlowAPIMiddleware)


def verify_api_key(request: Request) -> None:
    """Validate Bearer token via JWT or API key. No-op in dev mode."""
    if not state.api_keys and state.jwt_auth is None:
        return  # Auth disabled (dev mode)
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer token")
    token = auth[7:].strip()
    # Try JWT first
    if state.jwt_auth is not None:
        try:
            state.jwt_auth.verify_token(token)
            return
        except Exception:
            pass
    # Fall back to API key
    if token in state.api_keys:
        return
    raise HTTPException(status_code=403, detail="Invalid API key or token")


@app.post("/v1/settle", response_model=SettlementResult, dependencies=[Depends(verify_api_key)])
def settle(request: SettleRequest) -> SettlementResult:
    """Submit a proposal for settlement."""
    return state.engine.verify_and_settle(request.primary, shadow=request.shadow)


@app.get("/v1/context", dependencies=[Depends(verify_api_key)])
def context(keywords: str = Query(..., description="Comma-separated keywords")) -> dict[str, str]:
    """Get a context slice for a task."""
    kw_list = [k.strip() for k in keywords.split(",") if k.strip()]
    return get_context_slice(state.shared_state, kw_list)


@app.get("/v1/status/{task_id}", dependencies=[Depends(verify_api_key)])
def status(task_id: str) -> dict[str, object]:
    """Check settlement status of a specific task."""
    entries = state.ledger.read_all()
    for entry in reversed(entries):
        if entry.task_id == task_id:
            return {
                "task_id": task_id,
                "status": "SETTLED",
                "hash": entry.current_hash,
                "timestamp": entry.timestamp,
            }
    raise HTTPException(status_code=404, detail=f"Task {task_id} not found in ledger")


@app.get("/v1/ledger/latest", dependencies=[Depends(verify_api_key)])
def ledger_latest() -> dict[str, str]:
    """Get the latest settled hash."""
    return {"latest_hash": state.ledger.get_latest_hash()}


@app.get("/v1/ledger/verify", dependencies=[Depends(verify_api_key)])
def ledger_verify() -> dict[str, object]:
    """Verify full ledger integrity."""
    intact = state.ledger.verify_chain()
    entry_count = len(state.ledger.read_all())
    return {
        "intact": intact,
        "entry_count": entry_count,
    }


# ---------------------------------------------------------------------------
# Public read-only endpoints (no auth required)
# ---------------------------------------------------------------------------


@app.get("/public/ledger")
@limiter.limit("60/minute")
def public_ledger(
    request: Request,
    offset: int = Query(0, ge=0, description="Number of entries to skip"),
    limit: int = Query(50, ge=1, le=500, description="Max entries to return"),
) -> JSONResponse:
    """Paginated public ledger view."""
    entries = state.ledger.read_all()
    total = len(entries)
    page = entries[offset : offset + limit]
    return JSONResponse({
        "entries": [e.model_dump() for e in page],
        "total": total,
        "offset": offset,
        "limit": limit,
    })


@app.get("/public/ledger/latest")
def public_ledger_latest() -> dict[str, str]:
    """Latest settled hash (public)."""
    return {"latest_hash": state.ledger.get_latest_hash()}


@app.get("/public/ledger/verify")
def public_ledger_verify() -> dict[str, object]:
    """Verify chain integrity (public)."""
    intact = state.ledger.verify_chain()
    entry_count = len(state.ledger.read_all())
    return {"intact": intact, "entry_count": entry_count}


@app.get("/public/ledger/entry/{task_id}")
def public_ledger_entry(task_id: str) -> dict[str, object]:
    """Look up a single entry by task_id (public)."""
    entries = state.ledger.read_all()
    for entry in reversed(entries):
        if entry.task_id == task_id:
            return entry.model_dump()
    raise HTTPException(status_code=404, detail=f"Task {task_id} not found in ledger")


# ---------------------------------------------------------------------------
# Public agent registry endpoints (no auth required)
# ---------------------------------------------------------------------------


_AGENT_SORT_KEYS = {
    "reputation": lambda a: a.reputation_score,
    "volume": lambda a: a.settlements_completed,
    "success_rate": lambda a: a.success_rate,
    "active": lambda a: a.last_active,
    "seniority": lambda a: a.registered_at,
}


@app.get("/public/agents")
@limiter.limit("60/minute")
def public_agents(
    request: Request,
    min_trust: str = Query("untrusted", description="Minimum trust level"),
    role: str | None = Query(None, description="Filter by role (worker, orchestrator, etc.)"),
    sort: str = Query("reputation", description="Sort key: reputation, volume, success_rate, active, seniority"),
    order: str = Query("desc", description="Sort order: asc or desc"),
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    page_size: int = Query(50, ge=1, le=200, description="Results per page"),
) -> JSONResponse:
    """Public agent leaderboard — ranked directory of agents."""
    from swarm_at.agents import AgentRole, TrustLevel

    try:
        level = TrustLevel(min_trust)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid trust level: {min_trust}")

    if sort not in _AGENT_SORT_KEYS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid sort: {sort}. Must be one of: {', '.join(_AGENT_SORT_KEYS)}",
        )

    if order not in ("asc", "desc"):
        raise HTTPException(status_code=400, detail="order must be 'asc' or 'desc'")

    agents = state.agent_registry.find_by_trust(level)

    if role is not None:
        try:
            role_filter = AgentRole(role)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid role: {role}")
        agents = [a for a in agents if a.role == role_filter]

    agents.sort(key=_AGENT_SORT_KEYS[sort], reverse=(order == "desc"))

    total = len(agents)
    start = (page - 1) * page_size
    page_agents = agents[start : start + page_size]

    return JSONResponse({
        "agents": [
            {
                "agent_id": a.agent_id,
                "role": a.role.value,
                "trust_level": a.trust_level.value,
                "settlements_completed": a.settlements_completed,
                "success_rate": round(a.success_rate, 4),
                "reputation_score": round(a.reputation_score, 4),
                "last_active": a.last_active,
            }
            for a in page_agents
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_more": start + page_size < total,
    })


@app.get("/public/agents/{agent_id}")
def public_agent_detail(agent_id: str) -> dict[str, object]:
    """Public agent profile — verified work history."""
    from swarm_at.agents import AgentError

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")
    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "settlements_completed": agent.settlements_completed,
        "settlements_failed": agent.settlements_failed,
        "success_rate": round(agent.success_rate, 4),
        "reputation_score": round(agent.reputation_score, 4),
        "capabilities": agent.capabilities,
        "registered_at": agent.registered_at,
        "under_review": agent.under_review,
    }


# ---------------------------------------------------------------------------
# Public blueprint endpoints (no auth required)
# ---------------------------------------------------------------------------


@app.get("/public/blueprints")
@limiter.limit("60/minute")
def public_blueprints(
    request: Request,
    tag: str | None = Query(None, description="Filter by tag"),
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    page_size: int = Query(50, ge=1, le=200, description="Results per page"),
) -> JSONResponse:
    """Public blueprint catalog — list and filter blueprints."""
    blueprints = state.blueprint_store.list_blueprints(tag=tag)
    total = len(blueprints)
    start = (page - 1) * page_size
    page_bps = blueprints[start : start + page_size]

    return JSONResponse({
        "blueprints": [
            {
                "blueprint_id": bp.blueprint_id,
                "name": bp.name,
                "description": bp.description,
                "version": bp.version,
                "author": bp.author,
                "tags": bp.tags,
                "step_count": len(bp.steps),
                "credit_cost": bp.credit_cost,
                "validated": bp.validated,
            }
            for bp in page_bps
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_more": start + page_size < total,
    })


@app.get("/public/blueprints/{blueprint_id}")
def public_blueprint_detail(blueprint_id: str) -> dict[str, object]:
    """Blueprint detail with steps, credit cost, and fork count."""
    from swarm_at.blueprints import BlueprintError

    try:
        bp = state.blueprint_store.get_blueprint(blueprint_id)
    except BlueprintError:
        raise HTTPException(status_code=404, detail=f"Blueprint {blueprint_id} not found")

    try:
        forks = state.blueprint_store.fork_count(blueprint_id)
    except BlueprintError:
        forks = 0

    return {
        "blueprint_id": bp.blueprint_id,
        "name": bp.name,
        "description": bp.description,
        "version": bp.version,
        "author": bp.author,
        "tags": bp.tags,
        "steps": [
            {
                "step_id": s.step_id,
                "name": s.name,
                "description": s.description,
                "depends_on": s.depends_on,
                "agent_role": s.agent_role,
                "complexity": s.complexity,
            }
            for s in bp.steps
        ],
        "credit_cost": bp.credit_cost,
        "validated": bp.validated,
        "fork_count": forks,
    }


# ---------------------------------------------------------------------------
# Agent registration (auth required)
# ---------------------------------------------------------------------------


class RegisterAgentRequest(BaseModel):
    """Request body for agent self-registration."""

    agent_id: str
    role: str = "worker"
    capabilities: list[str] = []


@app.post("/v1/agents/register", dependencies=[Depends(verify_api_key)])
def register_agent(req: RegisterAgentRequest) -> dict[str, object]:
    """Register a new agent identity."""
    from swarm_at.agents import AgentError, AgentRole

    try:
        role = AgentRole(req.role)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid role: {req.role}")

    try:
        agent = state.agent_registry.register(
            agent_id=req.agent_id,
            role=role,
            capabilities=req.capabilities,
        )
    except ValidationError as exc:
        raise HTTPException(status_code=400, detail=exc.errors()[0]["msg"])
    except AgentError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "capabilities": agent.capabilities,
        "registered_at": agent.registered_at,
    }


@app.get("/v1/agents/{agent_id}", dependencies=[Depends(verify_api_key)])
def get_agent(agent_id: str) -> dict[str, object]:
    """Authenticated agent detail — includes review status."""
    from swarm_at.agents import AgentError

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "settlements_completed": agent.settlements_completed,
        "settlements_failed": agent.settlements_failed,
        "success_rate": round(agent.success_rate, 4),
        "reputation_score": round(agent.reputation_score, 4),
        "capabilities": agent.capabilities,
        "registered_at": agent.registered_at,
        "last_active": agent.last_active,
        "under_review": agent.under_review,
        "divergence_penalty": agent.divergence_penalty,
    }


@app.get("/v1/whoami", dependencies=[Depends(verify_api_key)])
def whoami(agent_id: str = Query(..., description="Agent ID to inspect")) -> dict[str, object]:
    """Agent self-check — trust status, effective permissions, promotion path."""
    from swarm_at.agents import (
        AgentError,
        BAYESIAN_THRESHOLDS,
        ROLE_DEFAULT_TOOLS,
        TrustLevel,
    )

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

    # Compute effective allowed tools (after trust gates)
    role_tools = ROLE_DEFAULT_TOOLS.get(agent.role, set())
    base_tools = set(agent.allowed_tools) if agent.allowed_tools is not None else role_tools
    effective_tools = sorted(
        t for t in base_tools
        if t not in agent.denied_tools and agent.can_use_tool(t)
    )

    # Next promotion target
    trust_order = list(TrustLevel)
    current_idx = trust_order.index(agent.trust_level)
    next_promotion: dict[str, object] | None = None
    if agent.trust_level != TrustLevel.SENIOR:
        target = trust_order[current_idx + 1]
        thresholds = BAYESIAN_THRESHOLDS[target]
        next_promotion = {
            "target_level": target.value,
            "required_volume": thresholds["min_volume"],
            "required_lower_bound": thresholds["min_lower_bound"],
        }

    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "reputation_score": round(agent.reputation_score, 4),
        "bayesian_lower_bound": round(agent.bayesian_lower_bound, 4),
        "is_in_cooldown": agent.is_in_cooldown,
        "cooldown_until": agent.cooldown_until,
        "under_review": agent.under_review,
        "allowed_tools": effective_tools,
        "next_promotion": next_promotion,
    }


# ---------------------------------------------------------------------------
# Credit endpoints (auth required)
# ---------------------------------------------------------------------------


class TopupRequest(BaseModel):
    """Request body for credit topup."""

    amount: float


@app.get("/v1/credits/{agent_id}", dependencies=[Depends(verify_api_key)])
def get_credits(agent_id: str) -> dict[str, object]:
    """Check an agent's credit balance."""
    from swarm_at.credits import CreditError

    try:
        balance = state.credit_ledger.balance(agent_id)
    except CreditError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not registered in credit ledger")
    return {"agent_id": agent_id, "balance": balance}


@app.post("/v1/credits/{agent_id}/topup", dependencies=[Depends(verify_api_key)])
def topup_credits(agent_id: str, req: TopupRequest) -> dict[str, object]:
    """Add credits to an agent's balance."""
    if req.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    new_balance = state.credit_ledger.topup(agent_id, req.amount)
    return {"agent_id": agent_id, "balance": new_balance}


# ---------------------------------------------------------------------------
# Blueprint execution (auth required)
# ---------------------------------------------------------------------------


@app.post("/v1/blueprints/{blueprint_id}/fork", dependencies=[Depends(verify_api_key)])
def fork_blueprint(blueprint_id: str, agent_id: str = Query("anonymous")) -> dict[str, object]:
    """Fork a blueprint into an executable workflow molecule. Debits credit cost."""
    from swarm_at.blueprints import BlueprintError
    from swarm_at.credits import CreditError
    from swarm_at.workflow import fork_blueprint as _fork

    try:
        bp = state.blueprint_store.get_blueprint(blueprint_id)
    except BlueprintError:
        raise HTTPException(status_code=404, detail=f"Blueprint {blueprint_id} not found")

    # Debit credits for the blueprint cost
    if bp.credit_cost > 0:
        try:
            state.credit_ledger.debit(agent_id, bp.credit_cost)
        except CreditError as exc:
            raise HTTPException(status_code=402, detail=str(exc))

    molecule = _fork(bp, agent_id=agent_id)
    state.workflow_engine.register_molecule(molecule)
    return {
        "molecule_id": molecule.molecule_id,
        "name": molecule.name,
        "bead_count": len(molecule.beads),
        "metadata": molecule.metadata,
    }


class ExecuteStepRequest(BaseModel):
    """Request body for executing a blueprint step."""
    agent_id: str
    step_id: str
    data: dict[str, object] = {}
    confidence: float = 0.95


@app.post("/v1/molecules/{molecule_id}/execute", dependencies=[Depends(verify_api_key)])
def execute_step(molecule_id: str, req: ExecuteStepRequest) -> dict[str, object]:
    """Execute a single step in a forked blueprint molecule."""
    from swarm_at.workflow import WorkflowError
    try:
        bead = state.workflow_engine.execute_bead(
            molecule_id=molecule_id,
            bead_id=req.step_id,
            output_data=req.data,
        )
    except WorkflowError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    if bead.settlement_hash is None:
        raise HTTPException(status_code=400, detail=f"Step failed: {bead.error}")

    return {
        "molecule_id": molecule_id,
        "step_id": req.step_id,
        "status": "SETTLED",
        "hash": bead.settlement_hash,
    }


# ---------------------------------------------------------------------------
# JWT token endpoint (public — agents exchange credentials for tokens)
# ---------------------------------------------------------------------------


class TokenRequest(BaseModel):
    """Request body for JWT token generation."""

    agent_id: str
    role: str = "worker"


@app.post("/v1/auth/token")
def create_token(req: TokenRequest) -> dict[str, object]:
    """Issue a JWT token for an agent. Requires JWT auth to be configured."""
    if state.jwt_auth is None:
        raise HTTPException(status_code=501, detail="JWT auth not configured. Set SWARM_JWT_SECRET.")
    token = state.jwt_auth.create_token(agent_id=req.agent_id, role=req.role)
    return {"token": token, "agent_id": req.agent_id, "role": req.role}


# ---------------------------------------------------------------------------
# Ledger mode endpoint
# ---------------------------------------------------------------------------


@app.get("/v1/ledger/mode")
def ledger_mode() -> dict[str, object]:
    """Report which ledger backend is active."""
    from swarm_at.ledger_factory import ledger_status as _status
    return _status(state.ledger)


# ---------------------------------------------------------------------------
# Webhook endpoints (auth required)
# ---------------------------------------------------------------------------


class WebhookRequest(BaseModel):
    """Request body for webhook registration."""

    event: str
    url: str


@app.post("/v1/webhooks", dependencies=[Depends(verify_api_key)])
def register_webhook(req: WebhookRequest) -> dict[str, object]:
    """Register a webhook URL for settlement events."""
    valid_events = {"settlement.created", "settlement.rejected", "blueprint.forked"}
    if req.event not in valid_events:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid event: {req.event}. Must be one of: {', '.join(sorted(valid_events))}",
        )
    state.webhook_registry.register(req.event, req.url)
    return {"event": req.event, "url": req.url, "status": "registered"}


@app.delete("/v1/webhooks", dependencies=[Depends(verify_api_key)])
def unregister_webhook(req: WebhookRequest) -> dict[str, object]:
    """Remove a webhook registration."""
    removed = state.webhook_registry.unregister(req.event, req.url)
    if not removed:
        raise HTTPException(status_code=404, detail="Webhook not found")
    return {"event": req.event, "url": req.url, "status": "removed"}


@app.get("/v1/webhooks", dependencies=[Depends(verify_api_key)])
def list_webhooks(event: str | None = Query(None)) -> dict[str, object]:
    """List registered webhooks."""
    hooks = state.webhook_registry.list_hooks(event)
    return {"webhooks": hooks, "total": state.webhook_registry.count}


@app.get("/public/schema")
def public_schema() -> dict[str, object]:
    """Machine-readable protocol schema for agent discovery."""
    from swarm_at.models import Proposal, SettlementResult, SettleRequest
    from swarm_at.tiers import TIER_POLICIES

    return {
        "protocol": "swarm.at",
        "version": "0.1.0",
        "schemas": {
            "Proposal": Proposal.model_json_schema(),
            "SettlementResult": SettlementResult.model_json_schema(),
            "SettleRequest": SettleRequest.model_json_schema(),
        },
        "guarantees": [
            "determinism",
            "idempotency",
            "chain_integrity",
            "trust_scoring",
        ],
        "tiers": {
            tier.value: {
                "enforce_chain": policy.enforce_chain,
                "enforce_confidence": policy.enforce_confidence,
                "write_ledger": policy.write_ledger,
                "log_only": policy.log_only,
            }
            for tier, policy in TIER_POLICIES.items()
        },
    }


@app.get("/health")
def health() -> dict[str, str]:
    """Health check for load balancers and deployment platforms."""
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Discovery routes (public, no auth)
# ---------------------------------------------------------------------------

_API_URL = os.environ.get("SWARM_API_URL", "https://api.swarm.at")
_SITE_URL = os.environ.get("SWARM_SITE_URL", "https://swarm.at")


@app.get("/llms.txt", response_class=PlainTextResponse)
def llms_txt() -> str:
    """LLM-readable protocol summary (llms.txt v1.1.0)."""
    from swarm_at.openclaw import generate_llms_txt
    return generate_llms_txt(_API_URL, _SITE_URL)


@app.get("/robots.txt", response_class=PlainTextResponse)
def robots_txt() -> str:
    """Crawler guidance with llms.txt reference."""
    from swarm_at.openclaw import generate_robots_txt
    return generate_robots_txt(_API_URL)


@app.get("/.well-known/agent-card.json")
def agent_card() -> JSONResponse:
    """A2A agent card for agent-to-agent discovery."""
    from swarm_at.openclaw import generate_agent_card
    return JSONResponse(content=generate_agent_card(_API_URL))


@app.get("/.well-known/openapi.json")
def well_known_openapi() -> JSONResponse:
    """Enriched OpenAPI spec at .well-known path."""
    from swarm_at.openclaw import enrich_openapi
    schema = app.openapi()
    enriched = enrich_openapi(schema, api_url=_API_URL)
    return JSONResponse(content=enriched)
