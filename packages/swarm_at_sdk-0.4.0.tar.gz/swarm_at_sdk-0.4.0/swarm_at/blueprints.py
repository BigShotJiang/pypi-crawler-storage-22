"""Blueprint Store: pre-validated transaction chain templates with settlement credits."""

from __future__ import annotations

import time
from typing import Any

from pydantic import BaseModel, Field


class Blueprint(BaseModel):
    """A pre-validated transaction chain template.

    Blueprints define reusable process flows that builders can fork
    into their private data planes.
    """

    blueprint_id: str
    name: str
    description: str = ""
    version: str = "1.0.0"
    author: str = ""
    tags: list[str] = Field(default_factory=list)
    created_at: float = Field(default_factory=time.time)

    # The chain definition: ordered list of step templates
    steps: list[BlueprintStep] = Field(default_factory=list)

    # Credit cost per atomic task settled using this blueprint
    credit_cost: float = Field(default=1.0, ge=0.0)

    # Validation status
    validated: bool = False
    validation_hash: str = ""


class BlueprintStep(BaseModel):
    """A single step in a blueprint's transaction chain."""

    step_id: str
    name: str
    description: str = ""
    depends_on: list[str] = Field(default_factory=list)
    agent_role: str = "worker"
    input_schema: dict[str, Any] = Field(default_factory=dict)
    expected_output: dict[str, Any] = Field(default_factory=dict)
    complexity: float = Field(default=0.5, ge=0.1, le=1.0)


# Fix forward reference
Blueprint.model_rebuild()


class CreditAccount(BaseModel):
    """Settlement credit balance for a builder."""

    account_id: str
    balance: float = 0.0
    total_earned: float = 0.0
    total_spent: float = 0.0


class BlueprintStore:
    """Registry of pre-validated blueprint templates.

    Manages blueprint lifecycle: register, validate, fork, and track credits.
    """

    def __init__(self) -> None:
        self._blueprints: dict[str, Blueprint] = {}
        self._accounts: dict[str, CreditAccount] = {}
        self._forks: dict[str, list[str]] = {}  # blueprint_id -> [account_ids]

    def register_blueprint(self, blueprint: Blueprint) -> Blueprint:
        """Register a new blueprint template."""
        if blueprint.blueprint_id in self._blueprints:
            raise BlueprintError(
                f"Blueprint {blueprint.blueprint_id} already registered."
            )
        self._blueprints[blueprint.blueprint_id] = blueprint
        self._forks[blueprint.blueprint_id] = []
        return blueprint

    def get_blueprint(self, blueprint_id: str) -> Blueprint:
        """Look up a blueprint by ID."""
        if blueprint_id not in self._blueprints:
            raise BlueprintError(f"Blueprint {blueprint_id} not found.")
        return self._blueprints[blueprint_id]

    def validate_blueprint(self, blueprint_id: str, validation_hash: str) -> Blueprint:
        """Mark a blueprint as validated after review."""
        bp = self.get_blueprint(blueprint_id)
        bp.validated = True
        bp.validation_hash = validation_hash
        return bp

    def list_blueprints(
        self,
        tag: str | None = None,
        validated_only: bool = False,
    ) -> list[Blueprint]:
        """List blueprints with optional filters."""
        results = list(self._blueprints.values())
        if validated_only:
            results = [bp for bp in results if bp.validated]
        if tag:
            results = [bp for bp in results if tag in bp.tags]
        return results

    def fork_blueprint(self, blueprint_id: str, account_id: str) -> Blueprint:
        """Fork a blueprint for a builder's private use.

        Returns a copy of the blueprint. Tracks the fork relationship.
        """
        bp = self.get_blueprint(blueprint_id)
        if not bp.validated:
            raise BlueprintError(
                f"Blueprint {blueprint_id} must be validated before forking."
            )
        self._forks[blueprint_id].append(account_id)
        return bp.model_copy()

    def fork_count(self, blueprint_id: str) -> int:
        """Number of times a blueprint has been forked."""
        if blueprint_id not in self._forks:
            raise BlueprintError(f"Blueprint {blueprint_id} not found.")
        return len(self._forks[blueprint_id])

    # Credit management

    def create_account(self, account_id: str, initial_balance: float = 0.0) -> CreditAccount:
        """Create a credit account for a builder."""
        if account_id in self._accounts:
            raise BlueprintError(f"Account {account_id} already exists.")
        account = CreditAccount(account_id=account_id, balance=initial_balance)
        self._accounts[account_id] = account
        return account

    def get_account(self, account_id: str) -> CreditAccount:
        """Look up an account."""
        if account_id not in self._accounts:
            raise BlueprintError(f"Account {account_id} not found.")
        return self._accounts[account_id]

    def charge_settlement(
        self, account_id: str, blueprint_id: str,
    ) -> CreditAccount:
        """Charge a settlement credit when an atomic task is committed.

        Deducts the blueprint's credit_cost from the builder's balance.
        """
        account = self.get_account(account_id)
        bp = self.get_blueprint(blueprint_id)
        if account.balance < bp.credit_cost:
            raise InsufficientCreditsError(
                f"Account {account_id} has {account.balance} credits, "
                f"needs {bp.credit_cost}."
            )
        account.balance -= bp.credit_cost
        account.total_spent += bp.credit_cost
        return account

    def earn_credits(self, account_id: str, amount: float) -> CreditAccount:
        """Credit earnings for verified settlement work."""
        account = self.get_account(account_id)
        account.balance += amount
        account.total_earned += amount
        return account

    @property
    def blueprint_count(self) -> int:
        return len(self._blueprints)


class BlueprintError(Exception):
    pass


class InsufficientCreditsError(BlueprintError):
    pass
