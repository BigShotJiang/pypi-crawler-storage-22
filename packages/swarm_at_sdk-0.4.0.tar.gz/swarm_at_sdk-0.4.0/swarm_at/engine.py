"""Core Settlement Engine: verify proposals and commit to ledger."""

from __future__ import annotations

import time

from swarm_at.models import (
    InstitutionalRules,
    LedgerEntry,
    Proposal,
    SettlementResult,
    SettlementStatus,
)
from swarm_at.settler import Ledger, generate_hash


class SwarmAtEngine:
    """Orchestrates verification and settlement of agent proposals."""

    def __init__(
        self,
        ledger: Ledger | None = None,
        rules: InstitutionalRules | None = None,
    ):
        self.ledger = ledger or Ledger()
        self.rules = rules or InstitutionalRules()

    def verify_and_settle(
        self,
        primary: Proposal,
        shadow: Proposal | None = None,
    ) -> SettlementResult:
        """Run the full verification pipeline and settle if valid.

        Steps:
        1. Hash-chain integrity check
        2. Confidence threshold check
        3. Shadow audit divergence check (if shadow provided)
        4. Commit to ledger
        """
        latest_hash = self.ledger.get_latest_hash()

        # 1. Integrity check
        if primary.header.parent_hash != latest_hash:
            return SettlementResult(
                status=SettlementStatus.REJECTED,
                reason="State drift detected. Re-base required.",
            )

        # 2. Confidence check
        if primary.payload.confidence_score < self.rules.min_confidence:
            return SettlementResult(
                status=SettlementStatus.REJECTED,
                reason=f"Insufficient confidence score: {primary.payload.confidence_score} < {self.rules.min_confidence}",
            )

        # 3. Shadow audit
        if shadow is not None:
            divergence = calculate_divergence(primary, shadow)
            if divergence > self.rules.max_drift_allowed:
                return SettlementResult(
                    status=SettlementStatus.ESCROWED,
                    reason=f"High model divergence: {divergence} > {self.rules.max_drift_allowed}",
                )

        # 4. Finality — build entry, hash it, append
        entry_dict = {
            "timestamp": time.time(),
            "task_id": primary.header.task_id,
            "parent_hash": latest_hash,
            "payload": primary.payload.data_update,
            "current_hash": "",
        }
        entry_dict["current_hash"] = generate_hash(entry_dict)

        entry = LedgerEntry.model_validate(entry_dict)
        self.ledger.append_entry(entry)

        return SettlementResult(
            status=SettlementStatus.SETTLED,
            hash=entry.current_hash,
        )


def calculate_divergence(primary: Proposal, shadow: Proposal) -> float:
    """Calculate divergence between primary and shadow proposals.

    Returns 0.0 if payloads match, 1.0 if they differ.
    Can be extended with NLP similarity for partial matches.
    """
    p1 = primary.payload.data_update
    p2 = shadow.payload.data_update

    if p1 == p2:
        return 0.0

    # Structural comparison: count matching vs total keys
    all_keys = set(p1.keys()) | set(p2.keys())
    if not all_keys:
        return 0.0

    matching = sum(1 for k in all_keys if p1.get(k) == p2.get(k))
    return 1.0 - (matching / len(all_keys))
