"""MCP Settlement Server: gatekeeper for high-risk agent actions.

Exposes tools via the Model Context Protocol that validate agent actions
against Institutional DNA before allowing execution.

Run via stdio:
    python -m swarm_at.mcp.server

Or add to an agent config:
    mcp add swarm-at -- python -m swarm_at.mcp.server
"""

from __future__ import annotations

from typing import Any

from swarm_at.agents import AgentRegistry
from swarm_at.blueprints import BlueprintError, BlueprintStore
from swarm_at.credits import CreditError, CreditLedger
from swarm_at.engine import SwarmAtEngine
from swarm_at.models import (
    Header,
    InstitutionalRules,
    Payload,
    Proposal,
    SettlementStatus,
)
from swarm_at.settler import Ledger


class SettlementMCPServer:
    """Core logic for the MCP settlement tools.

    Used both by the FastMCP transport layer and directly in tests.
    """

    def __init__(
        self,
        ledger: Ledger | None = None,
        rules: InstitutionalRules | None = None,
        blocked_commands: list[str] | None = None,
        agent_registry: AgentRegistry | None = None,
        blueprint_store: BlueprintStore | None = None,
        credit_ledger: CreditLedger | None = None,
    ):
        self.engine = SwarmAtEngine(ledger=ledger, rules=rules)
        self.ledger = self.engine.ledger
        self.blocked_commands = set(blocked_commands or [
            "rm -rf /",
            "rm -rf ~",
            "mkfs",
            "dd if=/dev/zero",
            ":(){:|:&};:",
        ])
        self.agent_registry = agent_registry
        self.blueprint_store = blueprint_store or BlueprintStore()
        self.credit_ledger = credit_ledger or CreditLedger()

    def check_tool_permission(self, agent_id: str | None, tool_name: str) -> str | None:
        """Check if an agent has permission to use a tool. Returns error message or None."""
        if self.agent_registry is None or agent_id is None:
            return None
        try:
            agent = self.agent_registry.get(agent_id)
        except Exception:
            return f"Agent {agent_id} not found in registry."
        if not agent.can_use_tool(tool_name):
            return f"Agent {agent_id} lacks permission for tool '{tool_name}'."
        return None

    def settle_action(
        self,
        action: str,
        context: dict[str, Any] | None = None,
        parent_hash: str | None = None,
        confidence: float = 0.9,
        agent_id: str | None = None,
    ) -> dict[str, Any]:
        """Validate a proposed action against institutional rules.

        Returns proceed/deny with reason and optional settlement token.
        """
        perm_error = self.check_tool_permission(agent_id, "settle_action")
        if perm_error:
            return {"proceed": False, "reason": perm_error, "settlement_token": None}

        for blocked in self.blocked_commands:
            if blocked in action:
                return {
                    "proceed": False,
                    "reason": f"Action contains blocked command pattern: {blocked}",
                    "settlement_token": None,
                }

        actual_parent = parent_hash or self.ledger.get_latest_hash()
        proposal = Proposal(
            header=Header(parent_hash=actual_parent),
            payload=Payload(
                data_update={"action": action, "context": context or {}},
                confidence_score=confidence,
            ),
            proof=f"MCP settle_action request: {action}",
        )

        result = self.engine.verify_and_settle(proposal)

        if result.status == SettlementStatus.SETTLED:
            return {
                "proceed": True,
                "reason": "Action settled and verified.",
                "settlement_token": result.hash,
            }

        return {
            "proceed": False,
            "reason": result.reason,
            "settlement_token": None,
        }

    def check_settlement(self, task_id: str | None = None, hash: str | None = None, agent_id: str | None = None) -> dict[str, Any]:
        """Query ledger status for a given task or hash."""
        perm_error = self.check_tool_permission(agent_id, "check_settlement")
        if perm_error:
            return {"found": False, "reason": perm_error}

        entries = self.ledger.read_all()

        if task_id:
            for entry in reversed(entries):
                if entry.task_id == task_id:
                    return {
                        "found": True,
                        "task_id": entry.task_id,
                        "hash": entry.current_hash,
                        "timestamp": entry.timestamp,
                    }

        if hash:
            for entry in entries:
                if entry.current_hash == hash:
                    return {
                        "found": True,
                        "task_id": entry.task_id,
                        "hash": entry.current_hash,
                        "timestamp": entry.timestamp,
                    }

        return {"found": False, "reason": "No matching entry in ledger."}

    def list_blueprints(self, tag: str | None = None) -> dict[str, Any]:
        """List available blueprints with optional tag filter."""
        blueprints = self.blueprint_store.list_blueprints(tag=tag)
        return {
            "blueprints": [
                {
                    "blueprint_id": bp.blueprint_id,
                    "name": bp.name,
                    "description": bp.description,
                    "tags": bp.tags,
                    "step_count": len(bp.steps),
                    "credit_cost": bp.credit_cost,
                    "validated": bp.validated,
                }
                for bp in blueprints
            ],
            "total": len(blueprints),
        }

    def get_blueprint(self, blueprint_id: str) -> dict[str, Any]:
        """Get full blueprint details including steps."""
        try:
            bp = self.blueprint_store.get_blueprint(blueprint_id)
        except BlueprintError:
            return {"error": f"Blueprint {blueprint_id} not found."}

        try:
            forks = self.blueprint_store.fork_count(blueprint_id)
        except BlueprintError:
            forks = 0

        return {
            "blueprint_id": bp.blueprint_id,
            "name": bp.name,
            "description": bp.description,
            "tags": bp.tags,
            "steps": [
                {
                    "step_id": s.step_id,
                    "name": s.name,
                    "description": s.description,
                    "depends_on": s.depends_on,
                    "agent_role": s.agent_role,
                    "complexity": s.complexity,
                }
                for s in bp.steps
            ],
            "credit_cost": bp.credit_cost,
            "validated": bp.validated,
            "fork_count": forks,
        }

    def get_credits(self, agent_id: str) -> dict[str, Any]:
        """Get agent credit balance."""
        try:
            balance = self.credit_ledger.balance(agent_id)
            return {
                "agent_id": agent_id,
                "balance": balance,
            }
        except CreditError as e:
            return {"error": str(e)}

    def topup_credits(self, agent_id: str, amount: float) -> dict[str, Any]:
        """Add credits to agent balance."""
        new_balance = self.credit_ledger.topup(agent_id, amount)
        return {
            "agent_id": agent_id,
            "balance": new_balance,
            "topup_amount": amount,
        }

    def fork_blueprint(self, blueprint_id: str, agent_id: str = "anonymous") -> dict[str, Any]:
        """Fork a blueprint into an executable molecule."""
        from swarm_at.workflow import fork_blueprint as _fork

        try:
            bp = self.blueprint_store.get_blueprint(blueprint_id)
        except BlueprintError:
            return {"error": f"Blueprint {blueprint_id} not found."}

        molecule = _fork(bp, agent_id=agent_id)
        return {
            "molecule_id": molecule.molecule_id,
            "name": molecule.name,
            "bead_count": len(molecule.beads),
            "metadata": molecule.metadata,
        }


def create_mcp_app(ledger_path: str = "ledger.jsonl") -> Any:
    """Create a FastMCP app wired to the settlement engine.

    Returns the FastMCP instance ready for stdio or SSE transport.
    """
    from mcp.server import FastMCP

    mcp = FastMCP(
        name="swarm-at",
        instructions="Settlement protocol server for validating agent actions against institutional rules.",
    )

    from swarm_at.seed_blueprints import seed_blueprints

    store = BlueprintStore()
    seed_blueprints(store)
    server = SettlementMCPServer(ledger=Ledger(path=ledger_path), blueprint_store=store)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def settle_action(
        action: str,
        context: str = "{}",
        confidence: float = 0.9,
    ) -> str:
        """Validate a proposed action against institutional rules before execution.

        Use this tool before performing high-risk operations (file writes, deletions,
        payments, terminal commands). Returns a settlement token if approved.

        Args:
            action: Description of the action to validate (e.g. "rm -rf /tmp/cache")
            context: JSON string of additional context for the action
            confidence: Confidence score for this action (0.0-1.0)
        """
        import json
        ctx = json.loads(context) if context else {}
        result = server.settle_action(action=action, context=ctx, confidence=confidence)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def check_settlement(
        task_id: str = "",
        hash: str = "",
    ) -> str:
        """Check the settlement status of a previously submitted action.

        Args:
            task_id: The task ID to look up
            hash: The settlement hash to look up
        """
        import json
        result = server.check_settlement(
            task_id=task_id or None,
            hash=hash or None,
        )
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def ledger_status() -> str:
        """Get the current state of the settlement ledger.

        Returns the latest hash, entry count, and chain integrity status.
        """
        import json
        latest = server.ledger.get_latest_hash()
        intact = server.ledger.verify_chain()
        count = len(server.ledger.read_all())
        return json.dumps({
            "latest_hash": latest,
            "entry_count": count,
            "chain_intact": intact,
        }, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def list_blueprints(tag: str = "") -> str:
        """List available workflow blueprints. Optionally filter by tag.

        Args:
            tag: Filter blueprints by tag (e.g. "audit", "code-review"). Empty for all.
        """
        import json
        result = server.list_blueprints(tag=tag or None)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def get_blueprint(blueprint_id: str) -> str:
        """Get full details of a blueprint including steps and credit cost.

        Args:
            blueprint_id: The blueprint ID to look up (e.g. "audit-chain")
        """
        import json
        result = server.get_blueprint(blueprint_id)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def get_credits(agent_id: str) -> str:
        """Check an agent's credit balance.

        Args:
            agent_id: The agent identifier to look up
        """
        import json
        result = server.get_credits(agent_id)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def topup_credits(agent_id: str, amount: float) -> str:
        """Add credits to an agent's balance.

        Args:
            agent_id: The agent identifier
            amount: Amount of credits to add
        """
        import json
        result = server.topup_credits(agent_id, amount)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def fork_blueprint(blueprint_id: str, agent_id: str = "anonymous") -> str:
        """Fork a blueprint into an executable workflow molecule.

        Args:
            blueprint_id: The blueprint ID to fork (e.g. "audit-chain")
            agent_id: The agent who will execute the workflow (default: "anonymous")
        """
        import json
        result = server.fork_blueprint(blueprint_id, agent_id)
        return json.dumps(result, indent=2)

    return mcp
