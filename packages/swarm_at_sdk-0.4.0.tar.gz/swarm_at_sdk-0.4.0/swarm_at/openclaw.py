"""OpenClaw: agent & LLM discovery layer for swarm.at.

Pure functions that generate discovery documents — llms.txt, A2A agent cards,
robots.txt, Schema.org JSON-LD, and enriched OpenAPI specs. No side effects.
"""

from __future__ import annotations

from typing import Any


def generate_llms_txt(api_url: str, site_url: str) -> str:
    """Generate llms.txt v1.1.0 — LLM-readable protocol summary."""
    return f"""# swarm.at

> Git-native Information Settlement Protocol for autonomous agent workflows.

swarm.at turns probabilistic agent outputs into deterministic, auditable
institutional records. Every action is settled to a hash-chained ledger.
Every agent earns trust through verified performance.

## Endpoints

- POST {api_url}/v1/settle — Submit a proposal for settlement
- GET {api_url}/v1/context?keywords=... — Get context slice for a task
- GET {api_url}/v1/status/{{task_id}} — Check settlement status
- GET {api_url}/v1/ledger/latest — Latest settled hash
- GET {api_url}/v1/ledger/verify — Verify full chain integrity
- POST {api_url}/v1/agents/register — Register a new agent
- GET {api_url}/v1/whoami?agent_id=... — Agent self-check
- GET {api_url}/public/ledger — Paginated public ledger
- GET {api_url}/public/agents — Agent leaderboard
- GET {api_url}/public/blueprints — Blueprint catalog
- GET {api_url}/v1/credits/{{agent_id}} — Check agent credit balance
- POST {api_url}/v1/credits/{{agent_id}}/topup — Add credits
- POST {api_url}/v1/blueprints/{{blueprint_id}}/fork — Fork blueprint into molecule
- POST {api_url}/v1/molecules/{{molecule_id}}/execute — Execute a workflow step
- POST {api_url}/v1/auth/token — Get JWT token
- GET {api_url}/v1/ledger/mode — Ledger backend status

## MCP Server

Install via: `mcp add swarm-at -- python -m swarm_at.mcp`

Tools: settle_action, check_settlement, ledger_status, list_blueprints, get_blueprint, get_credits, topup_credits, fork_blueprint

## Python SDK

```
pip install swarm-at-sdk
from swarm_at.sdk.client import SwarmClient
client = SwarmClient("{api_url}", api_key="sk-...")
```

## Settlement Tiers

- **sandbox** — Log-only, no ledger writes. Safe to experiment.
- **staging** — Writes ledger, no chain enforcement.
- **production** — Full verification + chain integrity (default).

## Trust Model

Agents progress through four trust levels based on Bayesian credible intervals:

- **untrusted** — New agent. Cannot stake.
- **provisional** — 5+ settlements, lower bound >= 0.60. Can execute.
- **trusted** — 20+ settlements, lower bound >= 0.82. Full participation.
- **senior** — 100+ settlements, lower bound >= 0.92. Can orchestrate.

## Links

- Website: {site_url}
- API: {api_url}
- Agent Card: {api_url}/.well-known/agent-card.json
- OpenAPI: {api_url}/.well-known/openapi.json
"""


def generate_agent_card(api_url: str) -> dict[str, Any]:
    """Generate A2A agent card — Google-backed agent-to-agent discovery."""
    return {
        "name": "swarm.at Settlement Protocol",
        "description": (
            "Git-native information settlement protocol for autonomous agent workflows. "
            "Validates actions against institutional rules, maintains a hash-chained ledger, "
            "and manages trust-tiered agent identities."
        ),
        "url": api_url,
        "version": "0.3.2",
        "capabilities": {
            "streaming": False,
            "pushNotifications": False,
        },
        "authentication": {
            "schemes": ["bearer"],
            "credentials": "API key via Authorization: Bearer <key>",
        },
        "defaultInputModes": ["application/json"],
        "defaultOutputModes": ["application/json"],
        "skills": [
            {
                "id": "settle_action",
                "name": "Settle Action",
                "description": (
                    "Validate a proposed action against institutional rules. "
                    "Returns a settlement token if approved."
                ),
            },
            {
                "id": "check_settlement",
                "name": "Check Settlement",
                "description": "Query ledger status for a given task or hash.",
            },
            {
                "id": "ledger_status",
                "name": "Ledger Status",
                "description": "Get the current state of the settlement ledger.",
            },
            {
                "id": "list_blueprints",
                "name": "List Blueprints",
                "description": "Browse available workflow blueprints. Filter by tag.",
            },
            {
                "id": "fork_blueprint",
                "name": "Fork Blueprint",
                "description": "Fork a blueprint into an executable workflow molecule.",
            },
            {
                "id": "get_credits",
                "name": "Get Credits",
                "description": "Check an agent's credit balance for workflow operations.",
            },
        ],
        "provider": {
            "organization": "swarm.at",
            "url": "https://swarm.at",
        },
        "documentationUrl": "https://swarm.at/SPEC.html",
        "serviceUrl": api_url,
    }


def generate_robots_txt(api_url: str) -> str:
    """Generate robots.txt — crawler guidance with llms.txt reference."""
    return f"""User-agent: *
Allow: /

# LLM-readable protocol summary
# See https://llmstxt.org for the llms.txt convention
Sitemap: {api_url}/llms.txt
"""


def generate_jsonld(api_url: str, site_url: str) -> dict[str, Any]:
    """Generate Schema.org JSON-LD for WebAPI type."""
    return {
        "@context": "https://schema.org",
        "@type": "WebAPI",
        "name": "swarm.at",
        "description": (
            "Git-native Information Settlement Protocol for autonomous agent workflows."
        ),
        "url": api_url,
        "documentation": f"{site_url}/SPEC.html",
        "provider": {
            "@type": "Organization",
            "name": "swarm.at",
            "url": site_url,
        },
        "termsOfService": f"{site_url}/terms",
        "category": "AI Infrastructure",
    }


def enrich_openapi(schema: dict[str, Any], api_url: str = "") -> dict[str, Any]:
    """Add servers, tags, examples, and externalDocs to FastAPI's auto-generated spec."""
    enriched = dict(schema)

    if api_url:
        enriched["servers"] = [
            {"url": api_url, "description": "Production"},
            {"url": "http://localhost:8000", "description": "Local development"},
        ]

    enriched["tags"] = [
        {"name": "settlement", "description": "Core settlement operations"},
        {"name": "ledger", "description": "Ledger queries and verification"},
        {"name": "agents", "description": "Agent identity and trust management"},
        {"name": "blueprints", "description": "Blueprint catalog and forking"},
        {"name": "workflows", "description": "Molecule execution and step management"},
        {"name": "credits", "description": "Agent credit balances and topups"},
        {"name": "auth", "description": "JWT token generation and API key auth"},
        {"name": "webhooks", "description": "Event notification subscriptions"},
        {"name": "discovery", "description": "Discovery endpoints (llms.txt, A2A, OpenAPI)"},
    ]

    enriched["externalDocs"] = {
        "description": "swarm.at Technical Specification",
        "url": "https://swarm.at/SPEC.html",
    }

    enriched.setdefault("info", {})
    enriched["info"]["x-llms-txt"] = "/llms.txt"
    enriched["info"]["x-agent-card"] = "/.well-known/agent-card.json"

    # Add example to settle endpoint if present
    paths = enriched.get("paths", {})
    settle_path = paths.get("/v1/settle", {})
    post_op = settle_path.get("post", {})
    if post_op and "x-example" not in post_op:
        post_op["x-example"] = {
            "primary": {
                "header": {
                    "task_id": "research-1",
                    "parent_hash": "0" * 64,
                },
                "payload": {
                    "data_update": {"findings": "Agent completed research"},
                    "confidence_score": 0.95,
                },
            }
        }

    return enriched
