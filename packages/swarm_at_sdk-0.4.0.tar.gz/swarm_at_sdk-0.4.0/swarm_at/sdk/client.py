"""Public Python SDK for swarm.at."""

from __future__ import annotations

from typing import Any, Callable

import httpx

from swarm_at.models import Proposal, SettlementResult


class SwarmClient:
    """Drop-in client for the swarm.at settlement protocol.

    Usage:
        client = SwarmClient(api_url="https://api.swarm.at", api_key="sk-...")
        result = client.settle(proposal)
    """

    def __init__(self, api_url: str, api_key: str = "", timeout: float = 30.0):
        self.api_url = api_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self.api_url,
            headers={"Authorization": f"Bearer {api_key}"} if api_key else {},
            timeout=timeout,
        )

    def settle(self, proposal: Proposal, shadow: Proposal | None = None) -> SettlementResult:
        """Submit a proposal for settlement."""
        body: dict[str, Any] = {"primary": proposal.model_dump()}
        if shadow is not None:
            body["shadow"] = shadow.model_dump()
        resp = self._http.post("/v1/settle", json=body)
        resp.raise_for_status()
        return SettlementResult.model_validate(resp.json())

    def context_slice(self, state: dict[str, Any], keywords: list[str]) -> dict[str, Any]:
        """Get a pruned context slice. Filters locally if state provided."""
        from swarm_at.context import get_context_slice
        return get_context_slice(state, keywords)

    def latest_hash(self) -> str:
        """Get the latest settled hash."""
        resp = self._http.get("/v1/ledger/latest")
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return str(data["latest_hash"])

    def verify_ledger(self) -> dict[str, Any]:
        """Verify full ledger integrity."""
        resp = self._http.get("/v1/ledger/verify")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def task_status(self, task_id: str) -> dict[str, Any]:
        """Check settlement status of a specific task."""
        resp = self._http.get(f"/v1/status/{task_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def list_blueprints(
        self, tag: str | None = None, page: int = 1, page_size: int = 50,
    ) -> dict[str, Any]:
        """List available blueprints with optional tag filter."""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if tag is not None:
            params["tag"] = tag
        resp = self._http.get("/public/blueprints", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_blueprint(self, blueprint_id: str) -> dict[str, Any]:
        """Get full blueprint details including steps and credit cost."""
        resp = self._http.get(f"/public/blueprints/{blueprint_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def whoami(self, agent_id: str) -> dict[str, Any]:
        """Agent self-check: trust status, permissions, promotion path."""
        resp = self._http.get("/v1/whoami", params={"agent_id": agent_id})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def register_agent(
        self, agent_id: str, role: str = "worker", capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a new agent identity."""
        body: dict[str, Any] = {"agent_id": agent_id, "role": role}
        if capabilities is not None:
            body["capabilities"] = capabilities
        resp = self._http.post("/v1/agents/register", json=body)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_credits(self, agent_id: str) -> dict[str, Any]:
        """Get agent credit balance."""
        resp = self._http.get(f"/v1/credits/{agent_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def topup_credits(self, agent_id: str, amount: float) -> dict[str, Any]:
        """Add credits to agent balance."""
        resp = self._http.post(f"/v1/credits/{agent_id}/topup", json={"amount": amount})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def fork_blueprint(self, blueprint_id: str, agent_id: str = "anonymous") -> dict[str, Any]:
        """Fork a blueprint into an executable workflow molecule."""
        resp = self._http.post(
            f"/v1/blueprints/{blueprint_id}/fork", params={"agent_id": agent_id},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def create_token(self, agent_id: str, role: str = "worker") -> dict[str, Any]:
        """Request a JWT token for an agent."""
        resp = self._http.post("/v1/auth/token", json={"agent_id": agent_id, "role": role})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def shadow_audit(
        self, shadow_fn: Callable[..., dict[str, Any]], max_drift: float = 0.15,
    ) -> Callable[[Callable[..., dict[str, Any]]], Callable[..., dict[str, Any]]]:
        """Decorator for cross-model verification.

        Usage:
            @client.shadow_audit(shadow_fn=cheap_model_call)
            def research_task(context):
                return expensive_model_call(context)
        """
        from swarm_at.auditor import shadow_audit as _shadow_audit
        return _shadow_audit(shadow_fn=shadow_fn, max_drift=max_drift)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> SwarmClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
