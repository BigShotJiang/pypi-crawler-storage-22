"""Canonical blueprint seeding: bootstrap a store with starter templates."""

from __future__ import annotations

from swarm_at.blueprints import Blueprint, BlueprintStep, BlueprintStore


CANONICAL_BLUEPRINTS: list[Blueprint] = [
    Blueprint(
        blueprint_id="audit-chain",
        name="Audit Chain",
        description="Three-step audit pipeline: collect evidence, cross-validate, produce final report.",
        version="1.0.0",
        author="swarm.at",
        tags=["audit", "compliance", "validation"],
        steps=[
            BlueprintStep(
                step_id="collect",
                name="Collect Evidence",
                description="Gather data from source systems.",
                agent_role="worker",
                complexity=0.3,
            ),
            BlueprintStep(
                step_id="validate",
                name="Cross-Validate",
                description="Shadow audit against a second model.",
                depends_on=["collect"],
                agent_role="auditor",
                complexity=0.6,
            ),
            BlueprintStep(
                step_id="report",
                name="Produce Report",
                description="Generate final audit report with findings.",
                depends_on=["validate"],
                agent_role="specialist",
                complexity=0.5,
            ),
        ],
        credit_cost=3.0,
        validated=True,
        validation_hash="a" * 64,
    ),
    Blueprint(
        blueprint_id="code-review-pipeline",
        name="Code Review Pipeline",
        description="Automated code review: static analysis, LLM review, consensus merge.",
        version="1.0.0",
        author="swarm.at",
        tags=["code-review", "development", "quality"],
        steps=[
            BlueprintStep(
                step_id="analyze",
                name="Static Analysis",
                description="Run linters and type checkers.",
                agent_role="worker",
                complexity=0.3,
            ),
            BlueprintStep(
                step_id="review",
                name="LLM Review",
                description="AI-powered code review for logic and security.",
                depends_on=["analyze"],
                agent_role="specialist",
                complexity=0.7,
            ),
            BlueprintStep(
                step_id="merge",
                name="Consensus Merge",
                description="Verify reviews agree and merge to main.",
                depends_on=["review"],
                agent_role="orchestrator",
                complexity=0.5,
            ),
        ],
        credit_cost=5.0,
        validated=True,
        validation_hash="b" * 64,
    ),
    Blueprint(
        blueprint_id="research-workflow",
        name="Research Workflow",
        description="Multi-source research: gather, synthesize, settle findings.",
        version="1.0.0",
        author="swarm.at",
        tags=["research", "synthesis", "knowledge"],
        steps=[
            BlueprintStep(
                step_id="gather",
                name="Gather Sources",
                description="Collect information from multiple sources.",
                agent_role="worker",
                complexity=0.4,
            ),
            BlueprintStep(
                step_id="synthesize",
                name="Synthesize Findings",
                description="Cross-reference and merge findings.",
                depends_on=["gather"],
                agent_role="specialist",
                complexity=0.8,
            ),
            BlueprintStep(
                step_id="settle",
                name="Settle Results",
                description="Commit verified findings to the ledger.",
                depends_on=["synthesize"],
                agent_role="validator",
                complexity=0.5,
            ),
        ],
        credit_cost=4.0,
        validated=True,
        validation_hash="c" * 64,
    ),
]


def seed_blueprints(
    store: BlueprintStore,
    blueprints: list[Blueprint] | None = None,
) -> list[Blueprint]:
    """Bootstrap a blueprint store with canonical templates."""
    bp_list = blueprints or CANONICAL_BLUEPRINTS
    seeded: list[Blueprint] = []
    for bp in bp_list:
        store.register_blueprint(bp)
        seeded.append(bp)
    return seeded
