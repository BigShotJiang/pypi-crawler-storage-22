"""Tests for framework adapters — all use MagicMock, no framework dependencies."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from swarm_at.models import SettlementStatus
from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


# ---------------------------------------------------------------------------
# Shared fixture: sandbox context so tests never touch the filesystem
# ---------------------------------------------------------------------------


@pytest.fixture()
def sandbox_ctx(tmp_path: Path) -> SettlementContext:
    return SettlementContext(tier=SettlementTier.SANDBOX, ledger_path=str(tmp_path / "l.jsonl"))


# ---------------------------------------------------------------------------
# LangGraph adapter
# ---------------------------------------------------------------------------


class TestLangGraphAdapter:
    """SwarmNodeWrapper wraps node functions and settles outputs."""

    def test_wrap_returns_original_result(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(context=sandbox_ctx)

        @wrapper.wrap
        def research_node(state: dict[str, Any]) -> dict[str, Any]:
            return {"findings": "important data"}

        result = research_node({"query": "test"})
        assert result == {"findings": "important data"}

    def test_wrap_settles_dict_output(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(agent="test-node", context=sandbox_ctx)

        @wrapper.wrap
        def my_node(state: dict[str, Any]) -> dict[str, Any]:
            return {"answer": 42}

        my_node({})
        # Context should have advanced (sandbox produces hashes)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_wrap_handles_non_dict_output(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(context=sandbox_ctx)

        @wrapper.wrap
        def string_node(state: dict[str, Any]) -> str:
            return "plain string"

        result = string_node({})
        assert result == "plain string"

    def test_custom_confidence(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(confidence=0.5, context=sandbox_ctx)
        assert wrapper.confidence == 0.5


# ---------------------------------------------------------------------------
# AutoGen adapter
# ---------------------------------------------------------------------------


class TestAutoGenAdapter:
    """SwarmReplyCallback observes replies without interfering."""

    def test_on_reply_returns_false_none(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        sender = MagicMock()
        sender.name = "research-agent"
        recipient = MagicMock()
        recipient.name = "user-proxy"

        result = cb.on_reply(
            recipient=recipient,
            messages=[{"content": "Here are my findings."}],
            sender=sender,
        )
        assert result == (False, None)

    def test_on_reply_settles_message(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        sender = MagicMock()
        sender.name = "analyst"
        recipient = MagicMock()
        recipient.name = "manager"

        cb.on_reply(recipient, [{"content": "analysis complete"}], sender)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_empty_messages(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        result = cb.on_reply(MagicMock(), [], MagicMock())
        assert result == (False, None)

    def test_string_messages(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        result = cb.on_reply(MagicMock(), ["plain text reply"], MagicMock())
        assert result == (False, None)


# ---------------------------------------------------------------------------
# CrewAI adapter
# ---------------------------------------------------------------------------


class TestCrewAIAdapter:
    """SwarmTaskCallback settles CrewAI task outputs."""

    def test_on_task_complete(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.crewai import SwarmTaskCallback

        cb = SwarmTaskCallback(context=sandbox_ctx)
        task_output = MagicMock()
        task_output.description = "Research market trends"
        task_output.raw = "Market is bullish on AI agents"
        task_output.agent = "researcher"

        cb.on_task_complete(task_output)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_agent_with_role_attr(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.crewai import SwarmTaskCallback

        cb = SwarmTaskCallback(context=sandbox_ctx)
        agent_mock = MagicMock()
        agent_mock.role = "data-scientist"
        task_output = MagicMock()
        task_output.description = "Analyze dataset"
        task_output.raw = "Found 3 clusters"
        task_output.agent = agent_mock

        cb.on_task_complete(task_output)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_custom_confidence(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.crewai import SwarmTaskCallback

        cb = SwarmTaskCallback(confidence=0.8, context=sandbox_ctx)
        assert cb.confidence == 0.8


# ---------------------------------------------------------------------------
# OpenAI Assistants adapter
# ---------------------------------------------------------------------------


class TestOpenAIAssistantsAdapter:
    """SwarmRunHandler settles runs and individual steps."""

    def test_settle_run(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(assistant_id="asst_test123", context=sandbox_ctx)
        run = MagicMock()
        run.id = "run_abc"
        run.status = "completed"

        result = handler.settle_run(run, messages=[])
        assert result.status == SettlementStatus.SETTLED

    def test_settle_run_with_messages(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(context=sandbox_ctx)
        run = MagicMock()
        run.id = "run_def"
        run.status = "completed"

        text_block = MagicMock()
        text_block.text.value = "The answer is 42"
        msg = MagicMock()
        msg.content = [text_block]

        result = handler.settle_run(run, messages=[msg])
        assert result.status == SettlementStatus.SETTLED

    def test_settle_step(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(context=sandbox_ctx)
        result = handler.settle_step("tool_calls", {"tool": "code_interpreter", "input": "x=1"})
        assert result.status == SettlementStatus.SETTLED

    def test_settle_step_with_mock_object(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(context=sandbox_ctx)
        step = MagicMock()
        step.id = "step_xyz"
        step.step_details = "tool_calls details"

        result = handler.settle_step("message_creation", step)
        assert result.status == SettlementStatus.SETTLED

    def test_custom_assistant_id(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(assistant_id="asst_custom", context=sandbox_ctx)
        assert handler.assistant_id == "asst_custom"
