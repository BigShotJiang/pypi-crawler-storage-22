"""Tests for discovery routes: llms.txt, robots.txt, agent-card, openapi."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.api.main import app


@pytest.fixture()
def api_client() -> TestClient:
    return TestClient(app)


# ---------------------------------------------------------------------------
# TestLlmsTxtRoute
# ---------------------------------------------------------------------------


class TestLlmsTxtRoute:
    """GET /llms.txt"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/llms.txt")
        assert resp.status_code == 200

    def test_content_type_is_text(self, api_client: TestClient) -> None:
        resp = api_client.get("/llms.txt")
        assert "text/plain" in resp.headers["content-type"]

    def test_contains_protocol_name(self, api_client: TestClient) -> None:
        resp = api_client.get("/llms.txt")
        assert "swarm.at" in resp.text

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/llms.txt")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestRobotsTxtRoute
# ---------------------------------------------------------------------------


class TestRobotsTxtRoute:
    """GET /robots.txt"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/robots.txt")
        assert resp.status_code == 200

    def test_contains_user_agent(self, api_client: TestClient) -> None:
        resp = api_client.get("/robots.txt")
        assert "User-agent" in resp.text

    def test_references_llms_txt(self, api_client: TestClient) -> None:
        resp = api_client.get("/robots.txt")
        assert "llms.txt" in resp.text


# ---------------------------------------------------------------------------
# TestAgentCardRoute
# ---------------------------------------------------------------------------


class TestAgentCardRoute:
    """GET /.well-known/agent-card.json"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        assert resp.status_code == 200

    def test_valid_json(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        data = resp.json()
        assert isinstance(data, dict)

    def test_a2a_fields(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        data = resp.json()
        for field in ["name", "description", "skills", "authentication", "serviceUrl"]:
            assert field in data, f"Missing A2A field: {field}"

    def test_well_known_path(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/agent-card.json")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestWellKnownOpenApi
# ---------------------------------------------------------------------------


class TestWellKnownOpenApi:
    """GET /.well-known/openapi.json"""

    def test_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/.well-known/openapi.json")
        assert resp.status_code == 200

    def test_has_paths(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/openapi.json").json()
        assert "paths" in data
        assert len(data["paths"]) > 0

    def test_has_servers(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/openapi.json").json()
        assert "servers" in data

    def test_enriched_tags(self, api_client: TestClient) -> None:
        data = api_client.get("/.well-known/openapi.json").json()
        assert "tags" in data
        tag_names = {t["name"] for t in data["tags"]}
        assert "settlement" in tag_names
        assert "discovery" in tag_names
