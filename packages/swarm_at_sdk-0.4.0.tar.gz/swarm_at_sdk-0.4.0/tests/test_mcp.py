"""Tests for the MCP Settlement Server."""

from __future__ import annotations

import pytest

from swarm_at.mcp.server import SettlementMCPServer


class TestSettleAction:
    @pytest.mark.parametrize(
        "action, confidence, expect_proceed",
        [
            ("ls -la /tmp", 0.95, True),
            ("echo hello", 0.95, True),
            ("rm -rf /", 0.95, False),
            ("rm -rf ~", 0.95, False),
            ("echo hello", 0.5, False),
        ],
        ids=["safe", "safe-echo", "blocked-rm-root", "blocked-rm-home", "low-confidence"],
    )
    def test_settle_action_outcomes(
        self, mcp_server: SettlementMCPServer, action: str, confidence: float, expect_proceed: bool
    ) -> None:
        result = mcp_server.settle_action(action, confidence=confidence)
        assert result["proceed"] is expect_proceed

    def test_chained_settlements(self, mcp_server: SettlementMCPServer) -> None:
        r1 = mcp_server.settle_action("step 1", confidence=0.95)
        assert r1["proceed"] is True
        r2 = mcp_server.settle_action("step 2", confidence=0.95)
        assert r2["proceed"] is True
        assert mcp_server.ledger.verify_chain() is True


class TestCheckSettlement:
    def test_not_found(self, mcp_server: SettlementMCPServer) -> None:
        assert mcp_server.check_settlement(task_id="nonexistent")["found"] is False

    def test_found_by_hash(self, mcp_server: SettlementMCPServer) -> None:
        token = mcp_server.settle_action("test action", confidence=0.95)["settlement_token"]
        result = mcp_server.check_settlement(hash=token)
        assert result["found"] is True
        assert result["hash"] == token


class TestMCPToolGuarding:
    """Tests for agent-based tool permission enforcement in MCP server."""

    def test_no_registry_allows_all(self, mcp_server: SettlementMCPServer) -> None:
        """Without a registry, no permission enforcement."""
        result = mcp_server.settle_action("safe action", confidence=0.95, agent_id="any-agent")
        assert result["proceed"] is True

    def test_untrusted_agent_blocked_from_settle(self, tmp_path) -> None:
        """UNTRUSTED agent cannot use settle_action."""
        from swarm_at.agents import AgentRegistry
        from swarm_at.settler import Ledger

        registry = AgentRegistry()
        registry.register("new-agent")
        ledger = Ledger(path=tmp_path / "guarded.jsonl")
        server = SettlementMCPServer(ledger=ledger, agent_registry=registry)
        result = server.settle_action("action", confidence=0.95, agent_id="new-agent")
        assert result["proceed"] is False
        assert "lacks permission" in result["reason"]

    def test_provisional_agent_can_settle(self, tmp_path) -> None:
        """PROVISIONAL agent can use settle_action."""
        from swarm_at.agents import AgentRegistry
        from swarm_at.settler import Ledger

        registry = AgentRegistry()
        registry.register("trusted-agent")
        for _ in range(8):
            registry.record_settlement("trusted-agent", success=True)
        ledger = Ledger(path=tmp_path / "guarded.jsonl")
        server = SettlementMCPServer(ledger=ledger, agent_registry=registry)
        result = server.settle_action("safe action", confidence=0.95, agent_id="trusted-agent")
        assert result["proceed"] is True
