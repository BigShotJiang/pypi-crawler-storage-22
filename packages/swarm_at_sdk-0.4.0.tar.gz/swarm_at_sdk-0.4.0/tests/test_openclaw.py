"""Tests for swarm_at.openclaw — discovery document generators."""

from __future__ import annotations

import pytest

from swarm_at.openclaw import (
    enrich_openapi,
    generate_agent_card,
    generate_jsonld,
    generate_llms_txt,
    generate_robots_txt,
)

API_URL = "https://api.swarm.at"
SITE_URL = "https://swarm.at"


# ---------------------------------------------------------------------------
# TestLlmsTxt
# ---------------------------------------------------------------------------


class TestLlmsTxt:
    """llms.txt v1.1.0 generation."""

    def test_contains_protocol_name(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        assert "# swarm.at" in txt

    def test_contains_required_sections(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        for section in ["## Endpoints", "## MCP Server", "## Python SDK", "## Settlement Tiers", "## Trust Model"]:
            assert section in txt, f"Missing section: {section}"

    def test_endpoint_links(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        assert f"{API_URL}/v1/settle" in txt
        assert f"{API_URL}/v1/context" in txt
        assert f"{API_URL}/public/ledger" in txt
        assert f"{API_URL}/public/agents" in txt
        assert f"{API_URL}/public/blueprints" in txt

    def test_mcp_mention(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        assert "settle_action" in txt
        assert "check_settlement" in txt
        assert "ledger_status" in txt

    def test_trust_levels(self) -> None:
        txt = generate_llms_txt(API_URL, SITE_URL)
        for level in ["untrusted", "provisional", "trusted", "senior"]:
            assert level in txt


# ---------------------------------------------------------------------------
# TestAgentCard
# ---------------------------------------------------------------------------


class TestAgentCard:
    """A2A agent card generation."""

    def test_required_fields(self) -> None:
        card = generate_agent_card(API_URL)
        for field in ["name", "description", "url", "version", "skills"]:
            assert field in card, f"Missing A2A field: {field}"

    def test_skills_match_mcp_tools(self) -> None:
        card = generate_agent_card(API_URL)
        skill_ids = {s["id"] for s in card["skills"]}
        assert skill_ids == {
            "settle_action", "check_settlement", "ledger_status",
            "list_blueprints", "fork_blueprint", "get_credits",
        }

    def test_auth_structure(self) -> None:
        card = generate_agent_card(API_URL)
        auth = card["authentication"]
        assert "bearer" in auth["schemes"]

    def test_service_url(self) -> None:
        card = generate_agent_card(API_URL)
        assert card["serviceUrl"] == API_URL

    def test_capabilities(self) -> None:
        card = generate_agent_card(API_URL)
        assert "capabilities" in card
        assert isinstance(card["capabilities"], dict)


# ---------------------------------------------------------------------------
# TestRobotsTxt
# ---------------------------------------------------------------------------


class TestRobotsTxt:
    """robots.txt generation."""

    def test_allows_crawlers(self) -> None:
        txt = generate_robots_txt(API_URL)
        assert "User-agent: *" in txt
        assert "Allow: /" in txt

    def test_references_llms_txt(self) -> None:
        txt = generate_robots_txt(API_URL)
        assert f"{API_URL}/llms.txt" in txt

    def test_valid_format(self) -> None:
        txt = generate_robots_txt(API_URL)
        lines = [line.strip() for line in txt.strip().splitlines() if line.strip()]
        assert len(lines) >= 2
        assert lines[0].startswith("User-agent:")


# ---------------------------------------------------------------------------
# TestJsonLd
# ---------------------------------------------------------------------------


class TestJsonLd:
    """Schema.org JSON-LD generation."""

    def test_context(self) -> None:
        ld = generate_jsonld(API_URL, SITE_URL)
        assert ld["@context"] == "https://schema.org"

    def test_type_is_webapi(self) -> None:
        ld = generate_jsonld(API_URL, SITE_URL)
        assert ld["@type"] == "WebAPI"

    def test_correct_urls(self) -> None:
        ld = generate_jsonld(API_URL, SITE_URL)
        assert ld["url"] == API_URL
        assert SITE_URL in ld["documentation"]


# ---------------------------------------------------------------------------
# TestEnrichOpenApi
# ---------------------------------------------------------------------------


class TestEnrichOpenApi:
    """OpenAPI enrichment."""

    @pytest.fixture()
    def base_schema(self) -> dict:
        return {
            "openapi": "3.1.0",
            "info": {"title": "swarm.at", "version": "0.1.0"},
            "paths": {
                "/v1/settle": {
                    "post": {"summary": "Submit a proposal"}
                },
                "/health": {
                    "get": {"summary": "Health check"}
                },
            },
        }

    def test_servers_added(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        assert "servers" in enriched
        urls = [s["url"] for s in enriched["servers"]]
        assert API_URL in urls

    def test_tags_added(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        assert "tags" in enriched
        tag_names = {t["name"] for t in enriched["tags"]}
        assert "settlement" in tag_names
        assert "discovery" in tag_names

    def test_examples_present(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        settle_post = enriched["paths"]["/v1/settle"]["post"]
        assert "x-example" in settle_post

    def test_existing_paths_preserved(self, base_schema: dict) -> None:
        enriched = enrich_openapi(base_schema, api_url=API_URL)
        assert "/health" in enriched["paths"]
        assert "/v1/settle" in enriched["paths"]


# ---------------------------------------------------------------------------
# TestPureFunctions
# ---------------------------------------------------------------------------


class TestPureFunctions:
    """Verify generators are deterministic and side-effect-free."""

    def test_llms_txt_deterministic(self) -> None:
        a = generate_llms_txt(API_URL, SITE_URL)
        b = generate_llms_txt(API_URL, SITE_URL)
        assert a == b

    def test_agent_card_deterministic(self) -> None:
        a = generate_agent_card(API_URL)
        b = generate_agent_card(API_URL)
        assert a == b

    def test_no_mutation_of_input(self) -> None:
        schema = {"openapi": "3.1.0", "info": {"title": "test"}, "paths": {}}
        original_keys = set(schema.keys())
        enrich_openapi(schema, api_url=API_URL)
        assert set(schema.keys()) == original_keys
