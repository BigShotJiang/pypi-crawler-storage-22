"""Tests for the Python SDK."""

from __future__ import annotations


from swarm_at.sdk.client import SwarmClient
from swarm_at.settler import GENESIS_HASH

from tests.conftest import assert_escrowed, assert_rejected, assert_settled, make_proposal


class TestSettle:
    def test_settle_sends_correct_body(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.settle(make_proposal())
        assert_settled(result)

    def test_settle_with_matching_shadow(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.settle(make_proposal(), shadow=make_proposal())
        assert_settled(result)

    def test_settle_divergent_shadow(self, sdk_client: SwarmClient) -> None:
        primary = make_proposal()
        shadow = make_proposal(data={"found": "different"})
        result = sdk_client.settle(primary, shadow=shadow)
        assert_escrowed(result)

    def test_settle_reject_drift(self, sdk_client: SwarmClient) -> None:
        result = sdk_client.settle(make_proposal(parent_hash="a" * 64))
        assert_rejected(result, reason_contains="drift")

    def test_chain_two_settlements(self, sdk_client: SwarmClient) -> None:
        h1 = assert_settled(sdk_client.settle(make_proposal()))
        p2 = make_proposal(parent_hash=h1, data={"step": 2}, task_id="test-task-2")
        assert_settled(sdk_client.settle(p2))


class TestContextSlice:
    def test_filters_by_keywords(self, sdk_client: SwarmClient) -> None:
        state = {"core_logic": "rules", "topic_a": "data_a", "noise": "ignore"}
        assert sdk_client.context_slice(state, ["topic_a"]) == {"core_logic": "rules", "topic_a": "data_a"}

    def test_empty_state(self, sdk_client: SwarmClient) -> None:
        assert sdk_client.context_slice({}, ["anything"]) == {}


class TestLedgerOps:
    def test_latest_hash_empty(self, sdk_client: SwarmClient) -> None:
        assert sdk_client.latest_hash() == GENESIS_HASH

    def test_latest_hash_after_settle(self, sdk_client: SwarmClient) -> None:
        h = assert_settled(sdk_client.settle(make_proposal()))
        assert sdk_client.latest_hash() == h

    def test_verify_ledger(self, sdk_client: SwarmClient) -> None:
        sdk_client.settle(make_proposal())
        result = sdk_client.verify_ledger()
        assert result["intact"] is True
        assert result["entry_count"] == 1

    def test_task_status(self, sdk_client: SwarmClient) -> None:
        sdk_client.settle(make_proposal())
        assert sdk_client.task_status("test-task-1")["task_id"] == "test-task-1"
