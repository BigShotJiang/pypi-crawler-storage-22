"""Tests for SDK blueprint, whoami, and register_agent methods."""

from __future__ import annotations

import httpx
import pytest

import swarm_at.api.state as api_state
from swarm_at.agents import AgentRole
from swarm_at.sdk.client import SwarmClient
from swarm_at.seed_blueprints import seed_blueprints


@pytest.fixture()
def sdk_client() -> SwarmClient:
    """SDK client backed by authed TestClient transport."""
    from fastapi.testclient import TestClient
    from swarm_at.api.main import app

    api_state.api_keys = {"sk-test-key"}
    test_client = TestClient(app)
    test_client.headers["Authorization"] = "Bearer sk-test-key"
    sdk = SwarmClient.__new__(SwarmClient)
    sdk.api_url = "http://testserver"
    sdk._http = test_client
    return sdk


@pytest.fixture()
def seeded_store():
    seed_blueprints(api_state.blueprint_store)


class TestListBlueprints:
    def test_returns_paginated(self, sdk_client: SwarmClient, seeded_store) -> None:
        data = sdk_client.list_blueprints()
        assert "blueprints" in data
        assert "total" in data
        assert data["total"] == 3

    def test_filter_by_tag(self, sdk_client: SwarmClient, seeded_store) -> None:
        data = sdk_client.list_blueprints(tag="audit")
        assert data["total"] == 1
        assert data["blueprints"][0]["blueprint_id"] == "audit-chain"

    def test_pagination(self, sdk_client: SwarmClient, seeded_store) -> None:
        data = sdk_client.list_blueprints(page=1, page_size=2)
        assert len(data["blueprints"]) == 2
        assert data["has_more"] is True


class TestGetBlueprint:
    def test_returns_detail(self, sdk_client: SwarmClient, seeded_store) -> None:
        data = sdk_client.get_blueprint("audit-chain")
        assert data["blueprint_id"] == "audit-chain"
        assert "steps" in data
        assert len(data["steps"]) == 3

    def test_not_found_raises(self, sdk_client: SwarmClient) -> None:
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            sdk_client.get_blueprint("nonexistent")
        assert exc_info.value.response.status_code == 404


class TestWhoami:
    def test_returns_trust_info(self, sdk_client: SwarmClient) -> None:
        api_state.agent_registry.register("whoami-test", role=AgentRole.WORKER)
        data = sdk_client.whoami("whoami-test")
        assert data["agent_id"] == "whoami-test"
        assert "trust_level" in data
        assert "allowed_tools" in data
        assert "next_promotion" in data

    def test_unknown_raises(self, sdk_client: SwarmClient) -> None:
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            sdk_client.whoami("nonexistent-agent")
        assert exc_info.value.response.status_code == 404


class TestRegisterAgent:
    def test_creates_agent(self, sdk_client: SwarmClient) -> None:
        data = sdk_client.register_agent("sdk-new-agent", role="worker")
        assert data["agent_id"] == "sdk-new-agent"
        assert data["role"] == "worker"
        assert "trust_level" in data

    def test_with_capabilities(self, sdk_client: SwarmClient) -> None:
        data = sdk_client.register_agent(
            "sdk-cap-agent", role="specialist", capabilities=["data-analysis"],
        )
        assert data["capabilities"] == ["data-analysis"]

    def test_duplicate_raises(self, sdk_client: SwarmClient) -> None:
        sdk_client.register_agent("sdk-dup-agent")
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            sdk_client.register_agent("sdk-dup-agent")
        assert exc_info.value.response.status_code == 409
