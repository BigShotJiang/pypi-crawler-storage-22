"""Event schema for append-only logging."""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class EventType(Enum):
    """Types of events that can be logged."""

    # Interaction lifecycle
    INTERACTION_PROPOSED = "interaction_proposed"
    INTERACTION_ACCEPTED = "interaction_accepted"
    INTERACTION_REJECTED = "interaction_rejected"
    INTERACTION_COMPLETED = "interaction_completed"

    # Agent events
    AGENT_CREATED = "agent_created"
    AGENT_STATE_UPDATED = "agent_state_updated"

    # Proxy computation
    PROXY_COMPUTED = "proxy_computed"

    # Payoff events
    PAYOFF_COMPUTED = "payoff_computed"
    TRANSFER_EXECUTED = "transfer_executed"

    # Governance events
    GOVERNANCE_COST_APPLIED = "governance_cost_applied"
    REPUTATION_UPDATED = "reputation_updated"

    # Marketplace events
    BOUNTY_POSTED = "bounty_posted"
    BID_PLACED = "bid_placed"
    BID_ACCEPTED = "bid_accepted"
    BID_REJECTED = "bid_rejected"
    ESCROW_CREATED = "escrow_created"
    ESCROW_RELEASED = "escrow_released"
    ESCROW_REFUNDED = "escrow_refunded"
    DISPUTE_FILED = "dispute_filed"
    DISPUTE_RESOLVED = "dispute_resolved"

    # Moltipedia wiki events
    PAGE_CREATED = "page_created"
    PAGE_EDITED = "page_edited"
    OBJECTION_FILED = "objection_filed"
    POLICY_VIOLATION_FLAGGED = "policy_violation_flagged"
    POINTS_AWARDED = "points_awarded"
    PAIR_CAP_TRIGGERED = "pair_cap_triggered"
    COOLDOWN_TRIGGERED = "cooldown_triggered"
    DAILY_CAP_TRIGGERED = "daily_cap_triggered"

    # Moltbook events
    POST_SUBMITTED = "post_submitted"
    COMMENT_SUBMITTED = "comment_submitted"
    CHALLENGE_ISSUED = "challenge_issued"
    CHALLENGE_PASSED = "challenge_passed"
    CHALLENGE_FAILED = "challenge_failed"
    CHALLENGE_EXPIRED = "challenge_expired"
    CONTENT_PUBLISHED = "content_published"
    RATE_LIMIT_HIT = "rate_limit_hit"
    KARMA_UPDATED = "karma_updated"

    # Memory tier events
    MEMORY_WRITTEN = "memory_written"
    MEMORY_PROMOTED = "memory_promoted"
    MEMORY_VERIFIED = "memory_verified"
    MEMORY_CHALLENGED = "memory_challenged"
    MEMORY_REVERTED = "memory_reverted"
    MEMORY_CACHE_REBUILT = "memory_cache_rebuilt"
    MEMORY_COMPACTION = "memory_compaction"
    MEMORY_WRITE_RATE_LIMITED = "memory_write_rate_limited"
    MEMORY_PROMOTION_BLOCKED = "memory_promotion_blocked"

    # Scholar/literature synthesis events
    SCHOLAR_RETRIEVAL = "scholar_retrieval"
    SCHOLAR_SYNTHESIS = "scholar_synthesis"
    SCHOLAR_VERIFICATION = "scholar_verification"

    # Kernel market events
    KERNEL_SUBMITTED = "kernel_submitted"
    KERNEL_VERIFIED = "kernel_verified"
    KERNEL_AUDITED = "kernel_audited"

    # Council events
    COUNCIL_DELIBERATION = "council_deliberation"
    COUNCIL_AUDIT = "council_audit"

    # Peer review events
    PEER_REVIEW_SUBMITTED = "peer_review_submitted"
    REVIEW_GATE_EVALUATED = "review_gate_evaluated"

    # System events
    SIMULATION_STARTED = "simulation_started"
    SIMULATION_ENDED = "simulation_ended"
    EPOCH_COMPLETED = "epoch_completed"


class Event(BaseModel):
    """
    An event for the append-only log.

    Events capture state changes and can be replayed to reconstruct
    the full history of a simulation.
    """

    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = Field(default_factory=datetime.now)
    event_type: EventType = EventType.INTERACTION_PROPOSED

    # References to related entities
    interaction_id: Optional[str] = None
    agent_id: Optional[str] = None
    initiator_id: Optional[str] = None
    counterparty_id: Optional[str] = None

    # Event payload (flexible structure)
    payload: Dict[str, Any] = Field(default_factory=dict)

    # Metadata
    epoch: Optional[int] = None
    step: Optional[int] = None
    scenario_id: Optional[str] = None
    replay_k: Optional[int] = None
    seed: Optional[int] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "event_id": self.event_id,
            "timestamp": self.timestamp.isoformat(),
            "event_type": self.event_type.value,
            "interaction_id": self.interaction_id,
            "agent_id": self.agent_id,
            "initiator_id": self.initiator_id,
            "counterparty_id": self.counterparty_id,
            "payload": self.payload,
            "epoch": self.epoch,
            "step": self.step,
            "scenario_id": self.scenario_id,
            "replay_k": self.replay_k,
            "seed": self.seed,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Event":
        """Create from dictionary."""
        return cls(
            event_id=data["event_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            event_type=EventType(data["event_type"]),
            interaction_id=data.get("interaction_id"),
            agent_id=data.get("agent_id"),
            initiator_id=data.get("initiator_id"),
            counterparty_id=data.get("counterparty_id"),
            payload=data.get("payload", {}),
            epoch=data.get("epoch"),
            step=data.get("step"),
            scenario_id=data.get("scenario_id"),
            replay_k=data.get("replay_k"),
            seed=data.get("seed"),
        )


# Factory functions for common events


def interaction_proposed_event(
    interaction_id: str,
    initiator_id: str,
    counterparty_id: str,
    interaction_type: str,
    v_hat: float,
    p: float,
    epoch: Optional[int] = None,
    step: Optional[int] = None,
) -> Event:
    """Create an interaction proposed event."""
    return Event(
        event_type=EventType.INTERACTION_PROPOSED,
        interaction_id=interaction_id,
        initiator_id=initiator_id,
        counterparty_id=counterparty_id,
        payload={
            "interaction_type": interaction_type,
            "v_hat": v_hat,
            "p": p,
        },
        epoch=epoch,
        step=step,
    )


def interaction_completed_event(
    interaction_id: str,
    accepted: bool,
    payoff_initiator: float,
    payoff_counterparty: float,
    epoch: Optional[int] = None,
    step: Optional[int] = None,
) -> Event:
    """Create an interaction completed event."""
    return Event(
        event_type=EventType.INTERACTION_COMPLETED,
        interaction_id=interaction_id,
        payload={
            "accepted": accepted,
            "payoff_initiator": payoff_initiator,
            "payoff_counterparty": payoff_counterparty,
        },
        epoch=epoch,
        step=step,
    )


def payoff_computed_event(
    interaction_id: str,
    initiator_id: str,
    counterparty_id: str,
    payoff_initiator: float,
    payoff_counterparty: float,
    components: dict,
    epoch: Optional[int] = None,
    step: Optional[int] = None,
) -> Event:
    """Create a payoff computed event with full breakdown."""
    return Event(
        event_type=EventType.PAYOFF_COMPUTED,
        interaction_id=interaction_id,
        initiator_id=initiator_id,
        counterparty_id=counterparty_id,
        payload={
            "payoff_initiator": payoff_initiator,
            "payoff_counterparty": payoff_counterparty,
            "components": components,
        },
        epoch=epoch,
        step=step,
    )


def peer_review_submitted_event(
    paper_id: str,
    review_id: str,
    reviewer_id: str,
    recommendation: str,
    rating: int,
) -> Event:
    """Create a peer review submitted event."""
    return Event(
        event_type=EventType.PEER_REVIEW_SUBMITTED,
        payload={
            "paper_id": paper_id,
            "review_id": review_id,
            "reviewer_id": reviewer_id,
            "recommendation": recommendation,
            "rating": rating,
        },
    )


def review_gate_evaluated_event(
    paper_id: str,
    passed: bool,
    failed_checks: list[str],
) -> Event:
    """Create a review gate evaluated event."""
    return Event(
        event_type=EventType.REVIEW_GATE_EVALUATED,
        payload={
            "paper_id": paper_id,
            "passed": passed,
            "failed_checks": failed_checks,
        },
    )


def reputation_updated_event(
    agent_id: str,
    old_reputation: float,
    new_reputation: float,
    delta: float,
    reason: str,
    epoch: Optional[int] = None,
    step: Optional[int] = None,
) -> Event:
    """Create a reputation update event."""
    return Event(
        event_type=EventType.REPUTATION_UPDATED,
        agent_id=agent_id,
        payload={
            "old_reputation": old_reputation,
            "new_reputation": new_reputation,
            "delta": delta,
            "reason": reason,
        },
        epoch=epoch,
        step=step,
    )
