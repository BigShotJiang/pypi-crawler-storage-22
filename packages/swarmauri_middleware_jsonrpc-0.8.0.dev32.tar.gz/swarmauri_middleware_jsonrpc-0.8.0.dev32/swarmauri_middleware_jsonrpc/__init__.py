from .JsonRpcMiddleware import JsonRpcMiddleware

__all__ = ["JsonRpcMiddleware"]

try:
    from importlib.metadata import version, PackageNotFoundError
except ImportError:  # pragma: no cover
    from importlib_metadata import version, PackageNotFoundError

try:
    __version__ = version("swarmauri_middleware_jsonrpc")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "0.0.0"
