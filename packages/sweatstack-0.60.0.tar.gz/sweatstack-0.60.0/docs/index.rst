MyPackage Documentation
=======================

.. toctree::
    :maxdepth: 2

    everything
