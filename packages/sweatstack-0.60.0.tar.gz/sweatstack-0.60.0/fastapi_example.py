"""Example FastAPI app with SweatStack authentication."""

from fastapi import FastAPI
from sweatstack.fastapi import configure, instrument, AuthenticatedUser

configure()  # Uses SWEATSTACK_* environment variables

app = FastAPI()
instrument(app)


@app.get("/")
def home(user: AuthenticatedUser):
    return {"message": f"Welcome, {user.user_id}!"}


@app.get("/activities")
def activities(user: AuthenticatedUser):
    return user.client.get_activities(limit=10)
