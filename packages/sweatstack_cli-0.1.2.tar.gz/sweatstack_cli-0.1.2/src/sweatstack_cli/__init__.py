"""SweatStack CLI — Command-line interface for the SweatStack platform."""

__version__ = "0.1.0"
