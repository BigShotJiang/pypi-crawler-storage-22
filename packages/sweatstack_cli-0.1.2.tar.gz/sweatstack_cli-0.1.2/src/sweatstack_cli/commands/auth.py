"""Authentication commands: login, logout, whoami, status."""

from __future__ import annotations

import datetime

import typer

from sweatstack_cli.api import APIClient
from sweatstack_cli.auth import Authenticator
from sweatstack_cli.auth.jwt import decode_jwt_payload
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import APIError, AuthenticationError


def login(
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Force re-authentication even if already logged in.",
    ),
) -> None:
    """Authenticate with SweatStack via browser."""
    auth = Authenticator()

    # Check if already logged in
    if not force:
        existing = auth.get_valid_tokens()
        if existing:
            try:
                client = APIClient(authenticator=auth)
                user = client.get("/api/v1/oauth/userinfo")
                console.print(
                    f"Already logged in as [bold]{user['name']}[/bold]. "
                    f"Use [cyan]--force[/cyan] to re-authenticate."
                )
                return
            except AuthenticationError:
                pass  # Token invalid, proceed with login

    with console.status("[bold]Opening browser for authentication...[/bold]"):
        try:
            auth.login(force=True)
        except AuthenticationError as e:
            console.print(f"[red]Authentication failed:[/red] {e}")
            raise typer.Exit(2)

    # Verify by fetching user info
    try:
        client = APIClient(authenticator=auth)
        user = client.get("/api/v1/oauth/userinfo")
        console.print(f"[green]✓[/green] Logged in as [bold]{user['name']}[/bold]")
    except AuthenticationError as e:
        console.print(f"[red]Login succeeded but verification failed:[/red] {e}")
        raise typer.Exit(2)


def logout() -> None:
    """Remove stored credentials."""
    auth = Authenticator()
    auth.logout()
    console.print("[green]✓[/green] Logged out")


def whoami() -> None:
    """Show current authenticated user."""
    try:
        client = APIClient()
        user = client.get("/api/v1/oauth/userinfo")
        console.print(
            f"Logged in as: [bold]{user['name']}[/bold] (email={user.get('email', 'no email')}, id={user.get('sub', 'no id')})"
        )
    except AuthenticationError:
        console.print("[yellow]Not logged in[/yellow]")
        console.print("Run [bold]sweatstack login[/bold] to authenticate.")
        raise typer.Exit(1)
    except APIError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(3)


def status() -> None:
    """Show authentication status and token details."""
    auth = Authenticator()
    tokens = auth.get_valid_tokens()

    if tokens is None:
        console.print("[yellow]Not authenticated[/yellow]")
        console.print("Run [bold]sweatstack login[/bold] to authenticate.")
        raise typer.Exit(1)

    try:
        payload = decode_jwt_payload(tokens.access_token)
    except ValueError as e:
        console.print(f"[red]Invalid token format:[/red] {e}")
        console.print("Run [bold]sweatstack login --force[/bold] to re-authenticate.")
        raise typer.Exit(2)

    # Format expiry time
    exp_timestamp = payload.get("exp", 0)
    exp_dt = datetime.datetime.fromtimestamp(exp_timestamp, tz=datetime.UTC)
    now = datetime.datetime.now(tz=datetime.UTC)

    if exp_dt > now:
        remaining = exp_dt - now
        hours, remainder = divmod(int(remaining.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)

        if hours > 0:
            time_str = f"{hours}h {minutes}m remaining"
        elif minutes > 0:
            time_str = f"{minutes}m {seconds}s remaining"
        else:
            time_str = f"{seconds}s remaining"

        expiry_display = f"{exp_dt.strftime('%Y-%m-%d %H:%M:%S')} UTC ({time_str})"
    else:
        expiry_display = f"{exp_dt.strftime('%Y-%m-%d %H:%M:%S')} UTC [red](expired)[/red]"

    console.print("[green]✓[/green] Authenticated")
    console.print(f"  User ID:  {payload.get('sub', 'unknown')}")
    console.print(f"  Expires:  {expiry_display}")

    # Show timezone if available
    if tz := payload.get("tz"):
        console.print(f"  Timezone: {tz}")
