"""Shared console instance for consistent terminal output."""

from rich.console import Console

# Singleton console for consistent output across the CLI
console = Console()
