"""SweatStack CLI entry point."""

from __future__ import annotations

import typer

from sweatstack_cli import __version__
from sweatstack_cli.commands import auth, pages
from sweatstack_cli.console import console
from sweatstack_cli.exceptions import CLIError

# Create main app
app = typer.Typer(
    name="sweatstack",
    help="SweatStack CLI — Deploy and manage your sports data applications.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,  # We handle exceptions ourselves
    context_settings={"help_option_names": ["-h", "--help"]},
)

# Register command groups
app.add_typer(pages.app, name="pages")

# Register top-level auth commands for convenience
# These are the most common operations, so we promote them to top level
app.command(name="login", help="Authenticate with SweatStack via browser.")(auth.login)
app.command(name="logout", help="Remove stored credentials.")(auth.logout)
app.command(name="whoami", help="Show current authenticated user.")(auth.whoami)
app.command(name="status", help="Show authentication status and token details.")(auth.status)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"sweatstack-cli {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """SweatStack CLI — Deploy and manage your sports data applications."""
    pass


def main() -> None:
    """
    CLI entry point with global error handling.

    This function is the main entry point registered in pyproject.toml.
    It wraps the Typer app with proper error handling.
    """
    try:
        app()
    except CLIError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(e.exit_code)
    except KeyboardInterrupt:
        console.print("\n[dim]Cancelled[/dim]")
        raise typer.Exit(130)


if __name__ == "__main__":
    main()
