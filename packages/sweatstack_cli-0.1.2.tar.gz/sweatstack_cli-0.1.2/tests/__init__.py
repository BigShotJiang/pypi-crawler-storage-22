"""SweatStack CLI tests."""
