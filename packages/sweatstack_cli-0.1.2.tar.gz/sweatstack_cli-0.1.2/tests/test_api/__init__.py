"""API module tests."""
