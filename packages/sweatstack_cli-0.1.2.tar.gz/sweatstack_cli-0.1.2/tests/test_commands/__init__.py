"""Command module tests."""
