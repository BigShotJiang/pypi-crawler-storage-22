"""Tests for CLI commands."""

from __future__ import annotations

from typer.testing import CliRunner

from sweatstack_cli.main import app

runner = CliRunner()


class TestCLI:
    """Tests for main CLI application."""

    def test_help(self) -> None:
        """Should show help text."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "SweatStack CLI" in result.stdout
        assert "login" in result.stdout
        assert "logout" in result.stdout
        assert "whoami" in result.stdout
        assert "pages" in result.stdout

    def test_version(self) -> None:
        """Should show version."""
        result = runner.invoke(app, ["--version"])

        assert result.exit_code == 0
        assert "sweatstack-cli" in result.stdout

    def test_short_help(self) -> None:
        """Should support -h for help."""
        result = runner.invoke(app, ["-h"])

        assert result.exit_code == 0
        assert "SweatStack CLI" in result.stdout

    def test_no_args_shows_help(self) -> None:
        """Should show help when invoked without arguments."""
        result = runner.invoke(app, [])

        # no_args_is_help=True causes exit code 2
        assert result.exit_code == 2
        assert "Usage:" in result.stdout


class TestPagesCommands:
    """Tests for pages subcommands."""

    def test_pages_help(self) -> None:
        """Should show pages help."""
        result = runner.invoke(app, ["pages", "--help"])

        assert result.exit_code == 0
        assert "deploy" in result.stdout

    def test_pages_deploy_help(self) -> None:
        """Should show deploy help."""
        result = runner.invoke(app, ["pages", "deploy", "--help"])

        assert result.exit_code == 0
        assert "SLUG" in result.stdout
        assert "DIRECTORY" in result.stdout
