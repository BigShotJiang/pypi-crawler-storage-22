# SweetConnect API Library

<!-- Uncomment if implemented!
[![PyPI](https://img.shields.io/pypi/v/sweetconnect-api.svg)][pypi_]
[![Read the documentation at https://sweetconnect-api.readthedocs.io/](https://img.shields.io/readthedocs/sweetconnect-api/latest.svg?label=Read%20the%20Docs)][read the docs]
[![Tests](https://gitlab.com/sweetconnect/public/sweetconnect-api/workflows/Tests/badge.svg)][tests]
[![Codecov](https://codecov.io/gh/cjolowicz/sweetconnect-api/branch/main/graph/badge.svg)][codecov]
 -->

[![Status](https://img.shields.io/badge/status-Alpha-orange)][status]
[![License](https://img.shields.io/badge/license-GPL_3.0-green)][license]
[![Python Version](https://img.shields.io/badge/python-%3E%3D%203.8-blue)][python version]
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)][pre-commit]
[![Black](https://img.shields.io/badge/code%20style-black-000000.svg)][black]

<!-- [pypi_]: https://pypi.org/project/sweetconnect-api/
[read the docs]: https://sweetconnect-api.readthedocs.io/
[tests]: https://gitlab.com/sweetconnect/public/sweetconnect-api/actions?workflow=Tests
[codecov]: https://app.codecov.io/gh/cjolowicz/sweetconnect-api
 -->

[status]: https://pypi.org/project/sweetconnect-api/
[python version]: https://pypi.org/project/sweetconnect-api
[pre-commit]: https://github.com/pre-commit/pre-commit
[black]: https://github.com/psf/black

## Features

- TODO

## Requirements

- TODO

## Installation

You can install _SweetConnect API Library_ via [pip] from [PyPI]:

```console
$ pip install sweetconnect-api
```

## Development

This project uses [uv] for dependency management. To set up a development environment:

```console
# Install uv (if not already installed)
$ curl -LsSf https://astral.sh/uv/install.sh | sh

# Clone the repository
$ git clone https://gitlab.com/sweetconnect/public/sweetconnect-api
$ cd sweetconnect-api

# Install dependencies
$ uv sync

# Run tests
$ uv run pytest

# Run all checks with nox
$ uv tool run nox

# Run linting with ruff
$ uv run ruff check .
$ uv run ruff format .
```

[uv]: https://github.com/astral-sh/uv

### Code Quality Notes

**Linting:** This project uses [Ruff](https://github.com/astral-sh/ruff) for linting and formatting.

**Pre-commit Hooks:** This project uses pre-commit hooks to ensure code quality before commits.

To set up pre-commit hooks:

```console
# Install pre-commit hooks (one-time setup)
$ uv run pre-commit install

# Run hooks manually on all files
$ uv run pre-commit run --all-files

# Run hooks on staged files only (happens automatically on commit)
$ git commit
```

The pre-commit hooks will automatically check:

- **Ruff**: Code linting and formatting
- **File checks**: Large files, TOML/YAML syntax, trailing whitespace
- **Secret detection**: Prevents committing passwords, API keys, and private keys
- **Prettier**: Formats JSON/YAML/Markdown files

**Known Issues to Address:**

- API models use `mixedCase` naming (e.g., `assetId`, `tenantId`) following the REST API convention
- Some examples use star imports (`from module import *`)
- A few bare `except` clauses need specific exception handling
- Missing docstrings in some public APIs

These naming conventions are intentional to match the SweetConnect API design and will be preserved. Other issues will be addressed in future updates.

### Versioning

This project uses [hatch-vcs](https://github.com/ofek/hatch-vcs) for automatic version management based on Git tags:

- **Release versions** (e.g., `0.1.0`): Created from Git tags (e.g., `v0.1.0`)
- **Development versions** (e.g., `0.1.1.dev0+g5712c2b`): Automatically generated between releases

To create a new release:

```console
# Create and push a version tag
$ git tag v0.2.0
$ git push origin v0.2.0
```

The version is automatically determined from Git history - no manual version updates needed in `pyproject.toml`.

### Continuous Integration

This project uses Bitbucket Pipelines for CI/CD. The pipeline runs:

- **Linting**: Ruff checks code style and quality
- **Type Checking**: mypy is currently disabled due to too many type errors that need to be addressed
- **Security**: Safety checks are currently disabled
- **Build**: Creates distribution packages
- **Deployments**:
  - **dev**: Automatically deploys to PyPI from the `main` branch (development versions)
  - **production**: Automatically deploys to PyPI when a `v*` tag is pushed (release versions)

**Setup Requirements:**

To enable PyPI publishing, add the `PYPI_TOKEN` secret in Bitbucket:

1. Go to Repository Settings → Pipelines → Repository variables
2. Add variable: `PYPI_TOKEN` with your PyPI API token

## Usage

Please see the [Command-line Reference] for details.
The documentation for the api-endpoints is available here:

- prod: <https://doc.api.my.sweetconnect.io/>
- test: <https://doc.api.test.sweetconnect.io/>
- dev: <https://doc.api.dev.sweetconnect.io/>

## Contributing

Contributions are very welcome.
To learn more, see the [Contributor Guide].

This project was generated from [@cjolowicz]'s [Hypermodern Python Cookiecutter] template. For more details see [Hypermodern Python documentation]

## License

Distributed under the terms of the [GPL 3.0 license][license],
_SweetConnect API Library_ is free and open source software.

## Issues

If you encounter any problems,
please [file an issue] along with a detailed description.

[@cjolowicz]: https://github.com/cjolowicz
[pypi]: https://pypi.org/
[hypermodern python cookiecutter]: https://github.com/cjolowicz/cookiecutter-hypermodern-python
[hypermodern python documentation]: https://cookiecutter-hypermodern-python.readthedocs.io/
[file an issue]: https://bitbucket.org/sweetconnect/sweetconnect-api-library-python/jira
[pip]: https://pip.pypa.io/

<!-- github-only -->

[license]: https://bitbucket.org/sweetconnect/sweetconnect-api-library-python/src/main/LICENSE
[contributor guide]: https://bitbucket.org/sweetconnect/sweetconnect-api-library-python/src/main/CONTRIBUTING.md
[command-line reference]: https://sweetconnect-api.readthedocs.io/en/latest/usage.html
