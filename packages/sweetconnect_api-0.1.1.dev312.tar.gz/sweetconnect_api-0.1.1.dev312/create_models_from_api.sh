#!/usr/bin/env bash

if ! command -v datamodel-codegen &> /dev/null
then
    echo "datamodel-codegen could not be found"
    echo "Please run"
    echo -e "\n\tpip install datamodel-code-generator"
    exit
fi

for f in openapi/*.json
    do
        filename=$(basename -- "$f")
        filename="${filename%.*}"
        echo "Generating model for ${filename} ..."
        datamodel-codegen --disable-timestamp --input openapi/${filename}.json --input-file-type openapi --output src/sweetconnect_api/models/auto_${filename}.py
    done
