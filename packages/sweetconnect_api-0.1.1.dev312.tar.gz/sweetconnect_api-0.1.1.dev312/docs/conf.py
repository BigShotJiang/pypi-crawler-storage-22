"""Sphinx configuration."""

project = "SweetConnect API Library"
author = "Kai CLauss"
copyright = "2022, Kai CLauss"
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx_click",
    "myst_parser",
]
autodoc_typehints = "description"
html_theme = "furo"
