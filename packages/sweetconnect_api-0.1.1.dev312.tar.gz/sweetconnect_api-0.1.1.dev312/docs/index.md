```{include} ../README.md
---
end-before: <!-- github-only -->
---
```

[license]: license
[contributor guide]: contributing
[command-line reference]: usage

```{toctree}
---
hidden:
maxdepth: 1
---

usage
reference
contributing
Code of Conduct <codeofconduct>
License <license>
Changelog <https://gitlab.com/sweetconnect/public/sweetconnect-api/releases>
```
