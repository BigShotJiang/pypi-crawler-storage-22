# Usage

```{eval-rst}
.. click:: sweetconnect-api.__main__:main
    :prog: sweetconnect-api
    :nested: full
```
