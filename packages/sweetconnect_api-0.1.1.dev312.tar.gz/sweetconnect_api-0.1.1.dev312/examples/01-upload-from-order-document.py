import time
from pathlib import Path

import numpy as np
from loguru import logger
from pandas import *
from pydantic import ValidationError

from sweetconnect_api.assets import Assets
from sweetconnect_api.connectionManager import SweetConnectSession
from sweetconnect_api.models.sc_assets import *


MANUFACTURER_ID = "<copy_your_manufacturer_id_here>"


def main():
    jwt = "<copy_your_jwt_here>"

    assets = Assets()

    ## Import the Excel Document with the Machine/Components Tree and replace all 'x' with the value True
    order_df = read_excel(
        (Path.cwd() / Path(__file__)).parents[0] / "testfiles/order_document.xlsx",
        usecols="A:F",
    ).replace("x", True)

    ## Replace the nan values with the value False
    order_df.replace(np.nan, False, inplace=True)

    ## SYNCHRONOUS CALL
    machine_pos = 0
    component_pos = 0
    id_list = list()

    order_structure = dict()
    local_machine = {"name": None, "type": None, "machine_no": None}

    local_component = {"name": None, "type": None, "machine_no": None}

    ### Base for the machines and components

    with SweetConnectSession(jwt, manufacturerId=MANUFACTURER_ID) as s:
        ## Add Location
        try:
            logger.debug("adding new location...")
            new_location = AddLocation(
                name="Standort A", address="Dummystr. 12A", country="BE", position=0
            )
            location = assets.add_location(new_location, s)
            logger.debug("added following location...")
            logger.debug(location)
            logger.debug("activating location...")
            assets.activate_location(location, s)
        except ValidationError as e:
            logger.exception(e)

        ## Add Line
        try:
            logger.debug("adding new line...")
            new_line = AddLine(name="Line 01")
            line = assets.add_line(new_line, s)
            logger.debug("added following line...")
            logger.debug(line)
            logger.debug("activating line...")
            assets.activate_line(line, location, s)
        except ValidationError as e:
            logger.exception(e)

        for row in order_df.head(5).to_numpy():  ## ONLY THE 5 FIRST ROWS
            # for row in order_df.to_numpy():

            if row[4]:
                try:
                    # print(f'Machine {row[3]}')
                    local_machine["name"] = row[1]
                    local_machine["type"] = str(row[2])
                    local_machine["machine_no"] = str(row[3])

                    new_machine = AddMachine(
                        name=row[1],
                        description=str(row[2]),
                        uniqueId=str(row[3]),
                        productionDate="2021",
                        position=machine_pos,
                        manufacturerId=MANUFACTURER_ID,
                        customManufacturer="",
                        catalogItemId="",
                        catalogItemVersion="",
                    )

                    logger.debug((row[1], str(row[2]), str(row[3]), "2021"))
                except ValidationError as e:
                    logger.exception(e)

                try:
                    machine = assets.add_machine(new_machine, s)
                    id_list.append(machine.id)

                    # machine['id'] = machine_uuid
                    local_machine["id"] = machine.id
                    assets.activate_machine(
                        machine, line, s
                    )  # Activate machine on already existing line
                    # assets.activate_machine(machine)
                    order_structure[local_machine["machine_no"]] = {
                        "name": machine.name,
                        "type": machine.description,
                        "id": machine.id,
                        "components": list(),
                    }  # TODO: dictionary and components key with list as value
                except Exception as e:
                    logger.exception(e)

                machine_pos += 1
                component_pos = 0
                time.sleep(2)
            elif row[5]:
                logger.debug(f"\tComponent {row[3]} on position {component_pos}")

                try:
                    local_component["name"] = row[1]
                    local_component["type"] = str(row[2])
                    local_component["machine_no"] = str(row[3])

                    new_component = AddComponent(
                        name=row[1],
                        customId=str(row[3]),
                        catalogItemId="",
                        catalogItemVersion="",
                    )

                    logger.debug((row[1], str(row[2]), str(row[3])))

                except ValidationError as e:
                    logger.exception(e)

                try:
                    component = assets.add_component(new_component, s)

                    id_list.append(component.id)

                    local_component["id"] = component.id
                    assets.activate_component(component, machine, s)
                    # core_api.activate_component(component['id'], machine_uuid)
                    order_structure[local_machine["machine_no"]]["components"].append(
                        component.copy()
                    )
                except Exception as e:
                    logger.exception(e)

                component_pos += 1
                time.sleep(2)


if __name__ == "__main__":
    main()
