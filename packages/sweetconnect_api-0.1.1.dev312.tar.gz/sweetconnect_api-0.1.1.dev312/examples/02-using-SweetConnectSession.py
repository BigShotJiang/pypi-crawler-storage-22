from datetime import date
from datetime import timedelta
from getpass import getpass
from pathlib import Path

from loguru import logger
from pydantic import ValidationError
from sweetconnect_api.files import Files

import sweetconnect_api.connectionManager as sc_Conn
from sweetconnect_api.assets import Assets
from sweetconnect_api.config import Datasources
from sweetconnect_api.documents import Documents
from sweetconnect_api.maintenances import Maintenances
from sweetconnect_api.models import sc_assets
from sweetconnect_api.models import sc_config
from sweetconnect_api.models import sc_documents
from sweetconnect_api.models import sc_files
from sweetconnect_api.models import sc_maintenance
from sweetconnect_api.models.sweetconnect_types import MaintenanceInterval
from sweetconnect_api.models.sweetconnect_types import MaintenancePersonnel
from sweetconnect_api.models.sweetconnect_types import datasourceAdapters
from sweetconnect_api.models.sweetconnect_types import refTypes


# Enter your manufacturer Id here
MANUFACTURER_ID = "<copy_your_manufacturer_id_here>"

# choose System to use
PlatformSystem = sc_Conn.SystemInfo.production


# define proxies if neccessary
proxies = {
    "http": "yourHttpProxy:Port",
    "https": "yourHttpsProxy:Port",
}

user = input("Enter your Username:")
password = getpass(f"Password for user {user}:")
# start the session
with sc_Conn.SweetConnectSession(
    user, password, PlatformSystem, MANUFACTURER_ID, proxies
) as s:
    # add datasource
    try:
        logger.info("adding new datasource")
        newDatasource = sc_config.AddDatasource(
            name="NewDatasource",
            adapterId=datasourceAdapters.influxDB20.value,
            adapterOptions=sc_config.AdapterOptions(
                url="https://www.UrlToInflux.com",
                token="yourInfluxToken",
                org="organization",
                bucket="bucket",
            ),
        )
        datasource, _ = Datasources.add_datasource(s, newDatasource)
    except ValidationError as e:
        logger.exception(e)

    # add location
    try:
        logger.info("adding new location")
        newLocation = sc_assets.AddLocation(
            name="MyLocation",
            position=1,
            address="Musterstraße 25, 12345 Musterhausen",
            country="Germany",
        )
        location, _ = Assets.add_location(newLocation, s)
        Assets.activate_location(location, s)
    except ValidationError as e:
        logger.exception(e)

    # add line
    try:
        logger.info("adding new line")
        newLine = sc_assets.AddLine(name="MyLine", description="Main chocolate line")
        line, _ = Assets.add_line(newLine, s)
        Assets.activate_line(line, location, s)
    except ValidationError as e:
        logger.exception(e)

    # add machine
    try:
        logger.info("adding new machine")
        imgPath = Path(r"./examples/testFiles/Machine.png")
        imgType, imgApp = Files.get_type(imgPath.suffix)
        newMachineImage = sc_files.AddFile(
            path=imgPath,
            fileType=imgType,
            appType=imgApp,
        )
        logger.info("uploading image for machine ...")
        machineImage, _ = Files.add_file(s, newMachineImage)
        try:
            newMachine = sc_assets.AddMachine(
                name="MyMachine",
                image=machineImage.id,
                position=0,
                description="Ultimate Sweets-Machine",
                uniqueId="Machine No. 1",
                manufacturerId=s.manufacturerId,
                catalogItemId="Machine No. 1",
                productionDate=2023,
            )
            logger.info("uploading machine ...")
            machine, _ = Assets.add_machine(newMachine, s)
            Assets.activate_machine(machine, line, s)
        except:
            # Remove image, if machine upload fails
            Files.delete_file(s, machineImage)
    except ValidationError as e:
        logger.exception(e)

    # add component
    try:
        logger.info("adding new component")
        imgPath = Path(r"./examples/testFiles/Component.png")
        imgType, imgApp = Files.get_type(imgPath.suffix)
        newComponentImage = sc_files.AddFile(
            path=imgPath,
            fileType=imgType,
            appType=imgApp,
        )
        logger.info("uploading image for component ...")
        componentImage, _ = Files.add_file(s, newComponentImage)
        try:
            newComponent = sc_assets.AddComponent(
                name="MyComponent",
                image=componentImage.id,
                customId="Component No. 1",
                customType="MyComponentType",
            )
            logger.info("uploading component ...")
            component, _ = Assets.add_component(newComponent, s)
            Assets.activate_component(component, machine, s)
        except:
            # Remove image, if component upload fails
            Files.delete_File(s, componentImage)
    except ValidationError as e:
        logger.exception(e)

    # add document - file
    try:
        logger.info("adding new document (file)")
        filePath = Path(r"./examples/testFiles/TestFile.docx")
        fType, app = Files.get_type(filePath.suffix)
        newFile = sc_files.AddFile(
            path=filePath,
            fileType=fType,
            appType=app,
        )
        logger.info("uploading document file ...")
        file, _ = Files.add_file(s, newFile)
        try:
            documentCategory, _ = Documents.get_categories(s)[
                0
            ]  # for the example just use the first one
            languageCode, _ = Documents.get_languages(s)[
                0
            ]  # for the example just use the first one
            newDocument = sc_documents.AddDocument(
                name="Document_TestFileDOCX",
                categoryId=documentCategory.id,
                languageCode=languageCode.code,
                links=[
                    sc_documents.AddLinkOptions(
                        refId=machine.id,
                        refType=refTypes.machine.value,
                    )
                ],
                type=file.appType,
                size=filePath.stat().st_size,
                fileId=file.id,
                fileType=newFile.fileType.value,
            )
            logger.info("uploading document ...")
            Document, _ = Documents.add_document(s, newDocument)
        except:
            # Remove file, if document upload fails
            Files.delete_file(s, file)
    except ValidationError as e:
        logger.exception(e)

    # add document - container
    try:
        logger.info("adding new document (container)")
        containerPath = Path(r"./examples/testFiles/TestContainer.zip")
        cType, app = Files.get_type(containerPath.suffix)
        newContainer = sc_files.AddFile(
            path=containerPath,
            fileType=cType,
            appType=app,
        )
        logger.info("uploading document container. Please be patient ...")
        container, _ = Files.add_file(s, newContainer)
        container.appType = (
            newContainer.appType
        )  # Response when creating container does not contain appType
        try:
            containerCategory, _ = Documents.get_categories(s)[
                0
            ]  # for the example just use the first one
            languageCode, _ = Documents.get_languages(s)[
                0
            ]  # for the example just use the first one
            newContainerDoc = sc_documents.AddDocument(
                name="ContainerName_TestContainerZIP",
                categoryId=containerCategory.id,
                languageCode=languageCode.code,
                links=[
                    sc_documents.AddLinkOptions(
                        refId=component.id,
                        refType=refTypes.component.value,
                    )
                ],
                type=newContainer.appType,
                size=containerPath.stat().st_size,
                fileId=container.id,
                fileType=newContainer.fileType.value,
            )
            logger.info("uploading document ...")
            ContainerDoc, _ = Documents.add_document(s, newContainerDoc)
        except:
            # Remove file, if document upload fails
            Files.delete_file(s, container)
    except ValidationError as e:
        logger.exception(e)

    # add maintenance
    try:
        logger.info("adding new maintenance")
        newMaintenance = sc_maintenance.AddMaintenance(
            title="Clean Air Filters",
            pdmId="1824935",
            description="Clean switching cabinet air filters with compressed air, replace if necessary.",
            active=True,
            structure="MyMachine > Switching Cabinet",
            part="",
            responsibilityGroup=MaintenancePersonnel.maintainer,
            dueDate=(date.today() + timedelta(days=1)).strftime(
                "%Y-%m-%dT%H:%M:%S.000Z"
            ),  # "2023-12-08T00:00:00.000Z",
            interval=1,
            intervalUnit=MaintenanceInterval.weeks,
            componentsList="",
            toolsList="",
            showFixedDialog=False,
            showStateDialog=True,
            showInputDialog=False,
            inputFieldLabel="",
            assetName=machine.name,
            assetId=machine.id,
        )
        Maintenance, _ = Maintenances.add_maintenance(s, newMaintenance)
    except ValidationError as e:
        logger.exception(e)

logger.info("Finished. Session to SweetConnect platform is closed.")
