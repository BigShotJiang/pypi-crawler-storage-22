#!/usr/bin/env bash
# Run the same linting checks as the Bitbucket pipeline locally

set -e  # Exit on any error

echo "🔍 Running linting checks..."
echo ""

# Ensure dependencies are installed
echo "📦 Syncing dependencies with uv..."
uv sync
echo ""

# Run ruff linter
echo "🔧 Running ruff check..."
uv run ruff check .
echo "✅ Ruff check passed"
echo ""

# Run ruff formatter check
echo "🎨 Running ruff format check..."
uv run ruff format --check .
echo "✅ Ruff format check passed"
echo ""

echo "🎉 All linting checks passed!"
