import json
from typing import Any
from typing import Generic
from typing import List
from typing import Tuple
from typing import Type
from typing import TypeVar
from typing import Union
from uuid import UUID

from loguru import logger

from sweetconnect_api.connectionManager import SweetConnectSession
from sweetconnect_api.helpers import get_returntype
from sweetconnect_api.models.sc_assets import AddComponent
from sweetconnect_api.models.sc_assets import AddLine
from sweetconnect_api.models.sc_assets import AddLocation
from sweetconnect_api.models.sc_assets import AddMachine
from sweetconnect_api.models.sc_assets import AddProcessCell
from sweetconnect_api.models.sc_assets import AlterComponent
from sweetconnect_api.models.sc_assets import AlterLine
from sweetconnect_api.models.sc_assets import AlterLocation
from sweetconnect_api.models.sc_assets import AlterMachine
from sweetconnect_api.models.sc_assets import AlterProcessCell
from sweetconnect_api.models.sc_assets import Component
from sweetconnect_api.models.sc_assets import Line
from sweetconnect_api.models.sc_assets import Location
from sweetconnect_api.models.sc_assets import Machine
from sweetconnect_api.models.sc_assets import ProcessCell
from sweetconnect_api.models.sc_assets import TreeNode
from sweetconnect_api.models.sc_files import AssetPicture
from sweetconnect_api.models.sweetconnect_types import AssetTypes
from sweetconnect_api.models.sweetconnect_types import AssetView


TAdd = TypeVar("TAdd", AddLocation, AddLine, AddProcessCell, AddMachine, AddComponent)
TAlter = TypeVar(
    "TAlter", AlterLocation, AlterLine, AlterProcessCell, AlterMachine, AlterComponent
)
TAsset = TypeVar("TAsset", Location, Line, ProcessCell, Machine, Component)


class Assets(Generic[TAdd, TAlter, TAsset]):
    def __init__(
        self, add_type: Type[TAdd], alter_type: Type[TAlter], asset_type: Type[TAsset]
    ):
        self.add_type = add_type
        self.alter_type = alter_type
        self.asset_type = asset_type

    @staticmethod
    def activate(
        session: SweetConnectSession,
        assetId: UUID,
    ) -> None:
        """Sets the active flag to true on asset. Activated assets are ready to be assigned!"""
        api = f"/api/asset/v1/assets/{assetId}/activate"
        logger.info(f"activating asset {assetId}")

        res = session.post(f"{session.baseUrl}{api}")

        if 200 <= res.status_code < 299:
            logger.info("asset activated successfully")
        if 400 <= res.status_code < 499:
            logger.info("asset could not be activated")
            logger.error(res.json())

    @staticmethod
    def deactivate(session: SweetConnectSession, assetId: UUID) -> None:
        """Sets the active flag to false on asset. Deactivated assets cannot be assigned to the asset tree!"""
        api = f"/api/asset/v1/assets/{assetId}/deactivate"
        logger.info(f"deactivating asset {assetId}")

        res = session.post(f"{session.baseUrl}{api}")

        if 200 <= res.status_code < 299:
            logger.info("asset deactivated successfully")
        if 400 <= res.status_code < 499:
            logger.info("asset could not be deactivated")
            logger.error(res.json())

    def create(
        self, session: SweetConnectSession, asset: TAdd
    ) -> Union[Tuple[TAsset, Any], None]:
        """Create an asset (Location, Production-Line, Process-Cell, Machine, Component)"""
        api = "/api/asset/v1/assets"

        asset.__fields_set__.add("assetType")
        if isinstance(asset, (AddComponent, AddMachine, AddProcessCell)):
            if isinstance(asset.assemblyParameters, dict):
                asset.assemblyParameters = json.dumps(asset.assemblyParameters)

        res = session.post(
            f"{session.baseUrl}{api}",
            data=asset.json(exclude_unset=True, by_alias=True),
            headers={"Content-Type": "application/json"},
        )
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, self.asset_type)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    def update(
        self, session: SweetConnectSession, assetId: UUID, updatedAsset: TAlter
    ) -> Union[Tuple[TAsset, Any], None]:
        """Update an existing asset (Location, Production-Line, Process-Cell, Machine, Component)"""
        api = f"/api/asset/v1/assets/{assetId}"

        # exclude_unset will not read the default assetType, but it is required by the API.
        # Set it manually
        updatedAsset.__fields_set__.add("assetType")
        if isinstance(updatedAsset, (AlterComponent, AlterMachine, AlterProcessCell)):
            if isinstance(updatedAsset.assemblyParameters, dict):
                updatedAsset.assemblyParameters = json.dumps(
                    updatedAsset.assemblyParameters
                )

        # res = session.patch(f'{session.baseUrl}{api}', data=updatedAsset.json(exclude_none=True, by_alias=True), headers={'Content-Type':'application/json'})
        res = session.patch(
            f"{session.baseUrl}{api}",
            data=updatedAsset.json(exclude_unset=True, by_alias=True),
            headers={"Content-Type": "application/json"},
        )
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, self.asset_type)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def delete(session: SweetConnectSession, assetId: UUID) -> None:
        """Deletes an asset if it has no parent and no children."""
        api = f"/api/asset/v1/assets/{assetId}"

        res = session.delete(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_asset_tree(
        session: SweetConnectSession, view: AssetView = AssetView.published
    ) -> Union[List[TreeNode], None]:
        """Get the asset tree with a specific view (normal, draft, unassigned, inactive, published)"""
        api = "/api/asset/v1/assets/tree"

        res = session.get(f"{session.baseUrl}{api}", params={"view": view.value})
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_asset_tree(res)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get(
        session: SweetConnectSession,
        assetId: UUID,
    ) -> Union[Tuple[TAsset, Any], None]:
        """Get a specific asset by id"""
        api = f"/api/asset/v1/assets/{assetId}"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            returnClass = get_returntype(AssetTypes(res.json()["data"]["assetType"]))
            return session.extract_new_object(res=res, platform_object=returnClass)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    # @staticmethod
    # def get_machines(session: SweetConnectSession, activated: bool = True, machine_uniqueId: Union[str, None] = None) -> Union[Tuple[List[Machine], Any], None]:
    # FILTER Methods for get_asset_tree will be available in the next api release (see https://oem-support.sweetconnect.io/en/support/tickets/899)
    #     """Get the machines of a tenant
    #     Args:
    #         session (SweetConnectSession): active request session to SweetConnect
    #         activated (bool): choose, if you pull activated or deactivated machines, default: True
    #         machine_uniqueId (str): Machine ID (from manufacturer). If None, all Machines from the Tenant are listed. default: None

    #     Returns:
    #         List[Machine]: List of machines
    #     """
    #     api = f'/api/core/v2/machines'
    #     params = []
    #     if activated:
    #         params.append(f'activated={int(activated)}')
    #     if machine_uniqueId:
    #         params.append(f'uniqueId={machine_uniqueId}')
    #     if params:
    #         api = api + '?' + ('&'.join(params))
    #     res = session.get(f'{session.baseUrl}{api}')
    #     logger.info(f'Response <{res.status_code}>')

    #     if 200 <= res.status_code < 299:
    #         return session.extract_object_list(res, Machine)
    #     if 400 <= res.status_code < 499:
    #         logger.error(res.json())

    # @staticmethod
    # def get_components(session: SweetConnectSession, activated: bool = True, machineUUID: Union[UUID, None] = None) -> Union[Tuple[List[Component], Any], None]:
    # FILTER Methods for get_asset_tree will be available in the next api release (see https://oem-support.sweetconnect.io/en/support/tickets/899)
    #     """Get the components of a tenant
    #     Args:
    #         session (SweetConnectSession): active request session to SweetConnect
    #         activated (bool): choose, if you pull activated or deactivated components, default: True
    #         machineUUID (str): UUID of machine, of which components shall be returned

    #     Returns:
    #         List[Component]: List of components
    #     """
    #     api = f'/api/core/v2/components?activated={int(activated)}'
    #     res = session.get(f'{session.baseUrl}{api}')
    #     logger.info(f'Response <{res.status_code}>')

    #     if machineUUID:
    #         logger.info('TODO Einschränkung muss noch erfolgen')

    #     if 200 <= res.status_code < 299:
    #         return session.extract_object_list(res, Component)
    #     if 400 <= res.status_code < 499:
    #         logger.error(res.json())

    @staticmethod
    def publish(session: SweetConnectSession, assetId: UUID) -> None:
        """Publish a Asset (marked as Draft) and all childs of the asset."""
        api = f"/api/asset/v1/assets/{assetId}/publish"

        logger.info(f"publishing asset {assetId}")
        res = session.post(f"{session.baseUrl}{api}")

        if 200 <= res.status_code < 299:
            logger.info("asset published succesfully")
        if 400 <= res.status_code < 499:
            logger.info("asset could not be published")
            logger.error(res.json())

    @staticmethod
    def assign(session: SweetConnectSession, assetId: UUID, parentId: UUID) -> None:
        """Sets the parent of the asset and places it at the last position within that level."""
        api = f"/api/asset/v1/assets/{assetId}/assign"

        logger.info(f"assigning asset {assetId} to parent {parentId}")
        res = session.post(f"{session.baseUrl}{api}", data={"parentId": parentId})

        if 200 <= res.status_code < 299:
            logger.info("asset assigned succesfully")
        if 400 <= res.status_code < 499:
            logger.info("asset could not be assigned")
            logger.error(res.json())

    @staticmethod
    def unassign(session: SweetConnectSession, assetId: UUID) -> None:
        """Removes the asset from the tree (clears its parent) and compacts the remaining siblings positions."""
        api = f"/api/asset/v1/assets/{assetId}/unassign"

        logger.info(f"unassigning asset {assetId}")
        res = session.post(f"{session.baseUrl}{api}")

        if 200 <= res.status_code < 299:
            logger.info("asset unassigned succesfully")
        if 400 <= res.status_code < 499:
            logger.info("asset could not be unassigned")
            logger.error(res.json())

    @staticmethod
    def sort(
        session: SweetConnectSession, parentId: UUID, sortedChildIds: List[UUID]
    ) -> None:
        """Sorting assets of the same level (same parentId)."""
        api = f"/api/asset/v1/assets/{parentId}/sort"

        res = session.post(
            f"{session.baseUrl}{api}",
            data={"sortedChildIds": [str(assetId) for assetId in sortedChildIds]},
        )

        if 200 <= res.status_code < 299:
            logger.info("asset sorted succesfully")
        if 400 <= res.status_code < 499:
            logger.info("asset could not be sorted")
            logger.error(res.json())

    def is_activated(
        self, session: SweetConnectSession, asset_uuid: UUID
    ) -> Union[bool, None]:
        """Check activation state of an asset

        Args:
            asset_uuid (str): Asset ID got at creation.

        Returns:
            bool: True if activated, False if not
        """
        # use existing method
        data = self.get(session, asset_uuid)
        if data is None:
            return data
        else:
            asset, _ = data
            if asset.active:
                logger.info("Asset is activated")
            else:
                logger.info("Asset is NOT activated")
            return asset.active

    ## manage pictures
    @staticmethod
    def add_picture(
        session: SweetConnectSession, assetId: UUID, organizationId: UUID, file
    ) -> Union[Tuple[AssetPicture, Any], None]:
        """Create a new asset-Image

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            assetId (UUID): ID of the asset the picture should be linked to
            organizationId (UUID): ID of the organization, that contains the asset
            file (binary-string): binary string representing the file

        Returns:
            AssetPicture: Valid AssetPicture Object
        """
        api = f"/api/storage/v1/pictures/asset/{assetId}/{organizationId}"

        res = session.post(f"{session.baseUrl}{api}", files={"file": file})
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, AssetPicture)
        if 400 <= res.status_code < 499:
            logger.error(res.json())
