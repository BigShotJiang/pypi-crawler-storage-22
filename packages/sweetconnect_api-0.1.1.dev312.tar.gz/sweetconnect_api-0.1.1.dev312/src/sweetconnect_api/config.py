import urllib.parse
from typing import Any
from typing import List
from typing import Tuple
from typing import Union
from uuid import UUID

from loguru import logger

from sweetconnect_api.connectionManager import SweetConnectSession
from sweetconnect_api.models.sc_config import AddDatasource
from sweetconnect_api.models.sc_config import Datasource
from sweetconnect_api.models.sc_config import DatasourceSummary
from sweetconnect_api.models.sc_config import Manufacturer
from sweetconnect_api.models.sc_config import Tenant
from sweetconnect_api.models.sc_config import User


class Users:
    @staticmethod
    def get_users(session: SweetConnectSession) -> Union[Tuple[List[User], Any], None]:
        """Get users in current Tenant

        Args:
            session (SweetConnectSession): active request session to SweetConnect

        Returns:
            List[Users]: List of valid user objects
        """
        api = "/api/auth/v1/users"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched users")
            return session.extract_object_list(res, User)
        if 400 <= res.status_code < 499:
            logger.info("users could not be fetched")
            logger.error(res.json())

    @staticmethod
    def get_me(session: SweetConnectSession) -> Union[Tuple[User, Any], None]:
        """Get current user

        Args:
            session (SweetConnectSession): active request session to SweetConnect

        Returns:
            User: valid user object
        """
        api = "/api/auth/v1/users/me"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            user_data = res.json()["data"]
            logger.info(
                f"successfully fetched current user >{user_data.get('username')}<"
            )
            logger.info(
                f"details in current user >ID: {user_data.get('id')}, manufacturerId: {user_data.get('manufacturerId')}, role: {user_data.get('role')}, marketplaceRole: {user_data.get('marketplaceRole')}<"
            )
            return session.extract_new_object(res, User)
        if 400 <= res.status_code < 499:
            logger.info("users could not be fetched")
            logger.error(res.json())

    @staticmethod
    def check_user(session: SweetConnectSession, email: str) -> Union[bool, None]:
        """Check if a User (email) has an existing account with SweetConnect"""
        api = f"/api/auth/v1/users/check?email={urllib.parse.quote_plus(email)}"

        res = session.post(
            f"{session.baseUrl}{api}", headers={"Content-Type": "application/json"}
        )
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            if res.json()["data"]["exist"]:
                return True
            elif not res.json()["data"]["exist"]:
                return False
            else:
                logger.error(res.json())
        if 400 <= res.status_code < 499:
            logger.error(res.json())


class Datasources:
    @staticmethod
    def add(
        session: SweetConnectSession, datasource: AddDatasource
    ) -> Union[Tuple[Datasource, Any], None]:
        """Create a new datsource

        Provision a new datasource for the current organization and OEM, if permitted
        """
        api = "/api/databus-controller/v1/datasources"

        res = session.post(
            f"{session.baseUrl}{api}",
            data=datasource.json(),
            headers={"Content-Type": "application/json"},
        )
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, Datasource)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_datasources(
        session: SweetConnectSession,
    ) -> Union[Tuple[List[Datasource], Any], None]:
        """List accessible datasources

        Retrieve all datasources the authenticated user has access to within their organization
        """
        api = "/api/databus-controller/v1/datasources"

        res = session.get(f"{session.baseUrl}{api}")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched datasources")
            return session.extract_object_list(res, Datasource)
        if 400 <= res.status_code < 499:
            logger.info("datasources could not be fetched")
            logger.error(res.json())

    @staticmethod
    def get(
        session: SweetConnectSession, datasourceId: UUID
    ) -> Union[Tuple[Datasource, Any], None]:
        """Fetch a single datasource by its UUID if the user has access"""
        api = f"/api/databus-controller/v1/datasources/{datasourceId}"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res=res, platform_object=Datasource)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_summaries(
        session: SweetConnectSession,
    ) -> Union[Tuple[List[DatasourceSummary], Any], None]:
        """List accessible summarized datasources

        Retrieve all summarized datasources the authenticated user has access to within their organization
        """
        api = "/api/databus-controller/v1/datasources-summary"

        res = session.get(f"{session.baseUrl}{api}")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched datasources")
            return session.extract_object_list(res, DatasourceSummary)
        if 400 <= res.status_code < 499:
            logger.info("datasources could not be fetched")
            logger.error(res.json())

    @staticmethod
    def get_summary(
        session: SweetConnectSession, datasourceId: UUID
    ) -> Union[Tuple[DatasourceSummary, Any], None]:
        """Retrieve a datasource by ID

        Fetch a single datasource by its UUID if the user has access
        """
        api = "/api/databus-controller/v1/datasources-summary/{datasourceId}"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(
                res=res, platform_object=DatasourceSummary
            )
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def update(
        session: SweetConnectSession,
        updatedDatasource: AddDatasource,
        datasourceId: UUID,
    ) -> Union[Tuple[Datasource, Any], None]:
        """Update an existing datasource

        Partially update fields of an existing datasource by its UUID
        """
        api = f"/api/databus-controller/v1/datasources/{datasourceId}"

        res = session.patch(
            f"{session.baseUrl}{api}",
            data=updatedDatasource.json(exclude_none=True, by_alias=True),
            headers={"Content-Type": "application/json"},
        )
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, Datasource)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def delete(session: SweetConnectSession, datasourceId: UUID) -> None:
        """Delete a datasource

        Remove a datasource permanently by its UUID. Requires proper access rights
        """
        api = f"/api/databus-controller/v1/datasources/{datasourceId}"
        res = session.delete(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return
        if 400 <= res.status_code < 499:
            logger.error(res.json())


class Tenants:
    @staticmethod
    def get_tenants(
        session: SweetConnectSession, tenantId: Union[UUID, None] = None
    ) -> Union[Tuple[List[Tenant], Any], None]:
        """List all available tenants.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            tenantId (str): Tenant ID. If None, all tenants from the platform are returned.

        Returns:
            List[Tenant]: List of existing tenants with their metadata.
        """
        api = "/api/auth/v1/tenants"

        if tenantId:
            api = api + f"/{tenantId}"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched tenants")
            return session.extract_object_list(res, Tenant)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_my_tenant(session: SweetConnectSession) -> Union[Tuple[Tenant, Any], None]:
        """Return currently activated tenant.

        Args:
            session (SweetConnectSession): active request session to SweetConnect

        Returns:
            Tenant: currently activated tenant.
        """
        api = "/api/auth/v1/tenants/mine"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched current tenants")
            return session.extract_new_object(res, Tenant)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def switch_tenant(
        session: SweetConnectSession, TenantId: UUID
    ) -> Union[Union[Tenant, Any], None]:
        """Enter a tenant and renew token to access tenant properties
        Args:
            session (SweetConnectSession): active request session to SweetConnect
            TenantId (str): Id of the tenant you want to switch to
        """
        api = "/api/auth/v1/tenants/switch/"
        res = session.post(f"{session.baseUrl}{api}{TenantId}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            # Renew Token after switching
            session.renewToken()
            # Sometimes the switch is not actually executed. Therefore ensure tenant switch was successful.
            try:
                current_tenant, _ = Tenants.get_my_tenant(session)
            except:
                logger.info("Tenant switching failed, trying again.")
                current_tenant = Tenants.switch_tenant(session, TenantId)
            if current_tenant.id == TenantId:
                logger.info(
                    f"Successfully switched to new tenant {current_tenant.name}"
                )
                return current_tenant
            else:
                logger.error("tenant switch not successfull. Please try again.")
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def leave_tenant(session: SweetConnectSession) -> None:
        """Enter a tenant and renew token to access tenant properties
        Args:
            session (SweetConnectSession): active request session to SweetConnect
        """
        api = "/api/auth/v1/tenants/leave"
        res = session.post(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            # Renew Token after leaving
            session.renewToken()
            logger.info("successfully left tenant")
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_picture_preview(
        session: SweetConnectSession, tenantId: UUID
    ) -> Union[bytes, None]:
        """Gets an organizations picture"""
        api = f"/api/storage/v1/pictures/profile/organization/{tenantId}/preview"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return res.content
        if 400 <= res.status_code < 499:
            logger.error(res.json())


class Manufacturers:
    @staticmethod
    def get_manufacturers(
        session: SweetConnectSession, manufacturerId: Union[str, None] = None
    ) -> Union[Tuple[List[Manufacturer], Any], None]:
        """List all available manufacturers.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            manufacturerId (str): Manufacturer ID. If None, all manufacturers from the platform are returned.

        Returns:
            List[Manufacturer]: List of existing manufacturers with their metadata.
        """
        api = "/api/core/manufacturers"

        if manufacturerId:
            api = api + f"/{manufacturerId}"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched manufacturers")
            return session.extract_object_list(res, Manufacturer)
        if 400 <= res.status_code < 499:
            logger.error(res.json())
