from dataclasses import dataclass
from datetime import datetime
from datetime import timedelta
from enum import Enum
from typing import Any
from typing import List
from typing import Tuple
from typing import Type
from typing import TypeVar
from typing import Union

from loguru import logger
from requests import Response
from requests import Session

from sweetconnect_api.models.sc_assets import Component
from sweetconnect_api.models.sc_assets import Line
from sweetconnect_api.models.sc_assets import Location
from sweetconnect_api.models.sc_assets import Machine
from sweetconnect_api.models.sc_assets import ProcessCell
from sweetconnect_api.models.sc_assets import TreeNode
from sweetconnect_api.models.sc_config import Datasource
from sweetconnect_api.models.sc_config import DatasourceSummary
from sweetconnect_api.models.sc_config import Manufacturer
from sweetconnect_api.models.sc_config import Tenant
from sweetconnect_api.models.sc_config import User
from sweetconnect_api.models.sc_documents import DocCategory
from sweetconnect_api.models.sc_documents import DocCategoryDetails
from sweetconnect_api.models.sc_documents import Document
from sweetconnect_api.models.sc_documents import Language
from sweetconnect_api.models.sc_files import AssetPicture
from sweetconnect_api.models.sc_maintenance import Maintenance
from sweetconnect_api.models.sc_maintenance import MaintenanceHistory


platform_object = TypeVar(
    "platform_object",
    Location,
    Line,
    ProcessCell,
    Machine,
    Component,
    TreeNode,
    AssetPicture,
    User,
    Tenant,
    Datasource,
    DatasourceSummary,
    Manufacturer,
    DocCategory,
    DocCategoryDetails,
    Language,
    Document,
    Maintenance,
    MaintenanceHistory,
)


@dataclass
class URLInfo:
    BaseURL: str
    TokenURL: str


class SystemInfo(Enum):
    production = URLInfo(
        BaseURL="https://my.sweetconnect.io",
        TokenURL="https://iam.my.sweetconnect.io/realms/sweetconnect-prod/protocol/openid-connect/token",
    )
    test = URLInfo(
        BaseURL="https://test.sweetconnect.io",
        TokenURL="https://iam.my.sweetconnect.io/realms/sweetconnect-test/protocol/openid-connect/token",
    )
    development = URLInfo(
        BaseURL="https://dev.sweetconnect.io",
        TokenURL="https://iam.dev.sweetconnect.io/realms/sweetconnect-test/protocol/openid-connect/token",
    )


class SweetConnectSession(Session):
    """Oject for building a persistent connection to Rest API."""

    def __init__(
        self,
        user: str,
        password: str,
        System: SystemInfo = SystemInfo.production,
        proxies: dict = {},
    ):
        super().__init__()
        self.baseUrl = System.value.BaseURL
        self.tokenUrl = System.value.TokenURL
        self.renewUrl = f"{self.baseUrl}/api/auth/v1/auth/renew"
        self.user = user
        self.proxies = proxies
        self.accessExpire = None
        self.getToken(password)

    def getToken(self, password: str):
        now = datetime.now()
        data = {
            "grant_type": "password",
            "client_id": "sweetconnect",
            "username": self.user,
            "password": password,
            "scope": "openid",
        }

        res = self.post(self.tokenUrl, data=data)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            resData = res.json()
            self.headers.update({"Authorization": f"Bearer {resData['access_token']}"})
            self.headers.update({"Cookie": f"refresh_token={resData['refresh_token']}"})
            self.cookies.set(
                "access_token",
                resData["access_token"],
                domain="my.sweetconnect.io",
                path="/",
            )
            self.cookies.set(
                "refresh_token",
                resData["refresh_token"],
                domain="my.sweetconnect.io",
                path="/",
            )
            self.accessExpire = now + timedelta(seconds=resData["expires_in"])
        if 400 <= res.status_code < 499:
            logger.error(res.text)

    def renewToken(self):
        """Renew token"""
        res = self.post(self.renewUrl)

        if 200 <= res.status_code < 299:
            logger.info("successfully renewed token")
            self.headers.update(
                {"Authorization": f"Bearer {res.cookies['access_token']}"}
            )
            self.headers.update(
                {"Cookie": f"refresh_token={res.cookies['refresh_token']}"}
            )
            self.cookies.set(
                "access_token",
                res.cookies["access_token"],
                domain="my.sweetconnect.io",
                path="/",
            )
            self.cookies.set(
                "refresh_token",
                res.cookies["refresh_token"],
                domain="my.sweetconnect.io",
                path="/",
            )
            for cookie in res.cookies:
                if cookie.name == "access_token" and cookie.expires:
                    self.accessExpire = datetime.fromtimestamp(cookie.expires)
                    break
        if 400 <= res.status_code < 499:
            logger.error("error renewing token")
            logger.error(res.json())

    def checkExpiration(self):
        """Check if Token needs refreshing"""
        if not self.accessExpire or (self.accessExpire - datetime.now()) < timedelta(
            seconds=120
        ):
            # renewToken, if valid for less than 120 seconds
            self.renewToken()

    def request(self, method, url, *args, **kwargs):
        """Overwrite default request function to check for token expiration"""
        if url not in [self.tokenUrl, self.renewUrl]:
            # exclude calls to get / renew tokens from check to prevent infinite loop
            self.checkExpiration()
        return super().request(method, url, *args, **kwargs)

    def logout(self):
        """Log out of SweetConnect"""
        api = "api/auth/v1/auth/sign-out"
        res = self.get(f"{self.baseUrl}{api}")

    def extract_new_object(
        self,
        res: Response,
        platform_object: Type[platform_object],
    ) -> Union[Tuple[platform_object, Any], None]:
        """Process HTTP Response when adding a new object

        Args:
            res (Response): HTTP Response

        Returns:
            platform object: a valid platform object, depending on the input data.
            meta: metainformation from api-call
        """
        res_dict = res.json()
        data = res_dict.get("data")
        meta = res_dict.get("meta")
        return platform_object.parse_obj(data), meta

    def extract_object_list(
        self, res: Response, platform_object: Type[platform_object,]
    ) -> Tuple[List[platform_object], Any]:
        """Process HTTP Response when adding a new object

        Args:
            res (Response): HTTP Response

        Returns:
            List[platform object]: a valid platform object, depending on the input data.
            meta: metainformation from api-call
        """
        res_dict = res.json()
        data = res_dict.get("data")
        if not isinstance(data, list):
            data = [data]
        objectList = [platform_object.parse_obj(eachObject) for eachObject in data]
        meta = res_dict.get("meta")
        return objectList, meta

    def extract_asset_tree(self, res: Response) -> List[TreeNode]:
        """Process HTTP Response when reading asset tree

        Args:
            res (Response): HTTP Response

        Returns:
            List[TreeNode]: List of locations with children
        """
        res_dict = res.json()
        data = res_dict.get("data")
        tree = [TreeNode.parse_obj(node) for node in data]
        return tree
