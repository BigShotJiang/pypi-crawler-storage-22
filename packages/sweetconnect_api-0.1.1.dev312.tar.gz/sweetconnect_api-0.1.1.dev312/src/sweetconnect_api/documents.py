from typing import Any
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union
from uuid import UUID

from loguru import logger
from pydantic import validate_arguments

from sweetconnect_api.connectionManager import SweetConnectSession
from sweetconnect_api.helpers import add_if_not_none
from sweetconnect_api.models.sc_documents import AddDocument
from sweetconnect_api.models.sc_documents import AlterDocument
from sweetconnect_api.models.sc_documents import DocCategory
from sweetconnect_api.models.sc_documents import DocCategoryDetails
from sweetconnect_api.models.sc_documents import Document
from sweetconnect_api.models.sc_documents import Language
from sweetconnect_api.models.sc_meta import PaginationMeta
from sweetconnect_api.models.sweetconnect_types import SortOrder


class Documents:
    # Storage - Categories
    # https://doc.api.dev.sweetconnect.io/#tag/Storage-Categories
    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_categories(
        session: SweetConnectSession, languageCode: Union[str, None] = None
    ) -> Union[Tuple[List[DocCategoryDetails], Any], None]:
        """Lists all document categories available in the platform

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            languageCode (str): filter returned category names by language

        Returns:
            List[DocCategory]: List of valid DocCategory objects
        """
        api = "/api/storage/v1/categories"

        params = {}
        if languageCode is not None:
            params["languageCode"] = languageCode

        res = session.get(f"{session.baseUrl}{api}", params=params)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched categories")
            return session.extract_object_list(res, DocCategoryDetails)
        if 400 <= res.status_code < 499:
            logger.info("categories could not be fetched")
            logger.error(res.json())

    @staticmethod
    def get_languages(
        session: SweetConnectSession,
    ) -> Union[Tuple[List[Language], Any], None]:
        """Lists all document languages available in the platform

        Args:
            session (SweetConnectSession): active request session to SweetConnect

        Returns:
            List[Language]: List of valid language objects
        """
        api = "/api/core/languages"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched languages")
            return session.extract_object_list(res, Language)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_category_by_id(
        session: SweetConnectSession,
        categoryId: str,
        languageCode: Union[str, None] = None,
    ) -> Union[Tuple[DocCategoryDetails, Any], None]:
        """Retrieve a specific category by its ID and language code

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            categoryId (str): UUID of category that should be returned
            languageCode (str): filter returned category names by language

        Returns:
            DocCategory: DocCategory object
        """
        api = f"/api/storage/v1/categories/{categoryId}"

        params = {}
        if languageCode is not None:
            params["languageCode"] = languageCode

        res = session.get(f"{session.baseUrl}{api}", params=params)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched categories")
            return session.extract_new_object(res, DocCategoryDetails)
        if 400 <= res.status_code < 499:
            logger.info("category could not be fetched")
            logger.error(res.json())

    # Storage - Documents
    # https://doc.api.dev.sweetconnect.io/#tag/Storage-Documents
    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_documents_by_assetId(
        session: SweetConnectSession,
        assetId: List[UUID],
        page: Optional[int] = 1,
        limit: Optional[int] = 10,
        searchByName: Optional[str] = None,
        sortByName: Optional[SortOrder] = None,
        sortByCategory: Optional[SortOrder] = None,
        sortByUpdatedAt: Optional[SortOrder] = None,
        sortByLanguage: Optional[SortOrder] = None,
        filterByCategory: Optional[list[str]] = None,
        filterByFileType: Optional[list[str]] = None,
        filterByLanguage: Optional[list[str]] = None,
    ) -> Union[Tuple[List[Document], PaginationMeta], None]:
        """Retrieve all documents associated with the given assetId and its children

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            assetId (list[str]): UUIDs of the assets, whose documents should be returned
            page (int >= 1): page number to retrieve
            limit (int [1...50]): The number of items per page
            searchByName (str [3...255] characters): Search filter by document name
            sortByName (str): Sort documents by name ("asc", "desc")
            sortByCategory (str): Sort documents by category ("asc", "desc")
            sortByUpdatedAt (str): Sort documents by last updated date ("asc", "desc")
            sortByLanguage (str): Sort documents by language ("asc", "desc")
            filterByCategory (list[str]): Filter by list of category codes
            filterByFileType (list[str]): Filter by list of file types (MIME types)
            filterByLanguage (list[str]): Filter by list of language codes (e.g., ISO 639-1). Pass "none" to exclude all language filters. If "none" is passed every other filter will get ignored

        Returns:
            list[Document]: List of documents associated with the given asset
        """
        api = "/api/storage/v1/documents"
        params = {"assetId": [str(uuid) for uuid in assetId]}
        add_if_not_none(
            params,
            page=page,
            limit=limit,
            searchByName=searchByName,
            sortByName=sortByName,
            sortByCategory=sortByCategory,
            sortByUpdatedAt=sortByUpdatedAt,
            sortByLanguage=sortByLanguage,
            filterByCategory=filterByCategory,
            filterByFileType=filterByFileType,
            filterByLanguage=filterByLanguage,
        )

        res = session.get(f"{session.baseUrl}{api}", params=params)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched languages")
            documents, meta = session.extract_object_list(res, Document)
            return documents, PaginationMeta.parse_obj(meta)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_document_by_fileId(
        session: SweetConnectSession, fileId: UUID
    ) -> Union[Tuple[Document, Any], None]:
        """Fetches a single document based on the provided file ID.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): The ID of the file to retrieve.

        Returns:
            Document: single document
        """
        api = f"/api/storage/v1/documents/file/{fileId}"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched languages")
            return session.extract_new_object(res, Document)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def preview_file(session: SweetConnectSession, fileId: UUID):
        """Streams the requested file as a response, allowing preview functionality.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): The ID of the file to retrieve.

        Returns:
            Document
        """
        api = f"/api/storage/v1/documents/{fileId}/preview"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")
        # TODO: What next?

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def add_document(
        session: SweetConnectSession, assetId: UUID, document: AddDocument
    ) -> Union[Tuple[Document, Any], None]:
        """This endpoint allows users to create a new document associated with a specific asset.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            assetId (str): The ID of the asset to associate the new document with.
            document (AddDocument): Object containing all needed parameters for creating a new document

        Returns:
            Document: the newly created document
        """
        if document.file.fileType == "application/zip":
            api = f"/api/storage/v1/documents/assets/zip/{assetId}"
        else:
            api = f"/api/storage/v1/documents/assets/{assetId}"
        with open(document.file.filePath, "rb") as file:
            fileData = file.read()
        files = {
            "file": (document.file.filePath.name, fileData, document.file.fileType)
        }
        data = {
            "displayname": document.displayname,
            "organizationId": document.organizationId,
            "categoryId": document.categoryId,
        }
        i = 0
        for languageCode in document.languageCodes:
            data[f"languageCodes[{i}]"] = languageCode
            i += 1
        res = session.post(f"{session.baseUrl}{api}", data=data, files=files)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, Document)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def update_document(
        session: SweetConnectSession, fileId: UUID, document: AlterDocument
    ) -> Union[Tuple[Document, Any], None]:
        """Updates an existing document with the given file ID.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): The ID of the file to update.
            document (AlterDocument): Object containing altered document

        Returns:
            Document: the updated document
        """
        api = f"/api/storage/v1/documents/{fileId}"

        with open(document.file.filePath, "rb") as file:
            fileData = file.read()

        with open(document.file.filePath, "rb") as file:
            fileData = file.read()
        files = {
            "file": (document.file.filePath.name, fileData, document.file.fileType)
        }
        data = {"displayname": document.displayname, "categoryId": document.categoryId}
        i = 0
        if document.languageCodes:
            for languageCode in document.languageCodes:
                data[f"languageCodes[{i}]"] = languageCode
                i += 1

        res = session.patch(f"{session.baseUrl}{api}", data=data, files=files)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, Document)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def delete_document(session: SweetConnectSession, fileId: UUID) -> None:
        """Deletes a document by file ID. Should check if the file is referenced before deletion.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): The ID of the file to update.

        Returns:
            None
        """
        api = f"/api/storage/v1/documents/{fileId}"
        res = session.delete(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_mime_types(session: SweetConnectSession, assetId: List[UUID]):
        """Returns a list of unique MIME types (e.g., application/pdf, image/png) used by documents associated with the provided asset IDs.
        This includes documents from the specified assets and any nested or related assets.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            assetId (List[str]): List of asset IDs to filter MIME types by

        Returns:
            ? List of available MIME types (for given asset IDs)
        """
        api = "/api/storage/v1/documents/available/mimetypes"

        params = {"assetId": assetId}
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")
        # TODO: What does the response look like?

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_categories_by_asset(
        session: SweetConnectSession, assetId: List[str]
    ) -> Union[Tuple[List[DocCategory], Any], None]:
        """Returns a list of unique document categories (IEC-61355 codes) associated with the provided asset IDs.
        This includes categories from related or nested assets in the production line hierarchy.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            assetId (List[str]): List of asset IDs to filter categories by

        Returns:
            List[DocCategory]: List of categories that are used by the documents of this asset (and children)
        """
        api = "/api/storage/v1/documents/available/categories"
        params = {"assetId": assetId}
        res = session.get(f"{session.baseUrl}{api}", params=params)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched languages")
            return session.extract_object_list(res, DocCategory)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_languages_by_asset(
        session: SweetConnectSession, assetId: List[UUID]
    ) -> Union[Tuple[List[Language], Any], None]:
        """Returns a list of languages in which documents are available for the given asset IDs. This includes languages from related or nested assets in the production line.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            assetId (List[str]): List of asset IDs to filter languages by

        Returns:
            List[Language]: List of languages that are used by the documents of this asset (and children)
        """
        api = "/api/storage/v1/documents/available/languages"
        params = {"assetId": [str(aId) for aId in assetId]}
        res = session.get(f"{session.baseUrl}{api}", params=params)
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched languages")
            return session.extract_object_list(res, Language)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    # Storage - Documents - Assets
    # https://doc.api.dev.sweetconnect.io/#tag/Storage-Documents-Assets
    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_assets_by_document(
        session: SweetConnectSession, fileId: UUID
    ) -> Union[List[UUID], None]:
        """Returns all assets, that are linked to the file

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): ID of the file whose references should be returned

        Returns:
            List of linked Assets (for given file ID)
        """
        api = f"/api/storage/v1/documents/assets/{fileId}/links"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")
        if 200 <= res.status_code < 299:
            logger.info("successfully fetched linked assets")
            data = res.json().get("data")
            return [UUID(assetId) for assetId in data]
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def link_document_asset(
        session: SweetConnectSession,
        fileId: UUID,
        assetId: UUID,
        assetOrganizationId: UUID,
    ) -> Union[Tuple[Document, Any], None]:
        """Link a document to an asset

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): The unique identifier of the file
            assetId (str): The unique identifier of the asset
            assetOrganizationId (str): The unique identifier of the organization of that asset

        Returns:
            Document: the linked document
        """
        api = (
            f"/api/storage/v1/documents/assets/{fileId}/{assetId}/{assetOrganizationId}"
        )
        res = session.post(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, Document)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def unlink_document_asset(
        session: SweetConnectSession, fileId: UUID, assetId: UUID
    ) -> None:
        """Removes a link between a file and an asset

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): The unique identifier of the file
            assetId (str): The unique identifier of the asset

        Returns:
            None
        """
        api = f"/api/storage/v1/documents/assets/{fileId}/{assetId}"
        res = session.post(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    # Storage - Documents - Maintenance
    # https://doc.api.dev.sweetconnect.io/#tag/Storage-Documents-Maintenance
    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def get_documents_by_maintenanceId(
        session: SweetConnectSession, maintenanceId: UUID
    ) -> Union[Tuple[List[Document], Any], None]:
        """Fetches all documents associated with a specific maintenance record.

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            maintenanceId (str): The ID of the maintenance record whose documents need to be retrieved.

        Returns:
            List[Document]: List of documents associated with the given maintenance
        """
        api = f"/api/storage/v1/documents/maintenance/{maintenanceId}"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched languages")
            return session.extract_object_list(res, Document)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_maintenances_by_document(
        session: SweetConnectSession, fileId: UUID
    ) -> Union[List[UUID], None]:
        """Returns all maintenances, that are linked to the file

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): ID of the file whose references should be returned

        Returns:
            List of linked maintenances (for given file ID)
        """
        api = f"/api/storage/v1/documents/maintenance/{fileId}/links"
        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched linked maintenances")
            data = res.json().get("data")
            return [UUID(maintenanceId) for maintenanceId in data]
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    @validate_arguments(config={"arbitrary_types_allowed": True})
    def link_document_maintenance(
        session: SweetConnectSession,
        maintenanceId: UUID,
        fileId: UUID,
        maintenanceOrganizationId: UUID,
    ) -> Union[bool, None]:
        """Link a document to an maintenance

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            maintenanceId (str): The unique identifier of the maintenance
            fileId (str): The unique identifier of the file
            maintenanceOrganizationId (str): The unique identifier of the organization of that maintenance

        Returns:
            None
        """
        api = f"/api/storage/v1/documents/maintenance/{maintenanceId}/{fileId}/{maintenanceOrganizationId}"
        res = session.post(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return True
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def unlink_document_maintenance(
        session: SweetConnectSession, fileId: UUID, maintenanceId: UUID
    ) -> None:
        """Removes a link between a file and an maintenance

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            fileId (str): The unique identifier of the file
            maintenanceId (str): The unique identifier of the maintenance

        Returns:
            None
        """
        api = f"/api/storage/v1/documents/maintenance/{maintenanceId}/{fileId}"
        res = session.post(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return
        if 400 <= res.status_code < 499:
            logger.error(res.json())
