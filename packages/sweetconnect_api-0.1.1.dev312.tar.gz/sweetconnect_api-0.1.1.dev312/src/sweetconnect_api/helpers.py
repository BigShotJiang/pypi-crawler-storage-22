from typing import Union

from sweetconnect_api.models import sc_assets
from sweetconnect_api.models.sweetconnect_types import AssetTypes


def add_if_not_none(target: dict, **kwargs):
    """Adds a key-value pair to a dict, if the value is not None"""
    for key, value in kwargs.items():
        if value is not None:
            target[key] = value


def get_application_type(fileSuffix: str) -> str:
    """Determines file type and corresponding application type based on file extension

    Args:
        fileSuffix (str): Extension of file eg. ".pdf"

    Returns:
        Tuple (FileType, str): returns the FileType and the application type to use
    """
    ApplicationTypes = {
        ".zip": "application/zip",
        ".pdf": "application/pdf",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".jfif": "image/jpeg",
        ".png": "image/png",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".txt": "text/plain",
        ".mp4": "video/mp4",
        ".mov": "video/mp4",
    }

    appType = ApplicationTypes.get(fileSuffix.lower())
    if appType:
        return appType
    else:
        raise NotImplementedError


def get_returntype(
    assetType: AssetTypes,
) -> Union[
    sc_assets.Location,
    sc_assets.Line,
    sc_assets.ProcessCell,
    sc_assets.Machine,
    sc_assets.Component,
]:
    """Determines the class, that is asscociated with an assetType"""
    ASSET_CLASS_MAP = {
        AssetTypes.location: sc_assets.Location,
        AssetTypes.production_line: sc_assets.Line,
        AssetTypes.process_cell: sc_assets.ProcessCell,
        AssetTypes.machine: sc_assets.Machine,
        AssetTypes.component: sc_assets.Component,
    }
    return ASSET_CLASS_MAP[assetType]


def get_detailModel(
    assetType: AssetTypes,
) -> Union[
    sc_assets.LocationDetail,
    sc_assets.LineDetail,
    sc_assets.ProcessCellDetail,
    sc_assets.MachineDetail,
    sc_assets.Component,
]:
    """Determines the class, that is asscociated with an assetType"""
    ASSET_CLASS_MAP = {
        AssetTypes.location: sc_assets.LocationDetail,
        AssetTypes.production_line: sc_assets.LineDetail,
        AssetTypes.process_cell: sc_assets.ProcessCellDetail,
        AssetTypes.machine: sc_assets.MachineDetail,
        AssetTypes.component: sc_assets.Component,
    }
    return ASSET_CLASS_MAP[assetType]
