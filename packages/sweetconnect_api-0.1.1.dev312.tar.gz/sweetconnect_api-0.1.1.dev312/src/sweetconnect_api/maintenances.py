from typing import Any
from typing import List
from typing import Tuple
from typing import Union
from uuid import UUID

from loguru import logger

from sweetconnect_api.connectionManager import SweetConnectSession
from sweetconnect_api.models.sc_maintenance import AddMaintenance
from sweetconnect_api.models.sc_maintenance import AlterMaintenance
from sweetconnect_api.models.sc_maintenance import Maintenance
from sweetconnect_api.models.sc_maintenance import MaintenanceHistory


class Maintenances:
    @staticmethod
    def add_maintenance(
        session: SweetConnectSession, maintenance: AddMaintenance
    ) -> Union[Tuple[Maintenance, Any], None]:
        """Create a new maintenance

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            maintenance (AddMaintenance): Object containing all needed parameters for creating a new maintenance

        Returns:
            Maintenace: Valid Maintenance object containing the ID given by the Tenant the maintenance was added to
        """
        api = "/api/wds/v1/maintenances"

        res = session.post(
            f"{session.baseUrl}{api}",
            data=maintenance.json(exclude_unset=True),
            headers={"Content-Type": "application/json"},
        )
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, Maintenance)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def update_maintenance(
        session: SweetConnectSession, maintenance: AlterMaintenance, uuid: UUID
    ) -> Union[Tuple[Maintenance, Any], None]:
        """Update an existing maintenance

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            maintenance (Maintenance): Object containing all needed parameters to update an exiting maintenance
            uuid (str): Platform Id of the maintenance which should be updated

        Returns:
            Maintenance: Valid Maintenance object containing the ID given by the Tenant the maintenance was added to
        """
        api = f"/api/wds/v1/maintenances/{uuid}"

        res = session.put(
            f"{session.baseUrl}{api}",
            data=maintenance.json(exclude_none=True),
            headers={"Content-Type": "application/json"},
        )
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            return session.extract_new_object(res, Maintenance)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_maintenances(
        session: SweetConnectSession,
        maintenanceId: Union[UUID, None] = None,
        assetId: Union[UUID, None] = None,
    ) -> Union[Tuple[List[Maintenance], Any], None]:
        """List all maintenances available in the platform

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            maintenanceId (str): can be specified, if only one maintenance sould be fetched
            assetId (str): can be specified to filter returned maintenances based on the asset they are linked to. CAUTION: Currently this only returns maintenances directly linked to this asset, not from child assets.

        Returns:
            List[Maintenance]: List of valid Maintenance objects
        """
        api = "/api/wds/v1/maintenances"
        if maintenanceId:
            api = api + f"/{maintenanceId}"
        else:  # es kann nur auf eine der beiden arten gefiltert werden.
            if assetId:
                api = api + f'?s={{"assetId":"{assetId}"}}'

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched maintenances")
            return session.extract_object_list(res, Maintenance)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def get_maintenance_history(
        session: SweetConnectSession, maintenanceId: UUID
    ) -> Union[Tuple[List[MaintenanceHistory], Any], None]:
        """Lists the history of one maintenance

        Args:
            session (SweetConnectSession): active request session to SweetConnect
            maintenanceId (str): platform Id of the maintenance in question

        Returns:
            List[MaintenanceHistory]: List of valid Maintenance objects
        """
        api = f"/api/wds/v1/maintenances/{maintenanceId}/history"

        res = session.get(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if 200 <= res.status_code < 299:
            logger.info("successfully fetched maintenance history")
            return session.extract_object_list(res, MaintenanceHistory)
        if 400 <= res.status_code < 499:
            logger.error(res.json())

    @staticmethod
    def delete_maintenance(session: SweetConnectSession, maintenanceId: UUID):
        """Delete a single Maintenance **Please unlink every documents assigned to this maintenace first!**"""
        api = f"/api/wds/v1/maintenances/{maintenanceId}"

        res = session.delete(f"{session.baseUrl}{api}")
        logger.info(f"Response <{res.status_code}>")

        if res.status_code != 200:
            logger.error(f"Deletion of maintenance {maintenanceId} failed!")
