from __future__ import annotations

import json
from datetime import datetime
from uuid import UUID

from pydantic import BaseModel
from pydantic import Field
from typing_extensions import Annotated

from sweetconnect_api.models.sweetconnect_types import AssetTypes


class CreatedBy(str):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, value):
        if isinstance(value, UUID):
            return value
        if isinstance(value, str):
            if value == "MIGRATION":
                return value
            try:
                return UUID(value)
            except ValueError:
                raise ValueError("createdBy must be a valid UUID or 'MIGRATION'")
        raise TypeError("createdBy must be a UUID or 'MIGRATION' string")


class AssemblyParameters(dict):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if isinstance(v, str):
            try:
                return cls(json.loads(v))
            except json.JSONDecodeError:
                raise ValueError("Value is not valid JSON")
        if isinstance(v, dict):
            return cls(v)
        raise TypeError("Value must be dict or JSON string")


class Address(BaseModel):
    city: str
    country: str
    address1: str | None = None
    address2: str | None = None
    postalcode: str | None = None
    state: str | None = None


class CustomAttribute(BaseModel):  # TODO. Not further specified in documentation
    key: str
    value: str


class AddComponent(BaseModel):
    assetType: AssetTypes = AssetTypes.component
    name: str
    manufacturerId: UUID | None = (
        None  # Id of the manufacturer -> only relevant for global admin, otherwise gets ignored
    )
    manufacturerName: str | None = None  # Name of the manufacturer
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    serialNumber: str
    constructionYear: str | None = (
        None  # https://oem-support.sweetconnect.io/en/support/tickets/898
    )
    component_type: str | None = Field(
        None, alias="type"
    )  # type is a reserved keyword in python, so alias is used
    assembly: str | None = None
    assemblyVersion: str | None = None
    assemblyParameters: AssemblyParameters | None = None
    connectionParameter: str | None = None
    datasourceId: UUID | None = None
    customAttributes: list[CustomAttribute] = []


class AlterComponent(BaseModel):
    assetType: AssetTypes = AssetTypes.component
    name: str | None = None
    serialNumber: str | None = None
    constructionYear: str | None = None
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    component_type: str | None = Field(default=None, alias="type")
    assembly: str | None = None
    assemblyVersion: str | None = None
    assemblyParameters: AssemblyParameters | None = None
    datasourceId: UUID | None = None
    connectionParameter: str | None = None
    customAttributes: list[CustomAttribute] | None = None


class Component(BaseModel):
    assetType: AssetTypes = AssetTypes.component
    id: UUID
    name: str
    organizationId: UUID
    description: str | None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    createdAt: datetime
    updatedAt: datetime
    createdBy: CreatedBy
    updatedBy: CreatedBy
    active: bool
    draft: bool
    custom: bool
    parentId: UUID | None
    position: Annotated[int, Field(strict=True, ge=0)]
    customAttributes: list[CustomAttribute]
    manufacturerId: UUID | None
    manufacturerName: str | None
    serialNumber: str
    component_type: str | None = Field(alias="type")
    assembly: str | None
    assemblyVersion: str | None
    assemblyParameters: AssemblyParameters | None
    datasourceId: UUID | None
    connectionParameter: str | None
    constructionYear: str | None = (
        None  # https://oem-support.sweetconnect.io/en/support/tickets/898
    )


class AddMachine(BaseModel):
    assetType: AssetTypes = AssetTypes.machine
    name: str
    manufacturerId: UUID | None = (
        None  # Id of the manufacturer -> only relevant for global admin, otherwise gets ignored
    )
    manufacturerName: str | None = None  # Name of the manufacturer
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    serialNumber: str
    constructionYear: str
    machine_type: str | None = Field(
        None, alias="type"
    )  # type is a reserved keyword in python, so alias is used
    assembly: str | None = None
    assemblyVersion: str | None = None
    assemblyParameters: AssemblyParameters | None = None
    connectionParameter: str | None = None
    datasourceId: UUID | None = None
    customAttributes: list[CustomAttribute] = []


class AlterMachine(BaseModel):
    """Object for altering an existing machine"""

    assetType: AssetTypes = AssetTypes.machine
    name: str | None = None
    serialNumber: str | None = None
    constructionYear: str | None = None
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    machine_type: str | None = Field(
        default=None, alias="type"
    )  # type is a reserved keyword in python, so alias is used
    assembly: str | None = None
    assemblyVersion: str | None = None
    assemblyParameters: AssemblyParameters | None = None
    datasourceId: UUID | None = None
    connectionParameter: str | None = None
    customAttributes: list[CustomAttribute] | None = None


class Machine(BaseModel):
    assetType: AssetTypes
    id: UUID
    name: str
    organizationId: UUID
    description: str | None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    createdAt: datetime
    updatedAt: datetime
    createdBy: CreatedBy
    updatedBy: CreatedBy
    active: bool
    draft: bool
    custom: bool
    parentId: UUID | None
    position: Annotated[int, Field(strict=True, ge=0)]
    customAttributes: list[CustomAttribute]
    manufacturerId: UUID | None
    manufacturerName: str | None
    serialNumber: str
    machine_type: str | None = Field(
        alias="type"
    )  # type is a reserved keyword in python, so alias is used
    assembly: str | None
    assemblyVersion: str | None
    assemblyParameters: AssemblyParameters | None
    datasourceId: UUID | None
    connectionParameter: str | None
    constructionYear: str


class MachineDetail(Machine):
    children: list[Component] = []


class AddProcessCell(BaseModel):
    assetType: AssetTypes = AssetTypes.process_cell
    name: str
    manufacturerId: UUID | None = (
        None  # Id of the manufacturer -> only relevant for global admin, otherwise gets ignored
    )
    manufacturerName: str | None = (
        None  # Name of the manufacturer -> only relevant for custom assets, otherwise gets ignored
    )
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    serialNumber: str
    constructionYear: str
    process_cell_type: str | None = Field(
        None, alias="type"
    )  # Specific type or model variant of the process cell
    assembly: str | None = None  # Assembly designation of the process cell
    assemblyVersion: str | None = (
        None  # Version of the assembly installed in the process cell
    )
    assemblyParameters: AssemblyParameters | None = (
        None  # Parameters for building the assembly url
    )
    connectionParameter: str | None = (
        None  # Connection interface used by the process cell
    )
    datasourceId: UUID | None = None  # Connection interface used by the process cell
    customAttributes: list[CustomAttribute] = []


class AlterProcessCell(BaseModel):
    assetType: AssetTypes = AssetTypes.process_cell
    name: str | None = None
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    serialNumber: str | None = None
    constructionYear: str | None = None
    process_cell_type: str | None = Field(None, alias="type")
    assembly: str | None = None
    assemblyVersion: str | None = None
    assemblyParameters: AssemblyParameters | None = None
    datasourceId: UUID | None = None
    connectionParameter: str | None = None
    customAttributes: list[CustomAttribute] | None = None


class ProcessCell(BaseModel):
    assetType: AssetTypes = AssetTypes.process_cell
    id: UUID
    name: str
    organizationId: UUID
    description: str | None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    createdAt: datetime
    updatedAt: datetime
    createdBy: CreatedBy
    updatedBy: CreatedBy
    active: bool  # Flag indicating whether the asset is active
    draft: bool  # Flag indicating whether the asset is in draft state
    custom: bool  # Flag indicating whether the asset is a custom asset (created by a producer)
    parentId: UUID | None
    position: Annotated[int, Field(strict=True, ge=0)]
    customAttributes: list[CustomAttribute]
    manufacturerId: UUID | None
    manufacturerName: str | None
    serialNumber: str  # Serial number assigned by the Manufacturer
    process_cell_type: str | None = Field(
        alias="type"
    )  # Subtype or model of the Manufacturer unit
    assembly: str | None  # Assembly line or section where the unit was assembled
    assemblyVersion: str | None  # Version of the assembly process used
    assemblyParameters: None | (
        AssemblyParameters
    )  # Parameters for building the assembly url
    datasourceId: UUID | None  # ID of the Datasource
    connectionParameter: str | None  # connection interface of the machine
    constructionYear: str  # Year the unit was constructed (YYYY)


class ProcessCellDetail(ProcessCell):
    children: list[MachineDetail] = []


class AddLine(
    BaseModel
):  # Manufacturers are not allowed to create locations and production lines
    assetType: AssetTypes = AssetTypes.production_line
    name: str
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    customAttributes: list[CustomAttribute] = []


class AlterLine(BaseModel):
    assetType: AssetTypes = AssetTypes.production_line
    name: str | None = None
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    customAttributes: list[CustomAttribute] | None = None


class Line(BaseModel):
    assetType: AssetTypes = Field(AssetTypes.production_line)
    id: UUID
    name: str
    organizationId: UUID
    description: str | None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    createdAt: datetime
    updatedAt: datetime
    createdBy: CreatedBy
    updatedBy: CreatedBy
    active: bool
    draft: bool
    custom: bool
    parentId: UUID | None
    position: Annotated[int, Field(strict=True, ge=0)]
    customAttributes: list[CustomAttribute]


class LineDetail(Line):
    children: list[MachineDetail | ProcessCellDetail] = []


class AddLocation(
    BaseModel
):  # Manufacturers are not allowed to create locations and production lines
    assetType: AssetTypes = AssetTypes.location
    name: str = Field(max_length=255)
    description: str | None = None  # Detailed description of the location
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    address: Address
    customAttributes: list[CustomAttribute] = []


class AlterLocation(BaseModel):
    assetType: AssetTypes = AssetTypes.location
    name: str | None = None
    description: str | None = None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    adress: Address | None = None
    customAttributes: list[CustomAttribute] | None = None


class Location(BaseModel):
    assetType: AssetTypes = Field(AssetTypes.location)
    id: UUID
    name: str
    organizationId: UUID
    description: str | None
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    createdAt: datetime
    updatedAt: datetime
    createdBy: CreatedBy
    updatedBy: CreatedBy
    active: bool  # Flag indicating whether the asset is active
    draft: bool  # Flag indicating whether the asset is in draft state
    custom: bool  # Flag indicating whether the asset is a custom asset (created by a producer)
    parentId: UUID | None
    position: Annotated[int, Field(strict=True, ge=0)]
    customAttributes: list[CustomAttribute]
    address: Address


class LocationDetail(Location):
    children: list[LineDetail | ProcessCellDetail | MachineDetail] = []


class TreeNode(BaseModel):
    id: UUID
    assetType: AssetTypes
    custom: bool
    active: bool
    machineConnection: bool
    name: str
    imageUrl: str | None = None  # Deprecated, will be removed in next update
    position: int
    parentId: UUID | None
    children: list[TreeNode]
