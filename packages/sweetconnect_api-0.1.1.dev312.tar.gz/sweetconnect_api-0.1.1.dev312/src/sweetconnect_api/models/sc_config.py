from datetime import datetime
from typing import List
from typing import Optional
from typing import Union
from uuid import UUID

from pydantic import BaseModel
from pydantic import Field
from pydantic import HttpUrl

from sweetconnect_api.models.sweetconnect_types import CatalogType
from sweetconnect_api.models.sweetconnect_types import datasourceTypes
from sweetconnect_api.models.sweetconnect_types import dbFeatures
from sweetconnect_api.models.sweetconnect_types import marketplaceRole
from sweetconnect_api.models.sweetconnect_types import sweetConnectRole


class AdapterOptions(BaseModel):
    """Definition of datasource adapter"""

    url: str
    token: str
    org: str
    bucket: str


class InfluxDb2ConnectionInfo(BaseModel):
    org: str
    url: HttpUrl
    token: str
    bucket: str


class TranslationMapper(BaseModel):
    state: List[str]
    log: List[str]
    aggregatedMetrics: List[str]


class InuatekConnectionInfo(BaseModel):
    url: HttpUrl
    token: str
    translationMapper: TranslationMapper


class AddDatasource(BaseModel):
    """class for adding datasource to platform"""

    datasourceTypes: datasourceTypes
    name: str
    adapter: Union[InfluxDb2ConnectionInfo, InuatekConnectionInfo]


class Datasource(BaseModel):
    """returned datasource object from platform"""

    id: UUID
    datasourceType: datasourceTypes
    name: str
    organizationId: UUID
    manufacturerId: UUID
    adapter: Union[InfluxDb2ConnectionInfo, InuatekConnectionInfo]
    supportedFeatures: List[dbFeatures]
    createdAt: datetime
    updatedAt: datetime


class AlterDatasource(BaseModel):
    datasourceType: Optional[datasourceTypes] = None
    name: Optional[str] = None
    adapter: Union[InfluxDb2ConnectionInfo, InuatekConnectionInfo]


class DatasourceSummary(BaseModel):
    id: UUID
    datasourceType: datasourceTypes
    name: str
    organizationId: UUID
    manufacturerId: UUID
    supportedFeatures: dbFeatures


class User(BaseModel):
    """Model for a platform user"""

    last_login: Optional[datetime] = Field(None, alias="last-login")
    manufacturerId: Optional[UUID]
    prior_login: Optional[datetime] = Field(None, alias="prior-login")
    id: UUID
    imageUrl: Optional[str]
    tenantId: Optional[UUID]
    roleIds: Optional[List[str]]
    name: Optional[str]
    username: Optional[str]
    firstName: Optional[str]
    lastName: Optional[str]
    email: str
    activated: Optional[bool]
    createdAt: datetime
    role: Optional[sweetConnectRole]
    marketplaceRole: Optional[marketplaceRole]
    consentGiven: Optional[str]
    language: Optional[str]
    termsAndCondition: Optional[datetime]


class Tenant(BaseModel):
    """Model for a platform tenant / organisation"""

    id: UUID
    name: str
    activated: bool
    createdAt: datetime
    image: Optional[str]
    duns: Optional[str]
    address: Optional[str]
    adminName: Optional[str]
    adminMail: Optional[str]
    properties: Optional[dict]
    active: Optional[bool]
    adminRequested: Optional[datetime]
    zip: Optional[str]
    city: Optional[str]
    country: Optional[str]
    state: Optional[str]
    lineOne: Optional[str]
    lineTwo: Optional[str]


class Manufacturer(BaseModel):
    createdAt: datetime
    updated: Optional[datetime]
    manufacturerName: str
    activated: bool
    id: UUID
    name: str
    catalog: Optional["Catalog"]


class Catalog(BaseModel):
    id: UUID
    type: CatalogType
    createdAt: datetime
    updatedAt: Optional[datetime]
