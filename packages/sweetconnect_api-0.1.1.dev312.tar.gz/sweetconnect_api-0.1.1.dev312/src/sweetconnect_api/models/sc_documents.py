from datetime import datetime
from typing import Dict
from typing import List
from typing import Optional
from uuid import UUID

from pydantic import BaseModel
from pydantic import Field

from sweetconnect_api.models.sc_files import File


class Translation(BaseModel):
    """Object that contains the localized name for an element"""

    languageCode: str = Field(max_length=10)
    name: str


class DocCategory(BaseModel):
    """Definition of document category"""

    id: str
    languageCode: str = Field(max_length=10)
    name: str


class DocCategoryDetails(BaseModel):
    id: str
    translations: List[Translation]


class Language(BaseModel):
    """Definition of document language"""

    code: str
    name: Dict[str, str]


class AddDocument(BaseModel):
    """Object containing all needed parameters for creating a new document"""

    displayname: str
    organizationId: UUID
    categoryId: str
    languageCodes: list[str]
    file: File


class Document(BaseModel):
    """Document object containing the ID given by the platform"""

    id: UUID
    filename: str
    displayname: str
    ownerId: str
    organizationId: str
    manufacturerId: Optional[str] = None
    mimetype: str
    updatedAt: datetime
    updatedBy: str
    createdAt: datetime
    createdBy: str
    category: DocCategory
    languages: List[str]


class AlterDocument(BaseModel):
    """Object for altering an existing document"""

    displayname: str
    categoryId: str
    languageCodes: Optional[List[str]]
    file: File
