from pathlib import Path
from typing import Optional
from uuid import UUID

from pydantic import BaseModel


class AssetPicture(BaseModel):
    """Object representing an assets image"""

    id: UUID
    filename: str
    ownerId: UUID
    mimetype: str
    organizationId: UUID
    manufacturerId: Optional[UUID]
    assetId: str


class File(BaseModel):
    filePath: Path
    fileType: str
