from typing import Optional
from uuid import UUID

from pydantic import BaseModel
from pydantic import Field
from pydantic import validator

from sweetconnect_api.models.sweetconnect_types import MaintenanceInterval
from sweetconnect_api.models.sweetconnect_types import MaintenancePersonnel


class MaintenanceReminder(BaseModel):
    """Defines a reminder for a maintenance"""

    id: Optional[str] = None
    interval: float
    intervalUnit: MaintenanceInterval


class AddMaintenance(BaseModel):
    """Object containing all needed parameters for creating a new maintenance"""

    title: str = Field(max_length=100)
    pdmId: str
    description: str
    active: bool
    structure: str
    part: str
    responsibilityGroup: MaintenancePersonnel
    dueDate: str
    interval: Optional[float] = None
    intervalUnit: MaintenanceInterval
    componentsList: str
    toolsList: str
    showFixedDialog: bool
    showStateDialog: bool
    showInputDialog: bool
    inputFieldLabel: Optional[str] = None
    assetName: str
    assetId: UUID
    startValue: Optional[float] = None
    reminder: Optional[MaintenanceReminder] = None

    class Config:
        # use_enum_values = True
        json_encoders = {
            MaintenancePersonnel: lambda v: v.value,
            MaintenanceInterval: lambda v: v.value,
        }

    # @validator('responsibilityGroup', pre=True, always=True)
    # def parse_responsibilityGroup(cls, v):
    #     if isinstance(v, str):
    #         return MaintenancePersonnel(v)
    #     return v

    # @validator('intervalUnit', pre=True, always=True)
    # def parse_intervalUnit(cls, v):
    #     if isinstance(v, str):
    #         return MaintenanceInterval(v)
    #     return v


class Maintenance(BaseModel):
    """Maintenance object containing the ID given by the platform"""

    id: UUID
    owner: Optional[str] = None
    title: str
    pdmId: str
    createdAt: str
    updatedAt: str
    assetId: UUID
    assetName: str
    description: str
    active: bool
    structure: str
    part: str
    responsibilityGroup: MaintenancePersonnel
    dueDate: str
    startValue: Optional[float]
    interval: int
    intervalUnit: MaintenanceInterval
    componentsList: str
    toolsList: str
    showFixedDialog: bool
    showStateDialog: bool
    showInputDialog: bool
    inputFieldLabel: Optional[str]
    reminder: Optional[MaintenanceReminder]


class AlterMaintenance(BaseModel):
    """Object for altering an existing maintenance"""

    owner: Optional[UUID] = None
    title: Optional[str] = None
    pdmId: Optional[str] = None
    createdAt: Optional[str] = None
    updatedAt: Optional[str] = None
    assetId: Optional[UUID] = None
    assetName: Optional[str] = None
    description: Optional[str] = None
    active: Optional[bool] = None
    structure: Optional[str] = None
    part: Optional[str] = None
    responsibilityGroup: Optional[MaintenancePersonnel] = None
    dueDate: Optional[str] = None
    startValue: Optional[float] = None
    interval: Optional[int] = None
    intervalUnit: Optional[MaintenanceInterval] = None
    componentsList: Optional[str] = None
    toolsList: Optional[str] = None
    showFixedDialog: Optional[bool] = None
    showStateDialog: Optional[bool] = None
    showInputDialog: Optional[bool] = None
    inputFieldLabel: Optional[str] = None
    reminder: Optional[MaintenanceReminder] = None


class MaintenanceHistory(BaseModel):
    """Object containing one fullfillment of a maintenance"""

    id: UUID
    owner: Optional[UUID]
    userId: UUID
    createdAt: str
    value: Optional[float]
    fixed: Optional[bool]
    state: Optional[str]
    numericInput: Optional[float]
    comment: Optional[str]

    @validator("owner", pre=True)
    def empty_string_to_none(cls, v):
        if v == "":
            return None
        return v
