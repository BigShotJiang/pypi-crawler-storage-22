from pydantic import BaseModel


class PaginationMeta(BaseModel):
    page: int
    offset: int
    limit: int
    totalItems: int
    totalPages: int
    hasNextPage: bool
    hasPreviousPage: bool
