from enum import Enum


class AssetTypes(Enum):
    location = "location"
    production_line = "production-line"
    process_cell = "process-cell"
    machine = "machine"
    component = "component"


class FileTypes(Enum):
    file = "file"
    container = "container"


class MaintenancePersonnel(Enum):
    operator = "operator"
    electrician = "electrician"
    maintainer = "maintainer"
    technician = "technician"
    cleaner = "cleaner"


class MaintenanceInterval(Enum):
    days = "days"
    weeks = "weeks"
    months = "months"
    years = "years"
    operating_hours = "operating_hours"
    unknown = "none"


class refTypes(Enum):
    location = "asset_location"
    line = "asset_line"
    machine = "asset_machine"
    component = "asset_component"
    maintenance = "maintenance"
    maintenance_history = "maintenance_history"
    user = "user"
    undefined = "asset_undefined"


class datasourceTypes(Enum):
    InfluxDB_v2 = "InfluxDB_v2"
    InfluxDB_v3 = "InfluxDB_v3"
    Inuatek = "Inuatek"


class dbFeatures(Enum):
    state = "state"
    log = "log"
    aggregatedMetrics = "aggregatedMetrics"


class marketplaceRole(Enum):
    sweetconnect = "sweetconnect"
    buyer = "buyer"
    seller = "seller"
    technician = "technician"


class sweetConnectRole(Enum):
    admin = "admin"
    manufacturer_admin = "manufacturer-admin"
    manufacturer_user = "manufacturer-user"
    producer_admin = "producer-admin"
    producer_user = "producer-user"
    representative = "representative"


class CatalogType(Enum):
    parts_publisher = "parts-publisher"
    catalog_creator = "catalog-creator"


class SortOrder(str, Enum):
    ASC = ("asc",)
    DESC = "desc"


class AssetView(Enum):
    normal = "normal"
    unassigned = "unassigned"
    inactive = "inactive"
    draft = "draft"
    published = "published"
