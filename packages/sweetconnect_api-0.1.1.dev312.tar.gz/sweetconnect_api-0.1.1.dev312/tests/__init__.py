"""Test suite for the sweetconnect-api package."""
