"""Git operations — branch management and PR creation."""

from __future__ import annotations

import asyncio
import logging
import os
import re

import requests

from sweetie.models import Task

logger = logging.getLogger(__name__)


def slugify(text: str) -> str:
    """Convert a task title to a git-safe branch slug."""
    slug = text.lower().strip()
    slug = re.sub(r"[^a-z0-9\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    slug = slug.strip("-")
    return slug[:60]  # keep branch names reasonable


def branch_name(task: Task) -> str:
    """Generate a branch name for a task."""
    return f"sweetie-agent/{slugify(task.title)}"


async def _run(cmd: str, cwd: str) -> tuple[int, str, str]:
    """Run a shell command and return (returncode, stdout, stderr)."""
    env = os.environ.copy()
    proc = await asyncio.create_subprocess_shell(
        cmd,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    stdout, stderr = await proc.communicate()
    return proc.returncode, stdout.decode(), stderr.decode()


def _get_github_repo(repo_path: str) -> str:
    """Extract 'owner/repo' from the git remote URL."""
    import subprocess
    result = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=repo_path, capture_output=True, text=True,
    )
    url = result.stdout.strip()
    # Handle SSH: git@github.com:owner/repo.git
    match = re.search(r"github\.com[:/](.+?)(?:\.git)?$", url)
    if match:
        return match.group(1)
    raise RuntimeError(f"Could not parse GitHub owner/repo from remote URL: {url}")


def _get_github_token(config_token: str = "") -> str:
    """Get a GitHub token from config, environment, or gh CLI auth."""
    if config_token:
        return config_token
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        return token
    # Try gh auth as fallback
    import subprocess
    result = subprocess.run(
        ["gh", "auth", "token"], capture_output=True, text=True,
    )
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    raise RuntimeError(
        "No GitHub token found. Set github.token in sweetie.yaml, GITHUB_TOKEN env var, or install and authenticate gh CLI."
    )


async def create_branch(repo_path: str, branch: str, base_branch: str) -> None:
    """Create and check out a new branch from the base branch."""
    # Commit or stash any uncommitted changes from a previous task
    rc, stdout, _ = await _run("git status --porcelain", repo_path)
    if rc == 0 and stdout.strip():
        logger.info("Stashing uncommitted changes before switching branches.")
        await _run("git stash --include-untracked", repo_path)

    rc, _, err = await _run("git fetch origin", repo_path)
    if rc != 0:
        logger.warning("git fetch failed: %s", err)

    # Check if branch already exists locally (for resumed tasks or PR revisions)
    rc, _, _ = await _run(f"git rev-parse --verify {branch}", repo_path)
    if rc == 0:
        logger.info("Branch %s already exists locally, checking it out.", branch)
        await _run(f"git checkout {branch}", repo_path)
        # Pull latest in case the developer pushed commits
        rc, _, err = await _run(f"git pull origin {branch}", repo_path)
        if rc != 0:
            logger.warning("git pull failed (may not have remote tracking): %s", err)
        return

    # Check if branch exists on the remote (e.g. after a state reset)
    rc, ls_out, _ = await _run(f"git ls-remote --heads origin refs/heads/{branch}", repo_path)
    if rc == 0 and ls_out.strip():
        logger.info("Branch %s exists on remote, checking it out.", branch)
        rc, _, err = await _run(f"git checkout -b {branch} origin/{branch}", repo_path)
        if rc != 0:
            raise RuntimeError(f"Failed to check out remote branch {branch}: {err}")
        return

    rc, _, err = await _run(
        f"git checkout -b {branch} origin/{base_branch}", repo_path
    )
    if rc != 0:
        raise RuntimeError(f"Failed to create branch {branch}: {err}")
    logger.info("Created branch %s from origin/%s", branch, base_branch)


async def read_handoff_file(repo_path: str) -> str | None:
    """Read the handoff file if it exists."""
    rc, stdout, _ = await _run(
        "cat .agent-queue/handoff.md 2>/dev/null", repo_path
    )
    if rc == 0 and stdout.strip():
        return stdout.strip()
    return None


async def remove_handoff_file(repo_path: str) -> None:
    """Remove the handoff file and commit the removal."""
    rc, _, _ = await _run("test -f .agent-queue/handoff.md", repo_path)
    if rc != 0:
        return  # file doesn't exist

    await _run(
        'git rm -f .agent-queue/handoff.md && git commit -m "agent: remove handoff file for PR"',
        repo_path,
    )
    # Clean up the directory if empty
    await _run("rmdir .agent-queue 2>/dev/null", repo_path)
    logger.info("Removed handoff file from branch.")


def fetch_pr_comments(pr_url: str, github_token: str = "") -> str:
    """Fetch review comments and issue comments from a GitHub PR.

    Returns a formatted string with all comments, or empty string if none.
    """
    # Extract owner/repo and PR number from URL
    # e.g. https://github.com/owner/repo/pull/123
    match = re.search(r"github\.com/([^/]+/[^/]+)/pull/(\d+)", pr_url)
    if not match:
        logger.warning("Could not parse PR URL: %s", pr_url)
        return ""

    owner_repo = match.group(1)
    pr_number = match.group(2)
    token = _get_github_token(github_token)
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
    }

    comments = []

    # 1. PR review comments (inline code comments)
    try:
        resp = requests.get(
            f"https://api.github.com/repos/{owner_repo}/pulls/{pr_number}/comments",
            headers=headers,
            timeout=30,
        )
        if resp.ok:
            for c in resp.json():
                path = c.get("path", "")
                body = c.get("body", "")
                user = c.get("user", {}).get("login", "reviewer")
                ts = c.get("created_at", "")
                line = c.get("original_line") or c.get("line") or ""
                location = f" ({path}:{line})" if path else ""
                comments.append(f"[{ts}] **{user}**{location}: {body}")
    except requests.RequestException:
        logger.exception("Failed to fetch PR review comments")

    # 2. PR reviews (the summary body submitted with approve/request changes)
    try:
        resp = requests.get(
            f"https://api.github.com/repos/{owner_repo}/pulls/{pr_number}/reviews",
            headers=headers,
            timeout=30,
        )
        if resp.ok:
            for r in resp.json():
                body = r.get("body", "").strip()
                if not body:
                    continue
                user = r.get("user", {}).get("login", "reviewer")
                ts = r.get("submitted_at", "")
                state = r.get("state", "").replace("_", " ").title()
                comments.append(f"[{ts}] **{user}** ({state}): {body}")
    except requests.RequestException:
        logger.exception("Failed to fetch PR reviews")

    # 3. PR issue comments (general conversation)
    try:
        resp = requests.get(
            f"https://api.github.com/repos/{owner_repo}/issues/{pr_number}/comments",
            headers=headers,
            timeout=30,
        )
        if resp.ok:
            for c in resp.json():
                body = c.get("body", "")
                user = c.get("user", {}).get("login", "reviewer")
                ts = c.get("created_at", "")
                comments.append(f"[{ts}] **{user}**: {body}")
    except requests.RequestException:
        logger.exception("Failed to fetch PR issue comments")

    if not comments:
        PR_feedback = ""
        logger.info("No PR review comments found")
    else:
        PR_feedback = "## PR Review Feedback\n\n" + "\n\n---\n\n".join(comments)
        logger.info("PR review comments found")
        logger.info(PR_feedback)
    return PR_feedback


async def create_pr(
    repo_path: str,
    branch: str,
    base_branch: str,
    task: Task,
    summary: str,
    test_output: str = "",
    github_token: str = "",
) -> str:
    """Push the branch and create a PR via GitHub API. Returns the PR URL."""
    # Verify there are commits on the branch beyond the base
    rc, stdout, _ = await _run(
        f"git log origin/{base_branch}..{branch} --oneline", repo_path
    )
    if rc != 0 or not stdout.strip():
        # No commits — stage and commit everything as a fallback
        logger.warning("No commits found on branch %s, committing all changes...", branch)
        rc2, status_out, _ = await _run("git status --porcelain", repo_path)
        if rc2 == 0 and status_out.strip():
            await _run("git add -A", repo_path)
            await _run(
                f'git commit -m "agent: {task.title}"',
                repo_path,
            )
        else:
            raise RuntimeError(
                f"No commits on branch {branch} and no uncommitted changes — nothing to PR."
            )

    # Push the branch
    rc, push_out, err = await _run(f"git push -u origin {branch}", repo_path)
    if rc != 0:
        raise RuntimeError(f"Failed to push branch: {err}")
    logger.info("Push output: %s", (push_out + err).strip()[:200])

    # Verify the branch exists on the remote
    rc, ls_out, _ = await _run(f"git ls-remote origin refs/heads/{branch}", repo_path)
    if rc != 0 or not ls_out.strip():
        raise RuntimeError(
            f"Push seemed to succeed but branch {branch} not found on remote. "
            f"Check that the git remote 'origin' is correct and the token has push access."
        )

    # Build PR body
    verification = test_output if test_output else "No test suite configured — agent self-verified changes"

    pr_body = f"""## Summary
{summary}

## Task
- **Notion:** {task.notion_url}
- **Branch:** `{branch}`

## Verification
{verification}

---
🤖 Generated by [Sweetie](https://github.com/maryanngong/sweetie)
"""

    # Create PR via GitHub API (retry to handle push propagation delay)
    owner_repo = _get_github_repo(repo_path)
    token = _get_github_token(github_token)
    logger.info("Creating PR: repo=%s, head=%s, base=%s", owner_repo, branch, base_branch)
    pr_payload = {
        "title": task.title,
        "body": pr_body,
        "head": branch,
        "base": base_branch,
    }
    pr_headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
    }

    max_attempts = 3
    for attempt in range(1, max_attempts + 1):
        resp = requests.post(
            f"https://api.github.com/repos/{owner_repo}/pulls",
            headers=pr_headers,
            json=pr_payload,
            timeout=30,
        )

        if resp.status_code == 422 and "already exists" in resp.text.lower():
            # PR already exists for this branch — find it
            resp2 = requests.get(
                f"https://api.github.com/repos/{owner_repo}/pulls",
                headers=pr_headers,
                params={"head": f"{owner_repo.split('/')[0]}:{branch}", "state": "open"},
                timeout=30,
            )
            if resp2.ok and resp2.json():
                pr_url = resp2.json()[0]["html_url"]
                logger.info("PR already exists: %s", pr_url)
                return pr_url

        if resp.ok:
            pr_url = resp.json()["html_url"]
            logger.info("Created PR: %s", pr_url)
            return pr_url

        # Retry on "not all refs are readable" — GitHub may still be processing the push
        if attempt < max_attempts and resp.status_code == 422 and "not all refs" in resp.text.lower():
            logger.warning("GitHub hasn't processed the push yet, retrying in %ds... (attempt %d/%d)",
                           attempt * 3, attempt, max_attempts)
            await asyncio.sleep(attempt * 3)
            continue

        raise RuntimeError(f"GitHub API error ({resp.status_code}): {resp.text[:500]}")
