"""Sweetie — autonomous AI coding agent orchestrator."""

__version__ = "0.1.0"
