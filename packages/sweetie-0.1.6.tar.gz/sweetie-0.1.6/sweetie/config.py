"""Configuration loading and validation."""

from __future__ import annotations

import os
import re
from pathlib import Path

import yaml
from pydantic import BaseModel, Field


def _interpolate_env_vars(value: str) -> str:
    """Replace ${VAR_NAME} with environment variable values."""
    def replacer(match: re.Match) -> str:
        var_name = match.group(1)
        env_val = os.environ.get(var_name)
        if env_val is None:
            raise ValueError(f"Environment variable ${{{var_name}}} is not set")
        return env_val
    return re.sub(r"\$\{(\w+)\}", replacer, value)


def _interpolate_recursive(obj: object) -> object:
    """Recursively interpolate env vars in strings throughout a nested structure."""
    if isinstance(obj, str):
        return _interpolate_env_vars(obj)
    if isinstance(obj, dict):
        return {k: _interpolate_recursive(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_interpolate_recursive(v) for v in obj]
    return obj


class NotionColumnConfig(BaseModel):
    title: str = "Task"
    description: str = "Description"
    status: str = "Status"
    status_type: str = "status"  # "status" (native Notion type) or "select"
    priority: str = "Priority"
    repo: str = "Repo"
    agent_branch: str = "Agent Branch"
    agent_pr: str = "Agent PR"
    agent_notes: str = "Agent Notes"
    blocked_reason: str = "Blocked Reason"
    cost: str = "Cost"
    test_command: str = "Test Command"
    slack_thread_ts: str = "Slack Thread TS"
    slack_channel: str = "Slack Channel"


class NotionStatusConfig(BaseModel):
    queued: str = "Queued"
    in_progress: str = "In Progress"
    blocked: str = "Blocked"
    in_review: str = "In Review"
    done: str = "Done"
    failed: str = "Failed"


class NotionFilterConfig(BaseModel):
    column: str                # Column name (e.g. "Assignee", "Team")
    value: str                 # Value to match (e.g. "Sweetie", "Backend")
    type: str = "select"       # Notion property type: "select", "rich_text", "checkbox", etc.


class NotionConfig(BaseModel):
    api_key: str
    database_id: str
    columns: NotionColumnConfig = Field(default_factory=NotionColumnConfig)
    status_values: NotionStatusConfig = Field(default_factory=NotionStatusConfig)
    priority_values: list[str] = Field(default_factory=lambda: ["P0", "P1", "P2"])
    filter: NotionFilterConfig | None = None


class SlackConfig(BaseModel):
    webhook_url: str
    bot_token: str = ""    # Required for picking up thread replies
    channel: str = ""      # Slack channel ID (e.g. C0123456789)


class AgentConfig(BaseModel):
    model: str = ""
    max_turns_per_task: int = 0
    max_retries_on_test_fail: int = 2
    max_cost_per_task_usd: float = 5.0
    max_cost_per_session_usd: float = 50.0
    poll_interval_seconds: int = 30
    loop_delay_seconds: int = 5


class RepoConfig(BaseModel):
    test_command: str = ""
    lint_command: str = ""
    base_branch: str = "main"
    allowed_tools: list[str] = Field(default_factory=list)
    pre_approved: list[str] = Field(default_factory=list)


class SafetyConfig(BaseModel):
    blocked_bash_patterns: list[str] = Field(default_factory=lambda: [
        "rm -rf",
        "git push --force",
        "DROP TABLE",
        "curl.*|.*sh",
    ])
    require_tests_pass: bool = True
    require_lint_pass: bool = False


class GitHubConfig(BaseModel):
    token: str = ""  # Falls back to GITHUB_TOKEN env var or gh CLI


class SweetieConfig(BaseModel):
    notion: NotionConfig
    slack: SlackConfig
    github: GitHubConfig = Field(default_factory=GitHubConfig)
    agent: AgentConfig = Field(default_factory=AgentConfig)
    repos: dict[str, RepoConfig] = Field(default_factory=dict)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)


def load_config(path: str | Path = "sweetie.yaml") -> SweetieConfig:
    """Load and validate config from a YAML file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path) as f:
        raw = yaml.safe_load(f)

    if not raw:
        raise ValueError(f"Config file is empty: {path}")

    interpolated = _interpolate_recursive(raw)
    return SweetieConfig.model_validate(interpolated)
