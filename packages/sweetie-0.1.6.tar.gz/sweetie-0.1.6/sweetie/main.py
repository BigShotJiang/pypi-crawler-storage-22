"""CLI entry point for Sweetie."""

from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

import click

from sweetie.config import load_config
from sweetie.models import TaskStatus
from sweetie.orchestrator import Orchestrator
from sweetie.state import AgentState


class ColoredFormatter(logging.Formatter):
    """Log formatter with ANSI colors for terminal output."""

    LEVEL_COLORS = {
        logging.DEBUG: "\033[2m",       # dim
        logging.INFO: "\033[36m",       # cyan
        logging.WARNING: "\033[33m",    # yellow
        logging.ERROR: "\033[31m",      # red
        logging.CRITICAL: "\033[1;31m", # bold red
    }
    NAME_COLOR = "\033[35m"  # magenta
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        level_color = self.LEVEL_COLORS.get(record.levelno, "")
        record.levelname = f"{level_color}{record.levelname}{self.RESET}"
        record.name = f"{self.NAME_COLOR}{record.name}{self.RESET}"
        return super().format(record)


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    handler = logging.StreamHandler()
    handler.setFormatter(ColoredFormatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logging.basicConfig(level=level, handlers=[handler])


@click.group()
@click.version_option(package_name="sweetie")
def cli() -> None:
    """Sweetie — autonomous AI coding agent orchestrator.

    Pulls tasks from Notion, works on them via Claude Code,
    notifies you on Slack when blocked, and delivers PRs.
    """


@cli.command()
@click.option("--config", "-c", default="sweetie.yaml", help="Path to config file.")
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging.")
@click.option("--fresh", is_flag=True, help="Reset session state before starting.")
def start(config: str, verbose: bool, fresh: bool) -> None:
    """Start the Sweetie daemon."""
    setup_logging(verbose)
    logger = logging.getLogger("sweetie")

    try:
        cfg = load_config(config)
    except FileNotFoundError:
        click.echo(f"Config file not found: {config}", err=True)
        click.echo("Run 'sweetie validate' to check your config, or copy sweetie.example.yaml.", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Config error: {e}", err=True)
        sys.exit(1)

    if fresh:
        state = AgentState()
        state.save()
        logger.info("Session state reset.")
    else:
        state = AgentState.load()
        # Clear stale active task from a previous crashed run — nothing is actually running
        if state.has_active_task():
            logger.info("Clearing stale active task %s from previous run.", state.active_task_id)
            state.active_task_id = None
            state.save()
    logger.info("Loaded state: %d blocked tasks, $%.2f spent this session.",
                len(state.blocked_tasks), state.total_cost_this_session)

    orchestrator = Orchestrator(cfg, state)

    try:
        asyncio.run(orchestrator.run())
    except KeyboardInterrupt:
        logger.info("Interrupted.")
        state.save()


@cli.command()
@click.option("--config", "-c", default="sweetie.yaml", help="Path to config file.")
def validate(config: str) -> None:
    """Validate the config file."""
    try:
        cfg = load_config(config)
        click.echo("Config is valid!")
        click.echo(f"  Notion database: {cfg.notion.database_id}")
        if cfg.repos:
            click.echo(f"  Repos configured: {len(cfg.repos)}")
            for path in cfg.repos:
                repo_cfg = cfg.repos[path]
                tests = repo_cfg.test_command or "(none)"
                click.echo(f"    {path} — tests: {tests}, base: {repo_cfg.base_branch}")
        else:
            click.echo(f"  Repos: (none configured — will use current directory)")
        click.echo(f"  Model: {cfg.agent.model}")
        click.echo(f"  Session budget: ${cfg.agent.max_cost_per_session_usd:.2f}")
        click.echo(f"  Task budget: ${cfg.agent.max_cost_per_task_usd:.2f}")
    except FileNotFoundError:
        click.echo(f"Config file not found: {config}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Config error: {e}", err=True)
        sys.exit(1)


@cli.command()
def status() -> None:
    """Show current agent status."""
    state = AgentState.load()

    click.echo("Sweetie Status")
    click.echo("=" * 40)

    if state.has_active_task():
        click.echo(f"  Active task: {state.active_task_id}")
    else:
        click.echo("  Active task: (none)")

    click.echo(f"  Blocked tasks: {len(state.blocked_tasks)}")
    for tid, info in state.blocked_tasks.items():
        click.echo(f"    {tid[:8]}... — {info.question[:60]}")
        click.echo(f"      Branch: {info.branch_name}")
        click.echo(f"      Blocked at: {info.blocked_at.isoformat()}")

    click.echo(f"  Completed this session: {len(state.completed_tasks)}")
    click.echo(f"  Session cost: ${state.total_cost_this_session:.2f}")
    click.echo(f"  Session started: {state.started_at.isoformat()}")


@cli.command()
@click.argument("task_id")
@click.option("--config", "-c", default="sweetie.yaml", help="Path to config file.")
def unblock(task_id: str, config: str) -> None:
    """Re-queue a blocked task so Sweetie picks it up again.

    TASK_ID can be the full Notion page ID or just the first few characters.
    """
    state = AgentState.load()

    # Match by prefix so you can use short IDs from `sweetie status`
    matches = [tid for tid in state.blocked_tasks if tid.startswith(task_id)]
    if not matches:
        click.echo(f"No blocked task found matching '{task_id}'.", err=True)
        if state.blocked_tasks:
            click.echo("Blocked tasks:", err=True)
            for tid in state.blocked_tasks:
                click.echo(f"  {tid[:8]}...", err=True)
        sys.exit(1)
    if len(matches) > 1:
        click.echo(f"Ambiguous ID '{task_id}' matches multiple tasks:", err=True)
        for tid in matches:
            click.echo(f"  {tid[:8]}...", err=True)
        sys.exit(1)

    full_id = matches[0]
    info = state.blocked_tasks[full_id]

    # Re-queue in Notion
    try:
        cfg = load_config(config)
    except Exception as e:
        click.echo(f"Config error: {e}", err=True)
        sys.exit(1)

    from sweetie.queue.notion import NotionQueueAdapter
    queue = NotionQueueAdapter(cfg.notion)
    try:
        asyncio.run(queue.update_task_status(full_id, TaskStatus.QUEUED, {
            "agent_notes": "Manually unblocked via CLI.",
        }))
    except Exception as e:
        click.echo(f"Failed to re-queue in Notion: {e}", err=True)
        sys.exit(1)

    # Remove from blocked state
    state.unblock_task(full_id)
    state.save()

    click.echo(f"Unblocked task {full_id[:8]}... — status set back to Queued.")
    click.echo(f"  Question was: {info.question[:80]}")
    click.echo(f"  Branch: {info.branch_name}")


@cli.command()
def reset() -> None:
    """Reset the session state (cost, completed tasks, blocked tasks)."""
    state = AgentState()
    state.save()
    click.echo("Session state has been reset.")


if __name__ == "__main__":
    cli()
