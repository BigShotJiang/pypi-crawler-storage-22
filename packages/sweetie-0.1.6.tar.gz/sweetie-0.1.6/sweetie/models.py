"""Shared data models for Sweetie."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class TaskStatus(str, Enum):
    QUEUED = "queued"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    IN_REVIEW = "in_review"
    DONE = "done"
    FAILED = "failed"


class ResultStatus(str, Enum):
    SUCCESS = "success"
    BLOCKED = "blocked"
    FAILED = "failed"
    UNCERTAIN = "uncertain"


@dataclass
class Task:
    id: str
    title: str
    description: str
    status: TaskStatus
    priority: str
    repo: str = ""
    agent_branch: str = ""
    agent_pr: str = ""
    agent_notes: str = ""
    blocked_reason: str = ""
    cost: float = 0.0
    test_command: str = ""
    slack_thread_ts: str = ""
    slack_channel: str = ""
    notion_url: str = ""
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class WorkerResult:
    status: ResultStatus
    summary: str = ""
    question: str = ""
    error: str = ""
    output: str = ""
    branch_name: str = ""
    cost: float = 0.0
    handoff_notes: str = ""


@dataclass
class BlockedInfo:
    question: str
    blocked_at: datetime
    branch_name: str
    slack_thread_ts: str = ""   # Slack message ts for polling thread replies
    slack_channel: str = ""     # Slack channel ID where the blocked message was posted
