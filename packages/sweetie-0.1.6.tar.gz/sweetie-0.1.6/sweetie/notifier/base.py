"""Abstract interface for notification backends."""

from __future__ import annotations

from typing import Protocol

from sweetie.models import Task


class Notifier(Protocol):
    """Protocol for notification backends (Slack, Telegram, etc.)."""

    async def notify_started(self, task: Task) -> None:
        """Notify that a task has been started."""
        ...

    async def notify_blocked(self, task: Task, question: str) -> tuple[str, str]:
        """Notify that a task is blocked. Returns (channel, thread_ts) for reply polling."""
        ...

    async def notify_completed(self, task: Task, pr_url: str) -> None:
        """Notify that a task is complete and a PR has been created."""
        ...

    async def notify_failed(self, task: Task, error: str) -> None:
        """Notify that a task has failed."""
        ...

    async def notify_budget_exceeded(self, total_cost: float) -> None:
        """Notify that the session budget has been exceeded."""
        ...

    async def notify_error(self, error: str) -> None:
        """Notify that an unexpected error occurred in the orchestrator."""
        ...

    async def notify_session_complete(self, completed: int, blocked: int, cost: float) -> None:
        """Notify that the queue is empty and the session is ending."""
        ...
