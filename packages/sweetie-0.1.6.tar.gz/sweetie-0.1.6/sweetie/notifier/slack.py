"""Slack notification implementation with thread reply support."""

from __future__ import annotations

import logging

import requests

from sweetie.config import SlackConfig
from sweetie.models import Task

logger = logging.getLogger(__name__)


class SlackNotifier:
    """Send notifications via Slack and poll thread replies for blocked tasks."""

    def __init__(self, config: SlackConfig) -> None:
        self.webhook_url = config.webhook_url
        self.bot_token = config.bot_token
        self.channel = config.channel
        self._bot_user_id: str = ""

    def _send_webhook(self, text: str) -> None:
        """Send a message via incoming webhook (fire-and-forget)."""
        try:
            resp = requests.post(
                self.webhook_url,
                json={"text": text},
                timeout=10,
            )
            resp.raise_for_status()
        except requests.RequestException:
            logger.exception("Failed to send Slack webhook notification")

    def _send_api(self, text: str, thread_ts: str = "") -> tuple[str, str]:
        """Send a message via Slack Web API. Returns (channel, ts) for threading.

        If thread_ts is provided, posts as a reply in that thread.
        Falls back to webhook if bot_token/channel not configured (returns empty strings).
        """
        if not self.bot_token or not self.channel:
            self._send_webhook(text)
            return "", ""

        try:
            payload = {
                "channel": self.channel,
                "text": text,
            }
            if thread_ts:
                payload["thread_ts"] = thread_ts

            resp = requests.post(
                "https://slack.com/api/chat.postMessage",
                headers={"Authorization": f"Bearer {self.bot_token}"},
                json=payload,
                timeout=10,
            )
            data = resp.json()
            if not data.get("ok"):
                logger.error("Slack API error: %s", data.get("error", "unknown"))
                # Fall back to webhook
                self._send_webhook(text)
                return "", ""
            return data.get("channel", ""), data.get("ts", "")
        except requests.RequestException:
            logger.exception("Failed to send Slack API notification")
            self._send_webhook(text)
            return "", ""

    _STATUS_ICONS = {
        "in_progress": ":large_blue_circle:",
        "blocked": ":large_yellow_circle:",
        "in_review": ":large_green_circle:",
        "failed": ":red_circle:",
        "done": ":white_check_mark:",
    }

    async def update_parent_status(
        self, channel: str, ts: str, task: Task, status: str, detail: str = "",
    ) -> None:
        """Update the parent thread message with the latest task status."""
        icon = self._STATUS_ICONS.get(status, ":large_blue_circle:")
        status_label = status.replace("_", " ").title()
        text = f"{icon} *{status_label}:* \"{task.title}\"\n{self._task_links(task)}"
        if detail:
            text += f"\n   {detail}"
        await self.update_message(channel, ts, text)

    def _task_links(self, task: Task) -> str:
        lines = []
        if task.notion_url:
            lines.append(f"   Notion: {task.notion_url}")
        if task.agent_branch:
            lines.append(f"   Branch: `{task.agent_branch}`")
        return "\n".join(lines)

    async def notify_started(self, task: Task) -> tuple[str, str]:
        """Send a started notification. Returns (channel, thread_ts) for threading."""
        text = (
            f":large_blue_circle: *Started:* \"{task.title}\"\n"
            f"{self._task_links(task)}"
        )
        return self._send_api(text)

    async def notify_blocked(
        self, task: Task, question: str, thread_ts: str = "",
    ) -> tuple[str, str]:
        """Send a blocked notification. Returns (channel, thread_ts) for reply polling."""
        text = (
            f":large_yellow_circle: *Blocked:* \"{task.title}\"\n"
            f"   Question: {question}\n"
            f"   Reply in this thread and @mention me to unblock, or update the Notion task.\n"
            f"{self._task_links(task)}"
        )
        return self._send_api(text, thread_ts=thread_ts)

    async def notify_completed(
        self, task: Task, pr_url: str, thread_ts: str = "",
    ) -> None:
        text = (
            f":large_green_circle: *PR Ready:* \"{task.title}\"\n"
            f"   PR: {pr_url}\n"
            f"{self._task_links(task)}"
        )
        self._send_api(text, thread_ts=thread_ts)

    async def notify_failed(
        self, task: Task, error: str, thread_ts: str = "",
    ) -> None:
        text = (
            f":red_circle: *Failed:* \"{task.title}\"\n"
            f"   Error: {error}\n"
            f"{self._task_links(task)}"
        )
        self._send_api(text, thread_ts=thread_ts)

    async def notify_budget_exceeded(self, total_cost: float) -> None:
        self._send_webhook(
            f":black_circle: *Session Budget Exceeded:* ${total_cost:.2f} spent across this session.\n"
            f"   Agent has shut down. Restart with `sweetie start` to continue."
        )

    async def notify_error(self, error: str) -> None:
        self._send_webhook(
            f":warning: *Sweetie Error:* {error[:500]}\n"
            f"   Check the terminal for full details."
        )

    async def notify_session_complete(
        self, completed: int, blocked: int, cost: float,
    ) -> None:
        self._send_webhook(
            f":white_check_mark: *Sweetie finished all queued tasks.*\n"
            f"   Completed: {completed} | Blocked: {blocked} | Cost: ${cost:.2f}\n"
            f"   Add more tasks to Notion and run `sweetie start` to continue. To reset the session stats and cost tracking, run `sweetie start --fresh`."
        )

    async def update_message(self, channel: str, ts: str, text: str) -> None:
        """Edit an existing Slack message."""
        if not self.bot_token or not channel or not ts:
            return
        try:
            resp = requests.post(
                "https://slack.com/api/chat.update",
                headers={"Authorization": f"Bearer {self.bot_token}"},
                json={
                    "channel": channel,
                    "ts": ts,
                    "text": text,
                },
                timeout=10,
            )
            data = resp.json()
            if not data.get("ok"):
                logger.error("Slack chat.update error: %s", data.get("error", "unknown"))
        except requests.RequestException:
            logger.exception("Failed to update Slack message")

    async def reply_in_thread(self, channel: str, thread_ts: str, text: str) -> None:
        """Post a reply in an existing Slack thread."""
        if not self.bot_token or not channel or not thread_ts:
            return
        try:
            requests.post(
                "https://slack.com/api/chat.postMessage",
                headers={"Authorization": f"Bearer {self.bot_token}"},
                json={
                    "channel": channel,
                    "thread_ts": thread_ts,
                    "text": text,
                },
                timeout=10,
            )
        except requests.RequestException:
            logger.exception("Failed to reply in Slack thread")

    def _get_bot_user_id(self) -> str:
        """Fetch and cache the bot's Slack user ID via auth.test."""
        if self._bot_user_id:
            return self._bot_user_id
        if not self.bot_token:
            return ""
        try:
            resp = requests.get(
                "https://slack.com/api/auth.test",
                headers={"Authorization": f"Bearer {self.bot_token}"},
                timeout=10,
            )
            data = resp.json()
            if data.get("ok"):
                self._bot_user_id = data.get("user_id", "")
                logger.debug("Bot user ID: %s", self._bot_user_id)
            else:
                logger.error("Failed to get bot user ID: %s", data.get("error", "unknown"))
        except requests.RequestException:
            logger.exception("Failed to fetch bot user ID")
        return self._bot_user_id

    async def check_thread_reply(self, channel: str, thread_ts: str) -> str | None:
        """Check if a developer has @mentioned the bot in a Slack thread.

        Only triggers on messages that mention the bot. Returns the full thread
        context (all non-bot replies) so Sweetie has the complete conversation.
        """
        if not self.bot_token or not channel or not thread_ts:
            return None

        bot_user_id = self._get_bot_user_id()

        try:
            resp = requests.get(
                "https://slack.com/api/conversations.replies",
                headers={"Authorization": f"Bearer {self.bot_token}"},
                params={
                    "channel": channel,
                    "ts": thread_ts,
                },
                timeout=10,
            )
            data = resp.json()
            if not data.get("ok"):
                logger.error("Slack API error checking replies: %s", data.get("error", "unknown"))
                return None

            messages = data.get("messages", [])
            # First message is always the parent — look for replies after it
            human_replies = []
            has_mention = False
            for msg in messages[1:]:
                # Skip bot messages (our own replies)
                if msg.get("bot_id") or msg.get("subtype") == "bot_message":
                    continue
                text = msg.get("text", "")
                human_replies.append(text)
                # Check if this message @mentions the bot
                if bot_user_id and f"<@{bot_user_id}>" in text:
                    has_mention = True

            if has_mention and human_replies:
                return "\n\n".join(human_replies)

        except requests.RequestException:
            logger.exception("Failed to check Slack thread replies")

        return None
