"""Main event loop — polls the queue, dispatches work, handles results."""

from __future__ import annotations

import asyncio
import logging
import signal
from pathlib import Path

from sweetie.config import RepoConfig, SweetieConfig
from sweetie.models import BlockedInfo, ResultStatus, TaskStatus
from sweetie.notifier.slack import SlackNotifier
from sweetie.queue.notion import NotionQueueAdapter
from sweetie.state import AgentState
from sweetie.worker import git as git_ops
from sweetie.worker.engine import WorkerEngine

logger = logging.getLogger(__name__)


class Orchestrator:
    """The main sweetie daemon loop."""

    def __init__(self, config: SweetieConfig, state: AgentState) -> None:
        self.config = config
        self.state = state
        self.queue = NotionQueueAdapter(config.notion)
        self.notifier = SlackNotifier(config.slack)
        self.worker = WorkerEngine(config.agent, config.safety, config.github.token)
        self._shutdown = False
        self._empty_polls = 0
        self._max_empty_polls = 10

    def _resolve_repo(self, task_repo: str) -> tuple[str, RepoConfig]:
        """Resolve repo path and config for a task.

        Priority: task's Repo field → config repos → current working directory.
        """
        if task_repo and task_repo in self.config.repos:
            return task_repo, self.config.repos[task_repo]

        if task_repo:
            # Task specifies a repo not in config — use it with defaults
            return task_repo, RepoConfig()

        # Fall back to first configured repo
        if self.config.repos:
            repo_path = next(iter(self.config.repos))
            return repo_path, self.config.repos[repo_path]

        # Fall back to current working directory
        import os
        cwd = os.getcwd()
        logger.info("No repo configured, using current directory: %s", cwd)
        return cwd, RepoConfig()

    async def run(self) -> None:
        """Main orchestrator loop."""
        loop = asyncio.get_event_loop()
        loop.add_signal_handler(signal.SIGTERM, self._handle_shutdown)
        loop.add_signal_handler(signal.SIGINT, self._handle_shutdown)

        # Repopulate blocked task thread info from Notion (survives state resets)
        await self._restore_blocked_tasks()

        logger.info("Sweetie started. Polling for tasks....")

        while not self._shutdown:
            try:
                await self._tick()
            except Exception as e:
                logger.exception("Error in orchestrator tick")
                try:
                    await self.notifier.notify_error(str(e))
                except Exception:
                    logger.exception("Failed to send error notification")

            self.state.save()
            await asyncio.sleep(self.config.agent.loop_delay_seconds)

        logger.info("Sweetie shutting down gracefully.")
        await self.worker.cancel()
        self.state.save()

    async def _tick(self) -> None:
        """Single iteration of the main loop."""
        # 1. Check session budget
        if self.state.total_cost_this_session >= self.config.agent.max_cost_per_session_usd:
            logger.warning(
                "Session budget exceeded ($%.2f), shutting down.",
                self.state.total_cost_this_session,
            )
            await self.notifier.notify_budget_exceeded(self.state.total_cost_this_session)
            self._shutdown = True
            return

        # 2. Check for Slack thread replies on blocked tasks
        await self._check_blocked_replies()

        # 3. Don't pick up new work if already busy
        if self.state.has_active_task():
            return

        # 4. Pick next task
        tasks = await self.queue.fetch_queued_tasks()
        if not tasks:
            self._empty_polls += 1
            if self._empty_polls >= self._max_empty_polls:
                logger.info("Queue empty for %d polls, wrapping up.", self._empty_polls)
                await self.notifier.notify_session_complete(
                    completed=len(self.state.completed_tasks),
                    blocked=len(self.state.blocked_tasks),
                    cost=self.state.total_cost_this_session,
                )
                self._shutdown = True
                return
            logger.info("Queue empty (%d/%d), sleeping %ds...",
                        self._empty_polls, self._max_empty_polls,
                        self.config.agent.poll_interval_seconds)
            await asyncio.sleep(self.config.agent.poll_interval_seconds)
            return

        self._empty_polls = 0  # reset on finding work
        task = tasks[0]
        logger.info("Picked task: %s (%s)", task.title, task.id[:8])

        # 5. Resolve repo
        try:
            repo_path, repo_config = self._resolve_repo(task.repo)
        except RuntimeError as e:
            logger.error("Cannot work on task %s: %s", task.title, e)
            await self.queue.update_task_status(task.id, TaskStatus.FAILED, {
                "agent_notes": str(e),
            })
            await self.notifier.notify_failed(task, str(e))
            return

        # 6. Claim it — reuse existing branch name if the task already has one
        branch_name = task.agent_branch.strip() or git_ops.branch_name(task)
        claimed = await self.queue.claim_task(task.id)
        if not claimed:
            logger.warning("Failed to claim task %s, skipping.", task.title)
            return

        self.state.active_task_id = task.id
        task.agent_branch = branch_name
        self.state.save()

        await self.queue.update_task_status(task.id, TaskStatus.IN_PROGRESS, {
            "agent_branch": branch_name,
            "agent_notes": "Working on this...",
        })
        # Store Slack thread for this task (reuse existing thread if resuming)
        thread_channel, thread_ts = "", ""
        if task.id in self.state.task_threads:
            thread_channel, thread_ts = self.state.task_threads[task.id]

        started_channel, started_ts = await self.notifier.notify_started(task)
        if not thread_ts and started_ts:
            # First time working on this task — use the started message as thread parent
            thread_channel, thread_ts = started_channel, started_ts
            self.state.task_threads[task.id] = (thread_channel, thread_ts)
            self.state.save()

        # 7. Check if this task was previously blocked and has an answer
        blocked_answer = None
        if task.id in self.state.blocked_tasks:
            blocked_info = self.state.blocked_tasks[task.id]
            # The developer may have added context to the description
            blocked_answer = f"Task was re-queued by developer. Previous question: {blocked_info.question}"
            self.state.unblock_task(task.id)

        # 8. Execute
        result = await self.worker.execute(
            task=task,
            repo_path=repo_path,
            repo_config=repo_config,
            blocked_answer=blocked_answer,
        )
        self.state.total_cost_this_session += result.cost

        # 9. Build agent notes from summary + handoff
        agent_notes = result.summary or ""
        if result.handoff_notes:
            agent_notes = f"{agent_notes}\n\n---\n\n{result.handoff_notes}" if agent_notes else result.handoff_notes

        # 10. Handle result
        if result.status == ResultStatus.SUCCESS:
            try:
                pr_url = await self.worker.create_pr(task, result, repo_path, repo_config)
                await self.queue.update_task_status(task.id, TaskStatus.IN_REVIEW, {
                    "agent_pr": pr_url,
                    "agent_branch": result.branch_name,
                    "agent_notes": agent_notes,
                    "cost": result.cost,
                })
                await self.notifier.notify_completed(task, pr_url, thread_ts=thread_ts)
                await self.notifier.update_parent_status(
                    thread_channel, thread_ts, task, "in_review", f"PR: {pr_url}",
                )
                self.state.mark_completed(task.id)
            except RuntimeError as e:
                logger.error("Failed to create PR: %s", e)
                await self.queue.update_task_status(task.id, TaskStatus.FAILED, {
                    "agent_notes": f"PR creation failed: {e}",
                    "cost": result.cost,
                })
                await self.notifier.notify_failed(task, f"PR creation failed: {e}", thread_ts=thread_ts)
                await self.notifier.update_parent_status(
                    thread_channel, thread_ts, task, "failed", f"PR creation failed",
                )
                self.state.mark_failed(task.id)

        elif result.status == ResultStatus.BLOCKED:
            # Create a draft PR so the developer can review the plan/proposal
            pr_url = ""
            try:
                pr_url = await self.worker.create_blocked_pr(task, result, repo_path, repo_config)
            except RuntimeError as e:
                logger.warning("Could not create draft PR for blocked task: %s", e)

            slack_channel, slack_thread_ts = await self.notifier.notify_blocked(
                task, result.question, thread_ts=thread_ts,
            )
            # Use the task's parent thread for reply monitoring (not the blocked message's own ts)
            monitor_channel = thread_channel or slack_channel
            monitor_ts = thread_ts or slack_thread_ts
            blocked_metadata = {
                "blocked_reason": result.question,
                "agent_notes": agent_notes or "Blocked — see question.",
                "cost": result.cost,
                "slack_thread_ts": monitor_ts,
                "slack_channel": monitor_channel,
            }
            if pr_url:
                blocked_metadata["agent_pr"] = pr_url
            await self.queue.update_task_status(task.id, TaskStatus.BLOCKED, blocked_metadata)
            await self.notifier.update_parent_status(
                thread_channel, thread_ts, task, "blocked", f"Question: {result.question}",
            )
            self.state.mark_blocked(
                task.id, result.question, result.branch_name,
                slack_thread_ts=monitor_ts,
                slack_channel=monitor_channel,
            )

        elif result.status == ResultStatus.FAILED:
            failed_notes = result.error or ""
            if result.handoff_notes:
                failed_notes = f"{failed_notes}\n\n---\n\n{result.handoff_notes}" if failed_notes else result.handoff_notes
            await self.queue.update_task_status(task.id, TaskStatus.FAILED, {
                "agent_notes": failed_notes,
                "cost": result.cost,
            })
            await self.notifier.notify_failed(task, result.error, thread_ts=thread_ts)
            await self.notifier.update_parent_status(
                thread_channel, thread_ts, task, "failed", str(result.error)[:200],
            )
            self.state.mark_failed(task.id)

        self.state.save()

    async def _check_blocked_replies(self) -> None:
        """Poll Slack threads for replies on blocked tasks, re-queue any that get answered."""
        for task_id, info in list(self.state.blocked_tasks.items()):
            if not info.slack_thread_ts or not info.slack_channel:
                continue

            reply = await self.notifier.check_thread_reply(info.slack_channel, info.slack_thread_ts)
            if reply:
                logger.info(
                    "Got Slack reply for blocked task %s: %s",
                    task_id[:8], reply[:100],
                )
                # Acknowledge in the thread
                await self.notifier.reply_in_thread(
                    info.slack_channel, info.slack_thread_ts,
                    "Got it, re-queuing this task now."
                )
                # Re-queue the task in Notion so it gets picked up
                await self.queue.update_task_status(task_id, TaskStatus.QUEUED, {
                    "agent_notes": f"Unblocked via Slack reply: {reply[:200]}",
                })
                # Update the blocked info with the answer so it's available when we pick it up
                info.question = f"{info.question}\n\nDeveloper replied: {reply}"
                self.state.save()

    async def _restore_blocked_tasks(self) -> None:
        """Restore blocked task thread info from Notion into state.

        This ensures thread reply monitoring works even after a state reset,
        since the Slack thread info is persisted in Notion columns.
        """
        try:
            blocked_tasks = await self.queue.fetch_blocked_tasks()
        except Exception:
            logger.warning("Could not fetch blocked tasks from Notion, skipping restore.")
            return

        restored = 0
        for task in blocked_tasks:
            if task.id in self.state.blocked_tasks:
                # Already tracked — but update thread info if state is missing it
                info = self.state.blocked_tasks[task.id]
                if not info.slack_thread_ts and task.slack_thread_ts:
                    info.slack_thread_ts = task.slack_thread_ts
                    info.slack_channel = task.slack_channel
                    restored += 1
                continue

            # Not in state — restore from Notion if we have thread info
            if task.slack_thread_ts and task.slack_channel:
                self.state.blocked_tasks[task.id] = BlockedInfo(
                    question=task.blocked_reason,
                    blocked_at=task.created_at,
                    branch_name=task.agent_branch,
                    slack_thread_ts=task.slack_thread_ts,
                    slack_channel=task.slack_channel,
                )
                restored += 1

        if restored:
            logger.info("Restored %d blocked task(s) with Slack thread info from Notion.", restored)
            self.state.save()

    def _handle_shutdown(self) -> None:
        """Handle SIGTERM/SIGINT for graceful shutdown."""
        logger.info("Received shutdown signal.")
        self._shutdown = True
