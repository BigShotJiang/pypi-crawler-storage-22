"""Abstract interface for task queue backends."""

from __future__ import annotations

from typing import Protocol

from sweetie.models import Task, TaskStatus


class QueueAdapter(Protocol):
    """Protocol for task queue backends (Notion, Linear, Jira, etc.)."""

    async def fetch_queued_tasks(self) -> list[Task]:
        """Fetch all tasks with 'queued' status, ordered by priority then creation date."""
        ...

    async def claim_task(self, task_id: str) -> bool:
        """Attempt to claim a task (set status to in_progress). Returns True if successful."""
        ...

    async def update_task_status(
        self, task_id: str, status: TaskStatus, metadata: dict | None = None
    ) -> None:
        """Update a task's status and optional metadata fields."""
        ...

    async def get_task(self, task_id: str) -> Task:
        """Fetch a single task by ID."""
        ...

    async def get_unblocked_tasks(self) -> list[Task]:
        """Fetch tasks that were blocked but have been moved back to queued by the developer."""
        ...
