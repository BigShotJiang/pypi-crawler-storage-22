"""Notion implementation of the QueueAdapter."""

from __future__ import annotations

import logging
from datetime import datetime

from notion_client import AsyncClient

from sweetie.config import NotionConfig
from sweetie.models import Task, TaskStatus

logger = logging.getLogger(__name__)

# Maps our internal TaskStatus to the config key used for Notion status values.
_STATUS_KEY_MAP = {
    TaskStatus.QUEUED: "queued",
    TaskStatus.IN_PROGRESS: "in_progress",
    TaskStatus.BLOCKED: "blocked",
    TaskStatus.IN_REVIEW: "in_review",
    TaskStatus.DONE: "done",
    TaskStatus.FAILED: "failed",
}


class NotionQueueAdapter:
    """Task queue backed by a Notion database."""

    def __init__(self, config: NotionConfig) -> None:
        self.config = config
        self.client = AsyncClient(auth=config.api_key)
        self.cols = config.columns
        self.statuses = config.status_values

    def _notion_status(self, status: TaskStatus) -> str:
        """Get the Notion status value string for a TaskStatus."""
        key = _STATUS_KEY_MAP[status]
        return getattr(self.statuses, key)

    def _parse_task(self, page: dict) -> Task:
        """Parse a Notion page into a Task."""
        props = page["properties"]

        def _rich_text(prop_name: str) -> str:
            prop = props.get(prop_name, {})
            rich = prop.get("rich_text", [])
            return rich[0]["plain_text"] if rich else ""

        def _title_text(prop_name: str) -> str:
            prop = props.get(prop_name, {})
            title = prop.get("title", [])
            return title[0]["plain_text"] if title else ""

        def _select(prop_name: str) -> str:
            prop = props.get(prop_name, {})
            sel = prop.get("select")
            return sel["name"] if sel else ""

        def _number(prop_name: str) -> float:
            prop = props.get(prop_name, {})
            return prop.get("number") or 0.0

        def _url(prop_name: str) -> str:
            prop = props.get(prop_name, {})
            return prop.get("url") or ""

        # Map Notion status string back to our enum
        notion_status = _select(self.cols.status)
        status = TaskStatus.QUEUED  # default
        for ts, key in _STATUS_KEY_MAP.items():
            if getattr(self.statuses, key) == notion_status:
                status = ts
                break

        notion_url = page.get("url", "")

        return Task(
            id=page["id"],
            title=_title_text(self.cols.title),
            description=_rich_text(self.cols.description),
            status=status,
            priority=_select(self.cols.priority),
            repo=_rich_text(self.cols.repo),
            agent_branch=_rich_text(self.cols.agent_branch),
            agent_pr=_url(self.cols.agent_pr),
            agent_notes=_rich_text(self.cols.agent_notes),
            blocked_reason=_rich_text(self.cols.blocked_reason),
            cost=_number(self.cols.cost),
            test_command=_rich_text(self.cols.test_command),
            slack_thread_ts=_rich_text(self.cols.slack_thread_ts),
            slack_channel=_rich_text(self.cols.slack_channel),
            notion_url=notion_url,
            created_at=datetime.fromisoformat(page["created_time"].replace("Z", "+00:00")),
        )

    async def fetch_queued_tasks(self) -> list[Task]:
        """Fetch all queued tasks, ordered by priority (highest first) then creation date."""
        status_filter_type = self.cols.status_type  # "status" or "select"
        status_filter = {
            "property": self.cols.status,
            status_filter_type: {"equals": self._notion_status(TaskStatus.QUEUED)},
        }

        # Combine with optional extra filter
        if self.config.filter:
            f = self.config.filter
            extra_filter = {"property": f.column, f.type: {"equals": f.value}}
            query_filter = {"and": [status_filter, extra_filter]}
        else:
            query_filter = status_filter

        response = await self.client.data_sources.query(
            data_source_id=self.config.database_id,
            filter=query_filter,
            sorts=[
                {"property": self.cols.priority, "direction": "ascending"},
                {"timestamp": "created_time", "direction": "ascending"},
            ],
        )

        tasks = [self._parse_task(page) for page in response["results"]]
        tasks = [t for t in tasks if t.title.strip()]

        # Sort by our priority order (P0 first, then P1, then P2, etc.)
        priority_order = {p: i for i, p in enumerate(self.config.priority_values)}
        tasks.sort(key=lambda t: priority_order.get(t.priority, 999))

        logger.info("Found %d queued tasks.", len(tasks))
        return tasks

    async def claim_task(self, task_id: str) -> bool:
        """Set a task's status to In Progress."""
        try:
            await self.update_task_status(task_id, TaskStatus.IN_PROGRESS)
            return True
        except Exception:
            logger.exception("Failed to claim task %s", task_id)
            return False

    async def update_task_status(
        self, task_id: str, status: TaskStatus, metadata: dict | None = None
    ) -> None:
        """Update a task's status and optional metadata in Notion."""
        status_filter_type = self.cols.status_type  # "status" or "select"
        properties: dict = {
            self.cols.status: {status_filter_type: {"name": self._notion_status(status)}},
        }

        if metadata:
            field_map = {
                "agent_branch": (self.cols.agent_branch, "rich_text"),
                "agent_notes": (self.cols.agent_notes, "rich_text"),
                "blocked_reason": (self.cols.blocked_reason, "rich_text"),
                "agent_pr": (self.cols.agent_pr, "url"),
                "cost": (self.cols.cost, "number"),
                "slack_thread_ts": (self.cols.slack_thread_ts, "rich_text"),
                "slack_channel": (self.cols.slack_channel, "rich_text"),
            }
            for key, value in metadata.items():
                if key not in field_map:
                    continue
                col_name, col_type = field_map[key]
                if col_type == "rich_text":
                    properties[col_name] = {
                        "rich_text": [{"text": {"content": str(value)[:2000]}}]
                    }
                elif col_type == "number":
                    properties[col_name] = {"number": float(value) if value else 0}
                elif col_type == "url":
                    properties[col_name] = {"url": str(value) if value else None}

        # Skip fields that don't exist in the database
        try:
            await self.client.pages.update(page_id=task_id, properties=properties)
        except Exception as e:
            # Retry with just the status if optional fields cause errors
            logger.warning("Full update failed (%s), retrying with status only.", e)
            await self.client.pages.update(
                page_id=task_id,
                properties={
                    self.cols.status: {status_filter_type: {"name": self._notion_status(status)}},
                },
            )
        logger.info("Updated task %s → %s", task_id[:8], status.value)

    async def get_task(self, task_id: str) -> Task:
        """Fetch a single task by ID."""
        page = await self.client.pages.retrieve(page_id=task_id)
        return self._parse_task(page)

    async def fetch_blocked_tasks(self) -> list[Task]:
        """Fetch all currently blocked tasks from Notion."""
        status_filter_type = self.cols.status_type
        response = await self.client.data_sources.query(
            data_source_id=self.config.database_id,
            filter={
                "property": self.cols.status,
                status_filter_type: {"equals": self._notion_status(TaskStatus.BLOCKED)},
            },
        )
        tasks = [self._parse_task(page) for page in response["results"]]
        return [t for t in tasks if t.title.strip()]

    async def get_unblocked_tasks(self) -> list[Task]:
        """Fetch tasks that were previously blocked but are now back to queued.

        This catches tasks where the developer manually changed the status
        back to Queued in Notion after answering a question.
        """
        return await self.fetch_queued_tasks()
