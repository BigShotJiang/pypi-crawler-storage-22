"""Local state management with JSON persistence."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

from sweetie.models import BlockedInfo

logger = logging.getLogger(__name__)

def _default_state_path() -> Path:
    """State file lives in ~/.sweetie/ so it's accessible from any directory."""
    state_dir = Path.home() / ".sweetie"
    state_dir.mkdir(exist_ok=True)
    return state_dir / "state.json"


DEFAULT_STATE_PATH = _default_state_path()


@dataclass
class AgentState:
    active_task_id: str | None = None
    blocked_tasks: dict[str, BlockedInfo] = field(default_factory=dict)
    completed_tasks: list[str] = field(default_factory=list)
    task_threads: dict[str, tuple[str, str]] = field(default_factory=dict)  # task_id → (channel, thread_ts)
    total_cost_this_session: float = 0.0
    started_at: datetime = field(default_factory=datetime.now)

    def has_active_task(self) -> bool:
        has_task = self.active_task_id is not None
        if has_task:
            logger.info("Sweetie is already working on task %s", self.active_task_id)
        return has_task

    def mark_blocked(
        self,
        task_id: str,
        question: str,
        branch_name: str,
        slack_thread_ts: str = "",
        slack_channel: str = "",
    ) -> None:
        self.blocked_tasks[task_id] = BlockedInfo(
            question=question,
            blocked_at=datetime.now(),
            branch_name=branch_name,
            slack_thread_ts=slack_thread_ts,
            slack_channel=slack_channel,
        )
        if self.active_task_id == task_id:
            self.active_task_id = None

    def mark_completed(self, task_id: str) -> None:
        self.completed_tasks.append(task_id)
        if self.active_task_id == task_id:
            self.active_task_id = None
        self.blocked_tasks.pop(task_id, None)

    def mark_failed(self, task_id: str) -> None:
        if self.active_task_id == task_id:
            self.active_task_id = None
        self.blocked_tasks.pop(task_id, None)

    def unblock_task(self, task_id: str) -> None:
        self.blocked_tasks.pop(task_id, None)

    def save(self, path: Path = DEFAULT_STATE_PATH) -> None:
        """Persist state to a JSON file."""
        data = {
            "active_task_id": self.active_task_id,
            "blocked_tasks": {
                tid: {
                    "question": info.question,
                    "blocked_at": info.blocked_at.isoformat(),
                    "branch_name": info.branch_name,
                    "slack_thread_ts": info.slack_thread_ts,
                    "slack_channel": info.slack_channel,
                }
                for tid, info in self.blocked_tasks.items()
            },
            "completed_tasks": self.completed_tasks,
            "task_threads": {tid: list(ts) for tid, ts in self.task_threads.items()},
            "total_cost_this_session": self.total_cost_this_session,
            "started_at": self.started_at.isoformat(),
        }
        path.write_text(json.dumps(data, indent=2))
        logger.debug("State saved to %s", path)

    @classmethod
    def load(cls, path: Path = DEFAULT_STATE_PATH) -> AgentState:
        """Load state from a JSON file, or return fresh state if not found."""
        if not path.exists():
            logger.info("No state file found, starting fresh.")
            return cls()

        try:
            data = json.loads(path.read_text())
            blocked = {}
            for tid, info in data.get("blocked_tasks", {}).items():
                blocked[tid] = BlockedInfo(
                    question=info["question"],
                    blocked_at=datetime.fromisoformat(info["blocked_at"]),
                    branch_name=info["branch_name"],
                    slack_thread_ts=info.get("slack_thread_ts", ""),
                    slack_channel=info.get("slack_channel", ""),
                )
            task_threads = {
                tid: tuple(ts) for tid, ts in data.get("task_threads", {}).items()
            }
            return cls(
                active_task_id=data.get("active_task_id"),
                blocked_tasks=blocked,
                completed_tasks=data.get("completed_tasks", []),
                task_threads=task_threads,
                total_cost_this_session=data.get("total_cost_this_session", 0.0),
                started_at=datetime.fromisoformat(data["started_at"]),
            )
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Failed to load state file (%s), starting fresh.", e)
            return cls()
