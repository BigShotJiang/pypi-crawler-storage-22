"""Worker engine — spawns Claude Code and orchestrates task execution."""

from __future__ import annotations

import asyncio
import logging
import re

from sweetie.config import AgentConfig, RepoConfig, SafetyConfig
from sweetie.models import ResultStatus, Task, WorkerResult
from sweetie.worker import git, prompt, testing

logger = logging.getLogger(__name__)

BLOCKED_PATTERN = re.compile(r"^BLOCKED:\s*(.+)$", re.MULTILINE)
DONE_PATTERN = re.compile(r"^DONE:\s*(.+)$", re.MULTILINE)


DEFAULT_ALLOWED_TOOLS = [
    "Read", "Write", "Edit",
    "Bash", "Glob", "Grep",
    "WebSearch", "WebFetch",
    "NotebookEdit",
]


def build_allowed_tools(repo_config: RepoConfig) -> list[str]:
    """Build the --allowedTools list for Claude Code.

    Returns the repo's configured tools if set, otherwise a broad default
    that covers standard coding tools. This is required for -p (pipe) mode
    since there's no human to approve tool permissions interactively.
    """
    if repo_config.allowed_tools:
        return repo_config.allowed_tools

    return DEFAULT_ALLOWED_TOOLS


def parse_claude_output(output: str) -> WorkerResult:
    """Parse Claude Code's output for DONE/BLOCKED signals."""
    blocked_match = BLOCKED_PATTERN.search(output)
    if blocked_match:
        return WorkerResult(
            status=ResultStatus.BLOCKED,
            question=blocked_match.group(1).strip(),
            output=output,
        )

    done_match = DONE_PATTERN.search(output)
    if done_match:
        return WorkerResult(
            status=ResultStatus.SUCCESS,
            summary=done_match.group(1).strip(),
            output=output,
        )

    # No explicit signal — treat as uncertain (check for commits)
    return WorkerResult(
        status=ResultStatus.UNCERTAIN,
        output=output,
    )


class WorkerEngine:
    """Executes a single task using Claude Code."""

    def __init__(
        self,
        agent_config: AgentConfig,
        safety_config: SafetyConfig,
        github_token: str = "",
    ) -> None:
        self.agent_config = agent_config
        self.safety_config = safety_config
        self.github_token = github_token
        self._active_proc: asyncio.subprocess.Process | None = None

    async def cancel(self) -> None:
        """Kill the active Claude Code subprocess if one is running."""
        if self._active_proc and self._active_proc.returncode is None:
            logger.warning("Terminating Claude Code subprocess (pid %d)...", self._active_proc.pid)
            self._active_proc.terminate()
            try:
                await asyncio.wait_for(self._active_proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                logger.warning("Claude Code didn't exit, killing.")
                self._active_proc.kill()
            self._active_proc = None

    def _get_repo_config(self, task: Task, repos: dict[str, RepoConfig]) -> RepoConfig:
        """Get the repo config for a task, falling back to defaults."""
        repo_path = task.repo
        if repo_path in repos:
            return repos[repo_path]
        return RepoConfig()

    async def execute(
        self,
        task: Task,
        repo_path: str,
        repo_config: RepoConfig,
        blocked_answer: str | None = None,
    ) -> WorkerResult:
        """Execute a task end-to-end: branch, invoke Claude, parse result."""
        branch = task.agent_branch.strip() or git.branch_name(task)
        base_branch = repo_config.base_branch

        # 1. Create or checkout the branch
        try:
            await git.create_branch(repo_path, branch, base_branch)
        except RuntimeError as e:
            return WorkerResult(
                status=ResultStatus.FAILED,
                error=f"Git branch setup failed: {e}",
                branch_name=branch,
            )

        # 2. Read handoff context if resuming
        handoff_context = await git.read_handoff_file(repo_path)

        # 3. Fetch PR feedback if this task already has a PR
        pr_feedback = None
        if task.agent_pr:
            logger.info("Task has existing PR: %s — fetching review comments.", task.agent_pr)
            pr_feedback = git.fetch_pr_comments(task.agent_pr, self.github_token)

        # 4. Build the prompt
        task_prompt = prompt.build_task_prompt(
            task=task,
            repo_path=repo_path,
            base_branch=base_branch,
            branch_name=branch,
            handoff_context=handoff_context,
            blocked_answer=blocked_answer,
            pr_feedback=pr_feedback,
            pre_approved=repo_config.pre_approved or None,
        )

        # 5. Get test command (task-level override or repo config)
        test_command = task.test_command or repo_config.test_command

        # 6. Invoke Claude Code
        result = await self._run_claude(task_prompt, repo_path, repo_config)
        result.branch_name = branch

        # 7. Handle the result
        if result.status == ResultStatus.SUCCESS:
            # Run tests if configured
            if test_command:
                result = await self._run_with_test_retries(
                    result, task, repo_path, repo_config, test_command, branch
                )

        if result.status == ResultStatus.UNCERTAIN:
            # No explicit signal but Claude finished — check if there are commits
            result.status = ResultStatus.SUCCESS
            result.summary = "Task completed (no explicit DONE signal from Claude)."

        # 8. Read the handoff file (before PR creation removes it) to persist as agent notes
        handoff = await git.read_handoff_file(repo_path)
        if handoff:
            result.handoff_notes = handoff

        return result

    async def _run_claude(
        self,
        task_prompt: str,
        repo_path: str,
        repo_config: RepoConfig,
    ) -> WorkerResult:
        """Spawn Claude Code and stream output to terminal in real-time."""
        import json as _json
        import os
        import sys

        cmd = [
            "claude", "-p",
            "--output-format", "stream-json",
            "--verbose",
        ]

        if self.agent_config.model:
            cmd.extend(["--model", self.agent_config.model])
        if self.agent_config.max_turns_per_task:
            cmd.extend(["--max-turns", str(self.agent_config.max_turns_per_task)])

        allowed_tools = build_allowed_tools(repo_config)
        cmd.extend(["--allowedTools", ",".join(allowed_tools)])

        logger.info("Spawning Claude Code (model=%s, max_turns=%s)...",
                     self.agent_config.model or "default",
                     self.agent_config.max_turns_per_task or "default")

        env = os.environ.copy()
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=repo_path,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            limit=10 * 1024 * 1024,  # 10MB line buffer for large stream-json events
        )
        self._active_proc = proc

        # Send the prompt and close stdin
        proc.stdin.write(task_prompt.encode())
        await proc.stdin.drain()
        proc.stdin.close()

        # ANSI escape codes for ephemeral streaming output
        DIM = "\033[2m"
        RESET = "\033[0m"
        CURSOR_UP = "\033[A"
        CLEAR_LINE = "\033[2K"

        # Stream JSON events from Claude Code, printing in dim so it's
        # visually distinct from Sweetie's own logs. After streaming finishes,
        # the dim output is erased and replaced with a compact summary.
        final_text = ""
        all_text_parts = []
        lines_printed = 0
        turn_count = 0
        cost = 0.0

        def _dim_print(text: str) -> None:
            nonlocal lines_printed
            # Count wrapped lines (rough: assume 120-col terminal)
            line_count = max(1, text.count("\n") + 1)
            print(f"{DIM}{text}{RESET}", flush=True)
            lines_printed += line_count

        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            line_str = line.decode().strip()
            if not line_str:
                continue
            try:
                event = _json.loads(line_str)
            except _json.JSONDecodeError:
                continue

            event_type = event.get("type", "")

            # Assistant messages contain content blocks (text + tool_use)
            if event_type == "assistant" and "message" in event:
                turn_count += 1
                for block in event["message"].get("content", []):
                    if block.get("type") == "text":
                        text = block.get("text", "")
                        all_text_parts.append(text)
                        _dim_print(text)
                    elif block.get("type") == "tool_use":
                        tool_name = block.get("name", "")
                        tool_input = block.get("input", {})
                        if tool_name == "Bash":
                            cmd_text = tool_input.get("command", "")
                            _dim_print(f"  > [{tool_name}] {cmd_text}")
                        elif tool_name in ("Read", "Glob", "Grep"):
                            target = tool_input.get("file_path", tool_input.get("pattern", ""))
                            _dim_print(f"  > [{tool_name}] {target}")
                        elif tool_name in ("Write", "Edit"):
                            target = tool_input.get("file_path", "")
                            _dim_print(f"  > [{tool_name}] {target}")
                        else:
                            _dim_print(f"  > [{tool_name}]")

            # Capture the final result
            elif event_type == "result":
                final_text = event.get("result", "")
                cost = event.get("total_cost_usd", 0.0)
                if final_text:
                    all_text_parts.append(final_text)

        # Erase the ephemeral streaming output
        for _ in range(lines_printed):
            sys.stdout.write(f"{CURSOR_UP}{CLEAR_LINE}")
        sys.stdout.flush()

        # Wait for process to finish
        stderr_bytes = await proc.stderr.read()
        await proc.wait()
        self._active_proc = None

        output = final_text or "\n".join(all_text_parts)
        stderr_text = stderr_bytes.decode()

        if proc.returncode != 0 and not output.strip():
            error_msg = stderr_text.strip() or f"Claude Code exited with code {proc.returncode}"
            logger.error("Claude Code failed: %s", error_msg)
            return WorkerResult(
                status=ResultStatus.FAILED,
                error=error_msg,
                output=output,
            )

        logger.info("Claude Code finished (exit code %d, %d turns, $%.4f).",
                     proc.returncode, turn_count, cost)
        result = parse_claude_output(output)
        result.cost = cost
        return result

    async def _run_with_test_retries(
        self,
        initial_result: WorkerResult,
        task: Task,
        repo_path: str,
        repo_config: RepoConfig,
        test_command: str,
        branch: str,
    ) -> WorkerResult:
        """Run tests and retry with Claude if they fail."""
        max_retries = self.agent_config.max_retries_on_test_fail

        for attempt in range(1, max_retries + 2):  # +1 for the initial run, +1 for range
            test_result = await testing.run_tests(repo_path, test_command)

            if test_result.passed:
                initial_result.output += f"\n\nTest output:\n{test_result.output}"
                return initial_result

            if attempt > max_retries:
                return WorkerResult(
                    status=ResultStatus.FAILED,
                    error=f"Tests failed after {max_retries} retries.",
                    output=test_result.output,
                    branch_name=branch,
                )

            logger.warning("Tests failed (attempt %d/%d), retrying with test output...",
                           attempt, max_retries + 1)

            # Re-invoke Claude with the test failure output
            retry_prompt = (
                f"The tests failed. Here is the test output:\n\n"
                f"```\n{test_result.output[-3000:]}\n```\n\n"
                f"Please fix the failing tests and try again. "
                f"When done, output: DONE: <summary>"
            )

            result = await self._run_claude(retry_prompt, repo_path, repo_config)
            result.branch_name = branch
            initial_result = result

            if result.status == ResultStatus.FAILED:
                return result

        return initial_result

    async def create_pr(
        self,
        task: Task,
        result: WorkerResult,
        repo_path: str,
        repo_config: RepoConfig,
    ) -> str:
        """Clean up handoff file and create a PR."""
        await git.remove_handoff_file(repo_path)

        test_output = ""
        test_command = task.test_command or repo_config.test_command
        if test_command:
            test_result = await testing.run_tests(repo_path, test_command)
            test_output = f"```\n$ {test_command}\n{test_result.output}\n```"

        return await git.create_pr(
            repo_path=repo_path,
            branch=result.branch_name,
            base_branch=repo_config.base_branch,
            task=task,
            summary=result.summary,
            test_output=test_output,
            github_token=self.github_token,
        )

    async def create_blocked_pr(
        self,
        task: Task,
        result: WorkerResult,
        repo_path: str,
        repo_config: RepoConfig,
    ) -> str:
        """Create a draft PR for a blocked task (plan/proposal). Keeps handoff file, skips tests."""
        return await git.create_pr(
            repo_path=repo_path,
            branch=result.branch_name,
            base_branch=repo_config.base_branch,
            task=task,
            summary=result.question,
            github_token=self.github_token,
            draft=True,
        )
