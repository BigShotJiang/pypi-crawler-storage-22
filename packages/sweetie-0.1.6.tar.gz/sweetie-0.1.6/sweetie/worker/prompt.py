"""Prompt construction for Claude Code invocations."""

from __future__ import annotations

from sweetie.models import Task


def _build_pre_approved_section(pre_approved: list[str] | None) -> str:
    """Build the pre-approved actions section for the prompt."""
    if not pre_approved:
        return ""
    items = "\n".join(f"- {action}" for action in pre_approved)
    return (
        "\n\nThe following actions have been pre-approved by the developer. "
        "You do NOT need to use BLOCKED to ask permission for these:\n"
        f"{items}"
    )


def build_task_prompt(
    task: Task,
    repo_path: str,
    base_branch: str,
    branch_name: str,
    handoff_context: str | None = None,
    blocked_answer: str | None = None,
    pr_feedback: str | None = None,
    pre_approved: list[str] | None = None,
) -> str:
    """Build the full prompt to send to Claude Code for a task."""
    resume_section = "This is a fresh task."
    if pr_feedback:
        resume_section = (
            "This task was previously completed and a PR was created, but the developer "
            "has re-queued it with feedback. Address all the review comments below, then "
            "commit your changes.\n\n"
            f"{pr_feedback}"
        )
    elif blocked_answer:
        resume_section = (
            f"This task was previously blocked. The developer answered your question:\n\n"
            f"**Your question:** {task.blocked_reason}\n"
            f"**Developer's answer:** {blocked_answer}\n\n"
            f"Continue from where you left off."
        )

    prior_context = "No prior context — this is a fresh start."
    if handoff_context:
        prior_context = handoff_context

    return f"""# Task: {task.title}

## Description
{task.description}

## Repository
You are working in: {repo_path}
Base branch: {base_branch}
Your branch: {branch_name}

## Instructions
1. Read the codebase to understand the existing patterns and architecture.
2. **Planning vs implementing:** Use your judgment on complexity.
   - If the task description explicitly asks for a plan, design doc, or review before implementing,
     you MUST write a plan and use BLOCKED to present it to the developer. Do NOT implement anything yet.
   - For complex tasks (large refactors, new systems, architectural changes), write a plan first
     and use BLOCKED to get developer approval before implementing.
   - For straightforward tasks (bug fixes, small features, simple changes), go ahead and implement directly.
3. Implement the task described above (unless you are presenting a plan first).
4. Follow the conventions in CLAUDE.md if one exists.
5. Write clean, minimal code — do not over-engineer.
6. Do not add features beyond what is described.
7. If you are unsure about something, require clarification, information, access, or a decision from the developer, or you were instructed to get developer feedback and approval before making changes, move the task to the Blocked state. (see "If you are blocked" section below)
8. **IMPORTANT: When you are done making changes, you MUST commit AND push them.**
   - Stage all changed files: `git add <files>`
   - Commit with a clear message: `git commit -m "<descriptive message>"`
   - Push to remote: `git push origin {branch_name}`
   - Do NOT skip this step. Your changes will be lost if you don't commit and push.

## When you are done
When you have completed the implementation, output on its own line:
DONE: <one-line summary of what you did>

## If you are blocked
If you cannot complete this task because you need clarification,
information, access, or a decision from the developer, output on its own line:
BLOCKED: <your specific question>

Do NOT guess on ambiguous requirements. Ask.

## Permissions
You are running autonomously — there is no human at the terminal to approve actions.
You MUST use BLOCKED to ask the developer for permission before:
- Installing or removing packages/dependencies (npm install, pip install, etc.)
- Modifying CI/CD config, deployment scripts, or infrastructure
- Changing database schemas or running migrations
- Any other potentially destructive or irreversible action

The developer will be notified on Slack and can reply to approve.
{_build_pre_approved_section(pre_approved)}

## If resuming a previously blocked task
{resume_section}

## Prior context from previous session
{prior_context}

## Before you finish (ALWAYS do this)
Before outputting DONE or BLOCKED, write a handoff file at `.agent-queue/handoff.md` that includes:
- **Completed:** What you implemented or changed so far
- **Remaining:** What still needs to be done (if anything)
- **Decisions:** Key decisions you made and why
- **Context:** File paths, patterns, or other info useful for the next session
Then commit and push it:
```
git add .agent-queue/handoff.md && git commit -m "agent: update handoff context" && git push origin {branch_name}
```
"""
