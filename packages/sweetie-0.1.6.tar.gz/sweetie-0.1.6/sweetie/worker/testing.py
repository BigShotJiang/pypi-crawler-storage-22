"""Test and lint runner for validating agent output."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class TestResult:
    passed: bool
    output: str


async def run_tests(repo_path: str, test_command: str) -> TestResult:
    """Run the test command and return the result."""
    if not test_command:
        return TestResult(passed=True, output="")

    logger.info("Running tests: %s", test_command)
    proc = await asyncio.create_subprocess_shell(
        test_command,
        cwd=repo_path,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await proc.communicate()
    output = stdout.decode()
    passed = proc.returncode == 0

    if passed:
        logger.info("Tests passed.")
    else:
        logger.warning("Tests failed (exit code %d).", proc.returncode)

    return TestResult(passed=passed, output=output)


async def run_lint(repo_path: str, lint_command: str) -> TestResult:
    """Run the lint command and return the result."""
    if not lint_command:
        return TestResult(passed=True, output="")

    logger.info("Running lint: %s", lint_command)
    proc = await asyncio.create_subprocess_shell(
        lint_command,
        cwd=repo_path,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await proc.communicate()
    output = stdout.decode()
    passed = proc.returncode == 0

    if passed:
        logger.info("Lint passed.")
    else:
        logger.warning("Lint failed (exit code %d).", proc.returncode)

    return TestResult(passed=passed, output=output)
