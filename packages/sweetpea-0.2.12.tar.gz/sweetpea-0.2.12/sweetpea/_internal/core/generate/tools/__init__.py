"""This module provides access to external tools for use in CNF generation,
solving, and sampling.
"""
