.. _finalize:

Finalize installation
~~~~~~~~~~~~~~~~~~~~~

Finalizing installation varies by distribution.

.. toctree::
   :maxdepth: 1

   finalize-installation-rdo.rst
   finalize-installation-ubuntu-debian.rst
