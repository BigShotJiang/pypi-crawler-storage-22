.. _next-steps:

==========
Next steps
==========

Your OpenStack environment now includes Object Storage.

To add more services, see the
`additional documentation on installing OpenStack <https://docs.openstack.org/latest/install/>`_ .
