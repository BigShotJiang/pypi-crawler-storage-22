"""
SwiftAPI Attested OpenAI - Drop-in replacement.

    # Before (vibe coding):
    from openai import OpenAI
    client = OpenAI(api_key="sk-...")

    # After (attested):
    from swiftapi import OpenAI
    client = OpenAI(swiftapi_key="swiftapi_live_...", openai_key="sk-...")

Same interface. Same return type. Every completion is cryptographically attested.
No attestation, no output. SwiftAPI governs. OpenAI executes. You bring both keys.
"""

import json
import requests
from typing import List, Dict, Optional, Any

from .exceptions import SwiftAPIError, AuthenticationError, NetworkError


class Message:
    """OpenAI-compatible message object."""

    def __init__(self, role: str, content: str):
        self.role = role
        self.content = content

    def __repr__(self):
        truncated = self.content[:80] if self.content else ""
        return f"Message(role='{self.role}', content='{truncated}')"


class Choice:
    """OpenAI-compatible choice object."""

    def __init__(self, index: int, message: Message, finish_reason: str):
        self.index = index
        self.message = message
        self.finish_reason = finish_reason


class ChatCompletion:
    """OpenAI-compatible chat completion response."""

    def __init__(self, content: str, model: str, attested: bool = False, jti: str = None):
        self.choices = [
            Choice(
                index=0,
                message=Message(role="assistant", content=content),
                finish_reason="stop" if content else "void",
            )
        ]
        self.model = model
        self.attested = attested
        self.jti = jti

    @property
    def content(self):
        """Convenience: response.content instead of response.choices[0].message.content"""
        return self.choices[0].message.content


class Completions:
    """Handles chat.completions.create() calls."""

    def __init__(self, swiftapi_key: str, openai_key: str, authority_url: str, timeout: int):
        self._swiftapi_key = swiftapi_key
        self._openai_key = openai_key
        self._authority_url = authority_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()

    def create(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        temperature: float = 0.7,
        max_completion_tokens: int = 300,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> ChatCompletion:
        """
        Create an attested chat completion.

        Same interface as openai.chat.completions.create().
        Step 1: Attest with SwiftAPI (governance).
        Step 2: Call OpenAI directly with your key (execution).

        If governance denies, content is empty string. Void.

        Args:
            model: Model name (e.g. "gpt-4o")
            messages: List of message dicts with role and content
            temperature: Sampling temperature
            max_completion_tokens: Max tokens in response
            max_tokens: Alias for max_completion_tokens (OpenAI compat)

        Returns:
            ChatCompletion with .choices[0].message.content
        """
        effective_max = max_tokens or max_completion_tokens

        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_completion_tokens": effective_max,
        }

        # Step 1: Attest with SwiftAPI — governance check
        try:
            attest_resp = self._session.post(
                f"{self._authority_url}/attest",
                json={"action_type": "chat_completion", "action_data": payload},
                headers={
                    "X-SwiftAPI-Authority": self._swiftapi_key,
                    "Content-Type": "application/json",
                    "User-Agent": "swiftapi-python/1.1.1",
                },
                timeout=self._timeout,
            )
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Attestation request failed: {e}")

        if attest_resp.status_code == 403:
            raise AuthenticationError("Invalid SwiftAPI authority key")
        if attest_resp.status_code == 429:
            raise SwiftAPIError("Rate limit exceeded")
        if attest_resp.status_code != 200:
            raise SwiftAPIError(f"Attestation failed: {attest_resp.text[:200]}")

        attestation = attest_resp.json()

        if not attestation.get("approved"):
            return ChatCompletion(content="", model=model)

        # Step 2: Call OpenAI directly — user's own key, user's own credits
        openai_payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_completion_tokens": effective_max,
        }
        openai_payload.update(kwargs)

        try:
            openai_resp = self._session.post(
                "https://api.openai.com/v1/chat/completions",
                json=openai_payload,
                headers={
                    "Authorization": f"Bearer {self._openai_key}",
                    "Content-Type": "application/json",
                    "User-Agent": "swiftapi-python/1.1.1",
                },
                timeout=self._timeout,
            )
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"OpenAI request failed: {e}")

        if openai_resp.status_code == 401:
            raise AuthenticationError("Invalid OpenAI API key")
        if openai_resp.status_code != 200:
            raise SwiftAPIError(f"OpenAI error: {openai_resp.text[:200]}")

        data = openai_resp.json()
        content = data.get("choices", [{}])[0].get("message", {}).get("content", "")

        return ChatCompletion(
            content=content,
            model=model,
            attested=True,
            jti=attestation.get("jti"),
        )


class _ChatNamespace:
    """Namespace for client.chat.completions"""

    def __init__(self, swiftapi_key: str, openai_key: str, authority_url: str, timeout: int):
        self.completions = Completions(swiftapi_key, openai_key, authority_url, timeout)


class OpenAI:
    """
    Drop-in replacement for openai.OpenAI.

    Every completion is cryptographically attested via SwiftAPI.
    SwiftAPI governs. OpenAI executes. You bring both keys.

    Usage:
        from swiftapi import OpenAI

        client = OpenAI(
            swiftapi_key="swiftapi_live_...",
            openai_key="sk-..."
        )
        r = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}]
        )
        print(r.choices[0].message.content)
    """

    def __init__(
        self,
        swiftapi_key: str = None,
        openai_key: str = None,
        api_key: str = None,
        authority_url: str = "https://swiftapi.ai",
        timeout: int = 60,
        **kwargs,
    ):
        if not swiftapi_key:
            raise AuthenticationError("swiftapi_key is required")
        if not swiftapi_key.startswith("swiftapi_live_"):
            raise AuthenticationError("Invalid key format: must start with 'swiftapi_live_'")

        oai_key = openai_key or api_key
        if not oai_key:
            raise AuthenticationError("openai_key is required (your OpenAI API key)")

        self.chat = _ChatNamespace(swiftapi_key, oai_key, authority_url, timeout)
