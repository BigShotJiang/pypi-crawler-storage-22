Citing SWIFTGalaxy
==================

.. include:: ../../../README.rst
   :start-after: CITING_START_LABEL
   :end-before: CITING_END_LABEL
