Developer guide
===============

.. include:: ../../../README.rst
   :start-after: COMMUNITY_START_LABEL
   :end-before: COMMUNITY_END_LABEL
