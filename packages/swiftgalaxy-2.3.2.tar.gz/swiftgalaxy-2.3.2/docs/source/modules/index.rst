.. API Documentation

API Documentation
=================

.. toctree::
   :maxdepth: 3

   swiftgalaxy




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
