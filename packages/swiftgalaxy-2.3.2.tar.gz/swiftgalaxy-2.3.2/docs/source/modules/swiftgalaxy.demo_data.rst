swiftgalaxy.demo\_data module
=============================

.. automodule:: swiftgalaxy.demo_data
   :members:
   :show-inheritance:
