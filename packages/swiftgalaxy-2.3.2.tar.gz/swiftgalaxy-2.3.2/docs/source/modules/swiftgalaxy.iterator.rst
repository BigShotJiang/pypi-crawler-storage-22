swiftgalaxy.iterator module
===========================

.. automodule:: swiftgalaxy.iterator
   :members:
   :show-inheritance:
   :inherited-members:
