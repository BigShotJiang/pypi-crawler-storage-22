Examples
========

You can view the notebooks by opening them on github, or locally.

The SWIFTGalaxy demo is also available as an `interactive notebook`_ on Colab_.

.. _interactive notebook: https://githubtocolab.com/SWIFTSIM/swiftgalaxy/blob/main/examples/SWIFTGalaxy_demo.ipynb
.. _CoLab: https://colab.google/
