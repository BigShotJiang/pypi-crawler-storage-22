from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

import httpx

from switch_sdk.errors import (
    SwitchAPIError,
    SwitchClientNotStartedError,
    SwitchLocalModelError,
    SwitchNetworkError,
    SwitchTimeoutError,
)
from switch_sdk.local_models import HardwareProfile, LocalModelHandle, LocalModelManager
from switch_sdk.local_runtime import LocalChatRuntime, default_stub_local_runtime, run_local_chat
from switch_sdk.models import (
    CarbonLiveResponse,
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletion,
    ChatMessage,
    ChatUsage,
    DashboardFeedResponse,
    DashboardSummaryResponse,
    RouteDecision,
    RouteRequest,
    TelemetryEvent,
    TelemetryIngestResult,
)
from switch_sdk.telemetry import TelemetryBatcher


class SwitchClient:
    """Async client for the Switch managed gateway."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout_seconds: float = 30.0,
        telemetry_enabled: bool = True,
        telemetry_flush_interval_seconds: float = 2.0,
        telemetry_max_batch_size: int = 20,
        telemetry_max_queue_size: int = 2000,
        max_retries: int = 2,
        retry_backoff_seconds: float = 0.25,
        user_agent: str = 'switch-sdk/0.3.0',
        local_model_manager: LocalModelManager | None = None,
        local_runtime: LocalChatRuntime | None = None,
        local_download_enabled: bool = True,
        local_fallback_to_cloud: bool = True,
        local_cloud_fallback_model: str = 'auto',
        local_task: str = 'chat',
    ) -> None:
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self.telemetry_enabled = telemetry_enabled
        self.telemetry_flush_interval_seconds = telemetry_flush_interval_seconds
        self.telemetry_max_batch_size = telemetry_max_batch_size
        self.telemetry_max_queue_size = telemetry_max_queue_size
        self.max_retries = max_retries
        self.retry_backoff_seconds = retry_backoff_seconds
        self.user_agent = user_agent
        self.local_model_manager = local_model_manager or LocalModelManager()
        self.local_runtime = local_runtime or default_stub_local_runtime
        self.local_download_enabled = local_download_enabled
        self.local_fallback_to_cloud = local_fallback_to_cloud
        self.local_cloud_fallback_model = local_cloud_fallback_model
        self.local_task = local_task

        self._http_client: httpx.AsyncClient | None = None
        self._telemetry_batcher: TelemetryBatcher | None = None

    async def __aenter__(self) -> 'SwitchClient':
        await self.start()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    @classmethod
    def from_env(
        cls,
        *,
        base_url_env: str = 'SHIFT_BASE_URL',
        api_key_env: str = 'SHIFT_API_KEY',
        base_url_fallback_envs: tuple[str, ...] = ('SWITCH_BASE_URL',),
        api_key_fallback_envs: tuple[str, ...] = ('SWITCH_API_KEY', 'API_KEY'),
        **kwargs: Any,
    ) -> 'SwitchClient':
        explicit_base_url = kwargs.pop('base_url', None)
        explicit_api_key = kwargs.pop('api_key', None)

        base_url = explicit_base_url or cls._read_first_env((base_url_env, *base_url_fallback_envs))
        api_key = explicit_api_key or cls._read_first_env((api_key_env, *api_key_fallback_envs))

        missing: list[str] = []
        if not base_url:
            missing.append(f'base URL env vars: {", ".join((base_url_env, *base_url_fallback_envs))}')
        if not api_key:
            missing.append(f'API key env vars: {", ".join((api_key_env, *api_key_fallback_envs))}')
        if missing:
            raise ValueError(
                'SwitchClient.from_env() missing required environment values. '
                + '; '.join(missing)
            )

        return cls(base_url=str(base_url), api_key=str(api_key), **kwargs)

    async def start(self) -> None:
        if self._http_client is not None:
            return

        self._http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.timeout_seconds),
            headers={
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json',
                'User-Agent': self.user_agent,
            },
        )

        if self.telemetry_enabled:
            self._telemetry_batcher = TelemetryBatcher(
                send_batch=self._send_telemetry_batch,
                flush_interval_seconds=self.telemetry_flush_interval_seconds,
                max_batch_size=self.telemetry_max_batch_size,
                max_queue_size=self.telemetry_max_queue_size,
                max_retries=self.max_retries,
                retry_backoff_seconds=self.retry_backoff_seconds,
            )
            await self._telemetry_batcher.start()

    async def close(self) -> None:
        if self._telemetry_batcher:
            await self._telemetry_batcher.stop()
            self._telemetry_batcher = None

        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    async def chat(
        self,
        model: str,
        messages: list[ChatMessage | dict[str, Any]],
        sla: str = 'realtime',
        residency: str = 'ANY',
        capability_flags: dict[str, Any] | None = None,
    ) -> ChatCompletion:
        started = datetime.now(timezone.utc)
        payload = await self._request_json(
            method='POST',
            path='/v1/chat',
            json_payload={
                'model': model,
                'messages': [self._serialize_message(message) for message in messages],
                'sla': sla,
                'residency': residency,
                'capability_flags': capability_flags or {},
            },
        )

        completion = ChatCompletion.from_dict(payload)
        latency_ms = (datetime.now(timezone.utc) - started).total_seconds() * 1000

        await self.track_event(
            TelemetryEvent(
                event_type='sdk_chat_call',
                request_id=completion.id,
                model=completion.model,
                execution_target=self._chat_execution_target(completion),
                latency_ms=latency_ms,
                metadata={
                    'sdk': 'switch-sdk',
                    'route': completion.switch_meta.get('route', {}),
                },
            )
        )

        return completion

    async def chat_hybrid(
        self,
        *,
        messages: list[ChatMessage | dict[str, Any]],
        model: str = 'auto',
        sla: str = 'realtime',
        residency: str = 'ANY',
        capability_flags: dict[str, Any] | None = None,
        prefer_local: bool = True,
        local_task: str | None = None,
        local_allow_download: bool | None = None,
        fallback_to_cloud: bool | None = None,
        fallback_model: str | None = None,
    ) -> ChatCompletion:
        chat_messages = [self._coerce_message(message) for message in messages]
        flags = dict(capability_flags or {})
        allow_download = self.local_download_enabled if local_allow_download is None else local_allow_download
        should_fallback = self.local_fallback_to_cloud if fallback_to_cloud is None else fallback_to_cloud
        resolved_fallback_model = fallback_model or model or self.local_cloud_fallback_model
        active_local_task = local_task or self.local_task

        local_error: str | None = None
        if prefer_local:
            try:
                prepared = await asyncio.to_thread(
                    self._prepare_local_handle,
                    chat_messages,
                    active_local_task,
                    allow_download,
                )
                if prepared:
                    handle, hardware = prepared
                    completion = await self._run_local_chat_completion(messages=chat_messages, handle=handle, hardware=hardware)
                    await self._track_local_event(completion=completion, handle=handle, hardware=hardware)
                    return completion
                local_error = 'no compatible local model for prompt and hardware profile'
            except Exception as exc:
                local_error = str(exc)

        if not should_fallback:
            raise SwitchLocalModelError(local_error or 'Local execution unavailable')

        cloud_flags = dict(flags)
        cloud_flags['force_cloud'] = True
        completion = await self.chat(
            model=resolved_fallback_model,
            messages=messages,
            sla=sla,
            residency=residency,
            capability_flags=cloud_flags,
        )
        if local_error:
            completion.switch_meta.setdefault(
                'local_fallback',
                {
                    'reason': local_error,
                    'fallback_model': resolved_fallback_model,
                    'mode': 'cloud',
                },
            )
        return completion

    async def route(
        self,
        model: str,
        sla: str = 'realtime',
        residency: str = 'ANY',
        capability_flags: dict[str, Any] | None = None,
    ) -> RouteDecision:
        payload = await self._request_json(
            method='POST',
            path='/v1/route',
            json_payload=RouteRequest(
                model=model,
                sla=sla,
                residency=residency,
                capability_flags=capability_flags or {},
            ).to_dict(),
        )
        return RouteDecision.from_dict(payload)

    async def get_dashboard_summary(self, since: datetime | None = None) -> DashboardSummaryResponse:
        params: dict[str, str] = {}
        if since is not None:
            params['since'] = since.isoformat()
        payload = await self._request_json(method='GET', path='/dashboard/summary', params=params)
        return DashboardSummaryResponse.from_dict(payload)

    async def get_dashboard_feed(self, limit: int = 50) -> DashboardFeedResponse:
        payload = await self._request_json(
            method='GET',
            path='/dashboard/feed',
            params={'limit': str(limit)},
        )
        return DashboardFeedResponse.from_dict(payload)

    async def get_live_carbon(self) -> CarbonLiveResponse:
        payload = await self._request_json(method='GET', path='/v1/carbon/live')
        return CarbonLiveResponse.from_dict(payload)

    async def track_event(self, event: TelemetryEvent | dict[str, Any]) -> None:
        if not self.telemetry_enabled:
            return

        if self._telemetry_batcher is None:
            raise SwitchClientNotStartedError('Telemetry batcher is not initialized. Call start() first.')

        payload = event.to_dict() if isinstance(event, TelemetryEvent) else dict(event)
        await self._telemetry_batcher.enqueue(payload)

    async def flush_telemetry(self) -> None:
        if self._telemetry_batcher:
            await self._telemetry_batcher.flush()

    async def _send_telemetry_batch(self, batch: list[dict[str, Any]]) -> None:
        payload = await self._request_json(
            method='POST',
            path='/v1/events',
            json_payload={'events': batch},
        )
        TelemetryIngestResult.from_dict(payload)

    async def _request_json(
        self,
        method: str,
        path: str,
        json_payload: dict[str, Any] | None = None,
        params: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        client = self._require_client()
        retryable_statuses = {408, 409, 425, 429, 500, 502, 503, 504}

        for attempt in range(self.max_retries + 1):
            try:
                response = await client.request(
                    method=method,
                    url=f'{self.base_url}{path}',
                    json=json_payload,
                    params=params,
                )
            except httpx.TimeoutException as exc:
                if attempt < self.max_retries:
                    await self._sleep_backoff(attempt)
                    continue
                raise SwitchTimeoutError(f'Request timed out for {method} {path}') from exc
            except httpx.RequestError as exc:
                if attempt < self.max_retries:
                    await self._sleep_backoff(attempt)
                    continue
                raise SwitchNetworkError(f'Network error for {method} {path}: {exc}') from exc

            if response.status_code in retryable_statuses and attempt < self.max_retries:
                await self._sleep_backoff(attempt)
                continue

            if response.is_error:
                raise self._build_api_error(response)

            try:
                payload = response.json()
            except ValueError as exc:
                raise SwitchAPIError(
                    status_code=response.status_code,
                    detail='Response was not valid JSON',
                    body=response.text,
                    request_id=response.headers.get('x-request-id'),
                ) from exc

            if isinstance(payload, dict):
                return payload

            raise SwitchAPIError(
                status_code=response.status_code,
                detail='Expected JSON object response',
                body=payload,
                request_id=response.headers.get('x-request-id'),
            )

        raise SwitchNetworkError(f'Exceeded retry attempts for {method} {path}')

    def _build_api_error(self, response: httpx.Response) -> SwitchAPIError:
        request_id = response.headers.get('x-request-id')
        try:
            payload = response.json()
        except ValueError:
            payload = response.text

        if isinstance(payload, dict):
            detail = str(payload.get('detail') or payload.get('message') or 'Request failed')
        else:
            detail = str(payload)

        return SwitchAPIError(
            status_code=response.status_code,
            detail=detail,
            body=payload,
            request_id=request_id,
        )

    async def _sleep_backoff(self, attempt: int) -> None:
        await asyncio.sleep(self.retry_backoff_seconds * (2**attempt))

    def _require_client(self) -> httpx.AsyncClient:
        if self._http_client is None:
            raise SwitchClientNotStartedError(
                'SwitchClient is not started. Use `async with SwitchClient(...)` or call `await start()`.'
            )
        return self._http_client

    def _chat_execution_target(self, completion: ChatCompletion) -> str | None:
        route = completion.switch_meta.get('route', {})
        target = route.get('target', {}) if isinstance(route, dict) else {}
        name = target.get('name') if isinstance(target, dict) else None
        return str(name) if name else None

    @staticmethod
    def _read_first_env(names: tuple[str, ...]) -> str | None:
        for name in names:
            value = os.getenv(name, '').strip()
            if value:
                return value
        return None

    def _serialize_message(self, message: ChatMessage | dict[str, Any]) -> dict[str, Any]:
        if isinstance(message, ChatMessage):
            return message.to_dict()
        return {'role': message['role'], 'content': message['content']}

    def _coerce_message(self, message: ChatMessage | dict[str, Any]) -> ChatMessage:
        if isinstance(message, ChatMessage):
            return message
        return ChatMessage(role=message['role'], content=message['content'])

    def _prepare_local_handle(
        self,
        messages: list[ChatMessage],
        task: str,
        allow_download: bool,
    ) -> tuple[LocalModelHandle, HardwareProfile] | None:
        hardware = self.local_model_manager.detect_hardware()
        spec = self.local_model_manager.pick_best_model(messages=messages, task=task, hardware=hardware)
        if spec is None:
            return None
        handle = self.local_model_manager.ensure_model(spec, allow_download=allow_download)
        return handle, hardware

    async def _run_local_chat_completion(
        self,
        *,
        messages: list[ChatMessage],
        handle: LocalModelHandle,
        hardware: HardwareProfile,
    ) -> ChatCompletion:
        started = datetime.now(timezone.utc)
        completion_text = await run_local_chat(self.local_runtime, messages, handle)
        latency_ms = (datetime.now(timezone.utc) - started).total_seconds() * 1000

        prompt_tokens = max(1, sum(len(message.content) for message in messages) // 4)
        completion_tokens = max(1, len(completion_text) // 4)
        usage = ChatUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
        )

        route = {
            'target': {
                'name': f'local-sdk-{handle.spec.model_id}',
                'provider': 'executorch',
                'region': 'LOCAL',
                'mode': 'local',
                'estimated_latency_ms': latency_ms,
                'estimated_cost_usd': 0.0,
                'carbon_intensity_gco2_kwh': 0.0,
            },
            'routing_reason': f'Local SDK selected model {handle.spec.model_id}',
        }
        switch_meta = {
            'source': 'sdk-local',
            'route': route,
            'local_model': handle.to_dict(),
            'hardware': hardware.to_dict(),
            'local_runtime': {
                'name': getattr(self.local_runtime, '__name__', self.local_runtime.__class__.__name__),
                'task': handle.spec.task,
            },
        }

        return ChatCompletion(
            id=f'local-{uuid4().hex}',
            model=handle.spec.model_id,
            created=int(datetime.now(timezone.utc).timestamp()),
            choices=[
                ChatChoice(
                    index=0,
                    message=ChatChoiceMessage(role='assistant', content=completion_text),
                    finish_reason='stop',
                )
            ],
            usage=usage,
            switch_meta=switch_meta,
        )

    async def _track_local_event(
        self,
        *,
        completion: ChatCompletion,
        handle: LocalModelHandle,
        hardware: HardwareProfile,
    ) -> None:
        if not self.telemetry_enabled:
            return

        try:
            await self.track_event(
                TelemetryEvent(
                    event_type='sdk_local_chat',
                    request_id=completion.id,
                    model=handle.spec.model_id,
                    execution_target=f'local-sdk-{handle.spec.model_id}',
                    region='LOCAL',
                    metadata={
                        'sdk': 'switch-sdk',
                        'from_cache': handle.from_cache,
                        'model_path': str(handle.path),
                        'hardware': hardware.to_dict(),
                    },
                )
            )
        except SwitchClientNotStartedError:
            # Keep local execution non-blocking even if telemetry client wasn't started.
            return
