from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from functools import wraps
from typing import Any, AsyncIterator, Awaitable, Callable, TypeVar

from switch_sdk.client import SwitchClient
from switch_sdk.models import TelemetryEvent

F = TypeVar('F', bound=Callable[..., Awaitable[Any]])


@asynccontextmanager
async def switch_trace(
    client: SwitchClient,
    event_type: str,
    request_id: str,
    model: str,
    metadata: dict[str, Any] | None = None,
) -> AsyncIterator[None]:
    started = datetime.now(timezone.utc)
    try:
        yield
    finally:
        latency_ms = (datetime.now(timezone.utc) - started).total_seconds() * 1000
        await client.track_event(
            TelemetryEvent(
                event_type=event_type,
                request_id=request_id,
                model=model,
                latency_ms=latency_ms,
                metadata=metadata or {},
            )
        )


def trace_execution(client: SwitchClient, event_type: str, model: str) -> Callable[[F], F]:
    """Decorator helper for async functions instrumented with Switch telemetry."""

    def decorator(func: F) -> F:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            request_id = f'trace-{int(asyncio.get_event_loop().time() * 1_000_000)}'
            async with switch_trace(client, event_type=event_type, request_id=request_id, model=model):
                return await func(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator
