from __future__ import annotations

from typing import Any


class SwitchSDKError(Exception):
    """Base exception for SDK errors."""


class SwitchClientNotStartedError(SwitchSDKError):
    """Raised when the client is used before being started."""


class SwitchNetworkError(SwitchSDKError):
    """Raised for network and transport-level errors."""


class SwitchTimeoutError(SwitchNetworkError):
    """Raised when requests time out after retries."""


class SwitchLocalModelError(SwitchSDKError):
    """Raised when local model selection/download/load fails."""


class SwitchAPIError(SwitchSDKError):
    """Raised for non-2xx API responses."""

    def __init__(
        self,
        status_code: int,
        detail: str,
        body: Any = None,
        request_id: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.detail = detail
        self.body = body
        self.request_id = request_id
        rid = f' request_id={request_id}' if request_id else ''
        super().__init__(f'Switch API error {status_code}: {detail}{rid}')
