from __future__ import annotations

import importlib
import inspect
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from switch_sdk.errors import SwitchLocalModelError
from switch_sdk.local_models import LocalModelHandle
from switch_sdk.models import ChatMessage


def _last_user_prompt(messages: list[ChatMessage]) -> str:
    for message in reversed(messages):
        if message.role == 'user':
            return message.content.strip()
    if messages:
        return messages[-1].content.strip()
    return ''


def _resolve_model_source(explicit: str | None, handle: LocalModelHandle) -> str:
    if explicit:
        path = Path(explicit).expanduser()
    else:
        path = handle.path

    if path.exists():
        if path.is_dir():
            pte = path / 'model.pte'
            if pte.exists():
                return str(pte)
            return str(path)
        return str(path)
    return str(path)


def _resolve_tokenizer_source(explicit: str | None, model_source: str) -> str:
    if explicit:
        return str(Path(explicit).expanduser())
    model_path = Path(model_source).expanduser()
    if model_path.is_file():
        return str(model_path.parent)
    return str(model_path)


def _trim_prompt_prefix(prompt: str, text: str) -> str:
    if text.startswith(prompt):
        trimmed = text[len(prompt) :].strip()
        return trimmed or text
    return text


@dataclass(slots=True)
class ExecuTorchRuntimeConfig:
    model_source: str | None = None
    tokenizer_source: str | None = None
    prefer_optimum: bool = True
    method_name: str = 'forward'
    max_new_tokens: int = 96
    temperature: float = 0.0
    top_p: float = 1.0


class ExecuTorchTextRuntime:
    """Local runtime that executes .pte using Optimum ExecuTorch or raw ExecuTorch runtime."""

    def __init__(self, config: ExecuTorchRuntimeConfig | None = None) -> None:
        self.config = config or ExecuTorchRuntimeConfig()
        self._optimum_model: Any | None = None
        self._optimum_tokenizer: Any | None = None
        self._optimum_disabled: bool = False
        self._runtime_method: Any | None = None
        self._runtime_method_meta: Any | None = None
        self._runtime_tokenizer: Any | None = None
        self._runtime_model_source: str | None = None

    def __call__(self, messages: list[ChatMessage], handle: LocalModelHandle) -> str:
        prompt = _last_user_prompt(messages)
        if not prompt:
            return 'Local ExecuTorch runtime received an empty prompt.'

        model_source = _resolve_model_source(self.config.model_source, handle)
        tokenizer_source = _resolve_tokenizer_source(self.config.tokenizer_source, model_source)

        optimum_error: Exception | None = None
        if self.config.prefer_optimum and not self._optimum_disabled:
            try:
                return self._run_with_optimum(prompt=prompt, model_source=model_source, tokenizer_source=tokenizer_source)
            except Exception as exc:
                optimum_error = exc
                self._optimum_disabled = True

        try:
            return self._run_with_runtime(prompt=prompt, model_source=model_source, tokenizer_source=tokenizer_source)
        except Exception as runtime_error:
            if optimum_error is not None:
                raise SwitchLocalModelError(
                    f'Optimum path failed ({optimum_error}); runtime path failed ({runtime_error}).'
                ) from runtime_error
            raise SwitchLocalModelError(str(runtime_error)) from runtime_error

    def _run_with_optimum(self, *, prompt: str, model_source: str, tokenizer_source: str) -> str:
        model_cls = self._import_optimum_model_class()
        tokenizer_cls = self._import_transformers_tokenizer()

        if self._optimum_model is None:
            model_root = self._normalize_pretrained_root(model_source)
            try:
                self._optimum_model = model_cls.from_pretrained(model_root, export=False)
            except TypeError:
                self._optimum_model = model_cls.from_pretrained(model_root)
            except Exception as exc:
                raise SwitchLocalModelError(f'Failed loading optimum model from {model_root}: {exc}') from exc

        if self._optimum_tokenizer is None:
            try:
                self._optimum_tokenizer = tokenizer_cls.from_pretrained(self._normalize_pretrained_root(tokenizer_source))
            except Exception as exc:
                raise SwitchLocalModelError(f'Failed loading tokenizer from {tokenizer_source}: {exc}') from exc

        if hasattr(self._optimum_model, 'text_generation'):
            fn = getattr(self._optimum_model, 'text_generation')
            kwargs = self._filter_kwargs(
                fn,
                {
                    'tokenizer': self._optimum_tokenizer,
                    'prompt': prompt,
                    'max_new_tokens': self.config.max_new_tokens,
                    'max_seq_len': self.config.max_new_tokens,
                    'temperature': self.config.temperature,
                    'top_p': self.config.top_p,
                },
            )
            result = fn(**kwargs)
            return str(result)

        if hasattr(self._optimum_model, 'generate'):
            generate_fn = getattr(self._optimum_model, 'generate')
            encoded = self._optimum_tokenizer(prompt, return_tensors='pt')
            output_ids = generate_fn(
                **encoded,
                max_new_tokens=self.config.max_new_tokens,
                temperature=self.config.temperature,
                top_p=self.config.top_p,
                do_sample=self.config.temperature > 0.0,
            )
            if isinstance(output_ids, (list, tuple)):
                output_ids = output_ids[0]
            decoded = self._optimum_tokenizer.decode(output_ids[0], skip_special_tokens=True)
            return _trim_prompt_prefix(prompt, str(decoded))

        raise SwitchLocalModelError('Loaded optimum model has neither text_generation() nor generate().')

    def _run_with_runtime(self, *, prompt: str, model_source: str, tokenizer_source: str) -> str:
        torch = self._import_module('torch')
        tokenizer_cls = self._import_transformers_tokenizer()
        runtime_mod = self._import_module('executorch.runtime')
        runtime_cls = getattr(runtime_mod, 'Runtime', None)
        if runtime_cls is None:
            raise SwitchLocalModelError('executorch.runtime.Runtime not available')

        if self._runtime_tokenizer is None:
            self._runtime_tokenizer = tokenizer_cls.from_pretrained(self._normalize_pretrained_root(tokenizer_source))

        if self._runtime_method is None or self._runtime_model_source != model_source:
            runtime = runtime_cls.get()
            program = runtime.load_program(model_source)
            self._runtime_method = program.load_method(self.config.method_name)
            self._runtime_method_meta = getattr(self._runtime_method, 'metadata', None)
            self._runtime_model_source = model_source

        input_ids = self._runtime_tokenizer(prompt, return_tensors='pt').input_ids
        if len(getattr(input_ids, 'shape', [])) == 1:
            input_ids = input_ids.unsqueeze(0)
        if int(input_ids.shape[0]) != 1:
            raise SwitchLocalModelError(f'Only batch size 1 is supported for local ExecuTorch runtime, got {input_ids.shape}')

        eos_token_id = getattr(self._runtime_tokenizer, 'eos_token_id', None)
        prompt_tokens = [int(token_id) for token_id in input_ids[0].tolist()]
        if not prompt_tokens:
            raise SwitchLocalModelError('Tokenizer produced no tokens for prompt')

        position = 0
        outputs: Any | None = None
        for token_id in prompt_tokens:
            token_tensor = torch.tensor([[token_id]], dtype=torch.long)
            outputs = self._execute_runtime_step(token_tensor=token_tensor, position=position, torch_module=torch)
            position += 1

        all_tokens = list(prompt_tokens)
        for _ in range(max(1, self.config.max_new_tokens)):
            if outputs is None:
                raise SwitchLocalModelError('ExecuTorch runtime did not return outputs during prefill')
            logits = self._extract_logits(outputs)
            next_token = torch.argmax(logits[:, -1, :], dim=-1).unsqueeze(-1)
            next_token_id = int(next_token.item())
            all_tokens.append(next_token_id)
            if eos_token_id is not None and next_token_id == int(eos_token_id):
                break
            token_tensor = torch.tensor([[next_token_id]], dtype=torch.long)
            outputs = self._execute_runtime_step(token_tensor=token_tensor, position=position, torch_module=torch)
            position += 1

        decoded = self._runtime_tokenizer.decode(all_tokens, skip_special_tokens=True)
        return _trim_prompt_prefix(prompt, str(decoded))

    def _execute_runtime_step(self, *, token_tensor: Any, position: int, torch_module: Any) -> Any:
        if self._runtime_method is None:
            raise SwitchLocalModelError('ExecuTorch runtime method is not initialized')

        candidates = self._runtime_input_candidates(token_tensor=token_tensor, position=position, torch_module=torch_module)
        last_error: Exception | None = None
        for candidate in candidates:
            try:
                return self._runtime_method.execute(candidate)
            except Exception as exc:
                last_error = exc
        raise SwitchLocalModelError(f'ExecuTorch step execution failed after {len(candidates)} input attempt(s): {last_error}')

    def _runtime_input_candidates(self, *, token_tensor: Any, position: int, torch_module: Any) -> list[tuple[Any, ...]]:
        num_inputs = self._runtime_num_inputs()
        if num_inputs <= 1:
            return [(token_tensor,)]

        # Primary guess: additional input is token position (common for static-shape decoder exports).
        extra_by_position = [self._build_aux_input(index=index, position=position, torch_module=torch_module) for index in range(1, num_inputs)]
        primary = (token_tensor, *extra_by_position)
        candidates: list[tuple[Any, ...]] = [primary]

        # Fallback attempts for common 2-input signatures.
        if num_inputs == 2:
            candidates.append((token_tensor, torch_module.tensor([[position]], dtype=torch_module.long)))
            candidates.append((token_tensor, torch_module.tensor([position], dtype=torch_module.long)))
            candidates.append((token_tensor, torch_module.ones_like(token_tensor, dtype=torch_module.long)))
        return candidates

    def _runtime_num_inputs(self) -> int:
        meta = self._runtime_method_meta
        if meta is None:
            return 1
        value = getattr(meta, 'num_inputs', None)
        if value is None:
            return 1
        if callable(value):
            try:
                return int(value())
            except Exception:
                return 1
        try:
            return int(value)
        except Exception:
            return 1

    def _build_aux_input(self, *, index: int, position: int, torch_module: Any) -> Any:
        sizes: tuple[int, ...] | None = None
        meta = self._runtime_method_meta
        if meta is not None:
            input_meta_fn = getattr(meta, 'input_tensor_meta', None)
            if callable(input_meta_fn):
                try:
                    info = input_meta_fn(index)
                    size_fn = getattr(info, 'sizes', None)
                    if callable(size_fn):
                        raw_sizes = size_fn()
                        sizes = tuple(int(value) for value in raw_sizes)
                except Exception:
                    sizes = None

        if sizes == (1,):
            return torch_module.tensor([position], dtype=torch_module.long)
        if sizes == (1, 1):
            return torch_module.tensor([[position]], dtype=torch_module.long)
        if sizes and all(dim >= 1 for dim in sizes):
            zeros = torch_module.zeros(sizes, dtype=torch_module.long)
            return zeros
        return torch_module.tensor([position], dtype=torch_module.long)

    def _extract_logits(self, outputs: Any) -> Any:
        # Common runtime output layouts: Tensor, tuple/list[Tensor], dict-like values.
        if hasattr(outputs, 'shape'):
            return outputs
        if isinstance(outputs, (list, tuple)) and outputs:
            first = outputs[0]
            if hasattr(first, 'shape'):
                return first
        if isinstance(outputs, dict):
            for value in outputs.values():
                if hasattr(value, 'shape'):
                    return value
        raise SwitchLocalModelError(f'Unable to extract logits tensor from runtime outputs: {type(outputs)}')

    def _import_optimum_model_class(self) -> Any:
        candidates = [
            ('optimum.executorch', 'ExecuTorchModelForCausalLM'),
            ('optimum.executorchruntime', 'ExecuTorchModelForCausalLM'),
        ]
        last_error: Exception | None = None
        for module_name, class_name in candidates:
            try:
                module = importlib.import_module(module_name)
                cls = getattr(module, class_name, None)
                if cls is not None:
                    return cls
            except Exception as exc:
                last_error = exc
                continue
        message = (
            'Could not import Optimum ExecuTorch model class. Install optimum-executorch, '
            'or set prefer_optimum=False to use raw executorch.runtime.'
        )
        if sys.version_info >= (3, 14):
            message = (
                f'{message} Your Python version is {sys.version_info.major}.{sys.version_info.minor}; '
                'ExecuTorch wheels currently target Python < 3.14.'
            )
        if last_error is not None:
            message = f'{message} Last import error: {last_error}'
        raise SwitchLocalModelError(message)

    def _import_transformers_tokenizer(self) -> Any:
        module = self._import_module('transformers')
        tokenizer_cls = getattr(module, 'AutoTokenizer', None)
        if tokenizer_cls is None:
            raise SwitchLocalModelError('transformers.AutoTokenizer is not available')
        return tokenizer_cls

    def _import_module(self, name: str) -> Any:
        try:
            return importlib.import_module(name)
        except Exception as exc:
            hint = ''
            if name.startswith('executorch') and sys.version_info >= (3, 14):
                hint = (
                    f' (Python {sys.version_info.major}.{sys.version_info.minor} detected; '
                    'use Python 3.10-3.13 for ExecuTorch packages)'
                )
            raise SwitchLocalModelError(f'Missing dependency {name}: {exc}{hint}') from exc

    def _normalize_pretrained_root(self, source: str) -> str:
        path = Path(source).expanduser()
        if path.exists() and path.is_file():
            return str(path.parent)
        return str(path)

    def _filter_kwargs(self, fn: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
        try:
            sig = inspect.signature(fn)
        except (TypeError, ValueError):
            return kwargs
        return {key: value for key, value in kwargs.items() if key in sig.parameters}


def build_executorch_text_runtime(
    *,
    model_source: str | None = None,
    tokenizer_source: str | None = None,
    prefer_optimum: bool = True,
    method_name: str = 'forward',
    max_new_tokens: int = 96,
    temperature: float = 0.0,
    top_p: float = 1.0,
) -> ExecuTorchTextRuntime:
    return ExecuTorchTextRuntime(
        ExecuTorchRuntimeConfig(
            model_source=model_source,
            tokenizer_source=tokenizer_source,
            prefer_optimum=prefer_optimum,
            method_name=method_name,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
        )
    )
