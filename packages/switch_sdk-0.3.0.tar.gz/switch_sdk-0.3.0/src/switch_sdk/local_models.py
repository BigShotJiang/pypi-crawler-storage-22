from __future__ import annotations

import hashlib
import json
import os
import platform
import tempfile
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from switch_sdk.errors import SwitchLocalModelError
from switch_sdk.models import ChatMessage


@dataclass(slots=True)
class HardwareProfile:
    os_name: str
    arch: str
    cpu_count: int
    memory_gb: float

    def to_dict(self) -> dict[str, Any]:
        return {
            'os_name': self.os_name,
            'arch': self.arch,
            'cpu_count': self.cpu_count,
            'memory_gb': self.memory_gb,
        }


@dataclass(slots=True)
class LocalModelSpec:
    model_id: str
    task: str
    download_url: str
    size_mb: float
    min_ram_gb: float
    max_prompt_chars: int
    rank: int
    sha256: str | None = None

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'LocalModelSpec':
        return cls(
            model_id=str(payload['model_id']),
            task=str(payload.get('task', 'chat')),
            download_url=str(payload.get('download_url', '')),
            size_mb=float(payload.get('size_mb', 0.0)),
            min_ram_gb=float(payload.get('min_ram_gb', 0.0)),
            max_prompt_chars=int(payload.get('max_prompt_chars', 1024)),
            rank=int(payload.get('rank', 100)),
            sha256=str(payload['sha256']) if payload.get('sha256') else None,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            'model_id': self.model_id,
            'task': self.task,
            'download_url': self.download_url,
            'size_mb': self.size_mb,
            'min_ram_gb': self.min_ram_gb,
            'max_prompt_chars': self.max_prompt_chars,
            'rank': self.rank,
            'sha256': self.sha256,
        }


@dataclass(slots=True)
class LocalModelHandle:
    spec: LocalModelSpec
    path: Path
    from_cache: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            'model_id': self.spec.model_id,
            'task': self.spec.task,
            'path': str(self.path),
            'from_cache': self.from_cache,
            'size_mb': self.spec.size_mb,
            'min_ram_gb': self.spec.min_ram_gb,
        }


_DEFAULT_MANIFEST: list[dict[str, Any]] = [
    {
        'model_id': 'smollm2-135m',
        'task': 'chat',
        'download_url': '',
        'size_mb': 550.0,
        'min_ram_gb': 4.0,
        'max_prompt_chars': 280,
        'rank': 10,
    },
    {
        'model_id': 'qwen2.5-0.5b-instruct',
        'task': 'chat',
        'download_url': '',
        'size_mb': 1100.0,
        'min_ram_gb': 8.0,
        'max_prompt_chars': 900,
        'rank': 20,
    },
]


class LocalModelManager:
    def __init__(
        self,
        *,
        cache_dir: str | Path | None = None,
        max_cache_gb: float = 4.0,
        manifest: list[dict[str, Any]] | None = None,
        manifest_path: str | Path | None = None,
        manifest_url: str | None = None,
        lock_timeout_seconds: float = 90.0,
        download_timeout_seconds: float = 300.0,
    ) -> None:
        self.cache_dir = Path(cache_dir or Path.home() / '.shift' / 'models')
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.max_cache_bytes = max(0, int(max_cache_gb * 1024 * 1024 * 1024))
        self.lock_timeout_seconds = lock_timeout_seconds
        self.download_timeout_seconds = download_timeout_seconds
        self._manifest = self._load_manifest(
            manifest=manifest,
            manifest_path=manifest_path,
            manifest_url=manifest_url,
        )

    @property
    def manifest(self) -> list[LocalModelSpec]:
        return list(self._manifest)

    def detect_hardware(self) -> HardwareProfile:
        cpu_count = os.cpu_count() or 1
        return HardwareProfile(
            os_name=platform.system().lower(),
            arch=platform.machine().lower(),
            cpu_count=cpu_count,
            memory_gb=self._detect_memory_gb(),
        )

    def pick_best_model(
        self,
        *,
        messages: list[ChatMessage],
        task: str = 'chat',
        hardware: HardwareProfile | None = None,
    ) -> LocalModelSpec | None:
        prompt = self._extract_prompt(messages)
        prompt_chars = len(prompt.strip())
        profile = hardware or self.detect_hardware()

        candidates = [spec for spec in self._manifest if spec.task == task and profile.memory_gb >= spec.min_ram_gb]
        if not candidates:
            return None

        fitting = [spec for spec in candidates if prompt_chars <= spec.max_prompt_chars]
        if fitting:
            return sorted(fitting, key=lambda spec: (spec.rank, spec.size_mb))[0]
        return sorted(candidates, key=lambda spec: (spec.rank, spec.size_mb))[-1]

    def ensure_model(
        self,
        spec: LocalModelSpec,
        *,
        allow_download: bool = True,
    ) -> LocalModelHandle:
        model_path = self._model_path(spec)
        lock_path = model_path.parent / '.download.lock'
        model_path.parent.mkdir(parents=True, exist_ok=True)

        with self._lock(lock_path):
            if model_path.exists():
                self._touch(model_path)
                if spec.sha256 and self._sha256(model_path) != spec.sha256:
                    raise SwitchLocalModelError(f'Cached model checksum mismatch for {spec.model_id}')
                return LocalModelHandle(spec=spec, path=model_path, from_cache=True)

            if not allow_download:
                raise SwitchLocalModelError(f'Model {spec.model_id} is not cached and downloads are disabled')

            if not spec.download_url:
                raise SwitchLocalModelError(
                    f'Model {spec.model_id} has no download URL configured. '
                    'Provide a manifest entry with download_url and sha256.'
                )

            tmp_file = Path(tempfile.mkstemp(prefix='shift-model-', suffix='.pte')[1])
            try:
                self._download(spec.download_url, tmp_file)
                if spec.sha256 and self._sha256(tmp_file) != spec.sha256:
                    raise SwitchLocalModelError(f'Downloaded checksum mismatch for {spec.model_id}')
                model_path.parent.mkdir(parents=True, exist_ok=True)
                os.replace(tmp_file, model_path)
                self._touch(model_path)
                self._evict_if_needed(protected={model_path})
                return LocalModelHandle(spec=spec, path=model_path, from_cache=False)
            finally:
                if tmp_file.exists():
                    tmp_file.unlink(missing_ok=True)

    def _load_manifest(
        self,
        *,
        manifest: list[dict[str, Any]] | None,
        manifest_path: str | Path | None,
        manifest_url: str | None,
    ) -> list[LocalModelSpec]:
        raw_manifest: list[dict[str, Any]]
        if manifest is not None:
            raw_manifest = manifest
        elif manifest_path:
            raw_manifest = json.loads(Path(manifest_path).read_text(encoding='utf-8'))
        elif manifest_url:
            with httpx.Client(timeout=self.download_timeout_seconds) as client:
                response = client.get(manifest_url)
                response.raise_for_status()
                data = response.json()
            if not isinstance(data, list):
                raise SwitchLocalModelError('Manifest URL must return a JSON array')
            raw_manifest = data
        else:
            raw_manifest = _DEFAULT_MANIFEST

        specs = [LocalModelSpec.from_dict(item) for item in raw_manifest]
        specs.sort(key=lambda spec: (spec.rank, spec.size_mb))
        return specs

    def _model_path(self, spec: LocalModelSpec) -> Path:
        version = (spec.sha256 or 'unversioned')[:12]
        return self.cache_dir / spec.model_id / version / 'model.pte'

    @contextmanager
    def _lock(self, lock_path: Path):
        start = time.time()
        fd: int | None = None
        while True:
            try:
                fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode('utf-8'))
                os.close(fd)
                fd = None
                break
            except FileExistsError:
                if time.time() - start > self.lock_timeout_seconds:
                    raise SwitchLocalModelError(f'Timed out waiting for model lock {lock_path}')
                time.sleep(0.2)
            finally:
                if fd is not None:
                    os.close(fd)
                    fd = None

        try:
            yield
        finally:
            lock_path.unlink(missing_ok=True)

    def _download(self, url: str, target_path: Path) -> None:
        with httpx.Client(timeout=self.download_timeout_seconds, follow_redirects=True) as client:
            with client.stream('GET', url) as response:
                response.raise_for_status()
                with target_path.open('wb') as f:
                    for chunk in response.iter_bytes():
                        if chunk:
                            f.write(chunk)

    def _evict_if_needed(self, *, protected: set[Path]) -> None:
        if self.max_cache_bytes <= 0:
            return
        files = [path for path in self.cache_dir.rglob('model.pte') if path.is_file()]
        total = sum(path.stat().st_size for path in files)
        if total <= self.max_cache_bytes:
            return

        # Evict oldest access-time files first, excluding newly downloaded/protected files.
        evictable = [path for path in files if path not in protected]
        evictable.sort(key=lambda path: path.stat().st_atime)

        for path in evictable:
            if total <= self.max_cache_bytes:
                break
            size = path.stat().st_size
            path.unlink(missing_ok=True)
            total -= size
            self._prune_empty_parents(path.parent)

    def _prune_empty_parents(self, directory: Path) -> None:
        current = directory
        while current != self.cache_dir and current.exists():
            try:
                current.rmdir()
            except OSError:
                return
            current = current.parent

    def _touch(self, path: Path) -> None:
        now = time.time()
        os.utime(path, (now, now))

    def _detect_memory_gb(self) -> float:
        # macOS and Linux
        if hasattr(os, 'sysconf'):
            page_size = os.sysconf_names.get('SC_PAGE_SIZE')
            phys_pages = os.sysconf_names.get('SC_PHYS_PAGES')
            if page_size is not None and phys_pages is not None:
                try:
                    total_bytes = int(os.sysconf('SC_PAGE_SIZE')) * int(os.sysconf('SC_PHYS_PAGES'))
                    return round(total_bytes / (1024**3), 2)
                except (ValueError, OSError):
                    pass

        # Windows fallback
        if hasattr(os, 'environ') and os.environ.get('COMPUTERNAME'):
            try:
                import ctypes

                class MEMORYSTATUSEX(ctypes.Structure):
                    _fields_ = [
                        ('dwLength', ctypes.c_ulong),
                        ('dwMemoryLoad', ctypes.c_ulong),
                        ('ullTotalPhys', ctypes.c_ulonglong),
                        ('ullAvailPhys', ctypes.c_ulonglong),
                        ('ullTotalPageFile', ctypes.c_ulonglong),
                        ('ullAvailPageFile', ctypes.c_ulonglong),
                        ('ullTotalVirtual', ctypes.c_ulonglong),
                        ('ullAvailVirtual', ctypes.c_ulonglong),
                        ('ullAvailExtendedVirtual', ctypes.c_ulonglong),
                    ]

                stat = MEMORYSTATUSEX()
                stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
                return round(float(stat.ullTotalPhys) / (1024**3), 2)
            except Exception:
                pass

        # Conservative fallback if detection fails.
        return 4.0

    def _extract_prompt(self, messages: list[ChatMessage]) -> str:
        for message in reversed(messages):
            if message.role == 'user':
                return message.content
        if messages:
            return messages[-1].content
        return ''

    def _sha256(self, file_path: Path) -> str:
        digest = hashlib.sha256()
        with file_path.open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                digest.update(chunk)
        return digest.hexdigest()
