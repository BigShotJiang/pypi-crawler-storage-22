from __future__ import annotations

import inspect
from typing import Awaitable, Callable

from switch_sdk.local_models import LocalModelHandle
from switch_sdk.models import ChatMessage

LocalChatRuntime = Callable[[list[ChatMessage], LocalModelHandle], str | Awaitable[str]]


async def run_local_chat(runtime: LocalChatRuntime, messages: list[ChatMessage], handle: LocalModelHandle) -> str:
    value = runtime(messages, handle)
    if inspect.isawaitable(value):
        result = await value
    else:
        result = value
    return str(result)


def default_stub_local_runtime(messages: list[ChatMessage], handle: LocalModelHandle) -> str:
    text = ''
    for message in reversed(messages):
        if message.role == 'user':
            text = message.content.strip()
            break
    lowered = text.lower()
    if lowered.startswith('reply exactly:'):
        return text.split(':', 1)[1].strip()
    if lowered.startswith('reply with:'):
        return text.split(':', 1)[1].strip()
    if lowered in {'hi', 'hello', 'hey'}:
        return 'Hello from local runtime.'
    return f"Local runtime ({handle.spec.model_id}) completed your request."
