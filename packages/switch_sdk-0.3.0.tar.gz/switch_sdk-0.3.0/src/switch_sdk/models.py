from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal

SLA = Literal['realtime', 'flexible']
Residency = Literal['EU', 'US', 'ANY']
TargetMode = Literal['local', 'green-cloud', 'default-cloud']
MessageRole = Literal['system', 'user', 'assistant', 'tool']


def _parse_datetime(value: str | datetime) -> datetime:
    if isinstance(value, datetime):
        return value
    if value.endswith('Z'):
        return datetime.fromisoformat(value[:-1] + '+00:00')
    return datetime.fromisoformat(value)


@dataclass(slots=True)
class ChatMessage:
    role: MessageRole
    content: str

    def to_dict(self) -> dict[str, Any]:
        return {'role': self.role, 'content': self.content}


@dataclass(slots=True)
class ChatRequest:
    model: str
    messages: list[ChatMessage]
    sla: SLA = 'realtime'
    residency: Residency = 'ANY'
    capability_flags: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            'model': self.model,
            'messages': [message.to_dict() for message in self.messages],
            'sla': self.sla,
            'residency': self.residency,
            'capability_flags': self.capability_flags,
        }


@dataclass(slots=True)
class ChatUsage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'ChatUsage':
        return cls(
            prompt_tokens=int(payload['prompt_tokens']),
            completion_tokens=int(payload['completion_tokens']),
            total_tokens=int(payload['total_tokens']),
        )


@dataclass(slots=True)
class ChatChoiceMessage:
    role: Literal['assistant']
    content: str

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'ChatChoiceMessage':
        return cls(role='assistant', content=str(payload.get('content', '')))


@dataclass(slots=True)
class ChatChoice:
    index: int
    message: ChatChoiceMessage
    finish_reason: str = 'stop'

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'ChatChoice':
        return cls(
            index=int(payload.get('index', 0)),
            message=ChatChoiceMessage.from_dict(payload.get('message', {})),
            finish_reason=str(payload.get('finish_reason', 'stop')),
        )


@dataclass(slots=True)
class ChatCompletion:
    id: str
    model: str
    created: int
    choices: list[ChatChoice]
    usage: ChatUsage
    object: str = 'chat.completion'
    switch_meta: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'ChatCompletion':
        choices = [ChatChoice.from_dict(choice) for choice in payload.get('choices', [])]
        return cls(
            id=str(payload['id']),
            model=str(payload['model']),
            created=int(payload['created']),
            object=str(payload.get('object', 'chat.completion')),
            choices=choices,
            usage=ChatUsage.from_dict(payload.get('usage', {})),
            switch_meta=dict(payload.get('switch_meta', {})),
        )


@dataclass(slots=True)
class RouteRequest:
    model: str
    residency: Residency = 'ANY'
    sla: SLA = 'realtime'
    capability_flags: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            'model': self.model,
            'residency': self.residency,
            'sla': self.sla,
            'capability_flags': self.capability_flags,
        }


@dataclass(slots=True)
class RoutingWeights:
    carbon: float
    latency: float
    cost: float

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'RoutingWeights':
        return cls(
            carbon=float(payload.get('carbon', 0.6)),
            latency=float(payload.get('latency', 0.2)),
            cost=float(payload.get('cost', 0.2)),
        )


@dataclass(slots=True)
class RouteTarget:
    name: str
    provider: str
    region: str
    mode: TargetMode
    estimated_latency_ms: float
    estimated_cost_usd: float
    carbon_intensity_gco2_kwh: float

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'RouteTarget':
        return cls(
            name=str(payload['name']),
            provider=str(payload['provider']),
            region=str(payload['region']),
            mode=str(payload['mode']),
            estimated_latency_ms=float(payload['estimated_latency_ms']),
            estimated_cost_usd=float(payload['estimated_cost_usd']),
            carbon_intensity_gco2_kwh=float(payload['carbon_intensity_gco2_kwh']),
        )


@dataclass(slots=True)
class CandidateScoreBreakdown:
    carbon_intensity_gco2_kwh: float
    latency_ms: float
    cost_usd: float
    normalized_carbon: float
    normalized_latency: float
    normalized_cost: float
    weighted_score: float

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'CandidateScoreBreakdown':
        return cls(
            carbon_intensity_gco2_kwh=float(payload.get('carbon_intensity_gco2_kwh', 0.0)),
            latency_ms=float(payload.get('latency_ms', 0.0)),
            cost_usd=float(payload.get('cost_usd', 0.0)),
            normalized_carbon=float(payload.get('normalized_carbon', 0.0)),
            normalized_latency=float(payload.get('normalized_latency', 0.0)),
            normalized_cost=float(payload.get('normalized_cost', 0.0)),
            weighted_score=float(payload.get('weighted_score', 0.0)),
        )


@dataclass(slots=True)
class RouteDecision:
    target: RouteTarget
    routing_reason: str
    carbon_intensity: dict[str, float]
    scores: dict[str, float]
    weights: RoutingWeights
    candidate_breakdown: dict[str, CandidateScoreBreakdown]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'RouteDecision':
        raw_breakdown = payload.get('candidate_breakdown', {})
        return cls(
            target=RouteTarget.from_dict(payload.get('target', {})),
            routing_reason=str(payload.get('routing_reason', '')),
            carbon_intensity={k: float(v) for k, v in payload.get('carbon_intensity', {}).items()},
            scores={k: float(v) for k, v in payload.get('scores', {}).items()},
            weights=RoutingWeights.from_dict(payload.get('weights', {})),
            candidate_breakdown={
                key: CandidateScoreBreakdown.from_dict(value)
                for key, value in raw_breakdown.items()
            },
        )


@dataclass(slots=True)
class TelemetryEvent:
    event_type: str
    request_id: str
    model: str | None = None
    execution_target: str | None = None
    co2_grams: float = 0.0
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    region: str | None = None
    routing_reason: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            'event_type': self.event_type,
            'request_id': self.request_id,
            'model': self.model,
            'execution_target': self.execution_target,
            'co2_grams': self.co2_grams,
            'latency_ms': self.latency_ms,
            'cost_usd': self.cost_usd,
            'region': self.region,
            'routing_reason': self.routing_reason,
            'metadata': self.metadata,
        }
        if self.created_at is not None:
            payload['created_at'] = self.created_at.isoformat()
        return payload


@dataclass(slots=True)
class TelemetryIngestResult:
    accepted: int

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'TelemetryIngestResult':
        return cls(accepted=int(payload.get('accepted', 0)))


@dataclass(slots=True)
class DashboardSummary:
    total_requests: int
    total_co2_grams: float
    total_kwh: float
    total_water_liters: float
    local_executions: int
    cloud_executions: int
    baseline_co2_grams: float = 0.0
    saved_vs_baseline_co2_grams: float = 0.0
    saved_vs_baseline_kwh: float = 0.0
    saved_vs_baseline_water_liters: float = 0.0
    saved_vs_baseline_percent: float = 0.0
    impact_baseline_model: str = 'gpt-5'

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'DashboardSummary':
        return cls(
            total_requests=int(payload.get('total_requests', 0)),
            total_co2_grams=float(payload.get('total_co2_grams', 0.0)),
            total_kwh=float(payload.get('total_kwh', 0.0)),
            total_water_liters=float(payload.get('total_water_liters', 0.0)),
            local_executions=int(payload.get('local_executions', 0)),
            cloud_executions=int(payload.get('cloud_executions', 0)),
            baseline_co2_grams=float(payload.get('baseline_co2_grams', 0.0)),
            saved_vs_baseline_co2_grams=float(payload.get('saved_vs_baseline_co2_grams', 0.0)),
            saved_vs_baseline_kwh=float(payload.get('saved_vs_baseline_kwh', 0.0)),
            saved_vs_baseline_water_liters=float(payload.get('saved_vs_baseline_water_liters', 0.0)),
            saved_vs_baseline_percent=float(payload.get('saved_vs_baseline_percent', 0.0)),
            impact_baseline_model=str(payload.get('impact_baseline_model', 'gpt-5')),
        )


@dataclass(slots=True)
class DashboardSummaryResponse:
    summary: DashboardSummary
    by_model: dict[str, dict[str, Any]]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'DashboardSummaryResponse':
        return cls(
            summary=DashboardSummary.from_dict(payload.get('summary', {})),
            by_model={k: dict(v) for k, v in payload.get('by_model', {}).items()},
        )


@dataclass(slots=True)
class DashboardFeedItem:
    request_id: str
    model: str | None
    execution_target: str | None
    co2_grams: float
    latency_ms: float
    cost_usd: float
    region: str | None
    routing_reason: str | None
    metadata: dict[str, Any]
    created_at: datetime

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'DashboardFeedItem':
        return cls(
            request_id=str(payload['request_id']),
            model=payload.get('model'),
            execution_target=payload.get('execution_target'),
            co2_grams=float(payload.get('co2_grams', 0.0)),
            latency_ms=float(payload.get('latency_ms', 0.0)),
            cost_usd=float(payload.get('cost_usd', 0.0)),
            region=payload.get('region'),
            routing_reason=payload.get('routing_reason'),
            metadata=dict(payload.get('metadata', {})),
            created_at=_parse_datetime(payload.get('created_at', datetime.utcnow().isoformat())),
        )


@dataclass(slots=True)
class DashboardFeedResponse:
    items: list[DashboardFeedItem]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'DashboardFeedResponse':
        return cls(items=[DashboardFeedItem.from_dict(item) for item in payload.get('items', [])])


@dataclass(slots=True)
class CarbonLiveResponse:
    provider: str
    regions: dict[str, dict[str, Any]]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> 'CarbonLiveResponse':
        return cls(provider=str(payload.get('provider', 'unknown')), regions=dict(payload.get('regions', {})))
