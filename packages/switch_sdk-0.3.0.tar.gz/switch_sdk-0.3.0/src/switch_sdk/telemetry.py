from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any


class TelemetryBatcher:
    """Async telemetry queue with periodic flush and retry-on-send behavior."""

    def __init__(
        self,
        send_batch: Callable[[list[dict[str, Any]]], Awaitable[None]],
        flush_interval_seconds: float = 2.0,
        max_batch_size: int = 20,
        max_queue_size: int = 2_000,
        max_retries: int = 2,
        retry_backoff_seconds: float = 0.25,
    ) -> None:
        self.send_batch = send_batch
        self.flush_interval_seconds = flush_interval_seconds
        self.max_batch_size = max_batch_size
        self.max_queue_size = max_queue_size
        self.max_retries = max_retries
        self.retry_backoff_seconds = retry_backoff_seconds

        self._events: list[dict[str, Any]] = []
        self._lock = asyncio.Lock()
        self._task: asyncio.Task[None] | None = None
        self._running = False

        self.dropped_events = 0
        self.failed_batches = 0

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self.flush()

    async def enqueue(self, event: dict[str, Any]) -> None:
        batch: list[dict[str, Any]] = []
        async with self._lock:
            if len(self._events) >= self.max_queue_size:
                # Keep newest data under pressure.
                self._events.pop(0)
                self.dropped_events += 1
            self._events.append(event)
            if len(self._events) >= self.max_batch_size:
                batch = self._drain_locked(self.max_batch_size)

        if batch:
            await self._send_with_retry(batch)

    async def flush(self) -> None:
        while True:
            async with self._lock:
                if not self._events:
                    return
                batch = self._drain_locked(self.max_batch_size)
            await self._send_with_retry(batch)

    def _drain_locked(self, batch_size: int) -> list[dict[str, Any]]:
        batch = self._events[:batch_size]
        del self._events[:batch_size]
        return batch

    async def _send_with_retry(self, batch: list[dict[str, Any]]) -> None:
        if not batch:
            return
        for attempt in range(self.max_retries + 1):
            try:
                await self.send_batch(batch)
                return
            except Exception:
                if attempt >= self.max_retries:
                    self.failed_batches += 1
                    self.dropped_events += len(batch)
                    return
                await asyncio.sleep(self.retry_backoff_seconds * (2**attempt))

    async def _run(self) -> None:
        try:
            while self._running:
                await asyncio.sleep(self.flush_interval_seconds)
                await self.flush()
        except asyncio.CancelledError:
            return
