from __future__ import annotations

import pytest

from switch_sdk import build_executorch_text_runtime
from switch_sdk.errors import SwitchLocalModelError
from switch_sdk.local_models import LocalModelHandle, LocalModelSpec
from switch_sdk.models import ChatMessage


def test_executorch_runtime_raises_helpful_error_without_dependencies(tmp_path):
    runtime = build_executorch_text_runtime(prefer_optimum=False)
    handle = LocalModelHandle(
        spec=LocalModelSpec(
            model_id='tiny-chat',
            task='chat',
            download_url='',
            size_mb=1.0,
            min_ram_gb=1.0,
            max_prompt_chars=256,
            rank=1,
        ),
        path=tmp_path / 'model.pte',
        from_cache=True,
    )
    handle.path.write_bytes(b'mock')

    with pytest.raises(SwitchLocalModelError):
        runtime([ChatMessage(role='user', content='Reply exactly: OK')], handle)


def test_runtime_input_candidates_include_position_tensor_for_two_input_methods():
    runtime = build_executorch_text_runtime(prefer_optimum=False)

    class _TensorInfo:
        def __init__(self, sizes: tuple[int, ...]):
            self._sizes = sizes

        def sizes(self):
            return self._sizes

    class _MethodMeta:
        def num_inputs(self):
            return 2

        def input_tensor_meta(self, index: int):
            if index == 1:
                return _TensorInfo((1,))
            return _TensorInfo((1, 1))

    class _FakeTorch:
        long = 'long'

        @staticmethod
        def tensor(value, dtype=None):
            return ('tensor', value, dtype)

        @staticmethod
        def ones_like(value, dtype=None):
            return ('ones_like', value, dtype)

        @staticmethod
        def zeros(shape, dtype=None):
            return ('zeros', shape, dtype)

    runtime._runtime_method_meta = _MethodMeta()
    candidates = runtime._runtime_input_candidates(token_tensor='token', position=7, torch_module=_FakeTorch)
    assert candidates[0] == ('token', ('tensor', [7], 'long'))
    assert len(candidates) >= 3
