from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
import respx
import httpx

from switch_sdk.local_models import LocalModelManager
from switch_sdk.models import ChatMessage


def _sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def test_pick_best_model_prefers_small_for_short_prompts(tmp_path: Path) -> None:
    manager = LocalModelManager(
        cache_dir=tmp_path,
        manifest=[
            {
                'model_id': 'tiny-chat',
                'task': 'chat',
                'download_url': '',
                'size_mb': 200,
                'min_ram_gb': 2,
                'max_prompt_chars': 160,
                'rank': 10,
            },
            {
                'model_id': 'mid-chat',
                'task': 'chat',
                'download_url': '',
                'size_mb': 700,
                'min_ram_gb': 2,
                'max_prompt_chars': 1200,
                'rank': 20,
            },
        ],
    )
    spec = manager.pick_best_model(messages=[ChatMessage(role='user', content='Reply exactly: OK')], task='chat')
    assert spec is not None
    assert spec.model_id == 'tiny-chat'


@respx.mock
def test_ensure_model_downloads_once_then_hits_cache(tmp_path: Path) -> None:
    payload = b'model-bytes-v1'
    digest = _sha256(payload)
    url = 'https://example.com/models/tiny-chat.pte'

    route = respx.get(url).mock(return_value=httpx.Response(200, content=payload))
    manager = LocalModelManager(
        cache_dir=tmp_path,
        manifest=[
            {
                'model_id': 'tiny-chat',
                'task': 'chat',
                'download_url': url,
                'sha256': digest,
                'size_mb': 1,
                'min_ram_gb': 1,
                'max_prompt_chars': 200,
                'rank': 1,
            }
        ],
    )
    spec = manager.manifest[0]

    first = manager.ensure_model(spec, allow_download=True)
    second = manager.ensure_model(spec, allow_download=True)

    assert first.path.exists()
    assert first.from_cache is False
    assert second.from_cache is True
    assert route.call_count == 1
