from __future__ import annotations

import os

import pytest

from switch_sdk import ChatMessage, SwitchClient

BASE_URL = os.getenv("SHIFT_BASE_URL")
API_KEY = os.getenv("SHIFT_API_KEY")
MODEL = os.getenv("SHIFT_MODEL", "gpt-5")
RESIDENCY = os.getenv("SHIFT_RESIDENCY", "US")
EAST_REGION = os.getenv("SHIFT_EAST_REGION", "eastus").lower()
WEST_REGION = os.getenv("SHIFT_WEST_REGION", "westus").lower()
CENTRAL_REGION = (os.getenv("SHIFT_CENTRAL_REGION", "centralus") or "").strip().lower()

pytestmark = [pytest.mark.integration, pytest.mark.asyncio]


if not BASE_URL or not API_KEY:
    pytestmark.append(
        pytest.mark.skip(reason="Set SHIFT_BASE_URL and SHIFT_API_KEY to run live region-switch tests")
    )


def _configured_regions() -> list[str]:
    regions = [EAST_REGION, WEST_REGION]
    if CENTRAL_REGION:
        regions.append(CENTRAL_REGION)
    return regions


def _region_matches(actual: str, expected: str) -> bool:
    return actual.lower() == expected.lower()


def _first_choice_text(chat_payload: object) -> str:
    if not hasattr(chat_payload, "choices"):
        return ""
    choices = getattr(chat_payload, "choices")
    if not choices:
        return ""
    first = choices[0]
    if not hasattr(first, "message"):
        return ""
    message = getattr(first, "message")
    return getattr(message, "content", "")


async def _route_region(client: SwitchClient, preferred_region: str | None = None):
    flags: dict[str, object] = {"force_cloud": True}
    if preferred_region:
        flags["preferred_region"] = preferred_region

    return await client.route(
        model=MODEL,
        residency=RESIDENCY,
        sla="realtime",
        capability_flags=flags,
    )


@pytest.mark.integration
async def test_route_force_configured_regions_switch() -> None:
    async with SwitchClient(base_url=BASE_URL, api_key=API_KEY, telemetry_enabled=False) as client:
        for region in _configured_regions():
            decision = await _route_region(client, preferred_region=region)
            assert _region_matches(decision.target.region, region), decision.target.region


@pytest.mark.integration
async def test_route_default_chooses_lowest_score_between_configured_regions() -> None:
    regions = _configured_regions()

    async with SwitchClient(base_url=BASE_URL, api_key=API_KEY, telemetry_enabled=False) as client:
        decision = await _route_region(client)

    candidate_names: dict[str, str] = {}
    for region in regions:
        matches = [name for name in decision.scores if region in name.lower()]
        if not matches:
            pytest.skip(f"Live org does not have '{region}' target in route scores")
        candidate_names[region] = matches[0]

    expected_name = min(candidate_names.values(), key=lambda name: decision.scores[name])
    assert decision.target.name == expected_name


@pytest.mark.integration
async def test_chat_force_configured_regions_switch() -> None:
    prompts = {
        EAST_REGION: "Reply exactly: EAST_SWITCH_OK",
        WEST_REGION: "Reply exactly: WEST_SWITCH_OK",
    }
    if CENTRAL_REGION:
        prompts[CENTRAL_REGION] = "Reply exactly: CENTRAL_SWITCH_OK"

    async with SwitchClient(base_url=BASE_URL, api_key=API_KEY, telemetry_enabled=False) as client:
        for region, message in prompts.items():
            chat = await client.chat(
                model=MODEL,
                messages=[ChatMessage(role="user", content=message)],
                residency=RESIDENCY,
                sla="realtime",
                capability_flags={"force_cloud": True, "preferred_region": region},
            )
            route = chat.switch_meta.get("route", {})
            target = route.get("target", {}) if isinstance(route, dict) else {}
            assert _region_matches(str(target.get("region", "")), region)
            assert message.split(":", 1)[1].strip() in _first_choice_text(chat)
