from __future__ import annotations

import pytest

from switch_sdk.telemetry import TelemetryBatcher


@pytest.mark.asyncio
async def test_flushes_when_batch_size_reached() -> None:
    sent: list[list[dict[str, object]]] = []

    async def send(batch: list[dict[str, object]]) -> None:
        sent.append(batch)

    batcher = TelemetryBatcher(
        send_batch=send,
        flush_interval_seconds=3600,
        max_batch_size=2,
        max_queue_size=10,
    )
    await batcher.start()

    await batcher.enqueue({'event_type': 'one'})
    await batcher.enqueue({'event_type': 'two'})

    await batcher.stop()

    assert len(sent) == 1
    assert [item['event_type'] for item in sent[0]] == ['one', 'two']


@pytest.mark.asyncio
async def test_retries_and_records_failures() -> None:
    attempts = 0

    async def always_fail(_: list[dict[str, object]]) -> None:
        nonlocal attempts
        attempts += 1
        raise RuntimeError('boom')

    batcher = TelemetryBatcher(
        send_batch=always_fail,
        flush_interval_seconds=3600,
        max_batch_size=10,
        max_retries=1,
        retry_backoff_seconds=0,
    )
    await batcher.start()

    await batcher.enqueue({'event_type': 'one'})
    await batcher.flush()
    await batcher.stop()

    assert attempts == 2
    assert batcher.failed_batches == 1
    assert batcher.dropped_events == 1
