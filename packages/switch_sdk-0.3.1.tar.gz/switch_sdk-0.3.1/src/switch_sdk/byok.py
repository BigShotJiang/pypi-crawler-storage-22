from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

_DEPLOYMENT_SEGMENT_RE = re.compile(r'/openai/deployments/[^/?]+/chat/completions', re.IGNORECASE)

DEFAULT_AZURE_BYOK_REGIONS = (
    'eastus',
    'westus',
    'centralus',
    'westeurope',
    'northeurope',
    'swedencentral',
)


def _normalize_model_key(model: str) -> str:
    return str(model or '').strip().lower().replace('_', '-')


def _normalize_region_key(region: str) -> str:
    return str(region or '').strip().lower().replace('_', '')


def _with_api_version(url: str, api_version: str | None) -> str:
    if not api_version:
        return url
    parsed = urlsplit(url)
    query_pairs = parse_qsl(parsed.query, keep_blank_values=True)
    query: dict[str, str] = {key: value for key, value in query_pairs}
    query.setdefault('api-version', api_version)
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))


def _build_chat_endpoint(endpoint: str, deployment: str, api_version: str | None) -> str:
    value = endpoint.strip()
    if not value:
        raise ValueError('BYOK endpoint is empty')

    if '{deployment}' in value or '{DEPLOYMENT}' in value:
        replaced = value.replace('{deployment}', deployment).replace('{DEPLOYMENT}', deployment)
        return _with_api_version(replaced, api_version)

    parsed = urlsplit(value)
    path = parsed.path.rstrip('/')
    if not path:
        path = ''

    if _DEPLOYMENT_SEGMENT_RE.search(path):
        path = _DEPLOYMENT_SEGMENT_RE.sub(f'/openai/deployments/{deployment}/chat/completions', path, count=1)
    elif path.endswith('/openai/chat/completions'):
        # Some endpoints are provisioned as /openai/chat/completions with deployment header;
        # Shift BYOK normalizes to deployment URL path for Azure OpenAI.
        path = path[: -len('/openai/chat/completions')]
        path = f'{path}/openai/deployments/{deployment}/chat/completions'
    elif '/openai/deployments/' in path and '/chat/completions' in path:
        path = _DEPLOYMENT_SEGMENT_RE.sub(f'/openai/deployments/{deployment}/chat/completions', path, count=1)
    elif path.endswith('/chat/completions'):
        # Endpoint likely already deployment-specific; keep as-is.
        pass
    else:
        path = f'{path}/openai/deployments/{deployment}/chat/completions'

    resolved = urlunsplit((parsed.scheme, parsed.netloc, path, parsed.query, parsed.fragment))
    return _with_api_version(resolved, api_version)


@dataclass(slots=True)
class AzureRegionCredential:
    endpoint: str
    api_key: str | None = None
    default_deployment: str | None = None
    deployment_overrides: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class AzureBYOKResolvedRequest:
    region: str
    endpoint: str
    api_key: str
    deployment: str


@dataclass(slots=True)
class AzureBYOKConfig:
    regions: dict[str, AzureRegionCredential]
    api_version: str = '2025-01-01-preview'
    default_api_key: str | None = None
    deployment_overrides: dict[str, str] = field(default_factory=dict)
    timeout_seconds: float = 45.0

    @classmethod
    def from_env(
        cls,
        *,
        prefix: str = 'SHIFT_BYOK_AZURE',
        regions: tuple[str, ...] = DEFAULT_AZURE_BYOK_REGIONS,
        default_api_version: str = '2025-01-01-preview',
        timeout_seconds: float = 45.0,
    ) -> 'AzureBYOKConfig':
        default_api_key = os.getenv(f'{prefix}_API_KEY', '').strip() or None
        api_version = os.getenv(f'{prefix}_API_VERSION', '').strip() or default_api_version

        deployment_overrides: dict[str, str] = {}
        deployment_prefix = f'{prefix}_DEPLOYMENT_'
        for env_name, env_value in os.environ.items():
            if not env_name.startswith(deployment_prefix):
                continue
            model_suffix = env_name[len(deployment_prefix) :]
            deployment = env_value.strip()
            if not model_suffix or not deployment:
                continue
            model_key = model_suffix.lower().replace('__', '@').replace('_', '-')
            deployment_overrides[model_key] = deployment

        configured_regions: dict[str, AzureRegionCredential] = {}
        for region in regions:
            region_key = _normalize_region_key(region)
            env_region = region.upper().replace('-', '_')
            endpoint = os.getenv(f'{prefix}_{env_region}_ENDPOINT', '').strip()
            if not endpoint:
                continue
            api_key = os.getenv(f'{prefix}_{env_region}_API_KEY', '').strip() or None
            default_deployment = os.getenv(f'{prefix}_{env_region}_DEPLOYMENT', '').strip() or None
            configured_regions[region_key] = AzureRegionCredential(
                endpoint=endpoint,
                api_key=api_key,
                default_deployment=default_deployment,
            )

        if not configured_regions:
            dynamic_regions = cls._parse_region_env(prefix=prefix)
            configured_regions.update(dynamic_regions)

        if not configured_regions:
            raise ValueError(
                f'No BYOK Azure endpoints found in environment for prefix {prefix}. '
                f'Set vars like {prefix}_EASTUS_ENDPOINT and {prefix}_EASTUS_API_KEY.'
            )

        return cls(
            regions=configured_regions,
            api_version=api_version,
            default_api_key=default_api_key,
            deployment_overrides=deployment_overrides,
            timeout_seconds=timeout_seconds,
        )

    @classmethod
    def _parse_region_env(cls, *, prefix: str) -> dict[str, AzureRegionCredential]:
        configured: dict[str, AzureRegionCredential] = {}
        suffix = '_ENDPOINT'
        for env_name, env_value in os.environ.items():
            if not env_name.startswith(f'{prefix}_') or not env_name.endswith(suffix):
                continue
            region_part = env_name[len(prefix) + 1 : -len(suffix)]
            if not region_part:
                continue
            region_key = _normalize_region_key(region_part)
            endpoint = env_value.strip()
            if not endpoint:
                continue
            api_key = os.getenv(f'{prefix}_{region_part}_API_KEY', '').strip() or None
            default_deployment = os.getenv(f'{prefix}_{region_part}_DEPLOYMENT', '').strip() or None
            configured[region_key] = AzureRegionCredential(
                endpoint=endpoint,
                api_key=api_key,
                default_deployment=default_deployment,
            )
        return configured

    def resolve_request(
        self,
        *,
        region: str,
        model: str,
        capability_flags: dict[str, object] | None = None,
    ) -> AzureBYOKResolvedRequest:
        region_key = _normalize_region_key(region)
        credential = self.regions.get(region_key)
        if credential is None:
            available = ', '.join(sorted(self.regions))
            raise ValueError(f'No BYOK Azure endpoint configured for region {region_key}. Available: {available}')

        flags = capability_flags or {}
        explicit_deployment = str(flags.get('azure_deployment', '')).strip()
        model_key = _normalize_model_key(model)

        deployment = (
            explicit_deployment
            or credential.deployment_overrides.get(model_key)
            or self.deployment_overrides.get(model_key)
            or credential.default_deployment
            or model
        )
        api_key = (credential.api_key or self.default_api_key or '').strip()
        if not api_key:
            raise ValueError(f'No BYOK Azure API key configured for region {region_key}')

        endpoint = _build_chat_endpoint(credential.endpoint, deployment=deployment, api_version=self.api_version)
        return AzureBYOKResolvedRequest(
            region=region_key,
            endpoint=endpoint,
            api_key=api_key,
            deployment=deployment,
        )
