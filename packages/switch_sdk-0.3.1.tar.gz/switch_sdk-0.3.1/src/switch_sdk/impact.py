from __future__ import annotations

from dataclasses import dataclass

MODEL_ENERGY_WH_PER_2K_TOKENS: dict[str, float] = {
    # Research-backed anchor points from public estimates.
    'gpt-4.1': 2.513,
    'gpt-4.1-mini': 0.847,
    'gpt-4.1-nano': 0.271,
    # Demo estimates for GPT-5 tiering until vendor-verified values are available.
    'gpt-5': 3.200,
    'gpt-5-mini': 1.100,
    'gpt-5-nano': 0.350,
    'gpt-4o-mini': 0.700,
}

MODEL_ALIASES: dict[str, str] = {
    'gpt5': 'gpt-5',
    'gpt5-mini': 'gpt-5-mini',
    'gpt5-nano': 'gpt-5-nano',
    'gpt4o-mini': 'gpt-4o-mini',
}

DEFAULT_WH_PER_2K_TOKENS = 1.200
DEFAULT_BASELINE_MODEL = 'gpt-5'
DEFAULT_WATER_LITERS_PER_KWH = 1.8
ESTIMATION_VERSION = 'model-wh-per-2k-v1'


@dataclass(slots=True)
class ImpactEstimate:
    model: str
    normalized_model: str
    total_tokens: int
    carbon_intensity_gco2_kwh: float
    model_wh_per_2k: float
    energy_kwh: float
    co2_grams: float
    water_liters: float
    baseline_model: str
    baseline_wh_per_2k: float
    baseline_energy_kwh: float
    baseline_co2_grams: float
    baseline_water_liters: float
    saved_vs_baseline_kwh: float
    saved_vs_baseline_co2_grams: float
    saved_vs_baseline_water_liters: float
    estimation_version: str = ESTIMATION_VERSION

    def to_metadata(self) -> dict[str, float | int | str]:
        return {
            'estimation_version': self.estimation_version,
            'model': self.model,
            'normalized_model': self.normalized_model,
            'total_tokens': self.total_tokens,
            'carbon_intensity_gco2_kwh': self.carbon_intensity_gco2_kwh,
            'model_wh_per_2k': self.model_wh_per_2k,
            'energy_kwh': self.energy_kwh,
            'co2_grams': self.co2_grams,
            'water_liters': self.water_liters,
            'baseline_model': self.baseline_model,
            'baseline_wh_per_2k': self.baseline_wh_per_2k,
            'baseline_energy_kwh': self.baseline_energy_kwh,
            'baseline_co2_grams': self.baseline_co2_grams,
            'baseline_water_liters': self.baseline_water_liters,
            'saved_vs_baseline_kwh': self.saved_vs_baseline_kwh,
            'saved_vs_baseline_co2_grams': self.saved_vs_baseline_co2_grams,
            'saved_vs_baseline_water_liters': self.saved_vs_baseline_water_liters,
        }


class ModelImpactEstimator:
    def __init__(
        self,
        *,
        baseline_model: str = DEFAULT_BASELINE_MODEL,
        default_wh_per_2k: float = DEFAULT_WH_PER_2K_TOKENS,
        water_liters_per_kwh: float = DEFAULT_WATER_LITERS_PER_KWH,
    ) -> None:
        self.baseline_model = self._normalize_model(baseline_model)
        self.default_wh_per_2k = float(default_wh_per_2k)
        self.water_liters_per_kwh = float(water_liters_per_kwh)

    def estimate(self, *, model: str, total_tokens: int, carbon_intensity_gco2_kwh: float) -> ImpactEstimate:
        normalized_model = self._normalize_model(model)
        tokens = max(1, int(total_tokens))
        carbon_intensity = max(0.0, float(carbon_intensity_gco2_kwh))
        model_wh_per_2k = self.model_wh_per_2k(normalized_model)
        baseline_wh_per_2k = self.model_wh_per_2k(self.baseline_model)

        energy_kwh = self._to_energy_kwh(tokens=tokens, wh_per_2k=model_wh_per_2k)
        baseline_energy_kwh = self._to_energy_kwh(tokens=tokens, wh_per_2k=baseline_wh_per_2k)

        co2_grams = energy_kwh * carbon_intensity
        water_liters = energy_kwh * self.water_liters_per_kwh
        baseline_co2_grams = baseline_energy_kwh * carbon_intensity
        baseline_water_liters = baseline_energy_kwh * self.water_liters_per_kwh

        return ImpactEstimate(
            model=model,
            normalized_model=normalized_model,
            total_tokens=tokens,
            carbon_intensity_gco2_kwh=carbon_intensity,
            model_wh_per_2k=model_wh_per_2k,
            energy_kwh=energy_kwh,
            co2_grams=co2_grams,
            water_liters=water_liters,
            baseline_model=self.baseline_model,
            baseline_wh_per_2k=baseline_wh_per_2k,
            baseline_energy_kwh=baseline_energy_kwh,
            baseline_co2_grams=baseline_co2_grams,
            baseline_water_liters=baseline_water_liters,
            saved_vs_baseline_kwh=baseline_energy_kwh - energy_kwh,
            saved_vs_baseline_co2_grams=baseline_co2_grams - co2_grams,
            saved_vs_baseline_water_liters=baseline_water_liters - water_liters,
        )

    def model_wh_per_2k(self, model: str) -> float:
        normalized = self._normalize_model(model)
        return float(MODEL_ENERGY_WH_PER_2K_TOKENS.get(normalized, self.default_wh_per_2k))

    def _normalize_model(self, model: str) -> str:
        value = str(model or '').strip().lower().replace('_', '-')
        if not value:
            return DEFAULT_BASELINE_MODEL

        # Strip common Azure deployment suffixes if present, for example "gpt-5@eastus".
        value = value.split('@', 1)[0].split(':', 1)[0].strip()
        return MODEL_ALIASES.get(value, value)

    @staticmethod
    def _to_energy_kwh(*, tokens: int, wh_per_2k: float) -> float:
        request_wh = float(wh_per_2k) * (float(tokens) / 2000.0)
        return request_wh / 1000.0
