import logging
import xml.etree.ElementTree as ET

import httpx
import pyspark.sql.functions as F
from sws_api_client import PluginPayload, SwsApiClient, TaskDataset, TaskManager
from sws_spark_dissemination_helper import SWSGoldIcebergSparkHelper
from sws_spark_dissemination_helper.utils import save_cache_csv


def get_structure_map_stubs(sdmx_registry_url: str, agency_id: str):
    url = f"{sdmx_registry_url}/sdmx/v2/structure/structuremap/{agency_id}/all/+/?format=sdmx-3.0&detail=allstubs"
    logging.info(f"Calling {url} to obtain all structure maps for this domain")

    with httpx.Client() as client:
        response = client.get(url)
        response.raise_for_status()  # optional, but helpful

        logging.info(response.text)

        ns = {"str": "http://www.sdmx.org/resources/sdmxml/schemas/v3_0/structure"}
        root = ET.fromstring(response.text)

        structure_maps = [
            {
                "agencyID": e.get("agencyID"),
                "id": e.get("id"),
                "version": e.get("version"),
            }
            for e in root.findall(".//str:StructureMap", ns)
            if "SWS_TO_FAOSTAT" in (e.get("id") or "")
        ]

        structure_maps = sorted(structure_maps, key=lambda x: x.get("id", ""))

        logging.info(
            "Structure Maps to obtain FAOSTAT representation: %s", structure_maps
        )

        return structure_maps


def execute_task_wait_execution(
    sws_client: SwsApiClient,
    sws_tasks: TaskManager,
    plugin_name: str,
    payload: PluginPayload,
    description: str,
    group: str,
    user: str,
):
    task_execution = sws_tasks.create_plugin_task(
        pluginName=plugin_name,
        slow=True,
        payload=payload,
        description=description,
        group=group,
        user=user,
        parentTaskId=sws_client.current_task_id,
    )

    task_response = sws_tasks.wait_completion(task_execution.task_id)

    if task_response.info.outcome == "SUCCESS":
        logging.info(f"Task {task_response.task_id} completed successfully.")
    else:
        logging.error(f"Task {task_response.task_id} failed.")
        logging.info("stopping the execution")
        exit(1)


def _get_sws_context():
    """Fetch SWS client, tasks, current task and dataset metadata."""
    sws_client = SwsApiClient.auto()
    sws_tasks = TaskManager(sws_client)
    current_task = sws_tasks.get_task(sws_client.current_task_id)

    payload = current_task.info.input["payload"]
    dataset = payload["datasets"][0]

    return (
        sws_client,
        sws_tasks,
        current_task,
        dataset.get("session"),
        dataset.get("selection"),
    )


def _run_structure_maps(
    structure_map_stubs,
    gold_helper: SWSGoldIcebergSparkHelper,
    sws_client: SwsApiClient,
    sws_tasks: TaskManager,
    current_task,
    session,
    selection,
    sdmx_registry_url: str,
    *,
    source_first_path: str,
    target_path: str,
):
    """Execute structure map tasks for all stubs."""
    for i, stub in enumerate(structure_map_stubs):
        source_path = source_first_path if i == 0 else target_path

        payload = PluginPayload(
            datasets=[
                TaskDataset(
                    dataset=gold_helper.dataset_id,
                    session=session,
                    selection=selection,
                )
            ],
            parameters={
                "source_csv_path": source_path,
                "target_csv_path": target_path,
                "s3_bucket": gold_helper.bucket,
                "sdmx_registry_url": sdmx_registry_url,
                "map_agency": stub["agencyID"],
                "map_structure_id": stub["id"],
                "map_version": stub["version"],
            },
        )

        execute_task_wait_execution(
            sws_client=sws_client,
            sws_tasks=sws_tasks,
            plugin_name="structure_map_mappings_utility_non_sws",
            payload=payload,
            description=f"Mapping from GOLD_SWS_DISSEMINATED to GOLD_FAOSTAT. Step {i+1}",
            group=current_task.info.group,
            user=current_task.info.user,
        )


def from_sws_to_faostat(
    gold_helper: SWSGoldIcebergSparkHelper,
    sdmx_registry_url: str,
):
    (
        sws_client,
        sws_tasks,
        current_task,
        session,
        selection,
    ) = _get_sws_context()

    structure_map_stubs = get_structure_map_stubs(
        sdmx_registry_url,
        f"FAO.FAOSTAT.{gold_helper.domain_code}",
    )

    source_first_path = gold_helper.iceberg_tables.GOLD_PRE_SDMX.csv_path
    target_path = gold_helper.iceberg_tables.GOLD_FAOSTAT.csv_path

    _run_structure_maps(
        structure_map_stubs,
        gold_helper,
        sws_client,
        sws_tasks,
        current_task,
        session,
        selection,
        sdmx_registry_url,
        source_first_path=source_first_path,
        target_path=target_path,
    )

    full_path = f"s3://{gold_helper.bucket}/{target_path}"
    logging.info("CSV path used to fetch data: %s", full_path)

    return gold_helper.spark.read.csv(full_path, header=True, inferSchema=False)


def from_sws_to_faostat_unfiltered(
    gold_helper: SWSGoldIcebergSparkHelper,
    sdmx_registry_url: str,
):
    (
        sws_client,
        sws_tasks,
        current_task,
        session,
        selection,
    ) = _get_sws_context()

    # --- Extract and transform GOLD Silver data -----------------------------
    df = gold_helper.read_silver_data().transform(gold_helper.keep_dim_val_attr_columns)

    # Replace dots in all dimension columns in a vectorized way
    for column in gold_helper.dim_columns:
        df = df.withColumn(column, F.regexp_replace(column, r"\.", "_"))

    # Rename value column & uppercase all other columns
    df = df.withColumnRenamed("value", "OBS_VALUE").withColumnsRenamed(
        {c: c.upper() for c in df.columns}
    )

    # Save unfiltered data
    save_cache_csv(
        df,
        bucket=gold_helper.bucket,
        prefix=gold_helper.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.csv_prefix,
        tag_name=gold_helper.tag_name,
    )

    # --- Execute structure mapping tasks -----------------------------------
    structure_map_stubs = get_structure_map_stubs(
        sdmx_registry_url,
        f"FAO.FAOSTAT.{gold_helper.domain_code}",
    )

    source_first_path = gold_helper.iceberg_tables.GOLD_PRE_SDMX.csv_path
    target_path = gold_helper.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.csv_path

    _run_structure_maps(
        structure_map_stubs,
        gold_helper,
        sws_client,
        sws_tasks,
        current_task,
        session,
        selection,
        sdmx_registry_url,
        source_first_path=source_first_path,
        target_path=target_path,
    )

    full_path = f"s3://{gold_helper.bucket}/{target_path}"
    logging.info("CSV path used to fetch UNFILTERED data: %s", full_path)

    return gold_helper.spark.read.csv(full_path, header=True, inferSchema=False)
