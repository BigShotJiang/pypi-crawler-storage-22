# `Catalog` class

::: sxs.Catalog
