# `TimeSeries` class

::: sxs.TimeSeries
