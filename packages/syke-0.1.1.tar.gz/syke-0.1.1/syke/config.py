"""Configuration — .env loading, paths, user data dirs."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# Root of the syke project
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Data directory (per-user data lives here)
DATA_DIR = Path(os.getenv("SYKE_DATA_DIR", PROJECT_ROOT / "data"))

# Anthropic
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
DEFAULT_MODEL = "claude-opus-4-6"
THINKING_BUDGET = 16000

# Default user
DEFAULT_USER = os.getenv("SYKE_USER", "")


def user_data_dir(user_id: str) -> Path:
    """Return the data directory for a specific user, creating it if needed."""
    if "/" in user_id or "\\" in user_id or ".." in user_id:
        raise ValueError(f"Invalid user_id: {user_id!r}")
    d = DATA_DIR / user_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def user_db_path(user_id: str) -> Path:
    """Return the SQLite DB path for a user."""
    return user_data_dir(user_id) / "syke.db"


def user_profile_path(user_id: str) -> Path:
    """Return the latest profile JSON path for a user."""
    return user_data_dir(user_id) / "profile.json"


