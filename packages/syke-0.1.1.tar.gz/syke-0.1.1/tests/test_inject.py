"""Tests for MCP and hooks auto-injection."""

from __future__ import annotations

import json

from syke.distribution.inject import (
    inject_hooks_config,
    inject_mcp_config,
)


def test_inject_mcp_config_creates_new(tmp_path, monkeypatch):
    """Creates settings.json if it doesn't exist and adds syke MCP server."""
    settings_path = tmp_path / ".claude" / "settings.json"
    monkeypatch.setattr("syke.distribution.inject.CLAUDE_SETTINGS_PATH", settings_path)

    result = inject_mcp_config("testuser", tmp_path / "project")
    assert result == settings_path
    assert settings_path.exists()

    settings = json.loads(settings_path.read_text())
    assert "syke" in settings["mcpServers"]
    assert settings["mcpServers"]["syke"]["args"][3] == "testuser"


def test_inject_mcp_config_merges(tmp_path, monkeypatch):
    """Preserves existing MCP servers when adding syke."""
    settings_path = tmp_path / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True)
    settings_path.write_text(json.dumps({
        "mcpServers": {
            "other-server": {"command": "other", "args": []}
        },
        "someOtherSetting": True,
    }))
    monkeypatch.setattr("syke.distribution.inject.CLAUDE_SETTINGS_PATH", settings_path)

    inject_mcp_config("testuser", tmp_path / "project")

    settings = json.loads(settings_path.read_text())
    assert "other-server" in settings["mcpServers"]
    assert "syke" in settings["mcpServers"]
    assert settings["someOtherSetting"] is True


def test_inject_hooks_creates_new(tmp_path, monkeypatch):
    """Creates settings.json with hooks if it doesn't exist."""
    settings_path = tmp_path / ".claude" / "settings.json"
    monkeypatch.setattr("syke.distribution.inject.CLAUDE_SETTINGS_PATH", settings_path)

    result = inject_hooks_config(tmp_path / "project")
    assert result == settings_path

    settings = json.loads(settings_path.read_text())
    assert "SessionStart" in settings["hooks"]
    assert "Stop" in settings["hooks"]
    assert len(settings["hooks"]["SessionStart"]) == 1
    assert len(settings["hooks"]["Stop"]) == 1
    assert "syke-session-start" in settings["hooks"]["SessionStart"][0]["command"]
    assert "syke-session-stop" in settings["hooks"]["Stop"][0]["command"]


def test_inject_hooks_merges(tmp_path, monkeypatch):
    """Preserves existing hooks when adding syke hooks."""
    settings_path = tmp_path / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True)
    settings_path.write_text(json.dumps({
        "hooks": {
            "SessionStart": [
                {"type": "command", "command": "echo existing-hook"}
            ],
            "PreToolUse": [
                {"type": "command", "command": "echo pre-tool"}
            ],
        }
    }))
    monkeypatch.setattr("syke.distribution.inject.CLAUDE_SETTINGS_PATH", settings_path)

    inject_hooks_config(tmp_path / "project")

    settings = json.loads(settings_path.read_text())
    # Existing SessionStart hook preserved
    commands = [h["command"] for h in settings["hooks"]["SessionStart"]]
    assert "echo existing-hook" in commands
    assert any("syke-session-start" in c for c in commands)
    # PreToolUse untouched
    assert len(settings["hooks"]["PreToolUse"]) == 1
    # Stop hook added
    assert len(settings["hooks"]["Stop"]) == 1


def test_inject_hooks_idempotent(tmp_path, monkeypatch):
    """Running inject_hooks_config twice doesn't duplicate syke hooks."""
    settings_path = tmp_path / ".claude" / "settings.json"
    monkeypatch.setattr("syke.distribution.inject.CLAUDE_SETTINGS_PATH", settings_path)

    inject_hooks_config(tmp_path / "project")
    inject_hooks_config(tmp_path / "project")

    settings = json.loads(settings_path.read_text())
    # Should have exactly 1 syke hook per event, not 2
    assert len(settings["hooks"]["SessionStart"]) == 1
    assert len(settings["hooks"]["Stop"]) == 1
