"""Tests for config.py data directory resolution."""

from __future__ import annotations

from pathlib import Path

from syke.config import _default_data_dir, _is_source_install


def test_is_source_install_true():
    """Returns True when pyproject.toml exists at PROJECT_ROOT (i.e., this repo)."""
    assert _is_source_install() is True


def test_env_var_overrides_everything(tmp_path, monkeypatch):
    """SYKE_DATA_DIR env var takes priority over all other logic."""
    target = tmp_path / "custom"
    monkeypatch.setenv("SYKE_DATA_DIR", str(target))
    result = _default_data_dir()
    assert result == target.resolve()


def test_default_data_dir_returns_home_syke_data(monkeypatch):
    """Without env var, always returns ~/.syke/data regardless of install type."""
    monkeypatch.delenv("SYKE_DATA_DIR", raising=False)
    result = _default_data_dir()
    assert result == Path.home() / ".syke" / "data"
