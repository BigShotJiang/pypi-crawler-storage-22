"""Tests for daemon-related functionality."""

import os
import signal
from unittest.mock import patch

from syke.daemon.daemon import (
    SykeDaemon,
    _write_pid,
    _remove_pid,
    is_running,
    generate_plist,
    PIDFILE,
)


def test_daemon_pid_lifecycle(tmp_path):
    """PID file is written and cleaned up correctly."""
    test_pidfile = tmp_path / "daemon.pid"
    with patch("syke.daemon.daemon.PIDFILE", test_pidfile):
        # Initially not running
        running, pid = is_running()
        assert running is False
        assert pid is None

        # Write PID
        _write_pid()
        assert test_pidfile.exists()
        written_pid = int(test_pidfile.read_text().strip())
        assert written_pid == os.getpid()

        # Should detect as running (our own PID)
        running, pid = is_running()
        assert running is True
        assert pid == os.getpid()

        # Remove PID
        _remove_pid()
        assert not test_pidfile.exists()

        # No longer running
        running, pid = is_running()
        assert running is False


def test_daemon_stale_pid_cleanup(tmp_path):
    """Stale PID file (dead process) is cleaned up automatically."""
    test_pidfile = tmp_path / "daemon.pid"
    # Write a PID that definitely doesn't exist (99999999)
    test_pidfile.write_text("99999999")

    with patch("syke.daemon.daemon.PIDFILE", test_pidfile):
        running, pid = is_running()
        assert running is False
        assert pid is None
        # PID file should be cleaned up
        assert not test_pidfile.exists()


def test_daemon_signal_stops_loop():
    """Daemon loop stops when signal handler sets running=False."""
    d = SykeDaemon("test", interval=1)
    assert d.running is True
    d._handle_signal(signal.SIGTERM, None)
    assert d.running is False


def test_generate_plist():
    """generate_plist produces valid XML with expected content."""
    plist = generate_plist("testuser")
    assert "com.syke.daemon" in plist
    assert "testuser" in plist
    assert "<string>sync</string>" in plist
    assert "<?xml" in plist
    assert "StartInterval" in plist
    # API key must NOT be embedded in the plist (security)
    assert "ANTHROPIC_API_KEY" not in plist
    assert "sk-ant" not in plist
