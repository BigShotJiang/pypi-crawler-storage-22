"""Configuration — .env loading, paths, user data dirs."""

from __future__ import annotations

import getpass
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# Root of the syke project
PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _is_source_install() -> bool:
    """True when running from a git clone (pyproject.toml exists at PROJECT_ROOT)."""
    return (PROJECT_ROOT / "pyproject.toml").exists()


def _default_data_dir() -> Path:
    """Resolve data directory: env var override or ~/.syke/data."""
    env = os.getenv("SYKE_DATA_DIR")
    if env:
        return Path(env).resolve()
    return Path.home() / ".syke" / "data"


# Data directory (per-user data lives here)
DATA_DIR = _default_data_dir()

# Anthropic
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
DEFAULT_MODEL = "claude-opus-4-6"
THINKING_BUDGET = 16000

# Default user — env var override, else system username
DEFAULT_USER = os.getenv("SYKE_USER", "") or getpass.getuser()


def user_data_dir(user_id: str) -> Path:
    """Return the data directory for a specific user, creating it if needed."""
    if "/" in user_id or "\\" in user_id or ".." in user_id:
        raise ValueError(f"Invalid user_id: {user_id!r}")
    d = DATA_DIR / user_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def user_db_path(user_id: str) -> Path:
    """Return the SQLite DB path for a user."""
    return user_data_dir(user_id) / "syke.db"


def user_profile_path(user_id: str) -> Path:
    """Return the latest profile JSON path for a user."""
    return user_data_dir(user_id) / "profile.json"


