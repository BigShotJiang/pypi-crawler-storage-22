"""Syke — Personal context daemon."""

__version__ = "0.1.0"
