import os
import inspect

from sylriekit.LLM import LLM
from sylriekit.Template import Template


class SlopPyCode:
    CODE_GENERATION_PROMPT = """Generate a Python function that does the following:

{pseudocode}

The function must:
1. Be named `sloppy_execute`
2. Accept these parameters: {input_params}
3. Return a dictionary with these keys and their expected types: {output_params}

ONLY output the Python function code, nothing else. No explanations, no markdown code blocks.
The function should be complete and executable.

Example format:
def sloppy_execute({example_params}):
    # implementation
    return {example_return}"""

    CACHE_FOLDER_NAME = "__SlopPyCache__"
    CACHE_INDEX = 0
    TEMPLATE_PROFILE = None
    PROVIDER = None
    MODEL = None
    API_KEY = None

    @classmethod
    def load_config(cls, config: dict):
        api_keys = config.get("api_key", {})
        env_variables = config.get("env", {})
        if "SlopPyCode" in config.keys():
            sloppy_config = config["SlopPyCode"]
            cls.CACHE_INDEX = sloppy_config.get("CACHE_INDEX", cls.CACHE_INDEX)
            cls.CACHE_FOLDER_NAME = sloppy_config.get("CACHE_FOLDER_NAME", cls.CACHE_FOLDER_NAME)
            cls.PROVIDER = sloppy_config.get("PROVIDER", cls.PROVIDER)
            cls.MODEL = sloppy_config.get("MODEL", cls.MODEL)
        cls._ensure_cache_folder()

    @classmethod
    def use_cache_index(cls, new_index: int):
        cls.CACHE_INDEX = new_index

    @classmethod
    def use_ai(cls, provider: str, model: str, key: str = None):
        cls.PROVIDER = provider
        cls.MODEL = model
        if key is not None:
            cls.API_KEY = key

    @classmethod
    def use_template_profile(cls, profile_id: str):
        cls.TEMPLATE_PROFILE = profile_id

    @classmethod
    def run(cls, pseudocode: str, input_args: dict, output: dict, forced_index: int = None) -> dict:
        cls._ensure_ai_configured()
        cls._ensure_cache_folder()

        if forced_index is not None:
            index = forced_index
        else:
            index = cls.CACHE_INDEX
            cls.CACHE_INDEX += 1

        cache_file_path = cls._get_cache_file_path(index)

        if os.path.exists(cache_file_path):
            return cls._run_cached(cache_file_path, input_args, output)

        generated_code = cls._generate_code(pseudocode, input_args, output)
        cls._save_to_cache(cache_file_path, generated_code)

        return cls._run_cached(cache_file_path, input_args, output)

    ### PRIVATE UTILITIES START
    @classmethod
    def _ensure_cache_folder(cls):
        caller_dir = cls._get_caller_directory()
        cache_path = os.path.join(caller_dir, cls.CACHE_FOLDER_NAME)
        if not os.path.exists(cache_path):
            os.makedirs(cache_path)

    @classmethod
    def _get_caller_directory(cls) -> str:
        stack = inspect.stack()
        for frame_info in stack:
            if frame_info.filename != __file__:
                return os.path.dirname(os.path.abspath(frame_info.filename))
        return os.getcwd()

    @classmethod
    def _get_cache_file_path(cls, index: int) -> str:
        caller_dir = cls._get_caller_directory()
        cache_folder = os.path.join(caller_dir, cls.CACHE_FOLDER_NAME)
        return os.path.join(cache_folder, f"{index}.py")

    @classmethod
    def _ensure_ai_configured(cls):
        if cls.PROVIDER is None or cls.MODEL is None:
            raise ValueError("AI not configured. Call use_ai(provider, model, key) before running.")

    @classmethod
    def _generate_code(cls, pseudocode: str, input_args: dict, output: dict) -> str:
        input_params = cls._format_input_params(input_args)
        output_params = cls._format_output_params(output)
        example_params = ", ".join(cls._extract_param_names(input_args))
        example_return = "{" + ", ".join(f'"{k}": {k}' for k in output.keys()) + "}"

        prompt = cls.CODE_GENERATION_PROMPT.format(
            pseudocode=pseudocode.strip(),
            input_params=input_params,
            output_params=output_params,
            example_params=example_params,
            example_return=example_return
        )

        LLM.use_provider(cls.PROVIDER)
        LLM.use_model(cls.MODEL)
        if cls.API_KEY is not None:
            LLM.use_key(cls.API_KEY)

        chat_id = LLM.generate_chat()
        LLM.use_chat(chat_id)

        response = LLM.send(prompt)
        return cls._clean_generated_code(response)

    @classmethod
    def _format_input_params(cls, input_args: dict) -> str:
        params = []
        for key, value in input_args.items():
            if ":" in key:
                param_name, param_type = key.rsplit(":", 1)
                params.append(f"{param_name}: {param_type}")
            else:
                params.append(key)
        return ", ".join(params)

    @classmethod
    def _format_output_params(cls, output: dict) -> str:
        return ", ".join(f"{k}: {v}" for k, v in output.items())

    @classmethod
    def _extract_param_names(cls, input_args: dict) -> list:
        names = []
        for key in input_args.keys():
            if ":" in key:
                param_name, _ = key.rsplit(":", 1)
                names.append(param_name)
            else:
                names.append(key)
        return names

    @classmethod
    def _clean_generated_code(cls, response: str) -> str:
        code = response.strip()
        if code.startswith("```python"):
            code = code[9:]
        elif code.startswith("```"):
            code = code[3:]
        if code.endswith("```"):
            code = code[:-3]
        return code.strip()

    @classmethod
    def _save_to_cache(cls, file_path: str, code: str):
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(code)

    @classmethod
    def _run_cached(cls, cache_file_path: str, input_args: dict, output: dict) -> dict:
        with open(cache_file_path, "r", encoding="utf-8") as f:
            cached_code = f.read()

        param_names = cls._extract_param_names(input_args)
        param_values = list(input_args.values())

        context_data = dict(zip(param_names, param_values))

        execution_code = cached_code + "\n" + f"sloppyresult = sloppy_execute({', '.join(param_names)})"

        if cls.TEMPLATE_PROFILE is not None:
            Template.PROFILES[cls.TEMPLATE_PROFILE]["context"].update(context_data)
            template_id = f"sloppycode_{id(cache_file_path)}"
            Template.register_template(template_id, execution_code)
            local_vars = Template.run(
                template_id,
                profile=cls.TEMPLATE_PROFILE,
                update_context=False,
                timeout=0
            )
            result = local_vars.get("sloppyresult", {})
        else:
            local_vars = {"__builtins__": __builtins__}
            local_vars.update(context_data)
            exec(execution_code, local_vars)
            result = local_vars.get("sloppyresult", {})

        output_result = {}
        for key in output.keys():
            if isinstance(result, dict) and key in result:
                output_result[key] = result[key]

        return output_result
    ### PRIVATE UTILITIES END


if __name__ == "__main__":
    SlopPyCode.use_ai("openai", "gpt-5-mini-2025-08-07", "sk-proj-8O...")

    val1 = 1
    val2 = 2
    val3 = "4"
    print("Starting Slop Py Code Creation:")
    result = SlopPyCode.run(
        """
        Add arg1 and arg2 together, then convert arg3 to an integer
        if arg3 is a valid number string, otherwise use 0.
        Return the sum of all three as val3.
        """,
        input_args={"arg1:int": val1, "arg2:int": val2, "arg3": val3},
        output={"val3": "int"},
        forced_index=0
    )
    print(result)
    print("FIN")