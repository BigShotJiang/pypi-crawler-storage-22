def sloppy_execute(arg1, arg2, arg3):
    total = arg1 + arg2
    arg3_int = 0
    if isinstance(arg3, str):
        s = arg3.strip()
        try:
            arg3_int = int(s)
        except Exception:
            arg3_int = 0
    val3 = total + arg3_int
    return {"val3": val3}