//! Rule infrastructure for the simplification engine
//!
//! Provides macros (`rule!`, `rule_with_helpers!`), traits (`Rule`), and registry
//! for defining and organizing simplification rules by category and priority.

use crate::Expr;
use crate::ExprKind as AstKind;
use crate::core::unified_context::BodyFn;
use std::collections::HashMap;
use std::sync::Arc;

/// Macro to define a simplification rule with minimal boilerplate
///
/// Supports 4 forms:
/// - Basic: `rule!(Name, "name", priority, Category, &[ExprKind::...], |expr, ctx| { ... })`
/// - With targets: `rule!(Name, "name", priority, Category, &[ExprKind::...], targets: &["fn"], |expr, ctx| { ... })`
/// - With `alters_domain`: `rule!(Name, "name", priority, Category, &[ExprKind::...], alters_domain: true, |expr, ctx| { ... })`
/// - Both: `rule!(Name, "name", priority, Category, &[ExprKind::...], alters_domain: true, targets: &["fn"], |expr, ctx| { ... })`
macro_rules! rule {
    // Basic form
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context).map(std::sync::Arc::new)
            }
        }
    };
    // With targets
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, targets: $targets:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn target_functions(&self) -> Vec<u64> {
                $targets.to_vec()
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context).map(std::sync::Arc::new)
            }
        }
    };
    // With alters_domain
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, alters_domain: $alters:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn alters_domain(&self) -> bool {
                $alters
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context).map(std::sync::Arc::new)
            }
        }
    };
    // With alters_domain AND targets
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, alters_domain: $alters:expr, targets: $targets:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn alters_domain(&self) -> bool {
                $alters
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn target_functions(&self) -> Vec<u64> {
                $targets.to_vec()
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context).map(std::sync::Arc::new)
            }
        }
    };
}

/// Macro to define a simplification rule that returns `Option<Arc<Expr>>` directly.
/// This avoids unnecessary wrapping when the result is already an Arc.
macro_rules! rule_arc {
    // Basic form
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context)
            }
        }
    };
    // With targets
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, targets: $targets:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn target_functions(&self) -> Vec<u64> {
                $targets.to_vec()
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context)
            }
        }
    };
    // With alters_domain
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, alters_domain: $alters:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn alters_domain(&self) -> bool {
                $alters
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context)
            }
        }
    };
    // With alters_domain AND targets
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, alters_domain: $alters:expr, targets: $targets:expr, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str {
                $rule_name
            }
            fn priority(&self) -> i32 {
                $priority
            }
            fn category(&self) -> RuleCategory {
                RuleCategory::$category
            }
            fn alters_domain(&self) -> bool {
                $alters
            }
            fn applies_to(&self) -> &'static [ExprKind] {
                $applies_to
            }
            fn target_functions(&self) -> Vec<u64> {
                $targets.to_vec()
            }
            fn apply(
                &self,
                expr: &std::sync::Arc<Expr>,
                context: &RuleContext,
            ) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                ($logic)(expr.as_ref(), context)
            }
        }
    };
}

/// Macro for rules with helpers that return `Option<Arc<Expr>>` directly
macro_rules! rule_with_helpers_arc {
    // Basic form
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, helpers: { $($helper:item)* }, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str { $rule_name }
            fn priority(&self) -> i32 { $priority }
            fn category(&self) -> RuleCategory { RuleCategory::$category }
            fn applies_to(&self) -> &'static [ExprKind] { $applies_to }
            fn apply(&self, expr: &std::sync::Arc<Expr>, context: &RuleContext) -> Option<std::sync::Arc<Expr>> {
                $($helper)*
                let _ = context;
                ($logic)(expr.as_ref(), context)
            }
        }
    };
    // With alters_domain
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, alters_domain: $alters:expr, helpers: { $($helper:item)* }, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str { $rule_name }
            fn priority(&self) -> i32 { $priority }
            fn category(&self) -> RuleCategory { RuleCategory::$category }
            fn alters_domain(&self) -> bool { $alters }
            fn applies_to(&self) -> &'static [ExprKind] { $applies_to }
            fn apply(&self, expr: &std::sync::Arc<Expr>, context: &RuleContext) -> Option<std::sync::Arc<Expr>> {
                $($helper)*
                let _ = context;
                ($logic)(expr.as_ref(), context)
            }
        }
    };
}

/// Macro for rules with helpers that wrap result in Arc
macro_rules! rule_with_helpers {
    // Basic form
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, helpers: { $($helper:item)* }, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str { $rule_name }
            fn priority(&self) -> i32 { $priority }
            fn category(&self) -> RuleCategory { RuleCategory::$category }
            fn applies_to(&self) -> &'static [ExprKind] { $applies_to }
            fn apply(&self, expr: &std::sync::Arc<Expr>, context: &RuleContext) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                $($helper)*
                ($logic)(expr.as_ref(), context).map(std::sync::Arc::new)
            }
        }
    };
    // With alters_domain
    ($name:ident, $rule_name:expr, $priority:expr, $category:ident, $applies_to:expr, alters_domain: $alters:expr, helpers: { $($helper:item)* }, $logic:expr) => {
        pub struct $name;
        impl Rule for $name {
            fn name(&self) -> &'static str { $rule_name }
            fn priority(&self) -> i32 { $priority }
            fn category(&self) -> RuleCategory { RuleCategory::$category }
            fn alters_domain(&self) -> bool { $alters }
            fn applies_to(&self) -> &'static [ExprKind] { $applies_to }
            fn apply(&self, expr: &std::sync::Arc<Expr>, context: &RuleContext) -> Option<std::sync::Arc<Expr>> {
                let _ = context;
                $($helper)*
                ($logic)(expr.as_ref(), context).map(std::sync::Arc::new)
            }
        }
    };
}

/// Expression kind for fast rule filtering
/// Rules declare which expression kinds they can apply to
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum ExprKind {
    /// Numeric literal
    Number,
    /// Symbolic variable
    Symbol,
    /// N-ary addition
    Sum,
    /// N-ary multiplication
    Product,
    /// Division
    Div,
    /// Power/exponentiation
    Pow,
    /// Any function call
    Function,
    /// Partial derivative expression
    Derivative,
    /// Polynomial (don't trigger Sum rules)
    Poly,
}

impl ExprKind {
    /// Get the kind of an expression (cheap O(1) operation)
    #[inline]
    pub const fn of(expr: &Expr) -> Self {
        match &expr.kind {
            AstKind::Number(_) => Self::Number,
            AstKind::Symbol(_) => Self::Symbol,
            AstKind::Sum(_) => Self::Sum,
            AstKind::Product(_) => Self::Product,
            AstKind::Div(_, _) => Self::Div,
            AstKind::Pow(_, _) => Self::Pow,
            AstKind::FunctionCall { .. } => Self::Function,
            AstKind::Derivative { .. } => Self::Derivative,
            AstKind::Poly(_) => Self::Poly, // Poly has its own rules, don't trigger Sum rules
        }
    }
}

/// Core trait for all simplification rules
pub trait Rule {
    /// Returns the unique name of this rule
    fn name(&self) -> &'static str;
    /// Returns the priority of this rule (higher = applied first)
    fn priority(&self) -> i32;
    #[allow(
        dead_code,
        reason = "Legacy for categorizzation maybe useful in the future"
    )]
    /// Returns the category of this rule
    fn category(&self) -> RuleCategory;

    /// Returns whether this rule alters the domain of the expression (e.g., by removing singularities)
    fn alters_domain(&self) -> bool {
        false
    }

    /// Which expression kinds this rule can apply to.
    /// Rules will ONLY be checked against expressions matching these kinds.
    /// Default: all kinds (for backwards compatibility during migration)
    fn applies_to(&self) -> &'static [ExprKind] {
        ALL_EXPR_KINDS
    }

    /// Optimized Dispatch: List of function names this rule targets.
    /// If non-empty, the rule is ONLY checked for `FunctionCall` nodes with these names.
    /// If empty, it is checked for ALL `FunctionCall` nodes (generic rules).
    fn target_functions(&self) -> Vec<u64> {
        Vec::new()
    }

    /// Apply this rule to an expression. Returns `Some(new_expr)` if transformation applied.
    /// Takes &`Arc<Expr>` for efficient sub-expression cloning (`Arc::clone` is cheap).
    fn apply(&self, expr: &Arc<Expr>, context: &RuleContext) -> Option<Arc<Expr>>;
}

/// Categories of simplification rules
#[allow(
    dead_code,
    reason = "Legacy for categorizzation maybe useful in the future"
)]
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum RuleCategory {
    /// Constant folding, identities
    Numeric,
    /// General algebraic rules
    Algebraic,
    /// Trigonometric identities and simplifications
    Trigonometric,
    /// Hyperbolic function rules
    Hyperbolic,
    /// Exponential and logarithmic rules
    Exponential,
    /// Root and radical simplifications
    Root,
}

/// All expression kinds - used as default for rules
pub const ALL_EXPR_KINDS: &[ExprKind] = &[
    ExprKind::Number,
    ExprKind::Symbol,
    ExprKind::Sum,
    ExprKind::Product,
    ExprKind::Div,
    ExprKind::Pow,
    ExprKind::Function,
    ExprKind::Derivative,
    ExprKind::Poly,
];

/// Priority ranges for different types of operations:
/// - 85-95: Expansion rules (distribute, expand powers, flatten nested structures)
/// - 70-84: Identity/Cancellation rules (x/x=1, x-x=0, x^a/x^b=x^(a-b), etc.)
/// - 40-69: Compression/Consolidation rules (combine terms, factor, compact a^n/b^n → (a/b)^n)
/// - 1-39: Canonicalization rules (sort terms, normalize display form)
///
/// Context passed to rules during application
/// Uses `Arc<HashSet>` for cheap cloning (context is cloned per-node)
#[derive(Clone, Default)]
pub struct RuleContext {
    /// Current recursion depth in the expression tree
    pub depth: usize,
    /// Whether to apply only domain-safe transformations
    pub domain_safe: bool,
    /// Custom function body definitions
    pub custom_bodies: Arc<HashMap<u64, BodyFn>>,
}

impl std::fmt::Debug for RuleContext {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("RuleContext")
            .field("depth", &self.depth)
            .field("domain_safe", &self.domain_safe)
            .field(
                "custom_bodies",
                &format!("<{} functions>", self.custom_bodies.len()),
            )
            .finish()
    }
}

impl RuleContext {
    /// Set depth by mutable reference (avoids clone)
    #[inline]
    pub const fn set_depth(&mut self, depth: usize) {
        self.depth = depth;
    }

    /// Sets the custom function bodies for this context.
    pub fn with_custom_bodies(mut self, custom_bodies: HashMap<u64, BodyFn>) -> Self {
        self.custom_bodies = Arc::new(custom_bodies);
        self
    }
}

/// Numeric simplification rules
pub mod numeric;

/// Algebraic simplification rules
pub mod algebraic;

/// Trigonometric simplification rules
pub mod trigonometric;

/// Exponential and logarithmic simplification rules
pub mod exponential;

/// Root simplification rules
pub mod root;

/// Hyperbolic function simplification rules
pub mod hyperbolic;

/// Rule Registry for dynamic loading and dependency management
pub struct RuleRegistry {
    /// All loaded rules in priority order
    pub(crate) rules: Vec<Arc<dyn Rule + Send + Sync>>,
    /// Rules indexed by expression kind for fast lookup
    rules_by_kind: HashMap<ExprKind, Vec<Arc<dyn Rule + Send + Sync>>>,
    /// Rules indexed by function name ID (u64) for O(1) dispatch
    /// Maps function symbol ID -> List of rules that target it SPECIFICALLY
    rules_by_func: HashMap<u64, Vec<Arc<dyn Rule + Send + Sync>>>,
    /// Generic function rules that must run for ALL functions
    generic_func_rules: Vec<Arc<dyn Rule + Send + Sync>>,
}

impl RuleRegistry {
    /// Creates a new empty rule registry.
    pub fn new() -> Self {
        Self {
            rules: Vec::new(),
            rules_by_kind: HashMap::new(),
            rules_by_func: HashMap::new(),
            generic_func_rules: Vec::new(),
        }
    }

    /// Loads all available simplification rules into the registry.
    pub fn load_all_rules(&mut self) {
        // Load rules from each category
        self.rules.extend(numeric::get_numeric_rules());
        self.rules.extend(algebraic::get_algebraic_rules());
        self.rules.extend(trigonometric::get_trigonometric_rules());
        self.rules.extend(exponential::get_exponential_rules());
        self.rules.extend(root::get_root_rules());
        self.rules.extend(hyperbolic::get_hyperbolic_rules());
        // Note: Rules are sorted by priority in order_by_dependencies()
    }

    /// Build the kind index after ordering rules
    pub fn order_by_dependencies(&mut self) {
        // Sort by priority descending (higher priority runs first)
        // Rules are processed by ExprKind separately, so category order doesn't matter
        self.rules.sort_by_key(|r| std::cmp::Reverse(r.priority()));

        self.build_kind_index();
    }

    /// Build the index of rules by expression kind
    fn build_kind_index(&mut self) {
        self.rules_by_kind.clear();

        // Initialize all kinds
        for &kind in ALL_EXPR_KINDS {
            self.rules_by_kind.insert(kind, Vec::new());
        }

        // Index each rule by the kinds it applies to
        for rule in &self.rules {
            for &kind in rule.applies_to() {
                if let Some(rules) = self.rules_by_kind.get_mut(&kind) {
                    rules.push(Arc::clone(rule));
                }

                // Special indexing for Function kind
                if kind == ExprKind::Function {
                    let targets = rule.target_functions();
                    if targets.is_empty() {
                        self.generic_func_rules.push(Arc::clone(rule));
                    } else {
                        for fid in targets {
                            self.rules_by_func
                                .entry(fid)
                                .or_default()
                                .push(Arc::clone(rule));
                        }
                    }
                }
            }
        }

        // Ensure generic rules are also sorted? They are processed in insertion order which is priority sorted.
    }

    /// Get only rules that apply to a specific expression kind
    #[inline]
    pub fn get_rules_for_kind(&self, kind: ExprKind) -> &[Arc<dyn Rule + Send + Sync>] {
        self.rules_by_kind
            .get(&kind)
            .map_or(&[], std::vec::Vec::as_slice)
    }

    #[inline]
    /// Gets rules that specifically target the given function ID.
    pub fn get_specific_func_rules(&self, func_id: u64) -> &[Arc<dyn Rule + Send + Sync>] {
        self.rules_by_func
            .get(&func_id)
            .map_or(&[], std::vec::Vec::as_slice)
    }

    #[inline]
    /// Gets generic function rules that apply to all functions.
    pub fn get_generic_func_rules(&self) -> &[Arc<dyn Rule + Send + Sync>] {
        &self.generic_func_rules
    }
}
