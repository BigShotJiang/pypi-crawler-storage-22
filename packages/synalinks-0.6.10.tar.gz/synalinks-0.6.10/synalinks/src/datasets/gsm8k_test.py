# from synalinks.src import testing
# from synalinks.src.datasets.gsm8k import load_data


# class GSM8kTest(testing.TestCase):
#     def test_load_data(self):
#         (x_train, y_train), (x_test, y_test) = load_data()
#         self.assertTrue(len(x_train) > 0)
#         self.assertTrue(len(y_train) > 0)
#         self.assertTrue(len(x_test) > 0)
#         self.assertTrue(len(y_test) > 0)
