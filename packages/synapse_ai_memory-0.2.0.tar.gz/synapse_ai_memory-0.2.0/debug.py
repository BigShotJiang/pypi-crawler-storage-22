#!/usr/bin/env python3
"""Debug script to test basic Synapse V2 functionality."""

import math
from synapse import Synapse

def test_basic_recall():
    print("=== Testing Basic Recall ===")
    s = Synapse(":memory:")
    
    # Add some memories
    m1 = s.remember("Python is a programming language", "fact")
    m2 = s.remember("Cats are fluffy animals", "fact") 
    m3 = s.remember("Python snakes are long", "fact")
    
    print(f"Added memories: {m1.id}, {m2.id}, {m3.id}")
    
    # Check if they're in storage
    print(f"Total memories in storage: {len(s.store.memories)}")
    for mid, mem in s.store.memories.items():
        print(f"  Memory {mid}: {mem['content']}")
    
    # Check inverted index
    print(f"Inverted index has {len(s.inverted_index.index)} terms")
    print(f"Document lengths: {s.inverted_index.doc_lengths}")
    print(f"Total docs: {s.inverted_index.total_docs}")
    print(f"Index terms: {list(s.inverted_index.index.keys())}")
    
    # Test tokenization
    query = "Python"
    tokens = s.inverted_index.tokenize_for_query(query)
    print(f"Query '{query}' tokenizes to: {tokens}")
    
    # Check if token is in index
    for token in tokens:
        if token in s.inverted_index.index:
            print(f"  Token '{token}' found in index: {s.inverted_index.index[token]}")
        else:
            print(f"  Token '{token}' NOT found in index")
    
    # Test BM25 scoring manually
    for token in tokens:
        if token in s.inverted_index.index:
            candidates = s.inverted_index.index[token].keys()
            print(f"  Candidates for '{token}': {list(candidates)}")
            for memory_id in candidates:
                score = s.inverted_index.bm25_score([token], memory_id)
                print(f"    Memory {memory_id} BM25 score: {score}")
                
                # Debug BM25 components
                tf = s.inverted_index.get_term_frequency(token, memory_id)
                df = s.inverted_index.get_document_frequency(token)
                doc_length = s.inverted_index.doc_lengths[memory_id]
                avg_len = s.inverted_index.avg_doc_length
                
                print(f"      tf={tf}, df={df}, doc_len={doc_length}, avg_len={avg_len}")
                print(f"      total_docs={s.inverted_index.total_docs}")
                
                # Manual IDF calculation
                idf = math.log((s.inverted_index.total_docs - df + 0.5) / (df + 0.5))
                print(f"      idf={idf}")
    
    # Test BM25 candidates
    bm25_scores = s.inverted_index.get_candidates(tokens)
    print(f"BM25 candidates: {bm25_scores}")
    
    # Test recall
    results = s.recall("Python")
    print(f"Recall results: {len(results)} memories")
    for r in results:
        print(f"  {r.id}: {r.content} (strength: {r.effective_strength})")
    
    s.close()

def test_concept_extraction():
    print("\n=== Testing Concept Extraction ===")
    
    from entity_graph import extract_concepts
    
    content = "I love programming in Python with machine learning"
    concepts = extract_concepts(content)
    print(f"Content: {content}")
    print(f"Extracted concepts: {concepts}")

if __name__ == "__main__":
    test_basic_recall()
    test_concept_extraction()