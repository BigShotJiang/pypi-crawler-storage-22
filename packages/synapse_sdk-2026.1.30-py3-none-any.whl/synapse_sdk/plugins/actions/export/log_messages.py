"""Export log message codes for user-facing UI messages."""

from __future__ import annotations

from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class ExportLogMessageCode(LogMessageCode):
    """Log message codes for export workflows."""

    EXPORT_INITIALIZED = ('EXPORT_INITIALIZED', LogLevel.INFO)
    EXPORT_NO_RESULTS = ('EXPORT_NO_RESULTS', LogLevel.WARNING)
    EXPORT_RESULTS_FETCHED = ('EXPORT_RESULTS_FETCHED', LogLevel.INFO)
    EXPORT_CONVERTING = ('EXPORT_CONVERTING', LogLevel.INFO)
    EXPORT_CONVERTED = ('EXPORT_CONVERTED', LogLevel.INFO)
    EXPORT_SAVING_FILES = ('EXPORT_SAVING_FILES', LogLevel.INFO)
    EXPORT_FILES_SAVED = ('EXPORT_FILES_SAVED', LogLevel.INFO)
    EXPORT_FILES_SAVED_WITH_FAILURES = ('EXPORT_FILES_SAVED_WITH_FAILURES', LogLevel.WARNING)
    EXPORT_COMPLETED = ('EXPORT_COMPLETED', LogLevel.SUCCESS)
    EXPORT_COMPLETED_WITH_FAILURES = ('EXPORT_COMPLETED_WITH_FAILURES', LogLevel.WARNING)
    EXPORT_SAVING_ORIGINAL = ('EXPORT_SAVING_ORIGINAL', LogLevel.INFO)
    EXPORT_SAVING_JSON = ('EXPORT_SAVING_JSON', LogLevel.INFO)
    EXPORT_STARTING = ('EXPORT_STARTING', LogLevel.INFO)
    EXPORT_CONVERTING_DATASET = ('EXPORT_CONVERTING_DATASET', LogLevel.INFO)


register_log_messages({
    ExportLogMessageCode.EXPORT_INITIALIZED: 'Export storage and paths initialized',
    ExportLogMessageCode.EXPORT_NO_RESULTS: 'No results found for export',
    ExportLogMessageCode.EXPORT_RESULTS_FETCHED: 'Retrieved {count} results for export',
    ExportLogMessageCode.EXPORT_CONVERTING: 'Converting {count} items',
    ExportLogMessageCode.EXPORT_CONVERTED: 'Converted {count} items',
    ExportLogMessageCode.EXPORT_SAVING_FILES: 'Saving {count} files',
    ExportLogMessageCode.EXPORT_FILES_SAVED: 'Saved {count} files',
    ExportLogMessageCode.EXPORT_FILES_SAVED_WITH_FAILURES: 'Saved {success} files, {failed} failed',
    ExportLogMessageCode.EXPORT_COMPLETED: 'Export complete: {count} items exported',
    ExportLogMessageCode.EXPORT_COMPLETED_WITH_FAILURES: 'Export complete: {exported} exported, {failed} failed',
    ExportLogMessageCode.EXPORT_SAVING_ORIGINAL: 'Saving original file.',
    ExportLogMessageCode.EXPORT_SAVING_JSON: 'Saving json file.',
    ExportLogMessageCode.EXPORT_STARTING: 'Starting export process.',
    ExportLogMessageCode.EXPORT_CONVERTING_DATASET: 'Converting dataset.',
})


__all__ = ['ExportLogMessageCode']
