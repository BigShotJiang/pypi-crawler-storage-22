"""To-task log message codes for user-facing UI messages."""

from __future__ import annotations

from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class ToTaskLogMessageCode(LogMessageCode):
    """Log message codes for to-task workflows."""

    # Initialization
    TASK_INITIALIZING = ('TASK_INITIALIZING', LogLevel.INFO)
    TASK_DATA_COLLECTION_LOADED = ('TASK_DATA_COLLECTION_LOADED', LogLevel.INFO)

    # Preparation
    TASK_PREPARING_FILE_METHOD = ('TASK_PREPARING_FILE_METHOD', LogLevel.INFO)
    TASK_PREPARING_INFERENCE_METHOD = ('TASK_PREPARING_INFERENCE_METHOD', LogLevel.INFO)
    TASK_SPECIFICATION_VALIDATED = ('TASK_SPECIFICATION_VALIDATED', LogLevel.INFO)
    TASK_INFERENCE_PARAMS_VALIDATING = ('TASK_INFERENCE_PARAMS_VALIDATING', LogLevel.INFO)
    TASK_INFERENCE_PARAMS_VALIDATED = ('TASK_INFERENCE_PARAMS_VALIDATED', LogLevel.INFO)
    TASK_PREPROCESSOR_RELEASE_FETCHING = ('TASK_PREPROCESSOR_RELEASE_FETCHING', LogLevel.INFO)
    TASK_PREPROCESSOR_RELEASE_FETCHED = ('TASK_PREPROCESSOR_RELEASE_FETCHED', LogLevel.INFO)
    TASK_PREPROCESSOR_CHECKING = ('TASK_PREPROCESSOR_CHECKING', LogLevel.INFO)
    TASK_PREPROCESSOR_ALREADY_RUNNING = ('TASK_PREPROCESSOR_ALREADY_RUNNING', LogLevel.INFO)
    TASK_DATA_PREPROCESSOR_DEPLOYING = ('TASK_DATA_PREPROCESSOR_DEPLOYING', LogLevel.WARNING)
    TASK_PREPROCESSOR_WAITING = ('TASK_PREPROCESSOR_WAITING', LogLevel.INFO)
    TASK_PREPROCESSOR_WAITING_PROGRESS = ('TASK_PREPROCESSOR_WAITING_PROGRESS', LogLevel.INFO)
    TASK_PREPROCESSOR_READY = ('TASK_PREPROCESSOR_READY', LogLevel.SUCCESS)
    TASK_INFERENCE_CONTEXT_READY = ('TASK_INFERENCE_CONTEXT_READY', LogLevel.SUCCESS)

    # Fetching
    TASK_FETCHING_TASKS = ('TASK_FETCHING_TASKS', LogLevel.INFO)
    TASK_TASKS_FETCHED = ('TASK_TASKS_FETCHED', LogLevel.INFO)

    # Processing
    TASK_DATA_ANNOTATING = ('TASK_DATA_ANNOTATING', LogLevel.INFO)
    TASK_DATA_COMPLETED = ('TASK_DATA_COMPLETED', LogLevel.SUCCESS)
    TASK_DATA_COMPLETED_WITH_FAILURES = ('TASK_DATA_COMPLETED_WITH_FAILURES', LogLevel.WARNING)

    # Finalization
    TASK_FINALIZING = ('TASK_FINALIZING', LogLevel.INFO)


register_log_messages({
    # Initialization
    ToTaskLogMessageCode.TASK_INITIALIZING: 'Initializing to_task workflow',
    ToTaskLogMessageCode.TASK_DATA_COLLECTION_LOADED: 'Data collection loaded successfully',
    # Preparation
    ToTaskLogMessageCode.TASK_PREPARING_FILE_METHOD: 'Preparing file-based annotation',
    ToTaskLogMessageCode.TASK_PREPARING_INFERENCE_METHOD: 'Preparing inference-based annotation',
    ToTaskLogMessageCode.TASK_SPECIFICATION_VALIDATED: 'Target specification validated',
    ToTaskLogMessageCode.TASK_INFERENCE_PARAMS_VALIDATING: 'Validating inference parameters',
    ToTaskLogMessageCode.TASK_INFERENCE_PARAMS_VALIDATED: 'Parameters validated: {pre_processor}, {model}',
    ToTaskLogMessageCode.TASK_PREPROCESSOR_RELEASE_FETCHING: 'Fetching pre-processor: {pre_processor}',
    ToTaskLogMessageCode.TASK_PREPROCESSOR_RELEASE_FETCHED: 'Release fetched: {plugin_code} v{version}',
    ToTaskLogMessageCode.TASK_PREPROCESSOR_CHECKING: 'Checking pre-processor status',
    ToTaskLogMessageCode.TASK_PREPROCESSOR_ALREADY_RUNNING: 'Pre-processor already running',
    ToTaskLogMessageCode.TASK_DATA_PREPROCESSOR_DEPLOYING: 'Starting pre-processor deployment',
    ToTaskLogMessageCode.TASK_PREPROCESSOR_WAITING: 'Waiting for pre-processor to be ready',
    ToTaskLogMessageCode.TASK_PREPROCESSOR_WAITING_PROGRESS: 'Still waiting... ({elapsed_seconds}s elapsed)',
    ToTaskLogMessageCode.TASK_PREPROCESSOR_READY: 'Pre-processor is ready',
    ToTaskLogMessageCode.TASK_INFERENCE_CONTEXT_READY: 'Inference context prepared successfully',
    # Fetching
    ToTaskLogMessageCode.TASK_FETCHING_TASKS: 'Fetching task list',
    ToTaskLogMessageCode.TASK_TASKS_FETCHED: 'Fetched {count} tasks for annotation',
    # Processing
    ToTaskLogMessageCode.TASK_DATA_ANNOTATING: 'Annotating {count} tasks ({method} method)',
    ToTaskLogMessageCode.TASK_DATA_COMPLETED: 'Annotation complete: {count} tasks annotated',
    ToTaskLogMessageCode.TASK_DATA_COMPLETED_WITH_FAILURES: 'Annotation complete: {success} succeeded, {failed} failed',
    # Finalization
    ToTaskLogMessageCode.TASK_FINALIZING: 'Finalizing annotation results',
})


__all__ = ['ToTaskLogMessageCode']
