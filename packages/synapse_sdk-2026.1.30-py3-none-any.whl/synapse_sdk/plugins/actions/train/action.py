"""Train action base class with optional step support."""

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypeVar

from pydantic import BaseModel, Field, model_validator

from synapse_sdk.plugins.action import BaseAction
from synapse_sdk.plugins.actions.train.context import TrainContext
from synapse_sdk.plugins.enums import PluginCategory
from synapse_sdk.plugins.steps import BaseStep, Orchestrator, StepRegistry, StepResult

P = TypeVar('P', bound=BaseModel)

logger = logging.getLogger(__name__)

# Lazy base class for tune callback — avoids hard dependency on ray
try:
    from ray.tune import Callback as _TuneCallbackBase
except ImportError:
    _TuneCallbackBase = object  # type: ignore[misc,assignment]

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient
    from synapse_sdk.plugins.actions.train.log_messages import TrainLogMessageCode


class BaseTrainParams(BaseModel):
    """Base parameters for training actions.

    Provides common fields used across training workflows.
    Extend this class to add plugin-specific training parameters.

    Attributes:
        dataset: Ground truth dataset ID to download from Synapse.
        splits: Optional split definitions for train/valid/test.
        checkpoint: Optional model ID to use as starting checkpoint.
        is_tune: Whether this is a hyperparameter tuning run (backend field).
        hyperparameters: Optional list of hyperparameter dicts from backend.
            When provided, hyperparameters[0] is flattened to top-level fields.

    Example:
        >>> class MyTrainParams(BaseTrainParams):
        ...     epochs: int = 100
        ...     batch_size: int = 32
    """

    dataset: int = Field(description='Synapse ground truth dataset ID')
    splits: dict[str, Any] | None = Field(
        default=None,
        description='Split definitions: {"train": {...filters}, "valid": {...}}',
    )
    checkpoint: int | None = Field(default=None, description='Checkpoint model ID to resume from')
    is_tune: bool = Field(default=False, description='Hyperparameter tuning mode (requires tune_config)')
    hyperparameters: list[dict[str, Any]] | None = Field(
        default=None,
        description='Hyperparameters list from backend (hyperparameters[0] is flattened to top-level)',
    )

    model_config = {'extra': 'allow'}

    @model_validator(mode='before')
    @classmethod
    def flatten_hyperparameters(cls, data: Any) -> Any:
        """Flatten hyperparameters[0] fields to top level for backend compatibility.

        For normal training, the backend sends resolved values:
            {"dataset": 176, "hyperparameters": [{"epochs": 10, "batch_size": 8}]}
        This validator flattens hyperparameters[0] to top level:
            {"dataset": 176, "epochs": 10, "batch_size": 8, "hyperparameters": [...]}

        For tune mode (is_tune=True), hyperparameters contain search space definitions:
            [{"name": "epochs", "type": "randint", "min": 5, "max": 10}, ...]
        In this case, flattening is skipped — the search space is consumed by
        _run_tune() to build Ray Tune param_space instead.
        """
        if not isinstance(data, dict):
            return data

        # Skip flattening for tune mode — hyperparameters are search space definitions
        if data.get('is_tune'):
            return data

        hyperparams = data.get('hyperparameters')
        if hyperparams and isinstance(hyperparams, list) and len(hyperparams) > 0:
            first_hp = hyperparams[0]
            if isinstance(first_hp, dict):
                for key, value in first_hp.items():
                    # Only set if not already present at top level
                    if key not in data:
                        data[key] = value

        return data


class BaseTrainAction(BaseAction[P]):
    """Base class for training actions.

    Provides a simplified API for training workflows. Plugin developers
    only need to:
    1. Set `target_format` class attribute (e.g., 'yolo')
    2. Override `execute(data_path, checkpoint)` with training logic

    The SDK automatically handles:
    - Dataset export from Synapse (if `dataset` in params)
    - Dataset conversion to target format
    - Step orchestration and progress tracking

    Attributes:
        category: Plugin category (defaults to NEURAL_NET).
        target_format: Dataset format for conversion (e.g., 'yolo', 'coco').
            Set this to enable automatic dataset conversion.

    Example (minimal - recommended):
        >>> class TrainAction(BaseTrainAction[TrainParams]):
        ...     target_format = 'yolo'  # Auto-converts dataset to YOLO format
        ...     result_model = TrainResult
        ...
        ...     def execute(self, data_path: Path, checkpoint: dict) -> TrainResult:
        ...         model = YOLO(checkpoint['path'])
        ...         model.train(data=str(data_path), epochs=self.params.epochs)
        ...         return TrainResult(weights_path='./weights')

    Example (custom steps - advanced):
        >>> class TrainAction(BaseTrainAction[TrainParams]):
        ...     def setup_steps(self, registry: StepRegistry[TrainContext]) -> None:
        ...         # Full control over step pipeline
        ...         registry.register(MyCustomExportStep())
        ...         registry.register(MyCustomTrainStep())

    Dataset Format Configuration:
        Set `target_format` to automatically convert downloaded datasets:
        - 'yolo': YOLO format with dataset.yaml
        - 'coco': COCO JSON format
        - None: No conversion (use raw Datamaker format)

    Overriding Steps:
        Override `setup_steps()` for full control over the pipeline.
        When overridden, auto-wiring is disabled and you manage all steps.
    """

    category = PluginCategory.NEURAL_NET

    # Dataset format for automatic conversion (e.g., 'yolo', 'coco')
    # Set to None to disable automatic conversion
    target_format: str | None = None

    @classmethod
    def get_log_message_code_class(cls) -> type[TrainLogMessageCode]:
        from synapse_sdk.plugins.actions.train.log_messages import TrainLogMessageCode

        return TrainLogMessageCode

    def autolog(self, framework: str) -> None:
        """Enable automatic logging for an ML framework.

        Call this before creating model objects. The SDK will automatically
        attach callbacks to log progress, metrics, and artifacts.

        Supported frameworks:
            - 'ultralytics': YOLO object detection models

        Args:
            framework: Framework name (e.g., 'ultralytics').

        Raises:
            ValueError: If framework is not recognized.
            ImportError: If framework package is not installed.

        Example:
            >>> def execute(self, data_path, checkpoint):
            ...     self.autolog('ultralytics')
            ...     model = YOLO(checkpoint['path'])
            ...     model.train(epochs=100)
        """
        from synapse_sdk.integrations import autolog as _autolog

        _autolog(framework, self)

    @property
    def client(self) -> BackendClient:
        """Backend client from context.

        Returns:
            BackendClient instance.

        Raises:
            RuntimeError: If no client in context.
        """
        if self.ctx.client is None:
            raise RuntimeError(
                'No client in context. Either provide a client via RuntimeContext '
                'or override the helper methods (get_dataset, create_model, get_model).'
            )
        return self.ctx.client

    def _has_custom_setup_steps(self) -> bool:
        """Check if setup_steps was overridden by subclass."""
        return type(self).setup_steps is not BaseTrainAction.setup_steps

    def setup_steps(self, registry: StepRegistry[TrainContext]) -> None:
        """Register workflow steps for step-based execution.

        Override this method for full control over the step pipeline.
        When overridden, automatic step wiring is disabled.

        By default (when not overridden), the SDK auto-wires steps based on:
        - `dataset` in params → adds ExportDatasetStep
        - `target_format` class attribute → adds ConvertDatasetStep
        - Always adds internal step that calls your `execute()` method

        Args:
            registry: StepRegistry to register steps with.

        Example:
            >>> def setup_steps(self, registry: StepRegistry[TrainContext]) -> None:
            ...     from synapse_sdk.plugins.steps import ExportDatasetStep
            ...     registry.register(ExportDatasetStep())
            ...     registry.register(MyCustomPreprocessStep())
            ...     registry.register(MyTrainStep())
        """
        pass  # Default: no custom steps, run() will auto-wire

    def create_context(self) -> TrainContext:
        """Create training context for step-based workflow.

        Override to customize context creation or add additional state.

        Returns:
            TrainContext instance with params and runtime context.
        """
        params_dict = self.params.model_dump() if hasattr(self.params, 'model_dump') else dict(self.params)
        return TrainContext(
            runtime_ctx=self.ctx,
            params=params_dict,
        )

    def run(self) -> Any:
        """Run the action with automatic step orchestration.

        This method is called by executors. It:
        1. Checks if is_tune mode → delegates to _run_tune()
        2. Checks if setup_steps() was overridden
        3. If overridden: uses custom steps
        4. If not overridden: auto-wires export/convert/train steps

        Step proportions are automatically configured by Orchestrator
        based on each step's progress_proportion property.

        Returns:
            Action result (dict or result_model instance).
        """
        # --- Tune mode ---
        # TODO(tune-extraction): When tune becomes a separate action type
        # (BaseTuneAction), this branch will be removed. The is_tune flag
        # routing will be handled by the executor or a dedicated TuneAction.
        if getattr(self.params, 'is_tune', False):
            return self._run_tune()

        from synapse_sdk.plugins.steps import ConvertDatasetStep, ExportDatasetStep

        registry: StepRegistry[TrainContext] = StepRegistry()

        if self._has_custom_setup_steps():
            # User has custom steps - use them
            self.setup_steps(registry)
        else:
            # Auto-wire steps based on params and target_format
            dataset = getattr(self.params, 'dataset', None)

            if dataset is not None:
                registry.register(ExportDatasetStep())
                if self.target_format:
                    registry.register(ConvertDatasetStep(target_format=self.target_format))

            # Add internal step that calls execute()
            registry.register(_TrainExecuteStep(self))

        if not registry:
            raise RuntimeError(
                'No steps registered. Either set target_format class attribute '
                'or override setup_steps() to register custom steps.'
            )

        # Step-based execution
        context = self.create_context()
        orchestrator: Orchestrator[TrainContext] = Orchestrator(
            registry=registry,
            context=context,
            progress_callback=lambda curr, total: self.set_progress(curr, total),
        )
        result = orchestrator.execute()

        # Add context data to result
        if context.model:
            result['model'] = context.model

        return result

    def execute(self, data_path: Path, checkpoint: dict[str, Any] | None) -> Any:
        """Execute training logic.

        Override this method with your training implementation.
        The SDK automatically resolves data_path and checkpoint for you.

        Args:
            data_path: Path to dataset config file (e.g., dataset.yaml for YOLO).
                Resolved from export/convert steps.
            checkpoint: Checkpoint dict with 'path' and 'category' keys, or None.
                Resolved from params.checkpoint or ctx.checkpoint.

        Returns:
            Training result. Can be a dict or result_model instance.

        Example:
            >>> def execute(self, data_path: Path, checkpoint: dict) -> TrainResult:
            ...     self.autolog('ultralytics')
            ...     model = YOLO(checkpoint['path'])
            ...     results = model.train(
            ...         data=str(data_path),
            ...         epochs=self.params.epochs,
            ...     )
            ...     return TrainResult(weights_path='./weights')
        """
        raise NotImplementedError(
            f'{type(self).__name__} must implement execute(data_path, checkpoint). '
            'See BaseTrainAction docstring for examples.'
        )

    def get_dataset(self) -> dict[str, Any]:
        """Fetch training dataset info from backend.

        Default implementation uses params.dataset. Override for custom behavior.

        Returns:
            Dataset metadata dictionary.

        Raises:
            ValueError: If params.dataset is not set.
            RuntimeError: If no client in context.
        """
        dataset = getattr(self.params, 'dataset', None)
        if dataset is None:
            raise ValueError(
                'params.dataset is required for default get_dataset(). '
                'Either set dataset in your params model or override get_dataset().'
            )
        # Return basic info - full data is fetched via ground_truth_events
        return {'id': dataset}

    def create_model(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Upload trained model to backend.

        Default implementation uploads via client.create_model().
        Override for custom behavior (e.g., MLflow, S3).

        Args:
            path: Local path to model artifacts.
            **kwargs: Additional fields for model creation.

        Returns:
            Created model metadata dictionary.

        Raises:
            RuntimeError: If no client in context.
        """
        return self.client.create_model({
            'file': path,
            **kwargs,
        })

    def get_model(self, model_id: int) -> dict[str, Any]:
        """Retrieve existing model by ID.

        Args:
            model_id: Model identifier.

        Returns:
            Model metadata dictionary.

        Raises:
            RuntimeError: If no client in context.
        """
        return self.client.get_model(model_id)

    def get_checkpoint(self) -> dict[str, Any] | None:
        """Get checkpoint for training.

        Resolves checkpoint in the following order:
        1. If ctx.checkpoint is set (remote mode), returns it directly
        2. If params.checkpoint is set (model ID), fetches and extracts

        Returns:
            Checkpoint dict with 'category', 'path', 'id', 'name', or None.

        Example:
            >>> checkpoint = self.get_checkpoint()
            >>> if checkpoint:
            ...     model_path = checkpoint['path']
        """
        from synapse_sdk.utils.file import extract_archive, get_temp_path

        # If checkpoint is already in context (remote mode), return it
        if self.ctx.checkpoint is not None:
            return self.ctx.checkpoint

        # Check if params has a checkpoint field (model ID)
        checkpoint_id = getattr(self.params, 'checkpoint', None)
        if checkpoint_id is None:
            return None

        # Fetch model from backend
        model = self.get_model(checkpoint_id)

        # The model['file'] is downloaded by the client's url_conversion
        model_file = Path(model['file'])

        # Extract to temp path
        output_path = get_temp_path(f'models/{model_file.stem}')
        if not output_path.exists():
            output_path.mkdir(parents=True, exist_ok=True)
            extract_archive(model_file, output_path)

        # Determine category - base models vs fine-tuned
        category = model.get('category') or 'base'

        return {
            'category': category,
            'path': output_path,
            'id': model.get('id'),
            'name': model.get('name'),
        }

    # ------------------------------------------------------------------ #
    # Tune support methods                                                #
    # TODO(tune-extraction): All methods below prefixed with _run_tune,  #
    # _prepare_tune_, _convert_tune_ are candidates for extraction into  #
    # a dedicated BaseTuneAction class. The _TuneTrialCallback class at  #
    # the bottom of this file should also move there.                    #
    # ------------------------------------------------------------------ #

    def _run_tune(self) -> Any:
        """Orchestrate hyperparameter tuning via Ray Tune.

        Runs dataset preparation once, then launches Ray Tune to explore
        the hyperparameter search space defined in params.hyperparameters.
        Each trial calls the plugin's execute() with resolved param values.

        Returns:
            Dict with 'best_result' containing the best trial config.
        """
        import ray
        from ray import tune

        if not ray.is_initialized():
            # Check if we're running inside a Ray Job (backend execution)
            # In this case, the Job already has a runtime_env configured by the backend.
            # We should connect to the existing cluster without specifying a new runtime_env
            # to avoid merge conflicts.
            is_inside_ray_job = bool(os.environ.get('RAY_JOB_CONFIG_JSON_ENV_VAR'))

            if is_inside_ray_job:
                # Connect to existing Ray cluster without custom runtime_env
                ray.init(address='auto')
                logger.info('Connected to existing Ray cluster (inside Ray Job).')
            else:
                # Local development: initialize with custom runtime_env
                runtime_env = self._build_tune_runtime_env()
                ray.init(runtime_env=runtime_env)
                logger.info('Initialized Ray with custom runtime_env (local mode).')

        logger.info('Starting hyperparameter tuning mode.')

        # 1. Prepare dataset (run export/convert steps once)
        data_path = self._prepare_tune_dataset()

        # 2. Get checkpoint
        checkpoint = self.get_checkpoint()

        # 3. Parse tune_config from params (extra field from backend)
        params_dict = self.params.model_dump() if hasattr(self.params, 'model_dump') else dict(self.params)
        tune_config = params_dict.get('tune_config') or {}
        hyperparameters = self.params.hyperparameters or []

        # 4. Convert search space definitions to Ray Tune param_space
        param_space = self._convert_tune_params(hyperparameters)

        # 5. Setup search algorithm and scheduler
        search_alg = self._convert_tune_search_alg(tune_config)
        scheduler = self._convert_tune_scheduler(tune_config)

        # 6. Build TuneConfig kwargs
        # Disable strict metric checking to allow metric keys with special characters
        # e.g., 'metrics/mAP50-95(B)' from ultralytics
        os.environ['TUNE_DISABLE_STRICT_METRIC_CHECKING'] = '1'

        tune_config_kwargs: dict[str, Any] = {
            'num_samples': tune_config.get('num_samples', 1),
        }
        if tune_config.get('mode'):
            tune_config_kwargs['mode'] = tune_config['mode']
        if tune_config.get('metric'):
            # Use original metric name as-is since strict checking is disabled
            tune_config_kwargs['metric'] = tune_config['metric']
        if tune_config.get('max_concurrent_trials'):
            tune_config_kwargs['max_concurrent_trials'] = tune_config['max_concurrent_trials']
        if search_alg is not None:
            tune_config_kwargs['search_alg'] = search_alg
        if scheduler is not None:
            tune_config_kwargs['scheduler'] = scheduler

        # 7. Create trainable function
        # Each trial receives resolved param values from Ray Tune,
        # creates a fresh action instance (to avoid tqdm serialization issues),
        # and calls execute().
        #
        # NOTE: We pass action_cls and base_params instead of the action instance
        # because the action contains a logger with tqdm objects that can't be
        # serialized by Ray (causes RecursionError).
        action_cls = type(self)
        base_params = params_dict.copy()

        def _trial_entrypoint(
            config: dict[str, Any],
            action_cls: type,
            base_params: dict[str, Any],
            data_path: Any,
            checkpoint: Any,
        ) -> None:
            """Single tune trial entrypoint.

            Does NOT return a result dict — metrics are reported via
            tune.report() by the ML framework integration (e.g., ultralytics
            callbacks when IS_TUNE=true). Returning a dict here would override
            the last tune.report() call and cause metric validation errors
            because the returned dict lacks the metric key TuneConfig expects.

            TODO(tune-extraction): Move to BaseTuneAction._trial_entrypoint.
            """
            from synapse_sdk.loggers import ConsoleLogger
            from synapse_sdk.plugins.context import PluginEnvironment, RuntimeContext

            os.environ['IS_TUNE'] = 'true'

            # Merge base params with trial config (trial config overrides)
            trial_params = {**base_params, **config}

            # Create fresh action instance with trial-specific params
            # This avoids serialization issues with tqdm in the logger
            ctx = RuntimeContext(
                logger=ConsoleLogger(),
                env=PluginEnvironment.from_environ(),
            )
            action = action_cls(action_cls.params_model(**trial_params), ctx)

            # Run plugin's execute() method.
            # Metrics flow through tune.report() called by the ML framework
            # (e.g., ultralytics YOLO callbacks). The result from execute()
            # is intentionally not returned to avoid overriding tune.report().
            action.execute(data_path, checkpoint)

        train_fn = tune.with_parameters(
            _trial_entrypoint,
            action_cls=action_cls,
            base_params=base_params,
            data_path=data_path,
            checkpoint=checkpoint,
        )

        # 8. Apply resource constraints
        # TODO(tune-extraction): Make resource config customizable via
        # tune_config or class attribute (e.g., tune_resources).
        trainable = tune.with_resources(train_fn, {'cpu': 1, 'gpu': 0.5})

        storage_dir = tempfile.mkdtemp(prefix='synapse_tune_')
        num_samples = tune_config.get('num_samples', 1)

        # Trial progress callback
        callbacks = [_TuneTrialCallback(action=self, num_samples=num_samples)]

        tuner = tune.Tuner(
            trainable,
            tune_config=tune.TuneConfig(**tune_config_kwargs),
            run_config=tune.RunConfig(
                name='synapse_tune_hpo',
                log_to_file=('stdout.log', 'stderr.log'),
                storage_path=storage_dir,
                callbacks=callbacks,
            ),
            param_space=param_space,
        )

        logger.info('Launching Ray Tune with %d samples.', num_samples)
        result_grid = tuner.fit()

        # 9. Extract best result
        best_result = result_grid.get_best_result()
        best_config = best_result.config if best_result else {}

        # TODO(tune-extraction): Add trial model upload logic here.
        # In v1, _upload_tune_trial_models() uploads all trial results and
        # _override_best_trial() marks the best one on the backend.

        logger.info('Tune completed. Best config: %s', best_config)

        return {
            'best_result': best_config,
        }

    def _prepare_tune_dataset(self) -> Path | None:
        """Run export/convert steps to prepare dataset for tuning.

        Executes only the dataset steps (no training step), returning
        the resolved data path for use across all tune trials.

        TODO(tune-extraction): Move to BaseTuneAction.

        Returns:
            Path to dataset config file, or None if no dataset in params.
        """
        from synapse_sdk.plugins.steps import ConvertDatasetStep, ExportDatasetStep

        registry: StepRegistry[TrainContext] = StepRegistry()
        dataset = getattr(self.params, 'dataset', None)

        if dataset is not None:
            registry.register(ExportDatasetStep())
            if self.target_format:
                registry.register(ConvertDatasetStep(target_format=self.target_format))

        if not registry:
            return None

        context = self.create_context()
        orchestrator: Orchestrator[TrainContext] = Orchestrator(
            registry=registry,
            context=context,
            progress_callback=lambda curr, total: self.set_progress(curr, total),
        )
        orchestrator.execute()

        # Resolve data path from context (same logic as _TrainExecuteStep)
        if context.dataset is None:
            return None
        config_path = context.dataset.get('config_path')
        if config_path is not None:
            return Path(config_path)
        path = context.dataset.get('path')
        if path is not None:
            path = Path(path)
            return path / 'dataset.yaml' if path.is_dir() else path
        return None

    def _build_tune_runtime_env(self) -> dict[str, Any]:
        """Build Ray runtime_env for tune trials.

        Mirrors the logic in BaseRayExecutor._build_runtime_env() to ensure
        tune trial workers have access to:
        - Plugin code (working_dir)
        - Python dependencies (requirements.txt)
        - SDK source (py_modules)
        - Environment variables (Synapse credentials)

        TODO(tune-extraction): Move to BaseTuneAction. Consider sharing
        the runtime_env building logic with BaseRayExecutor.

        Returns:
            Dict suitable for ray.init(runtime_env=...).
        """
        from synapse_sdk.plugins.executors.ray.base import read_requirements

        runtime_env: dict[str, Any] = {}

        # 1. Working directory — ship plugin code to workers
        working_dir = Path.cwd()
        runtime_env['working_dir'] = str(working_dir)

        # 2. Python dependencies from requirements.txt
        req_path = working_dir / 'requirements.txt'
        requirements = read_requirements(req_path)
        if requirements:
            packages = [r for r in requirements if not r.strip().startswith('-')]
            pip_args = [r for r in requirements if r.strip().startswith('-')]

            if packages:
                runtime_env['pip'] = {'packages': packages}

            if pip_args:
                import shlex

                split_args = []
                for arg in pip_args:
                    split_args.extend(shlex.split(arg))
                runtime_env.setdefault('pip', {})
                runtime_env['pip']['pip_install_options'] = split_args

        # 3. Include SDK source so workers can import synapse_sdk
        import synapse_sdk

        sdk_path = str(Path(synapse_sdk.__file__).parent)
        runtime_env['py_modules'] = [sdk_path]

        # 4. Environment variables — Synapse credentials for backend client
        env_vars: dict[str, str] = {}

        from synapse_sdk.utils.auth import ENV_SYNAPSE_ACCESS_TOKEN, ENV_SYNAPSE_HOST, load_credentials

        creds = load_credentials()
        if creds.host:
            env_vars[ENV_SYNAPSE_HOST] = creds.host
        if creds.token:
            env_vars[ENV_SYNAPSE_ACCESS_TOKEN] = creds.token

        # Include plugin environment variables
        if hasattr(self.ctx, 'env') and self.ctx.env:
            env_vars.update(self.ctx.env.to_dict())

        if env_vars:
            runtime_env['env_vars'] = env_vars

        logger.info(
            'Built tune runtime_env: working_dir=%s, pip=%s, py_modules=%s',
            working_dir,
            bool(requirements),
            bool(sdk_path),
        )

        return runtime_env

    @staticmethod
    def _convert_tune_params(param_list: list[dict[str, Any]]) -> dict[str, Any]:
        """Convert backend hyperparameter definitions to Ray Tune search space.

        Backend sends search space definitions like:
            [{"name": "epochs", "type": "randint", "min": 5, "max": 10},
             {"name": "batch_size", "type": "choice", "options": [2, 4, 8]}]

        This converts them to Ray Tune functions:
            {"epochs": tune.randint(5, 10), "batch_size": tune.choice([2, 4, 8])}

        TODO(tune-extraction): Move to BaseTuneAction._convert_tune_params.

        Args:
            param_list: List of hyperparameter search space definitions.

        Returns:
            Dict mapping param names to Ray Tune search space objects.
        """
        from ray import tune

        param_handlers = {
            'uniform': lambda p: tune.uniform(p['min'], p['max']),
            'quniform': lambda p: tune.quniform(p['min'], p['max']),
            'loguniform': lambda p: tune.loguniform(p['min'], p['max'], p['base']),
            'qloguniform': lambda p: tune.qloguniform(p['min'], p['max'], p['base']),
            'randn': lambda p: tune.randn(p['mean'], p['sd']),
            'qrandn': lambda p: tune.qrandn(p['mean'], p['sd']),
            'randint': lambda p: tune.randint(p['min'], p['max']),
            'qrandint': lambda p: tune.qrandint(p['min'], p['max']),
            'lograndint': lambda p: tune.lograndint(p['min'], p['max'], p['base']),
            'qlograndint': lambda p: tune.qlograndint(p['min'], p['max'], p['base']),
            'choice': lambda p: tune.choice(p['options']),
            'grid_search': lambda p: tune.grid_search(p['options']),
        }

        param_space: dict[str, Any] = {}

        for param in param_list:
            name = param['name']
            param_type = param['type']

            if param_type in param_handlers:
                param_space[name] = param_handlers[param_type](param)
            else:
                raise ValueError(
                    f"Unknown tune parameter type: '{param_type}' for '{name}'. "
                    f'Supported types: {", ".join(param_handlers.keys())}'
                )

        return param_space

    @staticmethod
    def _convert_tune_search_alg(tune_config: dict[str, Any]) -> Any:
        """Convert tune_config to a Ray Tune search algorithm instance.

        Supports both string and dict formats for search_alg:
            - String: "basicvariantgenerator"
            - Dict: {"name": "basicvariantgenerator", "options": {...}}

        TODO(tune-extraction): Move to BaseTuneAction._convert_tune_search_alg.

        Args:
            tune_config: Tune configuration from backend.

        Returns:
            Ray Tune search algorithm instance, or None.
        """
        search_alg_raw = tune_config.get('search_alg')
        if search_alg_raw is None:
            return None

        # Handle both string and dict formats
        if isinstance(search_alg_raw, str):
            search_alg_name = search_alg_raw.lower()
        elif isinstance(search_alg_raw, dict):
            search_alg_name = search_alg_raw.get('name', '').lower()
        else:
            return None

        metric = tune_config.get('metric')
        mode = tune_config.get('mode')

        if search_alg_name == 'bayesoptsearch':
            from ray.tune.search.bayesopt import BayesOptSearch

            return BayesOptSearch(metric=metric, mode=mode)
        elif search_alg_name == 'hyperoptsearch':
            from ray.tune.search.hyperopt import HyperOptSearch

            return HyperOptSearch(metric=metric, mode=mode)
        elif search_alg_name == 'optunasearch':
            from ray.tune.search.optuna import OptunaSearch

            return OptunaSearch(metric=metric, mode=mode)
        elif search_alg_name == 'basicvariantgenerator':
            from ray.tune.search.basic_variant import BasicVariantGenerator

            max_concurrent = tune_config.get('max_concurrent_trials')
            return BasicVariantGenerator(max_concurrent=max_concurrent)
        elif search_alg_name == 'axsearch':
            from ray.tune.search.ax import AxSearch

            return AxSearch(metric=metric, mode=mode)
        else:
            raise ValueError(
                f"Unsupported search algorithm: '{search_alg_name}'. "
                f'Supported: basicvariantgenerator, hyperoptsearch, optunasearch, '
                f'bayesoptsearch, axsearch'
            )

    @staticmethod
    def _convert_tune_scheduler(tune_config: dict[str, Any]) -> Any:
        """Convert tune_config to a Ray Tune scheduler instance.

        Supports both string and dict formats for scheduler:
            - String: "hyperband"
            - Dict: {"name": "hyperband", "options": {...}}

        TODO(tune-extraction): Move to BaseTuneAction._convert_tune_scheduler.

        Args:
            tune_config: Tune configuration from backend.

        Returns:
            Ray Tune scheduler instance, or None.
        """
        from ray.tune.schedulers import (
            ASHAScheduler,
            FIFOScheduler,
            HyperBandScheduler,
            MedianStoppingRule,
            PopulationBasedTraining,
        )

        scheduler_raw = tune_config.get('scheduler')
        if scheduler_raw is None:
            return None

        # Handle both string and dict formats
        if isinstance(scheduler_raw, str):
            scheduler_name = scheduler_raw.lower()
            options: dict[str, Any] = {}
        elif isinstance(scheduler_raw, dict):
            scheduler_name = scheduler_raw.get('name', 'fifo').lower()
            options = scheduler_raw.get('options') or {}
        else:
            return None

        scheduler_map = {
            'fifo': FIFOScheduler,
            'asha': ASHAScheduler,
            'hyperband': HyperBandScheduler,
            'pbt': PopulationBasedTraining,
            'median': MedianStoppingRule,
        }

        scheduler_class = scheduler_map.get(scheduler_name)
        if scheduler_class is None:
            raise ValueError(f"Unsupported scheduler: '{scheduler_name}'. Supported: {', '.join(scheduler_map.keys())}")

        return scheduler_class(**options) if options else scheduler_class()


class _TuneTrialCallback(_TuneCallbackBase):
    """Ray Tune callback for tracking trial progress.

    Reports trial completion progress via the action's set_progress().

    TODO(tune-extraction): When BaseTuneAction is implemented, this class
    should be enhanced with full trial table logging (log_trials) similar
    to the v1 _TuneTrialsLoggingCallback. Current implementation only
    tracks completion counts.
    """

    def __init__(self, action: BaseTrainAction[Any], num_samples: int = 1) -> None:
        self._action = action
        self._num_samples = num_samples
        self._completed = 0

    def on_trial_complete(self, iteration: int, trials: list[Any], trial: Any, **info: Any) -> None:
        self._completed += 1
        self._update_progress()

    def on_trial_error(self, iteration: int, trials: list[Any], trial: Any, **info: Any) -> None:
        self._completed += 1
        logger.warning('Tune trial %s ended with error.', getattr(trial, 'trial_id', '?'))
        self._update_progress()

    def _update_progress(self) -> None:
        completed = min(self._completed, self._num_samples)
        try:
            self._action.set_progress(completed, self._num_samples)
        except Exception:
            pass


class _TrainExecuteStep(BaseStep[TrainContext]):
    """Internal step that wraps action's execute() method.

    This step is auto-registered when setup_steps() is not overridden.
    It resolves data_path and checkpoint, then calls action.execute().
    """

    def __init__(self, action: BaseTrainAction[Any]) -> None:
        self._action = action

    @property
    def name(self) -> str:
        return 'train'

    @property
    def progress_weight(self) -> float:
        return 0.5

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress (75% - training)."""
        return 75

    def execute(self, context: TrainContext) -> StepResult:
        # Resolve data path from context (set by export/convert steps)
        data_path = self._resolve_data_path(context)
        if data_path is None:
            return StepResult(
                success=False,
                error='No data path available. Ensure ExportDatasetStep and ConvertDatasetStep ran successfully.',
            )

        # Resolve checkpoint
        checkpoint = self._action.get_checkpoint()

        # Call action's execute method
        try:
            result = self._action.execute(data_path, checkpoint)
        except Exception as e:
            return StepResult(success=False, error=str(e))

        # Extract result data
        if hasattr(result, 'model_dump'):
            result_data = result.model_dump()
        elif isinstance(result, dict):
            result_data = result
        else:
            result_data = {'result': result}

        # Store model_path in context if available
        weights_path = result_data.get('weights_path')
        if weights_path:
            context.model_path = weights_path

        return StepResult(success=True, data=result_data)

    def _resolve_data_path(self, context: TrainContext) -> Path | None:
        """Resolve data path from context (set by ConvertDatasetStep)."""
        if context.dataset is None:
            return None

        config_path = context.dataset.get('config_path')
        if config_path is not None:
            return Path(config_path)

        path = context.dataset.get('path')
        if path is not None:
            path = Path(path)
            if path.is_dir():
                return path / 'dataset.yaml'
            return path

        return None
