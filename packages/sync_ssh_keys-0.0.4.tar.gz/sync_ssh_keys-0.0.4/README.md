# Sync SSH Keys from GitHub
```sh
uv run --with sync-ssh-keys sync-ssh-keys {Github username}
```
