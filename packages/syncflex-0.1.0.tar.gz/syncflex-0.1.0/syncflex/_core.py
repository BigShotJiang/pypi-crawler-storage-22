from collections.abc import Callable, Coroutine, Generator
from typing import Any


def syncify[**P, RT](f: Callable[P, Generator[Any, Any, RT]]) -> Callable[P, RT]:
    def func(*args: P.args, **kwargs: P.kwargs) -> RT:
        gen = f(*args, **kwargs)
        task: Any = None
        while True:
            try:
                res = task
                task = gen.send(res)
            except StopIteration as e:
                return e.value  # type: ignore[no-any-return]

    return func


def asyncify[**P, RT](f: Callable[P, Generator[Any, Any, RT]]) -> Callable[P, Coroutine[Any, Any, RT]]:
    async def initial_coro() -> None:
        return None

    async def func(*args: P.args, **kwargs: P.kwargs) -> RT:
        gen = f(*args, **kwargs)
        task: Coroutine[Any, Any, Any] = initial_coro()
        while True:
            try:
                res = await task
                task = gen.send(res)
            except StopIteration as e:
                return e.value  # type: ignore[no-any-return]

    return func
