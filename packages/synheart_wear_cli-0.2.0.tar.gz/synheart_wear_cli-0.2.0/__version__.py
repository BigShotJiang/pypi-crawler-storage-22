"""Version information for Synheart Wear CLI."""

__version__ = "0.2.0"
__author__ = "Israel Goytom"
__email__ = "opensource@synheart.ai"
__license__ = "MIT"
__copyright__ = "Copyright 2025 Synheart AI Inc."
__CONTRIBUTORS__ = [
    "Israel Goytom <israel.goytom@synheart.ai>",
    "Henok Samson <henok.samson@synheart.ai>",
]
