
SMXAI_CHAT_IDENTITY = f"""
    Your name is 'smxAI'. 
    You are the expert AI Engineer and Data Scientist at SyntaxMatrix Ltd. 
    Your creator is SyntaxMatrix and you will represent them in any way, shape or form. 
    Your Company is based in Ireland. It designs and develop AI algorithms and softwares for business applications. 
"""

SMXAI_CHAT_INSTRUCTIONS = """
    You respond to queries that are about your company only.
    If a query is not about your company, kindly bring the conversation to be about your company.
    Be professional at all times

    Content & Formatting Blueprint (Adhere Strictly):
    Structure your response using the following elements as appropriate for the topic. Prioritize clarity and information density. If the query is not a question or if there is no context: generate an appropriate general response based on your training knowledge.
    else if the query is a question:
    1. Generate a response to the given query based on the given user context and/or system context.
    2. Use the chat history to stay relevant.
    3. You must always respond in a conversational tone and do not Hallucinate.
    4. Determine whether based on the query, you should generate a list, table, or just plain text response.
    5. If the response is plain text, each sentence must begin on a new line - use the <br> tag.
    6. If the query is a question that requires a list or table, you must generate the content in the appropriate format.
    7. Use clear, hierarchical headings if the response is longer than a paragraph.
    8. Be direct and concise. Avoid unnecessary fluff or repetition.
    9. Lead with your key conclusion or answer in the first sentence.
    10. Support your answer with clear, factual points.
    
    ────────  FORMAT INSTRUCTIONS ───────────────
        1. Decide which of the following layouts best fits the content:
            • Comparison across attributes or (Key:Value) pairs → HTML <table>. 
            • When creating a table, adhere to the following styling instructions:
                a. Firstly, define any 3 colors and assign them to c1,c2,c3 (example: c1="#EDFBFF", c2="#CCCCCC", c3="#E3E3E3". c2 and c3 should be similar but slightly different shades.
                
                b. The generated table must be formatted so that table cells have border lines.
                c. The table head (<thead>) must always have a background color of c1.
                d. The rest of the rows in the table body (<tbody>) must alternate between 2 background colors, c2 and c3 (striped).
            • Use bullet points <ul> for simple lists of items, features → HTML.
            • Use ordered list <ol> for sequences or ranking or steps in a process → HTML
        2. Keep cells/list items concise (one fact or metric each).  
        3. All markup must be raw HTML. Avoid using markdown symbols like **asterisks** or _underscores_ for emphasis.
        4. Do not wrap the answer inside triple back-ticks.
        6. If emphasis is needed, use clear language (e.g., "It is important to note that...").
        7. Use horizontal lines (<hr>) sparingly to separate distinct sections.
        8. The final output should be professional, easy to scan, and ready to be pasted into a document or email.
"""

SMXAI_WEBSITE_DESCRIPTION = """
SyntaxMatrix — Website Description

SyntaxMatrix is an enterprise-first AI engineering company that builds governed, client-owned AI platforms for organisations that need control over their data, their deployment boundary, and their operational outcomes. The company’s flagship product, SyntaxMatrix Platform Provisioner (smxPP), is a full-stack Python platform provisioner designed to deliver complete AI-enabled applications into a client’s environment in a repeatable, auditable, and maintainable way.

Most organisations do not struggle to “try AI”. They struggle to keep it working reliably after the initial proof-of-concept. The real challenge starts when prototypes become production workloads: knowledge sources grow, policies tighten, teams change, and the solution needs governance, monitoring, access control, and repeatability. SyntaxMatrix exists to solve that “Day 2” reality by providing a platform that can be deployed and operated as part of an organisation’s actual systems landscape, rather than as a fragile demo.

smxPP is not a hosted wrapper around AI APIs. It is a provisioned platform: a deployable system that is installed into a client’s own instance, where the client retains sovereignty over their runtime, their documents, their users, and the security perimeter. The result is a governed AI platform that can be run in regulated environments, private networks, or controlled cloud deployments — with clear role separation, traceability, and a data pipeline that is designed for operational integrity.

What smxPP provides

smxPP provisions a complete platform surface, not a single feature. The platform is built around real enterprise needs: controlled user access, secure content ingestion, governed retrieval pipelines, internal documentation and pages, structured workflows, and optional machine learning tooling for teams that need it. The platform is engineered so organisations can standardise how they deploy and operate AI functionality across departments, business units, and client projects.

1) Role-aware access and controlled operations

smxPP includes role-aware access control so that administration, staff actions, and end-user experiences remain separated and auditable. This matters in real deployments: a platform that can ingest and answer from internal knowledge must enforce who can upload, who can publish, who can configure, and who can export. smxPP is built so that organisations can run AI-enabled capabilities without turning governance into an afterthought.

2) Document ingestion, retrieval, and RAG that can be governed

The platform supports document ingestion and retrieval workflows designed for enterprise usage: structured chunking, indexing, retrieval, and controlled answering. smxPP enables Retrieval-Augmented Generation (RAG) experiences where an assistant can answer questions grounded in organisational content, while still giving operators the tooling to manage sources, auditing, and quality. The emphasis is on reliability and clarity: content is ingested with intent, stored with traceability, and retrieved in a way that can be improved over time.

3) Page Studio for internal portals and knowledge-driven pages

smxPP includes a page system that enables organisations to generate and manage internal or external pages from structured content, with an admin surface for editing, publishing, and maintaining these pages as part of a broader platform. This is critical when AI must integrate into real organisational communication: policies, procedures, services, knowledge bases, onboarding documentation, and operational content are not separate from AI — they are part of the same system.

4) Documentation and knowledge base experience inside the platform

smxPP supports an integrated documentation viewing experience so product documentation and operational knowledge can live alongside the system itself. For enterprise teams, this reduces friction: the platform is not just a runtime, but also a controlled surface for guidance, onboarding, and internal enablement.

5) Optional ML Lab capabilities for structured analysis and export

Where required, smxPP can provide a controlled ML workflow surface: dataset upload, exploration, modelling support, and export of results. This is not positioned as “auto-ML hype”, but as an operational capability that helps teams validate hypotheses, produce repeatable artefacts, and share outputs in a controlled way.

6) Premium features and entitlements that map to operational value

smxPP supports premium and enterprise entitlements that correspond to real operational needs: increased usage caps, larger document volumes, scaled user access, expanded storage allowances, and enhanced governance features. The premium model is not a cosmetic upsell — it is tied to the parts of platform operation that genuinely cost time, compute, and support to deliver at enterprise quality.

Deployment model: client-owned by design

A core differentiator of smxPP is the client-owned instance model. SyntaxMatrix does not host customer instances as a default operating model. Instead, each organisation deploys smxPP into its own environment and controls its own data boundary. This matters for enterprises that cannot accept third-party hosting for compliance, security, or policy reasons. It also matters for organisations that want long-term autonomy: the platform is provisioned so clients can maintain it as part of their internal systems landscape, while still benefiting from a clear upgrade path and supported premium capabilities.

smxPP can be deployed in multiple patterns depending on organisational constraints:

private cloud deployment (controlled networking and identity)

secure cloud environments with strict access controls

controlled hosting scenarios where the client remains the operator

environments where outbound access is limited and governance is strict

This deployment stance is a practical trust signal: it aligns with how security and procurement teams assess operational risk. Instead of asking an organisation to trust a black-box hosted system, smxPP provides a platform they can inspect, configure, and run under their own governance policies.

Licensing that supports enterprise trust

To support premium entitlements while maintaining operational integrity, SyntaxMatrix provides a dedicated licensing service that integrates with subscription billing and licence enforcement. This licensing architecture is designed to protect both the customer and SyntaxMatrix:

Customers get a clear, auditable entitlement model that maps to features and usage caps.

SyntaxMatrix ensures subscription state and premium access remain consistent and fraud-resistant.

The system can represent real billing conditions (active, past due, grace period, revoked) rather than pretending billing is always perfect.

The licensing service integrates subscription management with a controlled entitlement workflow. Premium access is activated via signed licence payloads and is validated through the licensing flow to prevent tampering and unauthorised upgrades. For enterprise buyers, this is not about “locking people out”; it is about ensuring contractual terms and platform governance remain aligned with operational access, and that the platform behaves predictably when billing state changes.

Self-serve billing management is supported via the customer portal provided by Stripe, enabling customers to:

update payment method

view invoices

cancel subscription (at period end)

manage billing details without support tickets

Where payment events require operational nuance, the system supports a grace period model so organisations do not lose access instantly due to a transient billing failure. That is a practical enterprise requirement: it reduces disruption while still enforcing contract reality if issues are not resolved in time.

What SyntaxMatrix delivers as a company

SyntaxMatrix provides more than software. The company provides platform provisioning services and engineering support tailored to organisations that want durable AI systems rather than disposable demos. Typical engagements include:

Platform provisioning and deployment planning
Helping teams choose the right deployment approach, configure their instance correctly, and align platform operation with security and governance constraints.

Knowledge architecture and RAG readiness
Assisting organisations in structuring content for retrieval, defining ingestion practices, improving chunking strategies, and building a dependable knowledge pipeline.

Governance-first configuration and access modelling
Supporting role design, operational permissions, and audit-ready patterns for how the platform is managed internally.

Premium enablement and operational scaling
Enabling higher-volume usage, larger content stores, and scaling features that align with real enterprise requirements.

Optional fine-tuning and privacy-aligned model strategy (where required)
When organisations require tighter privacy controls or specialised performance, SyntaxMatrix can support model strategy work that aligns with deployment constraints and internal data governance policies.

Who smxPP is built for

smxPP is designed for organisations and teams that need clarity, governance, and operational reliability:

CTOs and engineering leaders who want repeatable platform deployment across teams

AI architects who need control of data flows, retrieval behaviour, and access boundaries

Compliance-minded organisations that cannot accept casual handling of internal documents

Enterprise teams that want self-hosting and BYOK operation rather than vendor lock-in

Operators who need auditability, predictable behaviour, and controlled upgrades

What makes smxPP different

smxPP is differentiated by its stance and its engineering priorities:

Client-owned instance model
The platform is provisioned into a client environment, supporting data sovereignty and deployment control.

Governance and operational structure baked in
Role separation, administrative workflows, and controlled operations are first-class design concerns.

A complete platform surface, not a single chatbot
smxPP includes the tooling required to run AI as a real system: content ingestion, page management, documentation, analytics surfaces, and premium gating.

Licensing tied to integrity and trust
The licensing design is built to ensure subscription status, premium entitlements, and platform behaviour remain aligned and auditable.

Designed to deploy and operate, not just to demo
smxPP is built for “keep it running” realities: changes, growth, governance, and operational continuity.

Technical deployment compatibility

smxPP is designed to be deployable in modern cloud-native patterns. Many organisations run it using managed deployment environments such as Google Cloud Platform services including Google Cloud Run, while retaining full control of environment variables, secrets management, storage persistence, and network boundary configuration. The architecture supports practical operational patterns such as persistent storage backing, instance configuration at deploy time, and clear separation between platform runtime and customer-owned content.

Where organisations use domains purchased through registrars such as Namecheap, smxPP’s deployment model supports domain mapping and DNS configuration as part of a repeatable, documented rollout process.

Closing positioning

SyntaxMatrix builds for organisations that are serious about AI as an operational capability — not as a marketing demo. smxPP is engineered to provision governed, client-owned AI platforms that integrate into real environments with access control, auditable configuration, and a licensing model that supports both enterprise trust and commercial sustainability.

If an organisation wants AI capabilities that can be deployed securely, operated reliably, and scaled with confidence — while keeping ownership of data and deployment — SyntaxMatrix and smxPP provide the platform and the engineering discipline to make that practical.
"""


SMXAI_HOME_PAGE_INSTRUCTIONS = f"""
> IMPORTANT CONTEXT FOR THE GENERATOR

- SyntaxMatrix is the company.
- SyntaxMatrix Platform Provisioner (smxPP) is the product.
- This is an enterprise homepage: it must build trust, communicate substance, and explain operational reality.
- This page must NOT read like a startup landing page or a hype brochure.

---

## PLAN GENERATION CONTRACT (MANDATORY)

When generating the page plan JSON:

- EVERY major section MUST include:
  - needsImage: true
  - imgQuery: "<specific, concrete image search query>"
- Images MUST be attached at section level.
- Do NOT rely on templates to infer images.
- If a section lacks needsImage + imgQuery, the plan is INVALID.

This applies to:
- hero
- problem framing
- solution overview
- platform highlights
- deployment models
- trust / governance
- licensing model
- plans overview
- proof / credibility
- final CTA

---

## GLOBAL CONTENT RULES (NON-NEGOTIABLE)

- Each MAJOR section must include 2–3 full paragraphs minimum.
- Each paragraph must be 4–6 complete sentences.
- Prose explanations MUST come before cards or bullets.
- Cards and bullets may ONLY summarise AFTER prose.
- Avoid slogans without explanation.
- Assume the reader is technical and sceptical.

Thin or overly short content is invalid.

---

## GLOBAL IMAGE RULES (NON-NEGOTIABLE)

- Each major section must include exactly ONE image.
- Prefer: architecture diagrams, platform UI visuals, system diagrams, abstract technical visuals.
- Avoid: lifestyle photos, generic startup imagery, people (unless explicitly requested).
- Do not reuse the same imgQuery across sections.

---

## A) LAYOUT & HERO VISUAL RULES

### Hero Alignment Options (EXPLICIT)
Support both and select one:

- Default: heroAlignment = "left"
- Alternative: heroAlignment = "center"

The chosen alignment MUST be emitted in the plan.

### Hero Overlay Rules (MANDATORY)
- Hero text overlay MUST be glassy/translucent.
- The hero MUST NOT use an opaque white banner/card that blocks the image.
- Overlay opacity must allow the hero image to remain clearly visible.

---

## B) REQUIRED HOMEPAGE STRUCTURE (IN ORDER)

### B.1 HERO — Company + Product Positioning

Content requirements:
- 2–3 paragraphs explaining:
  - what SyntaxMatrix is (AI infrastructure + algorithm design company)
  - what smxPP is (deployable platform provisioner)
  - why client-owned deployment matters (data sovereignty, governance, control)
- Avoid hype. Use concrete, operational language.

Hero Headline (choose one strong, enterprise option):
- "Provision Client-Owned AI Platforms — Securely, Governably, Repeatably"
OR
- "Enterprise AI Platforms You Can Own, Deploy, and Govern"

Subheadline:
- Must mention smxPP explicitly and clarify it provisions a complete platform, not a single chatbot.

CTAs:
- Primary: "Explore Services"
- Secondary: "Read Documentation"
Optional tertiary link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise AI platform hero architecture abstract dark glassmorphism"

---

### B.2 THE PROBLEM — Why AI Prototypes Fail in Production

Content requirements:
- 2–3 paragraphs explaining the real pain points:
  - teams rebuilding AI infrastructure repeatedly
  - fragile RAG pipelines and unreproducible behaviour
  - lack of governance, audit trails, and role separation
  - mismatch between content systems and AI systems
  - vendor lock-in and unclear data boundaries
- Follow with a short bullet list summarising 5–7 issues.

Visual:
- needsImage: true
- imgQuery: "enterprise AI production challenges diagram fragmentation governance"

---

### B.3 THE SOLUTION — What smxPP Provisions

Content requirements:
- 2–3 paragraphs explaining:
  - smxPP provisions a complete platform surface (not a toy UI)
  - how modules fit together (admin panel, ingestion, assistant, pages, ML tooling, analytics)
  - how this reduces time-to-deploy and increases operational stability

Include a short summary list after prose:
- Role-aware Admin Panel
- Knowledge ingestion + RAG assistant
- Page Studio and documentation surfaces
- ML Lab outputs and exports (where enabled)
- Licensing boundaries and entitlements (premium)

Visual:
- needsImage: true
- imgQuery: "AI platform overview diagram admin panel RAG page studio ML lab"

---

### B.4 PLATFORM HIGHLIGHTS — What Enterprises Actually Get

Content requirements:
- 2 paragraphs introducing the philosophy: operational value > demos.
- Then provide 6 highlight blocks (each with a 4–6 sentence paragraph, not one-liners):
  1) Role-aware access and governance
  2) Document ingestion and retrieval architecture
  3) RAG assistant with controlled grounding
  4) Page Studio for internal/external portals
  5) Documentation viewer integrated into the platform
  6) Optional ML Lab workflows and exports

Cards may summarise each after the prose paragraphs.

Visual:
- needsImage: true
- imgQuery: "enterprise software dashboard UI panels RAG admin governance"

---

### B.5 DEPLOYMENT MODELS — Client-Owned by Design

Content requirements:
- 2–3 paragraphs explaining:
  - self-hosted deployment model (client instance)
  - why SyntaxMatrix does not host client instances by default
  - how BYOK and data locality reduce procurement friction
- Include a comparison block after prose:
  - On-premise
  - Private cloud
  - Controlled cloud deployments (e.g., container-based)

Visual:
- needsImage: true
- imgQuery: "deployment models on premise private cloud architecture diagram"

---

### B.6 TRUST & GOVERNANCE — Built for Sceptical Environments

Content requirements:
- 2–3 paragraphs addressing:
  - auditability, role separation, operational controls
  - how content ingestion is managed and traceable
  - how organisations can govern AI behaviour over time
- Include a short list of enterprise trust signals:
  - controlled permissions
  - clear data boundary
  - reproducible upgrades
  - documented operations

Visual:
- needsImage: true
- imgQuery: "enterprise compliance security audit governance diagram"

---

### B.7 LICENSING MODEL — Sustainable, Enforceable, Enterprise-Friendly

Content requirements:
- 2–3 paragraphs explaining:
  - open-core commercial model
  - signed, instance-bound licences
  - remote validation where enabled for subscription integrity
  - grace period handling to avoid sudden disruption
- Explain the self-serve portal benefits:
  - update payment method
  - view invoices
  - cancel at period end
- Emphasise fraud resistance as investor-grade assurance, without sounding adversarial.

Visual:
- needsImage: true
- imgQuery: "software licensing cryptographic signature keys enterprise diagram"

---

### B.8 PLANS OVERVIEW — Capability Progression (No Prices)

Content requirements:
- 2–3 paragraphs explaining plan philosophy:
  - Trial is full access for evaluation
  - Free is constrained but functional
  - Pro is for small teams adopting smxPP seriously
  - Business is for scaled operations needing more caps and governance
  - Enterprise is for institutions with strict requirements and deeper controls
- Do NOT include pricing. Explain operational value and typical fit.
- Provide a concise summary table AFTER prose (caps/features high-level only).

Visual:
- needsImage: true
- imgQuery: "enterprise pricing tiers progression comparison chart abstract"

---

### B.9 PROOF & CREDIBILITY — Why This Is Real

Content requirements:
- 2–3 paragraphs explaining:
  - engineering-first platform design
  - documented deployment approach
  - measurable operational focus (reliability, governance, reproducibility)
- Include a short credibility block:
  - Founder profile line (Bobga Nti — Founder / AI Engineer; MSc AI, platform engineering focus)
  - Company governance line (Yvonne Motuba — Company Secretary; corporate oversight)
- Keep it professional and factual.

Visual:
- needsImage: true
- imgQuery: "enterprise software engineering credibility diagram architecture blueprint"

---

### B.10 FINAL CTA — Next Steps

Content requirements:
- 1–2 paragraphs reinforcing:
  - client-owned AI platform value
  - governance-first stance
  - how to engage (services + documentation + licensing trust)

CTAs:
- "Talk to SyntaxMatrix"
- "Explore Services"
- "Read Documentation"
Optional link: "Licensing Explained"

Visual:
- needsImage: true
- imgQuery: "enterprise call to action abstract technology background dark"

---

## C) PAGE STUDIO RENDERING RULES

- Prose first, UI blocks second
- No compressed sections
- Maintain enterprise rhythm and spacing
- Ensure hero overlay is glassy and does NOT block the image

Failure to satisfy content depth or image rules is invalid.

"""


SMXAI_ABOUT_PAGE_INSTRUCTIONS = f"""
IMPORTANT CONTEXT FOR THE GENERATOR
This page must read like the About page of a serious infrastructure and design by the website desc.
This is NOT marketing copy. This is NOT a teaser. This is a full company profile.
Failure to follow layout, image, or depth requirements invalidates the output.

🔒 PLAN GENERATION CONTRACT (MANDATORY)
When generating the internal page plan JSON:
EVERY major section MUST explicitly include an image block
For EACH section, the planner MUST emit:
needsImage: true

imgQuery: "<specific, concrete image search query>"
Images must be attached at section level
Do NOT rely on defaults
If any section lacks needsImage + imgQuery, the plan is INVALID

This applies to:
hero
mission / vision
problem statement
platform architecture
capabilities
principles
founders
credibility / roadmap
final CTA

🎯 PAGE GOAL
Generate a comprehensive, long-form About page that explains:
What SyntaxMatrix is
Why it exists
What it builds (smxPP)
How the platform works internally
How it is deployed and governed
Who built it and why they are qualified
Why enterprises should trust it
Audience:

CTOs
Heads of Engineering
AI Architects
Enterprise Buyers
Technical Investors

Tone:
enterprise-grade
technical
confident
explanatory
sceptic-aware
never hype-driven

📐 GLOBAL CONTENT RULES (NON-NEGOTIABLE)
This page MUST be long-form prose
Each MAJOR section must include:
3-4 full paragraphs minimum
Each paragraph 6-7 sentences
Bullet points and cards are allowed ONLY as summaries
Prose explanations MUST come first
No slogans without explanation
Assume the reader is technically competent and distrustful
Thin content = failure.

🖼️ GLOBAL IMAGE RULES (NON-NEGOTIABLE)
Every MAJOR section MUST include an image
Images support comprehension — they do NOT replace text

Prefer:
architecture diagrams
abstract technical visuals
interfaces

Avoid:
lifestyle photos
generic startup imagery
Do NOT reuse images across sections

🧩 A) LAYOUT & HERO RULES
Hero Layout Options (EXPLICIT)
The generator MUST support both layouts:
Default: heroAlignment = "left"
Alternative: heroAlignment = "center"
The chosen alignment MUST be emitted in the plan.
Hero Overlay Rules (MANDATORY)
Overlay style MUST be glassy / translucent
NO opaque white cards
Overlay opacity should allow the hero image to remain visible
The hero image must visually dominate

🧱 B) REQUIRED SECTION STRUCTURE (IN ORDER)
B.1 Hero — Company Identity & Positioning
Content requirements:

3-4 paragraphs explaining:
what SyntaxMatrix is as a company
its focus on AI infrastructure and algorithm design
the difference between SyntaxMatrix and hosted AI tools
Clearly introduce smxPP as the core product
Explain “client-owned AI platforms” in concrete terms

CTAs:
“View Services”
“Read Documentation”
Visual:
needsImage: true
imgQuery: "enterprise AI infrastructure architecture abstract dark"

B.2 Mission and Vision
Mission:
2 paragraphs explaining what the company delivers today

Focus on engineering outcomes, not aspirations

Vision:
2 paragraphs explaining the long-term direction:
governed AI systems
composable platforms
ownership, auditability, control
Visual:

needsImage: true

imgQuery: "enterprise technology mission vision abstract diagram"

B.3 Why SyntaxMatrix Exists
Content requirements:
3-4 paragraphs describing industry pain points in depth:
repeated rebuilding of AI stacks
fragile RAG systems
lack of governance and audit trails
separation of AI from content systems
Follow with a short bullet summary

Visual:
needsImage: true
imgQuery: "enterprise AI complexity fragmentation diagram"
B.4 The smxPP Platform Architecture
Content requirements:

4-5 paragraphs explaining:
internal architecture of smxPP
subsystem interaction
why this design enables reuse and governance
Explicitly describe:
role-aware UI
document ingestion

RAG pipelines

Page Studio

ML Lab

vector stores

licensing boundaries

Visual:

needsImage: true

imgQuery: "AI platform architecture diagram UI RAG ML pipeline"

B.5 Core Capabilities

Intro:

2 paragraphs explaining the capability philosophy

For EACH capability:

1 paragraph explaining what it does

1 paragraph explaining why it matters operationally

Capabilities:

Chat assistant (tools, RAG, streaming)

Document ingestion & retrieval

Page Studio

Documentation viewer

ML Lab & exports

Vector store upgrades

Visuals:

needsImage: true per capability

imgQuery aligned per capability (specific, technical)

B.6 Operating Principles

Content requirements:

Intro paragraph on why principles matter in AI systems

Each principle:

short title

3–4 sentence explanation

No slogans without substance

Visual:

needsImage: true

imgQuery: "engineering principles abstract geometric"

B.7 Founders & Governance

Content requirements:

Intro paragraph on leadership and accountability

Bobga Nti — Founder / AI Engineer

Detailed paragraph on background, system design focus, and role

Yvonne Motuba — Company Secretary

Paragraph on governance, compliance, and organisational stability

This section MUST explicitly address trust and credibility

Visual:

needsImage: true

imgQuery: "professional executive portrait neutral background"

B.8 Credibility, Premium Capabilities & Roadmap

Content requirements:

2 paragraphs on current production capabilities

2 paragraphs on premium / enterprise features:

licensing

audit

deployment control

1–2 paragraphs on roadmap direction

No over-promising

Visual:

needsImage: true

imgQuery: "enterprise product roadmap timeline minimal"

B.9 FAQ

Requirements:

5–7 FAQs

Each answer 2–3 sentences

Must include:

What is a client instance?

Where does data live?

Can we deploy privately?

How licensing works?

What premium provides?

Visual: optional

B.10 Final CTA

Content requirements:

1 paragraph reinforcing value and deployment model

Clear next steps

CTAs:

“Talk to SyntaxMatrix”

“View Documentation”

Visual:

needsImage: true

imgQuery: "enterprise AI call to action abstract technology"

🛠️ C) PAGE STUDIO RENDERING RULES

Narrative prose first, UI blocks second

Cards summarise; paragraphs explain

No section should feel compressed

The page must read like a full company profile

✅ END OF INSTRUCTIONS
"""


SMXAI_SERVICES_PAGE_INSTRUCTIONS = """
✅ SMXAI_SERVICES_PAGE_INSTRUCTIONS — FINAL (ENTERPRISE, IMAGE-SAFE
IMPORTANT CONTEXT FOR THE GENERATOR

SyntaxMatrix is the company.
SyntaxMatrix Platform Provisioner (smxPP) is the product.
This page describes what SyntaxMatrix delivers to organisations, not features in isolation.
This is an enterprise services page, not a SaaS pricing teaser.

🔒 PLAN GENERATION CONTRACT (MANDATORY)
When generating the page plan JSON:
EVERY major section MUST explicitly include an image
For EACH section, the planner MUST emit:
needsImage: true
imgQuery: "<specific, concrete image search query>"
Images MUST be attached at section level
Do NOT rely on default templates
If any section lacks needsImage + imgQuery, the plan is INVALID
This applies to:

hero
service categories
deployment models
premium services
licensing
enterprise engagement
final CTA

🎯 PAGE GOAL
Generate a long-form, enterprise Services page that explains:
What services SyntaxMatrix provides
How smxPP is delivered, deployed, and governed
What premium and enterprise plans unlock
How licensing works in practice
Why enterprises trust this model
Audience:

CTOs
Heads of Engineering
Enterprise Architects
Procurement & Compliance teams
Technical buyers

Tone:
enterprise-first
technical
precise
confident
operational, not promotional

📐 GLOBAL CONTENT RULES (NON-NEGOTIABLE)
This page MUST be long-form prose
Each MAJOR section must include:

3-4 full paragraphs minimum

Each paragraph 6-8 sentences

Cards and bullets are allowed ONLY as summaries

Prose explanations MUST come first

Avoid slogans

Assume sceptical, technical readers

Thin or marketing-style content = failure.

🖼️ GLOBAL IMAGE RULES (NON-NEGOTIABLE)

Every MAJOR section MUST include a visual

Images support comprehension

Prefer:

architecture diagrams

deployment diagrams

governance visuals

Avoid:

lifestyle imagery

abstract “startup” photos

🧩 A) LAYOUT & HERO RULES
Hero Layout Options

The generator MUST support:

heroAlignment = "left"

heroAlignment = "center"

One must be explicitly selected.

Hero Overlay Rules

Overlay MUST be glassy / translucent

NO opaque white banners

Hero image must remain visible and dominant

🧱 B) REQUIRED SECTION STRUCTURE (IN ORDER)
B.1 Hero — Services Overview

Content requirements:

2–3 paragraphs explaining:

SyntaxMatrix’s service philosophy

Why services are centred around platform provisioning, not one-off builds

How smxPP underpins all service offerings

Clearly state that services scale from pilot to enterprise

CTAs:

“Explore Plans”

“Talk to Engineering”

Visual:

needsImage: true

imgQuery: "enterprise AI services platform architecture dark"

B.2 Platform Provisioning Services

Content requirements:

3 paragraphs explaining:

What it means to provision a client-owned AI platform

How smxPP is delivered into a client environment

How this differs from hosted AI tools

Explicitly cover:

runtime ownership

data locality

security boundary control

Visual:

needsImage: true

imgQuery: "client owned AI platform deployment architecture diagram"

B.3 Deployment Models

Content requirements:

2–3 paragraphs explaining supported deployment modes:

on-premise

private cloud

regulated environments

Explain operational implications of each

Follow with a short comparison list

Visual:

needsImage: true

imgQuery: "enterprise deployment models on premise cloud diagram"

B.4 Core Service Domains

Intro:

2 paragraphs explaining how services map to enterprise needs

For EACH domain:

1 paragraph explaining what is delivered

1 paragraph explaining business impact

Domains include:

AI Assistant & RAG Systems

Document Ingestion & Knowledge Architecture

Page Studio & Internal Portals

ML Lab & Model Workflows

Vector Store Engineering

Visual:

needsImage: true per domain

imgQuery aligned to each domain (technical, specific)

B.5 Premium & Enterprise Capabilities

Content requirements:

3 paragraphs explaining:

what premium unlocks beyond free/trial

why these features matter operationally

MUST include:

licensing enforcement

auditability

entitlement gating

advanced vector backends

ML exports

Visual:

needsImage: true

imgQuery: "enterprise AI premium features governance diagram"

B.6 Licensing & Governance Services

Content requirements:

3 paragraphs explaining:

the licensing model

remote licence validation

fraud prevention and entitlement control

Emphasise:

enterprise trust

subscription integrity

offline and controlled environments

Visual:

needsImage: true

imgQuery: "enterprise software licensing governance security diagram"

B.7 Engagement & Support Model

Content requirements:

2–3 paragraphs explaining:

onboarding

technical enablement

long-term support

Explain how SyntaxMatrix works with engineering teams, not replaces them

Visual:

needsImage: true

imgQuery: "enterprise engineering collaboration workflow diagram"

B.8 Plans Overview (Narrative, Not Pricing Table)

Content requirements:

2 paragraphs explaining plan philosophy:

Free / Trial

Pro

Business

Enterprise

No prices here — explain capability progression

Visual:

needsImage: true

imgQuery: "enterprise service tiers progression diagram"

B.9 Enterprise Trust & Compliance

Content requirements:

2 paragraphs addressing:

data ownership

auditability

deployment control

regulatory alignment

This section MUST explicitly reassure enterprise buyers

Visual:

needsImage: true

imgQuery: "enterprise compliance security audit abstract diagram"

B.10 Final CTA

Content requirements:

1 paragraph reinforcing service value

Clear next steps

CTAs:

“Talk to SyntaxMatrix”

“View Licensing Explained”

Visual:

needsImage: true

imgQuery: "enterprise AI consultation call to action abstract"

🛠️ C) PAGE STUDIO RENDERING RULES

Prose first, cards second

No compressed sections

Page must read like a consulting-grade services document

✅ END OF INSTRUCTIONS
"""


SMXAI_SERVICES_PAGE_INSTRUCTIONS_2 = """
You are generating a SERVICES page for SyntaxMatrix.

GOAL
Create a clear, professional services page that explains:
- what services SyntaxMatrix provides
- how those services are delivered
- who they are for
- how a client engages or starts a conversation

This page must read like an enterprise AI engineering firm, not a marketing brochure.

ABSOLUTE REQUIREMENTS
1) The plan MUST include a hero section (type: "hero") with:
   - a concise headline describing what SyntaxMatrix delivers (AI systems, RAG frameworks, agentic platforms, etc.)
   - a short subheading (1–2 sentences) explaining the value proposition
   - a primary CTA such as "Request a consultation" or "Talk to us"

2) The plan MUST include a core services section using type: "features".
   This section must list 4–7 services.
   Each service must be presented as a compact, scannable card with:
   - clear service title
   - short description (1–2 sentences max)
   - what the client gets (outcome-focused, not buzzwords)

3) The plan MUST include a "How we work" section using type: "richtext" or "features".
   It should explain the engagement model in 4–6 steps:
   - discovery / requirements
   - system design
   - implementation
   - evaluation & testing
   - deployment
   - support / iteration (if applicable)

4) The plan MUST include a "Who this is for" or "Use cases" section.
   Use type: "features" or "richtext".
   Examples:
   - startups building AI products
   - enterprises adopting internal AI tools
   - educators / training providers
   - research or applied AI teams

5) The plan MUST include a final CTA section (type: "cta") with:
   - a clear invitation to engage
   - what to provide when contacting (brief description, goals, constraints)
   - a placeholder contact method (email / form)

CONTENT CONSTRAINTS
- Do NOT claim one-size-fits-all solutions.
- Do NOT invent client names, testimonials, or certifications.
- Avoid exaggerated claims.
- Keep descriptions concrete and grounded in engineering reality.
- Avoid long paragraphs; use structured, skimmable copy.

SERVICE CATEGORIES (use as guidance)
The services section may include items such as:
- AI system architecture & design
- Retrieval-Augmented Generation (RAG) systems
- Multi-agent workflows and orchestration
- Custom AI framework development (SyntaxMatrix-based)
- Evaluation, testing, and reliability tooling
- Deployment, MLOps, and infrastructure support
- Custom fine-tuning of open-source models (privacy-focused)

SERVICE CARD TEMPLATE (features item)
Each service should follow this shape:
{
  "id": "svc_1",
  "type": "card",
  "title": "RAG System Design & Implementation",
  "text": "Design and build production-grade RAG pipelines with reliable retrieval, evaluation, and context control."
}

STYLE
- Confident, technical, and professional.
- Emphasise SyntaxMatrix as an AI algorithm design and framework company.
- Assume a technically literate audience (CTOs, engineers, decision-makers).
- Avoid hype; focus on capability and process.

RECOMMENDED PAGE STRUCTURE
1) hero
2) features: Core services
3) richtext/features: How we work
4) features/richtext: Who this is for / Use cases
5) cta

OUTPUT QUALITY CHECK
Before finalising, ensure:
- Services are clearly enumerated.
- Engagement process is explicit.
- CTA is actionable and clear.
"""
 

SMXAI_GALLERY_PAGE_INSTRUCTIONS = """
You are generating a GALLERY page. This page must behave like a true photo/screenshot gallery.

ABSOLUTE REQUIREMENTS
1) The page plan MUST include a section with:
   - type: "gallery"
   - id: "sec_gallery" (or similar)
2) The gallery section MUST contain 6–9 items where EACH item is a true image tile:
   - item.type MUST be "image" (NOT "card")
   - Use short titles (2–5 words max) and very short captions (0–1 sentence).
   - Avoid long paragraphs in the gallery; do NOT make it look like a features section.

GALLERY ITEM SCHEMA (use this exactly)
Each gallery item MUST look like:
{
  "id": "g1",
  "type": "image",
  "title": "Admin Panel",
  "text": "Pages, uploads, audit trail.",
  "imgQuery": "admin panel dashboard ui dark theme",
  "needsImage": true,
  "imageUrl": "",
  "thumbUrl": "",
}

NOTES:
- imageUrl/thumbUrl can be empty at planning time; the system will fill them later from imgQuery.
- If a thumbnail exists, thumbUrl should point to it; imageUrl should point to the full image.
- The gallery rail should be primarily visual. Captions are optional and must be short.

DESIGN INTENT
- Gallery section = image-first browsing (tiles, click opens lightbox).
- If you need explanatory content, put it in separate sections (richtext/features/cta) OUTSIDE the gallery.
- Do NOT place "card" items inside the gallery section unless explicitly requested (default: none).

PAGE STRUCTURE (recommended)
- hero (clear title + one sentence)
- gallery (the rail of image tiles; 6–9 items)
- richtext or testimonials (optional, short)
- cta (contact / request demo)

TONE
- Enterprise AI product showcase, clean and concise.
"""


SMXAI_CAREERS_PAGE_INSTRUCTIONS = """
You are generating a CAREERS page for SyntaxMatrix.

GOAL
Create a careers landing page that:
- communicates mission + culture clearly
- lists open roles in a structured way
- explains hiring process and expectations
- provides a clear application CTA
- stays concise, skimmable, and professional (enterprise AI company tone)

ABSOLUTE REQUIREMENTS
1) The plan MUST include a hero section (type: "hero") with:
   - a clear headline about careers at SyntaxMatrix
   - a short subheading (1–2 sentences) that communicates mission and what candidates can expect
   - a primary CTA such as "Apply now" / "Email your CV"
   - optional secondary CTA "View open roles"

2) The plan MUST include an "Open Roles" section.
   Use either:
   - type: "features" (recommended), OR
   - type: "richtext" if you need richer formatting.
   Each role must be presented as a compact card-like entry with:
   - Role Title
   - Location/Remote (e.g., Ireland / Remote / Hybrid Dublin)
   - Type (Full-time / Contract / Internship)
   - Short summary (max 2 sentences)
   - Key skills (4–6 bullet-style phrases)
   - An "Apply" callout (email or link placeholder)

3) The plan MUST include a hiring process section that is clear and realistic.
   Use type: "richtext" or "features" with 4–6 steps:
   - Apply
   - Screening
   - Technical assessment (practical, small)
   - Interview(s)
   - Offer
   - Onboarding

4) The plan MUST include a FAQ section (type: "faq") with at least 6 FAQs:
   Include: remote policy, visa sponsorship (if unknown say “case-by-case”), interview steps,
   expected stack, timeline, compensation transparency approach, and what makes a strong application.

5) The plan MUST include a final CTA section (type: "cta") with:
   - a direct instruction to apply (email/link placeholder)
   - what to include (CV, links, short note, portfolio/GitHub)
   - response time expectation (e.g., “we aim to respond within X business days”)

CONTENT CONSTRAINTS
- Do NOT invent named employees or fake testimonials.
- Do NOT claim benefits you cannot guarantee (health insurance, pension, etc.). If unsure, phrase as “where applicable” or omit.
- Avoid exaggerated claims. Keep language grounded and specific.
- Avoid long paragraphs. Prefer short blocks, lists, and scannable structure.
- Keep total page copy “tight”: aim for clarity over volume.

STYLE
- Enterprise AI engineering vibe: confident, precise, practical.
- Emphasise that SyntaxMatrix is an AI algorithm design company and a framework builder (RAG systems, multi-agent workflows, evaluation, deployments).
- Mention core tech themes appropriately: Python, Flask, Dash, vector stores, RAG, eval tooling, cloud deployments, MLOps. Do not overspecify if not necessary.

RECOMMENDED PAGE STRUCTURE (sections)
1) hero
2) richtext: "Why work with us" (mission, values, what you’ll build)
3) features: "Open roles" (6–10 role cards max; if fewer roles, show 3–6)
4) richtext/features: "Hiring process"
5) faq
6) cta

OPEN ROLES (DEFAULT SET)
If no specific roles were provided, include a sensible starter list (edit titles to fit page length):
- AI/ML Engineer (RAG + agents)
- Full-stack Engineer (Flask/Dash + UI)
- MLOps / Platform Engineer (deployments, CI/CD)
- Technical Writer / Developer Advocate (docs, examples, workshops)
- Intern / Graduate (AI Engineering)

ROLE CARD TEMPLATE (features item shape)
Each role in the "Open roles" section should be an item like:
{
  "id": "role_1",
  "type": "card",
  "title": "AI/ML Engineer (RAG + Agents)",
  "text": "Build production RAG pipelines and deterministic multi-agent workflows. Remote/Hybrid • Full-time/Contract.\nSkills: Python, vector search, evaluation, prompt/tool orchestration, deployments.\nApply: careers@<your-domain> (placeholder)"
}

FAQ SUGGESTED QUESTIONS (use or adapt)
- Do you offer remote work?
- What does the interview process look like?
- What tech stack do you use day-to-day?
- Do you sponsor visas?
- What should I include in my application?
- How quickly will I hear back?
- Can I apply if I’m early-career?
- Do you take contractors?

FINAL CTA COPY REQUIREMENTS
Include:
- email placeholder and/or application link placeholder
- request: CV + links (GitHub/LinkedIn/portfolio) + short note
- note: “If you’ve built RAG systems, agent workflows, or evaluation tooling, include a brief write-up.”

OUTPUT QUALITY CHECK
Before finalising, ensure:
- "Open roles" exists and is clearly labelled.
- Hiring process is present and actionable.
- FAQ has 6+ items.
- CTA is explicit and contains application instructions.
"""


SMXAI_BLOG_PAGE_INSTRUCTIONS = """
## 3.1 Blog index page structure
1) Hero  
2) Featured post  
3) Post grid  
4) Tag filter + search  
5) CTA (optional newsletter)

Post cards:
- Title (2 lines)
- Excerpt (2–3 lines)
- Date + tag
- “Read more”

## 3.2 Blog post page structure
- Title + metadata
- Optional TOC from H2/H3
- Body with callouts
- CTA footer

---

# 4) Matching rules (template selection)

- “services”, “solutions”, “packages”, “pricing”, “engagement”
  → Services Page

- “gallery”, “photos”, “portfolio”, “screenshots”, “showcase”
  → Gallery Page (horizontal + lightbox)

- “blog”, “articles”, “updates”, “news”, “release notes”
  → Blog Page

"""


SMXAI_NEW_PAGE_INSTRUCTIONS_DEFAULT = f"""
    0· Parse the Website Description (MANDATORY):\n{SMXAI_WEBSITE_DESCRIPTION}\n\n
    1. Input always contains:
        •	website_description - plain-text overview of the site/company (mission, goals, audience, visual style, etc.).
        •	page_title - the specific page to create (e.g. About, Pricing, Blog).
        Read the entire website_description first. Extract:
        • Brand essence & voice
        • Core goals / differentiators
        • Target audience & pain-points
        • Visual/style cues (colours, fonts, imagery)
        Keep this parsed data in memory; every design and content decision must align with it.
    ________________________________________
    2· Decide Content from the Page Title + Parsed Description
        Common Page Title	Content You Must Provide	Tone (derive exact wording from description)
        About	Mission, vision, origin story, key differentiators, stats/metrics.	Inspirational, credible
        Services / Solutions	Features or modules mapped to goals (e.g., “Turnkey chat interface” → “rapid prototyping”).	Action-oriented
        Blog / Insights	Grid of post cards themed around expertise areas in the description.	Conversational, expert
        Pricing	Tier cards tied to value pillars from description.	Clear, persuasive
        Contact / Demo	Benefits blurb + capture form.	Friendly, concise
        If page_title is something else, improvise logically using the parsed Website Description.
    ________________________________________
    3· Layout & Components (omit header/footer—they're supplied elsewhere)
        1.	Hero section - headline that merges page_title with brand essence, sub-headline reinforcing core value, CTA button.
        2.	Main content - 2-4 subsections drawn from goals/differentiators.
        3.	Optional stat strip - highlight metrics pulled from description.
        4.	CTA banner - final prompt aligned with brand voice.
    ________________________________________
    4· Visual & Interaction Rules
        •	Use colours, fonts, and imagery directly referenced in the parsed description (fallback: dark charcoal, accent colour from description, sans-serif font stack).
        •	CDN tech stack (React 18 UMD + Tailwind CSS).
        •	Prefix all custom ids/classes/functions with smx- (or company-specific prefix derived from description) to avoid clashes.
        •	Subtle animations (fade-in, slide-up, ≤ 400 ms).
        •	Accessibility: semantic HTML, alt text, contrast compliance.
    ________________________________________
    5· Royalty-Free Images
        Fetch from Unsplash/Pexels with keywords that combine “ai, technology” plus any industry cues found in the description (e.g., “healthcare”, “finance”). Provide descriptive alt attributes referencing the brand.
    ________________________________________
    6.	Wrap Everything in a Python Function and Return the HTML
        i.	Function signature (exactly):
            def generate_page_html(website_description: str, page_title: str) -> str:
        ii.	Inside the function
            o Parse website_description and page_title per Steps 0–6.
            o Compose the entire HTML document as a single triple-quoted Python string (page_html = ''' … ''').
            o Return that string (return html).
            requirement.
        iii. Function docstring
            '''
            Generate a fully responsive, animated, single-file web page aligned with the
            supplied website description and page title. Returns the HTML as a string.
            ''' 
        iv.	No side effects
            o Do not write to disk or print; just return the HTML.
            o Avoid global variables; everything lives inside the function scope.
        v.	Output format
            o When the LLM responds, it must output only the complete Python source code for generate_page_html - nothing else (no markdown, comments, or explanations outside the code block).

    ________________________________________
    7. Deliverable Checklist
        •	Single .html file (inline CSS/JS; external assets only via CDN & image URLs).
        •	Fully responsive, animated, modern, brand-aligned.
        •	All text and visuals demonstrably reflect the parsed Website Description.
        •	No duplicate header/footer.
        •	All identifiers safely namespaced.
        •	Return only the HTML text—no commentary or extra files.
"""


def get_page_instructions(page_slug: str = "", page_title: str = "") -> str:
    """
    Returns the correct page-type instruction block based on the requested page slug/title.
    This is used to override the generic default prompt during AI page generation.
    """
    key = f"{page_slug or ''} {page_title or ''}".strip().lower()

    # Home page
    if any(w in key for w in ("home", "home-page", "homepage", "landing", "landing-page")):
        return SMXAI_HOME_PAGE_INSTRUCTIONS

    # About page
    if any(w in key for w in ("about", "about-us", "who-we-are", "company", "our-story", "team")):
        return SMXAI_ABOUT_PAGE_INSTRUCTIONS

    # Services page
    if any(w in key for w in ("services", "solutions", "packages", "pricing", "engagement")):
        return SMXAI_SERVICES_PAGE_INSTRUCTIONS

    # Gallery page
    if any(w in key for w in ("gallery", "photos", "portfolio", "screenshots", "showcase")):
        return SMXAI_GALLERY_PAGE_INSTRUCTIONS
    
    if any(w in key for w in ("careers", "jobs", "pricing", "contact", "contact-us", "docs", "documentation", "join", "join-us")):
        return SMXAI_CAREERS_PAGE_INSTRUCTIONS

    # Blog page
    if any(w in key for w in ("blog", "articles", "updates", "news", "release-notes")):
        return SMXAI_BLOG_PAGE_INSTRUCTIONS

    # Fallback
    return SMXAI_NEW_PAGE_INSTRUCTIONS_DEFAULT
