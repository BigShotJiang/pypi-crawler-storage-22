---
name: "power-synth-sdk"
displayName: "SynthAgentSDK Power"
description: "Synth is a layered Python SDK for building production-grade AI agents and multi-agent systems. The architecture follows a composable, bottom-up design: a minimal core (Agent, Tool, RunResult) that works standalone, with orchestration layers (Pipeline, Graph, AgentTeam) composed on top. Provider adapters abstract LLM backends behind a unified interface. Cross-cutting concerns (Memory, Guards, Tracing, Checkpointing) are pluggable middleware that attach to any layer. The SDK targets Python 3.10+ and provides both sync and async APIs. The package uses optional extras (synth-agent-sdk[openai], synth-agent-sdk[anthropic], synth-agent-sdk[agentcore], etc.) to keep the core install minimal."
keywords: ["synth", "agent", "sdk", "tool", "pipeline", "graph", "team", "guard", "memory", "eval", "tracing", "agentcore", "structured-output", "provider", "streaming", "checkpoint"]
author: "Synth"
---

# SynthAgentSDK Power

Synth is a layered Python SDK for building production-grade AI agents and multi-agent systems. The architecture follows a composable, bottom-up design: a minimal core (Agent, Tool, RunResult) that works standalone, with orchestration layers (Pipeline, Graph, AgentTeam) composed on top. Provider adapters abstract LLM backends behind a unified interface. Cross-cutting concerns (Memory, Guards, Tracing, Checkpointing) are pluggable middleware that attach to any layer.

The SDK targets Python 3.10+ and provides both sync and async APIs. The package uses optional extras (`synth-agent-sdk[openai]`, `synth-agent-sdk[anthropic]`, `synth-agent-sdk[agentcore]`, etc.) to keep the core install minimal.

Install: `pip install synth-agent-sdk`
Import: `from synth import Agent, tool, Graph, Pipeline`
CLI: `synth` or `python -m synth`

## Architecture

```
Public API Layer:    Agent, Pipeline, Graph, AgentTeam, Eval, CLI
Middleware Layer:    Guards, Memory, Tracing, Checkpointing, Structured Output
Provider Layer:      ProviderRouter → Anthropic, OpenAI, Google, Ollama, Bedrock
Tool System:         @tool decorator, ToolKit, JSON Schema Generator, ToolExecutor
Deployment Layer:    AgentCore Adapter, @agentcore_handler, Deployer
```

## Package Structure

```
synth/
├── __init__.py              # Public API exports
├── __main__.py              # python -m synth entry point
├── agent.py                 # Agent class (sync/async run, stream)
├── types.py                 # RunResult, event types, config types
├── errors.py                # SynthError hierarchy
├── _compat.py               # Sync/async compatibility utilities
├── tools/
│   ├── decorator.py         # @tool decorator and schema generation
│   ├── toolkit.py           # ToolKit class
│   └── executor.py          # ToolExecutor (invocation + error handling)
├── providers/
│   ├── router.py            # ProviderRouter (model string → provider)
│   ├── base.py              # BaseProvider ABC
│   ├── anthropic.py         # AnthropicProvider
│   ├── openai.py            # OpenAIProvider
│   ├── google.py            # GoogleProvider
│   ├── ollama.py            # OllamaProvider
│   ├── bedrock.py           # BedrockProvider (AWS Bedrock Runtime)
│   └── retry.py             # Retry logic with exponential backoff
├── memory/
│   ├── base.py              # BaseMemory ABC
│   ├── thread.py            # ThreadMemory (in-process)
│   ├── persistent.py        # PersistentMemory (Redis)
│   └── semantic.py          # SemanticMemory (vector embeddings)
├── orchestration/
│   ├── pipeline.py          # Pipeline class
│   ├── graph.py             # Graph class, @node decorator, edge routing
│   ├── team.py              # AgentTeam class
│   └── human_in_loop.py     # PausedRun, human-in-the-loop logic
├── guards/
│   ├── base.py              # BaseGuard ABC
│   ├── pii.py               # PII detection guard
│   ├── cost.py              # Cost limit guard
│   ├── tool_filter.py       # Tool call filter guard
│   └── custom.py            # Custom guard wrapper
├── tracing/
│   ├── trace.py             # Trace class, span collection
│   ├── exporter.py          # OTEL JSON export, endpoint forwarding
│   └── integrations.py      # Langfuse, Datadog, Honeycomb adapters
├── checkpointing/
│   ├── base.py              # BaseCheckpointStore ABC
│   ├── local.py             # LocalCheckpointStore (disk)
│   └── redis.py             # RedisCheckpointStore
├── eval/
│   ├── eval.py              # Eval class, case management
│   ├── scorers.py           # ExactMatch, SemanticSimilarity scorers
│   └── report.py            # EvalReport, comparison logic
├── structured/
│   └── output.py            # Pydantic schema enforcement, retry parsing
├── deploy/
│   └── agentcore/
│       ├── adapter.py       # AgentCore payload translation
│       ├── handler.py       # @agentcore_handler decorator
│       ├── manifest.py      # Agent descriptor generation
│       └── memory.py        # AgentCore memory integration
└── cli/
    ├── main.py              # CLI entry point (click-based)
    ├── dev.py               # synth dev (REPL + hot-reload)
    ├── run_cmd.py           # synth run
    ├── eval_cmd.py          # synth eval
    ├── trace_cmd.py         # synth trace
    ├── deploy_cmd.py        # synth deploy
    ├── doctor.py            # synth doctor
    └── banner.py            # Boot sequence / terminal branding
```

## Quick Start

```python
from synth import Agent, tool

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"Sunny, 72°F in {city}"

agent = Agent(
    model="claude-sonnet-4-5",
    instructions="You are a helpful assistant.",
    tools=[get_weather],
)

result = agent.run("What's the weather in Seattle?")
print(result.text)
```

## Core Agent

```python
class Agent:
    def __init__(
        self,
        model: str | None = None,
        instructions: str = "",
        tools: list[Callable | ToolKit] | None = None,
        memory: BaseMemory | None = None,
        guards: list[BaseGuard] | None = None,
        output_schema: type[BaseModel] | None = None,
        base_url: str | None = None,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
    ): ...

    def run(self, prompt, thread_id=..., run_id=...) -> RunResult
    async def arun(self, prompt, ...) -> RunResult
    def stream(self, prompt, ...) -> Generator[StreamEvent]
    async def astream(self, prompt, ...) -> AsyncGenerator[StreamEvent]
```

Agent execution flow:
1. Memory retrieval (if configured) → prepend context messages
2. Input guard evaluation (in declaration order)
3. Provider call (via ProviderRouter) with tool schemas
4. Tool execution loop (if model requests tool calls)
5. Output guard evaluation
6. Structured output parsing (if output_schema set)
7. Trace finalization and attachment to RunResult

## Tool System

```python
@tool
def search_docs(query: str, limit: int = 5) -> list[str]:
    """Search the documentation for relevant articles."""
    return ["Article 1", "Article 2"]

toolkit = ToolKit([search_docs, another_tool])
agent = Agent(model="gpt-4o", tools=[toolkit])
```

Requirements for `@tool`:
- Every parameter must have a type annotation
- The function must have a docstring (sent to the LLM as the tool description)
- Missing either raises `ToolDefinitionError` at decoration time
- Async tool functions are automatically detected and awaited

## Provider Routing

| Prefix | Provider | Install |
|--------|----------|---------|
| `claude-` | Anthropic | `pip install synth-agent-sdk[anthropic]` |
| `gpt-` | OpenAI | `pip install synth-agent-sdk[openai]` |
| `gemini-` | Google | `pip install synth-agent-sdk[google]` |
| `ollama/` | Ollama | `pip install synth-agent-sdk[ollama]` |
| `bedrock/` | AWS Bedrock | `pip install synth-agent-sdk[bedrock]` |

Custom endpoints: pass `base_url` to use any OpenAI-compatible API.
Missing provider packages raise `SynthConfigError` with the exact `pip install` command.

## Memory

```python
Memory.thread()                              # In-process dict keyed by thread_id
Memory.persistent("redis://localhost:6379")   # Redis-backed storage
Memory.semantic(embedder=my_embedder)         # Vector embeddings with cosine similarity
```

## Guards

```python
Guard.no_pii_output()              # Block PII in responses
Guard.max_cost(dollars=0.50)       # Cost limit per run (raises CostLimitError)
Guard.no_tool_calls(["delete_*"])  # Block dangerous tools via glob patterns
Guard.custom(my_check_fn)          # Custom validation function
```

Guards evaluate in declaration order. First violation raises `GuardViolationError`.

## Structured Output

```python
class Analysis(BaseModel):
    sentiment: str
    confidence: float

agent = Agent(model="claude-sonnet-4-5", output_schema=Analysis)
result = agent.run("Analyze this text")
print(result.output.sentiment)  # Parsed Pydantic model
```

## Orchestration

### Pipeline
```python
pipeline = Pipeline([researcher, writer, editor])
result = pipeline.run("Quantum computing trends")
```

### Graph
```python
graph = Graph(state_schema=MyState)
graph.set_entry("classify")
graph.add_edge("classify", "handle_positive", when=lambda s: s.sentiment == "positive")
graph.add_edge("classify", "handle_negative", when=lambda s: s.sentiment == "negative")
graph.add_edge("handle_positive", Graph.END)
result = graph.run(initial_state, max_iterations=100)
```

### AgentTeam
```python
team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[researcher, coder, reviewer],
    strategy="auto",  # or "parallel"
)
result = team.run("Build a REST API")
```

## CLI Commands

Run `synth` or `python -m synth` to see the SynthAgentSDK boot sequence.

| Command | Description |
|---------|-------------|
| `synth` | Show boot sequence and available commands |
| `synth dev <file>` | Local REPL with hot-reload and trace UI |
| `synth run <file> "prompt"` | Execute agent, print result |
| `synth eval <file> --dataset <json>` | Run evaluation suite |
| `synth trace <run_id>` | Open trace in browser |
| `synth deploy --target agentcore` | Deploy to AWS AgentCore |
| `synth doctor` | Check env, credentials, dependencies |

If `synth` is not on your PATH, use `python -m synth` as an alternative.
Set `SYNTH_NO_BANNER=1` to suppress the boot sequence.

## Error Hierarchy

All errors inherit from `SynthError` with `component` and `suggestion` fields:

| Error | When |
|-------|------|
| `SynthConfigError` | Missing API key, invalid model, missing package |
| `ToolDefinitionError` | `@tool` missing annotations or docstring |
| `ToolExecutionError` | Tool function raises during execution |
| `GuardViolationError` | Guard constraint violated |
| `CostLimitError` | Cost guard limit exceeded |
| `SynthParseError` | Structured output parse failure after retries |
| `GraphRoutingError` | No matching edge condition at a node |
| `GraphLoopError` | Graph exceeds max_iterations |
| `RunNotFoundError` | Checkpoint not found for run_id |
| `PipelineError` | Pipeline step failure (includes partial results) |

## Data Models

```python
@dataclass
class RunResult:
    text: str                          # Model's text response
    output: BaseModel | None           # Parsed structured output
    tokens: TokenUsage                 # input_tokens, output_tokens, total_tokens
    cost: float                        # Estimated cost in USD
    latency_ms: float                  # Wall-clock time
    trace: Trace                       # Full execution trace
    tool_calls: list[ToolCallRecord]   # Record of all tool invocations

# Stream events
StreamEvent = TokenEvent | ToolCallEvent | ToolResultEvent | ThinkingEvent | DoneEvent | ErrorEvent

@dataclass
class TeamResult:
    answer: str
    contributions: list[AgentContribution]
    message_trace: list[Message]
    total_cost: float
    total_latency_ms: float
```

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `SYNTH_TRACE_ENDPOINT` | Auto-forward traces to OTEL collector |
| `SYNTH_NO_BANNER` | Skip terminal boot sequence |
| `ANTHROPIC_API_KEY` | Anthropic API key |
| `OPENAI_API_KEY` | OpenAI API key |
| `GOOGLE_API_KEY` | Google API key |

# When to Load Steering Files

- Building agents, adding tools, memory, guards, or structured output → `building-agents.md`
- Working with Pipeline, Graph, or AgentTeam orchestration → `orchestration-patterns.md`
- Deploying to AgentCore, using the CLI, or setting up tracing → `deployment-guide.md`
