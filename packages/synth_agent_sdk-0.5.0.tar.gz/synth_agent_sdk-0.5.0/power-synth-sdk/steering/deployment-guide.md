# Deployment and Operations Guide

## CLI Reference

### synth dev

Start a local development REPL with hot-reload and trace UI:

```bash
synth dev my_agent.py
```

- Opens an interactive REPL where you can chat with your agent
- Hot-reloads on file save (no restart needed)
- Opens a trace UI in the browser for debugging
- Displays the Fallout-inspired boot sequence on first run

Suppress the boot sequence: `SYNTH_NO_BANNER=1 synth dev my_agent.py`

### synth run

Execute an agent with a prompt and print the result:

```bash
synth run my_agent.py "What is the capital of France?"
```

Prints the RunResult text and a trace summary to stdout.

### synth eval

Run an evaluation suite against your agent:

```bash
synth eval my_agent.py --dataset cases.json
```

- Runs each case against the live agent
- Prints pass/fail report with summary score
- Exits non-zero if pass rate falls below threshold

### synth trace

Open a stored trace in the browser:

```bash
synth trace <run_id>
```

### synth deploy

Package and deploy to AWS AgentCore:

```bash
# Deploy
synth deploy --target agentcore

# Dry run (validate without deploying)
synth deploy --target agentcore --dry-run
```

Requires `pip install synth-agent-sdk[agentcore]`.

### synth doctor

Check environment, credentials, and dependencies:

```bash
synth doctor
```

Reports issues with fix instructions for:
- Missing environment variables
- Invalid provider credentials
- Missing or outdated dependencies

## AWS AgentCore Deployment

### Prerequisites

```bash
pip install synth-agent-sdk[agentcore]
```

This installs `boto3` for AWS Bedrock Runtime access.

### Wrapping an Agent

Use the `@agentcore_handler` decorator to make your agent AgentCore-compatible:

```python
from synth import Agent, tool
from synth.deploy.agentcore import agentcore_handler

@tool
def lookup_order(order_id: str) -> dict:
    """Look up an order by ID."""
    return {"order_id": order_id, "status": "shipped"}

agent = Agent(
    model="bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
    instructions="You are a customer service agent.",
    tools=[lookup_order],
)

handler = agentcore_handler(agent)
```

### Wrapping a Graph

```python
from synth import Graph
from synth.deploy.agentcore import agentcore_handler

graph = Graph(state_schema=MyState)
# ... define nodes and edges ...

handler = agentcore_handler(graph)
```

### What the Handler Does

The `AgentCoreAdapter` behind the decorator:
1. Translates AgentCore invocation payloads into Synth's `run()` input format
2. Executes the agent or graph
3. Translates the RunResult back into AgentCore's response format
4. Uses runtime-provided IAM credentials (no static AWS keys needed)
5. Routes memory operations to AgentCore's managed memory when available
6. Forwards traces to AgentCore's observability infrastructure

### Agent Manifest

The deploy command generates an agent manifest declaring:
- Agent name and description
- Supported actions
- Required IAM permissions (least-privilege)

### Deployment Flow

```bash
# 1. Validate configuration
synth deploy --target agentcore --dry-run

# 2. Deploy
synth deploy --target agentcore
```

The packager bundles code and dependencies but excludes:
- `.env` files
- Credential files
- `.synth/checkpoints/` directories

### Bedrock Provider for AgentCore

When deployed to AgentCore, use the Bedrock provider since the runtime provides IAM credentials automatically:

```python
agent = Agent(
    model="bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
    instructions="...",
)
```

The Bedrock provider uses `boto3` with AWS credential auth — no API keys needed in AgentCore.

### Checkpointing in AgentCore

When deployed to AgentCore with graph-based orchestration, the SDK uses AgentCore's managed state persistence instead of local disk or self-managed Redis:

```python
graph.with_checkpointing()  # Automatically uses AgentCore storage when deployed
```

## Tracing and Observability

### Automatic Tracing

Every `run()` and `stream()` call produces a trace:

```python
result = agent.run("Hello")
trace = result.trace

trace.total_tokens      # Total token count
trace.total_cost        # Total cost in USD
trace.total_latency_ms  # Total wall-clock time
trace.spans             # list[TraceSpan]
```

### TraceSpan

Each span records a discrete operation:

```python
for span in trace.spans:
    print(f"{span.type}: {span.name}")
    print(f"  Duration: {span.end_time - span.start_time}")
    print(f"  Metadata: {span.metadata}")
```

Span types: `llm_call`, `tool_call`, `guard_check`, `node_execution`

### Viewing Traces

```python
# Open in browser as HTML timeline
result.trace.show()

# Export as OpenTelemetry JSON
result.trace.export("trace.json")
```

### Auto-Forwarding

Set `SYNTH_TRACE_ENDPOINT` to automatically forward all traces:

```bash
export SYNTH_TRACE_ENDPOINT=https://otel-collector.example.com/v1/traces
```

### Third-Party Integrations

One-line configuration for:
- Langfuse
- Datadog
- Honeycomb

Traces are transformed into provider-specific formats automatically.

## Checkpointing

### Local Disk (Default)

Stores JSON files in `.synth/checkpoints/{run_id}/`:

```python
from synth.checkpointing import LocalCheckpointStore

graph.with_checkpointing(store=LocalCheckpointStore())
```

Uses atomic writes (write-to-temp-then-rename) for safety.

### Redis

For distributed environments:

```python
from synth.checkpointing import RedisCheckpointStore

graph.with_checkpointing(
    store=RedisCheckpointStore("redis://localhost:6379")
)
```

Uses Redis transactions for atomicity. Supports TLS and authentication.

### Resuming Runs

```python
# Start a run with an ID
result = graph.run(state, run_id="workflow-abc")

# If interrupted, resume later (even from a different process)
result = graph.resume("workflow-abc")

# If no checkpoint exists
# Raises RunNotFoundError
```

## Coding Conventions (Quick Reference)

When contributing to the SDK:

- Python 3.10+, `from __future__ import annotations` in every module
- Module-level docstring in every file
- `PascalCase` classes, `snake_case` functions, `UPPER_SNAKE_CASE` constants
- All public functions fully type-annotated
- `@dataclass` for internal types, Pydantic `BaseModel` for user-facing schemas
- Async-first: `arun`/`astream` are primary, sync wrappers via `_compat.run_sync()`
- All errors inherit from `SynthError` with `component` and `suggestion`
- Provider SDKs lazily imported with friendly `SynthConfigError` on missing package
- 90%+ test coverage, pytest runner, `@pytest.mark.asyncio` for async tests
