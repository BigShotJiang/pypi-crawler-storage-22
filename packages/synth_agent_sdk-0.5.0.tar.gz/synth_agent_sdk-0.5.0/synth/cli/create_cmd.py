"""``synth create`` command group — scaffold agents, tools, MCPs, and UIs.

Provides interactive project scaffolding with provider selection for agents,
MCP server templates, standalone tool files, multi-agent teams, and a local
testing UI.
"""

from __future__ import annotations

import os
import sys

import click


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _write(path: str, content: str) -> None:
    """Write *content* to *path* with UTF-8 encoding."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def _ensure_dir(name: str) -> None:
    """Create project directory or exit if it already exists."""
    if os.path.exists(name):
        click.echo(
            click.style(f"Directory '{name}' already exists.", fg="red"),
        )
        raise SystemExit(1)
    os.makedirs(name)


def _success_banner(name: str, files: list[tuple[str, str]]) -> None:
    """Print a consistent success banner with file listing."""
    click.echo(click.style("Project created successfully!", fg="green"))
    click.echo("")
    click.echo(f"  {click.style(name + '/', fg='cyan')}")
    for fname, desc in files:
        click.echo(f"    {fname:<20s} {desc}")
    click.echo("")


def _next_steps(steps: list[str]) -> None:
    """Print next-steps block."""
    click.echo("  Next steps:")
    for step in steps:
        click.echo(f"    {click.style('>', dim=True)} {step}")
    click.echo("")


# ---------------------------------------------------------------------------
# Provider configuration map
# ---------------------------------------------------------------------------

_PROVIDERS: dict[str, dict[str, str]] = {
    "anthropic": {
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "display": "Anthropic (Claude)",
    },
    "openai": {
        "model": "gpt-4o",
        "extra": "openai",
        "env_var": "OPENAI_API_KEY",
        "display": "OpenAI (GPT)",
    },
    "llama": {
        "model": "ollama/llama3.2",
        "extra": "ollama",
        "env_var": "",
        "display": "Llama (via Ollama)",
    },
    "gemini": {
        "model": "gemini/gemini-2.0-flash",
        "extra": "google",
        "env_var": "GOOGLE_API_KEY",
        "display": "Google Gemini",
    },
    "agentcore": {
        "model": "bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
        "extra": "agentcore",
        "env_var": "",
        "display": "AWS AgentCore (Bedrock)",
    },
}


# ---------------------------------------------------------------------------
# synth create agent
# ---------------------------------------------------------------------------

_AGENT_TEMPLATE = '''"""{display} agent built with SynthAgentSDK."""

from synth import Agent, tool


@tool
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}!"


@tool
def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


agent = Agent(
    model="{model}",
    instructions=(
        "You are a helpful assistant. Use your tools when appropriate."
    ),
    tools=[greet, get_current_time],
)


if __name__ == "__main__":
    result = agent.run("Hello! What time is it?")
    print(result.text)
'''

_AGENTCORE_AGENT_TEMPLATE = '''"""{display} agent deployed to AWS AgentCore."""

from synth import Agent, tool
from synth.deploy.agentcore import agentcore_handler


@tool
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}! Welcome aboard."


agent = Agent(
    model="{model}",
    instructions=(
        "You are a helpful assistant deployed on AWS AgentCore. "
        "Use the tools available to you to help users."
    ),
    tools=[greet],
)

# AgentCore entry point
handler = agentcore_handler(agent)
'''

_ENV_TEMPLATE = '''# AWS Configuration
# Set these before deploying with: synth deploy --target agentcore
#
# Option 1: Use AWS CLI (recommended)
#   pip install awscli
#   aws configure
#
# Option 2: Set environment variables directly
AWS_DEFAULT_REGION=us-east-1
# AWS_ACCESS_KEY_ID=your-access-key
# AWS_SECRET_ACCESS_KEY=your-secret-key

# Synth Configuration
SYNTH_NO_BANNER=0
# SYNTH_TRACE_ENDPOINT=https://your-otel-collector/v1/traces
'''

_AGENT_README = '''# {name}

A {display} agent built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/).

## Setup

```bash
pip install synth-agent-sdk[{extra}]
{env_setup}```

## Run

```bash
synth run agent.py "Hello, who are you?"
synth dev agent.py
synth doctor
```
'''

_AGENTCORE_README = '''# {name}

An AI agent built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/) and deployed to AWS AgentCore.

## Setup

```bash
pip install synth-agent-sdk[agentcore]
pip install awscli
aws configure
cp .env.template .env
```

## Development

```bash
synth run agent.py "Hello, who are you?"
synth dev agent.py
synth doctor
```

## Deploy

```bash
synth deploy --target agentcore --dry-run agent.py
synth deploy --target agentcore agent.py
```
'''


def _create_agent(name: str, provider: str) -> None:
    """Scaffold an agent project for the given provider."""
    cfg = _PROVIDERS[provider]
    is_agentcore = provider == "agentcore"

    # Pre-flight checks for AgentCore
    if is_agentcore:
        try:
            import boto3  # noqa: F401
        except ImportError:
            click.echo(click.style(
                "boto3 is not installed. Install it with:\n"
                "  pip install synth-agent-sdk[agentcore]",
                fg="yellow",
            ))
            click.echo("")

        has_aws = bool(
            os.environ.get("AWS_ACCESS_KEY_ID")
            or os.path.exists(
                os.path.join(os.path.expanduser("~"), ".aws", "credentials"),
            )
        )
        if not has_aws:
            click.echo(click.style(
                "AWS credentials not found. Configure them with:\n"
                "  pip install awscli && aws configure",
                fg="yellow",
            ))
            click.echo("")

    # Llama/Ollama check
    if provider == "llama":
        click.echo(click.style(
            "Llama runs locally via Ollama. Make sure Ollama is installed:\n"
            "  https://ollama.com/download\n"
            "  ollama pull llama3.2",
            fg="yellow",
        ))
        click.echo("")

    _ensure_dir(name)

    # Write agent file
    if is_agentcore:
        _write(
            os.path.join(name, "agent.py"),
            _AGENTCORE_AGENT_TEMPLATE.format(**cfg),
        )
        _write(os.path.join(name, ".env.template"), _ENV_TEMPLATE)
        _write(
            os.path.join(name, "README.md"),
            _AGENTCORE_README.format(name=name, **cfg),
        )
    else:
        _write(
            os.path.join(name, "agent.py"),
            _AGENT_TEMPLATE.format(**cfg),
        )
        env_setup = (
            f'export {cfg["env_var"]}="your-key-here"\n'
            if cfg["env_var"]
            else ""
        )
        _write(
            os.path.join(name, "README.md"),
            _AGENT_README.format(name=name, env_setup=env_setup, **cfg),
        )

    # Success output
    files = [("agent.py", f'{cfg["display"]} agent')]
    if is_agentcore:
        files.append((".env.template", "Environment variable template"))
    files.append(("README.md", "Getting started guide"))
    _success_banner(name, files)

    steps = [f"cd {name}", f"pip install synth-agent-sdk[{cfg['extra']}]"]
    if cfg["env_var"]:
        steps.append(f'export {cfg["env_var"]}="your-key"')
    if provider == "llama":
        steps.append("ollama pull llama3.2")
    steps.append('synth run agent.py "Hello"')
    if is_agentcore:
        steps.append("synth deploy --target agentcore agent.py")
    _next_steps(steps)


# ---------------------------------------------------------------------------
# synth create tool
# ---------------------------------------------------------------------------

_TOOL_TEMPLATE = '''"""Custom tools for SynthAgentSDK agents.

Each function decorated with ``@tool`` becomes available to the agent.
Rules:
  - Every parameter needs a type annotation.
  - Must have a docstring (this is sent to the LLM as the tool description).
  - Can be sync or async.
"""

from __future__ import annotations

from synth import tool


@tool
def search(query: str, limit: int = 5) -> list[str]:
    """Search for information matching the query.

    Parameters
    ----------
    query:
        The search term.
    limit:
        Maximum number of results to return.
    """
    # TODO: Replace with your real search implementation
    return [f"Result {{i + 1}} for '{{query}}'" for i in range(limit)]


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely.

    Parameters
    ----------
    expression:
        A numeric expression like ``2 + 2`` or ``sqrt(16)``.
    """
    import math
    allowed_names = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    try:
        result = eval(expression, {{"__builtins__": {{}}}}, allowed_names)  # noqa: S307
        return str(result)
    except Exception as e:
        return f"Error: {{e}}"


@tool
async def fetch_url(url: str) -> str:
    """Fetch the text content of a URL (async example).

    Parameters
    ----------
    url:
        The URL to fetch.
    """
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, follow_redirects=True, timeout=10.0)
        resp.raise_for_status()
        return resp.text[:2000]
'''


def _create_tool(name: str) -> None:
    """Scaffold a standalone tools file."""
    filename = f"{name}.py" if not name.endswith(".py") else name

    if os.path.exists(filename):
        click.echo(
            click.style(f"File '{filename}' already exists.", fg="red"),
        )
        raise SystemExit(1)

    _write(filename, _TOOL_TEMPLATE)

    click.echo(click.style(f"Tool file created: {filename}", fg="green"))
    click.echo("")
    click.echo("  Use it in your agent:")
    click.echo("")
    click.echo(f"    from {name.replace('.py', '')} import search, calculate, fetch_url")
    click.echo("")
    click.echo("    agent = Agent(")
    click.echo("        model=\"claude-sonnet-4-5\",")
    click.echo("        tools=[search, calculate, fetch_url],")
    click.echo("    )")
    click.echo("")


# ---------------------------------------------------------------------------
# synth create mcp
# ---------------------------------------------------------------------------

_MCP_SERVER_TEMPLATE = '''"""MCP server built with FastMCP.

Run this server:
    python server.py            # stdio transport (default)
    python server.py --sse      # SSE transport for web clients

Register in your MCP config (.kiro/settings/mcp.json):
    {{
        "mcpServers": {{
            "{name}": {{
                "command": "python",
                "args": ["{name}/server.py"]
            }}
        }}
    }}
"""

from __future__ import annotations

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    raise SystemExit(
        "mcp package is not installed. Install it with:\\n"
        "  pip install mcp"
    )

mcp = FastMCP("{name}")


# ---------------------------------------------------------------------------
# Tools — callable functions the LLM can invoke
# ---------------------------------------------------------------------------

@mcp.tool()
def greet(name: str) -> str:
    """Greet a user by name."""
    return f"Hello, {{name}}!"


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers together."""
    return a + b


# ---------------------------------------------------------------------------
# Resources — data the LLM can read
# ---------------------------------------------------------------------------

@mcp.resource("info://status")
def get_status() -> str:
    """Return the current server status."""
    return "Server is running."


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    transport = "sse" if "--sse" in sys.argv else "stdio"
    mcp.run(transport=transport)
'''

_MCP_README = '''# {name}

An MCP (Model Context Protocol) server built with [FastMCP](https://github.com/jlowin/fastmcp).

## Setup

```bash
pip install mcp
```

## Run

```bash
python server.py          # stdio (for CLI / IDE integration)
python server.py --sse    # SSE (for web clients)
```

## Register

Add to your MCP config (`.kiro/settings/mcp.json`):

```json
{{
    "mcpServers": {{
        "{name}": {{
            "command": "python",
            "args": ["{name}/server.py"]
        }}
    }}
}}
```

## Adding Tools

```python
@mcp.tool()
def my_tool(param: str) -> str:
    """Description shown to the LLM."""
    return "result"
```

## Adding Resources

```python
@mcp.resource("data://my-resource")
def my_resource() -> str:
    """A readable data source for the LLM."""
    return "resource content"
```
'''


def _create_mcp(name: str) -> None:
    """Scaffold an MCP server project."""
    _ensure_dir(name)

    _write(os.path.join(name, "server.py"), _MCP_SERVER_TEMPLATE.format(name=name))
    _write(os.path.join(name, "README.md"), _MCP_README.format(name=name))

    _success_banner(name, [
        ("server.py", "MCP server with sample tools and resources"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install mcp",
        "python server.py",
    ])


# ---------------------------------------------------------------------------
# synth create team
# ---------------------------------------------------------------------------

_TEAM_PY = '''"""SynthAgentSDK multi-agent team architecture."""

from synth import Agent, AgentTeam, tool


# --- Specialist agents ---

@tool
def search_web(query: str) -> str:
    """Search the web for information."""
    # TODO: Replace with your real search implementation
    return f"Search results for: {{query}}"


@tool
def write_file(filename: str, content: str) -> str:
    """Write content to a file."""
    # TODO: Replace with your real file writing logic
    return f"Wrote {{len(content)}} chars to {{filename}}"


researcher = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are an expert researcher. Find accurate, up-to-date "
        "information on any topic using your search tool."
    ),
    tools=[search_web],
)

writer = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are a skilled technical writer. Turn research notes into "
        "clear, well-structured documents."
    ),
    tools=[write_file],
)

reviewer = Agent(
    model="claude-sonnet-4-5",
    instructions=(
        "You are a thorough reviewer. Check for accuracy, clarity, "
        "and completeness. Suggest improvements."
    ),
)


# --- Team orchestration ---

team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[researcher, writer, reviewer],
    strategy="auto",
)


if __name__ == "__main__":
    result = team.run(
        "Research Python async best practices and write a short guide."
    )
    print(result.answer)
'''

_PIPELINE_PY = '''"""SynthAgentSDK sequential pipeline example."""

from synth import Agent, Pipeline


researcher = Agent(
    model="claude-sonnet-4-5",
    instructions="You research topics and produce detailed notes.",
)

writer = Agent(
    model="claude-sonnet-4-5",
    instructions="You turn research notes into a well-written article.",
)

editor = Agent(
    model="claude-sonnet-4-5",
    instructions="You edit text for grammar, clarity, and conciseness.",
)

pipeline = Pipeline([researcher, writer, editor])


if __name__ == "__main__":
    result = pipeline.run("The future of AI agents in software development")
    print(result.text)
'''

_TEAM_README = '''# {name}

A multi-agent system built with [SynthAgentSDK](https://pypi.org/project/synth-agent-sdk/).

## Setup

```bash
pip install synth-agent-sdk[anthropic]
export ANTHROPIC_API_KEY="your-key-here"
```

## Run

Team mode (orchestrator decides routing):

```bash
synth run team.py "Research and write a guide on Python testing"
```

Pipeline mode (linear chain):

```bash
synth run pipeline.py "The history of open source software"
```
'''


def _create_team(name: str) -> None:
    """Scaffold a multi-agent team project."""
    _ensure_dir(name)

    _write(os.path.join(name, "team.py"), _TEAM_PY)
    _write(os.path.join(name, "pipeline.py"), _PIPELINE_PY)
    _write(os.path.join(name, "README.md"), _TEAM_README.format(name=name))

    _success_banner(name, [
        ("team.py", "Agent team (researcher + writer + reviewer)"),
        ("pipeline.py", "Sequential pipeline (research > write > edit)"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install synth-agent-sdk[anthropic]",
        'export ANTHROPIC_API_KEY="your-key"',
        'synth run team.py "Build a REST API guide"',
    ])


# ---------------------------------------------------------------------------
# synth create ui — local testing UI
# ---------------------------------------------------------------------------


def _create_ui(name: str) -> None:
    """Scaffold a local agent testing UI with a FastAPI bridge."""
    _ensure_dir(name)

    _write(os.path.join(name, "server.py"), _UI_SERVER)
    os.makedirs(os.path.join(name, "static"))
    _write(os.path.join(name, "static", "index.html"), _UI_HTML)
    _write(os.path.join(name, "static", "style.css"), _UI_CSS)
    _write(os.path.join(name, "static", "app.js"), _UI_JS)
    _write(os.path.join(name, "README.md"), _UI_README.format(name=name))

    _success_banner(name, [
        ("server.py", "FastAPI bridge (connects UI to your agent)"),
        ("static/index.html", "Agent testing interface"),
        ("static/style.css", "Styles"),
        ("static/app.js", "Client logic"),
        ("README.md", "Getting started guide"),
    ])
    _next_steps([
        f"cd {name}",
        "pip install uvicorn fastapi",
        "# Edit server.py to point AGENT_FILE at your agent",
        "python server.py",
        "# Open http://localhost:8420 in your browser",
    ])


_UI_SERVER = '''"""Local testing UI server — bridges the browser to your Synth agent.

Run:
    python server.py

Then open http://localhost:8420 in your browser.
"""

from __future__ import annotations

import importlib.util
import json
import sys
import time
from pathlib import Path

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
    from fastapi.staticfiles import StaticFiles
    import uvicorn
except ImportError:
    print("Missing dependencies. Install them with:")
    print("  pip install uvicorn fastapi")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Configuration — point this at your agent file
# ---------------------------------------------------------------------------
AGENT_FILE = "../agent.py"  # relative path to your agent module


# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = FastAPI(title="Synth Agent UI")
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")

_agent = None


def _load_agent():
    """Load (or reload) the agent from AGENT_FILE."""
    global _agent
    spec = importlib.util.spec_from_file_location("_agent_mod", AGENT_FILE)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load agent from '{AGENT_FILE}'")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "agent"):
        raise RuntimeError(f"'{AGENT_FILE}' must define an 'agent' variable.")
    _agent = mod.agent
    return _agent


@app.on_event("startup")
async def startup():
    """Load the agent on server start."""
    try:
        _load_agent()
        print(f"Agent loaded from {AGENT_FILE}")
    except Exception as exc:
        print(f"Warning: could not load agent: {exc}")
        print("You can still start the UI — fix the agent file and reload.")


@app.get("/", response_class=HTMLResponse)
async def index():
    """Serve the main UI."""
    html = (Path(__file__).parent / "static" / "index.html").read_text()
    return HTMLResponse(content=html)


@app.post("/api/chat")
async def chat(request: Request):
    """Send a prompt to the agent and return the result."""
    global _agent
    if _agent is None:
        return JSONResponse(
            {"error": "No agent loaded. Check AGENT_FILE in server.py."},
            status_code=503,
        )

    body = await request.json()
    prompt = body.get("prompt", "")
    if not prompt.strip():
        return JSONResponse({"error": "Empty prompt."}, status_code=400)

    start = time.perf_counter()
    try:
        result = _agent.run(prompt)
        elapsed = (time.perf_counter() - start) * 1000
        return JSONResponse({
            "text": result.text,
            "tokens": {
                "input": result.tokens.input_tokens,
                "output": result.tokens.output_tokens,
                "total": result.tokens.total_tokens,
            },
            "cost": result.cost,
            "latency_ms": round(elapsed, 1),
            "tool_calls": [
                {
                    "name": tc.name,
                    "args": tc.args,
                    "result": str(tc.result),
                    "latency_ms": round(tc.latency_ms, 1),
                }
                for tc in result.tool_calls
            ],
        })
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.post("/api/reload")
async def reload_agent():
    """Hot-reload the agent from disk."""
    try:
        _load_agent()
        return JSONResponse({"status": "reloaded"})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8420)
'''


_UI_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Synth Agent UI</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <div class="scanlines"></div>
    <div class="app">
        <header class="header">
            <div class="header-left">
                <div class="logo">SYNTH<span class="logo-dim">AGENT</span>SDK</div>
                <div class="status-badge" id="status">
                    <span class="status-dot"></span>
                    <span class="status-text">CONNECTED</span>
                </div>
            </div>
            <div class="header-right">
                <button class="btn btn-ghost" id="btn-reload" title="Reload agent">
                    &#x21bb; RELOAD
                </button>
                <button class="btn btn-ghost" id="btn-clear" title="Clear chat">
                    &#x2715; CLEAR
                </button>
            </div>
        </header>

        <main class="chat-area" id="chat-area">
            <div class="welcome">
                <pre class="welcome-art">
  _____ _  _ _  _ _____ _  _
 / ____| \\| | \\| |_   _| || |
 \\___ \\|  ` |  ` | | | | __ |
  ___) | |\\  | |\\  | | | | || |
 |____/|_| \\_|_| \\_| |_| |_||_|
                </pre>
                <p class="welcome-text">Agent testing interface ready.</p>
                <p class="welcome-hint">Type a message below to talk to your agent.</p>
            </div>
        </main>

        <footer class="input-area">
            <form id="chat-form" autocomplete="off">
                <div class="input-row">
                    <span class="prompt-caret">&#x25B6;</span>
                    <input
                        type="text"
                        id="prompt-input"
                        placeholder="Enter a prompt..."
                        autofocus
                        aria-label="Chat prompt"
                    />
                    <button type="submit" class="btn btn-send" id="btn-send">
                        SEND
                    </button>
                </div>
            </form>
            <div class="metrics-bar" id="metrics-bar"></div>
        </footer>
    </div>
    <script src="/static/app.js"></script>
</body>
</html>
'''


_UI_CSS = '''/* Synth Agent UI — terminal-inspired dark theme */

:root {
    --bg: #0a0e14;
    --bg-surface: #0d1117;
    --bg-elevated: #131920;
    --bg-input: #0d1117;
    --border: #1e2a35;
    --border-focus: #39ff14;
    --text: #c9d1d9;
    --text-dim: #6a7a8a;
    --text-bright: #e6edf3;
    --green: #39ff14;
    --green-dim: #1a7a0a;
    --green-glow: rgba(57, 255, 20, 0.15);
    --amber: #ffb627;
    --red: #ff4444;
    --cyan: #00e5ff;
    --font-mono: "SF Mono", "Cascadia Code", "Fira Code", "JetBrains Mono",
                 Consolas, "Courier New", monospace;
    --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                 Helvetica, Arial, sans-serif;
    --radius: 6px;
    --transition: 150ms ease;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
    height: 100%;
    background: var(--bg);
    color: var(--text);
    font-family: var(--font-mono);
    font-size: 14px;
    line-height: 1.6;
    overflow: hidden;
    -webkit-font-smoothing: antialiased;
}

/* CRT scanline overlay */
.scanlines {
    pointer-events: none;
    position: fixed;
    inset: 0;
    z-index: 9999;
    background: repeating-linear-gradient(
        0deg,
        transparent,
        transparent 2px,
        rgba(0, 0, 0, 0.03) 2px,
        rgba(0, 0, 0, 0.03) 4px
    );
}

/* Layout */
.app {
    display: flex;
    flex-direction: column;
    height: 100vh;
    max-width: 960px;
    margin: 0 auto;
    padding: 0 16px;
}

/* Header */
.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 0;
    border-bottom: 1px solid var(--border);
    flex-shrink: 0;
}

.header-left { display: flex; align-items: center; gap: 16px; }
.header-right { display: flex; gap: 8px; }

.logo {
    font-size: 18px;
    font-weight: 700;
    color: var(--green);
    letter-spacing: 2px;
    text-shadow: 0 0 10px var(--green-glow);
}
.logo-dim { color: var(--text-dim); font-weight: 400; }

.status-badge {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    border: 1px solid var(--green-dim);
    border-radius: 999px;
    font-size: 10px;
    letter-spacing: 1px;
    color: var(--green);
}
.status-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--green);
    box-shadow: 0 0 6px var(--green);
    animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
}

/* Buttons */
.btn {
    font-family: var(--font-mono);
    font-size: 11px;
    letter-spacing: 1px;
    border: none;
    border-radius: var(--radius);
    cursor: pointer;
    transition: all var(--transition);
    padding: 6px 14px;
}
.btn-ghost {
    background: transparent;
    color: var(--text-dim);
    border: 1px solid var(--border);
}
.btn-ghost:hover {
    color: var(--text-bright);
    border-color: var(--text-dim);
    background: var(--bg-elevated);
}
.btn-send {
    background: var(--green-dim);
    color: var(--green);
    border: 1px solid var(--green);
    font-weight: 600;
    min-width: 80px;
}
.btn-send:hover {
    background: var(--green);
    color: var(--bg);
    box-shadow: 0 0 16px var(--green-glow);
}
.btn-send:disabled {
    opacity: 0.4;
    cursor: not-allowed;
}

/* Chat area */
.chat-area {
    flex: 1;
    overflow-y: auto;
    padding: 24px 0;
    scroll-behavior: smooth;
}
.chat-area::-webkit-scrollbar { width: 4px; }
.chat-area::-webkit-scrollbar-track { background: transparent; }
.chat-area::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

/* Welcome */
.welcome {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    text-align: center;
    opacity: 0.6;
}
.welcome-art {
    color: var(--green);
    font-size: 12px;
    line-height: 1.3;
    margin-bottom: 16px;
    text-shadow: 0 0 8px var(--green-glow);
}
.welcome-text { color: var(--text); font-size: 14px; margin-bottom: 4px; }
.welcome-hint { color: var(--text-dim); font-size: 12px; }

/* Messages */
.message {
    margin-bottom: 20px;
    animation: fadeIn 200ms ease;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(6px); }
    to { opacity: 1; transform: translateY(0); }
}

.msg-label {
    font-size: 10px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-bottom: 6px;
    font-weight: 600;
}
.msg-label-user { color: var(--cyan); }
.msg-label-agent { color: var(--green); }
.msg-label-error { color: var(--red); }

.msg-body {
    padding: 12px 16px;
    border-radius: var(--radius);
    border: 1px solid var(--border);
    white-space: pre-wrap;
    word-break: break-word;
    font-family: var(--font-sans);
    font-size: 14px;
    line-height: 1.7;
}
.msg-user .msg-body {
    background: var(--bg-elevated);
    border-color: var(--border);
}
.msg-agent .msg-body {
    background: var(--bg-surface);
    border-left: 3px solid var(--green-dim);
}
.msg-error .msg-body {
    background: rgba(255, 68, 68, 0.08);
    border-color: var(--red);
    color: var(--red);
}

/* Tool calls */
.tool-calls {
    margin-top: 10px;
    border-top: 1px dashed var(--border);
    padding-top: 10px;
}
.tool-call {
    font-family: var(--font-mono);
    font-size: 12px;
    padding: 8px 12px;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    margin-bottom: 6px;
}
.tool-name {
    color: var(--amber);
    font-weight: 600;
}
.tool-args { color: var(--text-dim); }
.tool-result { color: var(--text); margin-top: 4px; }
.tool-latency { color: var(--text-dim); font-size: 10px; }

/* Loading indicator */
.loading {
    display: inline-flex;
    gap: 4px;
    padding: 12px 16px;
}
.loading-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--green);
    animation: bounce 1.2s ease-in-out infinite;
}
.loading-dot:nth-child(2) { animation-delay: 0.15s; }
.loading-dot:nth-child(3) { animation-delay: 0.3s; }
@keyframes bounce {
    0%, 80%, 100% { transform: scale(0.6); opacity: 0.3; }
    40% { transform: scale(1); opacity: 1; }
}

/* Input area */
.input-area {
    flex-shrink: 0;
    padding: 16px 0;
    border-top: 1px solid var(--border);
}
.input-row {
    display: flex;
    align-items: center;
    gap: 10px;
    background: var(--bg-input);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 4px 8px;
    transition: border-color var(--transition);
}
.input-row:focus-within {
    border-color: var(--border-focus);
    box-shadow: 0 0 0 2px var(--green-glow);
}
.prompt-caret {
    color: var(--green);
    font-size: 12px;
    flex-shrink: 0;
    padding-left: 4px;
}
#prompt-input {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    color: var(--text-bright);
    font-family: var(--font-mono);
    font-size: 14px;
    padding: 10px 4px;
    caret-color: var(--green);
}
#prompt-input::placeholder { color: var(--text-dim); }

/* Metrics bar */
.metrics-bar {
    display: flex;
    gap: 20px;
    padding: 8px 4px 0;
    font-size: 11px;
    color: var(--text-dim);
    letter-spacing: 0.5px;
    min-height: 22px;
}
.metric-item { display: flex; gap: 6px; }
.metric-label { color: var(--text-dim); }
.metric-value { color: var(--text); }

/* Responsive */
@media (max-width: 640px) {
    .app { padding: 0 10px; }
    .header { flex-direction: column; gap: 10px; align-items: flex-start; }
    .header-right { width: 100%; justify-content: flex-end; }
    .welcome-art { font-size: 9px; }
}
'''


_UI_JS = '''/* Synth Agent UI — client logic */

const chatArea = document.getElementById("chat-area");
const chatForm = document.getElementById("chat-form");
const promptInput = document.getElementById("prompt-input");
const btnSend = document.getElementById("btn-send");
const btnClear = document.getElementById("btn-clear");
const btnReload = document.getElementById("btn-reload");
const metricsBar = document.getElementById("metrics-bar");
const statusBadge = document.getElementById("status");

let isLoading = false;

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

function clearWelcome() {
    const welcome = chatArea.querySelector(".welcome");
    if (welcome) welcome.remove();
}

function scrollToBottom() {
    chatArea.scrollTop = chatArea.scrollHeight;
}

function setStatus(text, ok) {
    const dot = statusBadge.querySelector(".status-dot");
    const label = statusBadge.querySelector(".status-text");
    label.textContent = text;
    dot.style.background = ok ? "var(--green)" : "var(--red)";
    dot.style.boxShadow = ok ? "0 0 6px var(--green)" : "0 0 6px var(--red)";
    statusBadge.style.borderColor = ok ? "var(--green-dim)" : "var(--red)";
    statusBadge.style.color = ok ? "var(--green)" : "var(--red)";
}

/* ------------------------------------------------------------------ */
/* Message rendering                                                   */
/* ------------------------------------------------------------------ */

function addUserMessage(text) {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-user";
    div.innerHTML =
        \'<div class="msg-label msg-label-user">YOU</div>\' +
        \'<div class="msg-body">\' + escapeHtml(text) + "</div>";
    chatArea.appendChild(div);
    scrollToBottom();
}

function addAgentMessage(data) {
    const div = document.createElement("div");
    div.className = "message msg-agent";

    let toolHtml = "";
    if (data.tool_calls && data.tool_calls.length > 0) {
        toolHtml = \'<div class="tool-calls">\';
        for (const tc of data.tool_calls) {
            toolHtml +=
                \'<div class="tool-call">\' +
                \'<span class="tool-name">\' + escapeHtml(tc.name) + "</span> " +
                \'<span class="tool-args">\' + escapeHtml(JSON.stringify(tc.args)) + "</span>" +
                \'<div class="tool-result">\' + escapeHtml(tc.result) + "</div>" +
                \'<div class="tool-latency">\' + tc.latency_ms + "ms</div>" +
                "</div>";
        }
        toolHtml += "</div>";
    }

    div.innerHTML =
        \'<div class="msg-label msg-label-agent">AGENT</div>\' +
        \'<div class="msg-body">\' + escapeHtml(data.text) + toolHtml + "</div>";
    chatArea.appendChild(div);
    scrollToBottom();

    /* Update metrics bar */
    metricsBar.innerHTML =
        \'<div class="metric-item"><span class="metric-label">Tokens:</span>\' +
        \'<span class="metric-value">\' + data.tokens.total + "</span></div>" +
        \'<div class="metric-item"><span class="metric-label">Cost:</span>\' +
        \'<span class="metric-value">$\' + data.cost.toFixed(4) + "</span></div>" +
        \'<div class="metric-item"><span class="metric-label">Latency:</span>\' +
        \'<span class="metric-value">\' + data.latency_ms + "ms</span></div>" +
        \'<div class="metric-item"><span class="metric-label">Tools:</span>\' +
        \'<span class="metric-value">\' + data.tool_calls.length + "</span></div>";
}

function addErrorMessage(text) {
    const div = document.createElement("div");
    div.className = "message msg-error";
    div.innerHTML =
        \'<div class="msg-label msg-label-error">ERROR</div>\' +
        \'<div class="msg-body">\' + escapeHtml(text) + "</div>";
    chatArea.appendChild(div);
    scrollToBottom();
}

function showLoading() {
    const div = document.createElement("div");
    div.className = "message msg-agent";
    div.id = "loading-msg";
    div.innerHTML =
        \'<div class="msg-label msg-label-agent">AGENT</div>\' +
        \'<div class="loading">\' +
        \'<div class="loading-dot"></div>\' +
        \'<div class="loading-dot"></div>\' +
        \'<div class="loading-dot"></div>\' +
        "</div>";
    chatArea.appendChild(div);
    scrollToBottom();
}

function hideLoading() {
    const el = document.getElementById("loading-msg");
    if (el) el.remove();
}

/* ------------------------------------------------------------------ */
/* API calls                                                           */
/* ------------------------------------------------------------------ */

async function sendPrompt(prompt) {
    if (isLoading) return;
    isLoading = true;
    btnSend.disabled = true;
    addUserMessage(prompt);
    showLoading();

    try {
        const resp = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt }),
        });
        const data = await resp.json();
        hideLoading();

        if (data.error) {
            addErrorMessage(data.error);
            setStatus("ERROR", false);
        } else {
            addAgentMessage(data);
            setStatus("CONNECTED", true);
        }
    } catch (err) {
        hideLoading();
        addErrorMessage("Network error: " + err.message);
        setStatus("DISCONNECTED", false);
    } finally {
        isLoading = false;
        btnSend.disabled = false;
        promptInput.focus();
    }
}

async function reloadAgent() {
    try {
        const resp = await fetch("/api/reload", { method: "POST" });
        const data = await resp.json();
        if (data.error) {
            addErrorMessage("Reload failed: " + data.error);
        } else {
            setStatus("RELOADED", true);
            setTimeout(() => setStatus("CONNECTED", true), 2000);
        }
    } catch (err) {
        addErrorMessage("Reload error: " + err.message);
        setStatus("DISCONNECTED", false);
    }
}

/* ------------------------------------------------------------------ */
/* Event listeners                                                     */
/* ------------------------------------------------------------------ */

chatForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = promptInput.value.trim();
    if (!text) return;
    promptInput.value = "";
    sendPrompt(text);
});

btnClear.addEventListener("click", () => {
    chatArea.innerHTML =
        \'<div class="welcome">\' +
        \'<p class="welcome-text">Chat cleared.</p>\' +
        \'<p class="welcome-hint">Type a message below to start again.</p>\' +
        "</div>";
    metricsBar.innerHTML = "";
});

btnReload.addEventListener("click", reloadAgent);

/* Keyboard shortcut: Ctrl+Enter to send */
promptInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        chatForm.dispatchEvent(new Event("submit"));
    }
});
'''


_UI_README = '''# {name}

A local testing UI for your SynthAgentSDK agent.

## Setup

```bash
pip install uvicorn fastapi
```

## Usage

1. Edit `server.py` and set `AGENT_FILE` to point at your agent module.
2. Start the server:

```bash
python server.py
```

3. Open http://localhost:8420 in your browser.

## Features

- Chat interface with your agent in real time
- Tool call inspection (name, args, result, latency)
- Token / cost / latency metrics per response
- Hot-reload button to pick up agent changes without restarting
- CRT scanline aesthetic matching the Synth boot sequence
'''

