"""``synth dev`` command — rich terminal UI for interactive agent development.

Provides a Fallout-inspired terminal interface with:
- Streaming responses with token-by-token rendering
- Slash commands (/tools, /reload, /trace, /clear, /export, /help)
- Tool call visualization with spinners
- Persistent status bar (model, tokens, cost, latency)
- Markdown rendering for agent responses
- Command history with up/down arrows
- Multi-line input support (backslash continuation)

Falls back to a basic REPL if ``rich`` or ``prompt_toolkit`` are not
installed.
"""

from __future__ import annotations

import sys

import click

from synth.errors import SynthError


def run_dev(file: str) -> None:
    """Start the interactive dev environment.

    Attempts to launch the rich TUI. Falls back to the basic REPL
    if ``rich`` or ``prompt_toolkit`` are not installed.
    """
    try:
        from synth.cli._tui import launch_tui
        launch_tui(file)
    except ImportError:
        click.echo(
            click.style(
                "Install rich TUI dependencies for the full experience:\n"
                "  pip install synth-agent-sdk[dev]\n"
                "Falling back to basic REPL...\n",
                fg="yellow",
            ),
        )
        _run_basic_repl(file)


def _run_basic_repl(file: str) -> None:
    """Basic REPL fallback when rich/prompt_toolkit are unavailable."""
    from synth.cli.run_cmd import _load_agent

    click.echo(click.style("Synth Dev Mode (basic)", fg="green"))
    click.echo(f"Loading agent from: {file}")

    try:
        agent = _load_agent(file)
    except SystemExit:
        return

    click.echo("Agent loaded. Type a prompt (Ctrl+C to exit).\n")

    while True:
        try:
            prompt = click.prompt("synth>", prompt_suffix=" ")
            if not prompt.strip():
                continue
            result = agent.run(prompt)
            click.echo(result.text)
            click.echo(
                click.style(
                    f"  [{result.tokens.total_tokens} tokens | "
                    f"${result.cost:.4f} | {result.latency_ms:.0f}ms]",
                    fg="bright_black",
                ),
            )
        except (KeyboardInterrupt, EOFError):
            click.echo("\nExiting dev mode.")
            break
        except SynthError as exc:
            click.echo(click.style(f"Error: {exc}", fg="red"))
            click.echo(
                click.style(f"Suggestion: {exc.suggestion}", fg="yellow"),
            )
