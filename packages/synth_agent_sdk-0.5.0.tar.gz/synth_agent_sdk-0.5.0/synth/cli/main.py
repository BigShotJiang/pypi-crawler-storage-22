"""CLI entry point for the Synth SDK.

Click-based CLI with ``synth`` as the root command.  Registers all
subcommands: ``dev``, ``run``, ``eval``, ``trace``, ``deploy``,
``doctor``, ``create`` (group), ``init``, ``bench``, and ``help``.
"""

from __future__ import annotations

import click

from synth.cli.banner import display_boot_sequence


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Synth SDK — Autonomous agents, engineered."""
    display_boot_sequence()
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ------------------------------------------------------------------
# Existing commands (lazy imports to avoid circular deps)
# ------------------------------------------------------------------

@cli.command("run")
@click.argument("file")
@click.argument("prompt")
def run_cmd(file: str, prompt: str) -> None:
    """Execute an agent with a prompt."""
    from synth.cli.run_cmd import run_agent

    run_agent(file, prompt)


@cli.command("eval")
@click.argument("file")
@click.option("--dataset", required=True, help="Path to JSON dataset.")
@click.option(
    "--threshold", default=0.5, type=float, help="Pass rate threshold.",
)
def eval_cmd(file: str, dataset: str, threshold: float) -> None:
    """Run evaluation suite against an agent."""
    from synth.cli.eval_cmd import run_eval

    run_eval(file, dataset, threshold)


@cli.command("dev")
@click.argument("file")
def dev_cmd(file: str) -> None:
    """Start local REPL with hot-reload."""
    from synth.cli.dev import run_dev

    run_dev(file)


@cli.command("trace")
@click.argument("run_id")
def trace_cmd(run_id: str) -> None:
    """Open stored trace in browser."""
    from synth.cli.trace_cmd import show_trace

    show_trace(run_id)


@cli.command("deploy")
@click.option(
    "--target", required=True, help="Deployment target (e.g. agentcore).",
)
@click.option("--dry-run", is_flag=True, help="Validate without deploying.")
@click.argument("file", required=False)
def deploy_cmd(target: str, dry_run: bool, file: str | None) -> None:
    """Deploy agent to a target platform."""
    from synth.cli.deploy_cmd import run_deploy

    run_deploy(target, dry_run, file)


@cli.command("doctor")
def doctor_cmd() -> None:
    """Check environment, credentials, and dependencies."""
    from synth.cli.doctor import run_doctor

    run_doctor()


# ------------------------------------------------------------------
# synth help
# ------------------------------------------------------------------

@cli.command("help")
def help_cmd() -> None:
    """Show the getting-started guide and command reference."""
    from synth.cli.help_cmd import run_help

    run_help()


# ------------------------------------------------------------------
# synth init
# ------------------------------------------------------------------

@cli.command("init")
def init_cmd() -> None:
    """Interactive project setup (like npm init for agents)."""
    from synth.cli.init_cmd import run_init

    run_init()


# ------------------------------------------------------------------
# synth bench
# ------------------------------------------------------------------

@cli.command("bench")
@click.argument("file")
@click.argument("prompt")
@click.option(
    "--runs", "-n", default=10, type=int,
    help="Number of benchmark runs.",
)
@click.option(
    "--warmup", "-w", default=1, type=int,
    help="Number of warmup runs (not counted).",
)
def bench_cmd(file: str, prompt: str, runs: int, warmup: int) -> None:
    """Benchmark agent performance over multiple runs.

    \b
    Reports p50/p95/p99 latency, token usage, and cost.

    \b
    Examples:
      synth bench agent.py "Hello" --runs 20
      synth bench agent.py "Summarize this" -n 50 -w 3
    """
    from synth.cli.bench_cmd import run_bench

    run_bench(file, prompt, runs, warmup)


# ------------------------------------------------------------------
# synth create (group)
# ------------------------------------------------------------------

@cli.group("create")
def create_group() -> None:
    """Scaffold agents, tools, MCP servers, teams, and UIs.

    \b
    Subcommands:
      agent   Scaffold a new agent (interactive provider selection)
      team    Scaffold a multi-agent team + pipeline
      tool    Generate a standalone tools file
      mcp     Scaffold an MCP server with FastMCP
      ui      Scaffold a local browser-based testing UI
    """


_PROVIDER_CHOICES = click.Choice(
    ["anthropic", "openai", "llama", "gemini", "agentcore"],
    case_sensitive=False,
)


@create_group.command("agent")
@click.argument("name")
@click.option(
    "--provider", "-p",
    type=_PROVIDER_CHOICES,
    default=None,
    help="LLM provider (prompted interactively if omitted).",
)
def create_agent_cmd(name: str, provider: str | None) -> None:
    """Scaffold a new agent project.

    \b
    Providers:
      anthropic   Claude (default)
      openai      GPT-4o
      llama       Llama 3 via Ollama (local)
      gemini      Google Gemini
      agentcore   AWS AgentCore (Bedrock)

    \b
    Examples:
      synth create agent my-bot
      synth create agent my-bot --provider openai
    """
    from synth.cli.create_cmd import _create_agent, _PROVIDERS

    if provider is None:
        click.echo("")
        click.echo(
            click.style("  What type of agent?", fg="cyan"),
        )
        click.echo("")
        for key, cfg in _PROVIDERS.items():
            click.echo(f"    {click.style(key, fg='green'):<22s} {cfg['display']}")
        click.echo("")
        provider = click.prompt(
            "  Provider",
            type=_PROVIDER_CHOICES,
            default="anthropic",
        )

    _create_agent(name, provider.lower())


@create_group.command("team")
@click.argument("name")
def create_team_cmd(name: str) -> None:
    """Scaffold a multi-agent team + pipeline project."""
    from synth.cli.create_cmd import _create_team

    _create_team(name)


@create_group.command("tool")
@click.argument("name")
def create_tool_cmd(name: str) -> None:
    """Generate a standalone tools file with sync/async examples."""
    from synth.cli.create_cmd import _create_tool

    _create_tool(name)


@create_group.command("mcp")
@click.argument("name")
def create_mcp_cmd(name: str) -> None:
    """Scaffold an MCP server project with FastMCP."""
    from synth.cli.create_cmd import _create_mcp

    _create_mcp(name)


@create_group.command("ui")
@click.argument("name")
def create_ui_cmd(name: str) -> None:
    """Scaffold a local browser-based agent testing UI."""
    from synth.cli.create_cmd import _create_ui

    _create_ui(name)
