"""``@agentcore_handler`` decorator for the Synth SDK.

Wraps a Synth ``Agent`` or ``Graph`` into an AWS AgentCore-compatible
request handler that conforms to the AgentCore runtime invocation contract.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from synth.deploy.agentcore.adapter import AgentCoreAdapter


def agentcore_handler(agent_or_graph: Any) -> Callable[[dict[str, Any]], dict[str, Any]]:
    """Wrap an Agent or Graph into an AgentCore-compatible handler.

    Parameters
    ----------
    agent_or_graph:
        A Synth ``Agent`` or ``Graph`` instance.

    Returns
    -------
    Callable
        A function ``(payload: dict) -> dict`` suitable for AgentCore.
    """
    adapter = AgentCoreAdapter(agent_or_graph)

    def handler(payload: dict[str, Any]) -> dict[str, Any]:
        """AgentCore invocation handler."""
        return adapter.handle_invocation(payload)

    handler._synth_adapter = adapter  # type: ignore[attr-defined]
    return handler
