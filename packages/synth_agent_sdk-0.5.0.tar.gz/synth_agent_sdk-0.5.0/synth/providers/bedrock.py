"""BedrockProvider — AWS Bedrock Runtime model adapter.

Routes requests through the AWS Bedrock Runtime API using ``boto3``.
Supports both short-form model IDs (``bedrock/claude-sonnet-4-5``) and
full ARN-style identifiers
(``bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0``).

AWS credentials are resolved from the environment (IAM role, env vars,
or AWS config) — no Synth-specific API key is required.
"""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import Any

from synth.errors import SynthConfigError
from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage

try:
    import boto3
except ImportError:
    boto3 = None  # type: ignore[assignment]


class BedrockProvider(BaseProvider):
    """LLM provider adapter for AWS Bedrock Runtime.

    Parameters
    ----------
    model:
        Model identifier, e.g. ``"bedrock/claude-sonnet-4-5"`` or
        ``"bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"``.
        The ``bedrock/`` prefix is stripped before calling the API.
    base_url:
        Optional custom Bedrock endpoint URL.
    **kwargs:
        Extra options forwarded to the ``boto3`` client constructor
        (e.g. ``region_name``).
    """

    def __init__(self, model: str, base_url: str | None = None, **kwargs: Any) -> None:
        if boto3 is None:
            raise SynthConfigError(
                message="Provider package 'boto3' is not installed. "
                "Run: pip install synth-agent-sdk[bedrock]",
                component="BedrockProvider",
                suggestion="pip install synth-agent-sdk[bedrock]",
            )

        # Strip the "bedrock/" prefix for the actual model ID
        self._model_id = model.removeprefix("bedrock/")

        client_kwargs: dict[str, Any] = {}
        if base_url is not None:
            client_kwargs["endpoint_url"] = base_url
        if "region_name" in kwargs:
            client_kwargs["region_name"] = kwargs.pop("region_name")

        self._client = boto3.client("bedrock-runtime", **client_kwargs)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def _build_messages(
        self, messages: list[Message]
    ) -> tuple[list[dict[str, Any]] | None, list[dict[str, Any]]]:
        """Split messages into system prompts and Bedrock message list."""
        system: list[dict[str, Any]] | None = None
        api_messages: list[dict[str, Any]] = []
        for msg in messages:
            if msg["role"] == "system":
                system = [{"text": msg["content"]}]
            else:
                api_messages.append({
                    "role": msg["role"],
                    "content": [{"text": msg["content"]}],
                })
        return system, api_messages

    def _build_tool_config(
        self, tools: list[dict[str, Any]] | None
    ) -> dict[str, Any] | None:
        """Convert Synth tool schemas to Bedrock toolConfiguration format."""
        if not tools:
            return None
        tool_specs = []
        for t in tools:
            tool_specs.append({
                "toolSpec": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "inputSchema": {
                        "json": t.get("parameters", {}),
                    },
                }
            })
        return {"tools": tool_specs}

    # -----------------------------------------------------------------
    # BaseProvider interface
    # -----------------------------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Send a completion request to the AWS Bedrock Runtime Converse API.

        Uses the synchronous ``boto3`` client wrapped in an executor to
        avoid blocking the event loop.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``maxTokens``, etc.).
        """
        import asyncio

        system, api_messages = self._build_messages(messages)
        api_kwargs: dict[str, Any] = {
            "modelId": self._model_id,
            "messages": api_messages,
        }
        if system is not None:
            api_kwargs["system"] = system

        tool_config = self._build_tool_config(tools)
        if tool_config is not None:
            api_kwargs["toolConfig"] = tool_config

        if kwargs:
            inference_config: dict[str, Any] = {}
            if "temperature" in kwargs:
                inference_config["temperature"] = kwargs.pop("temperature")
            if "max_tokens" in kwargs:
                inference_config["maxTokens"] = kwargs.pop("max_tokens")
            if inference_config:
                api_kwargs["inferenceConfig"] = inference_config

        loop = asyncio.get_running_loop()
        response = await loop.run_in_executor(
            None, lambda: self._client.converse(**api_kwargs)
        )

        # Parse response
        text_parts: list[str] = []
        tool_calls: list[ToolCallInfo] = []
        output = response.get("output", {})
        message_content = output.get("message", {}).get("content", [])
        for block in message_content:
            if "text" in block:
                text_parts.append(block["text"])
            elif "toolUse" in block:
                tu = block["toolUse"]
                tool_calls.append(
                    ToolCallInfo(
                        id=tu.get("toolUseId", ""),
                        name=tu.get("name", ""),
                        args=tu.get("input", {}),
                    )
                )

        usage_data = response.get("usage", {})
        usage = TokenUsage(
            input_tokens=usage_data.get("inputTokens", 0),
            output_tokens=usage_data.get("outputTokens", 0),
            total_tokens=usage_data.get("totalTokens", 0),
        )

        return ProviderResponse(
            text="".join(text_parts),
            usage=usage,
            tool_calls=tool_calls,
            raw=response,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Stream a completion from the AWS Bedrock Runtime Converse API.

        Uses ``converseStream`` via the synchronous ``boto3`` client,
        processing the event stream in an executor to avoid blocking.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``maxTokens``, etc.).
        """
        import asyncio

        system, api_messages = self._build_messages(messages)
        api_kwargs: dict[str, Any] = {
            "modelId": self._model_id,
            "messages": api_messages,
        }
        if system is not None:
            api_kwargs["system"] = system

        tool_config = self._build_tool_config(tools)
        if tool_config is not None:
            api_kwargs["toolConfig"] = tool_config

        if kwargs:
            inference_config: dict[str, Any] = {}
            if "temperature" in kwargs:
                inference_config["temperature"] = kwargs.pop("temperature")
            if "max_tokens" in kwargs:
                inference_config["maxTokens"] = kwargs.pop("max_tokens")
            if inference_config:
                api_kwargs["inferenceConfig"] = inference_config

        input_tokens = 0
        output_tokens = 0

        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None, lambda: self._client.converse_stream(**api_kwargs)
            )

            event_stream = response.get("stream", [])
            for event in event_stream:
                if "contentBlockDelta" in event:
                    delta = event["contentBlockDelta"].get("delta", {})
                    if "text" in delta:
                        yield TextChunkEvent(text=delta["text"])
                    elif "toolUse" in delta:
                        tu = delta["toolUse"]
                        yield ToolCallChunkEvent(
                            id=tu.get("toolUseId", ""),
                            name=tu.get("name", ""),
                            args=tu.get("input", {}),
                        )
                elif "metadata" in event:
                    usage_data = event["metadata"].get("usage", {})
                    input_tokens = usage_data.get("inputTokens", 0)
                    output_tokens = usage_data.get("outputTokens", 0)

            yield ProviderDoneEvent(
                usage=TokenUsage(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                )
            )
        except Exception as exc:
            yield ProviderErrorEvent(error=exc)
