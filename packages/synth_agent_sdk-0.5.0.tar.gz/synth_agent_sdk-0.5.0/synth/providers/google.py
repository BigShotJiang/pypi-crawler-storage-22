"""GoogleProvider — Google Gemini model adapter.

Routes requests to the Google Generative AI API using the
``google-generativeai`` SDK.  The SDK is lazily imported so that users
who don't need Google don't pay the import cost or require the package.
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from typing import Any

from synth.errors import SynthConfigError
from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage

try:
    import google.generativeai as genai
except ImportError:
    genai = None  # type: ignore[assignment]


class GoogleProvider(BaseProvider):
    """LLM provider adapter for Google Gemini models.

    Parameters
    ----------
    model:
        Model identifier, e.g. ``"gemini-2.0-flash"``.
    base_url:
        Optional custom API endpoint (passed as ``client_options``).
    **kwargs:
        Extra options forwarded to the generative model constructor.
    """

    def __init__(self, model: str, base_url: str | None = None, **kwargs: Any) -> None:
        if genai is None:
            raise SynthConfigError(
                message="Provider package 'google-generativeai' is not installed. "
                "Run: pip install synth-agent-sdk[google]",
                component="GoogleProvider",
                suggestion="pip install synth-agent-sdk[google]",
            )

        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise SynthConfigError(
                message="GOOGLE_API_KEY environment variable is not set.",
                component="GoogleProvider",
                suggestion="Set the GOOGLE_API_KEY environment variable. "
                "Get your key at https://aistudio.google.com/apikey",
            )

        self._model_name = model

        client_options: dict[str, Any] | None = None
        if base_url is not None:
            client_options = {"api_endpoint": base_url}

        genai.configure(api_key=api_key, client_options=client_options)
        self._generative_model = genai.GenerativeModel(model, **kwargs)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def _build_messages(
        self, messages: list[Message]
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert Synth messages to Gemini content format."""
        system: str | None = None
        contents: list[dict[str, Any]] = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                role = "model" if msg["role"] == "assistant" else "user"
                contents.append({"role": role, "parts": [msg["content"]]})
        return system, contents

    def _build_tools(
        self, tools: list[dict[str, Any]] | None
    ) -> list[Any] | None:
        """Convert Synth tool schemas to Gemini function declarations."""
        if not tools:
            return None
        declarations = []
        for t in tools:
            declarations.append(genai.protos.FunctionDeclaration(
                name=t["name"],
                description=t.get("description", ""),
                parameters=t.get("parameters", {}),
            ))
        return [genai.protos.Tool(function_declarations=declarations)]

    # -----------------------------------------------------------------
    # BaseProvider interface
    # -----------------------------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Send a completion request to the Google Generative AI API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra generation config options.
        """
        system, contents = self._build_messages(messages)
        gen_kwargs: dict[str, Any] = {**kwargs}

        gemini_tools = self._build_tools(tools)
        if gemini_tools is not None:
            gen_kwargs["tools"] = gemini_tools

        model = self._generative_model
        if system is not None:
            model = genai.GenerativeModel(
                self._model_name, system_instruction=system
            )

        response = await model.generate_content_async(contents, **gen_kwargs)

        # Parse response
        text = ""
        tool_calls: list[ToolCallInfo] = []
        if response.candidates:
            candidate = response.candidates[0]
            for part in candidate.content.parts:
                if part.text:
                    text += part.text
                elif part.function_call:
                    fc = part.function_call
                    tool_calls.append(
                        ToolCallInfo(
                            id=fc.name,
                            name=fc.name,
                            args=dict(fc.args) if fc.args else {},
                        )
                    )

        usage_meta = response.usage_metadata
        usage = TokenUsage(
            input_tokens=getattr(usage_meta, "prompt_token_count", 0),
            output_tokens=getattr(usage_meta, "candidates_token_count", 0),
            total_tokens=getattr(usage_meta, "total_token_count", 0),
        )

        return ProviderResponse(
            text=text,
            usage=usage,
            tool_calls=tool_calls,
            raw=response,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Stream a completion from the Google Generative AI API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra generation config options.
        """
        system, contents = self._build_messages(messages)
        gen_kwargs: dict[str, Any] = {"stream": True, **kwargs}

        gemini_tools = self._build_tools(tools)
        if gemini_tools is not None:
            gen_kwargs["tools"] = gemini_tools

        model = self._generative_model
        if system is not None:
            model = genai.GenerativeModel(
                self._model_name, system_instruction=system
            )

        input_tokens = 0
        output_tokens = 0
        total_tokens = 0

        try:
            response = await model.generate_content_async(contents, **gen_kwargs)
            async for chunk in response:
                if chunk.usage_metadata:
                    input_tokens = getattr(
                        chunk.usage_metadata, "prompt_token_count", 0
                    )
                    output_tokens = getattr(
                        chunk.usage_metadata, "candidates_token_count", 0
                    )
                    total_tokens = getattr(
                        chunk.usage_metadata, "total_token_count", 0
                    )

                if chunk.candidates:
                    for part in chunk.candidates[0].content.parts:
                        if part.text:
                            yield TextChunkEvent(text=part.text)
                        elif part.function_call:
                            fc = part.function_call
                            yield ToolCallChunkEvent(
                                id=fc.name,
                                name=fc.name,
                                args=dict(fc.args) if fc.args else {},
                            )

            yield ProviderDoneEvent(
                usage=TokenUsage(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=total_tokens,
                )
            )
        except Exception as exc:
            yield ProviderErrorEvent(error=exc)
