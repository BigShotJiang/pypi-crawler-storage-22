"""Property-based tests for the boot sequence.

**Property 43: Boot sequence monochrome in no-color mode**
**Validates: Requirements 19.9**

**Property 44: Boot sequence display idempotence**
**Validates: Requirements 19.10**
"""

from __future__ import annotations

import io
from unittest.mock import patch

from hypothesis import given, settings
from hypothesis import strategies as st

import synth.cli.banner as banner_mod


# ---------------------------------------------------------------------------
# Property 43: Boot sequence monochrome in no-color mode
# ---------------------------------------------------------------------------


@settings(max_examples=10)
@given(data=st.data())
def test_boot_sequence_monochrome_in_no_color_mode(data):
    """Property 43: Boot sequence monochrome in no-color mode.

    When NO_COLOR is set or stdout is not a TTY, the output should
    contain zero ANSI escape code sequences.

    **Validates: Requirements 19.9**
    """
    # Reset session flag
    banner_mod._DISPLAYED = False

    captured = io.StringIO()

    with (
        patch.dict("os.environ", {"NO_COLOR": "1"}, clear=False),
        patch("builtins.print", side_effect=lambda *a, **kw: captured.write(str(a[0]) + "\n") if a else None),
        patch("time.sleep"),  # skip delays
    ):
        banner_mod.display_boot_sequence()

    output = captured.getvalue()
    # No ANSI escape sequences
    assert "\033[" not in output


# ---------------------------------------------------------------------------
# Property 44: Boot sequence display idempotence
# ---------------------------------------------------------------------------


@settings(max_examples=10)
@given(data=st.data())
def test_boot_sequence_display_idempotence(data):
    """Property 44: Boot sequence display idempotence.

    Calling the boot sequence display function twice should produce
    output only on the first call.

    **Validates: Requirements 19.10**
    """
    # Reset session flag
    banner_mod._DISPLAYED = False

    call_count = [0]
    original_print = print

    def counting_print(*args, **kwargs):
        call_count[0] += 1

    with (
        patch.dict("os.environ", {"SYNTH_NO_BANNER": ""}, clear=False),
        patch("builtins.print", side_effect=counting_print),
        patch("time.sleep"),
    ):
        banner_mod.display_boot_sequence()
        first_count = call_count[0]

        banner_mod.display_boot_sequence()
        second_count = call_count[0]

    # Second call should produce no additional output
    assert second_count == first_count
