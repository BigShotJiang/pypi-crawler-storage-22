"""Property-based tests for human-in-the-loop.

**Property 21: Pause/resume round-trip**
**Validates: Requirements 8.2, 8.4**
"""

from __future__ import annotations

import asyncio
import uuid

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.checkpointing.local import LocalCheckpointStore
from synth.orchestration.graph import Graph
from synth.types import PausedRun, RunResult


# ---------------------------------------------------------------------------
# Property 21: Pause/resume round-trip
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    human_input=st.text(min_size=1, max_size=30),
    initial_value=st.integers(min_value=0, max_value=1000),
)
def test_pause_resume_round_trip(
    human_input: str,
    initial_value: int,
    tmp_path_factory,
):
    """Property 21: Pause/resume round-trip.

    For any Graph with human-in-the-loop configured at a node, pausing
    at that node and then resuming with input should produce a final
    result equivalent to what an uninterrupted execution with the same
    input at that decision point would produce.

    **Validates: Requirements 8.2, 8.4**
    """
    tmp_path = tmp_path_factory.mktemp("hitl")
    store = LocalCheckpointStore(base_dir=str(tmp_path))

    # Build a graph: step1 -> review (pause) -> step2 -> END
    graph = Graph()
    graph.add_node("step1", lambda s: {**s, "step1": True})
    graph.add_node("review", lambda s: {**s, "reviewed": True})
    graph.add_node("step2", lambda s: {**s, "step2": True})
    graph.add_edge("step1", "review")
    graph.add_edge("review", "step2")
    graph.add_edge("step2", Graph.END)
    graph.set_entry("step1")
    graph.with_checkpointing(store)
    graph.with_human_in_the_loop(pause_at=["review"])

    run_id = f"run-{uuid.uuid4().hex[:8]}"

    # Run should pause at "review"
    paused = asyncio.run(graph.arun(
        {"value": initial_value}, run_id=run_id,
    ))
    assert isinstance(paused, PausedRun)
    assert paused.paused_at_node == "review"
    assert paused.state.get("step1") is True
    assert paused.state.get("reviewed") is True

    # Resume with human input should complete
    result = asyncio.run(graph.aresume(run_id, human_input=human_input))
    assert isinstance(result, RunResult)
    assert result.output.get("step2") is True
    assert result.output.get("human_input") == human_input
