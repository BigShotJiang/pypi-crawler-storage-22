"""Tests for ``synth.cli.dev`` — dev REPL and TUI launcher."""

from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import MagicMock, patch

import click
import pytest

from synth.errors import SynthError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@dataclass
class _FakeRunResult:
    """Minimal stand-in for RunResult used by the basic REPL."""

    text: str = "mock answer"

    class _Tokens:
        total_tokens: int = 42

    tokens: _Tokens = _Tokens()
    cost: float = 0.0012
    latency_ms: float = 150.0


def _make_fake_agent(run_result: _FakeRunResult | None = None):
    """Return a mock agent whose ``.run()`` returns *run_result*."""
    agent = MagicMock()
    agent.run.return_value = run_result or _FakeRunResult()
    return agent


# ===================================================================
# run_dev — TUI / fallback dispatch
# ===================================================================


class TestRunDevDispatch:
    """Tests for ``run_dev`` — TUI launch vs. basic REPL fallback."""

    def test_delegates_to_launch_tui_when_available(self):
        """When _tui can be imported, run_dev calls launch_tui."""
        with patch("synth.cli.dev.click"):
            # Patch the import inside run_dev so it finds a mock launch_tui
            mock_tui = MagicMock()
            with patch.dict(
                "sys.modules",
                {"synth.cli._tui": mock_tui},
            ):
                from synth.cli.dev import run_dev

                run_dev("my_agent.py")
                mock_tui.launch_tui.assert_called_once_with("my_agent.py")

    def test_falls_back_to_basic_repl_on_import_error(self):
        """When _tui import fails, run_dev prints a hint and calls _run_basic_repl."""
        with patch("synth.cli.dev._run_basic_repl") as mock_repl, \
             patch("synth.cli.dev.click") as mock_click:
            # Force ImportError on the TUI import
            import synth.cli.dev as dev_mod

            original_run_dev = dev_mod.run_dev.__code__

            # We'll just call run_dev with a patched import that raises
            with patch.object(
                dev_mod,
                "run_dev",
                wraps=dev_mod.run_dev,
            ):
                # Simulate ImportError by making the import fail
                import builtins
                real_import = builtins.__import__

                def _fake_import(name, *args, **kwargs):
                    if name == "synth.cli._tui":
                        raise ImportError("no rich")
                    return real_import(name, *args, **kwargs)

                with patch("builtins.__import__", side_effect=_fake_import):
                    dev_mod.run_dev("agent.py")

                mock_repl.assert_called_once_with("agent.py")

    def test_fallback_prints_install_hint(self, capsys):
        """The fallback path echoes a pip install hint before starting the REPL."""
        import synth.cli.dev as dev_mod
        import builtins
        real_import = builtins.__import__

        def _fake_import(name, *args, **kwargs):
            if name == "synth.cli._tui":
                raise ImportError("no rich")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_fake_import), \
             patch.object(dev_mod, "_run_basic_repl"):
            dev_mod.run_dev("agent.py")

        captured = capsys.readouterr()
        assert "synth-agent-sdk[dev]" in captured.out


# ===================================================================
# _run_basic_repl
# ===================================================================


class TestBasicRepl:
    """Tests for ``_run_basic_repl`` — the minimal fallback REPL."""

    def test_prints_dev_mode_basic_header(self, capsys):
        """The REPL prints 'Synth Dev Mode (basic)' on start."""
        agent = _make_fake_agent()

        with patch("synth.cli.dev.click.prompt", side_effect=KeyboardInterrupt):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("agent.py")

        captured = capsys.readouterr()
        assert "Synth Dev Mode (basic)" in captured.out

    def test_prints_loading_message(self, capsys):
        """The REPL prints the file being loaded."""
        agent = _make_fake_agent()

        with patch("synth.cli.dev.click.prompt", side_effect=KeyboardInterrupt):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("my_agent.py")

        captured = capsys.readouterr()
        assert "my_agent.py" in captured.out

    def test_exits_on_keyboard_interrupt(self, capsys):
        """Ctrl+C exits the REPL cleanly."""
        agent = _make_fake_agent()

        with patch("synth.cli.dev.click.prompt", side_effect=KeyboardInterrupt):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("agent.py")

        captured = capsys.readouterr()
        assert "Exiting dev mode" in captured.out

    def test_exits_on_eof(self, capsys):
        """EOFError (Ctrl+D) exits the REPL cleanly."""
        agent = _make_fake_agent()

        with patch("synth.cli.dev.click.prompt", side_effect=EOFError):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("agent.py")

        captured = capsys.readouterr()
        assert "Exiting dev mode" in captured.out

    def test_runs_prompt_and_prints_result(self, capsys):
        """A valid prompt runs the agent and prints the response + stats."""
        result = _FakeRunResult(text="Hello world")
        agent = _make_fake_agent(result)

        # First prompt returns text, second raises KeyboardInterrupt to exit
        with patch(
            "synth.cli.dev.click.prompt",
            side_effect=["What is 1+1?", KeyboardInterrupt],
        ):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("agent.py")

        agent.run.assert_called_once_with("What is 1+1?")
        captured = capsys.readouterr()
        assert "Hello world" in captured.out
        assert "42 tokens" in captured.out

    def test_skips_empty_prompt(self):
        """Empty/whitespace prompts are skipped without calling agent.run()."""
        agent = _make_fake_agent()

        with patch(
            "synth.cli.dev.click.prompt",
            side_effect=["   ", "", KeyboardInterrupt],
        ):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("agent.py")

        agent.run.assert_not_called()

    def test_handles_synth_error(self, capsys):
        """SynthError during a run prints the error and suggestion."""
        agent = _make_fake_agent()
        agent.run.side_effect = SynthError(
            "something broke",
            component="Agent",
            suggestion="try again",
        )

        with patch(
            "synth.cli.dev.click.prompt",
            side_effect=["hello", KeyboardInterrupt],
        ):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("agent.py")

        captured = capsys.readouterr()
        assert "something broke" in captured.out
        assert "try again" in captured.out

    def test_returns_early_on_load_system_exit(self):
        """If _load_agent raises SystemExit, the REPL returns without looping."""
        with patch("synth.cli.run_cmd._load_agent", side_effect=SystemExit(1)):
            from synth.cli.dev import _run_basic_repl

            # Should not raise — just returns
            _run_basic_repl("bad_agent.py")

    def test_prints_cost_and_latency(self, capsys):
        """The stats line includes cost and latency."""
        result = _FakeRunResult(text="ok", cost=0.0050, latency_ms=320.0)
        agent = _make_fake_agent(result)

        with patch(
            "synth.cli.dev.click.prompt",
            side_effect=["hi", KeyboardInterrupt],
        ):
            with patch("synth.cli.run_cmd._load_agent", return_value=agent):
                from synth.cli.dev import _run_basic_repl

                _run_basic_repl("agent.py")

        captured = capsys.readouterr()
        assert "$0.0050" in captured.out
        assert "320ms" in captured.out
