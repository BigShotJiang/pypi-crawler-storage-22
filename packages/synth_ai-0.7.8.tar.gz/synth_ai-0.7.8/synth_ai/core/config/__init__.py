"""Configuration utilities.

This module provides configuration resolution and user config management.
"""

from __future__ import annotations

# Note: BaseJobConfig and expansion.py were removed (never used)
# See research/synth-ai/python_legacy/core/config/ for archived code
