"""Tests for tracing v3."""
