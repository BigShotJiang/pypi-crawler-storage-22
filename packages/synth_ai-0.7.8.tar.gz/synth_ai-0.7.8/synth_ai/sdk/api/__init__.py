"""Backward-compatible API namespace."""

from __future__ import annotations
