"""Backward-compatible training API namespace."""

from __future__ import annotations
