"""Backward-compatible learning namespace."""

from __future__ import annotations

from synth_ai.sdk.optimization.clients import PromptLearningClient

__all__ = ["PromptLearningClient"]
