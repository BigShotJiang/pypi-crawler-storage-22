import logging

# Get the root logger for this package
logger = logging.getLogger(__name__)

logger.debug("synth_pdb package initialized.")

__version__ = "1.14.0"
