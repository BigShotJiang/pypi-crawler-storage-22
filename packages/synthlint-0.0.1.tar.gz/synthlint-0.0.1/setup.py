from setuptools import setup
setup(
    name="synthlint",
    version="0.0.1",
    description="Reserved for SynthLint.",
    author="SynthLint",
    url="https://synthlint.dev"
)
