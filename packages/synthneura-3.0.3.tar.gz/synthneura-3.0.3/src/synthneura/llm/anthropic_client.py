from synthneura.core.schemas import ExtractedTrialData
from synthneura.llm.base import LLMClient


class AnthropicClient(LLMClient):
    """
    Placeholder client for Anthropic-backed extraction.
    """

    def extract_endpoints_biomarkers(self, prompt: str) -> ExtractedTrialData:
        raise NotImplementedError("Anthropic extraction client is not implemented yet.")
