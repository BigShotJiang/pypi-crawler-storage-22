from abc import ABC, abstractmethod

from synthneura.core.schemas import ExtractedTrialData


class LLMClient(ABC):
    @abstractmethod
    def extract_endpoints_biomarkers(self, prompt: str) -> ExtractedTrialData:
        """
        Extract endpoints and biomarkers from a trial text prompt.
        """
        raise NotImplementedError
