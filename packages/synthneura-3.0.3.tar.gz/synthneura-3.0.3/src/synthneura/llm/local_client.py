from typing import List

from synthneura.core.schemas import ExtractedTrialData
from synthneura.llm.base import LLMClient


class LocalMockClient(LLMClient):
    """
    Deterministic mock extractor for offline development.

    This uses simple keyword heuristics against the prompt text and
    returns stable outputs to exercise the extraction pipeline.
    """

    def extract_endpoints_biomarkers(self, prompt: str) -> ExtractedTrialData:
        text = prompt.lower()
        endpoints: List[str] = []
        biomarkers: List[str] = []

        if "overall survival" in text:
            endpoints.append("Overall survival")
        if "progression-free" in text or "progression free" in text:
            endpoints.append("Progression-free survival")
        if "response rate" in text:
            endpoints.append("Overall response rate")

        if "egfr" in text:
            biomarkers.append("EGFR")
        if "kras" in text:
            biomarkers.append("KRAS")
        if "pd-l1" in text or "pdl1" in text:
            biomarkers.append("PD-L1")

        return ExtractedTrialData(
            endpoints=endpoints,
            biomarkers=biomarkers,
            model="local-mock",
            provider="local-mock",
        )


class LocalClient(LLMClient):
    """
    Placeholder client for local/offline extraction.
    """

    def extract_endpoints_biomarkers(self, prompt: str) -> ExtractedTrialData:
        raise NotImplementedError("Local extraction client is not implemented yet.")
