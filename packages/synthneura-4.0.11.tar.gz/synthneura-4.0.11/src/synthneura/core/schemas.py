from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class ClinicalTrial(BaseModel):
    """
    Canonical internal representation of a clinical trial
    normalized from ClinicalTrials.gov (API v2 or legacy).
    """

    # Core identifiers
    nct_id: str

    # Descriptive fields (often missing in real-world data)
    title: Optional[str] = None
    status: Optional[str] = None
    phase: Optional[str] = None
    sponsor: Optional[str] = None
    disease_category: Optional[str] = None

    # Lists are defaulted to empty to avoid runtime errors
    conditions: List[str] = []
    interventions: List[str] = []
    outcomes: List[str] = []


class TopCount(BaseModel):
    value: str
    count: int


class Summary(BaseModel):
    """
    Aggregated summary statistics for a set of trials.
    """

    total_trials: int
    status_counts: Dict[str, int] = Field(default_factory=dict)
    phase_counts: Dict[str, int] = Field(default_factory=dict)
    top_conditions: List[TopCount] = Field(default_factory=list)
    top_sponsors: List[TopCount] = Field(default_factory=list)
    top_interventions: List[TopCount] = Field(default_factory=list)
    change_counts: Dict[str, int] = Field(default_factory=dict)
    run_id: Optional[str] = None
    ingested_at: Optional[str] = None
    source: Optional[str] = None
    query: Optional[str] = None


class ExtractedTrialData(BaseModel):
    """
    AI-extracted structured facts from trial text.
    """

    endpoints: List["Endpoint"] = Field(default_factory=list)
    biomarkers: List["Biomarker"] = Field(default_factory=list)
    prompt_version: Optional[str] = None
    raw_response: Optional[str] = None
    validation_status: Optional[str] = None
    validation_errors: List[str] = Field(default_factory=list)
    confidence: Optional[float] = None
    model: Optional[str] = None
    provider: Optional[str] = None


class Endpoint(BaseModel):
    endpoint_id: str
    raw_text: str
    normalized_name: str
    endpoint_category: str
    endpoint_type: str
    hierarchy: str
    time_horizon: Optional[str] = None
    measurement_context: Optional[str] = None
    confidence: str


class Biomarker(BaseModel):
    biomarker_id: str
    raw_text: str
    normalized_name: str
    variant_or_threshold: Optional[str] = None
    biological_level: str
    context: str
    confidence: str


class LLMRawResponse(BaseModel):
    raw_json: str
    model: Optional[str] = None
    provider: Optional[str] = None
