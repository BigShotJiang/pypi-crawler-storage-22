from datetime import date
from typing import Any, Dict, List, Optional, Tuple

import requests

from synthneura.core.logger import get_logger

CTG_V2_STUDIES_URL = "https://clinicaltrials.gov/api/v2/studies"

logger = get_logger(__name__)


def _parse_partial_date(raw_value: Optional[str]) -> Optional[date]:
    if not raw_value:
        return None
    value = str(raw_value).strip()
    if not value:
        return None
    if "T" in value:
        value = value.split("T", 1)[0]
    parts = value.split("-")
    try:
        if len(parts) == 1 and len(parts[0]) == 4:
            return date(int(parts[0]), 1, 1)
        if len(parts) == 2:
            return date(int(parts[0]), int(parts[1]), 1)
        if len(parts) >= 3:
            return date(int(parts[0]), int(parts[1]), int(parts[2]))
        return None
    except ValueError:
        return None


def _extract_last_update_date(study: Dict[str, Any]) -> Optional[date]:
    status_module = study.get("protocolSection", {}).get("statusModule", {})
    if not isinstance(status_module, dict):
        return None
    for raw_value in (
        status_module.get("lastUpdatePostDateStruct", {}).get("date"),
        status_module.get("lastUpdatePostDate"),
        status_module.get("lastUpdateSubmitDate"),
        status_module.get("studyFirstPostDateStruct", {}).get("date"),
        status_module.get("studyFirstPostDate"),
    ):
        parsed = _parse_partial_date(raw_value)
        if parsed:
            return parsed
    return None


def _fetch_studies(
    params: Dict[str, str], page_size: int, target: int
) -> List[Dict[str, Any]]:
    collected: List[Dict[str, Any]] = []
    next_page_token: Optional[str] = None

    while len(collected) < target:
        request_params = dict(params)
        request_params["pageSize"] = str(page_size)
        if next_page_token:
            request_params["pageToken"] = next_page_token
        try:
            response = requests.get(
                CTG_V2_STUDIES_URL,
                params=request_params,
                timeout=30,
            )
        except requests.RequestException as exc:
            logger.exception("HTTP request to ClinicalTrials.gov failed")
            raise RuntimeError("Failed to contact ClinicalTrials.gov") from exc

        logger.info(
            "ClinicalTrials.gov response status=%s url=%s",
            response.status_code,
            response.url,
        )

        content_type = response.headers.get("Content-Type", "")
        if "text/html" in content_type.lower():
            logger.error(
                "Received HTML instead of JSON (status=%s). Response preview=%s",
                response.status_code,
                response.text[:200],
            )
            raise ValueError(
                "ClinicalTrials.gov returned HTML (not JSON). "
                f"Status={response.status_code}. Check endpoint/params."
            )

        try:
            response.raise_for_status()
        except requests.HTTPError:
            logger.error(
                "HTTP error from ClinicalTrials.gov status=%s body=%s",
                response.status_code,
                response.text[:200],
            )
            raise

        data = response.json()
        studies = data.get("studies", [])
        if not studies:
            break
        collected.extend(studies)
        next_page_token = data.get("nextPageToken")
        if not next_page_token:
            break
    return collected


def _rank_latest_first(studies: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    ranked: List[Tuple[date, str, Dict[str, Any]]] = []
    for study in studies:
        update_date = _extract_last_update_date(study) or date.min
        nct_id = (
            study.get("protocolSection", {})
            .get("identificationModule", {})
            .get("nctId", "")
        )
        ranked.append((update_date, nct_id, study))
    ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return [item[2] for item in ranked]


def fetch_trials(query: str, max_results: int = 10) -> List[Dict[str, Any]]:
    """
    Fetch clinical trials from ClinicalTrials.gov API v2.
    Returns a list of study objects (dicts).
    """
    logger.info("Fetching ClinicalTrials.gov trials")
    logger.debug("Query=%s max_results=%s", query, max_results)

    desired = max(1, int(max_results))
    # Keep a stable candidate window so top-10 is a prefix of top-20.
    candidate_target = max(200, desired)
    page_size = min(100, max(25, desired))
    base_params: dict[str, str] = {
        "format": "json",
        "countTotal": "true",
    }

    condition_params = dict(base_params)
    condition_params["query.cond"] = query
    studies = _fetch_studies(condition_params, page_size, candidate_target)

    if not studies:
        # Fallback to broad weighted search for non-condition queries.
        broad_params = dict(base_params)
        broad_params["query.term"] = query
        studies = _fetch_studies(broad_params, page_size, candidate_target)

    if not studies:
        logger.warning("No trials found for query=%s", query)
        raise ValueError(f"No trials found for query: {query}")

    ranked = _rank_latest_first(studies)
    sliced = ranked[:desired]
    logger.info(
        "Fetched %d candidate trials and selected %d latest for query=%s",
        len(studies),
        len(sliced),
        query,
    )
    return sliced
