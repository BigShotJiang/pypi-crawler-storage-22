from synthneura.core.schemas import LLMRawResponse
from synthneura.llm.base import LLMClient


class AnthropicClient(LLMClient):
    """
    Placeholder client for Anthropic-backed extraction.
    """

    def extract_endpoints_biomarkers(self, prompt: str) -> LLMRawResponse:
        raise NotImplementedError("Anthropic extraction client is not implemented yet.")
