from abc import ABC, abstractmethod

from synthneura.core.schemas import LLMRawResponse


class LLMClient(ABC):
    @abstractmethod
    def extract_endpoints_biomarkers(self, prompt: str) -> LLMRawResponse:
        """
        Return raw JSON extraction output from a trial text prompt.
        """
        raise NotImplementedError
