import json
from typing import List

from synthneura.core.schemas import LLMRawResponse
from synthneura.llm.base import LLMClient


class LocalMockClient(LLMClient):
    """
    Deterministic mock extractor for offline development.

    This uses simple keyword heuristics against the prompt text and
    returns stable outputs to exercise the extraction pipeline.
    """

    def extract_endpoints_biomarkers(self, prompt: str) -> LLMRawResponse:
        text = prompt.lower()
        endpoints: List[dict] = []
        biomarkers: List[dict] = []

        if "overall survival" in text:
            endpoints.append(
                {
                    "endpoint_id": "ep-1",
                    "raw_text": "Overall survival",
                    "normalized_name": "Overall Survival (OS)",
                    "endpoint_category": "efficacy",
                    "endpoint_type": "time_to_event",
                    "hierarchy": "unspecified",
                    "time_horizon": None,
                    "measurement_context": None,
                    "confidence": "low",
                }
            )
        if "progression-free" in text or "progression free" in text:
            endpoints.append(
                {
                    "endpoint_id": "ep-2",
                    "raw_text": "Progression-free survival",
                    "normalized_name": "Progression-Free Survival (PFS)",
                    "endpoint_category": "efficacy",
                    "endpoint_type": "time_to_event",
                    "hierarchy": "unspecified",
                    "time_horizon": None,
                    "measurement_context": None,
                    "confidence": "low",
                }
            )
        if "response rate" in text:
            endpoints.append(
                {
                    "endpoint_id": "ep-3",
                    "raw_text": "Overall response rate",
                    "normalized_name": "Objective Response Rate (ORR)",
                    "endpoint_category": "efficacy",
                    "endpoint_type": "binary",
                    "hierarchy": "unspecified",
                    "time_horizon": None,
                    "measurement_context": None,
                    "confidence": "low",
                }
            )

        if "egfr" in text:
            biomarkers.append(
                {
                    "biomarker_id": "bm-1",
                    "raw_text": "EGFR",
                    "normalized_name": "EGFR",
                    "variant_or_threshold": None,
                    "biological_level": "gene",
                    "context": "outcome",
                    "confidence": "low",
                }
            )
        if "kras" in text:
            biomarkers.append(
                {
                    "biomarker_id": "bm-2",
                    "raw_text": "KRAS",
                    "normalized_name": "KRAS",
                    "variant_or_threshold": None,
                    "biological_level": "gene",
                    "context": "outcome",
                    "confidence": "low",
                }
            )
        if "pd-l1" in text or "pdl1" in text:
            biomarkers.append(
                {
                    "biomarker_id": "bm-3",
                    "raw_text": "PD-L1",
                    "normalized_name": "PD-L1",
                    "variant_or_threshold": None,
                    "biological_level": "protein",
                    "context": "outcome",
                    "confidence": "low",
                }
            )

        payload = {"endpoints": endpoints, "biomarkers": biomarkers}
        return LLMRawResponse(
            raw_json=json.dumps(payload, ensure_ascii=True),
            model="local-mock",
            provider="local-mock",
        )


class LocalClient(LLMClient):
    """
    Placeholder client for local/offline extraction.
    """

    def extract_endpoints_biomarkers(self, prompt: str) -> LLMRawResponse:
        raise NotImplementedError("Local extraction client is not implemented yet.")
