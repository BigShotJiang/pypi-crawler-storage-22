from typing import Any, Dict, List

import pytest

from synthneura.ingestion.clinical_trials import fetch_trials


class _FakeResponse:
    def __init__(
        self,
        payload: Dict[str, Any],
        url: str = "https://clinicaltrials.gov/api/v2/studies",
        status_code: int = 200,
    ) -> None:
        self._payload = payload
        self.url = url
        self.status_code = status_code
        self.headers = {"Content-Type": "application/json"}
        self.text = ""

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise RuntimeError("http error")

    def json(self) -> Dict[str, Any]:
        return self._payload


def _study(nct_id: str, last_update: str) -> Dict[str, Any]:
    return {
        "protocolSection": {
            "identificationModule": {"nctId": nct_id},
            "statusModule": {
                "lastUpdatePostDateStruct": {"date": last_update},
            },
        }
    }


def test_fetch_trials_returns_latest_sorted(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: List[Dict[str, str]] = []

    def _fake_get(url: str, params: Dict[str, str], timeout: int) -> _FakeResponse:
        del url, timeout
        calls.append(params)
        payload = {
            "studies": [
                _study("NCT-B", "2024-01-10"),
                _study("NCT-A", "2025-03-12"),
                _study("NCT-C", "2023-09-01"),
            ]
        }
        return _FakeResponse(payload)

    monkeypatch.setattr(
        "synthneura.ingestion.clinical_trials.requests.get",
        _fake_get,
    )

    top_2 = fetch_trials("sarcoma", max_results=2)
    top_3 = fetch_trials("sarcoma", max_results=3)

    ids_2 = [row["protocolSection"]["identificationModule"]["nctId"] for row in top_2]
    ids_3 = [row["protocolSection"]["identificationModule"]["nctId"] for row in top_3]
    assert ids_2 == ["NCT-A", "NCT-B"]
    assert ids_3[:2] == ids_2
    assert calls[0]["query.cond"] == "sarcoma"


def test_fetch_trials_paginates_and_uses_next_token(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: List[Dict[str, str]] = []

    def _fake_get(url: str, params: Dict[str, str], timeout: int) -> _FakeResponse:
        del url, timeout
        calls.append(params)
        if "pageToken" not in params:
            return _FakeResponse(
                {
                    "studies": [_study("NCT-OLD", "2023-01-01")],
                    "nextPageToken": "token-2",
                }
            )
        return _FakeResponse({"studies": [_study("NCT-NEW", "2025-07-20")]})

    monkeypatch.setattr(
        "synthneura.ingestion.clinical_trials.requests.get",
        _fake_get,
    )

    studies = fetch_trials("sarcoma", max_results=2)
    ids = [row["protocolSection"]["identificationModule"]["nctId"] for row in studies]

    assert ids == ["NCT-NEW", "NCT-OLD"]
    assert calls[1]["pageToken"] == "token-2"


def test_fetch_trials_falls_back_to_query_term(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: List[Dict[str, str]] = []

    def _fake_get(url: str, params: Dict[str, str], timeout: int) -> _FakeResponse:
        del url, timeout
        calls.append(params)
        if "query.cond" in params:
            return _FakeResponse({"studies": []})
        return _FakeResponse({"studies": [_study("NCT-1", "2024-02-10")]})

    monkeypatch.setattr(
        "synthneura.ingestion.clinical_trials.requests.get",
        _fake_get,
    )

    studies = fetch_trials("edge query", max_results=1)

    assert len(studies) == 1
    assert "query.cond" in calls[0]
    assert "query.term" in calls[1]
