import json

from synthneura.core import disease_taxonomy


def test_classify_disease_default_taxonomy():
    assert disease_taxonomy.classify_disease(["Metastatic melanoma"]) == "oncology"
    assert disease_taxonomy.classify_disease(["Parkinson disease"]) == "neurology"
    assert (
        disease_taxonomy.classify_disease(["Autoimmune asthma study"]) == "immunology"
    )


def test_classify_disease_env_override(monkeypatch):
    payload = {"cardio": ["heart failure", "hypertension"]}
    monkeypatch.setenv("SYNTHNEURA_DISEASE_TAXONOMY_JSON", json.dumps(payload))
    taxonomy = disease_taxonomy.load_disease_taxonomy()
    assert "cardio" in taxonomy
    assert disease_taxonomy.classify_disease(["Heart failure cohort"]) == "cardio"
