from synthneura.core.schemas import ClinicalTrial
from synthneura.services import extraction


def test_endpoint_canonical_map():
    trial = ClinicalTrial(
        nct_id="NCT00000001",
        title="Test",
        status="RECRUITING",
        phase="PHASE2",
        sponsor="Acme",
        conditions=[],
        interventions=[],
        outcomes=[],
    )
    endpoint = extraction._normalize_endpoint("PFS", trial, 1)
    assert endpoint.normalized_name == "Progression-Free Survival (PFS)"
    assert endpoint.endpoint_category == "efficacy"
    assert endpoint.endpoint_type == "time_to_event"


def test_biomarker_canonical_map():
    trial = ClinicalTrial(
        nct_id="NCT00000002",
        title="Test",
        status="RECRUITING",
        phase="PHASE2",
        sponsor="Acme",
        conditions=[],
        interventions=[],
        outcomes=[],
    )
    biomarker = extraction._normalize_biomarker("ERBB1", trial, 1)
    assert biomarker.normalized_name == "EGFR"
    assert biomarker.biological_level == "gene"
