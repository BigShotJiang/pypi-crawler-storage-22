# Syntropy Python SDK

Trace, guard, and govern your AI agents with zero-effort integration.

## Installation

```bash
pip install syntropy-ai
```

## Quick Start

```python
from syntropy import Syntropy

client = Syntropy(
    api_key="syn_your_key_here",
    base_url="https://ingest.syntropy.dev",
    agent_id="my-agent",
)

# Trace an LLM call (buffered, non-blocking)
client.trace(
    prompt="What is the capital of France?",
    response="The capital of France is Paris.",
    model="gpt-4o",
    tokens_in=12,
    tokens_out=8,
    latency_ms=340,
)

# Synchronous trace (blocks until confirmed)
result = client.trace_sync(
    prompt="Hello",
    response="Hi there!",
    model="gpt-4o-mini",
)
print(result.success, result.trace_id)
```

## OpenAI Integration

Auto-trace all `chat.completions.create()` calls:

```python
import openai
from syntropy import Syntropy
from syntropy.integrations.openai import wrap_openai

syn = Syntropy(api_key="syn_...", agent_id="my-agent")
client = wrap_openai(openai.OpenAI(), syntropy=syn)

# This call is now auto-traced — no code changes needed:
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

## Async Support

```python
from syntropy.client import AsyncSyntropy

async def main():
    client = AsyncSyntropy(
        api_key="syn_...",
        base_url="https://ingest.syntropy.dev",
        agent_id="my-agent",
    )

    result = await client.trace(
        prompt="Hello",
        response="Hi!",
        model="gpt-4o",
    )
    print(result.success)
    await client.close()
```

## Batch Tracing

```python
client.trace_batch([
    {"agent_id": "agent-1", "prompt": "Q1", "response": "A1", "model": "gpt-4o"},
    {"agent_id": "agent-2", "prompt": "Q2", "response": "A2", "model": "gpt-4o"},
])
```

## Configuration

| Option | Default | Description |
|--------|---------|-------------|
| `api_key` | required | Your Syntropy API key |
| `base_url` | `http://localhost:4000` | Ingestion service URL |
| `agent_id` | `""` | Default agent ID |
| `flush_interval` | `2.0` | Seconds between buffer flushes |
| `batch_size` | `50` | Max traces per batch |
| `max_queue_size` | `10000` | Max buffered traces |
| `enabled` | `True` | Set `False` to disable tracing |
