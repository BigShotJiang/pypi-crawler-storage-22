"""
Syntropy AI Observability SDK for Python.

Trace, guard, and govern your AI agents with zero-effort integration.

Quick Start — Auto-instrument (recommended):
    from syntropy import Syntropy

    syn = Syntropy.init(api_key="syn_...", agent_id="my-agent")
    # That's it! OpenAI, Anthropic, Mistral, Google are auto-traced.

Manual wrappers:
    from syntropy import Syntropy
    from syntropy.integrations.openai import wrap_openai
    from syntropy.integrations.anthropic import wrap_anthropic
    from syntropy.integrations.google import wrap_google_ai
    from syntropy.integrations.mistral import wrap_mistral
    from syntropy.integrations.bedrock import wrap_bedrock

    syn = Syntropy(api_key="syn_...", agent_id="my-agent")
    openai_client = wrap_openai(openai.OpenAI(), syntropy=syn)
    anthropic_client = wrap_anthropic(anthropic.Anthropic(), syntropy=syn)
    model = wrap_google_ai(genai.GenerativeModel("gemini-2.0-flash"), syntropy=syn)

LlamaIndex:
    from syntropy.integrations.llamaindex import SyntropyLlamaIndexHandler
    Settings.callback_manager.add_handler(SyntropyLlamaIndexHandler(syntropy=syn))

LangChain:
    from syntropy.integrations.langchain import SyntropyCallbackHandler
    chain.invoke(input, config={"callbacks": [SyntropyCallbackHandler(syntropy=syn)]})
"""

from syntropy.client import AsyncSyntropy, Syntropy, SyntropyConfig, TraceResult
from syntropy.trace_context import is_inside_trace, trace_scope

__all__ = [
    "Syntropy",
    "AsyncSyntropy",
    "SyntropyConfig",
    "TraceResult",
    "is_inside_trace",
    "trace_scope",
]
__version__ = "0.1.0"
