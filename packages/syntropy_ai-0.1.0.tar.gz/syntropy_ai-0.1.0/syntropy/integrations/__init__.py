"""
Syntropy AI provider integrations.

All wrappers are lazy-imported to avoid requiring provider packages at import time.
"""

__all__ = [
    "wrap_openai",
    "wrap_anthropic",
    "wrap_google_ai",
    "wrap_mistral",
    "wrap_bedrock",
    "SyntropyCallbackHandler",
    "SyntropyLlamaIndexHandler",
]


def __getattr__(name: str):
    """Lazy imports to avoid pulling in heavy provider SDKs."""
    if name == "wrap_openai":
        from syntropy.integrations.openai import wrap_openai
        return wrap_openai
    if name == "wrap_anthropic":
        from syntropy.integrations.anthropic import wrap_anthropic
        return wrap_anthropic
    if name == "wrap_google_ai":
        from syntropy.integrations.google import wrap_google_ai
        return wrap_google_ai
    if name == "wrap_mistral":
        from syntropy.integrations.mistral import wrap_mistral
        return wrap_mistral
    if name == "wrap_bedrock":
        from syntropy.integrations.bedrock import wrap_bedrock
        return wrap_bedrock
    if name == "SyntropyCallbackHandler":
        from syntropy.integrations.langchain import SyntropyCallbackHandler
        return SyntropyCallbackHandler
    if name == "SyntropyLlamaIndexHandler":
        from syntropy.integrations.llamaindex import SyntropyLlamaIndexHandler
        return SyntropyLlamaIndexHandler
    raise AttributeError(f"module 'syntropy.integrations' has no attribute {name!r}")
