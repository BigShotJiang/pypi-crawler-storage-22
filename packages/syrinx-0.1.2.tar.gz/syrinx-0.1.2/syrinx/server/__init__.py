"""Syrinx development server package.

This subpackage provides development server functionality including
file watching, live reload, and HTTP serving for Syrinx projects.
"""
