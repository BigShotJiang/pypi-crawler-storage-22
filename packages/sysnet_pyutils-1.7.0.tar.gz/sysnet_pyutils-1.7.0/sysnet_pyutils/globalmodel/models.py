
from __future__ import annotations

from datetime import datetime
from typing import Optional, List, Dict, Tuple, Set, Any

from .global_model import GlobalModel


class ExampleModel(GlobalModel):
    # Jednoduchá pole
    ts: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    # Kontejnerová pole
    ts_list: Optional[List[datetime]] = None
    ts_map: Optional[Dict[str, datetime]] = None
    ts_tuple: Optional[Tuple[datetime, ...]] = None
    ts_set: Optional[Set[datetime]] = None

    # Libovolně hluboké struktury
    payload: Optional[Dict[str, Any]] = None

    # Helper pro test "ostatní typy"
    any_value: Any = None
