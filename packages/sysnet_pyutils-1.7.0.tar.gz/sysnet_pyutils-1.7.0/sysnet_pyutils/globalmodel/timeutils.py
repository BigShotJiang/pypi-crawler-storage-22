from __future__ import annotations
from datetime import datetime
from pytz import timezone, utc
from typing import Any
from collections.abc import Mapping, Sequence

# Výchozí lokální zóna pro naivní časy
PRAGUE_TZ = timezone("Europe/Prague")

def _normalize_dt_value(dt: datetime) -> datetime:
    """Naivní datetime -> přiřadit Europe/Prague; vždy převést do UTC."""
    if dt.tzinfo is None or dt.utcoffset() is None:
        # dt = dt.replace(tzinfo=PRAGUE_TZ)
        dt = PRAGUE_TZ.localize(dt)
    return dt.astimezone(utc)


def normalize_dt_deep(obj: Any) -> Any:
    """
    Rekurzivně projde libovolné struktury a všechny instance `datetime`
    převede na UTC (naivní hodnoty nejprve považuje za Europe/Prague).

    Zachovává typ kontejneru (tuple zůstane tuple, set zůstane set).
    Řetězce ani binární data neparsuje.
    """
    # Přímý datetime
    if isinstance(obj, datetime):
        return _normalize_dt_value(obj)

    # Mapping (dict-like)
    if isinstance(obj, Mapping):
        return obj.__class__({k: normalize_dt_deep(v) for k, v in obj.items()})

    # Str necháváme nedotčený
    if isinstance(obj, str):
        return obj

    # Obecné sekvence (list/tuple …), ale ne bytes/bytearray
    if isinstance(obj, Sequence) and not isinstance(obj, (bytes, bytearray)):
        return obj.__class__(normalize_dt_deep(x) for x in obj)

    # Set
    if isinstance(obj, set):
        return {normalize_dt_deep(x) for x in obj}

    # Ostatní typy beze změny
    return obj
