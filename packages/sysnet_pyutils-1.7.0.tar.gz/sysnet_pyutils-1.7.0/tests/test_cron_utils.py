"""
Testy pro modul sysnet_pyutils.cron_utils.validation
"""
from datetime import datetime
import pytest

from sysnet_pyutils.cron_utils.validation import (
    is_cron_syntax_valid, has_next_occurrence, validate_cron, summarize_cron, CronSummary
)


class TestIsCronSyntaxValid:
    """Testy pro syntaktickou validaci"""

    def test_valid_cron_expressions(self):
        valid = ["* * * * *", "0 0 * * *", "0 12 * * *", "30 2 * * *", "0 0 1 * *",
                 "0 0 * * 0", "*/5 * * * *", "0 */2 * * *", "0 0 1,15 * *", "0 9-17 * * 1-5"]
        for expr in valid:
            assert is_cron_syntax_valid(expr) is True

    def test_invalid_cron_expressions(self):
        invalid = ["", "* * * *", "* * * * * *", "60 * * * *", "* 24 * * *",
                   "* * 32 * *", "* * * 13 *", "* * * * 7", "abc * * * *", "** * * * *"]
        for expr in invalid:
            assert is_cron_syntax_valid(expr) is False


class TestHasNextOccurrence:
    """Testy pro sémantickou validaci"""

    def test_expressions_with_occurrences(self):
        exprs = ["* * * * *", "0 0 * * *", "0 12 1 * *", "0 0 * * 1"]
        for expr in exprs:
            assert has_next_occurrence(expr) is True

    def test_february_29_leap_year(self):
        expr = "0 0 29 2 *"
        result = has_next_occurrence(expr, horizon_years=10)
        assert result is True

    def test_impossible_date(self):
        expr = "0 0 31 2 *"
        result = has_next_occurrence(expr, horizon_years=10)
        assert result is False


class TestValidateCron:
    """Testy pro komplexní validaci"""

    def test_valid_expression(self):
        expr = "0 9 * * 1-5"
        is_valid, errors = validate_cron(expr)
        assert is_valid is True
        assert len(errors) == 0

    def test_invalid_syntax(self):
        expr = "60 * * * *"
        is_valid, errors = validate_cron(expr)
        assert is_valid is False
        assert len(errors) > 0

    def test_impossible_occurrence(self):
        expr = "0 0 31 2 *"
        is_valid, errors = validate_cron(expr, horizon_years=10)
        assert is_valid is False
        assert len(errors) > 0


class TestSummarizeCron:
    """Testy pro sumarizaci"""

    def test_summarize_valid_expression(self):
        expr = "0 9 * * 1-5"
        summary = summarize_cron(expr)
        assert isinstance(summary, CronSummary)
        assert summary.syntax_ok is True
        assert summary.has_occurrence is True
        assert summary.next_run is not None

    def test_summarize_invalid_syntax(self):
        expr = "60 * * * *"
        summary = summarize_cron(expr)
        assert summary.syntax_ok is False
        assert summary.has_occurrence is False
        assert len(summary.errors) > 0


class TestCronRealWorldExamples:
    """Testy s reálnými příklady"""

    def test_daily_backup(self):
        expr = "0 2 * * *"
        summary = summarize_cron(expr)
        assert summary.syntax_ok is True
        assert summary.has_occurrence is True
        assert summary.next_run > datetime.now(summary.next_run.tzinfo)

    def test_weekly_report(self):
        expr = "0 8 * * 1"
        summary = summarize_cron(expr)
        assert summary.syntax_ok is True
        assert summary.has_occurrence is True

    def test_monthly_cleanup(self):
        expr = "0 3 1 * *"
        summary = summarize_cron(expr)
        assert summary.syntax_ok is True
        assert summary.has_occurrence is True
