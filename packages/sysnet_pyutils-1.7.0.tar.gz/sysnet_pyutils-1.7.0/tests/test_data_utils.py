"""
Testy pro modul sysnet_pyutils.data_utils
"""
from datetime import date, datetime
import pytest
import pytz

from sysnet_pyutils.data_utils import (
    get_dict_value, get_dict_value_string, get_dict_value_email,
    get_dict_value_bool, get_dict_value_int, get_dict_value_float,
    get_dict_value_list, get_dict_value_date, get_dict_value_code,
    get_dict_value_uuid, get_dict_value_datetime,
    convert_iso_to_date, convert_iso_to_datetime,
    convert_cz_to_date, convert_cz_to_datetime,
    get_object_attr, get_dict_item_value_list, get_dict_item_value,
    get_dict_code_value_list,
    adjust_datetime_to_utc, dict_convert_date_to_str,
    paging_to_mongo, recursive_update,
    address_to_string, get_dict_value_as_person_type,
)
from sysnet_pyutils.models.general import CodeValueType, PersonTypeEnum


class TestGetDictValue:
    """Testy pro základní get_dict_value funkce"""

    def test_get_dict_value_returns_value(self):
        data = {'key': 'value', 'number': 42}
        assert get_dict_value(data, 'key') == 'value'
        assert get_dict_value(data, 'number') == 42

    def test_get_dict_value_returns_none_for_missing_key(self):
        data = {'key': 'value'}
        assert get_dict_value(data, 'missing') is None

    def test_get_dict_value_returns_none_for_none_data(self):
        assert get_dict_value(None, 'key') is None

    def test_get_dict_value_string_returns_string(self):
        data = {'key': 'value', 'number': 42}
        assert get_dict_value_string(data, 'key') == 'value'
        assert get_dict_value_string(data, 'number') == '42'

    def test_get_dict_value_string_returns_empty_for_none(self):
        data = {'key': None}
        assert get_dict_value_string(data, 'key') == ''
        assert get_dict_value_string(data, 'missing') == ''

    def test_get_dict_value_email_validates_email(self):
        data = {'valid': 'test@example.com', 'invalid': 'not-an-email'}
        assert get_dict_value_email(data, 'valid') == 'test@example.com'
        assert get_dict_value_email(data, 'invalid') is None

    def test_get_dict_value_bool_converts_to_bool(self):
        data = {
            'true1': 'true', 'true2': '1', 'true3': 'ano',
            'false1': 'false', 'false2': '0', 'false3': ''
        }
        assert get_dict_value_bool(data, 'true1') is True
        assert get_dict_value_bool(data, 'true2') is True
        assert get_dict_value_bool(data, 'true3') is True
        assert get_dict_value_bool(data, 'false1') is False
        assert get_dict_value_bool(data, 'false2') is False
        assert get_dict_value_bool(data, 'false3') is False


class TestGetDictValueNumeric:
    """Testy pro numerické hodnoty"""

    def test_get_dict_value_int_returns_integer(self):
        data = {'number': '42', 'string': 'abc'}
        assert get_dict_value_int(data, 'number') == 42
        assert get_dict_value_int(data, 'string') == 0

    def test_get_dict_value_int_uses_spare(self):
        data = {'main': '0', 'spare': '100'}
        result = get_dict_value_int(data, 'main', 'spare')
        assert result == 100

    def test_get_dict_value_float_returns_float(self):
        data = {'number': '3.14', 'comma': '2,5'}
        assert get_dict_value_float(data, 'number') == 3.14
        assert get_dict_value_float(data, 'comma') == 2.5

    def test_get_dict_value_float_uses_spare(self):
        data = {'main': '0', 'spare': '99.9'}
        result = get_dict_value_float(data, 'main', 'spare')
        assert result == 99.9

    def test_get_dict_value_list_parses_list(self):
        data = {'items': '["item1"; "item2"; "item3"]'}
        result = get_dict_value_list(data, 'items')
        assert result == ['item1', 'item2', 'item3']

    def test_get_dict_value_list_handles_empty(self):
        data = {'items': '[]'}
        result = get_dict_value_list(data, 'items')
        assert result == []


class TestDateTimeConversion:
    """Testy pro konverzi data a času"""

    def test_convert_iso_to_date_valid(self):
        result = convert_iso_to_date('2023-05-15')
        assert isinstance(result, date)
        assert result.year == 2023
        assert result.month == 5
        assert result.day == 15

    def test_convert_iso_to_date_invalid(self):
        assert convert_iso_to_date('invalid') is None
        assert convert_iso_to_date('2023-13-45') is None

    def test_convert_cz_to_date_valid(self):
        result = convert_cz_to_date('15.05.2023')
        assert isinstance(result, date)
        assert result.year == 2023
        assert result.month == 5
        assert result.day == 15

    def test_convert_cz_to_date_invalid(self):
        assert convert_cz_to_date('invalid') is None
        assert convert_cz_to_date('45.13.2023') is None

    def test_convert_iso_to_datetime_valid(self):
        result = convert_iso_to_datetime('2023-05-15T12:00:00')
        assert isinstance(result, datetime)
        assert result.year == 2023
        assert result.month == 5
        assert result.day == 15

    def test_convert_cz_to_datetime_valid(self):
        result = convert_cz_to_datetime('15.05.2023 12:30:45')
        assert isinstance(result, datetime)
        assert result.year == 2023
        assert result.month == 5
        assert result.day == 15
        assert result.hour == 12
        assert result.minute == 30

    def test_get_dict_value_date_iso_format(self):
        data = {'date': '2023-05-15'}
        result = get_dict_value_date(data, 'date')
        assert isinstance(result, date)
        assert result == date(2023, 5, 15)

    def test_get_dict_value_date_cz_format(self):
        data = {'date': '15.05.2023'}
        result = get_dict_value_date(data, 'date')
        assert isinstance(result, date)
        assert result == date(2023, 5, 15)

    def test_get_dict_value_datetime_handles_types(self):
        dt = datetime(2023, 5, 15, 12, 0, 0)
        data = {'dt': dt}
        result = get_dict_value_datetime(data, 'dt')
        assert isinstance(result, datetime)

        d = date(2023, 5, 15)
        data = {'d': d}
        result = get_dict_value_datetime(data, 'd')
        assert isinstance(result, datetime)

        data = {'iso': '2023-05-15T12:00:00'}
        result = get_dict_value_datetime(data, 'iso')
        assert isinstance(result, datetime)


class TestCodeValueType:
    """Testy pro CodeValueType"""

    def test_get_dict_value_code_parses_pipe_format(self):
        data = {'code': 'Czech Republic|CZ'}
        result = get_dict_value_code(data, 'code')
        assert isinstance(result, CodeValueType)
        assert result.code == 'CZ'
        assert result.value == 'Czech Republic'

    def test_get_dict_value_code_handles_cz_country(self):
        data = {'code': 'CZ'}
        result = get_dict_value_code(data, 'code')
        assert isinstance(result, CodeValueType)
        assert result.code == 'CZ'
        assert 'Czech' in result.value or 'Česká' in result.value

    def test_get_dict_value_code_returns_none_for_none(self):
        data = {'code': None}
        assert get_dict_value_code(data, 'code') is None


class TestUUID:
    """Testy pro UUID zpracování"""

    def test_get_dict_value_uuid_valid(self):
        valid_uuid = '550e8400-e29b-41d4-a716-446655440000'
        data = {'uuid': valid_uuid}
        result = get_dict_value_uuid(data, 'uuid')
        assert result == valid_uuid

    def test_get_dict_value_uuid_invalid(self):
        data = {'uuid': 'invalid-uuid'}
        assert get_dict_value_uuid(data, 'uuid') is None


class TestObjectAttributes:
    """Testy pro práci s atributy objektů"""

    def test_get_object_attr_returns_attribute(self):
        class TestObj:
            def __init__(self):
                self.name = "test"
                self.value = 42

        obj = TestObj()
        assert get_object_attr(obj, 'name') == 'test'
        assert get_object_attr(obj, 'value') == 42

    def test_get_object_attr_returns_none_for_missing(self):
        class TestObj:
            pass

        obj = TestObj()
        assert get_object_attr(obj, 'missing') is None

    def test_get_object_attr_returns_none_for_none(self):
        assert get_object_attr(None, 'attr') is None


class TestDictItemValue:
    """Testy pro get_dict_item_value funkce"""

    def test_get_dict_item_value_returns_value(self):
        data = {'key': 'value'}
        assert get_dict_item_value(data, 'key') == 'value'

    def test_get_dict_item_value_uses_alternative(self):
        data = {'alt1': 'value'}
        result = get_dict_item_value(data, 'missing', ['alt1', 'alt2'])
        assert result == 'value'

    def test_get_dict_item_value_list_wraps_single_value(self):
        data = {'key': 'single'}
        result = get_dict_item_value_list(data, 'key')
        assert result == ['single']

    def test_get_dict_item_value_list_returns_list(self):
        data = {'key': ['a', 'b', 'c']}
        result = get_dict_item_value_list(data, 'key')
        assert result == ['a', 'b', 'c']

    def test_get_dict_code_value_list_pairs_codes_and_values(self):
        data = {
            'codes': '["C1"; "C2"; "C3"]',
            'values': '["V1"; "V2"; "V3"]'
        }
        result = get_dict_code_value_list(data, 'codes', 'values')
        assert result == [('C1', 'V1'), ('C2', 'V2'), ('C3', 'V3')]

    def test_get_dict_code_value_list_returns_none_for_mismatch(self):
        data = {
            'codes': '["C1"; "C2"]',
            'values': '["V1"]'
        }
        result = get_dict_code_value_list(data, 'codes', 'values')
        assert result is None


class TestDateTimeAdjustment:
    """Testy pro úpravu času"""

    def test_adjust_datetime_to_utc_for_storage(self):
        d = date(2023, 5, 15)
        result = adjust_datetime_to_utc(d, for_store=True)
        assert isinstance(result, datetime)
        assert result.tzinfo == pytz.UTC

    def test_adjust_datetime_to_utc_datetime_to_date(self):
        dt = datetime(2023, 5, 15, 12, 0, 0, tzinfo=pytz.UTC)
        result = adjust_datetime_to_utc(dt, for_store=False)
        assert isinstance(result, date)
        assert result == date(2023, 5, 15)

    def test_adjust_datetime_to_utc_handles_none(self):
        assert adjust_datetime_to_utc(None) is None

    def test_dict_convert_date_to_str_converts_datetimes(self):
        data = {
            'dt': datetime(2023, 5, 15, 12, 0, 0, tzinfo=pytz.UTC),
            'nested': {
                'dt': datetime(2023, 5, 16, 13, 0, 0, tzinfo=pytz.UTC)
            }
        }
        dict_convert_date_to_str(data)
        assert isinstance(data['dt'], str)
        assert 'T' in data['dt']
        assert isinstance(data['nested']['dt'], str)


class TestPaging:
    """Testy pro stránkování"""

    def test_paging_to_mongo_default(self):
        result = paging_to_mongo()
        assert result['start'] == 0
        assert result['page'] == 0
        assert result['skip'] == 0
        assert result['limit'] == 10

    def test_paging_to_mongo_with_start(self):
        result = paging_to_mongo(start=25, page_size=10)
        assert result['page'] == 2
        assert result['skip'] == 25
        assert result['limit'] == 5

    def test_paging_to_mongo_with_page(self):
        result = paging_to_mongo(page=2, page_size=10)
        assert result['skip'] == 20
        assert result['limit'] == 10


class TestAddressToString:
    """Testy pro konverzi adresy"""

    def test_address_to_string_from_string(self):
        address = "Street 123, City"
        result = address_to_string(address)
        assert result == "Street 123, City"

    def test_address_to_string_from_list(self):
        address = ["Street 123", "City 456 78", "Country"]
        result = address_to_string(address)
        assert "Street 123" in result
        assert "City 456 78" in result
        assert "Country" in result

    def test_address_to_string_from_dict(self):
        address = {
            'street': 'Main Street 123',
            'city': 'Prague',
            'zip': '110 00'
        }
        result = address_to_string(address)
        assert "Main Street 123" in result
        assert "Prague" in result
        assert "110 00" in result

    def test_address_to_string_handles_none(self):
        assert address_to_string(None) == ''
        assert address_to_string('') == ''


class TestPersonTypeEnum:
    """Testy pro PersonTypeEnum konverzi"""

    def test_get_dict_value_as_person_type_valid_enum(self):
        data = {'type': 'legalEntity'}
        result = get_dict_value_as_person_type(data, 'type')
        assert result == PersonTypeEnum.LEGAL_ENTITY

    def test_get_dict_value_as_person_type_legacy_codes(self):
        data_po = {'type': 'PO'}
        assert get_dict_value_as_person_type(data_po, 'type') == PersonTypeEnum.LEGAL_ENTITY

        data_fo = {'type': 'FO'}
        assert get_dict_value_as_person_type(data_fo, 'type') == PersonTypeEnum.BUSINESS_NATURAL_PERSON

        data_fn = {'type': 'FN'}
        assert get_dict_value_as_person_type(data_fn, 'type') == PersonTypeEnum.NATURAL_PERSON

        data_co = {'type': 'CO'}
        assert get_dict_value_as_person_type(data_co, 'type') == PersonTypeEnum.FOREIGN_LEGAL_ENTITY

    def test_get_dict_value_as_person_type_returns_none_for_invalid(self):
        data = {'type': 'INVALID'}
        result = get_dict_value_as_person_type(data, 'type')
        assert result is None

    def test_get_dict_value_as_person_type_returns_none_for_missing(self):
        data = {}
        result = get_dict_value_as_person_type(data, 'type')
        assert result is None
