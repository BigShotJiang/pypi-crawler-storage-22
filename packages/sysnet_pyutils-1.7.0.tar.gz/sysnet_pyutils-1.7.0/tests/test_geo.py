"""
Testy pro modul sysnet_pyutils.geo
"""
import pytest
import math

from sysnet_pyutils.geo import JTSK, Wgs84


class TestWgs84:
    """Testy pro třídu Wgs84"""

    def test_wgs84_initialization(self):
        wgs = Wgs84(latitude=50.0, longitude=14.0)
        assert wgs.latitude == 50.0
        assert wgs.longitude == 14.0
        assert wgs.altitude == 200.0

    def test_wgs84_with_custom_altitude(self):
        wgs = Wgs84(latitude=50.0, longitude=14.0, altitude=300.0)
        assert wgs.altitude == 300.0


class TestJTSK:
    """Testy pro třídu JTSK"""

    def test_jtsk_initialization(self):
        jtsk = JTSK(x=-500000.0, y=-1000000.0)
        assert jtsk.x == -500000.0
        assert jtsk.y == -1000000.0


class TestWgs84ToJTSK:
    """Testy pro konverzi WGS84 na JTSK"""

    def test_from_wgs84_prague_center(self):
        lat = 50.0755
        lon = 14.4378
        alt = 200.0

        jtsk = JTSK(0, 0)
        jtsk.from_wgs84(lon=lon, lat=lat, alt=alt)

        assert jtsk.x < 0
        assert jtsk.y < 0
        assert -900000 < jtsk.x < -700000
        assert -1200000 < jtsk.y < -1000000

    def test_from_wgs84_consistency(self):
        lat = 49.5
        lon = 15.0

        jtsk1 = JTSK(0, 0)
        jtsk1.from_wgs84(lon=lon, lat=lat)

        jtsk2 = JTSK(0, 0)
        jtsk2.from_wgs84(lon=lon, lat=lat)

        assert abs(jtsk1.x - jtsk2.x) < 0.001
        assert abs(jtsk1.y - jtsk2.y) < 0.001

    def test_from_wgs84_returns_self(self):
        jtsk = JTSK(0, 0)
        result = jtsk.from_wgs84(lon=14.0, lat=50.0)
        assert result is jtsk

    def test_from_wgs84_different_altitudes(self):
        lat = 50.0
        lon = 14.0

        jtsk1 = JTSK(0, 0)
        jtsk1.from_wgs84(lon=lon, lat=lat, alt=200.0)

        jtsk2 = JTSK(0, 0)
        jtsk2.from_wgs84(lon=lon, lat=lat, alt=500.0)

        assert abs(jtsk1.x - jtsk2.x) > 0.001 or abs(jtsk1.y - jtsk2.y) > 0.001

    def test_from_wgs84_north_south_orientation(self):
        jtsk_north = JTSK(0, 0)
        jtsk_north.from_wgs84(lon=14.0, lat=51.0)

        jtsk_south = JTSK(0, 0)
        jtsk_south.from_wgs84(lon=14.0, lat=49.0)

        assert jtsk_north.y > jtsk_south.y

    def test_from_wgs84_west_east_orientation(self):
        jtsk_west = JTSK(0, 0)
        jtsk_west.from_wgs84(lon=13.0, lat=50.0)

        jtsk_east = JTSK(0, 0)
        jtsk_east.from_wgs84(lon=15.0, lat=50.0)

        assert jtsk_west.x < jtsk_east.x


class TestJTSKKnownPoints:
    """Testy s známými body"""

    def test_known_point_prague_castle(self):
        lat = 50.0909
        lon = 14.4007

        jtsk = JTSK(0, 0)
        jtsk.from_wgs84(lon=lon, lat=lat)

        assert -800000 < jtsk.x < -700000
        assert -1100000 < jtsk.y < -1000000

    def test_known_point_brno(self):
        lat = 49.1951
        lon = 16.6068

        jtsk = JTSK(0, 0)
        jtsk.from_wgs84(lon=lon, lat=lat)

        assert -700000 < jtsk.x < -500000
        assert -1300000 < jtsk.y < -1100000


class TestJTSKEdgeCases:
    """Testy okrajových případů"""

    def test_from_wgs84_extreme_coordinates(self):
        jtsk = JTSK(0, 0)
        try:
            jtsk.from_wgs84(lon=14.0, lat=51.5)
            assert isinstance(jtsk.x, float)
            assert isinstance(jtsk.y, float)
        except Exception as e:
            pytest.fail(f"Conversion failed: {e}")

    def test_from_wgs84_zero_altitude(self):
        jtsk = JTSK(0, 0)
        jtsk.from_wgs84(lon=14.0, lat=50.0, alt=0.0)

        assert isinstance(jtsk.x, float)
        assert isinstance(jtsk.y, float)
        assert not math.isnan(jtsk.x)
        assert not math.isnan(jtsk.y)

    def test_from_wgs84_negative_altitude(self):
        jtsk = JTSK(0, 0)
        jtsk.from_wgs84(lon=14.0, lat=50.0, alt=-100.0)

        assert isinstance(jtsk.x, float)
        assert isinstance(jtsk.y, float)
        assert not math.isnan(jtsk.x)
        assert not math.isnan(jtsk.y)


class TestJTSKMathematicalProperties:
    """Testy matematických vlastností"""

    def test_transformation_is_deterministic(self):
        coords = [
            (50.0, 14.0),
            (49.5, 15.5),
            (50.5, 13.5)
        ]

        for lat, lon in coords:
            results = []
            for _ in range(3):
                jtsk = JTSK(0, 0)
                jtsk.from_wgs84(lon=lon, lat=lat)
                results.append((jtsk.x, jtsk.y))

            for result in results[1:]:
                assert abs(result[0] - results[0][0]) < 1e-10
                assert abs(result[1] - results[0][1]) < 1e-10

    def test_transformation_preserves_relative_distances(self):
        jtsk1 = JTSK(0, 0)
        jtsk1.from_wgs84(lon=14.0, lat=50.0)

        jtsk2 = JTSK(0, 0)
        jtsk2.from_wgs84(lon=14.01, lat=50.0)

        dist_jtsk_small = math.sqrt((jtsk2.x - jtsk1.x)**2 + (jtsk2.y - jtsk1.y)**2)

        jtsk3 = JTSK(0, 0)
        jtsk3.from_wgs84(lon=14.0, lat=50.0)

        jtsk4 = JTSK(0, 0)
        jtsk4.from_wgs84(lon=14.1, lat=50.0)

        dist_jtsk_large = math.sqrt((jtsk4.x - jtsk3.x)**2 + (jtsk4.y - jtsk3.y)**2)

        assert dist_jtsk_large > dist_jtsk_small * 5
