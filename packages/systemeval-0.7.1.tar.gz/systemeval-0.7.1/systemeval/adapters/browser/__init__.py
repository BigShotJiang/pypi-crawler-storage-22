"""Browser-based E2E test framework adapters (Playwright)."""

from .playwright_adapter import PlaywrightAdapter

__all__ = ["PlaywrightAdapter"]
