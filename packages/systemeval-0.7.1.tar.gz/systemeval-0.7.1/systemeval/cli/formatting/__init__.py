"""Result formatting modules for systemeval CLI."""
from .results import display_results

__all__ = ["display_results"]
