# MemoryX Python SDK

让 AI Agents 轻松拥有持久记忆

## 快速开始

```python
from memoryx import connect_memory

# 自动注册并连接
memory = connect_memory()

# 存储记忆
memory.add("用户喜欢深色模式")

# 搜索记忆
results = memory.search("用户偏好")
```

## 功能特性

- 🔧 **自动注册** - Agent 自动注册，无需手动配置
- 💾 **永久存储** - 记忆永久保存到向量数据库
- 🔍 **智能搜索** - 基于语义的相似度搜索
- 🏷️ **认知分类** - 自动分类为情景/语义/程序/情感/反思记忆
- 🔒 **隐私安全** - 机器隔离，验证码认领机制

## 完整示例

```python
from memoryx import connect_memory

# 连接记忆系统
memory = connect_memory()

# 存储不同类型的记忆
memory.add(
    content="用户是Python开发者",
    category="semantic"  # 语义记忆
)

memory.add(
    content="用户昨天去了北京",
    category="episodic"  # 情景记忆
)

# 列出所有记忆
memories = memory.list(limit=10)

# 搜索相关记忆
results = memory.search("用户职业")
for item in results["data"]["data"]:
    print(f"- {item['content']}")

# 删除记忆
memory.delete("memory_id_here")

# 获取认领验证码
code = memory.get_claim_code()
print(f"认领验证码: {code}")
```

## 安装

```bash
pip install memoryx
```

## 认领机器

Agent 注册后，访问 [t0ken.ai/agent-register](http://t0ken.ai/agent-register) 输入验证码认领这台机器。

## 文档

详细文档请访问: https://docs.t0ken.ai

## 开源

MemoryX 是开源项目，欢迎贡献代码！

- GitHub: https://github.com/CensorKo/MemoryX
- 许可证: MIT
