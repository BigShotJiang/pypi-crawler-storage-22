def main():
    print("📲 LinkerZap – Gerador de link WhatsApp\n")

    ddi = input("DDI (ex: 55): ").strip()
    ddd = input("DDD (ex: 51): ").strip()
    numero = input("Número (somente números): ").strip()
    mensagem = input("Mensagem: ").strip()

    mensagem = mensagem.replace(" ", "%20")

    link = f"https://wa.me/{ddi}{ddd}{numero}?text={mensagem}"

    print("\n✅ Link gerado com sucesso:\n")
    print(link)


if __name__ == "__main__":
    main()
