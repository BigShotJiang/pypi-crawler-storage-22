# qrcoder

Gerador de QR Code via terminal (CLI).

## Instalação
```bash
pip install qrcoder
