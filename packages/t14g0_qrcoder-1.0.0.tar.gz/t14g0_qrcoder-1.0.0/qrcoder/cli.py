import qrcode
import os
from datetime import datetime

SAVE_DIR = os.path.expanduser("~/Imagens")

def main():
    print("=" * 42)
    print(" QRCODER - Gerador de QR Code CLI ")
    print(" Gratuito • Offline • Vitalício ")
    print("=" * 42)

    link = input("\nDigite o link para gerar o QR Code:\n> ").strip()

    if not link:
        print("❌ Link inválido.")
        return

    name = input("\nDigite o nome do arquivo (sem .png):\n> ").strip()

    if not name:
        name = f"qrcode_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    filepath = os.path.join(SAVE_DIR, f"{name}.png")

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_Q,
        box_size=10,
        border=4,
    )

    qr.add_data(link)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    img.save(filepath)

    print("\n✅ QR Code gerado com sucesso!")
    print(f"📁 Salvo em:\n{filepath}")
