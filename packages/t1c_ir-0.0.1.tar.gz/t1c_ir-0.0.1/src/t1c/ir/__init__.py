"""T1C-IR: Neuromorphic Intermediate Representation for T1C hardware.

This package provides the core primitives and graph structure for representing
spiking neural networks and hybrid ANN-SNN architectures in a hardware-agnostic format.

Example:
    import numpy as np
    from t1c.ir import Graph, Input, Output, Affine, LIF, read, write

    nodes = {
        'input': Input(input_type={'input': np.array([784])}),
        'fc1': Affine(
            weight=np.random.randn(128, 784).astype(np.float32),
            bias=np.zeros(128, dtype=np.float32)
        ),
        'lif1': LIF(
            tau=np.ones(128), r=np.ones(128),
            v_leak=np.zeros(128), v_threshold=np.ones(128)
        ),
        'output': Output(output_type={'output': np.array([128])})
    }
    edges = [('input', 'fc1'), ('fc1', 'lif1'), ('lif1', 'output')]
    graph = Graph(nodes=nodes, edges=edges)
    write('model.t1c', graph)
    loaded = read('model.t1c')
"""

__version__ = "0.0.1"

from .node import Node
from .types import Edges, Nodes, Shape
from .graph import Graph, Input, Output
from .linear import Affine, SpikingAffine, SpikeMode
from .conv import Conv2d, SepConv2d
from .pooling import MaxPool2d, AvgPool2d
from .flatten import Flatten
from .neurons import (
    LIF,
    ReLU,
    Sigmoid,
    Tanh,
    Softmax,
    GELU,
    ELU,
    PReLU,
    BatchNorm1d,
    BatchNorm2d,
    LayerNorm,
    Dropout,
    HybridRegion,
    NeuronMode,
)
from .skip import Skip, SkipType
from .upsample import Upsample, UpsampleMode
from .serialization import read, write, read_version, T1CFormatError

# Node registry - maps type name to class for deserialization
_NODE_REGISTRY = {
    "Graph": Graph,
    "Input": Input,
    "Output": Output,
    "Affine": Affine,
    "SpikingAffine": SpikingAffine,
    "Conv2d": Conv2d,
    "SepConv2d": SepConv2d,
    "MaxPool2d": MaxPool2d,
    "AvgPool2d": AvgPool2d,
    "Flatten": Flatten,
    "LIF": LIF,
    "ReLU": ReLU,
    "Sigmoid": Sigmoid,
    "Tanh": Tanh,
    "Softmax": Softmax,
    "GELU": GELU,
    "ELU": ELU,
    "PReLU": PReLU,
    "BatchNorm1d": BatchNorm1d,
    "BatchNorm2d": BatchNorm2d,
    "LayerNorm": LayerNorm,
    "Dropout": Dropout,
    "HybridRegion": HybridRegion,
    "Skip": Skip,
    "Upsample": Upsample,
}


def str_to_node(name: str) -> type:
    """Get node class by name."""
    if name not in _NODE_REGISTRY:
        raise ValueError(f"Unknown node type: {name}. Available: {list(_NODE_REGISTRY.keys())}")
    return _NODE_REGISTRY[name]


def register_node(cls: type) -> type:
    """Decorator to register a custom node type at runtime."""
    _NODE_REGISTRY[cls.__name__] = cls
    return cls


def list_primitives() -> list[str]:
    """List all registered primitive names (excludes Graph, Input, Output)."""
    return [k for k in _NODE_REGISTRY.keys() if k not in ("Graph", "Input", "Output")]

__all__ = [
    "__version__",
    "Node",
    "Edges",
    "Nodes",
    "Shape",
    "Graph",
    "Input",
    "Output",
    "Affine",
    "SpikingAffine",
    "SpikeMode",
    "Conv2d",
    "SepConv2d",
    "MaxPool2d",
    "AvgPool2d",
    "Flatten",
    "LIF",
    "ReLU",
    "Sigmoid",
    "Tanh",
    "Softmax",
    "GELU",
    "ELU",
    "PReLU",
    "BatchNorm1d",
    "BatchNorm2d",
    "LayerNorm",
    "Dropout",
    "HybridRegion",
    "NeuronMode",
    "Skip",
    "SkipType",
    "Upsample",
    "UpsampleMode",
    "str_to_node",
    "register_node",
    "list_primitives",
    "read",
    "write",
    "read_version",
    "T1CFormatError",
]
