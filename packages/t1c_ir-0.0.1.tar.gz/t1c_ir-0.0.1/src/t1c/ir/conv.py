"""Convolution primitives.

This module contains 2D convolution operations:
- Conv2d: Standard 2D convolution
- SepConv2d: Depthwise separable convolution (more efficient)

Adding a new convolution primitive:
    1. Create a new dataclass inheriting from Node
    2. Define weight arrays and convolution parameters (stride, padding, etc.)
    3. Implement __post_init__ to validate shapes and compute input_type/output_type
    4. Use utils.conv2d_output_shape() for output shape calculation
    5. Register in __init__.py's _NODE_REGISTRY

Example:
    @dataclass(eq=False)
    class MyConv2d(Node):
        weight: np.ndarray
        bias: np.ndarray
        stride: Tuple[int, int] = (1, 1)
        padding: Tuple[int, int] = (0, 0)
        input_type: Optional[Shape] = None
        output_type: Optional[Shape] = None

        def __post_init__(self) -> None:
            out_ch = self.weight.shape[0]
            in_ch = self.weight.shape[1]
            if self.input_type is None:
                self.input_type = {"input": np.array([in_ch])}
            if self.output_type is None:
                self.output_type = {"output": np.array([out_ch])}
"""

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from .node import Node
from .types import Shape
from .utils import conv2d_output_shape


@dataclass(eq=False)
class Conv2d(Node):
    """2D convolution layer.

    Args:
        weight: Kernel of shape (out_channels, in_channels, kH, kW)
        bias: Bias of shape (out_channels,)
        stride: Stride (sH, sW), default (1, 1)
        padding: Padding (pH, pW), default (0, 0)
        dilation: Dilation (dH, dW), default (1, 1)
        groups: Number of groups for grouped convolution, default 1

    Example:
        from t1c.ir import Conv2d
        conv = Conv2d(
            weight=np.random.randn(16, 2, 3, 3).astype(np.float32),
            bias=np.zeros(16, dtype=np.float32),
            padding=(1, 1)
        )
        # Input: [2, H, W] -> Output: [16, H, W] (with same padding)
    """

    weight: np.ndarray
    bias: np.ndarray
    stride: Tuple[int, int] = (1, 1)
    padding: Tuple[int, int] = (0, 0)
    dilation: Tuple[int, int] = (1, 1)
    groups: int = 1
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        if self.weight.ndim != 4:
            raise ValueError("weight must be 4D (out_ch, in_ch, kH, kW)")
        out_ch = self.weight.shape[0]
        if self.bias.ndim != 1 or self.bias.shape[0] != out_ch:
            raise ValueError(f"bias must be 1D with {out_ch} elements, got shape {self.bias.shape}")
        if self.input_type is None:
            in_ch = self.weight.shape[1] * self.groups
            self.input_type = {"input": np.array([in_ch])}
        if self.output_type is None:
            self.output_type = {"output": np.array([out_ch])}


@dataclass(eq=False)
class SepConv2d(Node):
    """Depthwise separable convolution.

    Factorizes standard convolution into:
    1. Depthwise: Each input channel convolved separately (groups=in_channels)
    2. Pointwise: 1x1 convolution to mix channels

    More efficient than Conv2d: O(k^2*C + C*C') vs O(k^2*C*C')

    Args:
        depthwise_weight: (in_ch, 1, kH, kW) kernel
        pointwise_weight: (out_ch, in_ch, 1, 1) kernel
        depthwise_bias: (in_ch,) bias, defaults to zeros
        pointwise_bias: (out_ch,) bias, defaults to zeros
        stride, padding, dilation: Same as Conv2d

    Example:
        from t1c.ir import SepConv2d
        sep = SepConv2d(
            depthwise_weight=np.random.randn(2, 1, 3, 3).astype(np.float32),
            pointwise_weight=np.random.randn(8, 2, 1, 1).astype(np.float32),
            padding=(1, 1),
            input_type={'input': np.array([2, 35, 35])}
        )
        # Input: [2, 35, 35] -> Output: [8, 35, 35]
    """

    depthwise_weight: np.ndarray  # (in_ch, 1, kH, kW)
    pointwise_weight: np.ndarray  # (out_ch, in_ch, 1, 1)
    depthwise_bias: Optional[np.ndarray] = None
    pointwise_bias: Optional[np.ndarray] = None
    stride: Tuple[int, int] = (1, 1)
    padding: Tuple[int, int] = (0, 0)
    dilation: Tuple[int, int] = (1, 1)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        # Validate depthwise weight: (in_ch, 1, kH, kW)
        if self.depthwise_weight.ndim != 4:
            raise ValueError("depthwise_weight must be 4D (in_ch, 1, kH, kW)")
        if self.depthwise_weight.shape[1] != 1:
            raise ValueError("depthwise_weight dim 1 must be 1")

        # Validate pointwise weight: (out_ch, in_ch, 1, 1)
        if self.pointwise_weight.ndim != 4:
            raise ValueError("pointwise_weight must be 4D (out_ch, in_ch, 1, 1)")
        if self.pointwise_weight.shape[2] != 1 or self.pointwise_weight.shape[3] != 1:
            raise ValueError("pointwise_weight must have kernel size (1, 1)")

        in_ch = self.depthwise_weight.shape[0]
        out_ch = self.pointwise_weight.shape[0]
        kH, kW = self.depthwise_weight.shape[2], self.depthwise_weight.shape[3]

        if self.pointwise_weight.shape[1] != in_ch:
            raise ValueError("pointwise in_channels must match depthwise in_channels")

        # Set default biases
        if self.depthwise_bias is None:
            self.depthwise_bias = np.zeros(in_ch, dtype=np.float32)
        if self.pointwise_bias is None:
            self.pointwise_bias = np.zeros(out_ch, dtype=np.float32)

        # Compute output shape
        if self.input_type is not None and self.output_type is None:
            if "input" not in self.input_type:
                raise ValueError(
                    f"SepConv2d input_type dict must contain 'input' key, got keys: {list(self.input_type.keys())}"
                )
            in_shape = self.input_type["input"]
            if in_shape is None:
                raise ValueError("SepConv2d input_type['input'] cannot be None")
            if len(in_shape) >= 3:
                out = conv2d_output_shape(
                    tuple(int(x) for x in in_shape),
                    out_ch,
                    (kH, kW),
                    self.stride,
                    self.padding,
                    self.dilation,
                )
                self.output_type = {"output": np.array(out)}
            elif len(in_shape) >= 1:
                self.output_type = {"output": np.array([out_ch])}
            else:
                raise ValueError(
                    f"SepConv2d requires input with at least 1 dimension, got shape {tuple(in_shape)}"
                )
        elif self.output_type is None:
            self.input_type = {"input": np.array([in_ch])}
            self.output_type = {"output": np.array([out_ch])}

