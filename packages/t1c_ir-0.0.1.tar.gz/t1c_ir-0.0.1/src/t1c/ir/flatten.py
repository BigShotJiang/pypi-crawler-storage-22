"""Tensor reshape primitives.

This module contains operations that change tensor shape without computation:
- Flatten: Collapse dimensions into a single dimension

Adding a new reshape primitive:
    1. Create a new dataclass inheriting from Node
    2. Define shape transformation parameters
    3. Implement __post_init__ to compute output shape from input shape
    4. Register in __init__.py's _NODE_REGISTRY

Example:
    @dataclass(eq=False)
    class Reshape(Node):
        target_shape: Tuple[int, ...]
        input_type: Optional[Shape] = None
        output_type: Optional[Shape] = None

        def __post_init__(self) -> None:
            if self.output_type is None:
                self.output_type = {"output": np.array(self.target_shape)}
"""

from dataclasses import dataclass
from typing import Optional

import numpy as np

from .node import Node
from .types import Shape
from .utils import flatten_output_size


@dataclass(eq=False)
class Flatten(Node):
    """Flatten contiguous dimensions into a single dimension.

    Args:
        start_dim: First dimension to flatten (default 0)
        end_dim: Last dimension to flatten (default -1, i.e. last)
        input_type: Required to compute output shape

    Example:
        flat = Flatten(
            start_dim=0, end_dim=-1,
            input_type={'input': np.array([2, 35, 35])}
        )
        # Input: [2, 35, 35] -> Output: [2450]
    """

    start_dim: int = 0
    end_dim: int = -1
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        if self.input_type is not None and self.output_type is None:
            if "input" not in self.input_type:
                raise ValueError(
                    f"Flatten input_type dict must contain 'input' key, got keys: {list(self.input_type.keys())}"
                )
            shape = self.input_type["input"]
            if shape is None:
                raise ValueError("Flatten input_type['input'] cannot be None")

            ndim = len(shape)
            if ndim == 0:
                raise ValueError("Flatten requires input with at least 1 dimension")

            # Normalize negative indices
            s = self.start_dim if self.start_dim >= 0 else ndim + self.start_dim
            e = self.end_dim if self.end_dim >= 0 else ndim + self.end_dim

            # Validate bounds
            if not (0 <= s < ndim):
                raise ValueError(
                    f"start_dim={self.start_dim} (normalized: {s}) out of bounds for input shape {tuple(shape)} with {ndim} dimensions"
                )
            if not (0 <= e < ndim):
                raise ValueError(
                    f"end_dim={self.end_dim} (normalized: {e}) out of bounds for input shape {tuple(shape)} with {ndim} dimensions"
                )
            if s > e:
                raise ValueError(
                    f"start_dim={self.start_dim} (normalized: {s}) must be <= end_dim={self.end_dim} (normalized: {e})"
                )

            flat_size = flatten_output_size(tuple(shape), self.start_dim, self.end_dim)
            out = list(shape[:s]) + [flat_size] + list(shape[e + 1 :])
            self.output_type = {"output": np.array(out)}

