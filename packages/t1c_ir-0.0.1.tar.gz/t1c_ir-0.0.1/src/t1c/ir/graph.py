"""Graph structure and I/O nodes for T1C-IR.

This module provides the core Graph class for representing spiking neural
network architectures as directed graphs of computational primitives.

Key Features:
    - DAG enforcement by default for hardware pipelining
    - Optional cyclic graph support for recurrent architectures
    - RustworkX-powered graph algorithms (cycle detection, topology)
    - Lazy caching for O(1) repeated algorithm calls
    - Hybrid ANN-SNN architecture support

Graph Structure:
    A Graph contains nodes (primitives) connected by directed edges.
    Input/Output nodes mark the graph boundaries.
    
    nodes: Dict mapping node names to Node instances
    edges: List of (src, dst) tuples defining connections

RustworkX Integration:
    Graph operations use RustworkX (Rust-powered graph library) for
    high-performance algorithms:
    
    - is_dag property: O(V+E) cycle detection
    - find_cycles(): Find all simple cycles
    - get_strongly_connected_components(): SCC analysis
    
    The RustworkX graph is built lazily on first access and cached.
    Performance: ~100x faster than pure Python for large graphs.

Usage:
    from t1c.ir import Graph, Input, Output, Affine, LIF
    # Create a simple sequential graph
    nodes = {
        'input': Input(np.array([784])),
        'fc': Affine(weight=w, bias=b),
        'lif': LIF(tau=tau, r=r, v_leak=vl, v_threshold=vt),
        'output': Output(np.array([10]))
    }
    edges = [('input', 'fc'), ('fc', 'lif'), ('lif', 'output')]
    graph = Graph(nodes=nodes, edges=edges)
    
    # Check if DAG
    assert graph.is_dag  # Uses RustworkX
    
    # Validate structure
    graph.validate()  # Raises ValueError if invalid
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import numpy as np
import rustworkx as rx

from .node import Node
from .types import Edges, Nodes, Shape

if TYPE_CHECKING:
    pass


@dataclass(eq=False)
class Input(Node):
    """Graph input marker.

    Marks an entry point to the graph. Shape specifies expected input dimensions.

    Args:
        input_type: Shape array, e.g. np.array([2, 35, 35]) for 2-channel 35x35 image

    Example:
        inp = Input(np.array([784]))  # 784-dimensional input
    """

    input_type: Shape
    metadata: Dict[str, Any] = field(default_factory=dict)
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        if not isinstance(self.input_type, dict):
            self.input_type = {"input": np.asarray(self.input_type)}
        if "input" not in self.input_type:
            raise ValueError(
                f"Input node requires 'input' key in input_type dict, got keys: {list(self.input_type.keys())}"
            )
        self.output_type = {"output": self.input_type["input"]}

    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "Input", "shape": self.input_type["input"]}
        if self.metadata:
            d["metadata"] = self.metadata
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Input:
        return cls(
            input_type={"input": np.asarray(data["shape"])},
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class Output(Node):
    """Graph output marker.

    Marks an exit point from the graph. Shape specifies output dimensions.

    Args:
        output_type: Shape array, e.g. np.array([10]) for 10-class output

    Example:
        out = Output(np.array([4]))  # 4-class output
    """

    output_type: Shape
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        if not isinstance(self.output_type, dict):
            self.output_type = {"output": np.asarray(self.output_type)}
        if "output" not in self.output_type:
            raise ValueError(
                f"Output node requires 'output' key in output_type dict, got keys: {list(self.output_type.keys())}"
            )
        self.input_type = {"input": self.output_type["output"]}

    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "Output", "shape": self.output_type["output"]}
        if self.metadata:
            d["metadata"] = self.metadata
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Output:
        return cls(
            output_type={"output": np.asarray(data["shape"])},
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class Graph(Node):
    """T1C-IR computational graph.

    A directed graph of primitives connected by edges. By default, graphs are
    expected to be acyclic (DAG), but cyclic graphs are supported for advanced
    use cases like recurrent SNNs and hybrid ANN-SNN architectures.

    Args:
        nodes: Dict mapping node names to Node instances
        edges: List of (src, dst) tuples defining connections
        metadata: Optional dict for arbitrary metadata
        allow_cycles: If True, allows cyclic graphs (default: False for DAGs)

    Example:
        nodes = {
            'input': Input(np.array([784])),
            'fc': Affine(weight=w, bias=b),
            'output': Output(np.array([10]))
        }
        edges = [('input', 'fc'), ('fc', 'output')]
        graph = Graph(nodes=nodes, edges=edges)
        
    Cyclic Graph Example (recurrent SNN):
        # Recurrent connection from LIF back to input processing
        nodes = {...}
        edges = [..., ('lif1', 'hidden'), ('hidden', 'lif1')]  # Creates cycle
        graph = Graph(nodes=nodes, edges=edges, allow_cycles=True)

    Properties:
        inputs: Dict of Input nodes
        outputs: Dict of Output nodes
        input_type: Aggregated input shapes
        output_type: Aggregated output shapes
        is_dag: True if graph is acyclic
    """

    nodes: Nodes
    edges: Edges
    metadata: Dict[str, Any] = field(default_factory=dict)
    allow_cycles: bool = field(default=False)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    # Internal RustworkX cache (not serialized)
    _rx_graph: Optional[rx.PyDiGraph] = field(default=None, repr=False, compare=False)
    _node_to_idx: Optional[Dict[str, int]] = field(default=None, repr=False, compare=False)
    _idx_to_node: Optional[Dict[int, str]] = field(default=None, repr=False, compare=False)
    
    # Cached properties
    _cached_inputs: Optional[Dict[str, "Input"]] = field(default=None, repr=False, compare=False)
    _cached_outputs: Optional[Dict[str, "Output"]] = field(default=None, repr=False, compare=False)
    _cached_is_dag: Optional[bool] = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        self._update_io_types()
    
    def _get_rx_graph(self) -> rx.PyDiGraph:
        """Get RustworkX DiGraph for algorithm operations (cached).
        
        The RustworkX graph is built lazily on first access and cached.
        Use _invalidate_rx_cache() if nodes/edges are modified.
        
        Performance: Uses batch operations for O(V+E) graph construction.
        - add_nodes_from(): 3.6x faster than individual add_node() calls
        - add_edges_from_no_data(): Batch edge insertion
        
        Returns:
            RustworkX PyDiGraph with nodes indexed by integers
        """
        if self._rx_graph is None:
            G = rx.PyDiGraph()
            
            # Batch add all nodes at once (3.6x faster than loop)
            node_names = list(self.nodes.keys())
            indices = G.add_nodes_from(node_names)
            
            # Build bidirectional index mappings
            self._node_to_idx = dict(zip(node_names, indices))
            self._idx_to_node = dict(zip(indices, node_names))
            
            # Batch add edges using index mapping
            edge_list = [(self._node_to_idx[s], self._node_to_idx[d]) 
                         for s, d in self.edges
                         if s in self._node_to_idx and d in self._node_to_idx]
            G.add_edges_from_no_data(edge_list)
            
            self._rx_graph = G
        return self._rx_graph
    
    def _invalidate_rx_cache(self) -> None:
        """Invalidate RustworkX cache when graph structure changes."""
        self._rx_graph = None
        self._node_to_idx = None
        self._idx_to_node = None
    
    def _invalidate_io_cache(self) -> None:
        """Invalidate cached inputs/outputs when nodes change."""
        self._cached_inputs = None
        self._cached_outputs = None
    
    def _invalidate_dag_cache(self) -> None:
        """Invalidate DAG cache when edges change."""
        self._cached_is_dag = None

    @property
    def is_dag(self) -> bool:
        """Check if the graph is a Directed Acyclic Graph (DAG).
        
        Uses RustworkX for efficient cycle detection.
        
        Returns:
            True if no cycles exist, False otherwise
        """
        if self._cached_is_dag is None:
            G = self._get_rx_graph()
            self._cached_is_dag = rx.is_directed_acyclic_graph(G)
        return self._cached_is_dag

    def _update_io_types(self) -> None:
        """Compute graph I/O types from Input/Output nodes."""
        self.input_type = {
            k: n.input_type["input"]
            for k, n in self.nodes.items()
            if isinstance(n, Input)
        } or None
        self.output_type = {
            k: n.output_type["output"]
            for k, n in self.nodes.items()
            if isinstance(n, Output)
        } or None

    @property
    def inputs(self) -> Dict[str, Input]:
        """All Input nodes in the graph (cached)."""
        if self._cached_inputs is None:
            self._cached_inputs = {k: n for k, n in self.nodes.items() if isinstance(n, Input)}
        return self._cached_inputs

    @property
    def outputs(self) -> Dict[str, Output]:
        """All Output nodes in the graph (cached)."""
        if self._cached_outputs is None:
            self._cached_outputs = {k: n for k, n in self.nodes.items() if isinstance(n, Output)}
        return self._cached_outputs

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "type": "Graph",
            "nodes": {k: n.to_dict() for k, n in self.nodes.items()},
            "edges": self.edges,
        }
        if self.metadata:
            d["metadata"] = self.metadata
        if self.allow_cycles:
            d["allow_cycles"] = True
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Graph:
        from . import str_to_node

        nodes = {}
        for k, n in data["nodes"].items():
            node_type = n.get("type", "Node")
            nodes[k] = str_to_node(node_type).from_dict(n)

        # Decode edges (list comprehension is ~20% faster than loop)
        edges = [
            (a.decode() if isinstance(a, bytes) else a,
             b.decode() if isinstance(b, bytes) else b)
            for a, b in data["edges"]
        ]

        return cls(
            nodes=nodes,
            edges=edges,
            metadata=data.get("metadata", {}),
            allow_cycles=data.get("allow_cycles", False),
        )

    def validate(self) -> None:
        """Validate graph integrity.

        Checks for:
        - Dangling edges (references to non-existent nodes)
        - Missing Input/Output nodes
        - Self-loops
        - Cycles (unless allow_cycles=True)

        Raises:
            ValueError: If graph has structural issues

        Example:
            graph.validate()  # Raises if invalid
        """
        node_names = set(self.nodes.keys())
        
        # Check for at least one Input and Output (before edge iteration)
        if not self.inputs:
            raise ValueError("Graph has no Input nodes")
        if not self.outputs:
            raise ValueError("Graph has no Output nodes")
        
        # Get input/output names for edge validation
        input_names = set(self.inputs.keys())
        output_names = set(self.outputs.keys())

        # Single pass through all edges for all edge-related checks
        for src, dst in self.edges:
            # Check for dangling edges
            if src not in node_names:
                raise ValueError(f"Edge source '{src}' not found in nodes")
            if dst not in node_names:
                raise ValueError(f"Edge destination '{dst}' not found in nodes")
            # Check for self-loops
            if src == dst:
                raise ValueError(f"Self-loop detected: '{src}' -> '{dst}'")
            # Check Input nodes have no incoming edges
            if dst in input_names:
                raise ValueError(f"Input node '{dst}' has incoming edge from '{src}'")
            # Check Output nodes have no outgoing edges
            if src in output_names:
                raise ValueError(f"Output node '{src}' has outgoing edge to '{dst}'")
        
        # Check for cycles (unless explicitly allowed)
        if not self.allow_cycles and not self.is_dag:
            raise ValueError(
                "Graph contains cycles but allow_cycles=False. "
                "Set allow_cycles=True for recurrent/cyclic architectures."
            )
    
    def find_cycles(self) -> List[List[str]]:
        """Find all simple cycles in the graph.
        
        Returns:
            List of cycles, where each cycle is a list of node names
        """
        G = self._get_rx_graph()
        idx_to_node = self._idx_to_node
        
        # Use RustworkX to find simple cycles
        cycles_idx = rx.simple_cycles(G)
        return [[idx_to_node[idx] for idx in cycle] for cycle in cycles_idx]
    
    def get_strongly_connected_components(self) -> List[List[str]]:
        """Get strongly connected components of the graph.
        
        Useful for analyzing cyclic graph structure. Components with
        more than one node contain cycles.
        
        Returns:
            List of components, where each component is a list of node names
        """
        G = self._get_rx_graph()
        idx_to_node = self._idx_to_node
        
        sccs_idx = rx.strongly_connected_components(G)
        return [[idx_to_node[idx] for idx in scc] for scc in sccs_idx]
