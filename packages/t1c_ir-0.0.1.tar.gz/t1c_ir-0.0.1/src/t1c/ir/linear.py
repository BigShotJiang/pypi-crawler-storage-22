"""Linear (fully-connected) layer primitives.

This module contains primitives for dense/linear transformations:
- Affine: Standard fully-connected layer (y = Wx + b)
- SpikingAffine: Hardware-optimized variant with quantization hints

Adding a new linear primitive:
    1. Create a new dataclass inheriting from Node
    2. Define weight/bias arrays and any additional parameters
    3. Implement __post_init__ to compute input_type/output_type
    4. Register in __init__.py's _NODE_REGISTRY

Example:
    @dataclass(eq=False)
    class MyLinear(Node):
        weight: np.ndarray
        bias: np.ndarray
        input_type: Optional[Shape] = None
        output_type: Optional[Shape] = None

        def __post_init__(self) -> None:
            n_out, n_in = self.weight.shape
            if self.input_type is None:
                self.input_type = {"input": np.array([n_in])}
            if self.output_type is None:
                self.output_type = {"output": np.array([n_out])}
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional

import numpy as np

from .node import Node
from .types import Shape

# Type alias for spike encoding modes
SpikeMode = Literal["binary", "graded", "rate"]


@dataclass(eq=False)
class Affine(Node):
    """Fully connected linear layer: y = Wx + b.

    Args:
        weight: Weight matrix of shape (out_features, in_features)
        bias: Bias vector of shape (out_features,)

    Example:
        from t1c.ir import Affine
        fc = Affine(
            weight=np.random.randn(128, 784).astype(np.float32),
            bias=np.zeros(128, dtype=np.float32)
        )
        # Input: [784] -> Output: [128]
    """

    weight: np.ndarray
    bias: np.ndarray
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        if self.weight.ndim != 2:
            raise ValueError("weight must be exactly 2D (out_features, in_features)")
        n_out, n_in = self.weight.shape
        if self.bias.ndim != 1 or self.bias.shape[0] != n_out:
            raise ValueError(f"bias must be 1D with {n_out} elements, got shape {self.bias.shape}")
        if self.input_type is None:
            self.input_type = {"input": np.array([n_in])}
        if self.output_type is None:
            self.output_type = {"output": np.array([n_out])}


@dataclass(eq=False)
class SpikingAffine(Node):
    """Hardware-optimized affine layer with quantization hints.

    Like Affine (y = Wx + b), but includes compilation hints for
    neuromorphic hardware deployment.

    Args:
        weight: Weight matrix (out_features, in_features)
        bias: Bias vector (out_features,)
        spike_mode: Input spike encoding
            - "binary": Binary spikes (0/1)
            - "graded": Multi-level spikes
            - "rate": Rate-coded spikes
        weight_bits: Weight quantization precision (1-32)
        accumulator_bits: MAC accumulator precision (1-64)

    Example:
        from t1c.ir import SpikingAffine
        sfc = SpikingAffine(
            weight=np.random.randn(10, 128).astype(np.float32),
            bias=np.zeros(10, dtype=np.float32),
            spike_mode='binary',
            weight_bits=8,
            accumulator_bits=16
        )
    """

    weight: np.ndarray
    bias: np.ndarray
    spike_mode: SpikeMode = "binary"
    weight_bits: int = 8
    accumulator_bits: int = 16
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.weight.ndim != 2:
            raise ValueError("weight must be 2D (out_features, in_features)")
        n_in, n_out = self.weight.shape[1], self.weight.shape[0]

        if self.bias.ndim != 1 or self.bias.shape[0] != n_out:
            raise ValueError(f"bias must be 1D with {n_out} elements")

        if self.spike_mode not in ("binary", "graded", "rate"):
            raise ValueError("spike_mode must be 'binary', 'graded', or 'rate'")

        if not (1 <= self.weight_bits <= 32):
            raise ValueError("weight_bits must be in [1, 32]")
        if not (1 <= self.accumulator_bits <= 64):
            raise ValueError("accumulator_bits must be in [1, 64]")
        if self.accumulator_bits < self.weight_bits:
            raise ValueError("accumulator_bits must be >= weight_bits")

        if self.input_type is None:
            self.input_type = {"input": np.array([n_in])}
        if self.output_type is None:
            self.output_type = {"output": np.array([n_out])}

