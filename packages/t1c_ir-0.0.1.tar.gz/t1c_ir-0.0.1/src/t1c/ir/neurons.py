"""Neuron primitives for SNNs and hybrid ANN-SNN architectures.

This module contains neuron models and ANN components supporting:

SNN Neurons:
    - LIF: Leaky Integrate-and-Fire neuron (NIR-compliant)

ANN Activations (for hybrid architectures):
    - ReLU: Rectified Linear Unit (with optional negative_slope for LeakyReLU)
    - Sigmoid: Logistic sigmoid activation
    - Tanh: Hyperbolic tangent activation
    - Softmax: Softmax activation for classification
    - GELU: Gaussian Error Linear Unit (common in transformers)
    - ELU: Exponential Linear Unit
    - PReLU: Parametric ReLU with learnable negative slope

Normalization Layers:
    - BatchNorm1d: Batch normalization for 1D features (linear layers)
    - BatchNorm2d: Batch normalization for 2D features (conv layers)
    - LayerNorm: Layer normalization (common in transformers)

Regularization:
    - Dropout: Dropout regularization layer

Region Markers:
    - HybridRegion: Marker node to identify ANN vs SNN regions
    - NeuronMode: Enum for processing mode (SNN/ANN)

Hybrid ANN-SNN Architecture Support:
    Modern neuromorphic systems often use hybrid architectures where:
    - ANN layers perform feature extraction (encoder)
    - SNN layers perform temporal/event-based processing (core)
    - ANN layers perform task-specific output (decoder)
    
    Reference papers:
    - "A Hybrid ANN-SNN Architecture for Low-Power and Low-Latency Visual Perception"
      (CVPR 2024 Workshop)
    - "Best of Both Worlds: Hybrid SNN-ANN Architecture for Event-based Optical Flow"
      (CVPR 2024)

Adding a new neuron primitive:
    1. Create a new dataclass inheriting from Node
    2. Define neuron parameters (time constants, thresholds, etc.)
    3. Implement __post_init__ to validate parameters and compute I/O shapes
    4. Implement to_dict() and from_dict() for serialization
    5. Register in __init__.py's _NODE_REGISTRY

Example:
    @dataclass(eq=False)
    class IF(Node):
        '''Integrate-and-Fire neuron (no leak).'''
        v_threshold: np.ndarray
        input_type: Optional[Shape] = None
        output_type: Optional[Shape] = None

        def __post_init__(self) -> None:
            n = self.v_threshold.shape[0] if self.v_threshold.ndim > 0 else 1
            if self.input_type is None:
                self.input_type = {"input": np.array([n])}
            if self.output_type is None:
                self.output_type = {"output": np.array([n])}

Common neuron models to consider adding:
    - IF: Integrate-and-Fire (no leak)
    - AdEx: Adaptive Exponential Integrate-and-Fire
    - Izhikevich: Izhikevich neuron model
    - SRM: Spike Response Model
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Literal, Optional

import numpy as np

from .node import Node
from .types import Shape


class NeuronMode(str, Enum):
    """Processing mode for neurons in hybrid architectures.
    
    SNN: Spiking neural network mode (event-based, temporal)
    ANN: Artificial neural network mode (rate-based, continuous)
    """
    SNN = "snn"
    ANN = "ann"


@dataclass(eq=False)
class LIF(Node):
    """Leaky Integrate-and-Fire neuron (NIR-compliant).

    Implements the differential equation:
        tau * dv/dt = (v_leak - v) + r * i

    Spikes when membrane potential v >= v_threshold, then resets to zero.

    Args:
        tau: Time constant array of shape (n_neurons,)
        r: Resistance array of shape (n_neurons,)
        v_leak: Leak voltage array of shape (n_neurons,)
        v_threshold: Threshold voltage array of shape (n_neurons,)

    Example:
        lif = LIF(
            tau=np.ones(128),
            r=np.ones(128),
            v_leak=np.zeros(128),
            v_threshold=np.ones(128)
        )

    Note:
        Conversion from snnTorch beta: tau = 1/(1-beta), r = tau
    """

    tau: np.ndarray
    r: np.ndarray
    v_leak: np.ndarray
    v_threshold: np.ndarray
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        # Validate all parameter arrays have consistent shapes
        param_shapes = {
            "tau": self.tau.shape,
            "r": self.r.shape,
            "v_leak": self.v_leak.shape,
            "v_threshold": self.v_threshold.shape,
        }
        unique_shapes = set(param_shapes.values())
        if len(unique_shapes) > 1:
            shape_info = ", ".join(f"{k}={v}" for k, v in param_shapes.items())
            raise ValueError(f"All LIF parameters must have same shape, got: {shape_info}")

        n = self.tau.shape[0] if self.tau.ndim > 0 else 1
        if self.input_type is None:
            self.input_type = {"input": np.array([n])}
        if self.output_type is None:
            self.output_type = {"output": np.array([n])}


# =============================================================================
# ANN Activation Functions (for hybrid ANN-SNN architectures)
# =============================================================================

@dataclass(eq=False)
class ReLU(Node):
    """Rectified Linear Unit activation (ANN mode).
    
    For hybrid ANN-SNN architectures where some layers operate in
    rate-based (ANN) mode rather than spike-based (SNN) mode.
    
    Args:
        features: Number of features/neurons
        negative_slope: Slope for negative values (0 for ReLU, >0 for LeakyReLU)
        metadata: Optional metadata dict
    
    Example:
        # Standard ReLU
        relu = ReLU(features=128)
        
        # Leaky ReLU with negative slope
        leaky_relu = ReLU(features=128, negative_slope=0.01)
    """
    
    features: int
    negative_slope: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "ReLU", "features": self.features}
        if self.negative_slope != 0.0:
            d["negative_slope"] = self.negative_slope
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ReLU":
        return cls(
            features=data["features"],
            negative_slope=data.get("negative_slope", 0.0),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class Sigmoid(Node):
    """Sigmoid activation (ANN mode).
    
    For hybrid ANN-SNN architectures. Outputs values in (0, 1).
    
    Args:
        features: Number of features/neurons
        metadata: Optional metadata dict
    
    Example:
        sigmoid = Sigmoid(features=128)
    """
    
    features: int
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "Sigmoid", "features": self.features}
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Sigmoid":
        return cls(
            features=data["features"],
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class Tanh(Node):
    """Hyperbolic tangent activation (ANN mode).
    
    For hybrid ANN-SNN architectures. Outputs values in (-1, 1).
    
    Args:
        features: Number of features/neurons
        metadata: Optional metadata dict
    
    Example:
        tanh = Tanh(features=128)
    """
    
    features: int
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "Tanh", "features": self.features}
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Tanh":
        return cls(
            features=data["features"],
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class Softmax(Node):
    """Softmax activation (ANN mode).
    
    Computes softmax along a specified dimension. Essential for
    classification outputs in hybrid ANN-SNN architectures.
    
    Args:
        features: Number of features/classes
        dim: Dimension along which to compute softmax (default: -1, last dim)
        metadata: Optional metadata dict
    
    Example:
        # 10-class classification output
        softmax = Softmax(features=10)
        
        # Softmax along specific dimension
        softmax = Softmax(features=100, dim=1)
    """
    
    features: int
    dim: int = -1
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "Softmax", "features": self.features}
        if self.dim != -1:
            d["dim"] = self.dim
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Softmax":
        return cls(
            features=data["features"],
            dim=data.get("dim", -1),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class GELU(Node):
    """Gaussian Error Linear Unit activation (ANN mode).
    
    GELU(x) = x * Φ(x), where Φ is the cumulative distribution
    function of the standard normal distribution.
    
    Common in transformer architectures and modern CNNs.
    
    Args:
        features: Number of features/neurons
        approximate: Use tanh approximation (faster, default: True)
        metadata: Optional metadata dict
    
    Example:
        gelu = GELU(features=256)
        gelu_exact = GELU(features=256, approximate=False)
    """
    
    features: int
    approximate: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "GELU", "features": self.features}
        if not self.approximate:
            d["approximate"] = False
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GELU":
        return cls(
            features=data["features"],
            approximate=data.get("approximate", True),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class ELU(Node):
    """Exponential Linear Unit activation (ANN mode).
    
    ELU(x) = x if x > 0, else alpha * (exp(x) - 1)
    
    Smoother than ReLU for negative inputs, can produce negative outputs.
    
    Args:
        features: Number of features/neurons
        alpha: Scale for negative values (default: 1.0)
        metadata: Optional metadata dict
    
    Example:
        elu = ELU(features=128)
        elu_scaled = ELU(features=128, alpha=0.5)
    """
    
    features: int
    alpha: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "ELU", "features": self.features}
        if self.alpha != 1.0:
            d["alpha"] = self.alpha
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ELU":
        return cls(
            features=data["features"],
            alpha=data.get("alpha", 1.0),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class PReLU(Node):
    """Parametric Rectified Linear Unit activation (ANN mode).
    
    PReLU(x) = x if x >= 0, else weight * x
    
    Unlike LeakyReLU, the negative slope is a learnable parameter.
    
    Args:
        features: Number of features/neurons
        weight: Learnable negative slope parameter array
        metadata: Optional metadata dict
    
    Example:
        # Shared weight across all features
        prelu = PReLU(features=128, weight=np.array([0.25]))
        
        # Per-channel weights
        prelu = PReLU(features=128, weight=np.full(128, 0.25))
    """
    
    features: int
    weight: np.ndarray
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        self.weight = np.atleast_1d(np.asarray(self.weight, dtype=np.float32))
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "PReLU", "features": self.features, "weight": self.weight}
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PReLU":
        return cls(
            features=data["features"],
            weight=np.asarray(data["weight"], dtype=np.float32),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class BatchNorm1d(Node):
    """1D Batch Normalization (ANN mode).
    
    Normalizes over the features dimension for linear layers.
    
    Args:
        num_features: Number of features (C from input of size (N, C) or (N, C, L))
        weight: Scale (gamma) parameter array of shape (num_features,)
        bias: Shift (beta) parameter array of shape (num_features,)
        running_mean: Running mean for inference, shape (num_features,)
        running_var: Running variance for inference, shape (num_features,)
        eps: Small constant for numerical stability (default: 1e-5)
        momentum: Momentum for running stats update (default: 0.1)
        metadata: Optional metadata dict
    
    Example:
        bn = BatchNorm1d(
            num_features=128,
            weight=np.ones(128),
            bias=np.zeros(128),
            running_mean=np.zeros(128),
            running_var=np.ones(128)
        )
    """
    
    num_features: int
    weight: np.ndarray
    bias: np.ndarray
    running_mean: np.ndarray
    running_var: np.ndarray
    eps: float = 1e-5
    momentum: float = 0.1
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        self.weight = np.atleast_1d(np.asarray(self.weight, dtype=np.float32))
        self.bias = np.atleast_1d(np.asarray(self.bias, dtype=np.float32))
        self.running_mean = np.atleast_1d(np.asarray(self.running_mean, dtype=np.float32))
        self.running_var = np.atleast_1d(np.asarray(self.running_var, dtype=np.float32))
        if self.input_type is None:
            self.input_type = {"input": np.array([self.num_features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.num_features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {
            "type": "BatchNorm1d",
            "num_features": self.num_features,
            "weight": self.weight,
            "bias": self.bias,
            "running_mean": self.running_mean,
            "running_var": self.running_var,
        }
        if self.eps != 1e-5:
            d["eps"] = self.eps
        if self.momentum != 0.1:
            d["momentum"] = self.momentum
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchNorm1d":
        return cls(
            num_features=data["num_features"],
            weight=np.asarray(data["weight"], dtype=np.float32),
            bias=np.asarray(data["bias"], dtype=np.float32),
            running_mean=np.asarray(data["running_mean"], dtype=np.float32),
            running_var=np.asarray(data["running_var"], dtype=np.float32),
            eps=data.get("eps", 1e-5),
            momentum=data.get("momentum", 0.1),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class BatchNorm2d(Node):
    """2D Batch Normalization (ANN mode).
    
    Normalizes over the channels dimension for convolutional layers.
    
    Args:
        num_features: Number of channels (C from input of size (N, C, H, W))
        weight: Scale (gamma) parameter array of shape (num_features,)
        bias: Shift (beta) parameter array of shape (num_features,)
        running_mean: Running mean for inference, shape (num_features,)
        running_var: Running variance for inference, shape (num_features,)
        eps: Small constant for numerical stability (default: 1e-5)
        momentum: Momentum for running stats update (default: 0.1)
        metadata: Optional metadata dict
    
    Example:
        bn = BatchNorm2d(
            num_features=64,
            weight=np.ones(64),
            bias=np.zeros(64),
            running_mean=np.zeros(64),
            running_var=np.ones(64)
        )
    """
    
    num_features: int
    weight: np.ndarray
    bias: np.ndarray
    running_mean: np.ndarray
    running_var: np.ndarray
    eps: float = 1e-5
    momentum: float = 0.1
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        self.weight = np.atleast_1d(np.asarray(self.weight, dtype=np.float32))
        self.bias = np.atleast_1d(np.asarray(self.bias, dtype=np.float32))
        self.running_mean = np.atleast_1d(np.asarray(self.running_mean, dtype=np.float32))
        self.running_var = np.atleast_1d(np.asarray(self.running_var, dtype=np.float32))
        if self.input_type is None:
            self.input_type = {"input": np.array([self.num_features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.num_features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {
            "type": "BatchNorm2d",
            "num_features": self.num_features,
            "weight": self.weight,
            "bias": self.bias,
            "running_mean": self.running_mean,
            "running_var": self.running_var,
        }
        if self.eps != 1e-5:
            d["eps"] = self.eps
        if self.momentum != 0.1:
            d["momentum"] = self.momentum
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchNorm2d":
        return cls(
            num_features=data["num_features"],
            weight=np.asarray(data["weight"], dtype=np.float32),
            bias=np.asarray(data["bias"], dtype=np.float32),
            running_mean=np.asarray(data["running_mean"], dtype=np.float32),
            running_var=np.asarray(data["running_var"], dtype=np.float32),
            eps=data.get("eps", 1e-5),
            momentum=data.get("momentum", 0.1),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class LayerNorm(Node):
    """Layer Normalization (ANN mode).
    
    Normalizes over the last D dimensions, where D is the length of
    normalized_shape. Common in transformer architectures.
    
    Args:
        normalized_shape: Shape over which to normalize (typically [features])
        weight: Scale (gamma) parameter array
        bias: Shift (beta) parameter array
        eps: Small constant for numerical stability (default: 1e-5)
        metadata: Optional metadata dict
    
    Example:
        # Normalize over last dimension (features)
        ln = LayerNorm(
            normalized_shape=[256],
            weight=np.ones(256),
            bias=np.zeros(256)
        )
    """
    
    normalized_shape: tuple
    weight: np.ndarray
    bias: np.ndarray
    eps: float = 1e-5
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if isinstance(self.normalized_shape, (list, np.ndarray)):
            self.normalized_shape = tuple(int(x) for x in self.normalized_shape)
        elif isinstance(self.normalized_shape, int):
            self.normalized_shape = (self.normalized_shape,)
        self.weight = np.atleast_1d(np.asarray(self.weight, dtype=np.float32))
        self.bias = np.atleast_1d(np.asarray(self.bias, dtype=np.float32))
        if self.input_type is None:
            self.input_type = {"input": np.array(self.normalized_shape)}
        if self.output_type is None:
            self.output_type = {"output": np.array(self.normalized_shape)}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {
            "type": "LayerNorm",
            "normalized_shape": list(self.normalized_shape),
            "weight": self.weight,
            "bias": self.bias,
        }
        if self.eps != 1e-5:
            d["eps"] = self.eps
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LayerNorm":
        return cls(
            normalized_shape=tuple(data["normalized_shape"]),
            weight=np.asarray(data["weight"], dtype=np.float32),
            bias=np.asarray(data["bias"], dtype=np.float32),
            eps=data.get("eps", 1e-5),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class Dropout(Node):
    """Dropout regularization (ANN mode).
    
    During training, randomly zeroes elements with probability p.
    During inference, this is typically a no-op (identity).
    
    Args:
        features: Number of features passing through
        p: Probability of an element to be zeroed (default: 0.5)
        metadata: Optional metadata dict
    
    Example:
        dropout = Dropout(features=256, p=0.1)
    """
    
    features: int
    p: float = 0.5
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if not 0.0 <= self.p <= 1.0:
            raise ValueError(f"Dropout probability must be in [0, 1], got: {self.p}")
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "Dropout", "features": self.features}
        if self.p != 0.5:
            d["p"] = self.p
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Dropout":
        return cls(
            features=data["features"],
            p=data.get("p", 0.5),
            metadata=data.get("metadata", {}),
        )


@dataclass(eq=False)
class HybridRegion(Node):
    """Marker node for hybrid ANN-SNN architecture regions.
    
    Use this node to explicitly mark sections of a graph as operating
    in ANN or SNN mode. This helps with:
    - Visualization (color-coding regions)
    - Execution optimization (batch processing for ANN regions)
    - Hardware mapping (different accelerators for ANN vs SNN)
    
    Args:
        mode: Processing mode ('snn' or 'ann')
        features: Number of features passing through
        name: Optional human-readable name for the region
        metadata: Optional metadata dict
    
    Example:
        # Mark the start of an ANN encoder region
        encoder_start = HybridRegion(mode='ann', features=256, name='encoder')
        
        # Mark transition to SNN processing
        snn_start = HybridRegion(mode='snn', features=256, name='snn_core')
    """
    
    mode: Literal["snn", "ann"]
    features: int
    name: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    
    def __post_init__(self) -> None:
        if self.mode not in ("snn", "ann"):
            raise ValueError(f"mode must be 'snn' or 'ann', got: {self.mode}")
        if self.input_type is None:
            self.input_type = {"input": np.array([self.features])}
        if self.output_type is None:
            self.output_type = {"output": np.array([self.features])}
    
    def to_dict(self) -> Dict[str, Any]:
        d = {"type": "HybridRegion", "mode": self.mode, "features": self.features}
        if self.name:
            d["name"] = self.name
        if self.metadata:
            d["metadata"] = self.metadata
        return d
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HybridRegion":
        return cls(
            mode=data["mode"],
            features=data["features"],
            name=data.get("name"),
            metadata=data.get("metadata", {}),
        )
