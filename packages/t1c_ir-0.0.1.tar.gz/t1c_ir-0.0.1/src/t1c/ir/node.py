"""Base node class for T1C-IR primitives.

All T1C-IR primitives inherit from Node, which provides serialization
and type tracking infrastructure.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
from typing import Any, Dict

import numpy as np


# eq=False: Nodes use identity comparison, not value comparison,
# because two nodes with identical parameters are still distinct graph elements.
# This is critical for graph construction where the same weight matrix might
# appear in multiple layers but each layer is a unique node.
@dataclass(eq=False)
class Node:
    """Base class for all T1C-IR nodes.

    All primitives (Affine, LIF, Conv2d, etc.) inherit from Node.
    Each node tracks its input/output types for shape propagation.

    Attributes:
        input_type: Dict mapping input name to shape array, e.g. {"input": [784]}
        output_type: Dict mapping output name to shape array, e.g. {"output": [128]}

    Notes:
        - Identity is based on object identity, not value equality
        - Subclasses should call __post_init__ to compute shapes
        - to_dict/from_dict handle HDF5 serialization
    """

    def __eq__(self, other: object) -> bool:
        """Identity comparison (not value comparison)."""
        return self is other

    def to_dict(self) -> Dict[str, Any]:
        """Convert node to dictionary for serialization.

        Returns:
            Dict with 'type' key and all non-None field values.
            Excludes input_type/output_type (computed from parameters).
        """
        d = {"type": type(self).__name__}
        for f in fields(self):
            val = getattr(self, f.name)
            if f.name in ("input_type", "output_type"):
                continue
            if val is None:
                continue
            if isinstance(val, dict) and not val:
                continue
            d[f.name] = val
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Node:
        """Reconstruct node from dictionary.

        Args:
            data: Dictionary with node fields. 'type' key is ignored.

        Returns:
            New node instance with parameters from dict.
        """
        data = data.copy()
        data.pop("type", None)
        valid = {f.name for f in fields(cls)}
        kwargs = {}
        for k, v in data.items():
            if k not in valid:
                continue
            # Convert tuple-like attributes back from numpy arrays
            if k in ("stride", "padding", "dilation", "kernel_size") and isinstance(v, (list, np.ndarray)):
                v = tuple(int(x) for x in v)
            kwargs[k] = v
        return cls(**kwargs)
