"""Pooling primitives.

This module contains spatial downsampling operations:
- MaxPool2d: 2D max pooling
- AvgPool2d: 2D average pooling

Adding a new pooling primitive:
    1. Create a new dataclass inheriting from Node
    2. Define kernel_size, stride, padding parameters
    3. Implement __post_init__ to compute output shape
    4. Use utils.pool2d_output_shape() for output shape calculation
    5. Register in __init__.py's _NODE_REGISTRY

Example:
    @dataclass(eq=False)
    class AvgPool2d(Node):
        kernel_size: Tuple[int, int] = (2, 2)
        stride: Optional[Tuple[int, int]] = None
        padding: Tuple[int, int] = (0, 0)
        input_type: Optional[Shape] = None
        output_type: Optional[Shape] = None

        def __post_init__(self) -> None:
            if self.stride is None:
                self.stride = self.kernel_size
            # ... compute output shape using pool2d_output_shape
"""

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

from .node import Node
from .types import Shape
from .utils import pool2d_output_shape


@dataclass(eq=False)
class MaxPool2d(Node):
    """2D max pooling layer.

    Downsamples spatial dimensions by taking the maximum value in each window.

    Args:
        kernel_size: Pooling window (kH, kW), default (2, 2)
        stride: Stride (sH, sW), defaults to kernel_size
        padding: Padding (pH, pW), default (0, 0)
        dilation: Dilation (dH, dW), default (1, 1)
        ceil_mode: Use ceil for output size calculation, default False
        input_type: Input shape dict for automatic output computation

    Example:
        pool = MaxPool2d(
            kernel_size=(2, 2),
            input_type={'input': np.array([8, 34, 34])}
        )
        # Input: [8, 34, 34] -> Output: [8, 17, 17]
    """

    kernel_size: Tuple[int, int] = (2, 2)
    stride: Optional[Tuple[int, int]] = None
    padding: Tuple[int, int] = (0, 0)
    dilation: Tuple[int, int] = (1, 1)
    ceil_mode: bool = False
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        if self.stride is None:
            self.stride = self.kernel_size
        if self.input_type is not None and self.output_type is None:
            if "input" not in self.input_type:
                raise ValueError(
                    f"MaxPool2d input_type dict must contain 'input' key, got keys: {list(self.input_type.keys())}"
                )
            in_shape = self.input_type["input"]
            if in_shape is None:
                raise ValueError("MaxPool2d input_type['input'] cannot be None")
            if len(in_shape) >= 3:
                out = pool2d_output_shape(
                    tuple(int(x) for x in in_shape),
                    self.kernel_size,
                    self.stride,
                    self.padding,
                    self.dilation,
                    self.ceil_mode,
                )
                self.output_type = {"output": np.array(out)}
            elif len(in_shape) >= 1:
                self.output_type = {"output": np.array([in_shape[0]])}
            else:
                raise ValueError(
                    f"MaxPool2d requires input with at least 1 dimension, got shape {tuple(in_shape)}"
                )


@dataclass(eq=False)
class AvgPool2d(Node):
    """2D average pooling layer.

    Downsamples spatial dimensions by taking the average value in each window.
    Produces smoother outputs compared to MaxPool2d.

    Args:
        kernel_size: Pooling window (kH, kW), default (2, 2)
        stride: Stride (sH, sW), defaults to kernel_size
        padding: Padding (pH, pW), default (0, 0)
        ceil_mode: Use ceil for output size calculation, default False
        count_include_pad: Include padding in average calculation, default True
        input_type: Input shape dict for automatic output computation

    Example:
        pool = AvgPool2d(
            kernel_size=(2, 2),
            input_type={'input': np.array([8, 34, 34])}
        )
        # Input: [8, 34, 34] -> Output: [8, 17, 17]
    """

    kernel_size: Tuple[int, int] = (2, 2)
    stride: Optional[Tuple[int, int]] = None
    padding: Tuple[int, int] = (0, 0)
    ceil_mode: bool = False
    count_include_pad: bool = True
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        if self.stride is None:
            self.stride = self.kernel_size
        if self.input_type is not None and self.output_type is None:
            if "input" not in self.input_type:
                raise ValueError(
                    f"AvgPool2d input_type dict must contain 'input' key, got keys: {list(self.input_type.keys())}"
                )
            in_shape = self.input_type["input"]
            if in_shape is None:
                raise ValueError("AvgPool2d input_type['input'] cannot be None")
            if len(in_shape) >= 3:
                # AvgPool2d uses same output shape calculation as MaxPool2d
                # (without dilation parameter)
                out = pool2d_output_shape(
                    tuple(int(x) for x in in_shape),
                    self.kernel_size,
                    self.stride,
                    self.padding,
                    (1, 1),  # No dilation for AvgPool2d
                    self.ceil_mode,
                )
                self.output_type = {"output": np.array(out)}
            elif len(in_shape) >= 1:
                self.output_type = {"output": np.array([in_shape[0]])}
            else:
                raise ValueError(
                    f"AvgPool2d requires input with at least 1 dimension, got shape {tuple(in_shape)}"
                )
