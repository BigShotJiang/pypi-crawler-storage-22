"""HDF5 serialization for T1C-IR graphs.

T1C-IR uses HDF5 (.t1c files) for portable, self-describing serialization.
All numpy arrays, metadata, and graph structure are preserved.

Example:
    from t1c.ir import read, write, read_version

    write('model.t1c', graph)
    loaded = read('model.t1c')
    version = read_version('model.t1c')
"""

from __future__ import annotations

import pathlib
from typing import Any, Dict, Union

import h5py
import numpy as np

from .graph import Graph
from .node import Node

__version__ = "0.0.1"


class T1CFormatError(Exception):
    """Raised when a T1C-IR file is malformed or corrupt."""


def _write_recursive(group: h5py.Group, data: Dict[str, Any]) -> None:
    """Write dictionary to HDF5 group iteratively (avoids recursion limit).
    
    Uses an explicit stack to avoid Python's recursion limit on deeply nested data.
    """
    # Stack of (group, data_dict) pairs to process
    stack = [(group, data)]
    
    while stack:
        current_group, current_data = stack.pop()
        
        for k, v in current_data.items():
            if v is None:
                continue
            if isinstance(v, str):
                current_group.create_dataset(k, data=v, dtype=h5py.string_dtype())
            elif isinstance(v, np.ndarray):
                current_group.create_dataset(k, data=v, dtype=v.dtype)
            elif isinstance(v, dict):
                # Add to stack for iterative processing instead of recursion
                new_group = current_group.create_group(k)
                stack.append((new_group, v))
            elif isinstance(v, list):
                if not v:
                    # Empty list - store as edge group with empty arrays
                    g = current_group.create_group(k)
                    g.create_dataset("src", data=[], dtype=h5py.string_dtype())
                    g.create_dataset("dst", data=[], dtype=h5py.string_dtype())
                elif isinstance(v[0], tuple):
                    # Edge list - store as src/dst parallel arrays (single pass with zip)
                    if v:
                        src, dst = zip(*v)
                    else:
                        src, dst = [], []
                    g = current_group.create_group(k)
                    g.create_dataset("src", data=list(src), dtype=h5py.string_dtype())
                    g.create_dataset("dst", data=list(dst), dtype=h5py.string_dtype())
                elif isinstance(v[0], str):
                    # List of strings - use h5py string dtype
                    current_group.create_dataset(k, data=v, dtype=h5py.string_dtype())
                else:
                    arr = np.array(v)
                    current_group.create_dataset(k, data=arr, dtype=arr.dtype)
            elif isinstance(v, tuple):
                if len(v) > 0 and isinstance(v[0], str):
                    # Tuple of strings - use h5py string dtype
                    current_group.create_dataset(k, data=list(v), dtype=h5py.string_dtype())
                else:
                    arr = np.array(v)
                    current_group.create_dataset(k, data=arr, dtype=arr.dtype)
            elif isinstance(v, (int, float, bool)):
                current_group.create_dataset(k, data=v)
            else:
                current_group.create_dataset(k, data=str(v), dtype=h5py.string_dtype())


def _read_recursive(group: h5py.Group) -> Dict[str, Any]:
    """Read HDF5 group to dictionary iteratively (avoids recursion limit).
    
    Uses an explicit stack to avoid Python's recursion limit on deeply nested data.
    """
    result = {}
    # Stack of (h5py_group, target_dict) pairs to process
    stack = [(group, result)]
    
    while stack:
        current_group, current_dict = stack.pop()
        
        for key, item in current_group.items():
            if isinstance(item, h5py.Group):
                if "src" in item and "dst" in item:
                    # Edge list - decode and zip
                    src = [s.decode() if isinstance(s, bytes) else s for s in item["src"][()]]
                    dst = [d.decode() if isinstance(d, bytes) else d for d in item["dst"][()]]
                    current_dict[key] = list(zip(src, dst))
                else:
                    # Nested dict - add to stack for iterative processing
                    current_dict[key] = {}
                    stack.append((item, current_dict[key]))
            elif isinstance(item, h5py.Dataset):
                val = item[()]
                if isinstance(val, bytes):
                    val = val.decode("utf8")
                elif isinstance(val, np.ndarray) and val.dtype.kind == 'U':
                    # Unicode string array - convert to list of strings
                    val = val.tolist()
                elif isinstance(val, np.ndarray) and val.dtype.kind == 'S':
                    # Byte string array - decode and convert to list
                    val = [v.decode("utf8") if isinstance(v, bytes) else v for v in val]
                current_dict[key] = val
    
    return result


def write(path: Union[str, pathlib.Path], graph: Node) -> None:
    """Save T1C-IR graph to HDF5 file.

    Args:
        path: Output file path (conventionally .t1c extension)
        graph: Graph to serialize

    Raises:
        ValueError: If path is not a valid file path
        OSError: If file cannot be written

    Example:
        from t1c.ir import write
        write('model.t1c', graph)
    """
    path = pathlib.Path(path)

    # Validate path is not a directory
    if path.is_dir():
        raise ValueError(f"Path is a directory, not a file: {path}")

    # Ensure parent directory exists
    parent = path.parent
    if parent and not parent.exists():
        raise ValueError(f"Parent directory does not exist: {parent}")

    with h5py.File(path, "w") as f:
        f.create_dataset("version", data=__version__, dtype=h5py.string_dtype())
        _write_recursive(f.create_group("graph"), graph.to_dict())


def read(path: Union[str, pathlib.Path]) -> Graph:
    """Load T1C-IR graph from HDF5 file.

    Args:
        path: Input file path

    Returns:
        Deserialized Graph object

    Raises:
        FileNotFoundError: If file does not exist
        T1CFormatError: If file is not a valid T1C-IR file

    Example:
        from t1c.ir import read
        graph = read('model.t1c')
    """
    path = pathlib.Path(path)

    if not path.exists():
        raise FileNotFoundError(f"T1C-IR file not found: {path}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {path}")

    try:
        with h5py.File(path, "r") as f:
            if "graph" not in f:
                raise T1CFormatError(f"Invalid T1C-IR file: missing 'graph' group in {path}")
            if "version" not in f:
                raise T1CFormatError(f"Invalid T1C-IR file: missing 'version' in {path}")

            data = _read_recursive(f["graph"])
            node_type = data.get("type", "Graph")
            from . import str_to_node
            return str_to_node(node_type).from_dict(data)
    except OSError as e:
        raise T1CFormatError(f"Cannot read file as HDF5: {path}") from e


def read_version(path: Union[str, pathlib.Path]) -> str:
    """Read T1C-IR format version from file without loading graph.

    Args:
        path: Input file path

    Returns:
        Version string (e.g. "0.0.1")

    Raises:
        FileNotFoundError: If file does not exist
        T1CFormatError: If file is not a valid T1C-IR file
    """
    path = pathlib.Path(path)

    if not path.exists():
        raise FileNotFoundError(f"T1C-IR file not found: {path}")
    if not path.is_file():
        raise ValueError(f"Path is not a file: {path}")

    try:
        with h5py.File(path, "r") as f:
            if "version" not in f:
                raise T1CFormatError(f"Invalid T1C-IR file: missing 'version' in {path}")
            v = f["version"][()]
            return v.decode("utf8") if isinstance(v, bytes) else v
    except OSError as e:
        raise T1CFormatError(f"Cannot read file as HDF5: {path}") from e
