"""Skip/residual connection primitives.

This module contains primitives for multi-path architectures:
- Skip: Residual connections, concatenation, or passthrough

Adding a new skip/connection primitive:
    1. Create a new dataclass inheriting from Node
    2. Define connection type and any merge parameters
    3. Implement __post_init__ to compute output shape based on connection type
    4. Register in __init__.py's _NODE_REGISTRY

Example:
    @dataclass(eq=False)
    class Add(Node):
        '''Element-wise addition of two inputs.'''
        input_type: Optional[Shape] = None
        output_type: Optional[Shape] = None

        def __post_init__(self) -> None:
            if self.input_type is not None and self.output_type is None:
                self.output_type = {"output": self.input_type["input"].copy()}
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional

import numpy as np

from .node import Node
from .types import Shape

# Type alias for skip connection types
SkipType = Literal["residual", "concatenate", "passthrough", "add", "concat", "identity"]


@dataclass(eq=False)
class Skip(Node):
    """Skip/residual connection for multi-path architectures.

    Args:
        skip_type: Connection type
            - "residual" / "add": Element-wise addition (ResNet-style)
            - "concatenate" / "concat": Channel concatenation (DenseNet-style)
            - "passthrough" / "identity": Identity bypass
        input_type: Input shape dict

    Example:
        skip = Skip(
            input_type={'input': np.array([128])},
            skip_type='residual'
        )
    """

    skip_type: SkipType = "residual"
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Validate skip_type
        valid_types = ("residual", "concatenate", "passthrough", "add", "concat", "identity")
        if self.skip_type not in valid_types:
            raise ValueError(
                f"skip_type must be one of {valid_types}, got '{self.skip_type}'"
            )

        if self.input_type is not None and self.output_type is None:
            if "input" not in self.input_type:
                raise ValueError(
                    f"Skip node input_type dict must contain 'input' key, got keys: {list(self.input_type.keys())}"
                )
            self.output_type = {"output": self.input_type["input"].copy()}

