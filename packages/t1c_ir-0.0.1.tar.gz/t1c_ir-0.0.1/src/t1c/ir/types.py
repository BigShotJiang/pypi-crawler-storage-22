"""Type definitions for T1C-IR."""

from typing import Dict, List, Tuple, TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from .node import Node

# Node dictionary: name -> Node
Nodes = Dict[str, "Node"]

# Edge list: (source_name, target_name)
Edges = List[Tuple[str, str]]

# Shape type: maps port name to shape array
Shape = Dict[str, np.ndarray]
