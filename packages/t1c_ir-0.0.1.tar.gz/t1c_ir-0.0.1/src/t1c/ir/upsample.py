"""Upsample primitive for spatial upsampling operations.

This module contains spatial upsampling operations:
- Upsample: 2D spatial upsampling (nearest/bilinear interpolation)

Commonly used in FPN (Feature Pyramid Network) necks for multi-scale
feature fusion in detection architectures like YOLO, SSD, etc.

Adding a new upsampling primitive:
    1. Create a new dataclass inheriting from Node
    2. Define scale_factor or size parameters
    3. Implement __post_init__ to compute output shape
    4. Register in __init__.py's _NODE_REGISTRY

Example:
    @dataclass(eq=False)
    class Upsample(Node):
        scale_factor: Optional[int] = 2
        size: Optional[Tuple[int, int]] = None
        mode: str = "nearest"
        input_type: Optional[Shape] = None
        output_type: Optional[Shape] = None

        def __post_init__(self) -> None:
            # ... compute output shape
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple

import numpy as np

from .node import Node
from .types import Shape


class UpsampleMode(str, Enum):
    """Upsampling interpolation mode.
    
    Attributes:
        NEAREST: Nearest neighbor interpolation (faster, no new values)
        BILINEAR: Bilinear interpolation (smoother, creates new values)
    """
    
    NEAREST = "nearest"
    BILINEAR = "bilinear"


@dataclass(eq=False)
class Upsample(Node):
    """2D spatial upsampling layer.

    Increases the spatial dimensions of the input using interpolation.
    Commonly used in FPN necks for multi-scale feature fusion.

    The upsampling can be specified either by:
    - `scale_factor`: Multiplier for spatial dimensions (e.g., 2 doubles H and W)
    - `size`: Target output size as (H, W)

    If both are specified, `size` takes precedence.

    Args:
        scale_factor: Multiplier for height and width (e.g., 2 for 2x upsampling)
        size: Target output size as (height, width). Takes precedence over scale_factor.
        mode: Interpolation mode - 'nearest' or 'bilinear', default 'nearest'
        align_corners: If True, aligns corners for bilinear mode.
                       Only used when mode='bilinear'. Default False.
        input_type: Input shape dict for automatic output computation

    Example:
        # 2x upsampling with nearest neighbor (20x20 -> 40x40)
        up = Upsample(
            scale_factor=2,
            mode='nearest',
            input_type={'input': np.array([64, 20, 20])}
        )
        # Input: [64, 20, 20] -> Output: [64, 40, 40]

        # Upsample to specific size with bilinear interpolation
        up = Upsample(
            size=(80, 80),
            mode='bilinear',
            input_type={'input': np.array([128, 40, 40])}
        )
        # Input: [128, 40, 40] -> Output: [128, 80, 80]
    """

    scale_factor: Optional[int] = 2
    size: Optional[Tuple[int, int]] = None
    mode: str = "nearest"
    align_corners: bool = False
    input_type: Optional[Shape] = None
    output_type: Optional[Shape] = None

    def __post_init__(self) -> None:
        """Validate parameters and compute output shape."""
        # Validate mode
        if self.mode not in ("nearest", "bilinear"):
            raise ValueError(
                f"Upsample mode must be 'nearest' or 'bilinear', got '{self.mode}'"
            )

        # Must have either scale_factor or size
        if self.scale_factor is None and self.size is None:
            raise ValueError(
                "Upsample requires either scale_factor or size to be specified"
            )

        # Validate scale_factor
        if self.scale_factor is not None and self.scale_factor < 1:
            raise ValueError(
                f"Upsample scale_factor must be >= 1, got {self.scale_factor}"
            )

        # Validate and normalize size
        if self.size is not None:
            # Handle numpy arrays from HDF5 deserialization
            if isinstance(self.size, np.ndarray):
                self.size = tuple(int(x) for x in self.size)
            elif isinstance(self.size, (tuple, list)):
                self.size = tuple(int(x) for x in self.size)
            else:
                raise ValueError(
                    f"Upsample size must be (H, W) tuple, got {self.size}"
                )
            
            if len(self.size) != 2:
                raise ValueError(
                    f"Upsample size must be (H, W) tuple, got {self.size}"
                )
            if any(s <= 0 for s in self.size):
                raise ValueError(
                    f"Upsample size values must be positive, got {self.size}"
                )

        # align_corners only valid for bilinear
        if self.align_corners and self.mode != "bilinear":
            self.align_corners = False

        # Compute output shape if input shape is known
        if self.input_type is not None and self.output_type is None:
            if "input" not in self.input_type:
                raise ValueError(
                    f"Upsample input_type dict must contain 'input' key, "
                    f"got keys: {list(self.input_type.keys())}"
                )
            in_shape = self.input_type["input"]
            if in_shape is None:
                raise ValueError("Upsample input_type['input'] cannot be None")
            
            if len(in_shape) >= 3:
                c, h, w = int(in_shape[0]), int(in_shape[1]), int(in_shape[2])
                
                if self.size is not None:
                    # Use explicit size
                    out_h, out_w = self.size
                else:
                    # Use scale factor
                    out_h = h * self.scale_factor
                    out_w = w * self.scale_factor
                
                self.output_type = {"output": np.array([c, out_h, out_w])}
            elif len(in_shape) >= 1:
                # 1D case - just keep channels
                self.output_type = {"output": np.array([in_shape[0]])}
            else:
                raise ValueError(
                    f"Upsample requires input with at least 1 dimension, "
                    f"got shape {tuple(in_shape)}"
                )
