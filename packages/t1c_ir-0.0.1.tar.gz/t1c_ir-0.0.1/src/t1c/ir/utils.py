"""Utility functions for T1C-IR primitives.

This module provides helper functions for shape computation:
- conv_output_size: 1D output size for convolution/pooling
- conv2d_output_shape: 2D convolution output shape
- pool2d_output_shape: 2D pooling output shape
- flatten_output_size: Flattened dimension size

These utilities are used by primitives to automatically compute
output shapes from input shapes and layer parameters.
"""

from typing import Tuple

import numpy as np


def conv_output_size(
    in_size: int,
    kernel: int,
    stride: int = 1,
    padding: int = 0,
    dilation: int = 1,
    ceil_mode: bool = False,
) -> int:
    """Compute output size for conv/pool operations.

    Formula: floor((in + 2*pad - dilation*(kernel-1) - 1) / stride + 1)

    Args:
        in_size: Input spatial dimension
        kernel: Kernel size
        stride: Stride (default 1)
        padding: Padding (default 0)
        dilation: Dilation (default 1)
        ceil_mode: Use ceil instead of floor (default False)

    Returns:
        Output spatial dimension

    Raises:
        ValueError: If stride, kernel, or dilation are not positive,
                   or if parameters produce invalid output size
    """
    if stride <= 0:
        raise ValueError(f"stride must be positive, got {stride}")
    if kernel <= 0:
        raise ValueError(f"kernel must be positive, got {kernel}")
    if dilation <= 0:
        raise ValueError(f"dilation must be positive, got {dilation}")
    if in_size <= 0:
        raise ValueError(f"in_size must be positive, got {in_size}")
    if padding < 0:
        raise ValueError(f"padding must be non-negative, got {padding}")

    numerator = in_size + 2 * padding - dilation * (kernel - 1) - 1
    if ceil_mode:
        result = int(np.ceil(numerator / stride + 1))
    else:
        result = int(np.floor(numerator / stride + 1))

    if result <= 0:
        raise ValueError(
            f"Invalid output size {result} for in_size={in_size}, kernel={kernel}, "
            f"stride={stride}, padding={padding}, dilation={dilation}. "
            f"Input is too small for the given kernel/dilation configuration."
        )

    return result


def conv2d_output_shape(
    in_shape: Tuple[int, int, int],  # (C, H, W)
    out_channels: int,
    kernel_size: Tuple[int, int],
    stride: Tuple[int, int] = (1, 1),
    padding: Tuple[int, int] = (0, 0),
    dilation: Tuple[int, int] = (1, 1),
) -> Tuple[int, int, int]:
    """Compute output shape for Conv2d.

    Args:
        in_shape: Input shape (C, H, W)
        out_channels: Number of output channels
        kernel_size: Kernel size (kH, kW)
        stride: Stride (sH, sW)
        padding: Padding (pH, pW)
        dilation: Dilation (dH, dW)

    Returns:
        Output shape (out_channels, out_H, out_W)
    """
    _, H, W = in_shape
    out_H = conv_output_size(H, kernel_size[0], stride[0], padding[0], dilation[0])
    out_W = conv_output_size(W, kernel_size[1], stride[1], padding[1], dilation[1])
    return (out_channels, out_H, out_W)


def pool2d_output_shape(
    in_shape: Tuple[int, int, int],  # (C, H, W)
    kernel_size: Tuple[int, int],
    stride: Tuple[int, int],
    padding: Tuple[int, int] = (0, 0),
    dilation: Tuple[int, int] = (1, 1),
    ceil_mode: bool = False,
) -> Tuple[int, int, int]:
    """Compute output shape for pooling (preserves channels).

    Args:
        in_shape: Input shape (C, H, W)
        kernel_size: Kernel size (kH, kW)
        stride: Stride (sH, sW)
        padding: Padding (pH, pW)
        dilation: Dilation (dH, dW)
        ceil_mode: Use ceil instead of floor

    Returns:
        Output shape (C, out_H, out_W)
    """
    C, H, W = in_shape
    out_H = conv_output_size(H, kernel_size[0], stride[0], padding[0], dilation[0], ceil_mode)
    out_W = conv_output_size(W, kernel_size[1], stride[1], padding[1], dilation[1], ceil_mode)
    return (C, out_H, out_W)


def flatten_output_size(in_shape: Tuple[int, ...], start_dim: int = 0, end_dim: int = -1) -> int:
    """Compute flattened size.

    Args:
        in_shape: Input shape tuple
        start_dim: First dimension to flatten (default 0)
        end_dim: Last dimension to flatten (default -1, meaning last)

    Returns:
        Size of flattened dimension
    """
    if end_dim < 0:
        end_dim = len(in_shape) + end_dim
    return int(np.prod(in_shape[start_dim : end_dim + 1]))

