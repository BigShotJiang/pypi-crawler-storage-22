"""T1C-Viz: Interactive visualization for T1C-IR spiking neural network graphs.

T1C-Viz generates self-contained HTML visualizations with a dual-panel interface:
- Left panel: Netron-style graph visualization with SNN-specific node styling
- Right panel: HDF5-style data explorer with array visualizations

Installation:
    # Basic installation (graph visualization only)
    uv add t1c-viz

    # With Tonic for spike/event visualization (recommended for neuromorphic data)
    uv add t1c-viz[tonic]

Graph Visualization:
    from t1c import ir, viz

    # Load or create a graph
    graph = ir.read('model.t1c')

    # Display interactively (opens browser or shows in Jupyter)
    viz.visualize(graph, title="My SNN Model")

    # Export to standalone HTML file
    viz.export_html(graph, "model.html", title="My SNN Model")

    # Get raw data dict for custom processing
    data = viz.graph_to_dict(graph)

Spike/Event Visualization (requires: uv add t1c-viz[tonic]):
    import tonic
    from t1c import viz

    # Check if Tonic is available
    print(f"Tonic available: {viz.TONIC_AVAILABLE}")

    # Load event data from Tonic dataset
    dataset = tonic.datasets.NMNIST("./data", train=True)
    events, label = dataset[0]

    # Visualize events interactively (uses Tonic's fast ToFrame when available)
    viz.plot_events(events, title=f"NMNIST (label={label})")

    # Export to standalone HTML
    viz.export_events_html(events, "events.html")

    # Visualize pre-computed frames
    transform = tonic.transforms.ToFrame(sensor_size=dataset.sensor_size, time_window=1000)
    frames = transform(events)
    viz.plot_frames(frames)

Performance:
    With Tonic installed, events_to_frames uses Numba-accelerated binning:
    - With Tonic:    ~30M events/sec
    - Without Tonic: ~23M events/sec (pure NumPy fallback)
    Both exceed the 5M events/sec requirement for real-time neuromorphic processing.
"""

__version__ = "0.0.1"

from .serialize import graph_to_dict
from .render import render_html
from .display import visualize, export_html, list_graphs, TEMP_GRAPHS_DIR
from .patterns import (
    detect_all_patterns,
    detect_repconv_patterns,
    detect_spp_patterns,
    detect_sppf_patterns,
    detect_skip_connection_patterns,
    PatternMatch,
    build_group_hierarchy,
)
from .spikes import (
    plot_events,
    export_events_html,
    plot_frames,
    events_to_frames,
    events_to_grid,
    events_to_raster,
    serialize_events,
    TONIC_AVAILABLE,
    PIL_AVAILABLE,
)

__all__ = [
    "__version__",
    # Graph visualization
    "graph_to_dict",
    "render_html",
    "visualize",
    "export_html",
    "list_graphs",
    "TEMP_GRAPHS_DIR",
    # Pattern detection (hierarchical visualization)
    "detect_all_patterns",
    "detect_repconv_patterns",
    "detect_spp_patterns",
    "detect_sppf_patterns",
    "detect_skip_connection_patterns",
    "PatternMatch",
    "build_group_hierarchy",
    # Spike/event visualization (optional: uv add t1c-viz[tonic])
    "plot_events",
    "export_events_html",
    "plot_frames",
    "events_to_frames",
    "events_to_grid",
    "events_to_raster",
    "serialize_events",
    "TONIC_AVAILABLE",
    "PIL_AVAILABLE",
]
