"""Constants for T1C-Viz visualization styling.

Defines colors, shapes, and display properties for each T1C-IR primitive type.
"""

from typing import Dict, Any

# Node colors by primitive type (light, accessible colors for dark text)
NODE_COLORS: Dict[str, str] = {
    "Input": "#a5d6a7",        # Light green
    "Output": "#ffcdd2",       # Light red
    "Affine": "#90caf9",       # Light blue
    "SpikingAffine": "#ce93d8", # Light purple
    "LIF": "#80deea",          # Light cyan - distinctive for neurons
    "Conv2d": "#ffcc80",       # Light orange
    "SepConv2d": "#ffab91",    # Light deep orange
    "MaxPool2d": "#bcaaa4",    # Light brown
    "AvgPool2d": "#90a4ae",    # Light blue grey
    "Upsample": "#b39ddb",     # Light deep purple - inverse of pooling
    "Flatten": "#e0e0e0",      # Light grey
    "Skip": "#ffe082",         # Light amber
    "Graph": "#bdbdbd",        # Light grey for subgraphs
}

# Node shapes by primitive type
NODE_SHAPES: Dict[str, str] = {
    "Input": "terminal",
    "Output": "terminal",
    "Affine": "rectangle",
    "SpikingAffine": "rectangle",
    "LIF": "neuron",           # Special spiking neuron shape
    "Conv2d": "rectangle",
    "SepConv2d": "rectangle",
    "MaxPool2d": "trapezoid",
    "AvgPool2d": "trapezoid",
    "Upsample": "invtrapezoid",  # Inverted trapezoid - opposite of pooling
    "Flatten": "narrow",
    "Skip": "diamond",
    "Graph": "rectangle",
}

# Node dimensions (width, height) by shape type
NODE_DIMENSIONS: Dict[str, tuple] = {
    "terminal": (120, 40),
    "rectangle": (140, 60),
    "neuron": (100, 80),
    "trapezoid": (100, 50),
    "invtrapezoid": (100, 50),  # Inverted trapezoid (Upsample)
    "narrow": (80, 30),
    "diamond": (60, 60),
    "hexagon": (150, 70),  # For RepConv groups
}

# Icons/symbols for each primitive type
NODE_ICONS: Dict[str, str] = {
    "Input": "→",
    "Output": "→",
    "Affine": "⊗",
    "SpikingAffine": "⚡⊗",
    "LIF": "⚡",
    "Conv2d": "⊛",
    "SepConv2d": "⊛⊛",
    "MaxPool2d": "max",
    "AvgPool2d": "avg",
    "Upsample": "↗",
    "Flatten": "▭",
    "Skip": "+",
    "Graph": "{}",
}

# Parameters to display on nodes (for quick reference)
NODE_DISPLAY_PARAMS: Dict[str, list] = {
    "LIF": ["tau", "v_threshold"],
    "SpikingAffine": ["spike_mode", "weight_bits"],
    "Conv2d": ["kernel_size", "stride"],
    "SepConv2d": ["kernel_size", "stride"],
    "MaxPool2d": ["kernel_size"],
    "AvgPool2d": ["kernel_size"],
    "Upsample": ["scale_factor", "mode"],
    "Skip": ["skip_type"],
}

# Default node color for unknown types (light grey for dark text)
DEFAULT_NODE_COLOR = "#e0e0e0"
DEFAULT_NODE_SHAPE = "rectangle"

# ============================================
# Group/Pattern Styling
# ============================================

# Colors for collapsed pattern groups
GROUP_COLORS: Dict[str, str] = {
    "RepConv": "#b39ddb",       # Light deep purple - multi-branch convolution
    "SPP": "#a5d6a7",           # Light green - spatial pyramid pooling
    "SPPF": "#80cbc4",          # Light teal - spatial pyramid pooling fast
    "SkipConnection": "#ffe082", # Light amber - residual/skip connections
    "Default": "#c5cae9",       # Light indigo
}

# Shapes for collapsed pattern groups
GROUP_SHAPES: Dict[str, str] = {
    "RepConv": "hexagon",       # Hexagon for multi-branch patterns
    "SPP": "octagon",           # Octagon for parallel pooling pyramid
    "SPPF": "octagon",          # Octagon for sequential pooling pyramid
    "SkipConnection": "diamond", # Diamond for skip/residual connections
    "Default": "rectangle",
}

# Icons for pattern groups
GROUP_ICONS: Dict[str, str] = {
    "RepConv": "⊕",             # Multi-branch merge (addition)
    "SPP": "⫴",                 # Parallel lines (parallel pooling)
    "SPPF": "⋮",                # Vertical dots (sequential chain)
    "SkipConnection": "↷",      # Curved arrow (shortcut/bypass)
    "Default": "◫",
}

# Display parameters shown on collapsed groups
GROUP_DISPLAY_PARAMS: Dict[str, list] = {
    "RepConv": ["branches"],
    "SPP": ["num_scales"],
    "SPPF": ["chain_depth", "kernel_size"],
    "SkipConnection": ["processing_depth", "path_types"],
}

# Default group styling
DEFAULT_GROUP_COLOR = "#c5cae9"
DEFAULT_GROUP_SHAPE = "rectangle"
