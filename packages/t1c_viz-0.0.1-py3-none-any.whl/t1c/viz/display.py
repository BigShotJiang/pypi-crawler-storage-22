"""Display utilities for T1C-Viz.

Handles browser display and Jupyter notebook integration.
"""

import os
import tempfile
import webbrowser
from pathlib import Path
from typing import Any, List, Optional, Union

from .serialize import graph_to_dict
from .render import render_html

# Temporary directory for generated visualizations
TEMP_GRAPHS_DIR = Path(tempfile.gettempdir()) / "t1c-viz"

# Check for IPython/Jupyter
try:
    from IPython.display import IFrame, display as ipython_display
    _HAS_IPYTHON = True
except ImportError:
    _HAS_IPYTHON = False


def _in_jupyter() -> bool:
    """Check if running in Jupyter notebook/lab."""
    if not _HAS_IPYTHON:
        return False
    try:
        from IPython import get_ipython
        shell = get_ipython()
        if shell is None:
            return False
        shell_name = shell.__class__.__name__
        return shell_name in ("ZMQInteractiveShell", "Shell")
    except (ImportError, AttributeError):
        return False


def _sanitize_filename(name: str) -> str:
    """Sanitize a string for use as filename.

    Uses str.translate for O(n) efficiency instead of multiple replace calls.
    """
    # Translation table: replace problematic characters with underscore
    _SANITIZE_TABLE = str.maketrans({
        '/': '_', '\\': '_', ':': '_', '*': '_', '?': '_',
        '"': '_', '<': '_', '>': '_', '|': '_', ' ': '_'
    })
    return name.translate(_SANITIZE_TABLE)


def _ensure_temp_dir() -> Path:
    """Ensure temporary directory exists."""
    TEMP_GRAPHS_DIR.mkdir(parents=True, exist_ok=True)
    return TEMP_GRAPHS_DIR


def visualize(
    graph: Any,
    title: str = "T1C-Viz",
    width: int = 1200,
    height: int = 800,
) -> Optional[Any]:
    """Display a T1C-IR graph interactively.

    In Jupyter notebooks, displays an embedded IFrame.
    Outside Jupyter, opens the visualization in the default browser.

    Args:
        graph: T1C-IR Graph object or path to .t1c file
        title: Visualization title
        width: Viewport width (for Jupyter)
        height: Viewport height (for Jupyter)

    Returns:
        In Jupyter: IFrame object
        Outside Jupyter: Path to generated HTML file

    Example:
        from t1c import ir, viz
        graph = ir.read('model.t1c')
        viz.visualize(graph, title="My SNN Model")
    """
    # Convert graph to data dict
    data = graph_to_dict(graph)

    # Render HTML
    html = render_html(data, title=title, width=width, height=height)

    # Generate unique filename
    import hashlib
    import time

    name_hash = hashlib.md5(title.encode()).hexdigest()[:8]
    timestamp = int(time.time())
    filename = f"{_sanitize_filename(title)}_{name_hash}_{timestamp}.html"

    # Write to temp directory
    _ensure_temp_dir()
    filepath = TEMP_GRAPHS_DIR / filename
    filepath.write_text(html, encoding="utf-8")

    if _in_jupyter():
        # Display as IFrame in Jupyter
        iframe = IFrame(src=str(filepath), width=width, height=height)
        ipython_display(iframe)
        return iframe
    else:
        # Open in browser
        url = filepath.as_uri()
        print(f"Visualization written to: {filepath}")
        webbrowser.open(url)
        return filepath


def export_html(
    graph: Any,
    path: Union[str, Path],
    title: str = "T1C-Viz",
) -> Path:
    """Export a T1C-IR graph to a standalone HTML file.

    Creates a self-contained HTML file that can be viewed offline
    or shared. All data is embedded in the file.

    Args:
        graph: T1C-IR Graph object or path to .t1c file
        path: Output file path
        title: Visualization title

    Returns:
        Path to the generated HTML file

    Example:
        from t1c import ir, viz
        graph = ir.read('model.t1c')
        path = viz.export_html(graph, "model.html", title="My SNN")
        print(f"Saved to: {path}")
    """
    # Convert graph to data dict
    data = graph_to_dict(graph)

    # Render HTML
    html = render_html(data, title=title)

    # Write to file
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html, encoding="utf-8")

    return path


def list_graphs() -> List[str]:
    """List visualization files in the temporary directory.

    Returns:
        List of HTML filenames in the temp directory

    Example:
        files = viz.list_graphs()
        print(files)  # ['model_a_xxx.html', 'model_b_xxx.html']
    """
    if not TEMP_GRAPHS_DIR.exists():
        return []

    return [f.name for f in TEMP_GRAPHS_DIR.glob("*.html")]
