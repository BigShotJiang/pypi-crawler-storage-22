"""Array encoding utilities for T1C-Viz.

Provides efficient base64 encoding of numpy arrays for embedding in HTML.
"""

import base64
from typing import Any, Dict, Union

import numpy as np


def encode_array(arr: np.ndarray) -> Dict[str, Any]:
    """Encode a numpy array for JSON embedding.

    Uses base64 encoding for efficient binary data transfer.
    Includes shape, dtype, and statistics for display without decoding.

    Args:
        arr: Numpy array to encode

    Returns:
        Dictionary with:
            - shape: List of dimensions
            - dtype: String dtype name
            - data: Base64-encoded binary data
            - stats: Min, max, mean, std statistics
            - size: Total number of elements
    """
    # Ensure contiguous array for proper byte encoding
    arr = np.ascontiguousarray(arr)

    # Compute statistics (handle empty arrays)
    if arr.size > 0:
        stats = {
            "min": float(np.min(arr)),
            "max": float(np.max(arr)),
            "mean": float(np.mean(arr)),
            "std": float(np.std(arr)),
        }
    else:
        stats = {"min": 0.0, "max": 0.0, "mean": 0.0, "std": 0.0}

    return {
        "shape": list(arr.shape),
        "dtype": str(arr.dtype),
        "data": base64.b64encode(arr.tobytes()).decode("ascii"),
        "stats": stats,
        "size": int(arr.size),
    }


def encode_value(value: Any) -> Any:
    """Encode a value for JSON serialization.

    Handles numpy arrays, scalars, and nested structures.

    Args:
        value: Value to encode (array, scalar, dict, list, or primitive)

    Returns:
        JSON-serializable representation
    """
    if isinstance(value, np.ndarray):
        return encode_array(value)
    elif isinstance(value, (np.integer, np.floating)):
        return value.item()
    elif isinstance(value, np.bool_):
        return bool(value)
    elif isinstance(value, dict):
        return {k: encode_value(v) for k, v in value.items()}
    elif isinstance(value, (list, tuple)):
        return [encode_value(v) for v in value]
    elif isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    else:
        return value


def decode_array(encoded: Dict[str, Any]) -> np.ndarray:
    """Decode a base64-encoded array back to numpy.

    Args:
        encoded: Dictionary from encode_array()

    Returns:
        Numpy array with original shape and dtype
    """
    data = base64.b64decode(encoded["data"])
    arr = np.frombuffer(data, dtype=encoded["dtype"])
    return arr.reshape(encoded["shape"])


def format_shape(shape: Union[list, tuple, np.ndarray]) -> str:
    """Format a shape for display.

    Args:
        shape: Shape tuple/list/array

    Returns:
        String like "[128, 784]" or "[3, 32, 32]"
    """
    if isinstance(shape, np.ndarray):
        shape = shape.tolist()
    return "[" + ", ".join(str(int(d)) for d in shape) + "]"


def format_size(size: int) -> str:
    """Format byte size for display.

    Args:
        size: Size in bytes

    Returns:
        Human-readable string like "1.2 MB" or "256 KB"
    """
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    elif size < 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} MB"
    else:
        return f"{size / (1024 * 1024 * 1024):.2f} GB"
