"""Pattern detection for T1C-Viz.

Detects architectural design patterns in T1C-IR graphs for grouped visualization.

Supported patterns:
- RepConv: Multi-branch reparameterizable convolution (3x3, 1x1, identity) - SpikeYOLO
- SPP: Spatial Pyramid Pooling (parallel MaxPool2d with different kernels) - YOLO
- SPPF: Spatial Pyramid Pooling Fast (sequential MaxPool2d chain) - YOLOv5+
- SkipConnection: Residual connection pattern (bypass path + processing path) - ResNet

Uses RustworkX for efficient graph traversal with cached adjacency lookups.
"""

from collections import deque
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set, Tuple

import rustworkx as rx


@dataclass
class PatternMatch:
    """Represents a detected pattern in the graph."""
    pattern_type: str  # "RepConv", "SPP", "SPPF", "SkipConnection"
    group_id: str      # Unique identifier for this group
    nodes: List[str]   # Node IDs that belong to this pattern
    entry_nodes: List[str]  # Nodes that receive input from outside the pattern
    exit_nodes: List[str]   # Nodes that send output outside the pattern
    metadata: Dict[str, Any]  # Pattern-specific metadata


# =============================================================================
# PatternDetector Class - Cached Adjacency for Efficient Pattern Detection
# =============================================================================

class PatternDetector:
    """Cached pattern detection using RustworkX for O(1) adjacency lookups.
    
    Instead of O(E) lookups per node, builds adjacency maps once and reuses them.
    This provides 10-100x speedup for pattern detection on large graphs.
    
    Example:
        detector = PatternDetector(graph)
        incoming = detector.get_incoming_edges('node_a')  # O(1)
        outgoing = detector.get_outgoing_edges('node_a')  # O(1)
        fan_outs = detector.find_fan_out_points()  # Single pass
    """
    
    def __init__(self, graph: Any):
        """Initialize detector with a T1C-IR graph.

        Args:
            graph: T1C-IR Graph object with nodes and edges
        """
        self.graph = graph
        self._rx_graph: Optional[rx.PyDiGraph] = None
        self._node_to_idx: Optional[Dict[str, int]] = None
        self._idx_to_node: Optional[Dict[int, str]] = None
        self._predecessors: Optional[Dict[int, List[int]]] = None
        self._successors: Optional[Dict[int, List[int]]] = None
        self._fan_out_cache: Optional[List[Tuple[str, List[str]]]] = None
        self._merge_points_cache: Optional[Dict[str, List[str]]] = None
    
    def _ensure_rx_graph(self) -> None:
        """Build RustworkX graph if not already built."""
        if self._rx_graph is not None:
            return
        
        # Try to use cached RustworkX graph from t1c.ir Graph if available
        if hasattr(self.graph, '_get_rx_graph'):
            self._rx_graph = self.graph._get_rx_graph()
            self._node_to_idx = self.graph._node_to_idx
            self._idx_to_node = self.graph._idx_to_node
        else:
            # Build our own RustworkX graph
            G = rx.PyDiGraph()
            self._node_to_idx = {}
            self._idx_to_node = {}
            
            for name in self.graph.nodes:
                idx = G.add_node(name)
                self._node_to_idx[name] = idx
                self._idx_to_node[idx] = name
            
            edge_list = [(self._node_to_idx[s], self._node_to_idx[d]) 
                         for s, d in self.graph.edges
                         if s in self._node_to_idx and d in self._node_to_idx]
            G.add_edges_from_no_data(edge_list)
            self._rx_graph = G
    
    def _ensure_adjacency(self) -> None:
        """Build predecessor/successor maps once."""
        if self._predecessors is not None:
            return
        
        self._ensure_rx_graph()
        G = self._rx_graph
        
        # Build adjacency maps in single pass - O(V)
        self._predecessors = {}
        self._successors = {}
        for i in range(len(G)):
            self._predecessors[i] = list(G.predecessor_indices(i))
            self._successors[i] = list(G.successor_indices(i))
    
    def get_incoming_edges(self, node_id: str) -> List[str]:
        """Get all nodes that have edges pointing to this node. O(1) lookup."""
        self._ensure_adjacency()
        if node_id not in self._node_to_idx:
            return []
        idx = self._node_to_idx[node_id]
        return [self._idx_to_node[i] for i in self._predecessors.get(idx, [])]
    
    def get_outgoing_edges(self, node_id: str) -> List[str]:
        """Get all nodes that this node points to. O(1) lookup."""
        self._ensure_adjacency()
        if node_id not in self._node_to_idx:
            return []
        idx = self._node_to_idx[node_id]
        return [self._idx_to_node[i] for i in self._successors.get(idx, [])]
    
    def find_fan_out_points(self) -> List[Tuple[str, List[str]]]:
        """Find all nodes that fan out to multiple destinations. Cached."""
        if self._fan_out_cache is not None:
            return self._fan_out_cache
        
        self._ensure_adjacency()
        fan_outs = []
        for name, idx in self._node_to_idx.items():
            successors = self._successors.get(idx, [])
            if len(successors) >= 2:
                fan_outs.append((name, [self._idx_to_node[i] for i in successors]))
        
        self._fan_out_cache = fan_outs
        return fan_outs
    
    def find_merge_points(self) -> Dict[str, List[str]]:
        """Find all nodes that receive input from multiple sources. Cached."""
        if self._merge_points_cache is not None:
            return self._merge_points_cache
        
        self._ensure_adjacency()
        merge_points = {}
        for name, idx in self._node_to_idx.items():
            predecessors = self._predecessors.get(idx, [])
            if len(predecessors) >= 2:
                merge_points[name] = [self._idx_to_node[i] for i in predecessors]
        
        self._merge_points_cache = merge_points
        return merge_points
    
    def find_path_to_node(
        self,
        start: str,
        end: str,
        exclude: Set[str],
        max_depth: int = 10
    ) -> Optional[List[str]]:
        """Find a path from start to end, excluding certain nodes.
        
        Uses BFS to find the shortest path.
        
        Returns:
            Path BETWEEN start and end (not including start, not including end).
            Empty list if start directly connects to end.
            None if no path exists.
        """
        if start == end:
            return []
        
        # Check direct connection
        if end in self.get_outgoing_edges(start):
            return []
        
        queue: deque = deque([(start, [])])
        visited = {start} | exclude
        
        while queue:
            current, path = queue.popleft()
            
            if len(path) > max_depth:
                continue
            
            for neighbor in self.get_outgoing_edges(current):
                if neighbor == end:
                    return path  # Path between start and end
                
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        
        return None


# =============================================================================
# Helper Functions (Legacy compatibility + standalone use)
# =============================================================================

def get_node_type(graph: Any, node_id: str) -> str:
    """Get the type name of a node."""
    if node_id in graph.nodes:
        return type(graph.nodes[node_id]).__name__
    return ""


def get_skip_type(graph: Any, node_id: str) -> Optional[str]:
    """Get the skip_type of a Skip node."""
    if node_id in graph.nodes:
        node = graph.nodes[node_id]
        if hasattr(node, 'skip_type'):
            return node.skip_type
    return None


def get_incoming_edges(graph: Any, node_id: str) -> List[str]:
    """Get all nodes that have edges pointing to this node.
    
    Note: For better performance on large graphs, use PatternDetector class.
    """
    return [src for src, dst in graph.edges if dst == node_id]


def get_outgoing_edges(graph: Any, node_id: str) -> List[str]:
    """Get all nodes that this node points to.
    
    Note: For better performance on large graphs, use PatternDetector class.
    """
    return [dst for src, dst in graph.edges if src == node_id]


def get_conv_kernel_size(node: Any) -> Optional[Tuple[int, int]]:
    """Extract kernel size from a Conv2d node."""
    if hasattr(node, 'weight') and node.weight is not None:
        shape = node.weight.shape
        if len(shape) >= 4:
            return (shape[2], shape[3])
    return None


def get_pool_kernel_size(node: Any) -> Optional[Tuple[int, int]]:
    """Extract kernel size from a MaxPool2d or AvgPool2d node."""
    if hasattr(node, 'kernel_size') and node.kernel_size is not None:
        ks = node.kernel_size
        if isinstance(ks, (list, tuple)) and len(ks) >= 2:
            return (ks[0], ks[1])
        elif isinstance(ks, int):
            return (ks, ks)
    return None


def is_residual_skip(node: Any) -> bool:
    """Check if a Skip node uses residual/add merge (element-wise addition).
    
    T1C-IR skip_type values:
        - 'residual' / 'add': Element-wise addition (ResNet-style)
        - 'concatenate' / 'concat': Channel concatenation (DenseNet-style)
        - 'passthrough' / 'identity': Identity bypass (single input)
    """
    if hasattr(node, 'skip_type'):
        return node.skip_type in ('residual', 'add')
    return False


def is_passthrough_skip(node: Any) -> bool:
    """Check if a Skip node is a passthrough/identity (single input bypass).
    
    T1C-IR skip_type values:
        - 'passthrough' / 'identity': Identity bypass
    """
    if hasattr(node, 'skip_type'):
        return node.skip_type in ('passthrough', 'identity')
    return False


def is_concatenate_skip(node: Any) -> bool:
    """Check if a Skip node uses concatenate merge (channel concatenation).
    
    T1C-IR skip_type values:
        - 'concatenate' / 'concat': Channel concatenation (DenseNet-style)
    """
    if hasattr(node, 'skip_type'):
        return node.skip_type in ('concatenate', 'concat')
    return False


def find_fan_out_points(graph: Any) -> List[Tuple[str, List[str]]]:
    """Find all nodes that fan out to multiple destinations."""
    edge_map: Dict[str, List[str]] = {}
    for src, dst in graph.edges:
        if src not in edge_map:
            edge_map[src] = []
        edge_map[src].append(dst)
    
    fan_outs = []
    for src, dsts in edge_map.items():
        if len(dsts) >= 2:
            fan_outs.append((src, dsts))
    
    return fan_outs


def find_merge_points(graph: Any) -> Dict[str, List[str]]:
    """Find all nodes that receive input from multiple sources."""
    incoming_map: Dict[str, List[str]] = {}
    for src, dst in graph.edges:
        if dst not in incoming_map:
            incoming_map[dst] = []
        incoming_map[dst].append(src)
    
    return {k: v for k, v in incoming_map.items() if len(v) >= 2}


# =============================================================================
# RepConv Pattern Detection
# =============================================================================

def detect_repconv_pattern(
    graph: Any,
    fan_out_node: str,
    branches: List[str],
    merge_node: str
) -> Optional[PatternMatch]:
    """
    Detect a RepConv pattern starting from a fan-out point.
    
    RepConv pattern (used in SpikeYOLO):
    - Fan-out node splits to multiple branches (fan-out is NOT part of pattern)
    - Branch 1: Conv2d with 3x3 kernel
    - Branch 2: Conv2d with 1x1 kernel
    - Branch 3: Skip node (identity/residual) - optional
    - All branches merge to a single merge node (Skip with residual)
    - Optional: LIF/neuron after merge is included in pattern
    """
    if len(branches) < 2:
        return None
    
    has_3x3_conv = False
    has_1x1_conv = False
    has_identity = False
    branch_details = []
    
    for branch_id in branches:
        node = graph.nodes.get(branch_id)
        if node is None:
            continue
            
        node_type = type(node).__name__
        
        if node_type == 'Conv2d':
            kernel_size = get_conv_kernel_size(node)
            if kernel_size == (3, 3):
                has_3x3_conv = True
                branch_details.append({'type': 'conv3x3', 'node': branch_id})
            elif kernel_size == (1, 1):
                has_1x1_conv = True
                branch_details.append({'type': 'conv1x1', 'node': branch_id})
            else:
                branch_details.append({'type': f'conv{kernel_size}', 'node': branch_id})
        elif node_type == 'Skip':
            # In RepConv, any Skip branch acts as the identity path
            # It can use 'residual' (for merge) or 'passthrough' (bypass)
            has_identity = True
            branch_details.append({'type': 'identity', 'node': branch_id})
        else:
            branch_details.append({'type': node_type.lower(), 'node': branch_id})
    
    # Classic RepConv requires at least 3x3 conv and 1x1 conv
    if has_3x3_conv and has_1x1_conv:
        pattern_nodes = branches + [merge_node]
        
        # Check if there's a LIF immediately after the merge
        exit_node = merge_node
        merge_outputs = get_outgoing_edges(graph, merge_node)
        if len(merge_outputs) == 1:
            post_merge_node = merge_outputs[0]
            post_merge_type = get_node_type(graph, post_merge_node)
            if post_merge_type == 'LIF':
                pattern_nodes.append(post_merge_node)
                exit_node = post_merge_node
        
        # Remove duplicates
        seen = set()
        unique_nodes = []
        for n in pattern_nodes:
            if n not in seen:
                seen.add(n)
                unique_nodes.append(n)
        
        return PatternMatch(
            pattern_type="RepConv",
            group_id=f"repconv_{merge_node}",
            nodes=unique_nodes,
            entry_nodes=branches,
            exit_nodes=[exit_node],
            metadata={
                'has_3x3': has_3x3_conv,
                'has_1x1': has_1x1_conv,
                'has_identity': has_identity,
                'branches': branch_details,
                'input_from': fan_out_node,
                'merge': merge_node
            }
        )
    
    return None


def detect_repconv_patterns(graph: Any) -> List[PatternMatch]:
    """Detect all RepConv patterns in a graph."""
    patterns = []
    used_nodes: Set[str] = set()
    
    fan_outs = find_fan_out_points(graph)
    merge_points = find_merge_points(graph)
    
    for fan_out_node, branches in fan_outs:
        for merge_node, merge_sources in merge_points.items():
            branch_set = set(branches)
            merge_source_set = set(merge_sources)
            
            if merge_source_set.issubset(branch_set) and len(merge_source_set) >= 2:
                repconv_branches = list(merge_source_set)
                
                candidate_nodes = set([merge_node] + repconv_branches)
                if not candidate_nodes.intersection(used_nodes):
                    pattern = detect_repconv_pattern(
                        graph, fan_out_node, repconv_branches, merge_node
                    )
                    if pattern:
                        patterns.append(pattern)
                        used_nodes.update(pattern.nodes)
                        break
    
    return patterns


# =============================================================================
# SPP Pattern Detection (Spatial Pyramid Pooling)
# =============================================================================

def detect_spp_pattern(
    graph: Any,
    fan_out_node: str,
    branches: List[str],
    concat_node: str
) -> Optional[PatternMatch]:
    """
    Detect an SPP (Spatial Pyramid Pooling) pattern.
    
    SPP pattern structure:
    - Fan-out to: Skip(passthrough) + multiple MaxPool2d with DIFFERENT kernel sizes
    - All branches DIRECTLY feed into Skip(concatenate)
    - No sequential chaining between pools (that's SPPF)
    
    Example from T1C:
        input -> identity (passthrough) ──────────────┐
              -> pool5 (5x5) ──────────────────────────┼─> concat
              -> pool9 (9x9) ──────────────────────────┤
              -> pool13 (13x13) ───────────────────────┘
    """
    # Verify concat node is Skip with concatenate
    concat = graph.nodes.get(concat_node)
    if concat is None or not is_concatenate_skip(concat):
        return None
    
    # Analyze branches
    identity_node = None
    pool_nodes = []
    pool_kernels = []
    
    for branch_id in branches:
        node = graph.nodes.get(branch_id)
        if node is None:
            continue
        
        node_type = type(node).__name__
        
        if node_type == 'Skip' and is_passthrough_skip(node):
            identity_node = branch_id
        elif node_type in ('MaxPool2d', 'AvgPool2d'):
            kernel = get_pool_kernel_size(node)
            pool_nodes.append(branch_id)
            pool_kernels.append(kernel)
    
    # SPP requires: identity + at least 2 pools with different kernels
    if identity_node is None or len(pool_nodes) < 2:
        return None
    
    # Check that pools have different kernel sizes (SPP characteristic)
    unique_kernels = set(pool_kernels)
    if len(unique_kernels) < 2:
        # Same kernel sizes = more likely SPPF, not SPP
        return None
    
    # Verify all pools come directly from fan_out (no chaining)
    # In SPP, input -> pool_a, input -> pool_b directly
    for pool_node in pool_nodes:
        incoming = get_incoming_edges(graph, pool_node)
        if len(incoming) != 1 or incoming[0] != fan_out_node:
            # Pool has input from another pool = SPPF pattern
            return None
    
    # Build pattern
    pattern_nodes = [identity_node] + pool_nodes + [concat_node]
    
    # Remove duplicates
    seen = set()
    unique_nodes = []
    for n in pattern_nodes:
        if n not in seen:
            seen.add(n)
            unique_nodes.append(n)
    
    return PatternMatch(
        pattern_type="SPP",
        group_id=f"spp_{concat_node}",
        nodes=unique_nodes,
        entry_nodes=[identity_node] + pool_nodes,
        exit_nodes=[concat_node],
        metadata={
            'identity_node': identity_node,
            'pool_nodes': pool_nodes,
            'pool_kernels': pool_kernels,
            'input_from': fan_out_node,
            'concat_node': concat_node,
            'num_scales': len(pool_nodes) + 1  # +1 for identity
        }
    )


def detect_spp_patterns(graph: Any) -> List[PatternMatch]:
    """Detect all SPP (Spatial Pyramid Pooling) patterns in a graph."""
    patterns = []
    used_nodes: Set[str] = set()
    
    fan_outs = find_fan_out_points(graph)
    merge_points = find_merge_points(graph)
    
    for fan_out_node, branches in fan_outs:
        for concat_node, concat_sources in merge_points.items():
            # Check if this is a Skip(concatenate)
            if get_skip_type(graph, concat_node) not in ('concatenate', 'concat'):
                continue
            
            # All branches from this fan-out should feed into concat
            branch_set = set(branches)
            source_set = set(concat_sources)
            
            # At least identity + 2 pools
            if len(source_set) < 3:
                continue
            
            # Check overlap
            if source_set.issubset(branch_set):
                candidate_nodes = set([concat_node] + list(source_set))
                if not candidate_nodes.intersection(used_nodes):
                    pattern = detect_spp_pattern(
                        graph, fan_out_node, list(source_set), concat_node
                    )
                    if pattern:
                        patterns.append(pattern)
                        used_nodes.update(pattern.nodes)
                        break
    
    return patterns


# =============================================================================
# SPPF Pattern Detection (Spatial Pyramid Pooling Fast)
# =============================================================================

def detect_sppf_pattern(
    graph: Any,
    fan_out_node: str,
    concat_node: str,
    concat_sources: List[str]
) -> Optional[PatternMatch]:
    """
    Detect an SPPF (Spatial Pyramid Pooling Fast) pattern.
    
    SPPF pattern structure:
    - Fan-out to: Skip(passthrough) + first pool
    - Pools are SEQUENTIAL: pool1 -> pool2 -> pool3 (same kernel size)
    - Each pool ALSO feeds into concat (multi-output chain)
    
    Example from T1C:
        input -> identity (passthrough) ────────────────────────────────────────┐
              -> pool1 (5x5) -> pool2 (5x5) -> pool3 (5x5) ─────────────────────┼─> concat
                   │              │                                              │
                   └──────────────┴──────────────────────────────────────────────┘
    """
    # Verify concat node is Skip with concatenate
    concat = graph.nodes.get(concat_node)
    if concat is None or not is_concatenate_skip(concat):
        return None
    
    # Find identity and pools among concat sources
    identity_node = None
    pool_nodes_feeding_concat = []
    
    for src in concat_sources:
        node = graph.nodes.get(src)
        if node is None:
            continue
        
        node_type = type(node).__name__
        
        if node_type == 'Skip' and is_passthrough_skip(node):
            identity_node = src
        elif node_type in ('MaxPool2d', 'AvgPool2d'):
            pool_nodes_feeding_concat.append(src)
    
    # SPPF requires: identity + at least 2 pools
    if identity_node is None or len(pool_nodes_feeding_concat) < 2:
        return None
    
    # Check that pools form a sequential chain with SAME kernel
    # Build the chain: find which pool comes from fan_out, then follow the chain
    first_pool = None
    for pool in pool_nodes_feeding_concat:
        incoming = get_incoming_edges(graph, pool)
        if fan_out_node in incoming:
            first_pool = pool
            break
    
    if first_pool is None:
        return None
    
    # Trace the chain
    chain = [first_pool]
    current = first_pool
    pool_kernels = []
    
    first_kernel = get_pool_kernel_size(graph.nodes[first_pool])
    pool_kernels.append(first_kernel)
    
    while True:
        outputs = get_outgoing_edges(graph, current)
        next_pool = None
        for out in outputs:
            if out in pool_nodes_feeding_concat and out not in chain:
                next_pool = out
                break
        
        if next_pool is None:
            break
        
        chain.append(next_pool)
        current = next_pool
        kernel = get_pool_kernel_size(graph.nodes[next_pool])
        pool_kernels.append(kernel)
    
    # SPPF characteristic: same kernel size for all pools in chain
    if len(set(pool_kernels)) != 1:
        # Different kernels = SPP pattern
        return None
    
    # Verify each pool in chain also feeds into concat (SPPF multi-output)
    for pool in chain:
        outputs = get_outgoing_edges(graph, pool)
        if concat_node not in outputs:
            return None
    
    # Build pattern
    pattern_nodes = [identity_node] + chain + [concat_node]
    
    # Remove duplicates
    seen = set()
    unique_nodes = []
    for n in pattern_nodes:
        if n not in seen:
            seen.add(n)
            unique_nodes.append(n)
    
    return PatternMatch(
        pattern_type="SPPF",
        group_id=f"sppf_{concat_node}",
        nodes=unique_nodes,
        entry_nodes=[identity_node, first_pool],
        exit_nodes=[concat_node],
        metadata={
            'identity_node': identity_node,
            'pool_chain': chain,
            'kernel_size': pool_kernels[0] if pool_kernels else None,
            'chain_depth': len(chain),
            'input_from': fan_out_node,
            'concat_node': concat_node,
        }
    )


def detect_sppf_patterns(graph: Any) -> List[PatternMatch]:
    """Detect all SPPF (Spatial Pyramid Pooling Fast) patterns in a graph."""
    patterns = []
    used_nodes: Set[str] = set()
    
    fan_outs = find_fan_out_points(graph)
    merge_points = find_merge_points(graph)
    
    for fan_out_node, branches in fan_outs:
        for concat_node, concat_sources in merge_points.items():
            # Check if this is a Skip(concatenate) with 3+ inputs
            if get_skip_type(graph, concat_node) not in ('concatenate', 'concat'):
                continue
            
            if len(concat_sources) < 3:
                continue
            
            candidate_nodes = set([concat_node] + concat_sources)
            if not candidate_nodes.intersection(used_nodes):
                pattern = detect_sppf_pattern(
                    graph, fan_out_node, concat_node, concat_sources
                )
                if pattern:
                    patterns.append(pattern)
                    used_nodes.update(pattern.nodes)
                    break
    
    return patterns


# =============================================================================
# Skip Connection Pattern Detection (Residual Connections)
# =============================================================================

def detect_skip_connection_patterns(graph: Any) -> List[PatternMatch]:
    """
    Detect all Skip Connection (residual) patterns in a graph.
    
    T1C-IR supports TWO residual block structures:
    
    Structure A: Skip as bypass (Skip outputs to separate merge node)
        fork ──> Skip(residual) ─────────────────> merge (LIF/other)
             └──> [conv -> lif -> conv] ──────────┘
    
    Structure B: Skip as merge (Skip IS the merge point - SpikeYOLO uses this)
        fork ──> Skip(residual) <──────── [conv -> lif -> conv]
             └───────────────────────────────────┘
        Skip receives: direct from fork + end of processing path
        Skip outputs: to LIF/next layer
    
    Both are valid ResNet-style residual connections.
    """
    patterns = []
    used_nodes: Set[str] = set()
    
    # =================================================================
    # Structure B: Skip node IS the merge point (receives 2+ inputs)
    # This is used in SpikeYOLO and is the more common T1C-IR pattern
    # =================================================================
    merge_points = find_merge_points(graph)
    
    for skip_node, skip_sources in merge_points.items():
        # Check if this merge point is a Skip(residual)
        node = graph.nodes.get(skip_node)
        if node is None:
            continue
        
        node_type = type(node).__name__
        if node_type != 'Skip' or not is_residual_skip(node):
            continue
        
        # Skip already used?
        if skip_node in used_nodes:
            continue
        
        # We need 2+ sources: one bypass, one or more from processing
        if len(skip_sources) < 2:
            continue
        
        # Find the common fork node (node that feeds both bypass and processing)
        # The bypass goes: fork -> skip directly
        # The processing goes: fork -> conv -> ... -> skip
        
        bypass_candidates = []  # Direct edges from some node to skip
        processing_candidates = []  # Longer paths to skip
        
        for src in skip_sources:
            # Check how the source connects to the rest of the graph
            src_inputs = get_incoming_edges(graph, src)
            
            # Is there a common ancestor that also directly connects to skip?
            for other_src in skip_sources:
                if other_src == src:
                    continue
                
                # Check if other_src is a direct parent of src's path
                if other_src in src_inputs:
                    # Found: other_src -> src -> skip (processing path)
                    # And: other_src -> skip should exist (bypass)
                    if other_src in skip_sources:
                        # other_src feeds skip directly AND through src
                        bypass_candidates.append(other_src)
                        processing_candidates.append({'start': src, 'fork': other_src})
        
        # Alternative detection: find fork nodes that fan out to multiple skip sources
        fan_outs = find_fan_out_points(graph)
        for fork_node, fork_dests in fan_outs:
            # Check if fork connects directly to skip (bypass)
            if skip_node not in fork_dests:
                continue
            
            # Check if fork also starts a processing path that ends at skip
            for dest in fork_dests:
                if dest == skip_node:
                    continue  # This is the bypass, skip it
                
                # Can we trace from dest to skip?
                path = find_path_to_node(graph, dest, skip_node, exclude={fork_node}, max_depth=10)
                if path is not None:
                    # Found processing path: fork -> dest -> ... -> skip
                    processing_path = [dest] + path if path else [dest]
                    
                    # Check if processing path nodes are already used
                    candidate_nodes = {skip_node} | set(processing_path)
                    if candidate_nodes.intersection(used_nodes):
                        continue
                    
                    # Get processing path types
                    path_types = []
                    for n in processing_path:
                        if n in graph.nodes:
                            path_types.append(type(graph.nodes[n]).__name__)
                    
                    # Find exit node (what skip outputs to)
                    skip_outputs = get_outgoing_edges(graph, skip_node)
                    exit_node = skip_outputs[0] if skip_outputs else skip_node
                    
                    pattern = PatternMatch(
                        pattern_type="SkipConnection",
                        group_id=f"skip_{fork_node}_{skip_node}",
                        nodes=[skip_node] + processing_path,
                        entry_nodes=[skip_node, processing_path[0]] if processing_path else [skip_node],
                        exit_nodes=[exit_node],
                        metadata={
                            'fork_node': fork_node,
                            'skip_node': skip_node,
                            'merge_node': skip_node,  # Skip IS the merge in Structure B
                            'processing_path': processing_path,
                            'processing_depth': len(processing_path),
                            'path_types': path_types,
                            'structure': 'B',  # Skip as merge
                        }
                    )
                    patterns.append(pattern)
                    used_nodes.update(pattern.nodes)
                    break  # Found pattern for this skip node
            
            # If we found a pattern, don't check more fan_outs for this skip
            if skip_node in used_nodes:
                break
    
    # =================================================================
    # Structure A: Skip as bypass (Skip outputs to separate merge)
    # Fork -> Skip -> Merge <- Processing
    # =================================================================
    fan_outs = find_fan_out_points(graph)
    
    for fork_node, destinations in fan_outs:
        for dest in destinations:
            node = graph.nodes.get(dest)
            if node is None:
                continue
            
            node_type = type(node).__name__
            if node_type != 'Skip' or not is_residual_skip(node):
                continue
            
            skip_node = dest
            if skip_node in used_nodes:
                continue
            
            # Find where skip outputs to (potential merge)
            skip_outputs = get_outgoing_edges(graph, skip_node)
            if not skip_outputs:
                continue
            
            for merge_candidate in skip_outputs:
                merge_inputs = get_incoming_edges(graph, merge_candidate)
                if len(merge_inputs) < 2:
                    continue
                
                # Find processing path from fork to merge (not through skip)
                for other_dest in destinations:
                    if other_dest == skip_node:
                        continue
                    
                    path = find_path_to_node(graph, other_dest, merge_candidate, 
                                            exclude={skip_node}, max_depth=10)
                    if path is not None:
                        processing_path = [other_dest] + path if path else [other_dest]
                        
                        candidate_nodes = {skip_node} | set(processing_path)
                        if candidate_nodes.intersection(used_nodes):
                            continue
                        
                        path_types = [type(graph.nodes[n]).__name__ 
                                     for n in processing_path if n in graph.nodes]
                        
                        pattern = PatternMatch(
                            pattern_type="SkipConnection",
                            group_id=f"skip_{skip_node}_{merge_candidate}",
                            nodes=[skip_node] + processing_path,
                            entry_nodes=[skip_node, processing_path[0]] if processing_path else [skip_node],
                            exit_nodes=[merge_candidate],
                            metadata={
                                'fork_node': fork_node,
                                'skip_node': skip_node,
                                'merge_node': merge_candidate,
                                'processing_path': processing_path,
                                'processing_depth': len(processing_path),
                                'path_types': path_types,
                                'structure': 'A',  # Skip as bypass
                            }
                        )
                        patterns.append(pattern)
                        used_nodes.update(pattern.nodes)
                        break
                
                if skip_node in used_nodes:
                    break
    
    return patterns


def find_path_to_node(
    graph: Any,
    start: str,
    end: str,
    exclude: Set[str],
    max_depth: int = 10
) -> Optional[List[str]]:
    """
    Find a path from start to end, excluding certain nodes.
    Uses BFS to find the shortest path.
    
    Returns the path BETWEEN start and end (not including start, not including end).
    Returns empty list if start directly connects to end.
    Returns None if no path exists.
    """
    if start == end:
        return []
    
    # Check direct connection
    if end in get_outgoing_edges(graph, start):
        return []
    
    from collections import deque
    
    queue: deque = deque([(start, [])])
    visited = {start} | exclude
    
    while queue:
        current, path = queue.popleft()
        
        if len(path) > max_depth:
            continue
        
        for neighbor in get_outgoing_edges(graph, current):
            if neighbor == end:
                return path  # Path between start and end
            
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))
    
    return None


# =============================================================================
# Main Detection Function
# =============================================================================

def detect_all_patterns(graph: Any) -> List[PatternMatch]:
    """
    Detect all known architectural patterns in a graph.
    
    Supported patterns:
    - RepConv: Multi-branch reparameterizable convolution (3x3, 1x1, identity)
               Used in SpikeYOLO architecture.
    - SPP: Spatial Pyramid Pooling (parallel MaxPool2d with different kernels)
           Used in YOLO for multi-scale feature extraction.
    - SPPF: Spatial Pyramid Pooling Fast (sequential MaxPool2d chain)
            Used in YOLOv5+ for efficient multi-scale features.
    - SkipConnection: Residual connection (bypass + processing path)
                      Used in ResNet-style architectures.
    
    Args:
        graph: T1C-IR Graph object

    Returns:
        List of all detected patterns
    """
    all_patterns = []
    used_nodes: Set[str] = set()
    
    # 1. Detect RepConv patterns (highest priority - complex multi-branch)
    repconv_patterns = detect_repconv_patterns(graph)
    for p in repconv_patterns:
        all_patterns.append(p)
        used_nodes.update(p.nodes)
    
    # 2. Detect SPP patterns (parallel pooling)
    spp_patterns = detect_spp_patterns(graph)
    for p in spp_patterns:
        if not set(p.nodes).intersection(used_nodes):
            all_patterns.append(p)
            used_nodes.update(p.nodes)
    
    # 3. Detect SPPF patterns (sequential pooling)
    sppf_patterns = detect_sppf_patterns(graph)
    for p in sppf_patterns:
        if not set(p.nodes).intersection(used_nodes):
            all_patterns.append(p)
            used_nodes.update(p.nodes)
    
    # 4. Detect Skip Connection patterns (residual shortcuts)
    skip_patterns = detect_skip_connection_patterns(graph)
    for p in skip_patterns:
        if not set(p.nodes).intersection(used_nodes):
            all_patterns.append(p)
            used_nodes.update(p.nodes)
    
    return all_patterns


def build_group_hierarchy(
    graph: Any,
    patterns: List[PatternMatch]
) -> Dict[str, Any]:
    """
    Build a hierarchy of grouped nodes for visualization.
    
    Args:
        graph: T1C-IR Graph object
        patterns: List of detected patterns
        
    Returns:
        Dictionary with:
            - groups: Dict[group_id, PatternMatch]
            - node_to_group: Dict[node_id, group_id]
            - ungrouped_nodes: Set[node_id]
    """
    groups = {p.group_id: p for p in patterns}
    
    node_to_group: Dict[str, str] = {}
    for pattern in patterns:
        for node_id in pattern.nodes:
            node_to_group[node_id] = pattern.group_id
    
    all_node_ids = set(graph.nodes.keys())
    grouped_node_ids = set(node_to_group.keys())
    ungrouped_nodes = all_node_ids - grouped_node_ids
    
    return {
        'groups': groups,
        'node_to_group': node_to_group,
        'ungrouped_nodes': ungrouped_nodes
    }
