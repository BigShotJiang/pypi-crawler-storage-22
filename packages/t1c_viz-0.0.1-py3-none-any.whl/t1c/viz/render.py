"""HTML rendering for T1C-Viz.

Generates self-contained HTML files with embedded JavaScript and CSS.
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional

# Get templates directory
TEMPLATES_DIR = Path(__file__).parent / "templates"


def load_template(name: str) -> str:
    """Load a template file.

    Args:
        name: Template filename

    Returns:
        Template contents as string
    """
    template_path = TEMPLATES_DIR / name
    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")
    return template_path.read_text(encoding="utf-8")


def render_html(
    data: Dict[str, Any],
    title: str = "T1C-Viz",
    width: int = 1200,
    height: int = 800,
) -> str:
    """Render graph data to standalone HTML.

    Generates a self-contained HTML file with all JavaScript, CSS,
    and data embedded. Can be viewed offline in any modern browser.

    Args:
        data: Graph data dict from graph_to_dict()
        title: Page title
        width: Default viewport width
        height: Default viewport height

    Returns:
        Complete HTML string

    Example:
        data = graph_to_dict(graph)
        html = render_html(data, title="My SNN Model")
        Path("model.html").write_text(html)
    """
    # Load the main template
    template = load_template("viewer.html")

    # Serialize data to JSON
    data_json = json.dumps(data, ensure_ascii=False)

    # Render template with data
    html = template.replace("{{TITLE}}", _escape_html(title))
    html = html.replace("{{DATA_JSON}}", data_json)
    html = html.replace("{{WIDTH}}", str(width))
    html = html.replace("{{HEIGHT}}", str(height))

    return html


def _escape_html(text: str) -> str:
    """Escape HTML special characters.

    Args:
        text: Input text

    Returns:
        HTML-safe text
    """
    return (
        text
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )
